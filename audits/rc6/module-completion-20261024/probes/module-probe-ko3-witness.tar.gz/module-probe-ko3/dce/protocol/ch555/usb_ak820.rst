                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000027                        548 _control_setup_sloc1_1_0:
      000027                        549 	.ds 1
      000028                        550 _control_setup_sloc3_1_0:
      000028                        551 	.ds 2
      00002A                        552 _control_setup_sloc4_1_0:
      00002A                        553 	.ds 2
      00002C                        554 _ak820_usb_send_sloc0_1_0:
      00002C                        555 	.ds 2
      00002E                        556 _ak820_usb_send_sloc1_1_0:
      00002E                        557 	.ds 1
      00002F                        558 _ak820_usb_raw_task_sloc0_1_0:
      00002F                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000017                        576 _control_setup_valid_interface_10000_286:
      000017                        577 	.ds 1
      000018                        578 _control_setup_zero_index_10000_286:
      000018                        579 	.ds 1
      000019                        580 _control_setup_zero_value_10000_286:
      000019                        581 	.ds 1
      00001A                        582 _control_setup_zero_length_10000_286:
      00001A                        583 	.ds 1
      00001B                        584 _control_setup_sloc0_1_0:
      00001B                        585 	.ds 1
      00001C                        586 _control_setup_sloc2_1_0:
      00001C                        587 	.ds 1
      00001D                        588 _ak820_usb_try_send_sloc0_1_0:
      00001D                        589 	.ds 1
      00001E                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001E                        591 	.ds 1
      00001F                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001F                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      0007C6                        602 _D0SetupReqCode::
      0007C6                        603 	.ds 1
      0007C7                        604 _D0SetupLen::
      0007C7                        605 	.ds 2
      0007C9                        606 _pD0Descr::
      0007C9                        607 	.ds 3
      0007CC                        608 _D0UsbConfig::
      0007CC                        609 	.ds 1
      0007CD                        610 _USB_EnumStatus::
      0007CD                        611 	.ds 1
      0007CE                        612 _USB_SleepStatus::
      0007CE                        613 	.ds 1
      0007CF                        614 _MCU_Sleep_Operate::
      0007CF                        615 	.ds 1
      0007D0                        616 _KB_USB_UpStatus::
      0007D0                        617 	.ds 1
      0007D1                        618 _KB_USB_SetReport::
      0007D1                        619 	.ds 1
      0007D2                        620 _ak820_boot_stage::
      0007D2                        621 	.ds 1
      0007D3                        622 _ak820_main_heartbeat::
      0007D3                        623 	.ds 1
      0007D4                        624 _raw_state:
      0007D4                        625 	.ds 1
      0007D5                        626 _raw_buffer:
      0007D5                        627 	.ds 32
      0007F5                        628 _raw_reply_without_nvm:
      0007F5                        629 	.ds 1
      0007F6                        630 _keyboard_reset:
      0007F6                        631 	.ds 1
      0007F7                        632 _input_snapshot:
      0007F7                        633 	.ds 46
      000825                        634 _control_phase:
      000825                        635 	.ds 1
      000826                        636 _output_kind:
      000826                        637 	.ds 1
      000827                        638 _output_report_id:
      000827                        639 	.ds 1
      000828                        640 _control_zlp:
      000828                        641 	.ds 1
      000829                        642 _control_pointer:
      000829                        643 	.ds 2
      00082B                        644 _descriptor_select_PARM_2:
      00082B                        645 	.ds 1
      00082C                        646 _descriptor_select_PARM_3:
      00082C                        647 	.ds 2
      00082E                        648 _descriptor_select_type_10000_268:
      00082E                        649 	.ds 1
      00082F                        650 _control_setup_length_10000_286:
      00082F                        651 	.ds 2
      000831                        652 _control_setup_offset_10000_286:
      000831                        653 	.ds 1
      000832                        654 _ak820_usb_send_PARM_2:
      000832                        655 	.ds 2
      000834                        656 _ak820_usb_send_PARM_3:
      000834                        657 	.ds 1
      000835                        658 _ak820_usb_send_endpoint_10000_422:
      000835                        659 	.ds 1
      000836                        660 _ak820_usb_send_offset_10000_423:
      000836                        661 	.ds 1
      000837                        662 _ak820_usb_try_send_PARM_2:
      000837                        663 	.ds 2
      000839                        664 _ak820_usb_try_send_PARM_3:
      000839                        665 	.ds 1
      00083A                        666 _ak820_usb_try_send_endpoint_10000_443:
      00083A                        667 	.ds 1
      00083B                        668 _ak820_usb_try_send_sent_10000_444:
      00083B                        669 	.ds 1
      00083C                        670 _ak820_usb_raw_send_PARM_2:
      00083C                        671 	.ds 1
      00083D                        672 _ak820_usb_raw_send_report_10000_459:
      00083D                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005EC5                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005EC5 90 07 D4         [24]  727 	mov	dptr,#_raw_state
      005EC8 E0               [24]  728 	movx	a,@dptr
      005EC9 FF               [12]  729 	mov	r7,a
      005ECA BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005ECD 80 1C            [24]  731 	sjmp	00101$
      005ECF                        732 00130$:
      005ECF 90 07 D4         [24]  733 	mov	dptr,#_raw_state
      005ED2 E0               [24]  734 	movx	a,@dptr
      005ED3 FF               [12]  735 	mov	r7,a
      005ED4 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005ED7 80 12            [24]  737 	sjmp	00101$
      005ED9                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005ED9 90 07 D4         [24]  740 	mov	dptr,#_raw_state
      005EDC E0               [24]  741 	movx	a,@dptr
      005EDD FF               [12]  742 	mov	r7,a
      005EDE BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005EE1 80 08            [24]  744 	sjmp	00101$
      005EE3                        745 00132$:
      005EE3 90 07 D4         [24]  746 	mov	dptr,#_raw_state
      005EE6 E0               [24]  747 	movx	a,@dptr
      005EE7 FF               [12]  748 	mov	r7,a
      005EE8 BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005EEB                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005EEB 90 07 D4         [24]  752 	mov	dptr,#_raw_state
      005EEE 74 07            [12]  753 	mov	a,#0x07
      005EF0 F0               [24]  754 	movx	@dptr,a
      005EF1 80 05            [24]  755 	sjmp	00103$
      005EF3                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005EF3 90 07 D4         [24]  758 	mov	dptr,#_raw_state
      005EF6 E4               [12]  759 	clr	a
      005EF7 F0               [24]  760 	movx	@dptr,a
      005EF8                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005EF8 90 08 26         [24]  763 	mov	dptr,#_output_kind
      005EFB E4               [12]  764 	clr	a
      005EFC F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005EFD 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005EFE                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005EFE 90 07 D4         [24]  777 	mov	dptr,#_raw_state
      005F01 E0               [24]  778 	movx	a,@dptr
      005F02 FF               [12]  779 	mov	r7,a
      005F03 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005F06 90 07 D4         [24]  781 	mov	dptr,#_raw_state
      005F09 74 06            [12]  782 	mov	a,#0x06
      005F0B F0               [24]  783 	movx	@dptr,a
      005F0C 22               [24]  784 	ret
      005F0D                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005F0D 90 07 D4         [24]  787 	mov	dptr,#_raw_state
      005F10 E0               [24]  788 	movx	a,@dptr
      005F11 FF               [12]  789 	mov	r7,a
      005F12 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005F15 90 07 D4         [24]  791 	mov	dptr,#_raw_state
      005F18 E4               [12]  792 	clr	a
      005F19 F0               [24]  793 	movx	@dptr,a
      005F1A                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005F1A 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005F1B                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005F1B 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005F1E 74 01            [12]  809 	mov	a,#0x01
      005F20 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F21 F5 82            [12]  812 	mov	dpl,a
      005F23 74 12            [12]  813 	mov	a,#0x12
      005F25 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F26 A3               [24]  816 	inc	dptr
      005F27 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F28 A3               [24]  819 	inc	dptr
      005F29 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005F2A 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005F2D E4               [12]  823 	clr	a
      005F2E F0               [24]  824 	movx	@dptr,a
      005F2F 15 82            [12]  825 	dec	dpl
      005F31 F0               [24]  826 	movx	@dptr,a
      005F32 15 82            [12]  827 	dec	dpl
      005F34 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005F35 FF               [12]  830 	mov	r7,a
      005F36                        831 00103$:
      005F36 EF               [12]  832 	mov	a,r7
      005F37 24 F7            [12]  833 	add	a, #_input_snapshot
      005F39 F5 82            [12]  834 	mov	dpl,a
      005F3B E4               [12]  835 	clr	a
      005F3C 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005F3E F5 83            [12]  837 	mov	dph,a
      005F40 E4               [12]  838 	clr	a
      005F41 F0               [24]  839 	movx	@dptr,a
      005F42 0F               [12]  840 	inc	r7
      005F43 BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      005F46                        842 00139$:
      005F46 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005F48 90 07 FF         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005F4B 74 06            [12]  846 	mov	a,#0x06
      005F4D F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005F4E 90 08 1F         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005F51 03               [12]  850 	rr	a
      005F52 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005F53 90 08 22         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      005F56 04               [12]  854 	inc	a
      005F57 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005F58 7F 00            [12]  857 	mov	r7,#0x00
      005F5A                        858 00105$:
      005F5A 8F 06            [24]  859 	mov	ar6,r7
      005F5C 74 C0            [12]  860 	mov	a,#0xc0
      005F5E 2E               [12]  861 	add	a, r6
      005F5F F5 82            [12]  862 	mov	dpl,a
      005F61 74 10            [12]  863 	mov	a,#0x10
      005F63 24 00            [12]  864 	add	a, #0x00
      005F65 F5 83            [12]  865 	mov	dph,a
      005F67 E4               [12]  866 	clr	a
      005F68 F0               [24]  867 	movx	@dptr,a
      005F69 0F               [12]  868 	inc	r7
      005F6A BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005F6D                        870 00141$:
      005F6D 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005F6F 02 5E C5         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005F72                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005F72 90 07 D4         [24]  884 	mov	dptr,#_raw_state
      005F75 E0               [24]  885 	movx	a,@dptr
      005F76 FF               [12]  886 	mov	r7,a
      005F77 BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005F7A 90 07 D4         [24]  888 	mov	dptr,#_raw_state
      005F7D E4               [12]  889 	clr	a
      005F7E F0               [24]  890 	movx	@dptr,a
      005F7F                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005F7F 90 08 26         [24]  893 	mov	dptr,#_output_kind
      005F82 E4               [12]  894 	clr	a
      005F83 F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005F84 90 08 25         [24]  897 	mov	dptr,#_control_phase
      005F87 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005F88 90 07 C6         [24]  900 	mov	dptr,#_D0SetupReqCode
      005F8B 14               [12]  901 	dec	a
      005F8C F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005F8D 90 22 00         [24]  904 	mov	dptr,#0x2200
      005F90 74 CF            [12]  905 	mov	a,#0xcf
      005F92 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005F93 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      005F94                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005F94 90 07 C7         [24]  921 	mov	dptr,#_D0SetupLen
      005F97 E0               [24]  922 	movx	a,@dptr
      005F98 FE               [12]  923 	mov	r6,a
      005F99 A3               [24]  924 	inc	dptr
      005F9A E0               [24]  925 	movx	a,@dptr
      005F9B FF               [12]  926 	mov	r7,a
      005F9C C3               [12]  927 	clr	c
      005F9D 74 40            [12]  928 	mov	a,#0x40
      005F9F 9E               [12]  929 	subb	a,r6
      005FA0 E4               [12]  930 	clr	a
      005FA1 9F               [12]  931 	subb	a,r7
      005FA2 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      005FA4 7E 40            [12]  934 	mov	r6,#0x40
      005FA6 80 07            [24]  935 	sjmp	00110$
      005FA8                        936 00109$:
      005FA8 90 07 C7         [24]  937 	mov	dptr,#_D0SetupLen
      005FAB E0               [24]  938 	movx	a,@dptr
      005FAC FE               [12]  939 	mov	r6,a
      005FAD A3               [24]  940 	inc	dptr
      005FAE E0               [24]  941 	movx	a,@dptr
      005FAF                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005FAF 7F 00            [12]  944 	mov	r7,#0x00
      005FB1                        945 00105$:
      005FB1 C3               [12]  946 	clr	c
      005FB2 EF               [12]  947 	mov	a,r7
      005FB3 9E               [12]  948 	subb	a,r6
      005FB4 50 2A            [24]  949 	jnc	00101$
      005FB6 8F 04            [24]  950 	mov	ar4,r7
      005FB8 74 10            [12]  951 	mov	a,#0x10
      005FBA 24 00            [12]  952 	add	a, #0x00
      005FBC FD               [12]  953 	mov	r5,a
      005FBD 90 08 29         [24]  954 	mov	dptr,#_control_pointer
      005FC0 E0               [24]  955 	movx	a,@dptr
      005FC1 FA               [12]  956 	mov	r2,a
      005FC2 A3               [24]  957 	inc	dptr
      005FC3 E0               [24]  958 	movx	a,@dptr
      005FC4 FB               [12]  959 	mov	r3,a
      005FC5 8A 82            [24]  960 	mov	dpl,r2
      005FC7 8B 83            [24]  961 	mov	dph,r3
      005FC9 E4               [12]  962 	clr	a
      005FCA 93               [24]  963 	movc	a,@a+dptr
      005FCB F9               [12]  964 	mov	r1,a
      005FCC 90 08 29         [24]  965 	mov	dptr,#_control_pointer
      005FCF 74 01            [12]  966 	mov	a,#0x01
      005FD1 2A               [12]  967 	add	a, r2
      005FD2 F0               [24]  968 	movx	@dptr,a
      005FD3 E4               [12]  969 	clr	a
      005FD4 3B               [12]  970 	addc	a, r3
      005FD5 A3               [24]  971 	inc	dptr
      005FD6 F0               [24]  972 	movx	@dptr,a
      005FD7 8C 82            [24]  973 	mov	dpl,r4
      005FD9 8D 83            [24]  974 	mov	dph,r5
      005FDB E9               [12]  975 	mov	a,r1
      005FDC F0               [24]  976 	movx	@dptr,a
      005FDD 0F               [12]  977 	inc	r7
      005FDE 80 D1            [24]  978 	sjmp	00105$
      005FE0                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      005FE0 8E 05            [24]  981 	mov	ar5,r6
      005FE2 7F 00            [12]  982 	mov	r7,#0x00
      005FE4 90 07 C7         [24]  983 	mov	dptr,#_D0SetupLen
      005FE7 E0               [24]  984 	movx	a,@dptr
      005FE8 FB               [12]  985 	mov	r3,a
      005FE9 A3               [24]  986 	inc	dptr
      005FEA E0               [24]  987 	movx	a,@dptr
      005FEB FC               [12]  988 	mov	r4,a
      005FEC EB               [12]  989 	mov	a,r3
      005FED C3               [12]  990 	clr	c
      005FEE 9D               [12]  991 	subb	a,r5
      005FEF FB               [12]  992 	mov	r3,a
      005FF0 EC               [12]  993 	mov	a,r4
      005FF1 9F               [12]  994 	subb	a,r7
      005FF2 FC               [12]  995 	mov	r4,a
      005FF3 90 07 C7         [24]  996 	mov	dptr,#_D0SetupLen
      005FF6 EB               [12]  997 	mov	a,r3
      005FF7 F0               [24]  998 	movx	@dptr,a
      005FF8 EC               [12]  999 	mov	a,r4
      005FF9 A3               [24] 1000 	inc	dptr
      005FFA F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      005FFB EE               [12] 1003 	mov	a,r6
      005FFC 70 05            [24] 1004 	jnz	00103$
      005FFE 90 08 28         [24] 1005 	mov	dptr,#_control_zlp
      006001 E4               [12] 1006 	clr	a
      006002 F0               [24] 1007 	movx	@dptr,a
      006003                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      006003 90 22 08         [24] 1010 	mov	dptr,#0x2208
      006006 EE               [12] 1011 	mov	a,r6
      006007 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      006008 90 22 00         [24] 1014 	mov	dptr,#0x2200
      00600B E0               [24] 1015 	movx	a,@dptr
      00600C 54 C0            [12] 1016 	anl	a,#0xc0
      00600E F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      00600F 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      006010                       1032 _descriptor_select:
      006010 E5 82            [12] 1033 	mov	a,dpl
      006012 90 08 2E         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      006015 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      006016 E0               [24] 1037 	movx	a,@dptr
      006017 FF               [12] 1038 	mov	r7,a
      006018 BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      00601B 90 08 2B         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      00601E E0               [24] 1041 	movx	a,@dptr
      00601F 70 1A            [24] 1042 	jnz	00102$
      006021 90 08 2C         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      006024 E0               [24] 1044 	movx	a,@dptr
      006025 F5 F0            [12] 1045 	mov	b,a
      006027 A3               [24] 1046 	inc	dptr
      006028 E0               [24] 1047 	movx	a,@dptr
      006029 45 F0            [12] 1048 	orl	a,b
      00602B 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      00602D 90 08 29         [24] 1051 	mov	dptr,#_control_pointer
      006030 74 CA            [12] 1052 	mov	a,#_DeviceDescriptor
      006032 F0               [24] 1053 	movx	@dptr,a
      006033 74 C5            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      006035 A3               [24] 1055 	inc	dptr
      006036 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      006037 90 00 12         [24] 1058 	mov	dptr,#0x0012
      00603A 22               [24] 1059 	ret
      00603B                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      00603B 90 08 2E         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      00603E E0               [24] 1063 	movx	a,@dptr
      00603F FF               [12] 1064 	mov	r7,a
      006040 BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      006043 90 08 2B         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      006046 E0               [24] 1067 	movx	a,@dptr
      006047 70 1A            [24] 1068 	jnz	00106$
      006049 90 08 2C         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      00604C E0               [24] 1070 	movx	a,@dptr
      00604D F5 F0            [12] 1071 	mov	b,a
      00604F A3               [24] 1072 	inc	dptr
      006050 E0               [24] 1073 	movx	a,@dptr
      006051 45 F0            [12] 1074 	orl	a,b
      006053 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      006055 90 08 29         [24] 1077 	mov	dptr,#_control_pointer
      006058 74 DC            [12] 1078 	mov	a,#_ConfigurationDescriptor
      00605A F0               [24] 1079 	movx	@dptr,a
      00605B 74 C5            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      00605D A3               [24] 1081 	inc	dptr
      00605E F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      00605F 90 00 54         [24] 1084 	mov	dptr,#0x0054
      006062 22               [24] 1085 	ret
      006063                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      006063 90 08 2E         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      006066 E0               [24] 1089 	movx	a,@dptr
      006067 FF               [12] 1090 	mov	r7,a
      006068 BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      00606B 80 03            [24] 1092 	sjmp	00239$
      00606D                       1093 00238$:
      00606D 02 61 07         [24] 1094 	ljmp	00119$
      006070                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      006070 90 08 2C         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      006073 E0               [24] 1098 	movx	a,@dptr
      006074 FD               [12] 1099 	mov	r5,a
      006075 A3               [24] 1100 	inc	dptr
      006076 E0               [24] 1101 	movx	a,@dptr
      006077 FE               [12] 1102 	mov	r6,a
      006078 90 08 2C         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      00607B E0               [24] 1104 	movx	a,@dptr
      00607C F5 F0            [12] 1105 	mov	b,a
      00607E A3               [24] 1106 	inc	dptr
      00607F E0               [24] 1107 	movx	a,@dptr
      006080 45 F0            [12] 1108 	orl	a,b
      006082 60 0C            [24] 1109 	jz	00110$
      006084 BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      006087 BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      00608A 80 04            [24] 1112 	sjmp	00110$
      00608C                       1113 00241$:
      00608C 90 00 00         [24] 1114 	mov	dptr,#0x0000
      00608F 22               [24] 1115 	ret
      006090                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      006090 90 08 2B         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      006093 E0               [24] 1119 	movx	a,@dptr
      006094 FE               [12] 1120 	mov  r6,a
      006095 24 FC            [12] 1121 	add	a,#0xff - 0x03
      006097 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      006099 EE               [12] 1124 	mov	a,r6
      00609A 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      00609B 90 60 9F         [24] 1127 	mov	dptr,#00243$
      00609E 73               [24] 1128 	jmp	@a+dptr
      00609F                       1129 00243$:
      00609F 80 06            [24] 1130 	sjmp	00112$
      0060A1 80 1B            [24] 1131 	sjmp	00113$
      0060A3 80 30            [24] 1132 	sjmp	00114$
      0060A5 80 45            [24] 1133 	sjmp	00115$
      0060A7                       1134 00112$:
      0060A7 90 08 29         [24] 1135 	mov	dptr,#_control_pointer
      0060AA 74 30            [12] 1136 	mov	a,#_LanguageString
      0060AC F0               [24] 1137 	movx	@dptr,a
      0060AD 74 C6            [12] 1138 	mov	a,#(_LanguageString >> 8)
      0060AF A3               [24] 1139 	inc	dptr
      0060B0 F0               [24] 1140 	movx	@dptr,a
      0060B1 90 C6 30         [24] 1141 	mov	dptr,#_LanguageString
      0060B4 E4               [12] 1142 	clr	a
      0060B5 93               [24] 1143 	movc	a,@a+dptr
      0060B6 FE               [12] 1144 	mov	r6,a
      0060B7 7D 00            [12] 1145 	mov	r5,#0x00
      0060B9 8E 82            [24] 1146 	mov	dpl, r6
      0060BB 8D 83            [24] 1147 	mov	dph, r5
      0060BD 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      0060BE                       1150 00113$:
      0060BE 90 08 29         [24] 1151 	mov	dptr,#_control_pointer
      0060C1 74 34            [12] 1152 	mov	a,#_ManufacturerString
      0060C3 F0               [24] 1153 	movx	@dptr,a
      0060C4 74 C6            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      0060C6 A3               [24] 1155 	inc	dptr
      0060C7 F0               [24] 1156 	movx	@dptr,a
      0060C8 90 C6 34         [24] 1157 	mov	dptr,#_ManufacturerString
      0060CB E4               [12] 1158 	clr	a
      0060CC 93               [24] 1159 	movc	a,@a+dptr
      0060CD FE               [12] 1160 	mov	r6,a
      0060CE 7D 00            [12] 1161 	mov	r5,#0x00
      0060D0 8E 82            [24] 1162 	mov	dpl, r6
      0060D2 8D 83            [24] 1163 	mov	dph, r5
      0060D4 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      0060D5                       1166 00114$:
      0060D5 90 08 29         [24] 1167 	mov	dptr,#_control_pointer
      0060D8 74 42            [12] 1168 	mov	a,#_ProductString
      0060DA F0               [24] 1169 	movx	@dptr,a
      0060DB 74 C6            [12] 1170 	mov	a,#(_ProductString >> 8)
      0060DD A3               [24] 1171 	inc	dptr
      0060DE F0               [24] 1172 	movx	@dptr,a
      0060DF 90 C6 42         [24] 1173 	mov	dptr,#_ProductString
      0060E2 E4               [12] 1174 	clr	a
      0060E3 93               [24] 1175 	movc	a,@a+dptr
      0060E4 FE               [12] 1176 	mov	r6,a
      0060E5 7D 00            [12] 1177 	mov	r5,#0x00
      0060E7 8E 82            [24] 1178 	mov	dpl, r6
      0060E9 8D 83            [24] 1179 	mov	dph, r5
      0060EB 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      0060EC                       1182 00115$:
      0060EC 90 08 29         [24] 1183 	mov	dptr,#_control_pointer
      0060EF 74 7A            [12] 1184 	mov	a,#_SerialNumberString
      0060F1 F0               [24] 1185 	movx	@dptr,a
      0060F2 74 C6            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      0060F4 A3               [24] 1187 	inc	dptr
      0060F5 F0               [24] 1188 	movx	@dptr,a
      0060F6 90 C6 7A         [24] 1189 	mov	dptr,#_SerialNumberString
      0060F9 E4               [12] 1190 	clr	a
      0060FA 93               [24] 1191 	movc	a,@a+dptr
      0060FB FE               [12] 1192 	mov	r6,a
      0060FC 7D 00            [12] 1193 	mov	r5,#0x00
      0060FE 8E 82            [24] 1194 	mov	dpl, r6
      006100 8D 83            [24] 1195 	mov	dph, r5
      006102 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      006103                       1198 00116$:
      006103 90 00 00         [24] 1199 	mov	dptr,#0x0000
      006106 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      006107                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      006107 90 08 2B         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      00610A E0               [24] 1205 	movx	a,@dptr
      00610B 70 11            [24] 1206 	jnz	00120$
      00610D 90 08 2C         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      006110 E0               [24] 1208 	movx	a,@dptr
      006111 FD               [12] 1209 	mov	r5,a
      006112 A3               [24] 1210 	inc	dptr
      006113 E0               [24] 1211 	movx	a,@dptr
      006114 FE               [12] 1212 	mov	r6,a
      006115 C3               [12] 1213 	clr	c
      006116 ED               [12] 1214 	mov	a,r5
      006117 94 03            [12] 1215 	subb	a,#0x03
      006119 EE               [12] 1216 	mov	a,r6
      00611A 94 00            [12] 1217 	subb	a,#0x00
      00611C 40 04            [24] 1218 	jc	00121$
      00611E                       1219 00120$:
      00611E 90 00 00         [24] 1220 	mov	dptr,#0x0000
      006121 22               [24] 1221 	ret
      006122                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      006122 BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      006125 80 03            [24] 1225 	sjmp	00127$
      006127                       1226 00246$:
      006127 BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      00612A                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      00612A ED               [12] 1230 	mov	a,r5
      00612B 75 F0 04         [24] 1231 	mov	b,#0x04
      00612E A4               [48] 1232 	mul	ab
      00612F 24 53            [12] 1233 	add	a, #_interface_descriptors
      006131 FE               [12] 1234 	mov	r6,a
      006132 74 BF            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      006134 35 F0            [12] 1236 	addc	a, b
      006136 FF               [12] 1237 	mov	r7,a
      006137 8E 82            [24] 1238 	mov	dpl,r6
      006139 8F 83            [24] 1239 	mov	dph,r7
      00613B A3               [24] 1240 	inc	dptr
      00613C A3               [24] 1241 	inc	dptr
      00613D E4               [12] 1242 	clr	a
      00613E 93               [24] 1243 	movc	a,@a+dptr
      00613F FC               [12] 1244 	mov	r4,a
      006140 A3               [24] 1245 	inc	dptr
      006141 E4               [12] 1246 	clr	a
      006142 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      006143 FD               [12] 1249 	mov	r5,a
      006144 4C               [12] 1250 	orl	a,r4
      006145 70 04            [24] 1251 	jnz	00124$
      006147 90 00 00         [24] 1252 	mov	dptr,#0x0000
      00614A 22               [24] 1253 	ret
      00614B                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      00614B 90 08 2E         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      00614E E0               [24] 1257 	movx	a,@dptr
      00614F FB               [12] 1258 	mov	r3,a
      006150 BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      006153 8E 82            [24] 1261 	mov	dpl,r6
      006155 8F 83            [24] 1262 	mov	dph,r7
      006157 E4               [12] 1263 	clr	a
      006158 93               [24] 1264 	movc	a,@a+dptr
      006159 FE               [12] 1265 	mov	r6,a
      00615A A3               [24] 1266 	inc	dptr
      00615B E4               [12] 1267 	clr	a
      00615C 93               [24] 1268 	movc	a,@a+dptr
      00615D FF               [12] 1269 	mov	r7,a
      00615E 90 08 29         [24] 1270 	mov	dptr,#_control_pointer
      006161 EE               [12] 1271 	mov	a,r6
      006162 F0               [24] 1272 	movx	@dptr,a
      006163 EF               [12] 1273 	mov	a,r7
      006164 A3               [24] 1274 	inc	dptr
      006165 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      006166 74 07            [12] 1277 	mov	a,#0x07
      006168 2C               [12] 1278 	add	a, r4
      006169 F5 82            [12] 1279 	mov	dpl,a
      00616B E4               [12] 1280 	clr	a
      00616C 3D               [12] 1281 	addc	a, r5
      00616D F5 83            [12] 1282 	mov	dph,a
      00616F E4               [12] 1283 	clr	a
      006170 93               [24] 1284 	movc	a,@a+dptr
      006171 FE               [12] 1285 	mov	r6,a
      006172 A3               [24] 1286 	inc	dptr
      006173 E4               [12] 1287 	clr	a
      006174 93               [24] 1288 	movc	a,@a+dptr
      006175 FF               [12] 1289 	mov	r7,a
      006176 8E 82            [24] 1290 	mov	dpl, r6
      006178 8F 83            [24] 1291 	mov	dph, r7
      00617A 22               [24] 1292 	ret
      00617B                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      00617B 90 08 29         [24] 1295 	mov	dptr,#_control_pointer
      00617E EC               [12] 1296 	mov	a,r4
      00617F F0               [24] 1297 	movx	@dptr,a
      006180 ED               [12] 1298 	mov	a,r5
      006181 A3               [24] 1299 	inc	dptr
      006182 F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      006183 90 00 09         [24] 1302 	mov	dptr,#0x0009
      006186 22               [24] 1303 	ret
      006187                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      006187 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      00618A 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      00618B                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      00618B 90 10 00         [24] 1330 	mov	dptr,#0x1000
      00618E E0               [24] 1331 	movx	a,@dptr
      00618F FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006190 A3               [24] 1334 	inc	dptr
      006191 A3               [24] 1335 	inc	dptr
      006192 E0               [24] 1336 	movx	a,@dptr
      006193 FE               [12] 1337 	mov	r6,a
      006194 A3               [24] 1338 	inc	dptr
      006195 E0               [24] 1339 	movx	a,@dptr
      006196 FC               [12] 1340 	mov	r4,a
      006197 7D 00            [12] 1341 	mov	r5,#0x00
      006199 8E 03            [24] 1342 	mov	ar3,r6
      00619B 7E 00            [12] 1343 	mov	r6,#0x00
      00619D ED               [12] 1344 	mov	a,r5
      00619E 4B               [12] 1345 	orl	a,r3
      00619F FD               [12] 1346 	mov	r5,a
      0061A0 EC               [12] 1347 	mov	a,r4
      0061A1 4E               [12] 1348 	orl	a,r6
      0061A2 FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      0061A3 A3               [24] 1351 	inc	dptr
      0061A4 E0               [24] 1352 	movx	a,@dptr
      0061A5 FC               [12] 1353 	mov	r4,a
      0061A6 A3               [24] 1354 	inc	dptr
      0061A7 E0               [24] 1355 	movx	a,@dptr
      0061A8 FA               [12] 1356 	mov	r2,a
      0061A9 7B 00            [12] 1357 	mov	r3,#0x00
      0061AB 8C 01            [24] 1358 	mov	ar1,r4
      0061AD 7C 00            [12] 1359 	mov	r4,#0x00
      0061AF EB               [12] 1360 	mov	a,r3
      0061B0 49               [12] 1361 	orl	a,r1
      0061B1 FB               [12] 1362 	mov	r3,a
      0061B2 EA               [12] 1363 	mov	a,r2
      0061B3 4C               [12] 1364 	orl	a,r4
      0061B4 FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      0061B5 C3               [12] 1367 	clr	c
      0061B6 EB               [12] 1368 	mov	a,r3
      0061B7 94 03            [12] 1369 	subb	a,#0x03
      0061B9 EC               [12] 1370 	mov	a,r4
      0061BA 94 00            [12] 1371 	subb	a,#0x00
      0061BC 92 17            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      0061BE EB               [12] 1374 	mov	a,r3
      0061BF 4C               [12] 1375 	orl	a,r4
      0061C0 B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      0061C3                       1377 01201$:
      0061C3 92 18            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      0061C5 ED               [12] 1380 	mov	a,r5
      0061C6 4E               [12] 1381 	orl	a,r6
      0061C7 B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      0061CA                       1383 01202$:
                                   1384 ;	assignBit
      0061CA 92 1B            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      0061CC 92 19            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      0061CE 90 08 31         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      0061D1 E4               [12] 1389 	clr	a
      0061D2 F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      0061D3 90 07 D4         [24] 1392 	mov	dptr,#_raw_state
      0061D6 E0               [24] 1393 	movx	a,@dptr
      0061D7 FA               [12] 1394 	mov	r2,a
      0061D8 BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      0061DB 90 07 D4         [24] 1396 	mov	dptr,#_raw_state
      0061DE E4               [12] 1397 	clr	a
      0061DF F0               [24] 1398 	movx	@dptr,a
      0061E0                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      0061E0 C0 07            [24] 1401 	push	ar7
      0061E2 90 08 26         [24] 1402 	mov	dptr,#_output_kind
      0061E5 E4               [12] 1403 	clr	a
      0061E6 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      0061E7 90 08 25         [24] 1406 	mov	dptr,#_control_phase
      0061EA F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      0061EB 90 08 28         [24] 1409 	mov	dptr,#_control_zlp
      0061EE F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      0061EF 90 10 01         [24] 1412 	mov	dptr,#0x1001
      0061F2 E0               [24] 1413 	movx	a,@dptr
      0061F3 90 07 C6         [24] 1414 	mov	dptr,#_D0SetupReqCode
      0061F6 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      0061F7 90 10 06         [24] 1417 	mov	dptr,#0x1006
      0061FA E0               [24] 1418 	movx	a,@dptr
      0061FB FA               [12] 1419 	mov	r2,a
      0061FC A3               [24] 1420 	inc	dptr
      0061FD E0               [24] 1421 	movx	a,@dptr
      0061FE F9               [12] 1422 	mov	r1,a
      0061FF 78 00            [12] 1423 	mov	r0,#0x00
      006201 7F 00            [12] 1424 	mov	r7,#0x00
      006203 90 07 C7         [24] 1425 	mov	dptr,#_D0SetupLen
      006206 E8               [12] 1426 	mov	a,r0
      006207 4A               [12] 1427 	orl	a,r2
      006208 F0               [24] 1428 	movx	@dptr,a
      006209 E9               [12] 1429 	mov	a,r1
      00620A 4F               [12] 1430 	orl	a,r7
      00620B A3               [24] 1431 	inc	dptr
      00620C F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      00620D 90 07 C7         [24] 1434 	mov	dptr,#_D0SetupLen
      006210 E0               [24] 1435 	movx	a,@dptr
      006211 FA               [12] 1436 	mov	r2,a
      006212 A3               [24] 1437 	inc	dptr
      006213 E0               [24] 1438 	movx	a,@dptr
      006214 4A               [12] 1439 	orl	a,r2
      006215 B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      006218                       1441 01205$:
      006218 92 1A            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      00621A 90 22 00         [24] 1444 	mov	dptr,#0x2200
      00621D 74 C2            [12] 1445 	mov	a,#0xc2
      00621F F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      006220 90 22 08         [24] 1448 	mov	dptr,#0x2208
      006223 E4               [12] 1449 	clr	a
      006224 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      006225 90 07 C6         [24] 1452 	mov	dptr,#_D0SetupReqCode
      006228 E0               [24] 1453 	movx	a,@dptr
      006229 F5 27            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      00622B C3               [12] 1455 	clr	c
      00622C 74 0B            [12] 1456 	mov	a,#0x0b
      00622E 95 27            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      006230 D0 07            [24] 1458 	pop	ar7
      006232 50 03            [24] 1459 	jnc	01206$
      006234 02 5F 72         [24] 1460 	ljmp	_control_stall
      006237                       1461 01206$:
                                   1462 ;	free result
      006237 E5 27            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      006239 F5 F0            [12] 1464 	mov	b,a
      00623B 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      00623D 83               [24] 1466 	movc	a,@a+pc
      00623E F5 82            [12] 1467 	mov	dpl,a
      006240 E5 F0            [12] 1468 	mov	a,b
      006242 24 10            [12] 1469 	add	a,#(01208$-3-.)
      006244 83               [24] 1470 	movc	a,@a+pc
      006245 F5 83            [12] 1471 	mov	dph,a
      006247 E4               [12] 1472 	clr	a
      006248 73               [24] 1473 	jmp	@a+dptr
      006249                       1474 01207$:
      006249 F1                    1475 	.db	00188$
      00624A 97                    1476 	.db	00205$
      00624B DA                    1477 	.db	00282$
      00624C 97                    1478 	.db	00205$
      00624D 1E                    1479 	.db	00290$
      00624E 1B                    1480 	.db	00116$
      00624F 61                    1481 	.db	00103$
      006250 1E                    1482 	.db	00290$
      006251 20                    1483 	.db	00150$
      006252 44                    1484 	.db	00123$
      006253 50                    1485 	.db	00157$
      006254 A3                    1486 	.db	00173$
      006255                       1487 01208$:
      006255 64                    1488 	.db	00188$>>8
      006256 65                    1489 	.db	00205$>>8
      006257 68                    1490 	.db	00282$>>8
      006258 65                    1491 	.db	00205$>>8
      006259 69                    1492 	.db	00290$>>8
      00625A 63                    1493 	.db	00116$>>8
      00625B 62                    1494 	.db	00103$>>8
      00625C 69                    1495 	.db	00290$>>8
      00625D 64                    1496 	.db	00150$>>8
      00625E 63                    1497 	.db	00123$>>8
      00625F 64                    1498 	.db	00157$>>8
      006260 64                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      006261                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      006261 BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      006264 80 08            [24] 1504 	sjmp	00112$
      006266                       1505 01209$:
      006266 BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      006269 80 03            [24] 1507 	sjmp	01211$
      00626B                       1508 01210$:
      00626B 02 5F 72         [24] 1509 	ljmp	_control_stall
      00626E                       1510 01211$:
      00626E                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      00626E 8E 01            [24] 1513 	mov	ar1,r6
      006270 B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      006273 80 09            [24] 1515 	sjmp	00301$
      006275                       1516 01212$:
      006275 B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      006278 80 04            [24] 1518 	sjmp	00301$
      00627A                       1519 01213$:
                                   1520 ;	assignBit
      00627A C2 1C            [12] 1521 	clr	_control_setup_sloc2_1_0
      00627C 80 02            [24] 1522 	sjmp	00302$
      00627E                       1523 00301$:
                                   1524 ;	assignBit
      00627E D2 1C            [12] 1525 	setb	_control_setup_sloc2_1_0
      006280                       1526 00302$:
      006280 E4               [12] 1527 	clr	a
      006281 BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      006284 04               [12] 1529 	inc	a
      006285                       1530 01214$:
      006285 FA               [12] 1531 	mov	r2,a
      006286 A2 1C            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      006288 E4               [12] 1533 	clr	a
      006289 33               [12] 1534 	rlc	a
      00628A B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      00628D 80 03            [24] 1536 	sjmp	00105$
      00628F                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      00628F 02 5F 72         [24] 1539 	ljmp	_control_stall
      006292                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      006292 8E 02            [24] 1542 	mov	ar2,r6
      006294 90 08 2B         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      006297 ED               [12] 1544 	mov	a,r5
      006298 F0               [24] 1545 	movx	@dptr,a
      006299 90 08 2C         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      00629C EB               [12] 1547 	mov	a,r3
      00629D F0               [24] 1548 	movx	@dptr,a
      00629E EC               [12] 1549 	mov	a,r4
      00629F A3               [24] 1550 	inc	dptr
      0062A0 F0               [24] 1551 	movx	@dptr,a
      0062A1 8A 82            [24] 1552 	mov	dpl, r2
      0062A3 12 60 10         [24] 1553 	lcall	_descriptor_select
      0062A6 85 82 28         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      0062A9 85 83 29         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      0062AC E5 28            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      0062AE 45 29            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      0062B0 70 03            [24] 1559 	jnz	00107$
      0062B2 02 5F 72         [24] 1560 	ljmp	_control_stall
      0062B5                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      0062B5 90 07 C7         [24] 1563 	mov	dptr,#_D0SetupLen
      0062B8 E0               [24] 1564 	movx	a,@dptr
      0062B9 F8               [12] 1565 	mov	r0,a
      0062BA A3               [24] 1566 	inc	dptr
      0062BB E0               [24] 1567 	movx	a,@dptr
      0062BC FA               [12] 1568 	mov	r2,a
      0062BD C3               [12] 1569 	clr	c
      0062BE E5 28            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      0062C0 98               [12] 1571 	subb	a,r0
      0062C1 E5 29            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0062C3 9A               [12] 1573 	subb	a,r2
      0062C4 50 06            [24] 1574 	jnc	00303$
      0062C6 E5 28            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      0062C8 54 3F            [12] 1576 	anl	a,#0x3f
      0062CA 60 04            [24] 1577 	jz	00304$
      0062CC                       1578 00303$:
                                   1579 ;	assignBit
      0062CC C2 1C            [12] 1580 	clr	_control_setup_sloc2_1_0
      0062CE 80 02            [24] 1581 	sjmp	00305$
      0062D0                       1582 00304$:
                                   1583 ;	assignBit
      0062D0 D2 1C            [12] 1584 	setb	_control_setup_sloc2_1_0
      0062D2                       1585 00305$:
      0062D2 90 08 28         [24] 1586 	mov	dptr,#_control_zlp
      0062D5 A2 1C            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      0062D7 E4               [12] 1588 	clr	a
      0062D8 33               [12] 1589 	rlc	a
      0062D9 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      0062DA 90 07 C7         [24] 1592 	mov	dptr,#_D0SetupLen
      0062DD E0               [24] 1593 	movx	a,@dptr
      0062DE F9               [12] 1594 	mov	r1,a
      0062DF A3               [24] 1595 	inc	dptr
      0062E0 E0               [24] 1596 	movx	a,@dptr
      0062E1 FA               [12] 1597 	mov	r2,a
      0062E2 C3               [12] 1598 	clr	c
      0062E3 E5 28            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      0062E5 99               [12] 1600 	subb	a,r1
      0062E6 E5 29            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0062E8 9A               [12] 1602 	subb	a,r2
      0062E9 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      0062EB 90 07 C7         [24] 1605 	mov	dptr,#_D0SetupLen
      0062EE E5 28            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      0062F0 F0               [24] 1607 	movx	@dptr,a
      0062F1 E5 29            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0062F3 A3               [24] 1609 	inc	dptr
      0062F4 F0               [24] 1610 	movx	@dptr,a
      0062F5                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      0062F5 90 07 C7         [24] 1613 	mov	dptr,#_D0SetupLen
      0062F8 E0               [24] 1614 	movx	a,@dptr
      0062F9 F9               [12] 1615 	mov	r1,a
      0062FA A3               [24] 1616 	inc	dptr
      0062FB E0               [24] 1617 	movx	a,@dptr
      0062FC 49               [12] 1618 	orl	a,r1
      0062FD 60 04            [24] 1619 	jz	00306$
      0062FF 7A 01            [12] 1620 	mov	r2,#0x01
      006301 80 02            [24] 1621 	sjmp	00307$
      006303                       1622 00306$:
      006303 7A 02            [12] 1623 	mov	r2,#0x02
      006305                       1624 00307$:
      006305 90 08 25         [24] 1625 	mov	dptr,#_control_phase
      006308 EA               [12] 1626 	mov	a,r2
      006309 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      00630A 90 07 C7         [24] 1629 	mov	dptr,#_D0SetupLen
      00630D E0               [24] 1630 	movx	a,@dptr
      00630E F9               [12] 1631 	mov	r1,a
      00630F A3               [24] 1632 	inc	dptr
      006310 E0               [24] 1633 	movx	a,@dptr
      006311 49               [12] 1634 	orl	a,r1
      006312 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      006314 02 5F 94         [24] 1637 	ljmp	_control_next
      006317                       1638 00111$:
      006317 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      006318 02 5F 72         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      00631B                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      00631B EF               [12] 1645 	mov	a,r7
      00631C 70 23            [24] 1646 	jnz	00118$
      00631E 30 18 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      006321 30 1A 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      006324 8D 01            [24] 1649 	mov	ar1,r5
      006326 8E 02            [24] 1650 	mov	ar2,r6
      006328 C3               [12] 1651 	clr	c
      006329 74 7F            [12] 1652 	mov	a,#0x7f
      00632B 99               [12] 1653 	subb	a,r1
      00632C E4               [12] 1654 	clr	a
      00632D 9A               [12] 1655 	subb	a,r2
      00632E 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      006330 90 07 C7         [24] 1659 	mov	dptr,#_D0SetupLen
      006333 ED               [12] 1660 	mov	a,r5
      006334 F0               [24] 1661 	movx	@dptr,a
      006335 EE               [12] 1662 	mov	a,r6
      006336 A3               [24] 1663 	inc	dptr
      006337 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      006338 90 08 25         [24] 1666 	mov	dptr,#_control_phase
      00633B 74 03            [12] 1667 	mov	a,#0x03
      00633D F0               [24] 1668 	movx	@dptr,a
      00633E 02 69 21         [24] 1669 	ljmp	00291$
      006341                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      006341 02 5F 72         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      006344                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      006344 EF               [12] 1676 	mov	a,r7
      006345 70 3C            [24] 1677 	jnz	00145$
      006347 30 18 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      00634A 30 1A 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      00634D 8D 01            [24] 1680 	mov	ar1,r5
      00634F 8E 02            [24] 1681 	mov	ar2,r6
      006351 C3               [12] 1682 	clr	c
      006352 74 01            [12] 1683 	mov	a,#0x01
      006354 99               [12] 1684 	subb	a,r1
      006355 E4               [12] 1685 	clr	a
      006356 9A               [12] 1686 	subb	a,r2
      006357 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      006359 C0 06            [24] 1690 	push	ar6
      00635B C0 05            [24] 1691 	push	ar5
      00635D 12 5F 1B         [24] 1692 	lcall	_endpoints_reset
      006360 D0 05            [24] 1693 	pop	ar5
      006362 D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      006364 90 07 CC         [24] 1696 	mov	dptr,#_D0UsbConfig
      006367 ED               [12] 1697 	mov	a,r5
      006368 F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      006369 A2 1B            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      00636B B3               [12] 1701 	cpl	c
      00636C 92 1C            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      00636E 90 07 CD         [24] 1703 	mov	dptr,#_USB_EnumStatus
      006371 E4               [12] 1704 	clr	a
      006372 33               [12] 1705 	rlc	a
      006373 F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      006374 90 07 F6         [24] 1708 	mov	dptr,#_keyboard_reset
      006377 74 01            [12] 1709 	mov	a,#0x01
      006379 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      00637A 90 08 25         [24] 1712 	mov	dptr,#_control_phase
      00637D 74 03            [12] 1713 	mov	a,#0x03
      00637F F0               [24] 1714 	movx	@dptr,a
      006380 02 69 21         [24] 1715 	ljmp	00291$
      006383                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      006383 BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      006386 80 03            [24] 1719 	sjmp	01232$
      006388                       1720 01231$:
      006388 02 5F 72         [24] 1721 	ljmp	_control_stall
      00638B                       1722 01232$:
      00638B 90 07 CC         [24] 1723 	mov	dptr,#_D0UsbConfig
      00638E E0               [24] 1724 	movx	a,@dptr
      00638F 70 03            [24] 1725 	jnz	01233$
      006391 02 5F 72         [24] 1726 	ljmp	_control_stall
      006394                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      006394 BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      006397 BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      00639A 8D 01            [24] 1731 	mov	ar1,r5
      00639C 8E 02            [24] 1732 	mov	ar2,r6
      00639E B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      0063A1 BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      0063A4 90 07 C7         [24] 1735 	mov	dptr,#_D0SetupLen
      0063A7 E0               [24] 1736 	movx	a,@dptr
      0063A8 F9               [12] 1737 	mov	r1,a
      0063A9 A3               [24] 1738 	inc	dptr
      0063AA E0               [24] 1739 	movx	a,@dptr
      0063AB FA               [12] 1740 	mov	r2,a
      0063AC B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      0063AF BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      0063B2 90 07 D4         [24] 1743 	mov	dptr,#_raw_state
      0063B5 E0               [24] 1744 	movx	a,@dptr
      0063B6 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      0063B8 90 07 D4         [24] 1747 	mov	dptr,#_raw_state
      0063BB 74 01            [12] 1748 	mov	a,#0x01
      0063BD F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      0063BE 90 08 26         [24] 1751 	mov	dptr,#_output_kind
      0063C1 F0               [24] 1752 	movx	@dptr,a
      0063C2 80 52            [24] 1753 	sjmp	00136$
      0063C4                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      0063C4 EB               [12] 1756 	mov	a,r3
      0063C5 4C               [12] 1757 	orl	a,r4
      0063C6 70 20            [24] 1758 	jnz	00130$
      0063C8 8D 01            [24] 1759 	mov	ar1,r5
      0063CA 8E 02            [24] 1760 	mov	ar2,r6
      0063CC B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      0063CF BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      0063D2 90 07 C7         [24] 1763 	mov	dptr,#_D0SetupLen
      0063D5 E0               [24] 1764 	movx	a,@dptr
      0063D6 F9               [12] 1765 	mov	r1,a
      0063D7 A3               [24] 1766 	inc	dptr
      0063D8 E0               [24] 1767 	movx	a,@dptr
      0063D9 FA               [12] 1768 	mov	r2,a
      0063DA B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      0063DD BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      0063E0 90 08 26         [24] 1772 	mov	dptr,#_output_kind
      0063E3 74 02            [12] 1773 	mov	a,#0x02
      0063E5 F0               [24] 1774 	movx	@dptr,a
      0063E6 80 2E            [24] 1775 	sjmp	00136$
      0063E8                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      0063E8 BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      0063EB BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      0063EE 8D 01            [24] 1780 	mov	ar1,r5
      0063F0 8E 02            [24] 1781 	mov	ar2,r6
      0063F2 B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      0063F5 BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      0063F8 90 07 C7         [24] 1784 	mov	dptr,#_D0SetupLen
      0063FB E0               [24] 1785 	movx	a,@dptr
      0063FC F9               [12] 1786 	mov	r1,a
      0063FD A3               [24] 1787 	inc	dptr
      0063FE E0               [24] 1788 	movx	a,@dptr
      0063FF FA               [12] 1789 	mov	r2,a
      006400 B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      006403 BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      006406 90 08 26         [24] 1793 	mov	dptr,#_output_kind
      006409 74 03            [12] 1794 	mov	a,#0x03
      00640B F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      00640C 90 08 27         [24] 1797 	mov	dptr,#_output_report_id
      00640F 23               [12] 1798 	rl	a
      006410 F0               [24] 1799 	movx	@dptr,a
      006411 80 03            [24] 1800 	sjmp	00136$
      006413                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      006413 02 5F 72         [24] 1803 	ljmp	_control_stall
      006416                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      006416 90 08 25         [24] 1806 	mov	dptr,#_control_phase
      006419 74 04            [12] 1807 	mov	a,#0x04
      00641B F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      00641C 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      00641D 02 5F 72         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      006420                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006420 BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      006423 30 18 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      006426 30 19 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      006429 90 07 C7         [24] 1819 	mov	dptr,#_D0SetupLen
      00642C E0               [24] 1820 	movx	a,@dptr
      00642D F9               [12] 1821 	mov	r1,a
      00642E A3               [24] 1822 	inc	dptr
      00642F E0               [24] 1823 	movx	a,@dptr
      006430 FA               [12] 1824 	mov	r2,a
      006431 B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      006434 BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      006437 90 07 CC         [24] 1828 	mov	dptr,#_D0UsbConfig
      00643A E0               [24] 1829 	movx	a,@dptr
      00643B 90 10 00         [24] 1830 	mov	dptr,#0x1000
      00643E F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      00643F 90 22 08         [24] 1833 	mov	dptr,#0x2208
      006442 74 01            [12] 1834 	mov	a,#0x01
      006444 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      006445 90 08 25         [24] 1837 	mov	dptr,#_control_phase
      006448 04               [12] 1838 	inc	a
      006449 F0               [24] 1839 	movx	@dptr,a
      00644A 02 69 21         [24] 1840 	ljmp	00291$
      00644D                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      00644D 02 5F 72         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006450                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006450 BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      006453 30 17 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      006456 30 19 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      006459 90 07 C7         [24] 1850 	mov	dptr,#_D0SetupLen
      00645C E0               [24] 1851 	movx	a,@dptr
      00645D F9               [12] 1852 	mov	r1,a
      00645E A3               [24] 1853 	inc	dptr
      00645F E0               [24] 1854 	movx	a,@dptr
      006460 FA               [12] 1855 	mov	r2,a
      006461 B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      006464 BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      006467 90 07 CC         [24] 1858 	mov	dptr,#_D0UsbConfig
      00646A E0               [24] 1859 	movx	a,@dptr
      00646B 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      00646D 90 10 00         [24] 1862 	mov	dptr,#0x1000
      006470 E4               [12] 1863 	clr	a
      006471 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      006472 90 22 08         [24] 1866 	mov	dptr,#0x2208
      006475 04               [12] 1867 	inc	a
      006476 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      006477 90 08 25         [24] 1870 	mov	dptr,#_control_phase
      00647A 04               [12] 1871 	inc	a
      00647B F0               [24] 1872 	movx	@dptr,a
      00647C 02 69 21         [24] 1873 	ljmp	00291$
      00647F                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      00647F 30 17 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      006482 90 07 CC         [24] 1877 	mov	dptr,#_D0UsbConfig
      006485 E0               [24] 1878 	movx	a,@dptr
      006486 60 18            [24] 1879 	jz	00161$
      006488 BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      00648B 30 1A 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      00648E EB               [12] 1883 	mov	a,r3
      00648F 4C               [12] 1884 	orl	a,r4
      006490 70 05            [24] 1885 	jnz	00159$
      006492 90 06 A4         [24] 1886 	mov	dptr,#_keyboard_idle
      006495 EE               [12] 1887 	mov	a,r6
      006496 F0               [24] 1888 	movx	@dptr,a
      006497                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      006497 90 08 25         [24] 1891 	mov	dptr,#_control_phase
      00649A 74 03            [12] 1892 	mov	a,#0x03
      00649C F0               [24] 1893 	movx	@dptr,a
      00649D 02 69 21         [24] 1894 	ljmp	00291$
      0064A0                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      0064A0 02 5F 72         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0064A3                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0064A3 BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      0064A6 30 17 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      0064A9 30 19 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      0064AC 30 1A 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      0064AF 90 07 CC         [24] 1905 	mov	dptr,#_D0UsbConfig
      0064B2 E0               [24] 1906 	movx	a,@dptr
      0064B3 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      0064B5 90 08 25         [24] 1909 	mov	dptr,#_control_phase
      0064B8 74 03            [12] 1910 	mov	a,#0x03
      0064BA F0               [24] 1911 	movx	@dptr,a
      0064BB 02 69 21         [24] 1912 	ljmp	00291$
      0064BE                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      0064BE EB               [12] 1915 	mov	a,r3
      0064BF 4C               [12] 1916 	orl	a,r4
      0064C0 70 2C            [24] 1917 	jnz	00175$
      0064C2 90 07 CC         [24] 1918 	mov	dptr,#_D0UsbConfig
      0064C5 E0               [24] 1919 	movx	a,@dptr
      0064C6 60 26            [24] 1920 	jz	00175$
      0064C8 BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      0064CB 30 1A 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      0064CE 8D 01            [24] 1923 	mov	ar1,r5
      0064D0 8E 02            [24] 1924 	mov	ar2,r6
      0064D2 C3               [12] 1925 	clr	c
      0064D3 74 01            [12] 1926 	mov	a,#0x01
      0064D5 99               [12] 1927 	subb	a,r1
      0064D6 E4               [12] 1928 	clr	a
      0064D7 9A               [12] 1929 	subb	a,r2
      0064D8 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      0064DA 90 0E 36         [24] 1933 	mov	dptr,#_keyboard_protocol
      0064DD ED               [12] 1934 	mov	a,r5
      0064DE F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      0064DF 90 07 F6         [24] 1937 	mov	dptr,#_keyboard_reset
      0064E2 74 01            [12] 1938 	mov	a,#0x01
      0064E4 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      0064E5 90 08 25         [24] 1941 	mov	dptr,#_control_phase
      0064E8 74 03            [12] 1942 	mov	a,#0x03
      0064EA F0               [24] 1943 	movx	@dptr,a
      0064EB 02 69 21         [24] 1944 	ljmp	00291$
      0064EE                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      0064EE 02 5F 72         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      0064F1                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      0064F1 20 19 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      0064F4 02 5F 72         [24] 1952 	ljmp	_control_stall
      0064F7                       1953 01283$:
      0064F7 90 07 C7         [24] 1954 	mov	dptr,#_D0SetupLen
      0064FA E0               [24] 1955 	movx	a,@dptr
      0064FB F9               [12] 1956 	mov	r1,a
      0064FC A3               [24] 1957 	inc	dptr
      0064FD E0               [24] 1958 	movx	a,@dptr
      0064FE FA               [12] 1959 	mov	r2,a
      0064FF B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      006502 BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      006505 80 03            [24] 1962 	sjmp	01285$
      006507                       1963 01284$:
      006507 02 5F 72         [24] 1964 	ljmp	_control_stall
      00650A                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      00650A E4               [12] 1967 	clr	a
      00650B BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      00650E 04               [12] 1969 	inc	a
      00650F                       1970 01286$:
      00650F FA               [12] 1971 	mov	r2,a
      006510 60 03            [24] 1972 	jz	00196$
      006512 20 18 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      006515                       1974 00196$:
      006515 BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      006518 30 17 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      00651B 90 07 CC         [24] 1977 	mov	dptr,#_D0UsbConfig
      00651E E0               [24] 1978 	movx	a,@dptr
      00651F 70 29            [24] 1979 	jnz	00189$
      006521                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006521 BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      006524 90 07 CC         [24] 1983 	mov	dptr,#_D0UsbConfig
      006527 E0               [24] 1984 	movx	a,@dptr
      006528 60 6A            [24] 1985 	jz	00190$
      00652A EB               [12] 1986 	mov	a,r3
      00652B 4C               [12] 1987 	orl	a,r4
      00652C 60 1C            [24] 1988 	jz	00189$
      00652E 8B 00            [24] 1989 	mov	ar0,r3
      006530 8C 01            [24] 1990 	mov	ar1,r4
      006532 B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      006535 B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      006538 80 10            [24] 1993 	sjmp	00189$
      00653A                       1994 01298$:
      00653A C3               [12] 1995 	clr	c
      00653B E8               [12] 1996 	mov	a,r0
      00653C 94 81            [12] 1997 	subb	a,#0x81
      00653E E9               [12] 1998 	mov	a,r1
      00653F 94 00            [12] 1999 	subb	a,#0x00
      006541 40 51            [24] 2000 	jc	00190$
      006543 74 83            [12] 2001 	mov	a,#0x83
      006545 98               [12] 2002 	subb	a,r0
      006546 E4               [12] 2003 	clr	a
      006547 99               [12] 2004 	subb	a,r1
      006548 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      00654A                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      00654A 8B 01            [24] 2009 	mov	ar1,r3
      00654C 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      00654F EA               [12] 2012 	mov	a,r2
      006550 60 0B            [24] 2013 	jz	00308$
      006552 90 07 CE         [24] 2014 	mov	dptr,#_USB_SleepStatus
      006555 E0               [24] 2015 	movx	a,@dptr
      006556 54 01            [12] 2016 	anl	a,#0x01
      006558 25 E0            [12] 2017 	add	a,acc
      00655A FA               [12] 2018 	mov	r2,a
      00655B 80 22            [24] 2019 	sjmp	00309$
      00655D                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      00655D BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      006560 E9               [12] 2023 	mov	a,r1
      006561 60 18            [24] 2024 	jz	00310$
      006563 89 00            [24] 2025 	mov	ar0,r1
      006565 79 00            [12] 2026 	mov	r1,#0x00
      006567 74 22            [12] 2027 	mov	a,#0x22
      006569 29               [12] 2028 	add	a, r1
      00656A F9               [12] 2029 	mov	r1,a
      00656B 88 82            [24] 2030 	mov	dpl,r0
      00656D 89 83            [24] 2031 	mov	dph,r1
      00656F E0               [24] 2032 	movx	a,@dptr
      006570 F9               [12] 2033 	mov	r1,a
      006571 53 01 03         [24] 2034 	anl	ar1,#0x03
      006574 B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      006577 79 01            [12] 2036 	mov	r1,#0x01
      006579 80 02            [24] 2037 	sjmp	00311$
      00657B                       2038 00310$:
      00657B 79 00            [12] 2039 	mov	r1,#0x00
      00657D                       2040 00311$:
      00657D 89 02            [24] 2041 	mov	ar2,r1
      00657F                       2042 00309$:
      00657F 90 10 00         [24] 2043 	mov	dptr,#0x1000
      006582 EA               [12] 2044 	mov	a,r2
      006583 F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      006584 A3               [24] 2047 	inc	dptr
      006585 E4               [12] 2048 	clr	a
      006586 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      006587 90 22 08         [24] 2051 	mov	dptr,#0x2208
      00658A 74 02            [12] 2052 	mov	a,#0x02
      00658C F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      00658D 90 08 25         [24] 2055 	mov	dptr,#_control_phase
      006590 F0               [24] 2056 	movx	@dptr,a
      006591 02 69 21         [24] 2057 	ljmp	00291$
      006594                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      006594 02 5F 72         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006597                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      006597 20 1A 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      00659A 02 66 2A         [24] 2065 	ljmp	00279$
      00659D                       2066 01307$:
      00659D 90 07 CC         [24] 2067 	mov	dptr,#_D0UsbConfig
      0065A0 E0               [24] 2068 	movx	a,@dptr
      0065A1 70 03            [24] 2069 	jnz	01308$
      0065A3 02 66 2A         [24] 2070 	ljmp	00279$
      0065A6                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      0065A6 EF               [12] 2073 	mov	a,r7
      0065A7 70 29            [24] 2074 	jnz	00218$
      0065A9 8D 01            [24] 2075 	mov	ar1,r5
      0065AB 8E 02            [24] 2076 	mov	ar2,r6
      0065AD B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      0065B0 BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      0065B3 30 18 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      0065B6 90 07 C6         [24] 2081 	mov	dptr,#_D0SetupReqCode
      0065B9 E0               [24] 2082 	movx	a,@dptr
      0065BA FA               [12] 2083 	mov	r2,a
      0065BB BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      0065BE 90 07 CE         [24] 2085 	mov	dptr,#_USB_SleepStatus
      0065C1 E0               [24] 2086 	movx	a,@dptr
      0065C2 43 E0 01         [24] 2087 	orl	acc,#0x01
      0065C5 F0               [24] 2088 	movx	@dptr,a
      0065C6 80 59            [24] 2089 	sjmp	00219$
      0065C8                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      0065C8 90 07 CE         [24] 2092 	mov	dptr,#_USB_SleepStatus
      0065CB E0               [24] 2093 	movx	a,@dptr
      0065CC 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      0065CF F0               [24] 2095 	movx	@dptr,a
      0065D0 80 4F            [24] 2096 	sjmp	00219$
      0065D2                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0065D2 BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      0065D5 30 19 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      0065D8 8B 01            [24] 2101 	mov	ar1,r3
      0065DA 8C 02            [24] 2102 	mov	ar2,r4
      0065DC C3               [12] 2103 	clr	c
      0065DD E9               [12] 2104 	mov	a,r1
      0065DE 94 81            [12] 2105 	subb	a,#0x81
      0065E0 EA               [12] 2106 	mov	a,r2
      0065E1 94 00            [12] 2107 	subb	a,#0x00
      0065E3 40 39            [24] 2108 	jc	00212$
      0065E5 74 83            [12] 2109 	mov	a,#0x83
      0065E7 99               [12] 2110 	subb	a,r1
      0065E8 E4               [12] 2111 	clr	a
      0065E9 9A               [12] 2112 	subb	a,r2
      0065EA 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      0065EC 8B 02            [24] 2116 	mov	ar2,r3
      0065EE 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0065F1 8A 00            [24] 2119 	mov	ar0,r2
      0065F3 79 00            [12] 2120 	mov	r1,#0x00
      0065F5 74 22            [12] 2121 	mov	a,#0x22
      0065F7 29               [12] 2122 	add	a, r1
      0065F8 F9               [12] 2123 	mov	r1,a
      0065F9 88 28            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      0065FB 89 29            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      0065FD 90 07 C6         [24] 2126 	mov	dptr,#_D0SetupReqCode
      006600 E0               [24] 2127 	movx	a,@dptr
      006601 F9               [12] 2128 	mov	r1,a
      006602 B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      006605 79 03            [12] 2130 	mov	r1,#0x03
      006607 80 02            [24] 2131 	sjmp	00319$
      006609                       2132 00318$:
      006609 79 02            [12] 2133 	mov	r1,#0x02
      00660B                       2134 00319$:
      00660B 43 01 10         [24] 2135 	orl	ar1,#0x10
      00660E 85 28 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      006611 85 29 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006614 E9               [12] 2138 	mov	a,r1
      006615 F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006616 BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      006619 12 5E FE         [24] 2142 	lcall	_raw_complete
      00661C 80 03            [24] 2143 	sjmp	00219$
      00661E                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      00661E 02 5F 72         [24] 2146 	ljmp	_control_stall
      006621                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      006621 90 08 25         [24] 2149 	mov	dptr,#_control_phase
      006624 74 03            [12] 2150 	mov	a,#0x03
      006626 F0               [24] 2151 	movx	@dptr,a
      006627 02 69 21         [24] 2152 	ljmp	00291$
      00662A                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      00662A E4               [12] 2155 	clr	a
      00662B BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      00662E 04               [12] 2157 	inc	a
      00662F                       2158 01324$:
      00662F FA               [12] 2159 	mov	r2,a
      006630 70 03            [24] 2160 	jnz	01326$
      006632 02 68 9C         [24] 2161 	ljmp	00273$
      006635                       2162 01326$:
      006635 90 07 C6         [24] 2163 	mov	dptr,#_D0SetupReqCode
      006638 E0               [24] 2164 	movx	a,@dptr
      006639 F9               [12] 2165 	mov	r1,a
      00663A B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      00663D 80 03            [24] 2167 	sjmp	01328$
      00663F                       2168 01327$:
      00663F 02 68 9C         [24] 2169 	ljmp	00273$
      006642                       2170 01328$:
      006642 90 07 CC         [24] 2171 	mov	dptr,#_D0UsbConfig
      006645 E0               [24] 2172 	movx	a,@dptr
      006646 70 03            [24] 2173 	jnz	01329$
      006648 02 68 9C         [24] 2174 	ljmp	00273$
      00664B                       2175 01329$:
      00664B 90 07 C7         [24] 2176 	mov	dptr,#_D0SetupLen
      00664E E0               [24] 2177 	movx	a,@dptr
      00664F F8               [12] 2178 	mov	r0,a
      006650 A3               [24] 2179 	inc	dptr
      006651 E0               [24] 2180 	movx	a,@dptr
      006652 48               [12] 2181 	orl	a,r0
      006653 70 03            [24] 2182 	jnz	01330$
      006655 02 68 9C         [24] 2183 	ljmp	00273$
      006658                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      006658 C0 03            [24] 2186 	push	ar3
      00665A C0 04            [24] 2187 	push	ar4
      00665C 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      00665E 8E 00            [24] 2190 	mov	ar0,r6
      006660 B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      006663 E8               [12] 2192 	mov	a,r0
      006664 80 01            [24] 2193 	sjmp	01332$
      006666                       2194 01331$:
      006666 E4               [12] 2195 	clr	a
      006667                       2196 01332$:
      006667 F5 28            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      006669 D0 04            [24] 2198 	pop	ar4
      00666B D0 03            [24] 2199 	pop	ar3
      00666D E5 28            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      00666F 60 17            [24] 2201 	jz	00251$
      006671 EB               [12] 2202 	mov	a,r3
      006672 4C               [12] 2203 	orl	a,r4
      006673 70 13            [24] 2204 	jnz	00251$
      006675 E9               [12] 2205 	mov	a,r1
      006676 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      006678 90 08 2F         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      00667B 74 08            [12] 2209 	mov	a,#0x08
      00667D F0               [24] 2210 	movx	@dptr,a
      00667E E4               [12] 2211 	clr	a
      00667F A3               [24] 2212 	inc	dptr
      006680 F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      006681 90 08 31         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      006684 F0               [24] 2216 	movx	@dptr,a
      006685 02 68 0C         [24] 2217 	ljmp	00252$
      006688                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006688 E5 28            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      00668A 60 27            [24] 2221 	jz	00245$
      00668C BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      00668F BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006692 B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      006695                       2226 01339$:
      006695 50 1C            [24] 2227 	jnc	00245$
      006697 E9               [12] 2228 	mov	a,r1
      006698 90 BF 4C         [24] 2229 	mov	dptr,#_shared_lengths
      00669B 93               [24] 2230 	movc	a,@a+dptr
      00669C F8               [12] 2231 	mov	r0,a
      00669D 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      00669F 90 08 2F         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      0066A2 E8               [12] 2235 	mov	a,r0
      0066A3 F0               [24] 2236 	movx	@dptr,a
      0066A4 E4               [12] 2237 	clr	a
      0066A5 A3               [24] 2238 	inc	dptr
      0066A6 F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      0066A7 E9               [12] 2241 	mov	a,r1
      0066A8 90 BF 45         [24] 2242 	mov	dptr,#_shared_offsets
      0066AB 93               [24] 2243 	movc	a,@a+dptr
      0066AC 90 08 31         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      0066AF F0               [24] 2245 	movx	@dptr,a
      0066B0 02 68 0C         [24] 2246 	ljmp	00252$
      0066B3                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0066B3 E5 28            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      0066B5 60 7A            [24] 2250 	jz	00240$
      0066B7 BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      0066BA BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      0066BD E9               [12] 2253 	mov	a,r1
      0066BE 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0066C0 90 07 C7         [24] 2256 	mov	dptr,#_D0SetupLen
      0066C3 E0               [24] 2257 	movx	a,@dptr
      0066C4 F8               [12] 2258 	mov	r0,a
      0066C5 A3               [24] 2259 	inc	dptr
      0066C6 E0               [24] 2260 	movx	a,@dptr
      0066C7 F9               [12] 2261 	mov	r1,a
      0066C8 C3               [12] 2262 	clr	c
      0066C9 E8               [12] 2263 	mov	a,r0
      0066CA 94 20            [12] 2264 	subb	a,#0x20
      0066CC E9               [12] 2265 	mov	a,r1
      0066CD 94 00            [12] 2266 	subb	a,#0x00
      0066CF 50 0A            [24] 2267 	jnc	00320$
      0066D1 90 07 C7         [24] 2268 	mov	dptr,#_D0SetupLen
      0066D4 E0               [24] 2269 	movx	a,@dptr
      0066D5 F8               [12] 2270 	mov	r0,a
      0066D6 A3               [24] 2271 	inc	dptr
      0066D7 E0               [24] 2272 	movx	a,@dptr
      0066D8 F9               [12] 2273 	mov	r1,a
      0066D9 80 04            [24] 2274 	sjmp	00321$
      0066DB                       2275 00320$:
      0066DB 78 20            [12] 2276 	mov	r0,#0x20
      0066DD 79 00            [12] 2277 	mov	r1,#0x00
      0066DF                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      0066DF 75 28 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      0066E2                       2281 00293$:
      0066E2 C0 03            [24] 2282 	push	ar3
      0066E4 C0 04            [24] 2283 	push	ar4
      0066E6 AB 28            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      0066E8 7C 00            [12] 2285 	mov	r4,#0x00
      0066EA C3               [12] 2286 	clr	c
      0066EB EB               [12] 2287 	mov	a,r3
      0066EC 98               [12] 2288 	subb	a,r0
      0066ED EC               [12] 2289 	mov	a,r4
      0066EE 99               [12] 2290 	subb	a,r1
      0066EF D0 04            [24] 2291 	pop	ar4
      0066F1 D0 03            [24] 2292 	pop	ar3
      0066F3 50 32            [24] 2293 	jnc	00222$
      0066F5 C0 00            [24] 2294 	push	ar0
      0066F7 C0 01            [24] 2295 	push	ar1
      0066F9 85 28 2A         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0066FC 74 10            [12] 2297 	mov	a,#0x10
      0066FE 24 00            [12] 2298 	add	a, #0x00
      006700 F5 2B            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      006702 A8 28            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      006704 79 00            [12] 2301 	mov	r1,#0x00
      006706 74 C0            [12] 2302 	mov	a,#0xc0
      006708 28               [12] 2303 	add	a, r0
      006709 F8               [12] 2304 	mov	r0,a
      00670A E4               [12] 2305 	clr	a
      00670B 39               [12] 2306 	addc	a, r1
      00670C F9               [12] 2307 	mov	r1,a
      00670D 88 82            [24] 2308 	mov	dpl,r0
      00670F 74 10            [12] 2309 	mov	a,#0x10
      006711 29               [12] 2310 	add	a, r1
      006712 F5 83            [12] 2311 	mov	dph,a
      006714 E0               [24] 2312 	movx	a,@dptr
      006715 85 2A 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      006718 85 2B 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      00671B F0               [24] 2315 	movx	@dptr,a
      00671C E5 28            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      00671E 04               [12] 2317 	inc	a
      00671F F5 28            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      006721 D0 01            [24] 2319 	pop	ar1
      006723 D0 00            [24] 2320 	pop	ar0
      006725 80 BB            [24] 2321 	sjmp	00293$
      006727                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      006727 90 08 2F         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      00672A E4               [12] 2325 	clr	a
      00672B F0               [24] 2326 	movx	@dptr,a
      00672C A3               [24] 2327 	inc	dptr
      00672D F0               [24] 2328 	movx	@dptr,a
      00672E 02 68 0C         [24] 2329 	ljmp	00252$
      006731                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006731 8D 00            [24] 2332 	mov	ar0,r5
      006733 8E 01            [24] 2333 	mov	ar1,r6
      006735 B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      006738 B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      00673B EB               [12] 2336 	mov	a,r3
      00673C 4C               [12] 2337 	orl	a,r4
      00673D 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      00673F 90 07 D1         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      006742 E0               [24] 2341 	movx	a,@dptr
      006743 90 10 00         [24] 2342 	mov	dptr,#0x1000
      006746 F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      006747 90 08 2F         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      00674A E4               [12] 2346 	clr	a
      00674B F0               [24] 2347 	movx	@dptr,a
      00674C A3               [24] 2348 	inc	dptr
      00674D F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      00674E 90 07 C7         [24] 2351 	mov	dptr,#_D0SetupLen
      006751 04               [12] 2352 	inc	a
      006752 F0               [24] 2353 	movx	@dptr,a
      006753 E4               [12] 2354 	clr	a
      006754 A3               [24] 2355 	inc	dptr
      006755 F0               [24] 2356 	movx	@dptr,a
      006756 02 68 0C         [24] 2357 	ljmp	00252$
      006759                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006759 B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      00675C B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      00675F BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      006762 BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      006765 C0 03            [24] 2365 	push	ar3
      006767 C0 04            [24] 2366 	push	ar4
      006769 90 10 00         [24] 2367 	mov	dptr,#0x1000
      00676C 74 06            [12] 2368 	mov	a,#0x06
      00676E F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      00676F 90 07 D1         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      006772 E0               [24] 2372 	movx	a,@dptr
      006773 90 10 01         [24] 2373 	mov	dptr,#0x1001
      006776 F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      006777 90 08 2F         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      00677A E4               [12] 2377 	clr	a
      00677B F0               [24] 2378 	movx	@dptr,a
      00677C A3               [24] 2379 	inc	dptr
      00677D F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      00677E 90 07 C7         [24] 2382 	mov	dptr,#_D0SetupLen
      006781 E0               [24] 2383 	movx	a,@dptr
      006782 FB               [12] 2384 	mov	r3,a
      006783 A3               [24] 2385 	inc	dptr
      006784 E0               [24] 2386 	movx	a,@dptr
      006785 FC               [12] 2387 	mov	r4,a
      006786 C3               [12] 2388 	clr	c
      006787 74 02            [12] 2389 	mov	a,#0x02
      006789 9B               [12] 2390 	subb	a,r3
      00678A E4               [12] 2391 	clr	a
      00678B 9C               [12] 2392 	subb	a,r4
      00678C D0 04            [24] 2393 	pop	ar4
      00678E D0 03            [24] 2394 	pop	ar3
      006790 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      006792 90 07 C7         [24] 2397 	mov	dptr,#_D0SetupLen
      006795 74 02            [12] 2398 	mov	a,#0x02
      006797 F0               [24] 2399 	movx	@dptr,a
      006798 E4               [12] 2400 	clr	a
      006799 A3               [24] 2401 	inc	dptr
      00679A F0               [24] 2402 	movx	@dptr,a
      00679B 80 6F            [24] 2403 	sjmp	00252$
      00679D                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      00679D B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      0067A0 B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      0067A3 BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      0067A6 BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      0067A9 90 10 00         [24] 2411 	mov	dptr,#0x1000
      0067AC 74 41            [12] 2412 	mov	a,#0x41
      0067AE F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      0067AF A3               [24] 2415 	inc	dptr
      0067B0 74 4B            [12] 2416 	mov	a,#0x4b
      0067B2 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      0067B3 A3               [24] 2419 	inc	dptr
      0067B4 74 42            [12] 2420 	mov	a,#0x42
      0067B6 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      0067B7 A3               [24] 2423 	inc	dptr
      0067B8 74 54            [12] 2424 	mov	a,#0x54
      0067BA F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      0067BB A3               [24] 2427 	inc	dptr
      0067BC 74 01            [12] 2428 	mov	a,#0x01
      0067BE F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      0067BF 90 07 D2         [24] 2431 	mov	dptr,#_ak820_boot_stage
      0067C2 E0               [24] 2432 	movx	a,@dptr
      0067C3 90 10 05         [24] 2433 	mov	dptr,#0x1005
      0067C6 F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      0067C7 90 07 D3         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      0067CA E0               [24] 2437 	movx	a,@dptr
      0067CB 90 10 06         [24] 2438 	mov	dptr,#0x1006
      0067CE F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0067CF 90 07 CD         [24] 2441 	mov	dptr,#_USB_EnumStatus
      0067D2 E0               [24] 2442 	movx	a,@dptr
      0067D3 60 02            [24] 2443 	jz	00322$
      0067D5 74 01            [12] 2444 	mov	a,#0x01
      0067D7                       2445 00322$:
      0067D7 F9               [12] 2446 	mov	r1,a
      0067D8 90 07 CE         [24] 2447 	mov	dptr,#_USB_SleepStatus
      0067DB E0               [24] 2448 	movx	a,@dptr
      0067DC 54 02            [12] 2449 	anl	a,#0x02
      0067DE F8               [12] 2450 	mov	r0,a
      0067DF E9               [12] 2451 	mov	a,r1
      0067E0 42 00            [12] 2452 	orl	ar0,a
      0067E2 90 10 07         [24] 2453 	mov	dptr,#0x1007
      0067E5 E8               [12] 2454 	mov	a,r0
      0067E6 F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      0067E7 90 08 2F         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      0067EA E4               [12] 2458 	clr	a
      0067EB F0               [24] 2459 	movx	@dptr,a
      0067EC A3               [24] 2460 	inc	dptr
      0067ED F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      0067EE 90 07 C7         [24] 2463 	mov	dptr,#_D0SetupLen
      0067F1 E0               [24] 2464 	movx	a,@dptr
      0067F2 F8               [12] 2465 	mov	r0,a
      0067F3 A3               [24] 2466 	inc	dptr
      0067F4 E0               [24] 2467 	movx	a,@dptr
      0067F5 F9               [12] 2468 	mov	r1,a
      0067F6 C3               [12] 2469 	clr	c
      0067F7 74 08            [12] 2470 	mov	a,#0x08
      0067F9 98               [12] 2471 	subb	a,r0
      0067FA E4               [12] 2472 	clr	a
      0067FB 99               [12] 2473 	subb	a,r1
      0067FC 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      0067FE 90 07 C7         [24] 2476 	mov	dptr,#_D0SetupLen
      006801 74 08            [12] 2477 	mov	a,#0x08
      006803 F0               [24] 2478 	movx	@dptr,a
      006804 E4               [12] 2479 	clr	a
      006805 A3               [24] 2480 	inc	dptr
      006806 F0               [24] 2481 	movx	@dptr,a
      006807 80 03            [24] 2482 	sjmp	00252$
      006809                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      006809 02 5F 72         [24] 2485 	ljmp	_control_stall
      00680C                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      00680C 90 08 2F         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      00680F E0               [24] 2489 	movx	a,@dptr
      006810 F5 2A            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      006812 A3               [24] 2491 	inc	dptr
      006813 E0               [24] 2492 	movx	a,@dptr
      006814 F5 2B            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      006816 E5 2A            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      006818 45 2B            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      00681A 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      00681C 90 07 C7         [24] 2498 	mov	dptr,#_D0SetupLen
      00681F E0               [24] 2499 	movx	a,@dptr
      006820 F8               [12] 2500 	mov	r0,a
      006821 A3               [24] 2501 	inc	dptr
      006822 E0               [24] 2502 	movx	a,@dptr
      006823 F9               [12] 2503 	mov	r1,a
      006824 C3               [12] 2504 	clr	c
      006825 E5 2A            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      006827 98               [12] 2506 	subb	a,r0
      006828 E5 2B            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00682A 99               [12] 2508 	subb	a,r1
      00682B 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      00682D 90 07 C7         [24] 2511 	mov	dptr,#_D0SetupLen
      006830 E5 2A            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      006832 F0               [24] 2513 	movx	@dptr,a
      006833 E5 2B            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006835 A3               [24] 2515 	inc	dptr
      006836 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      006837                       2518 00559$:
      006837 75 2A 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      00683A                       2520 00296$:
      00683A 90 07 C7         [24] 2521 	mov	dptr,#_D0SetupLen
      00683D E0               [24] 2522 	movx	a,@dptr
      00683E F8               [12] 2523 	mov	r0,a
      00683F C3               [12] 2524 	clr	c
      006840 E5 2A            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      006842 98               [12] 2526 	subb	a,r0
      006843 50 46            [24] 2527 	jnc	00263$
      006845 85 2A 28         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006848 74 10            [12] 2529 	mov	a,#0x10
      00684A 24 00            [12] 2530 	add	a, #0x00
      00684C F5 29            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      00684E 90 08 31         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      006851 E0               [24] 2533 	movx	a,@dptr
      006852 25 2A            [12] 2534 	add	a, _control_setup_sloc4_1_0
      006854 24 F7            [12] 2535 	add	a, #_input_snapshot
      006856 F5 82            [12] 2536 	mov	dpl,a
      006858 E4               [12] 2537 	clr	a
      006859 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      00685B F5 83            [12] 2539 	mov	dph,a
      00685D E0               [24] 2540 	movx	a,@dptr
      00685E 85 28 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      006861 85 29 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006864 F0               [24] 2543 	movx	@dptr,a
      006865 E5 2A            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      006867 04               [12] 2545 	inc	a
      006868 F5 2A            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      00686A 80 CE            [24] 2547 	sjmp	00296$
      00686C                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      00686C BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      00686F BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      006872 90 07 C7         [24] 2552 	mov	dptr,#_D0SetupLen
      006875 E0               [24] 2553 	movx	a,@dptr
      006876 F8               [12] 2554 	mov	r0,a
      006877 A3               [24] 2555 	inc	dptr
      006878 E0               [24] 2556 	movx	a,@dptr
      006879 F9               [12] 2557 	mov	r1,a
      00687A C3               [12] 2558 	clr	c
      00687B 74 20            [12] 2559 	mov	a,#0x20
      00687D 98               [12] 2560 	subb	a,r0
      00687E E4               [12] 2561 	clr	a
      00687F 99               [12] 2562 	subb	a,r1
      006880 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      006882 90 07 C7         [24] 2565 	mov	dptr,#_D0SetupLen
      006885 74 20            [12] 2566 	mov	a,#0x20
      006887 F0               [24] 2567 	movx	@dptr,a
      006888 E4               [12] 2568 	clr	a
      006889 A3               [24] 2569 	inc	dptr
      00688A F0               [24] 2570 	movx	@dptr,a
      00688B                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      00688B 90 07 C7         [24] 2573 	mov	dptr,#_D0SetupLen
      00688E E0               [24] 2574 	movx	a,@dptr
      00688F 90 22 08         [24] 2575 	mov	dptr,#0x2208
      006892 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      006893 90 08 25         [24] 2578 	mov	dptr,#_control_phase
      006896 74 02            [12] 2579 	mov	a,#0x02
      006898 F0               [24] 2580 	movx	@dptr,a
      006899 02 69 21         [24] 2581 	ljmp	00291$
      00689C                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      00689C EB               [12] 2584 	mov	a,r3
      00689D 4C               [12] 2585 	orl	a,r4
      00689E 70 37            [24] 2586 	jnz	00265$
      0068A0 90 07 CC         [24] 2587 	mov	dptr,#_D0UsbConfig
      0068A3 E0               [24] 2588 	movx	a,@dptr
      0068A4 60 31            [24] 2589 	jz	00265$
      0068A6 EA               [12] 2590 	mov	a,r2
      0068A7 60 2E            [24] 2591 	jz	00265$
      0068A9 90 07 C6         [24] 2592 	mov	dptr,#_D0SetupReqCode
      0068AC E0               [24] 2593 	movx	a,@dptr
      0068AD FA               [12] 2594 	mov	r2,a
      0068AE BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      0068B1 30 19 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      0068B4 90 07 C7         [24] 2597 	mov	dptr,#_D0SetupLen
      0068B7 E0               [24] 2598 	movx	a,@dptr
      0068B8 F9               [12] 2599 	mov	r1,a
      0068B9 A3               [24] 2600 	inc	dptr
      0068BA E0               [24] 2601 	movx	a,@dptr
      0068BB FA               [12] 2602 	mov	r2,a
      0068BC B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      0068BF BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      0068C2 90 0E 36         [24] 2606 	mov	dptr,#_keyboard_protocol
      0068C5 E0               [24] 2607 	movx	a,@dptr
      0068C6 90 10 00         [24] 2608 	mov	dptr,#0x1000
      0068C9 F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      0068CA 90 22 08         [24] 2611 	mov	dptr,#0x2208
      0068CD 74 01            [12] 2612 	mov	a,#0x01
      0068CF F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      0068D0 90 08 25         [24] 2615 	mov	dptr,#_control_phase
      0068D3 04               [12] 2616 	inc	a
      0068D4 F0               [24] 2617 	movx	@dptr,a
      0068D5 80 4A            [24] 2618 	sjmp	00291$
      0068D7                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      0068D7 02 5F 72         [24] 2622 	ljmp	_control_stall
      0068DA                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      0068DA 30 17 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      0068DD 90 07 CC         [24] 2626 	mov	dptr,#_D0UsbConfig
      0068E0 E0               [24] 2627 	movx	a,@dptr
      0068E1 60 38            [24] 2628 	jz	00284$
      0068E3 BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      0068E6 8E 05            [24] 2630 	mov	ar5,r6
      0068E8 7E 00            [12] 2631 	mov	r6,#0x00
      0068EA ED               [12] 2632 	mov	a,r5
      0068EB 4E               [12] 2633 	orl	a,r6
      0068EC 70 2D            [24] 2634 	jnz	00284$
      0068EE 90 07 C7         [24] 2635 	mov	dptr,#_D0SetupLen
      0068F1 E0               [24] 2636 	movx	a,@dptr
      0068F2 FE               [12] 2637 	mov	r6,a
      0068F3 A3               [24] 2638 	inc	dptr
      0068F4 E0               [24] 2639 	movx	a,@dptr
      0068F5 FF               [12] 2640 	mov	r7,a
      0068F6 BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      0068F9 BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      0068FC EB               [12] 2644 	mov	a,r3
      0068FD 4C               [12] 2645 	orl	a,r4
      0068FE 70 07            [24] 2646 	jnz	00324$
      006900 90 06 A4         [24] 2647 	mov	dptr,#_keyboard_idle
      006903 E0               [24] 2648 	movx	a,@dptr
      006904 FF               [12] 2649 	mov	r7,a
      006905 80 02            [24] 2650 	sjmp	00325$
      006907                       2651 00324$:
      006907 7F 00            [12] 2652 	mov	r7,#0x00
      006909                       2653 00325$:
      006909 90 10 00         [24] 2654 	mov	dptr,#0x1000
      00690C EF               [12] 2655 	mov	a,r7
      00690D F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      00690E 90 22 08         [24] 2658 	mov	dptr,#0x2208
      006911 74 01            [12] 2659 	mov	a,#0x01
      006913 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      006914 90 08 25         [24] 2662 	mov	dptr,#_control_phase
      006917 04               [12] 2663 	inc	a
      006918 F0               [24] 2664 	movx	@dptr,a
      006919 80 06            [24] 2665 	sjmp	00291$
      00691B                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      00691B 02 5F 72         [24] 2669 	ljmp	_control_stall
      00691E                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      00691E 02 5F 72         [24] 2672 	ljmp	_control_stall
      006921                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006921 90 22 00         [24] 2675 	mov	dptr,#0x2200
      006924 74 C0            [12] 2676 	mov	a,#0xc0
      006926 F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      006927 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      006928                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006928 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      00692B E0               [24] 2692 	movx	a,@dptr
      00692C 20 E6 01         [24] 2693 	jb	acc.6,00102$
      00692F 22               [24] 2694 	ret
      006930                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006930 90 08 25         [24] 2697 	mov	dptr,#_control_phase
      006933 E0               [24] 2698 	movx	a,@dptr
      006934 FF               [12] 2699 	mov	r7,a
      006935 BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      006938 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      00693B E0               [24] 2702 	movx	a,@dptr
      00693C 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      00693E 90 08 25         [24] 2705 	mov	dptr,#_control_phase
      006941 E4               [12] 2706 	clr	a
      006942 F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006943 90 22 00         [24] 2709 	mov	dptr,#0x2200
      006946 74 02            [12] 2710 	mov	a,#0x02
      006948 F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006949 22               [24] 2713 	ret
      00694A                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      00694A BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      00694D 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      006950 E0               [24] 2718 	movx	a,@dptr
      006951 FF               [12] 2719 	mov	r7,a
      006952 90 07 C7         [24] 2720 	mov	dptr,#_D0SetupLen
      006955 E0               [24] 2721 	movx	a,@dptr
      006956 FD               [12] 2722 	mov	r5,a
      006957 A3               [24] 2723 	inc	dptr
      006958 E0               [24] 2724 	movx	a,@dptr
      006959 FE               [12] 2725 	mov	r6,a
      00695A 7C 00            [12] 2726 	mov	r4,#0x00
      00695C EF               [12] 2727 	mov	a,r7
      00695D B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      006960 EC               [12] 2729 	mov	a,r4
      006961 B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      006964 80 03            [24] 2731 	sjmp	00107$
      006966                       2732 00209$:
      006966                       2733 00106$:
      006966 02 5F 72         [24] 2734 	ljmp	_control_stall
      006969                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006969 90 08 26         [24] 2737 	mov	dptr,#_output_kind
      00696C E0               [24] 2738 	movx	a,@dptr
      00696D FF               [12] 2739 	mov	r7,a
      00696E BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      006971 90 07 D4         [24] 2741 	mov	dptr,#_raw_state
      006974 E0               [24] 2742 	movx	a,@dptr
      006975 FE               [12] 2743 	mov	r6,a
      006976 BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006979 7E 00            [12] 2746 	mov	r6,#0x00
      00697B                       2747 00121$:
      00697B EE               [12] 2748 	mov	a,r6
      00697C 24 D5            [12] 2749 	add	a, #_raw_buffer
      00697E FC               [12] 2750 	mov	r4,a
      00697F E4               [12] 2751 	clr	a
      006980 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      006982 FD               [12] 2753 	mov	r5,a
      006983 8E 82            [24] 2754 	mov	dpl,r6
      006985 74 10            [12] 2755 	mov	a,#0x10
      006987 24 00            [12] 2756 	add	a, #0x00
      006989 F5 83            [12] 2757 	mov	dph,a
      00698B E0               [24] 2758 	movx	a,@dptr
      00698C 8C 82            [24] 2759 	mov	dpl,r4
      00698E 8D 83            [24] 2760 	mov	dph,r5
      006990 F0               [24] 2761 	movx	@dptr,a
      006991 0E               [12] 2762 	inc	r6
      006992 BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      006995                       2764 00214$:
      006995 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006997 90 07 D4         [24] 2767 	mov	dptr,#_raw_state
      00699A 74 02            [12] 2768 	mov	a,#0x02
      00699C F0               [24] 2769 	movx	@dptr,a
      00699D 80 2B            [24] 2770 	sjmp	00119$
      00699F                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      00699F BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      0069A2 90 10 00         [24] 2775 	mov	dptr,#0x1000
      0069A5 E0               [24] 2776 	movx	a,@dptr
      0069A6 90 07 D1         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      0069A9 F0               [24] 2778 	movx	@dptr,a
      0069AA 80 1E            [24] 2779 	sjmp	00119$
      0069AC                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      0069AC BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      0069AF 90 10 00         [24] 2783 	mov	dptr,#0x1000
      0069B2 E0               [24] 2784 	movx	a,@dptr
      0069B3 FF               [12] 2785 	mov	r7,a
      0069B4 90 08 27         [24] 2786 	mov	dptr,#_output_report_id
      0069B7 E0               [24] 2787 	movx	a,@dptr
      0069B8 FE               [12] 2788 	mov	r6,a
      0069B9 EF               [12] 2789 	mov	a,r7
      0069BA B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      0069BD 90 10 01         [24] 2792 	mov	dptr,#0x1001
      0069C0 E0               [24] 2793 	movx	a,@dptr
      0069C1 90 07 D1         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      0069C4 F0               [24] 2795 	movx	@dptr,a
      0069C5 80 03            [24] 2796 	sjmp	00119$
      0069C7                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      0069C7 02 5F 72         [24] 2799 	ljmp	_control_stall
      0069CA                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      0069CA 90 08 26         [24] 2802 	mov	dptr,#_output_kind
      0069CD E4               [12] 2803 	clr	a
      0069CE F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      0069CF 90 07 C7         [24] 2806 	mov	dptr,#_D0SetupLen
      0069D2 F0               [24] 2807 	movx	@dptr,a
      0069D3 A3               [24] 2808 	inc	dptr
      0069D4 F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      0069D5 90 08 25         [24] 2811 	mov	dptr,#_control_phase
      0069D8 74 03            [12] 2812 	mov	a,#0x03
      0069DA F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      0069DB 90 22 08         [24] 2815 	mov	dptr,#0x2208
      0069DE E4               [12] 2816 	clr	a
      0069DF F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      0069E0 F5 82            [12] 2819 	mov	dpl,a
      0069E2 74 48            [12] 2820 	mov	a,#0x48
      0069E4 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      0069E5 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      0069E6                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      0069E6 90 08 25         [24] 2833 	mov	dptr,#_control_phase
      0069E9 E0               [24] 2834 	movx	a,@dptr
      0069EA FF               [12] 2835 	mov	r7,a
      0069EB BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      0069EE 90 07 C7         [24] 2838 	mov	dptr,#_D0SetupLen
      0069F1 E0               [24] 2839 	movx	a,@dptr
      0069F2 FD               [12] 2840 	mov	r5,a
      0069F3 A3               [24] 2841 	inc	dptr
      0069F4 E0               [24] 2842 	movx	a,@dptr
      0069F5 4D               [12] 2843 	orl	a,r5
      0069F6 70 06            [24] 2844 	jnz	00101$
      0069F8 90 08 28         [24] 2845 	mov	dptr,#_control_zlp
      0069FB E0               [24] 2846 	movx	a,@dptr
      0069FC 60 0A            [24] 2847 	jz	00102$
      0069FE                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      0069FE 90 22 00         [24] 2850 	mov	dptr,#0x2200
      006A01 E0               [24] 2851 	movx	a,@dptr
      006A02 64 40            [12] 2852 	xrl	a,#0x40
      006A04 F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006A05 02 5F 94         [24] 2856 	ljmp	_control_next
      006A08                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006A08 90 08 25         [24] 2859 	mov	dptr,#_control_phase
      006A0B 74 02            [12] 2860 	mov	a,#0x02
      006A0D F0               [24] 2861 	movx	@dptr,a
      006A0E 80 18            [24] 2862 	sjmp	00110$
      006A10                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006A10 BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006A13 90 07 C6         [24] 2867 	mov	dptr,#_D0SetupReqCode
      006A16 E0               [24] 2868 	movx	a,@dptr
      006A17 FF               [12] 2869 	mov	r7,a
      006A18 BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      006A1B 90 07 C7         [24] 2871 	mov	dptr,#_D0SetupLen
      006A1E E0               [24] 2872 	movx	a,@dptr
      006A1F 90 22 07         [24] 2873 	mov	dptr,#0x2207
      006A22 F0               [24] 2874 	movx	@dptr,a
      006A23                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      006A23 90 08 25         [24] 2877 	mov	dptr,#_control_phase
      006A26 E4               [12] 2878 	clr	a
      006A27 F0               [24] 2879 	movx	@dptr,a
      006A28                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A28 90 22 00         [24] 2882 	mov	dptr,#0x2200
      006A2B 74 82            [12] 2883 	mov	a,#0x82
      006A2D F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      006A2E 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      006A2F                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      006A2F                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      006A2F 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      006A32 E0               [24] 2902 	movx	a,@dptr
      006A33 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006A36 12 5F 1B         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006A39 90 22 07         [24] 2907 	mov	dptr,#0x2207
      006A3C E4               [12] 2908 	clr	a
      006A3D F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006A3E 90 07 CE         [24] 2911 	mov	dptr,#_USB_SleepStatus
      006A41 F0               [24] 2912 	movx	@dptr,a
      006A42 90 07 CD         [24] 2913 	mov	dptr,#_USB_EnumStatus
      006A45 F0               [24] 2914 	movx	@dptr,a
      006A46 90 07 CC         [24] 2915 	mov	dptr,#_D0UsbConfig
      006A49 F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006A4A 90 07 D1         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      006A4D F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006A4E 90 0E 36         [24] 2921 	mov	dptr,#_keyboard_protocol
      006A51 04               [12] 2922 	inc	a
      006A52 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006A53 90 06 A4         [24] 2925 	mov	dptr,#_keyboard_idle
      006A56 E4               [12] 2926 	clr	a
      006A57 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006A58 90 07 F6         [24] 2929 	mov	dptr,#_keyboard_reset
      006A5B 04               [12] 2930 	inc	a
      006A5C F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006A5D 90 07 C6         [24] 2933 	mov	dptr,#_D0SetupReqCode
      006A60 74 FF            [12] 2934 	mov	a,#0xff
      006A62 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006A63 90 07 C7         [24] 2937 	mov	dptr,#_D0SetupLen
      006A66 E4               [12] 2938 	clr	a
      006A67 F0               [24] 2939 	movx	@dptr,a
      006A68 A3               [24] 2940 	inc	dptr
      006A69 F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006A6A 90 08 25         [24] 2943 	mov	dptr,#_control_phase
      006A6D F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A6E 90 22 00         [24] 2946 	mov	dptr,#0x2200
      006A71 74 02            [12] 2947 	mov	a,#0x02
      006A73 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006A74 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      006A77 E4               [12] 2951 	clr	a
      006A78 F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006A79 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      006A7C 04               [12] 2955 	inc	a
      006A7D F0               [24] 2956 	movx	@dptr,a
      006A7E 02 6B 14         [24] 2957 	ljmp	00130$
      006A81                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006A81 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      006A84 E0               [24] 2961 	movx	a,@dptr
      006A85 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006A88 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      006A8B E0               [24] 2965 	movx	a,@dptr
      006A8C FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006A8D 74 07            [12] 2968 	mov	a,#0x07
      006A8F 5F               [12] 2969 	anl	a,r7
      006A90 FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006A91 EF               [12] 2972 	mov	a,r7
      006A92 54 18            [12] 2973 	anl	a,#0x18
      006A94 70 08            [24] 2974 	jnz	00115$
      006A96 EE               [12] 2975 	mov	a,r6
      006A97 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006A99 12 69 28         [24] 2978 	lcall	_control_out
      006A9C 80 43            [24] 2979 	sjmp	00116$
      006A9E                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006A9E 8F 05            [24] 2982 	mov	ar5,r7
      006AA0 74 18            [12] 2983 	mov	a,#0x18
      006AA2 5D               [12] 2984 	anl	a,r5
      006AA3 FC               [12] 2985 	mov	r4,a
      006AA4 BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006AA7 EE               [12] 2988 	mov	a,r6
      006AA8 70 05            [24] 2989 	jnz	00106$
      006AAA 12 69 E6         [24] 2990 	lcall	_control_in
      006AAD 80 32            [24] 2991 	sjmp	00116$
      006AAF                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006AAF EE               [12] 2994 	mov	a,r6
      006AB0 24 FC            [12] 2995 	add	a,#0xff - 0x03
      006AB2 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006AB4 8E 04            [24] 2999 	mov	ar4,r6
      006AB6 7B 00            [12] 3000 	mov	r3,#0x00
      006AB8 74 22            [12] 3001 	mov	a,#0x22
      006ABA 2B               [12] 3002 	add	a, r3
      006ABB FB               [12] 3003 	mov	r3,a
      006ABC 8C 82            [24] 3004 	mov	dpl,r4
      006ABE 8B 83            [24] 3005 	mov	dph,r3
      006AC0 E0               [24] 3006 	movx	a,@dptr
      006AC1 FA               [12] 3007 	mov	r2,a
      006AC2 74 FC            [12] 3008 	mov	a,#0xfc
      006AC4 5A               [12] 3009 	anl	a,r2
      006AC5 44 02            [12] 3010 	orl	a,#0x02
      006AC7 8C 82            [24] 3011 	mov	dpl,r4
      006AC9 8B 83            [24] 3012 	mov	dph,r3
      006ACB F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006ACC BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      006ACF 12 5E FE         [24] 3016 	lcall	_raw_complete
      006AD2 80 0D            [24] 3017 	sjmp	00116$
      006AD4                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006AD4 53 05 18         [24] 3020 	anl	ar5,#0x18
      006AD7 BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      006ADA EF               [12] 3022 	mov	a,r7
      006ADB 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006ADE 12 61 8B         [24] 3025 	lcall	_control_setup
      006AE1                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006AE1 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      006AE4 E4               [12] 3029 	clr	a
      006AE5 F0               [24] 3030 	movx	@dptr,a
      006AE6 80 2C            [24] 3031 	sjmp	00130$
      006AE8                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006AE8 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      006AEB E0               [24] 3035 	movx	a,@dptr
      006AEC 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006AEF 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      006AF2 E0               [24] 3039 	movx	a,@dptr
      006AF3 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      006AF6 90 07 CE         [24] 3041 	mov	dptr,#_USB_SleepStatus
      006AF9 E0               [24] 3042 	movx	a,@dptr
      006AFA 43 E0 02         [24] 3043 	orl	acc,#0x02
      006AFD F0               [24] 3044 	movx	@dptr,a
      006AFE 80 0E            [24] 3045 	sjmp	00120$
      006B00                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006B00 90 07 CE         [24] 3048 	mov	dptr,#_USB_SleepStatus
      006B03 E0               [24] 3049 	movx	a,@dptr
      006B04 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      006B07 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006B08 90 07 F6         [24] 3053 	mov	dptr,#_keyboard_reset
      006B0B 74 01            [12] 3054 	mov	a,#0x01
      006B0D F0               [24] 3055 	movx	@dptr,a
      006B0E                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      006B0E 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      006B11 74 04            [12] 3059 	mov	a,#0x04
      006B13 F0               [24] 3060 	movx	@dptr,a
      006B14                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006B14 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      006B17 E0               [24] 3064 	movx	a,@dptr
      006B18 54 25            [12] 3065 	anl	a,#0x25
      006B1A 60 03            [24] 3066 	jz	00242$
      006B1C 02 6A 2F         [24] 3067 	ljmp	00129$
      006B1F                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      006B1F 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      006B20                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3080 ;	assignBit
      006B20 C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006B22 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      006B25 E4               [12] 3084 	clr	a
      006B26 F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006B27 90 07 D4         [24] 3087 	mov	dptr,#_raw_state
      006B2A F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006B2B 12 5F 1B         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006B2E 90 07 CE         [24] 3092 	mov	dptr,#_USB_SleepStatus
      006B31 E4               [12] 3093 	clr	a
      006B32 F0               [24] 3094 	movx	@dptr,a
      006B33 90 07 CD         [24] 3095 	mov	dptr,#_USB_EnumStatus
      006B36 F0               [24] 3096 	movx	@dptr,a
      006B37 90 07 CC         [24] 3097 	mov	dptr,#_D0UsbConfig
      006B3A F0               [24] 3098 	movx	@dptr,a
      006B3B 90 22 07         [24] 3099 	mov	dptr,#0x2207
      006B3E F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006B3F 90 07 CF         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      006B42 F0               [24] 3103 	movx	@dptr,a
      006B43 90 07 D0         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      006B46 F0               [24] 3105 	movx	@dptr,a
      006B47 90 07 D1         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      006B4A F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006B4B 90 0E 36         [24] 3109 	mov	dptr,#_keyboard_protocol
      006B4E 04               [12] 3110 	inc	a
      006B4F F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006B50 90 06 A4         [24] 3113 	mov	dptr,#_keyboard_idle
      006B53 E4               [12] 3114 	clr	a
      006B54 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006B55 90 07 F6         [24] 3117 	mov	dptr,#_keyboard_reset
      006B58 F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006B59 90 08 25         [24] 3120 	mov	dptr,#_control_phase
      006B5C F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006B5D 90 07 C6         [24] 3123 	mov	dptr,#_D0SetupReqCode
      006B60 14               [12] 3124 	dec	a
      006B61 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006B62 90 07 C7         [24] 3127 	mov	dptr,#_D0SetupLen
      006B65 E4               [12] 3128 	clr	a
      006B66 F0               [24] 3129 	movx	@dptr,a
      006B67 A3               [24] 3130 	inc	dptr
      006B68 F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B69 90 22 00         [24] 3133 	mov	dptr,#0x2200
      006B6C 74 02            [12] 3134 	mov	a,#0x02
      006B6E F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006B6F 90 22 37         [24] 3137 	mov	dptr,#0x2237
      006B72 74 7F            [12] 3138 	mov	a,#0x7f
      006B74 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006B75 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      006B78 74 FF            [12] 3142 	mov	a,#0xff
      006B7A F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006B7B 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      006B7E 74 07            [12] 3146 	mov	a,#0x07
      006B80 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006B81 A3               [24] 3149 	inc	dptr
      006B82 74 80            [12] 3150 	mov	a,#0x80
      006B84 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3153 ;	assignBit
      006B85 D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006B87 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      006B88                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006B88 90 07 CE         [24] 3169 	mov	dptr,#_USB_SleepStatus
      006B8B E0               [24] 3170 	movx	a,@dptr
      006B8C FF               [12] 3171 	mov	r7,a
      006B8D BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006B90 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      006B93 E0               [24] 3175 	movx	a,@dptr
      006B94 FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006B95 E0               [24] 3178 	movx	a,@dptr
      006B96 FE               [12] 3179 	mov	r6,a
      006B97 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      006B9A 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      006B9D EE               [12] 3182 	mov	a,r6
      006B9E F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006B9F 7E 0A            [12] 3185 	mov	r6,#0x0a
      006BA1                       3186 00108$:
      006BA1 EE               [12] 3187 	mov	a,r6
      006BA2 60 09            [24] 3188 	jz	00105$
      006BA4 90 00 01         [24] 3189 	mov	dptr,#0x0001
      006BA7 12 5D 62         [24] 3190 	lcall	_mDelaymS
      006BAA 1E               [12] 3191 	dec	r6
      006BAB 80 F4            [24] 3192 	sjmp	00108$
      006BAD                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006BAD 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      006BB0 EF               [12] 3196 	mov	a,r7
      006BB1 F0               [24] 3197 	movx	@dptr,a
      006BB2                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006BB2 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      006BB3                       3220 _ak820_usb_send:
      006BB3 E5 82            [12] 3221 	mov	a,dpl
      006BB5 90 08 35         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006BB8 F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006BB9 90 08 36         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006BBC 74 2E            [12] 3226 	mov	a,#0x2e
      006BBE F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006BBF 90 08 35         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006BC2 E0               [24] 3230 	movx	a,@dptr
      006BC3 FF               [12] 3231 	mov	r7,a
      006BC4 BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      006BC7                       3233 00306$:
      006BC7 40 14            [24] 3234 	jc	00101$
      006BC9 EF               [12] 3235 	mov	a,r7
      006BCA 24 FC            [12] 3236 	add	a,#0xff - 0x03
      006BCC 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      006BCE 90 08 34         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      006BD1 E0               [24] 3240 	movx	a,@dptr
      006BD2 FE               [12] 3241 	mov  r6,a
      006BD3 24 BF            [12] 3242 	add	a,#0xff - 0x40
      006BD5 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      006BD7 90 07 CD         [24] 3245 	mov	dptr,#_USB_EnumStatus
      006BDA E0               [24] 3246 	movx	a,@dptr
      006BDB 70 04            [24] 3247 	jnz	00102$
      006BDD                       3248 00101$:
      006BDD 75 82 00         [24] 3249 	mov	dpl, #0x00
      006BE0 22               [24] 3250 	ret
      006BE1                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006BE1 BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006BE4 BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      006BE7 80 04            [24] 3256 	sjmp	00107$
      006BE9                       3257 00313$:
      006BE9 75 82 00         [24] 3258 	mov	dpl, #0x00
      006BEC 22               [24] 3259 	ret
      006BED                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006BED 90 08 36         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006BF0 E4               [12] 3263 	clr	a
      006BF1 F0               [24] 3264 	movx	@dptr,a
      006BF2 80 3C            [24] 3265 	sjmp	00119$
      006BF4                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006BF4 BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006BF7 90 08 32         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      006BFA E0               [24] 3271 	movx	a,@dptr
      006BFB FD               [12] 3272 	mov	r5,a
      006BFC A3               [24] 3273 	inc	dptr
      006BFD E0               [24] 3274 	movx	a,@dptr
      006BFE FF               [12] 3275 	mov	r7,a
      006BFF 8D 82            [24] 3276 	mov	dpl,r5
      006C01 8F 83            [24] 3277 	mov	dph,r7
      006C03 E0               [24] 3278 	movx	a,@dptr
      006C04 FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006C05 BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      006C08                       3282 00316$:
      006C08 50 0E            [24] 3283 	jnc	00108$
      006C0A EF               [12] 3284 	mov	a,r7
      006C0B 90 BF 4C         [24] 3285 	mov	dptr,#_shared_lengths
      006C0E 93               [24] 3286 	movc	a,@a+dptr
      006C0F FD               [12] 3287 	mov	r5,a
      006C10 60 06            [24] 3288 	jz	00108$
      006C12 EE               [12] 3289 	mov	a,r6
      006C13 B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      006C16 80 04            [24] 3291 	sjmp	00109$
      006C18                       3292 00319$:
      006C18                       3293 00108$:
      006C18 75 82 00         [24] 3294 	mov	dpl, #0x00
      006C1B 22               [24] 3295 	ret
      006C1C                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006C1C EF               [12] 3298 	mov	a,r7
      006C1D 90 BF 45         [24] 3299 	mov	dptr,#_shared_offsets
      006C20 93               [24] 3300 	movc	a,@a+dptr
      006C21 90 08 36         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006C24 F0               [24] 3302 	movx	@dptr,a
      006C25 80 09            [24] 3303 	sjmp	00119$
      006C27                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006C27 BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      006C2A 80 04            [24] 3307 	sjmp	00119$
      006C2C                       3308 00320$:
      006C2C 75 82 00         [24] 3309 	mov	dpl, #0x00
      006C2F 22               [24] 3310 	ret
      006C30                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006C30 90 07 CE         [24] 3313 	mov	dptr,#_USB_SleepStatus
      006C33 E0               [24] 3314 	movx	a,@dptr
      006C34 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      006C37 12 6B 88         [24] 3316 	lcall	_USB_WakeUp_PC
      006C3A 75 82 00         [24] 3317 	mov	dpl, #0x00
      006C3D 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006C3E                       3320 00184$:
      006C3E 7F FA            [12] 3321 	mov	r7,#0xfa
      006C40                       3322 00127$:
      006C40 90 08 35         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006C43 E0               [24] 3324 	movx	a,@dptr
      006C44 FC               [12] 3325 	mov	r4,a
      006C45 7D 00            [12] 3326 	mov	r5,#0x00
      006C47 8C 02            [24] 3327 	mov	ar2,r4
      006C49 74 22            [12] 3328 	mov	a,#0x22
      006C4B 2D               [12] 3329 	add	a, r5
      006C4C FB               [12] 3330 	mov	r3,a
      006C4D 8A 82            [24] 3331 	mov	dpl,r2
      006C4F 8B 83            [24] 3332 	mov	dph,r3
      006C51 E0               [24] 3333 	movx	a,@dptr
      006C52 54 03            [12] 3334 	anl	a,#0x03
      006C54 70 14            [24] 3335 	jnz	00129$
      006C56 8F 03            [24] 3336 	mov	ar3,r7
      006C58 1F               [12] 3337 	dec	r7
      006C59 EB               [12] 3338 	mov	a,r3
      006C5A 60 0E            [24] 3339 	jz	00129$
      006C5C 7B 28            [12] 3340 	mov	r3,#0x28
      006C5E                       3341 00141$:
      006C5E EB               [12] 3342 	mov	a,r3
      006C5F 60 DF            [24] 3343 	jz	00127$
      006C61 90 00 01         [24] 3344 	mov	dptr,#0x0001
      006C64 12 5D 1E         [24] 3345 	lcall	_mDelayuS
      006C67 1B               [12] 3346 	dec	r3
      006C68 80 F4            [24] 3347 	sjmp	00141$
      006C6A                       3348 00129$:
                                   3349 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006C6A A2 AF            [12] 3350 	mov	c,_EA
      006C6C E4               [12] 3351 	clr	a
      006C6D 33               [12] 3352 	rlc	a
      006C6E FF               [12] 3353 	mov	r7,a
                                   3354 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3355 ;	assignBit
      006C6F C2 AF            [12] 3356 	clr	_EA
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006C71 90 07 CD         [24] 3358 	mov	dptr,#_USB_EnumStatus
      006C74 E0               [24] 3359 	movx	a,@dptr
      006C75 60 25            [24] 3360 	jz	00130$
      006C77 90 08 35         [24] 3361 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006C7A E0               [24] 3362 	movx	a,@dptr
      006C7B FB               [12] 3363 	mov	r3,a
      006C7C F9               [12] 3364 	mov	r1,a
      006C7D 7A 00            [12] 3365 	mov	r2,#0x00
      006C7F 74 22            [12] 3366 	mov	a,#0x22
      006C81 2A               [12] 3367 	add	a, r2
      006C82 FA               [12] 3368 	mov	r2,a
      006C83 89 82            [24] 3369 	mov	dpl,r1
      006C85 8A 83            [24] 3370 	mov	dph,r2
      006C87 E0               [24] 3371 	movx	a,@dptr
      006C88 FA               [12] 3372 	mov	r2,a
      006C89 53 02 03         [24] 3373 	anl	ar2,#0x03
      006C8C BA 02 0D         [24] 3374 	cjne	r2,#0x02,00130$
                                   3375 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006C8F BB 03 13         [24] 3376 	cjne	r3,#0x03,00192$
      006C92 90 07 D4         [24] 3377 	mov	dptr,#_raw_state
      006C95 E0               [24] 3378 	movx	a,@dptr
      006C96 FB               [12] 3379 	mov	r3,a
      006C97 BB 03 02         [24] 3380 	cjne	r3,#0x03,00331$
      006C9A 80 09            [24] 3381 	sjmp	00192$
      006C9C                       3382 00331$:
      006C9C                       3383 00130$:
                                   3384 ;	assignBit
      006C9C EF               [12] 3385 	mov	a,r7
      006C9D 24 FF            [12] 3386 	add	a,#0xff
      006C9F 92 AF            [24] 3387 	mov	_EA,c
      006CA1 75 82 00         [24] 3388 	mov	dpl, #0x00
      006CA4 22               [24] 3389 	ret
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006CA5                       3391 00192$:
      006CA5 7B 00            [12] 3392 	mov	r3,#0x00
      006CA7                       3393 00144$:
      006CA7 C3               [12] 3394 	clr	c
      006CA8 EB               [12] 3395 	mov	a,r3
      006CA9 9E               [12] 3396 	subb	a,r6
      006CAA 50 67            [24] 3397 	jnc	00137$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006CAC C0 07            [24] 3399 	push	ar7
      006CAE 90 08 35         [24] 3400 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006CB1 E0               [24] 3401 	movx	a,@dptr
      006CB2 F9               [12] 3402 	mov	r1,a
      006CB3 E4               [12] 3403 	clr	a
      006CB4 C3               [12] 3404 	clr	c
      006CB5 C9               [12] 3405 	xch	a,r1
      006CB6 13               [12] 3406 	rrc	a
      006CB7 C9               [12] 3407 	xch	a,r1
      006CB8 13               [12] 3408 	rrc	a
      006CB9 A2 E0            [12] 3409 	mov	c,acc.0
      006CBB C9               [12] 3410 	xch	a,r1
      006CBC 13               [12] 3411 	rrc	a
      006CBD C9               [12] 3412 	xch	a,r1
      006CBE 13               [12] 3413 	rrc	a
      006CBF C9               [12] 3414 	xch	a,r1
      006CC0 FA               [12] 3415 	mov	r2,a
      006CC1 8B 00            [24] 3416 	mov	ar0,r3
      006CC3 7F 00            [12] 3417 	mov	r7,#0x00
      006CC5 E8               [12] 3418 	mov	a,r0
      006CC6 29               [12] 3419 	add	a, r1
      006CC7 F9               [12] 3420 	mov	r1,a
      006CC8 EF               [12] 3421 	mov	a,r7
      006CC9 3A               [12] 3422 	addc	a, r2
      006CCA 24 10            [12] 3423 	add	a,#0x10
      006CCC FA               [12] 3424 	mov	r2,a
      006CCD 90 08 32         [24] 3425 	mov	dptr,#_ak820_usb_send_PARM_2
      006CD0 E0               [24] 3426 	movx	a,@dptr
      006CD1 F8               [12] 3427 	mov	r0,a
      006CD2 A3               [24] 3428 	inc	dptr
      006CD3 E0               [24] 3429 	movx	a,@dptr
      006CD4 FF               [12] 3430 	mov	r7,a
      006CD5 EB               [12] 3431 	mov	a,r3
      006CD6 28               [12] 3432 	add	a, r0
      006CD7 F5 2C            [12] 3433 	mov	_ak820_usb_send_sloc0_1_0,a
      006CD9 E4               [12] 3434 	clr	a
      006CDA 3F               [12] 3435 	addc	a, r7
      006CDB F5 2D            [12] 3436 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006CDD 85 2C 82         [24] 3437 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006CE0 85 2D 83         [24] 3438 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006CE3 E0               [24] 3439 	movx	a,@dptr
      006CE4 89 82            [24] 3440 	mov	dpl,r1
      006CE6 8A 83            [24] 3441 	mov	dph,r2
      006CE8 F0               [24] 3442 	movx	@dptr,a
                                   3443 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006CE9 90 08 36         [24] 3444 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006CEC E0               [24] 3445 	movx	a,@dptr
      006CED F5 2E            [12] 3446 	mov	_ak820_usb_send_sloc1_1_0,a
      006CEF 74 2E            [12] 3447 	mov	a,#0x2e
      006CF1 B5 2E 04         [24] 3448 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006CF4 D0 07            [24] 3449 	pop	ar7
      006CF6 80 18            [24] 3450 	sjmp	00145$
      006CF8                       3451 00333$:
      006CF8 D0 07            [24] 3452 	pop	ar7
      006CFA EB               [12] 3453 	mov	a,r3
      006CFB 25 2E            [12] 3454 	add	a, _ak820_usb_send_sloc1_1_0
      006CFD 24 F7            [12] 3455 	add	a, #_input_snapshot
      006CFF F9               [12] 3456 	mov	r1,a
      006D00 E4               [12] 3457 	clr	a
      006D01 34 07            [12] 3458 	addc	a,#(_input_snapshot >> 8)
      006D03 FA               [12] 3459 	mov	r2,a
      006D04 85 2C 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006D07 85 2D 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006D0A E0               [24] 3462 	movx	a,@dptr
      006D0B 89 82            [24] 3463 	mov	dpl,r1
      006D0D 8A 83            [24] 3464 	mov	dph,r2
      006D0F F0               [24] 3465 	movx	@dptr,a
      006D10                       3466 00145$:
                                   3467 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006D10 0B               [12] 3468 	inc	r3
      006D11 80 94            [24] 3469 	sjmp	00144$
      006D13                       3470 00137$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006D13 90 08 35         [24] 3472 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006D16 E0               [24] 3473 	movx	a,@dptr
      006D17 FB               [12] 3474 	mov	r3,a
      006D18 F9               [12] 3475 	mov	r1,a
      006D19 7A 00            [12] 3476 	mov	r2,#0x00
      006D1B 74 08            [12] 3477 	mov	a,#0x08
      006D1D 29               [12] 3478 	add	a, r1
      006D1E F9               [12] 3479 	mov	r1,a
      006D1F 74 22            [12] 3480 	mov	a,#0x22
      006D21 3A               [12] 3481 	addc	a, r2
      006D22 FA               [12] 3482 	mov	r2,a
      006D23 89 82            [24] 3483 	mov	dpl,r1
      006D25 8A 83            [24] 3484 	mov	dph,r2
      006D27 EE               [12] 3485 	mov	a,r6
      006D28 F0               [24] 3486 	movx	@dptr,a
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006D29 BB 03 06         [24] 3488 	cjne	r3,#0x03,00139$
      006D2C 90 07 D4         [24] 3489 	mov	dptr,#_raw_state
      006D2F 74 04            [12] 3490 	mov	a,#0x04
      006D31 F0               [24] 3491 	movx	@dptr,a
      006D32                       3492 00139$:
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006D32 74 22            [12] 3494 	mov	a,#0x22
      006D34 2D               [12] 3495 	add	a, r5
      006D35 FD               [12] 3496 	mov	r5,a
      006D36 8C 82            [24] 3497 	mov	dpl,r4
      006D38 8D 83            [24] 3498 	mov	dph,r5
      006D3A E0               [24] 3499 	movx	a,@dptr
      006D3B FE               [12] 3500 	mov	r6,a
      006D3C 53 06 FC         [24] 3501 	anl	ar6,#0xfc
      006D3F 8C 82            [24] 3502 	mov	dpl,r4
      006D41 8D 83            [24] 3503 	mov	dph,r5
      006D43 EE               [12] 3504 	mov	a,r6
      006D44 F0               [24] 3505 	movx	@dptr,a
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3507 ;	assignBit
      006D45 EF               [12] 3508 	mov	a,r7
      006D46 24 FF            [12] 3509 	add	a,#0xff
      006D48 92 AF            [24] 3510 	mov	_EA,c
                                   3511 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006D4A 75 82 01         [24] 3512 	mov	dpl, #0x01
                                   3513 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006D4D 22               [24] 3514 	ret
                                   3515 ;------------------------------------------------------------
                                   3516 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3517 ;------------------------------------------------------------
                                   3518 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3519 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3520 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3521 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3522 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3523 ;------------------------------------------------------------
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3525 ;	-----------------------------------------
                                   3526 ;	 function ak820_usb_try_send
                                   3527 ;	-----------------------------------------
      006D4E                       3528 _ak820_usb_try_send:
      006D4E E5 82            [12] 3529 	mov	a,dpl
      006D50 90 08 3A         [24] 3530 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006D53 F0               [24] 3531 	movx	@dptr,a
                                   3532 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3533 ;	assignBit
      006D54 A2 AF            [12] 3534 	mov	c,_EA
      006D56 92 1D            [24] 3535 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006D58 90 08 3B         [24] 3537 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006D5B E4               [12] 3538 	clr	a
      006D5C F0               [24] 3539 	movx	@dptr,a
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3541 ;	assignBit
      006D5D C2 AF            [12] 3542 	clr	_EA
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006D5F 90 08 3A         [24] 3544 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006D62 E0               [24] 3545 	movx	a,@dptr
      006D63 FF               [12] 3546 	mov	r7,a
      006D64 BF 01 00         [24] 3547 	cjne	r7,#0x01,00152$
      006D67                       3548 00152$:
      006D67 40 4E            [24] 3549 	jc	00102$
      006D69 EF               [12] 3550 	mov	a,r7
      006D6A 24 FD            [12] 3551 	add	a,#0xff - 0x02
      006D6C 40 49            [24] 3552 	jc	00102$
                                   3553 ;	free result
      006D6E 90 07 CD         [24] 3554 	mov	dptr,#_USB_EnumStatus
      006D71 E0               [24] 3555 	movx	a,@dptr
      006D72 60 43            [24] 3556 	jz	00102$
                                   3557 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006D74 90 07 CE         [24] 3558 	mov	dptr,#_USB_SleepStatus
      006D77 E0               [24] 3559 	movx	a,@dptr
      006D78 20 E1 3C         [24] 3560 	jb	acc.1,00102$
      006D7B 90 07 F6         [24] 3561 	mov	dptr,#_keyboard_reset
      006D7E E0               [24] 3562 	movx	a,@dptr
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006D7F 70 36            [24] 3564 	jnz	00102$
      006D81 8F 06            [24] 3565 	mov	ar6,r7
      006D83 24 22            [12] 3566 	add	a,#0x22
      006D85 FD               [12] 3567 	mov	r5,a
      006D86 8E 82            [24] 3568 	mov	dpl,r6
      006D88 8D 83            [24] 3569 	mov	dph,r5
      006D8A E0               [24] 3570 	movx	a,@dptr
      006D8B FE               [12] 3571 	mov	r6,a
      006D8C 53 06 03         [24] 3572 	anl	ar6,#0x03
      006D8F BE 02 25         [24] 3573 	cjne	r6,#0x02,00102$
                                   3574 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006D92 90 08 37         [24] 3575 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006D95 E0               [24] 3576 	movx	a,@dptr
      006D96 FD               [12] 3577 	mov	r5,a
      006D97 A3               [24] 3578 	inc	dptr
      006D98 E0               [24] 3579 	movx	a,@dptr
      006D99 FE               [12] 3580 	mov	r6,a
      006D9A 90 08 39         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006D9D E0               [24] 3582 	movx	a,@dptr
      006D9E FC               [12] 3583 	mov	r4,a
      006D9F 90 08 32         [24] 3584 	mov	dptr,#_ak820_usb_send_PARM_2
      006DA2 ED               [12] 3585 	mov	a,r5
      006DA3 F0               [24] 3586 	movx	@dptr,a
      006DA4 EE               [12] 3587 	mov	a,r6
      006DA5 A3               [24] 3588 	inc	dptr
      006DA6 F0               [24] 3589 	movx	@dptr,a
      006DA7 90 08 34         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_3
      006DAA EC               [12] 3591 	mov	a,r4
      006DAB F0               [24] 3592 	movx	@dptr,a
      006DAC 8F 82            [24] 3593 	mov	dpl, r7
      006DAE 12 6B B3         [24] 3594 	lcall	_ak820_usb_send
      006DB1 E5 82            [12] 3595 	mov	a, dpl
      006DB3 90 08 3B         [24] 3596 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006DB6 F0               [24] 3597 	movx	@dptr,a
      006DB7                       3598 00102$:
                                   3599 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3600 ;	assignBit
      006DB7 A2 1D            [12] 3601 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006DB9 92 AF            [24] 3602 	mov	_EA,c
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006DBB 90 08 3B         [24] 3604 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006DBE E0               [24] 3605 	movx	a,@dptr
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006DBF F5 82            [12] 3607 	mov	dpl,a
      006DC1 22               [24] 3608 	ret
                                   3609 ;------------------------------------------------------------
                                   3610 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3611 ;------------------------------------------------------------
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3613 ;	-----------------------------------------
                                   3614 ;	 function raw_request_is_nonpersistent
                                   3615 ;	-----------------------------------------
      006DC2                       3616 _raw_request_is_nonpersistent:
                                   3617 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006DC2 90 07 D5         [24] 3618 	mov	dptr,#_raw_buffer
      006DC5 E0               [24] 3619 	movx	a,@dptr
      006DC6 FF               [12] 3620 	mov	r7,a
      006DC7 BF 01 02         [24] 3621 	cjne	r7,#0x01,00302$
      006DCA 80 35            [24] 3622 	sjmp	00108$
      006DCC                       3623 00302$:
      006DCC BF 02 02         [24] 3624 	cjne	r7,#0x02,00303$
      006DCF 80 34            [24] 3625 	sjmp	00109$
      006DD1                       3626 00303$:
      006DD1 BF 04 02         [24] 3627 	cjne	r7,#0x04,00304$
      006DD4 80 2B            [24] 3628 	sjmp	00108$
      006DD6                       3629 00304$:
      006DD6 BF 08 02         [24] 3630 	cjne	r7,#0x08,00305$
      006DD9 80 47            [24] 3631 	sjmp	00116$
      006DDB                       3632 00305$:
      006DDB BF 0B 02         [24] 3633 	cjne	r7,#0x0b,00306$
      006DDE 80 21            [24] 3634 	sjmp	00108$
      006DE0                       3635 00306$:
      006DE0 BF 0C 02         [24] 3636 	cjne	r7,#0x0c,00307$
      006DE3 80 1C            [24] 3637 	sjmp	00108$
      006DE5                       3638 00307$:
      006DE5 BF 0D 02         [24] 3639 	cjne	r7,#0x0d,00308$
      006DE8 80 17            [24] 3640 	sjmp	00108$
      006DEA                       3641 00308$:
      006DEA BF 0E 02         [24] 3642 	cjne	r7,#0x0e,00309$
      006DED 80 12            [24] 3643 	sjmp	00108$
      006DEF                       3644 00309$:
      006DEF BF 11 02         [24] 3645 	cjne	r7,#0x11,00310$
      006DF2 80 0D            [24] 3646 	sjmp	00108$
      006DF4                       3647 00310$:
      006DF4 BF 12 02         [24] 3648 	cjne	r7,#0x12,00311$
      006DF7 80 08            [24] 3649 	sjmp	00108$
      006DF9                       3650 00311$:
      006DF9 BF FE 02         [24] 3651 	cjne	r7,#0xfe,00312$
      006DFC 80 46            [24] 3652 	sjmp	00124$
      006DFE                       3653 00312$:
      006DFE 02 6E 99         [24] 3654 	ljmp	00144$
                                   3655 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006E01                       3656 00108$:
                                   3657 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006E01 75 82 01         [24] 3658 	mov	dpl, #0x01
      006E04 22               [24] 3659 	ret
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006E05                       3661 00109$:
                                   3662 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006E05 12 70 CB         [24] 3663 	lcall	_ak820_outline_0172
      006E08 BF 01 02         [24] 3664 	cjne	r7,#0x01,00313$
      006E0B 80 0D            [24] 3665 	sjmp	00113$
      006E0D                       3666 00313$:
      006E0D BF 02 02         [24] 3667 	cjne	r7,#0x02,00314$
      006E10 80 08            [24] 3668 	sjmp	00113$
      006E12                       3669 00314$:
      006E12 BF 03 02         [24] 3670 	cjne	r7,#0x03,00315$
      006E15 80 03            [24] 3671 	sjmp	00113$
      006E17                       3672 00315$:
      006E17 BF 04 04         [24] 3673 	cjne	r7,#0x04,00114$
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006E1A                       3675 00113$:
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006E1A 75 82 01         [24] 3677 	mov	dpl, #0x01
      006E1D 22               [24] 3678 	ret
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006E1E                       3680 00114$:
      006E1E 75 82 00         [24] 3681 	mov	dpl, #0x00
      006E21 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006E22                       3684 00116$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006E22 12 70 CB         [24] 3686 	lcall	_ak820_outline_0172
      006E25 BF 40 02         [24] 3687 	cjne	r7,#0x40,00318$
      006E28 80 12            [24] 3688 	sjmp	00121$
      006E2A                       3689 00318$:
      006E2A BF 41 02         [24] 3690 	cjne	r7,#0x41,00319$
      006E2D 80 0D            [24] 3691 	sjmp	00121$
      006E2F                       3692 00319$:
      006E2F BF 42 02         [24] 3693 	cjne	r7,#0x42,00320$
      006E32 80 08            [24] 3694 	sjmp	00121$
      006E34                       3695 00320$:
      006E34 BF 43 02         [24] 3696 	cjne	r7,#0x43,00321$
      006E37 80 03            [24] 3697 	sjmp	00121$
      006E39                       3698 00321$:
      006E39 BF 44 04         [24] 3699 	cjne	r7,#0x44,00122$
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006E3C                       3701 00121$:
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006E3C 75 82 01         [24] 3703 	mov	dpl, #0x01
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006E3F 22               [24] 3705 	ret
      006E40                       3706 00122$:
      006E40 75 82 00         [24] 3707 	mov	dpl, #0x00
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006E43 22               [24] 3709 	ret
      006E44                       3710 00124$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006E44 12 70 CB         [24] 3712 	lcall	_ak820_outline_0172
      006E47 24 F2            [12] 3713 	add	a,#0xff - 0x0d
      006E49 40 4A            [24] 3714 	jc	00142$
                                   3715 ;	free result
      006E4B EF               [12] 3716 	mov	a,r7
      006E4C 24 0A            [12] 3717 	add	a,#(00325$-3-.)
      006E4E 83               [24] 3718 	movc	a,@a+pc
      006E4F F5 82            [12] 3719 	mov	dpl,a
      006E51 EF               [12] 3720 	mov	a,r7
      006E52 24 12            [12] 3721 	add	a,#(00326$-3-.)
      006E54 83               [24] 3722 	movc	a,@a+pc
      006E55 F5 83            [12] 3723 	mov	dph,a
      006E57 E4               [12] 3724 	clr	a
      006E58 73               [24] 3725 	jmp	@a+dptr
      006E59                       3726 00325$:
      006E59 75                    3727 	.db	00134$
      006E5A 75                    3728 	.db	00134$
      006E5B 75                    3729 	.db	00134$
      006E5C 75                    3730 	.db	00134$
      006E5D 95                    3731 	.db	00142$
      006E5E 75                    3732 	.db	00134$
      006E5F 75                    3733 	.db	00134$
      006E60 75                    3734 	.db	00134$
      006E61 75                    3735 	.db	00134$
      006E62 75                    3736 	.db	00134$
      006E63 75                    3737 	.db	00134$
      006E64 95                    3738 	.db	00142$
      006E65 95                    3739 	.db	00142$
      006E66 79                    3740 	.db	00135$
      006E67                       3741 00326$:
      006E67 6E                    3742 	.db	00134$>>8
      006E68 6E                    3743 	.db	00134$>>8
      006E69 6E                    3744 	.db	00134$>>8
      006E6A 6E                    3745 	.db	00134$>>8
      006E6B 6E                    3746 	.db	00142$>>8
      006E6C 6E                    3747 	.db	00134$>>8
      006E6D 6E                    3748 	.db	00134$>>8
      006E6E 6E                    3749 	.db	00134$>>8
      006E6F 6E                    3750 	.db	00134$>>8
      006E70 6E                    3751 	.db	00134$>>8
      006E71 6E                    3752 	.db	00134$>>8
      006E72 6E                    3753 	.db	00142$>>8
      006E73 6E                    3754 	.db	00142$>>8
      006E74 6E                    3755 	.db	00135$>>8
                                   3756 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006E75                       3757 00134$:
                                   3758 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006E75 75 82 01         [24] 3759 	mov	dpl, #0x01
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006E78 22               [24] 3761 	ret
      006E79                       3762 00135$:
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006E79 90 07 D7         [24] 3764 	mov	dptr,#(_raw_buffer + 0x0002)
      006E7C E0               [24] 3765 	movx	a,@dptr
      006E7D FF               [12] 3766 	mov	r7,a
      006E7E 60 0D            [24] 3767 	jz	00139$
      006E80 BF 01 02         [24] 3768 	cjne	r7,#0x01,00328$
      006E83 80 08            [24] 3769 	sjmp	00139$
      006E85                       3770 00328$:
      006E85 BF 03 02         [24] 3771 	cjne	r7,#0x03,00329$
      006E88 80 03            [24] 3772 	sjmp	00139$
      006E8A                       3773 00329$:
      006E8A BF 05 04         [24] 3774 	cjne	r7,#0x05,00140$
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006E8D                       3776 00139$:
                                   3777 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006E8D 75 82 01         [24] 3778 	mov	dpl, #0x01
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006E90 22               [24] 3780 	ret
      006E91                       3781 00140$:
      006E91 75 82 00         [24] 3782 	mov	dpl, #0x00
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006E94 22               [24] 3784 	ret
      006E95                       3785 00142$:
      006E95 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006E98 22               [24] 3788 	ret
      006E99                       3789 00144$:
      006E99 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006E9C 22               [24] 3793 	ret
                                   3794 ;------------------------------------------------------------
                                   3795 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3796 ;------------------------------------------------------------
                                   3797 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3798 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3799 ;------------------------------------------------------------
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3801 ;	-----------------------------------------
                                   3802 ;	 function ak820_usb_raw_send
                                   3803 ;	-----------------------------------------
      006E9D                       3804 _ak820_usb_raw_send:
      006E9D 12 48 05         [24] 3805 	lcall	_ak820_outline_0040
      006EA0 90 08 3D         [24] 3806 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006EA3 12 37 E1         [24] 3807 	lcall	_ak820_outline_0019
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006EA6 90 08 3C         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006EA9 E0               [24] 3810 	movx	a,@dptr
      006EAA FF               [12] 3811 	mov	r7,a
      006EAB BF 20 2B         [24] 3812 	cjne	r7,#0x20,00106$
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006EAE C0 07            [24] 3814 	push	ar7
      006EB0 12 43 1B         [24] 3815 	lcall	_ak820_nvm_flush
      006EB3 D0 07            [24] 3816 	pop	ar7
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006EB5 90 07 F5         [24] 3818 	mov	dptr,#_raw_reply_without_nvm
      006EB8 E0               [24] 3819 	movx	a,@dptr
      006EB9 70 07            [24] 3820 	jnz	00103$
      006EBB 12 43 0C         [24] 3821 	lcall	_ak820_nvm_ok
      006EBE E5 82            [12] 3822 	mov	a, dpl
      006EC0 60 17            [24] 3823 	jz	00106$
      006EC2                       3824 00103$:
      006EC2 90 08 3D         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006EC5 12 48 36         [24] 3826 	lcall	_ak820_outline_0099
      006EC8 90 08 32         [24] 3827 	mov	dptr,#_ak820_usb_send_PARM_2
      006ECB 12 48 7E         [24] 3828 	lcall	_ak820_outline_0169
      006ECE 90 08 34         [24] 3829 	mov	dptr,#_ak820_usb_send_PARM_3
      006ED1 EF               [12] 3830 	mov	a,r7
      006ED2 F0               [24] 3831 	movx	@dptr,a
      006ED3 75 82 03         [24] 3832 	mov	dpl, #0x03
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006ED6 02 6B B3         [24] 3834 	ljmp	_ak820_usb_send
      006ED9                       3835 00106$:
      006ED9 22               [24] 3836 	ret
                                   3837 ;------------------------------------------------------------
                                   3838 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3839 ;------------------------------------------------------------
                                   3840 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3841 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3842 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3843 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3844 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3845 ;------------------------------------------------------------
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3847 ;	-----------------------------------------
                                   3848 ;	 function ak820_usb_raw_task
                                   3849 ;	-----------------------------------------
      006EDA                       3850 _ak820_usb_raw_task:
                                   3851 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006EDA A2 AF            [12] 3852 	mov	c,_EA
      006EDC E4               [12] 3853 	clr	a
      006EDD 33               [12] 3854 	rlc	a
      006EDE FF               [12] 3855 	mov	r7,a
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3857 ;	assignBit
      006EDF C2 AF            [12] 3858 	clr	_EA
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006EE1 90 07 CD         [24] 3860 	mov	dptr,#_USB_EnumStatus
      006EE4 E0               [24] 3861 	movx	a,@dptr
      006EE5 60 0A            [24] 3862 	jz	00101$
      006EE7 90 07 D4         [24] 3863 	mov	dptr,#_raw_state
      006EEA E0               [24] 3864 	movx	a,@dptr
      006EEB FE               [12] 3865 	mov	r6,a
      006EEC BE 02 02         [24] 3866 	cjne	r6,#0x02,00270$
      006EEF 80 06            [24] 3867 	sjmp	00102$
      006EF1                       3868 00270$:
      006EF1                       3869 00101$:
                                   3870 ;	assignBit
      006EF1 EF               [12] 3871 	mov	a,r7
      006EF2 24 FF            [12] 3872 	add	a,#0xff
      006EF4 92 AF            [24] 3873 	mov	_EA,c
      006EF6 22               [24] 3874 	ret
      006EF7                       3875 00102$:
                                   3876 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006EF7 90 07 D4         [24] 3877 	mov	dptr,#_raw_state
      006EFA 74 03            [12] 3878 	mov	a,#0x03
      006EFC F0               [24] 3879 	movx	@dptr,a
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3881 ;	assignBit
      006EFD EF               [12] 3882 	mov	a,r7
      006EFE 24 FF            [12] 3883 	add	a,#0xff
      006F00 92 AF            [24] 3884 	mov	_EA,c
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006F02 90 07 D5         [24] 3886 	mov	dptr,#_raw_buffer
      006F05 E0               [24] 3887 	movx	a,@dptr
      006F06 FF               [12] 3888 	mov	r7,a
      006F07 E4               [12] 3889 	clr	a
      006F08 BF FD 01         [24] 3890 	cjne	r7,#0xfd,00271$
      006F0B 04               [12] 3891 	inc	a
      006F0C                       3892 00271$:
      006F0C FF               [12] 3893 	mov	r7,a
      006F0D 70 03            [24] 3894 	jnz	00273$
      006F0F 02 6F AF         [24] 3895 	ljmp	00118$
      006F12                       3896 00273$:
      006F12 90 07 D6         [24] 3897 	mov	dptr,#(_raw_buffer + 0x0001)
      006F15 E0               [24] 3898 	movx	a,@dptr
      006F16 60 03            [24] 3899 	jz	00274$
      006F18 02 6F AF         [24] 3900 	ljmp	00118$
      006F1B                       3901 00274$:
                                   3902 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006F1B 90 07 D7         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0002)
      006F1E E0               [24] 3904 	movx	a,@dptr
      006F1F FD               [12] 3905 	mov	r5,a
      006F20 7E 00            [12] 3906 	mov	r6,#0x00
      006F22 90 07 D8         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0003)
      006F25 E0               [24] 3908 	movx	a,@dptr
      006F26 7B 00            [12] 3909 	mov	r3,#0x00
      006F28 42 06            [12] 3910 	orl	ar6,a
      006F2A EB               [12] 3911 	mov	a,r3
      006F2B 42 05            [12] 3912 	orl	ar5,a
                                   3913 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006F2D 90 07 D9         [24] 3914 	mov	dptr,#(_raw_buffer + 0x0004)
      006F30 E0               [24] 3915 	movx	a,@dptr
      006F31 FC               [12] 3916 	mov	r4,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006F32 7B 05            [12] 3918 	mov	r3,#0x05
      006F34                       3919 00128$:
      006F34 EB               [12] 3920 	mov	a,r3
      006F35 12 70 B9         [24] 3921 	lcall	_ak820_outline_0110
      006F38 0B               [12] 3922 	inc	r3
      006F39 BB 20 00         [24] 3923 	cjne	r3,#0x20,00275$
      006F3C                       3924 00275$:
      006F3C 40 F6            [24] 3925 	jc	00128$
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006F3E EC               [12] 3927 	mov	a,r4
      006F3F 24 E4            [12] 3928 	add	a,#0xff - 0x1b
      006F41 40 1C            [24] 3929 	jc	00106$
                                   3930 ;	free result
      006F43 EC               [12] 3931 	mov	a,r4
      006F44 60 26            [24] 3932 	jz	00165$
      006F46 8C 03            [24] 3933 	mov	ar3,r4
      006F48 1B               [12] 3934 	dec	r3
      006F49 7A 00            [12] 3935 	mov	r2,#0x00
      006F4B 74 FF            [12] 3936 	mov	a,#0xff
      006F4D C3               [12] 3937 	clr	c
      006F4E 9B               [12] 3938 	subb	a,r3
      006F4F FB               [12] 3939 	mov	r3,a
      006F50 74 FF            [12] 3940 	mov	a,#0xff
      006F52 9A               [12] 3941 	subb	a,r2
      006F53 FA               [12] 3942 	mov	r2,a
      006F54 8E 00            [24] 3943 	mov	ar0,r6
      006F56 8D 01            [24] 3944 	mov	ar1,r5
      006F58 C3               [12] 3945 	clr	c
      006F59 EB               [12] 3946 	mov	a,r3
      006F5A 98               [12] 3947 	subb	a,r0
      006F5B EA               [12] 3948 	mov	a,r2
      006F5C 99               [12] 3949 	subb	a,r1
      006F5D 50 0D            [24] 3950 	jnc	00165$
                                   3951 ;	free result
      006F5F                       3952 00106$:
                                   3953 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006F5F 90 07 D6         [24] 3954 	mov	dptr,#(_raw_buffer + 0x0001)
      006F62 74 FF            [12] 3955 	mov	a,#0xff
      006F64 F0               [24] 3956 	movx	@dptr,a
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006F65 90 07 D9         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0004)
      006F68 E4               [12] 3959 	clr	a
      006F69 F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006F6A 80 3A            [24] 3962 	sjmp	00108$
      006F6C                       3963 00165$:
      006F6C 7B 00            [12] 3964 	mov	r3,#0x00
      006F6E                       3965 00131$:
      006F6E C3               [12] 3966 	clr	c
      006F6F EB               [12] 3967 	mov	a,r3
      006F70 9C               [12] 3968 	subb	a,r4
      006F71 50 33            [24] 3969 	jnc	00108$
      006F73 C0 04            [24] 3970 	push	ar4
      006F75 8B 02            [24] 3971 	mov	ar2,r3
      006F77 74 05            [12] 3972 	mov	a,#0x05
      006F79 2A               [12] 3973 	add	a, r2
      006F7A F9               [12] 3974 	mov	r1,a
      006F7B 33               [12] 3975 	rlc	a
      006F7C 95 E0            [12] 3976 	subb	a,acc
      006F7E FA               [12] 3977 	mov	r2,a
      006F7F E9               [12] 3978 	mov	a,r1
      006F80 24 D5            [12] 3979 	add	a, #_raw_buffer
      006F82 F9               [12] 3980 	mov	r1,a
      006F83 EA               [12] 3981 	mov	a,r2
      006F84 34 07            [12] 3982 	addc	a, #(_raw_buffer >> 8)
      006F86 FA               [12] 3983 	mov	r2,a
      006F87 8B 2F            [24] 3984 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006F89 75 30 00         [24] 3985 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006F8C 8E 00            [24] 3986 	mov	ar0,r6
      006F8E 8D 04            [24] 3987 	mov	ar4,r5
      006F90 E5 2F            [12] 3988 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006F92 28               [12] 3989 	add	a, r0
      006F93 F8               [12] 3990 	mov	r0,a
      006F94 E5 30            [12] 3991 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006F96 3C               [12] 3992 	addc	a, r4
      006F97 FC               [12] 3993 	mov	r4,a
      006F98 88 82            [24] 3994 	mov	dpl,r0
      006F9A 8C 83            [24] 3995 	mov	dph,r4
      006F9C E4               [12] 3996 	clr	a
      006F9D 93               [24] 3997 	movc	a,@a+dptr
      006F9E 12 70 C5         [24] 3998 	lcall	_ak820_outline_0145
      006FA1 0B               [12] 3999 	inc	r3
      006FA2 D0 04            [24] 4000 	pop	ar4
      006FA4 80 C8            [24] 4001 	sjmp	00131$
      006FA6                       4002 00108$:
                                   4003 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006FA6 12 70 A5         [24] 4004 	lcall	_ak820_outline_0047
      006FA9 12 6B B3         [24] 4005 	lcall	_ak820_usb_send
      006FAC 02 70 55         [24] 4006 	ljmp	00119$
      006FAF                       4007 00118$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006FAF EF               [12] 4009 	mov	a,r7
      006FB0 70 03            [24] 4010 	jnz	00281$
      006FB2 02 70 32         [24] 4011 	ljmp	00114$
      006FB5                       4012 00281$:
      006FB5 12 70 CB         [24] 4013 	lcall	_ak820_outline_0172
      006FB8 BF 01 02         [24] 4014 	cjne	r7,#0x01,00282$
      006FBB 80 03            [24] 4015 	sjmp	00283$
      006FBD                       4016 00282$:
      006FBD 02 70 32         [24] 4017 	ljmp	00114$
      006FC0                       4018 00283$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006FC0 7F 02            [12] 4020 	mov	r7,#0x02
      006FC2                       4021 00133$:
      006FC2 EF               [12] 4022 	mov	a,r7
      006FC3 12 70 B9         [24] 4023 	lcall	_ak820_outline_0110
      006FC6 0F               [12] 4024 	inc	r7
      006FC7 BF 20 00         [24] 4025 	cjne	r7,#0x20,00284$
      006FCA                       4026 00284$:
      006FCA 40 F6            [24] 4027 	jc	00133$
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006FCC 90 07 D7         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0002)
      006FCF 74 01            [12] 4030 	mov	a,#0x01
      006FD1 F0               [24] 4031 	movx	@dptr,a
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006FD2 90 07 D8         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0003)
      006FD5 74 A8            [12] 4034 	mov	a,#0xa8
      006FD7 F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006FD8 90 07 D9         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0004)
      006FDB 12 40 8A         [24] 4038 	lcall	_ak820_nvm_diagnostic
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006FDE 7F 00            [12] 4040 	mov	r7,#0x00
      006FE0                       4041 00135$:
      006FE0 8F 06            [24] 4042 	mov	ar6,r7
      006FE2 74 0B            [12] 4043 	mov	a,#0x0b
      006FE4 2E               [12] 4044 	add	a, r6
      006FE5 24 D5            [12] 4045 	add	a,#_raw_buffer
      006FE7 FE               [12] 4046 	mov	r6,a
      006FE8 E4               [12] 4047 	clr	a
      006FE9 34 07            [12] 4048 	addc	a, #(_raw_buffer >> 8)
      006FEB FD               [12] 4049 	mov	r5,a
      006FEC EF               [12] 4050 	mov	a,r7
      006FED 24 60            [12] 4051 	add	a, #_ak820_flash_diagnostic
      006FEF F5 82            [12] 4052 	mov	dpl,a
      006FF1 E4               [12] 4053 	clr	a
      006FF2 34 04            [12] 4054 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006FF4 F5 83            [12] 4055 	mov	dph,a
      006FF6 E0               [24] 4056 	movx	a,@dptr
      006FF7 8E 82            [24] 4057 	mov	dpl,r6
      006FF9 8D 83            [24] 4058 	mov	dph,r5
      006FFB F0               [24] 4059 	movx	@dptr,a
      006FFC 0F               [12] 4060 	inc	r7
      006FFD BF 06 00         [24] 4061 	cjne	r7,#0x06,00286$
      007000                       4062 00286$:
      007000 40 DE            [24] 4063 	jc	00135$
                                   4064 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      007002 90 0E A4         [24] 4065 	mov	dptr,#_vial_unlocked
      007005 E0               [24] 4066 	movx	a,@dptr
      007006 90 07 E6         [24] 4067 	mov	dptr,#(_raw_buffer + 0x0011)
      007009 F0               [24] 4068 	movx	@dptr,a
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      00700A 90 0E A5         [24] 4070 	mov	dptr,#_vial_unlock_in_progress
      00700D E0               [24] 4071 	movx	a,@dptr
      00700E 90 07 E7         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0012)
      007011 F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      007012 90 07 CD         [24] 4075 	mov	dptr,#_USB_EnumStatus
      007015 E0               [24] 4076 	movx	a,@dptr
      007016 90 07 E8         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0013)
      007019 F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      00701A 90 07 CE         [24] 4080 	mov	dptr,#_USB_SleepStatus
      00701D E0               [24] 4081 	movx	a,@dptr
      00701E 90 07 E9         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0014)
      007021 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      007022 90 07 D4         [24] 4085 	mov	dptr,#_raw_state
      007025 E0               [24] 4086 	movx	a,@dptr
      007026 90 07 EA         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0015)
      007029 F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      00702A 12 70 A5         [24] 4090 	lcall	_ak820_outline_0047
      00702D 12 6B B3         [24] 4091 	lcall	_ak820_usb_send
      007030 80 23            [24] 4092 	sjmp	00119$
      007032                       4093 00114$:
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      007032 12 6D C2         [24] 4095 	lcall	_raw_request_is_nonpersistent
      007035 E5 82            [12] 4096 	mov	a, dpl
      007037 90 07 F5         [24] 4097 	mov	dptr,#_raw_reply_without_nvm
      00703A F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      00703B 12 44 6E         [24] 4100 	lcall	_ak820_nvm_begin
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      00703E 90 0C BF         [24] 4102 	mov	dptr,#_raw_hid_receive_PARM_2
      007041 74 20            [12] 4103 	mov	a,#0x20
      007043 F0               [24] 4104 	movx	@dptr,a
      007044 90 07 D5         [24] 4105 	mov	dptr,#_raw_buffer
      007047 75 F0 00         [24] 4106 	mov	b, #0x00
      00704A 12 AB E6         [24] 4107 	lcall	_raw_hid_receive
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      00704D 12 44 83         [24] 4109 	lcall	_ak820_nvm_end
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      007050 90 07 F5         [24] 4111 	mov	dptr,#_raw_reply_without_nvm
      007053 E4               [12] 4112 	clr	a
      007054 F0               [24] 4113 	movx	@dptr,a
      007055                       4114 00119$:
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4116 ;	assignBit
      007055 A2 AF            [12] 4117 	mov	c,_EA
      007057 92 1E            [24] 4118 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4120 ;	assignBit
      007059 C2 AF            [12] 4121 	clr	_EA
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      00705B 12 70 D1         [24] 4123 	lcall	_ak820_outline_0174
      00705E BF 04 08         [24] 4124 	cjne	r7,#0x04,00126$
      007061 90 07 D4         [24] 4125 	mov	dptr,#_raw_state
      007064 74 05            [12] 4126 	mov	a,#0x05
      007066 F0               [24] 4127 	movx	@dptr,a
      007067 80 1B            [24] 4128 	sjmp	00127$
      007069                       4129 00126$:
                                   4130 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      007069 12 70 D1         [24] 4131 	lcall	_ak820_outline_0174
      00706C BF 03 02         [24] 4132 	cjne	r7,#0x03,00290$
      00706F 80 0E            [24] 4133 	sjmp	00121$
      007071                       4134 00290$:
      007071 12 70 D1         [24] 4135 	lcall	_ak820_outline_0174
      007074 BF 06 02         [24] 4136 	cjne	r7,#0x06,00291$
      007077 80 06            [24] 4137 	sjmp	00121$
      007079                       4138 00291$:
      007079 12 70 D1         [24] 4139 	lcall	_ak820_outline_0174
      00707C BF 07 05         [24] 4140 	cjne	r7,#0x07,00127$
      00707F                       4141 00121$:
      00707F 90 07 D4         [24] 4142 	mov	dptr,#_raw_state
      007082 E4               [12] 4143 	clr	a
      007083 F0               [24] 4144 	movx	@dptr,a
      007084                       4145 00127$:
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4147 ;	assignBit
      007084 A2 1E            [12] 4148 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      007086 92 AF            [24] 4149 	mov	_EA,c
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      007088 22               [24] 4151 	ret
                                   4152 ;------------------------------------------------------------
                                   4153 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4154 ;------------------------------------------------------------
                                   4155 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4156 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_take_keyboard_reset
                                   4161 ;	-----------------------------------------
      007089                       4162 _ak820_usb_take_keyboard_reset:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4164 ;	assignBit
      007089 A2 AF            [12] 4165 	mov	c,_EA
      00708B 92 1F            [24] 4166 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4168 ;	assignBit
      00708D C2 AF            [12] 4169 	clr	_EA
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      00708F 90 07 F6         [24] 4171 	mov	dptr,#_keyboard_reset
      007092 E0               [24] 4172 	movx	a,@dptr
      007093 FF               [12] 4173 	mov	r7,a
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      007094 E4               [12] 4175 	clr	a
      007095 F0               [24] 4176 	movx	@dptr,a
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4178 ;	assignBit
      007096 A2 1F            [12] 4179 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      007098 92 AF            [24] 4180 	mov	_EA,c
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      00709A EF               [12] 4182 	mov	a,r7
      00709B B4 01 00         [24] 4183 	cjne	a,#0x01,00103$
      00709E                       4184 00103$:
      00709E B3               [12] 4185 	cpl	c
      00709F 92 1F            [24] 4186 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      0070A1 12 38 67         [24] 4187 	lcall	_ak820_outline_0150
                                   4188 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      0070A4 22               [24] 4189 	ret
                                   4190 	.area CSEG    (CODE)
                                   4191 	.area CONST   (CODE)
                                   4192 	.area CONST   (CODE)
      00BF45                       4193 _shared_offsets:
      00BF45 00                    4194 	.db #0x00	; 0
      00BF46 00                    4195 	.db #0x00	; 0
      00BF47 28                    4196 	.db #0x28	; 40
      00BF48 28                    4197 	.db #0x28	; 40
      00BF49 2B                    4198 	.db #0x2b	; 43
      00BF4A 00                    4199 	.db #0x00	; 0
      00BF4B 08                    4200 	.db #0x08	; 8
                                   4201 	.area CSEG    (CODE)
                                   4202 	.area CONST   (CODE)
      00BF4C                       4203 _shared_lengths:
      00BF4C 00                    4204 	.db #0x00	; 0
      00BF4D 00                    4205 	.db #0x00	; 0
      00BF4E 00                    4206 	.db #0x00	; 0
      00BF4F 03                    4207 	.db #0x03	; 3
      00BF50 03                    4208 	.db #0x03	; 3
      00BF51 00                    4209 	.db #0x00	; 0
      00BF52 20                    4210 	.db #0x20	; 32
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00BF53                       4213 _interface_descriptors:
      00BF53 EE C4                 4214 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BF55 EE C5                 4215 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BF57 A1 C5                 4216 	.byte _RawReport, (_RawReport >> 8)
      00BF59 07 C6                 4217 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BF5B 33 C5                 4218 	.byte _SharedReport, (_SharedReport >> 8)
      00BF5D 20 C6                 4219 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4220 	.area CSEG    (CODE)
                                   4221 	.area XINIT   (CODE)
                                   4222 	.area CABS    (ABS,CODE)
                                   4223 
                                   4224 ; Experimental exact instruction outlining.
                                   4225 	.globl _ak820_outline_0019
                                   4226 	.globl _ak820_outline_0040
                                   4227 	.globl _ak820_outline_0047
                                   4228 	.globl _ak820_outline_0099
                                   4229 	.globl _ak820_outline_0110
                                   4230 	.globl _ak820_outline_0145
                                   4231 	.globl _ak820_outline_0150
                                   4232 	.globl _ak820_outline_0169
                                   4233 	.globl _ak820_outline_0172
                                   4234 	.globl _ak820_outline_0174
                                   4235 
                                   4236 	.area CSEG (CODE)
                                   4237 ; function ak820_outline_0047
      0070A5                       4238 _ak820_outline_0047:
      0070A5 90 08 32         [24] 4239 	mov	dptr,#_ak820_usb_send_PARM_2
      0070A8 74 D5            [12] 4240 	mov	a,#_raw_buffer
      0070AA F0               [24] 4241 	movx	@dptr,a
      0070AB 74 07            [12] 4242 	mov	a,#(_raw_buffer>>8)
      0070AD A3               [24] 4243 	inc	dptr
      0070AE F0               [24] 4244 	movx	@dptr,a
      0070AF 90 08 34         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_3
      0070B2 74 20            [12] 4246 	mov	a,#0x20
      0070B4 F0               [24] 4247 	movx	@dptr,a
      0070B5 75 82 03         [24] 4248 	mov	dpl,#0x03
      0070B8 22               [24] 4249 	ret
                                   4250 
                                   4251 	.area CSEG (CODE)
                                   4252 ; function ak820_outline_0110
      0070B9                       4253 _ak820_outline_0110:
      0070B9 24 D5            [12] 4254 	add	a,#_raw_buffer
      0070BB F5 82            [12] 4255 	mov	dpl,a
      0070BD E4               [12] 4256 	clr	a
      0070BE 34 07            [12] 4257 	addc	a,#(_raw_buffer>>8)
      0070C0 F5 83            [12] 4258 	mov	dph,a
      0070C2 E4               [12] 4259 	clr	a
      0070C3 F0               [24] 4260 	movx	@dptr,a
      0070C4 22               [24] 4261 	ret
                                   4262 
                                   4263 	.area CSEG (CODE)
                                   4264 ; function ak820_outline_0145
      0070C5                       4265 _ak820_outline_0145:
      0070C5 89 82            [24] 4266 	mov	dpl,r1
      0070C7 8A 83            [24] 4267 	mov	dph,r2
      0070C9 F0               [24] 4268 	movx	@dptr,a
      0070CA 22               [24] 4269 	ret
                                   4270 
                                   4271 	.area CSEG (CODE)
                                   4272 ; function ak820_outline_0172
      0070CB                       4273 _ak820_outline_0172:
      0070CB 90 07 D6         [24] 4274 	mov	dptr,#(_raw_buffer+0x0001)
      0070CE E0               [24] 4275 	movx	a,@dptr
      0070CF FF               [12] 4276 	mov	r7,a
      0070D0 22               [24] 4277 	ret
                                   4278 
                                   4279 	.area CSEG (CODE)
                                   4280 ; function ak820_outline_0174
      0070D1                       4281 _ak820_outline_0174:
      0070D1 90 07 D4         [24] 4282 	mov	dptr,#_raw_state
      0070D4 E0               [24] 4283 	movx	a,@dptr
      0070D5 FF               [12] 4284 	mov	r7,a
      0070D6 22               [24] 4285 	ret
