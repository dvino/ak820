                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000017                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000017                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000012                        595 _suspended:
      000012                        596 	.ds 1
      000013                        597 _dirty:
      000013                        598 	.ds 1
      000014                        599 _rendering:
      000014                        600 	.ds 1
      000015                        601 _rgb_matrix_task_sloc0_1_0:
      000015                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      00070C                        611 _rgb_matrix_config::
      00070C                        612 	.ds 8
      000714                        613 _changed_at:
      000714                        614 	.ds 2
      000716                        615 _frame_at:
      000716                        616 	.ds 2
      000718                        617 _phase:
      000718                        618 	.ds 2
      00071A                        619 _led_index:
      00071A                        620 	.ds 1
      00071B                        621 _frame_mode:
      00071B                        622 	.ds 1
      00071C                        623 _frame_hue:
      00071C                        624 	.ds 1
      00071D                        625 _frame_sat:
      00071D                        626 	.ds 1
      00071E                        627 _frame_val:
      00071E                        628 	.ds 1
      00071F                        629 _frame_flags:
      00071F                        630 	.ds 1
      000720                        631 _frame_phase:
      000720                        632 	.ds 1
      000721                        633 _reactive_age:
      000721                        634 	.ds 82
      000773                        635 _reactive_at:
      000773                        636 	.ds 2
      000775                        637 _add_sat_PARM_2:
      000775                        638 	.ds 1
      000776                        639 _add_sat_x_10000_266:
      000776                        640 	.ds 1
      000777                        641 _sub_sat_PARM_2:
      000777                        642 	.ds 1
      000778                        643 _sub_sat_x_10000_268:
      000778                        644 	.ds 1
      000779                        645 _rgb_matrix_set_color_PARM_2:
      000779                        646 	.ds 1
      00077A                        647 _rgb_matrix_set_color_PARM_3:
      00077A                        648 	.ds 1
      00077B                        649 _rgb_matrix_set_color_PARM_4:
      00077B                        650 	.ds 1
      00077C                        651 _rgb_matrix_set_color_index_10000_284:
      00077C                        652 	.ds 2
      00077E                        653 _rgb_matrix_set_color_all_PARM_2:
      00077E                        654 	.ds 1
      00077F                        655 _rgb_matrix_set_color_all_PARM_3:
      00077F                        656 	.ds 1
      000780                        657 _rgb_matrix_set_color_all_r_10000_287:
      000780                        658 	.ds 1
      000781                        659 _sine8_theta_10000_289:
      000781                        660 	.ds 1
      000782                        661 _sine8_offset_10000_290:
      000782                        662 	.ds 1
      000783                        663 _sine8_fraction_10000_290:
      000783                        664 	.ds 1
      000784                        665 _breathing_cie_value_10000_293:
      000784                        666 	.ds 1
      000785                        667 _rgb_matrix_task_end_10000_298:
      000785                        668 	.ds 1
      000786                        669 _rgb_matrix_task_hsv_10000_298:
      000786                        670 	.ds 3
      000789                        671 _rgb_matrix_task_rgb_10000_298:
      000789                        672 	.ds 3
      00078C                        673 _process_rgb_matrix_PARM_2:
      00078C                        674 	.ds 1
      00078D                        675 _process_rgb_matrix_PARM_3:
      00078D                        676 	.ds 1
      00078E                        677 _process_rgb_matrix_row_10000_319:
      00078E                        678 	.ds 1
      00078F                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      00078F                        680 	.ds 1
      000790                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      000790                        682 	.ds 1
      000791                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000791                        684 	.ds 1
      000792                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000792                        686 	.ds 1
      000793                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      000793                        688 	.ds 2
      000795                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      000795                        690 	.ds 1
      000796                        691 _rgb_matrix_mode_mode_10000_411:
      000796                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      0053FF                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      0053FF 12 5B D2         [24]  746 	lcall	_ak820_outline_0186
      005402 74 52            [12]  747 	mov	a,#0x52
      005404 12 38 57         [24]  748 	lcall	_ak820_outline_0132
      005407 90 07 21         [24]  749 	mov	dptr,#_reactive_age
      00540A F5 F0            [12]  750 	mov	b,a
      00540C 12 BE 50         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      00540F 12 4D F3         [24]  753 	lcall	_timer_read
      005412 12 38 51         [24]  754 	lcall	_ak820_outline_0127
      005415 90 07 73         [24]  755 	mov	dptr,#_reactive_at
      005418 12 5B BE         [24]  756 	lcall	_ak820_outline_0177
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      00541B 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      00541C                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      00541C 90 07 73         [24]  772 	mov	dptr,#_reactive_at
      00541F 12 37 BA         [24]  773 	lcall	_ak820_outline_0006
      005422 12 4D F6         [24]  774 	lcall	_timer_elapsed
      005425 AE 82            [24]  775 	mov	r6, dpl
      005427 E5 83            [12]  776 	mov	a,dph
      005429 C4               [12]  777 	swap	a
      00542A CE               [12]  778 	xch	a,r6
      00542B C4               [12]  779 	swap	a
      00542C 54 0F            [12]  780 	anl	a,#0x0f
      00542E 6E               [12]  781 	xrl	a,r6
      00542F CE               [12]  782 	xch	a,r6
      005430 54 0F            [12]  783 	anl	a,#0x0f
      005432 CE               [12]  784 	xch	a,r6
      005433 6E               [12]  785 	xrl	a,r6
      005434 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      005435 FF               [12]  788 	mov	r7,a
      005436 4E               [12]  789 	orl	a,r6
      005437 70 01            [24]  790 	jnz	00102$
      005439 22               [24]  791 	ret
      00543A                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      00543A 8E 04            [24]  794 	mov	ar4,r6
      00543C EF               [12]  795 	mov	a,r7
      00543D C4               [12]  796 	swap	a
      00543E 54 F0            [12]  797 	anl	a,#0xf0
      005440 CC               [12]  798 	xch	a,r4
      005441 C4               [12]  799 	swap	a
      005442 CC               [12]  800 	xch	a,r4
      005443 6C               [12]  801 	xrl	a,r4
      005444 CC               [12]  802 	xch	a,r4
      005445 54 F0            [12]  803 	anl	a,#0xf0
      005447 CC               [12]  804 	xch	a,r4
      005448 6C               [12]  805 	xrl	a,r4
      005449 FD               [12]  806 	mov	r5,a
      00544A 90 07 73         [24]  807 	mov	dptr,#_reactive_at
      00544D 12 48 4D         [24]  808 	lcall	_ak820_outline_0129
      005450 90 07 73         [24]  809 	mov	dptr,#_reactive_at
      005453 EC               [12]  810 	mov	a,r4
      005454 2A               [12]  811 	add	a, r2
      005455 F0               [24]  812 	movx	@dptr,a
      005456 ED               [12]  813 	mov	a,r5
      005457 3B               [12]  814 	addc	a, r3
      005458 A3               [24]  815 	inc	dptr
      005459 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      00545A 8E 04            [24]  818 	mov	ar4,r6
      00545C 8F 05            [24]  819 	mov	ar5,r7
      00545E C3               [12]  820 	clr	c
      00545F 74 FF            [12]  821 	mov	a,#0xff
      005461 9C               [12]  822 	subb	a,r4
      005462 E4               [12]  823 	clr	a
      005463 9D               [12]  824 	subb	a,r5
      005464 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      005466 7D FF            [12]  827 	mov	r5,#0xff
      005468 80 02            [24]  828 	sjmp	00109$
      00546A                        829 00108$:
      00546A 8E 05            [24]  830 	mov	ar5,r6
      00546C                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00546C 7F 00            [12]  833 	mov	r7,#0x00
      00546E                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      00546E EF               [12]  836 	mov	a,r7
      00546F 24 21            [12]  837 	add	a, #_reactive_age
      005471 FC               [12]  838 	mov	r4,a
      005472 E4               [12]  839 	clr	a
      005473 34 07            [12]  840 	addc	a, #(_reactive_age >> 8)
      005475 FE               [12]  841 	mov	r6,a
      005476 8C 82            [24]  842 	mov	dpl,r4
      005478 8E 83            [24]  843 	mov	dph,r6
      00547A E0               [24]  844 	movx	a,@dptr
      00547B FB               [12]  845 	mov	r3,a
      00547C C3               [12]  846 	clr	c
      00547D ED               [12]  847 	mov	a,r5
      00547E 9B               [12]  848 	subb	a,r3
      00547F 40 04            [24]  849 	jc	00110$
      005481 7B 00            [12]  850 	mov	r3,#0x00
      005483 80 08            [24]  851 	sjmp	00111$
      005485                        852 00110$:
      005485 8C 82            [24]  853 	mov	dpl,r4
      005487 8E 83            [24]  854 	mov	dph,r6
      005489 E0               [24]  855 	movx	a,@dptr
      00548A C3               [12]  856 	clr	c
      00548B 9D               [12]  857 	subb	a,r5
      00548C FB               [12]  858 	mov	r3,a
      00548D                        859 00111$:
      00548D 8C 82            [24]  860 	mov	dpl,r4
      00548F 8E 83            [24]  861 	mov	dph,r6
      005491 EB               [12]  862 	mov	a,r3
      005492 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005493 0F               [12]  865 	inc	r7
      005494 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      005497                        867 00144$:
      005497 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      005499 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      00549A                        881 _add_sat:
      00549A E5 82            [12]  882 	mov	a,dpl
      00549C 90 07 76         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      00549F F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      0054A0 90 07 75         [24]  886 	mov	dptr,#_add_sat_PARM_2
      0054A3 E0               [24]  887 	movx	a,@dptr
      0054A4 FF               [12]  888 	mov	r7,a
      0054A5 FE               [12]  889 	mov	r6,a
      0054A6 74 FF            [12]  890 	mov	a,#0xff
      0054A8 C3               [12]  891 	clr	c
      0054A9 9E               [12]  892 	subb	a,r6
      0054AA FE               [12]  893 	mov	r6,a
      0054AB 90 07 76         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      0054AE E0               [24]  895 	movx	a,@dptr
      0054AF FD               [12]  896 	mov	r5,a
      0054B0 C3               [12]  897 	clr	c
      0054B1 EE               [12]  898 	mov	a,r6
      0054B2 9D               [12]  899 	subb	a,r5
      0054B3 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      0054B5 7E FF            [12]  902 	mov	r6,#0xff
      0054B7 80 03            [24]  903 	sjmp	00104$
      0054B9                        904 00103$:
      0054B9 EF               [12]  905 	mov	a,r7
      0054BA 2D               [12]  906 	add	a, r5
      0054BB FE               [12]  907 	mov	r6,a
      0054BC                        908 00104$:
      0054BC 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      0054BE 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      0054BF                        922 _sub_sat:
      0054BF E5 82            [12]  923 	mov	a,dpl
      0054C1 90 07 78         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      0054C4 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      0054C5 E0               [24]  927 	movx	a,@dptr
      0054C6 FF               [12]  928 	mov	r7,a
      0054C7 90 07 77         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      0054CA E0               [24]  930 	movx	a,@dptr
      0054CB FE               [12]  931 	mov	r6,a
      0054CC C3               [12]  932 	clr	c
      0054CD EF               [12]  933 	mov	a,r7
      0054CE 9E               [12]  934 	subb	a,r6
      0054CF 50 04            [24]  935 	jnc	00103$
      0054D1 7D 00            [12]  936 	mov	r5,#0x00
      0054D3 80 04            [24]  937 	sjmp	00104$
      0054D5                        938 00103$:
      0054D5 EF               [12]  939 	mov	a,r7
      0054D6 C3               [12]  940 	clr	c
      0054D7 9E               [12]  941 	subb	a,r6
      0054D8 FD               [12]  942 	mov	r5,a
      0054D9                        943 00104$:
      0054D9 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      0054DB 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      0054DC                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      0054DC D2 13            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      0054DE 12 4D F3         [24]  959 	lcall	_timer_read
      0054E1 12 38 51         [24]  960 	lcall	_ak820_outline_0127
      0054E4 90 07 14         [24]  961 	mov	dptr,#_changed_at
      0054E7 12 5B BE         [24]  962 	lcall	_ak820_outline_0177
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      0054EA 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      0054EB                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      0054EB 90 07 13         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      0054EE E4               [12]  978 	clr	a
      0054EF F0               [24]  979 	movx	@dptr,a
      0054F0 90 07 12         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      0054F3 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      0054F4 90 05 F6         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0054F7 12 5B A1         [24]  984 	lcall	_ak820_outline_0087
      0054FA 90 05 F9         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0054FD 12 5B 97         [24]  986 	lcall	_ak820_outline_0075
      005500 12 47 10         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      005503 C2 13            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      005505 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      005506                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      005506 12 5B D2         [24] 1002 	lcall	_ak820_outline_0186
      005509 12 5B 97         [24] 1003 	lcall	_ak820_outline_0075
      00550C F5 F0            [12] 1004 	mov	b,a
      00550E 12 BE 50         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      005511 12 5B B1         [24] 1007 	lcall	_ak820_outline_0120
      005514 44 01            [12] 1008 	orl	a,#0x01
      005516 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      005517 12 5B 90         [24] 1011 	lcall	_ak820_outline_0070
      00551A 44 04            [12] 1012 	orl	a,#0x04
      00551C F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      00551D 90 07 0D         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005520 E4               [12] 1016 	clr	a
      005521 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      005522 90 07 0E         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005525 14               [12] 1020 	dec	a
      005526 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005527 90 07 0F         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00552A 74 50            [12] 1024 	mov	a,#0x50
      00552C F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      00552D 90 07 10         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005530 74 60            [12] 1028 	mov	a,#0x60
      005532 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      005533 90 07 11         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005536 74 FF            [12] 1032 	mov	a,#0xff
      005538 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      005539 81 EB            [12] 1036 	ajmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      00553B                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      00553B 90 05 E6         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00553E 12 5B A1         [24] 1047 	lcall	_ak820_outline_0087
      005541 90 05 E9         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005544 12 5B 97         [24] 1049 	lcall	_ak820_outline_0075
      005547 12 45 A1         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      00554A 12 5B B1         [24] 1052 	lcall	_ak820_outline_0120
      00554D 60 11            [24] 1053 	jz	00101$
      00554F 12 5B 71         [24] 1054 	lcall	_ak820_outline_0020
      005552 C3               [12] 1055 	clr	c
      005553 64 80            [12] 1056 	xrl	a,#0x80
      005555 94 87            [12] 1057 	subb	a,#0x87
      005557 50 07            [24] 1058 	jnc	00101$
      005559 12 5B 90         [24] 1059 	lcall	_ak820_outline_0070
      00555C 24 FE            [12] 1060 	add	a,#0xff - 0x01
      00555E 50 02            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      005560                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      005560 B1 06            [24] 1065 	acall	_eeconfig_update_rgb_matrix_default
      005562                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      005562 90 07 0F         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005565 E0               [24] 1069 	movx	a,@dptr
      005566 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      005568 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00556A 90 07 0F         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00556D 74 A0            [12] 1075 	mov	a,#0xa0
      00556F F0               [24] 1076 	movx	@dptr,a
      005570                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      005570 C2 13            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      005572 C2 14            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      005574 61 FF            [12] 1086 	ajmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      005576                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      005576 B1 3B            [24] 1096 	acall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      005578 12 4D F3         [24] 1098 	lcall	_timer_read
      00557B 12 48 53         [24] 1099 	lcall	_ak820_outline_0140
      00557E EE               [12] 1100 	mov	a,r6
      00557F 24 F0            [12] 1101 	add	a,#0xf0
      005581 FE               [12] 1102 	mov	r6,a
      005582 EF               [12] 1103 	mov	a,r7
      005583 34 FF            [12] 1104 	addc	a,#0xff
      005585 FF               [12] 1105 	mov	r7,a
      005586 90 07 16         [24] 1106 	mov	dptr,#_frame_at
      005589 12 4D 63         [24] 1107 	lcall	_ak820_outline_0064
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      00558C 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      00558D                       1122 _rgb_matrix_set_color:
      00558D 12 38 42         [24] 1123 	lcall	_ak820_outline_0108
      005590 90 07 7C         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      005593 12 38 47         [24] 1125 	lcall	_ak820_outline_0109
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      005596 90 07 7C         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      005599 12 37 F9         [24] 1128 	lcall	_ak820_outline_0056
      00559C 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      00559F C3               [12] 1130 	clr	c
      0055A0 EE               [12] 1131 	mov	a,r6
      0055A1 94 52            [12] 1132 	subb	a,#0x52
      0055A3 EF               [12] 1133 	mov	a,r7
      0055A4 64 80            [12] 1134 	xrl	a,#0x80
      0055A6 94 80            [12] 1135 	subb	a,#0x80
      0055A8 50 23            [24] 1136 	jnc	00104$
      0055AA 90 07 79         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0055AD E0               [24] 1138 	movx	a,@dptr
      0055AE FF               [12] 1139 	mov	r7,a
      0055AF 90 07 7A         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0055B2 E0               [24] 1141 	movx	a,@dptr
      0055B3 FD               [12] 1142 	mov	r5,a
      0055B4 90 07 7B         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0055B7 E0               [24] 1144 	movx	a,@dptr
      0055B8 FC               [12] 1145 	mov	r4,a
      0055B9 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      0055BC EF               [12] 1147 	mov	a,r7
      0055BD F0               [24] 1148 	movx	@dptr,a
      0055BE 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      0055C1 ED               [12] 1150 	mov	a,r5
      0055C2 F0               [24] 1151 	movx	@dptr,a
      0055C3 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      0055C6 EC               [12] 1153 	mov	a,r4
      0055C7 F0               [24] 1154 	movx	@dptr,a
      0055C8 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      0055CA 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      0055CD                       1158 00104$:
      0055CD 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      0055CE                       1171 _rgb_matrix_set_color_all:
      0055CE E5 82            [12] 1172 	mov	a,dpl
      0055D0 90 07 80         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      0055D3 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      0055D4 E0               [24] 1176 	movx	a,@dptr
      0055D5 FF               [12] 1177 	mov	r7,a
      0055D6 90 07 7E         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0055D9 E0               [24] 1179 	movx	a,@dptr
      0055DA FE               [12] 1180 	mov	r6,a
      0055DB 90 07 7F         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0055DE E0               [24] 1182 	movx	a,@dptr
      0055DF FD               [12] 1183 	mov	r5,a
      0055E0 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      0055E3 EE               [12] 1185 	mov	a,r6
      0055E4 F0               [24] 1186 	movx	@dptr,a
      0055E5 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      0055E8 ED               [12] 1188 	mov	a,r5
      0055E9 F0               [24] 1189 	movx	@dptr,a
      0055EA 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      0055EC 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      0055EF                       1206 _sine8:
      0055EF E5 82            [12] 1207 	mov	a,dpl
      0055F1 90 07 81         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      0055F4 F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      0055F5 E0               [24] 1211 	movx	a,@dptr
      0055F6 FF               [12] 1212 	mov	r7,a
      0055F7 90 07 82         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      0055FA F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      0055FB EF               [12] 1216 	mov	a,r7
      0055FC 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      0055FF 90 07 82         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      005602 74 FF            [12] 1219 	mov	a,#0xff
      005604 C3               [12] 1220 	clr	c
      005605 9F               [12] 1221 	subb	a,r7
      005606 F0               [24] 1222 	movx	@dptr,a
      005607                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      005607 90 07 82         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      00560A E0               [24] 1226 	movx	a,@dptr
      00560B 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      00560E F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      00560F 90 07 82         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      005612 E0               [24] 1231 	movx	a,@dptr
      005613 54 0F            [12] 1232 	anl	a,#0x0f
      005615 FF               [12] 1233 	mov	r7,a
      005616 90 07 83         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      005619 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      00561A 90 07 81         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      00561D E0               [24] 1238 	movx	a,@dptr
      00561E 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      005621 90 07 83         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      005624 EF               [12] 1241 	mov	a,r7
      005625 04               [12] 1242 	inc	a
      005626 F0               [24] 1243 	movx	@dptr,a
      005627                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      005627 90 07 82         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      00562A E0               [24] 1247 	movx	a,@dptr
      00562B C4               [12] 1248 	swap	a
      00562C 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      00562E 25 E0            [12] 1251 	add	a,acc
      005630 FF               [12] 1252 	mov	r7,a
      005631 90 BF 35         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      005634 93               [24] 1254 	movc	a,@a+dptr
      005635 FE               [12] 1255 	mov	r6,a
      005636 0F               [12] 1256 	inc	r7
      005637 EF               [12] 1257 	mov	a,r7
      005638 90 BF 35         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      00563B 93               [24] 1259 	movc	a,@a+dptr
      00563C FF               [12] 1260 	mov	r7,a
      00563D 90 07 83         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      005640 E0               [24] 1262 	movx	a,@dptr
      005641 8F F0            [24] 1263 	mov	b,r7
      005643 A4               [48] 1264 	mul	ab
      005644 FF               [12] 1265 	mov	r7,a
      005645 E5 F0            [12] 1266 	mov	a,b
      005647 C4               [12] 1267 	swap	a
      005648 CF               [12] 1268 	xch	a,r7
      005649 C4               [12] 1269 	swap	a
      00564A 54 0F            [12] 1270 	anl	a,#0x0f
      00564C 6F               [12] 1271 	xrl	a,r7
      00564D CF               [12] 1272 	xch	a,r7
      00564E 54 0F            [12] 1273 	anl	a,#0x0f
      005650 CF               [12] 1274 	xch	a,r7
      005651 6F               [12] 1275 	xrl	a,r7
      005652 CF               [12] 1276 	xch	a,r7
      005653 EF               [12] 1277 	mov	a,r7
      005654 2E               [12] 1278 	add	a, r6
      005655 FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      005656 90 07 81         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      005659 E0               [24] 1282 	movx	a,@dptr
      00565A 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      00565D 8F 06            [24] 1284 	mov	ar6,r7
      00565F 74 80            [12] 1285 	mov	a,#0x80
      005661 C3               [12] 1286 	clr	c
      005662 9E               [12] 1287 	subb	a,r6
      005663 FE               [12] 1288 	mov	r6,a
      005664 80 04            [24] 1289 	sjmp	00108$
      005666                       1290 00107$:
      005666 74 80            [12] 1291 	mov	a,#0x80
      005668 2F               [12] 1292 	add	a, r7
      005669 FE               [12] 1293 	mov	r6,a
      00566A                       1294 00108$:
      00566A 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      00566C 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      00566D                       1312 _breathing_cie:
      00566D E5 82            [12] 1313 	mov	a,dpl
      00566F 90 07 84         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      005672 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      005673 E0               [24] 1317 	movx	a,@dptr
      005674 FF               [12] 1318 	mov	r7,a
      005675 C4               [12] 1319 	swap	a
      005676 23               [12] 1320 	rl	a
      005677 54 1F            [12] 1321 	anl	a,#0x1f
                                   1322 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      005679 FE               [12] 1323 	mov	r6,a
      00567A 90 C2 41         [24] 1324 	mov	dptr,#_CIE1931_CURVE
      00567D 93               [24] 1325 	movc	a,@a+dptr
      00567E FD               [12] 1326 	mov	r5,a
                                   1327 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      00567F BE 1F 03         [24] 1328 	cjne	r6,#0x1f,00102$
      005682 8D 82            [24] 1329 	mov	dpl, r5
      005684 22               [24] 1330 	ret
      005685                       1331 00102$:
                                   1332 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      005685 EE               [12] 1333 	mov	a,r6
      005686 04               [12] 1334 	inc	a
      005687 90 C2 41         [24] 1335 	mov	dptr,#_CIE1931_CURVE
      00568A 93               [24] 1336 	movc	a,@a+dptr
      00568B C3               [12] 1337 	clr	c
      00568C 9D               [12] 1338 	subb	a,r5
      00568D FE               [12] 1339 	mov	r6,a
                                   1340 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      00568E 74 07            [12] 1341 	mov	a,#0x07
      005690 5F               [12] 1342 	anl	a,r7
                                   1343 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      005691 F5 F0            [12] 1344 	mov	b,a
      005693 EE               [12] 1345 	mov	a,r6
      005694 A4               [48] 1346 	mul	ab
                                   1347 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      005695 C4               [12] 1348 	swap	a
      005696 23               [12] 1349 	rl	a
      005697 54 1F            [12] 1350 	anl	a,#0x1f
      005699 2D               [12] 1351 	add	a, r5
                                   1352 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      00569A F5 82            [12] 1353 	mov	dpl,a
      00569C 22               [24] 1354 	ret
                                   1355 ;------------------------------------------------------------
                                   1356 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1357 ;------------------------------------------------------------
                                   1358 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1359 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1360 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1361 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1362 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1363 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1364 ;------------------------------------------------------------
                                   1365 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1366 ;	-----------------------------------------
                                   1367 ;	 function rgb_matrix_task
                                   1368 ;	-----------------------------------------
      00569D                       1369 _rgb_matrix_task:
                                   1370 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      00569D 91 1C            [12] 1371 	acall	_age_reactive
                                   1372 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      00569F 30 13 17         [24] 1373 	jnb	_dirty,00102$
      0056A2 90 07 14         [24] 1374 	mov	dptr,#_changed_at
      0056A5 12 37 BA         [24] 1375 	lcall	_ak820_outline_0006
      0056A8 12 4D F6         [24] 1376 	lcall	_timer_elapsed
      0056AB 12 48 53         [24] 1377 	lcall	_ak820_outline_0140
      0056AE C3               [12] 1378 	clr	c
      0056AF EE               [12] 1379 	mov	a,r6
      0056B0 94 E8            [12] 1380 	subb	a,#0xe8
      0056B2 EF               [12] 1381 	mov	a,r7
      0056B3 94 03            [12] 1382 	subb	a,#0x03
      0056B5 40 02            [24] 1383 	jc	00102$
      0056B7 91 EB            [12] 1384 	acall	_eeconfig_update_rgb_matrix
      0056B9                       1385 00102$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      0056B9 30 14 02         [24] 1387 	jnb	_rendering,00254$
      0056BC E1 71            [12] 1388 	ajmp	00109$
      0056BE                       1389 00254$:
                                   1390 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      0056BE 90 07 16         [24] 1391 	mov	dptr,#_frame_at
      0056C1 12 37 BA         [24] 1392 	lcall	_ak820_outline_0006
      0056C4 12 4D F6         [24] 1393 	lcall	_timer_elapsed
      0056C7 12 48 53         [24] 1394 	lcall	_ak820_outline_0140
      0056CA C3               [12] 1395 	clr	c
      0056CB EE               [12] 1396 	mov	a,r6
      0056CC 94 10            [12] 1397 	subb	a,#0x10
      0056CE EF               [12] 1398 	mov	a,r7
      0056CF 94 00            [12] 1399 	subb	a,#0x00
      0056D1 50 01            [24] 1400 	jnc	00105$
      0056D3 22               [24] 1401 	ret
      0056D4                       1402 00105$:
                                   1403 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      0056D4 12 4D F3         [24] 1404 	lcall	_timer_read
      0056D7 12 38 51         [24] 1405 	lcall	_ak820_outline_0127
      0056DA 90 07 16         [24] 1406 	mov	dptr,#_frame_at
      0056DD 12 5B BE         [24] 1407 	lcall	_ak820_outline_0177
                                   1408 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      0056E0 90 07 10         [24] 1409 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0056E3 E0               [24] 1410 	movx	a,@dptr
      0056E4 FF               [12] 1411 	mov	r7,a
      0056E5 7E 00            [12] 1412 	mov	r6,#0x00
      0056E7 74 20            [12] 1413 	mov	a,#0x20
      0056E9 2F               [12] 1414 	add	a, r7
      0056EA FF               [12] 1415 	mov	r7,a
      0056EB E4               [12] 1416 	clr	a
      0056EC 3E               [12] 1417 	addc	a, r6
      0056ED FE               [12] 1418 	mov	r6,a
      0056EE 90 07 18         [24] 1419 	mov	dptr,#_phase
      0056F1 12 38 18         [24] 1420 	lcall	_ak820_outline_0065
      0056F4 EF               [12] 1421 	mov	a,r7
      0056F5 2C               [12] 1422 	add	a, r4
      0056F6 FF               [12] 1423 	mov	r7,a
      0056F7 EE               [12] 1424 	mov	a,r6
      0056F8 3D               [12] 1425 	addc	a, r5
      0056F9 FE               [12] 1426 	mov	r6,a
      0056FA 90 07 18         [24] 1427 	mov	dptr,#_phase
      0056FD EF               [12] 1428 	mov	a,r7
      0056FE F0               [24] 1429 	movx	@dptr,a
      0056FF EE               [12] 1430 	mov	a,r6
      005700 A3               [24] 1431 	inc	dptr
      005701 F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      005702 90 07 18         [24] 1434 	mov	dptr,#_phase
      005705 E0               [24] 1435 	movx	a,@dptr
      005706 A3               [24] 1436 	inc	dptr
      005707 E0               [24] 1437 	movx	a,@dptr
      005708 FF               [12] 1438 	mov	r7,a
      005709 90 07 20         [24] 1439 	mov	dptr,#_frame_phase
      00570C F0               [24] 1440 	movx	@dptr,a
                                   1441 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      00570D 20 12 05         [24] 1442 	jb	_suspended,00135$
      005710 12 5B 90         [24] 1443 	lcall	_ak820_outline_0070
      005713 70 04            [24] 1444 	jnz	00132$
      005715                       1445 00135$:
      005715 7E 00            [12] 1446 	mov	r6,#0x00
      005717 80 04            [24] 1447 	sjmp	00133$
      005719                       1448 00132$:
      005719 12 5B 71         [24] 1449 	lcall	_ak820_outline_0020
      00571C FE               [12] 1450 	mov	r6,a
      00571D                       1451 00133$:
      00571D 90 07 1B         [24] 1452 	mov	dptr,#_frame_mode
      005720 EE               [12] 1453 	mov	a,r6
      005721 F0               [24] 1454 	movx	@dptr,a
                                   1455 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      005722 90 07 0D         [24] 1456 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005725 E0               [24] 1457 	movx	a,@dptr
      005726 90 07 1C         [24] 1458 	mov	dptr,#_frame_hue
      005729 F0               [24] 1459 	movx	@dptr,a
                                   1460 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      00572A 90 07 0E         [24] 1461 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00572D E0               [24] 1462 	movx	a,@dptr
      00572E 90 07 1D         [24] 1463 	mov	dptr,#_frame_sat
      005731 F0               [24] 1464 	movx	@dptr,a
                                   1465 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      005732 90 07 0F         [24] 1466 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005735 E0               [24] 1467 	movx	a,@dptr
      005736 FD               [12] 1468 	mov	r5,a
      005737 90 07 1E         [24] 1469 	mov	dptr,#_frame_val
      00573A F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      00573B 90 07 11         [24] 1472 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      00573E E0               [24] 1473 	movx	a,@dptr
      00573F 90 07 1F         [24] 1474 	mov	dptr,#_frame_flags
      005742 F0               [24] 1475 	movx	@dptr,a
                                   1476 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      005743 BE 02 24         [24] 1477 	cjne	r6,#0x02,00107$
                                   1478 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      005746 EF               [12] 1479 	mov	a,r7
      005747 24 C0            [12] 1480 	add	a,#0xc0
      005749 F5 82            [12] 1481 	mov	dpl,a
      00574B C0 05            [24] 1482 	push	ar5
      00574D B1 EF            [24] 1483 	acall	_sine8
      00574F AF 82            [24] 1484 	mov	r7, dpl
      005751 D0 05            [24] 1485 	pop	ar5
      005753 8D F0            [24] 1486 	mov	b,r5
      005755 EF               [12] 1487 	mov	a,r7
      005756 A4               [48] 1488 	mul	ab
      005757 AE F0            [24] 1489 	mov	r6,b
      005759 8E 05            [24] 1490 	mov	ar5,r6
      00575B 90 07 1E         [24] 1491 	mov	dptr,#_frame_val
      00575E ED               [12] 1492 	mov	a,r5
      00575F F0               [24] 1493 	movx	@dptr,a
                                   1494 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      005760 8D 82            [24] 1495 	mov	dpl, r5
      005762 D1 6D            [24] 1496 	acall	_breathing_cie
      005764 E5 82            [12] 1497 	mov	a, dpl
      005766 90 07 1E         [24] 1498 	mov	dptr,#_frame_val
      005769 F0               [24] 1499 	movx	@dptr,a
      00576A                       1500 00107$:
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      00576A 90 07 1A         [24] 1502 	mov	dptr,#_led_index
      00576D E4               [12] 1503 	clr	a
      00576E F0               [24] 1504 	movx	@dptr,a
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1506 ;	assignBit
      00576F D2 14            [12] 1507 	setb	_rendering
      005771                       1508 00109$:
                                   1509 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      005771 12 5B DB         [24] 1510 	lcall	_ak820_outline_0192
      005774 24 08            [12] 1511 	add	a,#0x08
      005776 FF               [12] 1512 	mov	r7,a
      005777 90 07 85         [24] 1513 	mov	dptr,#_rgb_matrix_task_end_10000_298
      00577A F0               [24] 1514 	movx	@dptr,a
                                   1515 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      00577B EF               [12] 1516 	mov	a,r7
      00577C 24 AD            [12] 1517 	add	a,#0xff - 0x52
      00577E 50 06            [24] 1518 	jnc	00125$
                                   1519 ;	free result
      005780 90 07 85         [24] 1520 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005783 74 52            [12] 1521 	mov	a,#0x52
      005785 F0               [24] 1522 	movx	@dptr,a
                                   1523 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      005786                       1524 00125$:
      005786 12 5B DB         [24] 1525 	lcall	_ak820_outline_0192
      005789 FF               [12] 1526 	mov	r7,a
      00578A 90 07 85         [24] 1527 	mov	dptr,#_rgb_matrix_task_end_10000_298
      00578D E0               [24] 1528 	movx	a,@dptr
      00578E FE               [12] 1529 	mov	r6,a
      00578F C3               [12] 1530 	clr	c
      005790 EF               [12] 1531 	mov	a,r7
      005791 9E               [12] 1532 	subb	a,r6
      005792 40 03            [24] 1533 	jc	00261$
      005794 02 59 07         [24] 1534 	ljmp	00127$
      005797                       1535 00261$:
                                   1536 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      005797 12 5B B8         [24] 1537 	lcall	_ak820_outline_0146
      00579A E0               [24] 1538 	movx	a,@dptr
      00579B 60 07            [24] 1539 	jz	00121$
      00579D 90 07 1F         [24] 1540 	mov	dptr,#_frame_flags
      0057A0 E0               [24] 1541 	movx	a,@dptr
      0057A1 20 E2 1B         [24] 1542 	jb	acc.2,00122$
      0057A4                       1543 00121$:
                                   1544 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      0057A4 12 5B DB         [24] 1545 	lcall	_ak820_outline_0192
      0057A7 FC               [12] 1546 	mov	r4,a
      0057A8 7D 00            [12] 1547 	mov	r5,#0x00
      0057AA 90 07 79         [24] 1548 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0057AD E4               [12] 1549 	clr	a
      0057AE F0               [24] 1550 	movx	@dptr,a
      0057AF 90 07 7A         [24] 1551 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0057B2 F0               [24] 1552 	movx	@dptr,a
      0057B3 90 07 7B         [24] 1553 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0057B6 F0               [24] 1554 	movx	@dptr,a
      0057B7 12 38 4C         [24] 1555 	lcall	_ak820_outline_0126
      0057BA B1 8D            [24] 1556 	acall	_rgb_matrix_set_color
      0057BC 02 58 FE         [24] 1557 	ljmp	00123$
      0057BF                       1558 00122$:
                                   1559 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      0057BF BE 05 29         [24] 1560 	cjne	r6,#0x05,00119$
                                   1561 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      0057C2 EF               [12] 1562 	mov	a,r7
      0057C3 75 F0 03         [24] 1563 	mov	b,#0x03
      0057C6 A4               [48] 1564 	mul	ab
      0057C7 24 0D            [12] 1565 	add	a, #_g_direct_mode_colors
      0057C9 FD               [12] 1566 	mov	r5,a
      0057CA 74 0D            [12] 1567 	mov	a,#(_g_direct_mode_colors >> 8)
      0057CC 35 F0            [12] 1568 	addc	a, b
      0057CE FE               [12] 1569 	mov	r6,a
      0057CF 90 0E 21         [24] 1570 	mov	dptr,#___memcpy_PARM_2
      0057D2 ED               [12] 1571 	mov	a,r5
      0057D3 F0               [24] 1572 	movx	@dptr,a
      0057D4 EE               [12] 1573 	mov	a,r6
      0057D5 12 38 1E         [24] 1574 	lcall	_ak820_outline_0076
      0057D8 90 0E 24         [24] 1575 	mov	dptr,#___memcpy_PARM_3
      0057DB 74 03            [12] 1576 	mov	a,#0x03
      0057DD 12 38 57         [24] 1577 	lcall	_ak820_outline_0132
      0057E0 90 07 86         [24] 1578 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0057E3 F5 F0            [12] 1579 	mov	b,a
      0057E5 12 BD DA         [24] 1580 	lcall	___memcpy
      0057E8 02 58 9A         [24] 1581 	ljmp	00120$
      0057EB                       1582 00119$:
                                   1583 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      0057EB 90 07 1C         [24] 1584 	mov	dptr,#_frame_hue
      0057EE E0               [24] 1585 	movx	a,@dptr
      0057EF 90 07 86         [24] 1586 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0057F2 F0               [24] 1587 	movx	@dptr,a
                                   1588 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      0057F3 90 07 1D         [24] 1589 	mov	dptr,#_frame_sat
      0057F6 E0               [24] 1590 	movx	a,@dptr
      0057F7 90 07 87         [24] 1591 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      0057FA F0               [24] 1592 	movx	@dptr,a
                                   1593 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      0057FB 90 07 1E         [24] 1594 	mov	dptr,#_frame_val
      0057FE E0               [24] 1595 	movx	a,@dptr
      0057FF 90 07 88         [24] 1596 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005802 F0               [24] 1597 	movx	@dptr,a
                                   1598 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      005803 12 5B B8         [24] 1599 	lcall	_ak820_outline_0146
      005806 BE 03 0E         [24] 1600 	cjne	r6,#0x03,00113$
      005809 90 07 86         [24] 1601 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00580C E0               [24] 1602 	movx	a,@dptr
      00580D FE               [12] 1603 	mov	r6,a
      00580E 90 07 20         [24] 1604 	mov	dptr,#_frame_phase
      005811 E0               [24] 1605 	movx	a,@dptr
      005812 2E               [12] 1606 	add	a, r6
      005813 90 07 86         [24] 1607 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005816 F0               [24] 1608 	movx	@dptr,a
      005817                       1609 00113$:
                                   1610 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005817 12 5B B8         [24] 1611 	lcall	_ak820_outline_0146
      00581A BE 04 23         [24] 1612 	cjne	r6,#0x04,00115$
      00581D 90 07 86         [24] 1613 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005820 E0               [24] 1614 	movx	a,@dptr
      005821 FE               [12] 1615 	mov	r6,a
      005822 12 5B DB         [24] 1616 	lcall	_ak820_outline_0192
      005825 75 F0 02         [24] 1617 	mov	b,#0x02
      005828 A4               [48] 1618 	mul	ab
      005829 24 9D            [12] 1619 	add	a, #_ak820_led_points
      00582B F5 82            [12] 1620 	mov	dpl,a
      00582D 74 C1            [12] 1621 	mov	a,#(_ak820_led_points >> 8)
      00582F 12 5B AA         [24] 1622 	lcall	_ak820_outline_0113
      005832 FD               [12] 1623 	mov	r5,a
      005833 90 07 20         [24] 1624 	mov	dptr,#_frame_phase
      005836 E0               [24] 1625 	movx	a,@dptr
      005837 FC               [12] 1626 	mov	r4,a
      005838 ED               [12] 1627 	mov	a,r5
      005839 C3               [12] 1628 	clr	c
      00583A 9C               [12] 1629 	subb	a,r4
      00583B 2E               [12] 1630 	add	a, r6
      00583C 90 07 86         [24] 1631 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00583F F0               [24] 1632 	movx	@dptr,a
      005840                       1633 00115$:
                                   1634 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      005840 12 5B B8         [24] 1635 	lcall	_ak820_outline_0146
      005843 BE 06 54         [24] 1636 	cjne	r6,#0x06,00120$
                                   1637 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005846 12 5B C9         [24] 1638 	lcall	_ak820_outline_0180
      005849 FE               [12] 1639 	mov	r6,a
      00584A 74 07            [12] 1640 	mov	a,#0x07
      00584C C3               [12] 1641 	clr	c
      00584D 9E               [12] 1642 	subb	a,r6
      00584E FE               [12] 1643 	mov	r6,a
                                   1644 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      00584F 8E F0            [24] 1645 	mov	b,r6
      005851 05 F0            [12] 1646 	inc	b
      005853 74 01            [12] 1647 	mov	a,#0x01
      005855 80 02            [24] 1648 	sjmp	00273$
      005857                       1649 00272$:
      005857 25 E0            [12] 1650 	add	a,acc
      005859                       1651 00273$:
      005859 D5 F0 FB         [24] 1652 	djnz	b,00272$
      00585C FD               [12] 1653 	mov	r5,a
                                   1654 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      00585D 12 5B DB         [24] 1655 	lcall	_ak820_outline_0192
      005860 24 21            [12] 1656 	add	a, #_reactive_age
      005862 F5 82            [12] 1657 	mov	dpl,a
      005864 E4               [12] 1658 	clr	a
      005865 34 07            [12] 1659 	addc	a, #(_reactive_age >> 8)
      005867 F5 83            [12] 1660 	mov	dph,a
      005869 E0               [24] 1661 	movx	a,@dptr
                                   1662 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      00586A FC               [12] 1663 	mov	r4,a
      00586B C3               [12] 1664 	clr	c
      00586C 9D               [12] 1665 	subb	a,r5
      00586D 40 07            [24] 1666 	jc	00137$
      00586F 90 07 1E         [24] 1667 	mov	dptr,#_frame_val
      005872 E0               [24] 1668 	movx	a,@dptr
      005873 FB               [12] 1669 	mov	r3,a
      005874 80 1F            [24] 1670 	sjmp	00138$
      005876                       1671 00137$:
      005876 90 07 1E         [24] 1672 	mov	dptr,#_frame_val
      005879 E0               [24] 1673 	movx	a,@dptr
      00587A F5 F0            [12] 1674 	mov	b, a
      00587C EC               [12] 1675 	mov	a,r4
      00587D A4               [48] 1676 	mul	ab
      00587E FC               [12] 1677 	mov	r4,a
      00587F AA F0            [24] 1678 	mov	r2,b
      005881 8E F0            [24] 1679 	mov	b,r6
      005883 05 F0            [12] 1680 	inc	b
      005885 AB 04            [24] 1681 	mov	r3,ar4
      005887 AD 02            [24] 1682 	mov	r5,ar2
      005889 80 07            [24] 1683 	sjmp	00276$
      00588B                       1684 00275$:
      00588B C3               [12] 1685 	clr	c
      00588C ED               [12] 1686 	mov	a,r5
      00588D 13               [12] 1687 	rrc	a
      00588E FD               [12] 1688 	mov	r5,a
      00588F EB               [12] 1689 	mov	a,r3
      005890 13               [12] 1690 	rrc	a
      005891 FB               [12] 1691 	mov	r3,a
      005892                       1692 00276$:
      005892 D5 F0 F6         [24] 1693 	djnz	b,00275$
      005895                       1694 00138$:
      005895 90 07 88         [24] 1695 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005898 EB               [12] 1696 	mov	a,r3
      005899 F0               [24] 1697 	movx	@dptr,a
      00589A                       1698 00120$:
                                   1699 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      00589A 12 5B B8         [24] 1700 	lcall	_ak820_outline_0146
      00589D BE 02 03         [24] 1701 	cjne	r6,#0x02,00277$
      0058A0 D3               [12] 1702 	setb	c
      0058A1 80 01            [24] 1703 	sjmp	00278$
      0058A3                       1704 00277$:
      0058A3 C3               [12] 1705 	clr	c
      0058A4                       1706 00278$:
      0058A4 B3               [12] 1707 	cpl	c
      0058A5 92 15            [24] 1708 	mov	_rgb_matrix_task_sloc0_1_0,c
      0058A7 90 0E 21         [24] 1709 	mov	dptr,#___memcpy_PARM_2
      0058AA 74 86            [12] 1710 	mov	a,#_rgb_matrix_task_hsv_10000_298
      0058AC F0               [24] 1711 	movx	@dptr,a
      0058AD 74 07            [12] 1712 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      0058AF 12 38 1E         [24] 1713 	lcall	_ak820_outline_0076
      0058B2 90 0E 24         [24] 1714 	mov	dptr,#___memcpy_PARM_3
      0058B5 74 03            [12] 1715 	mov	a,#0x03
      0058B7 12 38 57         [24] 1716 	lcall	_ak820_outline_0132
      0058BA 90 0B 42         [24] 1717 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      0058BD F5 F0            [12] 1718 	mov	b,a
      0058BF 12 BD DA         [24] 1719 	lcall	___memcpy
      0058C2 90 0B 45         [24] 1720 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      0058C5 74 89            [12] 1721 	mov	a,#_rgb_matrix_task_rgb_10000_298
      0058C7 F0               [24] 1722 	movx	@dptr,a
      0058C8 74 07            [12] 1723 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      0058CA A3               [24] 1724 	inc	dptr
      0058CB F0               [24] 1725 	movx	@dptr,a
      0058CC A2 15            [12] 1726 	mov	c,_rgb_matrix_task_sloc0_1_0
      0058CE 12 38 67         [24] 1727 	lcall	_ak820_outline_0150
      0058D1 12 86 69         [24] 1728 	lcall	_hsv_to_rgb_into
                                   1729 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      0058D4 12 5B DB         [24] 1730 	lcall	_ak820_outline_0192
      0058D7 FD               [12] 1731 	mov	r5,a
      0058D8 7E 00            [12] 1732 	mov	r6,#0x00
      0058DA 90 07 8A         [24] 1733 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      0058DD E0               [24] 1734 	movx	a,@dptr
      0058DE FC               [12] 1735 	mov	r4,a
      0058DF 90 07 89         [24] 1736 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      0058E2 E0               [24] 1737 	movx	a,@dptr
      0058E3 FB               [12] 1738 	mov	r3,a
      0058E4 90 07 8B         [24] 1739 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      0058E7 E0               [24] 1740 	movx	a,@dptr
      0058E8 FA               [12] 1741 	mov	r2,a
      0058E9 90 07 79         [24] 1742 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0058EC EC               [12] 1743 	mov	a,r4
      0058ED F0               [24] 1744 	movx	@dptr,a
      0058EE 90 07 7A         [24] 1745 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0058F1 EB               [12] 1746 	mov	a,r3
      0058F2 F0               [24] 1747 	movx	@dptr,a
      0058F3 90 07 7B         [24] 1748 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0058F6 EA               [12] 1749 	mov	a,r2
      0058F7 F0               [24] 1750 	movx	@dptr,a
      0058F8 12 38 5C         [24] 1751 	lcall	_ak820_outline_0141
      0058FB 12 55 8D         [24] 1752 	lcall	_rgb_matrix_set_color
      0058FE                       1753 00123$:
                                   1754 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      0058FE 12 5B DB         [24] 1755 	lcall	_ak820_outline_0192
      005901 24 01            [12] 1756 	add	a, #0x01
      005903 F0               [24] 1757 	movx	@dptr,a
      005904 02 57 86         [24] 1758 	ljmp	00125$
      005907                       1759 00127$:
                                   1760 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      005907 BF 52 02         [24] 1761 	cjne	r7,#0x52,00130$
                                   1762 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1763 ;	assignBit
      00590A C2 14            [12] 1764 	clr	_rendering
      00590C                       1765 00130$:
                                   1766 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      00590C 22               [24] 1767 	ret
                                   1768 ;------------------------------------------------------------
                                   1769 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1770 ;------------------------------------------------------------
                                   1771 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1772 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1773 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1774 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1775 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1776 ;------------------------------------------------------------
                                   1777 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1778 ;	-----------------------------------------
                                   1779 ;	 function process_rgb_matrix
                                   1780 ;	-----------------------------------------
      00590D                       1781 _process_rgb_matrix:
      00590D E5 82            [12] 1782 	mov	a,dpl
      00590F 90 07 8E         [24] 1783 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005912 F0               [24] 1784 	movx	@dptr,a
                                   1785 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      005913 90 07 8D         [24] 1786 	mov	dptr,#_process_rgb_matrix_PARM_3
      005916 E0               [24] 1787 	movx	a,@dptr
      005917 60 23            [24] 1788 	jz	00101$
      005919 20 12 20         [24] 1789 	jb	_suspended,00101$
      00591C 12 5B 90         [24] 1790 	lcall	_ak820_outline_0070
      00591F 60 1B            [24] 1791 	jz	00101$
                                   1792 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      005921 12 5B 71         [24] 1793 	lcall	_ak820_outline_0020
      005924 FF               [12] 1794 	mov	r7,a
      005925 BF 06 14         [24] 1795 	cjne	r7,#0x06,00101$
      005928 90 07 8E         [24] 1796 	mov	dptr,#_process_rgb_matrix_row_10000_319
      00592B E0               [24] 1797 	movx	a,@dptr
      00592C FF               [12] 1798 	mov	r7,a
      00592D BF 10 00         [24] 1799 	cjne	r7,#0x10,00169$
      005930                       1800 00169$:
      005930 50 0A            [24] 1801 	jnc	00101$
      005932 90 07 8C         [24] 1802 	mov	dptr,#_process_rgb_matrix_PARM_2
      005935 E0               [24] 1803 	movx	a,@dptr
      005936 FE               [12] 1804 	mov	r6,a
      005937 BE 08 00         [24] 1805 	cjne	r6,#0x08,00171$
      00593A                       1806 00171$:
      00593A 40 01            [24] 1807 	jc	00102$
      00593C                       1808 00101$:
      00593C 22               [24] 1809 	ret
      00593D                       1810 00102$:
                                   1811 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      00593D C0 07            [24] 1812 	push	ar7
      00593F C0 06            [24] 1813 	push	ar6
      005941 12 54 1C         [24] 1814 	lcall	_age_reactive
      005944 D0 06            [24] 1815 	pop	ar6
      005946 D0 07            [24] 1816 	pop	ar7
                                   1817 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005948 EF               [12] 1818 	mov	a,r7
      005949 12 38 82         [24] 1819 	lcall	_ak820_outline_0193
      00594C 2E               [12] 1820 	add	a,r6
      00594D FF               [12] 1821 	mov	r7,a
                                   1822 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00594E 7E 00            [12] 1823 	mov	r6,#0x00
      005950                       1824 00111$:
                                   1825 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      005950 EE               [12] 1826 	mov	a,r6
      005951 90 BE E3         [24] 1827 	mov	dptr,#_ak820_rgb_slots
      005954 93               [24] 1828 	movc	a,@a+dptr
      005955 B5 07 29         [24] 1829 	cjne	a,ar7,00112$
                                   1830 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005958 EE               [12] 1831 	mov	a,r6
      005959 24 21            [12] 1832 	add	a, #_reactive_age
      00595B FC               [12] 1833 	mov	r4,a
      00595C E4               [12] 1834 	clr	a
      00595D 34 07            [12] 1835 	addc	a, #(_reactive_age >> 8)
      00595F FD               [12] 1836 	mov	r5,a
      005960 12 5B C9         [24] 1837 	lcall	_ak820_outline_0180
      005963 F5 F0            [12] 1838 	mov	b, a
      005965 05 F0            [12] 1839 	inc	b
      005967 7B 80            [12] 1840 	mov	r3,#0x80
      005969 E4               [12] 1841 	clr	a
      00596A FA               [12] 1842 	mov	r2,a
      00596B 33               [12] 1843 	rlc	a
      00596C 92 D2            [24] 1844 	mov	ov,c
      00596E 80 08            [24] 1845 	sjmp	00176$
      005970                       1846 00175$:
      005970 A2 D2            [12] 1847 	mov	c,ov
      005972 EA               [12] 1848 	mov	a,r2
      005973 13               [12] 1849 	rrc	a
      005974 FA               [12] 1850 	mov	r2,a
      005975 EB               [12] 1851 	mov	a,r3
      005976 13               [12] 1852 	rrc	a
      005977 FB               [12] 1853 	mov	r3,a
      005978                       1854 00176$:
      005978 D5 F0 F5         [24] 1855 	djnz	b,00175$
      00597B 12 38 4C         [24] 1856 	lcall	_ak820_outline_0126
      00597E EB               [12] 1857 	mov	a,r3
      00597F F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      005980 22               [24] 1860 	ret
      005981                       1861 00112$:
                                   1862 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005981 0E               [12] 1863 	inc	r6
      005982 BE 52 00         [24] 1864 	cjne	r6,#0x52,00177$
      005985                       1865 00177$:
      005985 40 C9            [24] 1866 	jc	00111$
                                   1867 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      005987 22               [24] 1868 	ret
                                   1869 ;------------------------------------------------------------
                                   1870 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1871 ;------------------------------------------------------------
                                   1872 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1873 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1874 ;------------------------------------------------------------
                                   1875 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1876 ;	-----------------------------------------
                                   1877 ;	 function rgb_matrix_set_suspend_state
                                   1878 ;	-----------------------------------------
      005988                       1879 _rgb_matrix_set_suspend_state:
      005988 E5 82            [12] 1880 	mov	a,dpl
      00598A 90 07 8F         [24] 1881 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      00598D F0               [24] 1882 	movx	@dptr,a
                                   1883 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      00598E E0               [24] 1884 	movx	a,@dptr
                                   1885 ;	assignBit
      00598F F5 17            [12] 1886 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      005991 13               [12] 1887 	rrc	a
      005992 92 12            [24] 1888 	mov	_suspended,c
                                   1889 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1890 ;	assignBit
      005994 C2 14            [12] 1891 	clr	_rendering
                                   1892 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      005996 12 53 FF         [24] 1893 	lcall	_clear_reactive
                                   1894 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      005999 E5 17            [12] 1895 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      00599B 60 0F            [24] 1896 	jz	00103$
                                   1897 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      00599D 90 07 7E         [24] 1898 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0059A0 E4               [12] 1899 	clr	a
      0059A1 F0               [24] 1900 	movx	@dptr,a
      0059A2 90 07 7F         [24] 1901 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0059A5 F0               [24] 1902 	movx	@dptr,a
      0059A6 75 82 00         [24] 1903 	mov	dpl, #0x00
                                   1904 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      0059A9 02 55 CE         [24] 1905 	ljmp	_rgb_matrix_set_color_all
      0059AC                       1906 00103$:
      0059AC 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1910 ;------------------------------------------------------------
                                   1911 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1912 ;	-----------------------------------------
                                   1913 ;	 function rgb_matrix_is_enabled
                                   1914 ;	-----------------------------------------
      0059AD                       1915 _rgb_matrix_is_enabled:
      0059AD 12 5B 90         [24] 1916 	lcall	_ak820_outline_0070
      0059B0 F5 82            [12] 1917 	mov	dpl,a
      0059B2 22               [24] 1918 	ret
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function rgb_matrix_get_mode
                                   1925 ;	-----------------------------------------
      0059B3                       1926 _rgb_matrix_get_mode:
      0059B3 12 5B 71         [24] 1927 	lcall	_ak820_outline_0020
      0059B6 F5 82            [12] 1928 	mov	dpl,a
      0059B8 22               [24] 1929 	ret
                                   1930 ;------------------------------------------------------------
                                   1931 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1932 ;------------------------------------------------------------
                                   1933 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1934 ;	-----------------------------------------
                                   1935 ;	 function rgb_matrix_get_hue
                                   1936 ;	-----------------------------------------
      0059B9                       1937 _rgb_matrix_get_hue:
      0059B9 90 07 0D         [24] 1938 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0059BC E0               [24] 1939 	movx	a,@dptr
      0059BD F5 82            [12] 1940 	mov	dpl,a
      0059BF 22               [24] 1941 	ret
                                   1942 ;------------------------------------------------------------
                                   1943 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1944 ;------------------------------------------------------------
                                   1945 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1946 ;	-----------------------------------------
                                   1947 ;	 function rgb_matrix_get_sat
                                   1948 ;	-----------------------------------------
      0059C0                       1949 _rgb_matrix_get_sat:
      0059C0 90 07 0E         [24] 1950 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0059C3 E0               [24] 1951 	movx	a,@dptr
      0059C4 F5 82            [12] 1952 	mov	dpl,a
      0059C6 22               [24] 1953 	ret
                                   1954 ;------------------------------------------------------------
                                   1955 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1956 ;------------------------------------------------------------
                                   1957 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1958 ;	-----------------------------------------
                                   1959 ;	 function rgb_matrix_get_val
                                   1960 ;	-----------------------------------------
      0059C7                       1961 _rgb_matrix_get_val:
      0059C7 90 07 0F         [24] 1962 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0059CA E0               [24] 1963 	movx	a,@dptr
      0059CB F5 82            [12] 1964 	mov	dpl,a
      0059CD 22               [24] 1965 	ret
                                   1966 ;------------------------------------------------------------
                                   1967 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1968 ;------------------------------------------------------------
                                   1969 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1970 ;	-----------------------------------------
                                   1971 ;	 function rgb_matrix_get_speed
                                   1972 ;	-----------------------------------------
      0059CE                       1973 _rgb_matrix_get_speed:
      0059CE 90 07 10         [24] 1974 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0059D1 E0               [24] 1975 	movx	a,@dptr
      0059D2 F5 82            [12] 1976 	mov	dpl,a
      0059D4 22               [24] 1977 	ret
                                   1978 ;------------------------------------------------------------
                                   1979 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1980 ;------------------------------------------------------------
                                   1981 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1982 ;	-----------------------------------------
                                   1983 ;	 function rgb_matrix_toggle_noeeprom
                                   1984 ;	-----------------------------------------
      0059D5                       1985 _rgb_matrix_toggle_noeeprom:
      0059D5 12 5B 90         [24] 1986 	lcall	_ak820_outline_0070
      0059D8 FF               [12] 1987 	mov	r7,a
      0059D9 63 07 01         [24] 1988 	xrl	ar7,#0x01
      0059DC 90 07 0C         [24] 1989 	mov	dptr,#_rgb_matrix_config
      0059DF EF               [12] 1990 	mov	a,r7
      0059E0 54 03            [12] 1991 	anl	a,#0x03
      0059E2 F5 F0            [12] 1992 	mov	b,a
      0059E4 E0               [24] 1993 	movx	a,@dptr
      0059E5 54 FC            [12] 1994 	anl	a,#0xfc
      0059E7 45 F0            [12] 1995 	orl	a,b
      0059E9 F0               [24] 1996 	movx	@dptr,a
                                   1997 ;	assignBit
      0059EA C2 14            [12] 1998 	clr	_rendering
      0059EC 02 53 FF         [24] 1999 	ljmp	_clear_reactive
                                   2000 ;------------------------------------------------------------
                                   2001 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   2002 ;------------------------------------------------------------
                                   2003 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   2004 ;	-----------------------------------------
                                   2005 ;	 function rgb_matrix_enable_noeeprom
                                   2006 ;	-----------------------------------------
      0059EF                       2007 _rgb_matrix_enable_noeeprom:
      0059EF 12 5B 90         [24] 2008 	lcall	_ak820_outline_0070
      0059F2 70 03            [24] 2009 	jnz	00102$
      0059F4 12 53 FF         [24] 2010 	lcall	_clear_reactive
      0059F7                       2011 00102$:
      0059F7 12 5B B1         [24] 2012 	lcall	_ak820_outline_0120
      0059FA 44 01            [12] 2013 	orl	a,#0x01
      0059FC F0               [24] 2014 	movx	@dptr,a
                                   2015 ;	assignBit
      0059FD C2 14            [12] 2016 	clr	_rendering
      0059FF 22               [24] 2017 	ret
                                   2018 ;------------------------------------------------------------
                                   2019 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2020 ;------------------------------------------------------------
                                   2021 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2022 ;	-----------------------------------------
                                   2023 ;	 function rgb_matrix_disable_noeeprom
                                   2024 ;	-----------------------------------------
      005A00                       2025 _rgb_matrix_disable_noeeprom:
      005A00 12 5B B1         [24] 2026 	lcall	_ak820_outline_0120
      005A03 F0               [24] 2027 	movx	@dptr,a
                                   2028 ;	assignBit
      005A04 C2 14            [12] 2029 	clr	_rendering
      005A06 02 53 FF         [24] 2030 	ljmp	_clear_reactive
                                   2031 ;------------------------------------------------------------
                                   2032 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2033 ;------------------------------------------------------------
                                   2034 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2035 ;------------------------------------------------------------
                                   2036 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2037 ;	-----------------------------------------
                                   2038 ;	 function rgb_matrix_mode_noeeprom
                                   2039 ;	-----------------------------------------
      005A09                       2040 _rgb_matrix_mode_noeeprom:
      005A09 E5 82            [12] 2041 	mov	a,dpl
      005A0B 90 07 90         [24] 2042 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005A0E F0               [24] 2043 	movx	@dptr,a
                                   2044 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005A0F E0               [24] 2045 	movx	a,@dptr
      005A10 FF               [12] 2046 	mov	r7,a
      005A11 60 05            [24] 2047 	jz	00101$
      005A13 BF 07 00         [24] 2048 	cjne	r7,#0x07,00123$
      005A16                       2049 00123$:
      005A16 40 01            [24] 2050 	jc	00102$
      005A18                       2051 00101$:
      005A18 22               [24] 2052 	ret
      005A19                       2053 00102$:
                                   2054 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      005A19 12 5B 71         [24] 2055 	lcall	_ak820_outline_0020
      005A1C FE               [12] 2056 	mov	r6,a
      005A1D EF               [12] 2057 	mov	a,r7
      005A1E B5 06 02         [24] 2058 	cjne	a,ar6,00125$
      005A21 80 03            [24] 2059 	sjmp	00105$
      005A23                       2060 00125$:
      005A23 12 53 FF         [24] 2061 	lcall	_clear_reactive
      005A26                       2062 00105$:
                                   2063 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      005A26 90 07 90         [24] 2064 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005A29 E0               [24] 2065 	movx	a,@dptr
      005A2A 90 07 0C         [24] 2066 	mov	dptr,#_rgb_matrix_config
      005A2D 25 E0            [12] 2067 	add	a,acc
      005A2F 25 E0            [12] 2068 	add	a,acc
      005A31 54 FC            [12] 2069 	anl	a,#0xfc
      005A33 F5 F0            [12] 2070 	mov	b,a
      005A35 E0               [24] 2071 	movx	a,@dptr
      005A36 54 03            [12] 2072 	anl	a,#0x03
      005A38 45 F0            [12] 2073 	orl	a,b
      005A3A F0               [24] 2074 	movx	@dptr,a
                                   2075 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2076 ;	assignBit
      005A3B C2 14            [12] 2077 	clr	_rendering
                                   2078 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005A3D 22               [24] 2079 	ret
                                   2080 ;------------------------------------------------------------
                                   2081 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2082 ;------------------------------------------------------------
                                   2083 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2084 ;	-----------------------------------------
                                   2085 ;	 function rgb_matrix_step_noeeprom
                                   2086 ;	-----------------------------------------
      005A3E                       2087 _rgb_matrix_step_noeeprom:
                                   2088 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005A3E 12 5B 71         [24] 2089 	lcall	_ak820_outline_0020
      005A41 FF               [12] 2090 	mov	r7,a
      005A42 0F               [12] 2091 	inc	r7
      005A43 BF 07 00         [24] 2092 	cjne	r7,#0x07,00112$
      005A46                       2093 00112$:
      005A46 40 04            [24] 2094 	jc	00103$
      005A48 7F 01            [12] 2095 	mov	r7,#0x01
      005A4A 80 07            [24] 2096 	sjmp	00104$
      005A4C                       2097 00103$:
      005A4C 12 5B 71         [24] 2098 	lcall	_ak820_outline_0020
      005A4F FE               [12] 2099 	mov	r6,a
      005A50 0E               [12] 2100 	inc	r6
      005A51 8E 07            [24] 2101 	mov	ar7,r6
      005A53                       2102 00104$:
      005A53 8F 82            [24] 2103 	mov	dpl, r7
                                   2104 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      005A55 41 09            [12] 2105 	ajmp	_rgb_matrix_mode_noeeprom
                                   2106 ;------------------------------------------------------------
                                   2107 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2108 ;------------------------------------------------------------
                                   2109 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2110 ;	-----------------------------------------
                                   2111 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2112 ;	-----------------------------------------
      005A57                       2113 _rgb_matrix_step_reverse_noeeprom:
                                   2114 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005A57 12 5B 71         [24] 2115 	lcall	_ak820_outline_0020
      005A5A 24 FE            [12] 2116 	add	a,#0xff - 0x01
      005A5C 40 04            [24] 2117 	jc	00103$
                                   2118 ;	free result
      005A5E 7F 06            [12] 2119 	mov	r7,#0x06
      005A60 80 05            [24] 2120 	sjmp	00104$
      005A62                       2121 00103$:
      005A62 12 5B 71         [24] 2122 	lcall	_ak820_outline_0020
      005A65 14               [12] 2123 	dec	a
      005A66 FF               [12] 2124 	mov	r7,a
      005A67                       2125 00104$:
      005A67 8F 82            [24] 2126 	mov	dpl, r7
                                   2127 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005A69 41 09            [12] 2128 	ajmp	_rgb_matrix_mode_noeeprom
                                   2129 ;------------------------------------------------------------
                                   2130 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2131 ;------------------------------------------------------------
                                   2132 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2133 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2134 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2135 ;------------------------------------------------------------
                                   2136 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2137 ;	-----------------------------------------
                                   2138 ;	 function rgb_matrix_sethsv_noeeprom
                                   2139 ;	-----------------------------------------
      005A6B                       2140 _rgb_matrix_sethsv_noeeprom:
      005A6B 12 38 42         [24] 2141 	lcall	_ak820_outline_0108
      005A6E 90 07 93         [24] 2142 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005A71 12 38 47         [24] 2143 	lcall	_ak820_outline_0109
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005A74 90 07 93         [24] 2145 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005A77 E0               [24] 2146 	movx	a,@dptr
      005A78 90 07 0D         [24] 2147 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005A7B F0               [24] 2148 	movx	@dptr,a
                                   2149 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005A7C 90 07 91         [24] 2150 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005A7F E0               [24] 2151 	movx	a,@dptr
      005A80 FF               [12] 2152 	mov	r7,a
      005A81 90 07 0E         [24] 2153 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005A84 F0               [24] 2154 	movx	@dptr,a
                                   2155 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005A85 90 07 92         [24] 2156 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005A88 E0               [24] 2157 	movx	a,@dptr
      005A89 FF               [12] 2158 	mov  r7,a
      005A8A 24 5F            [12] 2159 	add	a,#0xff - 0xa0
      005A8C 50 04            [24] 2160 	jnc	00103$
                                   2161 ;	free result
      005A8E 7E A0            [12] 2162 	mov	r6,#0xa0
      005A90 80 02            [24] 2163 	sjmp	00104$
      005A92                       2164 00103$:
      005A92 8F 06            [24] 2165 	mov	ar6,r7
      005A94                       2166 00104$:
      005A94 90 07 0F         [24] 2167 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005A97 EE               [12] 2168 	mov	a,r6
      005A98 F0               [24] 2169 	movx	@dptr,a
                                   2170 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005A99 22               [24] 2171 	ret
                                   2172 ;------------------------------------------------------------
                                   2173 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2174 ;------------------------------------------------------------
                                   2175 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2176 ;------------------------------------------------------------
                                   2177 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2178 ;	-----------------------------------------
                                   2179 ;	 function rgb_matrix_set_speed_noeeprom
                                   2180 ;	-----------------------------------------
      005A9A                       2181 _rgb_matrix_set_speed_noeeprom:
      005A9A E5 82            [12] 2182 	mov	a,dpl
      005A9C 90 07 95         [24] 2183 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      005A9F F0               [24] 2184 	movx	@dptr,a
      005AA0 E0               [24] 2185 	movx	a,@dptr
      005AA1 90 07 10         [24] 2186 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005AA4 F0               [24] 2187 	movx	@dptr,a
      005AA5 22               [24] 2188 	ret
                                   2189 ;------------------------------------------------------------
                                   2190 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2191 ;------------------------------------------------------------
                                   2192 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2193 ;------------------------------------------------------------
                                   2194 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2195 ;	-----------------------------------------
                                   2196 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2197 ;	-----------------------------------------
      005AA6                       2198 _rgb_matrix_increase_hue_noeeprom:
      005AA6 90 07 0D         [24] 2199 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AA9 E0               [24] 2200 	movx	a,@dptr
      005AAA 24 08            [12] 2201 	add	a,#0x08
      005AAC 90 07 0D         [24] 2202 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AAF F0               [24] 2203 	movx	@dptr,a
      005AB0 22               [24] 2204 	ret
                                   2205 ;------------------------------------------------------------
                                   2206 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2207 ;------------------------------------------------------------
                                   2208 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2209 ;	-----------------------------------------
                                   2210 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2211 ;	-----------------------------------------
      005AB1                       2212 _rgb_matrix_decrease_hue_noeeprom:
      005AB1 90 07 0D         [24] 2213 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AB4 E0               [24] 2214 	movx	a,@dptr
      005AB5 24 F8            [12] 2215 	add	a,#0xf8
      005AB7 90 07 0D         [24] 2216 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005ABA F0               [24] 2217 	movx	@dptr,a
      005ABB 22               [24] 2218 	ret
                                   2219 ;------------------------------------------------------------
                                   2220 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2221 ;------------------------------------------------------------
                                   2222 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2223 ;	-----------------------------------------
                                   2224 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2225 ;	-----------------------------------------
      005ABC                       2226 _rgb_matrix_increase_sat_noeeprom:
      005ABC 90 07 0E         [24] 2227 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005ABF 12 5B 7A         [24] 2228 	lcall	_ak820_outline_0052
      005AC2 12 54 9A         [24] 2229 	lcall	_add_sat
      005AC5 AF 82            [24] 2230 	mov	r7, dpl
      005AC7 90 07 0E         [24] 2231 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005ACA EF               [12] 2232 	mov	a,r7
      005ACB F0               [24] 2233 	movx	@dptr,a
      005ACC 22               [24] 2234 	ret
                                   2235 ;------------------------------------------------------------
                                   2236 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2237 ;------------------------------------------------------------
                                   2238 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2239 ;	-----------------------------------------
                                   2240 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2241 ;	-----------------------------------------
      005ACD                       2242 _rgb_matrix_decrease_sat_noeeprom:
      005ACD 90 07 0E         [24] 2243 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005AD0 12 5B 85         [24] 2244 	lcall	_ak820_outline_0053
      005AD3 12 54 BF         [24] 2245 	lcall	_sub_sat
      005AD6 AF 82            [24] 2246 	mov	r7, dpl
      005AD8 90 07 0E         [24] 2247 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005ADB EF               [12] 2248 	mov	a,r7
      005ADC F0               [24] 2249 	movx	@dptr,a
      005ADD 22               [24] 2250 	ret
                                   2251 ;------------------------------------------------------------
                                   2252 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2253 ;------------------------------------------------------------
                                   2254 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2255 ;------------------------------------------------------------
                                   2256 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2257 ;	-----------------------------------------
                                   2258 ;	 function rgb_matrix_increase_val_noeeprom
                                   2259 ;	-----------------------------------------
      005ADE                       2260 _rgb_matrix_increase_val_noeeprom:
                                   2261 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005ADE 90 07 0F         [24] 2262 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AE1 12 5B 7A         [24] 2263 	lcall	_ak820_outline_0052
      005AE4 12 54 9A         [24] 2264 	lcall	_add_sat
                                   2265 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005AE7 E5 82            [12] 2266 	mov	a,dpl
      005AE9 FF               [12] 2267 	mov	r7,a
      005AEA 24 5F            [12] 2268 	add	a,#0xff - 0xa0
      005AEC 50 04            [24] 2269 	jnc	00103$
                                   2270 ;	free result
      005AEE 7E A0            [12] 2271 	mov	r6,#0xa0
      005AF0 80 02            [24] 2272 	sjmp	00104$
      005AF2                       2273 00103$:
      005AF2 8F 06            [24] 2274 	mov	ar6,r7
      005AF4                       2275 00104$:
      005AF4 90 07 0F         [24] 2276 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AF7 EE               [12] 2277 	mov	a,r6
      005AF8 F0               [24] 2278 	movx	@dptr,a
                                   2279 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005AF9 22               [24] 2280 	ret
                                   2281 ;------------------------------------------------------------
                                   2282 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2283 ;------------------------------------------------------------
                                   2284 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2285 ;	-----------------------------------------
                                   2286 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2287 ;	-----------------------------------------
      005AFA                       2288 _rgb_matrix_decrease_val_noeeprom:
      005AFA 90 07 0F         [24] 2289 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AFD 12 5B 85         [24] 2290 	lcall	_ak820_outline_0053
      005B00 12 54 BF         [24] 2291 	lcall	_sub_sat
      005B03 AF 82            [24] 2292 	mov	r7, dpl
      005B05 90 07 0F         [24] 2293 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B08 EF               [12] 2294 	mov	a,r7
      005B09 F0               [24] 2295 	movx	@dptr,a
      005B0A 22               [24] 2296 	ret
                                   2297 ;------------------------------------------------------------
                                   2298 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2299 ;------------------------------------------------------------
                                   2300 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2301 ;	-----------------------------------------
                                   2302 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2303 ;	-----------------------------------------
      005B0B                       2304 _rgb_matrix_increase_speed_noeeprom:
      005B0B 90 07 10         [24] 2305 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B0E 12 5B 7A         [24] 2306 	lcall	_ak820_outline_0052
      005B11 12 54 9A         [24] 2307 	lcall	_add_sat
      005B14 AF 82            [24] 2308 	mov	r7, dpl
      005B16 90 07 10         [24] 2309 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B19 EF               [12] 2310 	mov	a,r7
      005B1A F0               [24] 2311 	movx	@dptr,a
      005B1B 22               [24] 2312 	ret
                                   2313 ;------------------------------------------------------------
                                   2314 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2315 ;------------------------------------------------------------
                                   2316 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2317 ;	-----------------------------------------
                                   2318 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2319 ;	-----------------------------------------
      005B1C                       2320 _rgb_matrix_decrease_speed_noeeprom:
      005B1C 90 07 10         [24] 2321 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B1F 12 5B 85         [24] 2322 	lcall	_ak820_outline_0053
      005B22 12 54 BF         [24] 2323 	lcall	_sub_sat
      005B25 AF 82            [24] 2324 	mov	r7, dpl
      005B27 90 07 10         [24] 2325 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B2A EF               [12] 2326 	mov	a,r7
      005B2B F0               [24] 2327 	movx	@dptr,a
      005B2C 22               [24] 2328 	ret
                                   2329 ;------------------------------------------------------------
                                   2330 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2331 ;------------------------------------------------------------
                                   2332 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2333 ;	-----------------------------------------
                                   2334 ;	 function rgb_matrix_toggle
                                   2335 ;	-----------------------------------------
      005B2D                       2336 _rgb_matrix_toggle:
      005B2D 31 D5            [12] 2337 	acall	_rgb_matrix_toggle_noeeprom
      005B2F 02 54 DC         [24] 2338 	ljmp	_mark_dirty
                                   2339 ;------------------------------------------------------------
                                   2340 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2341 ;------------------------------------------------------------
                                   2342 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2343 ;	-----------------------------------------
                                   2344 ;	 function rgb_matrix_step
                                   2345 ;	-----------------------------------------
      005B32                       2346 _rgb_matrix_step:
      005B32 51 3E            [12] 2347 	acall	_rgb_matrix_step_noeeprom
      005B34 02 54 DC         [24] 2348 	ljmp	_mark_dirty
                                   2349 ;------------------------------------------------------------
                                   2350 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2351 ;------------------------------------------------------------
                                   2352 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2353 ;	-----------------------------------------
                                   2354 ;	 function rgb_matrix_step_reverse
                                   2355 ;	-----------------------------------------
      005B37                       2356 _rgb_matrix_step_reverse:
      005B37 51 57            [12] 2357 	acall	_rgb_matrix_step_reverse_noeeprom
      005B39 02 54 DC         [24] 2358 	ljmp	_mark_dirty
                                   2359 ;------------------------------------------------------------
                                   2360 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2361 ;------------------------------------------------------------
                                   2362 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2363 ;	-----------------------------------------
                                   2364 ;	 function rgb_matrix_increase_hue
                                   2365 ;	-----------------------------------------
      005B3C                       2366 _rgb_matrix_increase_hue:
      005B3C 51 A6            [12] 2367 	acall	_rgb_matrix_increase_hue_noeeprom
      005B3E 02 54 DC         [24] 2368 	ljmp	_mark_dirty
                                   2369 ;------------------------------------------------------------
                                   2370 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2371 ;------------------------------------------------------------
                                   2372 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2373 ;	-----------------------------------------
                                   2374 ;	 function rgb_matrix_decrease_hue
                                   2375 ;	-----------------------------------------
      005B41                       2376 _rgb_matrix_decrease_hue:
      005B41 51 B1            [12] 2377 	acall	_rgb_matrix_decrease_hue_noeeprom
      005B43 02 54 DC         [24] 2378 	ljmp	_mark_dirty
                                   2379 ;------------------------------------------------------------
                                   2380 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2381 ;------------------------------------------------------------
                                   2382 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2383 ;	-----------------------------------------
                                   2384 ;	 function rgb_matrix_increase_sat
                                   2385 ;	-----------------------------------------
      005B46                       2386 _rgb_matrix_increase_sat:
      005B46 51 BC            [12] 2387 	acall	_rgb_matrix_increase_sat_noeeprom
      005B48 02 54 DC         [24] 2388 	ljmp	_mark_dirty
                                   2389 ;------------------------------------------------------------
                                   2390 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2391 ;------------------------------------------------------------
                                   2392 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2393 ;	-----------------------------------------
                                   2394 ;	 function rgb_matrix_decrease_sat
                                   2395 ;	-----------------------------------------
      005B4B                       2396 _rgb_matrix_decrease_sat:
      005B4B 51 CD            [12] 2397 	acall	_rgb_matrix_decrease_sat_noeeprom
      005B4D 02 54 DC         [24] 2398 	ljmp	_mark_dirty
                                   2399 ;------------------------------------------------------------
                                   2400 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2401 ;------------------------------------------------------------
                                   2402 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2403 ;	-----------------------------------------
                                   2404 ;	 function rgb_matrix_increase_val
                                   2405 ;	-----------------------------------------
      005B50                       2406 _rgb_matrix_increase_val:
      005B50 51 DE            [12] 2407 	acall	_rgb_matrix_increase_val_noeeprom
      005B52 02 54 DC         [24] 2408 	ljmp	_mark_dirty
                                   2409 ;------------------------------------------------------------
                                   2410 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2411 ;------------------------------------------------------------
                                   2412 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2413 ;	-----------------------------------------
                                   2414 ;	 function rgb_matrix_decrease_val
                                   2415 ;	-----------------------------------------
      005B55                       2416 _rgb_matrix_decrease_val:
      005B55 51 FA            [12] 2417 	acall	_rgb_matrix_decrease_val_noeeprom
      005B57 02 54 DC         [24] 2418 	ljmp	_mark_dirty
                                   2419 ;------------------------------------------------------------
                                   2420 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2421 ;------------------------------------------------------------
                                   2422 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2423 ;	-----------------------------------------
                                   2424 ;	 function rgb_matrix_increase_speed
                                   2425 ;	-----------------------------------------
      005B5A                       2426 _rgb_matrix_increase_speed:
      005B5A 71 0B            [12] 2427 	acall	_rgb_matrix_increase_speed_noeeprom
      005B5C 02 54 DC         [24] 2428 	ljmp	_mark_dirty
                                   2429 ;------------------------------------------------------------
                                   2430 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2431 ;------------------------------------------------------------
                                   2432 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2433 ;	-----------------------------------------
                                   2434 ;	 function rgb_matrix_decrease_speed
                                   2435 ;	-----------------------------------------
      005B5F                       2436 _rgb_matrix_decrease_speed:
      005B5F 71 1C            [12] 2437 	acall	_rgb_matrix_decrease_speed_noeeprom
      005B61 02 54 DC         [24] 2438 	ljmp	_mark_dirty
                                   2439 ;------------------------------------------------------------
                                   2440 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2441 ;------------------------------------------------------------
                                   2442 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2443 ;------------------------------------------------------------
                                   2444 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2445 ;	-----------------------------------------
                                   2446 ;	 function rgb_matrix_mode
                                   2447 ;	-----------------------------------------
      005B64                       2448 _rgb_matrix_mode:
      005B64 E5 82            [12] 2449 	mov	a,dpl
      005B66 90 07 96         [24] 2450 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005B69 12 5B C4         [24] 2451 	lcall	_ak820_outline_0179
      005B6C 51 09            [12] 2452 	acall	_rgb_matrix_mode_noeeprom
      005B6E 02 54 DC         [24] 2453 	ljmp	_mark_dirty
                                   2454 ;------------------------------------------------------------
                                   2455 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2456 ;------------------------------------------------------------
                                   2457 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2458 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2459 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2460 ;------------------------------------------------------------
                                   2461 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2462 ;	-----------------------------------------
                                   2463 	.area CSEG    (CODE)
                                   2464 	.area CONST   (CODE)
                                   2465 	.area CONST   (CODE)
      00BF35                       2466 _sine8_coefficients_10000_290:
      00BF35 00                    2467 	.db #0x00	; 0
      00BF36 31                    2468 	.db #0x31	; 49	'1'
      00BF37 31                    2469 	.db #0x31	; 49	'1'
      00BF38 29                    2470 	.db #0x29	; 41
      00BF39 5A                    2471 	.db #0x5a	; 90	'Z'
      00BF3A 1B                    2472 	.db #0x1b	; 27
      00BF3B 75                    2473 	.db #0x75	; 117	'u'
      00BF3C 0A                    2474 	.db #0x0a	; 10
                                   2475 	.area CSEG    (CODE)
                                   2476 	.area XINIT   (CODE)
                                   2477 	.area CABS    (ABS,CODE)
                                   2478 
                                   2479 ; Experimental exact instruction outlining.
                                   2480 	.globl _ak820_outline_0006
                                   2481 	.globl _ak820_outline_0020
                                   2482 	.globl _ak820_outline_0052
                                   2483 	.globl _ak820_outline_0053
                                   2484 	.globl _ak820_outline_0056
                                   2485 	.globl _ak820_outline_0064
                                   2486 	.globl _ak820_outline_0065
                                   2487 	.globl _ak820_outline_0070
                                   2488 	.globl _ak820_outline_0075
                                   2489 	.globl _ak820_outline_0076
                                   2490 	.globl _ak820_outline_0087
                                   2491 	.globl _ak820_outline_0108
                                   2492 	.globl _ak820_outline_0109
                                   2493 	.globl _ak820_outline_0113
                                   2494 	.globl _ak820_outline_0120
                                   2495 	.globl _ak820_outline_0126
                                   2496 	.globl _ak820_outline_0127
                                   2497 	.globl _ak820_outline_0129
                                   2498 	.globl _ak820_outline_0132
                                   2499 	.globl _ak820_outline_0140
                                   2500 	.globl _ak820_outline_0141
                                   2501 	.globl _ak820_outline_0146
                                   2502 	.globl _ak820_outline_0150
                                   2503 	.globl _ak820_outline_0177
                                   2504 	.globl _ak820_outline_0179
                                   2505 	.globl _ak820_outline_0180
                                   2506 	.globl _ak820_outline_0186
                                   2507 	.globl _ak820_outline_0192
                                   2508 	.globl _ak820_outline_0193
                                   2509 
                                   2510 	.area CSEG (CODE)
                                   2511 ; function ak820_outline_0020
      005B71                       2512 _ak820_outline_0020:
      005B71 90 07 0C         [24] 2513 	mov	dptr,#_rgb_matrix_config
      005B74 E0               [24] 2514 	movx	a,@dptr
      005B75 03               [12] 2515 	rr	a
      005B76 03               [12] 2516 	rr	a
      005B77 54 3F            [12] 2517 	anl	a,#0x3f
      005B79 22               [24] 2518 	ret
                                   2519 
                                   2520 	.area CSEG (CODE)
                                   2521 ; function ak820_outline_0052
      005B7A                       2522 _ak820_outline_0052:
      005B7A E0               [24] 2523 	movx	a,@dptr
      005B7B FF               [12] 2524 	mov	r7,a
      005B7C 90 07 75         [24] 2525 	mov	dptr,#_add_sat_PARM_2
      005B7F 74 10            [12] 2526 	mov	a,#0x10
      005B81 F0               [24] 2527 	movx	@dptr,a
      005B82 8F 82            [24] 2528 	mov	dpl,r7
      005B84 22               [24] 2529 	ret
                                   2530 
                                   2531 	.area CSEG (CODE)
                                   2532 ; function ak820_outline_0053
      005B85                       2533 _ak820_outline_0053:
      005B85 E0               [24] 2534 	movx	a,@dptr
      005B86 FF               [12] 2535 	mov	r7,a
      005B87 90 07 77         [24] 2536 	mov	dptr,#_sub_sat_PARM_2
      005B8A 74 10            [12] 2537 	mov	a,#0x10
      005B8C F0               [24] 2538 	movx	@dptr,a
      005B8D 8F 82            [24] 2539 	mov	dpl,r7
      005B8F 22               [24] 2540 	ret
                                   2541 
                                   2542 	.area CSEG (CODE)
                                   2543 ; function ak820_outline_0070
      005B90                       2544 _ak820_outline_0070:
      005B90 90 07 0C         [24] 2545 	mov	dptr,#_rgb_matrix_config
      005B93 E0               [24] 2546 	movx	a,@dptr
      005B94 54 03            [12] 2547 	anl	a,#0x03
      005B96 22               [24] 2548 	ret
                                   2549 
                                   2550 	.area CSEG (CODE)
                                   2551 ; function ak820_outline_0075
      005B97                       2552 _ak820_outline_0075:
      005B97 74 08            [12] 2553 	mov	a,#0x08
      005B99 F0               [24] 2554 	movx	@dptr,a
      005B9A E4               [12] 2555 	clr	a
      005B9B A3               [24] 2556 	inc	dptr
      005B9C F0               [24] 2557 	movx	@dptr,a
      005B9D 90 07 0C         [24] 2558 	mov	dptr,#_rgb_matrix_config
      005BA0 22               [24] 2559 	ret
                                   2560 
                                   2561 	.area CSEG (CODE)
                                   2562 ; function ak820_outline_0087
      005BA1                       2563 _ak820_outline_0087:
      005BA1 74 18            [12] 2564 	mov	a,#0x18
      005BA3 F0               [24] 2565 	movx	@dptr,a
      005BA4 E4               [12] 2566 	clr	a
      005BA5 A3               [24] 2567 	inc	dptr
      005BA6 F0               [24] 2568 	movx	@dptr,a
      005BA7 A3               [24] 2569 	inc	dptr
      005BA8 F0               [24] 2570 	movx	@dptr,a
      005BA9 22               [24] 2571 	ret
                                   2572 
                                   2573 	.area CSEG (CODE)
                                   2574 ; function ak820_outline_0113
      005BAA                       2575 _ak820_outline_0113:
      005BAA 35 F0            [12] 2576 	addc	a,b
      005BAC F5 83            [12] 2577 	mov	dph,a
      005BAE E4               [12] 2578 	clr	a
      005BAF 93               [24] 2579 	movc	a,@a+dptr
      005BB0 22               [24] 2580 	ret
                                   2581 
                                   2582 	.area CSEG (CODE)
                                   2583 ; function ak820_outline_0120
      005BB1                       2584 _ak820_outline_0120:
      005BB1 90 07 0C         [24] 2585 	mov	dptr,#_rgb_matrix_config
      005BB4 E0               [24] 2586 	movx	a,@dptr
      005BB5 54 FC            [12] 2587 	anl	a,#0xfc
      005BB7 22               [24] 2588 	ret
                                   2589 
                                   2590 	.area CSEG (CODE)
                                   2591 ; function ak820_outline_0146
      005BB8                       2592 _ak820_outline_0146:
      005BB8 90 07 1B         [24] 2593 	mov	dptr,#_frame_mode
      005BBB E0               [24] 2594 	movx	a,@dptr
      005BBC FE               [12] 2595 	mov	r6,a
      005BBD 22               [24] 2596 	ret
                                   2597 
                                   2598 	.area CSEG (CODE)
                                   2599 ; function ak820_outline_0177
      005BBE                       2600 _ak820_outline_0177:
      005BBE F0               [24] 2601 	movx	@dptr,a
      005BBF E5 F0            [12] 2602 	mov	a,b
      005BC1 A3               [24] 2603 	inc	dptr
      005BC2 F0               [24] 2604 	movx	@dptr,a
      005BC3 22               [24] 2605 	ret
                                   2606 
                                   2607 	.area CSEG (CODE)
                                   2608 ; function ak820_outline_0179
      005BC4                       2609 _ak820_outline_0179:
      005BC4 F0               [24] 2610 	movx	@dptr,a
      005BC5 E0               [24] 2611 	movx	a,@dptr
      005BC6 F5 82            [12] 2612 	mov	dpl,a
      005BC8 22               [24] 2613 	ret
                                   2614 
                                   2615 	.area CSEG (CODE)
                                   2616 ; function ak820_outline_0180
      005BC9                       2617 _ak820_outline_0180:
      005BC9 90 07 10         [24] 2618 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005BCC E0               [24] 2619 	movx	a,@dptr
      005BCD 23               [12] 2620 	rl	a
      005BCE 23               [12] 2621 	rl	a
      005BCF 54 03            [12] 2622 	anl	a,#0x03
      005BD1 22               [24] 2623 	ret
                                   2624 
                                   2625 	.area CSEG (CODE)
                                   2626 ; function ak820_outline_0186
      005BD2                       2627 _ak820_outline_0186:
      005BD2 90 0E 29         [24] 2628 	mov	dptr,#_memset_PARM_2
      005BD5 E4               [12] 2629 	clr	a
      005BD6 F0               [24] 2630 	movx	@dptr,a
      005BD7 90 0E 2A         [24] 2631 	mov	dptr,#_memset_PARM_3
      005BDA 22               [24] 2632 	ret
                                   2633 
                                   2634 	.area CSEG (CODE)
                                   2635 ; function ak820_outline_0192
      005BDB                       2636 _ak820_outline_0192:
      005BDB 90 07 1A         [24] 2637 	mov	dptr,#_led_index
      005BDE E0               [24] 2638 	movx	a,@dptr
      005BDF 22               [24] 2639 	ret
