;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_key_override
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dynamic_keymap_get_key_override
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_key_override_process_PARM_3
	.globl _ak820_key_override_process_PARM_2
	.globl _ak820_key_override_sync_PARM_2
	.globl _ak820_key_override_valid
	.globl _ak820_key_override_cancel
	.globl _ak820_key_override_reload
	.globl _ak820_key_override_sync
	.globl _ak820_key_override_process
	.globl _ak820_key_override_key
	.globl _ak820_key_override_mods
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_ak820_key_override_process_sloc0_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_ak820_key_override_valid_sloc0_1_0:
	.ds 1
_eligible_sloc0_1_0:
	.ds 1
_activate_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_entries:
	.ds 80
_trigger:
	.ds 1
_previous_mods:
	.ds 1
_current_mods:
	.ds 1
_current_layer:
	.ds 1
_blocked:
	.ds 1
_hidden:
	.ds 1
_ak820_key_override_valid_e_10000_597:
	.ds 2
_ak820_key_override_valid_any_10000_598:
	.ds 1
_eligible_index_10000_605:
	.ds 1
_activate_trigger_down_10000_619:
	.ds 1
_activate_e_30000_623:
	.ds 2
_ak820_key_override_sync_PARM_2:
	.ds 1
_ak820_key_override_sync_mods_10000_626:
	.ds 1
_ak820_key_override_process_PARM_2:
	.ds 1
_ak820_key_override_process_PARM_3:
	.ds 1
_ak820_key_override_process_record_10000_629:
	.ds 2
_ak820_key_override_mods_mods_10000_654:
	.ds 1
_ak820_key_override_mods_replacement_10000_655:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_source:
	.ds 1
_active:
	.ds 1
_enabled:
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function ak820_key_override_valid
;	-----------------------------------------
_ak820_key_override_valid:
	lcall	_ak820_outline_0108
	mov	dptr,#_ak820_key_override_valid_e_10000_597
	lcall	_ak820_outline_0109
;	keyboards/ajazz/ak820/ak820_key_override.c:20: const uint8_t AK820_STATE_MEM *bytes = (const uint8_t AK820_STATE_MEM *)e;
	mov	dptr,#_ak820_key_override_valid_e_10000_597
	lcall	_ak820_outline_0056
;	keyboards/ajazz/ak820/ak820_key_override.c:21: uint8_t any = 0;
	mov	dptr,#_ak820_key_override_valid_any_10000_598
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:24: for (uint8_t i = 0; i < 10; ++i) any |= bytes[i];
	mov	r5,a
00118$:
	cjne	r5,#0x0a,00206$
00206$:
	jnc	00101$
	mov	a,r5
	lcall	_ak820_outline_0013
	mov	r4,a
	mov	dptr,#_ak820_key_override_valid_any_10000_598
	movx	a,@dptr
	orl	a,r4
	movx	@dptr,a
	inc	r5
	sjmp	00118$
00101$:
;	keyboards/ajazz/ak820/ak820_key_override.c:25: if (!any) return true;
	mov	dptr,#_ak820_key_override_valid_any_10000_598
	movx	a,@dptr
	jnz	00103$
	mov	dpl, #0x01
	ret
00103$:
;	keyboards/ajazz/ak820/ak820_key_override.c:26: if (bytes[1] || !basic(bytes[0])) return false;
	mov	a,#0x01
	lcall	_ak820_outline_0009
	jnz	00104$
	lcall	_ak820_outline_0098
	mov	r5,a
	cjne	r5,#0x04,00210$
00210$:
	jc	00104$
	mov	a,r5
	add	a,#0xff - 0xa4
	jnc	00105$
;	free result
00104$:
	mov	dpl, #0x00
	ret
00105$:
;	keyboards/ajazz/ak820/ak820_key_override.c:27: if (bytes[5] || !bytes[4] || (bytes[4] & 0xC0)) return false;
	mov	a,#0x05
	lcall	_ak820_outline_0009
	jnz	00108$
	lcall	_ak820_outline_0017
	mov	r5,a
	jz	00108$
	mov	a,r5
	anl	a,#0xc0
	jz	00109$
00108$:
	mov	dpl, #0x00
	ret
00109$:
;	keyboards/ajazz/ak820/ak820_key_override.c:28: if ((bytes[9] & 0x40) || !(bytes[9] & ACTIVATIONS)) return false;
	mov	a,#0x09
	lcall	_ak820_outline_0013
	mov	r5,a
	jb	acc.6,00112$
	mov	a,r5
	anl	a,#0x07
	jnz	00113$
00112$:
	mov	dpl, #0x00
	ret
00113$:
;	keyboards/ajazz/ak820/ak820_key_override.c:30: if (bytes[2] | bytes[3]) return bytes[3] < 32 && basic(bytes[2]);
	lcall	_ak820_outline_0032
	mov	r5,a
	lcall	_ak820_outline_0015
	mov	r7,a
	orl	a,r5
	jz	00116$
	cjne	r7,#0x20,00220$
00220$:
	jnc	00122$
	cjne	r5,#0x04,00222$
00222$:
	jc	00122$
	mov	a,r5
	add	a,#0xff - 0xa4
	jnc	00123$
;	free result
00122$:
;	assignBit
	clr	_ak820_key_override_valid_sloc0_1_0
	sjmp	00124$
00123$:
;	assignBit
	setb	_ak820_key_override_valid_sloc0_1_0
00124$:
	mov	c,_ak820_key_override_valid_sloc0_1_0
	lcall	_ak820_outline_0150
	ret
00116$:
;	keyboards/ajazz/ak820/ak820_key_override.c:31: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_key_override.c:32: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eligible'
;------------------------------------------------------------
;index         Allocated with name '_eligible_index_10000_605'
;e             Allocated with name '_eligible_e_10000_606'
;low           Allocated with name '_eligible_low_10000_606'
;high          Allocated with name '_eligible_high_10000_606'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:34: static bool eligible(uint8_t index) {
;	-----------------------------------------
;	 function eligible
;	-----------------------------------------
_eligible:
	mov	a,dpl
	mov	dptr,#_eligible_index_10000_605
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:35: vial_key_override_entry_t AK820_STATE_MEM *e = &entries[index];
	movx	a,@dptr
	lcall	_ak820_outline_0016
;	keyboards/ajazz/ak820/ak820_key_override.c:36: uint8_t low = e->trigger_mods & 15, high = e->trigger_mods >> 4;
	mov	a,#0x06
	lcall	_ak820_outline_0013
	mov	r5,a
	mov	a,#0x0f
	anl	a,r5
	mov	r4,a
	mov	a,r5
	swap	a
	anl	a,#0x0f
	mov	r3,a
;	keyboards/ajazz/ak820/ak820_key_override.c:37: if (current_layer >= 6 || !((uint8_t)e->layers & ((uint8_t)1 << current_layer)) ||
	mov	dptr,#_current_layer
	movx	a,@dptr
	mov	r2,a
	cjne	r2,#0x06,00147$
00147$:
	jnc	00101$
	push	ar3
	lcall	_ak820_outline_0017
	mov	r1,a
	mov	b,r2
	inc	b
	mov	r0,#0x01
	mov	r2,#0x00
	sjmp	00150$
00149$:
	mov	a,r0
	add	a,r0
	mov	r0,a
	mov	a,r2
	rlc	a
	mov	r2,a
00150$:
	djnz	b,00149$
	mov	r3,#0x00
	mov	a,r1
	anl	ar0,a
	mov	a,r3
	anl	ar2,a
	pop	ar3
	mov	a,r0
	orl	a,r2
	jz	00101$
;	keyboards/ajazz/ak820/ak820_key_override.c:38: (current_mods & e->negative_mod_mask)) return false;
	mov	a,#0x07
	lcall	_ak820_outline_0013
	mov	r2,a
	mov	dptr,#_current_mods
	movx	a,@dptr
	mov	r1,a
	mov	a,r2
	anl	a,r1
	jz	00102$
00101$:
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:39: if (e->options & 8) return !(low | high) || (current_mods & e->trigger_mods);
	mov	a,#0x09
	lcall	_ak820_outline_0013
	jnb	acc.3,00106$
	mov	a,r3
	orl	a,r4
	jz	00110$
	mov	a,r5
	anl	a,r1
	jnz	00110$
;	assignBit
	clr	_eligible_sloc0_1_0
	sjmp	00111$
00110$:
;	assignBit
	setb	_eligible_sloc0_1_0
00111$:
	mov	c,_eligible_sloc0_1_0
	lcall	_ak820_outline_0150
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_key_override.c:40: return ((current_mods & low) | ((current_mods >> 4) & high)) == (low | high);
	mov	a,r4
	anl	a,r1
	mov	r7,a
	mov	a,r1
	swap	a
	anl	a,#0x0f
	mov	r1,a
	mov	a,r3
	anl	a,r1
	orl	ar7,a
	mov	a,r3
	orl	ar4,a
	mov	a,r7
	cjne	a,ar4,00156$
	setb	c
	sjmp	00157$
00156$:
	clr	c
00157$:
	mov  _eligible_sloc0_1_0,c
	lcall	_ak820_outline_0150
;	keyboards/ajazz/ak820/ak820_key_override.c:41: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'deactivate'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:42: static void deactivate(void) {
;	-----------------------------------------
;	 function deactivate
;	-----------------------------------------
_deactivate:
;	keyboards/ajazz/ak820/ak820_key_override.c:43: if (active != NONE && (entries[active].options & 16)) hidden = true;
	lcall	_ak820_outline_0128
	cjne	r7,#0xff,00120$
	sjmp	00102$
00120$:
	mov	a,r7
	lcall	_ak820_outline_0016
	mov	a,#0x09
	lcall	_ak820_outline_0013
	jnb	acc.4,00102$
	mov	dptr,#_hidden
	mov	a,#0x01
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:44: active = NONE;
	mov	dptr,#_active
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:45: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_cancel'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:46: void ak820_key_override_cancel(void) {
;	-----------------------------------------
;	 function ak820_key_override_cancel
;	-----------------------------------------
_ak820_key_override_cancel:
;	keyboards/ajazz/ak820/ak820_key_override.c:47: source = active = NONE;
	mov	dptr,#_active
	mov	a,#0xff
	movx	@dptr,a
	mov	dptr,#_source
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:48: previous_mods = 0;
	mov	dptr,#_previous_mods
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:49: blocked = hidden = false;
	mov	dptr,#_hidden
	movx	@dptr,a
	mov	dptr,#_blocked
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:50: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_reload'
;------------------------------------------------------------
;i             Allocated with name '_ak820_key_override_reload_i_20000_616'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:51: void ak820_key_override_reload(void) {
;	-----------------------------------------
;	 function ak820_key_override_reload
;	-----------------------------------------
_ak820_key_override_reload:
;	keyboards/ajazz/ak820/ak820_key_override.c:52: ak820_key_override_cancel();
	lcall	_ak820_key_override_cancel
;	keyboards/ajazz/ak820/ak820_key_override.c:53: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	mov	r7,#0x00
00105$:
	cjne	r7,#0x08,00131$
00131$:
	jnc	00107$
;	keyboards/ajazz/ak820/ak820_key_override.c:55: if (dynamic_keymap_get_key_override(i, &entries[i]))
	lcall	_ak820_outline_0101
	mov	r6,a
	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	lcall	_ak820_outline_0076
	mov	dpl, r7
	push	ar7
	push	ar6
	push	ar5
	lcall	_dynamic_keymap_get_key_override
	lcall	_ak820_outline_0127
	pop	ar5
	pop	ar6
	pop	ar7
	orl	a,b
	jz	00106$
;	keyboards/ajazz/ak820/ak820_key_override.c:56: entries[i].options = 0;
	mov	a,#0x09
	add	a, r5
	lcall	_ak820_outline_0117
	clr	a
	movx	@dptr,a
00106$:
;	keyboards/ajazz/ak820/ak820_key_override.c:53: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	inc	r7
	sjmp	00105$
00107$:
;	keyboards/ajazz/ak820/ak820_key_override.c:58: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'activate'
;------------------------------------------------------------
;trigger_down  Allocated with name '_activate_trigger_down_10000_619'
;i             Allocated with name '_activate_i_20000_622'
;e             Allocated with name '_activate_e_30000_623'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:59: static void activate(bool trigger_down) {
;	-----------------------------------------
;	 function activate
;	-----------------------------------------
_activate:
	mov	a,dpl
	mov	dptr,#_activate_trigger_down_10000_619
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:60: if (!enabled || source == NONE || blocked || hidden || active != NONE) return;
	mov	dptr,#_enabled
	movx	a,@dptr
	jz	00101$
	mov	dptr,#_source
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00221$
	ret
00221$:
	mov	dptr,#_blocked
	movx	a,@dptr
	jnz	00101$
	mov	dptr,#_hidden
	movx	a,@dptr
	jnz	00101$
	lcall	_ak820_outline_0128
	cjne	r7,#0xff,00224$
	sjmp	00154$
00224$:
00101$:
	ret
;	keyboards/ajazz/ak820/ak820_key_override.c:61: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
00154$:
	mov	dptr,#_activate_trigger_down_10000_619
	movx	a,@dptr
	mov	r7,a
	mov	r6,#0x00
00114$:
	cjne	r6,#0x08,00225$
00225$:
	jc	00226$
	ret
00226$:
;	keyboards/ajazz/ak820/ak820_key_override.c:62: vial_key_override_entry_t AK820_STATE_MEM *e = &entries[i];
	mov	a,r6
	lcall	_ak820_outline_0194
	add	a, #_entries
	mov	r4,a
	mov	a,#(_entries >> 8)
	addc	a, b
	mov	r5,a
	mov	dptr,#_activate_e_30000_623
	lcall	_ak820_outline_0078
;	keyboards/ajazz/ak820/ak820_key_override.c:63: if ((uint8_t)e->trigger == trigger && (e->options & ENABLED) && (trigger_down ? (e->options & 1) :
	lcall	_ak820_outline_0081
	mov	r3,a
	mov	dptr,#_trigger
	movx	a,@dptr
	mov	r2,a
	mov	a,r3
	cjne	a,ar2,00227$
	sjmp	00228$
00227$:
	ljmp	00115$
00228$:
	mov	a,#0x09
	lcall	_ak820_outline_0042
	mov	r3,a
	jb	acc.7,00229$
	ljmp	00115$
00229$:
	mov	a,r7
	jz	00118$
	mov	ar2,r3
	anl	ar2,#0x01
	ljmp	00119$
00118$:
;	keyboards/ajazz/ak820/ak820_key_override.c:64: (((e->options & 2) && (e->trigger_mods & current_mods & ~previous_mods)) ||
	mov	a,r3
	rr	a
	anl	a,#0x01
	jz	00125$
	mov	a,#0x06
	lcall	_ak820_outline_0042
	mov	r5,a
	mov	dptr,#_current_mods
	movx	a,@dptr
	anl	ar5,a
	mov	dptr,#_previous_mods
	lcall	_ak820_outline_0036
	jnz	00121$
00125$:
;	keyboards/ajazz/ak820/ak820_key_override.c:65: ((e->options & 4) && (e->negative_mod_mask & previous_mods & ~current_mods)))) && eligible(i)) {
	mov	dptr,#_activate_e_30000_623
	lcall	_ak820_outline_0065
	mov	a,#0x09
	lcall	_ak820_outline_0042
	rr	a
	rr	a
	anl	a,#0x01
	jz	00120$
	mov	a,#0x07
	lcall	_ak820_outline_0042
	mov	r5,a
	mov	dptr,#_previous_mods
	movx	a,@dptr
	anl	ar5,a
	mov	dptr,#_current_mods
	lcall	_ak820_outline_0036
	jnz	00121$
00120$:
;	assignBit
	clr	_activate_sloc0_1_0
	sjmp	00122$
00121$:
;	assignBit
	setb	_activate_sloc0_1_0
00122$:
	mov	c,_activate_sloc0_1_0
	clr	a
	rlc	a
	mov	r2,a
00119$:
	mov	a,r2
	jz	00115$
	mov	dpl, r6
	push	ar7
	push	ar6
	lcall	_eligible
	mov	a, dpl
	pop	ar6
	pop	ar7
	jz	00115$
;	keyboards/ajazz/ak820/ak820_key_override.c:66: active = i;
	mov	dptr,#_active
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:67: return;
	ret
00115$:
;	keyboards/ajazz/ak820/ak820_key_override.c:61: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	inc	r6
;	keyboards/ajazz/ak820/ak820_key_override.c:70: }
	ljmp	00114$
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_sync'
;------------------------------------------------------------
;layer         Allocated with name '_ak820_key_override_sync_PARM_2'
;mods          Allocated with name '_ak820_key_override_sync_mods_10000_626'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:71: void ak820_key_override_sync(uint8_t mods, uint8_t layer) {
;	-----------------------------------------
;	 function ak820_key_override_sync
;	-----------------------------------------
_ak820_key_override_sync:
	mov	a,dpl
	mov	dptr,#_ak820_key_override_sync_mods_10000_626
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:72: current_mods = mods; current_layer = layer;
	movx	a,@dptr
	mov	dptr,#_current_mods
	movx	@dptr,a
	mov	dptr,#_ak820_key_override_sync_PARM_2
	movx	a,@dptr
	mov	dptr,#_current_layer
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:73: if (active != NONE && !eligible(active)) deactivate();
	lcall	_ak820_outline_0128
	cjne	r7,#0xff,00120$
	sjmp	00102$
00120$:
	mov	dpl, r7
	lcall	_eligible
	mov	a, dpl
	jnz	00102$
	lcall	_deactivate
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:74: activate(false);
	mov	dpl, #0x00
	lcall	_activate
;	keyboards/ajazz/ak820/ak820_key_override.c:75: previous_mods = mods;
	mov	dptr,#_ak820_key_override_sync_mods_10000_626
	movx	a,@dptr
	mov	dptr,#_previous_mods
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:76: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_process'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_key_override_process_sloc0_1_0'
;mods          Allocated with name '_ak820_key_override_process_PARM_2'
;layer         Allocated with name '_ak820_key_override_process_PARM_3'
;record        Allocated with name '_ak820_key_override_process_record_10000_629'
;key           Allocated with name '_ak820_key_override_process_key_10000_630'
;id            Allocated with name '_ak820_key_override_process_id_10000_630'
;i             Allocated with name '_ak820_key_override_process_i_20000_647'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:77: bool ak820_key_override_process(keyrecord_t AK820_STATE_MEM *record, uint8_t mods, uint8_t layer) {
;	-----------------------------------------
;	 function ak820_key_override_process
;	-----------------------------------------
_ak820_key_override_process:
	lcall	_ak820_outline_0108
	mov	dptr,#_ak820_key_override_process_record_10000_629
	lcall	_ak820_outline_0109
;	keyboards/ajazz/ak820/ak820_key_override.c:78: uint16_t key = record->keycode;
	mov	dptr,#_ak820_key_override_process_record_10000_629
	lcall	_ak820_outline_0001
;	keyboards/ajazz/ak820/ak820_key_override.c:80: ak820_key_override_sync(mods, layer);
	mov	dptr,#_ak820_key_override_process_PARM_2
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_ak820_key_override_process_PARM_3
	movx	a,@dptr
	mov	dptr,#_ak820_key_override_sync_PARM_2
	movx	@dptr,a
	mov	dpl, r3
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_ak820_key_override_sync
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_key_override.c:81: if (key >= QK_KEY_OVERRIDE_TOGGLE && key <= QK_KEY_OVERRIDE_OFF) {
	mov	ar2,r4
	mov	ar3,r5
	clr	c
	mov	a,r2
	subb	a,#0x5d
	mov	a,r3
	subb	a,#0x7c
	jc	00112$
	mov	a,#0x5f
	subb	a,r2
	mov	a,#0x7c
	subb	a,r3
	jc	00112$
;	free result
;	keyboards/ajazz/ak820/ak820_key_override.c:82: if (record->event.pressed) {
	lcall	_ak820_outline_0004
	jz	00110$
;	keyboards/ajazz/ak820/ak820_key_override.c:83: if (key == QK_KEY_OVERRIDE_ON) enabled = true;
	cjne	r2,#0x5e,00105$
	cjne	r3,#0x7c,00105$
	mov	dptr,#_enabled
	mov	a,#0x01
	movx	@dptr,a
	sjmp	00106$
00105$:
;	keyboards/ajazz/ak820/ak820_key_override.c:84: else if (key == QK_KEY_OVERRIDE_OFF) enabled = false;
	cjne	r2,#0x5f,00102$
	cjne	r3,#0x7c,00102$
	mov	dptr,#_enabled
	clr	a
	movx	@dptr,a
	sjmp	00106$
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:85: else enabled = !enabled;
	mov	dptr,#_enabled
	movx	a,@dptr
	cjne	a,#0x01,00289$
00289$:
	clr	a
	rlc	a
	movx	@dptr,a
00106$:
;	keyboards/ajazz/ak820/ak820_key_override.c:86: if (!enabled) { deactivate(); blocked = true; }
	mov	dptr,#_enabled
	movx	a,@dptr
	jnz	00110$
	lcall	_deactivate
	mov	dptr,#_blocked
	mov	a,#0x01
	movx	@dptr,a
00110$:
;	keyboards/ajazz/ak820/ak820_key_override.c:88: return false;
	mov	dpl, #0x00
	ret
00112$:
;	keyboards/ajazz/ak820/ak820_key_override.c:90: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) return true;
	mov	dptr,#_ak820_key_override_process_record_10000_629
	movx	a,@dptr
	mov	_ak820_key_override_process_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_key_override_process_sloc0_1_0 + 1),a
	mov	dpl,_ak820_key_override_process_sloc0_1_0
	mov	dph,(_ak820_key_override_process_sloc0_1_0 + 1)
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	cjne	r1,#0x10,00291$
00291$:
	jnc	00114$
	mov	dpl,_ak820_key_override_process_sloc0_1_0
	mov	dph,(_ak820_key_override_process_sloc0_1_0 + 1)
	movx	a,@dptr
	mov	r0,a
	cjne	r0,#0x08,00293$
00293$:
	jc	00115$
00114$:
	mov	dpl, #0x01
	ret
00115$:
;	keyboards/ajazz/ak820/ak820_key_override.c:91: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
	mov	a,r1
	lcall	_ak820_outline_0193
	add	a,r0
	mov	r1,a
;	keyboards/ajazz/ak820/ak820_key_override.c:92: if (source == id) {
	mov	dptr,#_source
	movx	a,@dptr
	cjne	a,ar1,00120$
;	keyboards/ajazz/ak820/ak820_key_override.c:93: if (!record->event.pressed) ak820_key_override_cancel();
	mov	a,#0x05
	add	a, _ak820_key_override_process_sloc0_1_0
	mov	r0,a
	clr	a
	addc	a, (_ak820_key_override_process_sloc0_1_0 + 1)
	mov	r7,a
	mov	dpl,r0
	mov	dph,r7
	movx	a,@dptr
	jnz	00118$
	lcall	_ak820_key_override_cancel
00118$:
;	keyboards/ajazz/ak820/ak820_key_override.c:94: return false;
	mov	dpl, #0x00
	ret
00120$:
;	keyboards/ajazz/ak820/ak820_key_override.c:96: if (!record->event.pressed) return true;
	mov	a,#0x05
	add	a, _ak820_key_override_process_sloc0_1_0
	mov	r6,a
	clr	a
	addc	a, (_ak820_key_override_process_sloc0_1_0 + 1)
	mov	r7,a
	lcall	_ak820_outline_0098
	jnz	00122$
	mov	dpl, #0x01
	ret
00122$:
;	keyboards/ajazz/ak820/ak820_key_override.c:97: if (active != NONE && !(entries[active].options & 32) && !(key >= KC_LEFT_CTRL && key <= KC_RIGHT_GUI)) {
	lcall	_ak820_outline_0128
	cjne	r7,#0xff,00299$
	sjmp	00124$
00299$:
	mov	a,r7
	lcall	_ak820_outline_0016
	mov	a,#0x09
	lcall	_ak820_outline_0013
	jb	acc.5,00124$
	clr	c
	mov	a,r2
	subb	a,#0xe0
	mov	a,r3
	subb	a,#0x00
	jc	00123$
	mov	a,#0xe7
	subb	a,r2
	clr	a
	subb	a,r3
	jnc	00124$
;	free result
00123$:
;	keyboards/ajazz/ak820/ak820_key_override.c:98: deactivate(); blocked = true;
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	lcall	_deactivate
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	mov	dptr,#_blocked
	mov	a,#0x01
	movx	@dptr,a
00124$:
;	keyboards/ajazz/ak820/ak820_key_override.c:100: if (source != NONE || !enabled || !basic(key)) return true;
	mov	dptr,#_source
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00128$
	mov	dptr,#_enabled
	movx	a,@dptr
	jz	00128$
	clr	c
	mov	a,r2
	subb	a,#0x04
	mov	a,r3
	subb	a,#0x00
	jc	00128$
	mov	a,#0xa4
	subb	a,r2
	clr	a
	subb	a,r3
	jnc	00181$
;	free result
00128$:
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_key_override.c:101: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	ret
00181$:
	mov	r7,#0x00
00138$:
	cjne	r7,#0x08,00308$
00308$:
	jnc	00136$
;	keyboards/ajazz/ak820/ak820_key_override.c:102: if ((uint8_t)entries[i].trigger == (uint8_t)key && (entries[i].options & ENABLED)) {
	mov	a,r7
	lcall	_ak820_outline_0194
	add	a, #_entries
	mov	r3,a
	mov	a,#(_entries >> 8)
	addc	a, b
	mov	r6,a
	mov	dpl,r3
	mov	dph,r6
	movx	a,@dptr
	mov	ar0,r4
	cjne	a,ar0,00139$
	mov	a,#0x09
	add	a, r3
	lcall	_ak820_outline_0117
	movx	a,@dptr
	jnb	acc.7,00139$
;	keyboards/ajazz/ak820/ak820_key_override.c:103: source = id; trigger = key; hidden = blocked = false;
	mov	dptr,#_source
	mov	a,r1
	movx	@dptr,a
	mov	dptr,#_trigger
	mov	a,r0
	movx	@dptr,a
	mov	dptr,#_blocked
	clr	a
	movx	@dptr,a
	mov	dptr,#_hidden
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:104: activate(true);
	mov	dpl, #0x01
	lcall	_activate
;	keyboards/ajazz/ak820/ak820_key_override.c:105: return false;
	mov	dpl, #0x00
	ret
00139$:
;	keyboards/ajazz/ak820/ak820_key_override.c:101: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	inc	r7
	sjmp	00138$
00136$:
;	keyboards/ajazz/ak820/ak820_key_override.c:108: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_key_override.c:109: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_key'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:110: uint8_t ak820_key_override_key(void) {
;	-----------------------------------------
;	 function ak820_key_override_key
;	-----------------------------------------
_ak820_key_override_key:
;	keyboards/ajazz/ak820/ak820_key_override.c:111: if (source == NONE || hidden) return 0;
	mov	dptr,#_source
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00122$
	sjmp	00101$
00122$:
	mov	dptr,#_hidden
	movx	a,@dptr
	jz	00102$
00101$:
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:112: return active == NONE ? trigger : (uint8_t)entries[active].replacement;
	lcall	_ak820_outline_0128
	cjne	r7,#0xff,00106$
	mov	dptr,#_trigger
	movx	a,@dptr
	mov	r6,a
	sjmp	00107$
00106$:
	lcall	_ak820_outline_0101
	mov	r7,a
	lcall	_ak820_outline_0190
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r6,a
00107$:
	mov	dpl, r6
;	keyboards/ajazz/ak820/ak820_key_override.c:113: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_mods'
;------------------------------------------------------------
;mods          Allocated with name '_ak820_key_override_mods_mods_10000_654'
;replacement   Allocated with name '_ak820_key_override_mods_replacement_10000_655'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:114: uint8_t ak820_key_override_mods(uint8_t mods) {
;	-----------------------------------------
;	 function ak820_key_override_mods
;	-----------------------------------------
_ak820_key_override_mods:
	mov	a,dpl
	mov	dptr,#_ak820_key_override_mods_mods_10000_654
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:116: if (active == NONE) return mods;
	lcall	_ak820_outline_0128
	cjne	r7,#0xff,00102$
	mov	dptr,#_ak820_key_override_mods_mods_10000_654
	movx	a,@dptr
	mov	dpl,a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:117: replacement = entries[active].replacement >> 8;
	mov	a,r7
	lcall	_ak820_outline_0016
	lcall	_ak820_outline_0032
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_ak820_key_override_mods_replacement_10000_655
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:118: if (replacement & 16) replacement = (replacement & 15) << 4;
	mov	a,r5
	jnb	acc.4,00104$
	anl	ar5,#0x0f
	mov	a,r5
	swap	a
	anl	a,#0xf0
	mov	dptr,#_ak820_key_override_mods_replacement_10000_655
	movx	@dptr,a
00104$:
;	keyboards/ajazz/ak820/ak820_key_override.c:119: return (mods & ~entries[active].suppressed_mods) | replacement;
	mov	a,#0x08
	lcall	_ak820_outline_0013
	mov	r7,a
	xrl	ar7,#0xff
	mov	dptr,#_ak820_key_override_mods_mods_10000_654
	movx	a,@dptr
	anl	ar7,a
	mov	dptr,#_ak820_key_override_mods_replacement_10000_655
	lcall	_ak820_outline_0130
;	keyboards/ajazz/ak820/ak820_key_override.c:120: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_enabled'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:121: bool ak820_key_override_enabled(void) { return enabled; }
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__source:
	.db #0xff	; 255
__xinit__active:
	.db #0xff	; 255
__xinit__enabled:
	.db #0x01	;  1
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0001
	.globl _ak820_outline_0004
	.globl _ak820_outline_0009
	.globl _ak820_outline_0013
	.globl _ak820_outline_0015
	.globl _ak820_outline_0016
	.globl _ak820_outline_0017
	.globl _ak820_outline_0032
	.globl _ak820_outline_0036
	.globl _ak820_outline_0042
	.globl _ak820_outline_0056
	.globl _ak820_outline_0065
	.globl _ak820_outline_0076
	.globl _ak820_outline_0078
	.globl _ak820_outline_0081
	.globl _ak820_outline_0098
	.globl _ak820_outline_0101
	.globl _ak820_outline_0108
	.globl _ak820_outline_0109
	.globl _ak820_outline_0117
	.globl _ak820_outline_0127
	.globl _ak820_outline_0128
	.globl _ak820_outline_0130
	.globl _ak820_outline_0150
	.globl _ak820_outline_0190
	.globl _ak820_outline_0193
	.globl _ak820_outline_0194

	.area CSEG (CODE)
; function ak820_outline_0009
_ak820_outline_0009:
	add	a,r6
	mov	r4,a
	clr	a
	addc	a,r7
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0015
_ak820_outline_0015:
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0016
_ak820_outline_0016:
	mov	b,#0x0a
	mul	ab
	add	a,#_entries
	mov	r6,a
	mov	a,#(_entries>>8)
	addc	a,b
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0017
_ak820_outline_0017:
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0036
_ak820_outline_0036:
	movx	a,@dptr
	mov	r3,a
	mov	r4,#0x00
	xrl	ar3,#0xff
	xrl	ar4,#0xff
	mov	ar1,r5
	mov	r5,#0x00
	mov	a,r1
	anl	ar3,a
	mov	a,r5
	anl	ar4,a
	mov	a,r3
	orl	a,r4
	ret

	.area CSEG (CODE)
; function ak820_outline_0042
_ak820_outline_0042:
	add	a,r4
	mov	dpl,a
	clr	a
	addc	a,r5
	mov	dph,a
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0081
_ak820_outline_0081:
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0101
_ak820_outline_0101:
	mov	a,r7
	mov	b,#0x0a
	mul	ab
	add	a,#_entries
	mov	r5,a
	mov	a,#(_entries>>8)
	addc	a,b
	ret

	.area CSEG (CODE)
; function ak820_outline_0117
_ak820_outline_0117:
	mov	dpl,a
	clr	a
	addc	a,r6
	mov	dph,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0128
_ak820_outline_0128:
	mov	dptr,#_active
	movx	a,@dptr
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0130
_ak820_outline_0130:
	movx	a,@dptr
	orl	ar7,a
	mov	dpl,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0190
_ak820_outline_0190:
	mov	dpl,r5
	mov	dph,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0194
_ak820_outline_0194:
	mov	b,#0x0a
	mul	ab
	ret
