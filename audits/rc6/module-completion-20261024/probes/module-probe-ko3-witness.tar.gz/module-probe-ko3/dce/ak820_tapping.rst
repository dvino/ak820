                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000F                        552 _ak820_tapping_before_sloc0_1_0:
      00000F                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005FF                        562 _source_state:
      0005FF                        563 	.ds 130
      000681                        564 _pending_time:
      000681                        565 	.ds 2
      000683                        566 _pending_code:
      000683                        567 	.ds 2
      000685                        568 _ak820_tapping_source_PARM_1:
      000685                        569 	.ds 2
      000687                        570 _hold_PARM_2:
      000687                        571 	.ds 1
      000688                        572 _hold_code_10000_603:
      000688                        573 	.ds 2
      00068A                        574 _hold_mods_30000_606:
      00068A                        575 	.ds 1
      00068B                        576 _commit_pending_id_10000_612:
      00068B                        577 	.ds 1
      00068C                        578 _ak820_tapping_before_event_10000_613:
      00068C                        579 	.ds 2
      00068E                        580 _ak820_tapping_process_record_10000_624:
      00068E                        581 	.ds 2
      000690                        582 _ak820_tapping_process_code_10000_625:
      000690                        583 	.ds 2
      000692                        584 _ak820_tapping_process_sc_mods_10000_625:
      000692                        585 	.ds 1
      000693                        586 _ak820_oneshot_mods::
      000693                        587 	.ds 1
      000694                        588 _ak820_oneshot_consumed::
      000694                        589 	.ds 1
      000695                        590 _ak820_oneshot_process_PARM_2:
      000695                        591 	.ds 1
      000696                        592 _ak820_oneshot_process_PARM_3:
      000696                        593 	.ds 1
      000697                        594 _ak820_oneshot_process_code_10000_650:
      000697                        595 	.ds 2
      000699                        596 _ak820_oneshot_process_mods_10000_651:
      000699                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E34                        606 _pending:
      000E34                        607 	.ds 1
      000E35                        608 _ak820_oneshot_target::
      000E35                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004889                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004889 90 06 86         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      00488C E0               [24]  656 	movx	a,@dptr
      00488D FF               [12]  657 	mov	r7,a
      00488E BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004891                        659 00147$:
      004891 50 14            [24]  660 	jnc	00102$
      004893 90 06 85         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      004896 E0               [24]  662 	movx	a,@dptr
      004897 FE               [12]  663 	mov	r6,a
      004898 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      00489B                        665 00149$:
      00489B 50 0A            [24]  666 	jnc	00102$
      00489D 8F 05            [24]  667 	mov	ar5,r7
      00489F ED               [12]  668 	mov	a,r5
      0048A0 12 38 82         [24]  669 	lcall	_ak820_outline_0193
      0048A3 2E               [12]  670 	add	a,r6
      0048A4 F5 82            [12]  671 	mov	dpl,a
      0048A6 22               [24]  672 	ret
      0048A7                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0048A7 90 06 85         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0048AA E0               [24]  676 	movx	a,@dptr
      0048AB FE               [12]  677 	mov	r6,a
      0048AC BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0048AF                        679 00151$:
      0048AF 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0048B1 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0048B4 75 82 80         [24]  683 	mov	dpl, #0x80
      0048B7 22               [24]  684 	ret
      0048B8                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0048B8 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0048BB 75 82 81         [24]  688 	mov	dpl, #0x81
      0048BE 22               [24]  689 	ret
      0048BF                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0048BF 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      0048C2 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0048C3                        707 _hold:
      0048C3 12 38 42         [24]  708 	lcall	_ak820_outline_0108
      0048C6 90 06 88         [24]  709 	mov	dptr,#_hold_code_10000_603
      0048C9 12 38 47         [24]  710 	lcall	_ak820_outline_0109
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      0048CC 90 06 88         [24]  712 	mov	dptr,#_hold_code_10000_603
      0048CF 12 37 C4         [24]  713 	lcall	_ak820_outline_0010
      0048D2 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0048D4 2D               [12]  715 	add	a,r5
      0048D5 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0048D7 8F 05            [24]  718 	mov	ar5,r7
      0048D9 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0048DC 90 06 8A         [24]  720 	mov	dptr,#_hold_mods_30000_606
      0048DF ED               [12]  721 	mov	a,r5
      0048E0 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0048E1 ED               [12]  724 	mov	a,r5
      0048E2 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0048E5 ED               [12]  726 	mov	a,r5
      0048E6 C4               [12]  727 	swap	a
      0048E7 54 F0            [12]  728 	anl	a,#0xf0
      0048E9 90 06 8A         [24]  729 	mov	dptr,#_hold_mods_30000_606
      0048EC F0               [24]  730 	movx	@dptr,a
      0048ED                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0048ED 90 06 87         [24]  733 	mov	dptr,#_hold_PARM_2
      0048F0 E0               [24]  734 	movx	a,@dptr
      0048F1 60 09            [24]  735 	jz	00104$
      0048F3 90 06 8A         [24]  736 	mov	dptr,#_hold_mods_30000_606
      0048F6 E0               [24]  737 	movx	a,@dptr
      0048F7 F5 82            [12]  738 	mov	dpl,a
      0048F9 02 7A 4F         [24]  739 	ljmp	_register_mods
      0048FC                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      0048FC 90 06 8A         [24]  742 	mov	dptr,#_hold_mods_30000_606
      0048FF E0               [24]  743 	movx	a,@dptr
      004900 F5 82            [12]  744 	mov	dpl,a
      004902 02 7A 63         [24]  745 	ljmp	_unregister_mods
      004905                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004905 8F 06            [24]  748 	mov	ar6,r7
      004907 74 0F            [12]  749 	mov	a,#0x0f
      004909 5E               [12]  750 	anl	a,r6
      00490A FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      00490B 90 06 87         [24]  753 	mov	dptr,#_hold_PARM_2
      00490E E0               [24]  754 	movx	a,@dptr
      00490F 60 05            [24]  755 	jz	00107$
      004911 8F 82            [24]  756 	mov	dpl, r7
      004913 02 7C 0E         [24]  757 	ljmp	_layer_hold_on
      004916                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004916 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004918 02 7C 44         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00491B                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      00491B 90 0E 34         [24]  774 	mov	dptr,#_pending
      00491E E0               [24]  775 	movx	a,@dptr
      00491F 90 06 8B         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      004922 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004923 12 4D 76         [24]  779 	lcall	_ak820_outline_0161
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004926 90 06 8B         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      004929 E0               [24]  782 	movx	a,@dptr
      00492A 24 FF            [12]  783 	add	a,#_source_state
      00492C FF               [12]  784 	mov	r7,a
      00492D E4               [12]  785 	clr	a
      00492E 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004930 FE               [12]  787 	mov	r6,a
      004931 12 48 73         [24]  788 	lcall	_ak820_outline_0164
      004934 E0               [24]  789 	movx	a,@dptr
      004935 FD               [12]  790 	mov	r5,a
      004936 43 05 04         [24]  791 	orl	ar5,#0x04
      004939 12 48 73         [24]  792 	lcall	_ak820_outline_0164
      00493C ED               [12]  793 	mov	a,r5
      00493D F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      00493E 90 06 83         [24]  796 	mov	dptr,#_pending_code
      004941 12 37 F9         [24]  797 	lcall	_ak820_outline_0056
      004944 90 06 87         [24]  798 	mov	dptr,#_hold_PARM_2
      004947 12 4D 53         [24]  799 	lcall	_ak820_outline_0060
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      00494A 01 C3            [12]  801 	ajmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      00494C                        812 _ak820_tapping_before:
      00494C 12 38 42         [24]  813 	lcall	_ak820_outline_0108
      00494F 90 06 8C         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004952 12 38 47         [24]  815 	lcall	_ak820_outline_0109
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004955 90 06 8C         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004958 12 37 C4         [24]  818 	lcall	_ak820_outline_0010
      00495B 12 4D 2E         [24]  819 	lcall	_ak820_outline_0024
      00495E C0 07            [24]  820 	push	ar7
      004960 C0 06            [24]  821 	push	ar6
      004962 12 BD DA         [24]  822 	lcall	___memcpy
      004965 11 89            [12]  823 	acall	_ak820_tapping_source
      004967 AD 82            [24]  824 	mov	r5, dpl
      004969 D0 06            [24]  825 	pop	ar6
      00496B D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      00496D 90 0E A5         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      004970 E0               [24]  829 	movx	a,@dptr
      004971 60 29            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004973 74 04            [12]  832 	mov	a,#0x04
      004975 12 4D 14         [24]  833 	lcall	_ak820_outline_0014
      004978 60 1E            [24]  834 	jz	00102$
      00497A BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      00497D 80 19            [24]  836 	sjmp	00102$
      00497F                        837 00218$:
      00497F 74 05            [12]  838 	mov	a,#0x05
      004981 12 4D 14         [24]  839 	lcall	_ak820_outline_0014
      004984 70 12            [24]  840 	jnz	00102$
      004986 ED               [12]  841 	mov	a,r5
      004987 24 FF            [12]  842 	add	a, #_source_state
      004989 FB               [12]  843 	mov	r3,a
      00498A E4               [12]  844 	clr	a
      00498B 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      00498D 12 4D 5B         [24]  846 	lcall	_ak820_outline_0061
      004990 53 02 FD         [24]  847 	anl	ar2,#0xfd
      004993 12 33 FC         [24]  848 	lcall	_ak820_outline_0131
      004996 EA               [12]  849 	mov	a,r2
      004997 F0               [24]  850 	movx	@dptr,a
      004998                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004998 75 82 00         [24]  853 	mov	dpl, #0x00
      00499B 22               [24]  854 	ret
      00499C                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      00499C 90 0E 34         [24]  857 	mov	dptr,#_pending
      00499F E0               [24]  858 	movx	a,@dptr
      0049A0 FC               [12]  859 	mov	r4,a
      0049A1 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      0049A4 80 3A            [24]  861 	sjmp	00108$
      0049A6                        862 00220$:
      0049A6 12 37 E9         [24]  863 	lcall	_ak820_outline_0032
      0049A9 FA               [12]  864 	mov	r2,a
      0049AA A3               [24]  865 	inc	dptr
      0049AB E0               [24]  866 	movx	a,@dptr
      0049AC FB               [12]  867 	mov	r3,a
      0049AD 90 06 81         [24]  868 	mov	dptr,#_pending_time
      0049B0 12 38 3C         [24]  869 	lcall	_ak820_outline_0107
      0049B3 EA               [12]  870 	mov	a,r2
      0049B4 C3               [12]  871 	clr	c
      0049B5 98               [12]  872 	subb	a,r0
      0049B6 FA               [12]  873 	mov	r2,a
      0049B7 EB               [12]  874 	mov	a,r3
      0049B8 99               [12]  875 	subb	a,r1
      0049B9 FB               [12]  876 	mov	r3,a
      0049BA C3               [12]  877 	clr	c
      0049BB EA               [12]  878 	mov	a,r2
      0049BC 94 C8            [12]  879 	subb	a,#0xc8
      0049BE EB               [12]  880 	mov	a,r3
      0049BF 94 00            [12]  881 	subb	a,#0x00
      0049C1 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0049C3 74 04            [12]  884 	mov	a,#0x04
      0049C5 12 4D 48         [24]  885 	lcall	_ak820_outline_0051
      0049C8 60 16            [24]  886 	jz	00108$
      0049CA 12 37 AD         [24]  887 	lcall	_ak820_outline_0004
      0049CD 60 11            [24]  888 	jz	00108$
      0049CF BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      0049D2 80 06            [24]  890 	sjmp	00107$
      0049D4                        891 00224$:
      0049D4 ED               [12]  892 	mov	a,r5
      0049D5 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      0049D8 80 06            [24]  894 	sjmp	00108$
      0049DA                        895 00225$:
      0049DA                        896 00107$:
      0049DA C0 05            [24]  897 	push	ar5
      0049DC 31 1B            [12]  898 	acall	_commit_pending
      0049DE D0 05            [24]  899 	pop	ar5
      0049E0                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0049E0 90 06 8C         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_613
      0049E3 12 37 F9         [24]  903 	lcall	_ak820_outline_0056
      0049E6 74 04            [12]  904 	mov	a,#0x04
      0049E8 12 4D 14         [24]  905 	lcall	_ak820_outline_0014
      0049EB 60 03            [24]  906 	jz	00114$
      0049ED BD FF 04         [24]  907 	cjne	r5,#0xff,00115$
      0049F0                        908 00114$:
      0049F0 75 82 01         [24]  909 	mov	dpl, #0x01
      0049F3 22               [24]  910 	ret
      0049F4                        911 00115$:
                                    912 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      0049F4 ED               [12]  913 	mov	a,r5
      0049F5 24 FF            [12]  914 	add	a, #_source_state
      0049F7 FC               [12]  915 	mov	r4,a
      0049F8 E4               [12]  916 	clr	a
      0049F9 34 05            [12]  917 	addc	a, #(_source_state >> 8)
      0049FB FD               [12]  918 	mov	r5,a
      0049FC 12 40 46         [24]  919 	lcall	_ak820_outline_0081
      0049FF FB               [12]  920 	mov	r3,a
      004A00 30 E1 13         [24]  921 	jnb	acc.1,00120$
                                    922 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004A03 74 05            [12]  923 	mov	a,#0x05
      004A05 2E               [12]  924 	add	a, r6
      004A06 12 37 D7         [24]  925 	lcall	_ak820_outline_0018
      004A09 70 07            [24]  926 	jnz	00118$
      004A0B 74 FD            [12]  927 	mov	a,#0xfd
      004A0D 5B               [12]  928 	anl	a,r3
      004A0E 12 38 4C         [24]  929 	lcall	_ak820_outline_0126
      004A11 F0               [24]  930 	movx	@dptr,a
      004A12                        931 00118$:
                                    932 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004A12 75 82 00         [24]  933 	mov	dpl, #0x00
      004A15 22               [24]  934 	ret
      004A16                        935 00120$:
                                    936 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004A16 12 47 F3         [24]  937 	lcall	_ak820_outline_0012
      004A19 E0               [24]  938 	movx	a,@dptr
      004A1A FF               [12]  939 	mov	r7,a
      004A1B 8B 06            [24]  940 	mov	ar6,r3
      004A1D 53 06 01         [24]  941 	anl	ar6,#0x01
      004A20 EE               [12]  942 	mov	a,r6
      004A21 B4 01 00         [24]  943 	cjne	a,#0x01,00231$
      004A24                        944 00231$:
      004A24 B3               [12]  945 	cpl	c
      004A25 92 0F            [24]  946 	mov	_ak820_tapping_before_sloc0_1_0,c
      004A27 8F F0            [24]  947 	mov	b,r7
      004A29 E4               [12]  948 	clr	a
      004A2A 33               [12]  949 	rlc	a
      004A2B B5 F0 04         [24]  950 	cjne	a,b,00122$
      004A2E 75 82 00         [24]  951 	mov	dpl, #0x00
      004A31 22               [24]  952 	ret
      004A32                        953 00122$:
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004A32 63 03 01         [24]  955 	xrl	ar3,#0x01
      004A35 12 38 4C         [24]  956 	lcall	_ak820_outline_0126
      004A38 EB               [12]  957 	mov	a,r3
      004A39 F0               [24]  958 	movx	@dptr,a
                                    959 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004A3A 75 82 01         [24]  960 	mov	dpl, #0x01
                                    961 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004A3D 22               [24]  962 	ret
                                    963 ;------------------------------------------------------------
                                    964 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    965 ;------------------------------------------------------------
                                    966 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    967 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    968 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    969 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    970 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    971 ;------------------------------------------------------------
                                    972 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    973 ;	-----------------------------------------
                                    974 ;	 function ak820_tapping_process
                                    975 ;	-----------------------------------------
      004A3E                        976 _ak820_tapping_process:
      004A3E 12 38 42         [24]  977 	lcall	_ak820_outline_0108
      004A41 90 06 8E         [24]  978 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004A44 12 38 47         [24]  979 	lcall	_ak820_outline_0109
                                    980 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004A47 90 06 92         [24]  981 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004A4A E4               [12]  982 	clr	a
      004A4B F0               [24]  983 	movx	@dptr,a
                                    984 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004A4C 90 06 8E         [24]  985 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004A4F 12 37 F9         [24]  986 	lcall	_ak820_outline_0056
      004A52 74 04            [12]  987 	mov	a,#0x04
      004A54 12 3F FB         [24]  988 	lcall	_ak820_outline_0009
      004A57 70 04            [24]  989 	jnz	00102$
      004A59 75 82 01         [24]  990 	mov	dpl, #0x01
      004A5C 22               [24]  991 	ret
      004A5D                        992 00102$:
                                    993 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004A5D 8E 04            [24]  994 	mov	ar4,r6
      004A5F 8F 05            [24]  995 	mov	ar5,r7
      004A61 12 4D 2E         [24]  996 	lcall	_ak820_outline_0024
      004A64 C0 07            [24]  997 	push	ar7
      004A66 C0 06            [24]  998 	push	ar6
      004A68 12 BD DA         [24]  999 	lcall	___memcpy
      004A6B 11 89            [12] 1000 	acall	_ak820_tapping_source
      004A6D AD 82            [24] 1001 	mov	r5, dpl
      004A6F D0 06            [24] 1002 	pop	ar6
      004A71 D0 07            [24] 1003 	pop	ar7
                                   1004 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004A73 BD FF 04         [24] 1005 	cjne	r5,#0xff,00104$
      004A76 75 82 01         [24] 1006 	mov	dpl, #0x01
      004A79 22               [24] 1007 	ret
      004A7A                       1008 00104$:
                                   1009 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004A7A 74 07            [12] 1010 	mov	a,#0x07
      004A7C 12 37 CE         [24] 1011 	lcall	_ak820_outline_0013
      004A7F FE               [12] 1012 	mov	r6,a
      004A80 A3               [24] 1013 	inc	dptr
      004A81 E0               [24] 1014 	movx	a,@dptr
      004A82 FF               [12] 1015 	mov	r7,a
      004A83 90 06 90         [24] 1016 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004A86 12 4D 63         [24] 1017 	lcall	_ak820_outline_0064
                                   1018 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004A89 BE 1A 15         [24] 1019 	cjne	r6,#0x1a,00111$
      004A8C BF 7C 12         [24] 1020 	cjne	r7,#0x7c,00111$
      004A8F 90 06 90         [24] 1021 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004A92 74 26            [12] 1022 	mov	a,#0x26
      004A94 F0               [24] 1023 	movx	@dptr,a
      004A95 74 22            [12] 1024 	mov	a,#0x22
      004A97 A3               [24] 1025 	inc	dptr
      004A98 F0               [24] 1026 	movx	@dptr,a
      004A99 90 06 92         [24] 1027 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004A9C 74 02            [12] 1028 	mov	a,#0x02
      004A9E F0               [24] 1029 	movx	@dptr,a
      004A9F 80 28            [24] 1030 	sjmp	00112$
      004AA1                       1031 00111$:
                                   1032 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004AA1 BE 1B 15         [24] 1033 	cjne	r6,#0x1b,00108$
      004AA4 BF 7C 12         [24] 1034 	cjne	r7,#0x7c,00108$
      004AA7 90 06 90         [24] 1035 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004AAA 74 27            [12] 1036 	mov	a,#0x27
      004AAC F0               [24] 1037 	movx	@dptr,a
      004AAD 74 32            [12] 1038 	mov	a,#0x32
      004AAF A3               [24] 1039 	inc	dptr
      004AB0 F0               [24] 1040 	movx	@dptr,a
      004AB1 90 06 92         [24] 1041 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004AB4 74 20            [12] 1042 	mov	a,#0x20
      004AB6 F0               [24] 1043 	movx	@dptr,a
      004AB7 80 10            [24] 1044 	sjmp	00112$
      004AB9                       1045 00108$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004AB9 BE 1E 0D         [24] 1047 	cjne	r6,#0x1e,00112$
      004ABC BF 7C 0A         [24] 1048 	cjne	r7,#0x7c,00112$
      004ABF 90 06 90         [24] 1049 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004AC2 74 28            [12] 1050 	mov	a,#0x28
      004AC4 F0               [24] 1051 	movx	@dptr,a
      004AC5 74 32            [12] 1052 	mov	a,#0x32
      004AC7 A3               [24] 1053 	inc	dptr
      004AC8 F0               [24] 1054 	movx	@dptr,a
      004AC9                       1055 00112$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004AC9 90 06 90         [24] 1057 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004ACC E0               [24] 1058 	movx	a,@dptr
      004ACD A3               [24] 1059 	inc	dptr
      004ACE E0               [24] 1060 	movx	a,@dptr
      004ACF FF               [12] 1061 	mov	r7,a
                                   1062 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004AD0 BF 20 00         [24] 1063 	cjne	r7,#0x20,00242$
      004AD3                       1064 00242$:
      004AD3 40 05            [24] 1065 	jc	00113$
      004AD5 BF 50 00         [24] 1066 	cjne	r7,#0x50,00244$
      004AD8                       1067 00244$:
      004AD8 40 04            [24] 1068 	jc	00114$
      004ADA                       1069 00113$:
      004ADA 75 82 01         [24] 1070 	mov	dpl, #0x01
      004ADD 22               [24] 1071 	ret
      004ADE                       1072 00114$:
                                   1073 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004ADE BF 40 00         [24] 1074 	cjne	r7,#0x40,00246$
      004AE1                       1075 00246$:
      004AE1 40 0C            [24] 1076 	jc	00117$
      004AE3 53 07 0F         [24] 1077 	anl	ar7,#0x0f
      004AE6 BF 06 00         [24] 1078 	cjne	r7,#0x06,00248$
      004AE9                       1079 00248$:
      004AE9 40 04            [24] 1080 	jc	00117$
      004AEB 75 82 00         [24] 1081 	mov	dpl, #0x00
      004AEE 22               [24] 1082 	ret
      004AEF                       1083 00117$:
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004AEF 90 06 8E         [24] 1085 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004AF2 12 37 F9         [24] 1086 	lcall	_ak820_outline_0056
      004AF5 74 05            [12] 1087 	mov	a,#0x05
      004AF7 12 4D 14         [24] 1088 	lcall	_ak820_outline_0014
      004AFA 60 1E            [24] 1089 	jz	00131$
                                   1090 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004AFC 90 0E 34         [24] 1091 	mov	dptr,#_pending
      004AFF ED               [12] 1092 	mov	a,r5
      004B00 12 47 FD         [24] 1093 	lcall	_ak820_outline_0025
                                   1094 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004B03 12 37 F9         [24] 1095 	lcall	_ak820_outline_0056
      004B06 90 06 81         [24] 1096 	mov	dptr,#_pending_time
      004B09 12 4D 63         [24] 1097 	lcall	_ak820_outline_0064
                                   1098 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004B0C 90 06 90         [24] 1099 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B0F 12 37 F9         [24] 1100 	lcall	_ak820_outline_0056
      004B12 90 06 83         [24] 1101 	mov	dptr,#_pending_code
      004B15 12 4D 63         [24] 1102 	lcall	_ak820_outline_0064
      004B18 61 B3            [12] 1103 	ajmp	00132$
      004B1A                       1104 00131$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004B1A 90 0E 34         [24] 1106 	mov	dptr,#_pending
      004B1D E0               [24] 1107 	movx	a,@dptr
      004B1E FF               [12] 1108 	mov	r7,a
      004B1F ED               [12] 1109 	mov	a,r5
      004B20 B5 07 02         [24] 1110 	cjne	a,ar7,00251$
      004B23 80 02            [24] 1111 	sjmp	00252$
      004B25                       1112 00251$:
      004B25 61 8D            [12] 1113 	ajmp	00128$
      004B27                       1114 00252$:
                                   1115 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004B27 12 4D 76         [24] 1116 	lcall	_ak820_outline_0161
                                   1117 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004B2A 90 06 92         [24] 1118 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B2D E0               [24] 1119 	movx	a,@dptr
      004B2E FF               [12] 1120 	mov	r7,a
      004B2F E0               [24] 1121 	movx	a,@dptr
      004B30 60 05            [24] 1122 	jz	00120$
      004B32 8F 82            [24] 1123 	mov	dpl, r7
      004B34 12 80 77         [24] 1124 	lcall	_add_owned_mods
      004B37                       1125 00120$:
                                   1126 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004B37 90 06 8E         [24] 1127 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B3A 12 37 F9         [24] 1128 	lcall	_ak820_outline_0056
      004B3D 74 07            [12] 1129 	mov	a,#0x07
      004B3F 2E               [12] 1130 	add	a, r6
      004B40 FB               [12] 1131 	mov	r3,a
      004B41 E4               [12] 1132 	clr	a
      004B42 3F               [12] 1133 	addc	a, r7
      004B43 FC               [12] 1134 	mov	r4,a
      004B44 90 06 90         [24] 1135 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B47 E0               [24] 1136 	movx	a,@dptr
      004B48 F9               [12] 1137 	mov	r1,a
      004B49 7A 00            [12] 1138 	mov	r2,#0x00
      004B4B 12 33 FC         [24] 1139 	lcall	_ak820_outline_0131
      004B4E 12 4D 70         [24] 1140 	lcall	_ak820_outline_0144
                                   1141 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004B51 C3               [12] 1142 	clr	c
      004B52 04               [12] 1143 	inc	a
      004B53 99               [12] 1144 	subb	a,r1
      004B54 50 25            [24] 1145 	jnc	00122$
                                   1146 ;	free result
                                   1147 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004B56 74 06            [12] 1148 	mov	a,#0x06
      004B58 12 37 CE         [24] 1149 	lcall	_ak820_outline_0013
      004B5B 54 0F            [12] 1150 	anl	a,#0x0f
      004B5D 44 10            [12] 1151 	orl	a,#0x10
      004B5F F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004B60 12 47 F3         [24] 1154 	lcall	_ak820_outline_0012
      004B63 12 4D 53         [24] 1155 	lcall	_ak820_outline_0060
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004B66 12 75 28         [24] 1157 	lcall	_process_record
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004B69 90 06 8E         [24] 1159 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B6C 12 37 BA         [24] 1160 	lcall	_ak820_outline_0006
      004B6F A3               [24] 1161 	inc	dptr
      004B70 A3               [24] 1162 	inc	dptr
      004B71 A3               [24] 1163 	inc	dptr
      004B72 A3               [24] 1164 	inc	dptr
      004B73 A3               [24] 1165 	inc	dptr
      004B74 E4               [12] 1166 	clr	a
      004B75 12 48 29         [24] 1167 	lcall	_ak820_outline_0066
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004B78 12 75 28         [24] 1169 	lcall	_process_record
      004B7B                       1170 00122$:
                                   1171 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004B7B 90 06 92         [24] 1172 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B7E E0               [24] 1173 	movx	a,@dptr
      004B7F FF               [12] 1174 	mov	r7,a
      004B80 E0               [24] 1175 	movx	a,@dptr
      004B81 60 30            [24] 1176 	jz	00132$
                                   1177 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004B83 8F 82            [24] 1178 	mov	dpl, r7
      004B85 12 80 87         [24] 1179 	lcall	_del_owned_mods
                                   1180 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004B88 12 83 B0         [24] 1181 	lcall	_send_keyboard_report
      004B8B 80 26            [24] 1182 	sjmp	00132$
      004B8D                       1183 00128$:
                                   1184 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004B8D ED               [12] 1185 	mov	a,r5
      004B8E 24 FF            [12] 1186 	add	a, #_source_state
      004B90 FE               [12] 1187 	mov	r6,a
      004B91 E4               [12] 1188 	clr	a
      004B92 34 05            [12] 1189 	addc	a, #(_source_state >> 8)
      004B94 FF               [12] 1190 	mov	r7,a
      004B95 12 38 30         [24] 1191 	lcall	_ak820_outline_0098
      004B98 FD               [12] 1192 	mov	r5,a
      004B99 30 E2 17         [24] 1193 	jnb	acc.2,00132$
                                   1194 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004B9C 53 05 FB         [24] 1195 	anl	ar5,#0xfb
      004B9F 12 48 48         [24] 1196 	lcall	_ak820_outline_0123
      004BA2 ED               [12] 1197 	mov	a,r5
      004BA3 F0               [24] 1198 	movx	@dptr,a
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004BA4 90 06 90         [24] 1200 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BA7 12 37 F9         [24] 1201 	lcall	_ak820_outline_0056
      004BAA 90 06 87         [24] 1202 	mov	dptr,#_hold_PARM_2
      004BAD E4               [12] 1203 	clr	a
      004BAE 12 48 29         [24] 1204 	lcall	_ak820_outline_0066
      004BB1 11 C3            [12] 1205 	acall	_hold
      004BB3                       1206 00132$:
                                   1207 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004BB3 75 82 00         [24] 1208 	mov	dpl, #0x00
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004BB6 22               [24] 1210 	ret
                                   1211 ;------------------------------------------------------------
                                   1212 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1213 ;------------------------------------------------------------
                                   1214 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1215 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1216 ;------------------------------------------------------------
                                   1217 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1218 ;	-----------------------------------------
                                   1219 ;	 function ak820_tapping_cancel
                                   1220 ;	-----------------------------------------
      004BB7                       1221 _ak820_tapping_cancel:
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004BB7 12 4D 76         [24] 1223 	lcall	_ak820_outline_0161
                                   1224 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004BBA 7F 00            [12] 1225 	mov	r7,#0x00
      004BBC                       1226 00103$:
      004BBC BF 82 00         [24] 1227 	cjne	r7,#0x82,00122$
      004BBF                       1228 00122$:
      004BBF 50 16            [24] 1229 	jnc	00105$
                                   1230 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004BC1 12 4D 1F         [24] 1231 	lcall	_ak820_outline_0021
                                   1232 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004BC4 74 02            [12] 1233 	mov	a,#0x02
      004BC6 5C               [12] 1234 	anl	a,r4
      004BC7 FB               [12] 1235 	mov	r3,a
      004BC8 53 04 01         [24] 1236 	anl	ar4,#0x01
      004BCB EC               [12] 1237 	mov	a,r4
      004BCC 2C               [12] 1238 	add	a,r4
      004BCD 42 03            [12] 1239 	orl	ar3,a
      004BCF 12 38 5C         [24] 1240 	lcall	_ak820_outline_0141
      004BD2 EB               [12] 1241 	mov	a,r3
      004BD3 F0               [24] 1242 	movx	@dptr,a
                                   1243 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004BD4 0F               [12] 1244 	inc	r7
      004BD5 80 E5            [24] 1245 	sjmp	00103$
      004BD7                       1246 00105$:
                                   1247 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004BD7 22               [24] 1248 	ret
                                   1249 ;------------------------------------------------------------
                                   1250 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1251 ;------------------------------------------------------------
                                   1252 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1253 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1254 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1255 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1256 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1257 ;------------------------------------------------------------
                                   1258 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1259 ;	-----------------------------------------
                                   1260 ;	 function ak820_oneshot_process
                                   1261 ;	-----------------------------------------
      004BD8                       1262 _ak820_oneshot_process:
      004BD8 12 38 42         [24] 1263 	lcall	_ak820_outline_0108
      004BDB 90 06 97         [24] 1264 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004BDE 12 38 47         [24] 1265 	lcall	_ak820_outline_0109
                                   1266 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004BE1 90 06 95         [24] 1267 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004BE4 E0               [24] 1268 	movx	a,@dptr
      004BE5 FF               [12] 1269 	mov	r7,a
      004BE6 BF FF 02         [24] 1270 	cjne	r7,#0xff,00248$
      004BE9 80 07            [24] 1271 	sjmp	00101$
      004BEB                       1272 00248$:
      004BEB 12 A7 55         [24] 1273 	lcall	_get_repeat_key_count
      004BEE E5 82            [12] 1274 	mov	a, dpl
      004BF0 60 04            [24] 1275 	jz	00102$
      004BF2                       1276 00101$:
      004BF2 75 82 01         [24] 1277 	mov	dpl, #0x01
      004BF5 22               [24] 1278 	ret
      004BF6                       1279 00102$:
                                   1280 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004BF6 90 06 97         [24] 1281 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004BF9 E0               [24] 1282 	movx	a,@dptr
      004BFA FD               [12] 1283 	mov	r5,a
      004BFB A3               [24] 1284 	inc	dptr
      004BFC E0               [24] 1285 	movx	a,@dptr
      004BFD FB               [12] 1286 	mov	r3,a
      004BFE BB 52 02         [24] 1287 	cjne	r3,#0x52,00250$
      004C01 80 02            [24] 1288 	sjmp	00251$
      004C03                       1289 00250$:
      004C03 81 A6            [12] 1290 	ajmp	00116$
      004C05                       1291 00251$:
      004C05 8D 04            [24] 1292 	mov	ar4,r5
      004C07 53 04 E0         [24] 1293 	anl	ar4,#0xe0
      004C0A BC A0 02         [24] 1294 	cjne	r4,#0xa0,00252$
      004C0D 80 02            [24] 1295 	sjmp	00253$
      004C0F                       1296 00252$:
      004C0F 81 A6            [12] 1297 	ajmp	00116$
      004C11                       1298 00253$:
                                   1299 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004C11 8D 04            [24] 1300 	mov	ar4,r5
      004C13 53 04 0F         [24] 1301 	anl	ar4,#0x0f
      004C16 90 06 99         [24] 1302 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004C19 EC               [12] 1303 	mov	a,r4
      004C1A F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004C1B ED               [12] 1306 	mov	a,r5
      004C1C 30 E4 08         [24] 1307 	jnb	acc.4,00105$
      004C1F EC               [12] 1308 	mov	a,r4
      004C20 C4               [12] 1309 	swap	a
      004C21 54 F0            [12] 1310 	anl	a,#0xf0
      004C23 90 06 99         [24] 1311 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004C26 F0               [24] 1312 	movx	@dptr,a
      004C27                       1313 00105$:
                                   1314 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004C27 90 06 96         [24] 1315 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004C2A E0               [24] 1316 	movx	a,@dptr
      004C2B 60 2D            [24] 1317 	jz	00113$
                                   1318 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004C2D 12 4D 1F         [24] 1319 	lcall	_ak820_outline_0021
      004C30 43 04 08         [24] 1320 	orl	ar4,#0x08
      004C33 12 48 2F         [24] 1321 	lcall	_ak820_outline_0069
                                   1322 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004C36 53 04 EF         [24] 1323 	anl	ar4,#0xef
      004C39 12 48 2F         [24] 1324 	lcall	_ak820_outline_0069
                                   1325 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004C3C 90 0E 35         [24] 1326 	mov	dptr,#_ak820_oneshot_target
      004C3F E0               [24] 1327 	movx	a,@dptr
      004C40 FC               [12] 1328 	mov	r4,a
      004C41 BC FF 02         [24] 1329 	cjne	r4,#0xff,00256$
      004C44 80 09            [24] 1330 	sjmp	00107$
      004C46                       1331 00256$:
      004C46 12 4D 69         [24] 1332 	lcall	_ak820_outline_0079
      004C49 43 04 10         [24] 1333 	orl	ar4,#0x10
      004C4C 12 48 2F         [24] 1334 	lcall	_ak820_outline_0069
      004C4F                       1335 00107$:
                                   1336 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004C4F 90 06 99         [24] 1337 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004C52 E0               [24] 1338 	movx	a,@dptr
      004C53 F5 82            [12] 1339 	mov	dpl,a
      004C55 12 7A 4F         [24] 1340 	lcall	_register_mods
      004C58 80 48            [24] 1341 	sjmp	00114$
      004C5A                       1342 00113$:
                                   1343 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004C5A 12 4D 1F         [24] 1344 	lcall	_ak820_outline_0021
      004C5D 30 E3 42         [24] 1345 	jnb	acc.3,00114$
                                   1346 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004C60 EC               [12] 1347 	mov	a,r4
      004C61 20 E4 24         [24] 1348 	jb	acc.4,00109$
                                   1349 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004C64 90 06 93         [24] 1350 	mov	dptr,#_ak820_oneshot_mods
      004C67 E0               [24] 1351 	movx	a,@dptr
      004C68 F4               [12] 1352 	cpl	a
      004C69 FC               [12] 1353 	mov	r4,a
      004C6A 90 06 99         [24] 1354 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004C6D E0               [24] 1355 	movx	a,@dptr
      004C6E FB               [12] 1356 	mov	r3,a
      004C6F 52 04            [12] 1357 	anl	ar4,a
      004C71 8C 82            [24] 1358 	mov	dpl, r4
      004C73 C0 06            [24] 1359 	push	ar6
      004C75 C0 05            [24] 1360 	push	ar5
      004C77 C0 03            [24] 1361 	push	ar3
      004C79 12 80 77         [24] 1362 	lcall	_add_owned_mods
      004C7C D0 03            [24] 1363 	pop	ar3
      004C7E D0 05            [24] 1364 	pop	ar5
      004C80 D0 06            [24] 1365 	pop	ar6
                                   1366 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004C82 90 06 93         [24] 1367 	mov	dptr,#_ak820_oneshot_mods
      004C85 E0               [24] 1368 	movx	a,@dptr
      004C86 4B               [12] 1369 	orl	a,r3
      004C87 F0               [24] 1370 	movx	@dptr,a
      004C88                       1371 00109$:
                                   1372 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004C88 90 06 99         [24] 1373 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004C8B E0               [24] 1374 	movx	a,@dptr
      004C8C F5 82            [12] 1375 	mov	dpl,a
      004C8E C0 06            [24] 1376 	push	ar6
      004C90 C0 05            [24] 1377 	push	ar5
      004C92 12 7A 63         [24] 1378 	lcall	_unregister_mods
      004C95 D0 05            [24] 1379 	pop	ar5
      004C97 D0 06            [24] 1380 	pop	ar6
                                   1381 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004C99 12 4D 69         [24] 1382 	lcall	_ak820_outline_0079
      004C9C 53 04 E7         [24] 1383 	anl	ar4,#0xe7
      004C9F 12 48 2F         [24] 1384 	lcall	_ak820_outline_0069
      004CA2                       1385 00114$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004CA2 75 82 00         [24] 1387 	mov	dpl, #0x00
      004CA5 22               [24] 1388 	ret
      004CA6                       1389 00116$:
                                   1390 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004CA6 90 06 96         [24] 1391 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004CA9 E0               [24] 1392 	movx	a,@dptr
      004CAA 60 64            [24] 1393 	jz	00124$
      004CAC 90 06 97         [24] 1394 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004CAF 12 48 36         [24] 1395 	lcall	_ak820_outline_0099
      004CB2 C3               [12] 1396 	clr	c
      004CB3 74 01            [12] 1397 	mov	a,#0x01
      004CB5 9D               [12] 1398 	subb	a,r5
      004CB6 E4               [12] 1399 	clr	a
      004CB7 9E               [12] 1400 	subb	a,r6
      004CB8 50 56            [24] 1401 	jnc	00124$
                                   1402 ;	free result
                                   1403 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004CBA C3               [12] 1404 	clr	c
      004CBB ED               [12] 1405 	mov	a,r5
      004CBC 94 E0            [12] 1406 	subb	a,#0xe0
      004CBE EE               [12] 1407 	mov	a,r6
      004CBF 94 00            [12] 1408 	subb	a,#0x00
      004CC1 40 07            [24] 1409 	jc	00129$
      004CC3 74 E7            [12] 1410 	mov	a,#0xe7
      004CC5 9D               [12] 1411 	subb	a,r5
      004CC6 E4               [12] 1412 	clr	a
      004CC7 9E               [12] 1413 	subb	a,r6
      004CC8 50 46            [24] 1414 	jnc	00124$
                                   1415 ;	free result
      004CCA                       1416 00129$:
                                   1417 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004CCA 74 AE            [12] 1418 	mov	a,#0x100 - 0x52
      004CCC 2E               [12] 1419 	add	a,r6
      004CCD 50 09            [24] 1420 	jnc	00165$
      004CCF C3               [12] 1421 	clr	c
      004CD0 74 DF            [12] 1422 	mov	a,#0xdf
      004CD2 9D               [12] 1423 	subb	a,r5
      004CD3 74 52            [12] 1424 	mov	a,#0x52
      004CD5 9E               [12] 1425 	subb	a,r6
      004CD6 50 38            [24] 1426 	jnc	00124$
                                   1427 ;	free result
                                   1428 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004CD8                       1429 00165$:
      004CD8 7E 00            [12] 1430 	mov	r6,#0x00
      004CDA                       1431 00131$:
      004CDA BE 82 00         [24] 1432 	cjne	r6,#0x82,00265$
      004CDD                       1433 00265$:
      004CDD 50 1A            [24] 1434 	jnc	00120$
                                   1435 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004CDF EE               [12] 1436 	mov	a,r6
      004CE0 24 FF            [12] 1437 	add	a, #_source_state
      004CE2 FC               [12] 1438 	mov	r4,a
      004CE3 E4               [12] 1439 	clr	a
      004CE4 34 05            [12] 1440 	addc	a, #(_source_state >> 8)
      004CE6 FD               [12] 1441 	mov	r5,a
      004CE7 12 40 46         [24] 1442 	lcall	_ak820_outline_0081
      004CEA FB               [12] 1443 	mov	r3,a
      004CEB 30 E3 08         [24] 1444 	jnb	acc.3,00132$
      004CEE 43 03 10         [24] 1445 	orl	ar3,#0x10
      004CF1 12 38 4C         [24] 1446 	lcall	_ak820_outline_0126
      004CF4 EB               [12] 1447 	mov	a,r3
      004CF5 F0               [24] 1448 	movx	@dptr,a
      004CF6                       1449 00132$:
                                   1450 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004CF6 0E               [12] 1451 	inc	r6
      004CF7 80 E1            [24] 1452 	sjmp	00131$
      004CF9                       1453 00120$:
                                   1454 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004CF9 90 06 93         [24] 1455 	mov	dptr,#_ak820_oneshot_mods
      004CFC E0               [24] 1456 	movx	a,@dptr
      004CFD FE               [12] 1457 	mov	r6,a
      004CFE E0               [24] 1458 	movx	a,@dptr
      004CFF 60 0F            [24] 1459 	jz	00124$
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004D01 90 06 94         [24] 1461 	mov	dptr,#_ak820_oneshot_consumed
      004D04 EE               [12] 1462 	mov	a,r6
      004D05 F0               [24] 1463 	movx	@dptr,a
                                   1464 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004D06 90 0E 35         [24] 1465 	mov	dptr,#_ak820_oneshot_target
      004D09 EF               [12] 1466 	mov	a,r7
      004D0A F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004D0B 90 06 93         [24] 1469 	mov	dptr,#_ak820_oneshot_mods
      004D0E E4               [12] 1470 	clr	a
      004D0F F0               [24] 1471 	movx	@dptr,a
      004D10                       1472 00124$:
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004D10 75 82 01         [24] 1474 	mov	dpl, #0x01
                                   1475 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004D13 22               [24] 1476 	ret
                                   1477 	.area CSEG    (CODE)
                                   1478 	.area CONST   (CODE)
                                   1479 	.area XINIT   (CODE)
      00C69D                       1480 __xinit__pending:
      00C69D FF                    1481 	.db #0xff	; 255
      00C69E                       1482 __xinit__ak820_oneshot_target:
      00C69E FF                    1483 	.db #0xff	; 255
                                   1484 	.area CABS    (ABS,CODE)
                                   1485 
                                   1486 ; Experimental exact instruction outlining.
                                   1487 	.globl _ak820_outline_0004
                                   1488 	.globl _ak820_outline_0006
                                   1489 	.globl _ak820_outline_0009
                                   1490 	.globl _ak820_outline_0010
                                   1491 	.globl _ak820_outline_0012
                                   1492 	.globl _ak820_outline_0013
                                   1493 	.globl _ak820_outline_0014
                                   1494 	.globl _ak820_outline_0018
                                   1495 	.globl _ak820_outline_0021
                                   1496 	.globl _ak820_outline_0024
                                   1497 	.globl _ak820_outline_0025
                                   1498 	.globl _ak820_outline_0032
                                   1499 	.globl _ak820_outline_0051
                                   1500 	.globl _ak820_outline_0056
                                   1501 	.globl _ak820_outline_0060
                                   1502 	.globl _ak820_outline_0061
                                   1503 	.globl _ak820_outline_0064
                                   1504 	.globl _ak820_outline_0066
                                   1505 	.globl _ak820_outline_0069
                                   1506 	.globl _ak820_outline_0079
                                   1507 	.globl _ak820_outline_0081
                                   1508 	.globl _ak820_outline_0098
                                   1509 	.globl _ak820_outline_0099
                                   1510 	.globl _ak820_outline_0107
                                   1511 	.globl _ak820_outline_0108
                                   1512 	.globl _ak820_outline_0109
                                   1513 	.globl _ak820_outline_0123
                                   1514 	.globl _ak820_outline_0126
                                   1515 	.globl _ak820_outline_0131
                                   1516 	.globl _ak820_outline_0141
                                   1517 	.globl _ak820_outline_0144
                                   1518 	.globl _ak820_outline_0161
                                   1519 	.globl _ak820_outline_0164
                                   1520 	.globl _ak820_outline_0193
                                   1521 
                                   1522 	.area CSEG (CODE)
                                   1523 ; function ak820_outline_0014
      004D14                       1524 _ak820_outline_0014:
      004D14 2E               [12] 1525 	add	a,r6
      004D15 FB               [12] 1526 	mov	r3,a
      004D16 E4               [12] 1527 	clr	a
      004D17 3F               [12] 1528 	addc	a,r7
      004D18 FC               [12] 1529 	mov	r4,a
      004D19 8B 82            [24] 1530 	mov	dpl,r3
      004D1B 8C 83            [24] 1531 	mov	dph,r4
      004D1D E0               [24] 1532 	movx	a,@dptr
      004D1E 22               [24] 1533 	ret
                                   1534 
                                   1535 	.area CSEG (CODE)
                                   1536 ; function ak820_outline_0021
      004D1F                       1537 _ak820_outline_0021:
      004D1F EF               [12] 1538 	mov	a,r7
      004D20 24 FF            [12] 1539 	add	a,#_source_state
      004D22 FD               [12] 1540 	mov	r5,a
      004D23 E4               [12] 1541 	clr	a
      004D24 34 05            [12] 1542 	addc	a,#(_source_state>>8)
      004D26 FE               [12] 1543 	mov	r6,a
      004D27 8D 82            [24] 1544 	mov	dpl,r5
      004D29 8E 83            [24] 1545 	mov	dph,r6
      004D2B E0               [24] 1546 	movx	a,@dptr
      004D2C FC               [12] 1547 	mov	r4,a
      004D2D 22               [24] 1548 	ret
                                   1549 
                                   1550 	.area CSEG (CODE)
                                   1551 ; function ak820_outline_0024
      004D2E                       1552 _ak820_outline_0024:
      004D2E 90 0E 21         [24] 1553 	mov	dptr,#___memcpy_PARM_2
      004D31 EC               [12] 1554 	mov	a,r4
      004D32 F0               [24] 1555 	movx	@dptr,a
      004D33 ED               [12] 1556 	mov	a,r5
      004D34 A3               [24] 1557 	inc	dptr
      004D35 F0               [24] 1558 	movx	@dptr,a
      004D36 E4               [12] 1559 	clr	a
      004D37 A3               [24] 1560 	inc	dptr
      004D38 F0               [24] 1561 	movx	@dptr,a
      004D39 90 0E 24         [24] 1562 	mov	dptr,#___memcpy_PARM_3
      004D3C 74 02            [12] 1563 	mov	a,#0x02
      004D3E F0               [24] 1564 	movx	@dptr,a
      004D3F E4               [12] 1565 	clr	a
      004D40 A3               [24] 1566 	inc	dptr
      004D41 F0               [24] 1567 	movx	@dptr,a
      004D42 90 06 85         [24] 1568 	mov	dptr,#_ak820_tapping_source_PARM_1
      004D45 F5 F0            [12] 1569 	mov	b,a
      004D47 22               [24] 1570 	ret
                                   1571 
                                   1572 	.area CSEG (CODE)
                                   1573 ; function ak820_outline_0051
      004D48                       1574 _ak820_outline_0051:
      004D48 2E               [12] 1575 	add	a,r6
      004D49 FA               [12] 1576 	mov	r2,a
      004D4A E4               [12] 1577 	clr	a
      004D4B 3F               [12] 1578 	addc	a,r7
      004D4C FB               [12] 1579 	mov	r3,a
      004D4D 8A 82            [24] 1580 	mov	dpl,r2
      004D4F 8B 83            [24] 1581 	mov	dph,r3
      004D51 E0               [24] 1582 	movx	a,@dptr
      004D52 22               [24] 1583 	ret
                                   1584 
                                   1585 	.area CSEG (CODE)
                                   1586 ; function ak820_outline_0060
      004D53                       1587 _ak820_outline_0060:
      004D53 74 01            [12] 1588 	mov	a,#0x01
      004D55 F0               [24] 1589 	movx	@dptr,a
      004D56 8E 82            [24] 1590 	mov	dpl,r6
      004D58 8F 83            [24] 1591 	mov	dph,r7
      004D5A 22               [24] 1592 	ret
                                   1593 
                                   1594 	.area CSEG (CODE)
                                   1595 ; function ak820_outline_0061
      004D5B                       1596 _ak820_outline_0061:
      004D5B FC               [12] 1597 	mov	r4,a
      004D5C 8B 82            [24] 1598 	mov	dpl,r3
      004D5E 8C 83            [24] 1599 	mov	dph,r4
      004D60 E0               [24] 1600 	movx	a,@dptr
      004D61 FA               [12] 1601 	mov	r2,a
      004D62 22               [24] 1602 	ret
                                   1603 
                                   1604 	.area CSEG (CODE)
                                   1605 ; function ak820_outline_0064
      004D63                       1606 _ak820_outline_0064:
      004D63 EE               [12] 1607 	mov	a,r6
      004D64 F0               [24] 1608 	movx	@dptr,a
      004D65 EF               [12] 1609 	mov	a,r7
      004D66 A3               [24] 1610 	inc	dptr
      004D67 F0               [24] 1611 	movx	@dptr,a
      004D68 22               [24] 1612 	ret
                                   1613 
                                   1614 	.area CSEG (CODE)
                                   1615 ; function ak820_outline_0079
      004D69                       1616 _ak820_outline_0079:
      004D69 8D 82            [24] 1617 	mov	dpl,r5
      004D6B 8E 83            [24] 1618 	mov	dph,r6
      004D6D E0               [24] 1619 	movx	a,@dptr
      004D6E FC               [12] 1620 	mov	r4,a
      004D6F 22               [24] 1621 	ret
                                   1622 
                                   1623 	.area CSEG (CODE)
                                   1624 ; function ak820_outline_0144
      004D70                       1625 _ak820_outline_0144:
      004D70 E9               [12] 1626 	mov	a,r1
      004D71 F0               [24] 1627 	movx	@dptr,a
      004D72 EA               [12] 1628 	mov	a,r2
      004D73 A3               [24] 1629 	inc	dptr
      004D74 F0               [24] 1630 	movx	@dptr,a
      004D75 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0161
      004D76                       1635 _ak820_outline_0161:
      004D76 90 0E 34         [24] 1636 	mov	dptr,#_pending
      004D79 74 FF            [12] 1637 	mov	a,#0xff
      004D7B F0               [24] 1638 	movx	@dptr,a
      004D7C 22               [24] 1639 	ret
