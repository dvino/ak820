                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_key_override_mods
                                     12 	.globl _ak820_key_override_key
                                     13 	.globl _ak820_key_override_sync
                                     14 	.globl _biton
                                     15 	.globl _host_consumer_send
                                     16 	.globl _host_system_send
                                     17 	.globl _host_keyboard_send
                                     18 	.globl _clear_keys_from_report
                                     19 	.globl _del_key_from_report
                                     20 	.globl _add_key_to_report
                                     21 	.globl _KEYCODE2CONSUMER
                                     22 	.globl _ADC_START
                                     23 	.globl _S0_R_FIFO
                                     24 	.globl _S0_T_FIFO
                                     25 	.globl _S0_FREE
                                     26 	.globl _S0_IF_BYTE
                                     27 	.globl _S0_IF_FIRST
                                     28 	.globl _S0_IF_OV
                                     29 	.globl _S0_FST_ACT
                                     30 	.globl _CP_RL2
                                     31 	.globl _C_T2
                                     32 	.globl _TR2
                                     33 	.globl _EXEN2
                                     34 	.globl _TCLK
                                     35 	.globl _RCLK
                                     36 	.globl _EXF2
                                     37 	.globl _CAP1F
                                     38 	.globl _TF2
                                     39 	.globl _RI
                                     40 	.globl _TI
                                     41 	.globl _RB8
                                     42 	.globl _TB8
                                     43 	.globl _REN
                                     44 	.globl _SM2
                                     45 	.globl _SM1
                                     46 	.globl _SM0
                                     47 	.globl _IT0
                                     48 	.globl _IE0
                                     49 	.globl _IT1
                                     50 	.globl _IE1
                                     51 	.globl _TR0
                                     52 	.globl _TF0
                                     53 	.globl _TR1
                                     54 	.globl _TF1
                                     55 	.globl _P4_0
                                     56 	.globl _P4_1
                                     57 	.globl _P4_2
                                     58 	.globl _P4_3
                                     59 	.globl _P4_4
                                     60 	.globl _P4_5
                                     61 	.globl _P4_6
                                     62 	.globl _RXD
                                     63 	.globl _TXD
                                     64 	.globl _INT0
                                     65 	.globl _INT1
                                     66 	.globl _T0
                                     67 	.globl _T1
                                     68 	.globl _MOSI1
                                     69 	.globl _MISO1
                                     70 	.globl _SCK1
                                     71 	.globl _P3_0
                                     72 	.globl _P3_1
                                     73 	.globl _P3_2
                                     74 	.globl _P3_3
                                     75 	.globl _P3_4
                                     76 	.globl _P3_5
                                     77 	.globl _P3_6
                                     78 	.globl _P3_7
                                     79 	.globl _CAP1_
                                     80 	.globl _T2_
                                     81 	.globl _CAP2_
                                     82 	.globl _T2EX_
                                     83 	.globl _RXD1
                                     84 	.globl _TXD1
                                     85 	.globl _P2_0
                                     86 	.globl _P2_1
                                     87 	.globl _P2_2
                                     88 	.globl _P2_3
                                     89 	.globl _P2_4
                                     90 	.globl _P2_5
                                     91 	.globl _P2_6
                                     92 	.globl _P2_7
                                     93 	.globl _AIN0
                                     94 	.globl _AIN1
                                     95 	.globl _AIN2
                                     96 	.globl _AIN3
                                     97 	.globl _AIN4
                                     98 	.globl _AIN5
                                     99 	.globl _AIN6
                                    100 	.globl _AIN7
                                    101 	.globl _CAP1
                                    102 	.globl _T2
                                    103 	.globl _CAP2
                                    104 	.globl _T2EX
                                    105 	.globl _INT0_
                                    106 	.globl _SCS
                                    107 	.globl _MOSI
                                    108 	.globl _MISO
                                    109 	.globl _SCK
                                    110 	.globl _RXD1_
                                    111 	.globl _TXD1_
                                    112 	.globl _P1_0
                                    113 	.globl _P1_1
                                    114 	.globl _P1_2
                                    115 	.globl _P1_3
                                    116 	.globl _P1_4
                                    117 	.globl _P1_5
                                    118 	.globl _P1_6
                                    119 	.globl _P1_7
                                    120 	.globl _AIN8
                                    121 	.globl _AIN9
                                    122 	.globl _AIN10
                                    123 	.globl _AIN11
                                    124 	.globl _AIN12
                                    125 	.globl _AIN13
                                    126 	.globl _RXD_
                                    127 	.globl _TXD_
                                    128 	.globl _SCL0
                                    129 	.globl _SDA0
                                    130 	.globl _P0_0
                                    131 	.globl _P0_1
                                    132 	.globl _P0_2
                                    133 	.globl _P0_3
                                    134 	.globl _P0_4
                                    135 	.globl _P0_5
                                    136 	.globl _P0_6
                                    137 	.globl _P0_7
                                    138 	.globl _IE_SPI0
                                    139 	.globl _IE_USB
                                    140 	.globl _IE_ADC
                                    141 	.globl _IE_UART1
                                    142 	.globl _IE_PWM_I2C
                                    143 	.globl _IE_GPIO
                                    144 	.globl _IE_WDOG
                                    145 	.globl _PX0
                                    146 	.globl _PT0
                                    147 	.globl _PX1
                                    148 	.globl _PT1
                                    149 	.globl _PS
                                    150 	.globl _PT2
                                    151 	.globl _PL_FLAG
                                    152 	.globl _PH_FLAG
                                    153 	.globl _EX0
                                    154 	.globl _ET0
                                    155 	.globl _EX1
                                    156 	.globl _ET1
                                    157 	.globl _ES
                                    158 	.globl _ET2
                                    159 	.globl _E_DIS
                                    160 	.globl _EA
                                    161 	.globl _P
                                    162 	.globl _F1
                                    163 	.globl _OV
                                    164 	.globl _RS0
                                    165 	.globl _RS1
                                    166 	.globl _F0
                                    167 	.globl _AC
                                    168 	.globl _CY
                                    169 	.globl _I2CS_INT_ST
                                    170 	.globl _I2CX_INT
                                    171 	.globl _LED_STATUS
                                    172 	.globl _LED_DMA_H
                                    173 	.globl _LED_DMA_L
                                    174 	.globl _LED_DMA
                                    175 	.globl _LED_PWM_OE
                                    176 	.globl _LED_COMMON
                                    177 	.globl _ADC_CHAN
                                    178 	.globl _ADC_DAT_H
                                    179 	.globl _ADC_DAT_L
                                    180 	.globl _ADC_DAT
                                    181 	.globl _ADC_CTRL
                                    182 	.globl _SPI1_CK_SE
                                    183 	.globl _SPI1_CTRL
                                    184 	.globl _SPI1_DATA
                                    185 	.globl _SPI1_STAT
                                    186 	.globl _SIF1
                                    187 	.globl _SBAUD1
                                    188 	.globl _SBUF1
                                    189 	.globl _SCON1
                                    190 	.globl _SPI0_SETUP
                                    191 	.globl _SPI0_CK_SE
                                    192 	.globl _SPI0_CTRL
                                    193 	.globl _SPI0_DATA
                                    194 	.globl _SPI0_STAT
                                    195 	.globl _T2CAP1H
                                    196 	.globl _T2CAP1L
                                    197 	.globl _T2CAP1
                                    198 	.globl _TH2
                                    199 	.globl _TL2
                                    200 	.globl _T2COUNT
                                    201 	.globl _RCAP2H
                                    202 	.globl _RCAP2L
                                    203 	.globl _RCAP2
                                    204 	.globl _T2MOD
                                    205 	.globl _T2CON
                                    206 	.globl _SBUF
                                    207 	.globl _SCON
                                    208 	.globl _TH1
                                    209 	.globl _TH0
                                    210 	.globl _TL1
                                    211 	.globl _TL0
                                    212 	.globl _TMOD
                                    213 	.globl _TCON
                                    214 	.globl _XBUS_AUX
                                    215 	.globl _P7
                                    216 	.globl _P6_DIR
                                    217 	.globl _P6_OUT_PU
                                    218 	.globl _P6_IN
                                    219 	.globl _P5_DIR
                                    220 	.globl _P5_OUT_PU
                                    221 	.globl _P5_IN
                                    222 	.globl _P4_LED_KEY
                                    223 	.globl _P4_DIR_PU
                                    224 	.globl _P4_MOD_OC
                                    225 	.globl _P4
                                    226 	.globl _P3_DIR_PU
                                    227 	.globl _P3_MOD_OC
                                    228 	.globl _P3
                                    229 	.globl _P2_DIR_PU
                                    230 	.globl _P2_MOD_OC
                                    231 	.globl _P2
                                    232 	.globl _P1_DIR_PU
                                    233 	.globl _P1_MOD_OC
                                    234 	.globl _P1
                                    235 	.globl _P0_DIR_PU
                                    236 	.globl _P0_MOD_OC
                                    237 	.globl _P0
                                    238 	.globl _ROM_CTRL
                                    239 	.globl _ROM_DATA_HH
                                    240 	.globl _ROM_DATA_HL
                                    241 	.globl _ROM_DATA_HI
                                    242 	.globl _ROM_ADDR_H
                                    243 	.globl _ROM_ADDR_L
                                    244 	.globl _ROM_ADDR
                                    245 	.globl _GPIO_IE
                                    246 	.globl _IP_EX
                                    247 	.globl _IE_EX
                                    248 	.globl _IP
                                    249 	.globl _IE
                                    250 	.globl _WDOG_COUNT
                                    251 	.globl _RESET_KEEP
                                    252 	.globl _WAKE_CTRL
                                    253 	.globl _CLOCK_CFG
                                    254 	.globl _POWER_CFG
                                    255 	.globl _PCON
                                    256 	.globl _GLOBAL_CFG
                                    257 	.globl _SAFE_MOD
                                    258 	.globl _DPH
                                    259 	.globl _DPL
                                    260 	.globl _SP
                                    261 	.globl _A_INV
                                    262 	.globl _B
                                    263 	.globl _ACC
                                    264 	.globl _PSW
                                    265 	.globl _actual_keyboard_report
                                    266 	.globl _owned_usage_key_PARM_2
                                    267 	.globl _ak820_macro_change_PARM_3
                                    268 	.globl _ak820_macro_change_PARM_2
                                    269 	.globl _ak820_macro_cancelled
                                    270 	.globl _ak820_macro_primitive
                                    271 	.globl _ak820_macro_change
                                    272 	.globl _add_owned_mods
                                    273 	.globl _del_owned_mods
                                    274 	.globl _add_owned_weak_mods
                                    275 	.globl _del_owned_weak_mods
                                    276 	.globl _clear_owned_mods
                                    277 	.globl _clear_owned_keys
                                    278 	.globl _add_owned_key
                                    279 	.globl _del_owned_key
                                    280 	.globl _clear_owned_usages
                                    281 	.globl _owned_usage_key
                                    282 	.globl _send_keyboard_report
                                    283 	.globl _get_mods
                                    284 	.globl _clear_mods
                                    285 	.globl _get_weak_mods
                                    286 	.globl _add_weak_mods
                                    287 	.globl _del_weak_mods
                                    288 	.globl _clear_weak_mods
                                    289 ;--------------------------------------------------------
                                    290 ; special function registers
                                    291 ;--------------------------------------------------------
                                    292 	.area RSEG    (ABS,DATA)
      000000                        293 	.org 0x0000
                           0000D0   294 _PSW	=	0x00d0
                           0000E0   295 _ACC	=	0x00e0
                           0000F0   296 _B	=	0x00f0
                           0000FD   297 _A_INV	=	0x00fd
                           000081   298 _SP	=	0x0081
                           000082   299 _DPL	=	0x0082
                           000083   300 _DPH	=	0x0083
                           0000A1   301 _SAFE_MOD	=	0x00a1
                           0000B1   302 _GLOBAL_CFG	=	0x00b1
                           000087   303 _PCON	=	0x0087
                           0000BA   304 _POWER_CFG	=	0x00ba
                           0000B9   305 _CLOCK_CFG	=	0x00b9
                           0000A9   306 _WAKE_CTRL	=	0x00a9
                           0000FE   307 _RESET_KEEP	=	0x00fe
                           0000FF   308 _WDOG_COUNT	=	0x00ff
                           0000A8   309 _IE	=	0x00a8
                           0000B8   310 _IP	=	0x00b8
                           0000E8   311 _IE_EX	=	0x00e8
                           0000E9   312 _IP_EX	=	0x00e9
                           0000B2   313 _GPIO_IE	=	0x00b2
                           008584   314 _ROM_ADDR	=	0x8584
                           000084   315 _ROM_ADDR_L	=	0x0084
                           000085   316 _ROM_ADDR_H	=	0x0085
                           008F8E   317 _ROM_DATA_HI	=	0x8f8e
                           00008E   318 _ROM_DATA_HL	=	0x008e
                           00008F   319 _ROM_DATA_HH	=	0x008f
                           000086   320 _ROM_CTRL	=	0x0086
                           000080   321 _P0	=	0x0080
                           0000C4   322 _P0_MOD_OC	=	0x00c4
                           0000C5   323 _P0_DIR_PU	=	0x00c5
                           000090   324 _P1	=	0x0090
                           000092   325 _P1_MOD_OC	=	0x0092
                           000093   326 _P1_DIR_PU	=	0x0093
                           0000A0   327 _P2	=	0x00a0
                           000094   328 _P2_MOD_OC	=	0x0094
                           000095   329 _P2_DIR_PU	=	0x0095
                           0000B0   330 _P3	=	0x00b0
                           000096   331 _P3_MOD_OC	=	0x0096
                           000097   332 _P3_DIR_PU	=	0x0097
                           0000C0   333 _P4	=	0x00c0
                           0000C2   334 _P4_MOD_OC	=	0x00c2
                           0000C3   335 _P4_DIR_PU	=	0x00c3
                           0000C1   336 _P4_LED_KEY	=	0x00c1
                           0000AA   337 _P5_IN	=	0x00aa
                           0000AB   338 _P5_OUT_PU	=	0x00ab
                           0000AC   339 _P5_DIR	=	0x00ac
                           0000AD   340 _P6_IN	=	0x00ad
                           0000AE   341 _P6_OUT_PU	=	0x00ae
                           0000AF   342 _P6_DIR	=	0x00af
                           0000F1   343 _P7	=	0x00f1
                           0000A2   344 _XBUS_AUX	=	0x00a2
                           000088   345 _TCON	=	0x0088
                           000089   346 _TMOD	=	0x0089
                           00008A   347 _TL0	=	0x008a
                           00008B   348 _TL1	=	0x008b
                           00008C   349 _TH0	=	0x008c
                           00008D   350 _TH1	=	0x008d
                           000098   351 _SCON	=	0x0098
                           000099   352 _SBUF	=	0x0099
                           0000C8   353 _T2CON	=	0x00c8
                           0000C9   354 _T2MOD	=	0x00c9
                           00CBCA   355 _RCAP2	=	0xcbca
                           0000CA   356 _RCAP2L	=	0x00ca
                           0000CB   357 _RCAP2H	=	0x00cb
                           00CDCC   358 _T2COUNT	=	0xcdcc
                           0000CC   359 _TL2	=	0x00cc
                           0000CD   360 _TH2	=	0x00cd
                           00CFCE   361 _T2CAP1	=	0xcfce
                           0000CE   362 _T2CAP1L	=	0x00ce
                           0000CF   363 _T2CAP1H	=	0x00cf
                           0000F8   364 _SPI0_STAT	=	0x00f8
                           0000F9   365 _SPI0_DATA	=	0x00f9
                           0000FA   366 _SPI0_CTRL	=	0x00fa
                           0000FB   367 _SPI0_CK_SE	=	0x00fb
                           0000FC   368 _SPI0_SETUP	=	0x00fc
                           0000BC   369 _SCON1	=	0x00bc
                           0000BD   370 _SBUF1	=	0x00bd
                           0000BE   371 _SBAUD1	=	0x00be
                           0000BF   372 _SIF1	=	0x00bf
                           0000B4   373 _SPI1_STAT	=	0x00b4
                           0000B5   374 _SPI1_DATA	=	0x00b5
                           0000B6   375 _SPI1_CTRL	=	0x00b6
                           0000B7   376 _SPI1_CK_SE	=	0x00b7
                           0000F3   377 _ADC_CTRL	=	0x00f3
                           00F5F4   378 _ADC_DAT	=	0xf5f4
                           0000F4   379 _ADC_DAT_L	=	0x00f4
                           0000F5   380 _ADC_DAT_H	=	0x00f5
                           0000F6   381 _ADC_CHAN	=	0x00f6
                           0000A6   382 _LED_COMMON	=	0x00a6
                           0000A7   383 _LED_PWM_OE	=	0x00a7
                           00C7C6   384 _LED_DMA	=	0xc7c6
                           0000C6   385 _LED_DMA_L	=	0x00c6
                           0000C7   386 _LED_DMA_H	=	0x00c7
                           0000F7   387 _LED_STATUS	=	0x00f7
                           0000B3   388 _I2CX_INT	=	0x00b3
                           0000BB   389 _I2CS_INT_ST	=	0x00bb
                                    390 ;--------------------------------------------------------
                                    391 ; special function bits
                                    392 ;--------------------------------------------------------
                                    393 	.area RSEG    (ABS,DATA)
      000000                        394 	.org 0x0000
                           0000D7   395 _CY	=	0x00d7
                           0000D6   396 _AC	=	0x00d6
                           0000D5   397 _F0	=	0x00d5
                           0000D4   398 _RS1	=	0x00d4
                           0000D3   399 _RS0	=	0x00d3
                           0000D2   400 _OV	=	0x00d2
                           0000D1   401 _F1	=	0x00d1
                           0000D0   402 _P	=	0x00d0
                           0000AF   403 _EA	=	0x00af
                           0000AE   404 _E_DIS	=	0x00ae
                           0000AD   405 _ET2	=	0x00ad
                           0000AC   406 _ES	=	0x00ac
                           0000AB   407 _ET1	=	0x00ab
                           0000AA   408 _EX1	=	0x00aa
                           0000A9   409 _ET0	=	0x00a9
                           0000A8   410 _EX0	=	0x00a8
                           0000BF   411 _PH_FLAG	=	0x00bf
                           0000BE   412 _PL_FLAG	=	0x00be
                           0000BD   413 _PT2	=	0x00bd
                           0000BC   414 _PS	=	0x00bc
                           0000BB   415 _PT1	=	0x00bb
                           0000BA   416 _PX1	=	0x00ba
                           0000B9   417 _PT0	=	0x00b9
                           0000B8   418 _PX0	=	0x00b8
                           0000EF   419 _IE_WDOG	=	0x00ef
                           0000EE   420 _IE_GPIO	=	0x00ee
                           0000ED   421 _IE_PWM_I2C	=	0x00ed
                           0000EC   422 _IE_UART1	=	0x00ec
                           0000EB   423 _IE_ADC	=	0x00eb
                           0000E9   424 _IE_USB	=	0x00e9
                           0000E8   425 _IE_SPI0	=	0x00e8
                           000087   426 _P0_7	=	0x0087
                           000086   427 _P0_6	=	0x0086
                           000085   428 _P0_5	=	0x0085
                           000084   429 _P0_4	=	0x0084
                           000083   430 _P0_3	=	0x0083
                           000082   431 _P0_2	=	0x0082
                           000081   432 _P0_1	=	0x0081
                           000080   433 _P0_0	=	0x0080
                           000081   434 _SDA0	=	0x0081
                           000080   435 _SCL0	=	0x0080
                           000083   436 _TXD_	=	0x0083
                           000082   437 _RXD_	=	0x0082
                           000085   438 _AIN13	=	0x0085
                           000084   439 _AIN12	=	0x0084
                           000083   440 _AIN11	=	0x0083
                           000082   441 _AIN10	=	0x0082
                           000081   442 _AIN9	=	0x0081
                           000080   443 _AIN8	=	0x0080
                           000097   444 _P1_7	=	0x0097
                           000096   445 _P1_6	=	0x0096
                           000095   446 _P1_5	=	0x0095
                           000094   447 _P1_4	=	0x0094
                           000093   448 _P1_3	=	0x0093
                           000092   449 _P1_2	=	0x0092
                           000091   450 _P1_1	=	0x0091
                           000090   451 _P1_0	=	0x0090
                           000097   452 _TXD1_	=	0x0097
                           000096   453 _RXD1_	=	0x0096
                           000097   454 _SCK	=	0x0097
                           000096   455 _MISO	=	0x0096
                           000095   456 _MOSI	=	0x0095
                           000094   457 _SCS	=	0x0094
                           000092   458 _INT0_	=	0x0092
                           000091   459 _T2EX	=	0x0091
                           000091   460 _CAP2	=	0x0091
                           000090   461 _T2	=	0x0090
                           000090   462 _CAP1	=	0x0090
                           000097   463 _AIN7	=	0x0097
                           000096   464 _AIN6	=	0x0096
                           000095   465 _AIN5	=	0x0095
                           000094   466 _AIN4	=	0x0094
                           000093   467 _AIN3	=	0x0093
                           000092   468 _AIN2	=	0x0092
                           000091   469 _AIN1	=	0x0091
                           000090   470 _AIN0	=	0x0090
                           0000A7   471 _P2_7	=	0x00a7
                           0000A6   472 _P2_6	=	0x00a6
                           0000A5   473 _P2_5	=	0x00a5
                           0000A4   474 _P2_4	=	0x00a4
                           0000A3   475 _P2_3	=	0x00a3
                           0000A2   476 _P2_2	=	0x00a2
                           0000A1   477 _P2_1	=	0x00a1
                           0000A0   478 _P2_0	=	0x00a0
                           0000A7   479 _TXD1	=	0x00a7
                           0000A6   480 _RXD1	=	0x00a6
                           0000A5   481 _T2EX_	=	0x00a5
                           0000A5   482 _CAP2_	=	0x00a5
                           0000A4   483 _T2_	=	0x00a4
                           0000A4   484 _CAP1_	=	0x00a4
                           0000B7   485 _P3_7	=	0x00b7
                           0000B6   486 _P3_6	=	0x00b6
                           0000B5   487 _P3_5	=	0x00b5
                           0000B4   488 _P3_4	=	0x00b4
                           0000B3   489 _P3_3	=	0x00b3
                           0000B2   490 _P3_2	=	0x00b2
                           0000B1   491 _P3_1	=	0x00b1
                           0000B0   492 _P3_0	=	0x00b0
                           0000B7   493 _SCK1	=	0x00b7
                           0000B6   494 _MISO1	=	0x00b6
                           0000B5   495 _MOSI1	=	0x00b5
                           0000B5   496 _T1	=	0x00b5
                           0000B4   497 _T0	=	0x00b4
                           0000B3   498 _INT1	=	0x00b3
                           0000B2   499 _INT0	=	0x00b2
                           0000B1   500 _TXD	=	0x00b1
                           0000B0   501 _RXD	=	0x00b0
                           0000C6   502 _P4_6	=	0x00c6
                           0000C5   503 _P4_5	=	0x00c5
                           0000C4   504 _P4_4	=	0x00c4
                           0000C3   505 _P4_3	=	0x00c3
                           0000C2   506 _P4_2	=	0x00c2
                           0000C1   507 _P4_1	=	0x00c1
                           0000C0   508 _P4_0	=	0x00c0
                           00008F   509 _TF1	=	0x008f
                           00008E   510 _TR1	=	0x008e
                           00008D   511 _TF0	=	0x008d
                           00008C   512 _TR0	=	0x008c
                           00008B   513 _IE1	=	0x008b
                           00008A   514 _IT1	=	0x008a
                           000089   515 _IE0	=	0x0089
                           000088   516 _IT0	=	0x0088
                           00009F   517 _SM0	=	0x009f
                           00009E   518 _SM1	=	0x009e
                           00009D   519 _SM2	=	0x009d
                           00009C   520 _REN	=	0x009c
                           00009B   521 _TB8	=	0x009b
                           00009A   522 _RB8	=	0x009a
                           000099   523 _TI	=	0x0099
                           000098   524 _RI	=	0x0098
                           0000CF   525 _TF2	=	0x00cf
                           0000CF   526 _CAP1F	=	0x00cf
                           0000CE   527 _EXF2	=	0x00ce
                           0000CD   528 _RCLK	=	0x00cd
                           0000CC   529 _TCLK	=	0x00cc
                           0000CB   530 _EXEN2	=	0x00cb
                           0000CA   531 _TR2	=	0x00ca
                           0000C9   532 _C_T2	=	0x00c9
                           0000C8   533 _CP_RL2	=	0x00c8
                           0000FF   534 _S0_FST_ACT	=	0x00ff
                           0000FE   535 _S0_IF_OV	=	0x00fe
                           0000FD   536 _S0_IF_FIRST	=	0x00fd
                           0000FC   537 _S0_IF_BYTE	=	0x00fc
                           0000FB   538 _S0_FREE	=	0x00fb
                           0000FA   539 _S0_T_FIFO	=	0x00fa
                           0000F8   540 _S0_R_FIFO	=	0x00f8
                           0000F7   541 _ADC_START	=	0x00f7
                                    542 ;--------------------------------------------------------
                                    543 ; overlayable register banks
                                    544 ;--------------------------------------------------------
                                    545 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        546 	.ds 8
                                    547 ;--------------------------------------------------------
                                    548 ; internal ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area DSEG    (DATA)
                                    551 ;--------------------------------------------------------
                                    552 ; overlayable items in internal ram
                                    553 ;--------------------------------------------------------
                                    554 	.area	OSEG    (OVR,DATA)
      000058                        555 _change_owned_sloc1_1_0:
      000058                        556 	.ds 1
                                    557 ;--------------------------------------------------------
                                    558 ; indirectly addressable internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area ISEG    (DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; absolute internal ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area IABS    (ABS,DATA)
                                    565 	.area IABS    (ABS,DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; bit data
                                    568 ;--------------------------------------------------------
                                    569 	.area BSEG    (BIT)
      000021                        570 _ak820_macro_change_sloc0_1_0:
      000021                        571 	.ds 1
      000022                        572 _change_owned_sloc0_1_0:
      000022                        573 	.ds 1
      000023                        574 _owned_usage_key_sloc0_1_0:
      000023                        575 	.ds 1
                                    576 ;--------------------------------------------------------
                                    577 ; paged external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area PSEG    (PAG,XDATA)
                                    580 ;--------------------------------------------------------
                                    581 ; uninitialized external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area XSEG    (XDATA)
      0009CD                        584 _owned_mod_refs:
      0009CD                        585 	.ds 8
      0009D5                        586 _owned_weak_refs:
      0009D5                        587 	.ds 8
      0009DD                        588 _owned_mods:
      0009DD                        589 	.ds 1
      0009DE                        590 _owned_weak_mods:
      0009DE                        591 	.ds 1
      0009DF                        592 _macro_mods:
      0009DF                        593 	.ds 2
      0009E1                        594 _ak820_macro_primitive::
      0009E1                        595 	.ds 1
      0009E2                        596 _ak820_macro_cancelled::
      0009E2                        597 	.ds 1
      0009E3                        598 _ak820_macro_change_PARM_2:
      0009E3                        599 	.ds 1
      0009E4                        600 _ak820_macro_change_PARM_3:
      0009E4                        601 	.ds 1
      0009E5                        602 _ak820_macro_change_bits_10000_355:
      0009E5                        603 	.ds 2
      0009E7                        604 _change_owned_PARM_2:
      0009E7                        605 	.ds 1
      0009E8                        606 _change_owned_mods_10000_360:
      0009E8                        607 	.ds 1
      0009E9                        608 _change_owned_result_10001_364:
      0009E9                        609 	.ds 1
      0009EA                        610 _change_owned_bit_20001_365:
      0009EA                        611 	.ds 1
      0009EB                        612 _add_owned_mods_mods_10000_373:
      0009EB                        613 	.ds 1
      0009EC                        614 _del_owned_mods_mods_10000_375:
      0009EC                        615 	.ds 1
      0009ED                        616 _add_owned_weak_mods_mods_10000_377:
      0009ED                        617 	.ds 1
      0009EE                        618 _del_owned_weak_mods_mods_10000_379:
      0009EE                        619 	.ds 1
      0009EF                        620 _key_refs:
      0009EF                        621 	.ds 165
      000A94                        622 _distinct_keys:
      000A94                        623 	.ds 1
      000A95                        624 _macro_keys:
      000A95                        625 	.ds 21
      000AAA                        626 _add_owned_key_code_10000_388:
      000AAA                        627 	.ds 1
      000AAB                        628 _del_owned_key_code_10000_403:
      000AAB                        629 	.ds 1
      000AAC                        630 _usage_refs:
      000AAC                        631 	.ds 30
      000ACA                        632 _usage_order:
      000ACA                        633 	.ds 30
      000AE8                        634 _usage_lengths:
      000AE8                        635 	.ds 2
      000AEA                        636 _macro_usages:
      000AEA                        637 	.ds 4
      000AEE                        638 _owned_usage_key_PARM_2:
      000AEE                        639 	.ds 1
      000AEF                        640 _owned_usage_key_code_10000_430:
      000AEF                        641 	.ds 1
      000AF0                        642 _owned_usage_key___200000090_20000_431:
      000AF0                        643 	.ds 2
      000AF2                        644 _owned_usage_key_which_10000_431:
      000AF2                        645 	.ds 1
      000AF3                        646 _owned_usage_key_count_10000_431:
      000AF3                        647 	.ds 1
      000AF4                        648 _owned_usage_key_pos_30001_438:
      000AF4                        649 	.ds 1
      000AF5                        650 _owned_usage_key_key_40000_443:
      000AF5                        651 	.ds 1
      000AF6                        652 _send_keyboard_report_projected_10001_450:
      000AF6                        653 	.ds 32
      000B16                        654 _send_keyboard_report_empty_50002_457:
      000B16                        655 	.ds 1
      000B17                        656 _send_keyboard_report_present_50002_457:
      000B17                        657 	.ds 1
      000B18                        658 _send_keyboard_report_last_report_10003_466:
      000B18                        659 	.ds 32
      000B38                        660 _send_keyboard_report_changed_10003_466:
      000B38                        661 	.ds 1
      000B39                        662 _add_weak_mods_mods_10000_484:
      000B39                        663 	.ds 1
      000B3A                        664 _del_weak_mods_mods_10000_486:
      000B3A                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000E47                        674 _real_mods:
      000E47                        675 	.ds 1
      000E48                        676 _weak_mods:
      000E48                        677 	.ds 1
      000E49                        678 _actual_keyboard_report::
      000E49                        679 	.ds 32
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT0 (CODE)
                                    682 	.area GSINIT1 (CODE)
                                    683 	.area GSINIT2 (CODE)
                                    684 	.area GSINIT3 (CODE)
                                    685 	.area GSINIT4 (CODE)
                                    686 	.area GSINIT5 (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area CSEG    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; global & static initialisations
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 	.area GSFINAL (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    708 ;------------------------------------------------------------
                                    709 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    710 ;------------------------------------------------------------
                                    711 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function ak820_macro_change
                                    722 ;	-----------------------------------------
      007F40                        723 _ak820_macro_change:
      007F40 12 38 42         [24]  724 	lcall	_ak820_outline_0108
      007F43 90 09 E5         [24]  725 	mov	dptr,#_ak820_macro_change_bits_10000_355
      007F46 12 38 47         [24]  726 	lcall	_ak820_outline_0109
                                    727 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007F49 90 09 E1         [24]  728 	mov	dptr,#_ak820_macro_primitive
      007F4C E0               [24]  729 	movx	a,@dptr
      007F4D 70 04            [24]  730 	jnz	00102$
      007F4F 75 82 01         [24]  731 	mov	dpl, #0x01
      007F52 22               [24]  732 	ret
      007F53                        733 00102$:
                                    734 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007F53 90 09 E3         [24]  735 	mov	dptr,#_ak820_macro_change_PARM_2
      007F56 E0               [24]  736 	movx	a,@dptr
      007F57 FF               [12]  737 	mov	r7,a
      007F58 12 7A F0         [24]  738 	lcall	_ak820_outline_0041
      007F5B 80 02            [24]  739 	sjmp	00123$
      007F5D                        740 00122$:
      007F5D 25 E0            [12]  741 	add	a,acc
      007F5F                        742 00123$:
      007F5F D5 F0 FB         [24]  743 	djnz	b,00122$
      007F62 FE               [12]  744 	mov	r6,a
                                    745 ;	quantum/action_util.c:101: bits += index >> 3;
      007F63 12 85 A7         [24]  746 	lcall	_ak820_outline_0170
      007F66 FF               [12]  747 	mov	r7,a
      007F67 90 09 E5         [24]  748 	mov	dptr,#_ak820_macro_change_bits_10000_355
      007F6A 12 38 18         [24]  749 	lcall	_ak820_outline_0065
      007F6D 90 09 E5         [24]  750 	mov	dptr,#_ak820_macro_change_bits_10000_355
      007F70 EF               [12]  751 	mov	a,r7
      007F71 2C               [12]  752 	add	a, r4
      007F72 F0               [24]  753 	movx	@dptr,a
      007F73 E4               [12]  754 	clr	a
      007F74 3D               [12]  755 	addc	a, r5
      007F75 A3               [24]  756 	inc	dptr
      007F76 F0               [24]  757 	movx	@dptr,a
                                    758 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007F77 90 09 E5         [24]  759 	mov	dptr,#_ak820_macro_change_bits_10000_355
      007F7A E0               [24]  760 	movx	a,@dptr
      007F7B FD               [12]  761 	mov	r5,a
      007F7C A3               [24]  762 	inc	dptr
      007F7D E0               [24]  763 	movx	a,@dptr
      007F7E FF               [12]  764 	mov	r7,a
      007F7F 12 40 6C         [24]  765 	lcall	_ak820_outline_0190
      007F82 E0               [24]  766 	movx	a,@dptr
      007F83 FC               [12]  767 	mov	r4,a
      007F84 EE               [12]  768 	mov	a,r6
      007F85 5C               [12]  769 	anl	a,r4
      007F86 B4 01 00         [24]  770 	cjne	a,#0x01,00124$
      007F89                        771 00124$:
      007F89 B3               [12]  772 	cpl	c
      007F8A 92 21            [24]  773 	mov	_ak820_macro_change_sloc0_1_0,c
      007F8C 90 09 E4         [24]  774 	mov	dptr,#_ak820_macro_change_PARM_3
      007F8F E0               [24]  775 	movx	a,@dptr
      007F90 FB               [12]  776 	mov	r3,a
      007F91 A2 21            [12]  777 	mov	c,_ak820_macro_change_sloc0_1_0
      007F93 E4               [12]  778 	clr	a
      007F94 33               [12]  779 	rlc	a
      007F95 B5 03 04         [24]  780 	cjne	a,ar3,00104$
      007F98 75 82 00         [24]  781 	mov	dpl, #0x00
      007F9B 22               [24]  782 	ret
      007F9C                        783 00104$:
                                    784 ;	quantum/action_util.c:103: *bits ^= mask;
      007F9C EC               [12]  785 	mov	a,r4
      007F9D 62 06            [12]  786 	xrl	ar6,a
      007F9F 12 40 6C         [24]  787 	lcall	_ak820_outline_0190
      007FA2 EE               [12]  788 	mov	a,r6
      007FA3 F0               [24]  789 	movx	@dptr,a
                                    790 ;	quantum/action_util.c:104: return true;
      007FA4 75 82 01         [24]  791 	mov	dpl, #0x01
                                    792 ;	quantum/action_util.c:105: }
      007FA7 22               [24]  793 	ret
                                    794 ;------------------------------------------------------------
                                    795 ;Allocation info for local variables in function 'change_owned'
                                    796 ;------------------------------------------------------------
                                    797 ;mode          Allocated with name '_change_owned_PARM_2'
                                    798 ;mods          Allocated with name '_change_owned_mods_10000_360'
                                    799 ;kind          Allocated with name '_change_owned_kind_10000_361'
                                    800 ;pressed       Allocated with name '_change_owned_pressed_10000_361'
                                    801 ;refs          Allocated with name '_change_owned_refs_10000_361'
                                    802 ;old           Allocated with name '_change_owned_old_30000_363'
                                    803 ;result        Allocated with name '_change_owned_result_10001_364'
                                    804 ;i             Allocated with name '_change_owned_i_20001_365'
                                    805 ;bit           Allocated with name '_change_owned_bit_20001_365'
                                    806 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function change_owned
                                    811 ;	-----------------------------------------
      007FA8                        812 _change_owned:
      007FA8 E5 82            [12]  813 	mov	a,dpl
      007FAA 90 09 E8         [24]  814 	mov	dptr,#_change_owned_mods_10000_360
      007FAD F0               [24]  815 	movx	@dptr,a
                                    816 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007FAE 90 09 E7         [24]  817 	mov	dptr,#_change_owned_PARM_2
      007FB1 E0               [24]  818 	movx	a,@dptr
      007FB2 FF               [12]  819 	mov	r7,a
      007FB3 C3               [12]  820 	clr	c
      007FB4 13               [12]  821 	rrc	a
      007FB5 FE               [12]  822 	mov	r6,a
                                    823 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007FB6 53 07 01         [24]  824 	anl	ar7,#0x01
      007FB9 EF               [12]  825 	mov	a,r7
      007FBA B4 01 00         [24]  826 	cjne	a,#0x01,00205$
      007FBD                        827 00205$:
      007FBD 92 22            [24]  828 	mov  _change_owned_sloc0_1_0,c
      007FBF B3               [12]  829 	cpl	c
      007FC0 E4               [12]  830 	clr	a
      007FC1 33               [12]  831 	rlc	a
      007FC2 F5 58            [12]  832 	mov	_change_owned_sloc1_1_0,a
                                    833 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007FC4 EE               [12]  834 	mov	a,r6
      007FC5 60 06            [24]  835 	jz	00121$
      007FC7 7D D5            [12]  836 	mov	r5,#_owned_weak_refs
      007FC9 7F 09            [12]  837 	mov	r7,#(_owned_weak_refs >> 8)
      007FCB 80 04            [24]  838 	sjmp	00122$
      007FCD                        839 00121$:
      007FCD 7D CD            [12]  840 	mov	r5,#_owned_mod_refs
      007FCF 7F 09            [12]  841 	mov	r7,#(_owned_mod_refs >> 8)
      007FD1                        842 00122$:
                                    843 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      007FD1 90 09 E1         [24]  844 	mov	dptr,#_ak820_macro_primitive
      007FD4 E0               [24]  845 	movx	a,@dptr
      007FD5 60 36            [24]  846 	jz	00102$
                                    847 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      007FD7 EE               [12]  848 	mov	a,r6
      007FD8 24 DF            [12]  849 	add	a, #_macro_mods
      007FDA FB               [12]  850 	mov	r3,a
      007FDB E4               [12]  851 	clr	a
      007FDC 34 09            [12]  852 	addc	a, #(_macro_mods >> 8)
      007FDE 12 4D 5B         [24]  853 	lcall	_ak820_outline_0061
                                    854 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007FE1 E5 58            [12]  855 	mov	a,_change_owned_sloc1_1_0
      007FE3 60 0A            [24]  856 	jz	00123$
      007FE5 90 09 E8         [24]  857 	mov	dptr,#_change_owned_mods_10000_360
      007FE8 E0               [24]  858 	movx	a,@dptr
      007FE9 F9               [12]  859 	mov	r1,a
      007FEA EA               [12]  860 	mov	a,r2
      007FEB 42 01            [12]  861 	orl	ar1,a
      007FED 80 07            [24]  862 	sjmp	00124$
      007FEF                        863 00123$:
      007FEF 90 09 E8         [24]  864 	mov	dptr,#_change_owned_mods_10000_360
      007FF2 E0               [24]  865 	movx	a,@dptr
      007FF3 F4               [12]  866 	cpl	a
      007FF4 5A               [12]  867 	anl	a,r2
      007FF5 F9               [12]  868 	mov	r1,a
      007FF6                        869 00124$:
      007FF6 12 33 FC         [24]  870 	lcall	_ak820_outline_0131
      007FF9 E9               [12]  871 	mov	a,r1
      007FFA F0               [24]  872 	movx	@dptr,a
                                    873 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      007FFB E5 58            [12]  874 	mov	a,_change_owned_sloc1_1_0
      007FFD 60 06            [24]  875 	jz	00125$
      007FFF 74 FF            [12]  876 	mov	a,#0xff
      008001 6A               [12]  877 	xrl	a,r2
      008002 FC               [12]  878 	mov	r4,a
      008003 80 02            [24]  879 	sjmp	00126$
      008005                        880 00125$:
      008005 8A 04            [24]  881 	mov	ar4,r2
      008007                        882 00126$:
      008007 90 09 E8         [24]  883 	mov	dptr,#_change_owned_mods_10000_360
      00800A E0               [24]  884 	movx	a,@dptr
      00800B 5C               [12]  885 	anl	a,r4
      00800C F0               [24]  886 	movx	@dptr,a
      00800D                        887 00102$:
                                    888 ;	quantum/action_util.c:115: uint8_t result = 0;
      00800D 90 09 E9         [24]  889 	mov	dptr,#_change_owned_result_10001_364
      008010 E4               [12]  890 	clr	a
      008011 F0               [24]  891 	movx	@dptr,a
                                    892 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      008012 90 09 EA         [24]  893 	mov	dptr,#_change_owned_bit_20001_365
      008015 04               [12]  894 	inc	a
      008016 F0               [24]  895 	movx	@dptr,a
      008017 90 09 E8         [24]  896 	mov	dptr,#_change_owned_mods_10000_360
      00801A E0               [24]  897 	movx	a,@dptr
      00801B FC               [12]  898 	mov	r4,a
      00801C 7B 00            [12]  899 	mov	r3,#0x00
      00801E                        900 00117$:
      00801E BB 08 00         [24]  901 	cjne	r3,#0x08,00210$
      008021                        902 00210$:
      008021 50 3F            [24]  903 	jnc	00112$
                                    904 ;	quantum/action_util.c:117: if (mods & bit) {
      008023 90 09 EA         [24]  905 	mov	dptr,#_change_owned_bit_20001_365
      008026 E0               [24]  906 	movx	a,@dptr
      008027 5C               [12]  907 	anl	a,r4
      008028 60 1C            [24]  908 	jz	00109$
                                    909 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      00802A E5 58            [12]  910 	mov	a,_change_owned_sloc1_1_0
      00802C 60 0C            [24]  911 	jz	00106$
      00802E EB               [12]  912 	mov	a,r3
      00802F 2D               [12]  913 	add	a, r5
      008030 12 37 D7         [24]  914 	lcall	_ak820_outline_0018
      008033 F8               [12]  915 	mov	r0,a
      008034 08               [12]  916 	inc	r0
      008035 12 85 5A         [24]  917 	lcall	_ak820_outline_0068
      008038 80 0C            [24]  918 	sjmp	00109$
      00803A                        919 00106$:
                                    920 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      00803A EB               [12]  921 	mov	a,r3
      00803B 2D               [12]  922 	add	a, r5
      00803C 12 37 D7         [24]  923 	lcall	_ak820_outline_0018
      00803F F8               [12]  924 	mov	r0,a
      008040 60 04            [24]  925 	jz	00109$
      008042 18               [12]  926 	dec	r0
      008043 12 85 5A         [24]  927 	lcall	_ak820_outline_0068
      008046                        928 00109$:
                                    929 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      008046 EB               [12]  930 	mov	a,r3
      008047 2D               [12]  931 	add	a, r5
      008048 12 37 D7         [24]  932 	lcall	_ak820_outline_0018
      00804B 60 0B            [24]  933 	jz	00118$
      00804D 90 09 EA         [24]  934 	mov	dptr,#_change_owned_bit_20001_365
      008050 E0               [24]  935 	movx	a,@dptr
      008051 FA               [12]  936 	mov	r2,a
      008052 90 09 E9         [24]  937 	mov	dptr,#_change_owned_result_10001_364
      008055 E0               [24]  938 	movx	a,@dptr
      008056 4A               [12]  939 	orl	a,r2
      008057 F0               [24]  940 	movx	@dptr,a
      008058                        941 00118$:
                                    942 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      008058 0B               [12]  943 	inc	r3
      008059 90 09 EA         [24]  944 	mov	dptr,#_change_owned_bit_20001_365
      00805C E0               [24]  945 	movx	a,@dptr
      00805D 25 E0            [12]  946 	add	a,acc
      00805F F0               [24]  947 	movx	@dptr,a
      008060 80 BC            [24]  948 	sjmp	00117$
      008062                        949 00112$:
                                    950 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      008062 EE               [12]  951 	mov	a,r6
      008063 60 09            [24]  952 	jz	00114$
      008065 90 09 E9         [24]  953 	mov	dptr,#_change_owned_result_10001_364
      008068 E0               [24]  954 	movx	a,@dptr
      008069 90 09 DE         [24]  955 	mov	dptr,#_owned_weak_mods
      00806C F0               [24]  956 	movx	@dptr,a
      00806D 22               [24]  957 	ret
      00806E                        958 00114$:
                                    959 ;	quantum/action_util.c:124: else owned_mods = result;
      00806E 90 09 E9         [24]  960 	mov	dptr,#_change_owned_result_10001_364
      008071 E0               [24]  961 	movx	a,@dptr
      008072 90 09 DD         [24]  962 	mov	dptr,#_owned_mods
      008075 F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:125: }
      008076 22               [24]  965 	ret
                                    966 ;------------------------------------------------------------
                                    967 ;Allocation info for local variables in function 'add_owned_mods'
                                    968 ;------------------------------------------------------------
                                    969 ;mods          Allocated with name '_add_owned_mods_mods_10000_373'
                                    970 ;------------------------------------------------------------
                                    971 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    972 ;	-----------------------------------------
                                    973 ;	 function add_owned_mods
                                    974 ;	-----------------------------------------
      008077                        975 _add_owned_mods:
      008077 E5 82            [12]  976 	mov	a,dpl
      008079 90 09 EB         [24]  977 	mov	dptr,#_add_owned_mods_mods_10000_373
      00807C 12 85 8A         [24]  978 	lcall	_ak820_outline_0122
      00807F 74 01            [12]  979 	mov	a,#0x01
      008081 F0               [24]  980 	movx	@dptr,a
      008082 8F 82            [24]  981 	mov	dpl, r7
      008084 02 7F A8         [24]  982 	ljmp	_change_owned
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'del_owned_mods'
                                    985 ;------------------------------------------------------------
                                    986 ;mods          Allocated with name '_del_owned_mods_mods_10000_375'
                                    987 ;------------------------------------------------------------
                                    988 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    989 ;	-----------------------------------------
                                    990 ;	 function del_owned_mods
                                    991 ;	-----------------------------------------
      008087                        992 _del_owned_mods:
      008087 E5 82            [12]  993 	mov	a,dpl
      008089 90 09 EC         [24]  994 	mov	dptr,#_del_owned_mods_mods_10000_375
      00808C 12 85 8A         [24]  995 	lcall	_ak820_outline_0122
      00808F E4               [12]  996 	clr	a
      008090 F0               [24]  997 	movx	@dptr,a
      008091 8F 82            [24]  998 	mov	dpl, r7
      008093 02 7F A8         [24]  999 	ljmp	_change_owned
                                   1000 ;------------------------------------------------------------
                                   1001 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1002 ;------------------------------------------------------------
                                   1003 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_377'
                                   1004 ;------------------------------------------------------------
                                   1005 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1006 ;	-----------------------------------------
                                   1007 ;	 function add_owned_weak_mods
                                   1008 ;	-----------------------------------------
      008096                       1009 _add_owned_weak_mods:
      008096 E5 82            [12] 1010 	mov	a,dpl
      008098 90 09 ED         [24] 1011 	mov	dptr,#_add_owned_weak_mods_mods_10000_377
      00809B 12 85 8A         [24] 1012 	lcall	_ak820_outline_0122
      00809E 74 03            [12] 1013 	mov	a,#0x03
      0080A0 F0               [24] 1014 	movx	@dptr,a
      0080A1 8F 82            [24] 1015 	mov	dpl, r7
      0080A3 02 7F A8         [24] 1016 	ljmp	_change_owned
                                   1017 ;------------------------------------------------------------
                                   1018 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1019 ;------------------------------------------------------------
                                   1020 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_379'
                                   1021 ;------------------------------------------------------------
                                   1022 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1023 ;	-----------------------------------------
                                   1024 ;	 function del_owned_weak_mods
                                   1025 ;	-----------------------------------------
      0080A6                       1026 _del_owned_weak_mods:
      0080A6 E5 82            [12] 1027 	mov	a,dpl
      0080A8 90 09 EE         [24] 1028 	mov	dptr,#_del_owned_weak_mods_mods_10000_379
      0080AB 12 85 8A         [24] 1029 	lcall	_ak820_outline_0122
      0080AE 74 02            [12] 1030 	mov	a,#0x02
      0080B0 F0               [24] 1031 	movx	@dptr,a
      0080B1 8F 82            [24] 1032 	mov	dpl, r7
      0080B3 02 7F A8         [24] 1033 	ljmp	_change_owned
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1036 ;------------------------------------------------------------
                                   1037 ;i             Allocated with name '_clear_owned_mods_i_20000_383'
                                   1038 ;------------------------------------------------------------
                                   1039 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1040 ;	-----------------------------------------
                                   1041 ;	 function clear_owned_mods
                                   1042 ;	-----------------------------------------
      0080B6                       1043 _clear_owned_mods:
                                   1044 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      0080B6 7F 00            [12] 1045 	mov	r7,#0x00
      0080B8                       1046 00103$:
      0080B8 BF 08 00         [24] 1047 	cjne	r7,#0x08,00122$
      0080BB                       1048 00122$:
      0080BB 50 1A            [24] 1049 	jnc	00101$
      0080BD EF               [12] 1050 	mov	a,r7
      0080BE 24 CD            [12] 1051 	add	a, #_owned_mod_refs
      0080C0 FD               [12] 1052 	mov	r5,a
      0080C1 E4               [12] 1053 	clr	a
      0080C2 34 09            [12] 1054 	addc	a, #(_owned_mod_refs >> 8)
      0080C4 FE               [12] 1055 	mov	r6,a
      0080C5 EF               [12] 1056 	mov	a,r7
      0080C6 24 D5            [12] 1057 	add	a, #_owned_weak_refs
      0080C8 F5 82            [12] 1058 	mov	dpl,a
      0080CA E4               [12] 1059 	clr	a
      0080CB 34 09            [12] 1060 	addc	a, #(_owned_weak_refs >> 8)
      0080CD F5 83            [12] 1061 	mov	dph,a
      0080CF E4               [12] 1062 	clr	a
      0080D0 F0               [24] 1063 	movx	@dptr,a
      0080D1 12 85 84         [24] 1064 	lcall	_ak820_outline_0104
      0080D4 0F               [12] 1065 	inc	r7
      0080D5 80 E1            [24] 1066 	sjmp	00103$
      0080D7                       1067 00101$:
                                   1068 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      0080D7 90 09 E0         [24] 1069 	mov	dptr,#(_macro_mods + 0x0001)
      0080DA E4               [12] 1070 	clr	a
      0080DB F0               [24] 1071 	movx	@dptr,a
      0080DC 90 09 DF         [24] 1072 	mov	dptr,#_macro_mods
      0080DF F0               [24] 1073 	movx	@dptr,a
      0080E0 90 09 DE         [24] 1074 	mov	dptr,#_owned_weak_mods
      0080E3 F0               [24] 1075 	movx	@dptr,a
      0080E4 90 09 DD         [24] 1076 	mov	dptr,#_owned_mods
      0080E7 F0               [24] 1077 	movx	@dptr,a
                                   1078 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      0080E8 90 09 E2         [24] 1079 	mov	dptr,#_ak820_macro_cancelled
      0080EB 04               [12] 1080 	inc	a
      0080EC F0               [24] 1081 	movx	@dptr,a
                                   1082 ;	quantum/action_util.c:134: }
      0080ED 22               [24] 1083 	ret
                                   1084 ;------------------------------------------------------------
                                   1085 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1086 ;------------------------------------------------------------
                                   1087 ;i             Allocated with name '_clear_owned_keys_i_20000_386'
                                   1088 ;i             Allocated with name '_clear_owned_keys_i_20000_387'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function clear_owned_keys
                                   1093 ;	-----------------------------------------
      0080EE                       1094 _clear_owned_keys:
                                   1095 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      0080EE 7F 00            [12] 1096 	mov	r7,#0x00
      0080F0                       1097 00104$:
      0080F0 EF               [12] 1098 	mov	a,r7
      0080F1 24 5B            [12] 1099 	add	a,#0xff - 0xa4
      0080F3 40 0D            [24] 1100 	jc	00101$
                                   1101 ;	free result
      0080F5 EF               [12] 1102 	mov	a,r7
      0080F6 24 EF            [12] 1103 	add	a, #_key_refs
      0080F8 F5 82            [12] 1104 	mov	dpl,a
      0080FA E4               [12] 1105 	clr	a
      0080FB 34 09            [12] 1106 	addc	a, #(_key_refs >> 8)
      0080FD 12 7F 31         [24] 1107 	lcall	_ak820_outline_0171
      008100 80 EE            [24] 1108 	sjmp	00104$
      008102                       1109 00101$:
                                   1110 ;	quantum/action_util.c:142: distinct_keys = 0;
      008102 90 0A 94         [24] 1111 	mov	dptr,#_distinct_keys
      008105 E4               [12] 1112 	clr	a
      008106 F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      008107 FF               [12] 1115 	mov	r7,a
      008108                       1116 00107$:
      008108 BF 15 00         [24] 1117 	cjne	r7,#0x15,00142$
      00810B                       1118 00142$:
      00810B 50 0D            [24] 1119 	jnc	00109$
      00810D EF               [12] 1120 	mov	a,r7
      00810E 24 95            [12] 1121 	add	a, #_macro_keys
      008110 F5 82            [12] 1122 	mov	dpl,a
      008112 E4               [12] 1123 	clr	a
      008113 34 0A            [12] 1124 	addc	a, #(_macro_keys >> 8)
      008115 12 7F 31         [24] 1125 	lcall	_ak820_outline_0171
      008118 80 EE            [24] 1126 	sjmp	00107$
      00811A                       1127 00109$:
                                   1128 ;	quantum/action_util.c:144: }
      00811A 22               [24] 1129 	ret
                                   1130 ;------------------------------------------------------------
                                   1131 ;Allocation info for local variables in function 'add_owned_key'
                                   1132 ;------------------------------------------------------------
                                   1133 ;code          Allocated with name '_add_owned_key_code_10000_388'
                                   1134 ;__400000079   Allocated with name '_add_owned_key___400000079_40000_397'
                                   1135 ;key           Allocated with name '_add_owned_key_key_50000_398'
                                   1136 ;i             Allocated with name '_add_owned_key_i_40000_396'
                                   1137 ;__300000081   Allocated with name '_add_owned_key___300000081_30000_400'
                                   1138 ;key           Allocated with name '_add_owned_key_key_40000_401'
                                   1139 ;------------------------------------------------------------
                                   1140 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1141 ;	-----------------------------------------
                                   1142 ;	 function add_owned_key
                                   1143 ;	-----------------------------------------
      00811B                       1144 _add_owned_key:
      00811B E5 82            [12] 1145 	mov	a,dpl
      00811D 90 0A AA         [24] 1146 	mov	dptr,#_add_owned_key_code_10000_388
      008120 12 85 9C         [24] 1147 	lcall	_ak820_outline_0139
                                   1148 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      008123 74 01            [12] 1149 	mov	a,#0x01
      008125 F0               [24] 1150 	movx	@dptr,a
      008126 90 0A 95         [24] 1151 	mov	dptr,#_macro_keys
      008129 C0 07            [24] 1152 	push	ar7
      00812B 12 7F 40         [24] 1153 	lcall	_ak820_macro_change
      00812E E5 82            [12] 1154 	mov	a, dpl
      008130 D0 07            [24] 1155 	pop	ar7
      008132 70 03            [24] 1156 	jnz	00102$
      008134 F5 82            [12] 1157 	mov	dpl,a
      008136 22               [24] 1158 	ret
      008137                       1159 00102$:
                                   1160 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      008137 12 85 4C         [24] 1161 	lcall	_ak820_outline_0031
      00813A FC               [12] 1162 	mov	r4,a
      00813B 04               [12] 1163 	inc	a
      00813C 12 85 84         [24] 1164 	lcall	_ak820_outline_0104
      00813F EC               [12] 1165 	mov	a,r4
      008140 60 04            [24] 1166 	jz	00104$
      008142 75 82 00         [24] 1167 	mov	dpl, #0x00
      008145 22               [24] 1168 	ret
      008146                       1169 00104$:
                                   1170 ;	quantum/action_util.c:148: ++distinct_keys;
      008146 90 0A 94         [24] 1171 	mov	dptr,#_distinct_keys
      008149 E0               [24] 1172 	movx	a,@dptr
      00814A 24 01            [12] 1173 	add	a, #0x01
      00814C F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      00814D 90 0E 36         [24] 1176 	mov	dptr,#_keyboard_protocol
      008150 E0               [24] 1177 	movx	a,@dptr
      008151 60 11            [24] 1178 	jz	00106$
      008153 90 0B 3D         [24] 1179 	mov	dptr,#_keymap_config
      008156 E0               [24] 1180 	movx	a,@dptr
      008157 30 E7 0A         [24] 1181 	jnb	acc.7,00106$
                                   1182 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00815A 12 85 AD         [24] 1183 	lcall	_ak820_outline_0182
      00815D 12 73 41         [24] 1184 	lcall	_add_key_to_report
                                   1185 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      008160 75 82 01         [24] 1186 	mov	dpl, #0x01
      008163 22               [24] 1187 	ret
      008164                       1188 00106$:
                                   1189 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      008164 90 0A 94         [24] 1190 	mov	dptr,#_distinct_keys
      008167 E0               [24] 1191 	movx	a,@dptr
      008168 24 F9            [12] 1192 	add	a,#0xff - 0x06
      00816A 50 17            [24] 1193 	jnc	00110$
                                   1194 ;	free result
                                   1195 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      00816C 7F 00            [12] 1196 	mov	r7,#0x00
      00816E                       1197 00115$:
      00816E BF 06 00         [24] 1198 	cjne	r7,#0x06,00174$
      008171                       1199 00174$:
      008171 50 1E            [24] 1200 	jnc	00111$
      008173 EF               [12] 1201 	mov	a,r7
      008174 24 4B            [12] 1202 	add	a, #(_actual_keyboard_report + 0x0002)
      008176 F5 82            [12] 1203 	mov	dpl,a
      008178 E4               [12] 1204 	clr	a
      008179 34 0E            [12] 1205 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      00817B F5 83            [12] 1206 	mov	dph,a
      00817D 74 01            [12] 1207 	mov	a,#0x01
      00817F F0               [24] 1208 	movx	@dptr,a
      008180 0F               [12] 1209 	inc	r7
      008181 80 EB            [24] 1210 	sjmp	00115$
      008183                       1211 00110$:
                                   1212 ;	quantum/action_util.c:154: } else add_key(code);
      008183 90 0A AA         [24] 1213 	mov	dptr,#_add_owned_key_code_10000_388
      008186 E0               [24] 1214 	movx	a,@dptr
                                   1215 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008187 90 08 60         [24] 1216 	mov	dptr,#_add_key_to_report_PARM_2
      00818A F0               [24] 1217 	movx	@dptr,a
      00818B 90 0E 49         [24] 1218 	mov	dptr,#_actual_keyboard_report
      00818E 12 73 41         [24] 1219 	lcall	_add_key_to_report
                                   1220 ;	quantum/action_util.c:154: } else add_key(code);
      008191                       1221 00111$:
                                   1222 ;	quantum/action_util.c:155: return true;
      008191 75 82 01         [24] 1223 	mov	dpl, #0x01
                                   1224 ;	quantum/action_util.c:156: }
      008194 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'del_owned_key'
                                   1228 ;------------------------------------------------------------
                                   1229 ;code          Allocated with name '_del_owned_key_code_10000_403'
                                   1230 ;__400000083   Allocated with name '_del_owned_key___400000083_40000_414'
                                   1231 ;key           Allocated with name '_del_owned_key_key_50000_415'
                                   1232 ;key           Allocated with name '_del_owned_key_key_40000_412'
                                   1233 ;__600000086   Allocated with name '_del_owned_key___600000086_60000_420'
                                   1234 ;key           Allocated with name '_del_owned_key_key_70000_421'
                                   1235 ;__300000088   Allocated with name '_del_owned_key___300000088_30000_423'
                                   1236 ;key           Allocated with name '_del_owned_key_key_40000_424'
                                   1237 ;------------------------------------------------------------
                                   1238 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1239 ;	-----------------------------------------
                                   1240 ;	 function del_owned_key
                                   1241 ;	-----------------------------------------
      008195                       1242 _del_owned_key:
      008195 E5 82            [12] 1243 	mov	a,dpl
      008197 90 0A AB         [24] 1244 	mov	dptr,#_del_owned_key_code_10000_403
      00819A 12 85 9C         [24] 1245 	lcall	_ak820_outline_0139
                                   1246 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      00819D E4               [12] 1247 	clr	a
      00819E F0               [24] 1248 	movx	@dptr,a
      00819F 90 0A 95         [24] 1249 	mov	dptr,#_macro_keys
      0081A2 C0 07            [24] 1250 	push	ar7
      0081A4 12 7F 40         [24] 1251 	lcall	_ak820_macro_change
      0081A7 E5 82            [12] 1252 	mov	a, dpl
      0081A9 D0 07            [24] 1253 	pop	ar7
      0081AB 70 03            [24] 1254 	jnz	00102$
      0081AD F5 82            [12] 1255 	mov	dpl,a
      0081AF 22               [24] 1256 	ret
      0081B0                       1257 00102$:
                                   1258 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      0081B0 12 85 4C         [24] 1259 	lcall	_ak820_outline_0031
      0081B3 FC               [12] 1260 	mov	r4,a
      0081B4 60 07            [24] 1261 	jz	00103$
      0081B6 1C               [12] 1262 	dec	r4
      0081B7 12 48 2F         [24] 1263 	lcall	_ak820_outline_0069
      0081BA EC               [12] 1264 	mov	a,r4
      0081BB 60 04            [24] 1265 	jz	00104$
      0081BD                       1266 00103$:
      0081BD 75 82 00         [24] 1267 	mov	dpl, #0x00
      0081C0 22               [24] 1268 	ret
      0081C1                       1269 00104$:
                                   1270 ;	quantum/action_util.c:160: --distinct_keys;
      0081C1 90 0A 94         [24] 1271 	mov	dptr,#_distinct_keys
      0081C4 E0               [24] 1272 	movx	a,@dptr
      0081C5 14               [12] 1273 	dec	a
      0081C6 F0               [24] 1274 	movx	@dptr,a
                                   1275 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      0081C7 90 0E 36         [24] 1276 	mov	dptr,#_keyboard_protocol
      0081CA E0               [24] 1277 	movx	a,@dptr
      0081CB 60 16            [24] 1278 	jz	00107$
      0081CD 90 0B 3D         [24] 1279 	mov	dptr,#_keymap_config
      0081D0 E0               [24] 1280 	movx	a,@dptr
      0081D1 30 E7 0F         [24] 1281 	jnb	acc.7,00107$
                                   1282 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      0081D4 90 08 63         [24] 1283 	mov	dptr,#_del_key_from_report_PARM_2
      0081D7 EF               [12] 1284 	mov	a,r7
      0081D8 F0               [24] 1285 	movx	@dptr,a
      0081D9 90 0E 49         [24] 1286 	mov	dptr,#_actual_keyboard_report
      0081DC 12 73 75         [24] 1287 	lcall	_del_key_from_report
                                   1288 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      0081DF 75 82 01         [24] 1289 	mov	dpl, #0x01
      0081E2 22               [24] 1290 	ret
      0081E3                       1291 00107$:
                                   1292 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      0081E3 90 0A 94         [24] 1293 	mov	dptr,#_distinct_keys
      0081E6 E0               [24] 1294 	movx	a,@dptr
      0081E7 FF               [12] 1295 	mov  r7,a
      0081E8 24 F9            [12] 1296 	add	a,#0xff - 0x06
      0081EA 50 04            [24] 1297 	jnc	00110$
                                   1298 ;	free result
      0081EC 75 82 01         [24] 1299 	mov	dpl, #0x01
      0081EF 22               [24] 1300 	ret
      0081F0                       1301 00110$:
                                   1302 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      0081F0 BF 06 1F         [24] 1303 	cjne	r7,#0x06,00115$
                                   1304 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0081F3 90 0E 49         [24] 1305 	mov	dptr,#_actual_keyboard_report
      0081F6 12 73 A9         [24] 1306 	lcall	_clear_keys_from_report
                                   1307 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      0081F9 7F 04            [12] 1308 	mov	r7,#0x04
      0081FB                       1309 00122$:
      0081FB EF               [12] 1310 	mov	a,r7
      0081FC 24 5B            [12] 1311 	add	a,#0xff - 0xa4
      0081FE 40 20            [24] 1312 	jc	00116$
                                   1313 ;	free result
      008200 12 85 4C         [24] 1314 	lcall	_ak820_outline_0031
      008203 60 0A            [24] 1315 	jz	00123$
                                   1316 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008205 12 85 AD         [24] 1317 	lcall	_ak820_outline_0182
      008208 C0 07            [24] 1318 	push	ar7
      00820A 12 73 41         [24] 1319 	lcall	_add_key_to_report
      00820D D0 07            [24] 1320 	pop	ar7
                                   1321 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      00820F                       1322 00123$:
      00820F 0F               [12] 1323 	inc	r7
      008210 80 E9            [24] 1324 	sjmp	00122$
      008212                       1325 00115$:
                                   1326 ;	quantum/action_util.c:169: } else del_key(code);
      008212 90 0A AB         [24] 1327 	mov	dptr,#_del_owned_key_code_10000_403
      008215 E0               [24] 1328 	movx	a,@dptr
                                   1329 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008216 90 08 63         [24] 1330 	mov	dptr,#_del_key_from_report_PARM_2
      008219 F0               [24] 1331 	movx	@dptr,a
      00821A 90 0E 49         [24] 1332 	mov	dptr,#_actual_keyboard_report
      00821D 12 73 75         [24] 1333 	lcall	_del_key_from_report
                                   1334 ;	quantum/action_util.c:169: } else del_key(code);
      008220                       1335 00116$:
                                   1336 ;	quantum/action_util.c:170: return true;
      008220 75 82 01         [24] 1337 	mov	dpl, #0x01
                                   1338 ;	quantum/action_util.c:171: }
      008223 22               [24] 1339 	ret
                                   1340 ;------------------------------------------------------------
                                   1341 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1342 ;------------------------------------------------------------
                                   1343 ;i             Allocated with name '_clear_owned_usages_i_20000_428'
                                   1344 ;i             Allocated with name '_clear_owned_usages_i_20000_429'
                                   1345 ;------------------------------------------------------------
                                   1346 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1347 ;	-----------------------------------------
                                   1348 ;	 function clear_owned_usages
                                   1349 ;	-----------------------------------------
      008224                       1350 _clear_owned_usages:
                                   1351 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      008224 7F 00            [12] 1352 	mov	r7,#0x00
      008226                       1353 00104$:
      008226 BF 1E 00         [24] 1354 	cjne	r7,#0x1e,00141$
      008229                       1355 00141$:
      008229 50 14            [24] 1356 	jnc	00101$
      00822B EF               [12] 1357 	mov	a,r7
      00822C 24 AC            [12] 1358 	add	a, #_usage_refs
      00822E FD               [12] 1359 	mov	r5,a
      00822F E4               [12] 1360 	clr	a
      008230 34 0A            [12] 1361 	addc	a, #(_usage_refs >> 8)
      008232 FE               [12] 1362 	mov	r6,a
      008233 EF               [12] 1363 	mov	a,r7
      008234 12 85 6B         [24] 1364 	lcall	_ak820_outline_0073
      008237 E4               [12] 1365 	clr	a
      008238 F0               [24] 1366 	movx	@dptr,a
      008239 12 85 84         [24] 1367 	lcall	_ak820_outline_0104
      00823C 0F               [12] 1368 	inc	r7
      00823D 80 E7            [24] 1369 	sjmp	00104$
      00823F                       1370 00101$:
                                   1371 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      00823F 90 0A E9         [24] 1372 	mov	dptr,#(_usage_lengths + 0x0001)
      008242 E4               [12] 1373 	clr	a
      008243 F0               [24] 1374 	movx	@dptr,a
      008244 90 0A E8         [24] 1375 	mov	dptr,#_usage_lengths
      008247 F0               [24] 1376 	movx	@dptr,a
                                   1377 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      008248 FF               [12] 1378 	mov	r7,a
      008249                       1379 00107$:
      008249 BF 04 00         [24] 1380 	cjne	r7,#0x04,00143$
      00824C                       1381 00143$:
      00824C 50 0D            [24] 1382 	jnc	00109$
      00824E EF               [12] 1383 	mov	a,r7
      00824F 24 EA            [12] 1384 	add	a, #_macro_usages
      008251 F5 82            [12] 1385 	mov	dpl,a
      008253 E4               [12] 1386 	clr	a
      008254 34 0A            [12] 1387 	addc	a, #(_macro_usages >> 8)
      008256 12 7F 31         [24] 1388 	lcall	_ak820_outline_0171
      008259 80 EE            [24] 1389 	sjmp	00107$
      00825B                       1390 00109$:
                                   1391 ;	quantum/action_util.c:185: }
      00825B 22               [24] 1392 	ret
                                   1393 ;------------------------------------------------------------
                                   1394 ;Allocation info for local variables in function 'owned_usage_key'
                                   1395 ;------------------------------------------------------------
                                   1396 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1397 ;code          Allocated with name '_owned_usage_key_code_10000_430'
                                   1398 ;__200000090   Allocated with name '_owned_usage_key___200000090_20000_431'
                                   1399 ;which         Allocated with name '_owned_usage_key_which_10000_431'
                                   1400 ;base          Allocated with name '_owned_usage_key_base_10000_431'
                                   1401 ;count         Allocated with name '_owned_usage_key_count_10000_431'
                                   1402 ;index         Allocated with name '_owned_usage_key_index_10000_431'
                                   1403 ;pos           Allocated with name '_owned_usage_key_pos_30001_438'
                                   1404 ;i             Allocated with name '_owned_usage_key_i_40001_439'
                                   1405 ;__300000091   Allocated with name '_owned_usage_key___300000091_30000_442'
                                   1406 ;key           Allocated with name '_owned_usage_key_key_40000_443'
                                   1407 ;------------------------------------------------------------
                                   1408 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1409 ;	-----------------------------------------
                                   1410 ;	 function owned_usage_key
                                   1411 ;	-----------------------------------------
      00825C                       1412 _owned_usage_key:
      00825C E5 82            [12] 1413 	mov	a,dpl
      00825E 90 0A EF         [24] 1414 	mov	dptr,#_owned_usage_key_code_10000_430
      008261 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      008262 E0               [24] 1417 	movx	a,@dptr
      008263 FF               [12] 1418 	mov	r7,a
      008264 BF A8 00         [24] 1419 	cjne	r7,#0xa8,00244$
      008267                       1420 00244$:
      008267 B3               [12] 1421 	cpl	c
      008268 92 23            [24] 1422 	mov	_owned_usage_key_sloc0_1_0,c
      00826A E4               [12] 1423 	clr	a
      00826B 33               [12] 1424 	rlc	a
      00826C FF               [12] 1425 	mov	r7,a
      00826D 90 0A F2         [24] 1426 	mov	dptr,#_owned_usage_key_which_10000_431
      008270 F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      008271 EF               [12] 1429 	mov	a,r7
      008272 60 02            [24] 1430 	jz	00129$
      008274 74 03            [12] 1431 	mov	a,#0x03
      008276                       1432 00129$:
      008276 FE               [12] 1433 	mov	r6,a
                                   1434 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      008277 EF               [12] 1435 	mov	a,r7
      008278 24 E8            [12] 1436 	add	a, #_usage_lengths
      00827A FD               [12] 1437 	mov	r5,a
      00827B E4               [12] 1438 	clr	a
      00827C 34 0A            [12] 1439 	addc	a, #(_usage_lengths >> 8)
      00827E FF               [12] 1440 	mov	r7,a
      00827F 12 40 6C         [24] 1441 	lcall	_ak820_outline_0190
      008282 E0               [24] 1442 	movx	a,@dptr
      008283 FC               [12] 1443 	mov	r4,a
                                   1444 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      008284 90 0A EF         [24] 1445 	mov	dptr,#_owned_usage_key_code_10000_430
      008287 E0               [24] 1446 	movx	a,@dptr
      008288 24 5B            [12] 1447 	add	a,#0x5b
      00828A FB               [12] 1448 	mov	r3,a
                                   1449 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      00828B 90 0A EE         [24] 1450 	mov	dptr,#_owned_usage_key_PARM_2
      00828E E0               [24] 1451 	movx	a,@dptr
      00828F FA               [12] 1452 	mov	r2,a
      008290 90 09 E3         [24] 1453 	mov	dptr,#_ak820_macro_change_PARM_2
      008293 EB               [12] 1454 	mov	a,r3
      008294 F0               [24] 1455 	movx	@dptr,a
      008295 90 09 E4         [24] 1456 	mov	dptr,#_ak820_macro_change_PARM_3
      008298 EA               [12] 1457 	mov	a,r2
      008299 F0               [24] 1458 	movx	@dptr,a
      00829A 90 0A EA         [24] 1459 	mov	dptr,#_macro_usages
      00829D C0 07            [24] 1460 	push	ar7
      00829F C0 06            [24] 1461 	push	ar6
      0082A1 C0 05            [24] 1462 	push	ar5
      0082A3 C0 04            [24] 1463 	push	ar4
      0082A5 C0 03            [24] 1464 	push	ar3
      0082A7 C0 02            [24] 1465 	push	ar2
      0082A9 12 7F 40         [24] 1466 	lcall	_ak820_macro_change
      0082AC E5 82            [12] 1467 	mov	a, dpl
      0082AE D0 02            [24] 1468 	pop	ar2
      0082B0 D0 03            [24] 1469 	pop	ar3
      0082B2 D0 04            [24] 1470 	pop	ar4
      0082B4 D0 05            [24] 1471 	pop	ar5
      0082B6 D0 06            [24] 1472 	pop	ar6
      0082B8 D0 07            [24] 1473 	pop	ar7
      0082BA 70 01            [24] 1474 	jnz	00102$
      0082BC 22               [24] 1475 	ret
      0082BD                       1476 00102$:
                                   1477 ;	quantum/action_util.c:192: if (pressed) {
      0082BD EA               [12] 1478 	mov	a,r2
      0082BE 60 1A            [24] 1479 	jz	00115$
                                   1480 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      0082C0 12 85 75         [24] 1481 	lcall	_ak820_outline_0077
      0082C3 04               [12] 1482 	inc	a
      0082C4 12 70 C5         [24] 1483 	lcall	_ak820_outline_0145
      0082C7 E8               [12] 1484 	mov	a,r0
      0082C8 60 01            [24] 1485 	jz	00104$
      0082CA 22               [24] 1486 	ret
      0082CB                       1487 00104$:
                                   1488 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      0082CB 90 0A F3         [24] 1489 	mov	dptr,#_owned_usage_key_count_10000_431
      0082CE EC               [12] 1490 	mov	a,r4
      0082CF 04               [12] 1491 	inc	a
      0082D0 F0               [24] 1492 	movx	@dptr,a
      0082D1 EC               [12] 1493 	mov	a,r4
      0082D2 2E               [12] 1494 	add	a, r6
      0082D3 12 85 6B         [24] 1495 	lcall	_ak820_outline_0073
      0082D6 EB               [12] 1496 	mov	a,r3
      0082D7 F0               [24] 1497 	movx	@dptr,a
      0082D8 61 3B            [12] 1498 	ajmp	00116$
      0082DA                       1499 00115$:
                                   1500 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      0082DA 12 85 75         [24] 1501 	lcall	_ak820_outline_0077
      0082DD 60 07            [24] 1502 	jz	00105$
      0082DF 18               [12] 1503 	dec	r0
      0082E0 12 85 5A         [24] 1504 	lcall	_ak820_outline_0068
      0082E3 E8               [12] 1505 	mov	a,r0
      0082E4 60 01            [24] 1506 	jz	00106$
      0082E6                       1507 00105$:
      0082E6 22               [24] 1508 	ret
      0082E7                       1509 00106$:
                                   1510 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      0082E7 7A 00            [12] 1511 	mov	r2,#0x00
      0082E9                       1512 00108$:
      0082E9 EA               [12] 1513 	mov	a,r2
      0082EA 2E               [12] 1514 	add	a, r6
      0082EB 12 85 6B         [24] 1515 	lcall	_ak820_outline_0073
      0082EE E0               [24] 1516 	movx	a,@dptr
      0082EF B5 03 02         [24] 1517 	cjne	a,ar3,00251$
      0082F2 80 03            [24] 1518 	sjmp	00167$
      0082F4                       1519 00251$:
      0082F4 0A               [12] 1520 	inc	r2
      0082F5 80 F2            [24] 1521 	sjmp	00108$
      0082F7                       1522 00167$:
      0082F7 90 0A F4         [24] 1523 	mov	dptr,#_owned_usage_key_pos_30001_438
      0082FA EA               [12] 1524 	mov	a,r2
      0082FB F0               [24] 1525 	movx	@dptr,a
                                   1526 ;	quantum/action_util.c:199: --count;
      0082FC 1C               [12] 1527 	dec	r4
      0082FD 90 0A F3         [24] 1528 	mov	dptr,#_owned_usage_key_count_10000_431
      008300 EC               [12] 1529 	mov	a,r4
      008301 F0               [24] 1530 	movx	@dptr,a
                                   1531 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      008302 8A 03            [24] 1532 	mov	ar3,r2
      008304                       1533 00125$:
      008304 C3               [12] 1534 	clr	c
      008305 EB               [12] 1535 	mov	a,r3
      008306 9C               [12] 1536 	subb	a,r4
      008307 50 23            [24] 1537 	jnc	00111$
      008309 C0 05            [24] 1538 	push	ar5
      00830B C0 07            [24] 1539 	push	ar7
      00830D EB               [12] 1540 	mov	a,r3
      00830E 2E               [12] 1541 	add	a, r6
      00830F FA               [12] 1542 	mov	r2,a
      008310 24 CA            [12] 1543 	add	a, #_usage_order
      008312 F8               [12] 1544 	mov	r0,a
      008313 E4               [12] 1545 	clr	a
      008314 34 0A            [12] 1546 	addc	a, #(_usage_order >> 8)
      008316 F9               [12] 1547 	mov	r1,a
      008317 0A               [12] 1548 	inc	r2
      008318 EA               [12] 1549 	mov	a,r2
      008319 33               [12] 1550 	rlc	a
      00831A 95 E0            [12] 1551 	subb	a,acc
      00831C FF               [12] 1552 	mov	r7,a
      00831D EA               [12] 1553 	mov	a,r2
      00831E 12 85 91         [24] 1554 	lcall	_ak820_outline_0133
      008321 12 38 6C         [24] 1555 	lcall	_ak820_outline_0162
      008324 F0               [24] 1556 	movx	@dptr,a
      008325 0B               [12] 1557 	inc	r3
      008326 D0 07            [24] 1558 	pop	ar7
      008328 D0 05            [24] 1559 	pop	ar5
      00832A 80 D8            [24] 1560 	sjmp	00125$
      00832C                       1561 00111$:
                                   1562 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      00832C 12 40 6C         [24] 1563 	lcall	_ak820_outline_0190
      00832F EC               [12] 1564 	mov	a,r4
      008330 F0               [24] 1565 	movx	@dptr,a
                                   1566 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      008331 90 0A F4         [24] 1567 	mov	dptr,#_owned_usage_key_pos_30001_438
      008334 E0               [24] 1568 	movx	a,@dptr
      008335 B5 04 02         [24] 1569 	cjne	a,ar4,00253$
      008338 80 01            [24] 1570 	sjmp	00116$
      00833A                       1571 00253$:
      00833A 22               [24] 1572 	ret
      00833B                       1573 00116$:
                                   1574 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      00833B 90 0A F3         [24] 1575 	mov	dptr,#_owned_usage_key_count_10000_431
      00833E E0               [24] 1576 	movx	a,@dptr
      00833F FC               [12] 1577 	mov	r4,a
      008340 12 40 6C         [24] 1578 	lcall	_ak820_outline_0190
      008343 F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      008344 EC               [12] 1581 	mov	a,r4
      008345 60 15            [24] 1582 	jz	00131$
      008347 EC               [12] 1583 	mov	a,r4
      008348 2E               [12] 1584 	add	a, r6
      008349 FE               [12] 1585 	mov	r6,a
      00834A 1E               [12] 1586 	dec	r6
      00834B EE               [12] 1587 	mov	a,r6
      00834C 33               [12] 1588 	rlc	a
      00834D 95 E0            [12] 1589 	subb	a,acc
      00834F FF               [12] 1590 	mov	r7,a
      008350 EE               [12] 1591 	mov	a,r6
      008351 12 85 91         [24] 1592 	lcall	_ak820_outline_0133
      008354 24 A5            [12] 1593 	add	a,#0xa5
      008356 FE               [12] 1594 	mov	r6,a
      008357 33               [12] 1595 	rlc	a
      008358 95 E0            [12] 1596 	subb	a,acc
      00835A 80 02            [24] 1597 	sjmp	00132$
      00835C                       1598 00131$:
      00835C 7E 00            [12] 1599 	mov	r6,#0x00
      00835E                       1600 00132$:
      00835E 90 0A EF         [24] 1601 	mov	dptr,#_owned_usage_key_code_10000_430
      008361 EE               [12] 1602 	mov	a,r6
      008362 F0               [24] 1603 	movx	@dptr,a
                                   1604 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      008363 90 0A F2         [24] 1605 	mov	dptr,#_owned_usage_key_which_10000_431
      008366 E0               [24] 1606 	movx	a,@dptr
      008367 60 18            [24] 1607 	jz	00118$
      008369 EE               [12] 1608 	mov	a,r6
      00836A 60 0B            [24] 1609 	jz	00133$
      00836C 8E 82            [24] 1610 	mov	dpl, r6
      00836E 12 71 FC         [24] 1611 	lcall	_KEYCODE2CONSUMER
      008371 AD 82            [24] 1612 	mov	r5, dpl
      008373 AF 83            [24] 1613 	mov	r7, dph
      008375 80 04            [24] 1614 	sjmp	00134$
      008377                       1615 00133$:
      008377 7D 00            [12] 1616 	mov	r5,#0x00
      008379 7F 00            [12] 1617 	mov	r7,#0x00
      00837B                       1618 00134$:
      00837B 12 40 6C         [24] 1619 	lcall	_ak820_outline_0190
      00837E 02 71 B7         [24] 1620 	ljmp	_host_consumer_send
      008381                       1621 00118$:
                                   1622 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008381 EE               [12] 1623 	mov	a,r6
      008382 60 22            [24] 1624 	jz	00135$
                                   1625 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008384 BE A5 00         [24] 1626 	cjne	r6,#0xa5,00258$
      008387                       1627 00258$:
      008387 40 05            [24] 1628 	jc	00121$
      008389 EE               [12] 1629 	mov	a,r6
      00838A 24 58            [12] 1630 	add	a,#0xff - 0xa7
      00838C 50 08            [24] 1631 	jnc	00122$
                                   1632 ;	free result
      00838E                       1633 00121$:
      00838E 90 0A F0         [24] 1634 	mov	dptr,#_owned_usage_key___200000090_20000_431
      008391 12 53 F4         [24] 1635 	lcall	_ak820_outline_0155
      008394 80 09            [24] 1636 	sjmp	00123$
      008396                       1637 00122$:
                                   1638 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008396 74 DC            [12] 1639 	mov	a,#0xdc
      008398 2E               [12] 1640 	add	a, r6
      008399 90 0A F0         [24] 1641 	mov	dptr,#_owned_usage_key___200000090_20000_431
      00839C 12 38 57         [24] 1642 	lcall	_ak820_outline_0132
                                   1643 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00839F                       1644 00123$:
      00839F 90 0A F0         [24] 1645 	mov	dptr,#_owned_usage_key___200000090_20000_431
      0083A2 E0               [24] 1646 	movx	a,@dptr
      0083A3 FF               [12] 1647 	mov	r7,a
      0083A4 80 02            [24] 1648 	sjmp	00136$
      0083A6                       1649 00135$:
      0083A6 7F 00            [12] 1650 	mov	r7,#0x00
      0083A8                       1651 00136$:
      0083A8 7E 00            [12] 1652 	mov	r6,#0x00
      0083AA 12 48 73         [24] 1653 	lcall	_ak820_outline_0164
                                   1654 ;	quantum/action_util.c:208: }
      0083AD 02 71 88         [24] 1655 	ljmp	_host_system_send
                                   1656 ;------------------------------------------------------------
                                   1657 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1658 ;------------------------------------------------------------
                                   1659 ;projected     Allocated with name '_send_keyboard_report_projected_10001_450'
                                   1660 ;out           Allocated with name '_send_keyboard_report_out_10001_450'
                                   1661 ;base          Allocated with name '_send_keyboard_report_base_10001_450'
                                   1662 ;i             Allocated with name '_send_keyboard_report_i_20001_451'
                                   1663 ;overlay_key   Allocated with name '_send_keyboard_report_overlay_key_10002_452'
                                   1664 ;empty         Allocated with name '_send_keyboard_report_empty_50002_457'
                                   1665 ;present       Allocated with name '_send_keyboard_report_present_50002_457'
                                   1666 ;i             Allocated with name '_send_keyboard_report_i_60002_458'
                                   1667 ;i             Allocated with name '_send_keyboard_report_i_90002_465'
                                   1668 ;last_report   Allocated with name '_send_keyboard_report_last_report_10003_466'
                                   1669 ;changed       Allocated with name '_send_keyboard_report_changed_10003_466'
                                   1670 ;dest          Allocated with name '_send_keyboard_report_dest_10003_466'
                                   1671 ;src           Allocated with name '_send_keyboard_report_src_10003_466'
                                   1672 ;i             Allocated with name '_send_keyboard_report_i_20003_467'
                                   1673 ;------------------------------------------------------------
                                   1674 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1675 ;	-----------------------------------------
                                   1676 ;	 function send_keyboard_report
                                   1677 ;	-----------------------------------------
      0083B0                       1678 _send_keyboard_report:
                                   1679 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      0083B0 90 0E 47         [24] 1680 	mov	dptr,#_real_mods
      0083B3 E0               [24] 1681 	movx	a,@dptr
      0083B4 FF               [12] 1682 	mov	r7,a
      0083B5 90 0E 49         [24] 1683 	mov	dptr,#_actual_keyboard_report
      0083B8 F0               [24] 1684 	movx	@dptr,a
                                   1685 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      0083B9 90 0E 48         [24] 1686 	mov	dptr,#_weak_mods
      0083BC E0               [24] 1687 	movx	a,@dptr
      0083BD 42 07            [12] 1688 	orl	ar7,a
      0083BF 90 0E 49         [24] 1689 	mov	dptr,#_actual_keyboard_report
      0083C2 EF               [12] 1690 	mov	a,r7
      0083C3 F0               [24] 1691 	movx	@dptr,a
                                   1692 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      0083C4 90 09 DE         [24] 1693 	mov	dptr,#_owned_weak_mods
      0083C7 E0               [24] 1694 	movx	a,@dptr
      0083C8 FE               [12] 1695 	mov	r6,a
      0083C9 90 09 DD         [24] 1696 	mov	dptr,#_owned_mods
      0083CC E0               [24] 1697 	movx	a,@dptr
      0083CD 4E               [12] 1698 	orl	a,r6
      0083CE 42 07            [12] 1699 	orl	ar7,a
      0083D0 90 0E 49         [24] 1700 	mov	dptr,#_actual_keyboard_report
      0083D3 EF               [12] 1701 	mov	a,r7
      0083D4 F0               [24] 1702 	movx	@dptr,a
                                   1703 ;	quantum/action_util.c:458: ak820_key_override_sync(keyboard_report->mods, get_highest_layer(layer_state | default_layer_state));
      0083D5 90 0E 45         [24] 1704 	mov	dptr,#_default_layer_state
      0083D8 E0               [24] 1705 	movx	a,@dptr
      0083D9 FE               [12] 1706 	mov	r6,a
      0083DA 90 0E 46         [24] 1707 	mov	dptr,#_layer_state
      0083DD E0               [24] 1708 	movx	a,@dptr
      0083DE 42 06            [12] 1709 	orl	ar6,a
      0083E0 8E 82            [24] 1710 	mov	dpl, r6
      0083E2 C0 07            [24] 1711 	push	ar7
      0083E4 B1 B6            [12] 1712 	acall	_biton
      0083E6 E5 82            [12] 1713 	mov	a, dpl
      0083E8 D0 07            [24] 1714 	pop	ar7
      0083EA 90 05 56         [24] 1715 	mov	dptr,#_ak820_key_override_sync_PARM_2
      0083ED F0               [24] 1716 	movx	@dptr,a
      0083EE 8F 82            [24] 1717 	mov	dpl, r7
      0083F0 12 3D C0         [24] 1718 	lcall	_ak820_key_override_sync
                                   1719 ;	quantum/action_util.c:459: keyboard_report->mods = ak820_key_override_mods(keyboard_report->mods);
      0083F3 90 0E 49         [24] 1720 	mov	dptr,#_actual_keyboard_report
      0083F6 E0               [24] 1721 	movx	a,@dptr
      0083F7 F5 82            [12] 1722 	mov	dpl,a
      0083F9 12 3F B5         [24] 1723 	lcall	_ak820_key_override_mods
      0083FC AF 82            [24] 1724 	mov	r7, dpl
      0083FE 90 0E 49         [24] 1725 	mov	dptr,#_actual_keyboard_report
      008401 EF               [12] 1726 	mov	a,r7
      008402 F0               [24] 1727 	movx	@dptr,a
                                   1728 ;	quantum/action_util.c:482: uint8_t AK820_STATE_MEM *out = (uint8_t AK820_STATE_MEM *)&projected;
                                   1729 ;	quantum/action_util.c:483: const uint8_t AK820_STATE_MEM *base = (const uint8_t AK820_STATE_MEM *)keyboard_report;
                                   1730 ;	quantum/action_util.c:484: for (uint8_t i = 0; i < sizeof(projected); ++i) out[i] = base[i];
      008403 7F 00            [12] 1731 	mov	r7,#0x00
      008405                       1732 00125$:
      008405 BF 20 00         [24] 1733 	cjne	r7,#0x20,00261$
      008408                       1734 00261$:
      008408 50 19            [24] 1735 	jnc	00101$
      00840A EF               [12] 1736 	mov	a,r7
      00840B 24 F6            [12] 1737 	add	a, #_send_keyboard_report_projected_10001_450
      00840D FD               [12] 1738 	mov	r5,a
      00840E E4               [12] 1739 	clr	a
      00840F 34 0A            [12] 1740 	addc	a, #(_send_keyboard_report_projected_10001_450 >> 8)
      008411 FE               [12] 1741 	mov	r6,a
      008412 EF               [12] 1742 	mov	a,r7
      008413 24 49            [12] 1743 	add	a, #_actual_keyboard_report
      008415 F5 82            [12] 1744 	mov	dpl,a
      008417 E4               [12] 1745 	clr	a
      008418 34 0E            [12] 1746 	addc	a, #(_actual_keyboard_report >> 8)
      00841A F5 83            [12] 1747 	mov	dph,a
      00841C E0               [24] 1748 	movx	a,@dptr
      00841D 12 85 84         [24] 1749 	lcall	_ak820_outline_0104
      008420 0F               [12] 1750 	inc	r7
      008421 80 E2            [24] 1751 	sjmp	00125$
      008423                       1752 00101$:
                                   1753 ;	quantum/action_util.c:485: uint8_t overlay_key = ak820_key_override_key();
      008423 12 3F 86         [24] 1754 	lcall	_ak820_key_override_key
                                   1755 ;	quantum/action_util.c:486: if (overlay_key) {
      008426 E5 82            [12] 1756 	mov	a,dpl
      008428 FF               [12] 1757 	mov	r7,a
      008429 70 02            [24] 1758 	jnz	00263$
      00842B 81 BB            [12] 1759 	ajmp	00118$
      00842D                       1760 00263$:
                                   1761 ;	quantum/action_util.c:488: if (keyboard_protocol && keymap_config.nkro) {
      00842D 90 0E 36         [24] 1762 	mov	dptr,#_keyboard_protocol
      008430 E0               [24] 1763 	movx	a,@dptr
      008431 60 2B            [24] 1764 	jz	00114$
      008433 90 0B 3D         [24] 1765 	mov	dptr,#_keymap_config
      008436 E0               [24] 1766 	movx	a,@dptr
      008437 30 E7 24         [24] 1767 	jnb	acc.7,00114$
                                   1768 ;	quantum/action_util.c:489: projected.nkro.bits[overlay_key >> 3] |= 1u << (overlay_key & 7);
      00843A 12 85 A7         [24] 1769 	lcall	_ak820_outline_0170
      00843D 24 F8            [12] 1770 	add	a,#(_send_keyboard_report_projected_10001_450 + 0x0002)
      00843F FE               [12] 1771 	mov	r6,a
      008440 E4               [12] 1772 	clr	a
      008441 34 0A            [12] 1773 	addc	a, #((_send_keyboard_report_projected_10001_450 + 0x0002) >> 8)
      008443 FD               [12] 1774 	mov	r5,a
      008444 12 7A F0         [24] 1775 	lcall	_ak820_outline_0041
      008447 80 02            [24] 1776 	sjmp	00267$
      008449                       1777 00266$:
      008449 25 E0            [12] 1778 	add	a,acc
      00844B                       1779 00267$:
      00844B D5 F0 FB         [24] 1780 	djnz	b,00266$
      00844E FC               [12] 1781 	mov	r4,a
      00844F 8E 82            [24] 1782 	mov	dpl,r6
      008451 8D 83            [24] 1783 	mov	dph,r5
      008453 E0               [24] 1784 	movx	a,@dptr
      008454 42 04            [12] 1785 	orl	ar4,a
      008456 8E 82            [24] 1786 	mov	dpl,r6
      008458 8D 83            [24] 1787 	mov	dph,r5
      00845A EC               [12] 1788 	mov	a,r4
      00845B F0               [24] 1789 	movx	@dptr,a
      00845C 80 5D            [24] 1790 	sjmp	00118$
      00845E                       1791 00114$:
                                   1792 ;	quantum/action_util.c:493: uint8_t empty = 255;
      00845E 90 0B 16         [24] 1793 	mov	dptr,#_send_keyboard_report_empty_50002_457
      008461 74 FF            [12] 1794 	mov	a,#0xff
      008463 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	quantum/action_util.c:494: bool present = false;
      008464 90 0B 17         [24] 1797 	mov	dptr,#_send_keyboard_report_present_50002_457
      008467 E4               [12] 1798 	clr	a
      008468 F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	quantum/action_util.c:495: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) {
      008469 FE               [12] 1801 	mov	r6,a
      00846A                       1802 00128$:
      00846A BE 06 00         [24] 1803 	cjne	r6,#0x06,00268$
      00846D                       1804 00268$:
      00846D 50 23            [24] 1805 	jnc	00106$
                                   1806 ;	quantum/action_util.c:496: if (projected.keys[i] == overlay_key) present = true;
      00846F EE               [12] 1807 	mov	a,r6
      008470 12 85 61         [24] 1808 	lcall	_ak820_outline_0071
      008473 E0               [24] 1809 	movx	a,@dptr
      008474 B5 07 06         [24] 1810 	cjne	a,ar7,00103$
      008477 90 0B 17         [24] 1811 	mov	dptr,#_send_keyboard_report_present_50002_457
      00847A 74 01            [12] 1812 	mov	a,#0x01
      00847C F0               [24] 1813 	movx	@dptr,a
      00847D                       1814 00103$:
                                   1815 ;	quantum/action_util.c:497: if (!projected.keys[i]) empty = i;
      00847D EE               [12] 1816 	mov	a,r6
      00847E 24 F8            [12] 1817 	add	a, #(_send_keyboard_report_projected_10001_450 + 0x0002)
      008480 FC               [12] 1818 	mov	r4,a
      008481 E4               [12] 1819 	clr	a
      008482 34 0A            [12] 1820 	addc	a, #((_send_keyboard_report_projected_10001_450 + 0x0002) >> 8)
      008484 FD               [12] 1821 	mov	r5,a
      008485 12 40 46         [24] 1822 	lcall	_ak820_outline_0081
      008488 70 05            [24] 1823 	jnz	00129$
      00848A 90 0B 16         [24] 1824 	mov	dptr,#_send_keyboard_report_empty_50002_457
      00848D EE               [12] 1825 	mov	a,r6
      00848E F0               [24] 1826 	movx	@dptr,a
      00848F                       1827 00129$:
                                   1828 ;	quantum/action_util.c:495: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) {
      00848F 0E               [12] 1829 	inc	r6
      008490 80 D8            [24] 1830 	sjmp	00128$
      008492                       1831 00106$:
                                   1832 ;	quantum/action_util.c:499: if (!present) {
      008492 90 0B 17         [24] 1833 	mov	dptr,#_send_keyboard_report_present_50002_457
      008495 E0               [24] 1834 	movx	a,@dptr
      008496 70 23            [24] 1835 	jnz	00118$
                                   1836 ;	quantum/action_util.c:500: if (empty != 255) projected.keys[empty] = overlay_key;
      008498 90 0B 16         [24] 1837 	mov	dptr,#_send_keyboard_report_empty_50002_457
      00849B E0               [24] 1838 	movx	a,@dptr
      00849C FE               [12] 1839 	mov	r6,a
      00849D BE FF 02         [24] 1840 	cjne	r6,#0xff,00274$
      0084A0 80 08            [24] 1841 	sjmp	00167$
      0084A2                       1842 00274$:
      0084A2 EE               [12] 1843 	mov	a,r6
      0084A3 12 85 61         [24] 1844 	lcall	_ak820_outline_0071
      0084A6 EF               [12] 1845 	mov	a,r7
      0084A7 F0               [24] 1846 	movx	@dptr,a
                                   1847 ;	quantum/action_util.c:501: else for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) projected.keys[i] = 1;
      0084A8 80 11            [24] 1848 	sjmp	00118$
      0084AA                       1849 00167$:
      0084AA 7F 00            [12] 1850 	mov	r7,#0x00
      0084AC                       1851 00131$:
      0084AC BF 06 00         [24] 1852 	cjne	r7,#0x06,00275$
      0084AF                       1853 00275$:
      0084AF 50 0A            [24] 1854 	jnc	00118$
      0084B1 EF               [12] 1855 	mov	a,r7
      0084B2 12 85 61         [24] 1856 	lcall	_ak820_outline_0071
      0084B5 74 01            [12] 1857 	mov	a,#0x01
      0084B7 F0               [24] 1858 	movx	@dptr,a
      0084B8 0F               [12] 1859 	inc	r7
      0084B9 80 F1            [24] 1860 	sjmp	00131$
      0084BB                       1861 00118$:
                                   1862 ;	quantum/action_util.c:517: bool changed = false;
      0084BB 90 0B 38         [24] 1863 	mov	dptr,#_send_keyboard_report_changed_10003_466
      0084BE E4               [12] 1864 	clr	a
      0084BF F0               [24] 1865 	movx	@dptr,a
                                   1866 ;	quantum/action_util.c:519: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1867 ;	quantum/action_util.c:525: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0084C0 FF               [12] 1868 	mov	r7,a
      0084C1                       1869 00134$:
      0084C1 BF 20 00         [24] 1870 	cjne	r7,#0x20,00277$
      0084C4                       1871 00277$:
      0084C4 50 2B            [24] 1872 	jnc	00121$
                                   1873 ;	quantum/action_util.c:526: if (dest[i] != src[i]) {
      0084C6 EF               [12] 1874 	mov	a,r7
      0084C7 24 18            [12] 1875 	add	a, #_send_keyboard_report_last_report_10003_466
      0084C9 FD               [12] 1876 	mov	r5,a
      0084CA E4               [12] 1877 	clr	a
      0084CB 34 0B            [12] 1878 	addc	a, #(_send_keyboard_report_last_report_10003_466 >> 8)
      0084CD FE               [12] 1879 	mov	r6,a
      0084CE 12 4D 69         [24] 1880 	lcall	_ak820_outline_0079
      0084D1 EF               [12] 1881 	mov	a,r7
      0084D2 24 F6            [12] 1882 	add	a, #_send_keyboard_report_projected_10001_450
      0084D4 F5 82            [12] 1883 	mov	dpl,a
      0084D6 E4               [12] 1884 	clr	a
      0084D7 34 0A            [12] 1885 	addc	a, #(_send_keyboard_report_projected_10001_450 >> 8)
      0084D9 F5 83            [12] 1886 	mov	dph,a
      0084DB E0               [24] 1887 	movx	a,@dptr
      0084DC FB               [12] 1888 	mov	r3,a
      0084DD EC               [12] 1889 	mov	a,r4
      0084DE B5 03 02         [24] 1890 	cjne	a,ar3,00279$
      0084E1 80 0B            [24] 1891 	sjmp	00135$
      0084E3                       1892 00279$:
                                   1893 ;	quantum/action_util.c:527: dest[i] = src[i];
      0084E3 12 38 5C         [24] 1894 	lcall	_ak820_outline_0141
      0084E6 EB               [12] 1895 	mov	a,r3
      0084E7 F0               [24] 1896 	movx	@dptr,a
                                   1897 ;	quantum/action_util.c:528: changed = true;
      0084E8 90 0B 38         [24] 1898 	mov	dptr,#_send_keyboard_report_changed_10003_466
      0084EB 74 01            [12] 1899 	mov	a,#0x01
      0084ED F0               [24] 1900 	movx	@dptr,a
      0084EE                       1901 00135$:
                                   1902 ;	quantum/action_util.c:525: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0084EE 0F               [12] 1903 	inc	r7
      0084EF 80 D0            [24] 1904 	sjmp	00134$
      0084F1                       1905 00121$:
                                   1906 ;	quantum/action_util.c:531: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      0084F1 90 0B 38         [24] 1907 	mov	dptr,#_send_keyboard_report_changed_10003_466
      0084F4 E0               [24] 1908 	movx	a,@dptr
      0084F5 60 09            [24] 1909 	jz	00136$
      0084F7 90 0A F6         [24] 1910 	mov	dptr,#_send_keyboard_report_projected_10001_450
      0084FA 75 F0 00         [24] 1911 	mov	b, #0x00
                                   1912 ;	quantum/action_util.c:540: }
      0084FD 02 70 FD         [24] 1913 	ljmp	_host_keyboard_send
      008500                       1914 00136$:
      008500 22               [24] 1915 	ret
                                   1916 ;------------------------------------------------------------
                                   1917 ;Allocation info for local variables in function 'get_mods'
                                   1918 ;------------------------------------------------------------
                                   1919 ;	quantum/action_util.c:546: uint8_t get_mods(void) {
                                   1920 ;	-----------------------------------------
                                   1921 ;	 function get_mods
                                   1922 ;	-----------------------------------------
      008501                       1923 _get_mods:
      008501 C0 07            [24] 1924 	push	ar7
                                   1925 ;	quantum/action_util.c:551: ;
      008503 90 09 DD         [24] 1926 	mov	dptr,#_owned_mods
      008506 E0               [24] 1927 	movx	a,@dptr
      008507 FF               [12] 1928 	mov	r7,a
      008508 90 0E 47         [24] 1929 	mov	dptr,#_real_mods
      00850B 12 40 66         [24] 1930 	lcall	_ak820_outline_0130
                                   1931 ;	quantum/action_util.c:552: }
      00850E D0 07            [24] 1932 	pop	ar7
      008510 22               [24] 1933 	ret
                                   1934 ;------------------------------------------------------------
                                   1935 ;Allocation info for local variables in function 'add_mods'
                                   1936 ;------------------------------------------------------------
                                   1937 ;mods          Allocated with name '_add_mods_mods_10000_474'
                                   1938 ;------------------------------------------------------------
                                   1939 ;	quantum/action_util.c:557: void add_mods(uint8_t mods) {
                                   1940 ;	-----------------------------------------
                                   1941 ;	 function clear_mods
                                   1942 ;	-----------------------------------------
      008511                       1943 _clear_mods:
                                   1944 ;	quantum/action_util.c:579: real_mods = 0;
      008511 90 0E 47         [24] 1945 	mov	dptr,#_real_mods
      008514 E4               [12] 1946 	clr	a
      008515 F0               [24] 1947 	movx	@dptr,a
                                   1948 ;	quantum/action_util.c:580: }
      008516 22               [24] 1949 	ret
                                   1950 ;------------------------------------------------------------
                                   1951 ;Allocation info for local variables in function 'get_weak_mods'
                                   1952 ;------------------------------------------------------------
                                   1953 ;	quantum/action_util.c:586: uint8_t get_weak_mods(void) {
                                   1954 ;	-----------------------------------------
                                   1955 ;	 function get_weak_mods
                                   1956 ;	-----------------------------------------
      008517                       1957 _get_weak_mods:
      008517 C0 07            [24] 1958 	push	ar7
                                   1959 ;	quantum/action_util.c:591: ;
      008519 90 09 DE         [24] 1960 	mov	dptr,#_owned_weak_mods
      00851C E0               [24] 1961 	movx	a,@dptr
      00851D FF               [12] 1962 	mov	r7,a
      00851E 90 0E 48         [24] 1963 	mov	dptr,#_weak_mods
      008521 12 40 66         [24] 1964 	lcall	_ak820_outline_0130
                                   1965 ;	quantum/action_util.c:592: }
      008524 D0 07            [24] 1966 	pop	ar7
      008526 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'add_weak_mods'
                                   1970 ;------------------------------------------------------------
                                   1971 ;mods          Allocated with name '_add_weak_mods_mods_10000_484'
                                   1972 ;------------------------------------------------------------
                                   1973 ;	quantum/action_util.c:597: void add_weak_mods(uint8_t mods) {
                                   1974 ;	-----------------------------------------
                                   1975 ;	 function add_weak_mods
                                   1976 ;	-----------------------------------------
      008527                       1977 _add_weak_mods:
      008527 E5 82            [12] 1978 	mov	a,dpl
      008529 90 0B 39         [24] 1979 	mov	dptr,#_add_weak_mods_mods_10000_484
      00852C F0               [24] 1980 	movx	@dptr,a
                                   1981 ;	quantum/action_util.c:598: weak_mods |= mods;
      00852D E0               [24] 1982 	movx	a,@dptr
      00852E FF               [12] 1983 	mov	r7,a
      00852F 90 0E 48         [24] 1984 	mov	dptr,#_weak_mods
      008532 E0               [24] 1985 	movx	a,@dptr
      008533 4F               [12] 1986 	orl	a,r7
      008534 F0               [24] 1987 	movx	@dptr,a
                                   1988 ;	quantum/action_util.c:599: }
      008535 22               [24] 1989 	ret
                                   1990 ;------------------------------------------------------------
                                   1991 ;Allocation info for local variables in function 'del_weak_mods'
                                   1992 ;------------------------------------------------------------
                                   1993 ;mods          Allocated with name '_del_weak_mods_mods_10000_486'
                                   1994 ;------------------------------------------------------------
                                   1995 ;	quantum/action_util.c:604: void del_weak_mods(uint8_t mods) {
                                   1996 ;	-----------------------------------------
                                   1997 ;	 function del_weak_mods
                                   1998 ;	-----------------------------------------
      008536                       1999 _del_weak_mods:
      008536 E5 82            [12] 2000 	mov	a,dpl
      008538 90 0B 3A         [24] 2001 	mov	dptr,#_del_weak_mods_mods_10000_486
      00853B F0               [24] 2002 	movx	@dptr,a
                                   2003 ;	quantum/action_util.c:605: weak_mods &= ~mods;
      00853C E0               [24] 2004 	movx	a,@dptr
      00853D F4               [12] 2005 	cpl	a
      00853E FF               [12] 2006 	mov	r7,a
      00853F 90 0E 48         [24] 2007 	mov	dptr,#_weak_mods
      008542 E0               [24] 2008 	movx	a,@dptr
      008543 5F               [12] 2009 	anl	a,r7
      008544 F0               [24] 2010 	movx	@dptr,a
                                   2011 ;	quantum/action_util.c:606: }
      008545 22               [24] 2012 	ret
                                   2013 ;------------------------------------------------------------
                                   2014 ;Allocation info for local variables in function 'set_weak_mods'
                                   2015 ;------------------------------------------------------------
                                   2016 ;mods          Allocated with name '_set_weak_mods_mods_10000_488'
                                   2017 ;------------------------------------------------------------
                                   2018 ;	quantum/action_util.c:611: void set_weak_mods(uint8_t mods) {
                                   2019 ;	-----------------------------------------
                                   2020 ;	 function clear_weak_mods
                                   2021 ;	-----------------------------------------
      008546                       2022 _clear_weak_mods:
                                   2023 ;	quantum/action_util.c:619: weak_mods = 0;
      008546 90 0E 48         [24] 2024 	mov	dptr,#_weak_mods
      008549 E4               [12] 2025 	clr	a
      00854A F0               [24] 2026 	movx	@dptr,a
                                   2027 ;	quantum/action_util.c:620: }
      00854B 22               [24] 2028 	ret
                                   2029 ;------------------------------------------------------------
                                   2030 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   2031 ;------------------------------------------------------------
                                   2032 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_492'
                                   2033 ;------------------------------------------------------------
                                   2034 ;	quantum/action_util.c:702: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   2035 ;	-----------------------------------------
                                   2036 	.area CSEG    (CODE)
                                   2037 	.area CONST   (CODE)
                                   2038 	.area XINIT   (CODE)
      00C6B0                       2039 __xinit__real_mods:
      00C6B0 00                    2040 	.db #0x00	; 0
      00C6B1                       2041 __xinit__weak_mods:
      00C6B1 00                    2042 	.db #0x00	; 0
      00C6B2                       2043 __xinit__actual_keyboard_report:
      00C6B2 00                    2044 	.db #0x00	; 0
      00C6B3 00                    2045 	.db #0x00	; 0
      00C6B4 00                    2046 	.db #0x00	; 0
      00C6B5 00                    2047 	.db #0x00	; 0
      00C6B6 00                    2048 	.db #0x00	; 0
      00C6B7 00                    2049 	.db #0x00	; 0
      00C6B8 00                    2050 	.db #0x00	; 0
      00C6B9 00                    2051 	.db #0x00	; 0
      00C6BA 00                    2052 	.db 0x00
      00C6BB 00                    2053 	.db 0x00
      00C6BC 00                    2054 	.db 0x00
      00C6BD 00                    2055 	.db 0x00
      00C6BE 00                    2056 	.db 0x00
      00C6BF 00                    2057 	.db 0x00
      00C6C0 00                    2058 	.db 0x00
      00C6C1 00                    2059 	.db 0x00
      00C6C2 00                    2060 	.db 0x00
      00C6C3 00                    2061 	.db 0x00
      00C6C4 00                    2062 	.db 0x00
      00C6C5 00                    2063 	.db 0x00
      00C6C6 00                    2064 	.db 0x00
      00C6C7 00                    2065 	.db 0x00
      00C6C8 00                    2066 	.db 0x00
      00C6C9 00                    2067 	.db 0x00
      00C6CA 00                    2068 	.db 0x00
      00C6CB 00                    2069 	.db 0x00
      00C6CC 00                    2070 	.db 0x00
      00C6CD 00                    2071 	.db 0x00
      00C6CE 00                    2072 	.db 0x00
      00C6CF 00                    2073 	.db 0x00
      00C6D0 00                    2074 	.db 0x00
      00C6D1 00                    2075 	.db 0x00
                                   2076 	.area CABS    (ABS,CODE)
                                   2077 
                                   2078 ; Experimental exact instruction outlining.
                                   2079 	.globl _ak820_outline_0018
                                   2080 	.globl _ak820_outline_0031
                                   2081 	.globl _ak820_outline_0041
                                   2082 	.globl _ak820_outline_0061
                                   2083 	.globl _ak820_outline_0065
                                   2084 	.globl _ak820_outline_0068
                                   2085 	.globl _ak820_outline_0069
                                   2086 	.globl _ak820_outline_0071
                                   2087 	.globl _ak820_outline_0073
                                   2088 	.globl _ak820_outline_0077
                                   2089 	.globl _ak820_outline_0079
                                   2090 	.globl _ak820_outline_0081
                                   2091 	.globl _ak820_outline_0104
                                   2092 	.globl _ak820_outline_0108
                                   2093 	.globl _ak820_outline_0109
                                   2094 	.globl _ak820_outline_0122
                                   2095 	.globl _ak820_outline_0130
                                   2096 	.globl _ak820_outline_0131
                                   2097 	.globl _ak820_outline_0132
                                   2098 	.globl _ak820_outline_0133
                                   2099 	.globl _ak820_outline_0139
                                   2100 	.globl _ak820_outline_0141
                                   2101 	.globl _ak820_outline_0145
                                   2102 	.globl _ak820_outline_0155
                                   2103 	.globl _ak820_outline_0162
                                   2104 	.globl _ak820_outline_0164
                                   2105 	.globl _ak820_outline_0170
                                   2106 	.globl _ak820_outline_0171
                                   2107 	.globl _ak820_outline_0182
                                   2108 	.globl _ak820_outline_0190
                                   2109 
                                   2110 	.area CSEG (CODE)
                                   2111 ; function ak820_outline_0031
      00854C                       2112 _ak820_outline_0031:
      00854C EF               [12] 2113 	mov	a,r7
      00854D 24 EF            [12] 2114 	add	a,#_key_refs
      00854F FD               [12] 2115 	mov	r5,a
      008550 E4               [12] 2116 	clr	a
      008551 34 09            [12] 2117 	addc	a,#(_key_refs>>8)
      008553 FE               [12] 2118 	mov	r6,a
      008554 8D 82            [24] 2119 	mov	dpl,r5
      008556 8E 83            [24] 2120 	mov	dph,r6
      008558 E0               [24] 2121 	movx	a,@dptr
      008559 22               [24] 2122 	ret
                                   2123 
                                   2124 	.area CSEG (CODE)
                                   2125 ; function ak820_outline_0068
      00855A                       2126 _ak820_outline_0068:
      00855A 89 82            [24] 2127 	mov	dpl,r1
      00855C 8A 83            [24] 2128 	mov	dph,r2
      00855E E8               [12] 2129 	mov	a,r0
      00855F F0               [24] 2130 	movx	@dptr,a
      008560 22               [24] 2131 	ret
                                   2132 
                                   2133 	.area CSEG (CODE)
                                   2134 ; function ak820_outline_0071
      008561                       2135 _ak820_outline_0071:
      008561 24 F8            [12] 2136 	add	a,#(_send_keyboard_report_projected_10001_450+0x0002)
      008563 F5 82            [12] 2137 	mov	dpl,a
      008565 E4               [12] 2138 	clr	a
      008566 34 0A            [12] 2139 	addc	a,#((_send_keyboard_report_projected_10001_450+0x0002)>>8)
      008568 F5 83            [12] 2140 	mov	dph,a
      00856A 22               [24] 2141 	ret
                                   2142 
                                   2143 	.area CSEG (CODE)
                                   2144 ; function ak820_outline_0073
      00856B                       2145 _ak820_outline_0073:
      00856B 24 CA            [12] 2146 	add	a,#_usage_order
      00856D F5 82            [12] 2147 	mov	dpl,a
      00856F E4               [12] 2148 	clr	a
      008570 34 0A            [12] 2149 	addc	a,#(_usage_order>>8)
      008572 F5 83            [12] 2150 	mov	dph,a
      008574 22               [24] 2151 	ret
                                   2152 
                                   2153 	.area CSEG (CODE)
                                   2154 ; function ak820_outline_0077
      008575                       2155 _ak820_outline_0077:
      008575 EB               [12] 2156 	mov	a,r3
      008576 24 AC            [12] 2157 	add	a,#_usage_refs
      008578 F9               [12] 2158 	mov	r1,a
      008579 E4               [12] 2159 	clr	a
      00857A 34 0A            [12] 2160 	addc	a,#(_usage_refs>>8)
      00857C FA               [12] 2161 	mov	r2,a
      00857D 89 82            [24] 2162 	mov	dpl,r1
      00857F 8A 83            [24] 2163 	mov	dph,r2
      008581 E0               [24] 2164 	movx	a,@dptr
      008582 F8               [12] 2165 	mov	r0,a
      008583 22               [24] 2166 	ret
                                   2167 
                                   2168 	.area CSEG (CODE)
                                   2169 ; function ak820_outline_0104
      008584                       2170 _ak820_outline_0104:
      008584 8D 82            [24] 2171 	mov	dpl,r5
      008586 8E 83            [24] 2172 	mov	dph,r6
      008588 F0               [24] 2173 	movx	@dptr,a
      008589 22               [24] 2174 	ret
                                   2175 
                                   2176 	.area CSEG (CODE)
                                   2177 ; function ak820_outline_0122
      00858A                       2178 _ak820_outline_0122:
      00858A F0               [24] 2179 	movx	@dptr,a
      00858B E0               [24] 2180 	movx	a,@dptr
      00858C FF               [12] 2181 	mov	r7,a
      00858D 90 09 E7         [24] 2182 	mov	dptr,#_change_owned_PARM_2
      008590 22               [24] 2183 	ret
                                   2184 
                                   2185 	.area CSEG (CODE)
                                   2186 ; function ak820_outline_0133
      008591                       2187 _ak820_outline_0133:
      008591 24 CA            [12] 2188 	add	a,#_usage_order
      008593 F5 82            [12] 2189 	mov	dpl,a
      008595 EF               [12] 2190 	mov	a,r7
      008596 34 0A            [12] 2191 	addc	a,#(_usage_order>>8)
      008598 F5 83            [12] 2192 	mov	dph,a
      00859A E0               [24] 2193 	movx	a,@dptr
      00859B 22               [24] 2194 	ret
                                   2195 
                                   2196 	.area CSEG (CODE)
                                   2197 ; function ak820_outline_0139
      00859C                       2198 _ak820_outline_0139:
      00859C F0               [24] 2199 	movx	@dptr,a
      00859D E0               [24] 2200 	movx	a,@dptr
      00859E FF               [12] 2201 	mov	r7,a
      00859F 90 09 E3         [24] 2202 	mov	dptr,#_ak820_macro_change_PARM_2
      0085A2 F0               [24] 2203 	movx	@dptr,a
      0085A3 90 09 E4         [24] 2204 	mov	dptr,#_ak820_macro_change_PARM_3
      0085A6 22               [24] 2205 	ret
                                   2206 
                                   2207 	.area CSEG (CODE)
                                   2208 ; function ak820_outline_0170
      0085A7                       2209 _ak820_outline_0170:
      0085A7 EF               [12] 2210 	mov	a,r7
      0085A8 C4               [12] 2211 	swap	a
      0085A9 23               [12] 2212 	rl	a
      0085AA 54 1F            [12] 2213 	anl	a,#0x1f
      0085AC 22               [24] 2214 	ret
                                   2215 
                                   2216 	.area CSEG (CODE)
                                   2217 ; function ak820_outline_0182
      0085AD                       2218 _ak820_outline_0182:
      0085AD 90 08 60         [24] 2219 	mov	dptr,#_add_key_to_report_PARM_2
      0085B0 EF               [12] 2220 	mov	a,r7
      0085B1 F0               [24] 2221 	movx	@dptr,a
      0085B2 90 0E 49         [24] 2222 	mov	dptr,#_actual_keyboard_report
      0085B5 22               [24] 2223 	ret
