                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_key_override_valid
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_write_block_xdata
                                     16 	.globl _ak820_eeprom_read_block_xdata
                                     17 	.globl _ak820_nvm_flush
                                     18 	.globl _ak820_nvm_ok
                                     19 	.globl _ak820_macro_reset
                                     20 	.globl _ak820_macro_write
                                     21 	.globl _ak820_macro_length
                                     22 	.globl _ak820_macro_ready
                                     23 	.globl _send_char
                                     24 	.globl _keycode_at_encodermap_location_raw
                                     25 	.globl _keycode_at_keymap_location_raw
                                     26 	.globl _vial_keycode_tap
                                     27 	.globl _vial_keycode_up
                                     28 	.globl _vial_keycode_down
                                     29 	.globl _clear_keyboard
                                     30 	.globl _tap_code
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _mDelaymS
                                     34 	.globl ___memcpy
                                     35 	.globl _memset
                                     36 	.globl _eeprom_update_byte
                                     37 	.globl _eeprom_read_byte
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    284 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    285 	.globl _keycode_at_encodermap_location_PARM_3
                                    286 	.globl _keycode_at_encodermap_location_PARM_2
                                    287 	.globl _keycode_at_keymap_location_PARM_3
                                    288 	.globl _keycode_at_keymap_location_PARM_2
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    292 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    293 	.globl _dynamic_keymap_set_key_override_PARM_2
                                    294 	.globl _dynamic_keymap_get_key_override_PARM_2
                                    295 	.globl _dynamic_keymap_set_combo_PARM_2
                                    296 	.globl _dynamic_keymap_get_combo_PARM_2
                                    297 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    298 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    299 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    300 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    301 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    302 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    303 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    304 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    305 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    306 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    307 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    309 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    310 	.globl _dynamic_keymap_get_layer_count
                                    311 	.globl _dynamic_keymap_key_to_eeprom_address
                                    312 	.globl _dynamic_keymap_get_keycode
                                    313 	.globl _dynamic_keymap_set_keycode
                                    314 	.globl _dynamic_keymap_get_encoder
                                    315 	.globl _dynamic_keymap_set_encoder
                                    316 	.globl _dynamic_keymap_get_combo
                                    317 	.globl _dynamic_keymap_set_combo
                                    318 	.globl _dynamic_keymap_get_key_override
                                    319 	.globl _dynamic_keymap_set_key_override
                                    320 	.globl _dynamic_keymap_reset
                                    321 	.globl _dynamic_keymap_get_buffer
                                    322 	.globl _dynamic_keymap_set_buffer
                                    323 	.globl _keycode_at_keymap_location
                                    324 	.globl _keycode_at_encodermap_location
                                    325 	.globl _dynamic_keymap_macro_get_count
                                    326 	.globl _dynamic_keymap_macro_get_buffer_size
                                    327 	.globl _dynamic_keymap_macro_get_buffer
                                    328 	.globl _dynamic_keymap_macro_set_buffer
                                    329 	.globl _dynamic_keymap_macro_reset
                                    330 	.globl _dynamic_keymap_macro_send
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000031                        593 _dynamic_keymap_set_encoder_sloc0_1_0:
      000031                        594 	.ds 2
      000033                        595 _dynamic_keymap_get_combo_sloc0_1_0:
      000033                        596 	.ds 1
      000034                        597 _ak820_dynamic_read_buffer_sloc0_1_0:
      000034                        598 	.ds 1
      000035                        599 _dynamic_keymap_set_buffer_sloc0_1_0:
      000035                        600 	.ds 2
      000037                        601 _dynamic_keymap_set_buffer_sloc1_1_0:
      000037                        602 	.ds 2
      000039                        603 _dynamic_keymap_set_buffer_sloc2_1_0:
      000039                        604 	.ds 1
      00003A                        605 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      00003A                        606 	.ds 2
                                    607 ;--------------------------------------------------------
                                    608 ; overlayable items in internal ram
                                    609 ;--------------------------------------------------------
                                    610 ;--------------------------------------------------------
                                    611 ; indirectly addressable internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area ISEG    (DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; absolute internal ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area IABS    (ABS,DATA)
                                    618 	.area IABS    (ABS,DATA)
                                    619 ;--------------------------------------------------------
                                    620 ; bit data
                                    621 ;--------------------------------------------------------
                                    622 	.area BSEG    (BIT)
      000025                        623 _dynamic_keymap_macro_send_sloc0_1_0:
      000025                        624 	.ds 1
                                    625 ;--------------------------------------------------------
                                    626 ; paged external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area PSEG    (PAG,XDATA)
                                    629 ;--------------------------------------------------------
                                    630 ; uninitialized external ram data
                                    631 ;--------------------------------------------------------
                                    632 	.area XSEG    (XDATA)
      000B57                        633 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B57                        634 	.ds 1
      000B58                        635 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B58                        636 	.ds 1
      000B59                        637 _dynamic_keymap_key_to_eeprom_address_layer_10000_374:
      000B59                        638 	.ds 1
      000B5A                        639 _dynamic_keymap_get_keycode_PARM_2:
      000B5A                        640 	.ds 1
      000B5B                        641 _dynamic_keymap_get_keycode_PARM_3:
      000B5B                        642 	.ds 1
      000B5C                        643 _dynamic_keymap_get_keycode_layer_10000_376:
      000B5C                        644 	.ds 1
      000B5D                        645 _dynamic_keymap_set_keycode_PARM_2:
      000B5D                        646 	.ds 1
      000B5E                        647 _dynamic_keymap_set_keycode_PARM_3:
      000B5E                        648 	.ds 1
      000B5F                        649 _dynamic_keymap_set_keycode_PARM_4:
      000B5F                        650 	.ds 2
      000B61                        651 _dynamic_keymap_set_keycode_layer_10000_380:
      000B61                        652 	.ds 1
      000B62                        653 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B62                        654 	.ds 1
      000B63                        655 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_384:
      000B63                        656 	.ds 1
      000B64                        657 _dynamic_keymap_get_encoder_PARM_2:
      000B64                        658 	.ds 1
      000B65                        659 _dynamic_keymap_get_encoder_PARM_3:
      000B65                        660 	.ds 1
      000B66                        661 _dynamic_keymap_get_encoder_layer_10000_386:
      000B66                        662 	.ds 1
      000B67                        663 _dynamic_keymap_set_encoder_PARM_2:
      000B67                        664 	.ds 1
      000B68                        665 _dynamic_keymap_set_encoder_PARM_3:
      000B68                        666 	.ds 1
      000B69                        667 _dynamic_keymap_set_encoder_PARM_4:
      000B69                        668 	.ds 2
      000B6B                        669 _dynamic_keymap_set_encoder_layer_10000_390:
      000B6B                        670 	.ds 1
      000B6C                        671 _dynamic_keymap_get_combo_PARM_2:
      000B6C                        672 	.ds 3
      000B6F                        673 _dynamic_keymap_get_combo_index_10000_394:
      000B6F                        674 	.ds 1
      000B70                        675 _dynamic_keymap_set_combo_PARM_2:
      000B70                        676 	.ds 3
      000B73                        677 _dynamic_keymap_set_combo_index_10000_400:
      000B73                        678 	.ds 1
      000B74                        679 _dynamic_keymap_set_combo_stored_10002_405:
      000B74                        680 	.ds 10
      000B7E                        681 _dynamic_keymap_get_key_override_PARM_2:
      000B7E                        682 	.ds 3
      000B81                        683 _dynamic_keymap_get_key_override_index_10000_407:
      000B81                        684 	.ds 1
      000B82                        685 _dynamic_keymap_set_key_override_PARM_2:
      000B82                        686 	.ds 3
      000B85                        687 _dynamic_keymap_set_key_override_index_10000_411:
      000B85                        688 	.ds 1
      000B86                        689 _dynamic_keymap_reset_vial_unlocked_prev_10000_415:
      000B86                        690 	.ds 1
      000B87                        691 _dynamic_keymap_reset_combo_10001_424:
      000B87                        692 	.ds 10
      000B91                        693 _dynamic_keymap_reset_ko_10002_426:
      000B91                        694 	.ds 10
      000B9B                        695 _ak820_dynamic_read_buffer_PARM_2:
      000B9B                        696 	.ds 2
      000B9D                        697 _ak820_dynamic_read_buffer_PARM_3:
      000B9D                        698 	.ds 2
      000B9F                        699 _ak820_dynamic_read_buffer_PARM_4:
      000B9F                        700 	.ds 2
      000BA1                        701 _ak820_dynamic_read_buffer_PARM_5:
      000BA1                        702 	.ds 3
      000BA4                        703 _ak820_dynamic_read_buffer_base_10000_428:
      000BA4                        704 	.ds 2
      000BA6                        705 _ak820_dynamic_read_buffer_available_10000_429:
      000BA6                        706 	.ds 1
      000BA7                        707 _dynamic_keymap_get_buffer_PARM_2:
      000BA7                        708 	.ds 2
      000BA9                        709 _dynamic_keymap_get_buffer_PARM_3:
      000BA9                        710 	.ds 3
      000BAC                        711 _dynamic_keymap_get_buffer_offset_10000_435:
      000BAC                        712 	.ds 2
      000BAE                        713 _dynamic_keymap_set_buffer_PARM_2:
      000BAE                        714 	.ds 2
      000BB0                        715 _dynamic_keymap_set_buffer_PARM_3:
      000BB0                        716 	.ds 3
      000BB3                        717 _dynamic_keymap_set_buffer_offset_10000_437:
      000BB3                        718 	.ds 2
      000BB5                        719 _dynamic_keymap_set_buffer_chk_offset_30001_444:
      000BB5                        720 	.ds 1
      000BB6                        721 _dynamic_keymap_set_buffer_chk_sz_30001_444:
      000BB6                        722 	.ds 1
      000BB7                        723 _dynamic_keymap_set_buffer_i_40001_451:
      000BB7                        724 	.ds 1
      000BB8                        725 _keycode_at_keymap_location_PARM_2:
      000BB8                        726 	.ds 1
      000BB9                        727 _keycode_at_keymap_location_PARM_3:
      000BB9                        728 	.ds 1
      000BBA                        729 _keycode_at_keymap_location_layer_num_10000_455:
      000BBA                        730 	.ds 1
      000BBB                        731 _keycode_at_encodermap_location_PARM_2:
      000BBB                        732 	.ds 1
      000BBC                        733 _keycode_at_encodermap_location_PARM_3:
      000BBC                        734 	.ds 1
      000BBD                        735 _keycode_at_encodermap_location_layer_num_10000_459:
      000BBD                        736 	.ds 1
      000BBE                        737 _dynamic_keymap_macro_get_buffer_PARM_2:
      000BBE                        738 	.ds 2
      000BC0                        739 _dynamic_keymap_macro_get_buffer_PARM_3:
      000BC0                        740 	.ds 3
      000BC3                        741 _dynamic_keymap_macro_get_buffer_offset_10000_467:
      000BC3                        742 	.ds 2
      000BC5                        743 _dynamic_keymap_macro_set_buffer_PARM_2:
      000BC5                        744 	.ds 2
      000BC7                        745 _dynamic_keymap_macro_set_buffer_PARM_3:
      000BC7                        746 	.ds 3
      000BCA                        747 _dynamic_keymap_macro_set_buffer_offset_10000_469:
      000BCA                        748 	.ds 2
      000BCC                        749 _decode_keycode_kc_10000_473:
      000BCC                        750 	.ds 2
      000BCE                        751 _dynamic_keymap_macro_send_id_10000_476:
      000BCE                        752 	.ds 1
      000BCF                        753 _dynamic_keymap_macro_send_sending_10000_477:
      000BCF                        754 	.ds 1
      000BD0                        755 _dynamic_keymap_macro_send_p_10001_482:
      000BD0                        756 	.ds 2
      000BD2                        757 _dynamic_keymap_macro_send_data_10003_489:
      000BD2                        758 	.ds 4
                                    759 ;--------------------------------------------------------
                                    760 ; absolute external ram data
                                    761 ;--------------------------------------------------------
                                    762 	.area XABS    (ABS,XDATA)
                                    763 ;--------------------------------------------------------
                                    764 ; initialized external ram data
                                    765 ;--------------------------------------------------------
                                    766 	.area XISEG   (XDATA)
                                    767 	.area HOME    (CODE)
                                    768 	.area GSINIT0 (CODE)
                                    769 	.area GSINIT1 (CODE)
                                    770 	.area GSINIT2 (CODE)
                                    771 	.area GSINIT3 (CODE)
                                    772 	.area GSINIT4 (CODE)
                                    773 	.area GSINIT5 (CODE)
                                    774 	.area GSINIT  (CODE)
                                    775 	.area GSFINAL (CODE)
                                    776 	.area CSEG    (CODE)
                                    777 ;--------------------------------------------------------
                                    778 ; global & static initialisations
                                    779 ;--------------------------------------------------------
                                    780 	.area HOME    (CODE)
                                    781 	.area GSINIT  (CODE)
                                    782 	.area GSFINAL (CODE)
                                    783 	.area GSINIT  (CODE)
                                    784 ;--------------------------------------------------------
                                    785 ; Home
                                    786 ;--------------------------------------------------------
                                    787 	.area HOME    (CODE)
                                    788 	.area HOME    (CODE)
                                    789 ;--------------------------------------------------------
                                    790 ; code
                                    791 ;--------------------------------------------------------
                                    792 	.area CSEG    (CODE)
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    795 ;------------------------------------------------------------
                                    796 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_232'
                                    797 ;------------------------------------------------------------
                                    798 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    799 ;	-----------------------------------------
                           000007   800 	ar7 = 0x07
                           000006   801 	ar6 = 0x06
                           000005   802 	ar5 = 0x05
                           000004   803 	ar4 = 0x04
                           000003   804 	ar3 = 0x03
                           000002   805 	ar2 = 0x02
                           000001   806 	ar1 = 0x01
                           000000   807 	ar0 = 0x00
                                    808 ;	 function dynamic_keymap_get_layer_count
                                    809 ;	-----------------------------------------
      00888A                        810 _dynamic_keymap_get_layer_count:
                                    811 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00888A 75 82 06         [24]  812 	mov	dpl, #0x06
                                    813 ;	quantum/dynamic_keymap.c:201: }
      00888D 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    817 ;------------------------------------------------------------
                                    818 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    819 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    820 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_374'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function dynamic_keymap_key_to_eeprom_address
                                    825 ;	-----------------------------------------
      00888E                        826 _dynamic_keymap_key_to_eeprom_address:
      00888E E5 82            [12]  827 	mov	a,dpl
      008890 90 0B 59         [24]  828 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_374
      008893 F0               [24]  829 	movx	@dptr,a
                                    830 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008894 E0               [24]  831 	movx	a,@dptr
      008895 FF               [12]  832 	mov	r7,a
      008896 7E 00            [12]  833 	mov	r6,#0x00
      008898 74 40            [12]  834 	mov	a,#0x40
      00889A 12 48 58         [24]  835 	lcall	_ak820_outline_0143
      00889D 7D 00            [12]  836 	mov	r5,#0x00
      00889F 90 0B 57         [24]  837 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0088A2 E0               [24]  838 	movx	a,@dptr
      0088A3 75 F0 10         [24]  839 	mov	b,#0x10
      0088A6 A4               [48]  840 	mul	ab
      0088A7 2E               [12]  841 	add	a, r6
      0088A8 FE               [12]  842 	mov	r6,a
      0088A9 EF               [12]  843 	mov	a,r7
      0088AA 35 F0            [12]  844 	addc	a, b
      0088AC FF               [12]  845 	mov	r7,a
      0088AD 90 0B 58         [24]  846 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0088B0 E0               [24]  847 	movx	a,@dptr
      0088B1 7C 00            [12]  848 	mov	r4,#0x00
      0088B3 25 E0            [12]  849 	add	a,acc
      0088B5 FB               [12]  850 	mov	r3,a
      0088B6 EC               [12]  851 	mov	a,r4
      0088B7 33               [12]  852 	rlc	a
      0088B8 FC               [12]  853 	mov	r4,a
      0088B9 EB               [12]  854 	mov	a,r3
      0088BA 2E               [12]  855 	add	a, r6
      0088BB FE               [12]  856 	mov	r6,a
      0088BC EC               [12]  857 	mov	a,r4
      0088BD 3F               [12]  858 	addc	a, r7
      0088BE FF               [12]  859 	mov	r7,a
      0088BF 12 48 48         [24]  860 	lcall	_ak820_outline_0123
      0088C2 8D F0            [24]  861 	mov	b, r5
                                    862 ;	quantum/dynamic_keymap.c:206: }
      0088C4 22               [24]  863 	ret
                                    864 ;------------------------------------------------------------
                                    865 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    866 ;------------------------------------------------------------
                                    867 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    868 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    869 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_376'
                                    870 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_379'
                                    871 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_379'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function dynamic_keymap_get_keycode
                                    876 ;	-----------------------------------------
      0088C5                        877 _dynamic_keymap_get_keycode:
      0088C5 E5 82            [12]  878 	mov	a,dpl
      0088C7 90 0B 5C         [24]  879 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_376
      0088CA F0               [24]  880 	movx	@dptr,a
                                    881 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0088CB E0               [24]  882 	movx	a,@dptr
      0088CC FF               [12]  883 	mov	r7,a
      0088CD BF 06 00         [24]  884 	cjne	r7,#0x06,00121$
      0088D0                        885 00121$:
      0088D0 50 14            [24]  886 	jnc	00101$
      0088D2 90 0B 5A         [24]  887 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0088D5 E0               [24]  888 	movx	a,@dptr
      0088D6 FE               [12]  889 	mov	r6,a
      0088D7 BE 10 00         [24]  890 	cjne	r6,#0x10,00123$
      0088DA                        891 00123$:
      0088DA 50 0A            [24]  892 	jnc	00101$
      0088DC 90 0B 5B         [24]  893 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0088DF E0               [24]  894 	movx	a,@dptr
      0088E0 FD               [12]  895 	mov	r5,a
      0088E1 BD 08 00         [24]  896 	cjne	r5,#0x08,00125$
      0088E4                        897 00125$:
      0088E4 40 04            [24]  898 	jc	00102$
      0088E6                        899 00101$:
      0088E6 90 00 00         [24]  900 	mov	dptr,#0x0000
      0088E9 22               [24]  901 	ret
      0088EA                        902 00102$:
                                    903 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0088EA 12 94 7D         [24]  904 	lcall	_ak820_outline_0103
      0088ED 11 8E            [12]  905 	acall	_dynamic_keymap_key_to_eeprom_address
                                    906 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      0088EF 12 94 91         [24]  907 	lcall	_ak820_outline_0121
      0088F2 12 45 66         [24]  908 	lcall	_eeprom_read_byte
      0088F5 AB 82            [24]  909 	mov	r3,dpl
      0088F7 7C 00            [12]  910 	mov	r4,#0x00
                                    911 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      0088F9 0D               [12]  912 	inc	r5
      0088FA BD 00 01         [24]  913 	cjne	r5,#0x00,00127$
      0088FD 0E               [12]  914 	inc	r6
      0088FE                        915 00127$:
      0088FE 12 53 B2         [24]  916 	lcall	_ak820_outline_0049
      008901 12 45 66         [24]  917 	lcall	_eeprom_read_byte
      008904 AF 82            [24]  918 	mov	r7, dpl
      008906 7E 00            [12]  919 	mov	r6,#0x00
      008908 EF               [12]  920 	mov	a,r7
      008909 42 04            [12]  921 	orl	ar4,a
      00890B EE               [12]  922 	mov	a,r6
      00890C 42 03            [12]  923 	orl	ar3,a
                                    924 ;	quantum/dynamic_keymap.c:214: return keycode;
      00890E 12 48 84         [24]  925 	lcall	_ak820_outline_0189
                                    926 ;	quantum/dynamic_keymap.c:215: }
      008911 22               [24]  927 	ret
                                    928 ;------------------------------------------------------------
                                    929 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    930 ;------------------------------------------------------------
                                    931 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    932 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    933 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    934 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_380'
                                    935 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_383'
                                    936 ;------------------------------------------------------------
                                    937 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    938 ;	-----------------------------------------
                                    939 ;	 function dynamic_keymap_set_keycode
                                    940 ;	-----------------------------------------
      008912                        941 _dynamic_keymap_set_keycode:
      008912 E5 82            [12]  942 	mov	a,dpl
      008914 90 0B 61         [24]  943 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_380
      008917 F0               [24]  944 	movx	@dptr,a
                                    945 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008918 E0               [24]  946 	movx	a,@dptr
      008919 FF               [12]  947 	mov	r7,a
      00891A BF 06 00         [24]  948 	cjne	r7,#0x06,00121$
      00891D                        949 00121$:
      00891D 50 14            [24]  950 	jnc	00101$
      00891F 90 0B 5D         [24]  951 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008922 E0               [24]  952 	movx	a,@dptr
      008923 FE               [12]  953 	mov	r6,a
      008924 BE 10 00         [24]  954 	cjne	r6,#0x10,00123$
      008927                        955 00123$:
      008927 50 0A            [24]  956 	jnc	00101$
      008929 90 0B 5E         [24]  957 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00892C E0               [24]  958 	movx	a,@dptr
      00892D FD               [12]  959 	mov	r5,a
      00892E BD 08 00         [24]  960 	cjne	r5,#0x08,00125$
      008931                        961 00125$:
      008931 40 01            [24]  962 	jc	00102$
      008933                        963 00101$:
      008933 22               [24]  964 	ret
      008934                        965 00102$:
                                    966 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008934 12 94 7D         [24]  967 	lcall	_ak820_outline_0103
      008937 11 8E            [12]  968 	acall	_dynamic_keymap_key_to_eeprom_address
      008939 12 94 91         [24]  969 	lcall	_ak820_outline_0121
                                    970 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      00893C 90 0B 5F         [24]  971 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00893F E0               [24]  972 	movx	a,@dptr
      008940 FB               [12]  973 	mov	r3,a
      008941 A3               [24]  974 	inc	dptr
      008942 E0               [24]  975 	movx	a,@dptr
      008943 90 06 FC         [24]  976 	mov	dptr,#_eeprom_update_byte_PARM_2
      008946 F0               [24]  977 	movx	@dptr,a
      008947 12 53 B2         [24]  978 	lcall	_ak820_outline_0049
      00894A 12 52 9A         [24]  979 	lcall	_eeprom_update_byte
                                    980 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      00894D 0D               [12]  981 	inc	r5
      00894E BD 00 01         [24]  982 	cjne	r5,#0x00,00127$
      008951 0E               [12]  983 	inc	r6
      008952                        984 00127$:
      008952 90 06 FC         [24]  985 	mov	dptr,#_eeprom_update_byte_PARM_2
      008955 EB               [12]  986 	mov	a,r3
      008956 F0               [24]  987 	movx	@dptr,a
      008957 12 53 B2         [24]  988 	lcall	_ak820_outline_0049
                                    989 ;	quantum/dynamic_keymap.c:223: }
      00895A 02 52 9A         [24]  990 	ljmp	_eeprom_update_byte
                                    991 ;------------------------------------------------------------
                                    992 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    993 ;------------------------------------------------------------
                                    994 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    995 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_384'
                                    996 ;------------------------------------------------------------
                                    997 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    998 ;	-----------------------------------------
                                    999 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                   1000 ;	-----------------------------------------
      00895D                       1001 _dynamic_keymap_encoder_to_eeprom_address:
      00895D E5 82            [12] 1002 	mov	a,dpl
      00895F 90 0B 63         [24] 1003 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_384
      008962 F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008963 E0               [24] 1006 	movx	a,@dptr
      008964 75 F0 04         [24] 1007 	mov	b,#0x04
      008967 A4               [48] 1008 	mul	ab
      008968 24 40            [12] 1009 	add	a, #0x40
      00896A FD               [12] 1010 	mov	r5,a
      00896B 74 06            [12] 1011 	mov	a,#0x06
      00896D 35 F0            [12] 1012 	addc	a, b
      00896F FE               [12] 1013 	mov	r6,a
      008970 7F 00            [12] 1014 	mov	r7,#0x00
      008972 90 0B 62         [24] 1015 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008975 E0               [24] 1016 	movx	a,@dptr
      008976 75 F0 04         [24] 1017 	mov	b,#0x04
      008979 A4               [48] 1018 	mul	ab
      00897A 2D               [12] 1019 	add	a, r5
      00897B FD               [12] 1020 	mov	r5,a
      00897C EE               [12] 1021 	mov	a,r6
      00897D 35 F0            [12] 1022 	addc	a, b
      00897F FE               [12] 1023 	mov	r6,a
      008980 12 53 B2         [24] 1024 	lcall	_ak820_outline_0049
                                   1025 ;	quantum/dynamic_keymap.c:228: }
      008983 22               [24] 1026 	ret
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1029 ;------------------------------------------------------------
                                   1030 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1031 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1032 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_386'
                                   1033 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_389'
                                   1034 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_389'
                                   1035 ;------------------------------------------------------------
                                   1036 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1037 ;	-----------------------------------------
                                   1038 ;	 function dynamic_keymap_get_encoder
                                   1039 ;	-----------------------------------------
      008984                       1040 _dynamic_keymap_get_encoder:
      008984 E5 82            [12] 1041 	mov	a,dpl
      008986 90 0B 66         [24] 1042 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_386
      008989 F0               [24] 1043 	movx	@dptr,a
                                   1044 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      00898A E0               [24] 1045 	movx	a,@dptr
      00898B FF               [12] 1046 	mov	r7,a
      00898C BF 06 00         [24] 1047 	cjne	r7,#0x06,00131$
      00898F                       1048 00131$:
      00898F 50 0A            [24] 1049 	jnc	00101$
      008991 90 0B 64         [24] 1050 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008994 E0               [24] 1051 	movx	a,@dptr
      008995 FE               [12] 1052 	mov	r6,a
      008996 BE 01 00         [24] 1053 	cjne	r6,#0x01,00133$
      008999                       1054 00133$:
      008999 40 04            [24] 1055 	jc	00102$
      00899B                       1056 00101$:
      00899B 90 00 00         [24] 1057 	mov	dptr,#0x0000
      00899E 22               [24] 1058 	ret
      00899F                       1059 00102$:
                                   1060 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00899F 90 0B 62         [24] 1061 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0089A2 E4               [12] 1062 	clr	a
      0089A3 F0               [24] 1063 	movx	@dptr,a
      0089A4 8F 82            [24] 1064 	mov	dpl, r7
      0089A6 31 5D            [12] 1065 	acall	_dynamic_keymap_encoder_to_eeprom_address
      0089A8 12 94 91         [24] 1066 	lcall	_ak820_outline_0121
                                   1067 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0089AB 90 0B 65         [24] 1068 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0089AE E0               [24] 1069 	movx	a,@dptr
      0089AF FC               [12] 1070 	mov	r4,a
      0089B0 E0               [24] 1071 	movx	a,@dptr
      0089B1 60 04            [24] 1072 	jz	00106$
      0089B3 7B 00            [12] 1073 	mov	r3,#0x00
      0089B5 80 02            [24] 1074 	sjmp	00107$
      0089B7                       1075 00106$:
      0089B7 7B 02            [12] 1076 	mov	r3,#0x02
      0089B9                       1077 00107$:
      0089B9 EB               [12] 1078 	mov	a,r3
      0089BA 12 94 46         [24] 1079 	lcall	_ak820_outline_0027
      0089BD 12 45 66         [24] 1080 	lcall	_eeprom_read_byte
      0089C0 AA 82            [24] 1081 	mov	r2,dpl
      0089C2 7B 00            [12] 1082 	mov	r3,#0x00
                                   1083 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0089C4 EC               [12] 1084 	mov	a,r4
      0089C5 60 04            [24] 1085 	jz	00108$
      0089C7 7C 00            [12] 1086 	mov	r4,#0x00
      0089C9 80 02            [24] 1087 	sjmp	00109$
      0089CB                       1088 00108$:
      0089CB 7C 02            [12] 1089 	mov	r4,#0x02
      0089CD                       1090 00109$:
      0089CD EC               [12] 1091 	mov	a,r4
      0089CE 12 38 71         [24] 1092 	lcall	_ak820_outline_0166
      0089D1 0D               [12] 1093 	inc	r5
      0089D2 BD 00 01         [24] 1094 	cjne	r5,#0x00,00137$
      0089D5 0E               [12] 1095 	inc	r6
      0089D6                       1096 00137$:
      0089D6 12 53 B2         [24] 1097 	lcall	_ak820_outline_0049
      0089D9 12 45 66         [24] 1098 	lcall	_eeprom_read_byte
      0089DC AF 82            [24] 1099 	mov	r7, dpl
      0089DE 7E 00            [12] 1100 	mov	r6,#0x00
      0089E0 EF               [12] 1101 	mov	a,r7
      0089E1 42 03            [12] 1102 	orl	ar3,a
      0089E3 EE               [12] 1103 	mov	a,r6
      0089E4 42 02            [12] 1104 	orl	ar2,a
                                   1105 ;	quantum/dynamic_keymap.c:236: return keycode;
      0089E6 8B 82            [24] 1106 	mov	dpl, r3
      0089E8 8A 83            [24] 1107 	mov	dph, r2
                                   1108 ;	quantum/dynamic_keymap.c:237: }
      0089EA 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1112 ;------------------------------------------------------------
                                   1113 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1114 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1115 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1116 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1117 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_390'
                                   1118 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_393'
                                   1119 ;------------------------------------------------------------
                                   1120 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1121 ;	-----------------------------------------
                                   1122 ;	 function dynamic_keymap_set_encoder
                                   1123 ;	-----------------------------------------
      0089EB                       1124 _dynamic_keymap_set_encoder:
      0089EB E5 82            [12] 1125 	mov	a,dpl
      0089ED 90 0B 6B         [24] 1126 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_390
      0089F0 F0               [24] 1127 	movx	@dptr,a
                                   1128 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0089F1 E0               [24] 1129 	movx	a,@dptr
      0089F2 FF               [12] 1130 	mov	r7,a
      0089F3 BF 06 00         [24] 1131 	cjne	r7,#0x06,00131$
      0089F6                       1132 00131$:
      0089F6 50 0A            [24] 1133 	jnc	00101$
      0089F8 90 0B 67         [24] 1134 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0089FB E0               [24] 1135 	movx	a,@dptr
      0089FC FE               [12] 1136 	mov	r6,a
      0089FD BE 01 00         [24] 1137 	cjne	r6,#0x01,00133$
      008A00                       1138 00133$:
      008A00 40 01            [24] 1139 	jc	00102$
      008A02                       1140 00101$:
      008A02 22               [24] 1141 	ret
      008A03                       1142 00102$:
                                   1143 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008A03 90 0B 62         [24] 1144 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008A06 E4               [12] 1145 	clr	a
      008A07 F0               [24] 1146 	movx	@dptr,a
      008A08 8F 82            [24] 1147 	mov	dpl, r7
      008A0A 31 5D            [12] 1148 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008A0C 12 94 91         [24] 1149 	lcall	_ak820_outline_0121
                                   1150 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008A0F 90 0B 68         [24] 1151 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008A12 E0               [24] 1152 	movx	a,@dptr
      008A13 FC               [12] 1153 	mov	r4,a
      008A14 E0               [24] 1154 	movx	a,@dptr
      008A15 60 04            [24] 1155 	jz	00106$
      008A17 7B 00            [12] 1156 	mov	r3,#0x00
      008A19 80 02            [24] 1157 	sjmp	00107$
      008A1B                       1158 00106$:
      008A1B 7B 02            [12] 1159 	mov	r3,#0x02
      008A1D                       1160 00107$:
      008A1D EB               [12] 1161 	mov	a,r3
      008A1E 12 94 A3         [24] 1162 	lcall	_ak820_outline_0142
      008A21 8F 03            [24] 1163 	mov	ar3,r7
      008A23 90 0B 69         [24] 1164 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008A26 E0               [24] 1165 	movx	a,@dptr
      008A27 F5 31            [12] 1166 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008A29 A3               [24] 1167 	inc	dptr
      008A2A E0               [24] 1168 	movx	a,@dptr
      008A2B F5 32            [12] 1169 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008A2D 90 06 FC         [24] 1170 	mov	dptr,#_eeprom_update_byte_PARM_2
      008A30 F0               [24] 1171 	movx	@dptr,a
      008A31 12 48 6E         [24] 1172 	lcall	_ak820_outline_0163
      008A34 8B F0            [24] 1173 	mov	b, r3
      008A36 12 52 9A         [24] 1174 	lcall	_eeprom_update_byte
                                   1175 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008A39 EC               [12] 1176 	mov	a,r4
      008A3A 60 04            [24] 1177 	jz	00108$
      008A3C 7C 00            [12] 1178 	mov	r4,#0x00
      008A3E 80 02            [24] 1179 	sjmp	00109$
      008A40                       1180 00108$:
      008A40 7C 02            [12] 1181 	mov	r4,#0x02
      008A42                       1182 00109$:
      008A42 EC               [12] 1183 	mov	a,r4
      008A43 12 38 71         [24] 1184 	lcall	_ak820_outline_0166
      008A46 0D               [12] 1185 	inc	r5
      008A47 BD 00 01         [24] 1186 	cjne	r5,#0x00,00137$
      008A4A 0E               [12] 1187 	inc	r6
      008A4B                       1188 00137$:
      008A4B 90 06 FC         [24] 1189 	mov	dptr,#_eeprom_update_byte_PARM_2
      008A4E E5 31            [12] 1190 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008A50 F0               [24] 1191 	movx	@dptr,a
      008A51 12 53 B2         [24] 1192 	lcall	_ak820_outline_0049
                                   1193 ;	quantum/dynamic_keymap.c:245: }
      008A54 02 52 9A         [24] 1194 	ljmp	_eeprom_update_byte
                                   1195 ;------------------------------------------------------------
                                   1196 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1197 ;------------------------------------------------------------
                                   1198 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1199 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1200 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_394'
                                   1201 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_395'
                                   1202 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_397'
                                   1203 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_398'
                                   1204 ;------------------------------------------------------------
                                   1205 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1206 ;	-----------------------------------------
                                   1207 ;	 function dynamic_keymap_get_combo
                                   1208 ;	-----------------------------------------
      008A57                       1209 _dynamic_keymap_get_combo:
      008A57 E5 82            [12] 1210 	mov	a,dpl
      008A59 90 0B 6F         [24] 1211 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_394
      008A5C F0               [24] 1212 	movx	@dptr,a
                                   1213 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008A5D 90 0B 6C         [24] 1214 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008A60 12 37 F9         [24] 1215 	lcall	_ak820_outline_0056
                                   1216 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008A63 90 0B 6F         [24] 1217 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_394
      008A66 E0               [24] 1218 	movx	a,@dptr
      008A67 FD               [12] 1219 	mov	r5,a
      008A68 BD 08 00         [24] 1220 	cjne	r5,#0x08,00132$
      008A6B                       1221 00132$:
      008A6B 40 04            [24] 1222 	jc	00102$
                                   1223 ;	quantum/dynamic_keymap.c:315: return -1;
      008A6D 90 FF FF         [24] 1224 	mov	dptr,#0xffff
      008A70 22               [24] 1225 	ret
      008A71                       1226 00102$:
                                   1227 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008A71 12 94 69         [24] 1228 	lcall	_ak820_outline_0082
                                   1229 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008A74 8E 02            [24] 1230 	mov	ar2,r6
      008A76 8F 03            [24] 1231 	mov	ar3,r7
      008A78 90 05 E6         [24] 1232 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008A7B EC               [12] 1233 	mov	a,r4
      008A7C F0               [24] 1234 	movx	@dptr,a
      008A7D ED               [12] 1235 	mov	a,r5
      008A7E 12 38 1E         [24] 1236 	lcall	_ak820_outline_0076
      008A81 90 05 E9         [24] 1237 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008A84 12 94 8A         [24] 1238 	lcall	_ak820_outline_0116
      008A87 12 48 64         [24] 1239 	lcall	_ak820_outline_0149
      008A8A C0 07            [24] 1240 	push	ar7
      008A8C C0 06            [24] 1241 	push	ar6
      008A8E 12 45 A1         [24] 1242 	lcall	_ak820_eeprom_read_block_xdata
      008A91 D0 06            [24] 1243 	pop	ar6
      008A93 D0 07            [24] 1244 	pop	ar7
                                   1245 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008A95 74 04            [12] 1246 	mov	a,#0x04
      008A97 12 3F FB         [24] 1247 	lcall	_ak820_outline_0009
      008A9A FA               [12] 1248 	mov	r2,a
      008A9B A3               [24] 1249 	inc	dptr
      008A9C E0               [24] 1250 	movx	a,@dptr
      008A9D FB               [12] 1251 	mov	r3,a
      008A9E BA 20 14         [24] 1252 	cjne	r2,#0x20,00108$
      008AA1 BB 08 11         [24] 1253 	cjne	r3,#0x08,00108$
      008AA4 74 06            [12] 1254 	mov	a,#0x06
      008AA6 12 37 CE         [24] 1255 	lcall	_ak820_outline_0013
      008AA9 FA               [12] 1256 	mov	r2,a
      008AAA A3               [24] 1257 	inc	dptr
      008AAB E0               [24] 1258 	movx	a,@dptr
      008AAC FB               [12] 1259 	mov	r3,a
      008AAD BA 01 05         [24] 1260 	cjne	r2,#0x01,00136$
      008AB0 BB 00 02         [24] 1261 	cjne	r3,#0x00,00136$
      008AB3 80 05            [24] 1262 	sjmp	00109$
      008AB5                       1263 00136$:
      008AB5                       1264 00108$:
      008AB5 75 33 00         [24] 1265 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008AB8 80 03            [24] 1266 	sjmp	00110$
      008ABA                       1267 00109$:
      008ABA 75 33 01         [24] 1268 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008ABD                       1269 00110$:
                                   1270 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008ABD 74 06            [12] 1271 	mov	a,#0x06
      008ABF 12 37 F1         [24] 1272 	lcall	_ak820_outline_0033
      008AC2 12 53 F4         [24] 1273 	lcall	_ak820_outline_0155
      008AC5 12 38 4C         [24] 1274 	lcall	_ak820_outline_0126
      008AC8 F0               [24] 1275 	movx	@dptr,a
      008AC9 A3               [24] 1276 	inc	dptr
      008ACA F0               [24] 1277 	movx	@dptr,a
                                   1278 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008ACB E5 33            [12] 1279 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008ACD 60 12            [24] 1280 	jz	00103$
      008ACF 12 48 48         [24] 1281 	lcall	_ak820_outline_0123
      008AD2 C0 07            [24] 1282 	push	ar7
      008AD4 C0 06            [24] 1283 	push	ar6
      008AD6 12 34 68         [24] 1284 	lcall	_ak820_combo_valid
      008AD9 E5 82            [12] 1285 	mov	a, dpl
      008ADB D0 06            [24] 1286 	pop	ar6
      008ADD D0 07            [24] 1287 	pop	ar7
      008ADF 70 08            [24] 1288 	jnz	00104$
      008AE1                       1289 00103$:
      008AE1 7D 00            [12] 1290 	mov	r5,#0x00
      008AE3 12 94 54         [24] 1291 	lcall	_ak820_outline_0039
      008AE6 12 BE 50         [24] 1292 	lcall	_memset
      008AE9                       1293 00104$:
                                   1294 ;	quantum/dynamic_keymap.c:329: return 0;
      008AE9 90 00 00         [24] 1295 	mov	dptr,#0x0000
                                   1296 ;	quantum/dynamic_keymap.c:330: }
      008AEC 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1300 ;------------------------------------------------------------
                                   1301 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1302 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_400'
                                   1303 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_401'
                                   1304 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_404'
                                   1305 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_405'
                                   1306 ;------------------------------------------------------------
                                   1307 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1308 ;	-----------------------------------------
                                   1309 ;	 function dynamic_keymap_set_combo
                                   1310 ;	-----------------------------------------
      008AED                       1311 _dynamic_keymap_set_combo:
      008AED E5 82            [12] 1312 	mov	a,dpl
      008AEF 90 0B 73         [24] 1313 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_400
      008AF2 F0               [24] 1314 	movx	@dptr,a
                                   1315 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008AF3 90 0B 70         [24] 1316 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008AF6 12 37 BA         [24] 1317 	lcall	_ak820_outline_0006
                                   1318 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008AF9 C0 07            [24] 1319 	push	ar7
      008AFB C0 06            [24] 1320 	push	ar6
      008AFD 12 34 68         [24] 1321 	lcall	_ak820_combo_valid
      008B00 E5 82            [12] 1322 	mov	a, dpl
      008B02 D0 06            [24] 1323 	pop	ar6
      008B04 D0 07            [24] 1324 	pop	ar7
      008B06 60 07            [24] 1325 	jz	00101$
      008B08 12 43 0C         [24] 1326 	lcall	_ak820_nvm_ok
      008B0B E5 82            [12] 1327 	mov	a, dpl
      008B0D 70 04            [24] 1328 	jnz	00102$
      008B0F                       1329 00101$:
      008B0F 90 FF FF         [24] 1330 	mov	dptr,#0xffff
      008B12 22               [24] 1331 	ret
      008B13                       1332 00102$:
                                   1333 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008B13 90 0B 73         [24] 1334 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_400
      008B16 E0               [24] 1335 	movx	a,@dptr
      008B17 FD               [12] 1336 	mov	r5,a
      008B18 BD 08 00         [24] 1337 	cjne	r5,#0x08,00133$
      008B1B                       1338 00133$:
      008B1B 40 04            [24] 1339 	jc	00105$
                                   1340 ;	quantum/dynamic_keymap.c:342: return -1;
      008B1D 90 FF FF         [24] 1341 	mov	dptr,#0xffff
      008B20 22               [24] 1342 	ret
      008B21                       1343 00105$:
                                   1344 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008B21 12 94 69         [24] 1345 	lcall	_ak820_outline_0082
                                   1346 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008B24 C0 07            [24] 1347 	push	ar7
      008B26 C0 06            [24] 1348 	push	ar6
      008B28 C0 05            [24] 1349 	push	ar5
      008B2A C0 04            [24] 1350 	push	ar4
      008B2C 12 7A 9F         [24] 1351 	lcall	_clear_keyboard
      008B2F D0 04            [24] 1352 	pop	ar4
      008B31 D0 05            [24] 1353 	pop	ar5
      008B33 D0 06            [24] 1354 	pop	ar6
      008B35 D0 07            [24] 1355 	pop	ar7
                                   1356 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008B37 90 0E 21         [24] 1357 	mov	dptr,#___memcpy_PARM_2
      008B3A 12 4D 63         [24] 1358 	lcall	_ak820_outline_0064
      008B3D E4               [12] 1359 	clr	a
      008B3E A3               [24] 1360 	inc	dptr
      008B3F F0               [24] 1361 	movx	@dptr,a
      008B40 90 0E 24         [24] 1362 	mov	dptr,#___memcpy_PARM_3
      008B43 12 94 8A         [24] 1363 	lcall	_ak820_outline_0116
      008B46 90 0B 74         [24] 1364 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_405
      008B49 F5 F0            [12] 1365 	mov	b,a
      008B4B C0 05            [24] 1366 	push	ar5
      008B4D C0 04            [24] 1367 	push	ar4
      008B4F 12 BD DA         [24] 1368 	lcall	___memcpy
      008B52 D0 04            [24] 1369 	pop	ar4
      008B54 D0 05            [24] 1370 	pop	ar5
                                   1371 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008B56 90 0B 78         [24] 1372 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_405 + 0x0004)
      008B59 74 20            [12] 1373 	mov	a,#0x20
      008B5B F0               [24] 1374 	movx	@dptr,a
      008B5C 74 08            [12] 1375 	mov	a,#0x08
      008B5E A3               [24] 1376 	inc	dptr
      008B5F F0               [24] 1377 	movx	@dptr,a
                                   1378 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008B60 90 0B 7A         [24] 1379 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_405 + 0x0006)
      008B63 74 01            [12] 1380 	mov	a,#0x01
      008B65 12 38 57         [24] 1381 	lcall	_ak820_outline_0132
                                   1382 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008B68 90 05 EF         [24] 1383 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008B6B EC               [12] 1384 	mov	a,r4
      008B6C F0               [24] 1385 	movx	@dptr,a
      008B6D ED               [12] 1386 	mov	a,r5
      008B6E 12 38 1E         [24] 1387 	lcall	_ak820_outline_0076
      008B71 90 05 F2         [24] 1388 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008B74 12 94 8A         [24] 1389 	lcall	_ak820_outline_0116
      008B77 90 0B 74         [24] 1390 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_405
      008B7A 12 46 2D         [24] 1391 	lcall	_ak820_eeprom_write_block_xdata
                                   1392 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008B7D 12 43 1B         [24] 1393 	lcall	_ak820_nvm_flush
                                   1394 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008B80 12 43 0C         [24] 1395 	lcall	_ak820_nvm_ok
      008B83 E5 82            [12] 1396 	mov	a, dpl
      008B85 70 04            [24] 1397 	jnz	00107$
      008B87 90 FF FF         [24] 1398 	mov	dptr,#0xffff
      008B8A 22               [24] 1399 	ret
      008B8B                       1400 00107$:
                                   1401 ;	quantum/dynamic_keymap.c:360: return 0;
      008B8B 90 00 00         [24] 1402 	mov	dptr,#0x0000
                                   1403 ;	quantum/dynamic_keymap.c:361: }
      008B8E 22               [24] 1404 	ret
                                   1405 ;------------------------------------------------------------
                                   1406 ;Allocation info for local variables in function 'dynamic_keymap_get_key_override'
                                   1407 ;------------------------------------------------------------
                                   1408 ;buffer        Allocated with name '_dynamic_keymap_get_key_override_PARM_2'
                                   1409 ;index         Allocated with name '_dynamic_keymap_get_key_override_index_10000_407'
                                   1410 ;entry         Allocated with name '_dynamic_keymap_get_key_override_entry_10000_408'
                                   1411 ;------------------------------------------------------------
                                   1412 ;	quantum/dynamic_keymap.c:366: int dynamic_keymap_get_key_override(uint8_t index, vial_key_override_entry_t *buffer) {
                                   1413 ;	-----------------------------------------
                                   1414 ;	 function dynamic_keymap_get_key_override
                                   1415 ;	-----------------------------------------
      008B8F                       1416 _dynamic_keymap_get_key_override:
      008B8F E5 82            [12] 1417 	mov	a,dpl
      008B91 90 0B 81         [24] 1418 	mov	dptr,#_dynamic_keymap_get_key_override_index_10000_407
      008B94 F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	quantum/dynamic_keymap.c:367: vial_key_override_entry_t AK820_STATE_MEM *entry = (vial_key_override_entry_t AK820_STATE_MEM *)buffer;
      008B95 90 0B 7E         [24] 1421 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      008B98 12 37 F9         [24] 1422 	lcall	_ak820_outline_0056
                                   1423 ;	quantum/dynamic_keymap.c:368: if (index >= AK820_EXTENSION_ENTRIES) return -1;
      008B9B 90 0B 81         [24] 1424 	mov	dptr,#_dynamic_keymap_get_key_override_index_10000_407
      008B9E E0               [24] 1425 	movx	a,@dptr
      008B9F FD               [12] 1426 	mov	r5,a
      008BA0 BD 08 00         [24] 1427 	cjne	r5,#0x08,00130$
      008BA3                       1428 00130$:
      008BA3 40 04            [24] 1429 	jc	00102$
      008BA5 90 FF FF         [24] 1430 	mov	dptr,#0xffff
      008BA8 22               [24] 1431 	ret
      008BA9                       1432 00102$:
                                   1433 ;	quantum/dynamic_keymap.c:369: ak820_eeprom_read_block_xdata(entry, (const void *)(VIAL_KEY_OVERRIDE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008BA9 8E 03            [24] 1434 	mov	ar3,r6
      008BAB 8F 04            [24] 1435 	mov	ar4,r7
      008BAD BD 06 00         [24] 1436 	cjne	r5,#0x06,00132$
      008BB0                       1437 00132$:
      008BB0 50 0B            [24] 1438 	jnc	00107$
      008BB2 8D 02            [24] 1439 	mov	ar2,r5
      008BB4 EA               [12] 1440 	mov	a,r2
      008BB5 12 40 71         [24] 1441 	lcall	_ak820_outline_0194
      008BB8 F9               [12] 1442 	mov	r1,a
      008BB9 7A 00            [12] 1443 	mov	r2,#0x00
      008BBB 80 10            [24] 1444 	sjmp	00108$
      008BBD                       1445 00107$:
      008BBD ED               [12] 1446 	mov	a,r5
      008BBE 24 FA            [12] 1447 	add	a,#0xfa
      008BC0 12 40 71         [24] 1448 	lcall	_ak820_outline_0194
      008BC3 F8               [12] 1449 	mov	r0,a
      008BC4 7D 00            [12] 1450 	mov	r5,#0x00
      008BC6 74 40            [12] 1451 	mov	a,#0x40
      008BC8 28               [12] 1452 	add	a, r0
      008BC9 F9               [12] 1453 	mov	r1,a
      008BCA E4               [12] 1454 	clr	a
      008BCB 3D               [12] 1455 	addc	a, r5
      008BCC FA               [12] 1456 	mov	r2,a
      008BCD                       1457 00108$:
      008BCD 74 40            [12] 1458 	mov	a,#0x40
      008BCF 29               [12] 1459 	add	a, r1
      008BD0 F9               [12] 1460 	mov	r1,a
      008BD1 74 07            [12] 1461 	mov	a,#0x07
      008BD3 3A               [12] 1462 	addc	a, r2
      008BD4 FA               [12] 1463 	mov	r2,a
      008BD5 90 05 E6         [24] 1464 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008BD8 E9               [12] 1465 	mov	a,r1
      008BD9 F0               [24] 1466 	movx	@dptr,a
      008BDA EA               [12] 1467 	mov	a,r2
      008BDB 12 38 1E         [24] 1468 	lcall	_ak820_outline_0076
      008BDE 90 05 E9         [24] 1469 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008BE1 12 94 8A         [24] 1470 	lcall	_ak820_outline_0116
      008BE4 12 33 FC         [24] 1471 	lcall	_ak820_outline_0131
      008BE7 C0 07            [24] 1472 	push	ar7
      008BE9 C0 06            [24] 1473 	push	ar6
      008BEB 12 45 A1         [24] 1474 	lcall	_ak820_eeprom_read_block_xdata
      008BEE D0 06            [24] 1475 	pop	ar6
      008BF0 D0 07            [24] 1476 	pop	ar7
                                   1477 ;	quantum/dynamic_keymap.c:370: if (!ak820_key_override_valid(entry)) memset(entry, 0, sizeof(*entry));
      008BF2 12 48 48         [24] 1478 	lcall	_ak820_outline_0123
      008BF5 C0 07            [24] 1479 	push	ar7
      008BF7 C0 06            [24] 1480 	push	ar6
      008BF9 12 3B 3F         [24] 1481 	lcall	_ak820_key_override_valid
      008BFC E5 82            [12] 1482 	mov	a, dpl
      008BFE D0 06            [24] 1483 	pop	ar6
      008C00 D0 07            [24] 1484 	pop	ar7
      008C02 70 07            [24] 1485 	jnz	00104$
      008C04 FD               [12] 1486 	mov	r5,a
      008C05 12 94 54         [24] 1487 	lcall	_ak820_outline_0039
      008C08 12 BE 50         [24] 1488 	lcall	_memset
      008C0B                       1489 00104$:
                                   1490 ;	quantum/dynamic_keymap.c:371: return 0;
      008C0B 90 00 00         [24] 1491 	mov	dptr,#0x0000
                                   1492 ;	quantum/dynamic_keymap.c:372: }
      008C0E 22               [24] 1493 	ret
                                   1494 ;------------------------------------------------------------
                                   1495 ;Allocation info for local variables in function 'dynamic_keymap_set_key_override'
                                   1496 ;------------------------------------------------------------
                                   1497 ;buffer        Allocated with name '_dynamic_keymap_set_key_override_PARM_2'
                                   1498 ;index         Allocated with name '_dynamic_keymap_set_key_override_index_10000_411'
                                   1499 ;entry         Allocated with name '_dynamic_keymap_set_key_override_entry_10000_412'
                                   1500 ;------------------------------------------------------------
                                   1501 ;	quantum/dynamic_keymap.c:373: int dynamic_keymap_set_key_override(uint8_t index, const vial_key_override_entry_t *buffer) {
                                   1502 ;	-----------------------------------------
                                   1503 ;	 function dynamic_keymap_set_key_override
                                   1504 ;	-----------------------------------------
      008C0F                       1505 _dynamic_keymap_set_key_override:
      008C0F E5 82            [12] 1506 	mov	a,dpl
      008C11 90 0B 85         [24] 1507 	mov	dptr,#_dynamic_keymap_set_key_override_index_10000_411
      008C14 F0               [24] 1508 	movx	@dptr,a
                                   1509 ;	quantum/dynamic_keymap.c:374: const vial_key_override_entry_t AK820_STATE_MEM *entry = (const vial_key_override_entry_t AK820_STATE_MEM *)buffer;
      008C15 90 0B 82         [24] 1510 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      008C18 12 37 F9         [24] 1511 	lcall	_ak820_outline_0056
                                   1512 ;	quantum/dynamic_keymap.c:375: if (index >= AK820_EXTENSION_ENTRIES || !ak820_key_override_valid(entry) || !ak820_nvm_ok()) return -1;
      008C1B 90 0B 85         [24] 1513 	mov	dptr,#_dynamic_keymap_set_key_override_index_10000_411
      008C1E E0               [24] 1514 	movx	a,@dptr
      008C1F FD               [12] 1515 	mov	r5,a
      008C20 BD 08 00         [24] 1516 	cjne	r5,#0x08,00139$
      008C23                       1517 00139$:
      008C23 50 1D            [24] 1518 	jnc	00101$
      008C25 12 48 48         [24] 1519 	lcall	_ak820_outline_0123
      008C28 C0 07            [24] 1520 	push	ar7
      008C2A C0 06            [24] 1521 	push	ar6
      008C2C C0 05            [24] 1522 	push	ar5
      008C2E 12 3B 3F         [24] 1523 	lcall	_ak820_key_override_valid
      008C31 E5 82            [12] 1524 	mov	a, dpl
      008C33 D0 05            [24] 1525 	pop	ar5
      008C35 D0 06            [24] 1526 	pop	ar6
      008C37 D0 07            [24] 1527 	pop	ar7
      008C39 60 07            [24] 1528 	jz	00101$
      008C3B 12 43 0C         [24] 1529 	lcall	_ak820_nvm_ok
      008C3E E5 82            [12] 1530 	mov	a, dpl
      008C40 70 04            [24] 1531 	jnz	00102$
      008C42                       1532 00101$:
      008C42 90 FF FF         [24] 1533 	mov	dptr,#0xffff
      008C45 22               [24] 1534 	ret
      008C46                       1535 00102$:
                                   1536 ;	quantum/dynamic_keymap.c:376: clear_keyboard();
      008C46 C0 07            [24] 1537 	push	ar7
      008C48 C0 06            [24] 1538 	push	ar6
      008C4A C0 05            [24] 1539 	push	ar5
      008C4C 12 7A 9F         [24] 1540 	lcall	_clear_keyboard
      008C4F D0 05            [24] 1541 	pop	ar5
      008C51 D0 06            [24] 1542 	pop	ar6
      008C53 D0 07            [24] 1543 	pop	ar7
                                   1544 ;	quantum/dynamic_keymap.c:377: ak820_eeprom_update_block_xdata(entry, (void *)(VIAL_KEY_OVERRIDE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008C55 BD 06 00         [24] 1545 	cjne	r5,#0x06,00143$
      008C58                       1546 00143$:
      008C58 50 0B            [24] 1547 	jnc	00107$
      008C5A 8D 04            [24] 1548 	mov	ar4,r5
      008C5C EC               [12] 1549 	mov	a,r4
      008C5D 12 40 71         [24] 1550 	lcall	_ak820_outline_0194
      008C60 FB               [12] 1551 	mov	r3,a
      008C61 7C 00            [12] 1552 	mov	r4,#0x00
      008C63 80 10            [24] 1553 	sjmp	00108$
      008C65                       1554 00107$:
      008C65 ED               [12] 1555 	mov	a,r5
      008C66 24 FA            [12] 1556 	add	a,#0xfa
      008C68 12 40 71         [24] 1557 	lcall	_ak820_outline_0194
      008C6B FD               [12] 1558 	mov	r5,a
      008C6C 7A 00            [12] 1559 	mov	r2,#0x00
      008C6E 74 40            [12] 1560 	mov	a,#0x40
      008C70 2D               [12] 1561 	add	a, r5
      008C71 FB               [12] 1562 	mov	r3,a
      008C72 E4               [12] 1563 	clr	a
      008C73 3A               [12] 1564 	addc	a, r2
      008C74 FC               [12] 1565 	mov	r4,a
      008C75                       1566 00108$:
      008C75 74 40            [12] 1567 	mov	a,#0x40
      008C77 2B               [12] 1568 	add	a, r3
      008C78 FB               [12] 1569 	mov	r3,a
      008C79 74 07            [12] 1570 	mov	a,#0x07
      008C7B 3C               [12] 1571 	addc	a, r4
      008C7C FC               [12] 1572 	mov	r4,a
      008C7D 90 05 F6         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      008C80 EB               [12] 1574 	mov	a,r3
      008C81 F0               [24] 1575 	movx	@dptr,a
      008C82 EC               [12] 1576 	mov	a,r4
      008C83 12 38 1E         [24] 1577 	lcall	_ak820_outline_0076
      008C86 90 05 F9         [24] 1578 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      008C89 74 0A            [12] 1579 	mov	a,#0x0a
      008C8B F0               [24] 1580 	movx	@dptr,a
      008C8C E4               [12] 1581 	clr	a
      008C8D A3               [24] 1582 	inc	dptr
      008C8E 12 48 29         [24] 1583 	lcall	_ak820_outline_0066
      008C91 12 47 10         [24] 1584 	lcall	_ak820_eeprom_update_block_xdata
                                   1585 ;	quantum/dynamic_keymap.c:378: ak820_nvm_flush();
      008C94 12 43 1B         [24] 1586 	lcall	_ak820_nvm_flush
                                   1587 ;	quantum/dynamic_keymap.c:379: return ak820_nvm_ok() ? 0 : -1;
      008C97 12 43 0C         [24] 1588 	lcall	_ak820_nvm_ok
      008C9A E5 82            [12] 1589 	mov	a, dpl
      008C9C 60 06            [24] 1590 	jz	00109$
      008C9E 7E 00            [12] 1591 	mov	r6,#0x00
      008CA0 7F 00            [12] 1592 	mov	r7,#0x00
      008CA2 80 04            [24] 1593 	sjmp	00110$
      008CA4                       1594 00109$:
      008CA4 7E FF            [12] 1595 	mov	r6,#0xff
      008CA6 7F FF            [12] 1596 	mov	r7,#0xff
      008CA8                       1597 00110$:
      008CA8 12 48 48         [24] 1598 	lcall	_ak820_outline_0123
                                   1599 ;	quantum/dynamic_keymap.c:380: }
      008CAB 22               [24] 1600 	ret
                                   1601 ;------------------------------------------------------------
                                   1602 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1603 ;------------------------------------------------------------
                                   1604 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_415'
                                   1605 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_416'
                                   1606 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_418'
                                   1607 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_420'
                                   1608 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_422'
                                   1609 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_424'
                                   1610 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_425'
                                   1611 ;ko            Allocated with name '_dynamic_keymap_reset_ko_10002_426'
                                   1612 ;i             Allocated with name '_dynamic_keymap_reset_i_20002_427'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function dynamic_keymap_reset
                                   1617 ;	-----------------------------------------
      008CAC                       1618 _dynamic_keymap_reset:
                                   1619 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008CAC 90 0E A4         [24] 1620 	mov	dptr,#_vial_unlocked
      008CAF E0               [24] 1621 	movx	a,@dptr
      008CB0 90 0B 86         [24] 1622 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_415
      008CB3 F0               [24] 1623 	movx	@dptr,a
                                   1624 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008CB4 90 0E A4         [24] 1625 	mov	dptr,#_vial_unlocked
      008CB7 74 01            [12] 1626 	mov	a,#0x01
      008CB9 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008CBA 7F 00            [12] 1629 	mov	r7,#0x00
      008CBC                       1630 00117$:
      008CBC BF 06 00         [24] 1631 	cjne	r7,#0x06,00217$
      008CBF                       1632 00217$:
      008CBF 40 02            [24] 1633 	jc	00218$
      008CC1 A1 6A            [12] 1634 	ajmp	00104$
      008CC3                       1635 00218$:
                                   1636 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008CC3 7E 00            [12] 1637 	mov	r6,#0x00
      008CC5                       1638 00111$:
      008CC5 BE 10 00         [24] 1639 	cjne	r6,#0x10,00219$
      008CC8                       1640 00219$:
      008CC8 50 4C            [24] 1641 	jnc	00102$
                                   1642 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008CCA 7D 00            [12] 1643 	mov	r5,#0x00
      008CCC                       1644 00108$:
      008CCC BD 08 00         [24] 1645 	cjne	r5,#0x08,00221$
      008CCF                       1646 00221$:
      008CCF 50 42            [24] 1647 	jnc	00112$
                                   1648 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008CD1 90 0C 2C         [24] 1649 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008CD4 EE               [12] 1650 	mov	a,r6
      008CD5 F0               [24] 1651 	movx	@dptr,a
      008CD6 90 0C 2D         [24] 1652 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008CD9 ED               [12] 1653 	mov	a,r5
      008CDA F0               [24] 1654 	movx	@dptr,a
      008CDB 8F 82            [24] 1655 	mov	dpl, r7
      008CDD C0 07            [24] 1656 	push	ar7
      008CDF C0 06            [24] 1657 	push	ar6
      008CE1 C0 05            [24] 1658 	push	ar5
      008CE3 12 9C A0         [24] 1659 	lcall	_keycode_at_keymap_location_raw
      008CE6 AB 82            [24] 1660 	mov	r3, dpl
      008CE8 AC 83            [24] 1661 	mov	r4, dph
      008CEA D0 05            [24] 1662 	pop	ar5
      008CEC D0 06            [24] 1663 	pop	ar6
      008CEE D0 07            [24] 1664 	pop	ar7
      008CF0 90 0B 5D         [24] 1665 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008CF3 EE               [12] 1666 	mov	a,r6
      008CF4 F0               [24] 1667 	movx	@dptr,a
      008CF5 90 0B 5E         [24] 1668 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008CF8 ED               [12] 1669 	mov	a,r5
      008CF9 F0               [24] 1670 	movx	@dptr,a
      008CFA 90 0B 5F         [24] 1671 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008CFD 12 38 2A         [24] 1672 	lcall	_ak820_outline_0086
      008D00 8F 82            [24] 1673 	mov	dpl, r7
      008D02 C0 07            [24] 1674 	push	ar7
      008D04 C0 06            [24] 1675 	push	ar6
      008D06 C0 05            [24] 1676 	push	ar5
      008D08 31 12            [12] 1677 	acall	_dynamic_keymap_set_keycode
      008D0A D0 05            [24] 1678 	pop	ar5
      008D0C D0 06            [24] 1679 	pop	ar6
      008D0E D0 07            [24] 1680 	pop	ar7
                                   1681 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008D10 0D               [12] 1682 	inc	r5
      008D11 80 B9            [24] 1683 	sjmp	00108$
      008D13                       1684 00112$:
                                   1685 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008D13 0E               [12] 1686 	inc	r6
      008D14 80 AF            [24] 1687 	sjmp	00111$
      008D16                       1688 00102$:
                                   1689 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008D16 7E 00            [12] 1690 	mov	r6,#0x00
      008D18                       1691 00114$:
      008D18 BE 01 00         [24] 1692 	cjne	r6,#0x01,00223$
      008D1B                       1693 00223$:
      008D1B 50 4A            [24] 1694 	jnc	00118$
                                   1695 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008D1D 12 94 BF         [24] 1696 	lcall	_ak820_outline_0185
      008D20 04               [12] 1697 	inc	a
      008D21 F0               [24] 1698 	movx	@dptr,a
      008D22 8F 82            [24] 1699 	mov	dpl, r7
      008D24 C0 07            [24] 1700 	push	ar7
      008D26 12 9C E5         [24] 1701 	lcall	_keycode_at_encodermap_location_raw
      008D29 12 48 69         [24] 1702 	lcall	_ak820_outline_0156
      008D2C D0 07            [24] 1703 	pop	ar7
      008D2E 12 94 B6         [24] 1704 	lcall	_ak820_outline_0184
      008D31 04               [12] 1705 	inc	a
      008D32 F0               [24] 1706 	movx	@dptr,a
      008D33 90 0B 69         [24] 1707 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008D36 12 38 24         [24] 1708 	lcall	_ak820_outline_0078
      008D39 8F 82            [24] 1709 	mov	dpl, r7
      008D3B C0 07            [24] 1710 	push	ar7
      008D3D 31 EB            [24] 1711 	acall	_dynamic_keymap_set_encoder
      008D3F D0 07            [24] 1712 	pop	ar7
                                   1713 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008D41 12 94 BF         [24] 1714 	lcall	_ak820_outline_0185
      008D44 F0               [24] 1715 	movx	@dptr,a
      008D45 8F 82            [24] 1716 	mov	dpl, r7
      008D47 C0 07            [24] 1717 	push	ar7
      008D49 12 9C E5         [24] 1718 	lcall	_keycode_at_encodermap_location_raw
      008D4C 12 48 69         [24] 1719 	lcall	_ak820_outline_0156
      008D4F D0 07            [24] 1720 	pop	ar7
      008D51 12 94 B6         [24] 1721 	lcall	_ak820_outline_0184
      008D54 F0               [24] 1722 	movx	@dptr,a
      008D55 90 0B 69         [24] 1723 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008D58 12 38 24         [24] 1724 	lcall	_ak820_outline_0078
      008D5B 8F 82            [24] 1725 	mov	dpl, r7
      008D5D C0 07            [24] 1726 	push	ar7
      008D5F 31 EB            [24] 1727 	acall	_dynamic_keymap_set_encoder
      008D61 D0 07            [24] 1728 	pop	ar7
                                   1729 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008D63 7E 01            [12] 1730 	mov	r6,#0x01
      008D65 80 B1            [24] 1731 	sjmp	00114$
      008D67                       1732 00118$:
                                   1733 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008D67 0F               [12] 1734 	inc	r7
      008D68 81 BC            [12] 1735 	ajmp	00117$
      008D6A                       1736 00104$:
                                   1737 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008D6A 90 0B 87         [24] 1738 	mov	dptr,#_dynamic_keymap_reset_combo_10001_424
      008D6D 12 53 F4         [24] 1739 	lcall	_ak820_outline_0155
      008D70 90 0B 89         [24] 1740 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0002)
      008D73 F0               [24] 1741 	movx	@dptr,a
      008D74 A3               [24] 1742 	inc	dptr
      008D75 F0               [24] 1743 	movx	@dptr,a
      008D76 90 0B 8B         [24] 1744 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0004)
      008D79 F0               [24] 1745 	movx	@dptr,a
      008D7A A3               [24] 1746 	inc	dptr
      008D7B F0               [24] 1747 	movx	@dptr,a
      008D7C 90 0B 8D         [24] 1748 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0006)
      008D7F F0               [24] 1749 	movx	@dptr,a
      008D80 A3               [24] 1750 	inc	dptr
      008D81 F0               [24] 1751 	movx	@dptr,a
      008D82 90 0B 8F         [24] 1752 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0008)
      008D85 F0               [24] 1753 	movx	@dptr,a
      008D86 A3               [24] 1754 	inc	dptr
      008D87 F0               [24] 1755 	movx	@dptr,a
                                   1756 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008D88 FF               [12] 1757 	mov	r7,a
      008D89                       1758 00120$:
      008D89 BF 08 00         [24] 1759 	cjne	r7,#0x08,00225$
      008D8C                       1760 00225$:
      008D8C 50 16            [24] 1761 	jnc	00105$
                                   1762 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008D8E 90 0B 70         [24] 1763 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008D91 74 87            [12] 1764 	mov	a,#_dynamic_keymap_reset_combo_10001_424
      008D93 F0               [24] 1765 	movx	@dptr,a
      008D94 74 0B            [12] 1766 	mov	a,#(_dynamic_keymap_reset_combo_10001_424 >> 8)
      008D96 12 38 1E         [24] 1767 	lcall	_ak820_outline_0076
      008D99 8F 82            [24] 1768 	mov	dpl, r7
      008D9B C0 07            [24] 1769 	push	ar7
      008D9D 51 ED            [24] 1770 	acall	_dynamic_keymap_set_combo
      008D9F D0 07            [24] 1771 	pop	ar7
                                   1772 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008DA1 0F               [12] 1773 	inc	r7
      008DA2 80 E5            [24] 1774 	sjmp	00120$
      008DA4                       1775 00105$:
                                   1776 ;	quantum/dynamic_keymap.c:455: vial_key_override_entry_t ko = { 0 };
      008DA4 90 0B 91         [24] 1777 	mov	dptr,#_dynamic_keymap_reset_ko_10002_426
      008DA7 12 53 F4         [24] 1778 	lcall	_ak820_outline_0155
      008DAA 90 0B 93         [24] 1779 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0002)
      008DAD F0               [24] 1780 	movx	@dptr,a
      008DAE A3               [24] 1781 	inc	dptr
      008DAF F0               [24] 1782 	movx	@dptr,a
      008DB0 90 0B 95         [24] 1783 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0004)
      008DB3 F0               [24] 1784 	movx	@dptr,a
      008DB4 A3               [24] 1785 	inc	dptr
      008DB5 F0               [24] 1786 	movx	@dptr,a
      008DB6 90 0B 97         [24] 1787 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0006)
      008DB9 F0               [24] 1788 	movx	@dptr,a
      008DBA 90 0B 98         [24] 1789 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0007)
      008DBD F0               [24] 1790 	movx	@dptr,a
      008DBE 90 0B 99         [24] 1791 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0008)
      008DC1 F0               [24] 1792 	movx	@dptr,a
      008DC2 90 0B 9A         [24] 1793 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0009)
      008DC5 F0               [24] 1794 	movx	@dptr,a
                                   1795 ;	quantum/dynamic_keymap.c:460: for (reset_index_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i)
      008DC6 FF               [12] 1796 	mov	r7,a
      008DC7                       1797 00123$:
      008DC7 BF 08 00         [24] 1798 	cjne	r7,#0x08,00227$
      008DCA                       1799 00227$:
      008DCA 50 16            [24] 1800 	jnc	00106$
                                   1801 ;	quantum/dynamic_keymap.c:461: dynamic_keymap_set_key_override(i, &ko);
      008DCC 90 0B 82         [24] 1802 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      008DCF 74 91            [12] 1803 	mov	a,#_dynamic_keymap_reset_ko_10002_426
      008DD1 F0               [24] 1804 	movx	@dptr,a
      008DD2 74 0B            [12] 1805 	mov	a,#(_dynamic_keymap_reset_ko_10002_426 >> 8)
      008DD4 12 38 1E         [24] 1806 	lcall	_ak820_outline_0076
      008DD7 8F 82            [24] 1807 	mov	dpl, r7
      008DD9 C0 07            [24] 1808 	push	ar7
      008DDB 91 0F            [12] 1809 	acall	_dynamic_keymap_set_key_override
      008DDD D0 07            [24] 1810 	pop	ar7
                                   1811 ;	quantum/dynamic_keymap.c:460: for (reset_index_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i)
      008DDF 0F               [12] 1812 	inc	r7
      008DE0 80 E5            [24] 1813 	sjmp	00123$
      008DE2                       1814 00106$:
                                   1815 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008DE2 90 0B 86         [24] 1816 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_415
      008DE5 E0               [24] 1817 	movx	a,@dptr
      008DE6 90 0E A4         [24] 1818 	mov	dptr,#_vial_unlocked
      008DE9 F0               [24] 1819 	movx	@dptr,a
                                   1820 ;	quantum/dynamic_keymap.c:468: }
      008DEA 22               [24] 1821 	ret
                                   1822 ;------------------------------------------------------------
                                   1823 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1824 ;------------------------------------------------------------
                                   1825 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1826 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1827 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1828 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1829 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1830 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_428'
                                   1831 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_429'
                                   1832 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_429'
                                   1833 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_432'
                                   1834 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_434'
                                   1835 ;------------------------------------------------------------
                                   1836 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1837 ;	-----------------------------------------
                                   1838 ;	 function ak820_dynamic_read_buffer
                                   1839 ;	-----------------------------------------
      008DEB                       1840 _ak820_dynamic_read_buffer:
      008DEB 12 38 42         [24] 1841 	lcall	_ak820_outline_0108
      008DEE 90 0B A4         [24] 1842 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_428
      008DF1 12 38 47         [24] 1843 	lcall	_ak820_outline_0109
                                   1844 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008DF4 90 0B A1         [24] 1845 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008DF7 12 37 F9         [24] 1846 	lcall	_ak820_outline_0056
                                   1847 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008DFA 90 0B A6         [24] 1848 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      008DFD E4               [12] 1849 	clr	a
      008DFE F0               [24] 1850 	movx	@dptr,a
                                   1851 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008DFF 90 0B 9F         [24] 1852 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008E02 12 38 18         [24] 1853 	lcall	_ak820_outline_0065
      008E05 8C 02            [24] 1854 	mov	ar2,r4
      008E07 8D 03            [24] 1855 	mov	ar3,r5
      008E09 C3               [12] 1856 	clr	c
      008E0A 74 1C            [12] 1857 	mov	a,#0x1c
      008E0C 9A               [12] 1858 	subb	a,r2
      008E0D E4               [12] 1859 	clr	a
      008E0E 9B               [12] 1860 	subb	a,r3
      008E0F 50 01            [24] 1861 	jnc	00102$
                                   1862 ;	free result
      008E11 22               [24] 1863 	ret
      008E12                       1864 00102$:
                                   1865 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008E12 90 0B 9D         [24] 1866 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008E15 12 48 4D         [24] 1867 	lcall	_ak820_outline_0129
      008E18 90 0B 9B         [24] 1868 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008E1B 12 38 3C         [24] 1869 	lcall	_ak820_outline_0107
      008E1E C3               [12] 1870 	clr	c
      008E1F EA               [12] 1871 	mov	a,r2
      008E20 98               [12] 1872 	subb	a,r0
      008E21 EB               [12] 1873 	mov	a,r3
      008E22 99               [12] 1874 	subb	a,r1
      008E23 50 17            [24] 1875 	jnc	00104$
                                   1876 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008E25 E8               [12] 1877 	mov	a,r0
      008E26 C3               [12] 1878 	clr	c
      008E27 9A               [12] 1879 	subb	a,r2
      008E28 F8               [12] 1880 	mov	r0,a
      008E29 E9               [12] 1881 	mov	a,r1
      008E2A 9B               [12] 1882 	subb	a,r3
      008E2B F9               [12] 1883 	mov	r1,a
                                   1884 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008E2C C3               [12] 1885 	clr	c
      008E2D E8               [12] 1886 	mov	a,r0
      008E2E 9C               [12] 1887 	subb	a,r4
      008E2F E9               [12] 1888 	mov	a,r1
      008E30 9D               [12] 1889 	subb	a,r5
      008E31 40 04            [24] 1890 	jc	00114$
      008E33 8C 00            [24] 1891 	mov	ar0,r4
      008E35 8D 01            [24] 1892 	mov	ar1,r5
      008E37                       1893 00114$:
      008E37 90 0B A6         [24] 1894 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      008E3A E8               [12] 1895 	mov	a,r0
      008E3B F0               [24] 1896 	movx	@dptr,a
      008E3C                       1897 00104$:
                                   1898 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008E3C 90 0B A6         [24] 1899 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      008E3F E0               [24] 1900 	movx	a,@dptr
      008E40 F5 34            [12] 1901 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008E42 E0               [24] 1902 	movx	a,@dptr
      008E43 60 42            [24] 1903 	jz	00106$
      008E45 C0 04            [24] 1904 	push	ar4
      008E47 C0 05            [24] 1905 	push	ar5
      008E49 8E 00            [24] 1906 	mov	ar0,r6
      008E4B 8F 05            [24] 1907 	mov	ar5,r7
      008E4D 90 0B A4         [24] 1908 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_428
      008E50 E0               [24] 1909 	movx	a,@dptr
      008E51 F9               [12] 1910 	mov	r1,a
      008E52 A3               [24] 1911 	inc	dptr
      008E53 E0               [24] 1912 	movx	a,@dptr
      008E54 FC               [12] 1913 	mov	r4,a
      008E55 EA               [12] 1914 	mov	a,r2
      008E56 29               [12] 1915 	add	a, r1
      008E57 FA               [12] 1916 	mov	r2,a
      008E58 EB               [12] 1917 	mov	a,r3
      008E59 3C               [12] 1918 	addc	a, r4
      008E5A FB               [12] 1919 	mov	r3,a
      008E5B 90 05 E6         [24] 1920 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008E5E EA               [12] 1921 	mov	a,r2
      008E5F F0               [24] 1922 	movx	@dptr,a
      008E60 EB               [12] 1923 	mov	a,r3
      008E61 12 38 1E         [24] 1924 	lcall	_ak820_outline_0076
      008E64 90 05 E9         [24] 1925 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008E67 E5 34            [12] 1926 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008E69 12 38 57         [24] 1927 	lcall	_ak820_outline_0132
      008E6C 88 82            [24] 1928 	mov	dpl, r0
      008E6E 8D 83            [24] 1929 	mov	dph, r5
      008E70 C0 07            [24] 1930 	push	ar7
      008E72 C0 06            [24] 1931 	push	ar6
      008E74 C0 05            [24] 1932 	push	ar5
      008E76 C0 04            [24] 1933 	push	ar4
      008E78 12 45 A1         [24] 1934 	lcall	_ak820_eeprom_read_block_xdata
      008E7B D0 04            [24] 1935 	pop	ar4
      008E7D D0 05            [24] 1936 	pop	ar5
      008E7F D0 06            [24] 1937 	pop	ar6
      008E81 D0 07            [24] 1938 	pop	ar7
                                   1939 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008E83 D0 05            [24] 1940 	pop	ar5
      008E85 D0 04            [24] 1941 	pop	ar4
                                   1942 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008E87                       1943 00106$:
                                   1944 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008E87 90 0B A6         [24] 1945 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      008E8A E0               [24] 1946 	movx	a,@dptr
      008E8B FB               [12] 1947 	mov	r3,a
      008E8C                       1948 00109$:
      008E8C 8B 01            [24] 1949 	mov	ar1,r3
      008E8E 7A 00            [12] 1950 	mov	r2,#0x00
      008E90 C3               [12] 1951 	clr	c
      008E91 E9               [12] 1952 	mov	a,r1
      008E92 9C               [12] 1953 	subb	a,r4
      008E93 EA               [12] 1954 	mov	a,r2
      008E94 9D               [12] 1955 	subb	a,r5
      008E95 50 09            [24] 1956 	jnc	00111$
      008E97 EB               [12] 1957 	mov	a,r3
      008E98 12 37 F1         [24] 1958 	lcall	_ak820_outline_0033
      008E9B E4               [12] 1959 	clr	a
      008E9C F0               [24] 1960 	movx	@dptr,a
      008E9D 0B               [12] 1961 	inc	r3
      008E9E 80 EC            [24] 1962 	sjmp	00109$
      008EA0                       1963 00111$:
                                   1964 ;	quantum/dynamic_keymap.c:483: }
      008EA0 22               [24] 1965 	ret
                                   1966 ;------------------------------------------------------------
                                   1967 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1968 ;------------------------------------------------------------
                                   1969 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1970 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1971 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_435'
                                   1972 ;------------------------------------------------------------
                                   1973 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1974 ;	-----------------------------------------
                                   1975 ;	 function dynamic_keymap_get_buffer
                                   1976 ;	-----------------------------------------
      008EA1                       1977 _dynamic_keymap_get_buffer:
      008EA1 12 38 42         [24] 1978 	lcall	_ak820_outline_0108
      008EA4 90 0B AC         [24] 1979 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_435
      008EA7 12 38 47         [24] 1980 	lcall	_ak820_outline_0109
                                   1981 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008EAA 90 0B AC         [24] 1982 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_435
      008EAD 12 37 F9         [24] 1983 	lcall	_ak820_outline_0056
      008EB0 90 0B A7         [24] 1984 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008EB3 12 38 18         [24] 1985 	lcall	_ak820_outline_0065
      008EB6 90 0B A9         [24] 1986 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008EB9 12 53 DB         [24] 1987 	lcall	_ak820_outline_0094
      008EBC 90 0B 9B         [24] 1988 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008EBF E4               [12] 1989 	clr	a
      008EC0 F0               [24] 1990 	movx	@dptr,a
      008EC1 74 06            [12] 1991 	mov	a,#0x06
      008EC3 A3               [24] 1992 	inc	dptr
      008EC4 F0               [24] 1993 	movx	@dptr,a
      008EC5 90 0B 9D         [24] 1994 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008EC8 12 4D 63         [24] 1995 	lcall	_ak820_outline_0064
      008ECB 90 0B 9F         [24] 1996 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008ECE 12 38 24         [24] 1997 	lcall	_ak820_outline_0078
      008ED1 90 0B A1         [24] 1998 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008ED4 12 4D 70         [24] 1999 	lcall	_ak820_outline_0144
      008ED7 EB               [12] 2000 	mov	a,r3
      008ED8 A3               [24] 2001 	inc	dptr
      008ED9 F0               [24] 2002 	movx	@dptr,a
      008EDA 90 00 40         [24] 2003 	mov	dptr,#0x0040
                                   2004 ;	quantum/dynamic_keymap.c:511: }
      008EDD A1 EB            [12] 2005 	ajmp	_ak820_dynamic_read_buffer
                                   2006 ;------------------------------------------------------------
                                   2007 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   2008 ;------------------------------------------------------------
                                   2009 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   2010 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   2011 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   2012 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   2013 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   2014 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_437'
                                   2015 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_438'
                                   2016 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_438'
                                   2017 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_438'
                                   2018 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_441'
                                   2019 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_444'
                                   2020 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_444'
                                   2021 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_446'
                                   2022 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_449'
                                   2023 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_451'
                                   2024 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_452'
                                   2025 ;------------------------------------------------------------
                                   2026 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2027 ;	-----------------------------------------
                                   2028 ;	 function dynamic_keymap_set_buffer
                                   2029 ;	-----------------------------------------
      008EDF                       2030 _dynamic_keymap_set_buffer:
      008EDF 12 38 42         [24] 2031 	lcall	_ak820_outline_0108
      008EE2 90 0B B3         [24] 2032 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      008EE5 12 38 47         [24] 2033 	lcall	_ak820_outline_0109
                                   2034 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008EE8 90 0B B3         [24] 2035 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      008EEB 12 37 C4         [24] 2036 	lcall	_ak820_outline_0010
      008EEE 74 40            [12] 2037 	mov	a,#0x40
      008EF0 2C               [12] 2038 	add	a, r4
      008EF1 FA               [12] 2039 	mov	r2,a
      008EF2 E4               [12] 2040 	clr	a
      008EF3 3D               [12] 2041 	addc	a, r5
      008EF4 FB               [12] 2042 	mov	r3,a
                                   2043 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008EF5 90 0B B0         [24] 2044 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008EF8 12 38 3C         [24] 2045 	lcall	_ak820_outline_0107
                                   2046 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008EFB 90 0B AE         [24] 2047 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008EFE E0               [24] 2048 	movx	a,@dptr
      008EFF F5 35            [12] 2049 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008F01 A3               [24] 2050 	inc	dptr
      008F02 E0               [24] 2051 	movx	a,@dptr
      008F03 F5 36            [12] 2052 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008F05 E5 35            [12] 2053 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008F07 45 36            [12] 2054 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F09 70 01            [24] 2055 	jnz	00102$
      008F0B 22               [24] 2056 	ret
      008F0C                       2057 00102$:
                                   2058 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008F0C 85 35 37         [24] 2059 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008F0F 85 36 38         [24] 2060 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F12 C3               [12] 2061 	clr	c
      008F13 74 1C            [12] 2062 	mov	a,#0x1c
      008F15 95 37            [12] 2063 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008F17 E4               [12] 2064 	clr	a
      008F18 95 38            [12] 2065 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008F1A 50 01            [24] 2066 	jnc	00104$
                                   2067 ;	free result
      008F1C 22               [24] 2068 	ret
      008F1D                       2069 00104$:
                                   2070 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008F1D 85 35 39         [24] 2071 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   2072 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008F20 74 FA            [12] 2073 	mov	a,#0x100 - 0x06
      008F22 2F               [12] 2074 	add	a,r7
      008F23 40 11            [24] 2075 	jc	00105$
      008F25 E4               [12] 2076 	clr	a
      008F26 C3               [12] 2077 	clr	c
      008F27 9E               [12] 2078 	subb	a,r6
      008F28 FE               [12] 2079 	mov	r6,a
      008F29 74 06            [12] 2080 	mov	a,#0x06
      008F2B 9F               [12] 2081 	subb	a,r7
      008F2C FF               [12] 2082 	mov	r7,a
      008F2D C3               [12] 2083 	clr	c
      008F2E EE               [12] 2084 	mov	a,r6
      008F2F 95 35            [12] 2085 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008F31 EF               [12] 2086 	mov	a,r7
      008F32 95 36            [12] 2087 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F34 50 01            [24] 2088 	jnc	00106$
      008F36                       2089 00105$:
                                   2090 ;	quantum/dynamic_keymap.c:529: return;
      008F36 22               [24] 2091 	ret
      008F37                       2092 00106$:
                                   2093 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008F37 90 0E A4         [24] 2094 	mov	dptr,#_vial_unlocked
      008F3A E0               [24] 2095 	movx	a,@dptr
      008F3B 60 03            [24] 2096 	jz	00207$
      008F3D 02 90 4C         [24] 2097 	ljmp	00120$
      008F40                       2098 00207$:
                                   2099 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008F40 90 0B B5         [24] 2100 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_444
      008F43 E4               [12] 2101 	clr	a
      008F44 F0               [24] 2102 	movx	@dptr,a
                                   2103 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008F45 90 0B B6         [24] 2104 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_444
      008F48 E5 39            [12] 2105 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008F4A F0               [24] 2106 	movx	@dptr,a
                                   2107 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008F4B EC               [12] 2108 	mov	a,r4
      008F4C 30 E0 33         [24] 2109 	jnb	acc.0,00111$
                                   2110 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008F4F EA               [12] 2111 	mov	a,r2
      008F50 24 FF            [12] 2112 	add	a,#0xff
      008F52 FE               [12] 2113 	mov	r6,a
      008F53 EB               [12] 2114 	mov	a,r3
      008F54 34 FF            [12] 2115 	addc	a,#0xff
      008F56 FF               [12] 2116 	mov	r7,a
      008F57 7D 00            [12] 2117 	mov	r5,#0x00
      008F59 12 48 48         [24] 2118 	lcall	_ak820_outline_0123
      008F5C 8D F0            [24] 2119 	mov	b, r5
      008F5E 12 45 66         [24] 2120 	lcall	_eeprom_read_byte
      008F61 AE 82            [24] 2121 	mov	r6,dpl
      008F63 7F 00            [12] 2122 	mov	r7,#0x00
      008F65 12 38 6C         [24] 2123 	lcall	_ak820_outline_0162
      008F68 E0               [24] 2124 	movx	a,@dptr
      008F69 7C 00            [12] 2125 	mov	r4,#0x00
      008F6B 42 07            [12] 2126 	orl	ar7,a
      008F6D EC               [12] 2127 	mov	a,r4
      008F6E 42 06            [12] 2128 	orl	ar6,a
                                   2129 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008F70 BF 00 09         [24] 2130 	cjne	r7,#0x00,00109$
      008F73 BE 7C 06         [24] 2131 	cjne	r6,#0x7c,00109$
                                   2132 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008F76 12 38 6C         [24] 2133 	lcall	_ak820_outline_0162
      008F79 74 FF            [12] 2134 	mov	a,#0xff
      008F7B F0               [24] 2135 	movx	@dptr,a
      008F7C                       2136 00109$:
                                   2137 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008F7C 90 0B B5         [24] 2138 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_444
      008F7F 74 01            [12] 2139 	mov	a,#0x01
      008F81 F0               [24] 2140 	movx	@dptr,a
      008F82                       2141 00111$:
                                   2142 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008F82 90 0B B3         [24] 2143 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      008F85 12 37 F9         [24] 2144 	lcall	_ak820_outline_0056
      008F88 E5 35            [12] 2145 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008F8A 2E               [12] 2146 	add	a, r6
      008F8B FE               [12] 2147 	mov	r6,a
      008F8C E5 36            [12] 2148 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F8E 3F               [12] 2149 	addc	a, r7
      008F8F EE               [12] 2150 	mov	a,r6
      008F90 30 E0 5A         [24] 2151 	jnb	acc.0,00115$
                                   2152 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008F93 AE 39            [24] 2153 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008F95 7F 00            [12] 2154 	mov	r7,#0x00
      008F97 EE               [12] 2155 	mov	a,r6
      008F98 24 FF            [12] 2156 	add	a,#0xff
      008F9A FC               [12] 2157 	mov	r4,a
      008F9B EF               [12] 2158 	mov	a,r7
      008F9C 34 FF            [12] 2159 	addc	a,#0xff
      008F9E FD               [12] 2160 	mov	r5,a
      008F9F EC               [12] 2161 	mov	a,r4
      008FA0 28               [12] 2162 	add	a, r0
      008FA1 F5 82            [12] 2163 	mov	dpl,a
      008FA3 ED               [12] 2164 	mov	a,r5
      008FA4 39               [12] 2165 	addc	a, r1
      008FA5 F5 83            [12] 2166 	mov	dph,a
      008FA7 E0               [24] 2167 	movx	a,@dptr
      008FA8 FC               [12] 2168 	mov	r4,a
      008FA9 7D 00            [12] 2169 	mov	r5,#0x00
      008FAB E5 39            [12] 2170 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008FAD 2A               [12] 2171 	add	a, r2
      008FAE FA               [12] 2172 	mov	r2,a
      008FAF E4               [12] 2173 	clr	a
      008FB0 3B               [12] 2174 	addc	a, r3
      008FB1 FB               [12] 2175 	mov	r3,a
      008FB2 C0 00            [24] 2176 	push	ar0
      008FB4 C0 01            [24] 2177 	push	ar1
      008FB6 8B 01            [24] 2178 	mov	ar1,r3
      008FB8 7B 00            [12] 2179 	mov	r3,#0x00
      008FBA 8A 82            [24] 2180 	mov	dpl, r2
      008FBC 89 83            [24] 2181 	mov	dph, r1
      008FBE 8B F0            [24] 2182 	mov	b, r3
      008FC0 12 45 66         [24] 2183 	lcall	_eeprom_read_byte
      008FC3 AB 82            [24] 2184 	mov	r3, dpl
      008FC5 7A 00            [12] 2185 	mov	r2,#0x00
      008FC7 EB               [12] 2186 	mov	a,r3
      008FC8 12 48 5E         [24] 2187 	lcall	_ak820_outline_0148
                                   2188 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008FCB BD 00 05         [24] 2189 	cjne	r5,#0x00,00212$
      008FCE BC 7C 02         [24] 2190 	cjne	r4,#0x7c,00212$
      008FD1 80 06            [24] 2191 	sjmp	00213$
      008FD3                       2192 00212$:
      008FD3 D0 01            [24] 2193 	pop	ar1
      008FD5 D0 00            [24] 2194 	pop	ar0
      008FD7 80 0D            [24] 2195 	sjmp	00113$
      008FD9                       2196 00213$:
      008FD9 D0 01            [24] 2197 	pop	ar1
      008FDB D0 00            [24] 2198 	pop	ar0
                                   2199 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008FDD 1E               [12] 2200 	dec	r6
      008FDE BE FF 01         [24] 2201 	cjne	r6,#0xff,00214$
      008FE1 1F               [12] 2202 	dec	r7
      008FE2                       2203 00214$:
      008FE2 EE               [12] 2204 	mov	a,r6
      008FE3 12 94 98         [24] 2205 	lcall	_ak820_outline_0136
      008FE6                       2206 00113$:
                                   2207 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008FE6 E5 39            [12] 2208 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008FE8 14               [12] 2209 	dec	a
      008FE9 90 0B B6         [24] 2210 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_444
      008FEC F0               [24] 2211 	movx	@dptr,a
      008FED                       2212 00115$:
                                   2213 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008FED 90 0B B5         [24] 2214 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_444
      008FF0 E0               [24] 2215 	movx	a,@dptr
      008FF1 90 0B B7         [24] 2216 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_451
      008FF4 F0               [24] 2217 	movx	@dptr,a
      008FF5                       2218 00122$:
      008FF5 90 0B B7         [24] 2219 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_451
      008FF8 E0               [24] 2220 	movx	a,@dptr
      008FF9 FF               [12] 2221 	mov	r7,a
      008FFA 90 0B B6         [24] 2222 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_444
      008FFD E0               [24] 2223 	movx	a,@dptr
      008FFE FE               [12] 2224 	mov	r6,a
      008FFF C3               [12] 2225 	clr	c
      009000 EF               [12] 2226 	mov	a,r7
      009001 9E               [12] 2227 	subb	a,r6
      009002 50 48            [24] 2228 	jnc	00120$
                                   2229 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      009004 EF               [12] 2230 	mov	a,r7
      009005 28               [12] 2231 	add	a, r0
      009006 FD               [12] 2232 	mov	r5,a
      009007 E4               [12] 2233 	clr	a
      009008 39               [12] 2234 	addc	a, r1
      009009 FE               [12] 2235 	mov	r6,a
      00900A 12 4D 69         [24] 2236 	lcall	_ak820_outline_0079
      00900D 7B 00            [12] 2237 	mov	r3,#0x00
      00900F 8C 36            [24] 2238 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      009011 8B 35            [24] 2239 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      009013 8F 02            [24] 2240 	mov	ar2,r7
      009015 7F 00            [12] 2241 	mov	r7,#0x00
      009017 74 01            [12] 2242 	mov	a,#0x01
      009019 2A               [12] 2243 	add	a, r2
      00901A FB               [12] 2244 	mov	r3,a
      00901B E4               [12] 2245 	clr	a
      00901C 3F               [12] 2246 	addc	a, r7
      00901D FC               [12] 2247 	mov	r4,a
      00901E EB               [12] 2248 	mov	a,r3
      00901F 28               [12] 2249 	add	a, r0
      009020 F5 82            [12] 2250 	mov	dpl,a
      009022 EC               [12] 2251 	mov	a,r4
      009023 39               [12] 2252 	addc	a, r1
      009024 F5 83            [12] 2253 	mov	dph,a
      009026 E0               [24] 2254 	movx	a,@dptr
      009027 FC               [12] 2255 	mov	r4,a
      009028 7B 00            [12] 2256 	mov	r3,#0x00
      00902A E5 36            [12] 2257 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00902C 42 03            [12] 2258 	orl	ar3,a
                                   2259 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      00902E BC 00 12         [24] 2260 	cjne	r4,#0x00,00123$
      009031 BB 7C 0F         [24] 2261 	cjne	r3,#0x7c,00123$
                                   2262 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      009034 12 38 5C         [24] 2263 	lcall	_ak820_outline_0141
      009037 74 FF            [12] 2264 	mov	a,#0xff
      009039 F0               [24] 2265 	movx	@dptr,a
                                   2266 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      00903A 0A               [12] 2267 	inc	r2
      00903B BA 00 01         [24] 2268 	cjne	r2,#0x00,00218$
      00903E 0F               [12] 2269 	inc	r7
      00903F                       2270 00218$:
      00903F EA               [12] 2271 	mov	a,r2
      009040 12 94 98         [24] 2272 	lcall	_ak820_outline_0136
      009043                       2273 00123$:
                                   2274 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      009043 90 0B B7         [24] 2275 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_451
      009046 E0               [24] 2276 	movx	a,@dptr
      009047 24 02            [12] 2277 	add	a,#0x02
      009049 F0               [24] 2278 	movx	@dptr,a
      00904A 80 A9            [24] 2279 	sjmp	00122$
      00904C                       2280 00120$:
                                   2281 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      00904C 90 0B B3         [24] 2282 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      00904F 12 37 F9         [24] 2283 	lcall	_ak820_outline_0056
      009052 74 40            [12] 2284 	mov	a,#0x40
      009054 12 48 58         [24] 2285 	lcall	_ak820_outline_0143
      009057 90 05 EF         [24] 2286 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00905A 12 4D 63         [24] 2287 	lcall	_ak820_outline_0064
      00905D E4               [12] 2288 	clr	a
      00905E A3               [24] 2289 	inc	dptr
      00905F F0               [24] 2290 	movx	@dptr,a
      009060 90 05 F2         [24] 2291 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      009063 E5 37            [12] 2292 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      009065 F0               [24] 2293 	movx	@dptr,a
      009066 E5 38            [12] 2294 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      009068 A3               [24] 2295 	inc	dptr
      009069 F0               [24] 2296 	movx	@dptr,a
      00906A 12 38 6C         [24] 2297 	lcall	_ak820_outline_0162
                                   2298 ;	quantum/dynamic_keymap.c:584: }
      00906D 02 46 2D         [24] 2299 	ljmp	_ak820_eeprom_write_block_xdata
                                   2300 ;------------------------------------------------------------
                                   2301 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2302 ;------------------------------------------------------------
                                   2303 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2304 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2305 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_455'
                                   2306 ;------------------------------------------------------------
                                   2307 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2308 ;	-----------------------------------------
                                   2309 ;	 function keycode_at_keymap_location
                                   2310 ;	-----------------------------------------
      009070                       2311 _keycode_at_keymap_location:
      009070 E5 82            [12] 2312 	mov	a,dpl
      009072 90 0B BA         [24] 2313 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_455
      009075 F0               [24] 2314 	movx	@dptr,a
                                   2315 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      009076 E0               [24] 2316 	movx	a,@dptr
      009077 FF               [12] 2317 	mov	r7,a
      009078 BF 06 00         [24] 2318 	cjne	r7,#0x06,00128$
      00907B                       2319 00128$:
      00907B 50 23            [24] 2320 	jnc	00102$
      00907D 90 0B B8         [24] 2321 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      009080 E0               [24] 2322 	movx	a,@dptr
      009081 FE               [12] 2323 	mov	r6,a
      009082 BE 10 00         [24] 2324 	cjne	r6,#0x10,00130$
      009085                       2325 00130$:
      009085 50 19            [24] 2326 	jnc	00102$
      009087 90 0B B9         [24] 2327 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      00908A E0               [24] 2328 	movx	a,@dptr
      00908B FD               [12] 2329 	mov	r5,a
      00908C BD 08 00         [24] 2330 	cjne	r5,#0x08,00132$
      00908F                       2331 00132$:
      00908F 50 0F            [24] 2332 	jnc	00102$
                                   2333 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      009091 90 0B 5A         [24] 2334 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      009094 EE               [12] 2335 	mov	a,r6
      009095 F0               [24] 2336 	movx	@dptr,a
      009096 90 0B 5B         [24] 2337 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      009099 ED               [12] 2338 	mov	a,r5
      00909A F0               [24] 2339 	movx	@dptr,a
      00909B 8F 82            [24] 2340 	mov	dpl, r7
      00909D 02 88 C5         [24] 2341 	ljmp	_dynamic_keymap_get_keycode
      0090A0                       2342 00102$:
                                   2343 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      0090A0 90 00 00         [24] 2344 	mov	dptr,#0x0000
                                   2345 ;	quantum/dynamic_keymap.c:591: }
      0090A3 22               [24] 2346 	ret
                                   2347 ;------------------------------------------------------------
                                   2348 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2349 ;------------------------------------------------------------
                                   2350 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2351 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2352 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_459'
                                   2353 ;------------------------------------------------------------
                                   2354 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2355 ;	-----------------------------------------
                                   2356 ;	 function keycode_at_encodermap_location
                                   2357 ;	-----------------------------------------
      0090A4                       2358 _keycode_at_encodermap_location:
      0090A4 E5 82            [12] 2359 	mov	a,dpl
      0090A6 90 0B BD         [24] 2360 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_459
      0090A9 F0               [24] 2361 	movx	@dptr,a
                                   2362 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      0090AA E0               [24] 2363 	movx	a,@dptr
      0090AB FF               [12] 2364 	mov	r7,a
      0090AC BF 06 00         [24] 2365 	cjne	r7,#0x06,00120$
      0090AF                       2366 00120$:
      0090AF 50 1E            [24] 2367 	jnc	00102$
      0090B1 90 0B BB         [24] 2368 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0090B4 E0               [24] 2369 	movx	a,@dptr
      0090B5 FE               [12] 2370 	mov	r6,a
      0090B6 BE 01 00         [24] 2371 	cjne	r6,#0x01,00122$
      0090B9                       2372 00122$:
      0090B9 50 14            [24] 2373 	jnc	00102$
                                   2374 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      0090BB 90 0B BC         [24] 2375 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0090BE E0               [24] 2376 	movx	a,@dptr
      0090BF FE               [12] 2377 	mov	r6,a
      0090C0 90 0B 64         [24] 2378 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0090C3 E4               [12] 2379 	clr	a
      0090C4 F0               [24] 2380 	movx	@dptr,a
      0090C5 90 0B 65         [24] 2381 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0090C8 EE               [12] 2382 	mov	a,r6
      0090C9 F0               [24] 2383 	movx	@dptr,a
      0090CA 8F 82            [24] 2384 	mov	dpl, r7
      0090CC 02 89 84         [24] 2385 	ljmp	_dynamic_keymap_get_encoder
      0090CF                       2386 00102$:
                                   2387 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      0090CF 90 00 00         [24] 2388 	mov	dptr,#0x0000
                                   2389 ;	quantum/dynamic_keymap.c:599: }
      0090D2 22               [24] 2390 	ret
                                   2391 ;------------------------------------------------------------
                                   2392 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2393 ;------------------------------------------------------------
                                   2394 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2395 ;	-----------------------------------------
                                   2396 ;	 function dynamic_keymap_macro_get_count
                                   2397 ;	-----------------------------------------
      0090D3                       2398 _dynamic_keymap_macro_get_count:
                                   2399 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      0090D3 75 82 10         [24] 2400 	mov	dpl, #0x10
                                   2401 ;	quantum/dynamic_keymap.c:604: }
      0090D6 22               [24] 2402 	ret
                                   2403 ;------------------------------------------------------------
                                   2404 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2405 ;------------------------------------------------------------
                                   2406 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2407 ;	-----------------------------------------
                                   2408 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2409 ;	-----------------------------------------
      0090D7                       2410 _dynamic_keymap_macro_get_buffer_size:
                                   2411 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      0090D7 90 20 00         [24] 2412 	mov	dptr,#0x2000
                                   2413 ;	quantum/dynamic_keymap.c:608: }
      0090DA 22               [24] 2414 	ret
                                   2415 ;------------------------------------------------------------
                                   2416 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2417 ;------------------------------------------------------------
                                   2418 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2419 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2420 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2421 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_467'
                                   2422 ;------------------------------------------------------------
                                   2423 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2424 ;	-----------------------------------------
                                   2425 ;	 function dynamic_keymap_macro_get_buffer
                                   2426 ;	-----------------------------------------
      0090DB                       2427 _dynamic_keymap_macro_get_buffer:
      0090DB 12 38 42         [24] 2428 	lcall	_ak820_outline_0108
      0090DE 90 0B C3         [24] 2429 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_467
      0090E1 12 38 47         [24] 2430 	lcall	_ak820_outline_0109
                                   2431 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      0090E4 12 2B 2B         [24] 2432 	lcall	_ak820_macro_length
      0090E7 12 48 53         [24] 2433 	lcall	_ak820_outline_0140
      0090EA 90 0B C3         [24] 2434 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_467
      0090ED 12 38 18         [24] 2435 	lcall	_ak820_outline_0065
      0090F0 90 0B BE         [24] 2436 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      0090F3 E0               [24] 2437 	movx	a,@dptr
      0090F4 F5 3A            [12] 2438 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      0090F6 A3               [24] 2439 	inc	dptr
      0090F7 E0               [24] 2440 	movx	a,@dptr
      0090F8 F5 3B            [12] 2441 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      0090FA 90 0B C0         [24] 2442 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      0090FD 12 38 3C         [24] 2443 	lcall	_ak820_outline_0107
      009100 A3               [24] 2444 	inc	dptr
      009101 E0               [24] 2445 	movx	a,@dptr
      009102 FB               [12] 2446 	mov	r3,a
      009103 90 0B 9B         [24] 2447 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      009106 12 4D 63         [24] 2448 	lcall	_ak820_outline_0064
      009109 90 0B 9D         [24] 2449 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00910C 12 38 24         [24] 2450 	lcall	_ak820_outline_0078
      00910F 90 0B 9F         [24] 2451 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009112 E5 3A            [12] 2452 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      009114 F0               [24] 2453 	movx	@dptr,a
      009115 E5 3B            [12] 2454 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      009117 A3               [24] 2455 	inc	dptr
      009118 F0               [24] 2456 	movx	@dptr,a
      009119 90 0B A1         [24] 2457 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00911C 12 53 F9         [24] 2458 	lcall	_ak820_outline_0168
      00911F EB               [12] 2459 	mov	a,r3
      009120 A3               [24] 2460 	inc	dptr
      009121 F0               [24] 2461 	movx	@dptr,a
      009122 90 08 00         [24] 2462 	mov	dptr,#0x0800
                                   2463 ;	quantum/dynamic_keymap.c:635: }
      009125 02 8D EB         [24] 2464 	ljmp	_ak820_dynamic_read_buffer
                                   2465 ;------------------------------------------------------------
                                   2466 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2467 ;------------------------------------------------------------
                                   2468 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2469 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2470 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_469'
                                   2471 ;------------------------------------------------------------
                                   2472 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2473 ;	-----------------------------------------
                                   2474 ;	 function dynamic_keymap_macro_set_buffer
                                   2475 ;	-----------------------------------------
      009128                       2476 _dynamic_keymap_macro_set_buffer:
      009128 12 38 42         [24] 2477 	lcall	_ak820_outline_0108
      00912B 90 0B CA         [24] 2478 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_469
      00912E 12 38 47         [24] 2479 	lcall	_ak820_outline_0109
                                   2480 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      009131 90 0B CA         [24] 2481 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_469
      009134 12 37 F9         [24] 2482 	lcall	_ak820_outline_0056
      009137 90 0B C5         [24] 2483 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00913A 12 38 18         [24] 2484 	lcall	_ak820_outline_0065
      00913D 90 0B C7         [24] 2485 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009140 12 53 DB         [24] 2486 	lcall	_ak820_outline_0094
      009143 90 05 75         [24] 2487 	mov	dptr,#_ak820_macro_write_PARM_2
      009146 12 38 24         [24] 2488 	lcall	_ak820_outline_0078
      009149 90 05 77         [24] 2489 	mov	dptr,#_ak820_macro_write_PARM_3
      00914C 12 4D 70         [24] 2490 	lcall	_ak820_outline_0144
      00914F EB               [12] 2491 	mov	a,r3
      009150 A3               [24] 2492 	inc	dptr
      009151 12 48 29         [24] 2493 	lcall	_ak820_outline_0066
                                   2494 ;	quantum/dynamic_keymap.c:640: }
      009154 02 2B 45         [24] 2495 	ljmp	_ak820_macro_write
                                   2496 ;------------------------------------------------------------
                                   2497 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2498 ;------------------------------------------------------------
                                   2499 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2500 ;	-----------------------------------------
                                   2501 ;	 function dynamic_keymap_macro_reset
                                   2502 ;	-----------------------------------------
      009157                       2503 _dynamic_keymap_macro_reset:
                                   2504 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2505 ;	quantum/dynamic_keymap.c:666: }
      009157 02 2E 64         [24] 2506 	ljmp	_ak820_macro_reset
                                   2507 ;------------------------------------------------------------
                                   2508 ;Allocation info for local variables in function 'decode_keycode'
                                   2509 ;------------------------------------------------------------
                                   2510 ;kc            Allocated with name '_decode_keycode_kc_10000_473'
                                   2511 ;------------------------------------------------------------
                                   2512 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2513 ;	-----------------------------------------
                                   2514 ;	 function decode_keycode
                                   2515 ;	-----------------------------------------
      00915A                       2516 _decode_keycode:
      00915A 12 38 42         [24] 2517 	lcall	_ak820_outline_0108
      00915D 90 0B CC         [24] 2518 	mov	dptr,#_decode_keycode_kc_10000_473
      009160 12 38 47         [24] 2519 	lcall	_ak820_outline_0109
                                   2520 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      009163 90 0B CC         [24] 2521 	mov	dptr,#_decode_keycode_kc_10000_473
      009166 12 37 C4         [24] 2522 	lcall	_ak820_outline_0010
      009169 C3               [12] 2523 	clr	c
      00916A E4               [12] 2524 	clr	a
      00916B 9C               [12] 2525 	subb	a,r4
      00916C 74 FF            [12] 2526 	mov	a,#0xff
      00916E 9D               [12] 2527 	subb	a,r5
      00916F 50 08            [24] 2528 	jnc	00102$
                                   2529 ;	free result
                                   2530 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      009171 8C 05            [24] 2531 	mov	ar5,r4
      009173 7C 00            [12] 2532 	mov	r4,#0x00
      009175 12 38 4C         [24] 2533 	lcall	_ak820_outline_0126
      009178 22               [24] 2534 	ret
      009179                       2535 00102$:
                                   2536 ;	quantum/dynamic_keymap.c:672: return kc;
      009179 12 48 48         [24] 2537 	lcall	_ak820_outline_0123
                                   2538 ;	quantum/dynamic_keymap.c:673: }
      00917C 22               [24] 2539 	ret
                                   2540 ;------------------------------------------------------------
                                   2541 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2542 ;------------------------------------------------------------
                                   2543 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_476'
                                   2544 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_477'
                                   2545 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_482'
                                   2546 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_483'
                                   2547 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_489'
                                   2548 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_507'
                                   2549 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_511'
                                   2550 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_511'
                                   2551 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_513'
                                   2552 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_515'
                                   2553 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_519'
                                   2554 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_521'
                                   2555 ;------------------------------------------------------------
                                   2556 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2557 ;	-----------------------------------------
                                   2558 ;	 function dynamic_keymap_macro_send
                                   2559 ;	-----------------------------------------
      00917D                       2560 _dynamic_keymap_macro_send:
      00917D E5 82            [12] 2561 	mov	a,dpl
      00917F 90 0B CE         [24] 2562 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_476
      009182 F0               [24] 2563 	movx	@dptr,a
                                   2564 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      009183 90 0B CF         [24] 2565 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_477
      009186 E0               [24] 2566 	movx	a,@dptr
      009187 60 01            [24] 2567 	jz	00102$
      009189 22               [24] 2568 	ret
      00918A                       2569 00102$:
                                   2570 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      00918A 90 0B CE         [24] 2571 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_476
      00918D E0               [24] 2572 	movx	a,@dptr
      00918E FF               [12] 2573 	mov	r7,a
      00918F BF 10 00         [24] 2574 	cjne	r7,#0x10,00422$
      009192                       2575 00422$:
      009192 40 01            [24] 2576 	jc	00104$
                                   2577 ;	quantum/dynamic_keymap.c:683: return;
      009194 22               [24] 2578 	ret
      009195                       2579 00104$:
                                   2580 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      009195 C0 07            [24] 2581 	push	ar7
      009197 12 2A F2         [24] 2582 	lcall	_ak820_macro_ready
      00919A E5 82            [12] 2583 	mov	a, dpl
      00919C D0 07            [24] 2584 	pop	ar7
      00919E 70 01            [24] 2585 	jnz	00106$
      0091A0 22               [24] 2586 	ret
      0091A1                       2587 00106$:
                                   2588 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      0091A1 90 0B D0         [24] 2589 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      0091A4 E4               [12] 2590 	clr	a
      0091A5 F0               [24] 2591 	movx	@dptr,a
      0091A6 74 08            [12] 2592 	mov	a,#0x08
      0091A8 A3               [24] 2593 	inc	dptr
      0091A9 F0               [24] 2594 	movx	@dptr,a
                                   2595 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      0091AA C0 07            [24] 2596 	push	ar7
      0091AC 12 2B 2B         [24] 2597 	lcall	_ak820_macro_length
      0091AF AD 82            [24] 2598 	mov	r5, dpl
      0091B1 AE 83            [24] 2599 	mov	r6, dph
      0091B3 D0 07            [24] 2600 	pop	ar7
      0091B5 74 08            [12] 2601 	mov	a,#0x08
      0091B7 2E               [12] 2602 	add	a, r6
      0091B8 FE               [12] 2603 	mov	r6,a
                                   2604 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      0091B9 7B 00            [12] 2605 	mov	r3,#0x00
      0091BB 7C 08            [12] 2606 	mov	r4,#0x08
      0091BD                       2607 00111$:
      0091BD EF               [12] 2608 	mov	a,r7
      0091BE 60 31            [24] 2609 	jz	00113$
                                   2610 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      0091C0 EB               [12] 2611 	mov	a,r3
      0091C1 B5 05 05         [24] 2612 	cjne	a,ar5,00108$
      0091C4 EC               [12] 2613 	mov	a,r4
      0091C5 B5 06 01         [24] 2614 	cjne	a,ar6,00108$
                                   2615 ;	quantum/dynamic_keymap.c:717: return;
      0091C8 22               [24] 2616 	ret
      0091C9                       2617 00108$:
                                   2618 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      0091C9 8B 01            [24] 2619 	mov	ar1,r3
      0091CB 8C 02            [24] 2620 	mov	ar2,r4
      0091CD 8A 00            [24] 2621 	mov	ar0,r2
      0091CF 7A 00            [12] 2622 	mov	r2,#0x00
      0091D1 89 82            [24] 2623 	mov	dpl, r1
      0091D3 88 83            [24] 2624 	mov	dph, r0
      0091D5 8A F0            [24] 2625 	mov	b, r2
      0091D7 12 45 66         [24] 2626 	lcall	_eeprom_read_byte
      0091DA E5 82            [12] 2627 	mov	a, dpl
      0091DC 70 06            [24] 2628 	jnz	00110$
                                   2629 ;	quantum/dynamic_keymap.c:720: --id;
      0091DE 1F               [12] 2630 	dec	r7
      0091DF 90 0B CE         [24] 2631 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_476
      0091E2 EF               [12] 2632 	mov	a,r7
      0091E3 F0               [24] 2633 	movx	@dptr,a
      0091E4                       2634 00110$:
                                   2635 ;	quantum/dynamic_keymap.c:722: ++p;
      0091E4 0B               [12] 2636 	inc	r3
      0091E5 BB 00 01         [24] 2637 	cjne	r3,#0x00,00429$
      0091E8 0C               [12] 2638 	inc	r4
      0091E9                       2639 00429$:
      0091E9 90 0B D0         [24] 2640 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      0091EC 12 38 2A         [24] 2641 	lcall	_ak820_outline_0086
      0091EF 80 CC            [24] 2642 	sjmp	00111$
      0091F1                       2643 00113$:
                                   2644 ;	quantum/dynamic_keymap.c:728: sending = true;
      0091F1 90 0B CF         [24] 2645 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_477
      0091F4 74 01            [12] 2646 	mov	a,#0x01
      0091F6 F0               [24] 2647 	movx	@dptr,a
                                   2648 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      0091F7 12 94 B0         [24] 2649 	lcall	_ak820_outline_0173
      0091FA 90 09 E2         [24] 2650 	mov	dptr,#_ak820_macro_cancelled
      0091FD F0               [24] 2651 	movx	@dptr,a
                                   2652 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      0091FE 90 0B D2         [24] 2653 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009201 F0               [24] 2654 	movx	@dptr,a
      009202 90 0B D3         [24] 2655 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      009205 F0               [24] 2656 	movx	@dptr,a
      009206 90 0B D4         [24] 2657 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0002)
      009209 F0               [24] 2658 	movx	@dptr,a
      00920A 90 0B D5         [24] 2659 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0003)
      00920D F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	quantum/dynamic_keymap.c:738: while (p < end
      00920E                       2662 00167$:
                                   2663 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      00920E 90 0B D0         [24] 2664 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      009211 E0               [24] 2665 	movx	a,@dptr
      009212 FC               [12] 2666 	mov	r4,a
      009213 A3               [24] 2667 	inc	dptr
      009214 E0               [24] 2668 	movx	a,@dptr
      009215 FF               [12] 2669 	mov	r7,a
      009216 C3               [12] 2670 	clr	c
      009217 EC               [12] 2671 	mov	a,r4
      009218 9D               [12] 2672 	subb	a,r5
      009219 EF               [12] 2673 	mov	a,r7
      00921A 9E               [12] 2674 	subb	a,r6
      00921B 40 02            [24] 2675 	jc	00430$
      00921D 81 22            [12] 2676 	ajmp	00169$
      00921F                       2677 00430$:
      00921F 90 09 E2         [24] 2678 	mov	dptr,#_ak820_macro_cancelled
      009222 E0               [24] 2679 	movx	a,@dptr
      009223 60 02            [24] 2680 	jz	00431$
      009225 81 22            [12] 2681 	ajmp	00169$
      009227                       2682 00431$:
                                   2683 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009227 8C 02            [24] 2684 	mov	ar2,r4
      009229 8F 03            [24] 2685 	mov	ar3,r7
      00922B 90 0B D0         [24] 2686 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      00922E 74 01            [12] 2687 	mov	a,#0x01
      009230 2C               [12] 2688 	add	a, r4
      009231 F0               [24] 2689 	movx	@dptr,a
      009232 E4               [12] 2690 	clr	a
      009233 3F               [12] 2691 	addc	a, r7
      009234 A3               [24] 2692 	inc	dptr
      009235 F0               [24] 2693 	movx	@dptr,a
      009236 7F 00            [12] 2694 	mov	r7,#0x00
      009238 12 48 64         [24] 2695 	lcall	_ak820_outline_0149
      00923B 8F F0            [24] 2696 	mov	b, r7
      00923D 12 45 66         [24] 2697 	lcall	_eeprom_read_byte
      009240 AF 82            [24] 2698 	mov	r7, dpl
      009242 90 0B D2         [24] 2699 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009245 EF               [12] 2700 	mov	a,r7
      009246 F0               [24] 2701 	movx	@dptr,a
                                   2702 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      009247 90 0B D3         [24] 2703 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      00924A E4               [12] 2704 	clr	a
      00924B F0               [24] 2705 	movx	@dptr,a
                                   2706 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      00924C 90 0B D2         [24] 2707 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      00924F E0               [24] 2708 	movx	a,@dptr
      009250 70 02            [24] 2709 	jnz	00432$
      009252 81 22            [12] 2710 	ajmp	00169$
      009254                       2711 00432$:
                                   2712 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      009254 90 0B D2         [24] 2713 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009257 E0               [24] 2714 	movx	a,@dptr
      009258 FF               [12] 2715 	mov	r7,a
      009259 BF 01 02         [24] 2716 	cjne	r7,#0x01,00433$
      00925C 80 02            [24] 2717 	sjmp	00434$
      00925E                       2718 00433$:
      00925E 81 05            [12] 2719 	ajmp	00164$
      009260                       2720 00434$:
                                   2721 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009260 12 94 2A         [24] 2722 	lcall	_ak820_outline_0000
      009263 12 45 66         [24] 2723 	lcall	_eeprom_read_byte
      009266 AF 82            [24] 2724 	mov	r7, dpl
      009268 90 0B D3         [24] 2725 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      00926B EF               [12] 2726 	mov	a,r7
      00926C F0               [24] 2727 	movx	@dptr,a
                                   2728 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      00926D EF               [12] 2729 	mov	a,r7
      00926E 70 02            [24] 2730 	jnz	00435$
      009270 81 22            [12] 2731 	ajmp	00169$
      009272                       2732 00435$:
                                   2733 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      009272 12 94 77         [24] 2734 	lcall	_ak820_outline_0096
      009275 BF 01 02         [24] 2735 	cjne	r7,#0x01,00436$
      009278 80 12            [24] 2736 	sjmp	00151$
      00927A                       2737 00436$:
      00927A 12 94 77         [24] 2738 	lcall	_ak820_outline_0096
      00927D BF 02 02         [24] 2739 	cjne	r7,#0x02,00437$
      009280 80 0A            [24] 2740 	sjmp	00151$
      009282                       2741 00437$:
      009282 12 94 77         [24] 2742 	lcall	_ak820_outline_0096
      009285 BF 03 02         [24] 2743 	cjne	r7,#0x03,00438$
      009288 80 02            [24] 2744 	sjmp	00439$
      00928A                       2745 00438$:
      00928A 41 EB            [12] 2746 	ajmp	00152$
      00928C                       2747 00439$:
      00928C                       2748 00151$:
                                   2749 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00928C 12 94 2A         [24] 2750 	lcall	_ak820_outline_0000
      00928F 12 45 66         [24] 2751 	lcall	_eeprom_read_byte
      009292 12 94 C8         [24] 2752 	lcall	_ak820_outline_0188
                                   2753 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      009295 70 02            [24] 2754 	jnz	00440$
      009297 41 0E            [12] 2755 	ajmp	00167$
      009299                       2756 00440$:
                                   2757 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      009299 12 94 77         [24] 2758 	lcall	_ak820_outline_0096
      00929C BF 01 03         [24] 2759 	cjne	r7,#0x01,00441$
      00929F D3               [12] 2760 	setb	c
      0092A0 80 01            [24] 2761 	sjmp	00442$
      0092A2                       2762 00441$:
      0092A2 C3               [12] 2763 	clr	c
      0092A3                       2764 00442$:
      0092A3 92 25            [24] 2765 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0092A5 90 09 E1         [24] 2766 	mov	dptr,#_ak820_macro_primitive
      0092A8 B3               [12] 2767 	cpl	c
      0092A9 E4               [12] 2768 	clr	a
      0092AA 33               [12] 2769 	rlc	a
      0092AB F0               [24] 2770 	movx	@dptr,a
                                   2771 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0092AC 12 94 77         [24] 2772 	lcall	_ak820_outline_0096
      0092AF BF 01 10         [24] 2773 	cjne	r7,#0x01,00122$
      0092B2 12 94 A9         [24] 2774 	lcall	_ak820_outline_0158
      0092B5 C0 06            [24] 2775 	push	ar6
      0092B7 C0 05            [24] 2776 	push	ar5
      0092B9 12 7A 33         [24] 2777 	lcall	_tap_code
      0092BC D0 05            [24] 2778 	pop	ar5
      0092BE D0 06            [24] 2779 	pop	ar6
      0092C0 80 24            [24] 2780 	sjmp	00123$
      0092C2                       2781 00122$:
                                   2782 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0092C2 12 94 77         [24] 2783 	lcall	_ak820_outline_0096
      0092C5 BF 02 10         [24] 2784 	cjne	r7,#0x02,00119$
      0092C8 12 94 A9         [24] 2785 	lcall	_ak820_outline_0158
      0092CB C0 06            [24] 2786 	push	ar6
      0092CD C0 05            [24] 2787 	push	ar5
      0092CF 12 79 35         [24] 2788 	lcall	_register_code
      0092D2 D0 05            [24] 2789 	pop	ar5
      0092D4 D0 06            [24] 2790 	pop	ar6
      0092D6 80 0E            [24] 2791 	sjmp	00123$
      0092D8                       2792 00119$:
                                   2793 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      0092D8 12 94 A9         [24] 2794 	lcall	_ak820_outline_0158
      0092DB C0 06            [24] 2795 	push	ar6
      0092DD C0 05            [24] 2796 	push	ar5
      0092DF 12 79 9F         [24] 2797 	lcall	_unregister_code
      0092E2 D0 05            [24] 2798 	pop	ar5
      0092E4 D0 06            [24] 2799 	pop	ar6
      0092E6                       2800 00123$:
                                   2801 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      0092E6 12 94 B0         [24] 2802 	lcall	_ak820_outline_0173
      0092E9 41 0E            [12] 2803 	ajmp	00167$
      0092EB                       2804 00152$:
                                   2805 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0092EB 12 94 77         [24] 2806 	lcall	_ak820_outline_0096
      0092EE BF 05 02         [24] 2807 	cjne	r7,#0x05,00447$
      0092F1 80 12            [24] 2808 	sjmp	00146$
      0092F3                       2809 00447$:
      0092F3 12 94 77         [24] 2810 	lcall	_ak820_outline_0096
      0092F6 BF 06 02         [24] 2811 	cjne	r7,#0x06,00448$
      0092F9 80 0A            [24] 2812 	sjmp	00146$
      0092FB                       2813 00448$:
      0092FB 12 94 77         [24] 2814 	lcall	_ak820_outline_0096
      0092FE BF 07 02         [24] 2815 	cjne	r7,#0x07,00449$
      009301 80 02            [24] 2816 	sjmp	00450$
      009303                       2817 00449$:
      009303 61 A7            [12] 2818 	ajmp	00147$
      009305                       2819 00450$:
      009305                       2820 00146$:
                                   2821 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009305 12 94 2A         [24] 2822 	lcall	_ak820_outline_0000
      009308 12 45 66         [24] 2823 	lcall	_eeprom_read_byte
      00930B 12 94 C8         [24] 2824 	lcall	_ak820_outline_0188
                                   2825 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      00930E 70 02            [24] 2826 	jnz	00451$
      009310 41 0E            [12] 2827 	ajmp	00167$
      009312                       2828 00451$:
                                   2829 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009312 12 94 2A         [24] 2830 	lcall	_ak820_outline_0000
      009315 12 45 66         [24] 2831 	lcall	_eeprom_read_byte
      009318 AF 82            [24] 2832 	mov	r7, dpl
      00931A 90 0B D5         [24] 2833 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0003)
      00931D EF               [12] 2834 	mov	a,r7
      00931E F0               [24] 2835 	movx	@dptr,a
                                   2836 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      00931F EF               [12] 2837 	mov	a,r7
      009320 70 02            [24] 2838 	jnz	00452$
      009322 41 0E            [12] 2839 	ajmp	00167$
      009324                       2840 00452$:
                                   2841 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009324 90 0B D4         [24] 2842 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0002)
      009327 E0               [24] 2843 	movx	a,@dptr
      009328 FF               [12] 2844 	mov	r7,a
      009329 90 0B D5         [24] 2845 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0003)
      00932C E0               [24] 2846 	movx	a,@dptr
      00932D FB               [12] 2847 	mov	r3,a
      00932E E4               [12] 2848 	clr	a
      00932F FC               [12] 2849 	mov	r4,a
      009330 FA               [12] 2850 	mov	r2,a
      009331 EF               [12] 2851 	mov	a,r7
      009332 42 04            [12] 2852 	orl	ar4,a
      009334 EA               [12] 2853 	mov	a,r2
      009335 42 03            [12] 2854 	orl	ar3,a
                                   2855 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      009337 12 48 84         [24] 2856 	lcall	_ak820_outline_0189
      00933A C0 06            [24] 2857 	push	ar6
      00933C C0 05            [24] 2858 	push	ar5
      00933E 31 5A            [12] 2859 	acall	_decode_keycode
      009340 AC 82            [24] 2860 	mov	r4, dpl
      009342 AF 83            [24] 2861 	mov	r7, dph
      009344 D0 05            [24] 2862 	pop	ar5
      009346 D0 06            [24] 2863 	pop	ar6
                                   2864 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      009348 90 0B D3         [24] 2865 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      00934B E0               [24] 2866 	movx	a,@dptr
      00934C FB               [12] 2867 	mov	r3,a
      00934D BB 05 03         [24] 2868 	cjne	r3,#0x05,00453$
      009350 D3               [12] 2869 	setb	c
      009351 80 01            [24] 2870 	sjmp	00454$
      009353                       2871 00453$:
      009353 C3               [12] 2872 	clr	c
      009354                       2873 00454$:
      009354 92 25            [24] 2874 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009356 90 09 E1         [24] 2875 	mov	dptr,#_ak820_macro_primitive
      009359 B3               [12] 2876 	cpl	c
      00935A E4               [12] 2877 	clr	a
      00935B 33               [12] 2878 	rlc	a
      00935C F0               [24] 2879 	movx	@dptr,a
                                   2880 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      00935D 90 0B D3         [24] 2881 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      009360 E0               [24] 2882 	movx	a,@dptr
      009361 FB               [12] 2883 	mov	r3,a
      009362 BB 05 02         [24] 2884 	cjne	r3,#0x05,00455$
      009365 80 0A            [24] 2885 	sjmp	00126$
      009367                       2886 00455$:
      009367 BB 06 02         [24] 2887 	cjne	r3,#0x06,00456$
      00936A 80 16            [24] 2888 	sjmp	00127$
      00936C                       2889 00456$:
                                   2890 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      00936C BB 07 33         [24] 2891 	cjne	r3,#0x07,00129$
      00936F 80 22            [24] 2892 	sjmp	00128$
      009371                       2893 00126$:
                                   2894 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      009371 8C 82            [24] 2895 	mov	dpl, r4
      009373 8F 83            [24] 2896 	mov	dph, r7
      009375 C0 06            [24] 2897 	push	ar6
      009377 C0 05            [24] 2898 	push	ar5
      009379 12 B7 E6         [24] 2899 	lcall	_vial_keycode_tap
      00937C D0 05            [24] 2900 	pop	ar5
      00937E D0 06            [24] 2901 	pop	ar6
                                   2902 ;	quantum/dynamic_keymap.c:795: break;
                                   2903 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      009380 80 20            [24] 2904 	sjmp	00129$
      009382                       2905 00127$:
                                   2906 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      009382 8C 82            [24] 2907 	mov	dpl, r4
      009384 8F 83            [24] 2908 	mov	dph, r7
      009386 C0 06            [24] 2909 	push	ar6
      009388 C0 05            [24] 2910 	push	ar5
      00938A 12 B7 1B         [24] 2911 	lcall	_vial_keycode_down
      00938D D0 05            [24] 2912 	pop	ar5
      00938F D0 06            [24] 2913 	pop	ar6
                                   2914 ;	quantum/dynamic_keymap.c:798: break;
                                   2915 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      009391 80 0F            [24] 2916 	sjmp	00129$
      009393                       2917 00128$:
                                   2918 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      009393 8C 82            [24] 2919 	mov	dpl, r4
      009395 8F 83            [24] 2920 	mov	dph, r7
      009397 C0 06            [24] 2921 	push	ar6
      009399 C0 05            [24] 2922 	push	ar5
      00939B 12 B7 81         [24] 2923 	lcall	_vial_keycode_up
      00939E D0 05            [24] 2924 	pop	ar5
      0093A0 D0 06            [24] 2925 	pop	ar6
                                   2926 ;	quantum/dynamic_keymap.c:802: }
      0093A2                       2927 00129$:
                                   2928 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      0093A2 12 94 B0         [24] 2929 	lcall	_ak820_outline_0173
      0093A5 41 0E            [12] 2930 	ajmp	00167$
      0093A7                       2931 00147$:
                                   2932 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      0093A7 12 94 77         [24] 2933 	lcall	_ak820_outline_0096
      0093AA BF 04 02         [24] 2934 	cjne	r7,#0x04,00458$
      0093AD 80 02            [24] 2935 	sjmp	00459$
      0093AF                       2936 00458$:
      0093AF 41 0E            [12] 2937 	ajmp	00167$
      0093B1                       2938 00459$:
                                   2939 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0093B1 12 94 2A         [24] 2940 	lcall	_ak820_outline_0000
      0093B4 12 45 66         [24] 2941 	lcall	_eeprom_read_byte
      0093B7 AF 82            [24] 2942 	mov	r7, dpl
                                   2943 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0093B9 90 0B D0         [24] 2944 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      0093BC 12 38 61         [24] 2945 	lcall	_ak820_outline_0147
      0093BF 90 0B D0         [24] 2946 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      0093C2 74 01            [12] 2947 	mov	a,#0x01
      0093C4 2B               [12] 2948 	add	a, r3
      0093C5 F0               [24] 2949 	movx	@dptr,a
      0093C6 E4               [12] 2950 	clr	a
      0093C7 3C               [12] 2951 	addc	a, r4
      0093C8 A3               [24] 2952 	inc	dptr
      0093C9 F0               [24] 2953 	movx	@dptr,a
      0093CA 7A 00            [12] 2954 	mov	r2,#0x00
      0093CC 12 33 FC         [24] 2955 	lcall	_ak820_outline_0131
      0093CF 8A F0            [24] 2956 	mov	b, r2
      0093D1 12 45 66         [24] 2957 	lcall	_eeprom_read_byte
      0093D4 AC 82            [24] 2958 	mov	r4, dpl
                                   2959 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      0093D6 EF               [12] 2960 	mov	a,r7
      0093D7 60 49            [24] 2961 	jz	00169$
      0093D9 EC               [12] 2962 	mov	a,r4
      0093DA 60 46            [24] 2963 	jz	00169$
                                   2964 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0093DC 1F               [12] 2965 	dec	r7
      0093DD 1C               [12] 2966 	dec	r4
      0093DE EC               [12] 2967 	mov	a,r4
      0093DF 75 F0 FF         [24] 2968 	mov	b,#0xff
      0093E2 A4               [48] 2969 	mul	ab
      0093E3 FC               [12] 2970 	mov	r4,a
      0093E4 AB F0            [24] 2971 	mov	r3,b
      0093E6 7A 00            [12] 2972 	mov	r2,#0x00
      0093E8 EC               [12] 2973 	mov	a,r4
      0093E9 2F               [12] 2974 	add	a, r7
      0093EA FC               [12] 2975 	mov	r4,a
      0093EB EB               [12] 2976 	mov	a,r3
      0093EC 3A               [12] 2977 	addc	a, r2
      0093ED FB               [12] 2978 	mov	r3,a
                                   2979 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      0093EE                       2980 00141$:
      0093EE 8C 02            [24] 2981 	mov	ar2,r4
      0093F0 8B 07            [24] 2982 	mov	ar7,r3
      0093F2 1C               [12] 2983 	dec	r4
      0093F3 BC FF 01         [24] 2984 	cjne	r4,#0xff,00462$
      0093F6 1B               [12] 2985 	dec	r3
      0093F7                       2986 00462$:
      0093F7 EA               [12] 2987 	mov	a,r2
      0093F8 4F               [12] 2988 	orl	a,r7
      0093F9 70 02            [24] 2989 	jnz	00463$
      0093FB 41 0E            [12] 2990 	ajmp	00167$
      0093FD                       2991 00463$:
      0093FD 90 00 01         [24] 2992 	mov	dptr,#0x0001
      009400 12 5D 62         [24] 2993 	lcall	_mDelaymS
      009403 80 E9            [24] 2994 	sjmp	00141$
      009405                       2995 00164$:
                                   2996 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      009405 90 0B D2         [24] 2997 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009408 E0               [24] 2998 	movx	a,@dptr
      009409 FF               [12] 2999 	mov	r7,a
      00940A BF 80 00         [24] 3000 	cjne	r7,#0x80,00464$
      00940D                       3001 00464$:
      00940D 50 13            [24] 3002 	jnc	00169$
                                   3003 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      00940F 90 0B D2         [24] 3004 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009412 E0               [24] 3005 	movx	a,@dptr
      009413 F5 82            [12] 3006 	mov	dpl,a
      009415 C0 06            [24] 3007 	push	ar6
      009417 C0 05            [24] 3008 	push	ar5
      009419 12 A9 F4         [24] 3009 	lcall	_send_char
      00941C D0 05            [24] 3010 	pop	ar5
      00941E D0 06            [24] 3011 	pop	ar6
                                   3012 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009420 41 0E            [12] 3013 	ajmp	00167$
      009422                       3014 00169$:
                                   3015 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      009422 12 94 B0         [24] 3016 	lcall	_ak820_outline_0173
                                   3017 ;	quantum/dynamic_keymap.c:837: sending = false;
      009425 90 0B CF         [24] 3018 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_477
      009428 F0               [24] 3019 	movx	@dptr,a
                                   3020 ;	quantum/dynamic_keymap.c:839: }
      009429 22               [24] 3021 	ret
                                   3022 	.area CSEG    (CODE)
                                   3023 	.area CONST   (CODE)
                                   3024 	.area XINIT   (CODE)
                                   3025 	.area CABS    (ABS,CODE)
                                   3026 
                                   3027 ; Experimental exact instruction outlining.
                                   3028 	.globl _ak820_outline_0000
                                   3029 	.globl _ak820_outline_0006
                                   3030 	.globl _ak820_outline_0009
                                   3031 	.globl _ak820_outline_0010
                                   3032 	.globl _ak820_outline_0013
                                   3033 	.globl _ak820_outline_0027
                                   3034 	.globl _ak820_outline_0033
                                   3035 	.globl _ak820_outline_0039
                                   3036 	.globl _ak820_outline_0049
                                   3037 	.globl _ak820_outline_0056
                                   3038 	.globl _ak820_outline_0064
                                   3039 	.globl _ak820_outline_0065
                                   3040 	.globl _ak820_outline_0066
                                   3041 	.globl _ak820_outline_0076
                                   3042 	.globl _ak820_outline_0078
                                   3043 	.globl _ak820_outline_0079
                                   3044 	.globl _ak820_outline_0082
                                   3045 	.globl _ak820_outline_0086
                                   3046 	.globl _ak820_outline_0094
                                   3047 	.globl _ak820_outline_0096
                                   3048 	.globl _ak820_outline_0103
                                   3049 	.globl _ak820_outline_0107
                                   3050 	.globl _ak820_outline_0108
                                   3051 	.globl _ak820_outline_0109
                                   3052 	.globl _ak820_outline_0116
                                   3053 	.globl _ak820_outline_0121
                                   3054 	.globl _ak820_outline_0123
                                   3055 	.globl _ak820_outline_0126
                                   3056 	.globl _ak820_outline_0129
                                   3057 	.globl _ak820_outline_0131
                                   3058 	.globl _ak820_outline_0132
                                   3059 	.globl _ak820_outline_0136
                                   3060 	.globl _ak820_outline_0140
                                   3061 	.globl _ak820_outline_0141
                                   3062 	.globl _ak820_outline_0142
                                   3063 	.globl _ak820_outline_0143
                                   3064 	.globl _ak820_outline_0144
                                   3065 	.globl _ak820_outline_0147
                                   3066 	.globl _ak820_outline_0148
                                   3067 	.globl _ak820_outline_0149
                                   3068 	.globl _ak820_outline_0155
                                   3069 	.globl _ak820_outline_0156
                                   3070 	.globl _ak820_outline_0158
                                   3071 	.globl _ak820_outline_0162
                                   3072 	.globl _ak820_outline_0163
                                   3073 	.globl _ak820_outline_0166
                                   3074 	.globl _ak820_outline_0168
                                   3075 	.globl _ak820_outline_0173
                                   3076 	.globl _ak820_outline_0184
                                   3077 	.globl _ak820_outline_0185
                                   3078 	.globl _ak820_outline_0188
                                   3079 	.globl _ak820_outline_0189
                                   3080 	.globl _ak820_outline_0194
                                   3081 
                                   3082 	.area CSEG (CODE)
                                   3083 ; function ak820_outline_0000
      00942A                       3084 _ak820_outline_0000:
      00942A 90 0B D0         [24] 3085 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      00942D E0               [24] 3086 	movx	a,@dptr
      00942E FC               [12] 3087 	mov	r4,a
      00942F A3               [24] 3088 	inc	dptr
      009430 E0               [24] 3089 	movx	a,@dptr
      009431 FF               [12] 3090 	mov	r7,a
      009432 90 0B D0         [24] 3091 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      009435 74 01            [12] 3092 	mov	a,#0x01
      009437 2C               [12] 3093 	add	a,r4
      009438 F0               [24] 3094 	movx	@dptr,a
      009439 E4               [12] 3095 	clr	a
      00943A 3F               [12] 3096 	addc	a,r7
      00943B A3               [24] 3097 	inc	dptr
      00943C F0               [24] 3098 	movx	@dptr,a
      00943D 7B 00            [12] 3099 	mov	r3,#0x00
      00943F 8C 82            [24] 3100 	mov	dpl,r4
      009441 8F 83            [24] 3101 	mov	dph,r7
      009443 8B F0            [24] 3102 	mov	b,r3
      009445 22               [24] 3103 	ret
                                   3104 
                                   3105 	.area CSEG (CODE)
                                   3106 ; function ak820_outline_0027
      009446                       3107 _ak820_outline_0027:
      009446 2D               [12] 3108 	add	a,r5
      009447 F9               [12] 3109 	mov	r1,a
      009448 E4               [12] 3110 	clr	a
      009449 3E               [12] 3111 	addc	a,r6
      00944A FA               [12] 3112 	mov	r2,a
      00944B 8F 03            [24] 3113 	mov	ar3,r7
      00944D 89 82            [24] 3114 	mov	dpl,r1
      00944F 8A 83            [24] 3115 	mov	dph,r2
      009451 8B F0            [24] 3116 	mov	b,r3
      009453 22               [24] 3117 	ret
                                   3118 
                                   3119 	.area CSEG (CODE)
                                   3120 ; function ak820_outline_0039
      009454                       3121 _ak820_outline_0039:
      009454 90 0E 29         [24] 3122 	mov	dptr,#_memset_PARM_2
      009457 E4               [12] 3123 	clr	a
      009458 F0               [24] 3124 	movx	@dptr,a
      009459 90 0E 2A         [24] 3125 	mov	dptr,#_memset_PARM_3
      00945C 74 0A            [12] 3126 	mov	a,#0x0a
      00945E F0               [24] 3127 	movx	@dptr,a
      00945F E4               [12] 3128 	clr	a
      009460 A3               [24] 3129 	inc	dptr
      009461 F0               [24] 3130 	movx	@dptr,a
      009462 8E 82            [24] 3131 	mov	dpl,r6
      009464 8F 83            [24] 3132 	mov	dph,r7
      009466 8D F0            [24] 3133 	mov	b,r5
      009468 22               [24] 3134 	ret
                                   3135 
                                   3136 	.area CSEG (CODE)
                                   3137 ; function ak820_outline_0082
      009469                       3138 _ak820_outline_0082:
      009469 ED               [12] 3139 	mov	a,r5
      00946A 75 F0 0A         [24] 3140 	mov	b,#0x0a
      00946D A4               [48] 3141 	mul	ab
      00946E 24 58            [12] 3142 	add	a,#0x58
      009470 FC               [12] 3143 	mov	r4,a
      009471 74 06            [12] 3144 	mov	a,#0x06
      009473 35 F0            [12] 3145 	addc	a,b
      009475 FD               [12] 3146 	mov	r5,a
      009476 22               [24] 3147 	ret
                                   3148 
                                   3149 	.area CSEG (CODE)
                                   3150 ; function ak820_outline_0096
      009477                       3151 _ak820_outline_0096:
      009477 90 0B D3         [24] 3152 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489+0x0001)
      00947A E0               [24] 3153 	movx	a,@dptr
      00947B FF               [12] 3154 	mov	r7,a
      00947C 22               [24] 3155 	ret
                                   3156 
                                   3157 	.area CSEG (CODE)
                                   3158 ; function ak820_outline_0103
      00947D                       3159 _ak820_outline_0103:
      00947D 90 0B 57         [24] 3160 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      009480 EE               [12] 3161 	mov	a,r6
      009481 F0               [24] 3162 	movx	@dptr,a
      009482 90 0B 58         [24] 3163 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009485 ED               [12] 3164 	mov	a,r5
      009486 F0               [24] 3165 	movx	@dptr,a
      009487 8F 82            [24] 3166 	mov	dpl,r7
      009489 22               [24] 3167 	ret
                                   3168 
                                   3169 	.area CSEG (CODE)
                                   3170 ; function ak820_outline_0116
      00948A                       3171 _ak820_outline_0116:
      00948A 74 0A            [12] 3172 	mov	a,#0x0a
      00948C F0               [24] 3173 	movx	@dptr,a
      00948D E4               [12] 3174 	clr	a
      00948E A3               [24] 3175 	inc	dptr
      00948F F0               [24] 3176 	movx	@dptr,a
      009490 22               [24] 3177 	ret
                                   3178 
                                   3179 	.area CSEG (CODE)
                                   3180 ; function ak820_outline_0121
      009491                       3181 _ak820_outline_0121:
      009491 AD 82            [24] 3182 	mov	r5,dpl
      009493 AE 83            [24] 3183 	mov	r6,dph
      009495 AF F0            [24] 3184 	mov	r7,b
      009497 22               [24] 3185 	ret
                                   3186 
                                   3187 	.area CSEG (CODE)
                                   3188 ; function ak820_outline_0136
      009498                       3189 _ak820_outline_0136:
      009498 28               [12] 3190 	add	a,r0
      009499 F5 82            [12] 3191 	mov	dpl,a
      00949B EF               [12] 3192 	mov	a,r7
      00949C 39               [12] 3193 	addc	a,r1
      00949D F5 83            [12] 3194 	mov	dph,a
      00949F 74 FF            [12] 3195 	mov	a,#0xff
      0094A1 F0               [24] 3196 	movx	@dptr,a
      0094A2 22               [24] 3197 	ret
                                   3198 
                                   3199 	.area CSEG (CODE)
                                   3200 ; function ak820_outline_0142
      0094A3                       3201 _ak820_outline_0142:
      0094A3 2D               [12] 3202 	add	a,r5
      0094A4 F9               [12] 3203 	mov	r1,a
      0094A5 E4               [12] 3204 	clr	a
      0094A6 3E               [12] 3205 	addc	a,r6
      0094A7 FA               [12] 3206 	mov	r2,a
      0094A8 22               [24] 3207 	ret
                                   3208 
                                   3209 	.area CSEG (CODE)
                                   3210 ; function ak820_outline_0158
      0094A9                       3211 _ak820_outline_0158:
      0094A9 90 0B D4         [24] 3212 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489+0x0002)
      0094AC E0               [24] 3213 	movx	a,@dptr
      0094AD F5 82            [12] 3214 	mov	dpl,a
      0094AF 22               [24] 3215 	ret
                                   3216 
                                   3217 	.area CSEG (CODE)
                                   3218 ; function ak820_outline_0173
      0094B0                       3219 _ak820_outline_0173:
      0094B0 90 09 E1         [24] 3220 	mov	dptr,#_ak820_macro_primitive
      0094B3 E4               [12] 3221 	clr	a
      0094B4 F0               [24] 3222 	movx	@dptr,a
      0094B5 22               [24] 3223 	ret
                                   3224 
                                   3225 	.area CSEG (CODE)
                                   3226 ; function ak820_outline_0184
      0094B6                       3227 _ak820_outline_0184:
      0094B6 90 0B 67         [24] 3228 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0094B9 E4               [12] 3229 	clr	a
      0094BA F0               [24] 3230 	movx	@dptr,a
      0094BB 90 0B 68         [24] 3231 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0094BE 22               [24] 3232 	ret
                                   3233 
                                   3234 	.area CSEG (CODE)
                                   3235 ; function ak820_outline_0185
      0094BF                       3236 _ak820_outline_0185:
      0094BF 90 0C 2F         [24] 3237 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0094C2 E4               [12] 3238 	clr	a
      0094C3 F0               [24] 3239 	movx	@dptr,a
      0094C4 90 0C 30         [24] 3240 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0094C7 22               [24] 3241 	ret
                                   3242 
                                   3243 	.area CSEG (CODE)
                                   3244 ; function ak820_outline_0188
      0094C8                       3245 _ak820_outline_0188:
      0094C8 AF 82            [24] 3246 	mov	r7,dpl
      0094CA 90 0B D4         [24] 3247 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489+0x0002)
      0094CD EF               [12] 3248 	mov	a,r7
      0094CE F0               [24] 3249 	movx	@dptr,a
      0094CF EF               [12] 3250 	mov	a,r7
      0094D0 22               [24] 3251 	ret
