                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      00003C                        553 _raw_hid_receive_sloc0_1_0:
      00003C                        554 	.ds 4
      000040                        555 _raw_hid_receive_sloc1_1_0:
      000040                        556 	.ds 1
      000041                        557 _raw_hid_receive_sloc2_1_0:
      000041                        558 	.ds 1
      000042                        559 _raw_hid_receive_sloc3_1_0:
      000042                        560 	.ds 2
      000044                        561 _raw_hid_receive_sloc4_1_0:
      000044                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002A                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002A                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000CB1                        589 _via_eeprom_set_valid_valid_10000_611:
      000CB1                        590 	.ds 1
      000CB2                        591 _via_set_layout_options_value_10000_627:
      000CB2                        592 	.ds 4
      000CB6                        593 _process_record_via_PARM_2:
      000CB6                        594 	.ds 3
      000CB9                        595 _process_record_via_keycode_10000_629:
      000CB9                        596 	.ds 2
      000CBB                        597 _raw_hid_receive_kb_PARM_2:
      000CBB                        598 	.ds 1
      000CBC                        599 _raw_hid_receive_kb_data_10000_635:
      000CBC                        600 	.ds 3
      000CBF                        601 _raw_hid_receive_PARM_2:
      000CBF                        602 	.ds 1
      000CC0                        603 _raw_hid_receive_packet_10000_637:
      000CC0                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00AAB6                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00AAB6 90 00 25         [24]  658 	mov	dptr,#0x0025
      00AAB9 75 F0 00         [24]  659 	mov	b, #0x00
      00AABC 12 45 66         [24]  660 	lcall	_eeprom_read_byte
      00AABF AF 82            [24]  661 	mov	r7, dpl
      00AAC1 BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00AAC4 90 00 26         [24]  663 	mov	dptr,#0x0026
      00AAC7 75 F0 00         [24]  664 	mov	b, #0x00
      00AACA 12 45 66         [24]  665 	lcall	_eeprom_read_byte
      00AACD AF 82            [24]  666 	mov	r7, dpl
      00AACF BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00AAD2 90 00 27         [24]  668 	mov	dptr,#0x0027
      00AAD5 75 F0 00         [24]  669 	mov	b, #0x00
      00AAD8 12 45 66         [24]  670 	lcall	_eeprom_read_byte
      00AADB AF 82            [24]  671 	mov	r7, dpl
      00AADD BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00AAE0 80 04            [24]  673 	sjmp	00104$
      00AAE2                        674 00126$:
      00AAE2                        675 00103$:
                                    676 ;	assignBit
      00AAE2 C2 2A            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00AAE4 80 02            [24]  678 	sjmp	00105$
      00AAE6                        679 00104$:
                                    680 ;	assignBit
      00AAE6 D2 2A            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00AAE8                        682 00105$:
      00AAE8 A2 2A            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00AAEA 12 38 67         [24]  684 	lcall	_ak820_outline_0150
                                    685 ;	quantum/via.c:104: }
      00AAED 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_611'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_612'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_612'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_612'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00AAEE                        699 _via_eeprom_set_valid:
      00AAEE E5 82            [12]  700 	mov	a,dpl
      00AAF0 90 0C B1         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AAF3 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00AAF4 E0               [24]  704 	movx	a,@dptr
      00AAF5 60 04            [24]  705 	jz	00103$
      00AAF7 7F 03            [12]  706 	mov	r7,#0x03
      00AAF9 80 02            [24]  707 	sjmp	00104$
      00AAFB                        708 00103$:
      00AAFB 7F FF            [12]  709 	mov	r7,#0xff
      00AAFD                        710 00104$:
      00AAFD 90 06 FC         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB00 EF               [12]  712 	mov	a,r7
      00AB01 F0               [24]  713 	movx	@dptr,a
      00AB02 90 00 25         [24]  714 	mov	dptr,#0x0025
      00AB05 75 F0 00         [24]  715 	mov	b, #0x00
      00AB08 12 52 9A         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00AB0B 90 0C B1         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AB0E E0               [24]  719 	movx	a,@dptr
      00AB0F 60 04            [24]  720 	jz	00105$
      00AB11 7F 20            [12]  721 	mov	r7,#0x20
      00AB13 80 02            [24]  722 	sjmp	00106$
      00AB15                        723 00105$:
      00AB15 7F FF            [12]  724 	mov	r7,#0xff
      00AB17                        725 00106$:
      00AB17 90 06 FC         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB1A EF               [12]  727 	mov	a,r7
      00AB1B F0               [24]  728 	movx	@dptr,a
      00AB1C 90 00 26         [24]  729 	mov	dptr,#0x0026
      00AB1F 75 F0 00         [24]  730 	mov	b, #0x00
      00AB22 12 52 9A         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00AB25 90 0C B1         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AB28 E0               [24]  734 	movx	a,@dptr
      00AB29 60 04            [24]  735 	jz	00107$
      00AB2B 7F 08            [12]  736 	mov	r7,#0x08
      00AB2D 80 02            [24]  737 	sjmp	00108$
      00AB2F                        738 00107$:
      00AB2F 7F FF            [12]  739 	mov	r7,#0xff
      00AB31                        740 00108$:
      00AB31 90 06 FC         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB34 EF               [12]  742 	mov	a,r7
      00AB35 F0               [24]  743 	movx	@dptr,a
      00AB36 90 00 27         [24]  744 	mov	dptr,#0x0027
      00AB39 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00AB3C 02 52 9A         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00AB3F                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00AB3F 71 62            [12]  757 	acall	_via_get_layout_options
      00AB41 71 7A            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00AB43 51 B6            [12]  760 	acall	_via_eeprom_is_valid
      00AB45 E5 82            [12]  761 	mov	a, dpl
      00AB47 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00AB49 02 43 15         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00AB4C                        766 00103$:
      00AB4C 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00AB4D                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00AB4D 75 82 00         [24]  777 	mov	dpl, #0x00
      00AB50 51 EE            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00AB52 12 96 6C         [24]  780 	lcall	_ak820_outline_0159
      00AB55 71 7B            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00AB57 12 8C AC         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00AB5A 12 91 57         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00AB5D 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00AB60 41 EE            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00AB62                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00AB62 90 00 28         [24]  799 	mov	dptr,#0x0028
      00AB65 75 F0 00         [24]  800 	mov	b, #0x00
      00AB68 12 45 66         [24]  801 	lcall	_eeprom_read_byte
      00AB6B AF 82            [24]  802 	mov	r7, dpl
      00AB6D 7E 00            [12]  803 	mov	r6,#0x00
      00AB6F 7D 00            [12]  804 	mov	r5,#0x00
      00AB71 7C 00            [12]  805 	mov	r4,#0x00
      00AB73 12 48 73         [24]  806 	lcall	_ak820_outline_0164
      00AB76 8D F0            [24]  807 	mov	b, r5
      00AB78 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00AB79 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_624'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00AB7A                        820 _via_set_layout_options_kb:
      00AB7A 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_627'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00AB7B                        831 _via_set_layout_options:
      00AB7B 12 96 64         [24]  832 	lcall	_ak820_outline_0125
      00AB7E 90 0C B2         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_627
      00AB81 12 96 52         [24]  834 	lcall	_ak820_outline_0046
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00AB84 90 0C B2         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_627
      00AB87 E0               [24]  837 	movx	a,@dptr
      00AB88 90 06 FC         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB8B F0               [24]  839 	movx	@dptr,a
      00AB8C 90 00 28         [24]  840 	mov	dptr,#0x0028
      00AB8F 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00AB92 02 52 9A         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_629'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_634'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00AB95                        855 _process_record_via:
      00AB95 12 38 42         [24]  856 	lcall	_ak820_outline_0108
      00AB98 90 0C B9         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_629
      00AB9B 12 38 47         [24]  858 	lcall	_ak820_outline_0109
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00AB9E 90 0C B6         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00ABA1 12 53 A9         [24]  861 	lcall	_ak820_outline_0023
      00ABA4 74 05            [12]  862 	mov	a,#0x05
      00ABA6 12 38 71         [24]  863 	lcall	_ak820_outline_0166
      00ABA9 12 53 B2         [24]  864 	lcall	_ak820_outline_0049
      00ABAC 12 BE B3         [24]  865 	lcall	__gptrget
      00ABAF 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00ABB1 90 0C B9         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_629
      00ABB4 12 37 C4         [24]  869 	lcall	_ak820_outline_0010
      00ABB7 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00ABB9 2D               [12]  871 	add	a,r5
      00ABBA 50 12            [24]  872 	jnc	00105$
      00ABBC C3               [12]  873 	clr	c
      00ABBD 74 7F            [12]  874 	mov	a,#0x7f
      00ABBF 9C               [12]  875 	subb	a,r4
      00ABC0 74 77            [12]  876 	mov	a,#0x77
      00ABC2 9D               [12]  877 	subb	a,r5
      00ABC3 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00ABC5 8E 82            [24]  882 	mov	dpl, r6
      00ABC7 12 91 7D         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00ABCA 75 82 00         [24]  885 	mov	dpl, #0x00
      00ABCD 22               [24]  886 	ret
      00ABCE                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00ABCE 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00ABD1 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_635'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_636'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00ABD2                        903 _raw_hid_receive_kb:
      00ABD2 12 48 05         [24]  904 	lcall	_ak820_outline_0040
      00ABD5 90 0C BC         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00ABD8 12 37 E1         [24]  906 	lcall	_ak820_outline_0019
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00ABDB 90 0C BC         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00ABDE 12 53 9A         [24]  909 	lcall	_ak820_outline_0005
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00ABE1 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00ABE3 02 BE 78         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_637'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_638'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_638'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_638'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_644'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_652'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_653'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_656'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_657'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_658'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_663'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_665'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_674'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_675'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_675'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_680'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_680'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_687'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_687'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_692'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00ABE6                        950 _raw_hid_receive:
      00ABE6 12 48 05         [24]  951 	lcall	_ak820_outline_0040
      00ABE9 90 0C C0         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00ABEC 12 37 E1         [24]  953 	lcall	_ak820_outline_0019
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00ABEF 90 0C C0         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00ABF2 12 37 F9         [24]  956 	lcall	_ak820_outline_0056
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00ABF5 74 01            [12]  958 	mov	a,#0x01
      00ABF7 12 48 78         [24]  959 	lcall	_ak820_outline_0167
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00ABFA 90 0C BF         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00ABFD E0               [24]  962 	movx	a,@dptr
      00ABFE FB               [12]  963 	mov	r3,a
      00ABFF BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00AC02 80 01            [24]  965 	sjmp	00102$
      00AC04                        966 00520$:
      00AC04 22               [24]  967 	ret
      00AC05                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AC05 90 0E A5         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00AC08 E0               [24]  971 	movx	a,@dptr
      00AC09 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AC0B 12 38 30         [24]  974 	lcall	_ak820_outline_0098
      00AC0E FA               [12]  975 	mov	r2,a
      00AC0F BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00AC12 80 01            [24]  977 	sjmp	00104$
      00AC14                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00AC14 22               [24]  980 	ret
      00AC15                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AC15 12 40 46         [24]  983 	lcall	_ak820_outline_0081
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AC18 FA               [12]  985 	mov	r2,a
      00AC19 60 21            [24]  986 	jz	00114$
      00AC1B BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00AC1E 80 1C            [24]  988 	sjmp	00114$
      00AC20                        989 00524$:
      00AC20 BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00AC23 80 17            [24]  991 	sjmp	00114$
      00AC25                        992 00525$:
      00AC25 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00AC28 80 12            [24]  994 	sjmp	00114$
      00AC2A                        995 00526$:
      00AC2A BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00AC2D 80 0D            [24]  997 	sjmp	00114$
      00AC2F                        998 00527$:
      00AC2F BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00AC32 80 08            [24] 1000 	sjmp	00114$
      00AC34                       1001 00528$:
      00AC34 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00AC37 80 03            [24] 1003 	sjmp	00530$
      00AC39                       1004 00529$:
      00AC39 02 B1 5A         [24] 1005 	ljmp	00171$
      00AC3C                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00AC3C                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00AC3C 12 38 30         [24] 1010 	lcall	_ak820_outline_0098
      00AC3F FA               [12] 1011 	mov	r2,a
      00AC40 BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00AC43 80 66            [24] 1013 	sjmp	00115$
      00AC45                       1014 00531$:
      00AC45 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00AC48 80 6E            [24] 1016 	sjmp	00116$
      00AC4A                       1017 00532$:
      00AC4A BA 03 02         [24] 1018 	cjne	r2,#0x03,00533$
      00AC4D A1 76            [24] 1019 	ajmp	00125$
      00AC4F                       1020 00533$:
      00AC4F BA 04 02         [24] 1021 	cjne	r2,#0x04,00534$
      00AC52 C1 09            [12] 1022 	ajmp	00129$
      00AC54                       1023 00534$:
      00AC54 BA 05 02         [24] 1024 	cjne	r2,#0x05,00535$
      00AC57 C1 46            [12] 1025 	ajmp	00130$
      00AC59                       1026 00535$:
      00AC59 BA 06 02         [24] 1027 	cjne	r2,#0x06,00536$
      00AC5C C1 B1            [12] 1028 	ajmp	00135$
      00AC5E                       1029 00536$:
      00AC5E BA 07 02         [24] 1030 	cjne	r2,#0x07,00537$
      00AC61 C1 C3            [12] 1031 	ajmp	00136$
      00AC63                       1032 00537$:
      00AC63 BA 08 02         [24] 1033 	cjne	r2,#0x08,00538$
      00AC66 C1 DE            [12] 1034 	ajmp	00137$
      00AC68                       1035 00538$:
      00AC68 BA 09 02         [24] 1036 	cjne	r2,#0x09,00539$
      00AC6B C1 F9            [12] 1037 	ajmp	00138$
      00AC6D                       1038 00539$:
      00AC6D BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00AC70 02 B0 EA         [24] 1040 	ljmp	00161$
      00AC73                       1041 00540$:
      00AC73 BA 0C 02         [24] 1042 	cjne	r2,#0x0c,00541$
      00AC76 E1 14            [12] 1043 	ajmp	00139$
      00AC78                       1044 00541$:
      00AC78 BA 0D 03         [24] 1045 	cjne	r2,#0x0d,00542$
      00AC7B 02 AF 35         [24] 1046 	ljmp	00140$
      00AC7E                       1047 00542$:
      00AC7E BA 0E 03         [24] 1048 	cjne	r2,#0x0e,00543$
      00AC81 02 AF 5E         [24] 1049 	ljmp	00141$
      00AC84                       1050 00543$:
      00AC84 BA 0F 03         [24] 1051 	cjne	r2,#0x0f,00544$
      00AC87 02 AF A6         [24] 1052 	ljmp	00144$
      00AC8A                       1053 00544$:
      00AC8A BA 10 03         [24] 1054 	cjne	r2,#0x10,00545$
      00AC8D 02 B0 14         [24] 1055 	ljmp	00151$
      00AC90                       1056 00545$:
      00AC90 BA 11 03         [24] 1057 	cjne	r2,#0x11,00546$
      00AC93 02 B0 2C         [24] 1058 	ljmp	00154$
      00AC96                       1059 00546$:
      00AC96 BA 12 03         [24] 1060 	cjne	r2,#0x12,00547$
      00AC99 02 B0 4C         [24] 1061 	ljmp	00155$
      00AC9C                       1062 00547$:
      00AC9C BA 13 03         [24] 1063 	cjne	r2,#0x13,00548$
      00AC9F 02 B0 92         [24] 1064 	ljmp	00158$
      00ACA2                       1065 00548$:
      00ACA2 BA FE 03         [24] 1066 	cjne	r2,#0xfe,00549$
      00ACA5 02 B1 29         [24] 1067 	ljmp	00168$
      00ACA8                       1068 00549$:
      00ACA8 02 B1 42         [24] 1069 	ljmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00ACAB                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00ACAB 12 38 4C         [24] 1073 	lcall	_ak820_outline_0126
      00ACAE E4               [12] 1074 	clr	a
      00ACAF 12 47 FD         [24] 1075 	lcall	_ak820_outline_0025
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00ACB2 74 09            [12] 1077 	mov	a,#0x09
      00ACB4 F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00ACB5 02 B1 5A         [24] 1080 	ljmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00ACB8                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00ACB8 12 40 46         [24] 1084 	lcall	_ak820_outline_0081
      00ACBB FA               [12] 1085 	mov	r2,a
      00ACBC BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00ACBF 80 0C            [24] 1087 	sjmp	00117$
      00ACC1                       1088 00550$:
      00ACC1 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00ACC4 80 32            [24] 1090 	sjmp	00118$
      00ACC6                       1091 00551$:
      00ACC6 BA 03 02         [24] 1092 	cjne	r2,#0x03,00552$
      00ACC9 A1 32            [24] 1093 	ajmp	00119$
      00ACCB                       1094 00552$:
      00ACCB A1 5C            [24] 1095 	ajmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00ACCD                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00ACCD 12 4D C2         [24] 1099 	lcall	_timer_read32
      00ACD0 85 82 3C         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00ACD3 85 83 3D         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00ACD6 85 F0 3E         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00ACD9 F5 3F            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00ACDB 12 38 36         [24] 1105 	lcall	_ak820_outline_0105
      00ACDE A3               [24] 1106 	inc	dptr
      00ACDF E5 3F            [12] 1107 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00ACE1 12 47 FD         [24] 1108 	lcall	_ak820_outline_0025
                                   1109 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00ACE4 A3               [24] 1110 	inc	dptr
      00ACE5 E5 3E            [12] 1111 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00ACE7 12 47 FD         [24] 1112 	lcall	_ak820_outline_0025
                                   1113 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00ACEA A3               [24] 1114 	inc	dptr
      00ACEB A3               [24] 1115 	inc	dptr
      00ACEC E5 3D            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00ACEE F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00ACEF 12 47 F3         [24] 1119 	lcall	_ak820_outline_0012
      00ACF2 E5 3C            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00ACF4 F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00ACF5 02 B1 5A         [24] 1123 	ljmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00ACF8                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00ACF8 C0 03            [24] 1127 	push	ar3
      00ACFA C0 07            [24] 1128 	push	ar7
      00ACFC C0 06            [24] 1129 	push	ar6
      00ACFE C0 03            [24] 1130 	push	ar3
      00AD00 71 62            [12] 1131 	acall	_via_get_layout_options
      00AD02 85 82 3C         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AD05 85 83 3D         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AD08 85 F0 3E         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AD0B F5 3F            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AD0D D0 03            [24] 1136 	pop	ar3
      00AD0F D0 06            [24] 1137 	pop	ar6
      00AD11 D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AD13 12 38 36         [24] 1140 	lcall	_ak820_outline_0105
      00AD16 A3               [24] 1141 	inc	dptr
      00AD17 E5 3F            [12] 1142 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AD19 12 47 FD         [24] 1143 	lcall	_ak820_outline_0025
                                   1144 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00AD1C A3               [24] 1145 	inc	dptr
      00AD1D E5 3E            [12] 1146 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AD1F 12 47 FD         [24] 1147 	lcall	_ak820_outline_0025
                                   1148 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00AD22 A3               [24] 1149 	inc	dptr
      00AD23 A3               [24] 1150 	inc	dptr
      00AD24 E5 3D            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD26 F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AD27 12 47 F3         [24] 1154 	lcall	_ak820_outline_0012
      00AD2A E5 3C            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD2C F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00AD2D D0 03            [24] 1158 	pop	ar3
      00AD2F 02 B1 5A         [24] 1159 	ljmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AD32                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00AD32 90 0E A4         [24] 1163 	mov	dptr,#_vial_unlocked
      00AD35 E0               [24] 1164 	movx	a,@dptr
      00AD36 70 03            [24] 1165 	jnz	00553$
      00AD38 02 B1 5A         [24] 1166 	ljmp	00171$
      00AD3B                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AD3B 7A 01            [12] 1169 	mov	r2,#0x01
      00AD3D 79 00            [12] 1170 	mov	r1,#0x00
      00AD3F                       1171 00173$:
      00AD3F B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00AD42                       1173 00554$:
      00AD42 40 03            [24] 1174 	jc	00555$
      00AD44 02 B1 5A         [24] 1175 	ljmp	00171$
      00AD47                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AD47 89 82            [24] 1178 	mov	dpl, r1
      00AD49 12 5E 23         [24] 1179 	lcall	_matrix_get_row
      00AD4C A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AD4E EA               [12] 1182 	mov	a,r2
      00AD4F 2C               [12] 1183 	add	a, r4
      00AD50 F5 82            [12] 1184 	mov	dpl,a
      00AD52 E4               [12] 1185 	clr	a
      00AD53 3D               [12] 1186 	addc	a, r5
      00AD54 F5 83            [12] 1187 	mov	dph,a
      00AD56 0A               [12] 1188 	inc	r2
      00AD57 E8               [12] 1189 	mov	a,r0
      00AD58 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AD59 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00AD5A 80 E3            [24] 1194 	sjmp	00173$
      00AD5C                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00AD5C 12 B1 A4         [24] 1197 	lcall	_ak820_outline_0097
      00AD5F 90 0C BB         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AD62 12 B1 7F         [24] 1199 	lcall	_ak820_outline_0043
      00AD65 C0 07            [24] 1200 	push	ar7
      00AD67 C0 06            [24] 1201 	push	ar6
      00AD69 C0 03            [24] 1202 	push	ar3
      00AD6B 71 D2            [24] 1203 	acall	_raw_hid_receive_kb
      00AD6D D0 03            [24] 1204 	pop	ar3
      00AD6F D0 06            [24] 1205 	pop	ar6
      00AD71 D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00AD73 02 B1 5A         [24] 1208 	ljmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00AD76                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00AD76 12 40 46         [24] 1212 	lcall	_ak820_outline_0081
      00AD79 FA               [12] 1213 	mov	r2,a
      00AD7A BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00AD7D 80 02            [24] 1215 	sjmp	00557$
      00AD7F                       1216 00556$:
      00AD7F A1 EF            [12] 1217 	ajmp	00127$
      00AD81                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00AD81 C0 03            [24] 1220 	push	ar3
      00AD83 12 37 E9         [24] 1221 	lcall	_ak820_outline_0032
      00AD86 F8               [12] 1222 	mov	r0,a
      00AD87 79 00            [12] 1223 	mov	r1,#0x00
      00AD89 7B 00            [12] 1224 	mov	r3,#0x00
      00AD8B 88 3F            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00AD8D 8B 3C            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00AD8F 8B 3D            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00AD91 8B 3E            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00AD93 12 40 06         [24] 1229 	lcall	_ak820_outline_0015
      00AD96 F8               [12] 1230 	mov	r0,a
      00AD97 89 03            [24] 1231 	mov	ar3,r1
      00AD99 88 02            [24] 1232 	mov	ar2,r0
      00AD9B E4               [12] 1233 	clr	a
      00AD9C 42 3C            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00AD9E E9               [12] 1235 	mov	a,r1
      00AD9F 42 3D            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00ADA1 EA               [12] 1237 	mov	a,r2
      00ADA2 42 3E            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ADA4 EB               [12] 1239 	mov	a,r3
      00ADA5 42 3F            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ADA7 12 40 1C         [24] 1241 	lcall	_ak820_outline_0017
      00ADAA F8               [12] 1242 	mov	r0,a
      00ADAB 79 00            [12] 1243 	mov	r1,#0x00
      00ADAD 7A 00            [12] 1244 	mov	r2,#0x00
      00ADAF 8A 03            [24] 1245 	mov	ar3,r2
      00ADB1 89 02            [24] 1246 	mov	ar2,r1
      00ADB3 88 01            [24] 1247 	mov	ar1,r0
      00ADB5 E4               [12] 1248 	clr	a
      00ADB6 42 3C            [12] 1249 	orl	_raw_hid_receive_sloc0_1_0,a
      00ADB8 E9               [12] 1250 	mov	a,r1
      00ADB9 42 3D            [12] 1251 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00ADBB EA               [12] 1252 	mov	a,r2
      00ADBC 42 3E            [12] 1253 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ADBE EB               [12] 1254 	mov	a,r3
      00ADBF 42 3F            [12] 1255 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ADC1 12 47 F3         [24] 1256 	lcall	_ak820_outline_0012
      00ADC4 E0               [24] 1257 	movx	a,@dptr
      00ADC5 F8               [12] 1258 	mov	r0,a
      00ADC6 E4               [12] 1259 	clr	a
      00ADC7 F9               [12] 1260 	mov	r1,a
      00ADC8 FA               [12] 1261 	mov	r2,a
      00ADC9 FB               [12] 1262 	mov	r3,a
      00ADCA E5 3D            [12] 1263 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00ADCC 42 01            [12] 1264 	orl	ar1,a
      00ADCE E5 3E            [12] 1265 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00ADD0 42 02            [12] 1266 	orl	ar2,a
      00ADD2 E5 3F            [12] 1267 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00ADD4 42 03            [12] 1268 	orl	ar3,a
                                   1269 ;	quantum/via.c:323: via_set_layout_options(value);
      00ADD6 12 38 6C         [24] 1270 	lcall	_ak820_outline_0162
      00ADD9 8A F0            [24] 1271 	mov	b, r2
      00ADDB EB               [12] 1272 	mov	a, r3
      00ADDC C0 07            [24] 1273 	push	ar7
      00ADDE C0 06            [24] 1274 	push	ar6
      00ADE0 C0 03            [24] 1275 	push	ar3
      00ADE2 71 7B            [12] 1276 	acall	_via_set_layout_options
      00ADE4 D0 03            [24] 1277 	pop	ar3
      00ADE6 D0 06            [24] 1278 	pop	ar6
      00ADE8 D0 07            [24] 1279 	pop	ar7
                                   1280 ;	quantum/via.c:324: break;
      00ADEA D0 03            [24] 1281 	pop	ar3
      00ADEC 02 B1 5A         [24] 1282 	ljmp	00171$
                                   1283 ;	quantum/via.c:326: default: {
      00ADEF                       1284 00127$:
                                   1285 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00ADEF 12 B1 A4         [24] 1286 	lcall	_ak820_outline_0097
      00ADF2 90 0C BB         [24] 1287 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00ADF5 12 B1 7F         [24] 1288 	lcall	_ak820_outline_0043
      00ADF8 C0 07            [24] 1289 	push	ar7
      00ADFA C0 06            [24] 1290 	push	ar6
      00ADFC C0 03            [24] 1291 	push	ar3
      00ADFE 71 D2            [24] 1292 	acall	_raw_hid_receive_kb
      00AE00 D0 03            [24] 1293 	pop	ar3
      00AE02 D0 06            [24] 1294 	pop	ar6
      00AE04 D0 07            [24] 1295 	pop	ar7
                                   1296 ;	quantum/via.c:331: break;
      00AE06 02 B1 5A         [24] 1297 	ljmp	00171$
                                   1298 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AE09                       1299 00129$:
                                   1300 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AE09 12 40 46         [24] 1301 	lcall	_ak820_outline_0081
      00AE0C FA               [12] 1302 	mov	r2,a
      00AE0D 12 37 E9         [24] 1303 	lcall	_ak820_outline_0032
      00AE10 F9               [12] 1304 	mov	r1,a
      00AE11 12 40 06         [24] 1305 	lcall	_ak820_outline_0015
      00AE14 F8               [12] 1306 	mov	r0,a
      00AE15 90 0B 5A         [24] 1307 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AE18 E9               [12] 1308 	mov	a,r1
      00AE19 F0               [24] 1309 	movx	@dptr,a
      00AE1A 90 0B 5B         [24] 1310 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AE1D E8               [12] 1311 	mov	a,r0
      00AE1E F0               [24] 1312 	movx	@dptr,a
      00AE1F 8A 82            [24] 1313 	mov	dpl, r2
      00AE21 C0 07            [24] 1314 	push	ar7
      00AE23 C0 06            [24] 1315 	push	ar6
      00AE25 C0 03            [24] 1316 	push	ar3
      00AE27 12 88 C5         [24] 1317 	lcall	_dynamic_keymap_get_keycode
      00AE2A A9 82            [24] 1318 	mov	r1, dpl
      00AE2C AA 83            [24] 1319 	mov	r2, dph
      00AE2E D0 03            [24] 1320 	pop	ar3
      00AE30 D0 06            [24] 1321 	pop	ar6
      00AE32 D0 07            [24] 1322 	pop	ar7
                                   1323 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AE34 12 38 36         [24] 1324 	lcall	_ak820_outline_0105
      00AE37 A3               [24] 1325 	inc	dptr
      00AE38 A3               [24] 1326 	inc	dptr
      00AE39 A3               [24] 1327 	inc	dptr
      00AE3A 8A 00            [24] 1328 	mov	ar0,r2
      00AE3C E8               [12] 1329 	mov	a,r0
      00AE3D F0               [24] 1330 	movx	@dptr,a
                                   1331 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AE3E 12 47 F3         [24] 1332 	lcall	_ak820_outline_0012
      00AE41 E9               [12] 1333 	mov	a,r1
      00AE42 F0               [24] 1334 	movx	@dptr,a
                                   1335 ;	quantum/via.c:337: break;
      00AE43 02 B1 5A         [24] 1336 	ljmp	00171$
                                   1337 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AE46                       1338 00130$:
                                   1339 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AE46 90 0E A4         [24] 1340 	mov	dptr,#_vial_unlocked
      00AE49 E0               [24] 1341 	movx	a,@dptr
      00AE4A 70 18            [24] 1342 	jnz	00132$
      00AE4C 12 40 1C         [24] 1343 	lcall	_ak820_outline_0017
      00AE4F FA               [12] 1344 	mov	r2,a
      00AE50 BA 7C 11         [24] 1345 	cjne	r2,#0x7c,00132$
      00AE53 74 05            [12] 1346 	mov	a,#0x05
      00AE55 2E               [12] 1347 	add	a, r6
      00AE56 12 37 D7         [24] 1348 	lcall	_ak820_outline_0018
      00AE59 70 09            [24] 1349 	jnz	00132$
                                   1350 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AE5B 12 48 48         [24] 1351 	lcall	_ak820_outline_0123
      00AE5E 74 FF            [12] 1352 	mov	a,#0xff
      00AE60 F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/via.c:345: break;
      00AE61 02 B1 5A         [24] 1355 	ljmp	00171$
      00AE64                       1356 00132$:
                                   1357 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AE64 C0 03            [24] 1358 	push	ar3
      00AE66 12 40 46         [24] 1359 	lcall	_ak820_outline_0081
      00AE69 F5 41            [12] 1360 	mov	_raw_hid_receive_sloc2_1_0,a
      00AE6B 12 37 E9         [24] 1361 	lcall	_ak820_outline_0032
      00AE6E F5 40            [12] 1362 	mov	_raw_hid_receive_sloc1_1_0,a
      00AE70 12 40 06         [24] 1363 	lcall	_ak820_outline_0015
      00AE73 F5 3C            [12] 1364 	mov	_raw_hid_receive_sloc0_1_0,a
      00AE75 12 40 1C         [24] 1365 	lcall	_ak820_outline_0017
      00AE78 FB               [12] 1366 	mov	r3,a
      00AE79 78 00            [12] 1367 	mov	r0,#0x00
      00AE7B 12 47 F3         [24] 1368 	lcall	_ak820_outline_0012
      00AE7E E0               [24] 1369 	movx	a,@dptr
      00AE7F 7A 00            [12] 1370 	mov	r2,#0x00
      00AE81 42 00            [12] 1371 	orl	ar0,a
      00AE83 EA               [12] 1372 	mov	a,r2
      00AE84 42 03            [12] 1373 	orl	ar3,a
      00AE86 90 0B 5D         [24] 1374 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00AE89 E5 40            [12] 1375 	mov	a,_raw_hid_receive_sloc1_1_0
      00AE8B F0               [24] 1376 	movx	@dptr,a
      00AE8C 90 0B 5E         [24] 1377 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00AE8F E5 3C            [12] 1378 	mov	a,_raw_hid_receive_sloc0_1_0
      00AE91 F0               [24] 1379 	movx	@dptr,a
      00AE92 90 0B 5F         [24] 1380 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00AE95 E8               [12] 1381 	mov	a,r0
      00AE96 F0               [24] 1382 	movx	@dptr,a
      00AE97 EB               [12] 1383 	mov	a,r3
      00AE98 A3               [24] 1384 	inc	dptr
      00AE99 F0               [24] 1385 	movx	@dptr,a
      00AE9A 85 41 82         [24] 1386 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00AE9D C0 07            [24] 1387 	push	ar7
      00AE9F C0 06            [24] 1388 	push	ar6
      00AEA1 C0 03            [24] 1389 	push	ar3
      00AEA3 12 89 12         [24] 1390 	lcall	_dynamic_keymap_set_keycode
      00AEA6 D0 03            [24] 1391 	pop	ar3
      00AEA8 D0 06            [24] 1392 	pop	ar6
      00AEAA D0 07            [24] 1393 	pop	ar7
                                   1394 ;	quantum/via.c:349: break;
      00AEAC D0 03            [24] 1395 	pop	ar3
      00AEAE 02 B1 5A         [24] 1396 	ljmp	00171$
                                   1397 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00AEB1                       1398 00135$:
                                   1399 ;	quantum/via.c:352: dynamic_keymap_reset();
      00AEB1 C0 07            [24] 1400 	push	ar7
      00AEB3 C0 06            [24] 1401 	push	ar6
      00AEB5 C0 03            [24] 1402 	push	ar3
      00AEB7 12 8C AC         [24] 1403 	lcall	_dynamic_keymap_reset
      00AEBA D0 03            [24] 1404 	pop	ar3
      00AEBC D0 06            [24] 1405 	pop	ar6
      00AEBE D0 07            [24] 1406 	pop	ar7
                                   1407 ;	quantum/via.c:353: break;
      00AEC0 02 B1 5A         [24] 1408 	ljmp	00171$
                                   1409 ;	quantum/via.c:355: case id_lighting_set_value: {
      00AEC3                       1410 00136$:
                                   1411 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00AEC3 12 B1 A4         [24] 1412 	lcall	_ak820_outline_0097
      00AEC6 90 0E 1A         [24] 1413 	mov	dptr,#_vialrgb_set_value_PARM_2
      00AEC9 12 B1 7F         [24] 1414 	lcall	_ak820_outline_0043
      00AECC C0 07            [24] 1415 	push	ar7
      00AECE C0 06            [24] 1416 	push	ar6
      00AED0 C0 03            [24] 1417 	push	ar3
      00AED2 12 BC 54         [24] 1418 	lcall	_vialrgb_set_value
      00AED5 D0 03            [24] 1419 	pop	ar3
      00AED7 D0 06            [24] 1420 	pop	ar6
      00AED9 D0 07            [24] 1421 	pop	ar7
                                   1422 ;	quantum/via.c:375: break;
      00AEDB 02 B1 5A         [24] 1423 	ljmp	00171$
                                   1424 ;	quantum/via.c:377: case id_lighting_get_value: {
      00AEDE                       1425 00137$:
                                   1426 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00AEDE 12 B1 A4         [24] 1427 	lcall	_ak820_outline_0097
      00AEE1 90 0E 16         [24] 1428 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AEE4 12 B1 7F         [24] 1429 	lcall	_ak820_outline_0043
      00AEE7 C0 07            [24] 1430 	push	ar7
      00AEE9 C0 06            [24] 1431 	push	ar6
      00AEEB C0 03            [24] 1432 	push	ar3
      00AEED 12 BA EE         [24] 1433 	lcall	_vialrgb_get_value
      00AEF0 D0 03            [24] 1434 	pop	ar3
      00AEF2 D0 06            [24] 1435 	pop	ar6
      00AEF4 D0 07            [24] 1436 	pop	ar7
                                   1437 ;	quantum/via.c:397: break;
      00AEF6 02 B1 5A         [24] 1438 	ljmp	00171$
                                   1439 ;	quantum/via.c:399: case id_lighting_save: {
      00AEF9                       1440 00138$:
                                   1441 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AEF9 12 B1 A4         [24] 1442 	lcall	_ak820_outline_0097
      00AEFC 90 0E 1E         [24] 1443 	mov	dptr,#_vialrgb_save_PARM_2
      00AEFF 12 B1 7F         [24] 1444 	lcall	_ak820_outline_0043
      00AF02 C0 07            [24] 1445 	push	ar7
      00AF04 C0 06            [24] 1446 	push	ar6
      00AF06 C0 03            [24] 1447 	push	ar3
      00AF08 12 BC E5         [24] 1448 	lcall	_vialrgb_save
      00AF0B D0 03            [24] 1449 	pop	ar3
      00AF0D D0 06            [24] 1450 	pop	ar6
      00AF0F D0 07            [24] 1451 	pop	ar7
                                   1452 ;	quantum/via.c:419: break;
      00AF11 02 B1 5A         [24] 1453 	ljmp	00171$
                                   1454 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AF14                       1455 00139$:
                                   1456 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AF14 C0 07            [24] 1457 	push	ar7
      00AF16 C0 06            [24] 1458 	push	ar6
      00AF18 C0 05            [24] 1459 	push	ar5
      00AF1A C0 04            [24] 1460 	push	ar4
      00AF1C C0 03            [24] 1461 	push	ar3
      00AF1E 12 90 D3         [24] 1462 	lcall	_dynamic_keymap_macro_get_count
      00AF21 AA 82            [24] 1463 	mov	r2, dpl
      00AF23 D0 03            [24] 1464 	pop	ar3
      00AF25 D0 04            [24] 1465 	pop	ar4
      00AF27 D0 05            [24] 1466 	pop	ar5
      00AF29 D0 06            [24] 1467 	pop	ar6
      00AF2B D0 07            [24] 1468 	pop	ar7
      00AF2D 12 38 4C         [24] 1469 	lcall	_ak820_outline_0126
      00AF30 EA               [12] 1470 	mov	a,r2
      00AF31 F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	quantum/via.c:430: break;
      00AF32 02 B1 5A         [24] 1473 	ljmp	00171$
                                   1474 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AF35                       1475 00140$:
                                   1476 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AF35 C0 07            [24] 1477 	push	ar7
      00AF37 C0 06            [24] 1478 	push	ar6
      00AF39 C0 05            [24] 1479 	push	ar5
      00AF3B C0 04            [24] 1480 	push	ar4
      00AF3D C0 03            [24] 1481 	push	ar3
      00AF3F 12 90 D7         [24] 1482 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AF42 A9 82            [24] 1483 	mov	r1, dpl
      00AF44 AA 83            [24] 1484 	mov	r2, dph
      00AF46 D0 03            [24] 1485 	pop	ar3
      00AF48 D0 04            [24] 1486 	pop	ar4
      00AF4A D0 05            [24] 1487 	pop	ar5
      00AF4C D0 06            [24] 1488 	pop	ar6
      00AF4E D0 07            [24] 1489 	pop	ar7
                                   1490 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AF50 8A 00            [24] 1491 	mov	ar0,r2
      00AF52 12 38 4C         [24] 1492 	lcall	_ak820_outline_0126
      00AF55 E8               [12] 1493 	mov	a,r0
      00AF56 12 47 FD         [24] 1494 	lcall	_ak820_outline_0025
                                   1495 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AF59 E9               [12] 1496 	mov	a,r1
      00AF5A F0               [24] 1497 	movx	@dptr,a
                                   1498 ;	quantum/via.c:436: break;
      00AF5B 02 B1 5A         [24] 1499 	ljmp	00171$
                                   1500 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AF5E                       1501 00141$:
                                   1502 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AF5E C0 03            [24] 1503 	push	ar3
      00AF60 12 B1 68         [24] 1504 	lcall	_ak820_outline_0002
      00AF63 89 3C            [24] 1505 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AF65 8A 3D            [24] 1506 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1507 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AF67 12 40 06         [24] 1508 	lcall	_ak820_outline_0015
      00AF6A FB               [12] 1509 	mov	r3,a
                                   1510 ;	quantum/via.c:441: if (size <= 28)
      00AF6B 8B 42            [24] 1511 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AF6D 75 43 00         [24] 1512 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AF70 C3               [12] 1513 	clr	c
      00AF71 74 1C            [12] 1514 	mov	a,#0x1c
      00AF73 9B               [12] 1515 	subb	a,r3
      00AF74 D0 03            [24] 1516 	pop	ar3
      00AF76 50 03            [24] 1517 	jnc	00562$
      00AF78 02 B1 5A         [24] 1518 	ljmp	00171$
      00AF7B                       1519 00562$:
                                   1520 ;	free result
                                   1521 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AF7B 12 B1 88         [24] 1522 	lcall	_ak820_outline_0074
      00AF7E 90 0B BE         [24] 1523 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AF81 E5 42            [12] 1524 	mov	a,_raw_hid_receive_sloc3_1_0
      00AF83 F0               [24] 1525 	movx	@dptr,a
      00AF84 E5 43            [12] 1526 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AF86 A3               [24] 1527 	inc	dptr
      00AF87 F0               [24] 1528 	movx	@dptr,a
      00AF88 90 0B C0         [24] 1529 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00AF8B 12 B1 92         [24] 1530 	lcall	_ak820_outline_0088
      00AF8E 85 3C 82         [24] 1531 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00AF91 85 3D 83         [24] 1532 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00AF94 C0 07            [24] 1533 	push	ar7
      00AF96 C0 06            [24] 1534 	push	ar6
      00AF98 C0 03            [24] 1535 	push	ar3
      00AF9A 12 90 DB         [24] 1536 	lcall	_dynamic_keymap_macro_get_buffer
      00AF9D D0 03            [24] 1537 	pop	ar3
      00AF9F D0 06            [24] 1538 	pop	ar6
      00AFA1 D0 07            [24] 1539 	pop	ar7
                                   1540 ;	quantum/via.c:443: break;
      00AFA3 02 B1 5A         [24] 1541 	ljmp	00171$
                                   1542 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00AFA6                       1543 00144$:
                                   1544 ;	quantum/via.c:448: if (!vial_unlocked) {
      00AFA6 90 0E A4         [24] 1545 	mov	dptr,#_vial_unlocked
      00AFA9 E0               [24] 1546 	movx	a,@dptr
      00AFAA 70 01            [24] 1547 	jnz	00146$
                                   1548 ;	quantum/via.c:450: return;
      00AFAC 22               [24] 1549 	ret
      00AFAD                       1550 00146$:
                                   1551 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AFAD C0 03            [24] 1552 	push	ar3
      00AFAF 12 B1 68         [24] 1553 	lcall	_ak820_outline_0002
      00AFB2 89 42            [24] 1554 	mov	_raw_hid_receive_sloc3_1_0,r1
      00AFB4 8A 43            [24] 1555 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1556 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00AFB6 12 40 06         [24] 1557 	lcall	_ak820_outline_0015
      00AFB9 F5 3C            [12] 1558 	mov	_raw_hid_receive_sloc0_1_0, a
      00AFBB 75 3D 00         [24] 1559 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1560 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00AFBE 85 3C 44         [24] 1561 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00AFC1 85 3D 45         [24] 1562 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00AFC4 C3               [12] 1563 	clr	c
      00AFC5 74 1C            [12] 1564 	mov	a,#0x1c
      00AFC7 95 44            [12] 1565 	subb	a,_raw_hid_receive_sloc4_1_0
      00AFC9 E4               [12] 1566 	clr	a
      00AFCA 95 45            [12] 1567 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AFCC D0 03            [24] 1568 	pop	ar3
      00AFCE 40 43            [24] 1569 	jc	00147$
                                   1570 ;	free result
      00AFD0 8B 01            [24] 1571 	mov	ar1,r3
      00AFD2 7A 00            [12] 1572 	mov	r2,#0x00
      00AFD4 E9               [12] 1573 	mov	a,r1
      00AFD5 24 FC            [12] 1574 	add	a,#0xfc
      00AFD7 F9               [12] 1575 	mov	r1,a
      00AFD8 EA               [12] 1576 	mov	a,r2
      00AFD9 34 FF            [12] 1577 	addc	a,#0xff
      00AFDB FA               [12] 1578 	mov	r2,a
      00AFDC C3               [12] 1579 	clr	c
      00AFDD E9               [12] 1580 	mov	a,r1
      00AFDE 95 44            [12] 1581 	subb	a,_raw_hid_receive_sloc4_1_0
      00AFE0 EA               [12] 1582 	mov	a,r2
      00AFE1 95 45            [12] 1583 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AFE3 40 2E            [24] 1584 	jc	00147$
                                   1585 ;	free result
      00AFE5 12 B1 88         [24] 1586 	lcall	_ak820_outline_0074
      00AFE8 90 0B C5         [24] 1587 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00AFEB E5 3C            [12] 1588 	mov	a,_raw_hid_receive_sloc0_1_0
      00AFED F0               [24] 1589 	movx	@dptr,a
      00AFEE E5 3D            [12] 1590 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AFF0 A3               [24] 1591 	inc	dptr
      00AFF1 F0               [24] 1592 	movx	@dptr,a
      00AFF2 90 0B C7         [24] 1593 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00AFF5 12 B1 92         [24] 1594 	lcall	_ak820_outline_0088
      00AFF8 85 42 82         [24] 1595 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00AFFB 85 43 83         [24] 1596 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00AFFE C0 07            [24] 1597 	push	ar7
      00B000 C0 06            [24] 1598 	push	ar6
      00B002 C0 03            [24] 1599 	push	ar3
      00B004 12 91 28         [24] 1600 	lcall	_dynamic_keymap_macro_set_buffer
      00B007 E5 82            [12] 1601 	mov	a, dpl
      00B009 D0 03            [24] 1602 	pop	ar3
      00B00B D0 06            [24] 1603 	pop	ar6
      00B00D D0 07            [24] 1604 	pop	ar7
      00B00F 60 02            [24] 1605 	jz	00566$
      00B011 21 5A            [12] 1606 	ajmp	00171$
      00B013                       1607 00566$:
      00B013                       1608 00147$:
      00B013 22               [24] 1609 	ret
                                   1610 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00B014                       1611 00151$:
                                   1612 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00B014 90 0E A4         [24] 1613 	mov	dptr,#_vial_unlocked
      00B017 E0               [24] 1614 	movx	a,@dptr
      00B018 70 01            [24] 1615 	jnz	00153$
      00B01A 22               [24] 1616 	ret
      00B01B                       1617 00153$:
                                   1618 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00B01B C0 07            [24] 1619 	push	ar7
      00B01D C0 06            [24] 1620 	push	ar6
      00B01F C0 03            [24] 1621 	push	ar3
      00B021 12 91 57         [24] 1622 	lcall	_dynamic_keymap_macro_reset
      00B024 D0 03            [24] 1623 	pop	ar3
      00B026 D0 06            [24] 1624 	pop	ar6
      00B028 D0 07            [24] 1625 	pop	ar7
                                   1626 ;	quantum/via.c:473: break;
      00B02A 21 5A            [12] 1627 	ajmp	00171$
                                   1628 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00B02C                       1629 00154$:
                                   1630 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00B02C C0 07            [24] 1631 	push	ar7
      00B02E C0 06            [24] 1632 	push	ar6
      00B030 C0 05            [24] 1633 	push	ar5
      00B032 C0 04            [24] 1634 	push	ar4
      00B034 C0 03            [24] 1635 	push	ar3
      00B036 12 88 8A         [24] 1636 	lcall	_dynamic_keymap_get_layer_count
      00B039 AA 82            [24] 1637 	mov	r2, dpl
      00B03B D0 03            [24] 1638 	pop	ar3
      00B03D D0 04            [24] 1639 	pop	ar4
      00B03F D0 05            [24] 1640 	pop	ar5
      00B041 D0 06            [24] 1641 	pop	ar6
      00B043 D0 07            [24] 1642 	pop	ar7
      00B045 12 38 4C         [24] 1643 	lcall	_ak820_outline_0126
      00B048 EA               [12] 1644 	mov	a,r2
      00B049 F0               [24] 1645 	movx	@dptr,a
                                   1646 ;	quantum/via.c:477: break;
      00B04A 21 5A            [12] 1647 	ajmp	00171$
                                   1648 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00B04C                       1649 00155$:
                                   1650 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B04C C0 03            [24] 1651 	push	ar3
      00B04E 12 B1 68         [24] 1652 	lcall	_ak820_outline_0002
      00B051 89 44            [24] 1653 	mov	_raw_hid_receive_sloc4_1_0,r1
      00B053 8A 45            [24] 1654 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1655 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00B055 12 40 06         [24] 1656 	lcall	_ak820_outline_0015
      00B058 FB               [12] 1657 	mov	r3,a
                                   1658 ;	quantum/via.c:482: if (size <= 28)
      00B059 8B 42            [24] 1659 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B05B 75 43 00         [24] 1660 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B05E C3               [12] 1661 	clr	c
      00B05F 74 1C            [12] 1662 	mov	a,#0x1c
      00B061 9B               [12] 1663 	subb	a,r3
      00B062 D0 03            [24] 1664 	pop	ar3
      00B064 50 02            [24] 1665 	jnc	00568$
      00B066 21 5A            [12] 1666 	ajmp	00171$
      00B068                       1667 00568$:
                                   1668 ;	free result
                                   1669 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00B068 12 B1 88         [24] 1670 	lcall	_ak820_outline_0074
      00B06B 90 0B A7         [24] 1671 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00B06E E5 42            [12] 1672 	mov	a,_raw_hid_receive_sloc3_1_0
      00B070 F0               [24] 1673 	movx	@dptr,a
      00B071 E5 43            [12] 1674 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B073 A3               [24] 1675 	inc	dptr
      00B074 F0               [24] 1676 	movx	@dptr,a
      00B075 90 0B A9         [24] 1677 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00B078 12 B1 92         [24] 1678 	lcall	_ak820_outline_0088
      00B07B 85 44 82         [24] 1679 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B07E 85 45 83         [24] 1680 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B081 C0 07            [24] 1681 	push	ar7
      00B083 C0 06            [24] 1682 	push	ar6
      00B085 C0 03            [24] 1683 	push	ar3
      00B087 12 8E A1         [24] 1684 	lcall	_dynamic_keymap_get_buffer
      00B08A D0 03            [24] 1685 	pop	ar3
      00B08C D0 06            [24] 1686 	pop	ar6
      00B08E D0 07            [24] 1687 	pop	ar7
                                   1688 ;	quantum/via.c:484: break;
      00B090 21 5A            [12] 1689 	ajmp	00171$
                                   1690 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00B092                       1691 00158$:
                                   1692 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B092 12 40 46         [24] 1693 	lcall	_ak820_outline_0081
      00B095 FD               [12] 1694 	mov	r5,a
      00B096 7C 00            [12] 1695 	mov	r4,#0x00
      00B098 12 37 E9         [24] 1696 	lcall	_ak820_outline_0032
      00B09B 7A 00            [12] 1697 	mov	r2,#0x00
      00B09D 42 04            [12] 1698 	orl	ar4,a
      00B09F EA               [12] 1699 	mov	a,r2
      00B0A0 42 05            [12] 1700 	orl	ar5,a
      00B0A2 8C 44            [24] 1701 	mov	_raw_hid_receive_sloc4_1_0,r4
      00B0A4 8D 45            [24] 1702 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1703 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00B0A6 12 40 06         [24] 1704 	lcall	_ak820_outline_0015
      00B0A9 F9               [12] 1705 	mov	r1,a
      00B0AA 7A 00            [12] 1706 	mov	r2,#0x00
                                   1707 ;	quantum/via.c:489: if (size <= 28)
      00B0AC 89 00            [24] 1708 	mov	ar0,r1
      00B0AE E8               [12] 1709 	mov	a,r0
      00B0AF 24 E3            [12] 1710 	add	a,#0xff - 0x1c
      00B0B1 50 02            [24] 1711 	jnc	00569$
      00B0B3 21 5A            [12] 1712 	ajmp	00171$
      00B0B5                       1713 00569$:
                                   1714 ;	free result
                                   1715 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00B0B5 C0 03            [24] 1716 	push	ar3
      00B0B7 74 04            [12] 1717 	mov	a,#0x04
      00B0B9 2E               [12] 1718 	add	a, r6
      00B0BA F8               [12] 1719 	mov	r0,a
      00B0BB E4               [12] 1720 	clr	a
      00B0BC 3F               [12] 1721 	addc	a, r7
      00B0BD FB               [12] 1722 	mov	r3,a
      00B0BE 7D 00            [12] 1723 	mov	r5,#0x00
      00B0C0 90 0B AE         [24] 1724 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00B0C3 12 4D 70         [24] 1725 	lcall	_ak820_outline_0144
      00B0C6 90 0B B0         [24] 1726 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00B0C9 E8               [12] 1727 	mov	a,r0
      00B0CA F0               [24] 1728 	movx	@dptr,a
      00B0CB EB               [12] 1729 	mov	a,r3
      00B0CC A3               [24] 1730 	inc	dptr
      00B0CD F0               [24] 1731 	movx	@dptr,a
      00B0CE ED               [12] 1732 	mov	a,r5
      00B0CF A3               [24] 1733 	inc	dptr
      00B0D0 F0               [24] 1734 	movx	@dptr,a
      00B0D1 85 44 82         [24] 1735 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B0D4 85 45 83         [24] 1736 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B0D7 C0 07            [24] 1737 	push	ar7
      00B0D9 C0 06            [24] 1738 	push	ar6
      00B0DB C0 03            [24] 1739 	push	ar3
      00B0DD 12 8E DF         [24] 1740 	lcall	_dynamic_keymap_set_buffer
      00B0E0 D0 03            [24] 1741 	pop	ar3
      00B0E2 D0 06            [24] 1742 	pop	ar6
      00B0E4 D0 07            [24] 1743 	pop	ar7
                                   1744 ;	quantum/via.c:491: break;
      00B0E6 D0 03            [24] 1745 	pop	ar3
      00B0E8 21 5A            [12] 1746 	ajmp	00171$
                                   1747 ;	quantum/via.c:495: case id_bootloader_jump: {
      00B0EA                       1748 00161$:
                                   1749 ;	quantum/via.c:497: if (!vial_unlocked)
      00B0EA 90 0E A4         [24] 1750 	mov	dptr,#_vial_unlocked
      00B0ED E0               [24] 1751 	movx	a,@dptr
      00B0EE 70 02            [24] 1752 	jnz	00570$
      00B0F0 21 5A            [12] 1753 	ajmp	00171$
      00B0F2                       1754 00570$:
                                   1755 ;	quantum/via.c:501: raw_hid_send(data, length);
      00B0F2 12 B1 AB         [24] 1756 	lcall	_ak820_outline_0157
      00B0F5 90 06 D6         [24] 1757 	mov	dptr,#_raw_hid_send_PARM_2
      00B0F8 12 B1 9B         [24] 1758 	lcall	_ak820_outline_0089
      00B0FB C0 07            [24] 1759 	push	ar7
      00B0FD C0 06            [24] 1760 	push	ar6
      00B0FF C0 03            [24] 1761 	push	ar3
      00B101 12 4F AE         [24] 1762 	lcall	_raw_hid_send
      00B104 D0 03            [24] 1763 	pop	ar3
      00B106 D0 06            [24] 1764 	pop	ar6
      00B108 D0 07            [24] 1765 	pop	ar7
                                   1766 ;	quantum/via.c:503: wait_ms(100);
      00B10A 7D 64            [12] 1767 	mov	r5,#0x64
      00B10C                       1768 00176$:
      00B10C ED               [12] 1769 	mov	a,r5
      00B10D 60 09            [24] 1770 	jz	00166$
      00B10F 90 00 01         [24] 1771 	mov	dptr,#0x0001
      00B112 12 5D 62         [24] 1772 	lcall	_mDelaymS
      00B115 1D               [12] 1773 	dec	r5
      00B116 80 F4            [24] 1774 	sjmp	00176$
      00B118                       1775 00166$:
                                   1776 ;	quantum/via.c:504: bootloader_jump();
      00B118 C0 07            [24] 1777 	push	ar7
      00B11A C0 06            [24] 1778 	push	ar6
      00B11C C0 03            [24] 1779 	push	ar3
      00B11E 12 34 0E         [24] 1780 	lcall	_bootloader_jump
      00B121 D0 03            [24] 1781 	pop	ar3
      00B123 D0 06            [24] 1782 	pop	ar6
      00B125 D0 07            [24] 1783 	pop	ar7
                                   1784 ;	quantum/via.c:505: break;
                                   1785 ;	quantum/via.c:509: case id_vial_prefix: {
      00B127 80 31            [24] 1786 	sjmp	00171$
      00B129                       1787 00168$:
                                   1788 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B129 12 B1 AB         [24] 1789 	lcall	_ak820_outline_0157
      00B12C 90 0C CD         [24] 1790 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B12F 12 B1 9B         [24] 1791 	lcall	_ak820_outline_0089
      00B132 C0 07            [24] 1792 	push	ar7
      00B134 C0 06            [24] 1793 	push	ar6
      00B136 C0 03            [24] 1794 	push	ar3
      00B138 51 9B            [12] 1795 	acall	_vial_handle_cmd
      00B13A D0 03            [24] 1796 	pop	ar3
      00B13C D0 06            [24] 1797 	pop	ar6
      00B13E D0 07            [24] 1798 	pop	ar7
                                   1799 ;	quantum/via.c:511: break;
                                   1800 ;	quantum/via.c:514: default: {
      00B140 80 18            [24] 1801 	sjmp	00171$
      00B142                       1802 00169$:
                                   1803 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B142 12 B1 AB         [24] 1804 	lcall	_ak820_outline_0157
      00B145 90 0C BB         [24] 1805 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B148 12 B1 9B         [24] 1806 	lcall	_ak820_outline_0089
      00B14B C0 07            [24] 1807 	push	ar7
      00B14D C0 06            [24] 1808 	push	ar6
      00B14F C0 03            [24] 1809 	push	ar3
      00B151 12 AB D2         [24] 1810 	lcall	_raw_hid_receive_kb
      00B154 D0 03            [24] 1811 	pop	ar3
      00B156 D0 06            [24] 1812 	pop	ar6
      00B158 D0 07            [24] 1813 	pop	ar7
                                   1814 ;	quantum/via.c:521: skip:
      00B15A                       1815 00171$:
                                   1816 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B15A 7D 00            [12] 1817 	mov	r5,#0x00
      00B15C 90 06 D6         [24] 1818 	mov	dptr,#_raw_hid_send_PARM_2
      00B15F EB               [12] 1819 	mov	a,r3
      00B160 12 48 29         [24] 1820 	lcall	_ak820_outline_0066
      00B163 8D F0            [24] 1821 	mov	b, r5
                                   1822 ;	quantum/via.c:526: }
      00B165 02 4F AE         [24] 1823 	ljmp	_raw_hid_send
                                   1824 	.area CSEG    (CODE)
                                   1825 	.area CONST   (CODE)
                                   1826 	.area XINIT   (CODE)
                                   1827 	.area CABS    (ABS,CODE)
                                   1828 
                                   1829 ; Experimental exact instruction outlining.
                                   1830 	.globl _ak820_outline_0002
                                   1831 	.globl _ak820_outline_0005
                                   1832 	.globl _ak820_outline_0010
                                   1833 	.globl _ak820_outline_0012
                                   1834 	.globl _ak820_outline_0015
                                   1835 	.globl _ak820_outline_0017
                                   1836 	.globl _ak820_outline_0018
                                   1837 	.globl _ak820_outline_0019
                                   1838 	.globl _ak820_outline_0023
                                   1839 	.globl _ak820_outline_0025
                                   1840 	.globl _ak820_outline_0032
                                   1841 	.globl _ak820_outline_0040
                                   1842 	.globl _ak820_outline_0043
                                   1843 	.globl _ak820_outline_0046
                                   1844 	.globl _ak820_outline_0049
                                   1845 	.globl _ak820_outline_0056
                                   1846 	.globl _ak820_outline_0066
                                   1847 	.globl _ak820_outline_0074
                                   1848 	.globl _ak820_outline_0081
                                   1849 	.globl _ak820_outline_0088
                                   1850 	.globl _ak820_outline_0089
                                   1851 	.globl _ak820_outline_0097
                                   1852 	.globl _ak820_outline_0098
                                   1853 	.globl _ak820_outline_0105
                                   1854 	.globl _ak820_outline_0108
                                   1855 	.globl _ak820_outline_0109
                                   1856 	.globl _ak820_outline_0123
                                   1857 	.globl _ak820_outline_0125
                                   1858 	.globl _ak820_outline_0126
                                   1859 	.globl _ak820_outline_0144
                                   1860 	.globl _ak820_outline_0150
                                   1861 	.globl _ak820_outline_0157
                                   1862 	.globl _ak820_outline_0159
                                   1863 	.globl _ak820_outline_0162
                                   1864 	.globl _ak820_outline_0164
                                   1865 	.globl _ak820_outline_0166
                                   1866 	.globl _ak820_outline_0167
                                   1867 
                                   1868 	.area CSEG (CODE)
                                   1869 ; function ak820_outline_0002
      00B168                       1870 _ak820_outline_0002:
      00B168 8C 82            [24] 1871 	mov	dpl,r4
      00B16A 8D 83            [24] 1872 	mov	dph,r5
      00B16C E0               [24] 1873 	movx	a,@dptr
      00B16D FA               [12] 1874 	mov	r2,a
      00B16E 79 00            [12] 1875 	mov	r1,#0x00
      00B170 8E 82            [24] 1876 	mov	dpl,r6
      00B172 8F 83            [24] 1877 	mov	dph,r7
      00B174 A3               [24] 1878 	inc	dptr
      00B175 A3               [24] 1879 	inc	dptr
      00B176 E0               [24] 1880 	movx	a,@dptr
      00B177 7B 00            [12] 1881 	mov	r3,#0x00
      00B179 42 01            [12] 1882 	orl	ar1,a
      00B17B EB               [12] 1883 	mov	a,r3
      00B17C 42 02            [12] 1884 	orl	ar2,a
      00B17E 22               [24] 1885 	ret
                                   1886 
                                   1887 	.area CSEG (CODE)
                                   1888 ; function ak820_outline_0043
      00B17F                       1889 _ak820_outline_0043:
      00B17F EB               [12] 1890 	mov	a,r3
      00B180 F0               [24] 1891 	movx	@dptr,a
      00B181 88 82            [24] 1892 	mov	dpl,r0
      00B183 89 83            [24] 1893 	mov	dph,r1
      00B185 8A F0            [24] 1894 	mov	b,r2
      00B187 22               [24] 1895 	ret
                                   1896 
                                   1897 	.area CSEG (CODE)
                                   1898 ; function ak820_outline_0074
      00B188                       1899 _ak820_outline_0074:
      00B188 74 04            [12] 1900 	mov	a,#0x04
      00B18A 2E               [12] 1901 	add	a,r6
      00B18B F9               [12] 1902 	mov	r1,a
      00B18C E4               [12] 1903 	clr	a
      00B18D 3F               [12] 1904 	addc	a,r7
      00B18E F8               [12] 1905 	mov	r0,a
      00B18F 7A 00            [12] 1906 	mov	r2,#0x00
      00B191 22               [24] 1907 	ret
                                   1908 
                                   1909 	.area CSEG (CODE)
                                   1910 ; function ak820_outline_0088
      00B192                       1911 _ak820_outline_0088:
      00B192 E9               [12] 1912 	mov	a,r1
      00B193 F0               [24] 1913 	movx	@dptr,a
      00B194 E8               [12] 1914 	mov	a,r0
      00B195 A3               [24] 1915 	inc	dptr
      00B196 F0               [24] 1916 	movx	@dptr,a
      00B197 EA               [12] 1917 	mov	a,r2
      00B198 A3               [24] 1918 	inc	dptr
      00B199 F0               [24] 1919 	movx	@dptr,a
      00B19A 22               [24] 1920 	ret
                                   1921 
                                   1922 	.area CSEG (CODE)
                                   1923 ; function ak820_outline_0089
      00B19B                       1924 _ak820_outline_0089:
      00B19B EB               [12] 1925 	mov	a,r3
      00B19C F0               [24] 1926 	movx	@dptr,a
      00B19D 8A 82            [24] 1927 	mov	dpl,r2
      00B19F 8C 83            [24] 1928 	mov	dph,r4
      00B1A1 8D F0            [24] 1929 	mov	b,r5
      00B1A3 22               [24] 1930 	ret
                                   1931 
                                   1932 	.area CSEG (CODE)
                                   1933 ; function ak820_outline_0097
      00B1A4                       1934 _ak820_outline_0097:
      00B1A4 8E 00            [24] 1935 	mov	ar0,r6
      00B1A6 8F 01            [24] 1936 	mov	ar1,r7
      00B1A8 7A 00            [12] 1937 	mov	r2,#0x00
      00B1AA 22               [24] 1938 	ret
                                   1939 
                                   1940 	.area CSEG (CODE)
                                   1941 ; function ak820_outline_0157
      00B1AB                       1942 _ak820_outline_0157:
      00B1AB 8E 02            [24] 1943 	mov	ar2,r6
      00B1AD 8F 04            [24] 1944 	mov	ar4,r7
      00B1AF 7D 00            [12] 1945 	mov	r5,#0x00
      00B1B1 22               [24] 1946 	ret
