                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_key_override_reload
                                     12 	.globl _unregister_code16
                                     13 	.globl _register_code16
                                     14 	.globl _matrix_is_on
                                     15 	.globl _dynamic_keymap_set_key_override
                                     16 	.globl _dynamic_keymap_get_key_override
                                     17 	.globl _dynamic_keymap_set_combo
                                     18 	.globl _dynamic_keymap_get_combo
                                     19 	.globl _dynamic_keymap_set_encoder
                                     20 	.globl _dynamic_keymap_get_encoder
                                     21 	.globl _repeat_key_cancel
                                     22 	.globl _ak820_combo_reload
                                     23 	.globl _clear_keyboard
                                     24 	.globl _ak820_action_exec
                                     25 	.globl _timer_elapsed32
                                     26 	.globl _timer_read32
                                     27 	.globl _timer_read
                                     28 	.globl ___memcpy
                                     29 	.globl _ADC_START
                                     30 	.globl _S0_R_FIFO
                                     31 	.globl _S0_T_FIFO
                                     32 	.globl _S0_FREE
                                     33 	.globl _S0_IF_BYTE
                                     34 	.globl _S0_IF_FIRST
                                     35 	.globl _S0_IF_OV
                                     36 	.globl _S0_FST_ACT
                                     37 	.globl _CP_RL2
                                     38 	.globl _C_T2
                                     39 	.globl _TR2
                                     40 	.globl _EXEN2
                                     41 	.globl _TCLK
                                     42 	.globl _RCLK
                                     43 	.globl _EXF2
                                     44 	.globl _CAP1F
                                     45 	.globl _TF2
                                     46 	.globl _RI
                                     47 	.globl _TI
                                     48 	.globl _RB8
                                     49 	.globl _TB8
                                     50 	.globl _REN
                                     51 	.globl _SM2
                                     52 	.globl _SM1
                                     53 	.globl _SM0
                                     54 	.globl _IT0
                                     55 	.globl _IE0
                                     56 	.globl _IT1
                                     57 	.globl _IE1
                                     58 	.globl _TR0
                                     59 	.globl _TF0
                                     60 	.globl _TR1
                                     61 	.globl _TF1
                                     62 	.globl _P4_0
                                     63 	.globl _P4_1
                                     64 	.globl _P4_2
                                     65 	.globl _P4_3
                                     66 	.globl _P4_4
                                     67 	.globl _P4_5
                                     68 	.globl _P4_6
                                     69 	.globl _RXD
                                     70 	.globl _TXD
                                     71 	.globl _INT0
                                     72 	.globl _INT1
                                     73 	.globl _T0
                                     74 	.globl _T1
                                     75 	.globl _MOSI1
                                     76 	.globl _MISO1
                                     77 	.globl _SCK1
                                     78 	.globl _P3_0
                                     79 	.globl _P3_1
                                     80 	.globl _P3_2
                                     81 	.globl _P3_3
                                     82 	.globl _P3_4
                                     83 	.globl _P3_5
                                     84 	.globl _P3_6
                                     85 	.globl _P3_7
                                     86 	.globl _CAP1_
                                     87 	.globl _T2_
                                     88 	.globl _CAP2_
                                     89 	.globl _T2EX_
                                     90 	.globl _RXD1
                                     91 	.globl _TXD1
                                     92 	.globl _P2_0
                                     93 	.globl _P2_1
                                     94 	.globl _P2_2
                                     95 	.globl _P2_3
                                     96 	.globl _P2_4
                                     97 	.globl _P2_5
                                     98 	.globl _P2_6
                                     99 	.globl _P2_7
                                    100 	.globl _AIN0
                                    101 	.globl _AIN1
                                    102 	.globl _AIN2
                                    103 	.globl _AIN3
                                    104 	.globl _AIN4
                                    105 	.globl _AIN5
                                    106 	.globl _AIN6
                                    107 	.globl _AIN7
                                    108 	.globl _CAP1
                                    109 	.globl _T2
                                    110 	.globl _CAP2
                                    111 	.globl _T2EX
                                    112 	.globl _INT0_
                                    113 	.globl _SCS
                                    114 	.globl _MOSI
                                    115 	.globl _MISO
                                    116 	.globl _SCK
                                    117 	.globl _RXD1_
                                    118 	.globl _TXD1_
                                    119 	.globl _P1_0
                                    120 	.globl _P1_1
                                    121 	.globl _P1_2
                                    122 	.globl _P1_3
                                    123 	.globl _P1_4
                                    124 	.globl _P1_5
                                    125 	.globl _P1_6
                                    126 	.globl _P1_7
                                    127 	.globl _AIN8
                                    128 	.globl _AIN9
                                    129 	.globl _AIN10
                                    130 	.globl _AIN11
                                    131 	.globl _AIN12
                                    132 	.globl _AIN13
                                    133 	.globl _RXD_
                                    134 	.globl _TXD_
                                    135 	.globl _SCL0
                                    136 	.globl _SDA0
                                    137 	.globl _P0_0
                                    138 	.globl _P0_1
                                    139 	.globl _P0_2
                                    140 	.globl _P0_3
                                    141 	.globl _P0_4
                                    142 	.globl _P0_5
                                    143 	.globl _P0_6
                                    144 	.globl _P0_7
                                    145 	.globl _IE_SPI0
                                    146 	.globl _IE_USB
                                    147 	.globl _IE_ADC
                                    148 	.globl _IE_UART1
                                    149 	.globl _IE_PWM_I2C
                                    150 	.globl _IE_GPIO
                                    151 	.globl _IE_WDOG
                                    152 	.globl _PX0
                                    153 	.globl _PT0
                                    154 	.globl _PX1
                                    155 	.globl _PT1
                                    156 	.globl _PS
                                    157 	.globl _PT2
                                    158 	.globl _PL_FLAG
                                    159 	.globl _PH_FLAG
                                    160 	.globl _EX0
                                    161 	.globl _ET0
                                    162 	.globl _EX1
                                    163 	.globl _ET1
                                    164 	.globl _ES
                                    165 	.globl _ET2
                                    166 	.globl _E_DIS
                                    167 	.globl _EA
                                    168 	.globl _P
                                    169 	.globl _F1
                                    170 	.globl _OV
                                    171 	.globl _RS0
                                    172 	.globl _RS1
                                    173 	.globl _F0
                                    174 	.globl _AC
                                    175 	.globl _CY
                                    176 	.globl _I2CS_INT_ST
                                    177 	.globl _I2CX_INT
                                    178 	.globl _LED_STATUS
                                    179 	.globl _LED_DMA_H
                                    180 	.globl _LED_DMA_L
                                    181 	.globl _LED_DMA
                                    182 	.globl _LED_PWM_OE
                                    183 	.globl _LED_COMMON
                                    184 	.globl _ADC_CHAN
                                    185 	.globl _ADC_DAT_H
                                    186 	.globl _ADC_DAT_L
                                    187 	.globl _ADC_DAT
                                    188 	.globl _ADC_CTRL
                                    189 	.globl _SPI1_CK_SE
                                    190 	.globl _SPI1_CTRL
                                    191 	.globl _SPI1_DATA
                                    192 	.globl _SPI1_STAT
                                    193 	.globl _SIF1
                                    194 	.globl _SBAUD1
                                    195 	.globl _SBUF1
                                    196 	.globl _SCON1
                                    197 	.globl _SPI0_SETUP
                                    198 	.globl _SPI0_CK_SE
                                    199 	.globl _SPI0_CTRL
                                    200 	.globl _SPI0_DATA
                                    201 	.globl _SPI0_STAT
                                    202 	.globl _T2CAP1H
                                    203 	.globl _T2CAP1L
                                    204 	.globl _T2CAP1
                                    205 	.globl _TH2
                                    206 	.globl _TL2
                                    207 	.globl _T2COUNT
                                    208 	.globl _RCAP2H
                                    209 	.globl _RCAP2L
                                    210 	.globl _RCAP2
                                    211 	.globl _T2MOD
                                    212 	.globl _T2CON
                                    213 	.globl _SBUF
                                    214 	.globl _SCON
                                    215 	.globl _TH1
                                    216 	.globl _TH0
                                    217 	.globl _TL1
                                    218 	.globl _TL0
                                    219 	.globl _TMOD
                                    220 	.globl _TCON
                                    221 	.globl _XBUS_AUX
                                    222 	.globl _P7
                                    223 	.globl _P6_DIR
                                    224 	.globl _P6_OUT_PU
                                    225 	.globl _P6_IN
                                    226 	.globl _P5_DIR
                                    227 	.globl _P5_OUT_PU
                                    228 	.globl _P5_IN
                                    229 	.globl _P4_LED_KEY
                                    230 	.globl _P4_DIR_PU
                                    231 	.globl _P4_MOD_OC
                                    232 	.globl _P4
                                    233 	.globl _P3_DIR_PU
                                    234 	.globl _P3_MOD_OC
                                    235 	.globl _P3
                                    236 	.globl _P2_DIR_PU
                                    237 	.globl _P2_MOD_OC
                                    238 	.globl _P2
                                    239 	.globl _P1_DIR_PU
                                    240 	.globl _P1_MOD_OC
                                    241 	.globl _P1
                                    242 	.globl _P0_DIR_PU
                                    243 	.globl _P0_MOD_OC
                                    244 	.globl _P0
                                    245 	.globl _ROM_CTRL
                                    246 	.globl _ROM_DATA_HH
                                    247 	.globl _ROM_DATA_HL
                                    248 	.globl _ROM_DATA_HI
                                    249 	.globl _ROM_ADDR_H
                                    250 	.globl _ROM_ADDR_L
                                    251 	.globl _ROM_ADDR
                                    252 	.globl _GPIO_IE
                                    253 	.globl _IP_EX
                                    254 	.globl _IE_EX
                                    255 	.globl _IP
                                    256 	.globl _IE
                                    257 	.globl _WDOG_COUNT
                                    258 	.globl _RESET_KEEP
                                    259 	.globl _WAKE_CTRL
                                    260 	.globl _CLOCK_CFG
                                    261 	.globl _POWER_CFG
                                    262 	.globl _PCON
                                    263 	.globl _GLOBAL_CFG
                                    264 	.globl _SAFE_MOD
                                    265 	.globl _DPH
                                    266 	.globl _DPL
                                    267 	.globl _SP
                                    268 	.globl _A_INV
                                    269 	.globl _B
                                    270 	.globl _ACC
                                    271 	.globl _PSW
                                    272 	.globl _vial_unlock_in_progress
                                    273 	.globl _vial_unlocked
                                    274 	.globl _g_vial_magic_keycode_override
                                    275 	.globl _vial_handle_cmd_PARM_2
                                    276 	.globl _vial_unlock_task
                                    277 	.globl _vial_init
                                    278 	.globl _vial_handle_cmd
                                    279 	.globl _vial_keycode_down
                                    280 	.globl _vial_keycode_up
                                    281 	.globl _vial_keycode_tap
                                    282 ;--------------------------------------------------------
                                    283 ; special function registers
                                    284 ;--------------------------------------------------------
                                    285 	.area RSEG    (ABS,DATA)
      000000                        286 	.org 0x0000
                           0000D0   287 _PSW	=	0x00d0
                           0000E0   288 _ACC	=	0x00e0
                           0000F0   289 _B	=	0x00f0
                           0000FD   290 _A_INV	=	0x00fd
                           000081   291 _SP	=	0x0081
                           000082   292 _DPL	=	0x0082
                           000083   293 _DPH	=	0x0083
                           0000A1   294 _SAFE_MOD	=	0x00a1
                           0000B1   295 _GLOBAL_CFG	=	0x00b1
                           000087   296 _PCON	=	0x0087
                           0000BA   297 _POWER_CFG	=	0x00ba
                           0000B9   298 _CLOCK_CFG	=	0x00b9
                           0000A9   299 _WAKE_CTRL	=	0x00a9
                           0000FE   300 _RESET_KEEP	=	0x00fe
                           0000FF   301 _WDOG_COUNT	=	0x00ff
                           0000A8   302 _IE	=	0x00a8
                           0000B8   303 _IP	=	0x00b8
                           0000E8   304 _IE_EX	=	0x00e8
                           0000E9   305 _IP_EX	=	0x00e9
                           0000B2   306 _GPIO_IE	=	0x00b2
                           008584   307 _ROM_ADDR	=	0x8584
                           000084   308 _ROM_ADDR_L	=	0x0084
                           000085   309 _ROM_ADDR_H	=	0x0085
                           008F8E   310 _ROM_DATA_HI	=	0x8f8e
                           00008E   311 _ROM_DATA_HL	=	0x008e
                           00008F   312 _ROM_DATA_HH	=	0x008f
                           000086   313 _ROM_CTRL	=	0x0086
                           000080   314 _P0	=	0x0080
                           0000C4   315 _P0_MOD_OC	=	0x00c4
                           0000C5   316 _P0_DIR_PU	=	0x00c5
                           000090   317 _P1	=	0x0090
                           000092   318 _P1_MOD_OC	=	0x0092
                           000093   319 _P1_DIR_PU	=	0x0093
                           0000A0   320 _P2	=	0x00a0
                           000094   321 _P2_MOD_OC	=	0x0094
                           000095   322 _P2_DIR_PU	=	0x0095
                           0000B0   323 _P3	=	0x00b0
                           000096   324 _P3_MOD_OC	=	0x0096
                           000097   325 _P3_DIR_PU	=	0x0097
                           0000C0   326 _P4	=	0x00c0
                           0000C2   327 _P4_MOD_OC	=	0x00c2
                           0000C3   328 _P4_DIR_PU	=	0x00c3
                           0000C1   329 _P4_LED_KEY	=	0x00c1
                           0000AA   330 _P5_IN	=	0x00aa
                           0000AB   331 _P5_OUT_PU	=	0x00ab
                           0000AC   332 _P5_DIR	=	0x00ac
                           0000AD   333 _P6_IN	=	0x00ad
                           0000AE   334 _P6_OUT_PU	=	0x00ae
                           0000AF   335 _P6_DIR	=	0x00af
                           0000F1   336 _P7	=	0x00f1
                           0000A2   337 _XBUS_AUX	=	0x00a2
                           000088   338 _TCON	=	0x0088
                           000089   339 _TMOD	=	0x0089
                           00008A   340 _TL0	=	0x008a
                           00008B   341 _TL1	=	0x008b
                           00008C   342 _TH0	=	0x008c
                           00008D   343 _TH1	=	0x008d
                           000098   344 _SCON	=	0x0098
                           000099   345 _SBUF	=	0x0099
                           0000C8   346 _T2CON	=	0x00c8
                           0000C9   347 _T2MOD	=	0x00c9
                           00CBCA   348 _RCAP2	=	0xcbca
                           0000CA   349 _RCAP2L	=	0x00ca
                           0000CB   350 _RCAP2H	=	0x00cb
                           00CDCC   351 _T2COUNT	=	0xcdcc
                           0000CC   352 _TL2	=	0x00cc
                           0000CD   353 _TH2	=	0x00cd
                           00CFCE   354 _T2CAP1	=	0xcfce
                           0000CE   355 _T2CAP1L	=	0x00ce
                           0000CF   356 _T2CAP1H	=	0x00cf
                           0000F8   357 _SPI0_STAT	=	0x00f8
                           0000F9   358 _SPI0_DATA	=	0x00f9
                           0000FA   359 _SPI0_CTRL	=	0x00fa
                           0000FB   360 _SPI0_CK_SE	=	0x00fb
                           0000FC   361 _SPI0_SETUP	=	0x00fc
                           0000BC   362 _SCON1	=	0x00bc
                           0000BD   363 _SBUF1	=	0x00bd
                           0000BE   364 _SBAUD1	=	0x00be
                           0000BF   365 _SIF1	=	0x00bf
                           0000B4   366 _SPI1_STAT	=	0x00b4
                           0000B5   367 _SPI1_DATA	=	0x00b5
                           0000B6   368 _SPI1_CTRL	=	0x00b6
                           0000B7   369 _SPI1_CK_SE	=	0x00b7
                           0000F3   370 _ADC_CTRL	=	0x00f3
                           00F5F4   371 _ADC_DAT	=	0xf5f4
                           0000F4   372 _ADC_DAT_L	=	0x00f4
                           0000F5   373 _ADC_DAT_H	=	0x00f5
                           0000F6   374 _ADC_CHAN	=	0x00f6
                           0000A6   375 _LED_COMMON	=	0x00a6
                           0000A7   376 _LED_PWM_OE	=	0x00a7
                           00C7C6   377 _LED_DMA	=	0xc7c6
                           0000C6   378 _LED_DMA_L	=	0x00c6
                           0000C7   379 _LED_DMA_H	=	0x00c7
                           0000F7   380 _LED_STATUS	=	0x00f7
                           0000B3   381 _I2CX_INT	=	0x00b3
                           0000BB   382 _I2CS_INT_ST	=	0x00bb
                                    383 ;--------------------------------------------------------
                                    384 ; special function bits
                                    385 ;--------------------------------------------------------
                                    386 	.area RSEG    (ABS,DATA)
      000000                        387 	.org 0x0000
                           0000D7   388 _CY	=	0x00d7
                           0000D6   389 _AC	=	0x00d6
                           0000D5   390 _F0	=	0x00d5
                           0000D4   391 _RS1	=	0x00d4
                           0000D3   392 _RS0	=	0x00d3
                           0000D2   393 _OV	=	0x00d2
                           0000D1   394 _F1	=	0x00d1
                           0000D0   395 _P	=	0x00d0
                           0000AF   396 _EA	=	0x00af
                           0000AE   397 _E_DIS	=	0x00ae
                           0000AD   398 _ET2	=	0x00ad
                           0000AC   399 _ES	=	0x00ac
                           0000AB   400 _ET1	=	0x00ab
                           0000AA   401 _EX1	=	0x00aa
                           0000A9   402 _ET0	=	0x00a9
                           0000A8   403 _EX0	=	0x00a8
                           0000BF   404 _PH_FLAG	=	0x00bf
                           0000BE   405 _PL_FLAG	=	0x00be
                           0000BD   406 _PT2	=	0x00bd
                           0000BC   407 _PS	=	0x00bc
                           0000BB   408 _PT1	=	0x00bb
                           0000BA   409 _PX1	=	0x00ba
                           0000B9   410 _PT0	=	0x00b9
                           0000B8   411 _PX0	=	0x00b8
                           0000EF   412 _IE_WDOG	=	0x00ef
                           0000EE   413 _IE_GPIO	=	0x00ee
                           0000ED   414 _IE_PWM_I2C	=	0x00ed
                           0000EC   415 _IE_UART1	=	0x00ec
                           0000EB   416 _IE_ADC	=	0x00eb
                           0000E9   417 _IE_USB	=	0x00e9
                           0000E8   418 _IE_SPI0	=	0x00e8
                           000087   419 _P0_7	=	0x0087
                           000086   420 _P0_6	=	0x0086
                           000085   421 _P0_5	=	0x0085
                           000084   422 _P0_4	=	0x0084
                           000083   423 _P0_3	=	0x0083
                           000082   424 _P0_2	=	0x0082
                           000081   425 _P0_1	=	0x0081
                           000080   426 _P0_0	=	0x0080
                           000081   427 _SDA0	=	0x0081
                           000080   428 _SCL0	=	0x0080
                           000083   429 _TXD_	=	0x0083
                           000082   430 _RXD_	=	0x0082
                           000085   431 _AIN13	=	0x0085
                           000084   432 _AIN12	=	0x0084
                           000083   433 _AIN11	=	0x0083
                           000082   434 _AIN10	=	0x0082
                           000081   435 _AIN9	=	0x0081
                           000080   436 _AIN8	=	0x0080
                           000097   437 _P1_7	=	0x0097
                           000096   438 _P1_6	=	0x0096
                           000095   439 _P1_5	=	0x0095
                           000094   440 _P1_4	=	0x0094
                           000093   441 _P1_3	=	0x0093
                           000092   442 _P1_2	=	0x0092
                           000091   443 _P1_1	=	0x0091
                           000090   444 _P1_0	=	0x0090
                           000097   445 _TXD1_	=	0x0097
                           000096   446 _RXD1_	=	0x0096
                           000097   447 _SCK	=	0x0097
                           000096   448 _MISO	=	0x0096
                           000095   449 _MOSI	=	0x0095
                           000094   450 _SCS	=	0x0094
                           000092   451 _INT0_	=	0x0092
                           000091   452 _T2EX	=	0x0091
                           000091   453 _CAP2	=	0x0091
                           000090   454 _T2	=	0x0090
                           000090   455 _CAP1	=	0x0090
                           000097   456 _AIN7	=	0x0097
                           000096   457 _AIN6	=	0x0096
                           000095   458 _AIN5	=	0x0095
                           000094   459 _AIN4	=	0x0094
                           000093   460 _AIN3	=	0x0093
                           000092   461 _AIN2	=	0x0092
                           000091   462 _AIN1	=	0x0091
                           000090   463 _AIN0	=	0x0090
                           0000A7   464 _P2_7	=	0x00a7
                           0000A6   465 _P2_6	=	0x00a6
                           0000A5   466 _P2_5	=	0x00a5
                           0000A4   467 _P2_4	=	0x00a4
                           0000A3   468 _P2_3	=	0x00a3
                           0000A2   469 _P2_2	=	0x00a2
                           0000A1   470 _P2_1	=	0x00a1
                           0000A0   471 _P2_0	=	0x00a0
                           0000A7   472 _TXD1	=	0x00a7
                           0000A6   473 _RXD1	=	0x00a6
                           0000A5   474 _T2EX_	=	0x00a5
                           0000A5   475 _CAP2_	=	0x00a5
                           0000A4   476 _T2_	=	0x00a4
                           0000A4   477 _CAP1_	=	0x00a4
                           0000B7   478 _P3_7	=	0x00b7
                           0000B6   479 _P3_6	=	0x00b6
                           0000B5   480 _P3_5	=	0x00b5
                           0000B4   481 _P3_4	=	0x00b4
                           0000B3   482 _P3_3	=	0x00b3
                           0000B2   483 _P3_2	=	0x00b2
                           0000B1   484 _P3_1	=	0x00b1
                           0000B0   485 _P3_0	=	0x00b0
                           0000B7   486 _SCK1	=	0x00b7
                           0000B6   487 _MISO1	=	0x00b6
                           0000B5   488 _MOSI1	=	0x00b5
                           0000B5   489 _T1	=	0x00b5
                           0000B4   490 _T0	=	0x00b4
                           0000B3   491 _INT1	=	0x00b3
                           0000B2   492 _INT0	=	0x00b2
                           0000B1   493 _TXD	=	0x00b1
                           0000B0   494 _RXD	=	0x00b0
                           0000C6   495 _P4_6	=	0x00c6
                           0000C5   496 _P4_5	=	0x00c5
                           0000C4   497 _P4_4	=	0x00c4
                           0000C3   498 _P4_3	=	0x00c3
                           0000C2   499 _P4_2	=	0x00c2
                           0000C1   500 _P4_1	=	0x00c1
                           0000C0   501 _P4_0	=	0x00c0
                           00008F   502 _TF1	=	0x008f
                           00008E   503 _TR1	=	0x008e
                           00008D   504 _TF0	=	0x008d
                           00008C   505 _TR0	=	0x008c
                           00008B   506 _IE1	=	0x008b
                           00008A   507 _IT1	=	0x008a
                           000089   508 _IE0	=	0x0089
                           000088   509 _IT0	=	0x0088
                           00009F   510 _SM0	=	0x009f
                           00009E   511 _SM1	=	0x009e
                           00009D   512 _SM2	=	0x009d
                           00009C   513 _REN	=	0x009c
                           00009B   514 _TB8	=	0x009b
                           00009A   515 _RB8	=	0x009a
                           000099   516 _TI	=	0x0099
                           000098   517 _RI	=	0x0098
                           0000CF   518 _TF2	=	0x00cf
                           0000CF   519 _CAP1F	=	0x00cf
                           0000CE   520 _EXF2	=	0x00ce
                           0000CD   521 _RCLK	=	0x00cd
                           0000CC   522 _TCLK	=	0x00cc
                           0000CB   523 _EXEN2	=	0x00cb
                           0000CA   524 _TR2	=	0x00ca
                           0000C9   525 _C_T2	=	0x00c9
                           0000C8   526 _CP_RL2	=	0x00c8
                           0000FF   527 _S0_FST_ACT	=	0x00ff
                           0000FE   528 _S0_IF_OV	=	0x00fe
                           0000FD   529 _S0_IF_FIRST	=	0x00fd
                           0000FC   530 _S0_IF_BYTE	=	0x00fc
                           0000FB   531 _S0_FREE	=	0x00fb
                           0000FA   532 _S0_T_FIFO	=	0x00fa
                           0000F8   533 _S0_R_FIFO	=	0x00f8
                           0000F7   534 _ADC_START	=	0x00f7
                                    535 ;--------------------------------------------------------
                                    536 ; overlayable register banks
                                    537 ;--------------------------------------------------------
                                    538 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        539 	.ds 8
                                    540 ;--------------------------------------------------------
                                    541 ; internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area DSEG    (DATA)
      000046                        544 _vial_handle_cmd_sloc0_1_0:
      000046                        545 	.ds 2
      000048                        546 _vial_handle_cmd_sloc1_1_0:
      000048                        547 	.ds 2
      00004A                        548 _vial_handle_cmd_sloc2_1_0:
      00004A                        549 	.ds 2
      00004C                        550 _vial_handle_cmd_sloc3_1_0:
      00004C                        551 	.ds 2
                                    552 ;--------------------------------------------------------
                                    553 ; overlayable items in internal ram
                                    554 ;--------------------------------------------------------
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
                                    568 ;--------------------------------------------------------
                                    569 ; paged external ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area PSEG    (PAG,XDATA)
                                    572 ;--------------------------------------------------------
                                    573 ; uninitialized external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XSEG    (XDATA)
      000CC3                        576 _vial_unlock_timer:
      000CC3                        577 	.ds 4
      000CC7                        578 _vial_unlock_holding:
      000CC7                        579 	.ds 1
      000CC8                        580 _vial_keycode_firewall_in_10000_619:
      000CC8                        581 	.ds 2
      000CCA                        582 _vial_fill_packet_PARM_2:
      000CCA                        583 	.ds 1
      000CCB                        584 _vial_fill_packet_msg_10000_622:
      000CCB                        585 	.ds 2
      000CCD                        586 _vial_handle_cmd_PARM_2:
      000CCD                        587 	.ds 1
      000CCE                        588 _vial_handle_cmd_data_10000_627:
      000CCE                        589 	.ds 3
      000CD1                        590 _vial_handle_cmd_entry_70000_655:
      000CD1                        591 	.ds 10
      000CDB                        592 _vial_handle_cmd_entry_70000_656:
      000CDB                        593 	.ds 10
      000CE5                        594 _vial_handle_cmd_entry_70000_658:
      000CE5                        595 	.ds 10
      000CEF                        596 _vial_handle_cmd_entry_70000_659:
      000CEF                        597 	.ds 10
      000CF9                        598 _g_vial_magic_keycode_override::
      000CF9                        599 	.ds 2
      000CFB                        600 _vial_keycode_down_keycode_10000_661:
      000CFB                        601 	.ds 2
      000CFD                        602 _vial_keycode_down_dummy_event_30000_668:
      000CFD                        603 	.ds 6
      000D03                        604 _vial_keycode_up_keycode_10000_669:
      000D03                        605 	.ds 2
      000D05                        606 _vial_keycode_up_dummy_event_30000_676:
      000D05                        607 	.ds 6
      000D0B                        608 _vial_keycode_tap_keycode_10000_677:
      000D0B                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
      000EA4                        618 _vial_unlocked::
      000EA4                        619 	.ds 1
      000EA5                        620 _vial_unlock_in_progress::
      000EA5                        621 	.ds 1
      000EA6                        622 _vial_unlock_counter:
      000EA6                        623 	.ds 1
      000EA7                        624 _vial_unlock_combo_rows:
      000EA7                        625 	.ds 2
      000EA9                        626 _vial_unlock_combo_cols:
      000EA9                        627 	.ds 2
                                    628 	.area HOME    (CODE)
                                    629 	.area GSINIT0 (CODE)
                                    630 	.area GSINIT1 (CODE)
                                    631 	.area GSINIT2 (CODE)
                                    632 	.area GSINIT3 (CODE)
                                    633 	.area GSINIT4 (CODE)
                                    634 	.area GSINIT5 (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area CSEG    (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; global & static initialisations
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area GSINIT  (CODE)
                                    643 	.area GSFINAL (CODE)
                                    644 	.area GSINIT  (CODE)
                                    645 ;--------------------------------------------------------
                                    646 ; Home
                                    647 ;--------------------------------------------------------
                                    648 	.area HOME    (CODE)
                                    649 	.area HOME    (CODE)
                                    650 ;--------------------------------------------------------
                                    651 ; code
                                    652 ;--------------------------------------------------------
                                    653 	.area CSEG    (CODE)
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    656 ;------------------------------------------------------------
                                    657 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    658 ;------------------------------------------------------------
                                    659 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    660 ;	-----------------------------------------
                           000007   661 	ar7 = 0x07
                           000006   662 	ar6 = 0x06
                           000005   663 	ar5 = 0x05
                           000004   664 	ar4 = 0x04
                           000003   665 	ar3 = 0x03
                           000002   666 	ar2 = 0x02
                           000001   667 	ar1 = 0x01
                           000000   668 	ar0 = 0x00
                                    669 ;	 function vial_unlock_task
                                    670 ;	-----------------------------------------
      00B1B2                        671 _vial_unlock_task:
                                    672 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B1B2 90 0E A5         [24]  673 	mov	dptr,#_vial_unlock_in_progress
      00B1B5 E0               [24]  674 	movx	a,@dptr
      00B1B6 70 01            [24]  675 	jnz	00131$
      00B1B8 22               [24]  676 	ret
                                    677 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B1B9                        678 00131$:
      00B1B9 7F 00            [12]  679 	mov	r7,#0x00
      00B1BB                        680 00115$:
      00B1BB BF 02 00         [24]  681 	cjne	r7,#0x02,00184$
      00B1BE                        682 00184$:
      00B1BE 50 29            [24]  683 	jnc	00105$
                                    684 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B1C0 EF               [12]  685 	mov	a,r7
      00B1C1 12 B8 39         [24]  686 	lcall	_ak820_outline_0135
      00B1C4 FE               [12]  687 	mov	r6,a
      00B1C5 EF               [12]  688 	mov	a,r7
      00B1C6 12 B8 2E         [24]  689 	lcall	_ak820_outline_0134
      00B1C9 90 07 C0         [24]  690 	mov	dptr,#_matrix_is_on_PARM_2
      00B1CC F0               [24]  691 	movx	@dptr,a
      00B1CD 8E 82            [24]  692 	mov	dpl, r6
      00B1CF C0 07            [24]  693 	push	ar7
      00B1D1 12 5D D4         [24]  694 	lcall	_matrix_is_on
      00B1D4 E5 82            [12]  695 	mov	a, dpl
      00B1D6 D0 07            [24]  696 	pop	ar7
      00B1D8 70 0C            [24]  697 	jnz	00116$
                                    698 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B1DA 90 0C C7         [24]  699 	mov	dptr,#_vial_unlock_holding
      00B1DD E4               [12]  700 	clr	a
      00B1DE F0               [24]  701 	movx	@dptr,a
                                    702 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B1DF 90 0E A6         [24]  703 	mov	dptr,#_vial_unlock_counter
      00B1E2 74 1E            [12]  704 	mov	a,#0x1e
      00B1E4 F0               [24]  705 	movx	@dptr,a
                                    706 ;	quantum/vial.c:69: return;
      00B1E5 22               [24]  707 	ret
      00B1E6                        708 00116$:
                                    709 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B1E6 0F               [12]  710 	inc	r7
      00B1E7 80 D2            [24]  711 	sjmp	00115$
      00B1E9                        712 00105$:
                                    713 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B1E9 90 0C C7         [24]  714 	mov	dptr,#_vial_unlock_holding
      00B1EC E0               [24]  715 	movx	a,@dptr
      00B1ED 70 12            [24]  716 	jnz	00107$
                                    717 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B1EF 90 0C C7         [24]  718 	mov	dptr,#_vial_unlock_holding
      00B1F2 74 01            [12]  719 	mov	a,#0x01
      00B1F4 F0               [24]  720 	movx	@dptr,a
                                    721 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B1F5 12 4D C2         [24]  722 	lcall	_timer_read32
      00B1F8 12 53 D3         [24]  723 	lcall	_ak820_outline_0062
      00B1FB 90 0C C3         [24]  724 	mov	dptr,#_vial_unlock_timer
      00B1FE 12 96 46         [24]  725 	lcall	_ak820_outline_0008
      00B201                        726 00107$:
                                    727 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B201 90 0C C3         [24]  728 	mov	dptr,#_vial_unlock_timer
      00B204 12 53 C2         [24]  729 	lcall	_ak820_outline_0059
      00B207 12 4E 1B         [24]  730 	lcall	_timer_elapsed32
      00B20A 12 53 D3         [24]  731 	lcall	_ak820_outline_0062
                                    732 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B20D 7B 1E            [12]  733 	mov	r3,#0x1e
      00B20F                        734 00109$:
      00B20F EB               [12]  735 	mov	a,r3
      00B210 60 22            [24]  736 	jz	00111$
      00B212 C3               [12]  737 	clr	c
      00B213 EC               [12]  738 	mov	a,r4
      00B214 94 64            [12]  739 	subb	a,#0x64
      00B216 ED               [12]  740 	mov	a,r5
      00B217 94 00            [12]  741 	subb	a,#0x00
      00B219 EE               [12]  742 	mov	a,r6
      00B21A 94 00            [12]  743 	subb	a,#0x00
      00B21C EF               [12]  744 	mov	a,r7
      00B21D 94 00            [12]  745 	subb	a,#0x00
      00B21F 40 13            [24]  746 	jc	00111$
                                    747 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B221 EC               [12]  748 	mov	a,r4
      00B222 24 9C            [12]  749 	add	a,#0x9c
      00B224 FC               [12]  750 	mov	r4,a
      00B225 ED               [12]  751 	mov	a,r5
      00B226 34 FF            [12]  752 	addc	a,#0xff
      00B228 FD               [12]  753 	mov	r5,a
      00B229 EE               [12]  754 	mov	a,r6
      00B22A 34 FF            [12]  755 	addc	a,#0xff
      00B22C FE               [12]  756 	mov	r6,a
      00B22D EF               [12]  757 	mov	a,r7
      00B22E 34 FF            [12]  758 	addc	a,#0xff
      00B230 FF               [12]  759 	mov	r7,a
                                    760 ;	quantum/vial.c:82: --counter;
      00B231 1B               [12]  761 	dec	r3
      00B232 80 DB            [24]  762 	sjmp	00109$
      00B234                        763 00111$:
                                    764 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B234 90 0E A6         [24]  765 	mov	dptr,#_vial_unlock_counter
      00B237 EB               [12]  766 	mov	a,r3
      00B238 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:85: if (!counter) {
      00B239 EB               [12]  769 	mov	a,r3
      00B23A 70 0A            [24]  770 	jnz	00117$
                                    771 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B23C 90 0E A5         [24]  772 	mov	dptr,#_vial_unlock_in_progress
      00B23F E4               [12]  773 	clr	a
      00B240 F0               [24]  774 	movx	@dptr,a
                                    775 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B241 90 0E A4         [24]  776 	mov	dptr,#_vial_unlocked
      00B244 04               [12]  777 	inc	a
      00B245 F0               [24]  778 	movx	@dptr,a
      00B246                        779 00117$:
                                    780 ;	quantum/vial.c:90: }
      00B246 22               [24]  781 	ret
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'vial_init'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/vial.c:117: void vial_init(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function vial_init
                                    788 ;	-----------------------------------------
      00B247                        789 _vial_init:
                                    790 ;	quantum/vial.c:125: reload_combo();
      00B247 12 35 37         [24]  791 	lcall	_ak820_combo_reload
                                    792 ;	quantum/vial.c:128: reload_key_override();
                                    793 ;	quantum/vial.c:130: }
      00B24A 02 3C AB         [24]  794 	ljmp	_ak820_key_override_reload
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    797 ;------------------------------------------------------------
                                    798 ;in            Allocated with name '_vial_keycode_firewall_in_10000_619'
                                    799 ;------------------------------------------------------------
                                    800 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    801 ;	-----------------------------------------
                                    802 ;	 function vial_keycode_firewall
                                    803 ;	-----------------------------------------
      00B24D                        804 _vial_keycode_firewall:
      00B24D 12 38 42         [24]  805 	lcall	_ak820_outline_0108
      00B250 90 0C C8         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_619
      00B253 12 38 47         [24]  807 	lcall	_ak820_outline_0109
                                    808 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B256 90 0C C8         [24]  809 	mov	dptr,#_vial_keycode_firewall_in_10000_619
      00B259 12 37 C4         [24]  810 	lcall	_ak820_outline_0010
      00B25C BC 00 0D         [24]  811 	cjne	r4,#0x00,00102$
      00B25F BD 7C 0A         [24]  812 	cjne	r5,#0x7c,00102$
      00B262 90 0E A4         [24]  813 	mov	dptr,#_vial_unlocked
      00B265 E0               [24]  814 	movx	a,@dptr
      00B266 70 04            [24]  815 	jnz	00102$
                                    816 ;	quantum/vial.c:134: return 0;
      00B268 90 00 00         [24]  817 	mov	dptr,#0x0000
      00B26B 22               [24]  818 	ret
      00B26C                        819 00102$:
                                    820 ;	quantum/vial.c:135: return in;
      00B26C 12 48 48         [24]  821 	lcall	_ak820_outline_0123
                                    822 ;	quantum/vial.c:136: }
      00B26F 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'vial_fill_packet'
                                    826 ;------------------------------------------------------------
                                    827 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    828 ;msg           Allocated with name '_vial_fill_packet_msg_10000_622'
                                    829 ;i             Allocated with name '_vial_fill_packet_i_20000_624'
                                    830 ;------------------------------------------------------------
                                    831 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    832 ;	-----------------------------------------
                                    833 ;	 function vial_fill_packet
                                    834 ;	-----------------------------------------
      00B270                        835 _vial_fill_packet:
      00B270 12 38 42         [24]  836 	lcall	_ak820_outline_0108
      00B273 90 0C CB         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_622
      00B276 12 38 47         [24]  838 	lcall	_ak820_outline_0109
                                    839 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B279 90 0C CB         [24]  840 	mov	dptr,#_vial_fill_packet_msg_10000_622
      00B27C 12 37 F9         [24]  841 	lcall	_ak820_outline_0056
      00B27F 90 0C CA         [24]  842 	mov	dptr,#_vial_fill_packet_PARM_2
      00B282 E0               [24]  843 	movx	a,@dptr
      00B283 FD               [12]  844 	mov	r5,a
      00B284 7C 00            [12]  845 	mov	r4,#0x00
      00B286                        846 00103$:
      00B286 BC 20 00         [24]  847 	cjne	r4,#0x20,00122$
      00B289                        848 00122$:
      00B289 50 09            [24]  849 	jnc	00105$
      00B28B EC               [12]  850 	mov	a,r4
      00B28C 12 37 F1         [24]  851 	lcall	_ak820_outline_0033
      00B28F ED               [12]  852 	mov	a,r5
      00B290 F0               [24]  853 	movx	@dptr,a
      00B291 0C               [12]  854 	inc	r4
      00B292 80 F2            [24]  855 	sjmp	00103$
      00B294                        856 00105$:
                                    857 ;	quantum/vial.c:141: }
      00B294 22               [24]  858 	ret
                                    859 ;------------------------------------------------------------
                                    860 ;Allocation info for local variables in function 'vial_release_held_state'
                                    861 ;------------------------------------------------------------
                                    862 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    863 ;	-----------------------------------------
                                    864 ;	 function vial_release_held_state
                                    865 ;	-----------------------------------------
      00B295                        866 _vial_release_held_state:
                                    867 ;	quantum/vial.c:174: repeat_key_cancel();
      00B295 12 A6 C1         [24]  868 	lcall	_repeat_key_cancel
                                    869 ;	quantum/vial.c:176: clear_keyboard();
                                    870 ;	quantum/vial.c:177: }
      00B298 02 7A 9F         [24]  871 	ljmp	_clear_keyboard
                                    872 ;------------------------------------------------------------
                                    873 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    874 ;------------------------------------------------------------
                                    875 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    876 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    877 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    878 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    879 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    880 ;data          Allocated with name '_vial_handle_cmd_data_10000_627'
                                    881 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_628'
                                    882 ;i             Allocated with name '_vial_handle_cmd_i_50000_633'
                                    883 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_634'
                                    884 ;page          Allocated with name '_vial_handle_cmd_page_40001_637'
                                    885 ;start         Allocated with name '_vial_handle_cmd_start_40002_639'
                                    886 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_639'
                                    887 ;count         Allocated with name '_vial_handle_cmd_count_40002_639'
                                    888 ;i             Allocated with name '_vial_handle_cmd_i_50002_640'
                                    889 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_641'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_641'
                                    891 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_641'
                                    892 ;i             Allocated with name '_vial_handle_cmd_i_50000_644'
                                    893 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_655'
                                    894 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_655'
                                    895 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_656'
                                    896 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_656'
                                    897 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_658'
                                    898 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_658'
                                    899 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_659'
                                    900 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_659'
                                    901 ;------------------------------------------------------------
                                    902 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    903 ;	-----------------------------------------
                                    904 ;	 function vial_handle_cmd
                                    905 ;	-----------------------------------------
      00B29B                        906 _vial_handle_cmd:
      00B29B 12 48 05         [24]  907 	lcall	_ak820_outline_0040
      00B29E 90 0C CE         [24]  908 	mov	dptr,#_vial_handle_cmd_data_10000_627
      00B2A1 12 37 E1         [24]  909 	lcall	_ak820_outline_0019
                                    910 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B2A4 90 0C CE         [24]  911 	mov	dptr,#_vial_handle_cmd_data_10000_627
      00B2A7 12 37 F9         [24]  912 	lcall	_ak820_outline_0056
                                    913 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B2AA 90 0C CD         [24]  914 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B2AD E0               [24]  915 	movx	a,@dptr
      00B2AE FD               [12]  916 	mov	r5,a
      00B2AF BD 20 02         [24]  917 	cjne	r5,#0x20,00255$
      00B2B2 80 01            [24]  918 	sjmp	00102$
      00B2B4                        919 00255$:
                                    920 ;	quantum/vial.c:190: return;
      00B2B4 22               [24]  921 	ret
      00B2B5                        922 00102$:
                                    923 ;	quantum/vial.c:193: switch (msg[1]) {
      00B2B5 74 01            [12]  924 	mov	a,#0x01
      00B2B7 12 3F FB         [24]  925 	lcall	_ak820_outline_0009
      00B2BA FB               [12]  926 	mov  r3,a
      00B2BB 24 F2            [12]  927 	add	a,#0xff - 0x0d
      00B2BD 50 01            [24]  928 	jnc	00256$
      00B2BF 22               [24]  929 	ret
      00B2C0                        930 00256$:
                                    931 ;	free result
      00B2C0 EB               [12]  932 	mov	a,r3
      00B2C1 24 0A            [12]  933 	add	a,#(00257$-3-.)
      00B2C3 83               [24]  934 	movc	a,@a+pc
      00B2C4 F5 82            [12]  935 	mov	dpl,a
      00B2C6 EB               [12]  936 	mov	a,r3
      00B2C7 24 12            [12]  937 	add	a,#(00258$-3-.)
      00B2C9 83               [24]  938 	movc	a,@a+pc
      00B2CA F5 83            [12]  939 	mov	dph,a
      00B2CC E4               [12]  940 	clr	a
      00B2CD 73               [24]  941 	jmp	@a+dptr
      00B2CE                        942 00257$:
      00B2CE EA                     943 	.db	00103$
      00B2CF 32                     944 	.db	00105$
      00B2D0 47                     945 	.db	00106$
      00B2D1 D2                     946 	.db	00112$
      00B2D2 58                     947 	.db	00113$
      00B2D3 A2                     948 	.db	00114$
      00B2D4 11                     949 	.db	00116$
      00B2D5 2C                     950 	.db	00119$
      00B2D6 4C                     951 	.db	00120$
      00B2D7 5A                     952 	.db	00121$
      00B2D8 1A                     953 	.db	00143$
      00B2D9 1A                     954 	.db	00143$
      00B2DA 1A                     955 	.db	00143$
      00B2DB 65                     956 	.db	00122$
      00B2DC                        957 00258$:
      00B2DC B2                     958 	.db	00103$>>8
      00B2DD B3                     959 	.db	00105$>>8
      00B2DE B3                     960 	.db	00106$>>8
      00B2DF B3                     961 	.db	00112$>>8
      00B2E0 B4                     962 	.db	00113$>>8
      00B2E1 B4                     963 	.db	00114$>>8
      00B2E2 B5                     964 	.db	00116$>>8
      00B2E3 B5                     965 	.db	00119$>>8
      00B2E4 B5                     966 	.db	00120$>>8
      00B2E5 B5                     967 	.db	00121$>>8
      00B2E6 B7                     968 	.db	00143$>>8
      00B2E7 B7                     969 	.db	00143$>>8
      00B2E8 B7                     970 	.db	00143$>>8
      00B2E9 B5                     971 	.db	00122$>>8
                                    972 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B2EA                        973 00103$:
                                    974 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B2EA 90 0C CA         [24]  975 	mov	dptr,#_vial_fill_packet_PARM_2
      00B2ED E4               [12]  976 	clr	a
      00B2EE 12 48 29         [24]  977 	lcall	_ak820_outline_0066
      00B2F1 C0 07            [24]  978 	push	ar7
      00B2F3 C0 06            [24]  979 	push	ar6
      00B2F5 12 B2 70         [24]  980 	lcall	_vial_fill_packet
      00B2F8 D0 06            [24]  981 	pop	ar6
      00B2FA D0 07            [24]  982 	pop	ar7
                                    983 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B2FC 12 48 48         [24]  984 	lcall	_ak820_outline_0123
      00B2FF 74 06            [12]  985 	mov	a,#0x06
      00B301 12 48 29         [24]  986 	lcall	_ak820_outline_0066
                                    987 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B304 A3               [24]  988 	inc	dptr
      00B305 E4               [12]  989 	clr	a
      00B306 12 47 FD         [24]  990 	lcall	_ak820_outline_0025
                                    991 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B309 12 47 FD         [24]  992 	lcall	_ak820_outline_0025
                                    993 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B30C A3               [24]  994 	inc	dptr
      00B30D F0               [24]  995 	movx	@dptr,a
                                    996 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B30E FB               [12]  997 	mov	r3,a
      00B30F                        998 00135$:
      00B30F BB 08 00         [24]  999 	cjne	r3,#0x08,00259$
      00B312                       1000 00259$:
      00B312 50 15            [24] 1001 	jnc	00104$
      00B314 8B 02            [24] 1002 	mov	ar2,r3
      00B316 74 04            [12] 1003 	mov	a,#0x04
      00B318 2A               [12] 1004 	add	a, r2
      00B319 2E               [12] 1005 	add	a, r6
      00B31A F9               [12] 1006 	mov	r1,a
      00B31B E4               [12] 1007 	clr	a
      00B31C 3F               [12] 1008 	addc	a,r7
      00B31D FA               [12] 1009 	mov	r2,a
      00B31E EB               [12] 1010 	mov	a,r3
      00B31F 90 C4 D4         [24] 1011 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_632
      00B322 93               [24] 1012 	movc	a,@a+dptr
      00B323 12 70 C5         [24] 1013 	lcall	_ak820_outline_0145
      00B326 0B               [12] 1014 	inc	r3
      00B327 80 E6            [24] 1015 	sjmp	00135$
      00B329                       1016 00104$:
                                   1017 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B329 74 0C            [12] 1018 	mov	a,#0x0c
      00B32B 12 37 F1         [24] 1019 	lcall	_ak820_outline_0033
      00B32E 74 01            [12] 1020 	mov	a,#0x01
      00B330 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	quantum/vial.c:207: break;
      00B331 22               [24] 1023 	ret
                                   1024 ;	quantum/vial.c:210: case vial_get_size: {
      00B332                       1025 00105$:
                                   1026 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B332 12 48 48         [24] 1027 	lcall	_ak820_outline_0123
      00B335 74 7C            [12] 1028 	mov	a,#0x7c
      00B337 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B338 12 38 4C         [24] 1031 	lcall	_ak820_outline_0126
      00B33B 74 01            [12] 1032 	mov	a,#0x01
      00B33D 12 47 FD         [24] 1033 	lcall	_ak820_outline_0025
                                   1034 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B340 E4               [12] 1035 	clr	a
      00B341 12 47 FD         [24] 1036 	lcall	_ak820_outline_0025
                                   1037 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B344 A3               [24] 1038 	inc	dptr
      00B345 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	quantum/vial.c:216: break;
      00B346 22               [24] 1041 	ret
                                   1042 ;	quantum/vial.c:219: case vial_get_def: {
      00B347                       1043 00106$:
                                   1044 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B347 12 40 1C         [24] 1045 	lcall	_ak820_outline_0017
      00B34A FB               [12] 1046 	mov	r3,a
      00B34B 12 47 F3         [24] 1047 	lcall	_ak820_outline_0012
      00B34E E0               [24] 1048 	movx	a,@dptr
      00B34F 4B               [12] 1049 	orl	a,r3
      00B350 60 01            [24] 1050 	jz	00108$
      00B352 22               [24] 1051 	ret
      00B353                       1052 00108$:
                                   1053 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B353 12 37 E9         [24] 1054 	lcall	_ak820_outline_0032
      00B356 FB               [12] 1055 	mov	r3,a
      00B357 7A 00            [12] 1056 	mov	r2,#0x00
      00B359 12 40 06         [24] 1057 	lcall	_ak820_outline_0015
      00B35C F9               [12] 1058 	mov	r1,a
      00B35D E4               [12] 1059 	clr	a
      00B35E 42 03            [12] 1060 	orl	ar3,a
      00B360 E9               [12] 1061 	mov	a,r1
      00B361 42 02            [12] 1062 	orl	ar2,a
                                   1063 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B363 C3               [12] 1064 	clr	c
      00B364 EB               [12] 1065 	mov	a,r3
      00B365 94 0C            [12] 1066 	subb	a,#0x0c
      00B367 EA               [12] 1067 	mov	a,r2
      00B368 94 00            [12] 1068 	subb	a,#0x00
      00B36A 40 01            [24] 1069 	jc	00110$
      00B36C 22               [24] 1070 	ret
      00B36D                       1071 00110$:
                                   1072 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B36D EA               [12] 1073 	mov	a,r2
      00B36E C4               [12] 1074 	swap	a
      00B36F 23               [12] 1075 	rl	a
      00B370 54 E0            [12] 1076 	anl	a,#0xe0
      00B372 CB               [12] 1077 	xch	a,r3
      00B373 C4               [12] 1078 	swap	a
      00B374 23               [12] 1079 	rl	a
      00B375 CB               [12] 1080 	xch	a,r3
      00B376 6B               [12] 1081 	xrl	a,r3
      00B377 CB               [12] 1082 	xch	a,r3
      00B378 54 E0            [12] 1083 	anl	a,#0xe0
      00B37A CB               [12] 1084 	xch	a,r3
      00B37B 6B               [12] 1085 	xrl	a,r3
      00B37C FA               [12] 1086 	mov	r2,a
      00B37D 8B 46            [24] 1087 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B37F 8A 47            [24] 1088 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1089 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B381 74 7C            [12] 1090 	mov	a,#0x7c
      00B383 C3               [12] 1091 	clr	c
      00B384 95 46            [12] 1092 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B386 F8               [12] 1093 	mov	r0,a
      00B387 74 01            [12] 1094 	mov	a,#0x01
      00B389 95 47            [12] 1095 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B38B F9               [12] 1096 	mov	r1,a
                                   1097 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B38C C3               [12] 1098 	clr	c
      00B38D E8               [12] 1099 	mov	a,r0
      00B38E 94 20            [12] 1100 	subb	a,#0x20
      00B390 E9               [12] 1101 	mov	a,r1
      00B391 94 00            [12] 1102 	subb	a,#0x00
      00B393 40 02            [24] 1103 	jc	00146$
      00B395 78 20            [12] 1104 	mov	r0,#0x20
      00B397                       1105 00146$:
                                   1106 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B397 79 00            [12] 1107 	mov	r1,#0x00
      00B399                       1108 00138$:
      00B399 C3               [12] 1109 	clr	c
      00B39A E9               [12] 1110 	mov	a,r1
      00B39B 98               [12] 1111 	subb	a,r0
      00B39C 40 01            [24] 1112 	jc	00264$
      00B39E 22               [24] 1113 	ret
      00B39F                       1114 00264$:
      00B39F C0 00            [24] 1115 	push	ar0
      00B3A1 E9               [12] 1116 	mov	a,r1
      00B3A2 2E               [12] 1117 	add	a, r6
      00B3A3 F5 48            [12] 1118 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B3A5 E4               [12] 1119 	clr	a
      00B3A6 3F               [12] 1120 	addc	a, r7
      00B3A7 F5 49            [12] 1121 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B3A9 89 4A            [24] 1122 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B3AB 75 4B 00         [24] 1123 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B3AE A8 46            [24] 1124 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B3B0 AB 47            [24] 1125 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B3B2 E5 4A            [12] 1126 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B3B4 28               [12] 1127 	add	a, r0
      00B3B5 F8               [12] 1128 	mov	r0,a
      00B3B6 E5 4B            [12] 1129 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B3B8 3B               [12] 1130 	addc	a, r3
      00B3B9 FB               [12] 1131 	mov	r3,a
      00B3BA E8               [12] 1132 	mov	a,r0
      00B3BB 24 58            [12] 1133 	add	a, #_keyboard_definition
      00B3BD F5 82            [12] 1134 	mov	dpl,a
      00B3BF EB               [12] 1135 	mov	a,r3
      00B3C0 34 C3            [12] 1136 	addc	a, #(_keyboard_definition >> 8)
      00B3C2 F5 83            [12] 1137 	mov	dph,a
      00B3C4 E4               [12] 1138 	clr	a
      00B3C5 93               [24] 1139 	movc	a,@a+dptr
      00B3C6 85 48 82         [24] 1140 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B3C9 85 49 83         [24] 1141 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B3CC F0               [24] 1142 	movx	@dptr,a
      00B3CD 09               [12] 1143 	inc	r1
      00B3CE D0 00            [24] 1144 	pop	ar0
                                   1145 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B3D0 80 C7            [24] 1146 	sjmp	00138$
      00B3D2                       1147 00112$:
                                   1148 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B3D2 74 02            [12] 1149 	mov	a,#0x02
      00B3D4 12 4D 48         [24] 1150 	lcall	_ak820_outline_0051
      00B3D7 F5 4A            [12] 1151 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1152 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B3D9 74 03            [12] 1153 	mov	a,#0x03
      00B3DB 2E               [12] 1154 	add	a, r6
      00B3DC F5 48            [12] 1155 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B3DE E4               [12] 1156 	clr	a
      00B3DF 3F               [12] 1157 	addc	a, r7
      00B3E0 F5 49            [12] 1158 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B3E2 85 48 82         [24] 1159 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B3E5 85 49 83         [24] 1160 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B3E8 E0               [24] 1161 	movx	a,@dptr
                                   1162 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B3E9 F5 46            [12] 1163 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B3EB 90 0B 64         [24] 1164 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B3EE F0               [24] 1165 	movx	@dptr,a
      00B3EF 90 0B 65         [24] 1166 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B3F2 E4               [12] 1167 	clr	a
      00B3F3 F0               [24] 1168 	movx	@dptr,a
      00B3F4 85 4A 82         [24] 1169 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B3F7 C0 07            [24] 1170 	push	ar7
      00B3F9 C0 06            [24] 1171 	push	ar6
      00B3FB C0 05            [24] 1172 	push	ar5
      00B3FD C0 04            [24] 1173 	push	ar4
      00B3FF C0 03            [24] 1174 	push	ar3
      00B401 C0 02            [24] 1175 	push	ar2
      00B403 12 89 84         [24] 1176 	lcall	_dynamic_keymap_get_encoder
      00B406 85 82 4C         [24] 1177 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B409 85 83 4D         [24] 1178 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B40C D0 02            [24] 1179 	pop	ar2
      00B40E D0 03            [24] 1180 	pop	ar3
      00B410 D0 04            [24] 1181 	pop	ar4
      00B412 D0 05            [24] 1182 	pop	ar5
      00B414 D0 06            [24] 1183 	pop	ar6
      00B416 D0 07            [24] 1184 	pop	ar7
                                   1185 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B418 A9 4D            [24] 1186 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B41A 12 48 48         [24] 1187 	lcall	_ak820_outline_0123
      00B41D E9               [12] 1188 	mov	a,r1
      00B41E F0               [24] 1189 	movx	@dptr,a
                                   1190 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B41F A8 4C            [24] 1191 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B421 12 38 4C         [24] 1192 	lcall	_ak820_outline_0126
      00B424 E8               [12] 1193 	mov	a,r0
      00B425 F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B426 90 0B 64         [24] 1196 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B429 E5 46            [12] 1197 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B42B F0               [24] 1198 	movx	@dptr,a
      00B42C 90 0B 65         [24] 1199 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B42F 74 01            [12] 1200 	mov	a,#0x01
      00B431 F0               [24] 1201 	movx	@dptr,a
      00B432 85 4A 82         [24] 1202 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B435 C0 03            [24] 1203 	push	ar3
      00B437 C0 02            [24] 1204 	push	ar2
      00B439 12 89 84         [24] 1205 	lcall	_dynamic_keymap_get_encoder
      00B43C 85 82 4C         [24] 1206 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B43F 85 83 4D         [24] 1207 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B442 D0 02            [24] 1208 	pop	ar2
      00B444 D0 03            [24] 1209 	pop	ar3
                                   1210 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B446 A9 4D            [24] 1211 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B448 12 48 64         [24] 1212 	lcall	_ak820_outline_0149
      00B44B E9               [12] 1213 	mov	a,r1
      00B44C F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B44D A8 4C            [24] 1216 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B44F 85 48 82         [24] 1217 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B452 85 49 83         [24] 1218 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B455 E8               [12] 1219 	mov	a,r0
      00B456 F0               [24] 1220 	movx	@dptr,a
                                   1221 ;	quantum/vial.c:255: break;
      00B457 22               [24] 1222 	ret
                                   1223 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B458                       1224 00113$:
                                   1225 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B458 12 37 E9         [24] 1226 	lcall	_ak820_outline_0032
      00B45B F5 48            [12] 1227 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B45D 12 40 06         [24] 1228 	lcall	_ak820_outline_0015
      00B460 F5 4A            [12] 1229 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B462 12 40 1C         [24] 1230 	lcall	_ak820_outline_0017
                                   1231 ;	assignBit
      00B465 24 FF            [12] 1232 	add	a,#0xff
      00B467 E4               [12] 1233 	clr	a
      00B468 33               [12] 1234 	rlc	a
      00B469 F5 4C            [12] 1235 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B46B 12 47 F3         [24] 1236 	lcall	_ak820_outline_0012
      00B46E E0               [24] 1237 	movx	a,@dptr
      00B46F F9               [12] 1238 	mov	r1,a
      00B470 78 00            [12] 1239 	mov	r0,#0x00
      00B472 74 06            [12] 1240 	mov	a,#0x06
      00B474 12 37 CE         [24] 1241 	lcall	_ak820_outline_0013
      00B477 7B 00            [12] 1242 	mov	r3,#0x00
      00B479 42 00            [12] 1243 	orl	ar0,a
      00B47B EB               [12] 1244 	mov	a,r3
      00B47C 42 01            [12] 1245 	orl	ar1,a
      00B47E 12 38 6C         [24] 1246 	lcall	_ak820_outline_0162
      00B481 12 B2 4D         [24] 1247 	lcall	_vial_keycode_firewall
      00B484 AA 82            [24] 1248 	mov	r2, dpl
      00B486 AB 83            [24] 1249 	mov	r3, dph
      00B488 90 0B 67         [24] 1250 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B48B E5 4A            [12] 1251 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B48D F0               [24] 1252 	movx	@dptr,a
      00B48E 90 0B 68         [24] 1253 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B491 E5 4C            [12] 1254 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B493 F0               [24] 1255 	movx	@dptr,a
      00B494 90 0B 69         [24] 1256 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B497 EA               [12] 1257 	mov	a,r2
      00B498 F0               [24] 1258 	movx	@dptr,a
      00B499 EB               [12] 1259 	mov	a,r3
      00B49A A3               [24] 1260 	inc	dptr
      00B49B F0               [24] 1261 	movx	@dptr,a
      00B49C 85 48 82         [24] 1262 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1263 ;	quantum/vial.c:259: break;
      00B49F 02 89 EB         [24] 1264 	ljmp	_dynamic_keymap_set_encoder
                                   1265 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B4A2                       1266 00114$:
                                   1267 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B4A2 90 0C CA         [24] 1268 	mov	dptr,#_vial_fill_packet_PARM_2
      00B4A5 74 FF            [12] 1269 	mov	a,#0xff
      00B4A7 12 48 29         [24] 1270 	lcall	_ak820_outline_0066
      00B4AA C0 07            [24] 1271 	push	ar7
      00B4AC C0 06            [24] 1272 	push	ar6
      00B4AE 12 B2 70         [24] 1273 	lcall	_vial_fill_packet
      00B4B1 D0 06            [24] 1274 	pop	ar6
      00B4B3 D0 07            [24] 1275 	pop	ar7
                                   1276 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B4B5 90 0E A4         [24] 1277 	mov	dptr,#_vial_unlocked
      00B4B8 E0               [24] 1278 	movx	a,@dptr
      00B4B9 12 48 48         [24] 1279 	lcall	_ak820_outline_0123
      00B4BC F0               [24] 1280 	movx	@dptr,a
                                   1281 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B4BD 74 01            [12] 1282 	mov	a,#0x01
      00B4BF 2E               [12] 1283 	add	a, r6
      00B4C0 FA               [12] 1284 	mov	r2,a
      00B4C1 E4               [12] 1285 	clr	a
      00B4C2 3F               [12] 1286 	addc	a, r7
      00B4C3 FB               [12] 1287 	mov	r3,a
      00B4C4 90 0E A5         [24] 1288 	mov	dptr,#_vial_unlock_in_progress
      00B4C7 E0               [24] 1289 	movx	a,@dptr
      00B4C8 12 48 64         [24] 1290 	lcall	_ak820_outline_0149
      00B4CB F0               [24] 1291 	movx	@dptr,a
                                   1292 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B4CC 7B 00            [12] 1293 	mov	r3,#0x00
      00B4CE                       1294 00141$:
      00B4CE BB 02 00         [24] 1295 	cjne	r3,#0x02,00265$
      00B4D1                       1296 00265$:
      00B4D1 40 01            [24] 1297 	jc	00266$
      00B4D3 22               [24] 1298 	ret
      00B4D4                       1299 00266$:
                                   1300 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B4D4 8B 01            [24] 1301 	mov	ar1,r3
      00B4D6 7A 00            [12] 1302 	mov	r2,#0x00
      00B4D8 E9               [12] 1303 	mov	a,r1
      00B4D9 29               [12] 1304 	add	a,r1
      00B4DA F5 4C            [12] 1305 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B4DC EA               [12] 1306 	mov	a,r2
      00B4DD 33               [12] 1307 	rlc	a
      00B4DE F5 4D            [12] 1308 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B4E0 74 02            [12] 1309 	mov	a,#0x02
      00B4E2 25 4C            [12] 1310 	add	a, _vial_handle_cmd_sloc3_1_0
      00B4E4 F8               [12] 1311 	mov	r0,a
      00B4E5 E4               [12] 1312 	clr	a
      00B4E6 35 4D            [12] 1313 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B4E8 FA               [12] 1314 	mov	r2,a
      00B4E9 E8               [12] 1315 	mov	a,r0
      00B4EA 2E               [12] 1316 	add	a, r6
      00B4EB F8               [12] 1317 	mov	r0,a
      00B4EC EA               [12] 1318 	mov	a,r2
      00B4ED 3F               [12] 1319 	addc	a, r7
      00B4EE FA               [12] 1320 	mov	r2,a
      00B4EF EB               [12] 1321 	mov	a,r3
      00B4F0 12 B8 39         [24] 1322 	lcall	_ak820_outline_0135
      00B4F3 88 82            [24] 1323 	mov	dpl,r0
      00B4F5 8A 83            [24] 1324 	mov	dph,r2
      00B4F7 F0               [24] 1325 	movx	@dptr,a
                                   1326 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B4F8 74 03            [12] 1327 	mov	a,#0x03
      00B4FA 25 4C            [12] 1328 	add	a, _vial_handle_cmd_sloc3_1_0
      00B4FC F9               [12] 1329 	mov	r1,a
      00B4FD E4               [12] 1330 	clr	a
      00B4FE 35 4D            [12] 1331 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B500 FA               [12] 1332 	mov	r2,a
      00B501 E9               [12] 1333 	mov	a,r1
      00B502 2E               [12] 1334 	add	a, r6
      00B503 F9               [12] 1335 	mov	r1,a
      00B504 EA               [12] 1336 	mov	a,r2
      00B505 3F               [12] 1337 	addc	a, r7
      00B506 FA               [12] 1338 	mov	r2,a
      00B507 EB               [12] 1339 	mov	a,r3
      00B508 12 B8 2E         [24] 1340 	lcall	_ak820_outline_0134
      00B50B 12 70 C5         [24] 1341 	lcall	_ak820_outline_0145
                                   1342 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B50E 0B               [12] 1343 	inc	r3
                                   1344 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B50F 80 BD            [24] 1345 	sjmp	00141$
      00B511                       1346 00116$:
                                   1347 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B511 90 0E A5         [24] 1348 	mov	dptr,#_vial_unlock_in_progress
      00B514 E0               [24] 1349 	movx	a,@dptr
      00B515 70 03            [24] 1350 	jnz	00118$
      00B517 12 B2 95         [24] 1351 	lcall	_vial_release_held_state
      00B51A                       1352 00118$:
                                   1353 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B51A 90 0E A5         [24] 1354 	mov	dptr,#_vial_unlock_in_progress
      00B51D 74 01            [12] 1355 	mov	a,#0x01
      00B51F F0               [24] 1356 	movx	@dptr,a
                                   1357 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B520 90 0E A6         [24] 1358 	mov	dptr,#_vial_unlock_counter
      00B523 74 1E            [12] 1359 	mov	a,#0x1e
      00B525 F0               [24] 1360 	movx	@dptr,a
                                   1361 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B526 90 0C C7         [24] 1362 	mov	dptr,#_vial_unlock_holding
      00B529 E4               [12] 1363 	clr	a
      00B52A F0               [24] 1364 	movx	@dptr,a
                                   1365 ;	quantum/vial.c:287: break;
      00B52B 22               [24] 1366 	ret
                                   1367 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B52C                       1368 00119$:
                                   1369 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B52C 90 0E A4         [24] 1370 	mov	dptr,#_vial_unlocked
      00B52F E0               [24] 1371 	movx	a,@dptr
      00B530 12 48 48         [24] 1372 	lcall	_ak820_outline_0123
      00B533 F0               [24] 1373 	movx	@dptr,a
                                   1374 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B534 90 0E A5         [24] 1375 	mov	dptr,#_vial_unlock_in_progress
      00B537 E0               [24] 1376 	movx	a,@dptr
      00B538 12 38 4C         [24] 1377 	lcall	_ak820_outline_0126
      00B53B F0               [24] 1378 	movx	@dptr,a
                                   1379 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B53C 74 02            [12] 1380 	mov	a,#0x02
      00B53E 2E               [12] 1381 	add	a, r6
      00B53F FA               [12] 1382 	mov	r2,a
      00B540 E4               [12] 1383 	clr	a
      00B541 3F               [12] 1384 	addc	a, r7
      00B542 FB               [12] 1385 	mov	r3,a
      00B543 90 0E A6         [24] 1386 	mov	dptr,#_vial_unlock_counter
      00B546 E0               [24] 1387 	movx	a,@dptr
      00B547 12 48 64         [24] 1388 	lcall	_ak820_outline_0149
      00B54A F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vial.c:293: break;
      00B54B 22               [24] 1391 	ret
                                   1392 ;	quantum/vial.c:295: case vial_lock: {
      00B54C                       1393 00120$:
                                   1394 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B54C 90 0E A4         [24] 1395 	mov	dptr,#_vial_unlocked
      00B54F E4               [12] 1396 	clr	a
      00B550 F0               [24] 1397 	movx	@dptr,a
                                   1398 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B551 90 0E A5         [24] 1399 	mov	dptr,#_vial_unlock_in_progress
      00B554 F0               [24] 1400 	movx	@dptr,a
                                   1401 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B555 90 0C C7         [24] 1402 	mov	dptr,#_vial_unlock_holding
      00B558 F0               [24] 1403 	movx	@dptr,a
                                   1404 ;	quantum/vial.c:301: break;
      00B559 22               [24] 1405 	ret
                                   1406 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B55A                       1407 00121$:
                                   1408 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B55A 90 0C CA         [24] 1409 	mov	dptr,#_vial_fill_packet_PARM_2
      00B55D 74 FF            [12] 1410 	mov	a,#0xff
      00B55F 12 48 29         [24] 1411 	lcall	_ak820_outline_0066
                                   1412 ;	quantum/vial.c:314: break;
      00B562 02 B2 70         [24] 1413 	ljmp	_vial_fill_packet
                                   1414 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B565                       1415 00122$:
                                   1416 ;	quantum/vial.c:347: switch (msg[2]) {
      00B565 12 37 E9         [24] 1417 	lcall	_ak820_outline_0032
      00B568 FB               [12] 1418 	mov  r3,a
      00B569 24 F9            [12] 1419 	add	a,#0xff - 0x06
      00B56B 50 01            [24] 1420 	jnc	00268$
      00B56D 22               [24] 1421 	ret
      00B56E                       1422 00268$:
                                   1423 ;	free result
      00B56E EB               [12] 1424 	mov	a,r3
      00B56F 2B               [12] 1425 	add	a,r3
      00B570 2B               [12] 1426 	add	a,r3
      00B571 90 B5 75         [24] 1427 	mov	dptr,#00269$
      00B574 73               [24] 1428 	jmp	@a+dptr
      00B575                       1429 00269$:
      00B575 02 B5 8A         [24] 1430 	ljmp	00123$
      00B578 02 B7 1A         [24] 1431 	ljmp	00143$
      00B57B 02 B7 1A         [24] 1432 	ljmp	00143$
      00B57E 02 B5 B3         [24] 1433 	ljmp	00124$
      00B581 02 B6 15         [24] 1434 	ljmp	00125$
      00B584 02 B6 73         [24] 1435 	ljmp	00128$
      00B587 02 B6 D5         [24] 1436 	ljmp	00129$
                                   1437 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B58A                       1438 00123$:
                                   1439 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B58A 90 0C CA         [24] 1440 	mov	dptr,#_vial_fill_packet_PARM_2
      00B58D E4               [12] 1441 	clr	a
      00B58E 12 48 29         [24] 1442 	lcall	_ak820_outline_0066
      00B591 C0 07            [24] 1443 	push	ar7
      00B593 C0 06            [24] 1444 	push	ar6
      00B595 12 B2 70         [24] 1445 	lcall	_vial_fill_packet
      00B598 D0 06            [24] 1446 	pop	ar6
      00B59A D0 07            [24] 1447 	pop	ar7
                                   1448 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B59C 12 48 48         [24] 1449 	lcall	_ak820_outline_0123
      00B59F E4               [12] 1450 	clr	a
      00B5A0 12 48 29         [24] 1451 	lcall	_ak820_outline_0066
                                   1452 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B5A3 A3               [24] 1453 	inc	dptr
      00B5A4 74 08            [12] 1454 	mov	a,#0x08
      00B5A6 12 47 FD         [24] 1455 	lcall	_ak820_outline_0025
                                   1456 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B5A9 F0               [24] 1457 	movx	@dptr,a
                                   1458 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B5AA 74 1F            [12] 1459 	mov	a,#0x1f
      00B5AC 12 37 F1         [24] 1460 	lcall	_ak820_outline_0033
      00B5AF 74 01            [12] 1461 	mov	a,#0x01
      00B5B1 F0               [24] 1462 	movx	@dptr,a
                                   1463 ;	quantum/vial.c:356: break;
      00B5B2 22               [24] 1464 	ret
                                   1465 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B5B3                       1466 00124$:
                                   1467 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B5B3 12 40 06         [24] 1468 	lcall	_ak820_outline_0015
      00B5B6 FB               [12] 1469 	mov	r3,a
                                   1470 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B5B7 90 0C D1         [24] 1471 	mov	dptr,#_vial_handle_cmd_entry_70000_655
      00B5BA 12 53 F4         [24] 1472 	lcall	_ak820_outline_0155
      00B5BD 90 0C D3         [24] 1473 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0002)
      00B5C0 F0               [24] 1474 	movx	@dptr,a
      00B5C1 A3               [24] 1475 	inc	dptr
      00B5C2 F0               [24] 1476 	movx	@dptr,a
      00B5C3 90 0C D5         [24] 1477 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0004)
      00B5C6 F0               [24] 1478 	movx	@dptr,a
      00B5C7 A3               [24] 1479 	inc	dptr
      00B5C8 F0               [24] 1480 	movx	@dptr,a
      00B5C9 90 0C D7         [24] 1481 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0006)
      00B5CC F0               [24] 1482 	movx	@dptr,a
      00B5CD A3               [24] 1483 	inc	dptr
      00B5CE F0               [24] 1484 	movx	@dptr,a
      00B5CF 90 0C D9         [24] 1485 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0008)
      00B5D2 F0               [24] 1486 	movx	@dptr,a
      00B5D3 A3               [24] 1487 	inc	dptr
      00B5D4 F0               [24] 1488 	movx	@dptr,a
                                   1489 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B5D5 90 0B 6C         [24] 1490 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B5D8 74 D1            [12] 1491 	mov	a,#_vial_handle_cmd_entry_70000_655
      00B5DA F0               [24] 1492 	movx	@dptr,a
      00B5DB 74 0C            [12] 1493 	mov	a,#(_vial_handle_cmd_entry_70000_655 >> 8)
      00B5DD 12 38 1E         [24] 1494 	lcall	_ak820_outline_0076
      00B5E0 8B 82            [24] 1495 	mov	dpl, r3
      00B5E2 C0 07            [24] 1496 	push	ar7
      00B5E4 C0 06            [24] 1497 	push	ar6
      00B5E6 C0 05            [24] 1498 	push	ar5
      00B5E8 C0 04            [24] 1499 	push	ar4
      00B5EA 12 8A 57         [24] 1500 	lcall	_dynamic_keymap_get_combo
      00B5ED AA 82            [24] 1501 	mov	r2, dpl
      00B5EF D0 04            [24] 1502 	pop	ar4
      00B5F1 D0 05            [24] 1503 	pop	ar5
      00B5F3 D0 06            [24] 1504 	pop	ar6
      00B5F5 D0 07            [24] 1505 	pop	ar7
      00B5F7 12 48 48         [24] 1506 	lcall	_ak820_outline_0123
      00B5FA EA               [12] 1507 	mov	a,r2
      00B5FB F0               [24] 1508 	movx	@dptr,a
                                   1509 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B5FC 8C 01            [24] 1510 	mov	ar1,r4
      00B5FE 8D 02            [24] 1511 	mov	ar2,r5
      00B600 7B 00            [12] 1512 	mov	r3,#0x00
      00B602 90 0E 21         [24] 1513 	mov	dptr,#___memcpy_PARM_2
      00B605 74 D1            [12] 1514 	mov	a,#_vial_handle_cmd_entry_70000_655
      00B607 F0               [24] 1515 	movx	@dptr,a
      00B608 74 0C            [12] 1516 	mov	a,#(_vial_handle_cmd_entry_70000_655 >> 8)
      00B60A 12 B8 06         [24] 1517 	lcall	_ak820_outline_0011
      00B60D 12 48 6E         [24] 1518 	lcall	_ak820_outline_0163
      00B610 8B F0            [24] 1519 	mov	b, r3
                                   1520 ;	quantum/vial.c:387: break;
      00B612 02 BD DA         [24] 1521 	ljmp	___memcpy
                                   1522 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B615                       1523 00125$:
                                   1524 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B615 12 40 06         [24] 1525 	lcall	_ak820_outline_0015
      00B618 FB               [12] 1526 	mov	r3,a
                                   1527 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B619 74 04            [12] 1528 	mov	a,#0x04
      00B61B 2E               [12] 1529 	add	a, r6
      00B61C F9               [12] 1530 	mov	r1,a
      00B61D E4               [12] 1531 	clr	a
      00B61E 3F               [12] 1532 	addc	a, r7
      00B61F FA               [12] 1533 	mov	r2,a
      00B620 90 0E 21         [24] 1534 	mov	dptr,#___memcpy_PARM_2
      00B623 E9               [12] 1535 	mov	a,r1
      00B624 F0               [24] 1536 	movx	@dptr,a
      00B625 EA               [12] 1537 	mov	a,r2
      00B626 12 B8 06         [24] 1538 	lcall	_ak820_outline_0011
      00B629 90 0C DB         [24] 1539 	mov	dptr,#_vial_handle_cmd_entry_70000_656
      00B62C F5 F0            [12] 1540 	mov	b,a
      00B62E C0 07            [24] 1541 	push	ar7
      00B630 C0 06            [24] 1542 	push	ar6
      00B632 C0 03            [24] 1543 	push	ar3
      00B634 12 BD DA         [24] 1544 	lcall	___memcpy
                                   1545 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B637 90 0C E3         [24] 1546 	mov	dptr,#(_vial_handle_cmd_entry_70000_656 + 0x0008)
      00B63A E0               [24] 1547 	movx	a,@dptr
      00B63B F9               [12] 1548 	mov	r1,a
      00B63C A3               [24] 1549 	inc	dptr
      00B63D E0               [24] 1550 	movx	a,@dptr
      00B63E FA               [12] 1551 	mov	r2,a
      00B63F 12 48 6E         [24] 1552 	lcall	_ak820_outline_0163
      00B642 12 B2 4D         [24] 1553 	lcall	_vial_keycode_firewall
      00B645 A9 82            [24] 1554 	mov	r1, dpl
      00B647 AA 83            [24] 1555 	mov	r2, dph
      00B649 D0 03            [24] 1556 	pop	ar3
      00B64B 90 0C E3         [24] 1557 	mov	dptr,#(_vial_handle_cmd_entry_70000_656 + 0x0008)
      00B64E 12 4D 70         [24] 1558 	lcall	_ak820_outline_0144
                                   1559 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B651 90 0B 70         [24] 1560 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B654 74 DB            [12] 1561 	mov	a,#_vial_handle_cmd_entry_70000_656
      00B656 F0               [24] 1562 	movx	@dptr,a
      00B657 74 0C            [12] 1563 	mov	a,#(_vial_handle_cmd_entry_70000_656 >> 8)
      00B659 12 38 1E         [24] 1564 	lcall	_ak820_outline_0076
      00B65C 8B 82            [24] 1565 	mov	dpl, r3
      00B65E 12 8A ED         [24] 1566 	lcall	_dynamic_keymap_set_combo
      00B661 AA 82            [24] 1567 	mov	r2, dpl
      00B663 D0 06            [24] 1568 	pop	ar6
      00B665 D0 07            [24] 1569 	pop	ar7
      00B667 12 48 48         [24] 1570 	lcall	_ak820_outline_0123
      00B66A EA               [12] 1571 	mov	a,r2
      00B66B F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B66C EA               [12] 1574 	mov	a,r2
      00B66D 60 01            [24] 1575 	jz	00270$
      00B66F 22               [24] 1576 	ret
      00B670                       1577 00270$:
                                   1578 ;	quantum/vial.c:396: break;
      00B670 02 35 37         [24] 1579 	ljmp	_ak820_combo_reload
                                   1580 ;	quantum/vial.c:400: case dynamic_vial_key_override_get: {
      00B673                       1581 00128$:
                                   1582 ;	quantum/vial.c:401: uint8_t idx = msg[3];
      00B673 12 40 06         [24] 1583 	lcall	_ak820_outline_0015
      00B676 FB               [12] 1584 	mov	r3,a
                                   1585 ;	quantum/vial.c:402: vial_key_override_entry_t entry = { 0 };
      00B677 90 0C E5         [24] 1586 	mov	dptr,#_vial_handle_cmd_entry_70000_658
      00B67A 12 53 F4         [24] 1587 	lcall	_ak820_outline_0155
      00B67D 90 0C E7         [24] 1588 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0002)
      00B680 F0               [24] 1589 	movx	@dptr,a
      00B681 A3               [24] 1590 	inc	dptr
      00B682 F0               [24] 1591 	movx	@dptr,a
      00B683 90 0C E9         [24] 1592 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0004)
      00B686 F0               [24] 1593 	movx	@dptr,a
      00B687 A3               [24] 1594 	inc	dptr
      00B688 F0               [24] 1595 	movx	@dptr,a
      00B689 90 0C EB         [24] 1596 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0006)
      00B68C F0               [24] 1597 	movx	@dptr,a
      00B68D 90 0C EC         [24] 1598 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0007)
      00B690 F0               [24] 1599 	movx	@dptr,a
      00B691 90 0C ED         [24] 1600 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0008)
      00B694 F0               [24] 1601 	movx	@dptr,a
      00B695 90 0C EE         [24] 1602 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0009)
      00B698 F0               [24] 1603 	movx	@dptr,a
                                   1604 ;	quantum/vial.c:403: msg[0] = dynamic_keymap_get_key_override(idx, &entry);
      00B699 90 0B 7E         [24] 1605 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      00B69C 74 E5            [12] 1606 	mov	a,#_vial_handle_cmd_entry_70000_658
      00B69E F0               [24] 1607 	movx	@dptr,a
      00B69F 74 0C            [12] 1608 	mov	a,#(_vial_handle_cmd_entry_70000_658 >> 8)
      00B6A1 12 38 1E         [24] 1609 	lcall	_ak820_outline_0076
      00B6A4 8B 82            [24] 1610 	mov	dpl, r3
      00B6A6 C0 07            [24] 1611 	push	ar7
      00B6A8 C0 06            [24] 1612 	push	ar6
      00B6AA C0 05            [24] 1613 	push	ar5
      00B6AC C0 04            [24] 1614 	push	ar4
      00B6AE 12 8B 8F         [24] 1615 	lcall	_dynamic_keymap_get_key_override
      00B6B1 AA 82            [24] 1616 	mov	r2, dpl
      00B6B3 D0 04            [24] 1617 	pop	ar4
      00B6B5 D0 05            [24] 1618 	pop	ar5
      00B6B7 D0 06            [24] 1619 	pop	ar6
      00B6B9 D0 07            [24] 1620 	pop	ar7
      00B6BB 12 48 48         [24] 1621 	lcall	_ak820_outline_0123
      00B6BE EA               [12] 1622 	mov	a,r2
      00B6BF F0               [24] 1623 	movx	@dptr,a
                                   1624 ;	quantum/vial.c:404: memcpy(&msg[1], &entry, sizeof(entry));
      00B6C0 7B 00            [12] 1625 	mov	r3,#0x00
      00B6C2 90 0E 21         [24] 1626 	mov	dptr,#___memcpy_PARM_2
      00B6C5 74 E5            [12] 1627 	mov	a,#_vial_handle_cmd_entry_70000_658
      00B6C7 F0               [24] 1628 	movx	@dptr,a
      00B6C8 74 0C            [12] 1629 	mov	a,#(_vial_handle_cmd_entry_70000_658 >> 8)
      00B6CA 12 B8 06         [24] 1630 	lcall	_ak820_outline_0011
      00B6CD 12 38 4C         [24] 1631 	lcall	_ak820_outline_0126
      00B6D0 8B F0            [24] 1632 	mov	b, r3
                                   1633 ;	quantum/vial.c:405: break;
                                   1634 ;	quantum/vial.c:407: case dynamic_vial_key_override_set: {
      00B6D2 02 BD DA         [24] 1635 	ljmp	___memcpy
      00B6D5                       1636 00129$:
                                   1637 ;	quantum/vial.c:408: uint8_t idx = msg[3];
      00B6D5 12 40 06         [24] 1638 	lcall	_ak820_outline_0015
      00B6D8 FD               [12] 1639 	mov	r5,a
                                   1640 ;	quantum/vial.c:410: memcpy(&entry, &msg[4], sizeof(entry));
      00B6D9 74 04            [12] 1641 	mov	a,#0x04
      00B6DB 2E               [12] 1642 	add	a, r6
      00B6DC FB               [12] 1643 	mov	r3,a
      00B6DD E4               [12] 1644 	clr	a
      00B6DE 3F               [12] 1645 	addc	a, r7
      00B6DF FC               [12] 1646 	mov	r4,a
      00B6E0 90 0E 21         [24] 1647 	mov	dptr,#___memcpy_PARM_2
      00B6E3 EB               [12] 1648 	mov	a,r3
      00B6E4 F0               [24] 1649 	movx	@dptr,a
      00B6E5 EC               [12] 1650 	mov	a,r4
      00B6E6 12 B8 06         [24] 1651 	lcall	_ak820_outline_0011
      00B6E9 90 0C EF         [24] 1652 	mov	dptr,#_vial_handle_cmd_entry_70000_659
      00B6EC F5 F0            [12] 1653 	mov	b,a
      00B6EE C0 07            [24] 1654 	push	ar7
      00B6F0 C0 06            [24] 1655 	push	ar6
      00B6F2 C0 05            [24] 1656 	push	ar5
      00B6F4 12 BD DA         [24] 1657 	lcall	___memcpy
      00B6F7 D0 05            [24] 1658 	pop	ar5
                                   1659 ;	quantum/vial.c:414: msg[0] = dynamic_keymap_set_key_override(idx, &entry);
      00B6F9 90 0B 82         [24] 1660 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      00B6FC 74 EF            [12] 1661 	mov	a,#_vial_handle_cmd_entry_70000_659
      00B6FE F0               [24] 1662 	movx	@dptr,a
      00B6FF 74 0C            [12] 1663 	mov	a,#(_vial_handle_cmd_entry_70000_659 >> 8)
      00B701 12 38 1E         [24] 1664 	lcall	_ak820_outline_0076
      00B704 8D 82            [24] 1665 	mov	dpl, r5
      00B706 12 8C 0F         [24] 1666 	lcall	_dynamic_keymap_set_key_override
      00B709 AC 82            [24] 1667 	mov	r4, dpl
      00B70B D0 06            [24] 1668 	pop	ar6
      00B70D D0 07            [24] 1669 	pop	ar7
      00B70F 12 48 48         [24] 1670 	lcall	_ak820_outline_0123
      00B712 EC               [12] 1671 	mov	a,r4
      00B713 F0               [24] 1672 	movx	@dptr,a
                                   1673 ;	quantum/vial.c:415: if (!msg[0]) reload_key_override();
      00B714 EC               [12] 1674 	mov	a,r4
      00B715 70 03            [24] 1675 	jnz	00143$
                                   1676 ;	quantum/vial.c:423: }
                                   1677 ;	quantum/vial.c:424: }
      00B717 02 3C AB         [24] 1678 	ljmp	_ak820_key_override_reload
      00B71A                       1679 00143$:
      00B71A 22               [24] 1680 	ret
                                   1681 ;------------------------------------------------------------
                                   1682 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1683 ;------------------------------------------------------------
                                   1684 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_661'
                                   1685 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_668'
                                   1686 ;------------------------------------------------------------
                                   1687 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1688 ;	-----------------------------------------
                                   1689 ;	 function vial_keycode_down
                                   1690 ;	-----------------------------------------
      00B71B                       1691 _vial_keycode_down:
      00B71B 12 38 42         [24] 1692 	lcall	_ak820_outline_0108
      00B71E 90 0C FB         [24] 1693 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B721 12 38 47         [24] 1694 	lcall	_ak820_outline_0109
                                   1695 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B724 90 0C FB         [24] 1696 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B727 12 37 C4         [24] 1697 	lcall	_ak820_outline_0010
      00B72A 74 E0            [12] 1698 	mov	a,#0x100 - 0x20
      00B72C 2D               [12] 1699 	add	a,r5
      00B72D 50 19            [24] 1700 	jnc	00104$
      00B72F C3               [12] 1701 	clr	c
      00B730 74 FF            [12] 1702 	mov	a,#0xff
      00B732 9C               [12] 1703 	subb	a,r4
      00B733 74 4F            [12] 1704 	mov	a,#0x4f
      00B735 9D               [12] 1705 	subb	a,r5
      00B736 40 10            [24] 1706 	jc	00104$
                                   1707 ;	free result
                                   1708 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B738 90 0C FB         [24] 1709 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B73B EE               [12] 1710 	mov	a,r6
      00B73C 12 38 57         [24] 1711 	lcall	_ak820_outline_0132
                                   1712 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B73F 90 0C FB         [24] 1713 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B742 E0               [24] 1714 	movx	a,@dptr
      00B743 24 FE            [12] 1715 	add	a,#0xff - 0x01
      00B745 40 01            [24] 1716 	jc	00104$
                                   1717 ;	free result
      00B747 22               [24] 1718 	ret
      00B748                       1719 00104$:
                                   1720 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B748 90 0C FB         [24] 1721 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B74B 12 B8 15         [24] 1722 	lcall	_ak820_outline_0026
                                   1723 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B74E 40 06            [24] 1724 	jc	00107$
                                   1725 ;	free result
                                   1726 ;	quantum/vial.c:440: register_code16(keycode);
      00B750 12 48 48         [24] 1727 	lcall	_ak820_outline_0123
      00B753 02 A3 2F         [24] 1728 	ljmp	_register_code16
      00B756                       1729 00107$:
                                   1730 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B756 90 0D 01         [24] 1731 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0004)
      00B759 74 01            [12] 1732 	mov	a,#0x01
      00B75B F0               [24] 1733 	movx	@dptr,a
      00B75C 90 0C FE         [24] 1734 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0001)
      00B75F 74 F0            [12] 1735 	mov	a,#0xf0
      00B761 F0               [24] 1736 	movx	@dptr,a
      00B762 90 0C FD         [24] 1737 	mov	dptr,#_vial_keycode_down_dummy_event_30000_668
      00B765 F0               [24] 1738 	movx	@dptr,a
      00B766 90 0D 02         [24] 1739 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0005)
      00B769 74 01            [12] 1740 	mov	a,#0x01
      00B76B F0               [24] 1741 	movx	@dptr,a
      00B76C 12 4D F3         [24] 1742 	lcall	_timer_read
      00B76F 12 48 53         [24] 1743 	lcall	_ak820_outline_0140
      00B772 43 06 01         [24] 1744 	orl	ar6,#0x01
      00B775 90 0C FF         [24] 1745 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0002)
      00B778 12 4D 63         [24] 1746 	lcall	_ak820_outline_0064
                                   1747 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B77B 90 0C FD         [24] 1748 	mov	dptr,#_vial_keycode_down_dummy_event_30000_668
                                   1749 ;	quantum/vial.c:448: }
      00B77E 02 74 EC         [24] 1750 	ljmp	_ak820_action_exec
                                   1751 ;------------------------------------------------------------
                                   1752 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1753 ;------------------------------------------------------------
                                   1754 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_669'
                                   1755 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_676'
                                   1756 ;------------------------------------------------------------
                                   1757 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1758 ;	-----------------------------------------
                                   1759 ;	 function vial_keycode_up
                                   1760 ;	-----------------------------------------
      00B781                       1761 _vial_keycode_up:
      00B781 12 38 42         [24] 1762 	lcall	_ak820_outline_0108
      00B784 90 0D 03         [24] 1763 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B787 12 38 47         [24] 1764 	lcall	_ak820_outline_0109
                                   1765 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B78A 90 0D 03         [24] 1766 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B78D 12 37 C4         [24] 1767 	lcall	_ak820_outline_0010
      00B790 74 E0            [12] 1768 	mov	a,#0x100 - 0x20
      00B792 2D               [12] 1769 	add	a,r5
      00B793 50 19            [24] 1770 	jnc	00104$
      00B795 C3               [12] 1771 	clr	c
      00B796 74 FF            [12] 1772 	mov	a,#0xff
      00B798 9C               [12] 1773 	subb	a,r4
      00B799 74 4F            [12] 1774 	mov	a,#0x4f
      00B79B 9D               [12] 1775 	subb	a,r5
      00B79C 40 10            [24] 1776 	jc	00104$
                                   1777 ;	free result
                                   1778 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B79E 90 0D 03         [24] 1779 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B7A1 EE               [12] 1780 	mov	a,r6
      00B7A2 12 38 57         [24] 1781 	lcall	_ak820_outline_0132
                                   1782 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B7A5 90 0D 03         [24] 1783 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B7A8 E0               [24] 1784 	movx	a,@dptr
      00B7A9 24 FE            [12] 1785 	add	a,#0xff - 0x01
      00B7AB 40 01            [24] 1786 	jc	00104$
                                   1787 ;	free result
      00B7AD 22               [24] 1788 	ret
      00B7AE                       1789 00104$:
                                   1790 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B7AE 90 0D 03         [24] 1791 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B7B1 12 B8 15         [24] 1792 	lcall	_ak820_outline_0026
                                   1793 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B7B4 40 06            [24] 1794 	jc	00107$
                                   1795 ;	free result
                                   1796 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B7B6 12 48 48         [24] 1797 	lcall	_ak820_outline_0123
      00B7B9 02 A3 73         [24] 1798 	ljmp	_unregister_code16
      00B7BC                       1799 00107$:
                                   1800 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B7BC 90 0D 09         [24] 1801 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0004)
      00B7BF 74 01            [12] 1802 	mov	a,#0x01
      00B7C1 F0               [24] 1803 	movx	@dptr,a
      00B7C2 90 0D 06         [24] 1804 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0001)
      00B7C5 74 F0            [12] 1805 	mov	a,#0xf0
      00B7C7 F0               [24] 1806 	movx	@dptr,a
      00B7C8 90 0D 05         [24] 1807 	mov	dptr,#_vial_keycode_up_dummy_event_30000_676
      00B7CB F0               [24] 1808 	movx	@dptr,a
      00B7CC 90 0D 0A         [24] 1809 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0005)
      00B7CF E4               [12] 1810 	clr	a
      00B7D0 F0               [24] 1811 	movx	@dptr,a
      00B7D1 12 4D F3         [24] 1812 	lcall	_timer_read
      00B7D4 12 48 53         [24] 1813 	lcall	_ak820_outline_0140
      00B7D7 43 06 01         [24] 1814 	orl	ar6,#0x01
      00B7DA 90 0D 07         [24] 1815 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0002)
      00B7DD 12 4D 63         [24] 1816 	lcall	_ak820_outline_0064
                                   1817 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B7E0 90 0D 05         [24] 1818 	mov	dptr,#_vial_keycode_up_dummy_event_30000_676
                                   1819 ;	quantum/vial.c:470: }
      00B7E3 02 74 EC         [24] 1820 	ljmp	_ak820_action_exec
                                   1821 ;------------------------------------------------------------
                                   1822 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1823 ;------------------------------------------------------------
                                   1824 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_677'
                                   1825 ;i             Allocated with name '_vial_keycode_tap_i_30000_680'
                                   1826 ;------------------------------------------------------------
                                   1827 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1828 ;	-----------------------------------------
                                   1829 ;	 function vial_keycode_tap
                                   1830 ;	-----------------------------------------
      00B7E6                       1831 _vial_keycode_tap:
      00B7E6 12 38 42         [24] 1832 	lcall	_ak820_outline_0108
      00B7E9 90 0D 0B         [24] 1833 	mov	dptr,#_vial_keycode_tap_keycode_10000_677
      00B7EC 12 38 47         [24] 1834 	lcall	_ak820_outline_0109
                                   1835 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B7EF 90 0D 0B         [24] 1836 	mov	dptr,#_vial_keycode_tap_keycode_10000_677
      00B7F2 12 37 BA         [24] 1837 	lcall	_ak820_outline_0006
      00B7F5 C0 07            [24] 1838 	push	ar7
      00B7F7 C0 06            [24] 1839 	push	ar6
      00B7F9 12 B7 1B         [24] 1840 	lcall	_vial_keycode_down
      00B7FC D0 06            [24] 1841 	pop	ar6
      00B7FE D0 07            [24] 1842 	pop	ar7
                                   1843 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B800 12 48 48         [24] 1844 	lcall	_ak820_outline_0123
                                   1845 ;	quantum/vial.c:476: }
      00B803 02 B7 81         [24] 1846 	ljmp	_vial_keycode_up
                                   1847 ;------------------------------------------------------------
                                   1848 ;Allocation info for local variables in function 'process_record_vial'
                                   1849 ;------------------------------------------------------------
                                   1850 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1851 ;keycode       Allocated with name '_process_record_vial_keycode_10000_682'
                                   1852 ;------------------------------------------------------------
                                   1853 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1854 ;	-----------------------------------------
                                   1855 	.area CSEG    (CODE)
                                   1856 	.area CONST   (CODE)
                                   1857 	.area CONST   (CODE)
      00C358                       1858 _keyboard_definition:
      00C358 FD                    1859 	.db #0xfd	; 253
      00C359 37                    1860 	.db #0x37	; 55	'7'
      00C35A 7A                    1861 	.db #0x7a	; 122	'z'
      00C35B 58                    1862 	.db #0x58	; 88	'X'
      00C35C 5A                    1863 	.db #0x5a	; 90	'Z'
      00C35D 00                    1864 	.db #0x00	; 0
      00C35E 00                    1865 	.db #0x00	; 0
      00C35F 04                    1866 	.db #0x04	; 4
      00C360 E6                    1867 	.db #0xe6	; 230
      00C361 D6                    1868 	.db #0xd6	; 214
      00C362 B4                    1869 	.db #0xb4	; 180
      00C363 46                    1870 	.db #0x46	; 70	'F'
      00C364 02                    1871 	.db #0x02	; 2
      00C365 00                    1872 	.db #0x00	; 0
      00C366 21                    1873 	.db #0x21	; 33
      00C367 01                    1874 	.db #0x01	; 1
      00C368 00                    1875 	.db #0x00	; 0
      00C369 00                    1876 	.db #0x00	; 0
      00C36A 00                    1877 	.db #0x00	; 0
      00C36B 00                    1878 	.db #0x00	; 0
      00C36C 37                    1879 	.db #0x37	; 55	'7'
      00C36D 27                    1880 	.db #0x27	; 39
      00C36E 97                    1881 	.db #0x97	; 151
      00C36F D6                    1882 	.db #0xd6	; 214
      00C370 E0                    1883 	.db #0xe0	; 224
      00C371 03                    1884 	.db #0x03	; 3
      00C372 CB                    1885 	.db #0xcb	; 203
      00C373 01                    1886 	.db #0x01	; 1
      00C374 3C                    1887 	.db #0x3c	; 60
      00C375 00                    1888 	.db #0x00	; 0
      00C376 00                    1889 	.db #0x00	; 0
      00C377 3D                    1890 	.db #0x3d	; 61
      00C378 88                    1891 	.db #0x88	; 136
      00C379 CD                    1892 	.db #0xcd	; 205
      00C37A A5                    1893 	.db #0xa5	; 165
      00C37B AA                    1894 	.db #0xaa	; 170
      00C37C E5                    1895 	.db #0xe5	; 229
      00C37D A8                    1896 	.db #0xa8	; 168
      00C37E 76                    1897 	.db #0x76	; 118	'v'
      00C37F F6                    1898 	.db #0xf6	; 246
      00C380 43                    1899 	.db #0x43	; 67	'C'
      00C381 0E                    1900 	.db #0x0e	; 14
      00C382 D2                    1901 	.db #0xd2	; 210
      00C383 90                    1902 	.db #0x90	; 144
      00C384 7D                    1903 	.db #0x7d	; 125
      00C385 94                    1904 	.db #0x94	; 148
      00C386 79                    1905 	.db #0x79	; 121	'y'
      00C387 78                    1906 	.db #0x78	; 120	'x'
      00C388 EF                    1907 	.db #0xef	; 239
      00C389 49                    1908 	.db #0x49	; 73	'I'
      00C38A 3E                    1909 	.db #0x3e	; 62
      00C38B EF                    1910 	.db #0xef	; 239
      00C38C FD                    1911 	.db #0xfd	; 253
      00C38D 8F                    1912 	.db #0x8f	; 143
      00C38E EF                    1913 	.db #0xef	; 239
      00C38F 00                    1914 	.db #0x00	; 0
      00C390 C6                    1915 	.db #0xc6	; 198
      00C391 D1                    1916 	.db #0xd1	; 209
      00C392 DB                    1917 	.db #0xdb	; 219
      00C393 FB                    1918 	.db #0xfb	; 251
      00C394 EB                    1919 	.db #0xeb	; 235
      00C395 DE                    1920 	.db #0xde	; 222
      00C396 66                    1921 	.db #0x66	; 102	'f'
      00C397 63                    1922 	.db #0x63	; 99	'c'
      00C398 0C                    1923 	.db #0x0c	; 12
      00C399 92                    1924 	.db #0x92	; 146
      00C39A 7B                    1925 	.db #0x7b	; 123
      00C39B F9                    1926 	.db #0xf9	; 249
      00C39C D4                    1927 	.db #0xd4	; 212
      00C39D 7A                    1928 	.db #0x7a	; 122	'z'
      00C39E 4F                    1929 	.db #0x4f	; 79	'O'
      00C39F 83                    1930 	.db #0x83	; 131
      00C3A0 4B                    1931 	.db #0x4b	; 75	'K'
      00C3A1 86                    1932 	.db #0x86	; 134
      00C3A2 0E                    1933 	.db #0x0e	; 14
      00C3A3 6A                    1934 	.db #0x6a	; 106	'j'
      00C3A4 F2                    1935 	.db #0xf2	; 242
      00C3A5 22                    1936 	.db #0x22	; 34
      00C3A6 22                    1937 	.db #0x22	; 34
      00C3A7 0B                    1938 	.db #0x0b	; 11
      00C3A8 03                    1939 	.db #0x03	; 3
      00C3A9 BA                    1940 	.db #0xba	; 186
      00C3AA 67                    1941 	.db #0x67	; 103	'g'
      00C3AB 9B                    1942 	.db #0x9b	; 155
      00C3AC 7A                    1943 	.db #0x7a	; 122	'z'
      00C3AD E1                    1944 	.db #0xe1	; 225
      00C3AE BC                    1945 	.db #0xbc	; 188
      00C3AF 37                    1946 	.db #0x37	; 55	'7'
      00C3B0 26                    1947 	.db #0x26	; 38
      00C3B1 46                    1948 	.db #0x46	; 70	'F'
      00C3B2 78                    1949 	.db #0x78	; 120	'x'
      00C3B3 05                    1950 	.db #0x05	; 5
      00C3B4 0D                    1951 	.db #0x0d	; 13
      00C3B5 95                    1952 	.db #0x95	; 149
      00C3B6 02                    1953 	.db #0x02	; 2
      00C3B7 E4                    1954 	.db #0xe4	; 228
      00C3B8 18                    1955 	.db #0x18	; 24
      00C3B9 CA                    1956 	.db #0xca	; 202
      00C3BA 33                    1957 	.db #0x33	; 51	'3'
      00C3BB EA                    1958 	.db #0xea	; 234
      00C3BC 24                    1959 	.db #0x24	; 36
      00C3BD C8                    1960 	.db #0xc8	; 200
      00C3BE 81                    1961 	.db #0x81	; 129
      00C3BF 4E                    1962 	.db #0x4e	; 78	'N'
      00C3C0 47                    1963 	.db #0x47	; 71	'G'
      00C3C1 A8                    1964 	.db #0xa8	; 168
      00C3C2 44                    1965 	.db #0x44	; 68	'D'
      00C3C3 DD                    1966 	.db #0xdd	; 221
      00C3C4 91                    1967 	.db #0x91	; 145
      00C3C5 6D                    1968 	.db #0x6d	; 109	'm'
      00C3C6 69                    1969 	.db #0x69	; 105	'i'
      00C3C7 DB                    1970 	.db #0xdb	; 219
      00C3C8 4F                    1971 	.db #0x4f	; 79	'O'
      00C3C9 3A                    1972 	.db #0x3a	; 58
      00C3CA 43                    1973 	.db #0x43	; 67	'C'
      00C3CB 9D                    1974 	.db #0x9d	; 157
      00C3CC 26                    1975 	.db #0x26	; 38
      00C3CD 49                    1976 	.db #0x49	; 73	'I'
      00C3CE 4C                    1977 	.db #0x4c	; 76	'L'
      00C3CF EF                    1978 	.db #0xef	; 239
      00C3D0 2B                    1979 	.db #0x2b	; 43
      00C3D1 D8                    1980 	.db #0xd8	; 216
      00C3D2 55                    1981 	.db #0x55	; 85	'U'
      00C3D3 95                    1982 	.db #0x95	; 149
      00C3D4 70                    1983 	.db #0x70	; 112	'p'
      00C3D5 B1                    1984 	.db #0xb1	; 177
      00C3D6 CC                    1985 	.db #0xcc	; 204
      00C3D7 CF                    1986 	.db #0xcf	; 207
      00C3D8 13                    1987 	.db #0x13	; 19
      00C3D9 32                    1988 	.db #0x32	; 50	'2'
      00C3DA 6A                    1989 	.db #0x6a	; 106	'j'
      00C3DB A1                    1990 	.db #0xa1	; 161
      00C3DC FF                    1991 	.db #0xff	; 255
      00C3DD 99                    1992 	.db #0x99	; 153
      00C3DE 61                    1993 	.db #0x61	; 97	'a'
      00C3DF 95                    1994 	.db #0x95	; 149
      00C3E0 B1                    1995 	.db #0xb1	; 177
      00C3E1 89                    1996 	.db #0x89	; 137
      00C3E2 9B                    1997 	.db #0x9b	; 155
      00C3E3 11                    1998 	.db #0x11	; 17
      00C3E4 D9                    1999 	.db #0xd9	; 217
      00C3E5 35                    2000 	.db #0x35	; 53	'5'
      00C3E6 78                    2001 	.db #0x78	; 120	'x'
      00C3E7 ED                    2002 	.db #0xed	; 237
      00C3E8 CD                    2003 	.db #0xcd	; 205
      00C3E9 94                    2004 	.db #0x94	; 148
      00C3EA 6E                    2005 	.db #0x6e	; 110	'n'
      00C3EB 60                    2006 	.db #0x60	; 96
      00C3EC 8E                    2007 	.db #0x8e	; 142
      00C3ED 63                    2008 	.db #0x63	; 99	'c'
      00C3EE 8B                    2009 	.db #0x8b	; 139
      00C3EF FF                    2010 	.db #0xff	; 255
      00C3F0 4E                    2011 	.db #0x4e	; 78	'N'
      00C3F1 20                    2012 	.db #0x20	; 32
      00C3F2 7A                    2013 	.db #0x7a	; 122	'z'
      00C3F3 B5                    2014 	.db #0xb5	; 181
      00C3F4 87                    2015 	.db #0x87	; 135
      00C3F5 C2                    2016 	.db #0xc2	; 194
      00C3F6 35                    2017 	.db #0x35	; 53	'5'
      00C3F7 A4                    2018 	.db #0xa4	; 164
      00C3F8 6D                    2019 	.db #0x6d	; 109	'm'
      00C3F9 18                    2020 	.db #0x18	; 24
      00C3FA C1                    2021 	.db #0xc1	; 193
      00C3FB A3                    2022 	.db #0xa3	; 163
      00C3FC DB                    2023 	.db #0xdb	; 219
      00C3FD 53                    2024 	.db #0x53	; 83	'S'
      00C3FE 1D                    2025 	.db #0x1d	; 29
      00C3FF EC                    2026 	.db #0xec	; 236
      00C400 F0                    2027 	.db #0xf0	; 240
      00C401 BF                    2028 	.db #0xbf	; 191
      00C402 4A                    2029 	.db #0x4a	; 74	'J'
      00C403 4C                    2030 	.db #0x4c	; 76	'L'
      00C404 4A                    2031 	.db #0x4a	; 74	'J'
      00C405 C4                    2032 	.db #0xc4	; 196
      00C406 AA                    2033 	.db #0xaa	; 170
      00C407 37                    2034 	.db #0x37	; 55	'7'
      00C408 19                    2035 	.db #0x19	; 25
      00C409 34                    2036 	.db #0x34	; 52	'4'
      00C40A 3F                    2037 	.db #0x3f	; 63
      00C40B A1                    2038 	.db #0xa1	; 161
      00C40C D3                    2039 	.db #0xd3	; 211
      00C40D 1A                    2040 	.db #0x1a	; 26
      00C40E 5C                    2041 	.db #0x5c	; 92
      00C40F 03                    2042 	.db #0x03	; 3
      00C410 4D                    2043 	.db #0x4d	; 77	'M'
      00C411 BC                    2044 	.db #0xbc	; 188
      00C412 10                    2045 	.db #0x10	; 16
      00C413 2E                    2046 	.db #0x2e	; 46
      00C414 80                    2047 	.db #0x80	; 128
      00C415 F7                    2048 	.db #0xf7	; 247
      00C416 D6                    2049 	.db #0xd6	; 214
      00C417 82                    2050 	.db #0x82	; 130
      00C418 24                    2051 	.db #0x24	; 36
      00C419 4C                    2052 	.db #0x4c	; 76	'L'
      00C41A 87                    2053 	.db #0x87	; 135
      00C41B B9                    2054 	.db #0xb9	; 185
      00C41C F8                    2055 	.db #0xf8	; 248
      00C41D BE                    2056 	.db #0xbe	; 190
      00C41E 67                    2057 	.db #0x67	; 103	'g'
      00C41F 96                    2058 	.db #0x96	; 150
      00C420 89                    2059 	.db #0x89	; 137
      00C421 30                    2060 	.db #0x30	; 48	'0'
      00C422 C8                    2061 	.db #0xc8	; 200
      00C423 8D                    2062 	.db #0x8d	; 141
      00C424 2C                    2063 	.db #0x2c	; 44
      00C425 F5                    2064 	.db #0xf5	; 245
      00C426 06                    2065 	.db #0x06	; 6
      00C427 05                    2066 	.db #0x05	; 5
      00C428 7C                    2067 	.db #0x7c	; 124
      00C429 48                    2068 	.db #0x48	; 72	'H'
      00C42A 1B                    2069 	.db #0x1b	; 27
      00C42B 76                    2070 	.db #0x76	; 118	'v'
      00C42C AA                    2071 	.db #0xaa	; 170
      00C42D 3D                    2072 	.db #0x3d	; 61
      00C42E 28                    2073 	.db #0x28	; 40
      00C42F FC                    2074 	.db #0xfc	; 252
      00C430 80                    2075 	.db #0x80	; 128
      00C431 75                    2076 	.db #0x75	; 117	'u'
      00C432 EB                    2077 	.db #0xeb	; 235
      00C433 78                    2078 	.db #0x78	; 120	'x'
      00C434 D0                    2079 	.db #0xd0	; 208
      00C435 8A                    2080 	.db #0x8a	; 138
      00C436 8F                    2081 	.db #0x8f	; 143
      00C437 27                    2082 	.db #0x27	; 39
      00C438 F7                    2083 	.db #0xf7	; 247
      00C439 F2                    2084 	.db #0xf2	; 242
      00C43A EB                    2085 	.db #0xeb	; 235
      00C43B 58                    2086 	.db #0x58	; 88	'X'
      00C43C 37                    2087 	.db #0x37	; 55	'7'
      00C43D 3C                    2088 	.db #0x3c	; 60
      00C43E 2B                    2089 	.db #0x2b	; 43
      00C43F 6F                    2090 	.db #0x6f	; 111	'o'
      00C440 0E                    2091 	.db #0x0e	; 14
      00C441 C7                    2092 	.db #0xc7	; 199
      00C442 E2                    2093 	.db #0xe2	; 226
      00C443 A0                    2094 	.db #0xa0	; 160
      00C444 97                    2095 	.db #0x97	; 151
      00C445 EE                    2096 	.db #0xee	; 238
      00C446 FD                    2097 	.db #0xfd	; 253
      00C447 9F                    2098 	.db #0x9f	; 159
      00C448 45                    2099 	.db #0x45	; 69	'E'
      00C449 17                    2100 	.db #0x17	; 23
      00C44A 94                    2101 	.db #0x94	; 148
      00C44B E6                    2102 	.db #0xe6	; 230
      00C44C E7                    2103 	.db #0xe7	; 231
      00C44D FA                    2104 	.db #0xfa	; 250
      00C44E 4C                    2105 	.db #0x4c	; 76	'L'
      00C44F 7A                    2106 	.db #0x7a	; 122	'z'
      00C450 D6                    2107 	.db #0xd6	; 214
      00C451 7A                    2108 	.db #0x7a	; 122	'z'
      00C452 7B                    2109 	.db #0x7b	; 123
      00C453 ED                    2110 	.db #0xed	; 237
      00C454 10                    2111 	.db #0x10	; 16
      00C455 C5                    2112 	.db #0xc5	; 197
      00C456 BC                    2113 	.db #0xbc	; 188
      00C457 E3                    2114 	.db #0xe3	; 227
      00C458 A9                    2115 	.db #0xa9	; 169
      00C459 1F                    2116 	.db #0x1f	; 31
      00C45A CF                    2117 	.db #0xcf	; 207
      00C45B C4                    2118 	.db #0xc4	; 196
      00C45C 9D                    2119 	.db #0x9d	; 157
      00C45D DC                    2120 	.db #0xdc	; 220
      00C45E 45                    2121 	.db #0x45	; 69	'E'
      00C45F 2A                    2122 	.db #0x2a	; 42
      00C460 69                    2123 	.db #0x69	; 105	'i'
      00C461 57                    2124 	.db #0x57	; 87	'W'
      00C462 8F                    2125 	.db #0x8f	; 143
      00C463 EC                    2126 	.db #0xec	; 236
      00C464 85                    2127 	.db #0x85	; 133
      00C465 6C                    2128 	.db #0x6c	; 108	'l'
      00C466 43                    2129 	.db #0x43	; 67	'C'
      00C467 1C                    2130 	.db #0x1c	; 28
      00C468 BA                    2131 	.db #0xba	; 186
      00C469 89                    2132 	.db #0x89	; 137
      00C46A 68                    2133 	.db #0x68	; 104	'h'
      00C46B 4A                    2134 	.db #0x4a	; 74	'J'
      00C46C 1C                    2135 	.db #0x1c	; 28
      00C46D 91                    2136 	.db #0x91	; 145
      00C46E 3F                    2137 	.db #0x3f	; 63
      00C46F D1                    2138 	.db #0xd1	; 209
      00C470 B3                    2139 	.db #0xb3	; 179
      00C471 96                    2140 	.db #0x96	; 150
      00C472 1D                    2141 	.db #0x1d	; 29
      00C473 7C                    2142 	.db #0x7c	; 124
      00C474 14                    2143 	.db #0x14	; 20
      00C475 77                    2144 	.db #0x77	; 119	'w'
      00C476 9C                    2145 	.db #0x9c	; 156
      00C477 74                    2146 	.db #0x74	; 116	't'
      00C478 36                    2147 	.db #0x36	; 54	'6'
      00C479 FF                    2148 	.db #0xff	; 255
      00C47A 2C                    2149 	.db #0x2c	; 44
      00C47B 66                    2150 	.db #0x66	; 102	'f'
      00C47C AF                    2151 	.db #0xaf	; 175
      00C47D 0F                    2152 	.db #0x0f	; 15
      00C47E 3C                    2153 	.db #0x3c	; 60
      00C47F A2                    2154 	.db #0xa2	; 162
      00C480 23                    2155 	.db #0x23	; 35
      00C481 85                    2156 	.db #0x85	; 133
      00C482 05                    2157 	.db #0x05	; 5
      00C483 87                    2158 	.db #0x87	; 135
      00C484 DA                    2159 	.db #0xda	; 218
      00C485 61                    2160 	.db #0x61	; 97	'a'
      00C486 5E                    2161 	.db #0x5e	; 94
      00C487 42                    2162 	.db #0x42	; 66	'B'
      00C488 54                    2163 	.db #0x54	; 84	'T'
      00C489 60                    2164 	.db #0x60	; 96
      00C48A 23                    2165 	.db #0x23	; 35
      00C48B CA                    2166 	.db #0xca	; 202
      00C48C BC                    2167 	.db #0xbc	; 188
      00C48D B3                    2168 	.db #0xb3	; 179
      00C48E 18                    2169 	.db #0x18	; 24
      00C48F 1D                    2170 	.db #0x1d	; 29
      00C490 F8                    2171 	.db #0xf8	; 248
      00C491 0A                    2172 	.db #0x0a	; 10
      00C492 55                    2173 	.db #0x55	; 85	'U'
      00C493 CD                    2174 	.db #0xcd	; 205
      00C494 A3                    2175 	.db #0xa3	; 163
      00C495 DE                    2176 	.db #0xde	; 222
      00C496 FF                    2177 	.db #0xff	; 255
      00C497 B2                    2178 	.db #0xb2	; 178
      00C498 2A                    2179 	.db #0x2a	; 42
      00C499 35                    2180 	.db #0x35	; 53	'5'
      00C49A 00                    2181 	.db #0x00	; 0
      00C49B D6                    2182 	.db #0xd6	; 214
      00C49C 7B                    2183 	.db #0x7b	; 123
      00C49D E8                    2184 	.db #0xe8	; 232
      00C49E F2                    2185 	.db #0xf2	; 242
      00C49F 1A                    2186 	.db #0x1a	; 26
      00C4A0 BC                    2187 	.db #0xbc	; 188
      00C4A1 F5                    2188 	.db #0xf5	; 245
      00C4A2 7E                    2189 	.db #0x7e	; 126
      00C4A3 48                    2190 	.db #0x48	; 72	'H'
      00C4A4 72                    2191 	.db #0x72	; 114	'r'
      00C4A5 E0                    2192 	.db #0xe0	; 224
      00C4A6 E4                    2193 	.db #0xe4	; 228
      00C4A7 E0                    2194 	.db #0xe0	; 224
      00C4A8 27                    2195 	.db #0x27	; 39
      00C4A9 87                    2196 	.db #0x87	; 135
      00C4AA 9A                    2197 	.db #0x9a	; 154
      00C4AB 51                    2198 	.db #0x51	; 81	'Q'
      00C4AC D4                    2199 	.db #0xd4	; 212
      00C4AD DD                    2200 	.db #0xdd	; 221
      00C4AE C3                    2201 	.db #0xc3	; 195
      00C4AF AA                    2202 	.db #0xaa	; 170
      00C4B0 49                    2203 	.db #0x49	; 73	'I'
      00C4B1 5A                    2204 	.db #0x5a	; 90	'Z'
      00C4B2 2A                    2205 	.db #0x2a	; 42
      00C4B3 00                    2206 	.db #0x00	; 0
      00C4B4 A0                    2207 	.db #0xa0	; 160
      00C4B5 8C                    2208 	.db #0x8c	; 140
      00C4B6 FF                    2209 	.db #0xff	; 255
      00C4B7 74                    2210 	.db #0x74	; 116	't'
      00C4B8 BF                    2211 	.db #0xbf	; 191
      00C4B9 EC                    2212 	.db #0xec	; 236
      00C4BA 1D                    2213 	.db #0x1d	; 29
      00C4BB F1                    2214 	.db #0xf1	; 241
      00C4BC 00                    2215 	.db #0x00	; 0
      00C4BD 01                    2216 	.db #0x01	; 1
      00C4BE D8                    2217 	.db #0xd8	; 216
      00C4BF 02                    2218 	.db #0x02	; 2
      00C4C0 CC                    2219 	.db #0xcc	; 204
      00C4C1 07                    2220 	.db #0x07	; 7
      00C4C2 00                    2221 	.db #0x00	; 0
      00C4C3 00                    2222 	.db #0x00	; 0
      00C4C4 C4                    2223 	.db #0xc4	; 196
      00C4C5 5E                    2224 	.db #0x5e	; 94
      00C4C6 2C                    2225 	.db #0x2c	; 44
      00C4C7 7E                    2226 	.db #0x7e	; 126
      00C4C8 B1                    2227 	.db #0xb1	; 177
      00C4C9 C4                    2228 	.db #0xc4	; 196
      00C4CA 67                    2229 	.db #0x67	; 103	'g'
      00C4CB FB                    2230 	.db #0xfb	; 251
      00C4CC 02                    2231 	.db #0x02	; 2
      00C4CD 00                    2232 	.db #0x00	; 0
      00C4CE 00                    2233 	.db #0x00	; 0
      00C4CF 00                    2234 	.db #0x00	; 0
      00C4D0 00                    2235 	.db #0x00	; 0
      00C4D1 04                    2236 	.db #0x04	; 4
      00C4D2 59                    2237 	.db #0x59	; 89	'Y'
      00C4D3 5A                    2238 	.db #0x5a	; 90	'Z'
                                   2239 	.area CSEG    (CODE)
                                   2240 	.area CONST   (CODE)
      00C4D4                       2241 _vial_handle_cmd_keyboard_uid_40000_632:
      00C4D4 04                    2242 	.db #0x04	; 4
      00C4D5 70                    2243 	.db #0x70	; 112	'p'
      00C4D6 FF                    2244 	.db #0xff	; 255
      00C4D7 90                    2245 	.db #0x90	; 144
      00C4D8 01                    2246 	.db #0x01	; 1
      00C4D9 B9                    2247 	.db #0xb9	; 185
      00C4DA 15                    2248 	.db #0x15	; 21
      00C4DB D3                    2249 	.db #0xd3	; 211
                                   2250 	.area CSEG    (CODE)
                                   2251 	.area XINIT   (CODE)
      00C70D                       2252 __xinit__vial_unlocked:
      00C70D 00                    2253 	.db #0x00	;  0
      00C70E                       2254 __xinit__vial_unlock_in_progress:
      00C70E 00                    2255 	.db #0x00	;  0
      00C70F                       2256 __xinit__vial_unlock_counter:
      00C70F 00                    2257 	.db #0x00	; 0
      00C710                       2258 __xinit__vial_unlock_combo_rows:
      00C710 00                    2259 	.db #0x00	; 0
      00C711 00                    2260 	.db #0x00	; 0
      00C712                       2261 __xinit__vial_unlock_combo_cols:
      00C712 00                    2262 	.db #0x00	; 0
      00C713 05                    2263 	.db #0x05	; 5
                                   2264 	.area CABS    (ABS,CODE)
                                   2265 
                                   2266 ; Experimental exact instruction outlining.
                                   2267 	.globl _ak820_outline_0006
                                   2268 	.globl _ak820_outline_0008
                                   2269 	.globl _ak820_outline_0009
                                   2270 	.globl _ak820_outline_0010
                                   2271 	.globl _ak820_outline_0011
                                   2272 	.globl _ak820_outline_0012
                                   2273 	.globl _ak820_outline_0013
                                   2274 	.globl _ak820_outline_0015
                                   2275 	.globl _ak820_outline_0017
                                   2276 	.globl _ak820_outline_0019
                                   2277 	.globl _ak820_outline_0025
                                   2278 	.globl _ak820_outline_0026
                                   2279 	.globl _ak820_outline_0032
                                   2280 	.globl _ak820_outline_0033
                                   2281 	.globl _ak820_outline_0040
                                   2282 	.globl _ak820_outline_0051
                                   2283 	.globl _ak820_outline_0056
                                   2284 	.globl _ak820_outline_0059
                                   2285 	.globl _ak820_outline_0062
                                   2286 	.globl _ak820_outline_0064
                                   2287 	.globl _ak820_outline_0066
                                   2288 	.globl _ak820_outline_0076
                                   2289 	.globl _ak820_outline_0108
                                   2290 	.globl _ak820_outline_0109
                                   2291 	.globl _ak820_outline_0123
                                   2292 	.globl _ak820_outline_0126
                                   2293 	.globl _ak820_outline_0132
                                   2294 	.globl _ak820_outline_0134
                                   2295 	.globl _ak820_outline_0135
                                   2296 	.globl _ak820_outline_0140
                                   2297 	.globl _ak820_outline_0144
                                   2298 	.globl _ak820_outline_0145
                                   2299 	.globl _ak820_outline_0149
                                   2300 	.globl _ak820_outline_0155
                                   2301 	.globl _ak820_outline_0162
                                   2302 	.globl _ak820_outline_0163
                                   2303 
                                   2304 	.area CSEG (CODE)
                                   2305 ; function ak820_outline_0011
      00B806                       2306 _ak820_outline_0011:
      00B806 A3               [24] 2307 	inc	dptr
      00B807 F0               [24] 2308 	movx	@dptr,a
      00B808 E4               [12] 2309 	clr	a
      00B809 A3               [24] 2310 	inc	dptr
      00B80A F0               [24] 2311 	movx	@dptr,a
      00B80B 90 0E 24         [24] 2312 	mov	dptr,#___memcpy_PARM_3
      00B80E 74 0A            [12] 2313 	mov	a,#0x0a
      00B810 F0               [24] 2314 	movx	@dptr,a
      00B811 E4               [12] 2315 	clr	a
      00B812 A3               [24] 2316 	inc	dptr
      00B813 F0               [24] 2317 	movx	@dptr,a
      00B814 22               [24] 2318 	ret
                                   2319 
                                   2320 	.area CSEG (CODE)
                                   2321 ; function ak820_outline_0026
      00B815                       2322 _ak820_outline_0026:
      00B815 E0               [24] 2323 	movx	a,@dptr
      00B816 FE               [12] 2324 	mov	r6,a
      00B817 A3               [24] 2325 	inc	dptr
      00B818 E0               [24] 2326 	movx	a,@dptr
      00B819 FF               [12] 2327 	mov	r7,a
      00B81A 90 0C F9         [24] 2328 	mov	dptr,#_g_vial_magic_keycode_override
      00B81D EE               [12] 2329 	mov	a,r6
      00B81E F0               [24] 2330 	movx	@dptr,a
      00B81F EF               [12] 2331 	mov	a,r7
      00B820 A3               [24] 2332 	inc	dptr
      00B821 F0               [24] 2333 	movx	@dptr,a
      00B822 8E 04            [24] 2334 	mov	ar4,r6
      00B824 8F 05            [24] 2335 	mov	ar5,r7
      00B826 C3               [12] 2336 	clr	c
      00B827 74 FF            [12] 2337 	mov	a,#0xff
      00B829 9C               [12] 2338 	subb	a,r4
      00B82A 74 1F            [12] 2339 	mov	a,#0x1f
      00B82C 9D               [12] 2340 	subb	a,r5
      00B82D 22               [24] 2341 	ret
                                   2342 
                                   2343 	.area CSEG (CODE)
                                   2344 ; function ak820_outline_0134
      00B82E                       2345 _ak820_outline_0134:
      00B82E 24 A9            [12] 2346 	add	a,#_vial_unlock_combo_cols
      00B830 F5 82            [12] 2347 	mov	dpl,a
      00B832 E4               [12] 2348 	clr	a
      00B833 34 0E            [12] 2349 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B835 F5 83            [12] 2350 	mov	dph,a
      00B837 E0               [24] 2351 	movx	a,@dptr
      00B838 22               [24] 2352 	ret
                                   2353 
                                   2354 	.area CSEG (CODE)
                                   2355 ; function ak820_outline_0135
      00B839                       2356 _ak820_outline_0135:
      00B839 24 A7            [12] 2357 	add	a,#_vial_unlock_combo_rows
      00B83B F5 82            [12] 2358 	mov	dpl,a
      00B83D E4               [12] 2359 	clr	a
      00B83E 34 0E            [12] 2360 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B840 F5 83            [12] 2361 	mov	dph,a
      00B842 E0               [24] 2362 	movx	a,@dptr
      00B843 22               [24] 2363 	ret
