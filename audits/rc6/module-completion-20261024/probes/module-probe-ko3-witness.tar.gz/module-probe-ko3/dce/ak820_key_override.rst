                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_key_override
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_key_override
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _ak820_key_override_process_PARM_3
                                    256 	.globl _ak820_key_override_process_PARM_2
                                    257 	.globl _ak820_key_override_sync_PARM_2
                                    258 	.globl _ak820_key_override_valid
                                    259 	.globl _ak820_key_override_cancel
                                    260 	.globl _ak820_key_override_reload
                                    261 	.globl _ak820_key_override_sync
                                    262 	.globl _ak820_key_override_process
                                    263 	.globl _ak820_key_override_key
                                    264 	.globl _ak820_key_override_mods
                                    265 ;--------------------------------------------------------
                                    266 ; special function registers
                                    267 ;--------------------------------------------------------
                                    268 	.area RSEG    (ABS,DATA)
      000000                        269 	.org 0x0000
                           0000D0   270 _PSW	=	0x00d0
                           0000E0   271 _ACC	=	0x00e0
                           0000F0   272 _B	=	0x00f0
                           0000FD   273 _A_INV	=	0x00fd
                           000081   274 _SP	=	0x0081
                           000082   275 _DPL	=	0x0082
                           000083   276 _DPH	=	0x0083
                           0000A1   277 _SAFE_MOD	=	0x00a1
                           0000B1   278 _GLOBAL_CFG	=	0x00b1
                           000087   279 _PCON	=	0x0087
                           0000BA   280 _POWER_CFG	=	0x00ba
                           0000B9   281 _CLOCK_CFG	=	0x00b9
                           0000A9   282 _WAKE_CTRL	=	0x00a9
                           0000FE   283 _RESET_KEEP	=	0x00fe
                           0000FF   284 _WDOG_COUNT	=	0x00ff
                           0000A8   285 _IE	=	0x00a8
                           0000B8   286 _IP	=	0x00b8
                           0000E8   287 _IE_EX	=	0x00e8
                           0000E9   288 _IP_EX	=	0x00e9
                           0000B2   289 _GPIO_IE	=	0x00b2
                           008584   290 _ROM_ADDR	=	0x8584
                           000084   291 _ROM_ADDR_L	=	0x0084
                           000085   292 _ROM_ADDR_H	=	0x0085
                           008F8E   293 _ROM_DATA_HI	=	0x8f8e
                           00008E   294 _ROM_DATA_HL	=	0x008e
                           00008F   295 _ROM_DATA_HH	=	0x008f
                           000086   296 _ROM_CTRL	=	0x0086
                           000080   297 _P0	=	0x0080
                           0000C4   298 _P0_MOD_OC	=	0x00c4
                           0000C5   299 _P0_DIR_PU	=	0x00c5
                           000090   300 _P1	=	0x0090
                           000092   301 _P1_MOD_OC	=	0x0092
                           000093   302 _P1_DIR_PU	=	0x0093
                           0000A0   303 _P2	=	0x00a0
                           000094   304 _P2_MOD_OC	=	0x0094
                           000095   305 _P2_DIR_PU	=	0x0095
                           0000B0   306 _P3	=	0x00b0
                           000096   307 _P3_MOD_OC	=	0x0096
                           000097   308 _P3_DIR_PU	=	0x0097
                           0000C0   309 _P4	=	0x00c0
                           0000C2   310 _P4_MOD_OC	=	0x00c2
                           0000C3   311 _P4_DIR_PU	=	0x00c3
                           0000C1   312 _P4_LED_KEY	=	0x00c1
                           0000AA   313 _P5_IN	=	0x00aa
                           0000AB   314 _P5_OUT_PU	=	0x00ab
                           0000AC   315 _P5_DIR	=	0x00ac
                           0000AD   316 _P6_IN	=	0x00ad
                           0000AE   317 _P6_OUT_PU	=	0x00ae
                           0000AF   318 _P6_DIR	=	0x00af
                           0000F1   319 _P7	=	0x00f1
                           0000A2   320 _XBUS_AUX	=	0x00a2
                           000088   321 _TCON	=	0x0088
                           000089   322 _TMOD	=	0x0089
                           00008A   323 _TL0	=	0x008a
                           00008B   324 _TL1	=	0x008b
                           00008C   325 _TH0	=	0x008c
                           00008D   326 _TH1	=	0x008d
                           000098   327 _SCON	=	0x0098
                           000099   328 _SBUF	=	0x0099
                           0000C8   329 _T2CON	=	0x00c8
                           0000C9   330 _T2MOD	=	0x00c9
                           00CBCA   331 _RCAP2	=	0xcbca
                           0000CA   332 _RCAP2L	=	0x00ca
                           0000CB   333 _RCAP2H	=	0x00cb
                           00CDCC   334 _T2COUNT	=	0xcdcc
                           0000CC   335 _TL2	=	0x00cc
                           0000CD   336 _TH2	=	0x00cd
                           00CFCE   337 _T2CAP1	=	0xcfce
                           0000CE   338 _T2CAP1L	=	0x00ce
                           0000CF   339 _T2CAP1H	=	0x00cf
                           0000F8   340 _SPI0_STAT	=	0x00f8
                           0000F9   341 _SPI0_DATA	=	0x00f9
                           0000FA   342 _SPI0_CTRL	=	0x00fa
                           0000FB   343 _SPI0_CK_SE	=	0x00fb
                           0000FC   344 _SPI0_SETUP	=	0x00fc
                           0000BC   345 _SCON1	=	0x00bc
                           0000BD   346 _SBUF1	=	0x00bd
                           0000BE   347 _SBAUD1	=	0x00be
                           0000BF   348 _SIF1	=	0x00bf
                           0000B4   349 _SPI1_STAT	=	0x00b4
                           0000B5   350 _SPI1_DATA	=	0x00b5
                           0000B6   351 _SPI1_CTRL	=	0x00b6
                           0000B7   352 _SPI1_CK_SE	=	0x00b7
                           0000F3   353 _ADC_CTRL	=	0x00f3
                           00F5F4   354 _ADC_DAT	=	0xf5f4
                           0000F4   355 _ADC_DAT_L	=	0x00f4
                           0000F5   356 _ADC_DAT_H	=	0x00f5
                           0000F6   357 _ADC_CHAN	=	0x00f6
                           0000A6   358 _LED_COMMON	=	0x00a6
                           0000A7   359 _LED_PWM_OE	=	0x00a7
                           00C7C6   360 _LED_DMA	=	0xc7c6
                           0000C6   361 _LED_DMA_L	=	0x00c6
                           0000C7   362 _LED_DMA_H	=	0x00c7
                           0000F7   363 _LED_STATUS	=	0x00f7
                           0000B3   364 _I2CX_INT	=	0x00b3
                           0000BB   365 _I2CS_INT_ST	=	0x00bb
                                    366 ;--------------------------------------------------------
                                    367 ; special function bits
                                    368 ;--------------------------------------------------------
                                    369 	.area RSEG    (ABS,DATA)
      000000                        370 	.org 0x0000
                           0000D7   371 _CY	=	0x00d7
                           0000D6   372 _AC	=	0x00d6
                           0000D5   373 _F0	=	0x00d5
                           0000D4   374 _RS1	=	0x00d4
                           0000D3   375 _RS0	=	0x00d3
                           0000D2   376 _OV	=	0x00d2
                           0000D1   377 _F1	=	0x00d1
                           0000D0   378 _P	=	0x00d0
                           0000AF   379 _EA	=	0x00af
                           0000AE   380 _E_DIS	=	0x00ae
                           0000AD   381 _ET2	=	0x00ad
                           0000AC   382 _ES	=	0x00ac
                           0000AB   383 _ET1	=	0x00ab
                           0000AA   384 _EX1	=	0x00aa
                           0000A9   385 _ET0	=	0x00a9
                           0000A8   386 _EX0	=	0x00a8
                           0000BF   387 _PH_FLAG	=	0x00bf
                           0000BE   388 _PL_FLAG	=	0x00be
                           0000BD   389 _PT2	=	0x00bd
                           0000BC   390 _PS	=	0x00bc
                           0000BB   391 _PT1	=	0x00bb
                           0000BA   392 _PX1	=	0x00ba
                           0000B9   393 _PT0	=	0x00b9
                           0000B8   394 _PX0	=	0x00b8
                           0000EF   395 _IE_WDOG	=	0x00ef
                           0000EE   396 _IE_GPIO	=	0x00ee
                           0000ED   397 _IE_PWM_I2C	=	0x00ed
                           0000EC   398 _IE_UART1	=	0x00ec
                           0000EB   399 _IE_ADC	=	0x00eb
                           0000E9   400 _IE_USB	=	0x00e9
                           0000E8   401 _IE_SPI0	=	0x00e8
                           000087   402 _P0_7	=	0x0087
                           000086   403 _P0_6	=	0x0086
                           000085   404 _P0_5	=	0x0085
                           000084   405 _P0_4	=	0x0084
                           000083   406 _P0_3	=	0x0083
                           000082   407 _P0_2	=	0x0082
                           000081   408 _P0_1	=	0x0081
                           000080   409 _P0_0	=	0x0080
                           000081   410 _SDA0	=	0x0081
                           000080   411 _SCL0	=	0x0080
                           000083   412 _TXD_	=	0x0083
                           000082   413 _RXD_	=	0x0082
                           000085   414 _AIN13	=	0x0085
                           000084   415 _AIN12	=	0x0084
                           000083   416 _AIN11	=	0x0083
                           000082   417 _AIN10	=	0x0082
                           000081   418 _AIN9	=	0x0081
                           000080   419 _AIN8	=	0x0080
                           000097   420 _P1_7	=	0x0097
                           000096   421 _P1_6	=	0x0096
                           000095   422 _P1_5	=	0x0095
                           000094   423 _P1_4	=	0x0094
                           000093   424 _P1_3	=	0x0093
                           000092   425 _P1_2	=	0x0092
                           000091   426 _P1_1	=	0x0091
                           000090   427 _P1_0	=	0x0090
                           000097   428 _TXD1_	=	0x0097
                           000096   429 _RXD1_	=	0x0096
                           000097   430 _SCK	=	0x0097
                           000096   431 _MISO	=	0x0096
                           000095   432 _MOSI	=	0x0095
                           000094   433 _SCS	=	0x0094
                           000092   434 _INT0_	=	0x0092
                           000091   435 _T2EX	=	0x0091
                           000091   436 _CAP2	=	0x0091
                           000090   437 _T2	=	0x0090
                           000090   438 _CAP1	=	0x0090
                           000097   439 _AIN7	=	0x0097
                           000096   440 _AIN6	=	0x0096
                           000095   441 _AIN5	=	0x0095
                           000094   442 _AIN4	=	0x0094
                           000093   443 _AIN3	=	0x0093
                           000092   444 _AIN2	=	0x0092
                           000091   445 _AIN1	=	0x0091
                           000090   446 _AIN0	=	0x0090
                           0000A7   447 _P2_7	=	0x00a7
                           0000A6   448 _P2_6	=	0x00a6
                           0000A5   449 _P2_5	=	0x00a5
                           0000A4   450 _P2_4	=	0x00a4
                           0000A3   451 _P2_3	=	0x00a3
                           0000A2   452 _P2_2	=	0x00a2
                           0000A1   453 _P2_1	=	0x00a1
                           0000A0   454 _P2_0	=	0x00a0
                           0000A7   455 _TXD1	=	0x00a7
                           0000A6   456 _RXD1	=	0x00a6
                           0000A5   457 _T2EX_	=	0x00a5
                           0000A5   458 _CAP2_	=	0x00a5
                           0000A4   459 _T2_	=	0x00a4
                           0000A4   460 _CAP1_	=	0x00a4
                           0000B7   461 _P3_7	=	0x00b7
                           0000B6   462 _P3_6	=	0x00b6
                           0000B5   463 _P3_5	=	0x00b5
                           0000B4   464 _P3_4	=	0x00b4
                           0000B3   465 _P3_3	=	0x00b3
                           0000B2   466 _P3_2	=	0x00b2
                           0000B1   467 _P3_1	=	0x00b1
                           0000B0   468 _P3_0	=	0x00b0
                           0000B7   469 _SCK1	=	0x00b7
                           0000B6   470 _MISO1	=	0x00b6
                           0000B5   471 _MOSI1	=	0x00b5
                           0000B5   472 _T1	=	0x00b5
                           0000B4   473 _T0	=	0x00b4
                           0000B3   474 _INT1	=	0x00b3
                           0000B2   475 _INT0	=	0x00b2
                           0000B1   476 _TXD	=	0x00b1
                           0000B0   477 _RXD	=	0x00b0
                           0000C6   478 _P4_6	=	0x00c6
                           0000C5   479 _P4_5	=	0x00c5
                           0000C4   480 _P4_4	=	0x00c4
                           0000C3   481 _P4_3	=	0x00c3
                           0000C2   482 _P4_2	=	0x00c2
                           0000C1   483 _P4_1	=	0x00c1
                           0000C0   484 _P4_0	=	0x00c0
                           00008F   485 _TF1	=	0x008f
                           00008E   486 _TR1	=	0x008e
                           00008D   487 _TF0	=	0x008d
                           00008C   488 _TR0	=	0x008c
                           00008B   489 _IE1	=	0x008b
                           00008A   490 _IT1	=	0x008a
                           000089   491 _IE0	=	0x0089
                           000088   492 _IT0	=	0x0088
                           00009F   493 _SM0	=	0x009f
                           00009E   494 _SM1	=	0x009e
                           00009D   495 _SM2	=	0x009d
                           00009C   496 _REN	=	0x009c
                           00009B   497 _TB8	=	0x009b
                           00009A   498 _RB8	=	0x009a
                           000099   499 _TI	=	0x0099
                           000098   500 _RI	=	0x0098
                           0000CF   501 _TF2	=	0x00cf
                           0000CF   502 _CAP1F	=	0x00cf
                           0000CE   503 _EXF2	=	0x00ce
                           0000CD   504 _RCLK	=	0x00cd
                           0000CC   505 _TCLK	=	0x00cc
                           0000CB   506 _EXEN2	=	0x00cb
                           0000CA   507 _TR2	=	0x00ca
                           0000C9   508 _C_T2	=	0x00c9
                           0000C8   509 _CP_RL2	=	0x00c8
                           0000FF   510 _S0_FST_ACT	=	0x00ff
                           0000FE   511 _S0_IF_OV	=	0x00fe
                           0000FD   512 _S0_IF_FIRST	=	0x00fd
                           0000FC   513 _S0_IF_BYTE	=	0x00fc
                           0000FB   514 _S0_FREE	=	0x00fb
                           0000FA   515 _S0_T_FIFO	=	0x00fa
                           0000F8   516 _S0_R_FIFO	=	0x00f8
                           0000F7   517 _ADC_START	=	0x00f7
                                    518 ;--------------------------------------------------------
                                    519 ; overlayable register banks
                                    520 ;--------------------------------------------------------
                                    521 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        522 	.ds 8
                                    523 ;--------------------------------------------------------
                                    524 ; internal ram data
                                    525 ;--------------------------------------------------------
                                    526 	.area DSEG    (DATA)
      00000A                        527 _ak820_key_override_process_sloc0_1_0:
      00000A                        528 	.ds 2
                                    529 ;--------------------------------------------------------
                                    530 ; overlayable items in internal ram
                                    531 ;--------------------------------------------------------
                                    532 ;--------------------------------------------------------
                                    533 ; indirectly addressable internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area ISEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; absolute internal ram data
                                    538 ;--------------------------------------------------------
                                    539 	.area IABS    (ABS,DATA)
                                    540 	.area IABS    (ABS,DATA)
                                    541 ;--------------------------------------------------------
                                    542 ; bit data
                                    543 ;--------------------------------------------------------
                                    544 	.area BSEG    (BIT)
      000004                        545 _ak820_key_override_valid_sloc0_1_0:
      000004                        546 	.ds 1
      000005                        547 _eligible_sloc0_1_0:
      000005                        548 	.ds 1
      000006                        549 _activate_sloc0_1_0:
      000006                        550 	.ds 1
                                    551 ;--------------------------------------------------------
                                    552 ; paged external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area PSEG    (PAG,XDATA)
                                    555 ;--------------------------------------------------------
                                    556 ; uninitialized external ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area XSEG    (XDATA)
      0004F9                        559 _entries:
      0004F9                        560 	.ds 80
      000549                        561 _trigger:
      000549                        562 	.ds 1
      00054A                        563 _previous_mods:
      00054A                        564 	.ds 1
      00054B                        565 _current_mods:
      00054B                        566 	.ds 1
      00054C                        567 _current_layer:
      00054C                        568 	.ds 1
      00054D                        569 _blocked:
      00054D                        570 	.ds 1
      00054E                        571 _hidden:
      00054E                        572 	.ds 1
      00054F                        573 _ak820_key_override_valid_e_10000_597:
      00054F                        574 	.ds 2
      000551                        575 _ak820_key_override_valid_any_10000_598:
      000551                        576 	.ds 1
      000552                        577 _eligible_index_10000_605:
      000552                        578 	.ds 1
      000553                        579 _activate_trigger_down_10000_619:
      000553                        580 	.ds 1
      000554                        581 _activate_e_30000_623:
      000554                        582 	.ds 2
      000556                        583 _ak820_key_override_sync_PARM_2:
      000556                        584 	.ds 1
      000557                        585 _ak820_key_override_sync_mods_10000_626:
      000557                        586 	.ds 1
      000558                        587 _ak820_key_override_process_PARM_2:
      000558                        588 	.ds 1
      000559                        589 _ak820_key_override_process_PARM_3:
      000559                        590 	.ds 1
      00055A                        591 _ak820_key_override_process_record_10000_629:
      00055A                        592 	.ds 2
      00055C                        593 _ak820_key_override_mods_mods_10000_654:
      00055C                        594 	.ds 1
      00055D                        595 _ak820_key_override_mods_replacement_10000_655:
      00055D                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; absolute external ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area XABS    (ABS,XDATA)
                                    601 ;--------------------------------------------------------
                                    602 ; initialized external ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area XISEG   (XDATA)
      000E31                        605 _source:
      000E31                        606 	.ds 1
      000E32                        607 _active:
      000E32                        608 	.ds 1
      000E33                        609 _enabled:
      000E33                        610 	.ds 1
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function ak820_key_override_valid
                                    653 ;	-----------------------------------------
      003B3F                        654 _ak820_key_override_valid:
      003B3F 12 38 42         [24]  655 	lcall	_ak820_outline_0108
      003B42 90 05 4F         [24]  656 	mov	dptr,#_ak820_key_override_valid_e_10000_597
      003B45 12 38 47         [24]  657 	lcall	_ak820_outline_0109
                                    658 ;	keyboards/ajazz/ak820/ak820_key_override.c:20: const uint8_t AK820_STATE_MEM *bytes = (const uint8_t AK820_STATE_MEM *)e;
      003B48 90 05 4F         [24]  659 	mov	dptr,#_ak820_key_override_valid_e_10000_597
      003B4B 12 37 F9         [24]  660 	lcall	_ak820_outline_0056
                                    661 ;	keyboards/ajazz/ak820/ak820_key_override.c:21: uint8_t any = 0;
      003B4E 90 05 51         [24]  662 	mov	dptr,#_ak820_key_override_valid_any_10000_598
      003B51 E4               [12]  663 	clr	a
      003B52 F0               [24]  664 	movx	@dptr,a
                                    665 ;	keyboards/ajazz/ak820/ak820_key_override.c:24: for (uint8_t i = 0; i < 10; ++i) any |= bytes[i];
      003B53 FD               [12]  666 	mov	r5,a
      003B54                        667 00118$:
      003B54 BD 0A 00         [24]  668 	cjne	r5,#0x0a,00206$
      003B57                        669 00206$:
      003B57 50 0E            [24]  670 	jnc	00101$
      003B59 ED               [12]  671 	mov	a,r5
      003B5A 12 37 CE         [24]  672 	lcall	_ak820_outline_0013
      003B5D FC               [12]  673 	mov	r4,a
      003B5E 90 05 51         [24]  674 	mov	dptr,#_ak820_key_override_valid_any_10000_598
      003B61 E0               [24]  675 	movx	a,@dptr
      003B62 4C               [12]  676 	orl	a,r4
      003B63 F0               [24]  677 	movx	@dptr,a
      003B64 0D               [12]  678 	inc	r5
      003B65 80 ED            [24]  679 	sjmp	00118$
      003B67                        680 00101$:
                                    681 ;	keyboards/ajazz/ak820/ak820_key_override.c:25: if (!any) return true;
      003B67 90 05 51         [24]  682 	mov	dptr,#_ak820_key_override_valid_any_10000_598
      003B6A E0               [24]  683 	movx	a,@dptr
      003B6B 70 04            [24]  684 	jnz	00103$
      003B6D 75 82 01         [24]  685 	mov	dpl, #0x01
      003B70 22               [24]  686 	ret
      003B71                        687 00103$:
                                    688 ;	keyboards/ajazz/ak820/ak820_key_override.c:26: if (bytes[1] || !basic(bytes[0])) return false;
      003B71 74 01            [12]  689 	mov	a,#0x01
      003B73 12 3F FB         [24]  690 	lcall	_ak820_outline_0009
      003B76 70 0E            [24]  691 	jnz	00104$
      003B78 12 38 30         [24]  692 	lcall	_ak820_outline_0098
      003B7B FD               [12]  693 	mov	r5,a
      003B7C BD 04 00         [24]  694 	cjne	r5,#0x04,00210$
      003B7F                        695 00210$:
      003B7F 40 05            [24]  696 	jc	00104$
      003B81 ED               [12]  697 	mov	a,r5
      003B82 24 5B            [12]  698 	add	a,#0xff - 0xa4
      003B84 50 04            [24]  699 	jnc	00105$
                                    700 ;	free result
      003B86                        701 00104$:
      003B86 75 82 00         [24]  702 	mov	dpl, #0x00
      003B89 22               [24]  703 	ret
      003B8A                        704 00105$:
                                    705 ;	keyboards/ajazz/ak820/ak820_key_override.c:27: if (bytes[5] || !bytes[4] || (bytes[4] & 0xC0)) return false;
      003B8A 74 05            [12]  706 	mov	a,#0x05
      003B8C 12 3F FB         [24]  707 	lcall	_ak820_outline_0009
      003B8F 70 0B            [24]  708 	jnz	00108$
      003B91 12 40 1C         [24]  709 	lcall	_ak820_outline_0017
      003B94 FD               [12]  710 	mov	r5,a
      003B95 60 05            [24]  711 	jz	00108$
      003B97 ED               [12]  712 	mov	a,r5
      003B98 54 C0            [12]  713 	anl	a,#0xc0
      003B9A 60 04            [24]  714 	jz	00109$
      003B9C                        715 00108$:
      003B9C 75 82 00         [24]  716 	mov	dpl, #0x00
      003B9F 22               [24]  717 	ret
      003BA0                        718 00109$:
                                    719 ;	keyboards/ajazz/ak820/ak820_key_override.c:28: if ((bytes[9] & 0x40) || !(bytes[9] & ACTIVATIONS)) return false;
      003BA0 74 09            [12]  720 	mov	a,#0x09
      003BA2 12 37 CE         [24]  721 	lcall	_ak820_outline_0013
      003BA5 FD               [12]  722 	mov	r5,a
      003BA6 20 E6 05         [24]  723 	jb	acc.6,00112$
      003BA9 ED               [12]  724 	mov	a,r5
      003BAA 54 07            [12]  725 	anl	a,#0x07
      003BAC 70 04            [24]  726 	jnz	00113$
      003BAE                        727 00112$:
      003BAE 75 82 00         [24]  728 	mov	dpl, #0x00
      003BB1 22               [24]  729 	ret
      003BB2                        730 00113$:
                                    731 ;	keyboards/ajazz/ak820/ak820_key_override.c:30: if (bytes[2] | bytes[3]) return bytes[3] < 32 && basic(bytes[2]);
      003BB2 12 37 E9         [24]  732 	lcall	_ak820_outline_0032
      003BB5 FD               [12]  733 	mov	r5,a
      003BB6 12 40 06         [24]  734 	lcall	_ak820_outline_0015
      003BB9 FF               [12]  735 	mov	r7,a
      003BBA 4D               [12]  736 	orl	a,r5
      003BBB 60 1B            [24]  737 	jz	00116$
      003BBD BF 20 00         [24]  738 	cjne	r7,#0x20,00220$
      003BC0                        739 00220$:
      003BC0 50 0A            [24]  740 	jnc	00122$
      003BC2 BD 04 00         [24]  741 	cjne	r5,#0x04,00222$
      003BC5                        742 00222$:
      003BC5 40 05            [24]  743 	jc	00122$
      003BC7 ED               [12]  744 	mov	a,r5
      003BC8 24 5B            [12]  745 	add	a,#0xff - 0xa4
      003BCA 50 04            [24]  746 	jnc	00123$
                                    747 ;	free result
      003BCC                        748 00122$:
                                    749 ;	assignBit
      003BCC C2 04            [12]  750 	clr	_ak820_key_override_valid_sloc0_1_0
      003BCE 80 02            [24]  751 	sjmp	00124$
      003BD0                        752 00123$:
                                    753 ;	assignBit
      003BD0 D2 04            [12]  754 	setb	_ak820_key_override_valid_sloc0_1_0
      003BD2                        755 00124$:
      003BD2 A2 04            [12]  756 	mov	c,_ak820_key_override_valid_sloc0_1_0
      003BD4 12 38 67         [24]  757 	lcall	_ak820_outline_0150
      003BD7 22               [24]  758 	ret
      003BD8                        759 00116$:
                                    760 ;	keyboards/ajazz/ak820/ak820_key_override.c:31: return true;
      003BD8 75 82 01         [24]  761 	mov	dpl, #0x01
                                    762 ;	keyboards/ajazz/ak820/ak820_key_override.c:32: }
      003BDB 22               [24]  763 	ret
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'eligible'
                                    766 ;------------------------------------------------------------
                                    767 ;index         Allocated with name '_eligible_index_10000_605'
                                    768 ;e             Allocated with name '_eligible_e_10000_606'
                                    769 ;low           Allocated with name '_eligible_low_10000_606'
                                    770 ;high          Allocated with name '_eligible_high_10000_606'
                                    771 ;------------------------------------------------------------
                                    772 ;	keyboards/ajazz/ak820/ak820_key_override.c:34: static bool eligible(uint8_t index) {
                                    773 ;	-----------------------------------------
                                    774 ;	 function eligible
                                    775 ;	-----------------------------------------
      003BDC                        776 _eligible:
      003BDC E5 82            [12]  777 	mov	a,dpl
      003BDE 90 05 52         [24]  778 	mov	dptr,#_eligible_index_10000_605
      003BE1 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_key_override.c:35: vial_key_override_entry_t AK820_STATE_MEM *e = &entries[index];
      003BE2 E0               [24]  781 	movx	a,@dptr
      003BE3 12 40 0F         [24]  782 	lcall	_ak820_outline_0016
                                    783 ;	keyboards/ajazz/ak820/ak820_key_override.c:36: uint8_t low = e->trigger_mods & 15, high = e->trigger_mods >> 4;
      003BE6 74 06            [12]  784 	mov	a,#0x06
      003BE8 12 37 CE         [24]  785 	lcall	_ak820_outline_0013
      003BEB FD               [12]  786 	mov	r5,a
      003BEC 74 0F            [12]  787 	mov	a,#0x0f
      003BEE 5D               [12]  788 	anl	a,r5
      003BEF FC               [12]  789 	mov	r4,a
      003BF0 ED               [12]  790 	mov	a,r5
      003BF1 C4               [12]  791 	swap	a
      003BF2 54 0F            [12]  792 	anl	a,#0x0f
      003BF4 FB               [12]  793 	mov	r3,a
                                    794 ;	keyboards/ajazz/ak820/ak820_key_override.c:37: if (current_layer >= 6 || !((uint8_t)e->layers & ((uint8_t)1 << current_layer)) ||
      003BF5 90 05 4C         [24]  795 	mov	dptr,#_current_layer
      003BF8 E0               [24]  796 	movx	a,@dptr
      003BF9 FA               [12]  797 	mov	r2,a
      003BFA BA 06 00         [24]  798 	cjne	r2,#0x06,00147$
      003BFD                        799 00147$:
      003BFD 50 36            [24]  800 	jnc	00101$
      003BFF C0 03            [24]  801 	push	ar3
      003C01 12 40 1C         [24]  802 	lcall	_ak820_outline_0017
      003C04 F9               [12]  803 	mov	r1,a
      003C05 8A F0            [24]  804 	mov	b,r2
      003C07 05 F0            [12]  805 	inc	b
      003C09 78 01            [12]  806 	mov	r0,#0x01
      003C0B 7A 00            [12]  807 	mov	r2,#0x00
      003C0D 80 06            [24]  808 	sjmp	00150$
      003C0F                        809 00149$:
      003C0F E8               [12]  810 	mov	a,r0
      003C10 28               [12]  811 	add	a,r0
      003C11 F8               [12]  812 	mov	r0,a
      003C12 EA               [12]  813 	mov	a,r2
      003C13 33               [12]  814 	rlc	a
      003C14 FA               [12]  815 	mov	r2,a
      003C15                        816 00150$:
      003C15 D5 F0 F7         [24]  817 	djnz	b,00149$
      003C18 7B 00            [12]  818 	mov	r3,#0x00
      003C1A E9               [12]  819 	mov	a,r1
      003C1B 52 00            [12]  820 	anl	ar0,a
      003C1D EB               [12]  821 	mov	a,r3
      003C1E 52 02            [12]  822 	anl	ar2,a
      003C20 D0 03            [24]  823 	pop	ar3
      003C22 E8               [12]  824 	mov	a,r0
      003C23 4A               [12]  825 	orl	a,r2
      003C24 60 0F            [24]  826 	jz	00101$
                                    827 ;	keyboards/ajazz/ak820/ak820_key_override.c:38: (current_mods & e->negative_mod_mask)) return false;
      003C26 74 07            [12]  828 	mov	a,#0x07
      003C28 12 37 CE         [24]  829 	lcall	_ak820_outline_0013
      003C2B FA               [12]  830 	mov	r2,a
      003C2C 90 05 4B         [24]  831 	mov	dptr,#_current_mods
      003C2F E0               [24]  832 	movx	a,@dptr
      003C30 F9               [12]  833 	mov	r1,a
      003C31 EA               [12]  834 	mov	a,r2
      003C32 59               [12]  835 	anl	a,r1
      003C33 60 04            [24]  836 	jz	00102$
      003C35                        837 00101$:
      003C35 75 82 00         [24]  838 	mov	dpl, #0x00
      003C38 22               [24]  839 	ret
      003C39                        840 00102$:
                                    841 ;	keyboards/ajazz/ak820/ak820_key_override.c:39: if (e->options & 8) return !(low | high) || (current_mods & e->trigger_mods);
      003C39 74 09            [12]  842 	mov	a,#0x09
      003C3B 12 37 CE         [24]  843 	lcall	_ak820_outline_0013
      003C3E 30 E3 14         [24]  844 	jnb	acc.3,00106$
      003C41 EB               [12]  845 	mov	a,r3
      003C42 4C               [12]  846 	orl	a,r4
      003C43 60 08            [24]  847 	jz	00110$
      003C45 ED               [12]  848 	mov	a,r5
      003C46 59               [12]  849 	anl	a,r1
      003C47 70 04            [24]  850 	jnz	00110$
                                    851 ;	assignBit
      003C49 C2 05            [12]  852 	clr	_eligible_sloc0_1_0
      003C4B 80 02            [24]  853 	sjmp	00111$
      003C4D                        854 00110$:
                                    855 ;	assignBit
      003C4D D2 05            [12]  856 	setb	_eligible_sloc0_1_0
      003C4F                        857 00111$:
      003C4F A2 05            [12]  858 	mov	c,_eligible_sloc0_1_0
      003C51 12 38 67         [24]  859 	lcall	_ak820_outline_0150
      003C54 22               [24]  860 	ret
      003C55                        861 00106$:
                                    862 ;	keyboards/ajazz/ak820/ak820_key_override.c:40: return ((current_mods & low) | ((current_mods >> 4) & high)) == (low | high);
      003C55 EC               [12]  863 	mov	a,r4
      003C56 59               [12]  864 	anl	a,r1
      003C57 FF               [12]  865 	mov	r7,a
      003C58 E9               [12]  866 	mov	a,r1
      003C59 C4               [12]  867 	swap	a
      003C5A 54 0F            [12]  868 	anl	a,#0x0f
      003C5C F9               [12]  869 	mov	r1,a
      003C5D EB               [12]  870 	mov	a,r3
      003C5E 59               [12]  871 	anl	a,r1
      003C5F 42 07            [12]  872 	orl	ar7,a
      003C61 EB               [12]  873 	mov	a,r3
      003C62 42 04            [12]  874 	orl	ar4,a
      003C64 EF               [12]  875 	mov	a,r7
      003C65 B5 04 03         [24]  876 	cjne	a,ar4,00156$
      003C68 D3               [12]  877 	setb	c
      003C69 80 01            [24]  878 	sjmp	00157$
      003C6B                        879 00156$:
      003C6B C3               [12]  880 	clr	c
      003C6C                        881 00157$:
      003C6C 92 05            [24]  882 	mov  _eligible_sloc0_1_0,c
      003C6E 12 38 67         [24]  883 	lcall	_ak820_outline_0150
                                    884 ;	keyboards/ajazz/ak820/ak820_key_override.c:41: }
      003C71 22               [24]  885 	ret
                                    886 ;------------------------------------------------------------
                                    887 ;Allocation info for local variables in function 'deactivate'
                                    888 ;------------------------------------------------------------
                                    889 ;	keyboards/ajazz/ak820/ak820_key_override.c:42: static void deactivate(void) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function deactivate
                                    892 ;	-----------------------------------------
      003C72                        893 _deactivate:
                                    894 ;	keyboards/ajazz/ak820/ak820_key_override.c:43: if (active != NONE && (entries[active].options & 16)) hidden = true;
      003C72 12 40 60         [24]  895 	lcall	_ak820_outline_0128
      003C75 BF FF 02         [24]  896 	cjne	r7,#0xff,00120$
      003C78 80 12            [24]  897 	sjmp	00102$
      003C7A                        898 00120$:
      003C7A EF               [12]  899 	mov	a,r7
      003C7B 12 40 0F         [24]  900 	lcall	_ak820_outline_0016
      003C7E 74 09            [12]  901 	mov	a,#0x09
      003C80 12 37 CE         [24]  902 	lcall	_ak820_outline_0013
      003C83 30 E4 06         [24]  903 	jnb	acc.4,00102$
      003C86 90 05 4E         [24]  904 	mov	dptr,#_hidden
      003C89 74 01            [12]  905 	mov	a,#0x01
      003C8B F0               [24]  906 	movx	@dptr,a
      003C8C                        907 00102$:
                                    908 ;	keyboards/ajazz/ak820/ak820_key_override.c:44: active = NONE;
      003C8C 90 0E 32         [24]  909 	mov	dptr,#_active
      003C8F 74 FF            [12]  910 	mov	a,#0xff
      003C91 F0               [24]  911 	movx	@dptr,a
                                    912 ;	keyboards/ajazz/ak820/ak820_key_override.c:45: }
      003C92 22               [24]  913 	ret
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'ak820_key_override_cancel'
                                    916 ;------------------------------------------------------------
                                    917 ;	keyboards/ajazz/ak820/ak820_key_override.c:46: void ak820_key_override_cancel(void) {
                                    918 ;	-----------------------------------------
                                    919 ;	 function ak820_key_override_cancel
                                    920 ;	-----------------------------------------
      003C93                        921 _ak820_key_override_cancel:
                                    922 ;	keyboards/ajazz/ak820/ak820_key_override.c:47: source = active = NONE;
      003C93 90 0E 32         [24]  923 	mov	dptr,#_active
      003C96 74 FF            [12]  924 	mov	a,#0xff
      003C98 F0               [24]  925 	movx	@dptr,a
      003C99 90 0E 31         [24]  926 	mov	dptr,#_source
      003C9C F0               [24]  927 	movx	@dptr,a
                                    928 ;	keyboards/ajazz/ak820/ak820_key_override.c:48: previous_mods = 0;
      003C9D 90 05 4A         [24]  929 	mov	dptr,#_previous_mods
      003CA0 E4               [12]  930 	clr	a
      003CA1 F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_key_override.c:49: blocked = hidden = false;
      003CA2 90 05 4E         [24]  933 	mov	dptr,#_hidden
      003CA5 F0               [24]  934 	movx	@dptr,a
      003CA6 90 05 4D         [24]  935 	mov	dptr,#_blocked
      003CA9 F0               [24]  936 	movx	@dptr,a
                                    937 ;	keyboards/ajazz/ak820/ak820_key_override.c:50: }
      003CAA 22               [24]  938 	ret
                                    939 ;------------------------------------------------------------
                                    940 ;Allocation info for local variables in function 'ak820_key_override_reload'
                                    941 ;------------------------------------------------------------
                                    942 ;i             Allocated with name '_ak820_key_override_reload_i_20000_616'
                                    943 ;------------------------------------------------------------
                                    944 ;	keyboards/ajazz/ak820/ak820_key_override.c:51: void ak820_key_override_reload(void) {
                                    945 ;	-----------------------------------------
                                    946 ;	 function ak820_key_override_reload
                                    947 ;	-----------------------------------------
      003CAB                        948 _ak820_key_override_reload:
                                    949 ;	keyboards/ajazz/ak820/ak820_key_override.c:52: ak820_key_override_cancel();
      003CAB 12 3C 93         [24]  950 	lcall	_ak820_key_override_cancel
                                    951 ;	keyboards/ajazz/ak820/ak820_key_override.c:53: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003CAE 7F 00            [12]  952 	mov	r7,#0x00
      003CB0                        953 00105$:
      003CB0 BF 08 00         [24]  954 	cjne	r7,#0x08,00131$
      003CB3                        955 00131$:
      003CB3 50 30            [24]  956 	jnc	00107$
                                    957 ;	keyboards/ajazz/ak820/ak820_key_override.c:55: if (dynamic_keymap_get_key_override(i, &entries[i]))
      003CB5 12 40 4C         [24]  958 	lcall	_ak820_outline_0101
      003CB8 FE               [12]  959 	mov	r6,a
      003CB9 90 0B 7E         [24]  960 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      003CBC ED               [12]  961 	mov	a,r5
      003CBD F0               [24]  962 	movx	@dptr,a
      003CBE EE               [12]  963 	mov	a,r6
      003CBF 12 38 1E         [24]  964 	lcall	_ak820_outline_0076
      003CC2 8F 82            [24]  965 	mov	dpl, r7
      003CC4 C0 07            [24]  966 	push	ar7
      003CC6 C0 06            [24]  967 	push	ar6
      003CC8 C0 05            [24]  968 	push	ar5
      003CCA 12 8B 8F         [24]  969 	lcall	_dynamic_keymap_get_key_override
      003CCD 12 38 51         [24]  970 	lcall	_ak820_outline_0127
      003CD0 D0 05            [24]  971 	pop	ar5
      003CD2 D0 06            [24]  972 	pop	ar6
      003CD4 D0 07            [24]  973 	pop	ar7
      003CD6 45 F0            [12]  974 	orl	a,b
      003CD8 60 08            [24]  975 	jz	00106$
                                    976 ;	keyboards/ajazz/ak820/ak820_key_override.c:56: entries[i].options = 0;
      003CDA 74 09            [12]  977 	mov	a,#0x09
      003CDC 2D               [12]  978 	add	a, r5
      003CDD 12 40 59         [24]  979 	lcall	_ak820_outline_0117
      003CE0 E4               [12]  980 	clr	a
      003CE1 F0               [24]  981 	movx	@dptr,a
      003CE2                        982 00106$:
                                    983 ;	keyboards/ajazz/ak820/ak820_key_override.c:53: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003CE2 0F               [12]  984 	inc	r7
      003CE3 80 CB            [24]  985 	sjmp	00105$
      003CE5                        986 00107$:
                                    987 ;	keyboards/ajazz/ak820/ak820_key_override.c:58: }
      003CE5 22               [24]  988 	ret
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'activate'
                                    991 ;------------------------------------------------------------
                                    992 ;trigger_down  Allocated with name '_activate_trigger_down_10000_619'
                                    993 ;i             Allocated with name '_activate_i_20000_622'
                                    994 ;e             Allocated with name '_activate_e_30000_623'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_key_override.c:59: static void activate(bool trigger_down) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function activate
                                    999 ;	-----------------------------------------
      003CE6                       1000 _activate:
      003CE6 E5 82            [12] 1001 	mov	a,dpl
      003CE8 90 05 53         [24] 1002 	mov	dptr,#_activate_trigger_down_10000_619
      003CEB F0               [24] 1003 	movx	@dptr,a
                                   1004 ;	keyboards/ajazz/ak820/ak820_key_override.c:60: if (!enabled || source == NONE || blocked || hidden || active != NONE) return;
      003CEC 90 0E 33         [24] 1005 	mov	dptr,#_enabled
      003CEF E0               [24] 1006 	movx	a,@dptr
      003CF0 60 1D            [24] 1007 	jz	00101$
      003CF2 90 0E 31         [24] 1008 	mov	dptr,#_source
      003CF5 E0               [24] 1009 	movx	a,@dptr
      003CF6 FF               [12] 1010 	mov	r7,a
      003CF7 BF FF 01         [24] 1011 	cjne	r7,#0xff,00221$
      003CFA 22               [24] 1012 	ret
      003CFB                       1013 00221$:
      003CFB 90 05 4D         [24] 1014 	mov	dptr,#_blocked
      003CFE E0               [24] 1015 	movx	a,@dptr
      003CFF 70 0E            [24] 1016 	jnz	00101$
      003D01 90 05 4E         [24] 1017 	mov	dptr,#_hidden
      003D04 E0               [24] 1018 	movx	a,@dptr
      003D05 70 08            [24] 1019 	jnz	00101$
      003D07 12 40 60         [24] 1020 	lcall	_ak820_outline_0128
      003D0A BF FF 02         [24] 1021 	cjne	r7,#0xff,00224$
      003D0D 80 01            [24] 1022 	sjmp	00154$
      003D0F                       1023 00224$:
      003D0F                       1024 00101$:
      003D0F 22               [24] 1025 	ret
                                   1026 ;	keyboards/ajazz/ak820/ak820_key_override.c:61: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003D10                       1027 00154$:
      003D10 90 05 53         [24] 1028 	mov	dptr,#_activate_trigger_down_10000_619
      003D13 E0               [24] 1029 	movx	a,@dptr
      003D14 FF               [12] 1030 	mov	r7,a
      003D15 7E 00            [12] 1031 	mov	r6,#0x00
      003D17                       1032 00114$:
      003D17 BE 08 00         [24] 1033 	cjne	r6,#0x08,00225$
      003D1A                       1034 00225$:
      003D1A 40 01            [24] 1035 	jc	00226$
      003D1C 22               [24] 1036 	ret
      003D1D                       1037 00226$:
                                   1038 ;	keyboards/ajazz/ak820/ak820_key_override.c:62: vial_key_override_entry_t AK820_STATE_MEM *e = &entries[i];
      003D1D EE               [12] 1039 	mov	a,r6
      003D1E 12 40 71         [24] 1040 	lcall	_ak820_outline_0194
      003D21 24 F9            [12] 1041 	add	a, #_entries
      003D23 FC               [12] 1042 	mov	r4,a
      003D24 74 04            [12] 1043 	mov	a,#(_entries >> 8)
      003D26 35 F0            [12] 1044 	addc	a, b
      003D28 FD               [12] 1045 	mov	r5,a
      003D29 90 05 54         [24] 1046 	mov	dptr,#_activate_e_30000_623
      003D2C 12 38 24         [24] 1047 	lcall	_ak820_outline_0078
                                   1048 ;	keyboards/ajazz/ak820/ak820_key_override.c:63: if ((uint8_t)e->trigger == trigger && (e->options & ENABLED) && (trigger_down ? (e->options & 1) :
      003D2F 12 40 46         [24] 1049 	lcall	_ak820_outline_0081
      003D32 FB               [12] 1050 	mov	r3,a
      003D33 90 05 49         [24] 1051 	mov	dptr,#_trigger
      003D36 E0               [24] 1052 	movx	a,@dptr
      003D37 FA               [12] 1053 	mov	r2,a
      003D38 EB               [12] 1054 	mov	a,r3
      003D39 B5 02 02         [24] 1055 	cjne	a,ar2,00227$
      003D3C 80 03            [24] 1056 	sjmp	00228$
      003D3E                       1057 00227$:
      003D3E 02 3D BC         [24] 1058 	ljmp	00115$
      003D41                       1059 00228$:
      003D41 74 09            [12] 1060 	mov	a,#0x09
      003D43 12 40 3D         [24] 1061 	lcall	_ak820_outline_0042
      003D46 FB               [12] 1062 	mov	r3,a
      003D47 20 E7 03         [24] 1063 	jb	acc.7,00229$
      003D4A 02 3D BC         [24] 1064 	ljmp	00115$
      003D4D                       1065 00229$:
      003D4D EF               [12] 1066 	mov	a,r7
      003D4E 60 08            [24] 1067 	jz	00118$
      003D50 8B 02            [24] 1068 	mov	ar2,r3
      003D52 53 02 01         [24] 1069 	anl	ar2,#0x01
      003D55 02 3D A2         [24] 1070 	ljmp	00119$
      003D58                       1071 00118$:
                                   1072 ;	keyboards/ajazz/ak820/ak820_key_override.c:64: (((e->options & 2) && (e->trigger_mods & current_mods & ~previous_mods)) ||
      003D58 EB               [12] 1073 	mov	a,r3
      003D59 03               [12] 1074 	rr	a
      003D5A 54 01            [12] 1075 	anl	a,#0x01
      003D5C 60 14            [24] 1076 	jz	00125$
      003D5E 74 06            [12] 1077 	mov	a,#0x06
      003D60 12 40 3D         [24] 1078 	lcall	_ak820_outline_0042
      003D63 FD               [12] 1079 	mov	r5,a
      003D64 90 05 4B         [24] 1080 	mov	dptr,#_current_mods
      003D67 E0               [24] 1081 	movx	a,@dptr
      003D68 52 05            [12] 1082 	anl	ar5,a
      003D6A 90 05 4A         [24] 1083 	mov	dptr,#_previous_mods
      003D6D 12 40 26         [24] 1084 	lcall	_ak820_outline_0036
      003D70 70 29            [24] 1085 	jnz	00121$
      003D72                       1086 00125$:
                                   1087 ;	keyboards/ajazz/ak820/ak820_key_override.c:65: ((e->options & 4) && (e->negative_mod_mask & previous_mods & ~current_mods)))) && eligible(i)) {
      003D72 90 05 54         [24] 1088 	mov	dptr,#_activate_e_30000_623
      003D75 12 38 18         [24] 1089 	lcall	_ak820_outline_0065
      003D78 74 09            [12] 1090 	mov	a,#0x09
      003D7A 12 40 3D         [24] 1091 	lcall	_ak820_outline_0042
      003D7D 03               [12] 1092 	rr	a
      003D7E 03               [12] 1093 	rr	a
      003D7F 54 01            [12] 1094 	anl	a,#0x01
      003D81 60 14            [24] 1095 	jz	00120$
      003D83 74 07            [12] 1096 	mov	a,#0x07
      003D85 12 40 3D         [24] 1097 	lcall	_ak820_outline_0042
      003D88 FD               [12] 1098 	mov	r5,a
      003D89 90 05 4A         [24] 1099 	mov	dptr,#_previous_mods
      003D8C E0               [24] 1100 	movx	a,@dptr
      003D8D 52 05            [12] 1101 	anl	ar5,a
      003D8F 90 05 4B         [24] 1102 	mov	dptr,#_current_mods
      003D92 12 40 26         [24] 1103 	lcall	_ak820_outline_0036
      003D95 70 04            [24] 1104 	jnz	00121$
      003D97                       1105 00120$:
                                   1106 ;	assignBit
      003D97 C2 06            [12] 1107 	clr	_activate_sloc0_1_0
      003D99 80 02            [24] 1108 	sjmp	00122$
      003D9B                       1109 00121$:
                                   1110 ;	assignBit
      003D9B D2 06            [12] 1111 	setb	_activate_sloc0_1_0
      003D9D                       1112 00122$:
      003D9D A2 06            [12] 1113 	mov	c,_activate_sloc0_1_0
      003D9F E4               [12] 1114 	clr	a
      003DA0 33               [12] 1115 	rlc	a
      003DA1 FA               [12] 1116 	mov	r2,a
      003DA2                       1117 00119$:
      003DA2 EA               [12] 1118 	mov	a,r2
      003DA3 60 17            [24] 1119 	jz	00115$
      003DA5 8E 82            [24] 1120 	mov	dpl, r6
      003DA7 C0 07            [24] 1121 	push	ar7
      003DA9 C0 06            [24] 1122 	push	ar6
      003DAB 12 3B DC         [24] 1123 	lcall	_eligible
      003DAE E5 82            [12] 1124 	mov	a, dpl
      003DB0 D0 06            [24] 1125 	pop	ar6
      003DB2 D0 07            [24] 1126 	pop	ar7
      003DB4 60 06            [24] 1127 	jz	00115$
                                   1128 ;	keyboards/ajazz/ak820/ak820_key_override.c:66: active = i;
      003DB6 90 0E 32         [24] 1129 	mov	dptr,#_active
      003DB9 EE               [12] 1130 	mov	a,r6
      003DBA F0               [24] 1131 	movx	@dptr,a
                                   1132 ;	keyboards/ajazz/ak820/ak820_key_override.c:67: return;
      003DBB 22               [24] 1133 	ret
      003DBC                       1134 00115$:
                                   1135 ;	keyboards/ajazz/ak820/ak820_key_override.c:61: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003DBC 0E               [12] 1136 	inc	r6
                                   1137 ;	keyboards/ajazz/ak820/ak820_key_override.c:70: }
      003DBD 02 3D 17         [24] 1138 	ljmp	00114$
                                   1139 ;------------------------------------------------------------
                                   1140 ;Allocation info for local variables in function 'ak820_key_override_sync'
                                   1141 ;------------------------------------------------------------
                                   1142 ;layer         Allocated with name '_ak820_key_override_sync_PARM_2'
                                   1143 ;mods          Allocated with name '_ak820_key_override_sync_mods_10000_626'
                                   1144 ;------------------------------------------------------------
                                   1145 ;	keyboards/ajazz/ak820/ak820_key_override.c:71: void ak820_key_override_sync(uint8_t mods, uint8_t layer) {
                                   1146 ;	-----------------------------------------
                                   1147 ;	 function ak820_key_override_sync
                                   1148 ;	-----------------------------------------
      003DC0                       1149 _ak820_key_override_sync:
      003DC0 E5 82            [12] 1150 	mov	a,dpl
      003DC2 90 05 57         [24] 1151 	mov	dptr,#_ak820_key_override_sync_mods_10000_626
      003DC5 F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	keyboards/ajazz/ak820/ak820_key_override.c:72: current_mods = mods; current_layer = layer;
      003DC6 E0               [24] 1154 	movx	a,@dptr
      003DC7 90 05 4B         [24] 1155 	mov	dptr,#_current_mods
      003DCA F0               [24] 1156 	movx	@dptr,a
      003DCB 90 05 56         [24] 1157 	mov	dptr,#_ak820_key_override_sync_PARM_2
      003DCE E0               [24] 1158 	movx	a,@dptr
      003DCF 90 05 4C         [24] 1159 	mov	dptr,#_current_layer
      003DD2 F0               [24] 1160 	movx	@dptr,a
                                   1161 ;	keyboards/ajazz/ak820/ak820_key_override.c:73: if (active != NONE && !eligible(active)) deactivate();
      003DD3 12 40 60         [24] 1162 	lcall	_ak820_outline_0128
      003DD6 BF FF 02         [24] 1163 	cjne	r7,#0xff,00120$
      003DD9 80 0C            [24] 1164 	sjmp	00102$
      003DDB                       1165 00120$:
      003DDB 8F 82            [24] 1166 	mov	dpl, r7
      003DDD 12 3B DC         [24] 1167 	lcall	_eligible
      003DE0 E5 82            [12] 1168 	mov	a, dpl
      003DE2 70 03            [24] 1169 	jnz	00102$
      003DE4 12 3C 72         [24] 1170 	lcall	_deactivate
      003DE7                       1171 00102$:
                                   1172 ;	keyboards/ajazz/ak820/ak820_key_override.c:74: activate(false);
      003DE7 75 82 00         [24] 1173 	mov	dpl, #0x00
      003DEA 12 3C E6         [24] 1174 	lcall	_activate
                                   1175 ;	keyboards/ajazz/ak820/ak820_key_override.c:75: previous_mods = mods;
      003DED 90 05 57         [24] 1176 	mov	dptr,#_ak820_key_override_sync_mods_10000_626
      003DF0 E0               [24] 1177 	movx	a,@dptr
      003DF1 90 05 4A         [24] 1178 	mov	dptr,#_previous_mods
      003DF4 F0               [24] 1179 	movx	@dptr,a
                                   1180 ;	keyboards/ajazz/ak820/ak820_key_override.c:76: }
      003DF5 22               [24] 1181 	ret
                                   1182 ;------------------------------------------------------------
                                   1183 ;Allocation info for local variables in function 'ak820_key_override_process'
                                   1184 ;------------------------------------------------------------
                                   1185 ;sloc0         Allocated with name '_ak820_key_override_process_sloc0_1_0'
                                   1186 ;mods          Allocated with name '_ak820_key_override_process_PARM_2'
                                   1187 ;layer         Allocated with name '_ak820_key_override_process_PARM_3'
                                   1188 ;record        Allocated with name '_ak820_key_override_process_record_10000_629'
                                   1189 ;key           Allocated with name '_ak820_key_override_process_key_10000_630'
                                   1190 ;id            Allocated with name '_ak820_key_override_process_id_10000_630'
                                   1191 ;i             Allocated with name '_ak820_key_override_process_i_20000_647'
                                   1192 ;------------------------------------------------------------
                                   1193 ;	keyboards/ajazz/ak820/ak820_key_override.c:77: bool ak820_key_override_process(keyrecord_t AK820_STATE_MEM *record, uint8_t mods, uint8_t layer) {
                                   1194 ;	-----------------------------------------
                                   1195 ;	 function ak820_key_override_process
                                   1196 ;	-----------------------------------------
      003DF6                       1197 _ak820_key_override_process:
      003DF6 12 38 42         [24] 1198 	lcall	_ak820_outline_0108
      003DF9 90 05 5A         [24] 1199 	mov	dptr,#_ak820_key_override_process_record_10000_629
      003DFC 12 38 47         [24] 1200 	lcall	_ak820_outline_0109
                                   1201 ;	keyboards/ajazz/ak820/ak820_key_override.c:78: uint16_t key = record->keycode;
      003DFF 90 05 5A         [24] 1202 	mov	dptr,#_ak820_key_override_process_record_10000_629
      003E02 12 37 99         [24] 1203 	lcall	_ak820_outline_0001
                                   1204 ;	keyboards/ajazz/ak820/ak820_key_override.c:80: ak820_key_override_sync(mods, layer);
      003E05 90 05 58         [24] 1205 	mov	dptr,#_ak820_key_override_process_PARM_2
      003E08 E0               [24] 1206 	movx	a,@dptr
      003E09 FB               [12] 1207 	mov	r3,a
      003E0A 90 05 59         [24] 1208 	mov	dptr,#_ak820_key_override_process_PARM_3
      003E0D E0               [24] 1209 	movx	a,@dptr
      003E0E 90 05 56         [24] 1210 	mov	dptr,#_ak820_key_override_sync_PARM_2
      003E11 F0               [24] 1211 	movx	@dptr,a
      003E12 8B 82            [24] 1212 	mov	dpl, r3
      003E14 C0 07            [24] 1213 	push	ar7
      003E16 C0 06            [24] 1214 	push	ar6
      003E18 C0 05            [24] 1215 	push	ar5
      003E1A C0 04            [24] 1216 	push	ar4
      003E1C 12 3D C0         [24] 1217 	lcall	_ak820_key_override_sync
      003E1F D0 04            [24] 1218 	pop	ar4
      003E21 D0 05            [24] 1219 	pop	ar5
      003E23 D0 06            [24] 1220 	pop	ar6
      003E25 D0 07            [24] 1221 	pop	ar7
                                   1222 ;	keyboards/ajazz/ak820/ak820_key_override.c:81: if (key >= QK_KEY_OVERRIDE_TOGGLE && key <= QK_KEY_OVERRIDE_OFF) {
      003E27 8C 02            [24] 1223 	mov	ar2,r4
      003E29 8D 03            [24] 1224 	mov	ar3,r5
      003E2B C3               [12] 1225 	clr	c
      003E2C EA               [12] 1226 	mov	a,r2
      003E2D 94 5D            [12] 1227 	subb	a,#0x5d
      003E2F EB               [12] 1228 	mov	a,r3
      003E30 94 7C            [12] 1229 	subb	a,#0x7c
      003E32 40 45            [24] 1230 	jc	00112$
      003E34 74 5F            [12] 1231 	mov	a,#0x5f
      003E36 9A               [12] 1232 	subb	a,r2
      003E37 74 7C            [12] 1233 	mov	a,#0x7c
      003E39 9B               [12] 1234 	subb	a,r3
      003E3A 40 3D            [24] 1235 	jc	00112$
                                   1236 ;	free result
                                   1237 ;	keyboards/ajazz/ak820/ak820_key_override.c:82: if (record->event.pressed) {
      003E3C 12 37 AD         [24] 1238 	lcall	_ak820_outline_0004
      003E3F 60 34            [24] 1239 	jz	00110$
                                   1240 ;	keyboards/ajazz/ak820/ak820_key_override.c:83: if (key == QK_KEY_OVERRIDE_ON) enabled = true;
      003E41 BA 5E 0B         [24] 1241 	cjne	r2,#0x5e,00105$
      003E44 BB 7C 08         [24] 1242 	cjne	r3,#0x7c,00105$
      003E47 90 0E 33         [24] 1243 	mov	dptr,#_enabled
      003E4A 74 01            [12] 1244 	mov	a,#0x01
      003E4C F0               [24] 1245 	movx	@dptr,a
      003E4D 80 17            [24] 1246 	sjmp	00106$
      003E4F                       1247 00105$:
                                   1248 ;	keyboards/ajazz/ak820/ak820_key_override.c:84: else if (key == QK_KEY_OVERRIDE_OFF) enabled = false;
      003E4F BA 5F 0A         [24] 1249 	cjne	r2,#0x5f,00102$
      003E52 BB 7C 07         [24] 1250 	cjne	r3,#0x7c,00102$
      003E55 90 0E 33         [24] 1251 	mov	dptr,#_enabled
      003E58 E4               [12] 1252 	clr	a
      003E59 F0               [24] 1253 	movx	@dptr,a
      003E5A 80 0A            [24] 1254 	sjmp	00106$
      003E5C                       1255 00102$:
                                   1256 ;	keyboards/ajazz/ak820/ak820_key_override.c:85: else enabled = !enabled;
      003E5C 90 0E 33         [24] 1257 	mov	dptr,#_enabled
      003E5F E0               [24] 1258 	movx	a,@dptr
      003E60 B4 01 00         [24] 1259 	cjne	a,#0x01,00289$
      003E63                       1260 00289$:
      003E63 E4               [12] 1261 	clr	a
      003E64 33               [12] 1262 	rlc	a
      003E65 F0               [24] 1263 	movx	@dptr,a
      003E66                       1264 00106$:
                                   1265 ;	keyboards/ajazz/ak820/ak820_key_override.c:86: if (!enabled) { deactivate(); blocked = true; }
      003E66 90 0E 33         [24] 1266 	mov	dptr,#_enabled
      003E69 E0               [24] 1267 	movx	a,@dptr
      003E6A 70 09            [24] 1268 	jnz	00110$
      003E6C 12 3C 72         [24] 1269 	lcall	_deactivate
      003E6F 90 05 4D         [24] 1270 	mov	dptr,#_blocked
      003E72 74 01            [12] 1271 	mov	a,#0x01
      003E74 F0               [24] 1272 	movx	@dptr,a
      003E75                       1273 00110$:
                                   1274 ;	keyboards/ajazz/ak820/ak820_key_override.c:88: return false;
      003E75 75 82 00         [24] 1275 	mov	dpl, #0x00
      003E78 22               [24] 1276 	ret
      003E79                       1277 00112$:
                                   1278 ;	keyboards/ajazz/ak820/ak820_key_override.c:90: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) return true;
      003E79 90 05 5A         [24] 1279 	mov	dptr,#_ak820_key_override_process_record_10000_629
      003E7C E0               [24] 1280 	movx	a,@dptr
      003E7D F5 0A            [12] 1281 	mov	_ak820_key_override_process_sloc0_1_0,a
      003E7F A3               [24] 1282 	inc	dptr
      003E80 E0               [24] 1283 	movx	a,@dptr
      003E81 F5 0B            [12] 1284 	mov	(_ak820_key_override_process_sloc0_1_0 + 1),a
      003E83 85 0A 82         [24] 1285 	mov	dpl,_ak820_key_override_process_sloc0_1_0
      003E86 85 0B 83         [24] 1286 	mov	dph,(_ak820_key_override_process_sloc0_1_0 + 1)
      003E89 A3               [24] 1287 	inc	dptr
      003E8A E0               [24] 1288 	movx	a,@dptr
      003E8B F9               [12] 1289 	mov	r1,a
      003E8C B9 10 00         [24] 1290 	cjne	r1,#0x10,00291$
      003E8F                       1291 00291$:
      003E8F 50 0D            [24] 1292 	jnc	00114$
      003E91 85 0A 82         [24] 1293 	mov	dpl,_ak820_key_override_process_sloc0_1_0
      003E94 85 0B 83         [24] 1294 	mov	dph,(_ak820_key_override_process_sloc0_1_0 + 1)
      003E97 E0               [24] 1295 	movx	a,@dptr
      003E98 F8               [12] 1296 	mov	r0,a
      003E99 B8 08 00         [24] 1297 	cjne	r0,#0x08,00293$
      003E9C                       1298 00293$:
      003E9C 40 04            [24] 1299 	jc	00115$
      003E9E                       1300 00114$:
      003E9E 75 82 01         [24] 1301 	mov	dpl, #0x01
      003EA1 22               [24] 1302 	ret
      003EA2                       1303 00115$:
                                   1304 ;	keyboards/ajazz/ak820/ak820_key_override.c:91: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003EA2 E9               [12] 1305 	mov	a,r1
      003EA3 12 38 82         [24] 1306 	lcall	_ak820_outline_0193
      003EA6 28               [12] 1307 	add	a,r0
      003EA7 F9               [12] 1308 	mov	r1,a
                                   1309 ;	keyboards/ajazz/ak820/ak820_key_override.c:92: if (source == id) {
      003EA8 90 0E 31         [24] 1310 	mov	dptr,#_source
      003EAB E0               [24] 1311 	movx	a,@dptr
      003EAC B5 01 17         [24] 1312 	cjne	a,ar1,00120$
                                   1313 ;	keyboards/ajazz/ak820/ak820_key_override.c:93: if (!record->event.pressed) ak820_key_override_cancel();
      003EAF 74 05            [12] 1314 	mov	a,#0x05
      003EB1 25 0A            [12] 1315 	add	a, _ak820_key_override_process_sloc0_1_0
      003EB3 F8               [12] 1316 	mov	r0,a
      003EB4 E4               [12] 1317 	clr	a
      003EB5 35 0B            [12] 1318 	addc	a, (_ak820_key_override_process_sloc0_1_0 + 1)
      003EB7 FF               [12] 1319 	mov	r7,a
      003EB8 88 82            [24] 1320 	mov	dpl,r0
      003EBA 8F 83            [24] 1321 	mov	dph,r7
      003EBC E0               [24] 1322 	movx	a,@dptr
      003EBD 70 03            [24] 1323 	jnz	00118$
      003EBF 12 3C 93         [24] 1324 	lcall	_ak820_key_override_cancel
      003EC2                       1325 00118$:
                                   1326 ;	keyboards/ajazz/ak820/ak820_key_override.c:94: return false;
      003EC2 75 82 00         [24] 1327 	mov	dpl, #0x00
      003EC5 22               [24] 1328 	ret
      003EC6                       1329 00120$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_key_override.c:96: if (!record->event.pressed) return true;
      003EC6 74 05            [12] 1331 	mov	a,#0x05
      003EC8 25 0A            [12] 1332 	add	a, _ak820_key_override_process_sloc0_1_0
      003ECA FE               [12] 1333 	mov	r6,a
      003ECB E4               [12] 1334 	clr	a
      003ECC 35 0B            [12] 1335 	addc	a, (_ak820_key_override_process_sloc0_1_0 + 1)
      003ECE FF               [12] 1336 	mov	r7,a
      003ECF 12 38 30         [24] 1337 	lcall	_ak820_outline_0098
      003ED2 70 04            [24] 1338 	jnz	00122$
      003ED4 75 82 01         [24] 1339 	mov	dpl, #0x01
      003ED7 22               [24] 1340 	ret
      003ED8                       1341 00122$:
                                   1342 ;	keyboards/ajazz/ak820/ak820_key_override.c:97: if (active != NONE && !(entries[active].options & 32) && !(key >= KC_LEFT_CTRL && key <= KC_RIGHT_GUI)) {
      003ED8 12 40 60         [24] 1343 	lcall	_ak820_outline_0128
      003EDB BF FF 02         [24] 1344 	cjne	r7,#0xff,00299$
      003EDE 80 39            [24] 1345 	sjmp	00124$
      003EE0                       1346 00299$:
      003EE0 EF               [12] 1347 	mov	a,r7
      003EE1 12 40 0F         [24] 1348 	lcall	_ak820_outline_0016
      003EE4 74 09            [12] 1349 	mov	a,#0x09
      003EE6 12 37 CE         [24] 1350 	lcall	_ak820_outline_0013
      003EE9 20 E5 2D         [24] 1351 	jb	acc.5,00124$
      003EEC C3               [12] 1352 	clr	c
      003EED EA               [12] 1353 	mov	a,r2
      003EEE 94 E0            [12] 1354 	subb	a,#0xe0
      003EF0 EB               [12] 1355 	mov	a,r3
      003EF1 94 00            [12] 1356 	subb	a,#0x00
      003EF3 40 07            [24] 1357 	jc	00123$
      003EF5 74 E7            [12] 1358 	mov	a,#0xe7
      003EF7 9A               [12] 1359 	subb	a,r2
      003EF8 E4               [12] 1360 	clr	a
      003EF9 9B               [12] 1361 	subb	a,r3
      003EFA 50 1D            [24] 1362 	jnc	00124$
                                   1363 ;	free result
      003EFC                       1364 00123$:
                                   1365 ;	keyboards/ajazz/ak820/ak820_key_override.c:98: deactivate(); blocked = true;
      003EFC C0 05            [24] 1366 	push	ar5
      003EFE C0 04            [24] 1367 	push	ar4
      003F00 C0 03            [24] 1368 	push	ar3
      003F02 C0 02            [24] 1369 	push	ar2
      003F04 C0 01            [24] 1370 	push	ar1
      003F06 12 3C 72         [24] 1371 	lcall	_deactivate
      003F09 D0 01            [24] 1372 	pop	ar1
      003F0B D0 02            [24] 1373 	pop	ar2
      003F0D D0 03            [24] 1374 	pop	ar3
      003F0F D0 04            [24] 1375 	pop	ar4
      003F11 D0 05            [24] 1376 	pop	ar5
      003F13 90 05 4D         [24] 1377 	mov	dptr,#_blocked
      003F16 74 01            [12] 1378 	mov	a,#0x01
      003F18 F0               [24] 1379 	movx	@dptr,a
      003F19                       1380 00124$:
                                   1381 ;	keyboards/ajazz/ak820/ak820_key_override.c:100: if (source != NONE || !enabled || !basic(key)) return true;
      003F19 90 0E 31         [24] 1382 	mov	dptr,#_source
      003F1C E0               [24] 1383 	movx	a,@dptr
      003F1D FF               [12] 1384 	mov	r7,a
      003F1E BF FF 16         [24] 1385 	cjne	r7,#0xff,00128$
      003F21 90 0E 33         [24] 1386 	mov	dptr,#_enabled
      003F24 E0               [24] 1387 	movx	a,@dptr
      003F25 60 10            [24] 1388 	jz	00128$
      003F27 C3               [12] 1389 	clr	c
      003F28 EA               [12] 1390 	mov	a,r2
      003F29 94 04            [12] 1391 	subb	a,#0x04
      003F2B EB               [12] 1392 	mov	a,r3
      003F2C 94 00            [12] 1393 	subb	a,#0x00
      003F2E 40 07            [24] 1394 	jc	00128$
      003F30 74 A4            [12] 1395 	mov	a,#0xa4
      003F32 9A               [12] 1396 	subb	a,r2
      003F33 E4               [12] 1397 	clr	a
      003F34 9B               [12] 1398 	subb	a,r3
      003F35 50 04            [24] 1399 	jnc	00181$
                                   1400 ;	free result
      003F37                       1401 00128$:
      003F37 75 82 01         [24] 1402 	mov	dpl, #0x01
                                   1403 ;	keyboards/ajazz/ak820/ak820_key_override.c:101: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003F3A 22               [24] 1404 	ret
      003F3B                       1405 00181$:
      003F3B 7F 00            [12] 1406 	mov	r7,#0x00
      003F3D                       1407 00138$:
      003F3D BF 08 00         [24] 1408 	cjne	r7,#0x08,00308$
      003F40                       1409 00308$:
      003F40 50 40            [24] 1410 	jnc	00136$
                                   1411 ;	keyboards/ajazz/ak820/ak820_key_override.c:102: if ((uint8_t)entries[i].trigger == (uint8_t)key && (entries[i].options & ENABLED)) {
      003F42 EF               [12] 1412 	mov	a,r7
      003F43 12 40 71         [24] 1413 	lcall	_ak820_outline_0194
      003F46 24 F9            [12] 1414 	add	a, #_entries
      003F48 FB               [12] 1415 	mov	r3,a
      003F49 74 04            [12] 1416 	mov	a,#(_entries >> 8)
      003F4B 35 F0            [12] 1417 	addc	a, b
      003F4D FE               [12] 1418 	mov	r6,a
      003F4E 8B 82            [24] 1419 	mov	dpl,r3
      003F50 8E 83            [24] 1420 	mov	dph,r6
      003F52 E0               [24] 1421 	movx	a,@dptr
      003F53 8C 00            [24] 1422 	mov	ar0,r4
      003F55 B5 00 27         [24] 1423 	cjne	a,ar0,00139$
      003F58 74 09            [12] 1424 	mov	a,#0x09
      003F5A 2B               [12] 1425 	add	a, r3
      003F5B 12 40 59         [24] 1426 	lcall	_ak820_outline_0117
      003F5E E0               [24] 1427 	movx	a,@dptr
      003F5F 30 E7 1D         [24] 1428 	jnb	acc.7,00139$
                                   1429 ;	keyboards/ajazz/ak820/ak820_key_override.c:103: source = id; trigger = key; hidden = blocked = false;
      003F62 90 0E 31         [24] 1430 	mov	dptr,#_source
      003F65 E9               [12] 1431 	mov	a,r1
      003F66 F0               [24] 1432 	movx	@dptr,a
      003F67 90 05 49         [24] 1433 	mov	dptr,#_trigger
      003F6A E8               [12] 1434 	mov	a,r0
      003F6B F0               [24] 1435 	movx	@dptr,a
      003F6C 90 05 4D         [24] 1436 	mov	dptr,#_blocked
      003F6F E4               [12] 1437 	clr	a
      003F70 F0               [24] 1438 	movx	@dptr,a
      003F71 90 05 4E         [24] 1439 	mov	dptr,#_hidden
      003F74 F0               [24] 1440 	movx	@dptr,a
                                   1441 ;	keyboards/ajazz/ak820/ak820_key_override.c:104: activate(true);
      003F75 75 82 01         [24] 1442 	mov	dpl, #0x01
      003F78 12 3C E6         [24] 1443 	lcall	_activate
                                   1444 ;	keyboards/ajazz/ak820/ak820_key_override.c:105: return false;
      003F7B 75 82 00         [24] 1445 	mov	dpl, #0x00
      003F7E 22               [24] 1446 	ret
      003F7F                       1447 00139$:
                                   1448 ;	keyboards/ajazz/ak820/ak820_key_override.c:101: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003F7F 0F               [12] 1449 	inc	r7
      003F80 80 BB            [24] 1450 	sjmp	00138$
      003F82                       1451 00136$:
                                   1452 ;	keyboards/ajazz/ak820/ak820_key_override.c:108: return true;
      003F82 75 82 01         [24] 1453 	mov	dpl, #0x01
                                   1454 ;	keyboards/ajazz/ak820/ak820_key_override.c:109: }
      003F85 22               [24] 1455 	ret
                                   1456 ;------------------------------------------------------------
                                   1457 ;Allocation info for local variables in function 'ak820_key_override_key'
                                   1458 ;------------------------------------------------------------
                                   1459 ;	keyboards/ajazz/ak820/ak820_key_override.c:110: uint8_t ak820_key_override_key(void) {
                                   1460 ;	-----------------------------------------
                                   1461 ;	 function ak820_key_override_key
                                   1462 ;	-----------------------------------------
      003F86                       1463 _ak820_key_override_key:
                                   1464 ;	keyboards/ajazz/ak820/ak820_key_override.c:111: if (source == NONE || hidden) return 0;
      003F86 90 0E 31         [24] 1465 	mov	dptr,#_source
      003F89 E0               [24] 1466 	movx	a,@dptr
      003F8A FF               [12] 1467 	mov	r7,a
      003F8B BF FF 02         [24] 1468 	cjne	r7,#0xff,00122$
      003F8E 80 06            [24] 1469 	sjmp	00101$
      003F90                       1470 00122$:
      003F90 90 05 4E         [24] 1471 	mov	dptr,#_hidden
      003F93 E0               [24] 1472 	movx	a,@dptr
      003F94 60 04            [24] 1473 	jz	00102$
      003F96                       1474 00101$:
      003F96 75 82 00         [24] 1475 	mov	dpl, #0x00
      003F99 22               [24] 1476 	ret
      003F9A                       1477 00102$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_key_override.c:112: return active == NONE ? trigger : (uint8_t)entries[active].replacement;
      003F9A 12 40 60         [24] 1479 	lcall	_ak820_outline_0128
      003F9D BF FF 07         [24] 1480 	cjne	r7,#0xff,00106$
      003FA0 90 05 49         [24] 1481 	mov	dptr,#_trigger
      003FA3 E0               [24] 1482 	movx	a,@dptr
      003FA4 FE               [12] 1483 	mov	r6,a
      003FA5 80 0B            [24] 1484 	sjmp	00107$
      003FA7                       1485 00106$:
      003FA7 12 40 4C         [24] 1486 	lcall	_ak820_outline_0101
      003FAA FF               [12] 1487 	mov	r7,a
      003FAB 12 40 6C         [24] 1488 	lcall	_ak820_outline_0190
      003FAE A3               [24] 1489 	inc	dptr
      003FAF A3               [24] 1490 	inc	dptr
      003FB0 E0               [24] 1491 	movx	a,@dptr
      003FB1 FE               [12] 1492 	mov	r6,a
      003FB2                       1493 00107$:
      003FB2 8E 82            [24] 1494 	mov	dpl, r6
                                   1495 ;	keyboards/ajazz/ak820/ak820_key_override.c:113: }
      003FB4 22               [24] 1496 	ret
                                   1497 ;------------------------------------------------------------
                                   1498 ;Allocation info for local variables in function 'ak820_key_override_mods'
                                   1499 ;------------------------------------------------------------
                                   1500 ;mods          Allocated with name '_ak820_key_override_mods_mods_10000_654'
                                   1501 ;replacement   Allocated with name '_ak820_key_override_mods_replacement_10000_655'
                                   1502 ;------------------------------------------------------------
                                   1503 ;	keyboards/ajazz/ak820/ak820_key_override.c:114: uint8_t ak820_key_override_mods(uint8_t mods) {
                                   1504 ;	-----------------------------------------
                                   1505 ;	 function ak820_key_override_mods
                                   1506 ;	-----------------------------------------
      003FB5                       1507 _ak820_key_override_mods:
      003FB5 E5 82            [12] 1508 	mov	a,dpl
      003FB7 90 05 5C         [24] 1509 	mov	dptr,#_ak820_key_override_mods_mods_10000_654
      003FBA F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_key_override.c:116: if (active == NONE) return mods;
      003FBB 12 40 60         [24] 1512 	lcall	_ak820_outline_0128
      003FBE BF FF 07         [24] 1513 	cjne	r7,#0xff,00102$
      003FC1 90 05 5C         [24] 1514 	mov	dptr,#_ak820_key_override_mods_mods_10000_654
      003FC4 E0               [24] 1515 	movx	a,@dptr
      003FC5 F5 82            [12] 1516 	mov	dpl,a
      003FC7 22               [24] 1517 	ret
      003FC8                       1518 00102$:
                                   1519 ;	keyboards/ajazz/ak820/ak820_key_override.c:117: replacement = entries[active].replacement >> 8;
      003FC8 EF               [12] 1520 	mov	a,r7
      003FC9 12 40 0F         [24] 1521 	lcall	_ak820_outline_0016
      003FCC 12 37 E9         [24] 1522 	lcall	_ak820_outline_0032
      003FCF A3               [24] 1523 	inc	dptr
      003FD0 E0               [24] 1524 	movx	a,@dptr
      003FD1 FD               [12] 1525 	mov	r5,a
      003FD2 90 05 5D         [24] 1526 	mov	dptr,#_ak820_key_override_mods_replacement_10000_655
      003FD5 F0               [24] 1527 	movx	@dptr,a
                                   1528 ;	keyboards/ajazz/ak820/ak820_key_override.c:118: if (replacement & 16) replacement = (replacement & 15) << 4;
      003FD6 ED               [12] 1529 	mov	a,r5
      003FD7 30 E4 0B         [24] 1530 	jnb	acc.4,00104$
      003FDA 53 05 0F         [24] 1531 	anl	ar5,#0x0f
      003FDD ED               [12] 1532 	mov	a,r5
      003FDE C4               [12] 1533 	swap	a
      003FDF 54 F0            [12] 1534 	anl	a,#0xf0
      003FE1 90 05 5D         [24] 1535 	mov	dptr,#_ak820_key_override_mods_replacement_10000_655
      003FE4 F0               [24] 1536 	movx	@dptr,a
      003FE5                       1537 00104$:
                                   1538 ;	keyboards/ajazz/ak820/ak820_key_override.c:119: return (mods & ~entries[active].suppressed_mods) | replacement;
      003FE5 74 08            [12] 1539 	mov	a,#0x08
      003FE7 12 37 CE         [24] 1540 	lcall	_ak820_outline_0013
      003FEA FF               [12] 1541 	mov	r7,a
      003FEB 63 07 FF         [24] 1542 	xrl	ar7,#0xff
      003FEE 90 05 5C         [24] 1543 	mov	dptr,#_ak820_key_override_mods_mods_10000_654
      003FF1 E0               [24] 1544 	movx	a,@dptr
      003FF2 52 07            [12] 1545 	anl	ar7,a
      003FF4 90 05 5D         [24] 1546 	mov	dptr,#_ak820_key_override_mods_replacement_10000_655
      003FF7 12 40 66         [24] 1547 	lcall	_ak820_outline_0130
                                   1548 ;	keyboards/ajazz/ak820/ak820_key_override.c:120: }
      003FFA 22               [24] 1549 	ret
                                   1550 ;------------------------------------------------------------
                                   1551 ;Allocation info for local variables in function 'ak820_key_override_enabled'
                                   1552 ;------------------------------------------------------------
                                   1553 ;	keyboards/ajazz/ak820/ak820_key_override.c:121: bool ak820_key_override_enabled(void) { return enabled; }
                                   1554 ;	-----------------------------------------
                                   1555 	.area CSEG    (CODE)
                                   1556 	.area CONST   (CODE)
                                   1557 	.area XINIT   (CODE)
      00C69A                       1558 __xinit__source:
      00C69A FF                    1559 	.db #0xff	; 255
      00C69B                       1560 __xinit__active:
      00C69B FF                    1561 	.db #0xff	; 255
      00C69C                       1562 __xinit__enabled:
      00C69C 01                    1563 	.db #0x01	;  1
                                   1564 	.area CABS    (ABS,CODE)
                                   1565 
                                   1566 ; Experimental exact instruction outlining.
                                   1567 	.globl _ak820_outline_0001
                                   1568 	.globl _ak820_outline_0004
                                   1569 	.globl _ak820_outline_0009
                                   1570 	.globl _ak820_outline_0013
                                   1571 	.globl _ak820_outline_0015
                                   1572 	.globl _ak820_outline_0016
                                   1573 	.globl _ak820_outline_0017
                                   1574 	.globl _ak820_outline_0032
                                   1575 	.globl _ak820_outline_0036
                                   1576 	.globl _ak820_outline_0042
                                   1577 	.globl _ak820_outline_0056
                                   1578 	.globl _ak820_outline_0065
                                   1579 	.globl _ak820_outline_0076
                                   1580 	.globl _ak820_outline_0078
                                   1581 	.globl _ak820_outline_0081
                                   1582 	.globl _ak820_outline_0098
                                   1583 	.globl _ak820_outline_0101
                                   1584 	.globl _ak820_outline_0108
                                   1585 	.globl _ak820_outline_0109
                                   1586 	.globl _ak820_outline_0117
                                   1587 	.globl _ak820_outline_0127
                                   1588 	.globl _ak820_outline_0128
                                   1589 	.globl _ak820_outline_0130
                                   1590 	.globl _ak820_outline_0150
                                   1591 	.globl _ak820_outline_0190
                                   1592 	.globl _ak820_outline_0193
                                   1593 	.globl _ak820_outline_0194
                                   1594 
                                   1595 	.area CSEG (CODE)
                                   1596 ; function ak820_outline_0009
      003FFB                       1597 _ak820_outline_0009:
      003FFB 2E               [12] 1598 	add	a,r6
      003FFC FC               [12] 1599 	mov	r4,a
      003FFD E4               [12] 1600 	clr	a
      003FFE 3F               [12] 1601 	addc	a,r7
      003FFF FD               [12] 1602 	mov	r5,a
      004000 8C 82            [24] 1603 	mov	dpl,r4
      004002 8D 83            [24] 1604 	mov	dph,r5
      004004 E0               [24] 1605 	movx	a,@dptr
      004005 22               [24] 1606 	ret
                                   1607 
                                   1608 	.area CSEG (CODE)
                                   1609 ; function ak820_outline_0015
      004006                       1610 _ak820_outline_0015:
      004006 8E 82            [24] 1611 	mov	dpl,r6
      004008 8F 83            [24] 1612 	mov	dph,r7
      00400A A3               [24] 1613 	inc	dptr
      00400B A3               [24] 1614 	inc	dptr
      00400C A3               [24] 1615 	inc	dptr
      00400D E0               [24] 1616 	movx	a,@dptr
      00400E 22               [24] 1617 	ret
                                   1618 
                                   1619 	.area CSEG (CODE)
                                   1620 ; function ak820_outline_0016
      00400F                       1621 _ak820_outline_0016:
      00400F 75 F0 0A         [24] 1622 	mov	b,#0x0a
      004012 A4               [48] 1623 	mul	ab
      004013 24 F9            [12] 1624 	add	a,#_entries
      004015 FE               [12] 1625 	mov	r6,a
      004016 74 04            [12] 1626 	mov	a,#(_entries>>8)
      004018 35 F0            [12] 1627 	addc	a,b
      00401A FF               [12] 1628 	mov	r7,a
      00401B 22               [24] 1629 	ret
                                   1630 
                                   1631 	.area CSEG (CODE)
                                   1632 ; function ak820_outline_0017
      00401C                       1633 _ak820_outline_0017:
      00401C 8E 82            [24] 1634 	mov	dpl,r6
      00401E 8F 83            [24] 1635 	mov	dph,r7
      004020 A3               [24] 1636 	inc	dptr
      004021 A3               [24] 1637 	inc	dptr
      004022 A3               [24] 1638 	inc	dptr
      004023 A3               [24] 1639 	inc	dptr
      004024 E0               [24] 1640 	movx	a,@dptr
      004025 22               [24] 1641 	ret
                                   1642 
                                   1643 	.area CSEG (CODE)
                                   1644 ; function ak820_outline_0036
      004026                       1645 _ak820_outline_0036:
      004026 E0               [24] 1646 	movx	a,@dptr
      004027 FB               [12] 1647 	mov	r3,a
      004028 7C 00            [12] 1648 	mov	r4,#0x00
      00402A 63 03 FF         [24] 1649 	xrl	ar3,#0xff
      00402D 63 04 FF         [24] 1650 	xrl	ar4,#0xff
      004030 8D 01            [24] 1651 	mov	ar1,r5
      004032 7D 00            [12] 1652 	mov	r5,#0x00
      004034 E9               [12] 1653 	mov	a,r1
      004035 52 03            [12] 1654 	anl	ar3,a
      004037 ED               [12] 1655 	mov	a,r5
      004038 52 04            [12] 1656 	anl	ar4,a
      00403A EB               [12] 1657 	mov	a,r3
      00403B 4C               [12] 1658 	orl	a,r4
      00403C 22               [24] 1659 	ret
                                   1660 
                                   1661 	.area CSEG (CODE)
                                   1662 ; function ak820_outline_0042
      00403D                       1663 _ak820_outline_0042:
      00403D 2C               [12] 1664 	add	a,r4
      00403E F5 82            [12] 1665 	mov	dpl,a
      004040 E4               [12] 1666 	clr	a
      004041 3D               [12] 1667 	addc	a,r5
      004042 F5 83            [12] 1668 	mov	dph,a
      004044 E0               [24] 1669 	movx	a,@dptr
      004045 22               [24] 1670 	ret
                                   1671 
                                   1672 	.area CSEG (CODE)
                                   1673 ; function ak820_outline_0081
      004046                       1674 _ak820_outline_0081:
      004046 8C 82            [24] 1675 	mov	dpl,r4
      004048 8D 83            [24] 1676 	mov	dph,r5
      00404A E0               [24] 1677 	movx	a,@dptr
      00404B 22               [24] 1678 	ret
                                   1679 
                                   1680 	.area CSEG (CODE)
                                   1681 ; function ak820_outline_0101
      00404C                       1682 _ak820_outline_0101:
      00404C EF               [12] 1683 	mov	a,r7
      00404D 75 F0 0A         [24] 1684 	mov	b,#0x0a
      004050 A4               [48] 1685 	mul	ab
      004051 24 F9            [12] 1686 	add	a,#_entries
      004053 FD               [12] 1687 	mov	r5,a
      004054 74 04            [12] 1688 	mov	a,#(_entries>>8)
      004056 35 F0            [12] 1689 	addc	a,b
      004058 22               [24] 1690 	ret
                                   1691 
                                   1692 	.area CSEG (CODE)
                                   1693 ; function ak820_outline_0117
      004059                       1694 _ak820_outline_0117:
      004059 F5 82            [12] 1695 	mov	dpl,a
      00405B E4               [12] 1696 	clr	a
      00405C 3E               [12] 1697 	addc	a,r6
      00405D F5 83            [12] 1698 	mov	dph,a
      00405F 22               [24] 1699 	ret
                                   1700 
                                   1701 	.area CSEG (CODE)
                                   1702 ; function ak820_outline_0128
      004060                       1703 _ak820_outline_0128:
      004060 90 0E 32         [24] 1704 	mov	dptr,#_active
      004063 E0               [24] 1705 	movx	a,@dptr
      004064 FF               [12] 1706 	mov	r7,a
      004065 22               [24] 1707 	ret
                                   1708 
                                   1709 	.area CSEG (CODE)
                                   1710 ; function ak820_outline_0130
      004066                       1711 _ak820_outline_0130:
      004066 E0               [24] 1712 	movx	a,@dptr
      004067 42 07            [12] 1713 	orl	ar7,a
      004069 8F 82            [24] 1714 	mov	dpl,r7
      00406B 22               [24] 1715 	ret
                                   1716 
                                   1717 	.area CSEG (CODE)
                                   1718 ; function ak820_outline_0190
      00406C                       1719 _ak820_outline_0190:
      00406C 8D 82            [24] 1720 	mov	dpl,r5
      00406E 8F 83            [24] 1721 	mov	dph,r7
      004070 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0194
      004071                       1726 _ak820_outline_0194:
      004071 75 F0 0A         [24] 1727 	mov	b,#0x0a
      004074 A4               [48] 1728 	mul	ab
      004075 22               [24] 1729 	ret
