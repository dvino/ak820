                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      00001E                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      00001E                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000012                        595 _suspended:
      000012                        596 	.ds 1
      000013                        597 _dirty:
      000013                        598 	.ds 1
      000014                        599 _rendering:
      000014                        600 	.ds 1
      000015                        601 _rgb_matrix_task_sloc0_1_0:
      000015                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      000713                        611 _rgb_matrix_config::
      000713                        612 	.ds 8
      00071B                        613 _changed_at:
      00071B                        614 	.ds 2
      00071D                        615 _frame_at:
      00071D                        616 	.ds 2
      00071F                        617 _phase:
      00071F                        618 	.ds 2
      000721                        619 _led_index:
      000721                        620 	.ds 1
      000722                        621 _frame_mode:
      000722                        622 	.ds 1
      000723                        623 _frame_hue:
      000723                        624 	.ds 1
      000724                        625 _frame_sat:
      000724                        626 	.ds 1
      000725                        627 _frame_val:
      000725                        628 	.ds 1
      000726                        629 _frame_flags:
      000726                        630 	.ds 1
      000727                        631 _frame_phase:
      000727                        632 	.ds 1
      000728                        633 _reactive_age:
      000728                        634 	.ds 82
      00077A                        635 _reactive_at:
      00077A                        636 	.ds 2
      00077C                        637 _add_sat_PARM_2:
      00077C                        638 	.ds 1
      00077D                        639 _add_sat_x_10000_266:
      00077D                        640 	.ds 1
      00077E                        641 _sub_sat_PARM_2:
      00077E                        642 	.ds 1
      00077F                        643 _sub_sat_x_10000_268:
      00077F                        644 	.ds 1
      000780                        645 _rgb_matrix_set_color_PARM_2:
      000780                        646 	.ds 1
      000781                        647 _rgb_matrix_set_color_PARM_3:
      000781                        648 	.ds 1
      000782                        649 _rgb_matrix_set_color_PARM_4:
      000782                        650 	.ds 1
      000783                        651 _rgb_matrix_set_color_index_10000_284:
      000783                        652 	.ds 2
      000785                        653 _rgb_matrix_set_color_all_PARM_2:
      000785                        654 	.ds 1
      000786                        655 _rgb_matrix_set_color_all_PARM_3:
      000786                        656 	.ds 1
      000787                        657 _rgb_matrix_set_color_all_r_10000_287:
      000787                        658 	.ds 1
      000788                        659 _sine8_theta_10000_289:
      000788                        660 	.ds 1
      000789                        661 _sine8_offset_10000_290:
      000789                        662 	.ds 1
      00078A                        663 _sine8_fraction_10000_290:
      00078A                        664 	.ds 1
      00078B                        665 _breathing_cie_value_10000_293:
      00078B                        666 	.ds 1
      00078C                        667 _rgb_matrix_task_end_10000_298:
      00078C                        668 	.ds 1
      00078D                        669 _rgb_matrix_task_hsv_10000_298:
      00078D                        670 	.ds 3
      000790                        671 _rgb_matrix_task_rgb_10000_298:
      000790                        672 	.ds 3
      000793                        673 _process_rgb_matrix_PARM_2:
      000793                        674 	.ds 1
      000794                        675 _process_rgb_matrix_PARM_3:
      000794                        676 	.ds 1
      000795                        677 _process_rgb_matrix_row_10000_319:
      000795                        678 	.ds 1
      000796                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      000796                        680 	.ds 1
      000797                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      000797                        682 	.ds 1
      000798                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000798                        684 	.ds 1
      000799                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000799                        686 	.ds 1
      00079A                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      00079A                        688 	.ds 2
      00079C                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      00079C                        690 	.ds 1
      00079D                        691 _rgb_matrix_mode_mode_10000_411:
      00079D                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      00551D                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      00551D 12 5C EF         [24]  746 	lcall	_ak820_outline_0186
      005520 74 52            [12]  747 	mov	a,#0x52
      005522 12 38 59         [24]  748 	lcall	_ak820_outline_0129
      005525 90 07 28         [24]  749 	mov	dptr,#_reactive_age
      005528 F5 F0            [12]  750 	mov	b,a
      00552A 12 BF B9         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      00552D 12 4F 0D         [24]  753 	lcall	_timer_read
      005530 12 38 4E         [24]  754 	lcall	_ak820_outline_0123
      005533 90 07 7A         [24]  755 	mov	dptr,#_reactive_at
      005536 12 5C DB         [24]  756 	lcall	_ak820_outline_0177
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      005539 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      00553A                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      00553A 90 07 7A         [24]  772 	mov	dptr,#_reactive_at
      00553D 12 37 BE         [24]  773 	lcall	_ak820_outline_0007
      005540 12 4F 10         [24]  774 	lcall	_timer_elapsed
      005543 AE 82            [24]  775 	mov	r6, dpl
      005545 E5 83            [12]  776 	mov	a,dph
      005547 C4               [12]  777 	swap	a
      005548 CE               [12]  778 	xch	a,r6
      005549 C4               [12]  779 	swap	a
      00554A 54 0F            [12]  780 	anl	a,#0x0f
      00554C 6E               [12]  781 	xrl	a,r6
      00554D CE               [12]  782 	xch	a,r6
      00554E 54 0F            [12]  783 	anl	a,#0x0f
      005550 CE               [12]  784 	xch	a,r6
      005551 6E               [12]  785 	xrl	a,r6
      005552 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      005553 FF               [12]  788 	mov	r7,a
      005554 4E               [12]  789 	orl	a,r6
      005555 70 01            [24]  790 	jnz	00102$
      005557 22               [24]  791 	ret
      005558                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      005558 8E 04            [24]  794 	mov	ar4,r6
      00555A EF               [12]  795 	mov	a,r7
      00555B C4               [12]  796 	swap	a
      00555C 54 F0            [12]  797 	anl	a,#0xf0
      00555E CC               [12]  798 	xch	a,r4
      00555F C4               [12]  799 	swap	a
      005560 CC               [12]  800 	xch	a,r4
      005561 6C               [12]  801 	xrl	a,r4
      005562 CC               [12]  802 	xch	a,r4
      005563 54 F0            [12]  803 	anl	a,#0xf0
      005565 CC               [12]  804 	xch	a,r4
      005566 6C               [12]  805 	xrl	a,r4
      005567 FD               [12]  806 	mov	r5,a
      005568 90 07 7A         [24]  807 	mov	dptr,#_reactive_at
      00556B 12 49 68         [24]  808 	lcall	_ak820_outline_0126
      00556E 90 07 7A         [24]  809 	mov	dptr,#_reactive_at
      005571 EC               [12]  810 	mov	a,r4
      005572 2A               [12]  811 	add	a, r2
      005573 F0               [24]  812 	movx	@dptr,a
      005574 ED               [12]  813 	mov	a,r5
      005575 3B               [12]  814 	addc	a, r3
      005576 A3               [24]  815 	inc	dptr
      005577 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      005578 8E 04            [24]  818 	mov	ar4,r6
      00557A 8F 05            [24]  819 	mov	ar5,r7
      00557C C3               [12]  820 	clr	c
      00557D 74 FF            [12]  821 	mov	a,#0xff
      00557F 9C               [12]  822 	subb	a,r4
      005580 E4               [12]  823 	clr	a
      005581 9D               [12]  824 	subb	a,r5
      005582 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      005584 7D FF            [12]  827 	mov	r5,#0xff
      005586 80 02            [24]  828 	sjmp	00109$
      005588                        829 00108$:
      005588 8E 05            [24]  830 	mov	ar5,r6
      00558A                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00558A 7F 00            [12]  833 	mov	r7,#0x00
      00558C                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      00558C EF               [12]  836 	mov	a,r7
      00558D 24 28            [12]  837 	add	a, #_reactive_age
      00558F FC               [12]  838 	mov	r4,a
      005590 E4               [12]  839 	clr	a
      005591 34 07            [12]  840 	addc	a, #(_reactive_age >> 8)
      005593 FE               [12]  841 	mov	r6,a
      005594 8C 82            [24]  842 	mov	dpl,r4
      005596 8E 83            [24]  843 	mov	dph,r6
      005598 E0               [24]  844 	movx	a,@dptr
      005599 FB               [12]  845 	mov	r3,a
      00559A C3               [12]  846 	clr	c
      00559B ED               [12]  847 	mov	a,r5
      00559C 9B               [12]  848 	subb	a,r3
      00559D 40 04            [24]  849 	jc	00110$
      00559F 7B 00            [12]  850 	mov	r3,#0x00
      0055A1 80 08            [24]  851 	sjmp	00111$
      0055A3                        852 00110$:
      0055A3 8C 82            [24]  853 	mov	dpl,r4
      0055A5 8E 83            [24]  854 	mov	dph,r6
      0055A7 E0               [24]  855 	movx	a,@dptr
      0055A8 C3               [12]  856 	clr	c
      0055A9 9D               [12]  857 	subb	a,r5
      0055AA FB               [12]  858 	mov	r3,a
      0055AB                        859 00111$:
      0055AB 8C 82            [24]  860 	mov	dpl,r4
      0055AD 8E 83            [24]  861 	mov	dph,r6
      0055AF EB               [12]  862 	mov	a,r3
      0055B0 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0055B1 0F               [12]  865 	inc	r7
      0055B2 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      0055B5                        867 00144$:
      0055B5 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      0055B7 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      0055B8                        881 _add_sat:
      0055B8 E5 82            [12]  882 	mov	a,dpl
      0055BA 90 07 7D         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      0055BD F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      0055BE 90 07 7C         [24]  886 	mov	dptr,#_add_sat_PARM_2
      0055C1 E0               [24]  887 	movx	a,@dptr
      0055C2 FF               [12]  888 	mov	r7,a
      0055C3 FE               [12]  889 	mov	r6,a
      0055C4 74 FF            [12]  890 	mov	a,#0xff
      0055C6 C3               [12]  891 	clr	c
      0055C7 9E               [12]  892 	subb	a,r6
      0055C8 FE               [12]  893 	mov	r6,a
      0055C9 90 07 7D         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      0055CC E0               [24]  895 	movx	a,@dptr
      0055CD FD               [12]  896 	mov	r5,a
      0055CE C3               [12]  897 	clr	c
      0055CF EE               [12]  898 	mov	a,r6
      0055D0 9D               [12]  899 	subb	a,r5
      0055D1 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      0055D3 7E FF            [12]  902 	mov	r6,#0xff
      0055D5 80 03            [24]  903 	sjmp	00104$
      0055D7                        904 00103$:
      0055D7 EF               [12]  905 	mov	a,r7
      0055D8 2D               [12]  906 	add	a, r5
      0055D9 FE               [12]  907 	mov	r6,a
      0055DA                        908 00104$:
      0055DA 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      0055DC 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      0055DD                        922 _sub_sat:
      0055DD E5 82            [12]  923 	mov	a,dpl
      0055DF 90 07 7F         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      0055E2 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      0055E3 E0               [24]  927 	movx	a,@dptr
      0055E4 FF               [12]  928 	mov	r7,a
      0055E5 90 07 7E         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      0055E8 E0               [24]  930 	movx	a,@dptr
      0055E9 FE               [12]  931 	mov	r6,a
      0055EA C3               [12]  932 	clr	c
      0055EB EF               [12]  933 	mov	a,r7
      0055EC 9E               [12]  934 	subb	a,r6
      0055ED 50 04            [24]  935 	jnc	00103$
      0055EF 7D 00            [12]  936 	mov	r5,#0x00
      0055F1 80 04            [24]  937 	sjmp	00104$
      0055F3                        938 00103$:
      0055F3 EF               [12]  939 	mov	a,r7
      0055F4 C3               [12]  940 	clr	c
      0055F5 9E               [12]  941 	subb	a,r6
      0055F6 FD               [12]  942 	mov	r5,a
      0055F7                        943 00104$:
      0055F7 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      0055F9 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      0055FA                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      0055FA D2 13            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      0055FC 12 4F 0D         [24]  959 	lcall	_timer_read
      0055FF 12 38 4E         [24]  960 	lcall	_ak820_outline_0123
      005602 90 07 1B         [24]  961 	mov	dptr,#_changed_at
      005605 12 5C DB         [24]  962 	lcall	_ak820_outline_0177
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      005608 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      005609                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      005609 90 07 1A         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      00560C E4               [12]  978 	clr	a
      00560D F0               [24]  979 	movx	@dptr,a
      00560E 90 07 19         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      005611 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005612 90 05 FD         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      005615 12 5C BE         [24]  984 	lcall	_ak820_outline_0086
      005618 90 06 00         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00561B 12 5C B4         [24]  986 	lcall	_ak820_outline_0073
      00561E 12 48 25         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      005621 C2 13            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      005623 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      005624                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      005624 12 5C EF         [24] 1002 	lcall	_ak820_outline_0186
      005627 12 5C B4         [24] 1003 	lcall	_ak820_outline_0073
      00562A F5 F0            [12] 1004 	mov	b,a
      00562C 12 BF B9         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      00562F 12 5C CE         [24] 1007 	lcall	_ak820_outline_0117
      005632 44 01            [12] 1008 	orl	a,#0x01
      005634 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      005635 12 5C AD         [24] 1011 	lcall	_ak820_outline_0068
      005638 44 04            [12] 1012 	orl	a,#0x04
      00563A F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      00563B 90 07 14         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00563E E4               [12] 1016 	clr	a
      00563F F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      005640 90 07 15         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005643 14               [12] 1020 	dec	a
      005644 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005645 90 07 16         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005648 74 50            [12] 1024 	mov	a,#0x50
      00564A F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      00564B 90 07 17         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00564E 74 60            [12] 1028 	mov	a,#0x60
      005650 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      005651 90 07 18         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005654 74 FF            [12] 1032 	mov	a,#0xff
      005656 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      005657 C1 09            [12] 1036 	ajmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      005659                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005659 90 05 ED         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00565C 12 5C BE         [24] 1047 	lcall	_ak820_outline_0086
      00565F 90 05 F0         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005662 12 5C B4         [24] 1049 	lcall	_ak820_outline_0073
      005665 12 46 B6         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      005668 12 5C CE         [24] 1052 	lcall	_ak820_outline_0117
      00566B 60 11            [24] 1053 	jz	00101$
      00566D 12 5C 8E         [24] 1054 	lcall	_ak820_outline_0021
      005670 C3               [12] 1055 	clr	c
      005671 64 80            [12] 1056 	xrl	a,#0x80
      005673 94 87            [12] 1057 	subb	a,#0x87
      005675 50 07            [24] 1058 	jnc	00101$
      005677 12 5C AD         [24] 1059 	lcall	_ak820_outline_0068
      00567A 24 FE            [12] 1060 	add	a,#0xff - 0x01
      00567C 50 02            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      00567E                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      00567E D1 24            [24] 1065 	acall	_eeconfig_update_rgb_matrix_default
      005680                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      005680 90 07 16         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005683 E0               [24] 1069 	movx	a,@dptr
      005684 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      005686 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      005688 90 07 16         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00568B 74 A0            [12] 1075 	mov	a,#0xa0
      00568D F0               [24] 1076 	movx	@dptr,a
      00568E                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      00568E C2 13            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      005690 C2 14            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      005692 A1 1D            [12] 1086 	ajmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      005694                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      005694 D1 59            [24] 1096 	acall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      005696 12 4F 0D         [24] 1098 	lcall	_timer_read
      005699 12 49 6E         [24] 1099 	lcall	_ak820_outline_0139
      00569C EE               [12] 1100 	mov	a,r6
      00569D 24 F0            [12] 1101 	add	a,#0xf0
      00569F FE               [12] 1102 	mov	r6,a
      0056A0 EF               [12] 1103 	mov	a,r7
      0056A1 34 FF            [12] 1104 	addc	a,#0xff
      0056A3 FF               [12] 1105 	mov	r7,a
      0056A4 90 07 1D         [24] 1106 	mov	dptr,#_frame_at
      0056A7 12 4E 7D         [24] 1107 	lcall	_ak820_outline_0064
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      0056AA 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      0056AB                       1122 _rgb_matrix_set_color:
      0056AB 12 38 44         [24] 1123 	lcall	_ak820_outline_0109
      0056AE 90 07 83         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0056B1 12 38 49         [24] 1125 	lcall	_ak820_outline_0110
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      0056B4 90 07 83         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0056B7 12 37 FD         [24] 1128 	lcall	_ak820_outline_0056
      0056BA 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      0056BD C3               [12] 1130 	clr	c
      0056BE EE               [12] 1131 	mov	a,r6
      0056BF 94 52            [12] 1132 	subb	a,#0x52
      0056C1 EF               [12] 1133 	mov	a,r7
      0056C2 64 80            [12] 1134 	xrl	a,#0x80
      0056C4 94 80            [12] 1135 	subb	a,#0x80
      0056C6 50 23            [24] 1136 	jnc	00104$
      0056C8 90 07 80         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0056CB E0               [24] 1138 	movx	a,@dptr
      0056CC FF               [12] 1139 	mov	r7,a
      0056CD 90 07 81         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0056D0 E0               [24] 1141 	movx	a,@dptr
      0056D1 FD               [12] 1142 	mov	r5,a
      0056D2 90 07 82         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0056D5 E0               [24] 1144 	movx	a,@dptr
      0056D6 FC               [12] 1145 	mov	r4,a
      0056D7 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      0056DA EF               [12] 1147 	mov	a,r7
      0056DB F0               [24] 1148 	movx	@dptr,a
      0056DC 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      0056DF ED               [12] 1150 	mov	a,r5
      0056E0 F0               [24] 1151 	movx	@dptr,a
      0056E1 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      0056E4 EC               [12] 1153 	mov	a,r4
      0056E5 F0               [24] 1154 	movx	@dptr,a
      0056E6 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      0056E8 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      0056EB                       1158 00104$:
      0056EB 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      0056EC                       1171 _rgb_matrix_set_color_all:
      0056EC E5 82            [12] 1172 	mov	a,dpl
      0056EE 90 07 87         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      0056F1 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      0056F2 E0               [24] 1176 	movx	a,@dptr
      0056F3 FF               [12] 1177 	mov	r7,a
      0056F4 90 07 85         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0056F7 E0               [24] 1179 	movx	a,@dptr
      0056F8 FE               [12] 1180 	mov	r6,a
      0056F9 90 07 86         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0056FC E0               [24] 1182 	movx	a,@dptr
      0056FD FD               [12] 1183 	mov	r5,a
      0056FE 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      005701 EE               [12] 1185 	mov	a,r6
      005702 F0               [24] 1186 	movx	@dptr,a
      005703 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      005706 12 41 83         [24] 1188 	lcall	_ak820_outline_0194
                                   1189 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      005709 02 33 B9         [24] 1190 	ljmp	_ak820_rgb_set_color_all
                                   1191 ;------------------------------------------------------------
                                   1192 ;Allocation info for local variables in function 'sine8'
                                   1193 ;------------------------------------------------------------
                                   1194 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1195 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1196 ;section       Allocated with name '_sine8_section_10000_290'
                                   1197 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1198 ;value         Allocated with name '_sine8_value_10000_290'
                                   1199 ;------------------------------------------------------------
                                   1200 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1201 ;	-----------------------------------------
                                   1202 ;	 function sine8
                                   1203 ;	-----------------------------------------
      00570C                       1204 _sine8:
      00570C E5 82            [12] 1205 	mov	a,dpl
      00570E 90 07 88         [24] 1206 	mov	dptr,#_sine8_theta_10000_289
      005711 F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      005712 E0               [24] 1209 	movx	a,@dptr
      005713 FF               [12] 1210 	mov	r7,a
      005714 90 07 89         [24] 1211 	mov	dptr,#_sine8_offset_10000_290
      005717 F0               [24] 1212 	movx	@dptr,a
                                   1213 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      005718 EF               [12] 1214 	mov	a,r7
      005719 30 E6 08         [24] 1215 	jnb	acc.6,00102$
      00571C 90 07 89         [24] 1216 	mov	dptr,#_sine8_offset_10000_290
      00571F 74 FF            [12] 1217 	mov	a,#0xff
      005721 C3               [12] 1218 	clr	c
      005722 9F               [12] 1219 	subb	a,r7
      005723 F0               [24] 1220 	movx	@dptr,a
      005724                       1221 00102$:
                                   1222 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      005724 90 07 89         [24] 1223 	mov	dptr,#_sine8_offset_10000_290
      005727 E0               [24] 1224 	movx	a,@dptr
      005728 53 E0 3F         [24] 1225 	anl	acc,#0x3f
      00572B F0               [24] 1226 	movx	@dptr,a
                                   1227 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      00572C 90 07 89         [24] 1228 	mov	dptr,#_sine8_offset_10000_290
      00572F E0               [24] 1229 	movx	a,@dptr
      005730 54 0F            [12] 1230 	anl	a,#0x0f
      005732 FF               [12] 1231 	mov	r7,a
      005733 90 07 8A         [24] 1232 	mov	dptr,#_sine8_fraction_10000_290
      005736 F0               [24] 1233 	movx	@dptr,a
                                   1234 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      005737 90 07 88         [24] 1235 	mov	dptr,#_sine8_theta_10000_289
      00573A E0               [24] 1236 	movx	a,@dptr
      00573B 30 E6 06         [24] 1237 	jnb	acc.6,00104$
      00573E 90 07 8A         [24] 1238 	mov	dptr,#_sine8_fraction_10000_290
      005741 EF               [12] 1239 	mov	a,r7
      005742 04               [12] 1240 	inc	a
      005743 F0               [24] 1241 	movx	@dptr,a
      005744                       1242 00104$:
                                   1243 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      005744 90 07 89         [24] 1244 	mov	dptr,#_sine8_offset_10000_290
      005747 E0               [24] 1245 	movx	a,@dptr
      005748 C4               [12] 1246 	swap	a
      005749 54 0F            [12] 1247 	anl	a,#0x0f
                                   1248 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      00574B 25 E0            [12] 1249 	add	a,acc
      00574D FF               [12] 1250 	mov	r7,a
      00574E 90 C0 9E         [24] 1251 	mov	dptr,#_sine8_coefficients_10000_290
      005751 93               [24] 1252 	movc	a,@a+dptr
      005752 FE               [12] 1253 	mov	r6,a
      005753 0F               [12] 1254 	inc	r7
      005754 EF               [12] 1255 	mov	a,r7
      005755 90 C0 9E         [24] 1256 	mov	dptr,#_sine8_coefficients_10000_290
      005758 93               [24] 1257 	movc	a,@a+dptr
      005759 FF               [12] 1258 	mov	r7,a
      00575A 90 07 8A         [24] 1259 	mov	dptr,#_sine8_fraction_10000_290
      00575D E0               [24] 1260 	movx	a,@dptr
      00575E 8F F0            [24] 1261 	mov	b,r7
      005760 A4               [48] 1262 	mul	ab
      005761 FF               [12] 1263 	mov	r7,a
      005762 E5 F0            [12] 1264 	mov	a,b
      005764 C4               [12] 1265 	swap	a
      005765 CF               [12] 1266 	xch	a,r7
      005766 C4               [12] 1267 	swap	a
      005767 54 0F            [12] 1268 	anl	a,#0x0f
      005769 6F               [12] 1269 	xrl	a,r7
      00576A CF               [12] 1270 	xch	a,r7
      00576B 54 0F            [12] 1271 	anl	a,#0x0f
      00576D CF               [12] 1272 	xch	a,r7
      00576E 6F               [12] 1273 	xrl	a,r7
      00576F CF               [12] 1274 	xch	a,r7
      005770 EF               [12] 1275 	mov	a,r7
      005771 2E               [12] 1276 	add	a, r6
      005772 FF               [12] 1277 	mov	r7,a
                                   1278 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      005773 90 07 88         [24] 1279 	mov	dptr,#_sine8_theta_10000_289
      005776 E0               [24] 1280 	movx	a,@dptr
      005777 30 E7 09         [24] 1281 	jnb	acc.7,00107$
      00577A 8F 06            [24] 1282 	mov	ar6,r7
      00577C 74 80            [12] 1283 	mov	a,#0x80
      00577E C3               [12] 1284 	clr	c
      00577F 9E               [12] 1285 	subb	a,r6
      005780 FE               [12] 1286 	mov	r6,a
      005781 80 04            [24] 1287 	sjmp	00108$
      005783                       1288 00107$:
      005783 74 80            [12] 1289 	mov	a,#0x80
      005785 2F               [12] 1290 	add	a, r7
      005786 FE               [12] 1291 	mov	r6,a
      005787                       1292 00108$:
      005787 8E 82            [24] 1293 	mov	dpl, r6
                                   1294 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      005789 22               [24] 1295 	ret
                                   1296 ;------------------------------------------------------------
                                   1297 ;Allocation info for local variables in function 'breathing_cie'
                                   1298 ;------------------------------------------------------------
                                   1299 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1300 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1301 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1302 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1303 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1304 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1305 ;------------------------------------------------------------
                                   1306 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1307 ;	-----------------------------------------
                                   1308 ;	 function breathing_cie
                                   1309 ;	-----------------------------------------
      00578A                       1310 _breathing_cie:
      00578A E5 82            [12] 1311 	mov	a,dpl
      00578C 90 07 8B         [24] 1312 	mov	dptr,#_breathing_cie_value_10000_293
      00578F F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      005790 E0               [24] 1315 	movx	a,@dptr
      005791 FF               [12] 1316 	mov	r7,a
      005792 C4               [12] 1317 	swap	a
      005793 23               [12] 1318 	rl	a
      005794 54 1F            [12] 1319 	anl	a,#0x1f
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      005796 FE               [12] 1321 	mov	r6,a
      005797 90 C3 AA         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      00579A 93               [24] 1323 	movc	a,@a+dptr
      00579B FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      00579C BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      00579F 8D 82            [24] 1327 	mov	dpl, r5
      0057A1 22               [24] 1328 	ret
      0057A2                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      0057A2 EE               [12] 1331 	mov	a,r6
      0057A3 04               [12] 1332 	inc	a
      0057A4 90 C3 AA         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      0057A7 93               [24] 1334 	movc	a,@a+dptr
      0057A8 C3               [12] 1335 	clr	c
      0057A9 9D               [12] 1336 	subb	a,r5
      0057AA FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      0057AB 74 07            [12] 1339 	mov	a,#0x07
      0057AD 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      0057AE F5 F0            [12] 1342 	mov	b,a
      0057B0 EE               [12] 1343 	mov	a,r6
      0057B1 A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      0057B2 C4               [12] 1346 	swap	a
      0057B3 23               [12] 1347 	rl	a
      0057B4 54 1F            [12] 1348 	anl	a,#0x1f
      0057B6 2D               [12] 1349 	add	a, r5
                                   1350 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      0057B7 F5 82            [12] 1351 	mov	dpl,a
      0057B9 22               [24] 1352 	ret
                                   1353 ;------------------------------------------------------------
                                   1354 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1355 ;------------------------------------------------------------
                                   1356 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1357 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1358 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1359 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1360 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1361 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1362 ;------------------------------------------------------------
                                   1363 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1364 ;	-----------------------------------------
                                   1365 ;	 function rgb_matrix_task
                                   1366 ;	-----------------------------------------
      0057BA                       1367 _rgb_matrix_task:
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      0057BA B1 3A            [12] 1369 	acall	_age_reactive
                                   1370 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      0057BC 30 13 17         [24] 1371 	jnb	_dirty,00102$
      0057BF 90 07 1B         [24] 1372 	mov	dptr,#_changed_at
      0057C2 12 37 BE         [24] 1373 	lcall	_ak820_outline_0007
      0057C5 12 4F 10         [24] 1374 	lcall	_timer_elapsed
      0057C8 12 49 6E         [24] 1375 	lcall	_ak820_outline_0139
      0057CB C3               [12] 1376 	clr	c
      0057CC EE               [12] 1377 	mov	a,r6
      0057CD 94 E8            [12] 1378 	subb	a,#0xe8
      0057CF EF               [12] 1379 	mov	a,r7
      0057D0 94 03            [12] 1380 	subb	a,#0x03
      0057D2 40 02            [24] 1381 	jc	00102$
      0057D4 D1 09            [12] 1382 	acall	_eeconfig_update_rgb_matrix
      0057D6                       1383 00102$:
                                   1384 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      0057D6 30 14 03         [24] 1385 	jnb	_rendering,00254$
      0057D9 02 58 91         [24] 1386 	ljmp	00109$
      0057DC                       1387 00254$:
                                   1388 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      0057DC 90 07 1D         [24] 1389 	mov	dptr,#_frame_at
      0057DF 12 37 BE         [24] 1390 	lcall	_ak820_outline_0007
      0057E2 12 4F 10         [24] 1391 	lcall	_timer_elapsed
      0057E5 12 49 6E         [24] 1392 	lcall	_ak820_outline_0139
      0057E8 C3               [12] 1393 	clr	c
      0057E9 EE               [12] 1394 	mov	a,r6
      0057EA 94 10            [12] 1395 	subb	a,#0x10
      0057EC EF               [12] 1396 	mov	a,r7
      0057ED 94 00            [12] 1397 	subb	a,#0x00
      0057EF 50 01            [24] 1398 	jnc	00105$
      0057F1 22               [24] 1399 	ret
      0057F2                       1400 00105$:
                                   1401 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      0057F2 12 4F 0D         [24] 1402 	lcall	_timer_read
      0057F5 12 38 4E         [24] 1403 	lcall	_ak820_outline_0123
      0057F8 90 07 1D         [24] 1404 	mov	dptr,#_frame_at
      0057FB 12 5C DB         [24] 1405 	lcall	_ak820_outline_0177
                                   1406 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      0057FE 90 07 17         [24] 1407 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005801 E0               [24] 1408 	movx	a,@dptr
      005802 FF               [12] 1409 	mov	r7,a
      005803 7E 00            [12] 1410 	mov	r6,#0x00
      005805 74 20            [12] 1411 	mov	a,#0x20
      005807 2F               [12] 1412 	add	a, r7
      005808 FF               [12] 1413 	mov	r7,a
      005809 E4               [12] 1414 	clr	a
      00580A 3E               [12] 1415 	addc	a, r6
      00580B FE               [12] 1416 	mov	r6,a
      00580C 90 07 1F         [24] 1417 	mov	dptr,#_phase
      00580F 12 38 14         [24] 1418 	lcall	_ak820_outline_0062
      005812 EF               [12] 1419 	mov	a,r7
      005813 2C               [12] 1420 	add	a, r4
      005814 FF               [12] 1421 	mov	r7,a
      005815 EE               [12] 1422 	mov	a,r6
      005816 3D               [12] 1423 	addc	a, r5
      005817 FE               [12] 1424 	mov	r6,a
      005818 90 07 1F         [24] 1425 	mov	dptr,#_phase
      00581B EF               [12] 1426 	mov	a,r7
      00581C F0               [24] 1427 	movx	@dptr,a
      00581D EE               [12] 1428 	mov	a,r6
      00581E A3               [24] 1429 	inc	dptr
      00581F F0               [24] 1430 	movx	@dptr,a
                                   1431 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      005820 90 07 1F         [24] 1432 	mov	dptr,#_phase
      005823 E0               [24] 1433 	movx	a,@dptr
      005824 A3               [24] 1434 	inc	dptr
      005825 E0               [24] 1435 	movx	a,@dptr
      005826 FF               [12] 1436 	mov	r7,a
      005827 90 07 27         [24] 1437 	mov	dptr,#_frame_phase
      00582A F0               [24] 1438 	movx	@dptr,a
                                   1439 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      00582B 20 12 05         [24] 1440 	jb	_suspended,00135$
      00582E 12 5C AD         [24] 1441 	lcall	_ak820_outline_0068
      005831 70 04            [24] 1442 	jnz	00132$
      005833                       1443 00135$:
      005833 7E 00            [12] 1444 	mov	r6,#0x00
      005835 80 04            [24] 1445 	sjmp	00133$
      005837                       1446 00132$:
      005837 12 5C 8E         [24] 1447 	lcall	_ak820_outline_0021
      00583A FE               [12] 1448 	mov	r6,a
      00583B                       1449 00133$:
      00583B 90 07 22         [24] 1450 	mov	dptr,#_frame_mode
      00583E EE               [12] 1451 	mov	a,r6
      00583F F0               [24] 1452 	movx	@dptr,a
                                   1453 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      005840 90 07 14         [24] 1454 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005843 E0               [24] 1455 	movx	a,@dptr
      005844 90 07 23         [24] 1456 	mov	dptr,#_frame_hue
      005847 F0               [24] 1457 	movx	@dptr,a
                                   1458 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005848 90 07 15         [24] 1459 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00584B E0               [24] 1460 	movx	a,@dptr
      00584C 90 07 24         [24] 1461 	mov	dptr,#_frame_sat
      00584F F0               [24] 1462 	movx	@dptr,a
                                   1463 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      005850 90 07 16         [24] 1464 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005853 E0               [24] 1465 	movx	a,@dptr
      005854 FD               [12] 1466 	mov	r5,a
      005855 90 07 25         [24] 1467 	mov	dptr,#_frame_val
      005858 F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005859 90 07 18         [24] 1470 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      00585C E0               [24] 1471 	movx	a,@dptr
      00585D 90 07 26         [24] 1472 	mov	dptr,#_frame_flags
      005860 F0               [24] 1473 	movx	@dptr,a
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      005861 BE 02 26         [24] 1475 	cjne	r6,#0x02,00107$
                                   1476 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      005864 EF               [12] 1477 	mov	a,r7
      005865 24 C0            [12] 1478 	add	a,#0xc0
      005867 F5 82            [12] 1479 	mov	dpl,a
      005869 C0 05            [24] 1480 	push	ar5
      00586B 12 57 0C         [24] 1481 	lcall	_sine8
      00586E AF 82            [24] 1482 	mov	r7, dpl
      005870 D0 05            [24] 1483 	pop	ar5
      005872 8D F0            [24] 1484 	mov	b,r5
      005874 EF               [12] 1485 	mov	a,r7
      005875 A4               [48] 1486 	mul	ab
      005876 AE F0            [24] 1487 	mov	r6,b
      005878 8E 05            [24] 1488 	mov	ar5,r6
      00587A 90 07 25         [24] 1489 	mov	dptr,#_frame_val
      00587D ED               [12] 1490 	mov	a,r5
      00587E F0               [24] 1491 	movx	@dptr,a
                                   1492 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      00587F 8D 82            [24] 1493 	mov	dpl, r5
      005881 12 57 8A         [24] 1494 	lcall	_breathing_cie
      005884 E5 82            [12] 1495 	mov	a, dpl
      005886 90 07 25         [24] 1496 	mov	dptr,#_frame_val
      005889 F0               [24] 1497 	movx	@dptr,a
      00588A                       1498 00107$:
                                   1499 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      00588A 90 07 21         [24] 1500 	mov	dptr,#_led_index
      00588D E4               [12] 1501 	clr	a
      00588E F0               [24] 1502 	movx	@dptr,a
                                   1503 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1504 ;	assignBit
      00588F D2 14            [12] 1505 	setb	_rendering
      005891                       1506 00109$:
                                   1507 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      005891 12 5C F8         [24] 1508 	lcall	_ak820_outline_0192
      005894 24 08            [12] 1509 	add	a,#0x08
      005896 FF               [12] 1510 	mov	r7,a
      005897 90 07 8C         [24] 1511 	mov	dptr,#_rgb_matrix_task_end_10000_298
      00589A F0               [24] 1512 	movx	@dptr,a
                                   1513 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      00589B EF               [12] 1514 	mov	a,r7
      00589C 24 AD            [12] 1515 	add	a,#0xff - 0x52
      00589E 50 06            [24] 1516 	jnc	00125$
                                   1517 ;	free result
      0058A0 90 07 8C         [24] 1518 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0058A3 74 52            [12] 1519 	mov	a,#0x52
      0058A5 F0               [24] 1520 	movx	@dptr,a
                                   1521 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      0058A6                       1522 00125$:
      0058A6 12 5C F8         [24] 1523 	lcall	_ak820_outline_0192
      0058A9 FF               [12] 1524 	mov	r7,a
      0058AA 90 07 8C         [24] 1525 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0058AD E0               [24] 1526 	movx	a,@dptr
      0058AE FE               [12] 1527 	mov	r6,a
      0058AF C3               [12] 1528 	clr	c
      0058B0 EF               [12] 1529 	mov	a,r7
      0058B1 9E               [12] 1530 	subb	a,r6
      0058B2 40 02            [24] 1531 	jc	00261$
      0058B4 41 24            [12] 1532 	ajmp	00127$
      0058B6                       1533 00261$:
                                   1534 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      0058B6 12 5C D5         [24] 1535 	lcall	_ak820_outline_0144
      0058B9 E0               [24] 1536 	movx	a,@dptr
      0058BA 60 07            [24] 1537 	jz	00121$
      0058BC 90 07 26         [24] 1538 	mov	dptr,#_frame_flags
      0058BF E0               [24] 1539 	movx	a,@dptr
      0058C0 20 E2 1B         [24] 1540 	jb	acc.2,00122$
      0058C3                       1541 00121$:
                                   1542 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      0058C3 12 5C F8         [24] 1543 	lcall	_ak820_outline_0192
      0058C6 FC               [12] 1544 	mov	r4,a
      0058C7 7D 00            [12] 1545 	mov	r5,#0x00
      0058C9 90 07 80         [24] 1546 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0058CC E4               [12] 1547 	clr	a
      0058CD F0               [24] 1548 	movx	@dptr,a
      0058CE 90 07 81         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0058D1 F0               [24] 1550 	movx	@dptr,a
      0058D2 90 07 82         [24] 1551 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0058D5 F0               [24] 1552 	movx	@dptr,a
      0058D6 12 38 54         [24] 1553 	lcall	_ak820_outline_0128
      0058D9 12 56 AB         [24] 1554 	lcall	_rgb_matrix_set_color
      0058DC 41 1C            [12] 1555 	ajmp	00123$
      0058DE                       1556 00122$:
                                   1557 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      0058DE BE 05 28         [24] 1558 	cjne	r6,#0x05,00119$
                                   1559 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      0058E1 EF               [12] 1560 	mov	a,r7
      0058E2 75 F0 03         [24] 1561 	mov	b,#0x03
      0058E5 A4               [48] 1562 	mul	ab
      0058E6 24 1B            [12] 1563 	add	a, #_g_direct_mode_colors
      0058E8 FD               [12] 1564 	mov	r5,a
      0058E9 74 0D            [12] 1565 	mov	a,#(_g_direct_mode_colors >> 8)
      0058EB 35 F0            [12] 1566 	addc	a, b
      0058ED FE               [12] 1567 	mov	r6,a
      0058EE 90 0E 2F         [24] 1568 	mov	dptr,#___memcpy_PARM_2
      0058F1 ED               [12] 1569 	mov	a,r5
      0058F2 F0               [24] 1570 	movx	@dptr,a
      0058F3 EE               [12] 1571 	mov	a,r6
      0058F4 12 38 1A         [24] 1572 	lcall	_ak820_outline_0074
      0058F7 90 0E 32         [24] 1573 	mov	dptr,#___memcpy_PARM_3
      0058FA 74 03            [12] 1574 	mov	a,#0x03
      0058FC 12 38 59         [24] 1575 	lcall	_ak820_outline_0129
      0058FF 90 07 8D         [24] 1576 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005902 F5 F0            [12] 1577 	mov	b,a
      005904 12 BF 43         [24] 1578 	lcall	___memcpy
      005907 21 B8            [12] 1579 	ajmp	00120$
      005909                       1580 00119$:
                                   1581 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      005909 90 07 23         [24] 1582 	mov	dptr,#_frame_hue
      00590C E0               [24] 1583 	movx	a,@dptr
      00590D 90 07 8D         [24] 1584 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005910 F0               [24] 1585 	movx	@dptr,a
                                   1586 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      005911 90 07 24         [24] 1587 	mov	dptr,#_frame_sat
      005914 E0               [24] 1588 	movx	a,@dptr
      005915 90 07 8E         [24] 1589 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      005918 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      005919 90 07 25         [24] 1592 	mov	dptr,#_frame_val
      00591C E0               [24] 1593 	movx	a,@dptr
      00591D 90 07 8F         [24] 1594 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005920 F0               [24] 1595 	movx	@dptr,a
                                   1596 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      005921 12 5C D5         [24] 1597 	lcall	_ak820_outline_0144
      005924 BE 03 0E         [24] 1598 	cjne	r6,#0x03,00113$
      005927 90 07 8D         [24] 1599 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00592A E0               [24] 1600 	movx	a,@dptr
      00592B FE               [12] 1601 	mov	r6,a
      00592C 90 07 27         [24] 1602 	mov	dptr,#_frame_phase
      00592F E0               [24] 1603 	movx	a,@dptr
      005930 2E               [12] 1604 	add	a, r6
      005931 90 07 8D         [24] 1605 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005934 F0               [24] 1606 	movx	@dptr,a
      005935                       1607 00113$:
                                   1608 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005935 12 5C D5         [24] 1609 	lcall	_ak820_outline_0144
      005938 BE 04 23         [24] 1610 	cjne	r6,#0x04,00115$
      00593B 90 07 8D         [24] 1611 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00593E E0               [24] 1612 	movx	a,@dptr
      00593F FE               [12] 1613 	mov	r6,a
      005940 12 5C F8         [24] 1614 	lcall	_ak820_outline_0192
      005943 75 F0 02         [24] 1615 	mov	b,#0x02
      005946 A4               [48] 1616 	mul	ab
      005947 24 06            [12] 1617 	add	a, #_ak820_led_points
      005949 F5 82            [12] 1618 	mov	dpl,a
      00594B 74 C3            [12] 1619 	mov	a,#(_ak820_led_points >> 8)
      00594D 12 5C C7         [24] 1620 	lcall	_ak820_outline_0111
      005950 FD               [12] 1621 	mov	r5,a
      005951 90 07 27         [24] 1622 	mov	dptr,#_frame_phase
      005954 E0               [24] 1623 	movx	a,@dptr
      005955 FC               [12] 1624 	mov	r4,a
      005956 ED               [12] 1625 	mov	a,r5
      005957 C3               [12] 1626 	clr	c
      005958 9C               [12] 1627 	subb	a,r4
      005959 2E               [12] 1628 	add	a, r6
      00595A 90 07 8D         [24] 1629 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00595D F0               [24] 1630 	movx	@dptr,a
      00595E                       1631 00115$:
                                   1632 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      00595E 12 5C D5         [24] 1633 	lcall	_ak820_outline_0144
      005961 BE 06 54         [24] 1634 	cjne	r6,#0x06,00120$
                                   1635 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005964 12 5C E6         [24] 1636 	lcall	_ak820_outline_0180
      005967 FE               [12] 1637 	mov	r6,a
      005968 74 07            [12] 1638 	mov	a,#0x07
      00596A C3               [12] 1639 	clr	c
      00596B 9E               [12] 1640 	subb	a,r6
      00596C FE               [12] 1641 	mov	r6,a
                                   1642 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      00596D 8E F0            [24] 1643 	mov	b,r6
      00596F 05 F0            [12] 1644 	inc	b
      005971 74 01            [12] 1645 	mov	a,#0x01
      005973 80 02            [24] 1646 	sjmp	00273$
      005975                       1647 00272$:
      005975 25 E0            [12] 1648 	add	a,acc
      005977                       1649 00273$:
      005977 D5 F0 FB         [24] 1650 	djnz	b,00272$
      00597A FD               [12] 1651 	mov	r5,a
                                   1652 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      00597B 12 5C F8         [24] 1653 	lcall	_ak820_outline_0192
      00597E 24 28            [12] 1654 	add	a, #_reactive_age
      005980 F5 82            [12] 1655 	mov	dpl,a
      005982 E4               [12] 1656 	clr	a
      005983 34 07            [12] 1657 	addc	a, #(_reactive_age >> 8)
      005985 F5 83            [12] 1658 	mov	dph,a
      005987 E0               [24] 1659 	movx	a,@dptr
                                   1660 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      005988 FC               [12] 1661 	mov	r4,a
      005989 C3               [12] 1662 	clr	c
      00598A 9D               [12] 1663 	subb	a,r5
      00598B 40 07            [24] 1664 	jc	00137$
      00598D 90 07 25         [24] 1665 	mov	dptr,#_frame_val
      005990 E0               [24] 1666 	movx	a,@dptr
      005991 FB               [12] 1667 	mov	r3,a
      005992 80 1F            [24] 1668 	sjmp	00138$
      005994                       1669 00137$:
      005994 90 07 25         [24] 1670 	mov	dptr,#_frame_val
      005997 E0               [24] 1671 	movx	a,@dptr
      005998 F5 F0            [12] 1672 	mov	b, a
      00599A EC               [12] 1673 	mov	a,r4
      00599B A4               [48] 1674 	mul	ab
      00599C FC               [12] 1675 	mov	r4,a
      00599D AA F0            [24] 1676 	mov	r2,b
      00599F 8E F0            [24] 1677 	mov	b,r6
      0059A1 05 F0            [12] 1678 	inc	b
      0059A3 AB 04            [24] 1679 	mov	r3,ar4
      0059A5 AD 02            [24] 1680 	mov	r5,ar2
      0059A7 80 07            [24] 1681 	sjmp	00276$
      0059A9                       1682 00275$:
      0059A9 C3               [12] 1683 	clr	c
      0059AA ED               [12] 1684 	mov	a,r5
      0059AB 13               [12] 1685 	rrc	a
      0059AC FD               [12] 1686 	mov	r5,a
      0059AD EB               [12] 1687 	mov	a,r3
      0059AE 13               [12] 1688 	rrc	a
      0059AF FB               [12] 1689 	mov	r3,a
      0059B0                       1690 00276$:
      0059B0 D5 F0 F6         [24] 1691 	djnz	b,00275$
      0059B3                       1692 00138$:
      0059B3 90 07 8F         [24] 1693 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0059B6 EB               [12] 1694 	mov	a,r3
      0059B7 F0               [24] 1695 	movx	@dptr,a
      0059B8                       1696 00120$:
                                   1697 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      0059B8 12 5C D5         [24] 1698 	lcall	_ak820_outline_0144
      0059BB BE 02 03         [24] 1699 	cjne	r6,#0x02,00277$
      0059BE D3               [12] 1700 	setb	c
      0059BF 80 01            [24] 1701 	sjmp	00278$
      0059C1                       1702 00277$:
      0059C1 C3               [12] 1703 	clr	c
      0059C2                       1704 00278$:
      0059C2 B3               [12] 1705 	cpl	c
      0059C3 92 15            [24] 1706 	mov	_rgb_matrix_task_sloc0_1_0,c
      0059C5 90 0E 2F         [24] 1707 	mov	dptr,#___memcpy_PARM_2
      0059C8 74 8D            [12] 1708 	mov	a,#_rgb_matrix_task_hsv_10000_298
      0059CA F0               [24] 1709 	movx	@dptr,a
      0059CB 74 07            [12] 1710 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      0059CD 12 38 1A         [24] 1711 	lcall	_ak820_outline_0074
      0059D0 90 0E 32         [24] 1712 	mov	dptr,#___memcpy_PARM_3
      0059D3 74 03            [12] 1713 	mov	a,#0x03
      0059D5 12 38 59         [24] 1714 	lcall	_ak820_outline_0129
      0059D8 90 0B 49         [24] 1715 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      0059DB F5 F0            [12] 1716 	mov	b,a
      0059DD 12 BF 43         [24] 1717 	lcall	___memcpy
      0059E0 90 0B 4C         [24] 1718 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      0059E3 74 90            [12] 1719 	mov	a,#_rgb_matrix_task_rgb_10000_298
      0059E5 F0               [24] 1720 	movx	@dptr,a
      0059E6 74 07            [12] 1721 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      0059E8 A3               [24] 1722 	inc	dptr
      0059E9 F0               [24] 1723 	movx	@dptr,a
      0059EA A2 15            [12] 1724 	mov	c,_rgb_matrix_task_sloc0_1_0
      0059EC 12 38 69         [24] 1725 	lcall	_ak820_outline_0149
      0059EF 12 87 8B         [24] 1726 	lcall	_hsv_to_rgb_into
                                   1727 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      0059F2 12 5C F8         [24] 1728 	lcall	_ak820_outline_0192
      0059F5 FD               [12] 1729 	mov	r5,a
      0059F6 7E 00            [12] 1730 	mov	r6,#0x00
      0059F8 90 07 91         [24] 1731 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      0059FB E0               [24] 1732 	movx	a,@dptr
      0059FC FC               [12] 1733 	mov	r4,a
      0059FD 90 07 90         [24] 1734 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      005A00 E0               [24] 1735 	movx	a,@dptr
      005A01 FB               [12] 1736 	mov	r3,a
      005A02 90 07 92         [24] 1737 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      005A05 E0               [24] 1738 	movx	a,@dptr
      005A06 FA               [12] 1739 	mov	r2,a
      005A07 90 07 80         [24] 1740 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005A0A EC               [12] 1741 	mov	a,r4
      005A0B F0               [24] 1742 	movx	@dptr,a
      005A0C 90 07 81         [24] 1743 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005A0F EB               [12] 1744 	mov	a,r3
      005A10 F0               [24] 1745 	movx	@dptr,a
      005A11 90 07 82         [24] 1746 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005A14 EA               [12] 1747 	mov	a,r2
      005A15 F0               [24] 1748 	movx	@dptr,a
      005A16 12 38 5E         [24] 1749 	lcall	_ak820_outline_0138
      005A19 12 56 AB         [24] 1750 	lcall	_rgb_matrix_set_color
      005A1C                       1751 00123$:
                                   1752 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      005A1C 12 5C F8         [24] 1753 	lcall	_ak820_outline_0192
      005A1F 24 01            [12] 1754 	add	a, #0x01
      005A21 F0               [24] 1755 	movx	@dptr,a
      005A22 01 A6            [12] 1756 	ajmp	00125$
      005A24                       1757 00127$:
                                   1758 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      005A24 BF 52 02         [24] 1759 	cjne	r7,#0x52,00130$
                                   1760 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1761 ;	assignBit
      005A27 C2 14            [12] 1762 	clr	_rendering
      005A29                       1763 00130$:
                                   1764 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      005A29 22               [24] 1765 	ret
                                   1766 ;------------------------------------------------------------
                                   1767 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1768 ;------------------------------------------------------------
                                   1769 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1770 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1771 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1772 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1773 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1774 ;------------------------------------------------------------
                                   1775 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1776 ;	-----------------------------------------
                                   1777 ;	 function process_rgb_matrix
                                   1778 ;	-----------------------------------------
      005A2A                       1779 _process_rgb_matrix:
      005A2A E5 82            [12] 1780 	mov	a,dpl
      005A2C 90 07 95         [24] 1781 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005A2F F0               [24] 1782 	movx	@dptr,a
                                   1783 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      005A30 90 07 94         [24] 1784 	mov	dptr,#_process_rgb_matrix_PARM_3
      005A33 E0               [24] 1785 	movx	a,@dptr
      005A34 60 23            [24] 1786 	jz	00101$
      005A36 20 12 20         [24] 1787 	jb	_suspended,00101$
      005A39 12 5C AD         [24] 1788 	lcall	_ak820_outline_0068
      005A3C 60 1B            [24] 1789 	jz	00101$
                                   1790 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      005A3E 12 5C 8E         [24] 1791 	lcall	_ak820_outline_0021
      005A41 FF               [12] 1792 	mov	r7,a
      005A42 BF 06 14         [24] 1793 	cjne	r7,#0x06,00101$
      005A45 90 07 95         [24] 1794 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005A48 E0               [24] 1795 	movx	a,@dptr
      005A49 FF               [12] 1796 	mov	r7,a
      005A4A BF 10 00         [24] 1797 	cjne	r7,#0x10,00169$
      005A4D                       1798 00169$:
      005A4D 50 0A            [24] 1799 	jnc	00101$
      005A4F 90 07 93         [24] 1800 	mov	dptr,#_process_rgb_matrix_PARM_2
      005A52 E0               [24] 1801 	movx	a,@dptr
      005A53 FE               [12] 1802 	mov	r6,a
      005A54 BE 08 00         [24] 1803 	cjne	r6,#0x08,00171$
      005A57                       1804 00171$:
      005A57 40 01            [24] 1805 	jc	00102$
      005A59                       1806 00101$:
      005A59 22               [24] 1807 	ret
      005A5A                       1808 00102$:
                                   1809 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005A5A C0 07            [24] 1810 	push	ar7
      005A5C C0 06            [24] 1811 	push	ar6
      005A5E 12 55 3A         [24] 1812 	lcall	_age_reactive
      005A61 D0 06            [24] 1813 	pop	ar6
      005A63 D0 07            [24] 1814 	pop	ar7
                                   1815 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005A65 EF               [12] 1816 	mov	a,r7
      005A66 12 38 7E         [24] 1817 	lcall	_ak820_outline_0193
      005A69 2E               [12] 1818 	add	a,r6
      005A6A FF               [12] 1819 	mov	r7,a
                                   1820 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005A6B 7E 00            [12] 1821 	mov	r6,#0x00
      005A6D                       1822 00111$:
                                   1823 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      005A6D EE               [12] 1824 	mov	a,r6
      005A6E 90 C0 4C         [24] 1825 	mov	dptr,#_ak820_rgb_slots
      005A71 93               [24] 1826 	movc	a,@a+dptr
      005A72 B5 07 29         [24] 1827 	cjne	a,ar7,00112$
                                   1828 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005A75 EE               [12] 1829 	mov	a,r6
      005A76 24 28            [12] 1830 	add	a, #_reactive_age
      005A78 FC               [12] 1831 	mov	r4,a
      005A79 E4               [12] 1832 	clr	a
      005A7A 34 07            [12] 1833 	addc	a, #(_reactive_age >> 8)
      005A7C FD               [12] 1834 	mov	r5,a
      005A7D 12 5C E6         [24] 1835 	lcall	_ak820_outline_0180
      005A80 F5 F0            [12] 1836 	mov	b, a
      005A82 05 F0            [12] 1837 	inc	b
      005A84 7B 80            [12] 1838 	mov	r3,#0x80
      005A86 E4               [12] 1839 	clr	a
      005A87 FA               [12] 1840 	mov	r2,a
      005A88 33               [12] 1841 	rlc	a
      005A89 92 D2            [24] 1842 	mov	ov,c
      005A8B 80 08            [24] 1843 	sjmp	00176$
      005A8D                       1844 00175$:
      005A8D A2 D2            [12] 1845 	mov	c,ov
      005A8F EA               [12] 1846 	mov	a,r2
      005A90 13               [12] 1847 	rrc	a
      005A91 FA               [12] 1848 	mov	r2,a
      005A92 EB               [12] 1849 	mov	a,r3
      005A93 13               [12] 1850 	rrc	a
      005A94 FB               [12] 1851 	mov	r3,a
      005A95                       1852 00176$:
      005A95 D5 F0 F5         [24] 1853 	djnz	b,00175$
      005A98 12 38 54         [24] 1854 	lcall	_ak820_outline_0128
      005A9B EB               [12] 1855 	mov	a,r3
      005A9C F0               [24] 1856 	movx	@dptr,a
                                   1857 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      005A9D 22               [24] 1858 	ret
      005A9E                       1859 00112$:
                                   1860 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005A9E 0E               [12] 1861 	inc	r6
      005A9F BE 52 00         [24] 1862 	cjne	r6,#0x52,00177$
      005AA2                       1863 00177$:
      005AA2 40 C9            [24] 1864 	jc	00111$
                                   1865 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      005AA4 22               [24] 1866 	ret
                                   1867 ;------------------------------------------------------------
                                   1868 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1869 ;------------------------------------------------------------
                                   1870 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1871 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1872 ;------------------------------------------------------------
                                   1873 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1874 ;	-----------------------------------------
                                   1875 ;	 function rgb_matrix_set_suspend_state
                                   1876 ;	-----------------------------------------
      005AA5                       1877 _rgb_matrix_set_suspend_state:
      005AA5 E5 82            [12] 1878 	mov	a,dpl
      005AA7 90 07 96         [24] 1879 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      005AAA F0               [24] 1880 	movx	@dptr,a
                                   1881 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      005AAB E0               [24] 1882 	movx	a,@dptr
                                   1883 ;	assignBit
      005AAC F5 1E            [12] 1884 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      005AAE 13               [12] 1885 	rrc	a
      005AAF 92 12            [24] 1886 	mov	_suspended,c
                                   1887 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1888 ;	assignBit
      005AB1 C2 14            [12] 1889 	clr	_rendering
                                   1890 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      005AB3 12 55 1D         [24] 1891 	lcall	_clear_reactive
                                   1892 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      005AB6 E5 1E            [12] 1893 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      005AB8 60 0F            [24] 1894 	jz	00103$
                                   1895 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      005ABA 90 07 85         [24] 1896 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005ABD E4               [12] 1897 	clr	a
      005ABE F0               [24] 1898 	movx	@dptr,a
      005ABF 90 07 86         [24] 1899 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      005AC2 F0               [24] 1900 	movx	@dptr,a
      005AC3 75 82 00         [24] 1901 	mov	dpl, #0x00
                                   1902 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      005AC6 02 56 EC         [24] 1903 	ljmp	_rgb_matrix_set_color_all
      005AC9                       1904 00103$:
      005AC9 22               [24] 1905 	ret
                                   1906 ;------------------------------------------------------------
                                   1907 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1908 ;------------------------------------------------------------
                                   1909 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1910 ;	-----------------------------------------
                                   1911 ;	 function rgb_matrix_is_enabled
                                   1912 ;	-----------------------------------------
      005ACA                       1913 _rgb_matrix_is_enabled:
      005ACA 12 5C AD         [24] 1914 	lcall	_ak820_outline_0068
      005ACD F5 82            [12] 1915 	mov	dpl,a
      005ACF 22               [24] 1916 	ret
                                   1917 ;------------------------------------------------------------
                                   1918 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1919 ;------------------------------------------------------------
                                   1920 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1921 ;	-----------------------------------------
                                   1922 ;	 function rgb_matrix_get_mode
                                   1923 ;	-----------------------------------------
      005AD0                       1924 _rgb_matrix_get_mode:
      005AD0 12 5C 8E         [24] 1925 	lcall	_ak820_outline_0021
      005AD3 F5 82            [12] 1926 	mov	dpl,a
      005AD5 22               [24] 1927 	ret
                                   1928 ;------------------------------------------------------------
                                   1929 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1930 ;------------------------------------------------------------
                                   1931 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1932 ;	-----------------------------------------
                                   1933 ;	 function rgb_matrix_get_hue
                                   1934 ;	-----------------------------------------
      005AD6                       1935 _rgb_matrix_get_hue:
      005AD6 90 07 14         [24] 1936 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AD9 E0               [24] 1937 	movx	a,@dptr
      005ADA F5 82            [12] 1938 	mov	dpl,a
      005ADC 22               [24] 1939 	ret
                                   1940 ;------------------------------------------------------------
                                   1941 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1942 ;------------------------------------------------------------
                                   1943 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1944 ;	-----------------------------------------
                                   1945 ;	 function rgb_matrix_get_sat
                                   1946 ;	-----------------------------------------
      005ADD                       1947 _rgb_matrix_get_sat:
      005ADD 90 07 15         [24] 1948 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005AE0 E0               [24] 1949 	movx	a,@dptr
      005AE1 F5 82            [12] 1950 	mov	dpl,a
      005AE3 22               [24] 1951 	ret
                                   1952 ;------------------------------------------------------------
                                   1953 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1954 ;------------------------------------------------------------
                                   1955 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1956 ;	-----------------------------------------
                                   1957 ;	 function rgb_matrix_get_val
                                   1958 ;	-----------------------------------------
      005AE4                       1959 _rgb_matrix_get_val:
      005AE4 90 07 16         [24] 1960 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AE7 E0               [24] 1961 	movx	a,@dptr
      005AE8 F5 82            [12] 1962 	mov	dpl,a
      005AEA 22               [24] 1963 	ret
                                   1964 ;------------------------------------------------------------
                                   1965 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1966 ;------------------------------------------------------------
                                   1967 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1968 ;	-----------------------------------------
                                   1969 ;	 function rgb_matrix_get_speed
                                   1970 ;	-----------------------------------------
      005AEB                       1971 _rgb_matrix_get_speed:
      005AEB 90 07 17         [24] 1972 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005AEE E0               [24] 1973 	movx	a,@dptr
      005AEF F5 82            [12] 1974 	mov	dpl,a
      005AF1 22               [24] 1975 	ret
                                   1976 ;------------------------------------------------------------
                                   1977 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1978 ;------------------------------------------------------------
                                   1979 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1980 ;	-----------------------------------------
                                   1981 ;	 function rgb_matrix_toggle_noeeprom
                                   1982 ;	-----------------------------------------
      005AF2                       1983 _rgb_matrix_toggle_noeeprom:
      005AF2 12 5C AD         [24] 1984 	lcall	_ak820_outline_0068
      005AF5 FF               [12] 1985 	mov	r7,a
      005AF6 63 07 01         [24] 1986 	xrl	ar7,#0x01
      005AF9 90 07 13         [24] 1987 	mov	dptr,#_rgb_matrix_config
      005AFC EF               [12] 1988 	mov	a,r7
      005AFD 54 03            [12] 1989 	anl	a,#0x03
      005AFF F5 F0            [12] 1990 	mov	b,a
      005B01 E0               [24] 1991 	movx	a,@dptr
      005B02 54 FC            [12] 1992 	anl	a,#0xfc
      005B04 45 F0            [12] 1993 	orl	a,b
      005B06 F0               [24] 1994 	movx	@dptr,a
                                   1995 ;	assignBit
      005B07 C2 14            [12] 1996 	clr	_rendering
      005B09 02 55 1D         [24] 1997 	ljmp	_clear_reactive
                                   1998 ;------------------------------------------------------------
                                   1999 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   2000 ;------------------------------------------------------------
                                   2001 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   2002 ;	-----------------------------------------
                                   2003 ;	 function rgb_matrix_enable_noeeprom
                                   2004 ;	-----------------------------------------
      005B0C                       2005 _rgb_matrix_enable_noeeprom:
      005B0C 12 5C AD         [24] 2006 	lcall	_ak820_outline_0068
      005B0F 70 03            [24] 2007 	jnz	00102$
      005B11 12 55 1D         [24] 2008 	lcall	_clear_reactive
      005B14                       2009 00102$:
      005B14 12 5C CE         [24] 2010 	lcall	_ak820_outline_0117
      005B17 44 01            [12] 2011 	orl	a,#0x01
      005B19 F0               [24] 2012 	movx	@dptr,a
                                   2013 ;	assignBit
      005B1A C2 14            [12] 2014 	clr	_rendering
      005B1C 22               [24] 2015 	ret
                                   2016 ;------------------------------------------------------------
                                   2017 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2018 ;------------------------------------------------------------
                                   2019 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2020 ;	-----------------------------------------
                                   2021 ;	 function rgb_matrix_disable_noeeprom
                                   2022 ;	-----------------------------------------
      005B1D                       2023 _rgb_matrix_disable_noeeprom:
      005B1D 12 5C CE         [24] 2024 	lcall	_ak820_outline_0117
      005B20 F0               [24] 2025 	movx	@dptr,a
                                   2026 ;	assignBit
      005B21 C2 14            [12] 2027 	clr	_rendering
      005B23 02 55 1D         [24] 2028 	ljmp	_clear_reactive
                                   2029 ;------------------------------------------------------------
                                   2030 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2031 ;------------------------------------------------------------
                                   2032 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2033 ;------------------------------------------------------------
                                   2034 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2035 ;	-----------------------------------------
                                   2036 ;	 function rgb_matrix_mode_noeeprom
                                   2037 ;	-----------------------------------------
      005B26                       2038 _rgb_matrix_mode_noeeprom:
      005B26 E5 82            [12] 2039 	mov	a,dpl
      005B28 90 07 97         [24] 2040 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005B2B F0               [24] 2041 	movx	@dptr,a
                                   2042 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005B2C E0               [24] 2043 	movx	a,@dptr
      005B2D FF               [12] 2044 	mov	r7,a
      005B2E 60 05            [24] 2045 	jz	00101$
      005B30 BF 07 00         [24] 2046 	cjne	r7,#0x07,00123$
      005B33                       2047 00123$:
      005B33 40 01            [24] 2048 	jc	00102$
      005B35                       2049 00101$:
      005B35 22               [24] 2050 	ret
      005B36                       2051 00102$:
                                   2052 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      005B36 12 5C 8E         [24] 2053 	lcall	_ak820_outline_0021
      005B39 FE               [12] 2054 	mov	r6,a
      005B3A EF               [12] 2055 	mov	a,r7
      005B3B B5 06 02         [24] 2056 	cjne	a,ar6,00125$
      005B3E 80 03            [24] 2057 	sjmp	00105$
      005B40                       2058 00125$:
      005B40 12 55 1D         [24] 2059 	lcall	_clear_reactive
      005B43                       2060 00105$:
                                   2061 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      005B43 90 07 97         [24] 2062 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005B46 E0               [24] 2063 	movx	a,@dptr
      005B47 90 07 13         [24] 2064 	mov	dptr,#_rgb_matrix_config
      005B4A 25 E0            [12] 2065 	add	a,acc
      005B4C 25 E0            [12] 2066 	add	a,acc
      005B4E 54 FC            [12] 2067 	anl	a,#0xfc
      005B50 F5 F0            [12] 2068 	mov	b,a
      005B52 E0               [24] 2069 	movx	a,@dptr
      005B53 54 03            [12] 2070 	anl	a,#0x03
      005B55 45 F0            [12] 2071 	orl	a,b
      005B57 F0               [24] 2072 	movx	@dptr,a
                                   2073 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2074 ;	assignBit
      005B58 C2 14            [12] 2075 	clr	_rendering
                                   2076 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005B5A 22               [24] 2077 	ret
                                   2078 ;------------------------------------------------------------
                                   2079 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2080 ;------------------------------------------------------------
                                   2081 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2082 ;	-----------------------------------------
                                   2083 ;	 function rgb_matrix_step_noeeprom
                                   2084 ;	-----------------------------------------
      005B5B                       2085 _rgb_matrix_step_noeeprom:
                                   2086 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005B5B 12 5C 8E         [24] 2087 	lcall	_ak820_outline_0021
      005B5E FF               [12] 2088 	mov	r7,a
      005B5F 0F               [12] 2089 	inc	r7
      005B60 BF 07 00         [24] 2090 	cjne	r7,#0x07,00112$
      005B63                       2091 00112$:
      005B63 40 04            [24] 2092 	jc	00103$
      005B65 7F 01            [12] 2093 	mov	r7,#0x01
      005B67 80 07            [24] 2094 	sjmp	00104$
      005B69                       2095 00103$:
      005B69 12 5C 8E         [24] 2096 	lcall	_ak820_outline_0021
      005B6C FE               [12] 2097 	mov	r6,a
      005B6D 0E               [12] 2098 	inc	r6
      005B6E 8E 07            [24] 2099 	mov	ar7,r6
      005B70                       2100 00104$:
      005B70 8F 82            [24] 2101 	mov	dpl, r7
                                   2102 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      005B72 61 26            [12] 2103 	ajmp	_rgb_matrix_mode_noeeprom
                                   2104 ;------------------------------------------------------------
                                   2105 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2106 ;------------------------------------------------------------
                                   2107 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2108 ;	-----------------------------------------
                                   2109 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2110 ;	-----------------------------------------
      005B74                       2111 _rgb_matrix_step_reverse_noeeprom:
                                   2112 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005B74 12 5C 8E         [24] 2113 	lcall	_ak820_outline_0021
      005B77 24 FE            [12] 2114 	add	a,#0xff - 0x01
      005B79 40 04            [24] 2115 	jc	00103$
                                   2116 ;	free result
      005B7B 7F 06            [12] 2117 	mov	r7,#0x06
      005B7D 80 05            [24] 2118 	sjmp	00104$
      005B7F                       2119 00103$:
      005B7F 12 5C 8E         [24] 2120 	lcall	_ak820_outline_0021
      005B82 14               [12] 2121 	dec	a
      005B83 FF               [12] 2122 	mov	r7,a
      005B84                       2123 00104$:
      005B84 8F 82            [24] 2124 	mov	dpl, r7
                                   2125 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005B86 61 26            [12] 2126 	ajmp	_rgb_matrix_mode_noeeprom
                                   2127 ;------------------------------------------------------------
                                   2128 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2129 ;------------------------------------------------------------
                                   2130 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2131 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2132 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2133 ;------------------------------------------------------------
                                   2134 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2135 ;	-----------------------------------------
                                   2136 ;	 function rgb_matrix_sethsv_noeeprom
                                   2137 ;	-----------------------------------------
      005B88                       2138 _rgb_matrix_sethsv_noeeprom:
      005B88 12 38 44         [24] 2139 	lcall	_ak820_outline_0109
      005B8B 90 07 9A         [24] 2140 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005B8E 12 38 49         [24] 2141 	lcall	_ak820_outline_0110
                                   2142 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005B91 90 07 9A         [24] 2143 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005B94 E0               [24] 2144 	movx	a,@dptr
      005B95 90 07 14         [24] 2145 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005B98 F0               [24] 2146 	movx	@dptr,a
                                   2147 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005B99 90 07 98         [24] 2148 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005B9C E0               [24] 2149 	movx	a,@dptr
      005B9D FF               [12] 2150 	mov	r7,a
      005B9E 90 07 15         [24] 2151 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005BA1 F0               [24] 2152 	movx	@dptr,a
                                   2153 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005BA2 90 07 99         [24] 2154 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005BA5 E0               [24] 2155 	movx	a,@dptr
      005BA6 FF               [12] 2156 	mov  r7,a
      005BA7 24 5F            [12] 2157 	add	a,#0xff - 0xa0
      005BA9 50 04            [24] 2158 	jnc	00103$
                                   2159 ;	free result
      005BAB 7E A0            [12] 2160 	mov	r6,#0xa0
      005BAD 80 02            [24] 2161 	sjmp	00104$
      005BAF                       2162 00103$:
      005BAF 8F 06            [24] 2163 	mov	ar6,r7
      005BB1                       2164 00104$:
      005BB1 90 07 16         [24] 2165 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005BB4 EE               [12] 2166 	mov	a,r6
      005BB5 F0               [24] 2167 	movx	@dptr,a
                                   2168 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005BB6 22               [24] 2169 	ret
                                   2170 ;------------------------------------------------------------
                                   2171 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2172 ;------------------------------------------------------------
                                   2173 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2174 ;------------------------------------------------------------
                                   2175 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2176 ;	-----------------------------------------
                                   2177 ;	 function rgb_matrix_set_speed_noeeprom
                                   2178 ;	-----------------------------------------
      005BB7                       2179 _rgb_matrix_set_speed_noeeprom:
      005BB7 E5 82            [12] 2180 	mov	a,dpl
      005BB9 90 07 9C         [24] 2181 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      005BBC F0               [24] 2182 	movx	@dptr,a
      005BBD E0               [24] 2183 	movx	a,@dptr
      005BBE 90 07 17         [24] 2184 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005BC1 F0               [24] 2185 	movx	@dptr,a
      005BC2 22               [24] 2186 	ret
                                   2187 ;------------------------------------------------------------
                                   2188 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2189 ;------------------------------------------------------------
                                   2190 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2191 ;------------------------------------------------------------
                                   2192 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2193 ;	-----------------------------------------
                                   2194 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2195 ;	-----------------------------------------
      005BC3                       2196 _rgb_matrix_increase_hue_noeeprom:
      005BC3 90 07 14         [24] 2197 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005BC6 E0               [24] 2198 	movx	a,@dptr
      005BC7 24 08            [12] 2199 	add	a,#0x08
      005BC9 90 07 14         [24] 2200 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005BCC F0               [24] 2201 	movx	@dptr,a
      005BCD 22               [24] 2202 	ret
                                   2203 ;------------------------------------------------------------
                                   2204 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2205 ;------------------------------------------------------------
                                   2206 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2207 ;	-----------------------------------------
                                   2208 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2209 ;	-----------------------------------------
      005BCE                       2210 _rgb_matrix_decrease_hue_noeeprom:
      005BCE 90 07 14         [24] 2211 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005BD1 E0               [24] 2212 	movx	a,@dptr
      005BD2 24 F8            [12] 2213 	add	a,#0xf8
      005BD4 90 07 14         [24] 2214 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005BD7 F0               [24] 2215 	movx	@dptr,a
      005BD8 22               [24] 2216 	ret
                                   2217 ;------------------------------------------------------------
                                   2218 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2219 ;------------------------------------------------------------
                                   2220 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2221 ;	-----------------------------------------
                                   2222 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2223 ;	-----------------------------------------
      005BD9                       2224 _rgb_matrix_increase_sat_noeeprom:
      005BD9 90 07 15         [24] 2225 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005BDC 12 5C 97         [24] 2226 	lcall	_ak820_outline_0052
      005BDF 12 55 B8         [24] 2227 	lcall	_add_sat
      005BE2 AF 82            [24] 2228 	mov	r7, dpl
      005BE4 90 07 15         [24] 2229 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005BE7 EF               [12] 2230 	mov	a,r7
      005BE8 F0               [24] 2231 	movx	@dptr,a
      005BE9 22               [24] 2232 	ret
                                   2233 ;------------------------------------------------------------
                                   2234 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2235 ;------------------------------------------------------------
                                   2236 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2237 ;	-----------------------------------------
                                   2238 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2239 ;	-----------------------------------------
      005BEA                       2240 _rgb_matrix_decrease_sat_noeeprom:
      005BEA 90 07 15         [24] 2241 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005BED 12 5C A2         [24] 2242 	lcall	_ak820_outline_0053
      005BF0 12 55 DD         [24] 2243 	lcall	_sub_sat
      005BF3 AF 82            [24] 2244 	mov	r7, dpl
      005BF5 90 07 15         [24] 2245 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005BF8 EF               [12] 2246 	mov	a,r7
      005BF9 F0               [24] 2247 	movx	@dptr,a
      005BFA 22               [24] 2248 	ret
                                   2249 ;------------------------------------------------------------
                                   2250 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2251 ;------------------------------------------------------------
                                   2252 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2253 ;------------------------------------------------------------
                                   2254 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2255 ;	-----------------------------------------
                                   2256 ;	 function rgb_matrix_increase_val_noeeprom
                                   2257 ;	-----------------------------------------
      005BFB                       2258 _rgb_matrix_increase_val_noeeprom:
                                   2259 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005BFB 90 07 16         [24] 2260 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005BFE 12 5C 97         [24] 2261 	lcall	_ak820_outline_0052
      005C01 12 55 B8         [24] 2262 	lcall	_add_sat
                                   2263 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005C04 E5 82            [12] 2264 	mov	a,dpl
      005C06 FF               [12] 2265 	mov	r7,a
      005C07 24 5F            [12] 2266 	add	a,#0xff - 0xa0
      005C09 50 04            [24] 2267 	jnc	00103$
                                   2268 ;	free result
      005C0B 7E A0            [12] 2269 	mov	r6,#0xa0
      005C0D 80 02            [24] 2270 	sjmp	00104$
      005C0F                       2271 00103$:
      005C0F 8F 06            [24] 2272 	mov	ar6,r7
      005C11                       2273 00104$:
      005C11 90 07 16         [24] 2274 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005C14 EE               [12] 2275 	mov	a,r6
      005C15 F0               [24] 2276 	movx	@dptr,a
                                   2277 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005C16 22               [24] 2278 	ret
                                   2279 ;------------------------------------------------------------
                                   2280 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2281 ;------------------------------------------------------------
                                   2282 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2283 ;	-----------------------------------------
                                   2284 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2285 ;	-----------------------------------------
      005C17                       2286 _rgb_matrix_decrease_val_noeeprom:
      005C17 90 07 16         [24] 2287 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005C1A 12 5C A2         [24] 2288 	lcall	_ak820_outline_0053
      005C1D 12 55 DD         [24] 2289 	lcall	_sub_sat
      005C20 AF 82            [24] 2290 	mov	r7, dpl
      005C22 90 07 16         [24] 2291 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005C25 EF               [12] 2292 	mov	a,r7
      005C26 F0               [24] 2293 	movx	@dptr,a
      005C27 22               [24] 2294 	ret
                                   2295 ;------------------------------------------------------------
                                   2296 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2297 ;------------------------------------------------------------
                                   2298 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2299 ;	-----------------------------------------
                                   2300 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2301 ;	-----------------------------------------
      005C28                       2302 _rgb_matrix_increase_speed_noeeprom:
      005C28 90 07 17         [24] 2303 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005C2B 12 5C 97         [24] 2304 	lcall	_ak820_outline_0052
      005C2E 12 55 B8         [24] 2305 	lcall	_add_sat
      005C31 AF 82            [24] 2306 	mov	r7, dpl
      005C33 90 07 17         [24] 2307 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005C36 EF               [12] 2308 	mov	a,r7
      005C37 F0               [24] 2309 	movx	@dptr,a
      005C38 22               [24] 2310 	ret
                                   2311 ;------------------------------------------------------------
                                   2312 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2313 ;------------------------------------------------------------
                                   2314 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2315 ;	-----------------------------------------
                                   2316 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2317 ;	-----------------------------------------
      005C39                       2318 _rgb_matrix_decrease_speed_noeeprom:
      005C39 90 07 17         [24] 2319 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005C3C 12 5C A2         [24] 2320 	lcall	_ak820_outline_0053
      005C3F 12 55 DD         [24] 2321 	lcall	_sub_sat
      005C42 AF 82            [24] 2322 	mov	r7, dpl
      005C44 90 07 17         [24] 2323 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005C47 EF               [12] 2324 	mov	a,r7
      005C48 F0               [24] 2325 	movx	@dptr,a
      005C49 22               [24] 2326 	ret
                                   2327 ;------------------------------------------------------------
                                   2328 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2329 ;------------------------------------------------------------
                                   2330 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2331 ;	-----------------------------------------
                                   2332 ;	 function rgb_matrix_toggle
                                   2333 ;	-----------------------------------------
      005C4A                       2334 _rgb_matrix_toggle:
      005C4A 51 F2            [12] 2335 	acall	_rgb_matrix_toggle_noeeprom
      005C4C 02 55 FA         [24] 2336 	ljmp	_mark_dirty
                                   2337 ;------------------------------------------------------------
                                   2338 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2339 ;------------------------------------------------------------
                                   2340 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2341 ;	-----------------------------------------
                                   2342 ;	 function rgb_matrix_step
                                   2343 ;	-----------------------------------------
      005C4F                       2344 _rgb_matrix_step:
      005C4F 71 5B            [12] 2345 	acall	_rgb_matrix_step_noeeprom
      005C51 02 55 FA         [24] 2346 	ljmp	_mark_dirty
                                   2347 ;------------------------------------------------------------
                                   2348 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2349 ;------------------------------------------------------------
                                   2350 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2351 ;	-----------------------------------------
                                   2352 ;	 function rgb_matrix_step_reverse
                                   2353 ;	-----------------------------------------
      005C54                       2354 _rgb_matrix_step_reverse:
      005C54 71 74            [12] 2355 	acall	_rgb_matrix_step_reverse_noeeprom
      005C56 02 55 FA         [24] 2356 	ljmp	_mark_dirty
                                   2357 ;------------------------------------------------------------
                                   2358 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2359 ;------------------------------------------------------------
                                   2360 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2361 ;	-----------------------------------------
                                   2362 ;	 function rgb_matrix_increase_hue
                                   2363 ;	-----------------------------------------
      005C59                       2364 _rgb_matrix_increase_hue:
      005C59 71 C3            [12] 2365 	acall	_rgb_matrix_increase_hue_noeeprom
      005C5B 02 55 FA         [24] 2366 	ljmp	_mark_dirty
                                   2367 ;------------------------------------------------------------
                                   2368 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2369 ;------------------------------------------------------------
                                   2370 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2371 ;	-----------------------------------------
                                   2372 ;	 function rgb_matrix_decrease_hue
                                   2373 ;	-----------------------------------------
      005C5E                       2374 _rgb_matrix_decrease_hue:
      005C5E 71 CE            [12] 2375 	acall	_rgb_matrix_decrease_hue_noeeprom
      005C60 02 55 FA         [24] 2376 	ljmp	_mark_dirty
                                   2377 ;------------------------------------------------------------
                                   2378 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2379 ;------------------------------------------------------------
                                   2380 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2381 ;	-----------------------------------------
                                   2382 ;	 function rgb_matrix_increase_sat
                                   2383 ;	-----------------------------------------
      005C63                       2384 _rgb_matrix_increase_sat:
      005C63 71 D9            [12] 2385 	acall	_rgb_matrix_increase_sat_noeeprom
      005C65 02 55 FA         [24] 2386 	ljmp	_mark_dirty
                                   2387 ;------------------------------------------------------------
                                   2388 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2389 ;------------------------------------------------------------
                                   2390 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2391 ;	-----------------------------------------
                                   2392 ;	 function rgb_matrix_decrease_sat
                                   2393 ;	-----------------------------------------
      005C68                       2394 _rgb_matrix_decrease_sat:
      005C68 71 EA            [12] 2395 	acall	_rgb_matrix_decrease_sat_noeeprom
      005C6A 02 55 FA         [24] 2396 	ljmp	_mark_dirty
                                   2397 ;------------------------------------------------------------
                                   2398 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2399 ;------------------------------------------------------------
                                   2400 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2401 ;	-----------------------------------------
                                   2402 ;	 function rgb_matrix_increase_val
                                   2403 ;	-----------------------------------------
      005C6D                       2404 _rgb_matrix_increase_val:
      005C6D 71 FB            [12] 2405 	acall	_rgb_matrix_increase_val_noeeprom
      005C6F 02 55 FA         [24] 2406 	ljmp	_mark_dirty
                                   2407 ;------------------------------------------------------------
                                   2408 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2409 ;------------------------------------------------------------
                                   2410 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2411 ;	-----------------------------------------
                                   2412 ;	 function rgb_matrix_decrease_val
                                   2413 ;	-----------------------------------------
      005C72                       2414 _rgb_matrix_decrease_val:
      005C72 91 17            [12] 2415 	acall	_rgb_matrix_decrease_val_noeeprom
      005C74 02 55 FA         [24] 2416 	ljmp	_mark_dirty
                                   2417 ;------------------------------------------------------------
                                   2418 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2419 ;------------------------------------------------------------
                                   2420 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2421 ;	-----------------------------------------
                                   2422 ;	 function rgb_matrix_increase_speed
                                   2423 ;	-----------------------------------------
      005C77                       2424 _rgb_matrix_increase_speed:
      005C77 91 28            [12] 2425 	acall	_rgb_matrix_increase_speed_noeeprom
      005C79 02 55 FA         [24] 2426 	ljmp	_mark_dirty
                                   2427 ;------------------------------------------------------------
                                   2428 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2429 ;------------------------------------------------------------
                                   2430 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2431 ;	-----------------------------------------
                                   2432 ;	 function rgb_matrix_decrease_speed
                                   2433 ;	-----------------------------------------
      005C7C                       2434 _rgb_matrix_decrease_speed:
      005C7C 91 39            [12] 2435 	acall	_rgb_matrix_decrease_speed_noeeprom
      005C7E 02 55 FA         [24] 2436 	ljmp	_mark_dirty
                                   2437 ;------------------------------------------------------------
                                   2438 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2439 ;------------------------------------------------------------
                                   2440 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2441 ;------------------------------------------------------------
                                   2442 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2443 ;	-----------------------------------------
                                   2444 ;	 function rgb_matrix_mode
                                   2445 ;	-----------------------------------------
      005C81                       2446 _rgb_matrix_mode:
      005C81 E5 82            [12] 2447 	mov	a,dpl
      005C83 90 07 9D         [24] 2448 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005C86 12 5C E1         [24] 2449 	lcall	_ak820_outline_0178
      005C89 71 26            [12] 2450 	acall	_rgb_matrix_mode_noeeprom
      005C8B 02 55 FA         [24] 2451 	ljmp	_mark_dirty
                                   2452 ;------------------------------------------------------------
                                   2453 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2454 ;------------------------------------------------------------
                                   2455 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2456 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2457 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2458 ;------------------------------------------------------------
                                   2459 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2460 ;	-----------------------------------------
                                   2461 	.area CSEG    (CODE)
                                   2462 	.area CONST   (CODE)
                                   2463 	.area CONST   (CODE)
      00C09E                       2464 _sine8_coefficients_10000_290:
      00C09E 00                    2465 	.db #0x00	; 0
      00C09F 31                    2466 	.db #0x31	; 49	'1'
      00C0A0 31                    2467 	.db #0x31	; 49	'1'
      00C0A1 29                    2468 	.db #0x29	; 41
      00C0A2 5A                    2469 	.db #0x5a	; 90	'Z'
      00C0A3 1B                    2470 	.db #0x1b	; 27
      00C0A4 75                    2471 	.db #0x75	; 117	'u'
      00C0A5 0A                    2472 	.db #0x0a	; 10
                                   2473 	.area CSEG    (CODE)
                                   2474 	.area XINIT   (CODE)
                                   2475 	.area CABS    (ABS,CODE)
                                   2476 
                                   2477 ; Experimental exact instruction outlining.
                                   2478 	.globl _ak820_outline_0007
                                   2479 	.globl _ak820_outline_0021
                                   2480 	.globl _ak820_outline_0052
                                   2481 	.globl _ak820_outline_0053
                                   2482 	.globl _ak820_outline_0056
                                   2483 	.globl _ak820_outline_0062
                                   2484 	.globl _ak820_outline_0064
                                   2485 	.globl _ak820_outline_0068
                                   2486 	.globl _ak820_outline_0073
                                   2487 	.globl _ak820_outline_0074
                                   2488 	.globl _ak820_outline_0086
                                   2489 	.globl _ak820_outline_0109
                                   2490 	.globl _ak820_outline_0110
                                   2491 	.globl _ak820_outline_0111
                                   2492 	.globl _ak820_outline_0117
                                   2493 	.globl _ak820_outline_0123
                                   2494 	.globl _ak820_outline_0126
                                   2495 	.globl _ak820_outline_0128
                                   2496 	.globl _ak820_outline_0129
                                   2497 	.globl _ak820_outline_0138
                                   2498 	.globl _ak820_outline_0139
                                   2499 	.globl _ak820_outline_0144
                                   2500 	.globl _ak820_outline_0149
                                   2501 	.globl _ak820_outline_0177
                                   2502 	.globl _ak820_outline_0178
                                   2503 	.globl _ak820_outline_0180
                                   2504 	.globl _ak820_outline_0186
                                   2505 	.globl _ak820_outline_0192
                                   2506 	.globl _ak820_outline_0193
                                   2507 	.globl _ak820_outline_0194
                                   2508 
                                   2509 	.area CSEG (CODE)
                                   2510 ; function ak820_outline_0021
      005C8E                       2511 _ak820_outline_0021:
      005C8E 90 07 13         [24] 2512 	mov	dptr,#_rgb_matrix_config
      005C91 E0               [24] 2513 	movx	a,@dptr
      005C92 03               [12] 2514 	rr	a
      005C93 03               [12] 2515 	rr	a
      005C94 54 3F            [12] 2516 	anl	a,#0x3f
      005C96 22               [24] 2517 	ret
                                   2518 
                                   2519 	.area CSEG (CODE)
                                   2520 ; function ak820_outline_0052
      005C97                       2521 _ak820_outline_0052:
      005C97 E0               [24] 2522 	movx	a,@dptr
      005C98 FF               [12] 2523 	mov	r7,a
      005C99 90 07 7C         [24] 2524 	mov	dptr,#_add_sat_PARM_2
      005C9C 74 10            [12] 2525 	mov	a,#0x10
      005C9E F0               [24] 2526 	movx	@dptr,a
      005C9F 8F 82            [24] 2527 	mov	dpl,r7
      005CA1 22               [24] 2528 	ret
                                   2529 
                                   2530 	.area CSEG (CODE)
                                   2531 ; function ak820_outline_0053
      005CA2                       2532 _ak820_outline_0053:
      005CA2 E0               [24] 2533 	movx	a,@dptr
      005CA3 FF               [12] 2534 	mov	r7,a
      005CA4 90 07 7E         [24] 2535 	mov	dptr,#_sub_sat_PARM_2
      005CA7 74 10            [12] 2536 	mov	a,#0x10
      005CA9 F0               [24] 2537 	movx	@dptr,a
      005CAA 8F 82            [24] 2538 	mov	dpl,r7
      005CAC 22               [24] 2539 	ret
                                   2540 
                                   2541 	.area CSEG (CODE)
                                   2542 ; function ak820_outline_0068
      005CAD                       2543 _ak820_outline_0068:
      005CAD 90 07 13         [24] 2544 	mov	dptr,#_rgb_matrix_config
      005CB0 E0               [24] 2545 	movx	a,@dptr
      005CB1 54 03            [12] 2546 	anl	a,#0x03
      005CB3 22               [24] 2547 	ret
                                   2548 
                                   2549 	.area CSEG (CODE)
                                   2550 ; function ak820_outline_0073
      005CB4                       2551 _ak820_outline_0073:
      005CB4 74 08            [12] 2552 	mov	a,#0x08
      005CB6 F0               [24] 2553 	movx	@dptr,a
      005CB7 E4               [12] 2554 	clr	a
      005CB8 A3               [24] 2555 	inc	dptr
      005CB9 F0               [24] 2556 	movx	@dptr,a
      005CBA 90 07 13         [24] 2557 	mov	dptr,#_rgb_matrix_config
      005CBD 22               [24] 2558 	ret
                                   2559 
                                   2560 	.area CSEG (CODE)
                                   2561 ; function ak820_outline_0086
      005CBE                       2562 _ak820_outline_0086:
      005CBE 74 18            [12] 2563 	mov	a,#0x18
      005CC0 F0               [24] 2564 	movx	@dptr,a
      005CC1 E4               [12] 2565 	clr	a
      005CC2 A3               [24] 2566 	inc	dptr
      005CC3 F0               [24] 2567 	movx	@dptr,a
      005CC4 A3               [24] 2568 	inc	dptr
      005CC5 F0               [24] 2569 	movx	@dptr,a
      005CC6 22               [24] 2570 	ret
                                   2571 
                                   2572 	.area CSEG (CODE)
                                   2573 ; function ak820_outline_0111
      005CC7                       2574 _ak820_outline_0111:
      005CC7 35 F0            [12] 2575 	addc	a,b
      005CC9 F5 83            [12] 2576 	mov	dph,a
      005CCB E4               [12] 2577 	clr	a
      005CCC 93               [24] 2578 	movc	a,@a+dptr
      005CCD 22               [24] 2579 	ret
                                   2580 
                                   2581 	.area CSEG (CODE)
                                   2582 ; function ak820_outline_0117
      005CCE                       2583 _ak820_outline_0117:
      005CCE 90 07 13         [24] 2584 	mov	dptr,#_rgb_matrix_config
      005CD1 E0               [24] 2585 	movx	a,@dptr
      005CD2 54 FC            [12] 2586 	anl	a,#0xfc
      005CD4 22               [24] 2587 	ret
                                   2588 
                                   2589 	.area CSEG (CODE)
                                   2590 ; function ak820_outline_0144
      005CD5                       2591 _ak820_outline_0144:
      005CD5 90 07 22         [24] 2592 	mov	dptr,#_frame_mode
      005CD8 E0               [24] 2593 	movx	a,@dptr
      005CD9 FE               [12] 2594 	mov	r6,a
      005CDA 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0177
      005CDB                       2599 _ak820_outline_0177:
      005CDB F0               [24] 2600 	movx	@dptr,a
      005CDC E5 F0            [12] 2601 	mov	a,b
      005CDE A3               [24] 2602 	inc	dptr
      005CDF F0               [24] 2603 	movx	@dptr,a
      005CE0 22               [24] 2604 	ret
                                   2605 
                                   2606 	.area CSEG (CODE)
                                   2607 ; function ak820_outline_0178
      005CE1                       2608 _ak820_outline_0178:
      005CE1 F0               [24] 2609 	movx	@dptr,a
      005CE2 E0               [24] 2610 	movx	a,@dptr
      005CE3 F5 82            [12] 2611 	mov	dpl,a
      005CE5 22               [24] 2612 	ret
                                   2613 
                                   2614 	.area CSEG (CODE)
                                   2615 ; function ak820_outline_0180
      005CE6                       2616 _ak820_outline_0180:
      005CE6 90 07 17         [24] 2617 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005CE9 E0               [24] 2618 	movx	a,@dptr
      005CEA 23               [12] 2619 	rl	a
      005CEB 23               [12] 2620 	rl	a
      005CEC 54 03            [12] 2621 	anl	a,#0x03
      005CEE 22               [24] 2622 	ret
                                   2623 
                                   2624 	.area CSEG (CODE)
                                   2625 ; function ak820_outline_0186
      005CEF                       2626 _ak820_outline_0186:
      005CEF 90 0E 37         [24] 2627 	mov	dptr,#_memset_PARM_2
      005CF2 E4               [12] 2628 	clr	a
      005CF3 F0               [24] 2629 	movx	@dptr,a
      005CF4 90 0E 38         [24] 2630 	mov	dptr,#_memset_PARM_3
      005CF7 22               [24] 2631 	ret
                                   2632 
                                   2633 	.area CSEG (CODE)
                                   2634 ; function ak820_outline_0192
      005CF8                       2635 _ak820_outline_0192:
      005CF8 90 07 21         [24] 2636 	mov	dptr,#_led_index
      005CFB E0               [24] 2637 	movx	a,@dptr
      005CFC 22               [24] 2638 	ret
