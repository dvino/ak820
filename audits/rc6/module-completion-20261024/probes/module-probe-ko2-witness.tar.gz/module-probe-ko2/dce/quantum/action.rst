                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_key_override_cancel
                                     21 	.globl _pre_process_record_quantum
                                     22 	.globl _get_record_keycode
                                     23 	.globl _repeat_key_cancel
                                     24 	.globl _clear_owned_usages
                                     25 	.globl _owned_usage_key
                                     26 	.globl _clear_owned_keys
                                     27 	.globl _del_owned_key
                                     28 	.globl _add_owned_key
                                     29 	.globl _clear_owned_mods
                                     30 	.globl _del_owned_weak_mods
                                     31 	.globl _add_owned_weak_mods
                                     32 	.globl _del_owned_mods
                                     33 	.globl _add_owned_mods
                                     34 	.globl _clear_weak_mods
                                     35 	.globl _clear_mods
                                     36 	.globl _send_keyboard_report
                                     37 	.globl _layer_hold_clear
                                     38 	.globl _layer_hold_off
                                     39 	.globl _layer_hold_on
                                     40 	.globl _ak820_resolve_key
                                     41 	.globl _layer_xor
                                     42 	.globl _layer_and
                                     43 	.globl _layer_or
                                     44 	.globl _layer_off
                                     45 	.globl _layer_on
                                     46 	.globl _layer_move
                                     47 	.globl _layer_clear
                                     48 	.globl _layer_state_set
                                     49 	.globl _default_layer_xor
                                     50 	.globl _default_layer_and
                                     51 	.globl _default_layer_or
                                     52 	.globl _default_layer_set
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      00001F                        588 _process_action_sloc0_1_0:
      00001F                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      000020                        606 _process_action_sloc1_1_0:
      000020                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      000876                        616 _tp_buttons::
      000876                        617 	.ds 2
      000878                        618 _action_exec_PARM_1:
      000878                        619 	.ds 6
      00087E                        620 _action_exec_record_10001_634:
      00087E                        621 	.ds 9
      000887                        622 _ak820_action_exec_event_10000_638:
      000887                        623 	.ds 2
      000889                        624 _ak820_action_exec_snapshot_10000_639:
      000889                        625 	.ds 6
      00088F                        626 _process_record_record_argument_10000_642:
      00088F                        627 	.ds 2
      000891                        628 _process_record_handler_record_argument_10000_650:
      000891                        629 	.ds 2
      000893                        630 _process_record_handler_action_10000_651:
      000893                        631 	.ds 2
      000895                        632 _process_action_PARM_2:
      000895                        633 	.ds 2
      000897                        634 _process_action_record_argument_10000_662:
      000897                        635 	.ds 2
      000899                        636 _process_action_on_40000_685:
      000899                        637 	.ds 1
      00089A                        638 _register_code_code_10000_719:
      00089A                        639 	.ds 1
      00089B                        640 _unregister_code_code_10000_733:
      00089B                        641 	.ds 1
      00089C                        642 _tap_code_delay_PARM_2:
      00089C                        643 	.ds 2
      00089E                        644 _tap_code_delay_code_10000_746:
      00089E                        645 	.ds 1
      00089F                        646 _tap_code_code_10000_753:
      00089F                        647 	.ds 1
      0008A0                        648 _register_mods_mods_10000_755:
      0008A0                        649 	.ds 1
      0008A1                        650 _unregister_mods_mods_10000_759:
      0008A1                        651 	.ds 1
      0008A2                        652 _register_weak_mods_mods_10000_763:
      0008A2                        653 	.ds 1
      0008A3                        654 _unregister_weak_mods_mods_10000_767:
      0008A3                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000E52                        664 _disable_action_cache::
      000E52                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      0075A8                        709 _action_exec:
                                    710 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0075A8 90 08 7A         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0075AB 12 37 BE         [24]  712 	lcall	_ak820_outline_0007
      0075AE 12 35 B9         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0075B1 90 08 78         [24]  715 	mov	dptr,#_action_exec_PARM_1
      0075B4 12 4A 69         [24]  716 	lcall	_ak820_tapping_before
      0075B7 E5 82            [12]  717 	mov	a, dpl
      0075B9 70 01            [24]  718 	jnz	00102$
      0075BB 22               [24]  719 	ret
      0075BC                        720 00102$:
                                    721 ;	quantum/action.c:126: if (event.pressed) {
      0075BC 90 08 7D         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0075BF E0               [24]  723 	movx	a,@dptr
      0075C0 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:128: clear_weak_mods();
      0075C2 12 86 68         [24]  726 	lcall	_clear_weak_mods
      0075C5                        727 00104$:
                                    728 ;	quantum/action.c:140: record.event = event;
      0075C5 90 0E 2F         [24]  729 	mov	dptr,#___memcpy_PARM_2
      0075C8 74 78            [12]  730 	mov	a,#_action_exec_PARM_1
      0075CA F0               [24]  731 	movx	@dptr,a
      0075CB 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      0075CD 12 7C 21         [24]  733 	lcall	_ak820_outline_0055
      0075D0 12 7C 3A         [24]  734 	lcall	_ak820_outline_0113
      0075D3 90 08 7E         [24]  735 	mov	dptr,#_action_exec_record_10001_634
      0075D6 F5 F0            [12]  736 	mov	b,a
      0075D8 12 BF 43         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:142: record.tap.count = 0;
      0075DB 90 08 84         [24]  739 	mov	dptr,#(_action_exec_record_10001_634 + 0x0006)
      0075DE E0               [24]  740 	movx	a,@dptr
      0075DF 54 0F            [12]  741 	anl	a,#0x0f
      0075E1 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:147: record.keycode = 0;
      0075E2 90 08 85         [24]  744 	mov	dptr,#(_action_exec_record_10001_634 + 0x0007)
      0075E5 12 55 0D         [24]  745 	lcall	_ak820_outline_0154
                                    746 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0075E8 90 08 82         [24]  747 	mov	dptr,#(_action_exec_record_10001_634 + 0x0004)
      0075EB E0               [24]  748 	movx	a,@dptr
      0075EC 60 0A            [24]  749 	jz	00107$
      0075EE 90 08 7E         [24]  750 	mov	dptr,#_action_exec_record_10001_634
      0075F1 12 A5 70         [24]  751 	lcall	_pre_process_record_quantum
      0075F4 E5 82            [12]  752 	mov	a, dpl
      0075F6 60 10            [24]  753 	jz	00110$
      0075F8                        754 00107$:
                                    755 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      0075F8 90 08 7E         [24]  756 	mov	dptr,#_action_exec_record_10001_634
      0075FB 12 4B 5A         [24]  757 	lcall	_ak820_tapping_process
      0075FE E5 82            [12]  758 	mov	a, dpl
      007600 70 01            [24]  759 	jnz	00106$
      007602 22               [24]  760 	ret
      007603                        761 00106$:
                                    762 ;	quantum/action.c:185: process_record(&record);
      007603 90 08 7E         [24]  763 	mov	dptr,#_action_exec_record_10001_634
                                    764 ;	quantum/action.c:200: }
      007606 C1 47            [12]  765 	ajmp	_process_record
      007608                        766 00110$:
      007608 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'ak820_action_exec'
                                    770 ;------------------------------------------------------------
                                    771 ;event         Allocated with name '_ak820_action_exec_event_10000_638'
                                    772 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_639'
                                    773 ;------------------------------------------------------------
                                    774 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    775 ;	-----------------------------------------
                                    776 ;	 function ak820_action_exec
                                    777 ;	-----------------------------------------
      007609                        778 _ak820_action_exec:
      007609 12 38 44         [24]  779 	lcall	_ak820_outline_0109
      00760C 90 08 87         [24]  780 	mov	dptr,#_ak820_action_exec_event_10000_638
      00760F 12 38 49         [24]  781 	lcall	_ak820_outline_0110
                                    782 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007612 90 08 87         [24]  783 	mov	dptr,#_ak820_action_exec_event_10000_638
      007615 12 38 26         [24]  784 	lcall	_ak820_outline_0081
      007618 7F 00            [12]  785 	mov	r7,#0x00
      00761A 90 0E 2F         [24]  786 	mov	dptr,#___memcpy_PARM_2
      00761D ED               [12]  787 	mov	a,r5
      00761E 12 37 E5         [24]  788 	lcall	_ak820_outline_0020
      007621 90 0E 32         [24]  789 	mov	dptr,#___memcpy_PARM_3
      007624 12 7C 3A         [24]  790 	lcall	_ak820_outline_0113
      007627 90 08 89         [24]  791 	mov	dptr,#_ak820_action_exec_snapshot_10000_639
      00762A F5 F0            [12]  792 	mov	b,a
      00762C 12 BF 43         [24]  793 	lcall	___memcpy
                                    794 ;	quantum/action.c:207: action_exec(snapshot);
      00762F 90 0E 2F         [24]  795 	mov	dptr,#___memcpy_PARM_2
      007632 74 89            [12]  796 	mov	a,#_ak820_action_exec_snapshot_10000_639
      007634 F0               [24]  797 	movx	@dptr,a
      007635 74 08            [12]  798 	mov	a,#(_ak820_action_exec_snapshot_10000_639 >> 8)
      007637 12 7C 21         [24]  799 	lcall	_ak820_outline_0055
      00763A 12 7C 3A         [24]  800 	lcall	_ak820_outline_0113
      00763D 90 08 78         [24]  801 	mov	dptr,#_action_exec_PARM_1
      007640 F5 F0            [12]  802 	mov	b,a
      007642 12 BF 43         [24]  803 	lcall	___memcpy
                                    804 ;	quantum/action.c:208: }
      007645 A1 A8            [12]  805 	ajmp	_action_exec
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'process_record_nocache'
                                    808 ;------------------------------------------------------------
                                    809 ;record        Allocated with name '_process_record_nocache_record_10000_640'
                                    810 ;------------------------------------------------------------
                                    811 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    812 ;	-----------------------------------------
                                    813 ;	 function process_record
                                    814 ;	-----------------------------------------
      007647                        815 _process_record:
      007647 12 38 44         [24]  816 	lcall	_ak820_outline_0109
      00764A 90 08 8F         [24]  817 	mov	dptr,#_process_record_record_argument_10000_642
      00764D 12 38 49         [24]  818 	lcall	_ak820_outline_0110
                                    819 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007650 90 08 8F         [24]  820 	mov	dptr,#_process_record_record_argument_10000_642
      007653 12 37 FD         [24]  821 	lcall	_ak820_outline_0056
                                    822 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      007656 74 04            [12]  823 	mov	a,#0x04
      007658 12 41 26         [24]  824 	lcall	_ak820_outline_0012
      00765B 70 01            [24]  825 	jnz	00102$
                                    826 ;	quantum/action.c:354: return;
      00765D 22               [24]  827 	ret
      00765E                        828 00102$:
                                    829 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      00765E 8E 04            [24]  830 	mov	ar4,r6
      007660 8F 05            [24]  831 	mov	ar5,r7
      007662 90 0E 2F         [24]  832 	mov	dptr,#___memcpy_PARM_2
      007665 EC               [12]  833 	mov	a,r4
      007666 F0               [24]  834 	movx	@dptr,a
      007667 ED               [12]  835 	mov	a,r5
      007668 12 7C 21         [24]  836 	lcall	_ak820_outline_0055
      00766B 12 55 06         [24]  837 	lcall	_ak820_outline_0112
      00766E 90 06 8C         [24]  838 	mov	dptr,#_ak820_tapping_source_PARM_1
      007671 F5 F0            [12]  839 	mov	b,a
      007673 C0 07            [24]  840 	push	ar7
      007675 C0 06            [24]  841 	push	ar6
      007677 12 BF 43         [24]  842 	lcall	___memcpy
      00767A 12 49 A4         [24]  843 	lcall	_ak820_tapping_source
      00767D AD 82            [24]  844 	mov	r5, dpl
      00767F D0 06            [24]  845 	pop	ar6
      007681 D0 07            [24]  846 	pop	ar7
                                    847 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007683 12 49 08         [24]  848 	lcall	_ak820_outline_0011
      007686 E0               [24]  849 	movx	a,@dptr
      007687 FC               [12]  850 	mov	r4,a
                                    851 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      007688 74 07            [12]  852 	mov	a,#0x07
      00768A 2E               [12]  853 	add	a, r6
      00768B FA               [12]  854 	mov	r2,a
      00768C E4               [12]  855 	clr	a
      00768D 3F               [12]  856 	addc	a, r7
      00768E FB               [12]  857 	mov	r3,a
      00768F 90 0C 77         [24]  858 	mov	dptr,#_get_record_keycode_PARM_2
      007692 74 01            [12]  859 	mov	a,#0x01
      007694 12 49 3E         [24]  860 	lcall	_ak820_outline_0063
      007697 C0 07            [24]  861 	push	ar7
      007699 C0 06            [24]  862 	push	ar6
      00769B C0 05            [24]  863 	push	ar5
      00769D C0 04            [24]  864 	push	ar4
      00769F C0 03            [24]  865 	push	ar3
      0076A1 C0 02            [24]  866 	push	ar2
      0076A3 12 A5 32         [24]  867 	lcall	_get_record_keycode
      0076A6 A8 82            [24]  868 	mov	r0, dpl
      0076A8 A9 83            [24]  869 	mov	r1, dph
      0076AA D0 02            [24]  870 	pop	ar2
      0076AC D0 03            [24]  871 	pop	ar3
      0076AE D0 04            [24]  872 	pop	ar4
      0076B0 D0 05            [24]  873 	pop	ar5
      0076B2 D0 06            [24]  874 	pop	ar6
      0076B4 D0 07            [24]  875 	pop	ar7
      0076B6 12 49 7F         [24]  876 	lcall	_ak820_outline_0148
      0076B9 12 55 12         [24]  877 	lcall	_ak820_outline_0168
                                    878 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0076BC 74 07            [12]  879 	mov	a,#0x07
      0076BE 12 37 D2         [24]  880 	lcall	_ak820_outline_0013
      0076C1 FA               [12]  881 	mov	r2,a
      0076C2 A3               [24]  882 	inc	dptr
      0076C3 E0               [24]  883 	movx	a,@dptr
      0076C4 FB               [12]  884 	mov	r3,a
      0076C5 90 06 9C         [24]  885 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0076C8 ED               [12]  886 	mov	a,r5
      0076C9 F0               [24]  887 	movx	@dptr,a
      0076CA 90 06 9D         [24]  888 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0076CD EC               [12]  889 	mov	a,r4
      0076CE F0               [24]  890 	movx	@dptr,a
      0076CF 12 49 7F         [24]  891 	lcall	_ak820_outline_0148
      0076D2 C0 07            [24]  892 	push	ar7
      0076D4 C0 06            [24]  893 	push	ar6
      0076D6 C0 05            [24]  894 	push	ar5
      0076D8 C0 04            [24]  895 	push	ar4
      0076DA 12 4C F6         [24]  896 	lcall	_ak820_oneshot_process
      0076DD E5 82            [12]  897 	mov	a, dpl
      0076DF D0 04            [24]  898 	pop	ar4
      0076E1 D0 05            [24]  899 	pop	ar5
      0076E3 D0 06            [24]  900 	pop	ar6
      0076E5 D0 07            [24]  901 	pop	ar7
      0076E7 70 01            [24]  902 	jnz	00104$
      0076E9 22               [24]  903 	ret
      0076EA                        904 00104$:
                                    905 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      0076EA 12 49 5D         [24]  906 	lcall	_ak820_outline_0120
      0076ED C0 07            [24]  907 	push	ar7
      0076EF C0 06            [24]  908 	push	ar6
      0076F1 C0 05            [24]  909 	push	ar5
      0076F3 C0 04            [24]  910 	push	ar4
      0076F5 12 A5 B3         [24]  911 	lcall	_process_record_quantum
      0076F8 E5 82            [12]  912 	mov	a, dpl
      0076FA D0 04            [24]  913 	pop	ar4
      0076FC D0 05            [24]  914 	pop	ar5
      0076FE D0 06            [24]  915 	pop	ar6
      007700 D0 07            [24]  916 	pop	ar7
      007702 70 0A            [24]  917 	jnz	00106$
                                    918 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007704 90 06 04         [24]  919 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007707 EC               [12]  920 	mov	a,r4
      007708 F0               [24]  921 	movx	@dptr,a
      007709 8D 82            [24]  922 	mov	dpl, r5
                                    923 ;	quantum/action.c:376: return;
      00770B 02 2E BB         [24]  924 	ljmp	_ak820_oneshot_post
      00770E                        925 00106$:
                                    926 ;	quantum/action.c:382: process_record_handler(record);
      00770E 12 49 5D         [24]  927 	lcall	_ak820_outline_0120
      007711 C0 05            [24]  928 	push	ar5
      007713 C0 04            [24]  929 	push	ar4
      007715 F1 25            [24]  930 	acall	_process_record_handler
      007717 D0 04            [24]  931 	pop	ar4
      007719 D0 05            [24]  932 	pop	ar5
                                    933 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00771B 90 06 04         [24]  934 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00771E EC               [12]  935 	mov	a,r4
      00771F F0               [24]  936 	movx	@dptr,a
      007720 8D 82            [24]  937 	mov	dpl, r5
                                    938 ;	quantum/action.c:392: }
      007722 02 2E BB         [24]  939 	ljmp	_ak820_oneshot_post
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'process_record_handler'
                                    942 ;------------------------------------------------------------
                                    943 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_650'
                                    944 ;record        Allocated with name '_process_record_handler_record_10000_651'
                                    945 ;action        Allocated with name '_process_record_handler_action_10000_651'
                                    946 ;------------------------------------------------------------
                                    947 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    948 ;	-----------------------------------------
                                    949 ;	 function process_record_handler
                                    950 ;	-----------------------------------------
      007725                        951 _process_record_handler:
      007725 12 38 44         [24]  952 	lcall	_ak820_outline_0109
      007728 90 08 91         [24]  953 	mov	dptr,#_process_record_handler_record_argument_10000_650
      00772B 12 38 49         [24]  954 	lcall	_ak820_outline_0110
                                    955 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00772E 90 08 91         [24]  956 	mov	dptr,#_process_record_handler_record_argument_10000_650
      007731 12 37 9D         [24]  957 	lcall	_ak820_outline_0001
                                    958 ;	quantum/action.c:405: if (record->keycode) {
      007734 4C               [12]  959 	orl	a,r4
      007735 60 19            [24]  960 	jz	00102$
                                    961 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      007737 12 38 54         [24]  962 	lcall	_ak820_outline_0128
      00773A C0 07            [24]  963 	push	ar7
      00773C C0 06            [24]  964 	push	ar6
      00773E 12 9B DB         [24]  965 	lcall	_action_for_keycode
      007741 12 49 84         [24]  966 	lcall	_ak820_outline_0155
      007744 D0 06            [24]  967 	pop	ar6
      007746 D0 07            [24]  968 	pop	ar7
      007748 90 08 93         [24]  969 	mov	dptr,#_process_record_handler_action_10000_651
      00774B 12 38 20         [24]  970 	lcall	_ak820_outline_0078
      00774E 80 2B            [24]  971 	sjmp	00104$
      007750                        972 00102$:
                                    973 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007750 12 7B FF         [24]  974 	lcall	_ak820_outline_0023
      007753 7A 00            [12]  975 	mov	r2,#0x00
      007755 12 49 79         [24]  976 	lcall	_ak820_outline_0147
      007758 12 49 08         [24]  977 	lcall	_ak820_outline_0011
      00775B E0               [24]  978 	movx	a,@dptr
      00775C 90 09 CE         [24]  979 	mov	dptr,#_ak820_resolve_key_PARM_2
      00775F F0               [24]  980 	movx	@dptr,a
      007760 8D 82            [24]  981 	mov	dpl, r5
      007762 8C 83            [24]  982 	mov	dph, r4
      007764 C0 07            [24]  983 	push	ar7
      007766 C0 06            [24]  984 	push	ar6
      007768 12 7F 82         [24]  985 	lcall	_ak820_resolve_key
      00776B 12 9B DB         [24]  986 	lcall	_action_for_keycode
      00776E 12 49 84         [24]  987 	lcall	_ak820_outline_0155
      007771 D0 06            [24]  988 	pop	ar6
      007773 D0 07            [24]  989 	pop	ar7
      007775 90 08 93         [24]  990 	mov	dptr,#_process_record_handler_action_10000_651
      007778 12 38 20         [24]  991 	lcall	_ak820_outline_0078
                                    992 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      00777B                        993 00104$:
                                    994 ;	quantum/action.c:429: process_action(record, action);
      00777B 90 0E 2F         [24]  995 	mov	dptr,#___memcpy_PARM_2
      00777E 74 93            [12]  996 	mov	a,#_process_record_handler_action_10000_651
      007780 F0               [24]  997 	movx	@dptr,a
      007781 74 08            [12]  998 	mov	a,#(_process_record_handler_action_10000_651 >> 8)
      007783 12 7C 21         [24]  999 	lcall	_ak820_outline_0055
      007786 12 55 06         [24] 1000 	lcall	_ak820_outline_0112
      007789 90 08 95         [24] 1001 	mov	dptr,#_process_action_PARM_2
      00778C F5 F0            [12] 1002 	mov	b,a
      00778E C0 07            [24] 1003 	push	ar7
      007790 C0 06            [24] 1004 	push	ar6
      007792 12 BF 43         [24] 1005 	lcall	___memcpy
      007795 D0 06            [24] 1006 	pop	ar6
      007797 D0 07            [24] 1007 	pop	ar7
      007799 12 49 5D         [24] 1008 	lcall	_ak820_outline_0120
                                   1009 ;	quantum/action.c:430: }
      00779C E1 9E            [24] 1010 	ajmp	_process_action
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'register_mouse'
                                   1013 ;------------------------------------------------------------
                                   1014 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1015 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_659'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function process_action
                                   1020 ;	-----------------------------------------
      00779E                       1021 _process_action:
      00779E 12 38 44         [24] 1022 	lcall	_ak820_outline_0109
      0077A1 90 08 97         [24] 1023 	mov	dptr,#_process_action_record_argument_10000_662
      0077A4 12 38 49         [24] 1024 	lcall	_ak820_outline_0110
                                   1025 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0077A7 90 08 97         [24] 1026 	mov	dptr,#_process_action_record_argument_10000_662
      0077AA 12 37 BE         [24] 1027 	lcall	_ak820_outline_0007
                                   1028 ;	quantum/action.c:501: pressed = record->event.pressed;
      0077AD 12 41 77         [24] 1029 	lcall	_ak820_outline_0156
      0077B0 F5 1F            [12] 1030 	mov	_process_action_sloc0_1_0,a
                                   1031 ;	quantum/action.c:525: switch (action.kind.id) {
      0077B2 90 08 96         [24] 1032 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077B5 E0               [24] 1033 	movx	a,@dptr
      0077B6 C4               [12] 1034 	swap	a
      0077B7 54 0F            [12] 1035 	anl	a,#0x0f
      0077B9 FD               [12] 1036 	mov  r5,a
      0077BA 24 F4            [12] 1037 	add	a,#0xff - 0x0b
      0077BC 50 03            [24] 1038 	jnc	00434$
      0077BE 02 7A 3C         [24] 1039 	ljmp	00181$
      0077C1                       1040 00434$:
                                   1041 ;	free result
      0077C1 ED               [12] 1042 	mov	a,r5
      0077C2 24 0A            [12] 1043 	add	a,#(00435$-3-.)
      0077C4 83               [24] 1044 	movc	a,@a+pc
      0077C5 F5 82            [12] 1045 	mov	dpl,a
      0077C7 ED               [12] 1046 	mov	a,r5
      0077C8 24 10            [12] 1047 	add	a,#(00436$-3-.)
      0077CA 83               [24] 1048 	movc	a,@a+pc
      0077CB F5 83            [12] 1049 	mov	dph,a
      0077CD E4               [12] 1050 	clr	a
      0077CE 73               [24] 1051 	jmp	@a+dptr
      0077CF                       1052 00435$:
      0077CF E7                    1053 	.db	00102$
      0077D0 E7                    1054 	.db	00102$
      0077D1 3C                    1055 	.db	00181$
      0077D2 3C                    1056 	.db	00181$
      0077D3 71                    1057 	.db	00123$
      0077D4 3C                    1058 	.db	00181$
      0077D5 3C                    1059 	.db	00181$
      0077D6 3C                    1060 	.db	00181$
      0077D7 D1                    1061 	.db	00131$
      0077D8 A3                    1062 	.db	00147$
      0077D9 C9                    1063 	.db	00152$
      0077DA C9                    1064 	.db	00152$
      0077DB                       1065 00436$:
      0077DB 77                    1066 	.db	00102$>>8
      0077DC 77                    1067 	.db	00102$>>8
      0077DD 7A                    1068 	.db	00181$>>8
      0077DE 7A                    1069 	.db	00181$>>8
      0077DF 78                    1070 	.db	00123$>>8
      0077E0 7A                    1071 	.db	00181$>>8
      0077E1 7A                    1072 	.db	00181$>>8
      0077E2 7A                    1073 	.db	00181$>>8
      0077E3 78                    1074 	.db	00131$>>8
      0077E4 79                    1075 	.db	00147$>>8
      0077E5 79                    1076 	.db	00152$>>8
      0077E6 79                    1077 	.db	00152$>>8
                                   1078 ;	quantum/action.c:528: case ACT_RMODS: {
      0077E7                       1079 00102$:
                                   1080 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0077E7 90 08 96         [24] 1081 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077EA E0               [24] 1082 	movx	a,@dptr
      0077EB 54 F0            [12] 1083 	anl	a,#0xf0
      0077ED 70 06            [24] 1084 	jnz	00194$
      0077EF 12 7C 41         [24] 1085 	lcall	_ak820_outline_0115
      0077F2 FD               [12] 1086 	mov	r5,a
      0077F3 80 07            [24] 1087 	sjmp	00195$
      0077F5                       1088 00194$:
      0077F5 12 7C 41         [24] 1089 	lcall	_ak820_outline_0115
      0077F8 C4               [12] 1090 	swap	a
      0077F9 54 F0            [12] 1091 	anl	a,#0xf0
      0077FB FD               [12] 1092 	mov	r5,a
      0077FC                       1093 00195$:
                                   1094 ;	quantum/action.c:531: if (pressed) {
      0077FC E5 1F            [12] 1095 	mov	a,_process_action_sloc0_1_0
      0077FE 60 35            [24] 1096 	jz	00119$
                                   1097 ;	quantum/action.c:532: if (mods) {
      007800 ED               [12] 1098 	mov	a,r5
      007801 60 29            [24] 1099 	jz	00110$
                                   1100 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007803 12 7C 53         [24] 1101 	lcall	_ak820_outline_0165
      007806 FC               [12] 1102 	mov	r4,a
      007807 BC E0 00         [24] 1103 	cjne	r4,#0xe0,00440$
      00780A                       1104 00440$:
      00780A 40 07            [24] 1105 	jc	00108$
      00780C 12 7C 53         [24] 1106 	lcall	_ak820_outline_0165
      00780F 24 18            [12] 1107 	add	a,#0xff - 0xe7
      007811 50 0A            [24] 1108 	jnc	00104$
                                   1109 ;	free result
      007813                       1110 00108$:
      007813 7B 95            [12] 1111 	mov	r3,#_process_action_PARM_2
      007815 7C 08            [12] 1112 	mov	r4,#(_process_action_PARM_2 >> 8)
      007817 12 33 FC         [24] 1113 	lcall	_ak820_outline_0127
      00781A E0               [24] 1114 	movx	a,@dptr
      00781B 70 07            [24] 1115 	jnz	00105$
      00781D                       1116 00104$:
                                   1117 ;	quantum/action.c:537: add_owned_mods(mods);
      00781D 8D 82            [24] 1118 	mov	dpl, r5
      00781F 12 81 A0         [24] 1119 	lcall	_add_owned_mods
      007822 80 05            [24] 1120 	sjmp	00106$
      007824                       1121 00105$:
                                   1122 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      007824 8D 82            [24] 1123 	mov	dpl, r5
      007826 12 81 BD         [24] 1124 	lcall	_add_owned_weak_mods
      007829                       1125 00106$:
                                   1126 ;	quantum/action.c:541: send_keyboard_report();
      007829 12 84 D2         [24] 1127 	lcall	_send_keyboard_report
      00782C                       1128 00110$:
                                   1129 ;	quantum/action.c:543: register_code(action.key.code);
      00782C 12 7C 2A         [24] 1130 	lcall	_ak820_outline_0077
      00782F 12 7A 53         [24] 1131 	lcall	_register_code
      007832 02 7A 3C         [24] 1132 	ljmp	00181$
      007835                       1133 00119$:
                                   1134 ;	quantum/action.c:545: unregister_code(action.key.code);
      007835 12 7C 2A         [24] 1135 	lcall	_ak820_outline_0077
      007838 C0 05            [24] 1136 	push	ar5
      00783A 12 7A BD         [24] 1137 	lcall	_unregister_code
      00783D D0 05            [24] 1138 	pop	ar5
                                   1139 ;	quantum/action.c:546: if (mods) {
      00783F ED               [12] 1140 	mov	a,r5
      007840 70 03            [24] 1141 	jnz	00444$
      007842 02 7A 3C         [24] 1142 	ljmp	00181$
      007845                       1143 00444$:
                                   1144 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007845 12 7C 53         [24] 1145 	lcall	_ak820_outline_0165
      007848 FC               [12] 1146 	mov	r4,a
      007849 BC E0 00         [24] 1147 	cjne	r4,#0xe0,00445$
      00784C                       1148 00445$:
      00784C 40 07            [24] 1149 	jc	00115$
      00784E 12 7C 53         [24] 1150 	lcall	_ak820_outline_0165
      007851 24 18            [12] 1151 	add	a,#0xff - 0xe7
      007853 50 0A            [24] 1152 	jnc	00111$
                                   1153 ;	free result
      007855                       1154 00115$:
      007855 7B 95            [12] 1155 	mov	r3,#_process_action_PARM_2
      007857 7C 08            [12] 1156 	mov	r4,#(_process_action_PARM_2 >> 8)
      007859 12 33 FC         [24] 1157 	lcall	_ak820_outline_0127
      00785C E0               [24] 1158 	movx	a,@dptr
      00785D 70 07            [24] 1159 	jnz	00112$
      00785F                       1160 00111$:
                                   1161 ;	quantum/action.c:548: del_owned_mods(mods);
      00785F 8D 82            [24] 1162 	mov	dpl, r5
      007861 12 81 AF         [24] 1163 	lcall	_del_owned_mods
      007864 80 05            [24] 1164 	sjmp	00113$
      007866                       1165 00112$:
                                   1166 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      007866 8D 82            [24] 1167 	mov	dpl, r5
      007868 12 81 CC         [24] 1168 	lcall	_del_owned_weak_mods
      00786B                       1169 00113$:
                                   1170 ;	quantum/action.c:552: send_keyboard_report();
      00786B 12 84 D2         [24] 1171 	lcall	_send_keyboard_report
                                   1172 ;	quantum/action.c:555: } break;
      00786E 02 7A 3C         [24] 1173 	ljmp	00181$
                                   1174 ;	quantum/action.c:632: case ACT_USAGE:
      007871                       1175 00123$:
                                   1176 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007871 74 07            [12] 1177 	mov	a,#0x07
      007873 12 37 ED         [24] 1178 	lcall	_ak820_outline_0033
      007876 12 37 C8         [24] 1179 	lcall	_ak820_outline_0009
      007879 C3               [12] 1180 	clr	c
      00787A EC               [12] 1181 	mov	a,r4
      00787B 94 A5            [12] 1182 	subb	a,#0xa5
      00787D ED               [12] 1183 	mov	a,r5
      00787E 94 00            [12] 1184 	subb	a,#0x00
      007880 40 15            [24] 1185 	jc	00125$
      007882 74 C2            [12] 1186 	mov	a,#0xc2
      007884 9C               [12] 1187 	subb	a,r4
      007885 E4               [12] 1188 	clr	a
      007886 9D               [12] 1189 	subb	a,r5
      007887 40 0E            [24] 1190 	jc	00125$
                                   1191 ;	free result
                                   1192 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      007889 90 0A F5         [24] 1193 	mov	dptr,#_owned_usage_key_PARM_2
      00788C E5 1F            [12] 1194 	mov	a,_process_action_sloc0_1_0
      00788E F0               [24] 1195 	movx	@dptr,a
      00788F 8E 82            [24] 1196 	mov	dpl, r6
      007891 12 83 7F         [24] 1197 	lcall	_owned_usage_key
                                   1198 ;	quantum/action.c:640: break;
      007894 02 7A 3C         [24] 1199 	ljmp	00181$
      007897                       1200 00125$:
                                   1201 ;	quantum/action.c:643: switch (action.usage.page) {
      007897 12 7C 31         [24] 1202 	lcall	_ak820_outline_0089
      00789A FF               [12] 1203 	mov	r7,a
      00789B 60 08            [24] 1204 	jz	00127$
      00789D BF 01 02         [24] 1205 	cjne	r7,#0x01,00452$
      0078A0 80 19            [24] 1206 	sjmp	00128$
      0078A2                       1207 00452$:
      0078A2 02 7A 3C         [24] 1208 	ljmp	00181$
                                   1209 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0078A5                       1210 00127$:
                                   1211 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0078A5 E5 1F            [12] 1212 	mov	a,_process_action_sloc0_1_0
      0078A7 60 05            [24] 1213 	jz	00196$
      0078A9 12 7C 48         [24] 1214 	lcall	_ak820_outline_0136
      0078AC 80 04            [24] 1215 	sjmp	00197$
      0078AE                       1216 00196$:
      0078AE 7E 00            [12] 1217 	mov	r6,#0x00
      0078B0 7F 00            [12] 1218 	mov	r7,#0x00
      0078B2                       1219 00197$:
      0078B2 12 49 5D         [24] 1220 	lcall	_ak820_outline_0120
      0078B5 12 72 A5         [24] 1221 	lcall	_host_system_send
                                   1222 ;	quantum/action.c:646: break;
      0078B8 02 7A 3C         [24] 1223 	ljmp	00181$
                                   1224 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0078BB                       1225 00128$:
                                   1226 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0078BB E5 1F            [12] 1227 	mov	a,_process_action_sloc0_1_0
      0078BD 60 05            [24] 1228 	jz	00198$
      0078BF 12 7C 48         [24] 1229 	lcall	_ak820_outline_0136
      0078C2 80 04            [24] 1230 	sjmp	00199$
      0078C4                       1231 00198$:
      0078C4 7E 00            [12] 1232 	mov	r6,#0x00
      0078C6 7F 00            [12] 1233 	mov	r7,#0x00
      0078C8                       1234 00199$:
      0078C8 12 49 5D         [24] 1235 	lcall	_ak820_outline_0120
      0078CB 12 72 D4         [24] 1236 	lcall	_host_consumer_send
                                   1237 ;	quantum/action.c:651: break;
      0078CE 02 7A 3C         [24] 1238 	ljmp	00181$
                                   1239 ;	quantum/action.c:658: case ACT_LAYER: {
      0078D1                       1240 00131$:
                                   1241 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0078D1 90 08 96         [24] 1242 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078D4 E0               [24] 1243 	movx	a,@dptr
      0078D5 54 03            [12] 1244 	anl	a,#0x03
      0078D7 90 08 99         [24] 1245 	mov	dptr,#_process_action_on_40000_685
      0078DA F0               [24] 1246 	movx	@dptr,a
                                   1247 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0078DB E0               [24] 1248 	movx	a,@dptr
      0078DC FF               [12] 1249 	mov	r7,a
      0078DD 60 11            [24] 1250 	jz	00200$
      0078DF E5 1F            [12] 1251 	mov	a,_process_action_sloc0_1_0
      0078E1 60 07            [24] 1252 	jz	00202$
      0078E3 8F 06            [24] 1253 	mov	ar6,r7
      0078E5 53 06 01         [24] 1254 	anl	ar6,#0x01
      0078E8 80 10            [24] 1255 	sjmp	00201$
      0078EA                       1256 00202$:
      0078EA 74 02            [12] 1257 	mov	a,#0x02
      0078EC 5F               [12] 1258 	anl	a,r7
      0078ED FE               [12] 1259 	mov	r6,a
      0078EE 80 0A            [24] 1260 	sjmp	00201$
      0078F0                       1261 00200$:
      0078F0 E5 1F            [12] 1262 	mov	a,_process_action_sloc0_1_0
      0078F2 B4 01 00         [24] 1263 	cjne	a,#0x01,00457$
      0078F5                       1264 00457$:
      0078F5 92 20            [24] 1265 	mov  _process_action_sloc1_1_0,c
      0078F7 E4               [12] 1266 	clr	a
      0078F8 33               [12] 1267 	rlc	a
      0078F9 FE               [12] 1268 	mov	r6,a
      0078FA                       1269 00201$:
      0078FA EE               [12] 1270 	mov	a,r6
      0078FB 70 03            [24] 1271 	jnz	00458$
      0078FD 02 7A 3C         [24] 1272 	ljmp	00181$
      007900                       1273 00458$:
                                   1274 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007900 12 7C 53         [24] 1275 	lcall	_ak820_outline_0165
      007903 C4               [12] 1276 	swap	a
      007904 03               [12] 1277 	rr	a
      007905 54 07            [12] 1278 	anl	a,#0x07
      007907 25 E0            [12] 1279 	add	a,acc
      007909 25 E0            [12] 1280 	add	a,acc
      00790B FF               [12] 1281 	mov	r7,a
                                   1282 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00790C 12 7C 53         [24] 1283 	lcall	_ak820_outline_0165
      00790F 54 0F            [12] 1284 	anl	a,#0x0f
      007911 FE               [12] 1285 	mov	r6,a
      007912 8F F0            [24] 1286 	mov	b,r7
      007914 05 F0            [12] 1287 	inc	b
      007916 EE               [12] 1288 	mov	a,r6
      007917 80 02            [24] 1289 	sjmp	00460$
      007919                       1290 00459$:
      007919 25 E0            [12] 1291 	add	a,acc
      00791B                       1292 00460$:
      00791B D5 F0 FB         [24] 1293 	djnz	b,00459$
      00791E FE               [12] 1294 	mov	r6,a
                                   1295 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00791F 12 7C 53         [24] 1296 	lcall	_ak820_outline_0165
      007922 30 E4 11         [24] 1297 	jnb	acc.4,00204$
      007925 8F F0            [24] 1298 	mov	b,r7
      007927 05 F0            [12] 1299 	inc	b
      007929 74 0F            [12] 1300 	mov	a,#0x0f
      00792B 80 02            [24] 1301 	sjmp	00463$
      00792D                       1302 00462$:
      00792D 25 E0            [12] 1303 	add	a,acc
      00792F                       1304 00463$:
      00792F D5 F0 FB         [24] 1305 	djnz	b,00462$
      007932 F4               [12] 1306 	cpl	a
      007933 FF               [12] 1307 	mov	r7,a
      007934 80 02            [24] 1308 	sjmp	00205$
      007936                       1309 00204$:
      007936 7F 00            [12] 1310 	mov	r7,#0x00
      007938                       1311 00205$:
                                   1312 ;	quantum/action.c:666: bits |= mask;
      007938 EE               [12] 1313 	mov	a,r6
      007939 42 07            [12] 1314 	orl	ar7,a
                                   1315 ;	quantum/action.c:667: if (!on) {
      00793B 90 08 99         [24] 1316 	mov	dptr,#_process_action_on_40000_685
      00793E E0               [24] 1317 	movx	a,@dptr
      00793F 70 31            [24] 1318 	jnz	00143$
                                   1319 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007941 12 7C 31         [24] 1320 	lcall	_ak820_outline_0089
      007944 FE               [12] 1321 	mov	r6,a
      007945 2E               [12] 1322 	add	a,r6
                                   1323 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      007946 90 79 4A         [24] 1324 	mov	dptr,#00465$
      007949 73               [24] 1325 	jmp	@a+dptr
      00794A                       1326 00465$:
      00794A 80 06            [24] 1327 	sjmp	00132$
      00794C 80 0C            [24] 1328 	sjmp	00133$
      00794E 80 12            [24] 1329 	sjmp	00134$
      007950 80 18            [24] 1330 	sjmp	00135$
      007952                       1331 00132$:
      007952 8F 82            [24] 1332 	mov	dpl, r7
      007954 12 7C A9         [24] 1333 	lcall	_default_layer_and
      007957 02 7A 3C         [24] 1334 	ljmp	00181$
                                   1335 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      00795A                       1336 00133$:
      00795A 8F 82            [24] 1337 	mov	dpl, r7
      00795C 12 7C 99         [24] 1338 	lcall	_default_layer_or
      00795F 02 7A 3C         [24] 1339 	ljmp	00181$
                                   1340 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007962                       1341 00134$:
      007962 8F 82            [24] 1342 	mov	dpl, r7
      007964 12 7C BE         [24] 1343 	lcall	_default_layer_xor
      007967 02 7A 3C         [24] 1344 	ljmp	00181$
                                   1345 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      00796A                       1346 00135$:
      00796A 8F 82            [24] 1347 	mov	dpl, r7
      00796C 12 7C 8F         [24] 1348 	lcall	_default_layer_set
                                   1349 ;	quantum/action.c:673: }
      00796F 02 7A 3C         [24] 1350 	ljmp	00181$
      007972                       1351 00143$:
                                   1352 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007972 12 7C 31         [24] 1353 	lcall	_ak820_outline_0089
      007975 FE               [12] 1354 	mov	r6,a
      007976 2E               [12] 1355 	add	a,r6
                                   1356 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      007977 90 79 7B         [24] 1357 	mov	dptr,#00466$
      00797A 73               [24] 1358 	jmp	@a+dptr
      00797B                       1359 00466$:
      00797B 80 06            [24] 1360 	sjmp	00137$
      00797D 80 0C            [24] 1361 	sjmp	00138$
      00797F 80 12            [24] 1362 	sjmp	00139$
      007981 80 18            [24] 1363 	sjmp	00140$
      007983                       1364 00137$:
      007983 8F 82            [24] 1365 	mov	dpl, r7
      007985 12 7E 2F         [24] 1366 	lcall	_layer_and
      007988 02 7A 3C         [24] 1367 	ljmp	00181$
                                   1368 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      00798B                       1369 00138$:
      00798B 8F 82            [24] 1370 	mov	dpl, r7
      00798D 12 7E 1F         [24] 1371 	lcall	_layer_or
      007990 02 7A 3C         [24] 1372 	ljmp	00181$
                                   1373 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007993                       1374 00139$:
      007993 8F 82            [24] 1375 	mov	dpl, r7
      007995 12 7E 44         [24] 1376 	lcall	_layer_xor
      007998 02 7A 3C         [24] 1377 	ljmp	00181$
                                   1378 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      00799B                       1379 00140$:
      00799B 8F 82            [24] 1380 	mov	dpl, r7
      00799D 12 7D C7         [24] 1381 	lcall	_layer_state_set
                                   1382 ;	quantum/action.c:683: break;
      0079A0 02 7A 3C         [24] 1383 	ljmp	00181$
                                   1384 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0079A3                       1385 00147$:
                                   1386 ;	quantum/action.c:686: if (pressed) {
      0079A3 E5 1F            [12] 1387 	mov	a,_process_action_sloc0_1_0
      0079A5 60 11            [24] 1388 	jz	00149$
                                   1389 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0079A7 12 7C 41         [24] 1390 	lcall	_ak820_outline_0115
      0079AA F5 82            [12] 1391 	mov	dpl,a
      0079AC 12 7D 2C         [24] 1392 	lcall	_layer_hold_on
                                   1393 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0079AF 12 7C 2A         [24] 1394 	lcall	_ak820_outline_0077
      0079B2 12 7B 6D         [24] 1395 	lcall	_register_mods
      0079B5 02 7A 3C         [24] 1396 	ljmp	00181$
      0079B8                       1397 00149$:
                                   1398 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0079B8 12 7C 2A         [24] 1399 	lcall	_ak820_outline_0077
      0079BB 12 7B 81         [24] 1400 	lcall	_unregister_mods
                                   1401 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0079BE 12 7C 41         [24] 1402 	lcall	_ak820_outline_0115
      0079C1 F5 82            [12] 1403 	mov	dpl,a
      0079C3 12 7D 63         [24] 1404 	lcall	_layer_hold_off
                                   1405 ;	quantum/action.c:693: break;
      0079C6 02 7A 3C         [24] 1406 	ljmp	00181$
                                   1407 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0079C9                       1408 00152$:
                                   1409 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0079C9 12 7C 53         [24] 1410 	lcall	_ak820_outline_0165
      0079CC FF               [12] 1411 	mov	r7,a
      0079CD BF F1 02         [24] 1412 	cjne	r7,#0xf1,00468$
      0079D0 80 0A            [24] 1413 	sjmp	00154$
      0079D2                       1414 00468$:
      0079D2 BF F2 02         [24] 1415 	cjne	r7,#0xf2,00469$
      0079D5 80 19            [24] 1416 	sjmp	00155$
      0079D7                       1417 00469$:
                                   1418 ;	quantum/action.c:712: momentary_layer_action:
      0079D7 BF F3 3B         [24] 1419 	cjne	r7,#0xf3,00160$
      0079DA 80 28            [24] 1420 	sjmp	00156$
      0079DC                       1421 00154$:
                                   1422 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0079DC E5 1F            [12] 1423 	mov	a,_process_action_sloc0_1_0
      0079DE 60 08            [24] 1424 	jz	00206$
      0079E0 12 7C 18         [24] 1425 	lcall	_ak820_outline_0044
      0079E3 12 7D 2C         [24] 1426 	lcall	_layer_hold_on
      0079E6 80 54            [24] 1427 	sjmp	00181$
      0079E8                       1428 00206$:
      0079E8 12 7C 18         [24] 1429 	lcall	_ak820_outline_0044
      0079EB 12 7D 63         [24] 1430 	lcall	_layer_hold_off
                                   1431 ;	quantum/action.c:714: break;
                                   1432 ;	quantum/action.c:715: case OP_OFF_ON:
      0079EE 80 4C            [24] 1433 	sjmp	00181$
      0079F0                       1434 00155$:
                                   1435 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0079F0 E5 1F            [12] 1436 	mov	a,_process_action_sloc0_1_0
      0079F2 60 08            [24] 1437 	jz	00208$
      0079F4 12 7C 18         [24] 1438 	lcall	_ak820_outline_0044
      0079F7 12 7E 04         [24] 1439 	lcall	_layer_off
      0079FA 80 40            [24] 1440 	sjmp	00181$
      0079FC                       1441 00208$:
      0079FC 12 7C 18         [24] 1442 	lcall	_ak820_outline_0044
      0079FF 12 7D EC         [24] 1443 	lcall	_layer_on
                                   1444 ;	quantum/action.c:717: break;
                                   1445 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007A02 80 38            [24] 1446 	sjmp	00181$
      007A04                       1447 00156$:
                                   1448 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007A04 E5 1F            [12] 1449 	mov	a,_process_action_sloc0_1_0
      007A06 60 08            [24] 1450 	jz	00210$
      007A08 12 7C 18         [24] 1451 	lcall	_ak820_outline_0044
      007A0B 12 7D D9         [24] 1452 	lcall	_layer_move
      007A0E 80 2C            [24] 1453 	sjmp	00181$
      007A10                       1454 00210$:
      007A10 12 7D D4         [24] 1455 	lcall	_layer_clear
                                   1456 ;	quantum/action.c:720: break;
                                   1457 ;	quantum/action.c:766: default:
      007A13 80 27            [24] 1458 	sjmp	00181$
      007A15                       1459 00160$:
                                   1460 ;	quantum/action.c:773: if (pressed) {
      007A15 E5 1F            [12] 1461 	mov	a,_process_action_sloc0_1_0
      007A17 60 08            [24] 1462 	jz	00163$
                                   1463 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007A19 12 7C 2A         [24] 1464 	lcall	_ak820_outline_0077
      007A1C 12 7A 53         [24] 1465 	lcall	_register_code
                                   1466 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007A1F 80 1B            [24] 1467 	sjmp	00181$
      007A21                       1468 00163$:
                                   1469 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007A21 12 7C 53         [24] 1470 	lcall	_ak820_outline_0165
      007A24 FF               [12] 1471 	mov	r7,a
      007A25 BF 39 0E         [24] 1472 	cjne	r7,#0x39,00175$
                                   1473 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007A28 7F 50            [12] 1474 	mov	r7,#0x50
      007A2A                       1475 00187$:
      007A2A EF               [12] 1476 	mov	a,r7
      007A2B 60 09            [24] 1477 	jz	00175$
      007A2D 90 00 01         [24] 1478 	mov	dptr,#0x0001
      007A30 12 5E 7F         [24] 1479 	lcall	_mDelaymS
      007A33 1F               [12] 1480 	dec	r7
                                   1481 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      007A34 80 F4            [24] 1482 	sjmp	00187$
      007A36                       1483 00175$:
                                   1484 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      007A36 12 7C 2A         [24] 1485 	lcall	_ak820_outline_0077
      007A39 12 7A BD         [24] 1486 	lcall	_unregister_code
                                   1487 ;	quantum/action.c:866: }
      007A3C                       1488 00181$:
                                   1489 ;	quantum/action.c:887: switch (action.kind.id) {
      007A3C 90 08 96         [24] 1490 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007A3F E0               [24] 1491 	movx	a,@dptr
      007A40 C4               [12] 1492 	swap	a
      007A41 54 0F            [12] 1493 	anl	a,#0x0f
      007A43 FF               [12] 1494 	mov	r7,a
      007A44 BF 08 02         [24] 1495 	cjne	r7,#0x08,00478$
      007A47 80 03            [24] 1496 	sjmp	00183$
      007A49                       1497 00478$:
      007A49 BF 09 06         [24] 1498 	cjne	r7,#0x09,00192$
                                   1499 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007A4C                       1500 00183$:
                                   1501 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007A4C 12 72 0A         [24] 1502 	lcall	_host_keyboard_leds
                                   1503 ;	quantum/action.c:898: }
                                   1504 ;	quantum/action.c:951: }
      007A4F 02 9E 91         [24] 1505 	ljmp	_led_set
      007A52                       1506 00192$:
      007A52 22               [24] 1507 	ret
                                   1508 ;------------------------------------------------------------
                                   1509 ;Allocation info for local variables in function 'register_code'
                                   1510 ;------------------------------------------------------------
                                   1511 ;code          Allocated with name '_register_code_code_10000_719'
                                   1512 ;------------------------------------------------------------
                                   1513 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1514 ;	-----------------------------------------
                                   1515 ;	 function register_code
                                   1516 ;	-----------------------------------------
      007A53                       1517 _register_code:
      007A53 E5 82            [12] 1518 	mov	a,dpl
      007A55 90 08 9A         [24] 1519 	mov	dptr,#_register_code_code_10000_719
      007A58 F0               [24] 1520 	movx	@dptr,a
                                   1521 ;	quantum/action.c:958: if (code == KC_NO) {
      007A59 E0               [24] 1522 	movx	a,@dptr
      007A5A FF               [12] 1523 	mov	r7,a
      007A5B 70 01            [24] 1524 	jnz	00123$
                                   1525 ;	quantum/action.c:959: return;
      007A5D 22               [24] 1526 	ret
      007A5E                       1527 00123$:
                                   1528 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007A5E BF 04 00         [24] 1529 	cjne	r7,#0x04,00186$
      007A61                       1530 00186$:
      007A61 40 12            [24] 1531 	jc	00119$
      007A63 EF               [12] 1532 	mov	a,r7
      007A64 24 5B            [12] 1533 	add	a,#0xff - 0xa4
      007A66 40 0D            [24] 1534 	jc	00119$
                                   1535 ;	free result
                                   1536 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      007A68 8F 82            [24] 1537 	mov	dpl, r7
      007A6A 12 82 40         [24] 1538 	lcall	_add_owned_key
      007A6D E5 82            [12] 1539 	mov	a, dpl
      007A6F 70 01            [24] 1540 	jnz	00104$
      007A71 22               [24] 1541 	ret
      007A72                       1542 00104$:
                                   1543 ;	quantum/action.c:1013: send_keyboard_report();
      007A72 02 84 D2         [24] 1544 	ljmp	_send_keyboard_report
      007A75                       1545 00119$:
                                   1546 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A75 12 7C 58         [24] 1547 	lcall	_ak820_outline_0175
      007A78 BF E0 00         [24] 1548 	cjne	r7,#0xe0,00190$
      007A7B                       1549 00190$:
      007A7B 40 17            [24] 1550 	jc	00115$
      007A7D EF               [12] 1551 	mov	a,r7
      007A7E 24 18            [12] 1552 	add	a,#0xff - 0xe7
      007A80 40 12            [24] 1553 	jc	00115$
                                   1554 ;	free result
                                   1555 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007A82 12 7C 0E         [24] 1556 	lcall	_ak820_outline_0042
      007A85 80 02            [24] 1557 	sjmp	00194$
      007A87                       1558 00193$:
      007A87 25 E0            [12] 1559 	add	a,acc
      007A89                       1560 00194$:
      007A89 D5 F0 FB         [24] 1561 	djnz	b,00193$
      007A8C F5 82            [12] 1562 	mov	dpl,a
      007A8E 12 81 A0         [24] 1563 	lcall	_add_owned_mods
                                   1564 ;	quantum/action.c:1016: send_keyboard_report();
      007A91 02 84 D2         [24] 1565 	ljmp	_send_keyboard_report
      007A94                       1566 00115$:
                                   1567 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A94 12 7C 58         [24] 1568 	lcall	_ak820_outline_0175
      007A97 BF A5 00         [24] 1569 	cjne	r7,#0xa5,00195$
      007A9A                       1570 00195$:
      007A9A 40 05            [24] 1571 	jc	00113$
      007A9C EF               [12] 1572 	mov	a,r7
      007A9D 24 58            [12] 1573 	add	a,#0xff - 0xa7
      007A9F 50 0D            [24] 1574 	jnc	00108$
                                   1575 ;	free result
      007AA1                       1576 00113$:
      007AA1 12 7C 58         [24] 1577 	lcall	_ak820_outline_0175
      007AA4 BF A8 00         [24] 1578 	cjne	r7,#0xa8,00198$
      007AA7                       1579 00198$:
      007AA7 40 13            [24] 1580 	jc	00125$
      007AA9 EF               [12] 1581 	mov	a,r7
      007AAA 24 3D            [12] 1582 	add	a,#0xff - 0xc2
      007AAC 40 0E            [24] 1583 	jc	00125$
                                   1584 ;	free result
      007AAE                       1585 00108$:
                                   1586 ;	quantum/action.c:1021: owned_usage_key(code, true);
      007AAE 12 7C 58         [24] 1587 	lcall	_ak820_outline_0175
      007AB1 90 0A F5         [24] 1588 	mov	dptr,#_owned_usage_key_PARM_2
      007AB4 74 01            [12] 1589 	mov	a,#0x01
      007AB6 F0               [24] 1590 	movx	@dptr,a
      007AB7 8F 82            [24] 1591 	mov	dpl, r7
                                   1592 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1593 ;	quantum/action.c:1031: }
      007AB9 02 83 7F         [24] 1594 	ljmp	_owned_usage_key
      007ABC                       1595 00125$:
      007ABC 22               [24] 1596 	ret
                                   1597 ;------------------------------------------------------------
                                   1598 ;Allocation info for local variables in function 'unregister_code'
                                   1599 ;------------------------------------------------------------
                                   1600 ;code          Allocated with name '_unregister_code_code_10000_733'
                                   1601 ;------------------------------------------------------------
                                   1602 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1603 ;	-----------------------------------------
                                   1604 ;	 function unregister_code
                                   1605 ;	-----------------------------------------
      007ABD                       1606 _unregister_code:
      007ABD E5 82            [12] 1607 	mov	a,dpl
      007ABF 90 08 9B         [24] 1608 	mov	dptr,#_unregister_code_code_10000_733
      007AC2 F0               [24] 1609 	movx	@dptr,a
                                   1610 ;	quantum/action.c:1038: if (code == KC_NO) {
      007AC3 E0               [24] 1611 	movx	a,@dptr
      007AC4 FF               [12] 1612 	mov	r7,a
      007AC5 70 01            [24] 1613 	jnz	00121$
                                   1614 ;	quantum/action.c:1039: return;
      007AC7 22               [24] 1615 	ret
      007AC8                       1616 00121$:
                                   1617 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007AC8 BF 04 00         [24] 1618 	cjne	r7,#0x04,00184$
      007ACB                       1619 00184$:
      007ACB 40 12            [24] 1620 	jc	00117$
      007ACD EF               [12] 1621 	mov	a,r7
      007ACE 24 5B            [12] 1622 	add	a,#0xff - 0xa4
      007AD0 40 0D            [24] 1623 	jc	00117$
                                   1624 ;	free result
                                   1625 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      007AD2 8F 82            [24] 1626 	mov	dpl, r7
      007AD4 12 82 B9         [24] 1627 	lcall	_del_owned_key
      007AD7 E5 82            [12] 1628 	mov	a, dpl
      007AD9 70 01            [24] 1629 	jnz	00102$
      007ADB 22               [24] 1630 	ret
      007ADC                       1631 00102$:
                                   1632 ;	quantum/action.c:1080: send_keyboard_report();
      007ADC 02 84 D2         [24] 1633 	ljmp	_send_keyboard_report
      007ADF                       1634 00117$:
                                   1635 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007ADF 12 7C 5E         [24] 1636 	lcall	_ak820_outline_0176
      007AE2 BF E0 00         [24] 1637 	cjne	r7,#0xe0,00188$
      007AE5                       1638 00188$:
      007AE5 40 17            [24] 1639 	jc	00113$
      007AE7 EF               [12] 1640 	mov	a,r7
      007AE8 24 18            [12] 1641 	add	a,#0xff - 0xe7
      007AEA 40 12            [24] 1642 	jc	00113$
                                   1643 ;	free result
                                   1644 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007AEC 12 7C 0E         [24] 1645 	lcall	_ak820_outline_0042
      007AEF 80 02            [24] 1646 	sjmp	00192$
      007AF1                       1647 00191$:
      007AF1 25 E0            [12] 1648 	add	a,acc
      007AF3                       1649 00192$:
      007AF3 D5 F0 FB         [24] 1650 	djnz	b,00191$
      007AF6 F5 82            [12] 1651 	mov	dpl,a
      007AF8 12 81 AF         [24] 1652 	lcall	_del_owned_mods
                                   1653 ;	quantum/action.c:1083: send_keyboard_report();
      007AFB 02 84 D2         [24] 1654 	ljmp	_send_keyboard_report
      007AFE                       1655 00113$:
                                   1656 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007AFE 12 7C 5E         [24] 1657 	lcall	_ak820_outline_0176
      007B01 BF A5 00         [24] 1658 	cjne	r7,#0xa5,00193$
      007B04                       1659 00193$:
      007B04 40 05            [24] 1660 	jc	00111$
      007B06 EF               [12] 1661 	mov	a,r7
      007B07 24 58            [12] 1662 	add	a,#0xff - 0xa7
      007B09 50 0D            [24] 1663 	jnc	00106$
                                   1664 ;	free result
      007B0B                       1665 00111$:
      007B0B 12 7C 5E         [24] 1666 	lcall	_ak820_outline_0176
      007B0E BF A8 00         [24] 1667 	cjne	r7,#0xa8,00196$
      007B11                       1668 00196$:
      007B11 40 12            [24] 1669 	jc	00123$
      007B13 EF               [12] 1670 	mov	a,r7
      007B14 24 3D            [12] 1671 	add	a,#0xff - 0xc2
      007B16 40 0D            [24] 1672 	jc	00123$
                                   1673 ;	free result
      007B18                       1674 00106$:
                                   1675 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007B18 12 7C 5E         [24] 1676 	lcall	_ak820_outline_0176
      007B1B 90 0A F5         [24] 1677 	mov	dptr,#_owned_usage_key_PARM_2
      007B1E E4               [12] 1678 	clr	a
      007B1F F0               [24] 1679 	movx	@dptr,a
      007B20 8F 82            [24] 1680 	mov	dpl, r7
                                   1681 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1682 ;	quantum/action.c:1098: }
      007B22 02 83 7F         [24] 1683 	ljmp	_owned_usage_key
      007B25                       1684 00123$:
      007B25 22               [24] 1685 	ret
                                   1686 ;------------------------------------------------------------
                                   1687 ;Allocation info for local variables in function 'tap_code_delay'
                                   1688 ;------------------------------------------------------------
                                   1689 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1690 ;code          Allocated with name '_tap_code_delay_code_10000_746'
                                   1691 ;i             Allocated with name '_tap_code_delay_i_20000_748'
                                   1692 ;i             Allocated with name '_tap_code_delay_i_50000_751'
                                   1693 ;------------------------------------------------------------
                                   1694 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1695 ;	-----------------------------------------
                                   1696 ;	 function tap_code_delay
                                   1697 ;	-----------------------------------------
      007B26                       1698 _tap_code_delay:
      007B26 E5 82            [12] 1699 	mov	a,dpl
      007B28 90 08 9E         [24] 1700 	mov	dptr,#_tap_code_delay_code_10000_746
      007B2B F0               [24] 1701 	movx	@dptr,a
                                   1702 ;	quantum/action.c:1106: register_code(code);
      007B2C E0               [24] 1703 	movx	a,@dptr
      007B2D FF               [12] 1704 	mov	r7,a
      007B2E F5 82            [12] 1705 	mov	dpl,a
      007B30 C0 07            [24] 1706 	push	ar7
      007B32 51 53            [12] 1707 	acall	_register_code
      007B34 D0 07            [24] 1708 	pop	ar7
                                   1709 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007B36 90 08 9C         [24] 1710 	mov	dptr,#_tap_code_delay_PARM_2
      007B39 12 38 26         [24] 1711 	lcall	_ak820_outline_0081
      007B3C                       1712 00110$:
      007B3C ED               [12] 1713 	mov	a,r5
      007B3D 4E               [12] 1714 	orl	a,r6
      007B3E 60 0D            [24] 1715 	jz	00105$
                                   1716 ;	quantum/action.c:1108: wait_ms(1);
      007B40 90 00 01         [24] 1717 	mov	dptr,#0x0001
      007B43 12 5E 7F         [24] 1718 	lcall	_mDelaymS
                                   1719 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007B46 1D               [12] 1720 	dec	r5
      007B47 BD FF 01         [24] 1721 	cjne	r5,#0xff,00141$
      007B4A 1E               [12] 1722 	dec	r6
      007B4B                       1723 00141$:
      007B4B 80 EF            [24] 1724 	sjmp	00110$
      007B4D                       1725 00105$:
                                   1726 ;	quantum/action.c:1110: unregister_code(code);
      007B4D 8F 82            [24] 1727 	mov	dpl, r7
                                   1728 ;	quantum/action.c:1111: }
      007B4F 41 BD            [12] 1729 	ajmp	_unregister_code
                                   1730 ;------------------------------------------------------------
                                   1731 ;Allocation info for local variables in function 'tap_code'
                                   1732 ;------------------------------------------------------------
                                   1733 ;code          Allocated with name '_tap_code_code_10000_753'
                                   1734 ;------------------------------------------------------------
                                   1735 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1736 ;	-----------------------------------------
                                   1737 ;	 function tap_code
                                   1738 ;	-----------------------------------------
      007B51                       1739 _tap_code:
      007B51 E5 82            [12] 1740 	mov	a,dpl
      007B53 90 08 9F         [24] 1741 	mov	dptr,#_tap_code_code_10000_753
      007B56 F0               [24] 1742 	movx	@dptr,a
                                   1743 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007B57 E0               [24] 1744 	movx	a,@dptr
      007B58 FF               [12] 1745 	mov	r7,a
      007B59 BF 39 04         [24] 1746 	cjne	r7,#0x39,00103$
      007B5C 7E 50            [12] 1747 	mov	r6,#0x50
      007B5E 80 02            [24] 1748 	sjmp	00104$
      007B60                       1749 00103$:
      007B60 7E 00            [12] 1750 	mov	r6,#0x00
      007B62                       1751 00104$:
      007B62 90 08 9C         [24] 1752 	mov	dptr,#_tap_code_delay_PARM_2
      007B65 EE               [12] 1753 	mov	a,r6
      007B66 12 38 59         [24] 1754 	lcall	_ak820_outline_0129
      007B69 8F 82            [24] 1755 	mov	dpl, r7
                                   1756 ;	quantum/action.c:1119: }
      007B6B 61 26            [12] 1757 	ajmp	_tap_code_delay
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'register_mods'
                                   1760 ;------------------------------------------------------------
                                   1761 ;mods          Allocated with name '_register_mods_mods_10000_755'
                                   1762 ;------------------------------------------------------------
                                   1763 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1764 ;	-----------------------------------------
                                   1765 ;	 function register_mods
                                   1766 ;	-----------------------------------------
      007B6D                       1767 _register_mods:
      007B6D E5 82            [12] 1768 	mov	a,dpl
      007B6F 90 08 A0         [24] 1769 	mov	dptr,#_register_mods_mods_10000_755
      007B72 F0               [24] 1770 	movx	@dptr,a
                                   1771 ;	quantum/action.c:1126: if (mods) {
      007B73 E0               [24] 1772 	movx	a,@dptr
      007B74 FF               [12] 1773 	mov	r7,a
      007B75 E0               [24] 1774 	movx	a,@dptr
      007B76 60 08            [24] 1775 	jz	00103$
                                   1776 ;	quantum/action.c:1127: add_owned_mods(mods);
      007B78 8F 82            [24] 1777 	mov	dpl, r7
      007B7A 12 81 A0         [24] 1778 	lcall	_add_owned_mods
                                   1779 ;	quantum/action.c:1128: send_keyboard_report();
                                   1780 ;	quantum/action.c:1130: }
      007B7D 02 84 D2         [24] 1781 	ljmp	_send_keyboard_report
      007B80                       1782 00103$:
      007B80 22               [24] 1783 	ret
                                   1784 ;------------------------------------------------------------
                                   1785 ;Allocation info for local variables in function 'unregister_mods'
                                   1786 ;------------------------------------------------------------
                                   1787 ;mods          Allocated with name '_unregister_mods_mods_10000_759'
                                   1788 ;------------------------------------------------------------
                                   1789 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1790 ;	-----------------------------------------
                                   1791 ;	 function unregister_mods
                                   1792 ;	-----------------------------------------
      007B81                       1793 _unregister_mods:
      007B81 E5 82            [12] 1794 	mov	a,dpl
      007B83 90 08 A1         [24] 1795 	mov	dptr,#_unregister_mods_mods_10000_759
      007B86 F0               [24] 1796 	movx	@dptr,a
                                   1797 ;	quantum/action.c:1137: if (mods) {
      007B87 E0               [24] 1798 	movx	a,@dptr
      007B88 FF               [12] 1799 	mov	r7,a
      007B89 E0               [24] 1800 	movx	a,@dptr
      007B8A 60 08            [24] 1801 	jz	00103$
                                   1802 ;	quantum/action.c:1138: del_owned_mods(mods);
      007B8C 8F 82            [24] 1803 	mov	dpl, r7
      007B8E 12 81 AF         [24] 1804 	lcall	_del_owned_mods
                                   1805 ;	quantum/action.c:1139: send_keyboard_report();
                                   1806 ;	quantum/action.c:1141: }
      007B91 02 84 D2         [24] 1807 	ljmp	_send_keyboard_report
      007B94                       1808 00103$:
      007B94 22               [24] 1809 	ret
                                   1810 ;------------------------------------------------------------
                                   1811 ;Allocation info for local variables in function 'register_weak_mods'
                                   1812 ;------------------------------------------------------------
                                   1813 ;mods          Allocated with name '_register_weak_mods_mods_10000_763'
                                   1814 ;------------------------------------------------------------
                                   1815 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1816 ;	-----------------------------------------
                                   1817 ;	 function register_weak_mods
                                   1818 ;	-----------------------------------------
      007B95                       1819 _register_weak_mods:
      007B95 E5 82            [12] 1820 	mov	a,dpl
      007B97 90 08 A2         [24] 1821 	mov	dptr,#_register_weak_mods_mods_10000_763
      007B9A F0               [24] 1822 	movx	@dptr,a
                                   1823 ;	quantum/action.c:1148: if (mods) {
      007B9B E0               [24] 1824 	movx	a,@dptr
      007B9C FF               [12] 1825 	mov	r7,a
      007B9D E0               [24] 1826 	movx	a,@dptr
      007B9E 60 08            [24] 1827 	jz	00103$
                                   1828 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007BA0 8F 82            [24] 1829 	mov	dpl, r7
      007BA2 12 81 BD         [24] 1830 	lcall	_add_owned_weak_mods
                                   1831 ;	quantum/action.c:1150: send_keyboard_report();
                                   1832 ;	quantum/action.c:1152: }
      007BA5 02 84 D2         [24] 1833 	ljmp	_send_keyboard_report
      007BA8                       1834 00103$:
      007BA8 22               [24] 1835 	ret
                                   1836 ;------------------------------------------------------------
                                   1837 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1838 ;------------------------------------------------------------
                                   1839 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_767'
                                   1840 ;------------------------------------------------------------
                                   1841 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1842 ;	-----------------------------------------
                                   1843 ;	 function unregister_weak_mods
                                   1844 ;	-----------------------------------------
      007BA9                       1845 _unregister_weak_mods:
      007BA9 E5 82            [12] 1846 	mov	a,dpl
      007BAB 90 08 A3         [24] 1847 	mov	dptr,#_unregister_weak_mods_mods_10000_767
      007BAE F0               [24] 1848 	movx	@dptr,a
                                   1849 ;	quantum/action.c:1159: if (mods) {
      007BAF E0               [24] 1850 	movx	a,@dptr
      007BB0 FF               [12] 1851 	mov	r7,a
      007BB1 E0               [24] 1852 	movx	a,@dptr
      007BB2 60 08            [24] 1853 	jz	00103$
                                   1854 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007BB4 8F 82            [24] 1855 	mov	dpl, r7
      007BB6 12 81 CC         [24] 1856 	lcall	_del_owned_weak_mods
                                   1857 ;	quantum/action.c:1161: send_keyboard_report();
                                   1858 ;	quantum/action.c:1163: }
      007BB9 02 84 D2         [24] 1859 	ljmp	_send_keyboard_report
      007BBC                       1860 00103$:
      007BBC 22               [24] 1861 	ret
                                   1862 ;------------------------------------------------------------
                                   1863 ;Allocation info for local variables in function 'clear_keyboard'
                                   1864 ;------------------------------------------------------------
                                   1865 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1866 ;	-----------------------------------------
                                   1867 ;	 function clear_keyboard
                                   1868 ;	-----------------------------------------
      007BBD                       1869 _clear_keyboard:
                                   1870 ;	quantum/action.c:1170: clear_mods();
      007BBD 12 86 33         [24] 1871 	lcall	_clear_mods
                                   1872 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1873 ;	quantum/action.c:1172: }
      007BC0 61 C2            [12] 1874 	ajmp	_clear_keyboard_but_mods
                                   1875 ;------------------------------------------------------------
                                   1876 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1877 ;------------------------------------------------------------
                                   1878 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1879 ;	-----------------------------------------
                                   1880 ;	 function clear_keyboard_but_mods
                                   1881 ;	-----------------------------------------
      007BC2                       1882 _clear_keyboard_but_mods:
                                   1883 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007BC2 90 0E 57         [24] 1884 	mov	dptr,#_actual_keyboard_report
      007BC5 12 74 C6         [24] 1885 	lcall	_clear_keys_from_report
                                   1886 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1887 ;	quantum/action.c:1181: }
      007BC8 61 CA            [12] 1888 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1889 ;------------------------------------------------------------
                                   1890 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1891 ;------------------------------------------------------------
                                   1892 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1893 ;	-----------------------------------------
                                   1894 ;	 function clear_keyboard_but_mods_and_keys
                                   1895 ;	-----------------------------------------
      007BCA                       1896 _clear_keyboard_but_mods_and_keys:
                                   1897 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007BCA 12 4C D5         [24] 1898 	lcall	_ak820_tapping_cancel
                                   1899 ;	quantum/action.c:1194: ak820_key_override_cancel();
      007BCD 12 3C E6         [24] 1900 	lcall	_ak820_key_override_cancel
                                   1901 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007BD0 12 2E F0         [24] 1902 	lcall	_ak820_oneshot_cancel
                                   1903 ;	quantum/action.c:1209: ak820_combo_cancel();
      007BD3 12 35 29         [24] 1904 	lcall	_ak820_combo_cancel
                                   1905 ;	quantum/action.c:1212: repeat_key_cancel();
      007BD6 12 A8 20         [24] 1906 	lcall	_repeat_key_cancel
                                   1907 ;	quantum/action.c:1214: clear_owned_mods();
      007BD9 12 81 DB         [24] 1908 	lcall	_clear_owned_mods
                                   1909 ;	quantum/action.c:1215: clear_owned_keys();
      007BDC 12 82 13         [24] 1910 	lcall	_clear_owned_keys
                                   1911 ;	quantum/action.c:1216: clear_owned_usages();
      007BDF 12 83 47         [24] 1912 	lcall	_clear_owned_usages
                                   1913 ;	quantum/action.c:1217: layer_hold_clear();
      007BE2 B1 9A            [12] 1914 	acall	_layer_hold_clear
                                   1915 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007BE4 12 A3 42         [24] 1916 	lcall	_clear_macro_tri_layer
                                   1917 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007BE7 90 0E 57         [24] 1918 	mov	dptr,#_actual_keyboard_report
      007BEA 12 74 C6         [24] 1919 	lcall	_clear_keys_from_report
                                   1920 ;	quantum/action.c:1224: host_system_send(0);
      007BED 90 00 00         [24] 1921 	mov	dptr,#0x0000
      007BF0 12 72 A5         [24] 1922 	lcall	_host_system_send
                                   1923 ;	quantum/action.c:1225: host_consumer_send(0);
      007BF3 90 00 00         [24] 1924 	mov	dptr,#0x0000
      007BF6 12 72 D4         [24] 1925 	lcall	_host_consumer_send
                                   1926 ;	quantum/action.c:1227: clear_weak_mods();
      007BF9 12 86 68         [24] 1927 	lcall	_clear_weak_mods
                                   1928 ;	quantum/action.c:1228: send_keyboard_report();
                                   1929 ;	quantum/action.c:1236: }
      007BFC 02 84 D2         [24] 1930 	ljmp	_send_keyboard_report
                                   1931 ;------------------------------------------------------------
                                   1932 ;Allocation info for local variables in function 'is_tap_record'
                                   1933 ;------------------------------------------------------------
                                   1934 ;record        Allocated with name '_is_tap_record_record_10000_783'
                                   1935 ;action        Allocated with name '_is_tap_record_action_10001_787'
                                   1936 ;------------------------------------------------------------
                                   1937 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1938 ;	-----------------------------------------
                                   1939 	.area CSEG    (CODE)
                                   1940 	.area CONST   (CODE)
                                   1941 	.area XINIT   (CODE)
      00C816                       1942 __xinit__disable_action_cache:
      00C816 00                    1943 	.db #0x00	;  0
                                   1944 	.area CABS    (ABS,CODE)
                                   1945 
                                   1946 ; Experimental exact instruction outlining.
                                   1947 	.globl _ak820_outline_0001
                                   1948 	.globl _ak820_outline_0007
                                   1949 	.globl _ak820_outline_0009
                                   1950 	.globl _ak820_outline_0011
                                   1951 	.globl _ak820_outline_0012
                                   1952 	.globl _ak820_outline_0013
                                   1953 	.globl _ak820_outline_0020
                                   1954 	.globl _ak820_outline_0023
                                   1955 	.globl _ak820_outline_0033
                                   1956 	.globl _ak820_outline_0042
                                   1957 	.globl _ak820_outline_0044
                                   1958 	.globl _ak820_outline_0055
                                   1959 	.globl _ak820_outline_0056
                                   1960 	.globl _ak820_outline_0063
                                   1961 	.globl _ak820_outline_0077
                                   1962 	.globl _ak820_outline_0078
                                   1963 	.globl _ak820_outline_0081
                                   1964 	.globl _ak820_outline_0089
                                   1965 	.globl _ak820_outline_0109
                                   1966 	.globl _ak820_outline_0110
                                   1967 	.globl _ak820_outline_0112
                                   1968 	.globl _ak820_outline_0113
                                   1969 	.globl _ak820_outline_0115
                                   1970 	.globl _ak820_outline_0120
                                   1971 	.globl _ak820_outline_0127
                                   1972 	.globl _ak820_outline_0128
                                   1973 	.globl _ak820_outline_0129
                                   1974 	.globl _ak820_outline_0136
                                   1975 	.globl _ak820_outline_0147
                                   1976 	.globl _ak820_outline_0148
                                   1977 	.globl _ak820_outline_0154
                                   1978 	.globl _ak820_outline_0155
                                   1979 	.globl _ak820_outline_0156
                                   1980 	.globl _ak820_outline_0165
                                   1981 	.globl _ak820_outline_0168
                                   1982 	.globl _ak820_outline_0175
                                   1983 	.globl _ak820_outline_0176
                                   1984 
                                   1985 	.area CSEG (CODE)
                                   1986 ; function ak820_outline_0023
      007BFF                       1987 _ak820_outline_0023:
      007BFF 8E 82            [24] 1988 	mov	dpl,r6
      007C01 8F 83            [24] 1989 	mov	dph,r7
      007C03 A3               [24] 1990 	inc	dptr
      007C04 E0               [24] 1991 	movx	a,@dptr
      007C05 FC               [12] 1992 	mov	r4,a
      007C06 7D 00            [12] 1993 	mov	r5,#0x00
      007C08 8E 82            [24] 1994 	mov	dpl,r6
      007C0A 8F 83            [24] 1995 	mov	dph,r7
      007C0C E0               [24] 1996 	movx	a,@dptr
      007C0D 22               [24] 1997 	ret
                                   1998 
                                   1999 	.area CSEG (CODE)
                                   2000 ; function ak820_outline_0042
      007C0E                       2001 _ak820_outline_0042:
      007C0E 74 07            [12] 2002 	mov	a,#0x07
      007C10 5F               [12] 2003 	anl	a,r7
      007C11 F5 F0            [12] 2004 	mov	b,a
      007C13 05 F0            [12] 2005 	inc	b
      007C15 74 01            [12] 2006 	mov	a,#0x01
      007C17 22               [24] 2007 	ret
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0044
      007C18                       2011 _ak820_outline_0044:
      007C18 90 08 96         [24] 2012 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C1B E0               [24] 2013 	movx	a,@dptr
      007C1C 54 1F            [12] 2014 	anl	a,#0x1f
      007C1E F5 82            [12] 2015 	mov	dpl,a
      007C20 22               [24] 2016 	ret
                                   2017 
                                   2018 	.area CSEG (CODE)
                                   2019 ; function ak820_outline_0055
      007C21                       2020 _ak820_outline_0055:
      007C21 A3               [24] 2021 	inc	dptr
      007C22 F0               [24] 2022 	movx	@dptr,a
      007C23 E4               [12] 2023 	clr	a
      007C24 A3               [24] 2024 	inc	dptr
      007C25 F0               [24] 2025 	movx	@dptr,a
      007C26 90 0E 32         [24] 2026 	mov	dptr,#___memcpy_PARM_3
      007C29 22               [24] 2027 	ret
                                   2028 
                                   2029 	.area CSEG (CODE)
                                   2030 ; function ak820_outline_0077
      007C2A                       2031 _ak820_outline_0077:
      007C2A 90 08 95         [24] 2032 	mov	dptr,#_process_action_PARM_2
      007C2D E0               [24] 2033 	movx	a,@dptr
      007C2E F5 82            [12] 2034 	mov	dpl,a
      007C30 22               [24] 2035 	ret
                                   2036 
                                   2037 	.area CSEG (CODE)
                                   2038 ; function ak820_outline_0089
      007C31                       2039 _ak820_outline_0089:
      007C31 90 08 96         [24] 2040 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C34 E0               [24] 2041 	movx	a,@dptr
      007C35 03               [12] 2042 	rr	a
      007C36 03               [12] 2043 	rr	a
      007C37 54 03            [12] 2044 	anl	a,#0x03
      007C39 22               [24] 2045 	ret
                                   2046 
                                   2047 	.area CSEG (CODE)
                                   2048 ; function ak820_outline_0113
      007C3A                       2049 _ak820_outline_0113:
      007C3A 74 06            [12] 2050 	mov	a,#0x06
      007C3C F0               [24] 2051 	movx	@dptr,a
      007C3D E4               [12] 2052 	clr	a
      007C3E A3               [24] 2053 	inc	dptr
      007C3F F0               [24] 2054 	movx	@dptr,a
      007C40 22               [24] 2055 	ret
                                   2056 
                                   2057 	.area CSEG (CODE)
                                   2058 ; function ak820_outline_0115
      007C41                       2059 _ak820_outline_0115:
      007C41 90 08 96         [24] 2060 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C44 E0               [24] 2061 	movx	a,@dptr
      007C45 54 0F            [12] 2062 	anl	a,#0x0f
      007C47 22               [24] 2063 	ret
                                   2064 
                                   2065 	.area CSEG (CODE)
                                   2066 ; function ak820_outline_0136
      007C48                       2067 _ak820_outline_0136:
      007C48 90 08 95         [24] 2068 	mov	dptr,#_process_action_PARM_2
      007C4B E0               [24] 2069 	movx	a,@dptr
      007C4C FE               [12] 2070 	mov	r6,a
      007C4D A3               [24] 2071 	inc	dptr
      007C4E E0               [24] 2072 	movx	a,@dptr
      007C4F 54 03            [12] 2073 	anl	a,#0x03
      007C51 FF               [12] 2074 	mov	r7,a
      007C52 22               [24] 2075 	ret
                                   2076 
                                   2077 	.area CSEG (CODE)
                                   2078 ; function ak820_outline_0165
      007C53                       2079 _ak820_outline_0165:
      007C53 90 08 95         [24] 2080 	mov	dptr,#_process_action_PARM_2
      007C56 E0               [24] 2081 	movx	a,@dptr
      007C57 22               [24] 2082 	ret
                                   2083 
                                   2084 	.area CSEG (CODE)
                                   2085 ; function ak820_outline_0175
      007C58                       2086 _ak820_outline_0175:
      007C58 90 08 9A         [24] 2087 	mov	dptr,#_register_code_code_10000_719
      007C5B E0               [24] 2088 	movx	a,@dptr
      007C5C FF               [12] 2089 	mov	r7,a
      007C5D 22               [24] 2090 	ret
                                   2091 
                                   2092 	.area CSEG (CODE)
                                   2093 ; function ak820_outline_0176
      007C5E                       2094 _ak820_outline_0176:
      007C5E 90 08 9B         [24] 2095 	mov	dptr,#_unregister_code_code_10000_733
      007C61 E0               [24] 2096 	movx	a,@dptr
      007C62 FF               [12] 2097 	mov	r7,a
      007C63 22               [24] 2098 	ret
