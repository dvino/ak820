                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_weak_mods
                                     12 	.globl _register_weak_mods
                                     13 	.globl _process_record
                                     14 	.globl _memset
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _get_alt_repeat_key_keycode_user_PARM_2
                                    259 	.globl _set_last_record_PARM_2
                                    260 	.globl _repeat_key_cancel
                                    261 	.globl _set_last_mods
                                    262 	.globl _set_last_record
                                    263 	.globl _get_repeat_key_count
                                    264 	.globl _repeat_key_invoke
                                    265 	.globl _get_alt_repeat_key_keycode
                                    266 	.globl _alt_repeat_key_invoke
                                    267 	.globl _get_alt_repeat_key_keycode_user
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000C8C                        554 _last_record:
      000C8C                        555 	.ds 9
      000C95                        556 _ak820_repeat_invoking:
      000C95                        557 	.ds 1
      000C96                        558 _registered_record:
      000C96                        559 	.ds 9
      000C9F                        560 _registered_repeat_count:
      000C9F                        561 	.ds 1
      000CA0                        562 _registered_mods:
      000CA0                        563 	.ds 1
      000CA1                        564 _set_last_mods_mods_10000_170:
      000CA1                        565 	.ds 1
      000CA2                        566 _set_last_record_PARM_2:
      000CA2                        567 	.ds 3
      000CA5                        568 _set_last_record_keycode_10000_172:
      000CA5                        569 	.ds 2
      000CA7                        570 _update_last_repeat_count_dir_10000_174:
      000CA7                        571 	.ds 1
      000CA8                        572 _repeat_invoke_PARM_2:
      000CA8                        573 	.ds 1
      000CA9                        574 _repeat_invoke_event_10000_182:
      000CA9                        575 	.ds 3
      000CAC                        576 _repeat_key_invoke_event_10000_197:
      000CAC                        577 	.ds 3
      000CAF                        578 _find_alt_keycode_PARM_2:
      000CAF                        579 	.ds 1
      000CB0                        580 _find_alt_keycode_PARM_3:
      000CB0                        581 	.ds 1
      000CB1                        582 _find_alt_keycode_table_10000_199:
      000CB1                        583 	.ds 3
      000CB4                        584 _get_alt_repeat_key_keycode_keycode_10000_206:
      000CB4                        585 	.ds 2
      000CB6                        586 _get_alt_repeat_key_keycode_mods_10000_206:
      000CB6                        587 	.ds 1
      000CB7                        588 _get_alt_repeat_key_keycode_alt_keycode_10000_206:
      000CB7                        589 	.ds 2
      000CB9                        590 _alt_repeat_key_invoke_event_10000_220:
      000CB9                        591 	.ds 3
      000CBC                        592 _get_alt_repeat_key_keycode_user_PARM_2:
      000CBC                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; absolute external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XABS    (ABS,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; initialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XISEG   (XDATA)
      000EAA                        602 _last_mods:
      000EAA                        603 	.ds 1
      000EAB                        604 _last_repeat_count:
      000EAB                        605 	.ds 1
      000EAC                        606 _processing_repeat_count:
      000EAC                        607 	.ds 1
                                    608 	.area HOME    (CODE)
                                    609 	.area GSINIT0 (CODE)
                                    610 	.area GSINIT1 (CODE)
                                    611 	.area GSINIT2 (CODE)
                                    612 	.area GSINIT3 (CODE)
                                    613 	.area GSINIT4 (CODE)
                                    614 	.area GSINIT5 (CODE)
                                    615 	.area GSINIT  (CODE)
                                    616 	.area GSFINAL (CODE)
                                    617 	.area CSEG    (CODE)
                                    618 ;--------------------------------------------------------
                                    619 ; global & static initialisations
                                    620 ;--------------------------------------------------------
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 	.area GSFINAL (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; Home
                                    627 ;--------------------------------------------------------
                                    628 	.area HOME    (CODE)
                                    629 	.area HOME    (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; code
                                    632 ;--------------------------------------------------------
                                    633 	.area CSEG    (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'repeat_key_cancel'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/repeat_key.c:44: void repeat_key_cancel(void) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function repeat_key_cancel
                                    640 ;	-----------------------------------------
      00A820                        641 _repeat_key_cancel:
                           000007   642 	ar7 = 0x07
                           000006   643 	ar6 = 0x06
                           000005   644 	ar5 = 0x05
                           000004   645 	ar4 = 0x04
                           000003   646 	ar3 = 0x03
                           000002   647 	ar2 = 0x02
                           000001   648 	ar1 = 0x01
                           000000   649 	ar0 = 0x00
                                    650 ;	quantum/repeat_key.c:45: registered_record.keycode = 0;
      00A820 90 0C 9D         [24]  651 	mov	dptr,#(_registered_record + 0x0007)
      00A823 12 55 0D         [24]  652 	lcall	_ak820_outline_0154
                                    653 ;	quantum/repeat_key.c:46: }
      00A826 22               [24]  654 	ret
                                    655 ;------------------------------------------------------------
                                    656 ;Allocation info for local variables in function 'get_last_keycode'
                                    657 ;------------------------------------------------------------
                                    658 ;	quantum/repeat_key.c:48: uint16_t get_last_keycode(void) {
                                    659 ;	-----------------------------------------
                                    660 ;	 function set_last_mods
                                    661 ;	-----------------------------------------
      00A827                        662 _set_last_mods:
      00A827 E5 82            [12]  663 	mov	a,dpl
      00A829 90 0C A1         [24]  664 	mov	dptr,#_set_last_mods_mods_10000_170
      00A82C F0               [24]  665 	movx	@dptr,a
                                    666 ;	quantum/repeat_key.c:66: last_mods = mods;
      00A82D E0               [24]  667 	movx	a,@dptr
      00A82E 90 0E AA         [24]  668 	mov	dptr,#_last_mods
      00A831 F0               [24]  669 	movx	@dptr,a
                                    670 ;	quantum/repeat_key.c:67: }
      00A832 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'set_last_record'
                                    674 ;------------------------------------------------------------
                                    675 ;record        Allocated with name '_set_last_record_PARM_2'
                                    676 ;keycode       Allocated with name '_set_last_record_keycode_10000_172'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/repeat_key.c:69: void set_last_record(uint16_t keycode, keyrecord_t* record) {
                                    679 ;	-----------------------------------------
                                    680 ;	 function set_last_record
                                    681 ;	-----------------------------------------
      00A833                        682 _set_last_record:
      00A833 12 38 44         [24]  683 	lcall	_ak820_outline_0109
      00A836 90 0C A5         [24]  684 	mov	dptr,#_set_last_record_keycode_10000_172
      00A839 12 38 49         [24]  685 	lcall	_ak820_outline_0110
                                    686 ;	quantum/repeat_key.c:70: last_record         = *record;
      00A83C 90 0C A2         [24]  687 	mov	dptr,#_set_last_record_PARM_2
      00A83F 12 54 C2         [24]  688 	lcall	_ak820_outline_0014
      00A842 90 0E 2F         [24]  689 	mov	dptr,#___memcpy_PARM_2
      00A845 ED               [12]  690 	mov	a,r5
      00A846 12 37 E5         [24]  691 	lcall	_ak820_outline_0020
      00A849 90 0E 32         [24]  692 	mov	dptr,#___memcpy_PARM_3
      00A84C 74 09            [12]  693 	mov	a,#0x09
      00A84E 12 38 59         [24]  694 	lcall	_ak820_outline_0129
      00A851 90 0C 8C         [24]  695 	mov	dptr,#_last_record
      00A854 F5 F0            [12]  696 	mov	b,a
      00A856 12 BF 43         [24]  697 	lcall	___memcpy
                                    698 ;	quantum/repeat_key.c:71: last_record.keycode = keycode;
      00A859 90 0C A5         [24]  699 	mov	dptr,#_set_last_record_keycode_10000_172
      00A85C 12 37 FD         [24]  700 	lcall	_ak820_outline_0056
      00A85F 90 0C 93         [24]  701 	mov	dptr,#(_last_record + 0x0007)
      00A862 12 4E 7D         [24]  702 	lcall	_ak820_outline_0064
                                    703 ;	quantum/repeat_key.c:72: last_repeat_count   = 0;
      00A865 90 0E AB         [24]  704 	mov	dptr,#_last_repeat_count
      00A868 E4               [12]  705 	clr	a
      00A869 F0               [24]  706 	movx	@dptr,a
                                    707 ;	quantum/repeat_key.c:73: }
      00A86A 22               [24]  708 	ret
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'update_last_repeat_count'
                                    711 ;------------------------------------------------------------
                                    712 ;dir           Allocated with name '_update_last_repeat_count_dir_10000_174'
                                    713 ;------------------------------------------------------------
                                    714 ;	quantum/repeat_key.c:76: static void update_last_repeat_count(int8_t dir) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function update_last_repeat_count
                                    717 ;	-----------------------------------------
      00A86B                        718 _update_last_repeat_count:
      00A86B E5 82            [12]  719 	mov	a,dpl
      00A86D 90 0C A7         [24]  720 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A870 F0               [24]  721 	movx	@dptr,a
                                    722 ;	quantum/repeat_key.c:77: if ((dir < 0) != (last_repeat_count < 0)) {
      00A871 E0               [24]  723 	movx	a,@dptr
      00A872 FF               [12]  724 	mov	r7,a
      00A873 33               [12]  725 	rlc	a
      00A874 E4               [12]  726 	clr	a
      00A875 33               [12]  727 	rlc	a
      00A876 FE               [12]  728 	mov	r6,a
      00A877 90 0E AB         [24]  729 	mov	dptr,#_last_repeat_count
      00A87A E0               [24]  730 	movx	a,@dptr
      00A87B FD               [12]  731 	mov	r5,a
      00A87C 33               [12]  732 	rlc	a
      00A87D E4               [12]  733 	clr	a
      00A87E 33               [12]  734 	rlc	a
      00A87F FC               [12]  735 	mov	r4,a
      00A880 EE               [12]  736 	mov	a,r6
      00A881 B5 04 02         [24]  737 	cjne	a,ar4,00131$
      00A884 80 06            [24]  738 	sjmp	00104$
      00A886                        739 00131$:
                                    740 ;	quantum/repeat_key.c:78: last_repeat_count = dir;
      00A886 90 0E AB         [24]  741 	mov	dptr,#_last_repeat_count
      00A889 EF               [12]  742 	mov	a,r7
      00A88A F0               [24]  743 	movx	@dptr,a
      00A88B 22               [24]  744 	ret
      00A88C                        745 00104$:
                                    746 ;	quantum/repeat_key.c:79: } else if (dir < 0 ? last_repeat_count > -127 : last_repeat_count < 127) {
      00A88C EE               [12]  747 	mov	a,r6
      00A88D 60 0F            [24]  748 	jz	00108$
      00A88F C3               [12]  749 	clr	c
      00A890 74 01            [12]  750 	mov	a,#(0x81 ^ 0x80)
      00A892 8D F0            [24]  751 	mov	b,r5
      00A894 63 F0 80         [24]  752 	xrl	b,#0x80
      00A897 95 F0            [12]  753 	subb	a,b
      00A899 E4               [12]  754 	clr	a
      00A89A 33               [12]  755 	rlc	a
      00A89B FF               [12]  756 	mov	r7,a
                                    757 ;	free result
      00A89C 80 09            [24]  758 	sjmp	00109$
      00A89E                        759 00108$:
      00A89E C3               [12]  760 	clr	c
      00A89F ED               [12]  761 	mov	a,r5
      00A8A0 64 80            [12]  762 	xrl	a,#0x80
      00A8A2 94 FF            [12]  763 	subb	a,#0xff
      00A8A4 E4               [12]  764 	clr	a
      00A8A5 33               [12]  765 	rlc	a
      00A8A6 FF               [12]  766 	mov	r7,a
      00A8A7                        767 00109$:
      00A8A7 EF               [12]  768 	mov	a,r7
      00A8A8 60 09            [24]  769 	jz	00106$
                                    770 ;	quantum/repeat_key.c:80: last_repeat_count += dir;
      00A8AA 90 0C A7         [24]  771 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A8AD E0               [24]  772 	movx	a,@dptr
      00A8AE 90 0E AB         [24]  773 	mov	dptr,#_last_repeat_count
      00A8B1 2D               [12]  774 	add	a, r5
      00A8B2 F0               [24]  775 	movx	@dptr,a
      00A8B3                        776 00106$:
                                    777 ;	quantum/repeat_key.c:82: }
      00A8B3 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'get_repeat_key_count'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/repeat_key.c:84: int8_t get_repeat_key_count(void) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function get_repeat_key_count
                                    785 ;	-----------------------------------------
      00A8B4                        786 _get_repeat_key_count:
                                    787 ;	quantum/repeat_key.c:85: return processing_repeat_count;
      00A8B4 90 0E AC         [24]  788 	mov	dptr,#_processing_repeat_count
      00A8B7 E0               [24]  789 	movx	a,@dptr
                                    790 ;	quantum/repeat_key.c:86: }
      00A8B8 F5 82            [12]  791 	mov	dpl,a
      00A8BA 22               [24]  792 	ret
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'repeat_invoke'
                                    795 ;------------------------------------------------------------
                                    796 ;alternate     Allocated with name '_repeat_invoke_PARM_2'
                                    797 ;event         Allocated with name '_repeat_invoke_event_10000_182'
                                    798 ;------------------------------------------------------------
                                    799 ;	quantum/repeat_key.c:88: static void repeat_invoke(const keyevent_t* event, bool alternate) {
                                    800 ;	-----------------------------------------
                                    801 ;	 function repeat_invoke
                                    802 ;	-----------------------------------------
      00A8BB                        803 _repeat_invoke:
      00A8BB 12 49 1A         [24]  804 	lcall	_ak820_outline_0038
      00A8BE 90 0C A9         [24]  805 	mov	dptr,#_repeat_invoke_event_10000_182
      00A8C1 12 37 E5         [24]  806 	lcall	_ak820_outline_0020
                                    807 ;	quantum/repeat_key.c:97: if (ak820_repeat_invoking) return;
      00A8C4 90 0C 95         [24]  808 	mov	dptr,#_ak820_repeat_invoking
      00A8C7 E0               [24]  809 	movx	a,@dptr
      00A8C8 60 01            [24]  810 	jz	00102$
      00A8CA 22               [24]  811 	ret
      00A8CB                        812 00102$:
                                    813 ;	quantum/repeat_key.c:99: if (processing_repeat_count) {
      00A8CB 90 0E AC         [24]  814 	mov	dptr,#_processing_repeat_count
      00A8CE E0               [24]  815 	movx	a,@dptr
      00A8CF 60 01            [24]  816 	jz	00104$
                                    817 ;	quantum/repeat_key.c:100: return;
      00A8D1 22               [24]  818 	ret
      00A8D2                        819 00104$:
                                    820 ;	quantum/repeat_key.c:103: if (event->pressed) {
      00A8D2 90 0C A9         [24]  821 	mov	dptr,#_repeat_invoke_event_10000_182
      00A8D5 12 54 C2         [24]  822 	lcall	_ak820_outline_0014
      00A8D8 74 05            [12]  823 	mov	a,#0x05
      00A8DA 12 A2 86         [24]  824 	lcall	_ak820_outline_0028
      00A8DD 12 C0 1C         [24]  825 	lcall	__gptrget
      00A8E0 70 02            [24]  826 	jnz	00197$
      00A8E2 21 5A            [24]  827 	ajmp	00117$
      00A8E4                        828 00197$:
                                    829 ;	quantum/repeat_key.c:106: if (registered_record.keycode || !last_record.keycode) return;
      00A8E4 12 AB 5A         [24]  830 	lcall	_ak820_outline_0179
      00A8E7 70 0A            [24]  831 	jnz	00105$
      00A8E9 90 0C 93         [24]  832 	mov	dptr,#(_last_record + 0x0007)
      00A8EC E0               [24]  833 	movx	a,@dptr
      00A8ED FB               [12]  834 	mov	r3,a
      00A8EE A3               [24]  835 	inc	dptr
      00A8EF E0               [24]  836 	movx	a,@dptr
      00A8F0 4B               [12]  837 	orl	a,r3
      00A8F1 70 01            [24]  838 	jnz	00106$
      00A8F3                        839 00105$:
      00A8F3 22               [24]  840 	ret
      00A8F4                        841 00106$:
                                    842 ;	quantum/repeat_key.c:107: registered_record = last_record;
      00A8F4 90 0E 2F         [24]  843 	mov	dptr,#___memcpy_PARM_2
      00A8F7 74 8C            [12]  844 	mov	a,#_last_record
      00A8F9 F0               [24]  845 	movx	@dptr,a
      00A8FA 74 0C            [12]  846 	mov	a,#(_last_record >> 8)
      00A8FC 12 38 1A         [24]  847 	lcall	_ak820_outline_0074
      00A8FF 90 0E 32         [24]  848 	mov	dptr,#___memcpy_PARM_3
      00A902 74 09            [12]  849 	mov	a,#0x09
      00A904 12 38 59         [24]  850 	lcall	_ak820_outline_0129
      00A907 90 0C 96         [24]  851 	mov	dptr,#_registered_record
      00A90A F5 F0            [12]  852 	mov	b,a
      00A90C 12 BF 43         [24]  853 	lcall	___memcpy
                                    854 ;	quantum/repeat_key.c:108: registered_mods = last_mods;
      00A90F 90 0E AA         [24]  855 	mov	dptr,#_last_mods
      00A912 E0               [24]  856 	movx	a,@dptr
      00A913 90 0C A0         [24]  857 	mov	dptr,#_registered_mods
      00A916 F0               [24]  858 	movx	@dptr,a
                                    859 ;	quantum/repeat_key.c:110: if (alternate) {
      00A917 90 0C A8         [24]  860 	mov	dptr,#_repeat_invoke_PARM_2
      00A91A E0               [24]  861 	movx	a,@dptr
      00A91B FC               [12]  862 	mov	r4,a
      00A91C E0               [24]  863 	movx	a,@dptr
      00A91D 60 1B            [24]  864 	jz	00111$
                                    865 ;	quantum/repeat_key.c:111: registered_record.keycode = get_alt_repeat_key_keycode();
      00A91F C0 04            [24]  866 	push	ar4
      00A921 51 28            [24]  867 	acall	_get_alt_repeat_key_keycode
      00A923 AA 82            [24]  868 	mov	r2, dpl
      00A925 AB 83            [24]  869 	mov	r3, dph
      00A927 D0 04            [24]  870 	pop	ar4
      00A929 90 0C 9D         [24]  871 	mov	dptr,#(_registered_record + 0x0007)
      00A92C EA               [12]  872 	mov	a,r2
      00A92D 12 55 18         [24]  873 	lcall	_ak820_outline_0196
                                    874 ;	quantum/repeat_key.c:112: if (!registered_record.keycode) return;
      00A930 EA               [12]  875 	mov	a,r2
      00A931 4B               [12]  876 	orl	a,r3
      00A932 70 01            [24]  877 	jnz	00109$
      00A934 22               [24]  878 	ret
      00A935                        879 00109$:
                                    880 ;	quantum/repeat_key.c:114: registered_mods = 0;
      00A935 90 0C A0         [24]  881 	mov	dptr,#_registered_mods
      00A938 E4               [12]  882 	clr	a
      00A939 F0               [24]  883 	movx	@dptr,a
      00A93A                        884 00111$:
                                    885 ;	quantum/repeat_key.c:117: update_last_repeat_count(alternate ? -1 : 1);
      00A93A EC               [12]  886 	mov	a,r4
      00A93B 60 04            [24]  887 	jz	00123$
      00A93D 7C FF            [12]  888 	mov	r4,#0xff
      00A93F 80 02            [24]  889 	sjmp	00124$
      00A941                        890 00123$:
      00A941 7C 01            [12]  891 	mov	r4,#0x01
      00A943                        892 00124$:
      00A943 8C 82            [24]  893 	mov	dpl, r4
      00A945 11 6B            [12]  894 	acall	_update_last_repeat_count
                                    895 ;	quantum/repeat_key.c:118: register_weak_mods(registered_mods);
      00A947 90 0C A0         [24]  896 	mov	dptr,#_registered_mods
      00A94A E0               [24]  897 	movx	a,@dptr
      00A94B F5 82            [12]  898 	mov	dpl,a
      00A94D 12 7B 95         [24]  899 	lcall	_register_weak_mods
                                    900 ;	quantum/repeat_key.c:119: registered_repeat_count = last_repeat_count;
      00A950 90 0E AB         [24]  901 	mov	dptr,#_last_repeat_count
      00A953 E0               [24]  902 	movx	a,@dptr
      00A954 90 0C 9F         [24]  903 	mov	dptr,#_registered_repeat_count
      00A957 F0               [24]  904 	movx	@dptr,a
      00A958 80 2A            [24]  905 	sjmp	00118$
      00A95A                        906 00117$:
                                    907 ;	quantum/repeat_key.c:122: if (!registered_record.keycode || event->key.row != registered_record.event.key.row ||
      00A95A 12 AB 5A         [24]  908 	lcall	_ak820_outline_0179
      00A95D 60 24            [24]  909 	jz	00112$
      00A95F 74 01            [12]  910 	mov	a,#0x01
      00A961 12 A2 86         [24]  911 	lcall	_ak820_outline_0028
      00A964 12 C0 1C         [24]  912 	lcall	__gptrget
      00A967 FA               [12]  913 	mov	r2,a
      00A968 90 0C 97         [24]  914 	mov	dptr,#(_registered_record + 0x0001)
      00A96B E0               [24]  915 	movx	a,@dptr
      00A96C FC               [12]  916 	mov	r4,a
      00A96D EA               [12]  917 	mov	a,r2
      00A96E B5 04 12         [24]  918 	cjne	a,ar4,00112$
                                    919 ;	quantum/repeat_key.c:123: event->key.col != registered_record.event.key.col) return;
      00A971 12 54 CB         [24]  920 	lcall	_ak820_outline_0049
      00A974 12 C0 1C         [24]  921 	lcall	__gptrget
      00A977 FD               [12]  922 	mov	r5,a
      00A978 90 0C 96         [24]  923 	mov	dptr,#_registered_record
      00A97B E0               [24]  924 	movx	a,@dptr
      00A97C FF               [12]  925 	mov	r7,a
      00A97D ED               [12]  926 	mov	a,r5
      00A97E B5 07 02         [24]  927 	cjne	a,ar7,00206$
      00A981 80 01            [24]  928 	sjmp	00118$
      00A983                        929 00206$:
      00A983                        930 00112$:
      00A983 22               [24]  931 	ret
      00A984                        932 00118$:
                                    933 ;	quantum/repeat_key.c:127: registered_record.event = *event;
      00A984 90 0C A9         [24]  934 	mov	dptr,#_repeat_invoke_event_10000_182
      00A987 12 54 C2         [24]  935 	lcall	_ak820_outline_0014
      00A98A 90 0E 2F         [24]  936 	mov	dptr,#___memcpy_PARM_2
      00A98D ED               [12]  937 	mov	a,r5
      00A98E 12 37 E5         [24]  938 	lcall	_ak820_outline_0020
      00A991 90 0E 32         [24]  939 	mov	dptr,#___memcpy_PARM_3
      00A994 12 7C 3A         [24]  940 	lcall	_ak820_outline_0113
      00A997 90 0C 96         [24]  941 	mov	dptr,#_registered_record
      00A99A F5 F0            [12]  942 	mov	b,a
      00A99C 12 BF 43         [24]  943 	lcall	___memcpy
                                    944 ;	quantum/repeat_key.c:128: processing_repeat_count = registered_repeat_count;
      00A99F 90 0C 9F         [24]  945 	mov	dptr,#_registered_repeat_count
      00A9A2 E0               [24]  946 	movx	a,@dptr
      00A9A3 90 0E AC         [24]  947 	mov	dptr,#_processing_repeat_count
      00A9A6 F0               [24]  948 	movx	@dptr,a
                                    949 ;	quantum/repeat_key.c:130: ak820_repeat_invoking = true;
      00A9A7 90 0C 95         [24]  950 	mov	dptr,#_ak820_repeat_invoking
      00A9AA 74 01            [12]  951 	mov	a,#0x01
      00A9AC F0               [24]  952 	movx	@dptr,a
                                    953 ;	quantum/repeat_key.c:132: process_record(&registered_record);
      00A9AD 90 0C 96         [24]  954 	mov	dptr,#_registered_record
      00A9B0 12 76 47         [24]  955 	lcall	_process_record
                                    956 ;	quantum/repeat_key.c:134: ak820_repeat_invoking = false;
      00A9B3 90 0C 95         [24]  957 	mov	dptr,#_ak820_repeat_invoking
      00A9B6 E4               [12]  958 	clr	a
      00A9B7 F0               [24]  959 	movx	@dptr,a
                                    960 ;	quantum/repeat_key.c:136: processing_repeat_count = 0;
      00A9B8 90 0E AC         [24]  961 	mov	dptr,#_processing_repeat_count
      00A9BB F0               [24]  962 	movx	@dptr,a
                                    963 ;	quantum/repeat_key.c:142: if (!registered_record.event.pressed) {
      00A9BC 90 0C 9B         [24]  964 	mov	dptr,#(_registered_record + 0x0005)
      00A9BF E0               [24]  965 	movx	a,@dptr
      00A9C0 70 0F            [24]  966 	jnz	00121$
                                    967 ;	quantum/repeat_key.c:143: unregister_weak_mods(registered_mods);
      00A9C2 90 0C A0         [24]  968 	mov	dptr,#_registered_mods
      00A9C5 E0               [24]  969 	movx	a,@dptr
      00A9C6 F5 82            [12]  970 	mov	dpl,a
      00A9C8 12 7B A9         [24]  971 	lcall	_unregister_weak_mods
                                    972 ;	quantum/repeat_key.c:144: registered_record.keycode = 0;
      00A9CB 90 0C 9D         [24]  973 	mov	dptr,#(_registered_record + 0x0007)
      00A9CE 12 55 0D         [24]  974 	lcall	_ak820_outline_0154
      00A9D1                        975 00121$:
                                    976 ;	quantum/repeat_key.c:146: }
      00A9D1 22               [24]  977 	ret
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'repeat_key_invoke'
                                    980 ;------------------------------------------------------------
                                    981 ;event         Allocated with name '_repeat_key_invoke_event_10000_197'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/repeat_key.c:148: void repeat_key_invoke(const keyevent_t* event) {
                                    984 ;	-----------------------------------------
                                    985 ;	 function repeat_key_invoke
                                    986 ;	-----------------------------------------
      00A9D2                        987 _repeat_key_invoke:
      00A9D2 12 49 1A         [24]  988 	lcall	_ak820_outline_0038
      00A9D5 90 0C AC         [24]  989 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A9D8 12 37 E5         [24]  990 	lcall	_ak820_outline_0020
                                    991 ;	quantum/repeat_key.c:149: repeat_invoke(event, false);
      00A9DB 90 0C AC         [24]  992 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A9DE 12 54 C2         [24]  993 	lcall	_ak820_outline_0014
      00A9E1 90 0C A8         [24]  994 	mov	dptr,#_repeat_invoke_PARM_2
      00A9E4 E4               [12]  995 	clr	a
      00A9E5 F0               [24]  996 	movx	@dptr,a
      00A9E6 12 54 CB         [24]  997 	lcall	_ak820_outline_0049
                                    998 ;	quantum/repeat_key.c:150: }
      00A9E9 01 BB            [12]  999 	ajmp	_repeat_invoke
                                   1000 ;------------------------------------------------------------
                                   1001 ;Allocation info for local variables in function 'find_alt_keycode'
                                   1002 ;------------------------------------------------------------
                                   1003 ;table_size_bytes Allocated with name '_find_alt_keycode_PARM_2'
                                   1004 ;target        Allocated with name '_find_alt_keycode_PARM_3'
                                   1005 ;table         Allocated with name '_find_alt_keycode_table_10000_199'
                                   1006 ;keycodes      Allocated with name '_find_alt_keycode_keycodes_10000_200'
                                   1007 ;i             Allocated with name '_find_alt_keycode_i_20000_201'
                                   1008 ;------------------------------------------------------------
                                   1009 ;	quantum/repeat_key.c:166: static uint8_t find_alt_keycode(const uint8_t (*table)[2], uint8_t table_size_bytes, uint8_t target) {
                                   1010 ;	-----------------------------------------
                                   1011 ;	 function find_alt_keycode
                                   1012 ;	-----------------------------------------
      00A9EB                       1013 _find_alt_keycode:
      00A9EB 12 49 1A         [24] 1014 	lcall	_ak820_outline_0038
      00A9EE 90 0C B1         [24] 1015 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A9F1 12 37 E5         [24] 1016 	lcall	_ak820_outline_0020
                                   1017 ;	quantum/repeat_key.c:167: const uint8_t* keycodes = (const uint8_t*)table;
      00A9F4 90 0C B1         [24] 1018 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A9F7 12 54 C2         [24] 1019 	lcall	_ak820_outline_0014
                                   1020 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A9FA 7C 00            [12] 1021 	mov	r4,#0x00
      00A9FC                       1022 00105$:
      00A9FC 90 0C AF         [24] 1023 	mov	dptr,#_find_alt_keycode_PARM_2
      00A9FF E0               [24] 1024 	movx	a,@dptr
      00AA00 FB               [12] 1025 	mov	r3,a
      00AA01 C3               [12] 1026 	clr	c
      00AA02 EC               [12] 1027 	mov	a,r4
      00AA03 9B               [12] 1028 	subb	a,r3
      00AA04 50 1E            [24] 1029 	jnc	00103$
                                   1030 ;	quantum/repeat_key.c:169: if (target == pgm_read_byte(keycodes + i)) {
      00AA06 EC               [12] 1031 	mov	a,r4
      00AA07 12 95 6C         [24] 1032 	lcall	_ak820_outline_0027
      00AA0A 12 C0 1C         [24] 1033 	lcall	__gptrget
      00AA0D F9               [12] 1034 	mov	r1,a
      00AA0E 90 0C B0         [24] 1035 	mov	dptr,#_find_alt_keycode_PARM_3
      00AA11 E0               [24] 1036 	movx	a,@dptr
      00AA12 B5 01 0C         [24] 1037 	cjne	a,ar1,00106$
                                   1038 ;	quantum/repeat_key.c:171: return pgm_read_byte(keycodes + (i ^ 1));
      00AA15 74 01            [12] 1039 	mov	a,#0x01
      00AA17 6C               [12] 1040 	xrl	a,r4
      00AA18 12 95 6C         [24] 1041 	lcall	_ak820_outline_0027
      00AA1B 12 C0 1C         [24] 1042 	lcall	__gptrget
      00AA1E F5 82            [12] 1043 	mov	dpl,a
      00AA20 22               [24] 1044 	ret
      00AA21                       1045 00106$:
                                   1046 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00AA21 0C               [12] 1047 	inc	r4
      00AA22 80 D8            [24] 1048 	sjmp	00105$
      00AA24                       1049 00103$:
                                   1050 ;	quantum/repeat_key.c:174: return KC_NO;
      00AA24 75 82 00         [24] 1051 	mov	dpl, #0x00
                                   1052 ;	quantum/repeat_key.c:175: }
      00AA27 22               [24] 1053 	ret
                                   1054 ;------------------------------------------------------------
                                   1055 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode'
                                   1056 ;------------------------------------------------------------
                                   1057 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_keycode_10000_206'
                                   1058 ;mods          Allocated with name '_get_alt_repeat_key_keycode_mods_10000_206'
                                   1059 ;alt_keycode   Allocated with name '_get_alt_repeat_key_keycode_alt_keycode_10000_206'
                                   1060 ;------------------------------------------------------------
                                   1061 ;	quantum/repeat_key.c:177: uint16_t get_alt_repeat_key_keycode(void) {
                                   1062 ;	-----------------------------------------
                                   1063 ;	 function get_alt_repeat_key_keycode
                                   1064 ;	-----------------------------------------
      00AA28                       1065 _get_alt_repeat_key_keycode:
                                   1066 ;	quantum/repeat_key.c:178: uint16_t keycode = last_record.keycode;
      00AA28 90 0C 93         [24] 1067 	mov	dptr,#(_last_record + 0x0007)
      00AA2B 12 37 FD         [24] 1068 	lcall	_ak820_outline_0056
      00AA2E 90 0C B4         [24] 1069 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00AA31 12 4E 7D         [24] 1070 	lcall	_ak820_outline_0064
                                   1071 ;	quantum/repeat_key.c:179: uint8_t  mods    = last_mods;
      00AA34 90 0E AA         [24] 1072 	mov	dptr,#_last_mods
      00AA37 E0               [24] 1073 	movx	a,@dptr
      00AA38 FD               [12] 1074 	mov	r5,a
      00AA39 90 0C B6         [24] 1075 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00AA3C F0               [24] 1076 	movx	@dptr,a
                                   1077 ;	quantum/repeat_key.c:183: uint16_t alt_keycode = get_alt_repeat_key_keycode_user(keycode, mods);
      00AA3D 90 0C BC         [24] 1078 	mov	dptr,#_get_alt_repeat_key_keycode_user_PARM_2
      00AA40 ED               [12] 1079 	mov	a,r5
      00AA41 12 49 3E         [24] 1080 	lcall	_ak820_outline_0063
      00AA44 C0 07            [24] 1081 	push	ar7
      00AA46 C0 06            [24] 1082 	push	ar6
      00AA48 71 56            [12] 1083 	acall	_get_alt_repeat_key_keycode_user
      00AA4A 12 49 84         [24] 1084 	lcall	_ak820_outline_0155
      00AA4D D0 06            [24] 1085 	pop	ar6
      00AA4F D0 07            [24] 1086 	pop	ar7
                                   1087 ;	quantum/repeat_key.c:185: if (alt_keycode != KC_TRANSPARENT) {
      00AA51 8C 02            [24] 1088 	mov	ar2,r4
      00AA53 8D 03            [24] 1089 	mov	ar3,r5
      00AA55 BA 01 05         [24] 1090 	cjne	r2,#0x01,00176$
      00AA58 BB 00 02         [24] 1091 	cjne	r3,#0x00,00176$
      00AA5B 80 04            [24] 1092 	sjmp	00102$
      00AA5D                       1093 00176$:
                                   1094 ;	quantum/repeat_key.c:186: return alt_keycode;
      00AA5D 12 38 54         [24] 1095 	lcall	_ak820_outline_0128
      00AA60 22               [24] 1096 	ret
      00AA61                       1097 00102$:
                                   1098 ;	quantum/repeat_key.c:191: mods = ((mods & 0xf0) ? /* set right hand bit */ 0x10 : 0)
      00AA61 90 0C B6         [24] 1099 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00AA64 E0               [24] 1100 	movx	a,@dptr
      00AA65 54 F0            [12] 1101 	anl	a,#0xf0
      00AA67 60 02            [24] 1102 	jz	00118$
      00AA69 74 10            [12] 1103 	mov	a,#0x10
      00AA6B                       1104 00118$:
      00AA6B FD               [12] 1105 	mov	r5,a
                                   1106 ;	quantum/repeat_key.c:193: | (((mods >> 4) | mods) & 0xf);
      00AA6C 90 0C B6         [24] 1107 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00AA6F E0               [24] 1108 	movx	a,@dptr
      00AA70 FC               [12] 1109 	mov	r4,a
      00AA71 C4               [12] 1110 	swap	a
      00AA72 54 0F            [12] 1111 	anl	a,#0x0f
      00AA74 4C               [12] 1112 	orl	a,r4
      00AA75 54 0F            [12] 1113 	anl	a,#0x0f
      00AA77 4D               [12] 1114 	orl	a,r5
      00AA78 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/repeat_key.c:196: if (keycode >= QK_MODS && keycode <= QK_MODS_MAX) {
      00AA79 8E 04            [24] 1117 	mov	ar4,r6
      00AA7B 8F 05            [24] 1118 	mov	ar5,r7
      00AA7D 74 FF            [12] 1119 	mov	a,#0x100 - 0x01
      00AA7F 2D               [12] 1120 	add	a,r5
      00AA80 50 1C            [24] 1121 	jnc	00115$
      00AA82 C3               [12] 1122 	clr	c
      00AA83 74 FF            [12] 1123 	mov	a,#0xff
      00AA85 9C               [12] 1124 	subb	a,r4
      00AA86 74 1F            [12] 1125 	mov	a,#0x1f
      00AA88 9D               [12] 1126 	subb	a,r5
      00AA89 40 13            [24] 1127 	jc	00115$
                                   1128 ;	free result
                                   1129 ;	quantum/repeat_key.c:197: mods |= QK_MODS_GET_MODS(keycode);
      00AA8B 8F 06            [24] 1130 	mov	ar6,r7
      00AA8D 53 06 1F         [24] 1131 	anl	ar6,#0x1f
      00AA90 90 0C B6         [24] 1132 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00AA93 E0               [24] 1133 	movx	a,@dptr
      00AA94 4E               [12] 1134 	orl	a,r6
      00AA95 F0               [24] 1135 	movx	@dptr,a
                                   1136 ;	quantum/repeat_key.c:198: keycode = QK_MODS_GET_BASIC_KEYCODE(keycode);
      00AA96 7D 00            [12] 1137 	mov	r5,#0x00
      00AA98 90 0C B4         [24] 1138 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00AA9B 12 38 20         [24] 1139 	lcall	_ak820_outline_0078
                                   1140 ;	quantum/repeat_key.c:214: if (IS_QK_BASIC(keycode)) {
      00AA9E                       1141 00115$:
      00AA9E 90 0C B4         [24] 1142 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00AAA1 12 37 C8         [24] 1143 	lcall	_ak820_outline_0009
      00AAA4 C3               [12] 1144 	clr	c
      00AAA5 74 FF            [12] 1145 	mov	a,#0xff
      00AAA7 9C               [12] 1146 	subb	a,r4
      00AAA8 E4               [12] 1147 	clr	a
      00AAA9 9D               [12] 1148 	subb	a,r5
      00AAAA 50 02            [24] 1149 	jnc	00180$
      00AAAC 61 38            [12] 1150 	ajmp	00114$
      00AAAE                       1151 00180$:
                                   1152 ;	free result
                                   1153 ;	quantum/repeat_key.c:215: if ((mods & (MOD_LCTL | MOD_LALT | MOD_LGUI))) {
      00AAAE 90 0C B6         [24] 1154 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00AAB1 E0               [24] 1155 	movx	a,@dptr
      00AAB2 54 0D            [12] 1156 	anl	a,#0x0d
      00AAB4 60 20            [24] 1157 	jz	00107$
                                   1158 ;	quantum/repeat_key.c:230: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00AAB6 8E 05            [24] 1159 	mov	ar5,r6
      00AAB8 90 0C AF         [24] 1160 	mov	dptr,#_find_alt_keycode_PARM_2
      00AABB 74 0A            [12] 1161 	mov	a,#0x0a
      00AABD F0               [24] 1162 	movx	@dptr,a
      00AABE 90 0C B0         [24] 1163 	mov	dptr,#_find_alt_keycode_PARM_3
      00AAC1 ED               [12] 1164 	mov	a,r5
      00AAC2 F0               [24] 1165 	movx	@dptr,a
      00AAC3 90 C3 E1         [24] 1166 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_214
      00AAC6 75 F0 80         [24] 1167 	mov	b, #0x80
      00AAC9 31 EB            [24] 1168 	acall	_find_alt_keycode
      00AACB AD 82            [24] 1169 	mov	r5, dpl
      00AACD 90 0C B7         [24] 1170 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AAD0 ED               [12] 1171 	mov	a,r5
      00AAD1 12 38 59         [24] 1172 	lcall	_ak820_outline_0129
      00AAD4 80 1C            [24] 1173 	sjmp	00108$
      00AAD6                       1174 00107$:
                                   1175 ;	quantum/repeat_key.c:243: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00AAD6 90 0C AF         [24] 1176 	mov	dptr,#_find_alt_keycode_PARM_2
      00AAD9 74 08            [12] 1177 	mov	a,#0x08
      00AADB F0               [24] 1178 	movx	@dptr,a
      00AADC 90 0C B0         [24] 1179 	mov	dptr,#_find_alt_keycode_PARM_3
      00AADF EE               [12] 1180 	mov	a,r6
      00AAE0 F0               [24] 1181 	movx	@dptr,a
      00AAE1 90 C3 EB         [24] 1182 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_215
      00AAE4 75 F0 80         [24] 1183 	mov	b, #0x80
      00AAE7 31 EB            [24] 1184 	acall	_find_alt_keycode
      00AAE9 AF 82            [24] 1185 	mov	r7, dpl
      00AAEB 90 0C B7         [24] 1186 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AAEE EF               [12] 1187 	mov	a,r7
      00AAEF 12 38 59         [24] 1188 	lcall	_ak820_outline_0129
      00AAF2                       1189 00108$:
                                   1190 ;	quantum/repeat_key.c:246: if (!alt_keycode) {
      00AAF2 90 0C B7         [24] 1191 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AAF5 12 73 11         [24] 1192 	lcall	_ak820_outline_0040
      00AAF8 70 21            [24] 1193 	jnz	00110$
                                   1194 ;	quantum/repeat_key.c:271: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00AAFA 90 0C B4         [24] 1195 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00AAFD E0               [24] 1196 	movx	a,@dptr
      00AAFE FF               [12] 1197 	mov	r7,a
      00AAFF 90 0C AF         [24] 1198 	mov	dptr,#_find_alt_keycode_PARM_2
      00AB02 74 16            [12] 1199 	mov	a,#0x16
      00AB04 F0               [24] 1200 	movx	@dptr,a
      00AB05 90 0C B0         [24] 1201 	mov	dptr,#_find_alt_keycode_PARM_3
      00AB08 EF               [12] 1202 	mov	a,r7
      00AB09 F0               [24] 1203 	movx	@dptr,a
      00AB0A 90 C3 F3         [24] 1204 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_217
      00AB0D 75 F0 80         [24] 1205 	mov	b, #0x80
      00AB10 31 EB            [24] 1206 	acall	_find_alt_keycode
      00AB12 AF 82            [24] 1207 	mov	r7, dpl
      00AB14 90 0C B7         [24] 1208 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AB17 EF               [12] 1209 	mov	a,r7
      00AB18 12 38 59         [24] 1210 	lcall	_ak820_outline_0129
      00AB1B                       1211 00110$:
                                   1212 ;	quantum/repeat_key.c:274: if (alt_keycode) {
      00AB1B 90 0C B7         [24] 1213 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AB1E 12 37 FD         [24] 1214 	lcall	_ak820_outline_0056
      00AB21 90 0C B7         [24] 1215 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AB24 12 73 11         [24] 1216 	lcall	_ak820_outline_0040
      00AB27 60 0F            [24] 1217 	jz	00114$
                                   1218 ;	quantum/repeat_key.c:276: return (mods << 8) | alt_keycode;
      00AB29 90 0C B6         [24] 1219 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00AB2C E0               [24] 1220 	movx	a,@dptr
      00AB2D FD               [12] 1221 	mov	r5,a
      00AB2E E4               [12] 1222 	clr	a
      00AB2F 42 06            [12] 1223 	orl	ar6,a
      00AB31 ED               [12] 1224 	mov	a,r5
      00AB32 42 07            [12] 1225 	orl	ar7,a
      00AB34 12 49 5D         [24] 1226 	lcall	_ak820_outline_0120
      00AB37 22               [24] 1227 	ret
      00AB38                       1228 00114$:
                                   1229 ;	quantum/repeat_key.c:280: return KC_NO; // No alternate key found.
      00AB38 90 00 00         [24] 1230 	mov	dptr,#0x0000
                                   1231 ;	quantum/repeat_key.c:281: }
      00AB3B 22               [24] 1232 	ret
                                   1233 ;------------------------------------------------------------
                                   1234 ;Allocation info for local variables in function 'alt_repeat_key_invoke'
                                   1235 ;------------------------------------------------------------
                                   1236 ;event         Allocated with name '_alt_repeat_key_invoke_event_10000_220'
                                   1237 ;------------------------------------------------------------
                                   1238 ;	quantum/repeat_key.c:283: void alt_repeat_key_invoke(const keyevent_t* event) {
                                   1239 ;	-----------------------------------------
                                   1240 ;	 function alt_repeat_key_invoke
                                   1241 ;	-----------------------------------------
      00AB3C                       1242 _alt_repeat_key_invoke:
      00AB3C 12 49 1A         [24] 1243 	lcall	_ak820_outline_0038
      00AB3F 90 0C B9         [24] 1244 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00AB42 12 37 E5         [24] 1245 	lcall	_ak820_outline_0020
                                   1246 ;	quantum/repeat_key.c:285: repeat_invoke(event, true);
      00AB45 90 0C B9         [24] 1247 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00AB48 12 54 C2         [24] 1248 	lcall	_ak820_outline_0014
      00AB4B 90 0C A8         [24] 1249 	mov	dptr,#_repeat_invoke_PARM_2
      00AB4E 74 01            [12] 1250 	mov	a,#0x01
      00AB50 F0               [24] 1251 	movx	@dptr,a
      00AB51 12 54 CB         [24] 1252 	lcall	_ak820_outline_0049
                                   1253 ;	quantum/repeat_key.c:286: }
      00AB54 01 BB            [12] 1254 	ajmp	_repeat_invoke
                                   1255 ;------------------------------------------------------------
                                   1256 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode_user'
                                   1257 ;------------------------------------------------------------
                                   1258 ;mods          Allocated with name '_get_alt_repeat_key_keycode_user_PARM_2'
                                   1259 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_user_keycode_10000_222'
                                   1260 ;------------------------------------------------------------
                                   1261 ;	quantum/repeat_key.c:289: __attribute__((weak)) uint16_t get_alt_repeat_key_keycode_user(uint16_t keycode, uint8_t mods) {
                                   1262 ;	-----------------------------------------
                                   1263 ;	 function get_alt_repeat_key_keycode_user
                                   1264 ;	-----------------------------------------
      00AB56                       1265 _get_alt_repeat_key_keycode_user:
                                   1266 ;	quantum/repeat_key.c:290: return KC_TRANSPARENT;
      00AB56 90 00 01         [24] 1267 	mov	dptr,#0x0001
                                   1268 ;	quantum/repeat_key.c:291: }
      00AB59 22               [24] 1269 	ret
                                   1270 	.area CSEG    (CODE)
                                   1271 	.area CONST   (CODE)
                                   1272 	.area CONST   (CODE)
      00C3E1                       1273 _get_alt_repeat_key_keycode_pairs_50000_214:
      00C3E1 09                    1274 	.db #0x09	; 9
      00C3E2 05                    1275 	.db #0x05	; 5
      00C3E3 07                    1276 	.db #0x07	; 7
      00C3E4 18                    1277 	.db #0x18	; 24
      00C3E5 11                    1278 	.db #0x11	; 17
      00C3E6 13                    1279 	.db #0x13	; 19
      00C3E7 04                    1280 	.db #0x04	; 4
      00C3E8 08                    1281 	.db #0x08	; 8
      00C3E9 12                    1282 	.db #0x12	; 18
      00C3EA 0C                    1283 	.db #0x0c	; 12
                                   1284 	.area CSEG    (CODE)
                                   1285 	.area CONST   (CODE)
      00C3EB                       1286 _get_alt_repeat_key_keycode_pairs_50000_215:
      00C3EB 0D                    1287 	.db #0x0d	; 13
      00C3EC 0E                    1288 	.db #0x0e	; 14
      00C3ED 0B                    1289 	.db #0x0b	; 11
      00C3EE 0F                    1290 	.db #0x0f	; 15
      00C3EF 1A                    1291 	.db #0x1a	; 26
      00C3F0 05                    1292 	.db #0x05	; 5
      00C3F1 08                    1293 	.db #0x08	; 8
      00C3F2 05                    1294 	.db #0x05	; 5
                                   1295 	.area CSEG    (CODE)
                                   1296 	.area CONST   (CODE)
      00C3F3                       1297 _get_alt_repeat_key_keycode_pairs_50000_217:
      00C3F3 50                    1298 	.db #0x50	; 80	'P'
      00C3F4 4F                    1299 	.db #0x4f	; 79	'O'
      00C3F5 52                    1300 	.db #0x52	; 82	'R'
      00C3F6 51                    1301 	.db #0x51	; 81	'Q'
      00C3F7 4A                    1302 	.db #0x4a	; 74	'J'
      00C3F8 4D                    1303 	.db #0x4d	; 77	'M'
      00C3F9 4B                    1304 	.db #0x4b	; 75	'K'
      00C3FA 4E                    1305 	.db #0x4e	; 78	'N'
      00C3FB 2A                    1306 	.db #0x2a	; 42
      00C3FC 4C                    1307 	.db #0x4c	; 76	'L'
      00C3FD 2F                    1308 	.db #0x2f	; 47
      00C3FE 30                    1309 	.db #0x30	; 48	'0'
      00C3FF B6                    1310 	.db #0xb6	; 182
      00C400 B7                    1311 	.db #0xb7	; 183
      00C401 AB                    1312 	.db #0xab	; 171
      00C402 AC                    1313 	.db #0xac	; 172
      00C403 BB                    1314 	.db #0xbb	; 187
      00C404 BC                    1315 	.db #0xbc	; 188
      00C405 A9                    1316 	.db #0xa9	; 169
      00C406 AA                    1317 	.db #0xaa	; 170
      00C407 BD                    1318 	.db #0xbd	; 189
      00C408 BE                    1319 	.db #0xbe	; 190
                                   1320 	.area CSEG    (CODE)
                                   1321 	.area XINIT   (CODE)
      00C86E                       1322 __xinit__last_mods:
      00C86E 00                    1323 	.db #0x00	; 0
      00C86F                       1324 __xinit__last_repeat_count:
      00C86F 00                    1325 	.db #0x00	;  0
      00C870                       1326 __xinit__processing_repeat_count:
      00C870 00                    1327 	.db #0x00	;  0
                                   1328 	.area CABS    (ABS,CODE)
                                   1329 
                                   1330 ; Experimental exact instruction outlining.
                                   1331 	.globl _ak820_outline_0009
                                   1332 	.globl _ak820_outline_0014
                                   1333 	.globl _ak820_outline_0020
                                   1334 	.globl _ak820_outline_0027
                                   1335 	.globl _ak820_outline_0028
                                   1336 	.globl _ak820_outline_0038
                                   1337 	.globl _ak820_outline_0040
                                   1338 	.globl _ak820_outline_0049
                                   1339 	.globl _ak820_outline_0056
                                   1340 	.globl _ak820_outline_0063
                                   1341 	.globl _ak820_outline_0064
                                   1342 	.globl _ak820_outline_0074
                                   1343 	.globl _ak820_outline_0078
                                   1344 	.globl _ak820_outline_0109
                                   1345 	.globl _ak820_outline_0110
                                   1346 	.globl _ak820_outline_0113
                                   1347 	.globl _ak820_outline_0120
                                   1348 	.globl _ak820_outline_0128
                                   1349 	.globl _ak820_outline_0129
                                   1350 	.globl _ak820_outline_0154
                                   1351 	.globl _ak820_outline_0155
                                   1352 	.globl _ak820_outline_0179
                                   1353 	.globl _ak820_outline_0196
                                   1354 
                                   1355 	.area CSEG (CODE)
                                   1356 ; function ak820_outline_0179
      00AB5A                       1357 _ak820_outline_0179:
      00AB5A 90 0C 9D         [24] 1358 	mov	dptr,#(_registered_record+0x0007)
      00AB5D E0               [24] 1359 	movx	a,@dptr
      00AB5E FB               [12] 1360 	mov	r3,a
      00AB5F A3               [24] 1361 	inc	dptr
      00AB60 E0               [24] 1362 	movx	a,@dptr
      00AB61 4B               [12] 1363 	orl	a,r3
      00AB62 22               [24] 1364 	ret
