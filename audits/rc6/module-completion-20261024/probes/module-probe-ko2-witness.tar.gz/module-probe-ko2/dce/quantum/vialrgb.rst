                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      000053                        535 _fast_set_leds_sloc0_1_0:
      000053                        536 	.ds 2
      000055                        537 _fast_set_leds_sloc1_1_0:
      000055                        538 	.ds 2
      000057                        539 _vialrgb_get_value_sloc0_1_0:
      000057                        540 	.ds 2
      000059                        541 _vialrgb_get_value_sloc1_1_0:
      000059                        542 	.ds 2
      00005B                        543 _vialrgb_set_value_sloc0_1_0:
      00005B                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000D1B                        569 _g_direct_mode_colors::
      000D1B                        570 	.ds 246
      000E11                        571 _get_supported_PARM_2:
      000E11                        572 	.ds 1
      000E12                        573 _get_supported_args_10000_255:
      000E12                        574 	.ds 2
      000E14                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000E14                        576 	.ds 2
      000E16                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000E16                        578 	.ds 2
      000E18                        579 _set_mode_mode_10000_275:
      000E18                        580 	.ds 2
      000E1A                        581 _get_matrix_pos_for_led_PARM_2:
      000E1A                        582 	.ds 2
      000E1C                        583 _get_matrix_pos_for_led_led_10000_280:
      000E1C                        584 	.ds 2
      000E1E                        585 _fast_set_leds_PARM_2:
      000E1E                        586 	.ds 1
      000E1F                        587 _fast_set_leds_args_10000_282:
      000E1F                        588 	.ds 2
      000E21                        589 _fast_set_leds_first_index_10001_285:
      000E21                        590 	.ds 2
      000E23                        591 _fast_set_leds_num_leds_10001_285:
      000E23                        592 	.ds 1
      000E24                        593 _vialrgb_get_value_PARM_2:
      000E24                        594 	.ds 1
      000E25                        595 _vialrgb_get_value_data_10000_291:
      000E25                        596 	.ds 3
      000E28                        597 _vialrgb_set_value_PARM_2:
      000E28                        598 	.ds 1
      000E29                        599 _vialrgb_set_value_data_10000_302:
      000E29                        600 	.ds 3
      000E2C                        601 _vialrgb_save_PARM_2:
      000E2C                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B9AE                        654 _get_supported:
      00B9AE 12 38 44         [24]  655 	lcall	_ak820_outline_0109
      00B9B1 90 0E 12         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B9B4 12 38 49         [24]  657 	lcall	_ak820_outline_0110
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B9B7 90 0E 12         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B9BA 12 37 BE         [24]  660 	lcall	_ak820_outline_0007
      00B9BD E0               [24]  661 	movx	a,@dptr
      00B9BE FD               [12]  662 	mov	r5,a
      00B9BF 7C 00            [12]  663 	mov	r4,#0x00
      00B9C1 12 38 38         [24]  664 	lcall	_ak820_outline_0103
      00B9C4 E0               [24]  665 	movx	a,@dptr
      00B9C5 FA               [12]  666 	mov	r2,a
      00B9C6 E4               [12]  667 	clr	a
      00B9C7 12 49 79         [24]  668 	lcall	_ak820_outline_0147
                                    669 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B9CA 90 0E 11         [24]  670 	mov	dptr,#_get_supported_PARM_2
      00B9CD E0               [24]  671 	movx	a,@dptr
      00B9CE FB               [12]  672 	mov	r3,a
      00B9CF 7A 00            [12]  673 	mov	r2,#0x00
      00B9D1                        674 00107$:
      00B9D1 C3               [12]  675 	clr	c
      00B9D2 EA               [12]  676 	mov	a,r2
      00B9D3 9B               [12]  677 	subb	a,r3
      00B9D4 50 0A            [24]  678 	jnc	00101$
      00B9D6 EA               [12]  679 	mov	a,r2
      00B9D7 12 37 ED         [24]  680 	lcall	_ak820_outline_0033
      00B9DA 74 FF            [12]  681 	mov	a,#0xff
      00B9DC F0               [24]  682 	movx	@dptr,a
      00B9DD 0A               [12]  683 	inc	r2
      00B9DE 80 F1            [24]  684 	sjmp	00107$
      00B9E0                        685 00101$:
                                    686 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B9E0 8D 06            [24]  687 	mov	ar6,r5
      00B9E2 8C 07            [24]  688 	mov	ar7,r4
      00B9E4 8B 05            [24]  689 	mov	ar5,r3
      00B9E6 90 0E 12         [24]  690 	mov	dptr,#_get_supported_args_10000_255
      00B9E9 12 38 63         [24]  691 	lcall	_ak820_outline_0145
      00B9EC 7A 00            [12]  692 	mov	r2,#0x00
      00B9EE                        693 00110$:
      00B9EE BA 07 00         [24]  694 	cjne	r2,#0x07,00159$
      00B9F1                        695 00159$:
      00B9F1 50 46            [24]  696 	jnc	00127$
                                    697 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B9F3 EA               [12]  698 	mov	a,r2
      00B9F4 75 F0 02         [24]  699 	mov	b,#0x02
      00B9F7 A4               [48]  700 	mul	ab
      00B9F8 24 45            [12]  701 	add	a, #_supported_modes
      00B9FA F5 82            [12]  702 	mov	dpl,a
      00B9FC 74 C6            [12]  703 	mov	a,#(_supported_modes >> 8)
      00B9FE 12 5C C7         [24]  704 	lcall	_ak820_outline_0111
      00BA01 F8               [12]  705 	mov	r0,a
      00BA02 79 00            [12]  706 	mov	r1,#0x00
                                    707 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00BA04 C3               [12]  708 	clr	c
      00BA05 EE               [12]  709 	mov	a,r6
      00BA06 98               [12]  710 	subb	a,r0
      00BA07 EF               [12]  711 	mov	a,r7
      00BA08 99               [12]  712 	subb	a,r1
      00BA09 50 2B            [24]  713 	jnc	00111$
                                    714 ;	free result
      00BA0B BD 02 00         [24]  715 	cjne	r5,#0x02,00162$
      00BA0E                        716 00162$:
      00BA0E 40 26            [24]  717 	jc	00111$
                                    718 ;	quantum/vialrgb.c:49: args[0] = id;
      00BA10 C0 06            [24]  719 	push	ar6
      00BA12 C0 07            [24]  720 	push	ar7
      00BA14 88 07            [24]  721 	mov	ar7,r0
      00BA16 12 33 FC         [24]  722 	lcall	_ak820_outline_0127
      00BA19 EF               [12]  723 	mov	a,r7
      00BA1A F0               [24]  724 	movx	@dptr,a
                                    725 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00BA1B 12 33 FC         [24]  726 	lcall	_ak820_outline_0127
      00BA1E A3               [24]  727 	inc	dptr
      00BA1F 89 00            [24]  728 	mov	ar0,r1
      00BA21 E8               [12]  729 	mov	a,r0
      00BA22 F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00BA23 1D               [12]  732 	dec	r5
      00BA24 1D               [12]  733 	dec	r5
                                    734 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00BA25 74 02            [12]  735 	mov	a,#0x02
      00BA27 2B               [12]  736 	add	a, r3
      00BA28 FB               [12]  737 	mov	r3,a
      00BA29 E4               [12]  738 	clr	a
      00BA2A 3C               [12]  739 	addc	a, r4
      00BA2B FC               [12]  740 	mov	r4,a
      00BA2C 90 0E 12         [24]  741 	mov	dptr,#_get_supported_args_10000_255
      00BA2F 12 38 2C         [24]  742 	lcall	_ak820_outline_0095
                                    743 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BA32 D0 07            [24]  744 	pop	ar7
      00BA34 D0 06            [24]  745 	pop	ar6
                                    746 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00BA36                        747 00111$:
                                    748 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BA36 0A               [12]  749 	inc	r2
      00BA37 80 B5            [24]  750 	sjmp	00110$
      00BA39                        751 00127$:
      00BA39 90 0E 12         [24]  752 	mov	dptr,#_get_supported_args_10000_255
      00BA3C 12 38 2C         [24]  753 	lcall	_ak820_outline_0095
                                    754 ;	quantum/vialrgb.c:55: }
      00BA3F 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    758 ;------------------------------------------------------------
                                    759 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    760 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    761 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function qmk_id_to_vialrgb_id
                                    766 ;	-----------------------------------------
      00BA40                        767 _qmk_id_to_vialrgb_id:
      00BA40 12 38 44         [24]  768 	lcall	_ak820_outline_0109
      00BA43 90 0E 14         [24]  769 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00BA46 12 38 49         [24]  770 	lcall	_ak820_outline_0110
                                    771 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BA49 90 0E 14         [24]  772 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00BA4C 12 37 FD         [24]  773 	lcall	_ak820_outline_0056
      00BA4F 7D 00            [12]  774 	mov	r5,#0x00
      00BA51                        775 00105$:
      00BA51 BD 07 00         [24]  776 	cjne	r5,#0x07,00130$
      00BA54                        777 00130$:
      00BA54 50 19            [24]  778 	jnc	00103$
                                    779 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00BA56 12 BE 6D         [24]  780 	lcall	_ak820_outline_0050
      00BA59 A3               [24]  781 	inc	dptr
      00BA5A E4               [12]  782 	clr	a
      00BA5B 93               [24]  783 	movc	a,@a+dptr
                                    784 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00BA5C 7A 00            [12]  785 	mov	r2,#0x00
      00BA5E B5 06 0B         [24]  786 	cjne	a,ar6,00106$
      00BA61 EA               [12]  787 	mov	a,r2
      00BA62 B5 07 07         [24]  788 	cjne	a,ar7,00106$
                                    789 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00BA65 12 33 FC         [24]  790 	lcall	_ak820_outline_0127
      00BA68 12 BE 99         [24]  791 	lcall	_ak820_outline_0150
      00BA6B 22               [24]  792 	ret
      00BA6C                        793 00106$:
                                    794 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BA6C 0D               [12]  795 	inc	r5
      00BA6D 80 E2            [24]  796 	sjmp	00105$
      00BA6F                        797 00103$:
                                    798 ;	quantum/vialrgb.c:63: return 0;
      00BA6F 90 00 00         [24]  799 	mov	dptr,#0x0000
                                    800 ;	quantum/vialrgb.c:64: }
      00BA72 22               [24]  801 	ret
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    804 ;------------------------------------------------------------
                                    805 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    806 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    807 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function vialrgb_id_to_qmk_id
                                    812 ;	-----------------------------------------
      00BA73                        813 _vialrgb_id_to_qmk_id:
      00BA73 12 38 44         [24]  814 	lcall	_ak820_outline_0109
      00BA76 90 0E 16         [24]  815 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00BA79 12 38 49         [24]  816 	lcall	_ak820_outline_0110
                                    817 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BA7C 90 0E 16         [24]  818 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00BA7F 12 37 FD         [24]  819 	lcall	_ak820_outline_0056
      00BA82 7D 00            [12]  820 	mov	r5,#0x00
      00BA84                        821 00105$:
      00BA84 BD 07 00         [24]  822 	cjne	r5,#0x07,00130$
      00BA87                        823 00130$:
      00BA87 50 19            [24]  824 	jnc	00103$
                                    825 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00BA89 12 BE 6D         [24]  826 	lcall	_ak820_outline_0050
      00BA8C E4               [12]  827 	clr	a
      00BA8D 93               [24]  828 	movc	a,@a+dptr
                                    829 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00BA8E 7A 00            [12]  830 	mov	r2,#0x00
      00BA90 B5 06 0C         [24]  831 	cjne	a,ar6,00106$
      00BA93 EA               [12]  832 	mov	a,r2
      00BA94 B5 07 08         [24]  833 	cjne	a,ar7,00106$
                                    834 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00BA97 12 33 FC         [24]  835 	lcall	_ak820_outline_0127
      00BA9A A3               [24]  836 	inc	dptr
      00BA9B 12 BE 99         [24]  837 	lcall	_ak820_outline_0150
      00BA9E 22               [24]  838 	ret
      00BA9F                        839 00106$:
                                    840 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BA9F 0D               [12]  841 	inc	r5
      00BAA0 80 E2            [24]  842 	sjmp	00105$
      00BAA2                        843 00103$:
                                    844 ;	quantum/vialrgb.c:72: return 0;
      00BAA2 90 00 00         [24]  845 	mov	dptr,#0x0000
                                    846 ;	quantum/vialrgb.c:73: }
      00BAA5 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'get_mode'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function get_mode
                                    854 ;	-----------------------------------------
      00BAA6                        855 _get_mode:
                                    856 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00BAA6 12 5A CA         [24]  857 	lcall	_rgb_matrix_is_enabled
      00BAA9 E5 82            [12]  858 	mov	a, dpl
      00BAAB 70 04            [24]  859 	jnz	00102$
                                    860 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00BAAD 90 00 00         [24]  861 	mov	dptr,#0x0000
      00BAB0 22               [24]  862 	ret
      00BAB1                        863 00102$:
                                    864 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00BAB1 12 5A D0         [24]  865 	lcall	_rgb_matrix_get_mode
      00BAB4 7E 00            [12]  866 	mov	r6,#0x00
      00BAB6 8E 83            [24]  867 	mov	dph, r6
                                    868 ;	quantum/vialrgb.c:80: }
      00BAB8 41 40            [12]  869 	ajmp	_qmk_id_to_vialrgb_id
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'set_mode'
                                    872 ;------------------------------------------------------------
                                    873 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    874 ;------------------------------------------------------------
                                    875 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    876 ;	-----------------------------------------
                                    877 ;	 function set_mode
                                    878 ;	-----------------------------------------
      00BABA                        879 _set_mode:
      00BABA 12 38 44         [24]  880 	lcall	_ak820_outline_0109
      00BABD 90 0E 18         [24]  881 	mov	dptr,#_set_mode_mode_10000_275
      00BAC0 12 38 49         [24]  882 	lcall	_ak820_outline_0110
                                    883 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00BAC3 90 0E 18         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00BAC6 12 37 FD         [24]  885 	lcall	_ak820_outline_0056
      00BAC9 90 0E 18         [24]  886 	mov	dptr,#_set_mode_mode_10000_275
      00BACC 12 73 11         [24]  887 	lcall	_ak820_outline_0040
      00BACF 70 03            [24]  888 	jnz	00102$
                                    889 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00BAD1 02 5B 1D         [24]  890 	ljmp	_rgb_matrix_disable_noeeprom
      00BAD4                        891 00102$:
                                    892 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00BAD4 C0 07            [24]  893 	push	ar7
      00BAD6 C0 06            [24]  894 	push	ar6
      00BAD8 12 5B 0C         [24]  895 	lcall	_rgb_matrix_enable_noeeprom
      00BADB D0 06            [24]  896 	pop	ar6
      00BADD D0 07            [24]  897 	pop	ar7
                                    898 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00BADF 12 49 5D         [24]  899 	lcall	_ak820_outline_0120
      00BAE2 51 73            [12]  900 	acall	_vialrgb_id_to_qmk_id
                                    901 ;	quantum/vialrgb.c:90: }
      00BAE4 02 5B 26         [24]  902 	ljmp	_rgb_matrix_mode_noeeprom
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    905 ;------------------------------------------------------------
                                    906 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    907 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    908 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    909 ;------------------------------------------------------------
                                    910 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    911 ;	-----------------------------------------
                                    912 ;	 function get_matrix_pos_for_led
                                    913 ;	-----------------------------------------
      00BAE7                        914 _get_matrix_pos_for_led:
      00BAE7 12 38 44         [24]  915 	lcall	_ak820_outline_0109
      00BAEA 90 0E 1C         [24]  916 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00BAED 12 38 49         [24]  917 	lcall	_ak820_outline_0110
                                    918 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00BAF0 90 0E 1C         [24]  919 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00BAF3 12 37 FD         [24]  920 	lcall	_ak820_outline_0056
      00BAF6 EE               [12]  921 	mov	a,r6
      00BAF7 24 4C            [12]  922 	add	a, #_ak820_rgb_slots
      00BAF9 F5 82            [12]  923 	mov	dpl,a
      00BAFB EF               [12]  924 	mov	a,r7
      00BAFC 34 C0            [12]  925 	addc	a, #(_ak820_rgb_slots >> 8)
      00BAFE F5 83            [12]  926 	mov	dph,a
      00BB00 E4               [12]  927 	clr	a
      00BB01 93               [24]  928 	movc	a,@a+dptr
      00BB02 FF               [12]  929 	mov	r7,a
                                    930 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00BB03 90 0E 1A         [24]  931 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BB06 12 38 26         [24]  932 	lcall	_ak820_outline_0081
      00BB09 12 86 C9         [24]  933 	lcall	_ak820_outline_0170
      00BB0C 12 86 A6         [24]  934 	lcall	_ak820_outline_0102
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00BB0F 12 38 5E         [24]  936 	lcall	_ak820_outline_0138
      00BB12 A3               [24]  937 	inc	dptr
      00BB13 53 07 07         [24]  938 	anl	ar7,#0x07
      00BB16 EF               [12]  939 	mov	a,r7
      00BB17 F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00BB18 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00BB19                        960 _fast_set_leds:
      00BB19 12 38 44         [24]  961 	lcall	_ak820_outline_0109
      00BB1C 90 0E 1F         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00BB1F 12 38 49         [24]  963 	lcall	_ak820_outline_0110
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00BB22 90 0E 1E         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00BB25 E0               [24]  966 	movx	a,@dptr
      00BB26 FF               [12]  967 	mov	r7,a
      00BB27 BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00BB2A                        969 00159$:
      00BB2A 50 01            [24]  970 	jnc	00102$
      00BB2C 22               [24]  971 	ret
      00BB2D                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BB2D 90 0E 1F         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00BB30 12 38 26         [24]  975 	lcall	_ak820_outline_0081
      00BB33 12 4E 83         [24]  976 	lcall	_ak820_outline_0076
      00BB36 7B 00            [12]  977 	mov	r3,#0x00
      00BB38 12 38 5E         [24]  978 	lcall	_ak820_outline_0138
      00BB3B A3               [24]  979 	inc	dptr
      00BB3C E0               [24]  980 	movx	a,@dptr
      00BB3D FA               [12]  981 	mov	r2,a
      00BB3E 79 00            [12]  982 	mov	r1,#0x00
      00BB40 90 0E 21         [24]  983 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BB43 E9               [12]  984 	mov	a,r1
      00BB44 4C               [12]  985 	orl	a,r4
      00BB45 F0               [24]  986 	movx	@dptr,a
      00BB46 EA               [12]  987 	mov	a,r2
      00BB47 4B               [12]  988 	orl	a,r3
      00BB48 A3               [24]  989 	inc	dptr
      00BB49 F0               [24]  990 	movx	@dptr,a
                                    991 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00BB4A 12 38 5E         [24]  992 	lcall	_ak820_outline_0138
      00BB4D A3               [24]  993 	inc	dptr
      00BB4E A3               [24]  994 	inc	dptr
      00BB4F E0               [24]  995 	movx	a,@dptr
      00BB50 90 0E 23         [24]  996 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BB53 F0               [24]  997 	movx	@dptr,a
                                    998 ;	quantum/vialrgb.c:119: length -= 3;
      00BB54 EF               [12]  999 	mov	a,r7
      00BB55 24 FD            [12] 1000 	add	a,#0xfd
      00BB57 90 0E 1E         [24] 1001 	mov	dptr,#_fast_set_leds_PARM_2
      00BB5A F0               [24] 1002 	movx	@dptr,a
                                   1003 ;	quantum/vialrgb.c:120: args += 3;
      00BB5B 90 0E 1F         [24] 1004 	mov	dptr,#_fast_set_leds_args_10000_282
      00BB5E 74 03            [12] 1005 	mov	a,#0x03
      00BB60 2D               [12] 1006 	add	a, r5
      00BB61 F0               [24] 1007 	movx	@dptr,a
      00BB62 E4               [12] 1008 	clr	a
      00BB63 3E               [12] 1009 	addc	a, r6
      00BB64 A3               [24] 1010 	inc	dptr
      00BB65 F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00BB66 90 0E 23         [24] 1013 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BB69 E0               [24] 1014 	movx	a,@dptr
      00BB6A FF               [12] 1015 	mov	r7,a
      00BB6B 75 F0 03         [24] 1016 	mov	b,#0x03
      00BB6E A4               [48] 1017 	mul	ab
      00BB6F FE               [12] 1018 	mov	r6,a
      00BB70 AD F0            [24] 1019 	mov	r5,b
      00BB72 90 0E 1E         [24] 1020 	mov	dptr,#_fast_set_leds_PARM_2
      00BB75 E0               [24] 1021 	movx	a,@dptr
      00BB76 FB               [12] 1022 	mov	r3,a
      00BB77 7C 00            [12] 1023 	mov	r4,#0x00
      00BB79 C3               [12] 1024 	clr	c
      00BB7A EB               [12] 1025 	mov	a,r3
      00BB7B 9E               [12] 1026 	subb	a,r6
      00BB7C EC               [12] 1027 	mov	a,r4
      00BB7D 9D               [12] 1028 	subb	a,r5
      00BB7E 40 13            [24] 1029 	jc	00103$
                                   1030 ;	free result
      00BB80 90 0E 21         [24] 1031 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BB83 12 38 26         [24] 1032 	lcall	_ak820_outline_0081
      00BB86 8D 03            [24] 1033 	mov	ar3,r5
      00BB88 8E 04            [24] 1034 	mov	ar4,r6
      00BB8A C3               [12] 1035 	clr	c
      00BB8B EB               [12] 1036 	mov	a,r3
      00BB8C 94 52            [12] 1037 	subb	a,#0x52
      00BB8E EC               [12] 1038 	mov	a,r4
      00BB8F 94 00            [12] 1039 	subb	a,#0x00
      00BB91 40 01            [24] 1040 	jc	00104$
      00BB93                       1041 00103$:
      00BB93 22               [24] 1042 	ret
      00BB94                       1043 00104$:
                                   1044 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00BB94 74 52            [12] 1045 	mov	a,#0x52
      00BB96 C3               [12] 1046 	clr	c
      00BB97 9D               [12] 1047 	subb	a,r5
      00BB98 FB               [12] 1048 	mov	r3,a
      00BB99 E4               [12] 1049 	clr	a
      00BB9A 9E               [12] 1050 	subb	a,r6
      00BB9B FC               [12] 1051 	mov	r4,a
      00BB9C 7A 00            [12] 1052 	mov	r2,#0x00
      00BB9E C3               [12] 1053 	clr	c
      00BB9F EB               [12] 1054 	mov	a,r3
      00BBA0 9F               [12] 1055 	subb	a,r7
      00BBA1 EC               [12] 1056 	mov	a,r4
      00BBA2 9A               [12] 1057 	subb	a,r2
      00BBA3 50 08            [24] 1058 	jnc	00127$
                                   1059 ;	free result
      00BBA5 90 0E 23         [24] 1060 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BBA8 74 52            [12] 1061 	mov	a,#0x52
      00BBAA C3               [12] 1062 	clr	c
      00BBAB 9D               [12] 1063 	subb	a,r5
      00BBAC F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BBAD                       1066 00127$:
      00BBAD 90 0E 23         [24] 1067 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BBB0 E0               [24] 1068 	movx	a,@dptr
      00BBB1 FF               [12] 1069 	mov	r7,a
      00BBB2 90 0E 21         [24] 1070 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BBB5 12 38 26         [24] 1071 	lcall	_ak820_outline_0081
      00BBB8 7C 00            [12] 1072 	mov	r4,#0x00
      00BBBA                       1073 00110$:
      00BBBA C3               [12] 1074 	clr	c
      00BBBB EC               [12] 1075 	mov	a,r4
      00BBBC 9F               [12] 1076 	subb	a,r7
      00BBBD 40 01            [24] 1077 	jc	00164$
      00BBBF 22               [24] 1078 	ret
      00BBC0                       1079 00164$:
                                   1080 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00BBC0 C0 07            [24] 1081 	push	ar7
      00BBC2 90 0E 3B         [24] 1082 	mov	dptr,#__mulint_PARM_2
      00BBC5 12 49 99         [24] 1083 	lcall	_ak820_outline_0169
      00BBC8 90 00 03         [24] 1084 	mov	dptr,#0x0003
      00BBCB C0 07            [24] 1085 	push	ar7
      00BBCD C0 06            [24] 1086 	push	ar6
      00BBCF C0 05            [24] 1087 	push	ar5
      00BBD1 C0 04            [24] 1088 	push	ar4
      00BBD3 12 BF FC         [24] 1089 	lcall	__mulint
      00BBD6 AA 82            [24] 1090 	mov	r2, dpl
      00BBD8 AB 83            [24] 1091 	mov	r3, dph
      00BBDA D0 04            [24] 1092 	pop	ar4
      00BBDC D0 05            [24] 1093 	pop	ar5
      00BBDE D0 06            [24] 1094 	pop	ar6
      00BBE0 D0 07            [24] 1095 	pop	ar7
      00BBE2 0D               [12] 1096 	inc	r5
      00BBE3 BD 00 01         [24] 1097 	cjne	r5,#0x00,00165$
      00BBE6 0E               [12] 1098 	inc	r6
      00BBE7                       1099 00165$:
      00BBE7 EA               [12] 1100 	mov	a,r2
      00BBE8 24 1B            [12] 1101 	add	a, #_g_direct_mode_colors
      00BBEA FA               [12] 1102 	mov	r2,a
      00BBEB EB               [12] 1103 	mov	a,r3
      00BBEC 34 0D            [12] 1104 	addc	a, #(_g_direct_mode_colors >> 8)
      00BBEE FB               [12] 1105 	mov	r3,a
                                   1106 ;	quantum/vialrgb.c:128: color->h = *args++;
      00BBEF 8A 53            [24] 1107 	mov	_fast_set_leds_sloc0_1_0,r2
      00BBF1 8B 54            [24] 1108 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00BBF3 12 BE 7F         [24] 1109 	lcall	_ak820_outline_0085
      00BBF6 F8               [12] 1110 	mov	r0,a
      00BBF7 12 BE 8D         [24] 1111 	lcall	_ak820_outline_0108
      00BBFA 85 53 82         [24] 1112 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BBFD 85 54 83         [24] 1113 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BC00 E8               [12] 1114 	mov	a,r0
      00BC01 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/vialrgb.c:129: color->s = *args++;
      00BC02 74 01            [12] 1117 	mov	a,#0x01
      00BC04 2A               [12] 1118 	add	a, r2
      00BC05 F5 53            [12] 1119 	mov	_fast_set_leds_sloc0_1_0,a
      00BC07 E4               [12] 1120 	clr	a
      00BC08 3B               [12] 1121 	addc	a, r3
      00BC09 F5 54            [12] 1122 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00BC0B 90 0E 1F         [24] 1123 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC0E E0               [24] 1124 	movx	a,@dptr
      00BC0F F8               [12] 1125 	mov	r0,a
      00BC10 A3               [24] 1126 	inc	dptr
      00BC11 E0               [24] 1127 	movx	a,@dptr
      00BC12 FF               [12] 1128 	mov	r7,a
      00BC13 88 82            [24] 1129 	mov	dpl,r0
      00BC15 8F 83            [24] 1130 	mov	dph,r7
      00BC17 E0               [24] 1131 	movx	a,@dptr
      00BC18 F9               [12] 1132 	mov	r1,a
      00BC19 90 0E 1F         [24] 1133 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC1C 74 01            [12] 1134 	mov	a,#0x01
      00BC1E 28               [12] 1135 	add	a, r0
      00BC1F F0               [24] 1136 	movx	@dptr,a
      00BC20 E4               [12] 1137 	clr	a
      00BC21 3F               [12] 1138 	addc	a, r7
      00BC22 A3               [24] 1139 	inc	dptr
      00BC23 F0               [24] 1140 	movx	@dptr,a
      00BC24 85 53 82         [24] 1141 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BC27 85 54 83         [24] 1142 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BC2A E9               [12] 1143 	mov	a,r1
      00BC2B F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00BC2C 12 BE 7F         [24] 1146 	lcall	_ak820_outline_0085
      00BC2F F5 53            [12] 1147 	mov	_fast_set_leds_sloc0_1_0,a
      00BC31 12 BE 8D         [24] 1148 	lcall	_ak820_outline_0108
                                   1149 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00BC34 74 02            [12] 1150 	mov	a,#0x02
      00BC36 2A               [12] 1151 	add	a, r2
      00BC37 F5 55            [12] 1152 	mov	_fast_set_leds_sloc1_1_0,a
      00BC39 E4               [12] 1153 	clr	a
      00BC3A 3B               [12] 1154 	addc	a, r3
      00BC3B F5 56            [12] 1155 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00BC3D C3               [12] 1156 	clr	c
      00BC3E 74 A0            [12] 1157 	mov	a,#0xa0
      00BC40 95 53            [12] 1158 	subb	a,_fast_set_leds_sloc0_1_0
      00BC42 D0 07            [24] 1159 	pop	ar7
      00BC44 50 04            [24] 1160 	jnc	00114$
                                   1161 ;	free result
      00BC46 7B A0            [12] 1162 	mov	r3,#0xa0
      00BC48 80 04            [24] 1163 	sjmp	00115$
      00BC4A                       1164 00114$:
      00BC4A AA 53            [24] 1165 	mov	r2,_fast_set_leds_sloc0_1_0
      00BC4C 8A 03            [24] 1166 	mov	ar3,r2
      00BC4E                       1167 00115$:
      00BC4E 85 55 82         [24] 1168 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BC51 85 56 83         [24] 1169 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BC54 EB               [12] 1170 	mov	a,r3
      00BC55 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BC56 0C               [12] 1173 	inc	r4
                                   1174 ;	quantum/vialrgb.c:133: }
      00BC57 61 BA            [24] 1175 	ajmp	00110$
                                   1176 ;------------------------------------------------------------
                                   1177 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1178 ;------------------------------------------------------------
                                   1179 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1180 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1181 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1182 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1183 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1184 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1185 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1186 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1187 ;------------------------------------------------------------
                                   1188 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1189 ;	-----------------------------------------
                                   1190 ;	 function vialrgb_get_value
                                   1191 ;	-----------------------------------------
      00BC59                       1192 _vialrgb_get_value:
      00BC59 12 49 1A         [24] 1193 	lcall	_ak820_outline_0038
      00BC5C 90 0E 25         [24] 1194 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BC5F 12 37 E5         [24] 1195 	lcall	_ak820_outline_0020
                                   1196 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BC62 90 0E 24         [24] 1197 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BC65 E0               [24] 1198 	movx	a,@dptr
      00BC66 FF               [12] 1199 	mov	r7,a
      00BC67 BF 20 02         [24] 1200 	cjne	r7,#0x20,00162$
      00BC6A 80 01            [24] 1201 	sjmp	00102$
      00BC6C                       1202 00162$:
      00BC6C 22               [24] 1203 	ret
      00BC6D                       1204 00102$:
                                   1205 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BC6D 90 0E 25         [24] 1206 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BC70 12 BE 59         [24] 1207 	lcall	_ak820_outline_0048
                                   1208 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1209 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BC73 BA 40 02         [24] 1210 	cjne	r2,#0x40,00163$
      00BC76 80 15            [24] 1211 	sjmp	00103$
      00BC78                       1212 00163$:
      00BC78 BA 41 02         [24] 1213 	cjne	r2,#0x41,00164$
      00BC7B 80 23            [24] 1214 	sjmp	00104$
      00BC7D                       1215 00164$:
      00BC7D BA 42 02         [24] 1216 	cjne	r2,#0x42,00165$
      00BC80 A1 31            [12] 1217 	ajmp	00105$
      00BC82                       1218 00165$:
      00BC82 BA 43 02         [24] 1219 	cjne	r2,#0x43,00166$
      00BC85 A1 3D            [12] 1220 	ajmp	00106$
      00BC87                       1221 00166$:
      00BC87 BA 44 02         [24] 1222 	cjne	r2,#0x44,00167$
      00BC8A A1 49            [12] 1223 	ajmp	00107$
      00BC8C                       1224 00167$:
      00BC8C 22               [24] 1225 	ret
                                   1226 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BC8D                       1227 00103$:
                                   1228 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BC8D 12 33 FC         [24] 1229 	lcall	_ak820_outline_0127
      00BC90 74 01            [12] 1230 	mov	a,#0x01
      00BC92 F0               [24] 1231 	movx	@dptr,a
                                   1232 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BC93 12 BE 51         [24] 1233 	lcall	_ak820_outline_0039
      00BC96 E4               [12] 1234 	clr	a
      00BC97 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BC98 12 BE 51         [24] 1237 	lcall	_ak820_outline_0039
      00BC9B A3               [24] 1238 	inc	dptr
      00BC9C 74 A0            [12] 1239 	mov	a,#0xa0
      00BC9E F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/vialrgb.c:147: break;
      00BC9F 22               [24] 1242 	ret
                                   1243 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BCA0                       1244 00104$:
                                   1245 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BCA0 C0 06            [24] 1246 	push	ar6
      00BCA2 C0 05            [24] 1247 	push	ar5
      00BCA4 C0 04            [24] 1248 	push	ar4
      00BCA6 C0 03            [24] 1249 	push	ar3
      00BCA8 51 A6            [12] 1250 	acall	_get_mode
      00BCAA A9 82            [24] 1251 	mov	r1, dpl
      00BCAC AA 83            [24] 1252 	mov	r2, dph
      00BCAE D0 03            [24] 1253 	pop	ar3
      00BCB0 D0 04            [24] 1254 	pop	ar4
      00BCB2 D0 05            [24] 1255 	pop	ar5
      00BCB4 D0 06            [24] 1256 	pop	ar6
                                   1257 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BCB6 89 00            [24] 1258 	mov	ar0,r1
      00BCB8 12 33 FC         [24] 1259 	lcall	_ak820_outline_0127
      00BCBB E8               [12] 1260 	mov	a,r0
      00BCBC F0               [24] 1261 	movx	@dptr,a
                                   1262 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BCBD 12 BE 51         [24] 1263 	lcall	_ak820_outline_0039
      00BCC0 8A 01            [24] 1264 	mov	ar1,r2
      00BCC2 E9               [12] 1265 	mov	a,r1
      00BCC3 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BCC4 74 04            [12] 1268 	mov	a,#0x04
      00BCC6 12 95 C9         [24] 1269 	lcall	_ak820_outline_0140
      00BCC9 C0 06            [24] 1270 	push	ar6
      00BCCB C0 05            [24] 1271 	push	ar5
      00BCCD C0 02            [24] 1272 	push	ar2
      00BCCF C0 01            [24] 1273 	push	ar1
      00BCD1 12 5A EB         [24] 1274 	lcall	_rgb_matrix_get_speed
      00BCD4 A8 82            [24] 1275 	mov	r0, dpl
      00BCD6 D0 01            [24] 1276 	pop	ar1
      00BCD8 D0 02            [24] 1277 	pop	ar2
      00BCDA D0 05            [24] 1278 	pop	ar5
      00BCDC D0 06            [24] 1279 	pop	ar6
      00BCDE 12 86 7C         [24] 1280 	lcall	_ak820_outline_0066
                                   1281 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BCE1 74 05            [12] 1282 	mov	a,#0x05
      00BCE3 12 95 C9         [24] 1283 	lcall	_ak820_outline_0140
      00BCE6 C0 06            [24] 1284 	push	ar6
      00BCE8 C0 05            [24] 1285 	push	ar5
      00BCEA C0 02            [24] 1286 	push	ar2
      00BCEC C0 01            [24] 1287 	push	ar1
      00BCEE 12 5A D6         [24] 1288 	lcall	_rgb_matrix_get_hue
      00BCF1 A8 82            [24] 1289 	mov	r0, dpl
      00BCF3 D0 01            [24] 1290 	pop	ar1
      00BCF5 D0 02            [24] 1291 	pop	ar2
      00BCF7 D0 05            [24] 1292 	pop	ar5
      00BCF9 D0 06            [24] 1293 	pop	ar6
      00BCFB 12 86 7C         [24] 1294 	lcall	_ak820_outline_0066
                                   1295 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BCFE 74 06            [12] 1296 	mov	a,#0x06
      00BD00 12 95 C9         [24] 1297 	lcall	_ak820_outline_0140
      00BD03 C0 06            [24] 1298 	push	ar6
      00BD05 C0 05            [24] 1299 	push	ar5
      00BD07 C0 02            [24] 1300 	push	ar2
      00BD09 C0 01            [24] 1301 	push	ar1
      00BD0B 12 5A DD         [24] 1302 	lcall	_rgb_matrix_get_sat
      00BD0E A8 82            [24] 1303 	mov	r0, dpl
      00BD10 D0 01            [24] 1304 	pop	ar1
      00BD12 D0 02            [24] 1305 	pop	ar2
      00BD14 D0 05            [24] 1306 	pop	ar5
      00BD16 D0 06            [24] 1307 	pop	ar6
      00BD18 12 86 7C         [24] 1308 	lcall	_ak820_outline_0066
                                   1309 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BD1B 74 07            [12] 1310 	mov	a,#0x07
      00BD1D 12 95 C9         [24] 1311 	lcall	_ak820_outline_0140
      00BD20 C0 02            [24] 1312 	push	ar2
      00BD22 C0 01            [24] 1313 	push	ar1
      00BD24 12 5A E4         [24] 1314 	lcall	_rgb_matrix_get_val
      00BD27 A8 82            [24] 1315 	mov	r0, dpl
      00BD29 D0 01            [24] 1316 	pop	ar1
      00BD2B D0 02            [24] 1317 	pop	ar2
      00BD2D 12 86 7C         [24] 1318 	lcall	_ak820_outline_0066
                                   1319 ;	quantum/vialrgb.c:156: break;
      00BD30 22               [24] 1320 	ret
                                   1321 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BD31                       1322 00105$:
                                   1323 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BD31 EF               [12] 1324 	mov	a,r7
      00BD32 24 FE            [12] 1325 	add	a,#0xfe
      00BD34 90 0E 11         [24] 1326 	mov	dptr,#_get_supported_PARM_2
      00BD37 F0               [24] 1327 	movx	@dptr,a
      00BD38 12 33 FC         [24] 1328 	lcall	_ak820_outline_0127
                                   1329 ;	quantum/vialrgb.c:160: break;
      00BD3B 21 AE            [12] 1330 	ajmp	_get_supported
                                   1331 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BD3D                       1332 00106$:
                                   1333 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BD3D 12 33 FC         [24] 1334 	lcall	_ak820_outline_0127
      00BD40 74 52            [12] 1335 	mov	a,#0x52
      00BD42 F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BD43 12 BE 51         [24] 1338 	lcall	_ak820_outline_0039
      00BD46 E4               [12] 1339 	clr	a
      00BD47 F0               [24] 1340 	movx	@dptr,a
                                   1341 ;	quantum/vialrgb.c:166: break;
      00BD48 22               [24] 1342 	ret
                                   1343 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BD49                       1344 00107$:
                                   1345 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BD49 12 33 FC         [24] 1346 	lcall	_ak820_outline_0127
      00BD4C E0               [24] 1347 	movx	a,@dptr
      00BD4D FF               [12] 1348 	mov	r7,a
      00BD4E 7A 00            [12] 1349 	mov	r2,#0x00
      00BD50 74 03            [12] 1350 	mov	a,#0x03
      00BD52 2D               [12] 1351 	add	a, r5
      00BD53 F8               [12] 1352 	mov	r0,a
      00BD54 E4               [12] 1353 	clr	a
      00BD55 3E               [12] 1354 	addc	a, r6
      00BD56 F9               [12] 1355 	mov	r1,a
      00BD57 C0 03            [24] 1356 	push	ar3
      00BD59 C0 04            [24] 1357 	push	ar4
      00BD5B 12 38 6E         [24] 1358 	lcall	_ak820_outline_0162
      00BD5E E0               [24] 1359 	movx	a,@dptr
      00BD5F FB               [12] 1360 	mov	r3,a
      00BD60 E4               [12] 1361 	clr	a
      00BD61 4F               [12] 1362 	orl	a,r7
      00BD62 F5 57            [12] 1363 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BD64 EB               [12] 1364 	mov	a,r3
      00BD65 4A               [12] 1365 	orl	a,r2
      00BD66 F5 58            [12] 1366 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1367 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BD68 AC 57            [24] 1368 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BD6A AF 58            [24] 1369 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BD6C C3               [12] 1370 	clr	c
      00BD6D EC               [12] 1371 	mov	a,r4
      00BD6E 94 52            [12] 1372 	subb	a,#0x52
      00BD70 EF               [12] 1373 	mov	a,r7
      00BD71 94 00            [12] 1374 	subb	a,#0x00
      00BD73 D0 04            [24] 1375 	pop	ar4
      00BD75 D0 03            [24] 1376 	pop	ar3
      00BD77 40 01            [24] 1377 	jc	00109$
      00BD79 22               [24] 1378 	ret
      00BD7A                       1379 00109$:
                                   1380 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BD7A E5 57            [12] 1381 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BD7C 25 57            [12] 1382 	add	a,_vialrgb_get_value_sloc0_1_0
      00BD7E FA               [12] 1383 	mov	r2,a
      00BD7F E5 58            [12] 1384 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BD81 33               [12] 1385 	rlc	a
      00BD82 FF               [12] 1386 	mov	r7,a
      00BD83 EA               [12] 1387 	mov	a,r2
      00BD84 24 06            [12] 1388 	add	a, #_ak820_led_points
      00BD86 F5 59            [12] 1389 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BD88 EF               [12] 1390 	mov	a,r7
      00BD89 34 C3            [12] 1391 	addc	a, #(_ak820_led_points >> 8)
      00BD8B F5 5A            [12] 1392 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BD8D 85 59 82         [24] 1393 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BD90 85 5A 83         [24] 1394 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BD93 E4               [12] 1395 	clr	a
      00BD94 93               [24] 1396 	movc	a,@a+dptr
      00BD95 12 33 FC         [24] 1397 	lcall	_ak820_outline_0127
      00BD98 F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BD99 85 59 82         [24] 1400 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BD9C 85 5A 83         [24] 1401 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BD9F A3               [24] 1402 	inc	dptr
      00BDA0 E4               [12] 1403 	clr	a
      00BDA1 93               [24] 1404 	movc	a,@a+dptr
      00BDA2 12 38 6E         [24] 1405 	lcall	_ak820_outline_0162
      00BDA5 F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BDA6 12 BE 51         [24] 1408 	lcall	_ak820_outline_0039
      00BDA9 A3               [24] 1409 	inc	dptr
      00BDAA 74 04            [12] 1410 	mov	a,#0x04
      00BDAC F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BDAD 90 0E 1A         [24] 1413 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BDB0 04               [12] 1414 	inc	a
      00BDB1 2D               [12] 1415 	add	a, r5
      00BDB2 F0               [24] 1416 	movx	@dptr,a
      00BDB3 E4               [12] 1417 	clr	a
      00BDB4 3E               [12] 1418 	addc	a, r6
      00BDB5 A3               [24] 1419 	inc	dptr
      00BDB6 F0               [24] 1420 	movx	@dptr,a
      00BDB7 85 57 82         [24] 1421 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BDBA 85 58 83         [24] 1422 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1423 ;	quantum/vialrgb.c:187: }
                                   1424 ;	quantum/vialrgb.c:188: }
      00BDBD 41 E7            [24] 1425 	ajmp	_get_matrix_pos_for_led
                                   1426 ;------------------------------------------------------------
                                   1427 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1428 ;------------------------------------------------------------
                                   1429 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1430 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1431 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1432 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1433 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1434 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1435 ;------------------------------------------------------------
                                   1436 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1437 ;	-----------------------------------------
                                   1438 ;	 function vialrgb_set_value
                                   1439 ;	-----------------------------------------
      00BDBF                       1440 _vialrgb_set_value:
      00BDBF 12 49 1A         [24] 1441 	lcall	_ak820_outline_0038
      00BDC2 90 0E 29         [24] 1442 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BDC5 12 37 E5         [24] 1443 	lcall	_ak820_outline_0020
                                   1444 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BDC8 90 0E 28         [24] 1445 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BDCB E0               [24] 1446 	movx	a,@dptr
      00BDCC FF               [12] 1447 	mov	r7,a
      00BDCD BF 20 02         [24] 1448 	cjne	r7,#0x20,00129$
      00BDD0 80 01            [24] 1449 	sjmp	00102$
      00BDD2                       1450 00129$:
      00BDD2 22               [24] 1451 	ret
      00BDD3                       1452 00102$:
                                   1453 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BDD3 90 0E 29         [24] 1454 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BDD6 12 BE 59         [24] 1455 	lcall	_ak820_outline_0048
                                   1456 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1457 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BDD9 BA 41 02         [24] 1458 	cjne	r2,#0x41,00130$
      00BDDC 80 06            [24] 1459 	sjmp	00103$
      00BDDE                       1460 00130$:
      00BDDE BA 42 02         [24] 1461 	cjne	r2,#0x42,00131$
      00BDE1 80 5F            [24] 1462 	sjmp	00104$
      00BDE3                       1463 00131$:
      00BDE3 22               [24] 1464 	ret
                                   1465 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BDE4                       1466 00103$:
                                   1467 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BDE4 12 33 FC         [24] 1468 	lcall	_ak820_outline_0127
      00BDE7 E0               [24] 1469 	movx	a,@dptr
      00BDE8 FA               [12] 1470 	mov	r2,a
      00BDE9 12 BE 51         [24] 1471 	lcall	_ak820_outline_0039
      00BDEC E0               [24] 1472 	movx	a,@dptr
      00BDED F8               [12] 1473 	mov	r0,a
      00BDEE 79 00            [12] 1474 	mov	r1,#0x00
      00BDF0 88 5C            [24] 1475 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BDF2 89 5B            [24] 1476 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BDF4 8A 01            [24] 1477 	mov	ar1,r2
      00BDF6 7A 00            [12] 1478 	mov	r2,#0x00
      00BDF8 E5 5C            [12] 1479 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BDFA 42 02            [12] 1480 	orl	ar2,a
                                   1481 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BDFC 12 49 89         [24] 1482 	lcall	_ak820_outline_0163
      00BDFF C0 06            [24] 1483 	push	ar6
      00BE01 C0 05            [24] 1484 	push	ar5
      00BE03 51 BA            [24] 1485 	acall	_set_mode
      00BE05 D0 05            [24] 1486 	pop	ar5
      00BE07 D0 06            [24] 1487 	pop	ar6
                                   1488 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BE09 12 BE 51         [24] 1489 	lcall	_ak820_outline_0039
      00BE0C A3               [24] 1490 	inc	dptr
      00BE0D E0               [24] 1491 	movx	a,@dptr
      00BE0E F5 82            [12] 1492 	mov	dpl,a
      00BE10 C0 06            [24] 1493 	push	ar6
      00BE12 C0 05            [24] 1494 	push	ar5
      00BE14 12 5B B7         [24] 1495 	lcall	_rgb_matrix_set_speed_noeeprom
      00BE17 D0 05            [24] 1496 	pop	ar5
      00BE19 D0 06            [24] 1497 	pop	ar6
                                   1498 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BE1B 12 BE 51         [24] 1499 	lcall	_ak820_outline_0039
      00BE1E A3               [24] 1500 	inc	dptr
      00BE1F A3               [24] 1501 	inc	dptr
      00BE20 E0               [24] 1502 	movx	a,@dptr
      00BE21 F9               [12] 1503 	mov	r1,a
      00BE22 7A 00            [12] 1504 	mov	r2,#0x00
      00BE24 74 06            [12] 1505 	mov	a,#0x06
      00BE26 2D               [12] 1506 	add	a, r5
      00BE27 12 41 5E         [24] 1507 	lcall	_ak820_outline_0079
      00BE2A F8               [12] 1508 	mov	r0,a
      00BE2B 74 07            [12] 1509 	mov	a,#0x07
      00BE2D 2D               [12] 1510 	add	a, r5
      00BE2E 12 41 5E         [24] 1511 	lcall	_ak820_outline_0079
      00BE31 FE               [12] 1512 	mov	r6,a
      00BE32 90 07 98         [24] 1513 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BE35 E8               [12] 1514 	mov	a,r0
      00BE36 F0               [24] 1515 	movx	@dptr,a
      00BE37 90 07 99         [24] 1516 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BE3A EE               [12] 1517 	mov	a,r6
      00BE3B F0               [24] 1518 	movx	@dptr,a
      00BE3C 12 49 89         [24] 1519 	lcall	_ak820_outline_0163
                                   1520 ;	quantum/vialrgb.c:202: break;
                                   1521 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BE3F 02 5B 88         [24] 1522 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BE42                       1523 00104$:
                                   1524 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BE42 EF               [12] 1525 	mov	a,r7
      00BE43 24 FE            [12] 1526 	add	a,#0xfe
      00BE45 90 0E 1E         [24] 1527 	mov	dptr,#_fast_set_leds_PARM_2
      00BE48 F0               [24] 1528 	movx	@dptr,a
      00BE49 12 33 FC         [24] 1529 	lcall	_ak820_outline_0127
                                   1530 ;	quantum/vialrgb.c:210: }
                                   1531 ;	quantum/vialrgb.c:211: }
      00BE4C 61 19            [24] 1532 	ajmp	_fast_set_leds
                                   1533 ;------------------------------------------------------------
                                   1534 ;Allocation info for local variables in function 'vialrgb_save'
                                   1535 ;------------------------------------------------------------
                                   1536 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1537 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1538 ;------------------------------------------------------------
                                   1539 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1540 ;	-----------------------------------------
                                   1541 ;	 function vialrgb_save
                                   1542 ;	-----------------------------------------
      00BE4E                       1543 _vialrgb_save:
                                   1544 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1545 ;	quantum/vialrgb.c:218: }
      00BE4E 02 56 09         [24] 1546 	ljmp	_eeconfig_update_rgb_matrix
                                   1547 	.area CSEG    (CODE)
                                   1548 	.area CONST   (CODE)
                                   1549 	.area CONST   (CODE)
      00C645                       1550 _supported_modes:
      00C645 00                    1551 	.db #0x00	; 0
      00C646 00                    1552 	.db #0x00	; 0
      00C647 01                    1553 	.db #0x01	; 1
      00C648 05                    1554 	.db #0x05	; 5
      00C649 02                    1555 	.db #0x02	; 2
      00C64A 01                    1556 	.db #0x01	; 1
      00C64B 06                    1557 	.db #0x06	; 6
      00C64C 02                    1558 	.db #0x02	; 2
      00C64D 0D                    1559 	.db #0x0d	; 13
      00C64E 03                    1560 	.db #0x03	; 3
      00C64F 0E                    1561 	.db #0x0e	; 14
      00C650 04                    1562 	.db #0x04	; 4
      00C651 1F                    1563 	.db #0x1f	; 31
      00C652 06                    1564 	.db #0x06	; 6
                                   1565 	.area CSEG    (CODE)
                                   1566 	.area XINIT   (CODE)
                                   1567 	.area CABS    (ABS,CODE)
                                   1568 
                                   1569 ; Experimental exact instruction outlining.
                                   1570 	.globl _ak820_outline_0007
                                   1571 	.globl _ak820_outline_0020
                                   1572 	.globl _ak820_outline_0033
                                   1573 	.globl _ak820_outline_0038
                                   1574 	.globl _ak820_outline_0039
                                   1575 	.globl _ak820_outline_0040
                                   1576 	.globl _ak820_outline_0048
                                   1577 	.globl _ak820_outline_0050
                                   1578 	.globl _ak820_outline_0056
                                   1579 	.globl _ak820_outline_0066
                                   1580 	.globl _ak820_outline_0076
                                   1581 	.globl _ak820_outline_0079
                                   1582 	.globl _ak820_outline_0081
                                   1583 	.globl _ak820_outline_0085
                                   1584 	.globl _ak820_outline_0095
                                   1585 	.globl _ak820_outline_0102
                                   1586 	.globl _ak820_outline_0103
                                   1587 	.globl _ak820_outline_0108
                                   1588 	.globl _ak820_outline_0109
                                   1589 	.globl _ak820_outline_0110
                                   1590 	.globl _ak820_outline_0111
                                   1591 	.globl _ak820_outline_0120
                                   1592 	.globl _ak820_outline_0127
                                   1593 	.globl _ak820_outline_0138
                                   1594 	.globl _ak820_outline_0140
                                   1595 	.globl _ak820_outline_0145
                                   1596 	.globl _ak820_outline_0147
                                   1597 	.globl _ak820_outline_0150
                                   1598 	.globl _ak820_outline_0162
                                   1599 	.globl _ak820_outline_0163
                                   1600 	.globl _ak820_outline_0169
                                   1601 	.globl _ak820_outline_0170
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0039
      00BE51                       1605 _ak820_outline_0039:
      00BE51 8D 82            [24] 1606 	mov	dpl,r5
      00BE53 8E 83            [24] 1607 	mov	dph,r6
      00BE55 A3               [24] 1608 	inc	dptr
      00BE56 A3               [24] 1609 	inc	dptr
      00BE57 A3               [24] 1610 	inc	dptr
      00BE58 22               [24] 1611 	ret
                                   1612 
                                   1613 	.area CSEG (CODE)
                                   1614 ; function ak820_outline_0048
      00BE59                       1615 _ak820_outline_0048:
      00BE59 E0               [24] 1616 	movx	a,@dptr
      00BE5A FD               [12] 1617 	mov	r5,a
      00BE5B A3               [24] 1618 	inc	dptr
      00BE5C E0               [24] 1619 	movx	a,@dptr
      00BE5D FE               [12] 1620 	mov	r6,a
      00BE5E 74 02            [12] 1621 	mov	a,#0x02
      00BE60 2D               [12] 1622 	add	a,r5
      00BE61 FB               [12] 1623 	mov	r3,a
      00BE62 E4               [12] 1624 	clr	a
      00BE63 3E               [12] 1625 	addc	a,r6
      00BE64 FC               [12] 1626 	mov	r4,a
      00BE65 8D 82            [24] 1627 	mov	dpl,r5
      00BE67 8E 83            [24] 1628 	mov	dph,r6
      00BE69 A3               [24] 1629 	inc	dptr
      00BE6A E0               [24] 1630 	movx	a,@dptr
      00BE6B FA               [12] 1631 	mov	r2,a
      00BE6C 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0050
      00BE6D                       1636 _ak820_outline_0050:
      00BE6D ED               [12] 1637 	mov	a,r5
      00BE6E 75 F0 02         [24] 1638 	mov	b,#0x02
      00BE71 A4               [48] 1639 	mul	ab
      00BE72 24 45            [12] 1640 	add	a,#_supported_modes
      00BE74 FB               [12] 1641 	mov	r3,a
      00BE75 74 C6            [12] 1642 	mov	a,#(_supported_modes>>8)
      00BE77 35 F0            [12] 1643 	addc	a,b
      00BE79 FC               [12] 1644 	mov	r4,a
      00BE7A 8B 82            [24] 1645 	mov	dpl,r3
      00BE7C 8C 83            [24] 1646 	mov	dph,r4
      00BE7E 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0085
      00BE7F                       1651 _ak820_outline_0085:
      00BE7F 90 0E 1F         [24] 1652 	mov	dptr,#_fast_set_leds_args_10000_282
      00BE82 E0               [24] 1653 	movx	a,@dptr
      00BE83 F9               [12] 1654 	mov	r1,a
      00BE84 A3               [24] 1655 	inc	dptr
      00BE85 E0               [24] 1656 	movx	a,@dptr
      00BE86 FF               [12] 1657 	mov	r7,a
      00BE87 89 82            [24] 1658 	mov	dpl,r1
      00BE89 8F 83            [24] 1659 	mov	dph,r7
      00BE8B E0               [24] 1660 	movx	a,@dptr
      00BE8C 22               [24] 1661 	ret
                                   1662 
                                   1663 	.area CSEG (CODE)
                                   1664 ; function ak820_outline_0108
      00BE8D                       1665 _ak820_outline_0108:
      00BE8D 90 0E 1F         [24] 1666 	mov	dptr,#_fast_set_leds_args_10000_282
      00BE90 74 01            [12] 1667 	mov	a,#0x01
      00BE92 29               [12] 1668 	add	a,r1
      00BE93 F0               [24] 1669 	movx	@dptr,a
      00BE94 E4               [12] 1670 	clr	a
      00BE95 3F               [12] 1671 	addc	a,r7
      00BE96 A3               [24] 1672 	inc	dptr
      00BE97 F0               [24] 1673 	movx	@dptr,a
      00BE98 22               [24] 1674 	ret
                                   1675 
                                   1676 	.area CSEG (CODE)
                                   1677 ; function ak820_outline_0150
      00BE99                       1678 _ak820_outline_0150:
      00BE99 E4               [12] 1679 	clr	a
      00BE9A 93               [24] 1680 	movc	a,@a+dptr
      00BE9B FC               [12] 1681 	mov	r4,a
      00BE9C 7B 00            [12] 1682 	mov	r3,#0x00
      00BE9E 8C 82            [24] 1683 	mov	dpl,r4
      00BEA0 8B 83            [24] 1684 	mov	dph,r3
      00BEA2 22               [24] 1685 	ret
