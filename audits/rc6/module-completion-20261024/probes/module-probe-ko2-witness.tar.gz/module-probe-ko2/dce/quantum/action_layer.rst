                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_layer
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_macro_change
                                     12 	.globl _ak820_tri_layer_derived
                                     13 	.globl _ak820_keycode_at
                                     14 	.globl _action_for_keycode
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _layer_state
                                    259 	.globl _default_layer_state
                                    260 	.globl _ak820_resolve_key_PARM_2
                                    261 	.globl _ak820_cache_layer_PARM_2
                                    262 	.globl _ak820_cache_keycode_PARM_2
                                    263 	.globl _default_layer_state_set_user
                                    264 	.globl _default_layer_state_set_kb
                                    265 	.globl _default_layer_set
                                    266 	.globl _default_layer_or
                                    267 	.globl _default_layer_and
                                    268 	.globl _default_layer_xor
                                    269 	.globl _ak820_layer_refresh
                                    270 	.globl _layer_hold_on
                                    271 	.globl _layer_hold_off
                                    272 	.globl _layer_hold_clear
                                    273 	.globl _layer_state_set_user
                                    274 	.globl _layer_state_set_kb
                                    275 	.globl _layer_state_set
                                    276 	.globl _layer_clear
                                    277 	.globl _layer_move
                                    278 	.globl _layer_on
                                    279 	.globl _layer_off
                                    280 	.globl _layer_or
                                    281 	.globl _layer_and
                                    282 	.globl _layer_xor
                                    283 	.globl _ak820_cache_keycode
                                    284 	.globl _ak820_cache_layer
                                    285 	.globl _ak820_cached_key
                                    286 	.globl _ak820_resolve_key
                                    287 	.globl _ak820_layer_for_key
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; overlayable items in internal ram
                                    552 ;--------------------------------------------------------
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
                                    566 ;--------------------------------------------------------
                                    567 ; paged external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area PSEG    (PAG,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; uninitialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XSEG    (XDATA)
      0008A4                        574 _default_layer_state_set_user_state_10000_317:
      0008A4                        575 	.ds 1
      0008A5                        576 _default_layer_state_set_kb_state_10000_319:
      0008A5                        577 	.ds 1
      0008A6                        578 _default_layer_state_set_state_10000_321:
      0008A6                        579 	.ds 1
      0008A7                        580 _default_layer_set_state_10000_326:
      0008A7                        581 	.ds 1
      0008A8                        582 _default_layer_or_state_10000_328:
      0008A8                        583 	.ds 1
      0008A9                        584 _default_layer_and_state_10000_330:
      0008A9                        585 	.ds 1
      0008AA                        586 _default_layer_xor_state_10000_332:
      0008AA                        587 	.ds 1
      0008AB                        588 _persistent_layers:
      0008AB                        589 	.ds 1
      0008AC                        590 _layer_refs:
      0008AC                        591 	.ds 6
      0008B2                        592 _macro_layers:
      0008B2                        593 	.ds 1
      0008B3                        594 _ak820_layer_refresh_state_10000_335:
      0008B3                        595 	.ds 1
      0008B4                        596 _layer_hold_on_layer_10000_338:
      0008B4                        597 	.ds 1
      0008B5                        598 _layer_hold_off_layer_10000_342:
      0008B5                        599 	.ds 1
      0008B6                        600 _layer_state_set_user_state_10000_349:
      0008B6                        601 	.ds 1
      0008B7                        602 _layer_state_set_kb_state_10000_351:
      0008B7                        603 	.ds 1
      0008B8                        604 _layer_state_set_state_10000_353:
      0008B8                        605 	.ds 1
      0008B9                        606 _layer_move_layer_10000_366:
      0008B9                        607 	.ds 1
      0008BA                        608 _layer_on_layer_10000_368:
      0008BA                        609 	.ds 1
      0008BB                        610 _layer_off_layer_10000_370:
      0008BB                        611 	.ds 1
      0008BC                        612 _layer_or_state_10000_374:
      0008BC                        613 	.ds 1
      0008BD                        614 _layer_and_state_10000_376:
      0008BD                        615 	.ds 1
      0008BE                        616 _layer_xor_state_10000_378:
      0008BE                        617 	.ds 1
      0008BF                        618 _source_keycodes_cache:
      0008BF                        619 	.ds 256
      0009BF                        620 _encoder_source_keycodes_cache:
      0009BF                        621 	.ds 4
      0009C3                        622 _source_keycode_cache_slot_position_10000_380:
      0009C3                        623 	.ds 2
      0009C5                        624 _ak820_cache_keycode_PARM_2:
      0009C5                        625 	.ds 2
      0009C7                        626 _ak820_cache_keycode_position_10000_386:
      0009C7                        627 	.ds 2
      0009C9                        628 _ak820_cache_layer_PARM_2:
      0009C9                        629 	.ds 1
      0009CA                        630 _ak820_cache_layer_position_10000_389:
      0009CA                        631 	.ds 2
      0009CC                        632 _ak820_cached_key_position_10000_392:
      0009CC                        633 	.ds 2
      0009CE                        634 _ak820_resolve_key_PARM_2:
      0009CE                        635 	.ds 1
      0009CF                        636 _ak820_resolve_key_position_10000_403:
      0009CF                        637 	.ds 2
      0009D1                        638 _ak820_layer_for_key_position_10000_410:
      0009D1                        639 	.ds 2
      0009D3                        640 _ak820_layer_for_key_layers_10000_411:
      0009D3                        641 	.ds 1
                                    642 ;--------------------------------------------------------
                                    643 ; absolute external ram data
                                    644 ;--------------------------------------------------------
                                    645 	.area XABS    (ABS,XDATA)
                                    646 ;--------------------------------------------------------
                                    647 ; initialized external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XISEG   (XDATA)
      000E53                        650 _default_layer_state::
      000E53                        651 	.ds 1
      000E54                        652 _layer_state::
      000E54                        653 	.ds 1
                                    654 	.area HOME    (CODE)
                                    655 	.area GSINIT0 (CODE)
                                    656 	.area GSINIT1 (CODE)
                                    657 	.area GSINIT2 (CODE)
                                    658 	.area GSINIT3 (CODE)
                                    659 	.area GSINIT4 (CODE)
                                    660 	.area GSINIT5 (CODE)
                                    661 	.area GSINIT  (CODE)
                                    662 	.area GSFINAL (CODE)
                                    663 	.area CSEG    (CODE)
                                    664 ;--------------------------------------------------------
                                    665 ; global & static initialisations
                                    666 ;--------------------------------------------------------
                                    667 	.area HOME    (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area GSINIT  (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; Home
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area HOME    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; code
                                    678 ;--------------------------------------------------------
                                    679 	.area CSEG    (CODE)
                                    680 ;------------------------------------------------------------
                                    681 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    682 ;------------------------------------------------------------
                                    683 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_190'
                                    684 ;------------------------------------------------------------
                                    685 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    686 ;	-----------------------------------------
                           000007   687 	ar7 = 0x07
                           000006   688 	ar6 = 0x06
                           000005   689 	ar5 = 0x05
                           000004   690 	ar4 = 0x04
                           000003   691 	ar3 = 0x03
                           000002   692 	ar2 = 0x02
                           000001   693 	ar1 = 0x01
                           000000   694 	ar0 = 0x00
                                    695 ;	 function default_layer_state_set_user
                                    696 ;	-----------------------------------------
      007C64                        697 _default_layer_state_set_user:
      007C64 E5 82            [12]  698 	mov	a,dpl
      007C66 90 08 A4         [24]  699 	mov	dptr,#_default_layer_state_set_user_state_10000_317
      007C69 12 5C E1         [24]  700 	lcall	_ak820_outline_0178
                                    701 ;	quantum/action_layer.c:32: return state;
                                    702 ;	quantum/action_layer.c:33: }
      007C6C 22               [24]  703 	ret
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'default_layer_state_set_kb'
                                    706 ;------------------------------------------------------------
                                    707 ;state         Allocated with name '_default_layer_state_set_kb_state_10000_319'
                                    708 ;------------------------------------------------------------
                                    709 ;	quantum/action_layer.c:39: __attribute__((weak)) layer_state_t default_layer_state_set_kb(layer_state_t state) {
                                    710 ;	-----------------------------------------
                                    711 ;	 function default_layer_state_set_kb
                                    712 ;	-----------------------------------------
      007C6D                        713 _default_layer_state_set_kb:
      007C6D E5 82            [12]  714 	mov	a,dpl
      007C6F 90 08 A5         [24]  715 	mov	dptr,#_default_layer_state_set_kb_state_10000_319
      007C72 12 5C E1         [24]  716 	lcall	_ak820_outline_0178
                                    717 ;	quantum/action_layer.c:40: return default_layer_state_set_user(state);
                                    718 ;	quantum/action_layer.c:41: }
      007C75 81 64            [12]  719 	ajmp	_default_layer_state_set_user
                                    720 ;------------------------------------------------------------
                                    721 ;Allocation info for local variables in function 'default_layer_state_set'
                                    722 ;------------------------------------------------------------
                                    723 ;state         Allocated with name '_default_layer_state_set_state_10000_321'
                                    724 ;------------------------------------------------------------
                                    725 ;	quantum/action_layer.c:47: static void default_layer_state_set(layer_state_t state) {
                                    726 ;	-----------------------------------------
                                    727 ;	 function default_layer_state_set
                                    728 ;	-----------------------------------------
      007C77                        729 _default_layer_state_set:
      007C77 E5 82            [12]  730 	mov	a,dpl
      007C79 90 08 A6         [24]  731 	mov	dptr,#_default_layer_state_set_state_10000_321
      007C7C 12 5C E1         [24]  732 	lcall	_ak820_outline_0178
                                    733 ;	quantum/action_layer.c:48: state = default_layer_state_set_kb(state);
      007C7F 91 6D            [12]  734 	acall	_default_layer_state_set_kb
      007C81 AF 82            [24]  735 	mov	r7, dpl
      007C83 90 08 A6         [24]  736 	mov	dptr,#_default_layer_state_set_state_10000_321
      007C86 EF               [12]  737 	mov	a,r7
      007C87 F0               [24]  738 	movx	@dptr,a
                                    739 ;	quantum/action_layer.c:52: default_layer_state = state;
      007C88 90 0E 53         [24]  740 	mov	dptr,#_default_layer_state
      007C8B EF               [12]  741 	mov	a,r7
      007C8C F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action_layer.c:54: ak820_layer_refresh();
                                    744 ;	quantum/action_layer.c:57: ac_dprintf("\n");
                                    745 ;	quantum/action_layer.c:63: }
      007C8D 81 D0            [12]  746 	ajmp	_ak820_layer_refresh
                                    747 ;------------------------------------------------------------
                                    748 ;Allocation info for local variables in function 'default_layer_set'
                                    749 ;------------------------------------------------------------
                                    750 ;state         Allocated with name '_default_layer_set_state_10000_326'
                                    751 ;------------------------------------------------------------
                                    752 ;	quantum/action_layer.c:79: void default_layer_set(layer_state_t state) {
                                    753 ;	-----------------------------------------
                                    754 ;	 function default_layer_set
                                    755 ;	-----------------------------------------
      007C8F                        756 _default_layer_set:
      007C8F E5 82            [12]  757 	mov	a,dpl
      007C91 90 08 A7         [24]  758 	mov	dptr,#_default_layer_set_state_10000_326
      007C94 12 5C E1         [24]  759 	lcall	_ak820_outline_0178
                                    760 ;	quantum/action_layer.c:80: default_layer_state_set(state);
                                    761 ;	quantum/action_layer.c:81: }
      007C97 81 77            [12]  762 	ajmp	_default_layer_state_set
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'default_layer_or'
                                    765 ;------------------------------------------------------------
                                    766 ;state         Allocated with name '_default_layer_or_state_10000_328'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/action_layer.c:88: void default_layer_or(layer_state_t state) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function default_layer_or
                                    771 ;	-----------------------------------------
      007C99                        772 _default_layer_or:
      007C99 E5 82            [12]  773 	mov	a,dpl
      007C9B 90 08 A8         [24]  774 	mov	dptr,#_default_layer_or_state_10000_328
      007C9E F0               [24]  775 	movx	@dptr,a
                                    776 ;	quantum/action_layer.c:89: default_layer_state_set(default_layer_state | state);
      007C9F E0               [24]  777 	movx	a,@dptr
      007CA0 FF               [12]  778 	mov	r7,a
      007CA1 90 0E 53         [24]  779 	mov	dptr,#_default_layer_state
      007CA4 12 80 54         [24]  780 	lcall	_ak820_outline_0146
                                    781 ;	quantum/action_layer.c:90: }
      007CA7 81 77            [12]  782 	ajmp	_default_layer_state_set
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'default_layer_and'
                                    785 ;------------------------------------------------------------
                                    786 ;state         Allocated with name '_default_layer_and_state_10000_330'
                                    787 ;------------------------------------------------------------
                                    788 ;	quantum/action_layer.c:95: void default_layer_and(layer_state_t state) {
                                    789 ;	-----------------------------------------
                                    790 ;	 function default_layer_and
                                    791 ;	-----------------------------------------
      007CA9                        792 _default_layer_and:
      007CA9 E5 82            [12]  793 	mov	a,dpl
      007CAB 90 08 A9         [24]  794 	mov	dptr,#_default_layer_and_state_10000_330
      007CAE F0               [24]  795 	movx	@dptr,a
                                    796 ;	quantum/action_layer.c:96: default_layer_state_set(default_layer_state & state);
      007CAF 90 0E 53         [24]  797 	mov	dptr,#_default_layer_state
      007CB2 E0               [24]  798 	movx	a,@dptr
      007CB3 FF               [12]  799 	mov	r7,a
      007CB4 90 08 A9         [24]  800 	mov	dptr,#_default_layer_and_state_10000_330
      007CB7 E0               [24]  801 	movx	a,@dptr
      007CB8 52 07            [12]  802 	anl	ar7,a
      007CBA 8F 82            [24]  803 	mov	dpl, r7
                                    804 ;	quantum/action_layer.c:97: }
      007CBC 81 77            [12]  805 	ajmp	_default_layer_state_set
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'default_layer_xor'
                                    808 ;------------------------------------------------------------
                                    809 ;state         Allocated with name '_default_layer_xor_state_10000_332'
                                    810 ;------------------------------------------------------------
                                    811 ;	quantum/action_layer.c:102: void default_layer_xor(layer_state_t state) {
                                    812 ;	-----------------------------------------
                                    813 ;	 function default_layer_xor
                                    814 ;	-----------------------------------------
      007CBE                        815 _default_layer_xor:
      007CBE E5 82            [12]  816 	mov	a,dpl
      007CC0 90 08 AA         [24]  817 	mov	dptr,#_default_layer_xor_state_10000_332
      007CC3 F0               [24]  818 	movx	@dptr,a
                                    819 ;	quantum/action_layer.c:103: default_layer_state_set(default_layer_state ^ state);
      007CC4 E0               [24]  820 	movx	a,@dptr
      007CC5 FF               [12]  821 	mov	r7,a
      007CC6 90 0E 53         [24]  822 	mov	dptr,#_default_layer_state
      007CC9 E0               [24]  823 	movx	a,@dptr
      007CCA 62 07            [12]  824 	xrl	ar7,a
      007CCC 8F 82            [24]  825 	mov	dpl, r7
                                    826 ;	quantum/action_layer.c:104: }
      007CCE 81 77            [12]  827 	ajmp	_default_layer_state_set
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'ak820_layer_refresh'
                                    830 ;------------------------------------------------------------
                                    831 ;state         Allocated with name '_ak820_layer_refresh_state_10000_335'
                                    832 ;i             Allocated with name '_ak820_layer_refresh_i_20000_336'
                                    833 ;------------------------------------------------------------
                                    834 ;	quantum/action_layer.c:114: void ak820_layer_refresh(void) {
                                    835 ;	-----------------------------------------
                                    836 ;	 function ak820_layer_refresh
                                    837 ;	-----------------------------------------
      007CD0                        838 _ak820_layer_refresh:
                                    839 ;	quantum/action_layer.c:115: layer_state_t state = persistent_layers;
      007CD0 90 08 AB         [24]  840 	mov	dptr,#_persistent_layers
      007CD3 E0               [24]  841 	movx	a,@dptr
      007CD4 90 08 B3         [24]  842 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007CD7 F0               [24]  843 	movx	@dptr,a
                                    844 ;	quantum/action_layer.c:116: for (uint8_t i = 0; i < MAX_LAYER; ++i) if (layer_refs[i]) state |= (layer_state_t)1 << i;
      007CD8 7F 00            [12]  845 	mov	r7,#0x00
      007CDA                        846 00105$:
      007CDA BF 06 00         [24]  847 	cjne	r7,#0x06,00131$
      007CDD                        848 00131$:
      007CDD 50 25            [24]  849 	jnc	00103$
      007CDF EF               [12]  850 	mov	a,r7
      007CE0 24 AC            [12]  851 	add	a, #_layer_refs
      007CE2 FD               [12]  852 	mov	r5,a
      007CE3 E4               [12]  853 	clr	a
      007CE4 34 08            [12]  854 	addc	a, #(_layer_refs >> 8)
      007CE6 FE               [12]  855 	mov	r6,a
      007CE7 12 38 5E         [24]  856 	lcall	_ak820_outline_0138
      007CEA E0               [24]  857 	movx	a,@dptr
      007CEB 60 14            [24]  858 	jz	00106$
      007CED 8F F0            [24]  859 	mov	b,r7
      007CEF 05 F0            [12]  860 	inc	b
      007CF1 74 01            [12]  861 	mov	a,#0x01
      007CF3 80 02            [24]  862 	sjmp	00135$
      007CF5                        863 00134$:
      007CF5 25 E0            [12]  864 	add	a,acc
      007CF7                        865 00135$:
      007CF7 D5 F0 FB         [24]  866 	djnz	b,00134$
      007CFA FE               [12]  867 	mov	r6,a
      007CFB 90 08 B3         [24]  868 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007CFE E0               [24]  869 	movx	a,@dptr
      007CFF 4E               [12]  870 	orl	a,r6
      007D00 F0               [24]  871 	movx	@dptr,a
      007D01                        872 00106$:
      007D01 0F               [12]  873 	inc	r7
      007D02 80 D6            [24]  874 	sjmp	00105$
      007D04                        875 00103$:
                                    876 ;	quantum/action_layer.c:118: state |= ak820_tri_layer_derived(state | default_layer_state);
      007D04 90 0E 53         [24]  877 	mov	dptr,#_default_layer_state
      007D07 E0               [24]  878 	movx	a,@dptr
      007D08 FF               [12]  879 	mov	r7,a
      007D09 90 08 B3         [24]  880 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007D0C E0               [24]  881 	movx	a,@dptr
      007D0D FE               [12]  882 	mov	r6,a
      007D0E 42 07            [12]  883 	orl	ar7,a
      007D10 8F 82            [24]  884 	mov	dpl, r7
      007D12 C0 06            [24]  885 	push	ar6
      007D14 12 AB F8         [24]  886 	lcall	_ak820_tri_layer_derived
      007D17 AF 82            [24]  887 	mov	r7, dpl
      007D19 D0 06            [24]  888 	pop	ar6
      007D1B 90 08 B3         [24]  889 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007D1E EF               [12]  890 	mov	a,r7
      007D1F 4E               [12]  891 	orl	a,r6
      007D20 12 5C E1         [24]  892 	lcall	_ak820_outline_0178
                                    893 ;	quantum/action_layer.c:120: layer_state = layer_state_set_kb(state);
      007D23 B1 BD            [24]  894 	acall	_layer_state_set_kb
      007D25 E5 82            [12]  895 	mov	a, dpl
      007D27 90 0E 54         [24]  896 	mov	dptr,#_layer_state
      007D2A F0               [24]  897 	movx	@dptr,a
                                    898 ;	quantum/action_layer.c:121: }
      007D2B 22               [24]  899 	ret
                                    900 ;------------------------------------------------------------
                                    901 ;Allocation info for local variables in function 'layer_hold_on'
                                    902 ;------------------------------------------------------------
                                    903 ;layer         Allocated with name '_layer_hold_on_layer_10000_338'
                                    904 ;------------------------------------------------------------
                                    905 ;	quantum/action_layer.c:122: void layer_hold_on(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, true)) { ++layer_refs[layer]; ak820_layer_refresh(); } }
                                    906 ;	-----------------------------------------
                                    907 ;	 function layer_hold_on
                                    908 ;	-----------------------------------------
      007D2C                        909 _layer_hold_on:
      007D2C E5 82            [12]  910 	mov	a,dpl
      007D2E 90 08 B4         [24]  911 	mov	dptr,#_layer_hold_on_layer_10000_338
      007D31 F0               [24]  912 	movx	@dptr,a
      007D32 E0               [24]  913 	movx	a,@dptr
      007D33 FF               [12]  914 	mov	r7,a
      007D34 BF 06 00         [24]  915 	cjne	r7,#0x06,00120$
      007D37                        916 00120$:
      007D37 50 29            [24]  917 	jnc	00104$
      007D39 12 80 60         [24]  918 	lcall	_ak820_outline_0183
      007D3C 74 01            [12]  919 	mov	a,#0x01
      007D3E F0               [24]  920 	movx	@dptr,a
      007D3F 90 08 B2         [24]  921 	mov	dptr,#_macro_layers
      007D42 C0 07            [24]  922 	push	ar7
      007D44 12 80 69         [24]  923 	lcall	_ak820_macro_change
      007D47 E5 82            [12]  924 	mov	a, dpl
      007D49 D0 07            [24]  925 	pop	ar7
      007D4B 60 15            [24]  926 	jz	00104$
      007D4D EF               [12]  927 	mov	a,r7
      007D4E 24 AC            [12]  928 	add	a, #_layer_refs
      007D50 FF               [12]  929 	mov	r7,a
      007D51 E4               [12]  930 	clr	a
      007D52 34 08            [12]  931 	addc	a, #(_layer_refs >> 8)
      007D54 FE               [12]  932 	mov	r6,a
      007D55 12 49 8E         [24]  933 	lcall	_ak820_outline_0164
      007D58 E0               [24]  934 	movx	a,@dptr
      007D59 FD               [12]  935 	mov	r5,a
      007D5A 0D               [12]  936 	inc	r5
      007D5B 12 49 8E         [24]  937 	lcall	_ak820_outline_0164
      007D5E ED               [12]  938 	mov	a,r5
      007D5F F0               [24]  939 	movx	@dptr,a
      007D60 81 D0            [12]  940 	ajmp	_ak820_layer_refresh
      007D62                        941 00104$:
      007D62 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'layer_hold_off'
                                    945 ;------------------------------------------------------------
                                    946 ;layer         Allocated with name '_layer_hold_off_layer_10000_342'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action_layer.c:123: void layer_hold_off(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, false) && layer_refs[layer]) { --layer_refs[layer]; ak820_layer_refresh(); } }
                                    949 ;	-----------------------------------------
                                    950 ;	 function layer_hold_off
                                    951 ;	-----------------------------------------
      007D63                        952 _layer_hold_off:
      007D63 E5 82            [12]  953 	mov	a,dpl
      007D65 90 08 B5         [24]  954 	mov	dptr,#_layer_hold_off_layer_10000_342
      007D68 F0               [24]  955 	movx	@dptr,a
      007D69 E0               [24]  956 	movx	a,@dptr
      007D6A FF               [12]  957 	mov	r7,a
      007D6B BF 06 00         [24]  958 	cjne	r7,#0x06,00128$
      007D6E                        959 00128$:
      007D6E 50 29            [24]  960 	jnc	00105$
      007D70 12 80 60         [24]  961 	lcall	_ak820_outline_0183
      007D73 E4               [12]  962 	clr	a
      007D74 F0               [24]  963 	movx	@dptr,a
      007D75 90 08 B2         [24]  964 	mov	dptr,#_macro_layers
      007D78 C0 07            [24]  965 	push	ar7
      007D7A 12 80 69         [24]  966 	lcall	_ak820_macro_change
      007D7D E5 82            [12]  967 	mov	a, dpl
      007D7F D0 07            [24]  968 	pop	ar7
      007D81 60 16            [24]  969 	jz	00105$
      007D83 EF               [12]  970 	mov	a,r7
      007D84 24 AC            [12]  971 	add	a, #_layer_refs
      007D86 FE               [12]  972 	mov	r6,a
      007D87 E4               [12]  973 	clr	a
      007D88 34 08            [12]  974 	addc	a, #(_layer_refs >> 8)
      007D8A FF               [12]  975 	mov	r7,a
      007D8B 12 38 32         [24]  976 	lcall	_ak820_outline_0098
      007D8E FD               [12]  977 	mov	r5,a
      007D8F 60 08            [24]  978 	jz	00105$
      007D91 1D               [12]  979 	dec	r5
      007D92 12 49 5D         [24]  980 	lcall	_ak820_outline_0120
      007D95 ED               [12]  981 	mov	a,r5
      007D96 F0               [24]  982 	movx	@dptr,a
      007D97 81 D0            [12]  983 	ajmp	_ak820_layer_refresh
      007D99                        984 00105$:
      007D99 22               [24]  985 	ret
                                    986 ;------------------------------------------------------------
                                    987 ;Allocation info for local variables in function 'layer_hold_clear'
                                    988 ;------------------------------------------------------------
                                    989 ;i             Allocated with name '_layer_hold_clear_i_20000_348'
                                    990 ;------------------------------------------------------------
                                    991 ;	quantum/action_layer.c:124: void layer_hold_clear(void) { macro_layers = 0; for (uint8_t i = 0; i < MAX_LAYER; ++i) layer_refs[i] = 0; ak820_layer_refresh(); }
                                    992 ;	-----------------------------------------
                                    993 ;	 function layer_hold_clear
                                    994 ;	-----------------------------------------
      007D9A                        995 _layer_hold_clear:
      007D9A 90 08 B2         [24]  996 	mov	dptr,#_macro_layers
      007D9D E4               [12]  997 	clr	a
      007D9E F0               [24]  998 	movx	@dptr,a
      007D9F FF               [12]  999 	mov	r7,a
      007DA0                       1000 00103$:
      007DA0 BF 06 00         [24] 1001 	cjne	r7,#0x06,00122$
      007DA3                       1002 00122$:
      007DA3 50 0D            [24] 1003 	jnc	00101$
      007DA5 EF               [12] 1004 	mov	a,r7
      007DA6 24 AC            [12] 1005 	add	a, #_layer_refs
      007DA8 F5 82            [12] 1006 	mov	dpl,a
      007DAA E4               [12] 1007 	clr	a
      007DAB 34 08            [12] 1008 	addc	a, #(_layer_refs >> 8)
      007DAD 12 80 5A         [24] 1009 	lcall	_ak820_outline_0171
      007DB0 80 EE            [24] 1010 	sjmp	00103$
      007DB2                       1011 00101$:
      007DB2 81 D0            [12] 1012 	ajmp	_ak820_layer_refresh
                                   1013 ;------------------------------------------------------------
                                   1014 ;Allocation info for local variables in function 'layer_state_set_user'
                                   1015 ;------------------------------------------------------------
                                   1016 ;state         Allocated with name '_layer_state_set_user_state_10000_349'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/action_layer.c:131: __attribute__((weak)) layer_state_t layer_state_set_user(layer_state_t state) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function layer_state_set_user
                                   1021 ;	-----------------------------------------
      007DB4                       1022 _layer_state_set_user:
      007DB4 E5 82            [12] 1023 	mov	a,dpl
      007DB6 90 08 B6         [24] 1024 	mov	dptr,#_layer_state_set_user_state_10000_349
      007DB9 12 5C E1         [24] 1025 	lcall	_ak820_outline_0178
                                   1026 ;	quantum/action_layer.c:132: return state;
                                   1027 ;	quantum/action_layer.c:133: }
      007DBC 22               [24] 1028 	ret
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'layer_state_set_kb'
                                   1031 ;------------------------------------------------------------
                                   1032 ;state         Allocated with name '_layer_state_set_kb_state_10000_351'
                                   1033 ;------------------------------------------------------------
                                   1034 ;	quantum/action_layer.c:139: __attribute__((weak)) layer_state_t layer_state_set_kb(layer_state_t state) {
                                   1035 ;	-----------------------------------------
                                   1036 ;	 function layer_state_set_kb
                                   1037 ;	-----------------------------------------
      007DBD                       1038 _layer_state_set_kb:
      007DBD E5 82            [12] 1039 	mov	a,dpl
      007DBF 90 08 B7         [24] 1040 	mov	dptr,#_layer_state_set_kb_state_10000_351
      007DC2 12 5C E1         [24] 1041 	lcall	_ak820_outline_0178
                                   1042 ;	quantum/action_layer.c:140: return layer_state_set_user(state);
                                   1043 ;	quantum/action_layer.c:141: }
      007DC5 A1 B4            [24] 1044 	ajmp	_layer_state_set_user
                                   1045 ;------------------------------------------------------------
                                   1046 ;Allocation info for local variables in function 'layer_state_set'
                                   1047 ;------------------------------------------------------------
                                   1048 ;state         Allocated with name '_layer_state_set_state_10000_353'
                                   1049 ;------------------------------------------------------------
                                   1050 ;	quantum/action_layer.c:147: void layer_state_set(layer_state_t state) {
                                   1051 ;	-----------------------------------------
                                   1052 ;	 function layer_state_set
                                   1053 ;	-----------------------------------------
      007DC7                       1054 _layer_state_set:
      007DC7 E5 82            [12] 1055 	mov	a,dpl
      007DC9 90 08 B8         [24] 1056 	mov	dptr,#_layer_state_set_state_10000_353
      007DCC F0               [24] 1057 	movx	@dptr,a
                                   1058 ;	quantum/action_layer.c:149: persistent_layers = state;
      007DCD E0               [24] 1059 	movx	a,@dptr
      007DCE 90 08 AB         [24] 1060 	mov	dptr,#_persistent_layers
      007DD1 F0               [24] 1061 	movx	@dptr,a
                                   1062 ;	quantum/action_layer.c:150: ak820_layer_refresh();
                                   1063 ;	quantum/action_layer.c:151: return;
                                   1064 ;	quantum/action_layer.c:159: ac_dprintf("\n");
                                   1065 ;	quantum/action_layer.c:165: }
      007DD2 81 D0            [12] 1066 	ajmp	_ak820_layer_refresh
                                   1067 ;------------------------------------------------------------
                                   1068 ;Allocation info for local variables in function 'layer_clear'
                                   1069 ;------------------------------------------------------------
                                   1070 ;	quantum/action_layer.c:171: void layer_clear(void) {
                                   1071 ;	-----------------------------------------
                                   1072 ;	 function layer_clear
                                   1073 ;	-----------------------------------------
      007DD4                       1074 _layer_clear:
                                   1075 ;	quantum/action_layer.c:172: layer_state_set(0);
      007DD4 75 82 00         [24] 1076 	mov	dpl, #0x00
                                   1077 ;	quantum/action_layer.c:173: }
      007DD7 A1 C7            [24] 1078 	ajmp	_layer_state_set
                                   1079 ;------------------------------------------------------------
                                   1080 ;Allocation info for local variables in function 'layer_state_is'
                                   1081 ;------------------------------------------------------------
                                   1082 ;layer         Allocated with name '_layer_state_is_layer_10000_360'
                                   1083 ;------------------------------------------------------------
                                   1084 ;	quantum/action_layer.c:179: bool layer_state_is(uint8_t layer) {
                                   1085 ;	-----------------------------------------
                                   1086 ;	 function layer_move
                                   1087 ;	-----------------------------------------
      007DD9                       1088 _layer_move:
      007DD9 E5 82            [12] 1089 	mov	a,dpl
      007DDB 90 08 B9         [24] 1090 	mov	dptr,#_layer_move_layer_10000_366
      007DDE 12 80 4B         [24] 1091 	lcall	_ak820_outline_0092
                                   1092 ;	quantum/action_layer.c:199: layer_state_set((layer_state_t)1 << layer);
      007DE1 80 02            [24] 1093 	sjmp	00104$
      007DE3                       1094 00103$:
      007DE3 25 E0            [12] 1095 	add	a,acc
      007DE5                       1096 00104$:
      007DE5 D5 F0 FB         [24] 1097 	djnz	b,00103$
      007DE8 F5 82            [12] 1098 	mov	dpl,a
                                   1099 ;	quantum/action_layer.c:200: }
      007DEA A1 C7            [24] 1100 	ajmp	_layer_state_set
                                   1101 ;------------------------------------------------------------
                                   1102 ;Allocation info for local variables in function 'layer_on'
                                   1103 ;------------------------------------------------------------
                                   1104 ;layer         Allocated with name '_layer_on_layer_10000_368'
                                   1105 ;------------------------------------------------------------
                                   1106 ;	quantum/action_layer.c:206: void layer_on(uint8_t layer) {
                                   1107 ;	-----------------------------------------
                                   1108 ;	 function layer_on
                                   1109 ;	-----------------------------------------
      007DEC                       1110 _layer_on:
      007DEC E5 82            [12] 1111 	mov	a,dpl
      007DEE 90 08 BA         [24] 1112 	mov	dptr,#_layer_on_layer_10000_368
      007DF1 12 80 4B         [24] 1113 	lcall	_ak820_outline_0092
                                   1114 ;	quantum/action_layer.c:213: ((layer_state_t)1 << layer));
      007DF4 80 02            [24] 1115 	sjmp	00104$
      007DF6                       1116 00103$:
      007DF6 25 E0            [12] 1117 	add	a,acc
      007DF8                       1118 00104$:
      007DF8 D5 F0 FB         [24] 1119 	djnz	b,00103$
      007DFB FF               [12] 1120 	mov	r7,a
      007DFC 90 08 AB         [24] 1121 	mov	dptr,#_persistent_layers
      007DFF 12 80 54         [24] 1122 	lcall	_ak820_outline_0146
                                   1123 ;	quantum/action_layer.c:214: }
      007E02 A1 C7            [24] 1124 	ajmp	_layer_state_set
                                   1125 ;------------------------------------------------------------
                                   1126 ;Allocation info for local variables in function 'layer_off'
                                   1127 ;------------------------------------------------------------
                                   1128 ;layer         Allocated with name '_layer_off_layer_10000_370'
                                   1129 ;------------------------------------------------------------
                                   1130 ;	quantum/action_layer.c:220: void layer_off(uint8_t layer) {
                                   1131 ;	-----------------------------------------
                                   1132 ;	 function layer_off
                                   1133 ;	-----------------------------------------
      007E04                       1134 _layer_off:
      007E04 E5 82            [12] 1135 	mov	a,dpl
      007E06 90 08 BB         [24] 1136 	mov	dptr,#_layer_off_layer_10000_370
      007E09 12 80 4B         [24] 1137 	lcall	_ak820_outline_0092
                                   1138 ;	quantum/action_layer.c:227: ~((layer_state_t)1 << layer));
      007E0C 80 02            [24] 1139 	sjmp	00104$
      007E0E                       1140 00103$:
      007E0E 25 E0            [12] 1141 	add	a,acc
      007E10                       1142 00104$:
      007E10 D5 F0 FB         [24] 1143 	djnz	b,00103$
      007E13 F4               [12] 1144 	cpl	a
      007E14 FF               [12] 1145 	mov	r7,a
      007E15 90 08 AB         [24] 1146 	mov	dptr,#_persistent_layers
      007E18 E0               [24] 1147 	movx	a,@dptr
      007E19 52 07            [12] 1148 	anl	ar7,a
      007E1B 8F 82            [24] 1149 	mov	dpl, r7
                                   1150 ;	quantum/action_layer.c:228: }
      007E1D A1 C7            [24] 1151 	ajmp	_layer_state_set
                                   1152 ;------------------------------------------------------------
                                   1153 ;Allocation info for local variables in function 'layer_invert'
                                   1154 ;------------------------------------------------------------
                                   1155 ;layer         Allocated with name '_layer_invert_layer_10000_372'
                                   1156 ;------------------------------------------------------------
                                   1157 ;	quantum/action_layer.c:234: void layer_invert(uint8_t layer) {
                                   1158 ;	-----------------------------------------
                                   1159 ;	 function layer_or
                                   1160 ;	-----------------------------------------
      007E1F                       1161 _layer_or:
      007E1F E5 82            [12] 1162 	mov	a,dpl
      007E21 90 08 BC         [24] 1163 	mov	dptr,#_layer_or_state_10000_374
      007E24 F0               [24] 1164 	movx	@dptr,a
                                   1165 ;	quantum/action_layer.c:255: state);
      007E25 E0               [24] 1166 	movx	a,@dptr
      007E26 FF               [12] 1167 	mov	r7,a
      007E27 90 08 AB         [24] 1168 	mov	dptr,#_persistent_layers
      007E2A 12 80 54         [24] 1169 	lcall	_ak820_outline_0146
                                   1170 ;	quantum/action_layer.c:256: }
      007E2D A1 C7            [24] 1171 	ajmp	_layer_state_set
                                   1172 ;------------------------------------------------------------
                                   1173 ;Allocation info for local variables in function 'layer_and'
                                   1174 ;------------------------------------------------------------
                                   1175 ;state         Allocated with name '_layer_and_state_10000_376'
                                   1176 ;------------------------------------------------------------
                                   1177 ;	quantum/action_layer.c:261: void layer_and(layer_state_t state) {
                                   1178 ;	-----------------------------------------
                                   1179 ;	 function layer_and
                                   1180 ;	-----------------------------------------
      007E2F                       1181 _layer_and:
      007E2F E5 82            [12] 1182 	mov	a,dpl
      007E31 90 08 BD         [24] 1183 	mov	dptr,#_layer_and_state_10000_376
      007E34 F0               [24] 1184 	movx	@dptr,a
                                   1185 ;	quantum/action_layer.c:268: state);
      007E35 90 08 AB         [24] 1186 	mov	dptr,#_persistent_layers
      007E38 E0               [24] 1187 	movx	a,@dptr
      007E39 FF               [12] 1188 	mov	r7,a
      007E3A 90 08 BD         [24] 1189 	mov	dptr,#_layer_and_state_10000_376
      007E3D E0               [24] 1190 	movx	a,@dptr
      007E3E 52 07            [12] 1191 	anl	ar7,a
      007E40 8F 82            [24] 1192 	mov	dpl, r7
                                   1193 ;	quantum/action_layer.c:269: }
      007E42 A1 C7            [24] 1194 	ajmp	_layer_state_set
                                   1195 ;------------------------------------------------------------
                                   1196 ;Allocation info for local variables in function 'layer_xor'
                                   1197 ;------------------------------------------------------------
                                   1198 ;state         Allocated with name '_layer_xor_state_10000_378'
                                   1199 ;------------------------------------------------------------
                                   1200 ;	quantum/action_layer.c:274: void layer_xor(layer_state_t state) {
                                   1201 ;	-----------------------------------------
                                   1202 ;	 function layer_xor
                                   1203 ;	-----------------------------------------
      007E44                       1204 _layer_xor:
      007E44 E5 82            [12] 1205 	mov	a,dpl
      007E46 90 08 BE         [24] 1206 	mov	dptr,#_layer_xor_state_10000_378
      007E49 F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	quantum/action_layer.c:281: state);
      007E4A E0               [24] 1209 	movx	a,@dptr
      007E4B FF               [12] 1210 	mov	r7,a
      007E4C 90 08 AB         [24] 1211 	mov	dptr,#_persistent_layers
      007E4F E0               [24] 1212 	movx	a,@dptr
      007E50 62 07            [12] 1213 	xrl	ar7,a
      007E52 8F 82            [24] 1214 	mov	dpl, r7
                                   1215 ;	quantum/action_layer.c:282: }
      007E54 A1 C7            [24] 1216 	ajmp	_layer_state_set
                                   1217 ;------------------------------------------------------------
                                   1218 ;Allocation info for local variables in function 'source_keycode_cache_slot'
                                   1219 ;------------------------------------------------------------
                                   1220 ;position      Allocated with name '_source_keycode_cache_slot_position_10000_380'
                                   1221 ;row           Allocated with name '_source_keycode_cache_slot_row_10000_381'
                                   1222 ;col           Allocated with name '_source_keycode_cache_slot_col_10000_381'
                                   1223 ;------------------------------------------------------------
                                   1224 ;	quantum/action_layer.c:324: static uint16_t SOURCE_CACHE_MEM *source_keycode_cache_slot(uint16_t position) {
                                   1225 ;	-----------------------------------------
                                   1226 ;	 function source_keycode_cache_slot
                                   1227 ;	-----------------------------------------
      007E56                       1228 _source_keycode_cache_slot:
      007E56 12 38 44         [24] 1229 	lcall	_ak820_outline_0109
      007E59 90 09 C3         [24] 1230 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      007E5C 12 38 49         [24] 1231 	lcall	_ak820_outline_0110
                                   1232 ;	quantum/action_layer.c:325: uint8_t row = position >> 8, col = position;
      007E5F 90 09 C3         [24] 1233 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      007E62 E0               [24] 1234 	movx	a,@dptr
      007E63 FE               [12] 1235 	mov	r6,a
      007E64 A3               [24] 1236 	inc	dptr
      007E65 E0               [24] 1237 	movx	a,@dptr
      007E66 FD               [12] 1238 	mov	r5,a
                                   1239 ;	quantum/action_layer.c:326: if (row < MATRIX_ROWS && col < MATRIX_COLS) {
      007E67 BD 10 00         [24] 1240 	cjne	r5,#0x10,00147$
      007E6A                       1241 00147$:
      007E6A 50 21            [24] 1242 	jnc	00102$
      007E6C BE 08 00         [24] 1243 	cjne	r6,#0x08,00149$
      007E6F                       1244 00149$:
      007E6F 50 1C            [24] 1245 	jnc	00102$
                                   1246 ;	quantum/action_layer.c:327: return &source_keycodes_cache[(uint8_t)(row * MATRIX_COLS + col)];
      007E71 8D 07            [24] 1247 	mov	ar7,r5
      007E73 EF               [12] 1248 	mov	a,r7
      007E74 12 38 7E         [24] 1249 	lcall	_ak820_outline_0193
      007E77 FF               [12] 1250 	mov	r7,a
      007E78 8E 04            [24] 1251 	mov	ar4,r6
      007E7A EC               [12] 1252 	mov	a,r4
      007E7B 2F               [12] 1253 	add	a, r7
      007E7C 75 F0 02         [24] 1254 	mov	b,#0x02
      007E7F A4               [48] 1255 	mul	ab
      007E80 24 BF            [12] 1256 	add	a, #_source_keycodes_cache
      007E82 FC               [12] 1257 	mov	r4,a
      007E83 74 08            [12] 1258 	mov	a,#(_source_keycodes_cache >> 8)
      007E85 35 F0            [12] 1259 	addc	a, b
      007E87 FF               [12] 1260 	mov	r7,a
      007E88 8C 82            [24] 1261 	mov	dpl, r4
      007E8A 8F 83            [24] 1262 	mov	dph, r7
      007E8C 22               [24] 1263 	ret
      007E8D                       1264 00102$:
                                   1265 ;	quantum/action_layer.c:330: if ((row == KEYLOC_ENCODER_CW || row == KEYLOC_ENCODER_CCW) && col < NUM_ENCODERS) {
      007E8D BD FD 02         [24] 1266 	cjne	r5,#0xfd,00151$
      007E90 80 03            [24] 1267 	sjmp	00107$
      007E92                       1268 00151$:
      007E92 BD FC 2E         [24] 1269 	cjne	r5,#0xfc,00105$
      007E95                       1270 00107$:
      007E95 BE 01 00         [24] 1271 	cjne	r6,#0x01,00154$
      007E98                       1272 00154$:
      007E98 50 29            [24] 1273 	jnc	00105$
                                   1274 ;	quantum/action_layer.c:331: return &encoder_source_keycodes_cache[col + (row == KEYLOC_ENCODER_CCW ? NUM_ENCODERS : 0)];
      007E9A BD FC 04         [24] 1275 	cjne	r5,#0xfc,00110$
      007E9D 7F 01            [12] 1276 	mov	r7,#0x01
      007E9F 80 02            [24] 1277 	sjmp	00111$
      007EA1                       1278 00110$:
      007EA1 7F 00            [12] 1279 	mov	r7,#0x00
      007EA3                       1280 00111$:
      007EA3 C2 D5            [12] 1281 	clr	F0
      007EA5 75 F0 02         [24] 1282 	mov	b,#0x02
      007EA8 EF               [12] 1283 	mov	a,r7
      007EA9 30 E7 04         [24] 1284 	jnb	acc.7,00158$
      007EAC B2 D5            [12] 1285 	cpl	F0
      007EAE F4               [12] 1286 	cpl	a
      007EAF 04               [12] 1287 	inc	a
      007EB0                       1288 00158$:
      007EB0 A4               [48] 1289 	mul	ab
      007EB1 30 D5 03         [24] 1290 	jnb	F0,00159$
      007EB4 12 75 27         [24] 1291 	lcall	_ak820_outline_0134
      007EB7                       1292 00159$:
      007EB7 24 BF            [12] 1293 	add	a, #_encoder_source_keycodes_cache
      007EB9 FE               [12] 1294 	mov	r6,a
      007EBA 74 09            [12] 1295 	mov	a,#(_encoder_source_keycodes_cache >> 8)
      007EBC 35 F0            [12] 1296 	addc	a, b
      007EBE FF               [12] 1297 	mov	r7,a
      007EBF 12 49 5D         [24] 1298 	lcall	_ak820_outline_0120
      007EC2 22               [24] 1299 	ret
      007EC3                       1300 00105$:
                                   1301 ;	quantum/action_layer.c:334: return 0;
      007EC3 90 00 00         [24] 1302 	mov	dptr,#0x0000
                                   1303 ;	quantum/action_layer.c:335: }
      007EC6 22               [24] 1304 	ret
                                   1305 ;------------------------------------------------------------
                                   1306 ;Allocation info for local variables in function 'ak820_cache_keycode'
                                   1307 ;------------------------------------------------------------
                                   1308 ;keycode       Allocated with name '_ak820_cache_keycode_PARM_2'
                                   1309 ;position      Allocated with name '_ak820_cache_keycode_position_10000_386'
                                   1310 ;slot          Allocated with name '_ak820_cache_keycode_slot_10000_387'
                                   1311 ;------------------------------------------------------------
                                   1312 ;	quantum/action_layer.c:339: bool ak820_cache_keycode(uint16_t position, uint16_t keycode) {
                                   1313 ;	-----------------------------------------
                                   1314 ;	 function ak820_cache_keycode
                                   1315 ;	-----------------------------------------
      007EC7                       1316 _ak820_cache_keycode:
      007EC7 12 38 44         [24] 1317 	lcall	_ak820_outline_0109
      007ECA 90 09 C7         [24] 1318 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      007ECD 12 38 49         [24] 1319 	lcall	_ak820_outline_0110
                                   1320 ;	quantum/action_layer.c:340: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007ED0 90 09 C7         [24] 1321 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      007ED3 12 37 BE         [24] 1322 	lcall	_ak820_outline_0007
      007ED6 D1 56            [24] 1323 	acall	_source_keycode_cache_slot
      007ED8 12 49 6E         [24] 1324 	lcall	_ak820_outline_0139
                                   1325 ;	quantum/action_layer.c:341: if (!slot) return false;
      007EDB EE               [12] 1326 	mov	a,r6
      007EDC 4F               [12] 1327 	orl	a,r7
      007EDD 70 03            [24] 1328 	jnz	00102$
      007EDF F5 82            [12] 1329 	mov	dpl,a
      007EE1 22               [24] 1330 	ret
      007EE2                       1331 00102$:
                                   1332 ;	quantum/action_layer.c:342: *slot = keycode;
      007EE2 90 09 C5         [24] 1333 	mov	dptr,#_ak820_cache_keycode_PARM_2
      007EE5 12 38 14         [24] 1334 	lcall	_ak820_outline_0062
      007EE8 12 49 5D         [24] 1335 	lcall	_ak820_outline_0120
      007EEB 12 38 20         [24] 1336 	lcall	_ak820_outline_0078
                                   1337 ;	quantum/action_layer.c:343: return true;
      007EEE 75 82 01         [24] 1338 	mov	dpl, #0x01
                                   1339 ;	quantum/action_layer.c:344: }
      007EF1 22               [24] 1340 	ret
                                   1341 ;------------------------------------------------------------
                                   1342 ;Allocation info for local variables in function 'ak820_cache_layer'
                                   1343 ;------------------------------------------------------------
                                   1344 ;layer         Allocated with name '_ak820_cache_layer_PARM_2'
                                   1345 ;position      Allocated with name '_ak820_cache_layer_position_10000_389'
                                   1346 ;slot          Allocated with name '_ak820_cache_layer_slot_10000_390'
                                   1347 ;------------------------------------------------------------
                                   1348 ;	quantum/action_layer.c:346: void ak820_cache_layer(uint16_t position, uint8_t layer) {
                                   1349 ;	-----------------------------------------
                                   1350 ;	 function ak820_cache_layer
                                   1351 ;	-----------------------------------------
      007EF2                       1352 _ak820_cache_layer:
      007EF2 12 38 44         [24] 1353 	lcall	_ak820_outline_0109
      007EF5 90 09 CA         [24] 1354 	mov	dptr,#_ak820_cache_layer_position_10000_389
      007EF8 12 38 49         [24] 1355 	lcall	_ak820_outline_0110
                                   1356 ;	quantum/action_layer.c:347: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007EFB 90 09 CA         [24] 1357 	mov	dptr,#_ak820_cache_layer_position_10000_389
      007EFE 12 37 BE         [24] 1358 	lcall	_ak820_outline_0007
      007F01 C0 07            [24] 1359 	push	ar7
      007F03 C0 06            [24] 1360 	push	ar6
      007F05 D1 56            [24] 1361 	acall	_source_keycode_cache_slot
      007F07 12 49 84         [24] 1362 	lcall	_ak820_outline_0155
      007F0A D0 06            [24] 1363 	pop	ar6
      007F0C D0 07            [24] 1364 	pop	ar7
                                   1365 ;	quantum/action_layer.c:348: if (!slot) return;
      007F0E EC               [12] 1366 	mov	a,r4
      007F0F 4D               [12] 1367 	orl	a,r5
      007F10 70 01            [24] 1368 	jnz	00102$
      007F12 22               [24] 1369 	ret
      007F13                       1370 00102$:
                                   1371 ;	quantum/action_layer.c:349: layer &= (1u << MAX_LAYER_BITS) - 1;
      007F13 90 09 C9         [24] 1372 	mov	dptr,#_ak820_cache_layer_PARM_2
      007F16 E0               [24] 1373 	movx	a,@dptr
      007F17 53 E0 07         [24] 1374 	anl	acc,#0x07
      007F1A F0               [24] 1375 	movx	@dptr,a
                                   1376 ;	quantum/action_layer.c:361: *slot = ak820_keycode_at(layer, position);
      007F1B 90 09 C9         [24] 1377 	mov	dptr,#_ak820_cache_layer_PARM_2
      007F1E E0               [24] 1378 	movx	a,@dptr
      007F1F FB               [12] 1379 	mov	r3,a
      007F20 90 0C 30         [24] 1380 	mov	dptr,#_ak820_keycode_at_PARM_2
      007F23 12 4E 7D         [24] 1381 	lcall	_ak820_outline_0064
      007F26 8B 82            [24] 1382 	mov	dpl, r3
      007F28 C0 05            [24] 1383 	push	ar5
      007F2A C0 04            [24] 1384 	push	ar4
      007F2C 12 9D 42         [24] 1385 	lcall	_ak820_keycode_at
      007F2F 12 49 6E         [24] 1386 	lcall	_ak820_outline_0139
      007F32 D0 04            [24] 1387 	pop	ar4
      007F34 D0 05            [24] 1388 	pop	ar5
      007F36 12 38 54         [24] 1389 	lcall	_ak820_outline_0128
      007F39 12 4E 7D         [24] 1390 	lcall	_ak820_outline_0064
                                   1391 ;	quantum/action_layer.c:362: }
      007F3C 22               [24] 1392 	ret
                                   1393 ;------------------------------------------------------------
                                   1394 ;Allocation info for local variables in function 'ak820_cached_key'
                                   1395 ;------------------------------------------------------------
                                   1396 ;position      Allocated with name '_ak820_cached_key_position_10000_392'
                                   1397 ;slot          Allocated with name '_ak820_cached_key_slot_10001_396'
                                   1398 ;------------------------------------------------------------
                                   1399 ;	quantum/action_layer.c:383: uint16_t ak820_cached_key(uint16_t position) {
                                   1400 ;	-----------------------------------------
                                   1401 ;	 function ak820_cached_key
                                   1402 ;	-----------------------------------------
      007F3D                       1403 _ak820_cached_key:
      007F3D 12 38 44         [24] 1404 	lcall	_ak820_outline_0109
      007F40 90 09 CC         [24] 1405 	mov	dptr,#_ak820_cached_key_position_10000_392
      007F43 12 38 49         [24] 1406 	lcall	_ak820_outline_0110
                                   1407 ;	quantum/action_layer.c:386: if (vial_unlock_in_progress) return KC_NO;
      007F46 90 0E B3         [24] 1408 	mov	dptr,#_vial_unlock_in_progress
      007F49 E0               [24] 1409 	movx	a,@dptr
      007F4A 60 04            [24] 1410 	jz	00102$
      007F4C 90 00 00         [24] 1411 	mov	dptr,#0x0000
      007F4F 22               [24] 1412 	ret
      007F50                       1413 00102$:
                                   1414 ;	quantum/action_layer.c:387: if (position == (((uint16_t)VIAL_MATRIX_MAGIC << 8) | VIAL_MATRIX_MAGIC)) return g_vial_magic_keycode_override;
      007F50 90 09 CC         [24] 1415 	mov	dptr,#_ak820_cached_key_position_10000_392
      007F53 12 37 FD         [24] 1416 	lcall	_ak820_outline_0056
      007F56 BE F0 0D         [24] 1417 	cjne	r6,#0xf0,00104$
      007F59 BF F0 0A         [24] 1418 	cjne	r7,#0xf0,00104$
      007F5C 90 0D 07         [24] 1419 	mov	dptr,#_g_vial_magic_keycode_override
      007F5F 12 38 14         [24] 1420 	lcall	_ak820_outline_0062
      007F62 12 38 54         [24] 1421 	lcall	_ak820_outline_0128
      007F65 22               [24] 1422 	ret
      007F66                       1423 00104$:
                                   1424 ;	quantum/action_layer.c:389: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007F66 12 49 5D         [24] 1425 	lcall	_ak820_outline_0120
      007F69 D1 56            [24] 1426 	acall	_source_keycode_cache_slot
      007F6B 12 49 6E         [24] 1427 	lcall	_ak820_outline_0139
                                   1428 ;	quantum/action_layer.c:390: return slot ? *slot : KC_NO;
      007F6E EE               [12] 1429 	mov	a,r6
      007F6F 4F               [12] 1430 	orl	a,r7
      007F70 60 08            [24] 1431 	jz	00107$
      007F72 12 49 5D         [24] 1432 	lcall	_ak820_outline_0120
      007F75 12 37 FD         [24] 1433 	lcall	_ak820_outline_0056
      007F78 80 04            [24] 1434 	sjmp	00108$
      007F7A                       1435 00107$:
      007F7A 7E 00            [12] 1436 	mov	r6,#0x00
      007F7C 7F 00            [12] 1437 	mov	r7,#0x00
      007F7E                       1438 00108$:
      007F7E 12 49 5D         [24] 1439 	lcall	_ak820_outline_0120
                                   1440 ;	quantum/action_layer.c:391: }
      007F81 22               [24] 1441 	ret
                                   1442 ;------------------------------------------------------------
                                   1443 ;Allocation info for local variables in function 'update_source_keycode_cache'
                                   1444 ;------------------------------------------------------------
                                   1445 ;key           Allocated with name '_update_source_keycode_cache_PARM_1'
                                   1446 ;keycode       Allocated with name '_update_source_keycode_cache_keycode_10000_397'
                                   1447 ;------------------------------------------------------------
                                   1448 ;	quantum/action_layer.c:394: bool update_source_keycode_cache(keypos_t key, uint16_t keycode) {
                                   1449 ;	-----------------------------------------
                                   1450 ;	 function ak820_resolve_key
                                   1451 ;	-----------------------------------------
      007F82                       1452 _ak820_resolve_key:
      007F82 12 38 44         [24] 1453 	lcall	_ak820_outline_0109
      007F85 90 09 CF         [24] 1454 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007F88 12 38 49         [24] 1455 	lcall	_ak820_outline_0110
                                   1456 ;	quantum/action_layer.c:493: if (disable_action_cache) {
      007F8B 90 0E 52         [24] 1457 	mov	dptr,#_disable_action_cache
      007F8E E0               [24] 1458 	movx	a,@dptr
      007F8F 60 1E            [24] 1459 	jz	00102$
                                   1460 ;	quantum/action_layer.c:494: return ak820_keycode_at(ak820_layer_for_key(position), position);
      007F91 90 09 CF         [24] 1461 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007F94 12 37 BE         [24] 1462 	lcall	_ak820_outline_0007
      007F97 C0 07            [24] 1463 	push	ar7
      007F99 C0 06            [24] 1464 	push	ar6
      007F9B 12 7F D9         [24] 1465 	lcall	_ak820_layer_for_key
      007F9E AD 82            [24] 1466 	mov	r5, dpl
      007FA0 D0 06            [24] 1467 	pop	ar6
      007FA2 D0 07            [24] 1468 	pop	ar7
      007FA4 90 0C 30         [24] 1469 	mov	dptr,#_ak820_keycode_at_PARM_2
      007FA7 12 4E 7D         [24] 1470 	lcall	_ak820_outline_0064
      007FAA 8D 82            [24] 1471 	mov	dpl, r5
      007FAC 02 9D 42         [24] 1472 	ljmp	_ak820_keycode_at
      007FAF                       1473 00102$:
                                   1474 ;	quantum/action_layer.c:496: if (cache_press) ak820_cache_layer(position, ak820_layer_for_key(position));
      007FAF 90 09 CE         [24] 1475 	mov	dptr,#_ak820_resolve_key_PARM_2
      007FB2 E0               [24] 1476 	movx	a,@dptr
      007FB3 60 1B            [24] 1477 	jz	00104$
      007FB5 90 09 CF         [24] 1478 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007FB8 12 37 BE         [24] 1479 	lcall	_ak820_outline_0007
      007FBB C0 07            [24] 1480 	push	ar7
      007FBD C0 06            [24] 1481 	push	ar6
      007FBF F1 D9            [12] 1482 	acall	_ak820_layer_for_key
      007FC1 E5 82            [12] 1483 	mov	a, dpl
      007FC3 D0 06            [24] 1484 	pop	ar6
      007FC5 D0 07            [24] 1485 	pop	ar7
      007FC7 90 09 C9         [24] 1486 	mov	dptr,#_ak820_cache_layer_PARM_2
      007FCA 12 49 3E         [24] 1487 	lcall	_ak820_outline_0063
      007FCD 12 7E F2         [24] 1488 	lcall	_ak820_cache_layer
      007FD0                       1489 00104$:
                                   1490 ;	quantum/action_layer.c:497: return ak820_cached_key(position);
      007FD0 90 09 CF         [24] 1491 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007FD3 12 37 BE         [24] 1492 	lcall	_ak820_outline_0007
                                   1493 ;	quantum/action_layer.c:498: }
      007FD6 02 7F 3D         [24] 1494 	ljmp	_ak820_cached_key
                                   1495 ;------------------------------------------------------------
                                   1496 ;Allocation info for local variables in function 'store_or_get_action'
                                   1497 ;------------------------------------------------------------
                                   1498 ;key           Allocated with name '_store_or_get_action_PARM_2'
                                   1499 ;pressed       Allocated with name '_store_or_get_action_pressed_10000_408'
                                   1500 ;------------------------------------------------------------
                                   1501 ;	quantum/action_layer.c:499: uint16_t store_or_get_action(bool pressed, keypos_t key) {
                                   1502 ;	-----------------------------------------
                                   1503 ;	 function ak820_layer_for_key
                                   1504 ;	-----------------------------------------
      007FD9                       1505 _ak820_layer_for_key:
      007FD9 12 38 44         [24] 1506 	lcall	_ak820_outline_0109
      007FDC 90 09 D1         [24] 1507 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      007FDF 12 38 49         [24] 1508 	lcall	_ak820_outline_0110
                                   1509 ;	quantum/action_layer.c:539: layer_state_t layers = layer_state | default_layer_state;
      007FE2 90 0E 53         [24] 1510 	mov	dptr,#_default_layer_state
      007FE5 E0               [24] 1511 	movx	a,@dptr
      007FE6 FF               [12] 1512 	mov	r7,a
      007FE7 90 0E 54         [24] 1513 	mov	dptr,#_layer_state
      007FEA E0               [24] 1514 	movx	a,@dptr
      007FEB 90 09 D3         [24] 1515 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      007FEE 4F               [12] 1516 	orl	a,r7
      007FEF F0               [24] 1517 	movx	@dptr,a
                                   1518 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007FF0 90 09 D1         [24] 1519 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      007FF3 12 37 FD         [24] 1520 	lcall	_ak820_outline_0056
      007FF6 7D 05            [12] 1521 	mov	r5,#0x05
      007FF8                       1522 00107$:
      007FF8 ED               [12] 1523 	mov	a,r5
      007FF9 20 E7 4B         [24] 1524 	jb	acc.7,00105$
                                   1525 ;	quantum/action_layer.c:542: if (layers & ((layer_state_t)1 << i)) {
      007FFC 8D F0            [24] 1526 	mov	b,r5
      007FFE 05 F0            [12] 1527 	inc	b
      008000 7B 01            [12] 1528 	mov	r3,#0x01
      008002 7C 00            [12] 1529 	mov	r4,#0x00
      008004 80 06            [24] 1530 	sjmp	00141$
      008006                       1531 00140$:
      008006 EB               [12] 1532 	mov	a,r3
      008007 2B               [12] 1533 	add	a,r3
      008008 FB               [12] 1534 	mov	r3,a
      008009 EC               [12] 1535 	mov	a,r4
      00800A 33               [12] 1536 	rlc	a
      00800B FC               [12] 1537 	mov	r4,a
      00800C                       1538 00141$:
      00800C D5 F0 F7         [24] 1539 	djnz	b,00140$
      00800F 90 09 D3         [24] 1540 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      008012 E0               [24] 1541 	movx	a,@dptr
      008013 7A 00            [12] 1542 	mov	r2,#0x00
      008015 52 03            [12] 1543 	anl	ar3,a
      008017 EA               [12] 1544 	mov	a,r2
      008018 52 04            [12] 1545 	anl	ar4,a
      00801A EB               [12] 1546 	mov	a,r3
      00801B 4C               [12] 1547 	orl	a,r4
      00801C 60 26            [24] 1548 	jz	00108$
                                   1549 ;	quantum/action_layer.c:546: if (ak820_keycode_at(i, position) != KC_TRANSPARENT) {
      00801E 90 0C 30         [24] 1550 	mov	dptr,#_ak820_keycode_at_PARM_2
      008021 12 4E 7D         [24] 1551 	lcall	_ak820_outline_0064
      008024 8D 82            [24] 1552 	mov	dpl, r5
      008026 C0 07            [24] 1553 	push	ar7
      008028 C0 06            [24] 1554 	push	ar6
      00802A C0 05            [24] 1555 	push	ar5
      00802C 12 9D 42         [24] 1556 	lcall	_ak820_keycode_at
      00802F AB 82            [24] 1557 	mov	r3, dpl
      008031 AC 83            [24] 1558 	mov	r4, dph
      008033 D0 05            [24] 1559 	pop	ar5
      008035 D0 06            [24] 1560 	pop	ar6
      008037 D0 07            [24] 1561 	pop	ar7
      008039 BB 01 05         [24] 1562 	cjne	r3,#0x01,00143$
      00803C BC 00 02         [24] 1563 	cjne	r4,#0x00,00143$
      00803F 80 03            [24] 1564 	sjmp	00108$
      008041                       1565 00143$:
                                   1566 ;	quantum/action_layer.c:555: return i;
      008041 8D 82            [24] 1567 	mov	dpl, r5
      008043 22               [24] 1568 	ret
      008044                       1569 00108$:
                                   1570 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      008044 1D               [12] 1571 	dec	r5
      008045 80 B1            [24] 1572 	sjmp	00107$
      008047                       1573 00105$:
                                   1574 ;	quantum/action_layer.c:560: return 0;
      008047 75 82 00         [24] 1575 	mov	dpl, #0x00
                                   1576 ;	quantum/action_layer.c:565: }
      00804A 22               [24] 1577 	ret
                                   1578 ;------------------------------------------------------------
                                   1579 ;Allocation info for local variables in function 'layer_switch_get_layer'
                                   1580 ;------------------------------------------------------------
                                   1581 ;key           Allocated with name '_layer_switch_get_layer_PARM_1'
                                   1582 ;------------------------------------------------------------
                                   1583 ;	quantum/action_layer.c:567: uint8_t layer_switch_get_layer(keypos_t key) {
                                   1584 ;	-----------------------------------------
                                   1585 	.area CSEG    (CODE)
                                   1586 	.area CONST   (CODE)
                                   1587 	.area XINIT   (CODE)
      00C817                       1588 __xinit__default_layer_state:
      00C817 00                    1589 	.db #0x00	; 0
      00C818                       1590 __xinit__layer_state:
      00C818 00                    1591 	.db #0x00	; 0
                                   1592 	.area CABS    (ABS,CODE)
                                   1593 
                                   1594 ; Experimental exact instruction outlining.
                                   1595 	.globl _ak820_outline_0007
                                   1596 	.globl _ak820_outline_0056
                                   1597 	.globl _ak820_outline_0062
                                   1598 	.globl _ak820_outline_0063
                                   1599 	.globl _ak820_outline_0064
                                   1600 	.globl _ak820_outline_0078
                                   1601 	.globl _ak820_outline_0092
                                   1602 	.globl _ak820_outline_0098
                                   1603 	.globl _ak820_outline_0109
                                   1604 	.globl _ak820_outline_0110
                                   1605 	.globl _ak820_outline_0120
                                   1606 	.globl _ak820_outline_0128
                                   1607 	.globl _ak820_outline_0134
                                   1608 	.globl _ak820_outline_0138
                                   1609 	.globl _ak820_outline_0139
                                   1610 	.globl _ak820_outline_0146
                                   1611 	.globl _ak820_outline_0155
                                   1612 	.globl _ak820_outline_0164
                                   1613 	.globl _ak820_outline_0171
                                   1614 	.globl _ak820_outline_0178
                                   1615 	.globl _ak820_outline_0183
                                   1616 	.globl _ak820_outline_0193
                                   1617 
                                   1618 	.area CSEG (CODE)
                                   1619 ; function ak820_outline_0092
      00804B                       1620 _ak820_outline_0092:
      00804B F0               [24] 1621 	movx	@dptr,a
      00804C E0               [24] 1622 	movx	a,@dptr
      00804D F5 F0            [12] 1623 	mov	b,a
      00804F 05 F0            [12] 1624 	inc	b
      008051 74 01            [12] 1625 	mov	a,#0x01
      008053 22               [24] 1626 	ret
                                   1627 
                                   1628 	.area CSEG (CODE)
                                   1629 ; function ak820_outline_0146
      008054                       1630 _ak820_outline_0146:
      008054 E0               [24] 1631 	movx	a,@dptr
      008055 42 07            [12] 1632 	orl	ar7,a
      008057 8F 82            [24] 1633 	mov	dpl,r7
      008059 22               [24] 1634 	ret
                                   1635 
                                   1636 	.area CSEG (CODE)
                                   1637 ; function ak820_outline_0171
      00805A                       1638 _ak820_outline_0171:
      00805A F5 83            [12] 1639 	mov	dph,a
      00805C E4               [12] 1640 	clr	a
      00805D F0               [24] 1641 	movx	@dptr,a
      00805E 0F               [12] 1642 	inc	r7
      00805F 22               [24] 1643 	ret
                                   1644 
                                   1645 	.area CSEG (CODE)
                                   1646 ; function ak820_outline_0183
      008060                       1647 _ak820_outline_0183:
      008060 90 09 EA         [24] 1648 	mov	dptr,#_ak820_macro_change_PARM_2
      008063 EF               [12] 1649 	mov	a,r7
      008064 F0               [24] 1650 	movx	@dptr,a
      008065 90 09 EB         [24] 1651 	mov	dptr,#_ak820_macro_change_PARM_3
      008068 22               [24] 1652 	ret
