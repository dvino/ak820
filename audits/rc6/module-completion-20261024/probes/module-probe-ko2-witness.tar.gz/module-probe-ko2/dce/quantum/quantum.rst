                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_key_override_process
                                     18 	.globl _process_repeat_key
                                     19 	.globl _process_last_key
                                     20 	.globl _get_repeat_key_count
                                     21 	.globl _process_caps_word
                                     22 	.globl _process_record_via
                                     23 	.globl _get_weak_mods
                                     24 	.globl _get_mods
                                     25 	.globl _send_keyboard_report
                                     26 	.globl _mcu_reset
                                     27 	.globl _bootloader_jump
                                     28 	.globl _ak820_resolve_key
                                     29 	.globl _default_layer_set
                                     30 	.globl _biton
                                     31 	.globl _clear_keyboard
                                     32 	.globl _unregister_weak_mods
                                     33 	.globl _register_weak_mods
                                     34 	.globl _unregister_mods
                                     35 	.globl _register_mods
                                     36 	.globl _unregister_code
                                     37 	.globl _register_code
                                     38 	.globl _eeconfig_disable
                                     39 	.globl _rgb_matrix_set_suspend_state
                                     40 	.globl _rgb_matrix_task
                                     41 	.globl _mDelaymS
                                     42 	.globl _ADC_START
                                     43 	.globl _S0_R_FIFO
                                     44 	.globl _S0_T_FIFO
                                     45 	.globl _S0_FREE
                                     46 	.globl _S0_IF_BYTE
                                     47 	.globl _S0_IF_FIRST
                                     48 	.globl _S0_IF_OV
                                     49 	.globl _S0_FST_ACT
                                     50 	.globl _CP_RL2
                                     51 	.globl _C_T2
                                     52 	.globl _TR2
                                     53 	.globl _EXEN2
                                     54 	.globl _TCLK
                                     55 	.globl _RCLK
                                     56 	.globl _EXF2
                                     57 	.globl _CAP1F
                                     58 	.globl _TF2
                                     59 	.globl _RI
                                     60 	.globl _TI
                                     61 	.globl _RB8
                                     62 	.globl _TB8
                                     63 	.globl _REN
                                     64 	.globl _SM2
                                     65 	.globl _SM1
                                     66 	.globl _SM0
                                     67 	.globl _IT0
                                     68 	.globl _IE0
                                     69 	.globl _IT1
                                     70 	.globl _IE1
                                     71 	.globl _TR0
                                     72 	.globl _TF0
                                     73 	.globl _TR1
                                     74 	.globl _TF1
                                     75 	.globl _P4_0
                                     76 	.globl _P4_1
                                     77 	.globl _P4_2
                                     78 	.globl _P4_3
                                     79 	.globl _P4_4
                                     80 	.globl _P4_5
                                     81 	.globl _P4_6
                                     82 	.globl _RXD
                                     83 	.globl _TXD
                                     84 	.globl _INT0
                                     85 	.globl _INT1
                                     86 	.globl _T0
                                     87 	.globl _T1
                                     88 	.globl _MOSI1
                                     89 	.globl _MISO1
                                     90 	.globl _SCK1
                                     91 	.globl _P3_0
                                     92 	.globl _P3_1
                                     93 	.globl _P3_2
                                     94 	.globl _P3_3
                                     95 	.globl _P3_4
                                     96 	.globl _P3_5
                                     97 	.globl _P3_6
                                     98 	.globl _P3_7
                                     99 	.globl _CAP1_
                                    100 	.globl _T2_
                                    101 	.globl _CAP2_
                                    102 	.globl _T2EX_
                                    103 	.globl _RXD1
                                    104 	.globl _TXD1
                                    105 	.globl _P2_0
                                    106 	.globl _P2_1
                                    107 	.globl _P2_2
                                    108 	.globl _P2_3
                                    109 	.globl _P2_4
                                    110 	.globl _P2_5
                                    111 	.globl _P2_6
                                    112 	.globl _P2_7
                                    113 	.globl _AIN0
                                    114 	.globl _AIN1
                                    115 	.globl _AIN2
                                    116 	.globl _AIN3
                                    117 	.globl _AIN4
                                    118 	.globl _AIN5
                                    119 	.globl _AIN6
                                    120 	.globl _AIN7
                                    121 	.globl _CAP1
                                    122 	.globl _T2
                                    123 	.globl _CAP2
                                    124 	.globl _T2EX
                                    125 	.globl _INT0_
                                    126 	.globl _SCS
                                    127 	.globl _MOSI
                                    128 	.globl _MISO
                                    129 	.globl _SCK
                                    130 	.globl _RXD1_
                                    131 	.globl _TXD1_
                                    132 	.globl _P1_0
                                    133 	.globl _P1_1
                                    134 	.globl _P1_2
                                    135 	.globl _P1_3
                                    136 	.globl _P1_4
                                    137 	.globl _P1_5
                                    138 	.globl _P1_6
                                    139 	.globl _P1_7
                                    140 	.globl _AIN8
                                    141 	.globl _AIN9
                                    142 	.globl _AIN10
                                    143 	.globl _AIN11
                                    144 	.globl _AIN12
                                    145 	.globl _AIN13
                                    146 	.globl _RXD_
                                    147 	.globl _TXD_
                                    148 	.globl _SCL0
                                    149 	.globl _SDA0
                                    150 	.globl _P0_0
                                    151 	.globl _P0_1
                                    152 	.globl _P0_2
                                    153 	.globl _P0_3
                                    154 	.globl _P0_4
                                    155 	.globl _P0_5
                                    156 	.globl _P0_6
                                    157 	.globl _P0_7
                                    158 	.globl _IE_SPI0
                                    159 	.globl _IE_USB
                                    160 	.globl _IE_ADC
                                    161 	.globl _IE_UART1
                                    162 	.globl _IE_PWM_I2C
                                    163 	.globl _IE_GPIO
                                    164 	.globl _IE_WDOG
                                    165 	.globl _PX0
                                    166 	.globl _PT0
                                    167 	.globl _PX1
                                    168 	.globl _PT1
                                    169 	.globl _PS
                                    170 	.globl _PT2
                                    171 	.globl _PL_FLAG
                                    172 	.globl _PH_FLAG
                                    173 	.globl _EX0
                                    174 	.globl _ET0
                                    175 	.globl _EX1
                                    176 	.globl _ET1
                                    177 	.globl _ES
                                    178 	.globl _ET2
                                    179 	.globl _E_DIS
                                    180 	.globl _EA
                                    181 	.globl _P
                                    182 	.globl _F1
                                    183 	.globl _OV
                                    184 	.globl _RS0
                                    185 	.globl _RS1
                                    186 	.globl _F0
                                    187 	.globl _AC
                                    188 	.globl _CY
                                    189 	.globl _I2CS_INT_ST
                                    190 	.globl _I2CX_INT
                                    191 	.globl _LED_STATUS
                                    192 	.globl _LED_DMA_H
                                    193 	.globl _LED_DMA_L
                                    194 	.globl _LED_DMA
                                    195 	.globl _LED_PWM_OE
                                    196 	.globl _LED_COMMON
                                    197 	.globl _ADC_CHAN
                                    198 	.globl _ADC_DAT_H
                                    199 	.globl _ADC_DAT_L
                                    200 	.globl _ADC_DAT
                                    201 	.globl _ADC_CTRL
                                    202 	.globl _SPI1_CK_SE
                                    203 	.globl _SPI1_CTRL
                                    204 	.globl _SPI1_DATA
                                    205 	.globl _SPI1_STAT
                                    206 	.globl _SIF1
                                    207 	.globl _SBAUD1
                                    208 	.globl _SBUF1
                                    209 	.globl _SCON1
                                    210 	.globl _SPI0_SETUP
                                    211 	.globl _SPI0_CK_SE
                                    212 	.globl _SPI0_CTRL
                                    213 	.globl _SPI0_DATA
                                    214 	.globl _SPI0_STAT
                                    215 	.globl _T2CAP1H
                                    216 	.globl _T2CAP1L
                                    217 	.globl _T2CAP1
                                    218 	.globl _TH2
                                    219 	.globl _TL2
                                    220 	.globl _T2COUNT
                                    221 	.globl _RCAP2H
                                    222 	.globl _RCAP2L
                                    223 	.globl _RCAP2
                                    224 	.globl _T2MOD
                                    225 	.globl _T2CON
                                    226 	.globl _SBUF
                                    227 	.globl _SCON
                                    228 	.globl _TH1
                                    229 	.globl _TH0
                                    230 	.globl _TL1
                                    231 	.globl _TL0
                                    232 	.globl _TMOD
                                    233 	.globl _TCON
                                    234 	.globl _XBUS_AUX
                                    235 	.globl _P7
                                    236 	.globl _P6_DIR
                                    237 	.globl _P6_OUT_PU
                                    238 	.globl _P6_IN
                                    239 	.globl _P5_DIR
                                    240 	.globl _P5_OUT_PU
                                    241 	.globl _P5_IN
                                    242 	.globl _P4_LED_KEY
                                    243 	.globl _P4_DIR_PU
                                    244 	.globl _P4_MOD_OC
                                    245 	.globl _P4
                                    246 	.globl _P3_DIR_PU
                                    247 	.globl _P3_MOD_OC
                                    248 	.globl _P3
                                    249 	.globl _P2_DIR_PU
                                    250 	.globl _P2_MOD_OC
                                    251 	.globl _P2
                                    252 	.globl _P1_DIR_PU
                                    253 	.globl _P1_MOD_OC
                                    254 	.globl _P1
                                    255 	.globl _P0_DIR_PU
                                    256 	.globl _P0_MOD_OC
                                    257 	.globl _P0
                                    258 	.globl _ROM_CTRL
                                    259 	.globl _ROM_DATA_HH
                                    260 	.globl _ROM_DATA_HL
                                    261 	.globl _ROM_DATA_HI
                                    262 	.globl _ROM_ADDR_H
                                    263 	.globl _ROM_ADDR_L
                                    264 	.globl _ROM_ADDR
                                    265 	.globl _GPIO_IE
                                    266 	.globl _IP_EX
                                    267 	.globl _IE_EX
                                    268 	.globl _IP
                                    269 	.globl _IE
                                    270 	.globl _WDOG_COUNT
                                    271 	.globl _RESET_KEEP
                                    272 	.globl _WAKE_CTRL
                                    273 	.globl _CLOCK_CFG
                                    274 	.globl _POWER_CFG
                                    275 	.globl _PCON
                                    276 	.globl _GLOBAL_CFG
                                    277 	.globl _SAFE_MOD
                                    278 	.globl _DPH
                                    279 	.globl _DPL
                                    280 	.globl _SP
                                    281 	.globl _A_INV
                                    282 	.globl _B
                                    283 	.globl _ACC
                                    284 	.globl _PSW
                                    285 	.globl _process_record_quantum_helper_PARM_2
                                    286 	.globl _get_record_keycode_PARM_2
                                    287 	.globl _register_code16
                                    288 	.globl _unregister_code16
                                    289 	.globl _reset_keyboard
                                    290 	.globl _soft_reset_keyboard
                                    291 	.globl _get_record_keycode
                                    292 	.globl _pre_process_record_quantum
                                    293 	.globl _process_record_quantum
                                    294 	.globl _process_record_quantum_helper
                                    295 	.globl _shutdown_user
                                    296 ;--------------------------------------------------------
                                    297 ; special function registers
                                    298 ;--------------------------------------------------------
                                    299 	.area RSEG    (ABS,DATA)
      000000                        300 	.org 0x0000
                           0000D0   301 _PSW	=	0x00d0
                           0000E0   302 _ACC	=	0x00e0
                           0000F0   303 _B	=	0x00f0
                           0000FD   304 _A_INV	=	0x00fd
                           000081   305 _SP	=	0x0081
                           000082   306 _DPL	=	0x0082
                           000083   307 _DPH	=	0x0083
                           0000A1   308 _SAFE_MOD	=	0x00a1
                           0000B1   309 _GLOBAL_CFG	=	0x00b1
                           000087   310 _PCON	=	0x0087
                           0000BA   311 _POWER_CFG	=	0x00ba
                           0000B9   312 _CLOCK_CFG	=	0x00b9
                           0000A9   313 _WAKE_CTRL	=	0x00a9
                           0000FE   314 _RESET_KEEP	=	0x00fe
                           0000FF   315 _WDOG_COUNT	=	0x00ff
                           0000A8   316 _IE	=	0x00a8
                           0000B8   317 _IP	=	0x00b8
                           0000E8   318 _IE_EX	=	0x00e8
                           0000E9   319 _IP_EX	=	0x00e9
                           0000B2   320 _GPIO_IE	=	0x00b2
                           008584   321 _ROM_ADDR	=	0x8584
                           000084   322 _ROM_ADDR_L	=	0x0084
                           000085   323 _ROM_ADDR_H	=	0x0085
                           008F8E   324 _ROM_DATA_HI	=	0x8f8e
                           00008E   325 _ROM_DATA_HL	=	0x008e
                           00008F   326 _ROM_DATA_HH	=	0x008f
                           000086   327 _ROM_CTRL	=	0x0086
                           000080   328 _P0	=	0x0080
                           0000C4   329 _P0_MOD_OC	=	0x00c4
                           0000C5   330 _P0_DIR_PU	=	0x00c5
                           000090   331 _P1	=	0x0090
                           000092   332 _P1_MOD_OC	=	0x0092
                           000093   333 _P1_DIR_PU	=	0x0093
                           0000A0   334 _P2	=	0x00a0
                           000094   335 _P2_MOD_OC	=	0x0094
                           000095   336 _P2_DIR_PU	=	0x0095
                           0000B0   337 _P3	=	0x00b0
                           000096   338 _P3_MOD_OC	=	0x0096
                           000097   339 _P3_DIR_PU	=	0x0097
                           0000C0   340 _P4	=	0x00c0
                           0000C2   341 _P4_MOD_OC	=	0x00c2
                           0000C3   342 _P4_DIR_PU	=	0x00c3
                           0000C1   343 _P4_LED_KEY	=	0x00c1
                           0000AA   344 _P5_IN	=	0x00aa
                           0000AB   345 _P5_OUT_PU	=	0x00ab
                           0000AC   346 _P5_DIR	=	0x00ac
                           0000AD   347 _P6_IN	=	0x00ad
                           0000AE   348 _P6_OUT_PU	=	0x00ae
                           0000AF   349 _P6_DIR	=	0x00af
                           0000F1   350 _P7	=	0x00f1
                           0000A2   351 _XBUS_AUX	=	0x00a2
                           000088   352 _TCON	=	0x0088
                           000089   353 _TMOD	=	0x0089
                           00008A   354 _TL0	=	0x008a
                           00008B   355 _TL1	=	0x008b
                           00008C   356 _TH0	=	0x008c
                           00008D   357 _TH1	=	0x008d
                           000098   358 _SCON	=	0x0098
                           000099   359 _SBUF	=	0x0099
                           0000C8   360 _T2CON	=	0x00c8
                           0000C9   361 _T2MOD	=	0x00c9
                           00CBCA   362 _RCAP2	=	0xcbca
                           0000CA   363 _RCAP2L	=	0x00ca
                           0000CB   364 _RCAP2H	=	0x00cb
                           00CDCC   365 _T2COUNT	=	0xcdcc
                           0000CC   366 _TL2	=	0x00cc
                           0000CD   367 _TH2	=	0x00cd
                           00CFCE   368 _T2CAP1	=	0xcfce
                           0000CE   369 _T2CAP1L	=	0x00ce
                           0000CF   370 _T2CAP1H	=	0x00cf
                           0000F8   371 _SPI0_STAT	=	0x00f8
                           0000F9   372 _SPI0_DATA	=	0x00f9
                           0000FA   373 _SPI0_CTRL	=	0x00fa
                           0000FB   374 _SPI0_CK_SE	=	0x00fb
                           0000FC   375 _SPI0_SETUP	=	0x00fc
                           0000BC   376 _SCON1	=	0x00bc
                           0000BD   377 _SBUF1	=	0x00bd
                           0000BE   378 _SBAUD1	=	0x00be
                           0000BF   379 _SIF1	=	0x00bf
                           0000B4   380 _SPI1_STAT	=	0x00b4
                           0000B5   381 _SPI1_DATA	=	0x00b5
                           0000B6   382 _SPI1_CTRL	=	0x00b6
                           0000B7   383 _SPI1_CK_SE	=	0x00b7
                           0000F3   384 _ADC_CTRL	=	0x00f3
                           00F5F4   385 _ADC_DAT	=	0xf5f4
                           0000F4   386 _ADC_DAT_L	=	0x00f4
                           0000F5   387 _ADC_DAT_H	=	0x00f5
                           0000F6   388 _ADC_CHAN	=	0x00f6
                           0000A6   389 _LED_COMMON	=	0x00a6
                           0000A7   390 _LED_PWM_OE	=	0x00a7
                           00C7C6   391 _LED_DMA	=	0xc7c6
                           0000C6   392 _LED_DMA_L	=	0x00c6
                           0000C7   393 _LED_DMA_H	=	0x00c7
                           0000F7   394 _LED_STATUS	=	0x00f7
                           0000B3   395 _I2CX_INT	=	0x00b3
                           0000BB   396 _I2CS_INT_ST	=	0x00bb
                                    397 ;--------------------------------------------------------
                                    398 ; special function bits
                                    399 ;--------------------------------------------------------
                                    400 	.area RSEG    (ABS,DATA)
      000000                        401 	.org 0x0000
                           0000D7   402 _CY	=	0x00d7
                           0000D6   403 _AC	=	0x00d6
                           0000D5   404 _F0	=	0x00d5
                           0000D4   405 _RS1	=	0x00d4
                           0000D3   406 _RS0	=	0x00d3
                           0000D2   407 _OV	=	0x00d2
                           0000D1   408 _F1	=	0x00d1
                           0000D0   409 _P	=	0x00d0
                           0000AF   410 _EA	=	0x00af
                           0000AE   411 _E_DIS	=	0x00ae
                           0000AD   412 _ET2	=	0x00ad
                           0000AC   413 _ES	=	0x00ac
                           0000AB   414 _ET1	=	0x00ab
                           0000AA   415 _EX1	=	0x00aa
                           0000A9   416 _ET0	=	0x00a9
                           0000A8   417 _EX0	=	0x00a8
                           0000BF   418 _PH_FLAG	=	0x00bf
                           0000BE   419 _PL_FLAG	=	0x00be
                           0000BD   420 _PT2	=	0x00bd
                           0000BC   421 _PS	=	0x00bc
                           0000BB   422 _PT1	=	0x00bb
                           0000BA   423 _PX1	=	0x00ba
                           0000B9   424 _PT0	=	0x00b9
                           0000B8   425 _PX0	=	0x00b8
                           0000EF   426 _IE_WDOG	=	0x00ef
                           0000EE   427 _IE_GPIO	=	0x00ee
                           0000ED   428 _IE_PWM_I2C	=	0x00ed
                           0000EC   429 _IE_UART1	=	0x00ec
                           0000EB   430 _IE_ADC	=	0x00eb
                           0000E9   431 _IE_USB	=	0x00e9
                           0000E8   432 _IE_SPI0	=	0x00e8
                           000087   433 _P0_7	=	0x0087
                           000086   434 _P0_6	=	0x0086
                           000085   435 _P0_5	=	0x0085
                           000084   436 _P0_4	=	0x0084
                           000083   437 _P0_3	=	0x0083
                           000082   438 _P0_2	=	0x0082
                           000081   439 _P0_1	=	0x0081
                           000080   440 _P0_0	=	0x0080
                           000081   441 _SDA0	=	0x0081
                           000080   442 _SCL0	=	0x0080
                           000083   443 _TXD_	=	0x0083
                           000082   444 _RXD_	=	0x0082
                           000085   445 _AIN13	=	0x0085
                           000084   446 _AIN12	=	0x0084
                           000083   447 _AIN11	=	0x0083
                           000082   448 _AIN10	=	0x0082
                           000081   449 _AIN9	=	0x0081
                           000080   450 _AIN8	=	0x0080
                           000097   451 _P1_7	=	0x0097
                           000096   452 _P1_6	=	0x0096
                           000095   453 _P1_5	=	0x0095
                           000094   454 _P1_4	=	0x0094
                           000093   455 _P1_3	=	0x0093
                           000092   456 _P1_2	=	0x0092
                           000091   457 _P1_1	=	0x0091
                           000090   458 _P1_0	=	0x0090
                           000097   459 _TXD1_	=	0x0097
                           000096   460 _RXD1_	=	0x0096
                           000097   461 _SCK	=	0x0097
                           000096   462 _MISO	=	0x0096
                           000095   463 _MOSI	=	0x0095
                           000094   464 _SCS	=	0x0094
                           000092   465 _INT0_	=	0x0092
                           000091   466 _T2EX	=	0x0091
                           000091   467 _CAP2	=	0x0091
                           000090   468 _T2	=	0x0090
                           000090   469 _CAP1	=	0x0090
                           000097   470 _AIN7	=	0x0097
                           000096   471 _AIN6	=	0x0096
                           000095   472 _AIN5	=	0x0095
                           000094   473 _AIN4	=	0x0094
                           000093   474 _AIN3	=	0x0093
                           000092   475 _AIN2	=	0x0092
                           000091   476 _AIN1	=	0x0091
                           000090   477 _AIN0	=	0x0090
                           0000A7   478 _P2_7	=	0x00a7
                           0000A6   479 _P2_6	=	0x00a6
                           0000A5   480 _P2_5	=	0x00a5
                           0000A4   481 _P2_4	=	0x00a4
                           0000A3   482 _P2_3	=	0x00a3
                           0000A2   483 _P2_2	=	0x00a2
                           0000A1   484 _P2_1	=	0x00a1
                           0000A0   485 _P2_0	=	0x00a0
                           0000A7   486 _TXD1	=	0x00a7
                           0000A6   487 _RXD1	=	0x00a6
                           0000A5   488 _T2EX_	=	0x00a5
                           0000A5   489 _CAP2_	=	0x00a5
                           0000A4   490 _T2_	=	0x00a4
                           0000A4   491 _CAP1_	=	0x00a4
                           0000B7   492 _P3_7	=	0x00b7
                           0000B6   493 _P3_6	=	0x00b6
                           0000B5   494 _P3_5	=	0x00b5
                           0000B4   495 _P3_4	=	0x00b4
                           0000B3   496 _P3_3	=	0x00b3
                           0000B2   497 _P3_2	=	0x00b2
                           0000B1   498 _P3_1	=	0x00b1
                           0000B0   499 _P3_0	=	0x00b0
                           0000B7   500 _SCK1	=	0x00b7
                           0000B6   501 _MISO1	=	0x00b6
                           0000B5   502 _MOSI1	=	0x00b5
                           0000B5   503 _T1	=	0x00b5
                           0000B4   504 _T0	=	0x00b4
                           0000B3   505 _INT1	=	0x00b3
                           0000B2   506 _INT0	=	0x00b2
                           0000B1   507 _TXD	=	0x00b1
                           0000B0   508 _RXD	=	0x00b0
                           0000C6   509 _P4_6	=	0x00c6
                           0000C5   510 _P4_5	=	0x00c5
                           0000C4   511 _P4_4	=	0x00c4
                           0000C3   512 _P4_3	=	0x00c3
                           0000C2   513 _P4_2	=	0x00c2
                           0000C1   514 _P4_1	=	0x00c1
                           0000C0   515 _P4_0	=	0x00c0
                           00008F   516 _TF1	=	0x008f
                           00008E   517 _TR1	=	0x008e
                           00008D   518 _TF0	=	0x008d
                           00008C   519 _TR0	=	0x008c
                           00008B   520 _IE1	=	0x008b
                           00008A   521 _IT1	=	0x008a
                           000089   522 _IE0	=	0x0089
                           000088   523 _IT0	=	0x0088
                           00009F   524 _SM0	=	0x009f
                           00009E   525 _SM1	=	0x009e
                           00009D   526 _SM2	=	0x009d
                           00009C   527 _REN	=	0x009c
                           00009B   528 _TB8	=	0x009b
                           00009A   529 _RB8	=	0x009a
                           000099   530 _TI	=	0x0099
                           000098   531 _RI	=	0x0098
                           0000CF   532 _TF2	=	0x00cf
                           0000CF   533 _CAP1F	=	0x00cf
                           0000CE   534 _EXF2	=	0x00ce
                           0000CD   535 _RCLK	=	0x00cd
                           0000CC   536 _TCLK	=	0x00cc
                           0000CB   537 _EXEN2	=	0x00cb
                           0000CA   538 _TR2	=	0x00ca
                           0000C9   539 _C_T2	=	0x00c9
                           0000C8   540 _CP_RL2	=	0x00c8
                           0000FF   541 _S0_FST_ACT	=	0x00ff
                           0000FE   542 _S0_IF_OV	=	0x00fe
                           0000FD   543 _S0_IF_FIRST	=	0x00fd
                           0000FC   544 _S0_IF_BYTE	=	0x00fc
                           0000FB   545 _S0_FREE	=	0x00fb
                           0000FA   546 _S0_T_FIFO	=	0x00fa
                           0000F8   547 _S0_R_FIFO	=	0x00f8
                           0000F7   548 _ADC_START	=	0x00f7
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable register banks
                                    551 ;--------------------------------------------------------
                                    552 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        553 	.ds 8
                                    554 ;--------------------------------------------------------
                                    555 ; internal ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area DSEG    (DATA)
                                    558 ;--------------------------------------------------------
                                    559 ; overlayable items in internal ram
                                    560 ;--------------------------------------------------------
                                    561 ;--------------------------------------------------------
                                    562 ; indirectly addressable internal ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area ISEG    (DATA)
                                    565 ;--------------------------------------------------------
                                    566 ; absolute internal ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area IABS    (ABS,DATA)
                                    569 	.area IABS    (ABS,DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; bit data
                                    572 ;--------------------------------------------------------
                                    573 	.area BSEG    (BIT)
      000026                        574 _get_record_keycode_sloc0_1_0:
      000026                        575 	.ds 1
      000027                        576 _pre_process_record_quantum_sloc0_1_0:
      000027                        577 	.ds 1
      000028                        578 _process_ak820_nkro_sloc0_1_0:
      000028                        579 	.ds 1
                                    580 ;--------------------------------------------------------
                                    581 ; paged external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area PSEG    (PAG,XDATA)
                                    584 ;--------------------------------------------------------
                                    585 ; uninitialized external ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area XSEG    (XDATA)
      000C71                        588 _extract_mod_bits_code_10000_609:
      000C71                        589 	.ds 2
      000C73                        590 _register_code16_code_10000_615:
      000C73                        591 	.ds 2
      000C75                        592 _unregister_code16_code_10000_620:
      000C75                        593 	.ds 2
      000C77                        594 _get_record_keycode_PARM_2:
      000C77                        595 	.ds 1
      000C78                        596 _get_record_keycode_record_argument_10000_658:
      000C78                        597 	.ds 2
      000C7A                        598 _pre_process_record_quantum_record_argument_10000_664:
      000C7A                        599 	.ds 2
      000C7C                        600 _process_record_quantum_record_10000_668:
      000C7C                        601 	.ds 2
      000C7E                        602 _process_ak820_override_record_10000_670:
      000C7E                        603 	.ds 2
      000C80                        604 _process_ak820_nkro_PARM_2:
      000C80                        605 	.ds 3
      000C83                        606 _process_ak820_nkro_keycode_10000_674:
      000C83                        607 	.ds 2
      000C85                        608 _process_record_quantum_helper_PARM_2:
      000C85                        609 	.ds 2
      000C87                        610 _process_record_quantum_helper_keycode_10000_679:
      000C87                        611 	.ds 2
      000C89                        612 _get_u8_str_last_num_10000_705:
      000C89                        613 	.ds 1
      000C8A                        614 _get_u16_str_last_num_10000_709:
      000C8A                        615 	.ds 2
                                    616 ;--------------------------------------------------------
                                    617 ; absolute external ram data
                                    618 ;--------------------------------------------------------
                                    619 	.area XABS    (ABS,XDATA)
                                    620 ;--------------------------------------------------------
                                    621 ; initialized external ram data
                                    622 ;--------------------------------------------------------
                                    623 	.area XISEG   (XDATA)
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT0 (CODE)
                                    626 	.area GSINIT1 (CODE)
                                    627 	.area GSINIT2 (CODE)
                                    628 	.area GSINIT3 (CODE)
                                    629 	.area GSINIT4 (CODE)
                                    630 	.area GSINIT5 (CODE)
                                    631 	.area GSINIT  (CODE)
                                    632 	.area GSFINAL (CODE)
                                    633 	.area CSEG    (CODE)
                                    634 ;--------------------------------------------------------
                                    635 ; global & static initialisations
                                    636 ;--------------------------------------------------------
                                    637 	.area HOME    (CODE)
                                    638 	.area GSINIT  (CODE)
                                    639 	.area GSFINAL (CODE)
                                    640 	.area GSINIT  (CODE)
                                    641 ;------------------------------------------------------------
                                    642 ;Allocation info for local variables in function 'get_u8_str'
                                    643 ;------------------------------------------------------------
                                    644 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    645 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_704'
                                    646 ;buf           Allocated with name '_get_u8_str_buf_10000_705'
                                    647 ;last_num      Allocated with name '_get_u8_str_last_num_10000_705'
                                    648 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_705'
                                    649 ;------------------------------------------------------------
                                    650 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0C 89         [24]  651 	mov	dptr,#_get_u8_str_last_num_10000_705
      0030F6 74 FF            [12]  652 	mov	a,#0xff
      0030F8 F0               [24]  653 	movx	@dptr,a
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'get_u16_str'
                                    656 ;------------------------------------------------------------
                                    657 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    658 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_708'
                                    659 ;buf           Allocated with name '_get_u16_str_buf_10000_709'
                                    660 ;last_num      Allocated with name '_get_u16_str_last_num_10000_709'
                                    661 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_709'
                                    662 ;------------------------------------------------------------
                                    663 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0C 8A         [24]  664 	mov	dptr,#_get_u16_str_last_num_10000_709
      0030FC 74 FF            [12]  665 	mov	a,#0xff
      0030FE F0               [24]  666 	movx	@dptr,a
      0030FF E4               [12]  667 	clr	a
      003100 A3               [24]  668 	inc	dptr
      003101 F0               [24]  669 	movx	@dptr,a
                                    670 ;--------------------------------------------------------
                                    671 ; Home
                                    672 ;--------------------------------------------------------
                                    673 	.area HOME    (CODE)
                                    674 	.area HOME    (CODE)
                                    675 ;--------------------------------------------------------
                                    676 ; code
                                    677 ;--------------------------------------------------------
                                    678 	.area CSEG    (CODE)
                                    679 ;------------------------------------------------------------
                                    680 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    681 ;------------------------------------------------------------
                                    682 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    683 ;------------------------------------------------------------
                                    684 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    685 ;	-----------------------------------------
                           000007   686 	ar7 = 0x07
                           000006   687 	ar6 = 0x06
                           000005   688 	ar5 = 0x05
                           000004   689 	ar4 = 0x04
                           000003   690 	ar3 = 0x03
                           000002   691 	ar2 = 0x02
                           000001   692 	ar1 = 0x01
                           000000   693 	ar0 = 0x00
                                    694 ;	 function extract_mod_bits
                                    695 ;	-----------------------------------------
      00A45C                        696 _extract_mod_bits:
      00A45C 12 38 44         [24]  697 	lcall	_ak820_outline_0109
      00A45F 90 0C 71         [24]  698 	mov	dptr,#_extract_mod_bits_code_10000_609
      00A462 12 38 49         [24]  699 	lcall	_ak820_outline_0110
                                    700 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A465 90 0C 71         [24]  701 	mov	dptr,#_extract_mod_bits_code_10000_609
      00A468 E0               [24]  702 	movx	a,@dptr
      00A469 A3               [24]  703 	inc	dptr
      00A46A E0               [24]  704 	movx	a,@dptr
                                    705 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A46B FF               [12]  706 	mov	r7,a
      00A46C 60 05            [24]  707 	jz	00101$
      00A46E EF               [12]  708 	mov	a,r7
      00A46F 24 E0            [12]  709 	add	a,#0xff - 0x1f
      00A471 50 04            [24]  710 	jnc	00102$
                                    711 ;	free result
      00A473                        712 00101$:
      00A473 75 82 00         [24]  713 	mov	dpl, #0x00
      00A476 22               [24]  714 	ret
      00A477                        715 00102$:
                                    716 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A477 EF               [12]  717 	mov	a,r7
      00A478 30 E4 07         [24]  718 	jnb	acc.4,00106$
      00A47B EF               [12]  719 	mov	a,r7
      00A47C C4               [12]  720 	swap	a
      00A47D 54 F0            [12]  721 	anl	a,#0xf0
      00A47F FE               [12]  722 	mov	r6,a
      00A480 80 02            [24]  723 	sjmp	00107$
      00A482                        724 00106$:
      00A482 8F 06            [24]  725 	mov	ar6,r7
      00A484                        726 00107$:
      00A484 8E 82            [24]  727 	mov	dpl, r6
                                    728 ;	quantum/quantum.c:143: }
      00A486 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'do_code16'
                                    732 ;------------------------------------------------------------
                                    733 ;f             Allocated with name '_do_code16_PARM_2'
                                    734 ;code          Allocated with name '_do_code16_code_10000_612'
                                    735 ;------------------------------------------------------------
                                    736 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    737 ;	-----------------------------------------
                                    738 ;	 function register_code16
                                    739 ;	-----------------------------------------
      00A487                        740 _register_code16:
      00A487 12 38 44         [24]  741 	lcall	_ak820_outline_0109
      00A48A 90 0C 73         [24]  742 	mov	dptr,#_register_code16_code_10000_615
      00A48D 12 38 49         [24]  743 	lcall	_ak820_outline_0110
                                    744 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A490 90 0C 73         [24]  745 	mov	dptr,#_register_code16_code_10000_615
      00A493 12 37 BE         [24]  746 	lcall	_ak820_outline_0007
      00A496 C0 07            [24]  747 	push	ar7
      00A498 C0 06            [24]  748 	push	ar6
      00A49A 91 5C            [12]  749 	acall	_extract_mod_bits
      00A49C AD 82            [24]  750 	mov	r5, dpl
      00A49E D0 06            [24]  751 	pop	ar6
      00A4A0 D0 07            [24]  752 	pop	ar7
                                    753 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A4A2 12 A2 94         [24]  754 	lcall	_ak820_outline_0121
      00A4A5 40 07            [24]  755 	jc	00105$
      00A4A7 74 E7            [12]  756 	mov	a,#0xe7
      00A4A9 9E               [12]  757 	subb	a,r6
      00A4AA E4               [12]  758 	clr	a
      00A4AB 9F               [12]  759 	subb	a,r7
      00A4AC 50 08            [24]  760 	jnc	00101$
                                    761 ;	free result
      00A4AE                        762 00105$:
      00A4AE 90 0C 73         [24]  763 	mov	dptr,#_register_code16_code_10000_615
      00A4B1 12 73 11         [24]  764 	lcall	_ak820_outline_0040
      00A4B4 70 07            [24]  765 	jnz	00102$
      00A4B6                        766 00101$:
                                    767 ;	quantum/quantum.c:153: register_mods(mods);
      00A4B6 8D 82            [24]  768 	mov	dpl, r5
      00A4B8 12 7B 6D         [24]  769 	lcall	_register_mods
      00A4BB 80 05            [24]  770 	sjmp	00103$
      00A4BD                        771 00102$:
                                    772 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A4BD 8D 82            [24]  773 	mov	dpl, r5
      00A4BF 12 7B 95         [24]  774 	lcall	_register_weak_mods
      00A4C2                        775 00103$:
                                    776 ;	quantum/quantum.c:157: register_code(code);
      00A4C2 90 0C 73         [24]  777 	mov	dptr,#_register_code16_code_10000_615
      00A4C5 E0               [24]  778 	movx	a,@dptr
      00A4C6 F5 82            [12]  779 	mov	dpl,a
                                    780 ;	quantum/quantum.c:167: }
      00A4C8 02 7A 53         [24]  781 	ljmp	_register_code
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'unregister_code16'
                                    784 ;------------------------------------------------------------
                                    785 ;code          Allocated with name '_unregister_code16_code_10000_620'
                                    786 ;mods          Allocated with name '_unregister_code16_mods_10000_621'
                                    787 ;------------------------------------------------------------
                                    788 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    789 ;	-----------------------------------------
                                    790 ;	 function unregister_code16
                                    791 ;	-----------------------------------------
      00A4CB                        792 _unregister_code16:
      00A4CB 12 38 44         [24]  793 	lcall	_ak820_outline_0109
      00A4CE 90 0C 75         [24]  794 	mov	dptr,#_unregister_code16_code_10000_620
      00A4D1 12 38 49         [24]  795 	lcall	_ak820_outline_0110
                                    796 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A4D4 90 0C 75         [24]  797 	mov	dptr,#_unregister_code16_code_10000_620
      00A4D7 12 37 BE         [24]  798 	lcall	_ak820_outline_0007
      00A4DA C0 07            [24]  799 	push	ar7
      00A4DC C0 06            [24]  800 	push	ar6
      00A4DE 91 5C            [12]  801 	acall	_extract_mod_bits
      00A4E0 AD 82            [24]  802 	mov	r5, dpl
      00A4E2 D0 06            [24]  803 	pop	ar6
                                    804 ;	quantum/quantum.c:172: unregister_code(code);
      00A4E4 8E 04            [24]  805 	mov	ar4,r6
      00A4E6 8C 82            [24]  806 	mov	dpl, r4
      00A4E8 C0 06            [24]  807 	push	ar6
      00A4EA C0 05            [24]  808 	push	ar5
      00A4EC 12 7A BD         [24]  809 	lcall	_unregister_code
      00A4EF D0 05            [24]  810 	pop	ar5
      00A4F1 D0 06            [24]  811 	pop	ar6
      00A4F3 D0 07            [24]  812 	pop	ar7
                                    813 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A4F5 12 A2 94         [24]  814 	lcall	_ak820_outline_0121
      00A4F8 40 07            [24]  815 	jc	00105$
      00A4FA 74 E7            [12]  816 	mov	a,#0xe7
      00A4FC 9E               [12]  817 	subb	a,r6
      00A4FD E4               [12]  818 	clr	a
      00A4FE 9F               [12]  819 	subb	a,r7
      00A4FF 50 08            [24]  820 	jnc	00101$
                                    821 ;	free result
      00A501                        822 00105$:
      00A501 90 0C 75         [24]  823 	mov	dptr,#_unregister_code16_code_10000_620
      00A504 12 73 11         [24]  824 	lcall	_ak820_outline_0040
      00A507 70 05            [24]  825 	jnz	00102$
      00A509                        826 00101$:
                                    827 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A509 8D 82            [24]  828 	mov	dpl, r5
      00A50B 02 7B 81         [24]  829 	ljmp	_unregister_mods
      00A50E                        830 00102$:
                                    831 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A50E 8D 82            [24]  832 	mov	dpl, r5
                                    833 ;	quantum/quantum.c:187: }
      00A510 02 7B A9         [24]  834 	ljmp	_unregister_weak_mods
                                    835 ;------------------------------------------------------------
                                    836 ;Allocation info for local variables in function 'tap_code16_delay'
                                    837 ;------------------------------------------------------------
                                    838 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    839 ;code          Allocated with name '_tap_code16_delay_code_10000_625'
                                    840 ;i             Allocated with name '_tap_code16_delay_i_20000_627'
                                    841 ;i             Allocated with name '_tap_code16_delay_i_50000_630'
                                    842 ;------------------------------------------------------------
                                    843 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    844 ;	-----------------------------------------
                                    845 ;	 function shutdown_quantum
                                    846 ;	-----------------------------------------
      00A513                        847 _shutdown_quantum:
                                    848 ;	quantum/quantum.c:237: clear_keyboard();
      00A513 12 7B BD         [24]  849 	lcall	_clear_keyboard
                                    850 ;	quantum/quantum.c:252: shutdown_user();
      00A516 12 A8 12         [24]  851 	lcall	_shutdown_user
                                    852 ;	quantum/quantum.c:253: wait_ms(250);
      00A519 7F FA            [12]  853 	mov	r7,#0xfa
      00A51B                        854 00106$:
      00A51B EF               [12]  855 	mov	a,r7
      00A51C 60 09            [24]  856 	jz	00108$
      00A51E 90 00 01         [24]  857 	mov	dptr,#0x0001
      00A521 12 5E 7F         [24]  858 	lcall	_mDelaymS
      00A524 1F               [12]  859 	dec	r7
      00A525 80 F4            [24]  860 	sjmp	00106$
      00A527                        861 00108$:
                                    862 ;	quantum/quantum.c:258: }
      00A527 22               [24]  863 	ret
                                    864 ;------------------------------------------------------------
                                    865 ;Allocation info for local variables in function 'reset_keyboard'
                                    866 ;------------------------------------------------------------
                                    867 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    868 ;	-----------------------------------------
                                    869 ;	 function reset_keyboard
                                    870 ;	-----------------------------------------
      00A528                        871 _reset_keyboard:
                                    872 ;	quantum/quantum.c:261: shutdown_quantum();
      00A528 B1 13            [12]  873 	acall	_shutdown_quantum
                                    874 ;	quantum/quantum.c:262: bootloader_jump();
                                    875 ;	quantum/quantum.c:263: }
      00A52A 02 34 0E         [24]  876 	ljmp	_bootloader_jump
                                    877 ;------------------------------------------------------------
                                    878 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    879 ;------------------------------------------------------------
                                    880 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    881 ;	-----------------------------------------
                                    882 ;	 function soft_reset_keyboard
                                    883 ;	-----------------------------------------
      00A52D                        884 _soft_reset_keyboard:
                                    885 ;	quantum/quantum.c:266: shutdown_quantum();
      00A52D B1 13            [12]  886 	acall	_shutdown_quantum
                                    887 ;	quantum/quantum.c:267: mcu_reset();
                                    888 ;	quantum/quantum.c:268: }
      00A52F 02 34 01         [24]  889 	ljmp	_mcu_reset
                                    890 ;------------------------------------------------------------
                                    891 ;Allocation info for local variables in function 'get_record_keycode'
                                    892 ;------------------------------------------------------------
                                    893 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    894 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_658'
                                    895 ;record        Allocated with name '_get_record_keycode_record_10000_659'
                                    896 ;------------------------------------------------------------
                                    897 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    898 ;	-----------------------------------------
                                    899 ;	 function get_record_keycode
                                    900 ;	-----------------------------------------
      00A532                        901 _get_record_keycode:
      00A532 12 38 44         [24]  902 	lcall	_ak820_outline_0109
      00A535 90 0C 78         [24]  903 	mov	dptr,#_get_record_keycode_record_argument_10000_658
      00A538 12 38 49         [24]  904 	lcall	_ak820_outline_0110
                                    905 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A53B 90 0C 78         [24]  906 	mov	dptr,#_get_record_keycode_record_argument_10000_658
      00A53E 12 37 9D         [24]  907 	lcall	_ak820_outline_0001
                                    908 ;	quantum/quantum.c:278: if (record->keycode) {
      00A541 4C               [12]  909 	orl	a,r4
      00A542 60 04            [24]  910 	jz	00102$
                                    911 ;	quantum/quantum.c:279: return record->keycode;
      00A544 12 38 54         [24]  912 	lcall	_ak820_outline_0128
      00A547 22               [24]  913 	ret
      00A548                        914 00102$:
                                    915 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A548 12 7B FF         [24]  916 	lcall	_ak820_outline_0023
      00A54B 7A 00            [12]  917 	mov	r2,#0x00
      00A54D 12 49 79         [24]  918 	lcall	_ak820_outline_0147
      00A550 12 37 B1         [24]  919 	lcall	_ak820_outline_0006
      00A553 60 06            [24]  920 	jz	00105$
      00A555 90 0C 77         [24]  921 	mov	dptr,#_get_record_keycode_PARM_2
      00A558 E0               [24]  922 	movx	a,@dptr
      00A559 70 04            [24]  923 	jnz	00106$
      00A55B                        924 00105$:
                                    925 ;	assignBit
      00A55B C2 26            [12]  926 	clr	_get_record_keycode_sloc0_1_0
      00A55D 80 02            [24]  927 	sjmp	00107$
      00A55F                        928 00106$:
                                    929 ;	assignBit
      00A55F D2 26            [12]  930 	setb	_get_record_keycode_sloc0_1_0
      00A561                        931 00107$:
      00A561 90 09 CE         [24]  932 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A564 A2 26            [12]  933 	mov	c,_get_record_keycode_sloc0_1_0
      00A566 E4               [12]  934 	clr	a
      00A567 33               [12]  935 	rlc	a
      00A568 F0               [24]  936 	movx	@dptr,a
      00A569 8D 82            [24]  937 	mov	dpl, r5
      00A56B 8C 83            [24]  938 	mov	dph, r4
                                    939 ;	quantum/quantum.c:287: }
      00A56D 02 7F 82         [24]  940 	ljmp	_ak820_resolve_key
                                    941 ;------------------------------------------------------------
                                    942 ;Allocation info for local variables in function 'get_event_keycode'
                                    943 ;------------------------------------------------------------
                                    944 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    945 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_662'
                                    946 ;------------------------------------------------------------
                                    947 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    948 ;	-----------------------------------------
                                    949 ;	 function pre_process_record_quantum
                                    950 ;	-----------------------------------------
      00A570                        951 _pre_process_record_quantum:
      00A570 12 38 44         [24]  952 	lcall	_ak820_outline_0109
      00A573 90 0C 7A         [24]  953 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_664
      00A576 12 38 49         [24]  954 	lcall	_ak820_outline_0110
                                    955 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A579 90 0C 7A         [24]  956 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_664
      00A57C 12 37 FD         [24]  957 	lcall	_ak820_outline_0056
                                    958 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A57F 90 0C 77         [24]  959 	mov	dptr,#_get_record_keycode_PARM_2
      00A582 74 01            [12]  960 	mov	a,#0x01
      00A584 12 49 3E         [24]  961 	lcall	_ak820_outline_0063
      00A587 C0 07            [24]  962 	push	ar7
      00A589 C0 06            [24]  963 	push	ar6
      00A58B B1 32            [12]  964 	acall	_get_record_keycode
      00A58D 12 49 84         [24]  965 	lcall	_ak820_outline_0155
      00A590 D0 06            [24]  966 	pop	ar6
      00A592 D0 07            [24]  967 	pop	ar7
                                    968 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A594 74 07            [12]  969 	mov	a,#0x07
      00A596 12 37 ED         [24]  970 	lcall	_ak820_outline_0033
      00A599 EC               [12]  971 	mov	a,r4
      00A59A F0               [24]  972 	movx	@dptr,a
      00A59B ED               [12]  973 	mov	a,r5
      00A59C A3               [24]  974 	inc	dptr
      00A59D 12 49 3E         [24]  975 	lcall	_ak820_outline_0063
                                    976 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A5A0 12 35 EF         [24]  977 	lcall	_ak820_combo_process
      00A5A3 E5 82            [12]  978 	mov	a, dpl
      00A5A5 70 04            [24]  979 	jnz	00104$
                                    980 ;	quantum/quantum.c:366: true;
                                    981 ;	assignBit
      00A5A7 C2 27            [12]  982 	clr	_pre_process_record_quantum_sloc0_1_0
      00A5A9 80 02            [24]  983 	sjmp	00105$
      00A5AB                        984 00104$:
                                    985 ;	assignBit
      00A5AB D2 27            [12]  986 	setb	_pre_process_record_quantum_sloc0_1_0
      00A5AD                        987 00105$:
      00A5AD A2 27            [12]  988 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A5AF 12 38 69         [24]  989 	lcall	_ak820_outline_0149
                                    990 ;	quantum/quantum.c:367: }
      00A5B2 22               [24]  991 	ret
                                    992 ;------------------------------------------------------------
                                    993 ;Allocation info for local variables in function 'post_process_record_quantum'
                                    994 ;------------------------------------------------------------
                                    995 ;record        Allocated with name '_post_process_record_quantum_record_10000_666'
                                    996 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_667'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                    999 ;	-----------------------------------------
                                   1000 ;	 function process_record_quantum
                                   1001 ;	-----------------------------------------
      00A5B3                       1002 _process_record_quantum:
      00A5B3 12 38 44         [24] 1003 	lcall	_ak820_outline_0109
      00A5B6 90 0C 7C         [24] 1004 	mov	dptr,#_process_record_quantum_record_10000_668
      00A5B9 12 38 49         [24] 1005 	lcall	_ak820_outline_0110
                                   1006 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      00A5BC 90 0C 7C         [24] 1007 	mov	dptr,#_process_record_quantum_record_10000_668
      00A5BF 12 37 FD         [24] 1008 	lcall	_ak820_outline_0056
      00A5C2 90 0C 77         [24] 1009 	mov	dptr,#_get_record_keycode_PARM_2
      00A5C5 E4               [12] 1010 	clr	a
      00A5C6 12 49 3E         [24] 1011 	lcall	_ak820_outline_0063
      00A5C9 B1 32            [12] 1012 	acall	_get_record_keycode
      00A5CB 12 49 6E         [24] 1013 	lcall	_ak820_outline_0139
                                   1014 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      00A5CE 90 0C 7C         [24] 1015 	mov	dptr,#_process_record_quantum_record_10000_668
      00A5D1 12 38 14         [24] 1016 	lcall	_ak820_outline_0062
      00A5D4 90 0C 85         [24] 1017 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A5D7 EC               [12] 1018 	mov	a,r4
      00A5D8 F0               [24] 1019 	movx	@dptr,a
      00A5D9 ED               [12] 1020 	mov	a,r5
      00A5DA A3               [24] 1021 	inc	dptr
      00A5DB 12 49 3E         [24] 1022 	lcall	_ak820_outline_0063
                                   1023 ;	quantum/quantum.c:382: }
      00A5DE C1 B3            [24] 1024 	ajmp	_process_record_quantum_helper
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'process_ak820_override'
                                   1027 ;------------------------------------------------------------
                                   1028 ;record        Allocated with name '_process_ak820_override_record_10000_670'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/quantum.c:384: static bool process_ak820_override(keyrecord_t AK820_STATE_MEM *record) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function process_ak820_override
                                   1033 ;	-----------------------------------------
      00A5E0                       1034 _process_ak820_override:
      00A5E0 12 38 44         [24] 1035 	lcall	_ak820_outline_0109
      00A5E3 90 0C 7E         [24] 1036 	mov	dptr,#_process_ak820_override_record_10000_670
      00A5E6 12 38 49         [24] 1037 	lcall	_ak820_outline_0110
                                   1038 ;	quantum/quantum.c:386: if (get_repeat_key_count() || ak820_macro_primitive) return true;
      00A5E9 12 A8 B4         [24] 1039 	lcall	_get_repeat_key_count
      00A5EC E5 82            [12] 1040 	mov	a, dpl
      00A5EE 70 06            [24] 1041 	jnz	00101$
      00A5F0 90 09 E8         [24] 1042 	mov	dptr,#_ak820_macro_primitive
      00A5F3 E0               [24] 1043 	movx	a,@dptr
      00A5F4 60 04            [24] 1044 	jz	00102$
      00A5F6                       1045 00101$:
      00A5F6 75 82 01         [24] 1046 	mov	dpl, #0x01
      00A5F9 22               [24] 1047 	ret
      00A5FA                       1048 00102$:
                                   1049 ;	quantum/quantum.c:387: if (ak820_key_override_process(record, get_mods() | get_weak_mods(),
      00A5FA 90 0C 7E         [24] 1050 	mov	dptr,#_process_ak820_override_record_10000_670
      00A5FD 12 37 FD         [24] 1051 	lcall	_ak820_outline_0056
      00A600 12 86 23         [24] 1052 	lcall	_get_mods
      00A603 AD 82            [24] 1053 	mov	r5, dpl
      00A605 12 86 39         [24] 1054 	lcall	_get_weak_mods
      00A608 E5 82            [12] 1055 	mov	a,dpl
      00A60A 42 05            [12] 1056 	orl	ar5,a
                                   1057 ;	quantum/quantum.c:388: get_highest_layer(layer_state | default_layer_state))) return true;
      00A60C 90 0E 53         [24] 1058 	mov	dptr,#_default_layer_state
      00A60F E0               [24] 1059 	movx	a,@dptr
      00A610 FC               [12] 1060 	mov	r4,a
      00A611 90 0E 54         [24] 1061 	mov	dptr,#_layer_state
      00A614 E0               [24] 1062 	movx	a,@dptr
      00A615 42 04            [12] 1063 	orl	ar4,a
      00A617 8C 82            [24] 1064 	mov	dpl, r4
      00A619 C0 07            [24] 1065 	push	ar7
      00A61B C0 06            [24] 1066 	push	ar6
      00A61D C0 05            [24] 1067 	push	ar5
      00A61F 12 86 D8         [24] 1068 	lcall	_biton
      00A622 AC 82            [24] 1069 	mov	r4, dpl
      00A624 D0 05            [24] 1070 	pop	ar5
      00A626 D0 06            [24] 1071 	pop	ar6
      00A628 D0 07            [24] 1072 	pop	ar7
      00A62A 90 05 60         [24] 1073 	mov	dptr,#_ak820_key_override_process_PARM_2
      00A62D ED               [12] 1074 	mov	a,r5
      00A62E F0               [24] 1075 	movx	@dptr,a
      00A62F 90 05 61         [24] 1076 	mov	dptr,#_ak820_key_override_process_PARM_3
      00A632 EC               [12] 1077 	mov	a,r4
      00A633 12 49 3E         [24] 1078 	lcall	_ak820_outline_0063
      00A636 12 3F 04         [24] 1079 	lcall	_ak820_key_override_process
      00A639 E5 82            [12] 1080 	mov	a, dpl
      00A63B 60 04            [24] 1081 	jz	00105$
      00A63D 75 82 01         [24] 1082 	mov	dpl, #0x01
      00A640 22               [24] 1083 	ret
      00A641                       1084 00105$:
                                   1085 ;	quantum/quantum.c:389: send_keyboard_report();
      00A641 12 84 D2         [24] 1086 	lcall	_send_keyboard_report
                                   1087 ;	quantum/quantum.c:390: return false;
      00A644 75 82 00         [24] 1088 	mov	dpl, #0x00
                                   1089 ;	quantum/quantum.c:391: }
      00A647 22               [24] 1090 	ret
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1093 ;------------------------------------------------------------
                                   1094 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1095 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_674'
                                   1096 ;record        Allocated with name '_process_ak820_nkro_record_10000_675'
                                   1097 ;------------------------------------------------------------
                                   1098 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1099 ;	-----------------------------------------
                                   1100 ;	 function process_ak820_nkro
                                   1101 ;	-----------------------------------------
      00A648                       1102 _process_ak820_nkro:
      00A648 12 38 44         [24] 1103 	lcall	_ak820_outline_0109
      00A64B 90 0C 83         [24] 1104 	mov	dptr,#_process_ak820_nkro_keycode_10000_674
      00A64E 12 38 49         [24] 1105 	lcall	_ak820_outline_0110
                                   1106 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A651 90 0C 80         [24] 1107 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A654 12 37 FD         [24] 1108 	lcall	_ak820_outline_0056
                                   1109 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A657 90 0C 83         [24] 1110 	mov	dptr,#_process_ak820_nkro_keycode_10000_674
      00A65A 12 38 14         [24] 1111 	lcall	_ak820_outline_0062
      00A65D C3               [12] 1112 	clr	c
      00A65E EC               [12] 1113 	mov	a,r4
      00A65F 94 11            [12] 1114 	subb	a,#0x11
      00A661 ED               [12] 1115 	mov	a,r5
      00A662 94 70            [12] 1116 	subb	a,#0x70
      00A664 40 08            [24] 1117 	jc	00101$
      00A666 74 13            [12] 1118 	mov	a,#0x13
      00A668 9C               [12] 1119 	subb	a,r4
      00A669 74 70            [12] 1120 	mov	a,#0x70
      00A66B 9D               [12] 1121 	subb	a,r5
      00A66C 50 04            [24] 1122 	jnc	00102$
                                   1123 ;	free result
      00A66E                       1124 00101$:
      00A66E 75 82 01         [24] 1125 	mov	dpl, #0x01
      00A671 22               [24] 1126 	ret
      00A672                       1127 00102$:
                                   1128 ;	quantum/quantum.c:406: if (record->event.pressed) {
      00A672 12 37 B1         [24] 1129 	lcall	_ak820_outline_0006
      00A675 60 38            [24] 1130 	jz	00105$
                                   1131 ;	quantum/quantum.c:407: clear_keyboard();
      00A677 C0 05            [24] 1132 	push	ar5
      00A679 C0 04            [24] 1133 	push	ar4
      00A67B 12 7B BD         [24] 1134 	lcall	_clear_keyboard
      00A67E D0 04            [24] 1135 	pop	ar4
      00A680 D0 05            [24] 1136 	pop	ar5
                                   1137 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A682 BC 13 14         [24] 1138 	cjne	r4,#0x13,00108$
      00A685 BD 70 11         [24] 1139 	cjne	r5,#0x70,00108$
      00A688 90 0B 44         [24] 1140 	mov	dptr,#_keymap_config
      00A68B E0               [24] 1141 	movx	a,@dptr
      00A68C 23               [12] 1142 	rl	a
      00A68D 54 01            [12] 1143 	anl	a,#0x01
      00A68F B4 01 00         [24] 1144 	cjne	a,#0x01,00136$
      00A692                       1145 00136$:
      00A692 92 28            [24] 1146 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A694 E4               [12] 1147 	clr	a
      00A695 33               [12] 1148 	rlc	a
      00A696 FF               [12] 1149 	mov	r7,a
      00A697 80 09            [24] 1150 	sjmp	00109$
      00A699                       1151 00108$:
      00A699 E4               [12] 1152 	clr	a
      00A69A BC 11 04         [24] 1153 	cjne	r4,#0x11,00137$
      00A69D BD 70 01         [24] 1154 	cjne	r5,#0x70,00137$
      00A6A0 04               [12] 1155 	inc	a
      00A6A1                       1156 00137$:
      00A6A1 FF               [12] 1157 	mov	r7,a
      00A6A2                       1158 00109$:
                                   1159 ;	assignBit
      00A6A2 EF               [12] 1160 	mov	a,r7
      00A6A3 24 FF            [12] 1161 	add	a,#0xff
      00A6A5 E4               [12] 1162 	clr	a
      00A6A6 33               [12] 1163 	rlc	a
      00A6A7 90 0B 44         [24] 1164 	mov	dptr,#_keymap_config
      00A6AA 13               [12] 1165 	rrc	a
      00A6AB E0               [24] 1166 	movx	a,@dptr
      00A6AC 92 E7            [24] 1167 	mov	acc.7,c
      00A6AE F0               [24] 1168 	movx	@dptr,a
      00A6AF                       1169 00105$:
                                   1170 ;	quantum/quantum.c:410: return false;
      00A6AF 75 82 00         [24] 1171 	mov	dpl, #0x00
                                   1172 ;	quantum/quantum.c:411: }
      00A6B2 22               [24] 1173 	ret
                                   1174 ;------------------------------------------------------------
                                   1175 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1176 ;------------------------------------------------------------
                                   1177 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1178 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_679'
                                   1179 ;record        Allocated with name '_process_record_quantum_helper_record_10000_680'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function process_record_quantum_helper
                                   1184 ;	-----------------------------------------
      00A6B3                       1185 _process_record_quantum_helper:
      00A6B3 12 38 44         [24] 1186 	lcall	_ak820_outline_0109
      00A6B6 90 0C 87         [24] 1187 	mov	dptr,#_process_record_quantum_helper_keycode_10000_679
      00A6B9 12 38 49         [24] 1188 	lcall	_ak820_outline_0110
                                   1189 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A6BC 90 0C 85         [24] 1190 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A6BF 12 37 FD         [24] 1191 	lcall	_ak820_outline_0056
                                   1192 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      00A6C2 90 0C 87         [24] 1193 	mov	dptr,#_process_record_quantum_helper_keycode_10000_679
      00A6C5 12 38 14         [24] 1194 	lcall	_ak820_outline_0062
      00A6C8 90 0C 80         [24] 1195 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A6CB 12 A8 13         [24] 1196 	lcall	_ak820_outline_0003
      00A6CE C0 07            [24] 1197 	push	ar7
      00A6D0 C0 06            [24] 1198 	push	ar6
      00A6D2 C0 05            [24] 1199 	push	ar5
      00A6D4 C0 04            [24] 1200 	push	ar4
      00A6D6 D1 48            [24] 1201 	acall	_process_ak820_nkro
      00A6D8 E5 82            [12] 1202 	mov	a, dpl
      00A6DA D0 04            [24] 1203 	pop	ar4
      00A6DC D0 05            [24] 1204 	pop	ar5
      00A6DE D0 06            [24] 1205 	pop	ar6
      00A6E0 D0 07            [24] 1206 	pop	ar7
      00A6E2 70 03            [24] 1207 	jnz	00204$
      00A6E4 02 A7 D5         [24] 1208 	ljmp	00101$
      00A6E7                       1209 00204$:
                                   1210 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A6E7 90 0C 5A         [24] 1211 	mov	dptr,#_process_last_key_PARM_2
      00A6EA 12 A8 13         [24] 1212 	lcall	_ak820_outline_0003
      00A6ED C0 07            [24] 1213 	push	ar7
      00A6EF C0 06            [24] 1214 	push	ar6
      00A6F1 C0 05            [24] 1215 	push	ar5
      00A6F3 C0 04            [24] 1216 	push	ar4
      00A6F5 31 BD            [12] 1217 	acall	_process_last_key
      00A6F7 E5 82            [12] 1218 	mov	a, dpl
      00A6F9 D0 04            [24] 1219 	pop	ar4
      00A6FB D0 05            [24] 1220 	pop	ar5
      00A6FD D0 06            [24] 1221 	pop	ar6
      00A6FF D0 07            [24] 1222 	pop	ar7
      00A701 70 03            [24] 1223 	jnz	00205$
      00A703 02 A7 D5         [24] 1224 	ljmp	00101$
      00A706                       1225 00205$:
      00A706 90 0C 60         [24] 1226 	mov	dptr,#_process_repeat_key_PARM_2
      00A709 12 A8 13         [24] 1227 	lcall	_ak820_outline_0003
      00A70C C0 07            [24] 1228 	push	ar7
      00A70E C0 06            [24] 1229 	push	ar6
      00A710 C0 05            [24] 1230 	push	ar5
      00A712 C0 04            [24] 1231 	push	ar4
      00A714 51 3A            [12] 1232 	acall	_process_repeat_key
      00A716 E5 82            [12] 1233 	mov	a, dpl
      00A718 D0 04            [24] 1234 	pop	ar4
      00A71A D0 05            [24] 1235 	pop	ar5
      00A71C D0 06            [24] 1236 	pop	ar6
      00A71E D0 07            [24] 1237 	pop	ar7
      00A720 70 03            [24] 1238 	jnz	00206$
      00A722 02 A7 D5         [24] 1239 	ljmp	00101$
      00A725                       1240 00206$:
                                   1241 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      00A725 90 0C C4         [24] 1242 	mov	dptr,#_process_record_via_PARM_2
      00A728 12 A8 13         [24] 1243 	lcall	_ak820_outline_0003
      00A72B C0 07            [24] 1244 	push	ar7
      00A72D C0 06            [24] 1245 	push	ar6
      00A72F C0 05            [24] 1246 	push	ar5
      00A731 C0 04            [24] 1247 	push	ar4
      00A733 12 AD 04         [24] 1248 	lcall	_process_record_via
      00A736 E5 82            [12] 1249 	mov	a, dpl
      00A738 D0 04            [24] 1250 	pop	ar4
      00A73A D0 05            [24] 1251 	pop	ar5
      00A73C D0 06            [24] 1252 	pop	ar6
      00A73E D0 07            [24] 1253 	pop	ar7
      00A740 70 03            [24] 1254 	jnz	00207$
      00A742 02 A7 D5         [24] 1255 	ljmp	00101$
      00A745                       1256 00207$:
                                   1257 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      00A745 90 0C 42         [24] 1258 	mov	dptr,#_process_caps_word_PARM_2
      00A748 12 A8 13         [24] 1259 	lcall	_ak820_outline_0003
      00A74B C0 07            [24] 1260 	push	ar7
      00A74D C0 06            [24] 1261 	push	ar6
      00A74F C0 05            [24] 1262 	push	ar5
      00A751 C0 04            [24] 1263 	push	ar4
      00A753 12 9F 48         [24] 1264 	lcall	_process_caps_word
      00A756 E5 82            [12] 1265 	mov	a, dpl
      00A758 D0 04            [24] 1266 	pop	ar4
      00A75A D0 05            [24] 1267 	pop	ar5
      00A75C D0 06            [24] 1268 	pop	ar6
      00A75E D0 07            [24] 1269 	pop	ar7
      00A760 70 02            [24] 1270 	jnz	00208$
      00A762 E1 D5            [12] 1271 	ajmp	00101$
      00A764                       1272 00208$:
                                   1273 ;	quantum/quantum.c:517: process_ak820_override((keyrecord_t AK820_STATE_MEM *)record) &&
      00A764 12 49 5D         [24] 1274 	lcall	_ak820_outline_0120
      00A767 C0 07            [24] 1275 	push	ar7
      00A769 C0 06            [24] 1276 	push	ar6
      00A76B C0 05            [24] 1277 	push	ar5
      00A76D C0 04            [24] 1278 	push	ar4
      00A76F 12 A5 E0         [24] 1279 	lcall	_process_ak820_override
      00A772 E5 82            [12] 1280 	mov	a, dpl
      00A774 D0 04            [24] 1281 	pop	ar4
      00A776 D0 05            [24] 1282 	pop	ar5
      00A778 D0 06            [24] 1283 	pop	ar6
      00A77A D0 07            [24] 1284 	pop	ar7
      00A77C 60 57            [24] 1285 	jz	00101$
                                   1286 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      00A77E 90 0C 47         [24] 1287 	mov	dptr,#_process_grave_esc_PARM_2
      00A781 12 A8 13         [24] 1288 	lcall	_ak820_outline_0003
      00A784 C0 07            [24] 1289 	push	ar7
      00A786 C0 06            [24] 1290 	push	ar6
      00A788 C0 05            [24] 1291 	push	ar5
      00A78A C0 04            [24] 1292 	push	ar4
      00A78C 12 A0 5B         [24] 1293 	lcall	_process_grave_esc
      00A78F E5 82            [12] 1294 	mov	a, dpl
      00A791 D0 04            [24] 1295 	pop	ar4
      00A793 D0 05            [24] 1296 	pop	ar5
      00A795 D0 06            [24] 1297 	pop	ar6
      00A797 D0 07            [24] 1298 	pop	ar7
      00A799 60 3A            [24] 1299 	jz	00101$
                                   1300 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      00A79B 90 0C 65         [24] 1301 	mov	dptr,#_process_rgb_PARM_2
      00A79E 12 A8 13         [24] 1302 	lcall	_ak820_outline_0003
      00A7A1 C0 07            [24] 1303 	push	ar7
      00A7A3 C0 06            [24] 1304 	push	ar6
      00A7A5 C0 05            [24] 1305 	push	ar5
      00A7A7 C0 04            [24] 1306 	push	ar4
      00A7A9 12 A2 9C         [24] 1307 	lcall	_process_rgb
      00A7AC E5 82            [12] 1308 	mov	a, dpl
      00A7AE D0 04            [24] 1309 	pop	ar4
      00A7B0 D0 05            [24] 1310 	pop	ar5
      00A7B2 D0 06            [24] 1311 	pop	ar6
      00A7B4 D0 07            [24] 1312 	pop	ar7
      00A7B6 60 1D            [24] 1313 	jz	00101$
                                   1314 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      00A7B8 90 0C 6B         [24] 1315 	mov	dptr,#_process_tri_layer_PARM_2
      00A7BB 12 A8 13         [24] 1316 	lcall	_ak820_outline_0003
      00A7BE C0 07            [24] 1317 	push	ar7
      00A7C0 C0 06            [24] 1318 	push	ar6
      00A7C2 C0 05            [24] 1319 	push	ar5
      00A7C4 C0 04            [24] 1320 	push	ar4
      00A7C6 12 A3 4D         [24] 1321 	lcall	_process_tri_layer
      00A7C9 E5 82            [12] 1322 	mov	a, dpl
      00A7CB D0 04            [24] 1323 	pop	ar4
      00A7CD D0 05            [24] 1324 	pop	ar5
      00A7CF D0 06            [24] 1325 	pop	ar6
      00A7D1 D0 07            [24] 1326 	pop	ar7
      00A7D3 70 04            [24] 1327 	jnz	00102$
                                   1328 ;	quantum/quantum.c:561: true)) {
      00A7D5                       1329 00101$:
                                   1330 ;	quantum/quantum.c:562: return false;
      00A7D5 75 82 00         [24] 1331 	mov	dpl, #0x00
      00A7D8 22               [24] 1332 	ret
      00A7D9                       1333 00102$:
                                   1334 ;	quantum/quantum.c:565: if (record->event.pressed) {
      00A7D9 12 37 B1         [24] 1335 	lcall	_ak820_outline_0006
      00A7DC 60 30            [24] 1336 	jz	00117$
                                   1337 ;	quantum/quantum.c:566: switch (keycode) {
      00A7DE BC 00 05         [24] 1338 	cjne	r4,#0x00,00214$
      00A7E1 BD 7C 02         [24] 1339 	cjne	r5,#0x7c,00214$
      00A7E4 80 10            [24] 1340 	sjmp	00112$
      00A7E6                       1341 00214$:
      00A7E6 BC 01 05         [24] 1342 	cjne	r4,#0x01,00215$
      00A7E9 BD 7C 02         [24] 1343 	cjne	r5,#0x7c,00215$
      00A7EC 80 0F            [24] 1344 	sjmp	00113$
      00A7EE                       1345 00215$:
                                   1346 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      00A7EE BC 03 1D         [24] 1347 	cjne	r4,#0x03,00117$
      00A7F1 BD 7C 1A         [24] 1348 	cjne	r5,#0x7c,00117$
      00A7F4 80 0E            [24] 1349 	sjmp	00114$
      00A7F6                       1350 00112$:
                                   1351 ;	quantum/quantum.c:569: reset_keyboard();
      00A7F6 12 A5 28         [24] 1352 	lcall	_reset_keyboard
                                   1353 ;	quantum/quantum.c:570: return false;
      00A7F9 75 82 00         [24] 1354 	mov	dpl, #0x00
                                   1355 ;	quantum/quantum.c:571: case QK_REBOOT:
      00A7FC 22               [24] 1356 	ret
      00A7FD                       1357 00113$:
                                   1358 ;	quantum/quantum.c:572: soft_reset_keyboard();
      00A7FD 12 A5 2D         [24] 1359 	lcall	_soft_reset_keyboard
                                   1360 ;	quantum/quantum.c:573: return false;
      00A800 75 82 00         [24] 1361 	mov	dpl, #0x00
                                   1362 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      00A803 22               [24] 1363 	ret
      00A804                       1364 00114$:
                                   1365 ;	quantum/quantum.c:592: eeconfig_disable();
      00A804 12 96 D3         [24] 1366 	lcall	_eeconfig_disable
                                   1367 ;	quantum/quantum.c:593: soft_reset_keyboard();
      00A807 12 A5 2D         [24] 1368 	lcall	_soft_reset_keyboard
                                   1369 ;	quantum/quantum.c:595: return false;
      00A80A 75 82 00         [24] 1370 	mov	dpl, #0x00
                                   1371 ;	quantum/quantum.c:650: }
      00A80D 22               [24] 1372 	ret
      00A80E                       1373 00117$:
                                   1374 ;	quantum/quantum.c:654: return true;
      00A80E 75 82 01         [24] 1375 	mov	dpl, #0x01
                                   1376 ;	quantum/quantum.c:658: }
      00A811 22               [24] 1377 	ret
                                   1378 ;------------------------------------------------------------
                                   1379 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1380 ;------------------------------------------------------------
                                   1381 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_687'
                                   1382 ;------------------------------------------------------------
                                   1383 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1384 ;	-----------------------------------------
                                   1385 ;	 function shutdown_user
                                   1386 ;	-----------------------------------------
      00A812                       1387 _shutdown_user:
      00A812 22               [24] 1388 	ret
                                   1389 ;------------------------------------------------------------
                                   1390 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1391 ;------------------------------------------------------------
                                   1392 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1393 ;	-----------------------------------------
                                   1394 	.area CSEG    (CODE)
                                   1395 	.area CONST   (CODE)
                                   1396 	.area XINIT   (CODE)
                                   1397 	.area CABS    (ABS,CODE)
                                   1398 
                                   1399 ; Experimental exact instruction outlining.
                                   1400 	.globl _ak820_outline_0001
                                   1401 	.globl _ak820_outline_0003
                                   1402 	.globl _ak820_outline_0006
                                   1403 	.globl _ak820_outline_0007
                                   1404 	.globl _ak820_outline_0023
                                   1405 	.globl _ak820_outline_0033
                                   1406 	.globl _ak820_outline_0040
                                   1407 	.globl _ak820_outline_0056
                                   1408 	.globl _ak820_outline_0062
                                   1409 	.globl _ak820_outline_0063
                                   1410 	.globl _ak820_outline_0109
                                   1411 	.globl _ak820_outline_0110
                                   1412 	.globl _ak820_outline_0120
                                   1413 	.globl _ak820_outline_0121
                                   1414 	.globl _ak820_outline_0128
                                   1415 	.globl _ak820_outline_0139
                                   1416 	.globl _ak820_outline_0147
                                   1417 	.globl _ak820_outline_0149
                                   1418 	.globl _ak820_outline_0155
                                   1419 
                                   1420 	.area CSEG (CODE)
                                   1421 ; function ak820_outline_0003
      00A813                       1422 _ak820_outline_0003:
      00A813 EE               [12] 1423 	mov	a,r6
      00A814 F0               [24] 1424 	movx	@dptr,a
      00A815 EF               [12] 1425 	mov	a,r7
      00A816 A3               [24] 1426 	inc	dptr
      00A817 F0               [24] 1427 	movx	@dptr,a
      00A818 E4               [12] 1428 	clr	a
      00A819 A3               [24] 1429 	inc	dptr
      00A81A F0               [24] 1430 	movx	@dptr,a
      00A81B 8C 82            [24] 1431 	mov	dpl,r4
      00A81D 8D 83            [24] 1432 	mov	dph,r5
      00A81F 22               [24] 1433 	ret
