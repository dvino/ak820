                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_key_override_reload
                                     12 	.globl _unregister_code16
                                     13 	.globl _register_code16
                                     14 	.globl _matrix_is_on
                                     15 	.globl _dynamic_keymap_set_key_override
                                     16 	.globl _dynamic_keymap_get_key_override
                                     17 	.globl _dynamic_keymap_set_combo
                                     18 	.globl _dynamic_keymap_get_combo
                                     19 	.globl _dynamic_keymap_set_encoder
                                     20 	.globl _dynamic_keymap_get_encoder
                                     21 	.globl _repeat_key_cancel
                                     22 	.globl _ak820_combo_reload
                                     23 	.globl _clear_keyboard
                                     24 	.globl _ak820_action_exec
                                     25 	.globl _timer_elapsed32
                                     26 	.globl _timer_read32
                                     27 	.globl _timer_read
                                     28 	.globl ___memcpy
                                     29 	.globl _ADC_START
                                     30 	.globl _S0_R_FIFO
                                     31 	.globl _S0_T_FIFO
                                     32 	.globl _S0_FREE
                                     33 	.globl _S0_IF_BYTE
                                     34 	.globl _S0_IF_FIRST
                                     35 	.globl _S0_IF_OV
                                     36 	.globl _S0_FST_ACT
                                     37 	.globl _CP_RL2
                                     38 	.globl _C_T2
                                     39 	.globl _TR2
                                     40 	.globl _EXEN2
                                     41 	.globl _TCLK
                                     42 	.globl _RCLK
                                     43 	.globl _EXF2
                                     44 	.globl _CAP1F
                                     45 	.globl _TF2
                                     46 	.globl _RI
                                     47 	.globl _TI
                                     48 	.globl _RB8
                                     49 	.globl _TB8
                                     50 	.globl _REN
                                     51 	.globl _SM2
                                     52 	.globl _SM1
                                     53 	.globl _SM0
                                     54 	.globl _IT0
                                     55 	.globl _IE0
                                     56 	.globl _IT1
                                     57 	.globl _IE1
                                     58 	.globl _TR0
                                     59 	.globl _TF0
                                     60 	.globl _TR1
                                     61 	.globl _TF1
                                     62 	.globl _P4_0
                                     63 	.globl _P4_1
                                     64 	.globl _P4_2
                                     65 	.globl _P4_3
                                     66 	.globl _P4_4
                                     67 	.globl _P4_5
                                     68 	.globl _P4_6
                                     69 	.globl _RXD
                                     70 	.globl _TXD
                                     71 	.globl _INT0
                                     72 	.globl _INT1
                                     73 	.globl _T0
                                     74 	.globl _T1
                                     75 	.globl _MOSI1
                                     76 	.globl _MISO1
                                     77 	.globl _SCK1
                                     78 	.globl _P3_0
                                     79 	.globl _P3_1
                                     80 	.globl _P3_2
                                     81 	.globl _P3_3
                                     82 	.globl _P3_4
                                     83 	.globl _P3_5
                                     84 	.globl _P3_6
                                     85 	.globl _P3_7
                                     86 	.globl _CAP1_
                                     87 	.globl _T2_
                                     88 	.globl _CAP2_
                                     89 	.globl _T2EX_
                                     90 	.globl _RXD1
                                     91 	.globl _TXD1
                                     92 	.globl _P2_0
                                     93 	.globl _P2_1
                                     94 	.globl _P2_2
                                     95 	.globl _P2_3
                                     96 	.globl _P2_4
                                     97 	.globl _P2_5
                                     98 	.globl _P2_6
                                     99 	.globl _P2_7
                                    100 	.globl _AIN0
                                    101 	.globl _AIN1
                                    102 	.globl _AIN2
                                    103 	.globl _AIN3
                                    104 	.globl _AIN4
                                    105 	.globl _AIN5
                                    106 	.globl _AIN6
                                    107 	.globl _AIN7
                                    108 	.globl _CAP1
                                    109 	.globl _T2
                                    110 	.globl _CAP2
                                    111 	.globl _T2EX
                                    112 	.globl _INT0_
                                    113 	.globl _SCS
                                    114 	.globl _MOSI
                                    115 	.globl _MISO
                                    116 	.globl _SCK
                                    117 	.globl _RXD1_
                                    118 	.globl _TXD1_
                                    119 	.globl _P1_0
                                    120 	.globl _P1_1
                                    121 	.globl _P1_2
                                    122 	.globl _P1_3
                                    123 	.globl _P1_4
                                    124 	.globl _P1_5
                                    125 	.globl _P1_6
                                    126 	.globl _P1_7
                                    127 	.globl _AIN8
                                    128 	.globl _AIN9
                                    129 	.globl _AIN10
                                    130 	.globl _AIN11
                                    131 	.globl _AIN12
                                    132 	.globl _AIN13
                                    133 	.globl _RXD_
                                    134 	.globl _TXD_
                                    135 	.globl _SCL0
                                    136 	.globl _SDA0
                                    137 	.globl _P0_0
                                    138 	.globl _P0_1
                                    139 	.globl _P0_2
                                    140 	.globl _P0_3
                                    141 	.globl _P0_4
                                    142 	.globl _P0_5
                                    143 	.globl _P0_6
                                    144 	.globl _P0_7
                                    145 	.globl _IE_SPI0
                                    146 	.globl _IE_USB
                                    147 	.globl _IE_ADC
                                    148 	.globl _IE_UART1
                                    149 	.globl _IE_PWM_I2C
                                    150 	.globl _IE_GPIO
                                    151 	.globl _IE_WDOG
                                    152 	.globl _PX0
                                    153 	.globl _PT0
                                    154 	.globl _PX1
                                    155 	.globl _PT1
                                    156 	.globl _PS
                                    157 	.globl _PT2
                                    158 	.globl _PL_FLAG
                                    159 	.globl _PH_FLAG
                                    160 	.globl _EX0
                                    161 	.globl _ET0
                                    162 	.globl _EX1
                                    163 	.globl _ET1
                                    164 	.globl _ES
                                    165 	.globl _ET2
                                    166 	.globl _E_DIS
                                    167 	.globl _EA
                                    168 	.globl _P
                                    169 	.globl _F1
                                    170 	.globl _OV
                                    171 	.globl _RS0
                                    172 	.globl _RS1
                                    173 	.globl _F0
                                    174 	.globl _AC
                                    175 	.globl _CY
                                    176 	.globl _I2CS_INT_ST
                                    177 	.globl _I2CX_INT
                                    178 	.globl _LED_STATUS
                                    179 	.globl _LED_DMA_H
                                    180 	.globl _LED_DMA_L
                                    181 	.globl _LED_DMA
                                    182 	.globl _LED_PWM_OE
                                    183 	.globl _LED_COMMON
                                    184 	.globl _ADC_CHAN
                                    185 	.globl _ADC_DAT_H
                                    186 	.globl _ADC_DAT_L
                                    187 	.globl _ADC_DAT
                                    188 	.globl _ADC_CTRL
                                    189 	.globl _SPI1_CK_SE
                                    190 	.globl _SPI1_CTRL
                                    191 	.globl _SPI1_DATA
                                    192 	.globl _SPI1_STAT
                                    193 	.globl _SIF1
                                    194 	.globl _SBAUD1
                                    195 	.globl _SBUF1
                                    196 	.globl _SCON1
                                    197 	.globl _SPI0_SETUP
                                    198 	.globl _SPI0_CK_SE
                                    199 	.globl _SPI0_CTRL
                                    200 	.globl _SPI0_DATA
                                    201 	.globl _SPI0_STAT
                                    202 	.globl _T2CAP1H
                                    203 	.globl _T2CAP1L
                                    204 	.globl _T2CAP1
                                    205 	.globl _TH2
                                    206 	.globl _TL2
                                    207 	.globl _T2COUNT
                                    208 	.globl _RCAP2H
                                    209 	.globl _RCAP2L
                                    210 	.globl _RCAP2
                                    211 	.globl _T2MOD
                                    212 	.globl _T2CON
                                    213 	.globl _SBUF
                                    214 	.globl _SCON
                                    215 	.globl _TH1
                                    216 	.globl _TH0
                                    217 	.globl _TL1
                                    218 	.globl _TL0
                                    219 	.globl _TMOD
                                    220 	.globl _TCON
                                    221 	.globl _XBUS_AUX
                                    222 	.globl _P7
                                    223 	.globl _P6_DIR
                                    224 	.globl _P6_OUT_PU
                                    225 	.globl _P6_IN
                                    226 	.globl _P5_DIR
                                    227 	.globl _P5_OUT_PU
                                    228 	.globl _P5_IN
                                    229 	.globl _P4_LED_KEY
                                    230 	.globl _P4_DIR_PU
                                    231 	.globl _P4_MOD_OC
                                    232 	.globl _P4
                                    233 	.globl _P3_DIR_PU
                                    234 	.globl _P3_MOD_OC
                                    235 	.globl _P3
                                    236 	.globl _P2_DIR_PU
                                    237 	.globl _P2_MOD_OC
                                    238 	.globl _P2
                                    239 	.globl _P1_DIR_PU
                                    240 	.globl _P1_MOD_OC
                                    241 	.globl _P1
                                    242 	.globl _P0_DIR_PU
                                    243 	.globl _P0_MOD_OC
                                    244 	.globl _P0
                                    245 	.globl _ROM_CTRL
                                    246 	.globl _ROM_DATA_HH
                                    247 	.globl _ROM_DATA_HL
                                    248 	.globl _ROM_DATA_HI
                                    249 	.globl _ROM_ADDR_H
                                    250 	.globl _ROM_ADDR_L
                                    251 	.globl _ROM_ADDR
                                    252 	.globl _GPIO_IE
                                    253 	.globl _IP_EX
                                    254 	.globl _IE_EX
                                    255 	.globl _IP
                                    256 	.globl _IE
                                    257 	.globl _WDOG_COUNT
                                    258 	.globl _RESET_KEEP
                                    259 	.globl _WAKE_CTRL
                                    260 	.globl _CLOCK_CFG
                                    261 	.globl _POWER_CFG
                                    262 	.globl _PCON
                                    263 	.globl _GLOBAL_CFG
                                    264 	.globl _SAFE_MOD
                                    265 	.globl _DPH
                                    266 	.globl _DPL
                                    267 	.globl _SP
                                    268 	.globl _A_INV
                                    269 	.globl _B
                                    270 	.globl _ACC
                                    271 	.globl _PSW
                                    272 	.globl _vial_unlock_in_progress
                                    273 	.globl _vial_unlocked
                                    274 	.globl _g_vial_magic_keycode_override
                                    275 	.globl _vial_handle_cmd_PARM_2
                                    276 	.globl _vial_unlock_task
                                    277 	.globl _vial_init
                                    278 	.globl _vial_handle_cmd
                                    279 	.globl _vial_keycode_down
                                    280 	.globl _vial_keycode_up
                                    281 	.globl _vial_keycode_tap
                                    282 ;--------------------------------------------------------
                                    283 ; special function registers
                                    284 ;--------------------------------------------------------
                                    285 	.area RSEG    (ABS,DATA)
      000000                        286 	.org 0x0000
                           0000D0   287 _PSW	=	0x00d0
                           0000E0   288 _ACC	=	0x00e0
                           0000F0   289 _B	=	0x00f0
                           0000FD   290 _A_INV	=	0x00fd
                           000081   291 _SP	=	0x0081
                           000082   292 _DPL	=	0x0082
                           000083   293 _DPH	=	0x0083
                           0000A1   294 _SAFE_MOD	=	0x00a1
                           0000B1   295 _GLOBAL_CFG	=	0x00b1
                           000087   296 _PCON	=	0x0087
                           0000BA   297 _POWER_CFG	=	0x00ba
                           0000B9   298 _CLOCK_CFG	=	0x00b9
                           0000A9   299 _WAKE_CTRL	=	0x00a9
                           0000FE   300 _RESET_KEEP	=	0x00fe
                           0000FF   301 _WDOG_COUNT	=	0x00ff
                           0000A8   302 _IE	=	0x00a8
                           0000B8   303 _IP	=	0x00b8
                           0000E8   304 _IE_EX	=	0x00e8
                           0000E9   305 _IP_EX	=	0x00e9
                           0000B2   306 _GPIO_IE	=	0x00b2
                           008584   307 _ROM_ADDR	=	0x8584
                           000084   308 _ROM_ADDR_L	=	0x0084
                           000085   309 _ROM_ADDR_H	=	0x0085
                           008F8E   310 _ROM_DATA_HI	=	0x8f8e
                           00008E   311 _ROM_DATA_HL	=	0x008e
                           00008F   312 _ROM_DATA_HH	=	0x008f
                           000086   313 _ROM_CTRL	=	0x0086
                           000080   314 _P0	=	0x0080
                           0000C4   315 _P0_MOD_OC	=	0x00c4
                           0000C5   316 _P0_DIR_PU	=	0x00c5
                           000090   317 _P1	=	0x0090
                           000092   318 _P1_MOD_OC	=	0x0092
                           000093   319 _P1_DIR_PU	=	0x0093
                           0000A0   320 _P2	=	0x00a0
                           000094   321 _P2_MOD_OC	=	0x0094
                           000095   322 _P2_DIR_PU	=	0x0095
                           0000B0   323 _P3	=	0x00b0
                           000096   324 _P3_MOD_OC	=	0x0096
                           000097   325 _P3_DIR_PU	=	0x0097
                           0000C0   326 _P4	=	0x00c0
                           0000C2   327 _P4_MOD_OC	=	0x00c2
                           0000C3   328 _P4_DIR_PU	=	0x00c3
                           0000C1   329 _P4_LED_KEY	=	0x00c1
                           0000AA   330 _P5_IN	=	0x00aa
                           0000AB   331 _P5_OUT_PU	=	0x00ab
                           0000AC   332 _P5_DIR	=	0x00ac
                           0000AD   333 _P6_IN	=	0x00ad
                           0000AE   334 _P6_OUT_PU	=	0x00ae
                           0000AF   335 _P6_DIR	=	0x00af
                           0000F1   336 _P7	=	0x00f1
                           0000A2   337 _XBUS_AUX	=	0x00a2
                           000088   338 _TCON	=	0x0088
                           000089   339 _TMOD	=	0x0089
                           00008A   340 _TL0	=	0x008a
                           00008B   341 _TL1	=	0x008b
                           00008C   342 _TH0	=	0x008c
                           00008D   343 _TH1	=	0x008d
                           000098   344 _SCON	=	0x0098
                           000099   345 _SBUF	=	0x0099
                           0000C8   346 _T2CON	=	0x00c8
                           0000C9   347 _T2MOD	=	0x00c9
                           00CBCA   348 _RCAP2	=	0xcbca
                           0000CA   349 _RCAP2L	=	0x00ca
                           0000CB   350 _RCAP2H	=	0x00cb
                           00CDCC   351 _T2COUNT	=	0xcdcc
                           0000CC   352 _TL2	=	0x00cc
                           0000CD   353 _TH2	=	0x00cd
                           00CFCE   354 _T2CAP1	=	0xcfce
                           0000CE   355 _T2CAP1L	=	0x00ce
                           0000CF   356 _T2CAP1H	=	0x00cf
                           0000F8   357 _SPI0_STAT	=	0x00f8
                           0000F9   358 _SPI0_DATA	=	0x00f9
                           0000FA   359 _SPI0_CTRL	=	0x00fa
                           0000FB   360 _SPI0_CK_SE	=	0x00fb
                           0000FC   361 _SPI0_SETUP	=	0x00fc
                           0000BC   362 _SCON1	=	0x00bc
                           0000BD   363 _SBUF1	=	0x00bd
                           0000BE   364 _SBAUD1	=	0x00be
                           0000BF   365 _SIF1	=	0x00bf
                           0000B4   366 _SPI1_STAT	=	0x00b4
                           0000B5   367 _SPI1_DATA	=	0x00b5
                           0000B6   368 _SPI1_CTRL	=	0x00b6
                           0000B7   369 _SPI1_CK_SE	=	0x00b7
                           0000F3   370 _ADC_CTRL	=	0x00f3
                           00F5F4   371 _ADC_DAT	=	0xf5f4
                           0000F4   372 _ADC_DAT_L	=	0x00f4
                           0000F5   373 _ADC_DAT_H	=	0x00f5
                           0000F6   374 _ADC_CHAN	=	0x00f6
                           0000A6   375 _LED_COMMON	=	0x00a6
                           0000A7   376 _LED_PWM_OE	=	0x00a7
                           00C7C6   377 _LED_DMA	=	0xc7c6
                           0000C6   378 _LED_DMA_L	=	0x00c6
                           0000C7   379 _LED_DMA_H	=	0x00c7
                           0000F7   380 _LED_STATUS	=	0x00f7
                           0000B3   381 _I2CX_INT	=	0x00b3
                           0000BB   382 _I2CS_INT_ST	=	0x00bb
                                    383 ;--------------------------------------------------------
                                    384 ; special function bits
                                    385 ;--------------------------------------------------------
                                    386 	.area RSEG    (ABS,DATA)
      000000                        387 	.org 0x0000
                           0000D7   388 _CY	=	0x00d7
                           0000D6   389 _AC	=	0x00d6
                           0000D5   390 _F0	=	0x00d5
                           0000D4   391 _RS1	=	0x00d4
                           0000D3   392 _RS0	=	0x00d3
                           0000D2   393 _OV	=	0x00d2
                           0000D1   394 _F1	=	0x00d1
                           0000D0   395 _P	=	0x00d0
                           0000AF   396 _EA	=	0x00af
                           0000AE   397 _E_DIS	=	0x00ae
                           0000AD   398 _ET2	=	0x00ad
                           0000AC   399 _ES	=	0x00ac
                           0000AB   400 _ET1	=	0x00ab
                           0000AA   401 _EX1	=	0x00aa
                           0000A9   402 _ET0	=	0x00a9
                           0000A8   403 _EX0	=	0x00a8
                           0000BF   404 _PH_FLAG	=	0x00bf
                           0000BE   405 _PL_FLAG	=	0x00be
                           0000BD   406 _PT2	=	0x00bd
                           0000BC   407 _PS	=	0x00bc
                           0000BB   408 _PT1	=	0x00bb
                           0000BA   409 _PX1	=	0x00ba
                           0000B9   410 _PT0	=	0x00b9
                           0000B8   411 _PX0	=	0x00b8
                           0000EF   412 _IE_WDOG	=	0x00ef
                           0000EE   413 _IE_GPIO	=	0x00ee
                           0000ED   414 _IE_PWM_I2C	=	0x00ed
                           0000EC   415 _IE_UART1	=	0x00ec
                           0000EB   416 _IE_ADC	=	0x00eb
                           0000E9   417 _IE_USB	=	0x00e9
                           0000E8   418 _IE_SPI0	=	0x00e8
                           000087   419 _P0_7	=	0x0087
                           000086   420 _P0_6	=	0x0086
                           000085   421 _P0_5	=	0x0085
                           000084   422 _P0_4	=	0x0084
                           000083   423 _P0_3	=	0x0083
                           000082   424 _P0_2	=	0x0082
                           000081   425 _P0_1	=	0x0081
                           000080   426 _P0_0	=	0x0080
                           000081   427 _SDA0	=	0x0081
                           000080   428 _SCL0	=	0x0080
                           000083   429 _TXD_	=	0x0083
                           000082   430 _RXD_	=	0x0082
                           000085   431 _AIN13	=	0x0085
                           000084   432 _AIN12	=	0x0084
                           000083   433 _AIN11	=	0x0083
                           000082   434 _AIN10	=	0x0082
                           000081   435 _AIN9	=	0x0081
                           000080   436 _AIN8	=	0x0080
                           000097   437 _P1_7	=	0x0097
                           000096   438 _P1_6	=	0x0096
                           000095   439 _P1_5	=	0x0095
                           000094   440 _P1_4	=	0x0094
                           000093   441 _P1_3	=	0x0093
                           000092   442 _P1_2	=	0x0092
                           000091   443 _P1_1	=	0x0091
                           000090   444 _P1_0	=	0x0090
                           000097   445 _TXD1_	=	0x0097
                           000096   446 _RXD1_	=	0x0096
                           000097   447 _SCK	=	0x0097
                           000096   448 _MISO	=	0x0096
                           000095   449 _MOSI	=	0x0095
                           000094   450 _SCS	=	0x0094
                           000092   451 _INT0_	=	0x0092
                           000091   452 _T2EX	=	0x0091
                           000091   453 _CAP2	=	0x0091
                           000090   454 _T2	=	0x0090
                           000090   455 _CAP1	=	0x0090
                           000097   456 _AIN7	=	0x0097
                           000096   457 _AIN6	=	0x0096
                           000095   458 _AIN5	=	0x0095
                           000094   459 _AIN4	=	0x0094
                           000093   460 _AIN3	=	0x0093
                           000092   461 _AIN2	=	0x0092
                           000091   462 _AIN1	=	0x0091
                           000090   463 _AIN0	=	0x0090
                           0000A7   464 _P2_7	=	0x00a7
                           0000A6   465 _P2_6	=	0x00a6
                           0000A5   466 _P2_5	=	0x00a5
                           0000A4   467 _P2_4	=	0x00a4
                           0000A3   468 _P2_3	=	0x00a3
                           0000A2   469 _P2_2	=	0x00a2
                           0000A1   470 _P2_1	=	0x00a1
                           0000A0   471 _P2_0	=	0x00a0
                           0000A7   472 _TXD1	=	0x00a7
                           0000A6   473 _RXD1	=	0x00a6
                           0000A5   474 _T2EX_	=	0x00a5
                           0000A5   475 _CAP2_	=	0x00a5
                           0000A4   476 _T2_	=	0x00a4
                           0000A4   477 _CAP1_	=	0x00a4
                           0000B7   478 _P3_7	=	0x00b7
                           0000B6   479 _P3_6	=	0x00b6
                           0000B5   480 _P3_5	=	0x00b5
                           0000B4   481 _P3_4	=	0x00b4
                           0000B3   482 _P3_3	=	0x00b3
                           0000B2   483 _P3_2	=	0x00b2
                           0000B1   484 _P3_1	=	0x00b1
                           0000B0   485 _P3_0	=	0x00b0
                           0000B7   486 _SCK1	=	0x00b7
                           0000B6   487 _MISO1	=	0x00b6
                           0000B5   488 _MOSI1	=	0x00b5
                           0000B5   489 _T1	=	0x00b5
                           0000B4   490 _T0	=	0x00b4
                           0000B3   491 _INT1	=	0x00b3
                           0000B2   492 _INT0	=	0x00b2
                           0000B1   493 _TXD	=	0x00b1
                           0000B0   494 _RXD	=	0x00b0
                           0000C6   495 _P4_6	=	0x00c6
                           0000C5   496 _P4_5	=	0x00c5
                           0000C4   497 _P4_4	=	0x00c4
                           0000C3   498 _P4_3	=	0x00c3
                           0000C2   499 _P4_2	=	0x00c2
                           0000C1   500 _P4_1	=	0x00c1
                           0000C0   501 _P4_0	=	0x00c0
                           00008F   502 _TF1	=	0x008f
                           00008E   503 _TR1	=	0x008e
                           00008D   504 _TF0	=	0x008d
                           00008C   505 _TR0	=	0x008c
                           00008B   506 _IE1	=	0x008b
                           00008A   507 _IT1	=	0x008a
                           000089   508 _IE0	=	0x0089
                           000088   509 _IT0	=	0x0088
                           00009F   510 _SM0	=	0x009f
                           00009E   511 _SM1	=	0x009e
                           00009D   512 _SM2	=	0x009d
                           00009C   513 _REN	=	0x009c
                           00009B   514 _TB8	=	0x009b
                           00009A   515 _RB8	=	0x009a
                           000099   516 _TI	=	0x0099
                           000098   517 _RI	=	0x0098
                           0000CF   518 _TF2	=	0x00cf
                           0000CF   519 _CAP1F	=	0x00cf
                           0000CE   520 _EXF2	=	0x00ce
                           0000CD   521 _RCLK	=	0x00cd
                           0000CC   522 _TCLK	=	0x00cc
                           0000CB   523 _EXEN2	=	0x00cb
                           0000CA   524 _TR2	=	0x00ca
                           0000C9   525 _C_T2	=	0x00c9
                           0000C8   526 _CP_RL2	=	0x00c8
                           0000FF   527 _S0_FST_ACT	=	0x00ff
                           0000FE   528 _S0_IF_OV	=	0x00fe
                           0000FD   529 _S0_IF_FIRST	=	0x00fd
                           0000FC   530 _S0_IF_BYTE	=	0x00fc
                           0000FB   531 _S0_FREE	=	0x00fb
                           0000FA   532 _S0_T_FIFO	=	0x00fa
                           0000F8   533 _S0_R_FIFO	=	0x00f8
                           0000F7   534 _ADC_START	=	0x00f7
                                    535 ;--------------------------------------------------------
                                    536 ; overlayable register banks
                                    537 ;--------------------------------------------------------
                                    538 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        539 	.ds 8
                                    540 ;--------------------------------------------------------
                                    541 ; internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area DSEG    (DATA)
      00004B                        544 _vial_handle_cmd_sloc0_1_0:
      00004B                        545 	.ds 2
      00004D                        546 _vial_handle_cmd_sloc1_1_0:
      00004D                        547 	.ds 2
      00004F                        548 _vial_handle_cmd_sloc2_1_0:
      00004F                        549 	.ds 2
      000051                        550 _vial_handle_cmd_sloc3_1_0:
      000051                        551 	.ds 2
                                    552 ;--------------------------------------------------------
                                    553 ; overlayable items in internal ram
                                    554 ;--------------------------------------------------------
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
                                    568 ;--------------------------------------------------------
                                    569 ; paged external ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area PSEG    (PAG,XDATA)
                                    572 ;--------------------------------------------------------
                                    573 ; uninitialized external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XSEG    (XDATA)
      000CD1                        576 _vial_unlock_timer:
      000CD1                        577 	.ds 4
      000CD5                        578 _vial_unlock_holding:
      000CD5                        579 	.ds 1
      000CD6                        580 _vial_keycode_firewall_in_10000_619:
      000CD6                        581 	.ds 2
      000CD8                        582 _vial_fill_packet_PARM_2:
      000CD8                        583 	.ds 1
      000CD9                        584 _vial_fill_packet_msg_10000_622:
      000CD9                        585 	.ds 2
      000CDB                        586 _vial_handle_cmd_PARM_2:
      000CDB                        587 	.ds 1
      000CDC                        588 _vial_handle_cmd_data_10000_627:
      000CDC                        589 	.ds 3
      000CDF                        590 _vial_handle_cmd_entry_70000_655:
      000CDF                        591 	.ds 10
      000CE9                        592 _vial_handle_cmd_entry_70000_656:
      000CE9                        593 	.ds 10
      000CF3                        594 _vial_handle_cmd_entry_70000_658:
      000CF3                        595 	.ds 10
      000CFD                        596 _vial_handle_cmd_entry_70000_659:
      000CFD                        597 	.ds 10
      000D07                        598 _g_vial_magic_keycode_override::
      000D07                        599 	.ds 2
      000D09                        600 _vial_keycode_down_keycode_10000_661:
      000D09                        601 	.ds 2
      000D0B                        602 _vial_keycode_down_dummy_event_30000_668:
      000D0B                        603 	.ds 6
      000D11                        604 _vial_keycode_up_keycode_10000_669:
      000D11                        605 	.ds 2
      000D13                        606 _vial_keycode_up_dummy_event_30000_676:
      000D13                        607 	.ds 6
      000D19                        608 _vial_keycode_tap_keycode_10000_677:
      000D19                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
      000EB2                        618 _vial_unlocked::
      000EB2                        619 	.ds 1
      000EB3                        620 _vial_unlock_in_progress::
      000EB3                        621 	.ds 1
      000EB4                        622 _vial_unlock_counter:
      000EB4                        623 	.ds 1
      000EB5                        624 _vial_unlock_combo_rows:
      000EB5                        625 	.ds 2
      000EB7                        626 _vial_unlock_combo_cols:
      000EB7                        627 	.ds 2
                                    628 	.area HOME    (CODE)
                                    629 	.area GSINIT0 (CODE)
                                    630 	.area GSINIT1 (CODE)
                                    631 	.area GSINIT2 (CODE)
                                    632 	.area GSINIT3 (CODE)
                                    633 	.area GSINIT4 (CODE)
                                    634 	.area GSINIT5 (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area CSEG    (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; global & static initialisations
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area GSINIT  (CODE)
                                    643 	.area GSFINAL (CODE)
                                    644 	.area GSINIT  (CODE)
                                    645 ;--------------------------------------------------------
                                    646 ; Home
                                    647 ;--------------------------------------------------------
                                    648 	.area HOME    (CODE)
                                    649 	.area HOME    (CODE)
                                    650 ;--------------------------------------------------------
                                    651 ; code
                                    652 ;--------------------------------------------------------
                                    653 	.area CSEG    (CODE)
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    656 ;------------------------------------------------------------
                                    657 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    658 ;------------------------------------------------------------
                                    659 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    660 ;	-----------------------------------------
                           000007   661 	ar7 = 0x07
                           000006   662 	ar6 = 0x06
                           000005   663 	ar5 = 0x05
                           000004   664 	ar4 = 0x04
                           000003   665 	ar3 = 0x03
                           000002   666 	ar2 = 0x02
                           000001   667 	ar1 = 0x01
                           000000   668 	ar0 = 0x00
                                    669 ;	 function vial_unlock_task
                                    670 ;	-----------------------------------------
      00B320                        671 _vial_unlock_task:
                                    672 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B320 90 0E B3         [24]  673 	mov	dptr,#_vial_unlock_in_progress
      00B323 E0               [24]  674 	movx	a,@dptr
      00B324 70 01            [24]  675 	jnz	00131$
      00B326 22               [24]  676 	ret
                                    677 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B327                        678 00131$:
      00B327 7F 00            [12]  679 	mov	r7,#0x00
      00B329                        680 00115$:
      00B329 BF 02 00         [24]  681 	cjne	r7,#0x02,00184$
      00B32C                        682 00184$:
      00B32C 50 29            [24]  683 	jnc	00105$
                                    684 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B32E EF               [12]  685 	mov	a,r7
      00B32F 12 B9 A3         [24]  686 	lcall	_ak820_outline_0132
      00B332 FE               [12]  687 	mov	r6,a
      00B333 EF               [12]  688 	mov	a,r7
      00B334 12 B9 98         [24]  689 	lcall	_ak820_outline_0131
      00B337 90 07 C7         [24]  690 	mov	dptr,#_matrix_is_on_PARM_2
      00B33A F0               [24]  691 	movx	@dptr,a
      00B33B 8E 82            [24]  692 	mov	dpl, r6
      00B33D C0 07            [24]  693 	push	ar7
      00B33F 12 5E F1         [24]  694 	lcall	_matrix_is_on
      00B342 E5 82            [12]  695 	mov	a, dpl
      00B344 D0 07            [24]  696 	pop	ar7
      00B346 70 0C            [24]  697 	jnz	00116$
                                    698 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B348 90 0C D5         [24]  699 	mov	dptr,#_vial_unlock_holding
      00B34B E4               [12]  700 	clr	a
      00B34C F0               [24]  701 	movx	@dptr,a
                                    702 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B34D 90 0E B4         [24]  703 	mov	dptr,#_vial_unlock_counter
      00B350 74 1E            [12]  704 	mov	a,#0x1e
      00B352 F0               [24]  705 	movx	@dptr,a
                                    706 ;	quantum/vial.c:69: return;
      00B353 22               [24]  707 	ret
      00B354                        708 00116$:
                                    709 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B354 0F               [12]  710 	inc	r7
      00B355 80 D2            [24]  711 	sjmp	00115$
      00B357                        712 00105$:
                                    713 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B357 90 0C D5         [24]  714 	mov	dptr,#_vial_unlock_holding
      00B35A E0               [24]  715 	movx	a,@dptr
      00B35B 70 12            [24]  716 	jnz	00107$
                                    717 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B35D 90 0C D5         [24]  718 	mov	dptr,#_vial_unlock_holding
      00B360 74 01            [12]  719 	mov	a,#0x01
      00B362 F0               [24]  720 	movx	@dptr,a
                                    721 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B363 12 4E DC         [24]  722 	lcall	_timer_read32
      00B366 12 54 EC         [24]  723 	lcall	_ak820_outline_0061
      00B369 90 0C D1         [24]  724 	mov	dptr,#_vial_unlock_timer
      00B36C 12 97 6C         [24]  725 	lcall	_ak820_outline_0008
      00B36F                        726 00107$:
                                    727 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B36F 90 0C D1         [24]  728 	mov	dptr,#_vial_unlock_timer
      00B372 12 54 DB         [24]  729 	lcall	_ak820_outline_0059
      00B375 12 4F 35         [24]  730 	lcall	_timer_elapsed32
      00B378 12 54 EC         [24]  731 	lcall	_ak820_outline_0061
                                    732 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B37B 7B 1E            [12]  733 	mov	r3,#0x1e
      00B37D                        734 00109$:
      00B37D EB               [12]  735 	mov	a,r3
      00B37E 60 22            [24]  736 	jz	00111$
      00B380 C3               [12]  737 	clr	c
      00B381 EC               [12]  738 	mov	a,r4
      00B382 94 64            [12]  739 	subb	a,#0x64
      00B384 ED               [12]  740 	mov	a,r5
      00B385 94 00            [12]  741 	subb	a,#0x00
      00B387 EE               [12]  742 	mov	a,r6
      00B388 94 00            [12]  743 	subb	a,#0x00
      00B38A EF               [12]  744 	mov	a,r7
      00B38B 94 00            [12]  745 	subb	a,#0x00
      00B38D 40 13            [24]  746 	jc	00111$
                                    747 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B38F EC               [12]  748 	mov	a,r4
      00B390 24 9C            [12]  749 	add	a,#0x9c
      00B392 FC               [12]  750 	mov	r4,a
      00B393 ED               [12]  751 	mov	a,r5
      00B394 34 FF            [12]  752 	addc	a,#0xff
      00B396 FD               [12]  753 	mov	r5,a
      00B397 EE               [12]  754 	mov	a,r6
      00B398 34 FF            [12]  755 	addc	a,#0xff
      00B39A FE               [12]  756 	mov	r6,a
      00B39B EF               [12]  757 	mov	a,r7
      00B39C 34 FF            [12]  758 	addc	a,#0xff
      00B39E FF               [12]  759 	mov	r7,a
                                    760 ;	quantum/vial.c:82: --counter;
      00B39F 1B               [12]  761 	dec	r3
      00B3A0 80 DB            [24]  762 	sjmp	00109$
      00B3A2                        763 00111$:
                                    764 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B3A2 90 0E B4         [24]  765 	mov	dptr,#_vial_unlock_counter
      00B3A5 EB               [12]  766 	mov	a,r3
      00B3A6 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:85: if (!counter) {
      00B3A7 EB               [12]  769 	mov	a,r3
      00B3A8 70 0A            [24]  770 	jnz	00117$
                                    771 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B3AA 90 0E B3         [24]  772 	mov	dptr,#_vial_unlock_in_progress
      00B3AD E4               [12]  773 	clr	a
      00B3AE F0               [24]  774 	movx	@dptr,a
                                    775 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B3AF 90 0E B2         [24]  776 	mov	dptr,#_vial_unlocked
      00B3B2 04               [12]  777 	inc	a
      00B3B3 F0               [24]  778 	movx	@dptr,a
      00B3B4                        779 00117$:
                                    780 ;	quantum/vial.c:90: }
      00B3B4 22               [24]  781 	ret
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'vial_init'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/vial.c:117: void vial_init(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function vial_init
                                    788 ;	-----------------------------------------
      00B3B5                        789 _vial_init:
                                    790 ;	quantum/vial.c:125: reload_combo();
      00B3B5 12 35 39         [24]  791 	lcall	_ak820_combo_reload
                                    792 ;	quantum/vial.c:128: reload_key_override();
                                    793 ;	quantum/vial.c:130: }
      00B3B8 02 3C FE         [24]  794 	ljmp	_ak820_key_override_reload
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    797 ;------------------------------------------------------------
                                    798 ;in            Allocated with name '_vial_keycode_firewall_in_10000_619'
                                    799 ;------------------------------------------------------------
                                    800 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    801 ;	-----------------------------------------
                                    802 ;	 function vial_keycode_firewall
                                    803 ;	-----------------------------------------
      00B3BB                        804 _vial_keycode_firewall:
      00B3BB 12 38 44         [24]  805 	lcall	_ak820_outline_0109
      00B3BE 90 0C D6         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_619
      00B3C1 12 38 49         [24]  807 	lcall	_ak820_outline_0110
                                    808 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B3C4 90 0C D6         [24]  809 	mov	dptr,#_vial_keycode_firewall_in_10000_619
      00B3C7 12 37 C8         [24]  810 	lcall	_ak820_outline_0009
      00B3CA BC 00 0D         [24]  811 	cjne	r4,#0x00,00102$
      00B3CD BD 7C 0A         [24]  812 	cjne	r5,#0x7c,00102$
      00B3D0 90 0E B2         [24]  813 	mov	dptr,#_vial_unlocked
      00B3D3 E0               [24]  814 	movx	a,@dptr
      00B3D4 70 04            [24]  815 	jnz	00102$
                                    816 ;	quantum/vial.c:134: return 0;
      00B3D6 90 00 00         [24]  817 	mov	dptr,#0x0000
      00B3D9 22               [24]  818 	ret
      00B3DA                        819 00102$:
                                    820 ;	quantum/vial.c:135: return in;
      00B3DA 12 49 5D         [24]  821 	lcall	_ak820_outline_0120
                                    822 ;	quantum/vial.c:136: }
      00B3DD 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'vial_fill_packet'
                                    826 ;------------------------------------------------------------
                                    827 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    828 ;msg           Allocated with name '_vial_fill_packet_msg_10000_622'
                                    829 ;i             Allocated with name '_vial_fill_packet_i_20000_624'
                                    830 ;------------------------------------------------------------
                                    831 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    832 ;	-----------------------------------------
                                    833 ;	 function vial_fill_packet
                                    834 ;	-----------------------------------------
      00B3DE                        835 _vial_fill_packet:
      00B3DE 12 38 44         [24]  836 	lcall	_ak820_outline_0109
      00B3E1 90 0C D9         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_622
      00B3E4 12 38 49         [24]  838 	lcall	_ak820_outline_0110
                                    839 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B3E7 90 0C D9         [24]  840 	mov	dptr,#_vial_fill_packet_msg_10000_622
      00B3EA 12 37 FD         [24]  841 	lcall	_ak820_outline_0056
      00B3ED 90 0C D8         [24]  842 	mov	dptr,#_vial_fill_packet_PARM_2
      00B3F0 E0               [24]  843 	movx	a,@dptr
      00B3F1 FD               [12]  844 	mov	r5,a
      00B3F2 7C 00            [12]  845 	mov	r4,#0x00
      00B3F4                        846 00103$:
      00B3F4 BC 20 00         [24]  847 	cjne	r4,#0x20,00122$
      00B3F7                        848 00122$:
      00B3F7 50 09            [24]  849 	jnc	00105$
      00B3F9 EC               [12]  850 	mov	a,r4
      00B3FA 12 37 ED         [24]  851 	lcall	_ak820_outline_0033
      00B3FD ED               [12]  852 	mov	a,r5
      00B3FE F0               [24]  853 	movx	@dptr,a
      00B3FF 0C               [12]  854 	inc	r4
      00B400 80 F2            [24]  855 	sjmp	00103$
      00B402                        856 00105$:
                                    857 ;	quantum/vial.c:141: }
      00B402 22               [24]  858 	ret
                                    859 ;------------------------------------------------------------
                                    860 ;Allocation info for local variables in function 'vial_release_held_state'
                                    861 ;------------------------------------------------------------
                                    862 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    863 ;	-----------------------------------------
                                    864 ;	 function vial_release_held_state
                                    865 ;	-----------------------------------------
      00B403                        866 _vial_release_held_state:
                                    867 ;	quantum/vial.c:174: repeat_key_cancel();
      00B403 12 A8 20         [24]  868 	lcall	_repeat_key_cancel
                                    869 ;	quantum/vial.c:176: clear_keyboard();
                                    870 ;	quantum/vial.c:177: }
      00B406 02 7B BD         [24]  871 	ljmp	_clear_keyboard
                                    872 ;------------------------------------------------------------
                                    873 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    874 ;------------------------------------------------------------
                                    875 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    876 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    877 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    878 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    879 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    880 ;data          Allocated with name '_vial_handle_cmd_data_10000_627'
                                    881 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_628'
                                    882 ;i             Allocated with name '_vial_handle_cmd_i_50000_633'
                                    883 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_634'
                                    884 ;page          Allocated with name '_vial_handle_cmd_page_40001_637'
                                    885 ;start         Allocated with name '_vial_handle_cmd_start_40002_639'
                                    886 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_639'
                                    887 ;count         Allocated with name '_vial_handle_cmd_count_40002_639'
                                    888 ;i             Allocated with name '_vial_handle_cmd_i_50002_640'
                                    889 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_641'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_641'
                                    891 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_641'
                                    892 ;i             Allocated with name '_vial_handle_cmd_i_50000_644'
                                    893 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_655'
                                    894 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_655'
                                    895 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_656'
                                    896 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_656'
                                    897 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_658'
                                    898 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_658'
                                    899 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_659'
                                    900 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_659'
                                    901 ;------------------------------------------------------------
                                    902 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    903 ;	-----------------------------------------
                                    904 ;	 function vial_handle_cmd
                                    905 ;	-----------------------------------------
      00B409                        906 _vial_handle_cmd:
      00B409 12 49 1A         [24]  907 	lcall	_ak820_outline_0038
      00B40C 90 0C DC         [24]  908 	mov	dptr,#_vial_handle_cmd_data_10000_627
      00B40F 12 37 E5         [24]  909 	lcall	_ak820_outline_0020
                                    910 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B412 90 0C DC         [24]  911 	mov	dptr,#_vial_handle_cmd_data_10000_627
      00B415 12 37 FD         [24]  912 	lcall	_ak820_outline_0056
                                    913 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B418 90 0C DB         [24]  914 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B41B E0               [24]  915 	movx	a,@dptr
      00B41C FD               [12]  916 	mov	r5,a
      00B41D BD 20 02         [24]  917 	cjne	r5,#0x20,00255$
      00B420 80 01            [24]  918 	sjmp	00102$
      00B422                        919 00255$:
                                    920 ;	quantum/vial.c:190: return;
      00B422 22               [24]  921 	ret
      00B423                        922 00102$:
                                    923 ;	quantum/vial.c:193: switch (msg[1]) {
      00B423 74 01            [12]  924 	mov	a,#0x01
      00B425 12 41 26         [24]  925 	lcall	_ak820_outline_0012
      00B428 FB               [12]  926 	mov  r3,a
      00B429 24 F2            [12]  927 	add	a,#0xff - 0x0d
      00B42B 50 01            [24]  928 	jnc	00256$
      00B42D 22               [24]  929 	ret
      00B42E                        930 00256$:
                                    931 ;	free result
      00B42E EB               [12]  932 	mov	a,r3
      00B42F 24 0A            [12]  933 	add	a,#(00257$-3-.)
      00B431 83               [24]  934 	movc	a,@a+pc
      00B432 F5 82            [12]  935 	mov	dpl,a
      00B434 EB               [12]  936 	mov	a,r3
      00B435 24 12            [12]  937 	add	a,#(00258$-3-.)
      00B437 83               [24]  938 	movc	a,@a+pc
      00B438 F5 83            [12]  939 	mov	dph,a
      00B43A E4               [12]  940 	clr	a
      00B43B 73               [24]  941 	jmp	@a+dptr
      00B43C                        942 00257$:
      00B43C 58                     943 	.db	00103$
      00B43D A0                     944 	.db	00105$
      00B43E B5                     945 	.db	00106$
      00B43F 40                     946 	.db	00112$
      00B440 C6                     947 	.db	00113$
      00B441 0F                     948 	.db	00114$
      00B442 7E                     949 	.db	00116$
      00B443 99                     950 	.db	00119$
      00B444 B8                     951 	.db	00120$
      00B445 C6                     952 	.db	00121$
      00B446 86                     953 	.db	00143$
      00B447 86                     954 	.db	00143$
      00B448 86                     955 	.db	00143$
      00B449 D1                     956 	.db	00122$
      00B44A                        957 00258$:
      00B44A B4                     958 	.db	00103$>>8
      00B44B B4                     959 	.db	00105$>>8
      00B44C B4                     960 	.db	00106$>>8
      00B44D B5                     961 	.db	00112$>>8
      00B44E B5                     962 	.db	00113$>>8
      00B44F B6                     963 	.db	00114$>>8
      00B450 B6                     964 	.db	00116$>>8
      00B451 B6                     965 	.db	00119$>>8
      00B452 B6                     966 	.db	00120$>>8
      00B453 B6                     967 	.db	00121$>>8
      00B454 B8                     968 	.db	00143$>>8
      00B455 B8                     969 	.db	00143$>>8
      00B456 B8                     970 	.db	00143$>>8
      00B457 B6                     971 	.db	00122$>>8
                                    972 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B458                        973 00103$:
                                    974 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B458 90 0C D8         [24]  975 	mov	dptr,#_vial_fill_packet_PARM_2
      00B45B E4               [12]  976 	clr	a
      00B45C 12 49 3E         [24]  977 	lcall	_ak820_outline_0063
      00B45F C0 07            [24]  978 	push	ar7
      00B461 C0 06            [24]  979 	push	ar6
      00B463 12 B3 DE         [24]  980 	lcall	_vial_fill_packet
      00B466 D0 06            [24]  981 	pop	ar6
      00B468 D0 07            [24]  982 	pop	ar7
                                    983 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B46A 12 49 5D         [24]  984 	lcall	_ak820_outline_0120
      00B46D 74 06            [12]  985 	mov	a,#0x06
      00B46F 12 49 3E         [24]  986 	lcall	_ak820_outline_0063
                                    987 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B472 A3               [24]  988 	inc	dptr
      00B473 E4               [12]  989 	clr	a
      00B474 12 49 12         [24]  990 	lcall	_ak820_outline_0025
                                    991 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B477 12 49 12         [24]  992 	lcall	_ak820_outline_0025
                                    993 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B47A A3               [24]  994 	inc	dptr
      00B47B F0               [24]  995 	movx	@dptr,a
                                    996 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B47C FB               [12]  997 	mov	r3,a
      00B47D                        998 00135$:
      00B47D BB 08 00         [24]  999 	cjne	r3,#0x08,00259$
      00B480                       1000 00259$:
      00B480 50 15            [24] 1001 	jnc	00104$
      00B482 8B 02            [24] 1002 	mov	ar2,r3
      00B484 74 04            [12] 1003 	mov	a,#0x04
      00B486 2A               [12] 1004 	add	a, r2
      00B487 2E               [12] 1005 	add	a, r6
      00B488 F9               [12] 1006 	mov	r1,a
      00B489 E4               [12] 1007 	clr	a
      00B48A 3F               [12] 1008 	addc	a,r7
      00B48B FA               [12] 1009 	mov	r2,a
      00B48C EB               [12] 1010 	mov	a,r3
      00B48D 90 C6 3D         [24] 1011 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_632
      00B490 93               [24] 1012 	movc	a,@a+dptr
      00B491 12 71 E2         [24] 1013 	lcall	_ak820_outline_0143
      00B494 0B               [12] 1014 	inc	r3
      00B495 80 E6            [24] 1015 	sjmp	00135$
      00B497                       1016 00104$:
                                   1017 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B497 74 0C            [12] 1018 	mov	a,#0x0c
      00B499 12 37 ED         [24] 1019 	lcall	_ak820_outline_0033
      00B49C 74 01            [12] 1020 	mov	a,#0x01
      00B49E F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	quantum/vial.c:207: break;
      00B49F 22               [24] 1023 	ret
                                   1024 ;	quantum/vial.c:210: case vial_get_size: {
      00B4A0                       1025 00105$:
                                   1026 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B4A0 12 49 5D         [24] 1027 	lcall	_ak820_outline_0120
      00B4A3 74 7C            [12] 1028 	mov	a,#0x7c
      00B4A5 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B4A6 12 38 54         [24] 1031 	lcall	_ak820_outline_0128
      00B4A9 74 01            [12] 1032 	mov	a,#0x01
      00B4AB 12 49 12         [24] 1033 	lcall	_ak820_outline_0025
                                   1034 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B4AE E4               [12] 1035 	clr	a
      00B4AF 12 49 12         [24] 1036 	lcall	_ak820_outline_0025
                                   1037 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B4B2 A3               [24] 1038 	inc	dptr
      00B4B3 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	quantum/vial.c:216: break;
      00B4B4 22               [24] 1041 	ret
                                   1042 ;	quantum/vial.c:219: case vial_get_def: {
      00B4B5                       1043 00106$:
                                   1044 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B4B5 12 41 47         [24] 1045 	lcall	_ak820_outline_0018
      00B4B8 FB               [12] 1046 	mov	r3,a
      00B4B9 12 49 08         [24] 1047 	lcall	_ak820_outline_0011
      00B4BC E0               [24] 1048 	movx	a,@dptr
      00B4BD 4B               [12] 1049 	orl	a,r3
      00B4BE 60 01            [24] 1050 	jz	00108$
      00B4C0 22               [24] 1051 	ret
      00B4C1                       1052 00108$:
                                   1053 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B4C1 12 37 F5         [24] 1054 	lcall	_ak820_outline_0034
      00B4C4 FB               [12] 1055 	mov	r3,a
      00B4C5 7A 00            [12] 1056 	mov	r2,#0x00
      00B4C7 12 41 31         [24] 1057 	lcall	_ak820_outline_0016
      00B4CA F9               [12] 1058 	mov	r1,a
      00B4CB E4               [12] 1059 	clr	a
      00B4CC 42 03            [12] 1060 	orl	ar3,a
      00B4CE E9               [12] 1061 	mov	a,r1
      00B4CF 42 02            [12] 1062 	orl	ar2,a
                                   1063 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B4D1 C3               [12] 1064 	clr	c
      00B4D2 EB               [12] 1065 	mov	a,r3
      00B4D3 94 0C            [12] 1066 	subb	a,#0x0c
      00B4D5 EA               [12] 1067 	mov	a,r2
      00B4D6 94 00            [12] 1068 	subb	a,#0x00
      00B4D8 40 01            [24] 1069 	jc	00110$
      00B4DA 22               [24] 1070 	ret
      00B4DB                       1071 00110$:
                                   1072 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B4DB EA               [12] 1073 	mov	a,r2
      00B4DC C4               [12] 1074 	swap	a
      00B4DD 23               [12] 1075 	rl	a
      00B4DE 54 E0            [12] 1076 	anl	a,#0xe0
      00B4E0 CB               [12] 1077 	xch	a,r3
      00B4E1 C4               [12] 1078 	swap	a
      00B4E2 23               [12] 1079 	rl	a
      00B4E3 CB               [12] 1080 	xch	a,r3
      00B4E4 6B               [12] 1081 	xrl	a,r3
      00B4E5 CB               [12] 1082 	xch	a,r3
      00B4E6 54 E0            [12] 1083 	anl	a,#0xe0
      00B4E8 CB               [12] 1084 	xch	a,r3
      00B4E9 6B               [12] 1085 	xrl	a,r3
      00B4EA FA               [12] 1086 	mov	r2,a
      00B4EB 8B 4B            [24] 1087 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B4ED 8A 4C            [24] 1088 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1089 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B4EF 74 7C            [12] 1090 	mov	a,#0x7c
      00B4F1 C3               [12] 1091 	clr	c
      00B4F2 95 4B            [12] 1092 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B4F4 F8               [12] 1093 	mov	r0,a
      00B4F5 74 01            [12] 1094 	mov	a,#0x01
      00B4F7 95 4C            [12] 1095 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B4F9 F9               [12] 1096 	mov	r1,a
                                   1097 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B4FA C3               [12] 1098 	clr	c
      00B4FB E8               [12] 1099 	mov	a,r0
      00B4FC 94 20            [12] 1100 	subb	a,#0x20
      00B4FE E9               [12] 1101 	mov	a,r1
      00B4FF 94 00            [12] 1102 	subb	a,#0x00
      00B501 40 02            [24] 1103 	jc	00146$
      00B503 78 20            [12] 1104 	mov	r0,#0x20
      00B505                       1105 00146$:
                                   1106 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B505 79 00            [12] 1107 	mov	r1,#0x00
      00B507                       1108 00138$:
      00B507 C3               [12] 1109 	clr	c
      00B508 E9               [12] 1110 	mov	a,r1
      00B509 98               [12] 1111 	subb	a,r0
      00B50A 40 01            [24] 1112 	jc	00264$
      00B50C 22               [24] 1113 	ret
      00B50D                       1114 00264$:
      00B50D C0 00            [24] 1115 	push	ar0
      00B50F E9               [12] 1116 	mov	a,r1
      00B510 2E               [12] 1117 	add	a, r6
      00B511 F5 4D            [12] 1118 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B513 E4               [12] 1119 	clr	a
      00B514 3F               [12] 1120 	addc	a, r7
      00B515 F5 4E            [12] 1121 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B517 89 4F            [24] 1122 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B519 75 50 00         [24] 1123 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B51C A8 4B            [24] 1124 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B51E AB 4C            [24] 1125 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B520 E5 4F            [12] 1126 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B522 28               [12] 1127 	add	a, r0
      00B523 F8               [12] 1128 	mov	r0,a
      00B524 E5 50            [12] 1129 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B526 3B               [12] 1130 	addc	a, r3
      00B527 FB               [12] 1131 	mov	r3,a
      00B528 E8               [12] 1132 	mov	a,r0
      00B529 24 C1            [12] 1133 	add	a, #_keyboard_definition
      00B52B F5 82            [12] 1134 	mov	dpl,a
      00B52D EB               [12] 1135 	mov	a,r3
      00B52E 34 C4            [12] 1136 	addc	a, #(_keyboard_definition >> 8)
      00B530 F5 83            [12] 1137 	mov	dph,a
      00B532 E4               [12] 1138 	clr	a
      00B533 93               [24] 1139 	movc	a,@a+dptr
      00B534 85 4D 82         [24] 1140 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B537 85 4E 83         [24] 1141 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B53A F0               [24] 1142 	movx	@dptr,a
      00B53B 09               [12] 1143 	inc	r1
      00B53C D0 00            [24] 1144 	pop	ar0
                                   1145 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B53E 80 C7            [24] 1146 	sjmp	00138$
      00B540                       1147 00112$:
                                   1148 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B540 74 02            [12] 1149 	mov	a,#0x02
      00B542 12 4E 6A         [24] 1150 	lcall	_ak820_outline_0051
      00B545 F5 4F            [12] 1151 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1152 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B547 74 03            [12] 1153 	mov	a,#0x03
      00B549 2E               [12] 1154 	add	a, r6
      00B54A F5 4D            [12] 1155 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B54C E4               [12] 1156 	clr	a
      00B54D 3F               [12] 1157 	addc	a, r7
      00B54E F5 4E            [12] 1158 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B550 85 4D 82         [24] 1159 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B553 85 4E 83         [24] 1160 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B556 E0               [24] 1161 	movx	a,@dptr
                                   1162 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B557 F5 4B            [12] 1163 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B559 90 0B 6B         [24] 1164 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B55C F0               [24] 1165 	movx	@dptr,a
      00B55D 90 0B 6C         [24] 1166 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B560 E4               [12] 1167 	clr	a
      00B561 F0               [24] 1168 	movx	@dptr,a
      00B562 85 4F 82         [24] 1169 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B565 C0 07            [24] 1170 	push	ar7
      00B567 C0 06            [24] 1171 	push	ar6
      00B569 C0 05            [24] 1172 	push	ar5
      00B56B C0 04            [24] 1173 	push	ar4
      00B56D C0 03            [24] 1174 	push	ar3
      00B56F C0 02            [24] 1175 	push	ar2
      00B571 12 8A AD         [24] 1176 	lcall	_dynamic_keymap_get_encoder
      00B574 85 82 51         [24] 1177 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B577 85 83 52         [24] 1178 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B57A D0 02            [24] 1179 	pop	ar2
      00B57C D0 03            [24] 1180 	pop	ar3
      00B57E D0 04            [24] 1181 	pop	ar4
      00B580 D0 05            [24] 1182 	pop	ar5
      00B582 D0 06            [24] 1183 	pop	ar6
      00B584 D0 07            [24] 1184 	pop	ar7
                                   1185 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B586 A9 52            [24] 1186 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B588 12 49 5D         [24] 1187 	lcall	_ak820_outline_0120
      00B58B E9               [12] 1188 	mov	a,r1
      00B58C F0               [24] 1189 	movx	@dptr,a
                                   1190 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B58D A8 51            [24] 1191 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B58F 12 38 54         [24] 1192 	lcall	_ak820_outline_0128
      00B592 E8               [12] 1193 	mov	a,r0
      00B593 F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B594 90 0B 6B         [24] 1196 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B597 E5 4B            [12] 1197 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B599 F0               [24] 1198 	movx	@dptr,a
      00B59A 90 0B 6C         [24] 1199 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B59D 74 01            [12] 1200 	mov	a,#0x01
      00B59F F0               [24] 1201 	movx	@dptr,a
      00B5A0 85 4F 82         [24] 1202 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B5A3 C0 03            [24] 1203 	push	ar3
      00B5A5 C0 02            [24] 1204 	push	ar2
      00B5A7 12 8A AD         [24] 1205 	lcall	_dynamic_keymap_get_encoder
      00B5AA 85 82 51         [24] 1206 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B5AD 85 83 52         [24] 1207 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B5B0 D0 02            [24] 1208 	pop	ar2
      00B5B2 D0 03            [24] 1209 	pop	ar3
                                   1210 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B5B4 A9 52            [24] 1211 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B5B6 12 49 7F         [24] 1212 	lcall	_ak820_outline_0148
      00B5B9 E9               [12] 1213 	mov	a,r1
      00B5BA F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B5BB A8 51            [24] 1216 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B5BD 85 4D 82         [24] 1217 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B5C0 85 4E 83         [24] 1218 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B5C3 E8               [12] 1219 	mov	a,r0
      00B5C4 F0               [24] 1220 	movx	@dptr,a
                                   1221 ;	quantum/vial.c:255: break;
      00B5C5 22               [24] 1222 	ret
                                   1223 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B5C6                       1224 00113$:
                                   1225 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B5C6 12 37 F5         [24] 1226 	lcall	_ak820_outline_0034
      00B5C9 F5 4D            [12] 1227 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B5CB 12 41 31         [24] 1228 	lcall	_ak820_outline_0016
      00B5CE F5 4F            [12] 1229 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B5D0 12 41 47         [24] 1230 	lcall	_ak820_outline_0018
                                   1231 ;	assignBit
      00B5D3 24 FF            [12] 1232 	add	a,#0xff
      00B5D5 E4               [12] 1233 	clr	a
      00B5D6 33               [12] 1234 	rlc	a
      00B5D7 F5 51            [12] 1235 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B5D9 12 49 08         [24] 1236 	lcall	_ak820_outline_0011
      00B5DC E0               [24] 1237 	movx	a,@dptr
      00B5DD F9               [12] 1238 	mov	r1,a
      00B5DE 78 00            [12] 1239 	mov	r0,#0x00
      00B5E0 74 06            [12] 1240 	mov	a,#0x06
      00B5E2 12 37 D2         [24] 1241 	lcall	_ak820_outline_0013
      00B5E5 7B 00            [12] 1242 	mov	r3,#0x00
      00B5E7 42 00            [12] 1243 	orl	ar0,a
      00B5E9 EB               [12] 1244 	mov	a,r3
      00B5EA 42 01            [12] 1245 	orl	ar1,a
      00B5EC 12 38 6E         [24] 1246 	lcall	_ak820_outline_0162
      00B5EF 12 B3 BB         [24] 1247 	lcall	_vial_keycode_firewall
      00B5F2 AA 82            [24] 1248 	mov	r2, dpl
      00B5F4 AB 83            [24] 1249 	mov	r3, dph
      00B5F6 90 0B 6E         [24] 1250 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B5F9 E5 4F            [12] 1251 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B5FB F0               [24] 1252 	movx	@dptr,a
      00B5FC 90 0B 6F         [24] 1253 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B5FF E5 51            [12] 1254 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B601 F0               [24] 1255 	movx	@dptr,a
      00B602 90 0B 70         [24] 1256 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B605 EA               [12] 1257 	mov	a,r2
      00B606 12 55 18         [24] 1258 	lcall	_ak820_outline_0196
      00B609 85 4D 82         [24] 1259 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1260 ;	quantum/vial.c:259: break;
      00B60C 02 8B 14         [24] 1261 	ljmp	_dynamic_keymap_set_encoder
                                   1262 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B60F                       1263 00114$:
                                   1264 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B60F 90 0C D8         [24] 1265 	mov	dptr,#_vial_fill_packet_PARM_2
      00B612 74 FF            [12] 1266 	mov	a,#0xff
      00B614 12 49 3E         [24] 1267 	lcall	_ak820_outline_0063
      00B617 C0 07            [24] 1268 	push	ar7
      00B619 C0 06            [24] 1269 	push	ar6
      00B61B 12 B3 DE         [24] 1270 	lcall	_vial_fill_packet
      00B61E D0 06            [24] 1271 	pop	ar6
      00B620 D0 07            [24] 1272 	pop	ar7
                                   1273 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B622 90 0E B2         [24] 1274 	mov	dptr,#_vial_unlocked
      00B625 E0               [24] 1275 	movx	a,@dptr
      00B626 12 49 5D         [24] 1276 	lcall	_ak820_outline_0120
      00B629 F0               [24] 1277 	movx	@dptr,a
                                   1278 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B62A 74 01            [12] 1279 	mov	a,#0x01
      00B62C 2E               [12] 1280 	add	a, r6
      00B62D FA               [12] 1281 	mov	r2,a
      00B62E E4               [12] 1282 	clr	a
      00B62F 3F               [12] 1283 	addc	a, r7
      00B630 FB               [12] 1284 	mov	r3,a
      00B631 90 0E B3         [24] 1285 	mov	dptr,#_vial_unlock_in_progress
      00B634 E0               [24] 1286 	movx	a,@dptr
      00B635 12 49 7F         [24] 1287 	lcall	_ak820_outline_0148
      00B638 F0               [24] 1288 	movx	@dptr,a
                                   1289 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B639 7B 00            [12] 1290 	mov	r3,#0x00
      00B63B                       1291 00141$:
      00B63B BB 02 00         [24] 1292 	cjne	r3,#0x02,00265$
      00B63E                       1293 00265$:
      00B63E 40 01            [24] 1294 	jc	00266$
      00B640 22               [24] 1295 	ret
      00B641                       1296 00266$:
                                   1297 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B641 8B 01            [24] 1298 	mov	ar1,r3
      00B643 7A 00            [12] 1299 	mov	r2,#0x00
      00B645 E9               [12] 1300 	mov	a,r1
      00B646 29               [12] 1301 	add	a,r1
      00B647 F5 51            [12] 1302 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B649 EA               [12] 1303 	mov	a,r2
      00B64A 33               [12] 1304 	rlc	a
      00B64B F5 52            [12] 1305 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B64D 74 02            [12] 1306 	mov	a,#0x02
      00B64F 25 51            [12] 1307 	add	a, _vial_handle_cmd_sloc3_1_0
      00B651 F8               [12] 1308 	mov	r0,a
      00B652 E4               [12] 1309 	clr	a
      00B653 35 52            [12] 1310 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B655 FA               [12] 1311 	mov	r2,a
      00B656 E8               [12] 1312 	mov	a,r0
      00B657 2E               [12] 1313 	add	a, r6
      00B658 F8               [12] 1314 	mov	r0,a
      00B659 EA               [12] 1315 	mov	a,r2
      00B65A 3F               [12] 1316 	addc	a, r7
      00B65B FA               [12] 1317 	mov	r2,a
      00B65C EB               [12] 1318 	mov	a,r3
      00B65D 12 B9 A3         [24] 1319 	lcall	_ak820_outline_0132
      00B660 88 82            [24] 1320 	mov	dpl,r0
      00B662 8A 83            [24] 1321 	mov	dph,r2
      00B664 F0               [24] 1322 	movx	@dptr,a
                                   1323 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B665 74 03            [12] 1324 	mov	a,#0x03
      00B667 25 51            [12] 1325 	add	a, _vial_handle_cmd_sloc3_1_0
      00B669 F9               [12] 1326 	mov	r1,a
      00B66A E4               [12] 1327 	clr	a
      00B66B 35 52            [12] 1328 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B66D FA               [12] 1329 	mov	r2,a
      00B66E E9               [12] 1330 	mov	a,r1
      00B66F 2E               [12] 1331 	add	a, r6
      00B670 F9               [12] 1332 	mov	r1,a
      00B671 EA               [12] 1333 	mov	a,r2
      00B672 3F               [12] 1334 	addc	a, r7
      00B673 FA               [12] 1335 	mov	r2,a
      00B674 EB               [12] 1336 	mov	a,r3
      00B675 12 B9 98         [24] 1337 	lcall	_ak820_outline_0131
      00B678 12 71 E2         [24] 1338 	lcall	_ak820_outline_0143
                                   1339 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B67B 0B               [12] 1340 	inc	r3
                                   1341 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B67C 80 BD            [24] 1342 	sjmp	00141$
      00B67E                       1343 00116$:
                                   1344 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B67E 90 0E B3         [24] 1345 	mov	dptr,#_vial_unlock_in_progress
      00B681 E0               [24] 1346 	movx	a,@dptr
      00B682 70 03            [24] 1347 	jnz	00118$
      00B684 12 B4 03         [24] 1348 	lcall	_vial_release_held_state
      00B687                       1349 00118$:
                                   1350 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B687 90 0E B3         [24] 1351 	mov	dptr,#_vial_unlock_in_progress
      00B68A 74 01            [12] 1352 	mov	a,#0x01
      00B68C F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B68D 90 0E B4         [24] 1355 	mov	dptr,#_vial_unlock_counter
      00B690 74 1E            [12] 1356 	mov	a,#0x1e
      00B692 F0               [24] 1357 	movx	@dptr,a
                                   1358 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B693 90 0C D5         [24] 1359 	mov	dptr,#_vial_unlock_holding
      00B696 E4               [12] 1360 	clr	a
      00B697 F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/vial.c:287: break;
      00B698 22               [24] 1363 	ret
                                   1364 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B699                       1365 00119$:
                                   1366 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B699 90 0E B2         [24] 1367 	mov	dptr,#_vial_unlocked
      00B69C E0               [24] 1368 	movx	a,@dptr
      00B69D 12 49 5D         [24] 1369 	lcall	_ak820_outline_0120
      00B6A0 F0               [24] 1370 	movx	@dptr,a
                                   1371 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B6A1 90 0E B3         [24] 1372 	mov	dptr,#_vial_unlock_in_progress
      00B6A4 E0               [24] 1373 	movx	a,@dptr
      00B6A5 12 49 62         [24] 1374 	lcall	_ak820_outline_0124
                                   1375 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B6A8 74 02            [12] 1376 	mov	a,#0x02
      00B6AA 2E               [12] 1377 	add	a, r6
      00B6AB FA               [12] 1378 	mov	r2,a
      00B6AC E4               [12] 1379 	clr	a
      00B6AD 3F               [12] 1380 	addc	a, r7
      00B6AE FB               [12] 1381 	mov	r3,a
      00B6AF 90 0E B4         [24] 1382 	mov	dptr,#_vial_unlock_counter
      00B6B2 E0               [24] 1383 	movx	a,@dptr
      00B6B3 12 49 7F         [24] 1384 	lcall	_ak820_outline_0148
      00B6B6 F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/vial.c:293: break;
      00B6B7 22               [24] 1387 	ret
                                   1388 ;	quantum/vial.c:295: case vial_lock: {
      00B6B8                       1389 00120$:
                                   1390 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B6B8 90 0E B2         [24] 1391 	mov	dptr,#_vial_unlocked
      00B6BB E4               [12] 1392 	clr	a
      00B6BC F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B6BD 90 0E B3         [24] 1395 	mov	dptr,#_vial_unlock_in_progress
      00B6C0 F0               [24] 1396 	movx	@dptr,a
                                   1397 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B6C1 90 0C D5         [24] 1398 	mov	dptr,#_vial_unlock_holding
      00B6C4 F0               [24] 1399 	movx	@dptr,a
                                   1400 ;	quantum/vial.c:301: break;
      00B6C5 22               [24] 1401 	ret
                                   1402 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B6C6                       1403 00121$:
                                   1404 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B6C6 90 0C D8         [24] 1405 	mov	dptr,#_vial_fill_packet_PARM_2
      00B6C9 74 FF            [12] 1406 	mov	a,#0xff
      00B6CB 12 49 3E         [24] 1407 	lcall	_ak820_outline_0063
                                   1408 ;	quantum/vial.c:314: break;
      00B6CE 02 B3 DE         [24] 1409 	ljmp	_vial_fill_packet
                                   1410 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B6D1                       1411 00122$:
                                   1412 ;	quantum/vial.c:347: switch (msg[2]) {
      00B6D1 12 37 F5         [24] 1413 	lcall	_ak820_outline_0034
      00B6D4 FB               [12] 1414 	mov  r3,a
      00B6D5 24 F9            [12] 1415 	add	a,#0xff - 0x06
      00B6D7 50 01            [24] 1416 	jnc	00268$
      00B6D9 22               [24] 1417 	ret
      00B6DA                       1418 00268$:
                                   1419 ;	free result
      00B6DA EB               [12] 1420 	mov	a,r3
      00B6DB 2B               [12] 1421 	add	a,r3
      00B6DC 2B               [12] 1422 	add	a,r3
      00B6DD 90 B6 E1         [24] 1423 	mov	dptr,#00269$
      00B6E0 73               [24] 1424 	jmp	@a+dptr
      00B6E1                       1425 00269$:
      00B6E1 02 B6 F6         [24] 1426 	ljmp	00123$
      00B6E4 02 B8 86         [24] 1427 	ljmp	00143$
      00B6E7 02 B8 86         [24] 1428 	ljmp	00143$
      00B6EA 02 B7 1F         [24] 1429 	ljmp	00124$
      00B6ED 02 B7 81         [24] 1430 	ljmp	00125$
      00B6F0 02 B7 DF         [24] 1431 	ljmp	00128$
      00B6F3 02 B8 41         [24] 1432 	ljmp	00129$
                                   1433 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B6F6                       1434 00123$:
                                   1435 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B6F6 90 0C D8         [24] 1436 	mov	dptr,#_vial_fill_packet_PARM_2
      00B6F9 E4               [12] 1437 	clr	a
      00B6FA 12 49 3E         [24] 1438 	lcall	_ak820_outline_0063
      00B6FD C0 07            [24] 1439 	push	ar7
      00B6FF C0 06            [24] 1440 	push	ar6
      00B701 12 B3 DE         [24] 1441 	lcall	_vial_fill_packet
      00B704 D0 06            [24] 1442 	pop	ar6
      00B706 D0 07            [24] 1443 	pop	ar7
                                   1444 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B708 12 49 5D         [24] 1445 	lcall	_ak820_outline_0120
      00B70B E4               [12] 1446 	clr	a
      00B70C 12 49 3E         [24] 1447 	lcall	_ak820_outline_0063
                                   1448 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B70F A3               [24] 1449 	inc	dptr
      00B710 74 08            [12] 1450 	mov	a,#0x08
      00B712 12 49 12         [24] 1451 	lcall	_ak820_outline_0025
                                   1452 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B715 F0               [24] 1453 	movx	@dptr,a
                                   1454 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B716 74 1F            [12] 1455 	mov	a,#0x1f
      00B718 12 37 ED         [24] 1456 	lcall	_ak820_outline_0033
      00B71B 74 01            [12] 1457 	mov	a,#0x01
      00B71D F0               [24] 1458 	movx	@dptr,a
                                   1459 ;	quantum/vial.c:356: break;
      00B71E 22               [24] 1460 	ret
                                   1461 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B71F                       1462 00124$:
                                   1463 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B71F 12 41 31         [24] 1464 	lcall	_ak820_outline_0016
      00B722 FB               [12] 1465 	mov	r3,a
                                   1466 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B723 90 0C DF         [24] 1467 	mov	dptr,#_vial_handle_cmd_entry_70000_655
      00B726 12 55 0D         [24] 1468 	lcall	_ak820_outline_0154
      00B729 90 0C E1         [24] 1469 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0002)
      00B72C F0               [24] 1470 	movx	@dptr,a
      00B72D A3               [24] 1471 	inc	dptr
      00B72E F0               [24] 1472 	movx	@dptr,a
      00B72F 90 0C E3         [24] 1473 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0004)
      00B732 F0               [24] 1474 	movx	@dptr,a
      00B733 A3               [24] 1475 	inc	dptr
      00B734 F0               [24] 1476 	movx	@dptr,a
      00B735 90 0C E5         [24] 1477 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0006)
      00B738 F0               [24] 1478 	movx	@dptr,a
      00B739 A3               [24] 1479 	inc	dptr
      00B73A F0               [24] 1480 	movx	@dptr,a
      00B73B 90 0C E7         [24] 1481 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0008)
      00B73E F0               [24] 1482 	movx	@dptr,a
      00B73F A3               [24] 1483 	inc	dptr
      00B740 F0               [24] 1484 	movx	@dptr,a
                                   1485 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B741 90 0B 73         [24] 1486 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B744 74 DF            [12] 1487 	mov	a,#_vial_handle_cmd_entry_70000_655
      00B746 F0               [24] 1488 	movx	@dptr,a
      00B747 74 0C            [12] 1489 	mov	a,#(_vial_handle_cmd_entry_70000_655 >> 8)
      00B749 12 38 1A         [24] 1490 	lcall	_ak820_outline_0074
      00B74C 8B 82            [24] 1491 	mov	dpl, r3
      00B74E C0 07            [24] 1492 	push	ar7
      00B750 C0 06            [24] 1493 	push	ar6
      00B752 C0 05            [24] 1494 	push	ar5
      00B754 C0 04            [24] 1495 	push	ar4
      00B756 12 8B 80         [24] 1496 	lcall	_dynamic_keymap_get_combo
      00B759 AA 82            [24] 1497 	mov	r2, dpl
      00B75B D0 04            [24] 1498 	pop	ar4
      00B75D D0 05            [24] 1499 	pop	ar5
      00B75F D0 06            [24] 1500 	pop	ar6
      00B761 D0 07            [24] 1501 	pop	ar7
      00B763 12 49 5D         [24] 1502 	lcall	_ak820_outline_0120
      00B766 EA               [12] 1503 	mov	a,r2
      00B767 F0               [24] 1504 	movx	@dptr,a
                                   1505 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B768 8C 01            [24] 1506 	mov	ar1,r4
      00B76A 8D 02            [24] 1507 	mov	ar2,r5
      00B76C 7B 00            [12] 1508 	mov	r3,#0x00
      00B76E 90 0E 2F         [24] 1509 	mov	dptr,#___memcpy_PARM_2
      00B771 74 DF            [12] 1510 	mov	a,#_vial_handle_cmd_entry_70000_655
      00B773 F0               [24] 1511 	movx	@dptr,a
      00B774 74 0C            [12] 1512 	mov	a,#(_vial_handle_cmd_entry_70000_655 >> 8)
      00B776 12 B9 70         [24] 1513 	lcall	_ak820_outline_0010
      00B779 12 49 89         [24] 1514 	lcall	_ak820_outline_0163
      00B77C 8B F0            [24] 1515 	mov	b, r3
                                   1516 ;	quantum/vial.c:387: break;
      00B77E 02 BF 43         [24] 1517 	ljmp	___memcpy
                                   1518 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B781                       1519 00125$:
                                   1520 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B781 12 41 31         [24] 1521 	lcall	_ak820_outline_0016
      00B784 FB               [12] 1522 	mov	r3,a
                                   1523 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B785 74 04            [12] 1524 	mov	a,#0x04
      00B787 2E               [12] 1525 	add	a, r6
      00B788 F9               [12] 1526 	mov	r1,a
      00B789 E4               [12] 1527 	clr	a
      00B78A 3F               [12] 1528 	addc	a, r7
      00B78B FA               [12] 1529 	mov	r2,a
      00B78C 90 0E 2F         [24] 1530 	mov	dptr,#___memcpy_PARM_2
      00B78F E9               [12] 1531 	mov	a,r1
      00B790 F0               [24] 1532 	movx	@dptr,a
      00B791 EA               [12] 1533 	mov	a,r2
      00B792 12 B9 70         [24] 1534 	lcall	_ak820_outline_0010
      00B795 90 0C E9         [24] 1535 	mov	dptr,#_vial_handle_cmd_entry_70000_656
      00B798 F5 F0            [12] 1536 	mov	b,a
      00B79A C0 07            [24] 1537 	push	ar7
      00B79C C0 06            [24] 1538 	push	ar6
      00B79E C0 03            [24] 1539 	push	ar3
      00B7A0 12 BF 43         [24] 1540 	lcall	___memcpy
                                   1541 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B7A3 90 0C F1         [24] 1542 	mov	dptr,#(_vial_handle_cmd_entry_70000_656 + 0x0008)
      00B7A6 E0               [24] 1543 	movx	a,@dptr
      00B7A7 F9               [12] 1544 	mov	r1,a
      00B7A8 A3               [24] 1545 	inc	dptr
      00B7A9 E0               [24] 1546 	movx	a,@dptr
      00B7AA FA               [12] 1547 	mov	r2,a
      00B7AB 12 49 89         [24] 1548 	lcall	_ak820_outline_0163
      00B7AE 12 B3 BB         [24] 1549 	lcall	_vial_keycode_firewall
      00B7B1 A9 82            [24] 1550 	mov	r1, dpl
      00B7B3 AA 83            [24] 1551 	mov	r2, dph
      00B7B5 D0 03            [24] 1552 	pop	ar3
      00B7B7 90 0C F1         [24] 1553 	mov	dptr,#(_vial_handle_cmd_entry_70000_656 + 0x0008)
      00B7BA 12 4E 8A         [24] 1554 	lcall	_ak820_outline_0142
                                   1555 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B7BD 90 0B 77         [24] 1556 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B7C0 74 E9            [12] 1557 	mov	a,#_vial_handle_cmd_entry_70000_656
      00B7C2 F0               [24] 1558 	movx	@dptr,a
      00B7C3 74 0C            [12] 1559 	mov	a,#(_vial_handle_cmd_entry_70000_656 >> 8)
      00B7C5 12 38 1A         [24] 1560 	lcall	_ak820_outline_0074
      00B7C8 8B 82            [24] 1561 	mov	dpl, r3
      00B7CA 12 8C 15         [24] 1562 	lcall	_dynamic_keymap_set_combo
      00B7CD AA 82            [24] 1563 	mov	r2, dpl
      00B7CF D0 06            [24] 1564 	pop	ar6
      00B7D1 D0 07            [24] 1565 	pop	ar7
      00B7D3 12 49 5D         [24] 1566 	lcall	_ak820_outline_0120
      00B7D6 EA               [12] 1567 	mov	a,r2
      00B7D7 F0               [24] 1568 	movx	@dptr,a
                                   1569 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B7D8 EA               [12] 1570 	mov	a,r2
      00B7D9 60 01            [24] 1571 	jz	00270$
      00B7DB 22               [24] 1572 	ret
      00B7DC                       1573 00270$:
                                   1574 ;	quantum/vial.c:396: break;
      00B7DC 02 35 39         [24] 1575 	ljmp	_ak820_combo_reload
                                   1576 ;	quantum/vial.c:400: case dynamic_vial_key_override_get: {
      00B7DF                       1577 00128$:
                                   1578 ;	quantum/vial.c:401: uint8_t idx = msg[3];
      00B7DF 12 41 31         [24] 1579 	lcall	_ak820_outline_0016
      00B7E2 FB               [12] 1580 	mov	r3,a
                                   1581 ;	quantum/vial.c:402: vial_key_override_entry_t entry = { 0 };
      00B7E3 90 0C F3         [24] 1582 	mov	dptr,#_vial_handle_cmd_entry_70000_658
      00B7E6 12 55 0D         [24] 1583 	lcall	_ak820_outline_0154
      00B7E9 90 0C F5         [24] 1584 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0002)
      00B7EC F0               [24] 1585 	movx	@dptr,a
      00B7ED A3               [24] 1586 	inc	dptr
      00B7EE F0               [24] 1587 	movx	@dptr,a
      00B7EF 90 0C F7         [24] 1588 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0004)
      00B7F2 F0               [24] 1589 	movx	@dptr,a
      00B7F3 A3               [24] 1590 	inc	dptr
      00B7F4 F0               [24] 1591 	movx	@dptr,a
      00B7F5 90 0C F9         [24] 1592 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0006)
      00B7F8 F0               [24] 1593 	movx	@dptr,a
      00B7F9 90 0C FA         [24] 1594 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0007)
      00B7FC F0               [24] 1595 	movx	@dptr,a
      00B7FD 90 0C FB         [24] 1596 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0008)
      00B800 F0               [24] 1597 	movx	@dptr,a
      00B801 90 0C FC         [24] 1598 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0009)
      00B804 F0               [24] 1599 	movx	@dptr,a
                                   1600 ;	quantum/vial.c:403: msg[0] = dynamic_keymap_get_key_override(idx, &entry);
      00B805 90 0B 85         [24] 1601 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      00B808 74 F3            [12] 1602 	mov	a,#_vial_handle_cmd_entry_70000_658
      00B80A F0               [24] 1603 	movx	@dptr,a
      00B80B 74 0C            [12] 1604 	mov	a,#(_vial_handle_cmd_entry_70000_658 >> 8)
      00B80D 12 38 1A         [24] 1605 	lcall	_ak820_outline_0074
      00B810 8B 82            [24] 1606 	mov	dpl, r3
      00B812 C0 07            [24] 1607 	push	ar7
      00B814 C0 06            [24] 1608 	push	ar6
      00B816 C0 05            [24] 1609 	push	ar5
      00B818 C0 04            [24] 1610 	push	ar4
      00B81A 12 8C B7         [24] 1611 	lcall	_dynamic_keymap_get_key_override
      00B81D AA 82            [24] 1612 	mov	r2, dpl
      00B81F D0 04            [24] 1613 	pop	ar4
      00B821 D0 05            [24] 1614 	pop	ar5
      00B823 D0 06            [24] 1615 	pop	ar6
      00B825 D0 07            [24] 1616 	pop	ar7
      00B827 12 49 5D         [24] 1617 	lcall	_ak820_outline_0120
      00B82A EA               [12] 1618 	mov	a,r2
      00B82B F0               [24] 1619 	movx	@dptr,a
                                   1620 ;	quantum/vial.c:404: memcpy(&msg[1], &entry, sizeof(entry));
      00B82C 7B 00            [12] 1621 	mov	r3,#0x00
      00B82E 90 0E 2F         [24] 1622 	mov	dptr,#___memcpy_PARM_2
      00B831 74 F3            [12] 1623 	mov	a,#_vial_handle_cmd_entry_70000_658
      00B833 F0               [24] 1624 	movx	@dptr,a
      00B834 74 0C            [12] 1625 	mov	a,#(_vial_handle_cmd_entry_70000_658 >> 8)
      00B836 12 B9 70         [24] 1626 	lcall	_ak820_outline_0010
      00B839 12 38 54         [24] 1627 	lcall	_ak820_outline_0128
      00B83C 8B F0            [24] 1628 	mov	b, r3
                                   1629 ;	quantum/vial.c:405: break;
                                   1630 ;	quantum/vial.c:407: case dynamic_vial_key_override_set: {
      00B83E 02 BF 43         [24] 1631 	ljmp	___memcpy
      00B841                       1632 00129$:
                                   1633 ;	quantum/vial.c:408: uint8_t idx = msg[3];
      00B841 12 41 31         [24] 1634 	lcall	_ak820_outline_0016
      00B844 FD               [12] 1635 	mov	r5,a
                                   1636 ;	quantum/vial.c:410: memcpy(&entry, &msg[4], sizeof(entry));
      00B845 74 04            [12] 1637 	mov	a,#0x04
      00B847 2E               [12] 1638 	add	a, r6
      00B848 FB               [12] 1639 	mov	r3,a
      00B849 E4               [12] 1640 	clr	a
      00B84A 3F               [12] 1641 	addc	a, r7
      00B84B FC               [12] 1642 	mov	r4,a
      00B84C 90 0E 2F         [24] 1643 	mov	dptr,#___memcpy_PARM_2
      00B84F EB               [12] 1644 	mov	a,r3
      00B850 F0               [24] 1645 	movx	@dptr,a
      00B851 EC               [12] 1646 	mov	a,r4
      00B852 12 B9 70         [24] 1647 	lcall	_ak820_outline_0010
      00B855 90 0C FD         [24] 1648 	mov	dptr,#_vial_handle_cmd_entry_70000_659
      00B858 F5 F0            [12] 1649 	mov	b,a
      00B85A C0 07            [24] 1650 	push	ar7
      00B85C C0 06            [24] 1651 	push	ar6
      00B85E C0 05            [24] 1652 	push	ar5
      00B860 12 BF 43         [24] 1653 	lcall	___memcpy
      00B863 D0 05            [24] 1654 	pop	ar5
                                   1655 ;	quantum/vial.c:414: msg[0] = dynamic_keymap_set_key_override(idx, &entry);
      00B865 90 0B 89         [24] 1656 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      00B868 74 FD            [12] 1657 	mov	a,#_vial_handle_cmd_entry_70000_659
      00B86A F0               [24] 1658 	movx	@dptr,a
      00B86B 74 0C            [12] 1659 	mov	a,#(_vial_handle_cmd_entry_70000_659 >> 8)
      00B86D 12 38 1A         [24] 1660 	lcall	_ak820_outline_0074
      00B870 8D 82            [24] 1661 	mov	dpl, r5
      00B872 12 8D 37         [24] 1662 	lcall	_dynamic_keymap_set_key_override
      00B875 AC 82            [24] 1663 	mov	r4, dpl
      00B877 D0 06            [24] 1664 	pop	ar6
      00B879 D0 07            [24] 1665 	pop	ar7
      00B87B 12 49 5D         [24] 1666 	lcall	_ak820_outline_0120
      00B87E EC               [12] 1667 	mov	a,r4
      00B87F F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	quantum/vial.c:415: if (!msg[0]) reload_key_override();
      00B880 EC               [12] 1670 	mov	a,r4
      00B881 70 03            [24] 1671 	jnz	00143$
                                   1672 ;	quantum/vial.c:423: }
                                   1673 ;	quantum/vial.c:424: }
      00B883 02 3C FE         [24] 1674 	ljmp	_ak820_key_override_reload
      00B886                       1675 00143$:
      00B886 22               [24] 1676 	ret
                                   1677 ;------------------------------------------------------------
                                   1678 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1679 ;------------------------------------------------------------
                                   1680 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_661'
                                   1681 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_668'
                                   1682 ;------------------------------------------------------------
                                   1683 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1684 ;	-----------------------------------------
                                   1685 ;	 function vial_keycode_down
                                   1686 ;	-----------------------------------------
      00B887                       1687 _vial_keycode_down:
      00B887 12 38 44         [24] 1688 	lcall	_ak820_outline_0109
      00B88A 90 0D 09         [24] 1689 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B88D 12 38 49         [24] 1690 	lcall	_ak820_outline_0110
                                   1691 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B890 90 0D 09         [24] 1692 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B893 12 37 C8         [24] 1693 	lcall	_ak820_outline_0009
      00B896 74 E0            [12] 1694 	mov	a,#0x100 - 0x20
      00B898 2D               [12] 1695 	add	a,r5
      00B899 50 19            [24] 1696 	jnc	00104$
      00B89B C3               [12] 1697 	clr	c
      00B89C 74 FF            [12] 1698 	mov	a,#0xff
      00B89E 9C               [12] 1699 	subb	a,r4
      00B89F 74 4F            [12] 1700 	mov	a,#0x4f
      00B8A1 9D               [12] 1701 	subb	a,r5
      00B8A2 40 10            [24] 1702 	jc	00104$
                                   1703 ;	free result
                                   1704 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B8A4 90 0D 09         [24] 1705 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B8A7 EE               [12] 1706 	mov	a,r6
      00B8A8 12 38 59         [24] 1707 	lcall	_ak820_outline_0129
                                   1708 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B8AB 90 0D 09         [24] 1709 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B8AE E0               [24] 1710 	movx	a,@dptr
      00B8AF 24 FE            [12] 1711 	add	a,#0xff - 0x01
      00B8B1 40 01            [24] 1712 	jc	00104$
                                   1713 ;	free result
      00B8B3 22               [24] 1714 	ret
      00B8B4                       1715 00104$:
                                   1716 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B8B4 90 0D 09         [24] 1717 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B8B7 12 B9 7F         [24] 1718 	lcall	_ak820_outline_0026
                                   1719 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B8BA 40 06            [24] 1720 	jc	00107$
                                   1721 ;	free result
                                   1722 ;	quantum/vial.c:440: register_code16(keycode);
      00B8BC 12 49 5D         [24] 1723 	lcall	_ak820_outline_0120
      00B8BF 02 A4 87         [24] 1724 	ljmp	_register_code16
      00B8C2                       1725 00107$:
                                   1726 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B8C2 90 0D 0F         [24] 1727 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0004)
      00B8C5 74 01            [12] 1728 	mov	a,#0x01
      00B8C7 F0               [24] 1729 	movx	@dptr,a
      00B8C8 90 0D 0C         [24] 1730 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0001)
      00B8CB 74 F0            [12] 1731 	mov	a,#0xf0
      00B8CD F0               [24] 1732 	movx	@dptr,a
      00B8CE 90 0D 0B         [24] 1733 	mov	dptr,#_vial_keycode_down_dummy_event_30000_668
      00B8D1 F0               [24] 1734 	movx	@dptr,a
      00B8D2 90 0D 10         [24] 1735 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0005)
      00B8D5 74 01            [12] 1736 	mov	a,#0x01
      00B8D7 F0               [24] 1737 	movx	@dptr,a
      00B8D8 12 4F 0D         [24] 1738 	lcall	_timer_read
      00B8DB 12 49 6E         [24] 1739 	lcall	_ak820_outline_0139
      00B8DE 43 06 01         [24] 1740 	orl	ar6,#0x01
      00B8E1 90 0D 0D         [24] 1741 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0002)
      00B8E4 12 4E 7D         [24] 1742 	lcall	_ak820_outline_0064
                                   1743 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B8E7 90 0D 0B         [24] 1744 	mov	dptr,#_vial_keycode_down_dummy_event_30000_668
                                   1745 ;	quantum/vial.c:448: }
      00B8EA 02 76 09         [24] 1746 	ljmp	_ak820_action_exec
                                   1747 ;------------------------------------------------------------
                                   1748 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1749 ;------------------------------------------------------------
                                   1750 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_669'
                                   1751 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_676'
                                   1752 ;------------------------------------------------------------
                                   1753 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1754 ;	-----------------------------------------
                                   1755 ;	 function vial_keycode_up
                                   1756 ;	-----------------------------------------
      00B8ED                       1757 _vial_keycode_up:
      00B8ED 12 38 44         [24] 1758 	lcall	_ak820_outline_0109
      00B8F0 90 0D 11         [24] 1759 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B8F3 12 38 49         [24] 1760 	lcall	_ak820_outline_0110
                                   1761 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B8F6 90 0D 11         [24] 1762 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B8F9 12 37 C8         [24] 1763 	lcall	_ak820_outline_0009
      00B8FC 74 E0            [12] 1764 	mov	a,#0x100 - 0x20
      00B8FE 2D               [12] 1765 	add	a,r5
      00B8FF 50 19            [24] 1766 	jnc	00104$
      00B901 C3               [12] 1767 	clr	c
      00B902 74 FF            [12] 1768 	mov	a,#0xff
      00B904 9C               [12] 1769 	subb	a,r4
      00B905 74 4F            [12] 1770 	mov	a,#0x4f
      00B907 9D               [12] 1771 	subb	a,r5
      00B908 40 10            [24] 1772 	jc	00104$
                                   1773 ;	free result
                                   1774 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B90A 90 0D 11         [24] 1775 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B90D EE               [12] 1776 	mov	a,r6
      00B90E 12 38 59         [24] 1777 	lcall	_ak820_outline_0129
                                   1778 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B911 90 0D 11         [24] 1779 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B914 E0               [24] 1780 	movx	a,@dptr
      00B915 24 FE            [12] 1781 	add	a,#0xff - 0x01
      00B917 40 01            [24] 1782 	jc	00104$
                                   1783 ;	free result
      00B919 22               [24] 1784 	ret
      00B91A                       1785 00104$:
                                   1786 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B91A 90 0D 11         [24] 1787 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B91D 12 B9 7F         [24] 1788 	lcall	_ak820_outline_0026
                                   1789 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B920 40 06            [24] 1790 	jc	00107$
                                   1791 ;	free result
                                   1792 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B922 12 49 5D         [24] 1793 	lcall	_ak820_outline_0120
      00B925 02 A4 CB         [24] 1794 	ljmp	_unregister_code16
      00B928                       1795 00107$:
                                   1796 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B928 90 0D 17         [24] 1797 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0004)
      00B92B 74 01            [12] 1798 	mov	a,#0x01
      00B92D F0               [24] 1799 	movx	@dptr,a
      00B92E 90 0D 14         [24] 1800 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0001)
      00B931 74 F0            [12] 1801 	mov	a,#0xf0
      00B933 F0               [24] 1802 	movx	@dptr,a
      00B934 90 0D 13         [24] 1803 	mov	dptr,#_vial_keycode_up_dummy_event_30000_676
      00B937 F0               [24] 1804 	movx	@dptr,a
      00B938 90 0D 18         [24] 1805 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0005)
      00B93B E4               [12] 1806 	clr	a
      00B93C F0               [24] 1807 	movx	@dptr,a
      00B93D 12 4F 0D         [24] 1808 	lcall	_timer_read
      00B940 12 49 6E         [24] 1809 	lcall	_ak820_outline_0139
      00B943 43 06 01         [24] 1810 	orl	ar6,#0x01
      00B946 90 0D 15         [24] 1811 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0002)
      00B949 12 4E 7D         [24] 1812 	lcall	_ak820_outline_0064
                                   1813 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B94C 90 0D 13         [24] 1814 	mov	dptr,#_vial_keycode_up_dummy_event_30000_676
                                   1815 ;	quantum/vial.c:470: }
      00B94F 02 76 09         [24] 1816 	ljmp	_ak820_action_exec
                                   1817 ;------------------------------------------------------------
                                   1818 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1819 ;------------------------------------------------------------
                                   1820 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_677'
                                   1821 ;i             Allocated with name '_vial_keycode_tap_i_30000_680'
                                   1822 ;------------------------------------------------------------
                                   1823 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1824 ;	-----------------------------------------
                                   1825 ;	 function vial_keycode_tap
                                   1826 ;	-----------------------------------------
      00B952                       1827 _vial_keycode_tap:
      00B952 12 38 44         [24] 1828 	lcall	_ak820_outline_0109
      00B955 90 0D 19         [24] 1829 	mov	dptr,#_vial_keycode_tap_keycode_10000_677
      00B958 12 38 49         [24] 1830 	lcall	_ak820_outline_0110
                                   1831 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B95B 90 0D 19         [24] 1832 	mov	dptr,#_vial_keycode_tap_keycode_10000_677
      00B95E 12 37 BE         [24] 1833 	lcall	_ak820_outline_0007
      00B961 C0 07            [24] 1834 	push	ar7
      00B963 C0 06            [24] 1835 	push	ar6
      00B965 11 87            [12] 1836 	acall	_vial_keycode_down
      00B967 D0 06            [24] 1837 	pop	ar6
      00B969 D0 07            [24] 1838 	pop	ar7
                                   1839 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B96B 12 49 5D         [24] 1840 	lcall	_ak820_outline_0120
                                   1841 ;	quantum/vial.c:476: }
      00B96E 01 ED            [12] 1842 	ajmp	_vial_keycode_up
                                   1843 ;------------------------------------------------------------
                                   1844 ;Allocation info for local variables in function 'process_record_vial'
                                   1845 ;------------------------------------------------------------
                                   1846 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1847 ;keycode       Allocated with name '_process_record_vial_keycode_10000_682'
                                   1848 ;------------------------------------------------------------
                                   1849 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1850 ;	-----------------------------------------
                                   1851 	.area CSEG    (CODE)
                                   1852 	.area CONST   (CODE)
                                   1853 	.area CONST   (CODE)
      00C4C1                       1854 _keyboard_definition:
      00C4C1 FD                    1855 	.db #0xfd	; 253
      00C4C2 37                    1856 	.db #0x37	; 55	'7'
      00C4C3 7A                    1857 	.db #0x7a	; 122	'z'
      00C4C4 58                    1858 	.db #0x58	; 88	'X'
      00C4C5 5A                    1859 	.db #0x5a	; 90	'Z'
      00C4C6 00                    1860 	.db #0x00	; 0
      00C4C7 00                    1861 	.db #0x00	; 0
      00C4C8 04                    1862 	.db #0x04	; 4
      00C4C9 E6                    1863 	.db #0xe6	; 230
      00C4CA D6                    1864 	.db #0xd6	; 214
      00C4CB B4                    1865 	.db #0xb4	; 180
      00C4CC 46                    1866 	.db #0x46	; 70	'F'
      00C4CD 02                    1867 	.db #0x02	; 2
      00C4CE 00                    1868 	.db #0x00	; 0
      00C4CF 21                    1869 	.db #0x21	; 33
      00C4D0 01                    1870 	.db #0x01	; 1
      00C4D1 00                    1871 	.db #0x00	; 0
      00C4D2 00                    1872 	.db #0x00	; 0
      00C4D3 00                    1873 	.db #0x00	; 0
      00C4D4 00                    1874 	.db #0x00	; 0
      00C4D5 37                    1875 	.db #0x37	; 55	'7'
      00C4D6 27                    1876 	.db #0x27	; 39
      00C4D7 97                    1877 	.db #0x97	; 151
      00C4D8 D6                    1878 	.db #0xd6	; 214
      00C4D9 E0                    1879 	.db #0xe0	; 224
      00C4DA 03                    1880 	.db #0x03	; 3
      00C4DB CB                    1881 	.db #0xcb	; 203
      00C4DC 01                    1882 	.db #0x01	; 1
      00C4DD 3C                    1883 	.db #0x3c	; 60
      00C4DE 00                    1884 	.db #0x00	; 0
      00C4DF 00                    1885 	.db #0x00	; 0
      00C4E0 3D                    1886 	.db #0x3d	; 61
      00C4E1 88                    1887 	.db #0x88	; 136
      00C4E2 CD                    1888 	.db #0xcd	; 205
      00C4E3 A5                    1889 	.db #0xa5	; 165
      00C4E4 AA                    1890 	.db #0xaa	; 170
      00C4E5 E5                    1891 	.db #0xe5	; 229
      00C4E6 A8                    1892 	.db #0xa8	; 168
      00C4E7 76                    1893 	.db #0x76	; 118	'v'
      00C4E8 F6                    1894 	.db #0xf6	; 246
      00C4E9 43                    1895 	.db #0x43	; 67	'C'
      00C4EA 0E                    1896 	.db #0x0e	; 14
      00C4EB D2                    1897 	.db #0xd2	; 210
      00C4EC 90                    1898 	.db #0x90	; 144
      00C4ED 7D                    1899 	.db #0x7d	; 125
      00C4EE 94                    1900 	.db #0x94	; 148
      00C4EF 79                    1901 	.db #0x79	; 121	'y'
      00C4F0 78                    1902 	.db #0x78	; 120	'x'
      00C4F1 EF                    1903 	.db #0xef	; 239
      00C4F2 49                    1904 	.db #0x49	; 73	'I'
      00C4F3 3E                    1905 	.db #0x3e	; 62
      00C4F4 EF                    1906 	.db #0xef	; 239
      00C4F5 FD                    1907 	.db #0xfd	; 253
      00C4F6 8F                    1908 	.db #0x8f	; 143
      00C4F7 EF                    1909 	.db #0xef	; 239
      00C4F8 00                    1910 	.db #0x00	; 0
      00C4F9 C6                    1911 	.db #0xc6	; 198
      00C4FA D1                    1912 	.db #0xd1	; 209
      00C4FB DB                    1913 	.db #0xdb	; 219
      00C4FC FB                    1914 	.db #0xfb	; 251
      00C4FD EB                    1915 	.db #0xeb	; 235
      00C4FE DE                    1916 	.db #0xde	; 222
      00C4FF 66                    1917 	.db #0x66	; 102	'f'
      00C500 63                    1918 	.db #0x63	; 99	'c'
      00C501 0C                    1919 	.db #0x0c	; 12
      00C502 92                    1920 	.db #0x92	; 146
      00C503 7B                    1921 	.db #0x7b	; 123
      00C504 F9                    1922 	.db #0xf9	; 249
      00C505 D4                    1923 	.db #0xd4	; 212
      00C506 7A                    1924 	.db #0x7a	; 122	'z'
      00C507 4F                    1925 	.db #0x4f	; 79	'O'
      00C508 83                    1926 	.db #0x83	; 131
      00C509 4B                    1927 	.db #0x4b	; 75	'K'
      00C50A 86                    1928 	.db #0x86	; 134
      00C50B 0E                    1929 	.db #0x0e	; 14
      00C50C 6A                    1930 	.db #0x6a	; 106	'j'
      00C50D F2                    1931 	.db #0xf2	; 242
      00C50E 22                    1932 	.db #0x22	; 34
      00C50F 22                    1933 	.db #0x22	; 34
      00C510 0B                    1934 	.db #0x0b	; 11
      00C511 03                    1935 	.db #0x03	; 3
      00C512 BA                    1936 	.db #0xba	; 186
      00C513 67                    1937 	.db #0x67	; 103	'g'
      00C514 9B                    1938 	.db #0x9b	; 155
      00C515 7A                    1939 	.db #0x7a	; 122	'z'
      00C516 E1                    1940 	.db #0xe1	; 225
      00C517 BC                    1941 	.db #0xbc	; 188
      00C518 37                    1942 	.db #0x37	; 55	'7'
      00C519 26                    1943 	.db #0x26	; 38
      00C51A 46                    1944 	.db #0x46	; 70	'F'
      00C51B 78                    1945 	.db #0x78	; 120	'x'
      00C51C 05                    1946 	.db #0x05	; 5
      00C51D 0D                    1947 	.db #0x0d	; 13
      00C51E 95                    1948 	.db #0x95	; 149
      00C51F 02                    1949 	.db #0x02	; 2
      00C520 E4                    1950 	.db #0xe4	; 228
      00C521 18                    1951 	.db #0x18	; 24
      00C522 CA                    1952 	.db #0xca	; 202
      00C523 33                    1953 	.db #0x33	; 51	'3'
      00C524 EA                    1954 	.db #0xea	; 234
      00C525 24                    1955 	.db #0x24	; 36
      00C526 C8                    1956 	.db #0xc8	; 200
      00C527 81                    1957 	.db #0x81	; 129
      00C528 4E                    1958 	.db #0x4e	; 78	'N'
      00C529 47                    1959 	.db #0x47	; 71	'G'
      00C52A A8                    1960 	.db #0xa8	; 168
      00C52B 44                    1961 	.db #0x44	; 68	'D'
      00C52C DD                    1962 	.db #0xdd	; 221
      00C52D 91                    1963 	.db #0x91	; 145
      00C52E 6D                    1964 	.db #0x6d	; 109	'm'
      00C52F 69                    1965 	.db #0x69	; 105	'i'
      00C530 DB                    1966 	.db #0xdb	; 219
      00C531 4F                    1967 	.db #0x4f	; 79	'O'
      00C532 3A                    1968 	.db #0x3a	; 58
      00C533 43                    1969 	.db #0x43	; 67	'C'
      00C534 9D                    1970 	.db #0x9d	; 157
      00C535 26                    1971 	.db #0x26	; 38
      00C536 49                    1972 	.db #0x49	; 73	'I'
      00C537 4C                    1973 	.db #0x4c	; 76	'L'
      00C538 EF                    1974 	.db #0xef	; 239
      00C539 2B                    1975 	.db #0x2b	; 43
      00C53A D8                    1976 	.db #0xd8	; 216
      00C53B 55                    1977 	.db #0x55	; 85	'U'
      00C53C 95                    1978 	.db #0x95	; 149
      00C53D 70                    1979 	.db #0x70	; 112	'p'
      00C53E B1                    1980 	.db #0xb1	; 177
      00C53F CC                    1981 	.db #0xcc	; 204
      00C540 CF                    1982 	.db #0xcf	; 207
      00C541 13                    1983 	.db #0x13	; 19
      00C542 32                    1984 	.db #0x32	; 50	'2'
      00C543 6A                    1985 	.db #0x6a	; 106	'j'
      00C544 A1                    1986 	.db #0xa1	; 161
      00C545 FF                    1987 	.db #0xff	; 255
      00C546 99                    1988 	.db #0x99	; 153
      00C547 61                    1989 	.db #0x61	; 97	'a'
      00C548 95                    1990 	.db #0x95	; 149
      00C549 B1                    1991 	.db #0xb1	; 177
      00C54A 89                    1992 	.db #0x89	; 137
      00C54B 9B                    1993 	.db #0x9b	; 155
      00C54C 11                    1994 	.db #0x11	; 17
      00C54D D9                    1995 	.db #0xd9	; 217
      00C54E 35                    1996 	.db #0x35	; 53	'5'
      00C54F 78                    1997 	.db #0x78	; 120	'x'
      00C550 ED                    1998 	.db #0xed	; 237
      00C551 CD                    1999 	.db #0xcd	; 205
      00C552 94                    2000 	.db #0x94	; 148
      00C553 6E                    2001 	.db #0x6e	; 110	'n'
      00C554 60                    2002 	.db #0x60	; 96
      00C555 8E                    2003 	.db #0x8e	; 142
      00C556 63                    2004 	.db #0x63	; 99	'c'
      00C557 8B                    2005 	.db #0x8b	; 139
      00C558 FF                    2006 	.db #0xff	; 255
      00C559 4E                    2007 	.db #0x4e	; 78	'N'
      00C55A 20                    2008 	.db #0x20	; 32
      00C55B 7A                    2009 	.db #0x7a	; 122	'z'
      00C55C B5                    2010 	.db #0xb5	; 181
      00C55D 87                    2011 	.db #0x87	; 135
      00C55E C2                    2012 	.db #0xc2	; 194
      00C55F 35                    2013 	.db #0x35	; 53	'5'
      00C560 A4                    2014 	.db #0xa4	; 164
      00C561 6D                    2015 	.db #0x6d	; 109	'm'
      00C562 18                    2016 	.db #0x18	; 24
      00C563 C1                    2017 	.db #0xc1	; 193
      00C564 A3                    2018 	.db #0xa3	; 163
      00C565 DB                    2019 	.db #0xdb	; 219
      00C566 53                    2020 	.db #0x53	; 83	'S'
      00C567 1D                    2021 	.db #0x1d	; 29
      00C568 EC                    2022 	.db #0xec	; 236
      00C569 F0                    2023 	.db #0xf0	; 240
      00C56A BF                    2024 	.db #0xbf	; 191
      00C56B 4A                    2025 	.db #0x4a	; 74	'J'
      00C56C 4C                    2026 	.db #0x4c	; 76	'L'
      00C56D 4A                    2027 	.db #0x4a	; 74	'J'
      00C56E C4                    2028 	.db #0xc4	; 196
      00C56F AA                    2029 	.db #0xaa	; 170
      00C570 37                    2030 	.db #0x37	; 55	'7'
      00C571 19                    2031 	.db #0x19	; 25
      00C572 34                    2032 	.db #0x34	; 52	'4'
      00C573 3F                    2033 	.db #0x3f	; 63
      00C574 A1                    2034 	.db #0xa1	; 161
      00C575 D3                    2035 	.db #0xd3	; 211
      00C576 1A                    2036 	.db #0x1a	; 26
      00C577 5C                    2037 	.db #0x5c	; 92
      00C578 03                    2038 	.db #0x03	; 3
      00C579 4D                    2039 	.db #0x4d	; 77	'M'
      00C57A BC                    2040 	.db #0xbc	; 188
      00C57B 10                    2041 	.db #0x10	; 16
      00C57C 2E                    2042 	.db #0x2e	; 46
      00C57D 80                    2043 	.db #0x80	; 128
      00C57E F7                    2044 	.db #0xf7	; 247
      00C57F D6                    2045 	.db #0xd6	; 214
      00C580 82                    2046 	.db #0x82	; 130
      00C581 24                    2047 	.db #0x24	; 36
      00C582 4C                    2048 	.db #0x4c	; 76	'L'
      00C583 87                    2049 	.db #0x87	; 135
      00C584 B9                    2050 	.db #0xb9	; 185
      00C585 F8                    2051 	.db #0xf8	; 248
      00C586 BE                    2052 	.db #0xbe	; 190
      00C587 67                    2053 	.db #0x67	; 103	'g'
      00C588 96                    2054 	.db #0x96	; 150
      00C589 89                    2055 	.db #0x89	; 137
      00C58A 30                    2056 	.db #0x30	; 48	'0'
      00C58B C8                    2057 	.db #0xc8	; 200
      00C58C 8D                    2058 	.db #0x8d	; 141
      00C58D 2C                    2059 	.db #0x2c	; 44
      00C58E F5                    2060 	.db #0xf5	; 245
      00C58F 06                    2061 	.db #0x06	; 6
      00C590 05                    2062 	.db #0x05	; 5
      00C591 7C                    2063 	.db #0x7c	; 124
      00C592 48                    2064 	.db #0x48	; 72	'H'
      00C593 1B                    2065 	.db #0x1b	; 27
      00C594 76                    2066 	.db #0x76	; 118	'v'
      00C595 AA                    2067 	.db #0xaa	; 170
      00C596 3D                    2068 	.db #0x3d	; 61
      00C597 28                    2069 	.db #0x28	; 40
      00C598 FC                    2070 	.db #0xfc	; 252
      00C599 80                    2071 	.db #0x80	; 128
      00C59A 75                    2072 	.db #0x75	; 117	'u'
      00C59B EB                    2073 	.db #0xeb	; 235
      00C59C 78                    2074 	.db #0x78	; 120	'x'
      00C59D D0                    2075 	.db #0xd0	; 208
      00C59E 8A                    2076 	.db #0x8a	; 138
      00C59F 8F                    2077 	.db #0x8f	; 143
      00C5A0 27                    2078 	.db #0x27	; 39
      00C5A1 F7                    2079 	.db #0xf7	; 247
      00C5A2 F2                    2080 	.db #0xf2	; 242
      00C5A3 EB                    2081 	.db #0xeb	; 235
      00C5A4 58                    2082 	.db #0x58	; 88	'X'
      00C5A5 37                    2083 	.db #0x37	; 55	'7'
      00C5A6 3C                    2084 	.db #0x3c	; 60
      00C5A7 2B                    2085 	.db #0x2b	; 43
      00C5A8 6F                    2086 	.db #0x6f	; 111	'o'
      00C5A9 0E                    2087 	.db #0x0e	; 14
      00C5AA C7                    2088 	.db #0xc7	; 199
      00C5AB E2                    2089 	.db #0xe2	; 226
      00C5AC A0                    2090 	.db #0xa0	; 160
      00C5AD 97                    2091 	.db #0x97	; 151
      00C5AE EE                    2092 	.db #0xee	; 238
      00C5AF FD                    2093 	.db #0xfd	; 253
      00C5B0 9F                    2094 	.db #0x9f	; 159
      00C5B1 45                    2095 	.db #0x45	; 69	'E'
      00C5B2 17                    2096 	.db #0x17	; 23
      00C5B3 94                    2097 	.db #0x94	; 148
      00C5B4 E6                    2098 	.db #0xe6	; 230
      00C5B5 E7                    2099 	.db #0xe7	; 231
      00C5B6 FA                    2100 	.db #0xfa	; 250
      00C5B7 4C                    2101 	.db #0x4c	; 76	'L'
      00C5B8 7A                    2102 	.db #0x7a	; 122	'z'
      00C5B9 D6                    2103 	.db #0xd6	; 214
      00C5BA 7A                    2104 	.db #0x7a	; 122	'z'
      00C5BB 7B                    2105 	.db #0x7b	; 123
      00C5BC ED                    2106 	.db #0xed	; 237
      00C5BD 10                    2107 	.db #0x10	; 16
      00C5BE C5                    2108 	.db #0xc5	; 197
      00C5BF BC                    2109 	.db #0xbc	; 188
      00C5C0 E3                    2110 	.db #0xe3	; 227
      00C5C1 A9                    2111 	.db #0xa9	; 169
      00C5C2 1F                    2112 	.db #0x1f	; 31
      00C5C3 CF                    2113 	.db #0xcf	; 207
      00C5C4 C4                    2114 	.db #0xc4	; 196
      00C5C5 9D                    2115 	.db #0x9d	; 157
      00C5C6 DC                    2116 	.db #0xdc	; 220
      00C5C7 45                    2117 	.db #0x45	; 69	'E'
      00C5C8 2A                    2118 	.db #0x2a	; 42
      00C5C9 69                    2119 	.db #0x69	; 105	'i'
      00C5CA 57                    2120 	.db #0x57	; 87	'W'
      00C5CB 8F                    2121 	.db #0x8f	; 143
      00C5CC EC                    2122 	.db #0xec	; 236
      00C5CD 85                    2123 	.db #0x85	; 133
      00C5CE 6C                    2124 	.db #0x6c	; 108	'l'
      00C5CF 43                    2125 	.db #0x43	; 67	'C'
      00C5D0 1C                    2126 	.db #0x1c	; 28
      00C5D1 BA                    2127 	.db #0xba	; 186
      00C5D2 89                    2128 	.db #0x89	; 137
      00C5D3 68                    2129 	.db #0x68	; 104	'h'
      00C5D4 4A                    2130 	.db #0x4a	; 74	'J'
      00C5D5 1C                    2131 	.db #0x1c	; 28
      00C5D6 91                    2132 	.db #0x91	; 145
      00C5D7 3F                    2133 	.db #0x3f	; 63
      00C5D8 D1                    2134 	.db #0xd1	; 209
      00C5D9 B3                    2135 	.db #0xb3	; 179
      00C5DA 96                    2136 	.db #0x96	; 150
      00C5DB 1D                    2137 	.db #0x1d	; 29
      00C5DC 7C                    2138 	.db #0x7c	; 124
      00C5DD 14                    2139 	.db #0x14	; 20
      00C5DE 77                    2140 	.db #0x77	; 119	'w'
      00C5DF 9C                    2141 	.db #0x9c	; 156
      00C5E0 74                    2142 	.db #0x74	; 116	't'
      00C5E1 36                    2143 	.db #0x36	; 54	'6'
      00C5E2 FF                    2144 	.db #0xff	; 255
      00C5E3 2C                    2145 	.db #0x2c	; 44
      00C5E4 66                    2146 	.db #0x66	; 102	'f'
      00C5E5 AF                    2147 	.db #0xaf	; 175
      00C5E6 0F                    2148 	.db #0x0f	; 15
      00C5E7 3C                    2149 	.db #0x3c	; 60
      00C5E8 A2                    2150 	.db #0xa2	; 162
      00C5E9 23                    2151 	.db #0x23	; 35
      00C5EA 85                    2152 	.db #0x85	; 133
      00C5EB 05                    2153 	.db #0x05	; 5
      00C5EC 87                    2154 	.db #0x87	; 135
      00C5ED DA                    2155 	.db #0xda	; 218
      00C5EE 61                    2156 	.db #0x61	; 97	'a'
      00C5EF 5E                    2157 	.db #0x5e	; 94
      00C5F0 42                    2158 	.db #0x42	; 66	'B'
      00C5F1 54                    2159 	.db #0x54	; 84	'T'
      00C5F2 60                    2160 	.db #0x60	; 96
      00C5F3 23                    2161 	.db #0x23	; 35
      00C5F4 CA                    2162 	.db #0xca	; 202
      00C5F5 BC                    2163 	.db #0xbc	; 188
      00C5F6 B3                    2164 	.db #0xb3	; 179
      00C5F7 18                    2165 	.db #0x18	; 24
      00C5F8 1D                    2166 	.db #0x1d	; 29
      00C5F9 F8                    2167 	.db #0xf8	; 248
      00C5FA 0A                    2168 	.db #0x0a	; 10
      00C5FB 55                    2169 	.db #0x55	; 85	'U'
      00C5FC CD                    2170 	.db #0xcd	; 205
      00C5FD A3                    2171 	.db #0xa3	; 163
      00C5FE DE                    2172 	.db #0xde	; 222
      00C5FF FF                    2173 	.db #0xff	; 255
      00C600 B2                    2174 	.db #0xb2	; 178
      00C601 2A                    2175 	.db #0x2a	; 42
      00C602 35                    2176 	.db #0x35	; 53	'5'
      00C603 00                    2177 	.db #0x00	; 0
      00C604 D6                    2178 	.db #0xd6	; 214
      00C605 7B                    2179 	.db #0x7b	; 123
      00C606 E8                    2180 	.db #0xe8	; 232
      00C607 F2                    2181 	.db #0xf2	; 242
      00C608 1A                    2182 	.db #0x1a	; 26
      00C609 BC                    2183 	.db #0xbc	; 188
      00C60A F5                    2184 	.db #0xf5	; 245
      00C60B 7E                    2185 	.db #0x7e	; 126
      00C60C 48                    2186 	.db #0x48	; 72	'H'
      00C60D 72                    2187 	.db #0x72	; 114	'r'
      00C60E E0                    2188 	.db #0xe0	; 224
      00C60F E4                    2189 	.db #0xe4	; 228
      00C610 E0                    2190 	.db #0xe0	; 224
      00C611 27                    2191 	.db #0x27	; 39
      00C612 87                    2192 	.db #0x87	; 135
      00C613 9A                    2193 	.db #0x9a	; 154
      00C614 51                    2194 	.db #0x51	; 81	'Q'
      00C615 D4                    2195 	.db #0xd4	; 212
      00C616 DD                    2196 	.db #0xdd	; 221
      00C617 C3                    2197 	.db #0xc3	; 195
      00C618 AA                    2198 	.db #0xaa	; 170
      00C619 49                    2199 	.db #0x49	; 73	'I'
      00C61A 5A                    2200 	.db #0x5a	; 90	'Z'
      00C61B 2A                    2201 	.db #0x2a	; 42
      00C61C 00                    2202 	.db #0x00	; 0
      00C61D A0                    2203 	.db #0xa0	; 160
      00C61E 8C                    2204 	.db #0x8c	; 140
      00C61F FF                    2205 	.db #0xff	; 255
      00C620 74                    2206 	.db #0x74	; 116	't'
      00C621 BF                    2207 	.db #0xbf	; 191
      00C622 EC                    2208 	.db #0xec	; 236
      00C623 1D                    2209 	.db #0x1d	; 29
      00C624 F1                    2210 	.db #0xf1	; 241
      00C625 00                    2211 	.db #0x00	; 0
      00C626 01                    2212 	.db #0x01	; 1
      00C627 D8                    2213 	.db #0xd8	; 216
      00C628 02                    2214 	.db #0x02	; 2
      00C629 CC                    2215 	.db #0xcc	; 204
      00C62A 07                    2216 	.db #0x07	; 7
      00C62B 00                    2217 	.db #0x00	; 0
      00C62C 00                    2218 	.db #0x00	; 0
      00C62D C4                    2219 	.db #0xc4	; 196
      00C62E 5E                    2220 	.db #0x5e	; 94
      00C62F 2C                    2221 	.db #0x2c	; 44
      00C630 7E                    2222 	.db #0x7e	; 126
      00C631 B1                    2223 	.db #0xb1	; 177
      00C632 C4                    2224 	.db #0xc4	; 196
      00C633 67                    2225 	.db #0x67	; 103	'g'
      00C634 FB                    2226 	.db #0xfb	; 251
      00C635 02                    2227 	.db #0x02	; 2
      00C636 00                    2228 	.db #0x00	; 0
      00C637 00                    2229 	.db #0x00	; 0
      00C638 00                    2230 	.db #0x00	; 0
      00C639 00                    2231 	.db #0x00	; 0
      00C63A 04                    2232 	.db #0x04	; 4
      00C63B 59                    2233 	.db #0x59	; 89	'Y'
      00C63C 5A                    2234 	.db #0x5a	; 90	'Z'
                                   2235 	.area CSEG    (CODE)
                                   2236 	.area CONST   (CODE)
      00C63D                       2237 _vial_handle_cmd_keyboard_uid_40000_632:
      00C63D 04                    2238 	.db #0x04	; 4
      00C63E 70                    2239 	.db #0x70	; 112	'p'
      00C63F FF                    2240 	.db #0xff	; 255
      00C640 90                    2241 	.db #0x90	; 144
      00C641 01                    2242 	.db #0x01	; 1
      00C642 B9                    2243 	.db #0xb9	; 185
      00C643 15                    2244 	.db #0x15	; 21
      00C644 D3                    2245 	.db #0xd3	; 211
                                   2246 	.area CSEG    (CODE)
                                   2247 	.area XINIT   (CODE)
      00C876                       2248 __xinit__vial_unlocked:
      00C876 00                    2249 	.db #0x00	;  0
      00C877                       2250 __xinit__vial_unlock_in_progress:
      00C877 00                    2251 	.db #0x00	;  0
      00C878                       2252 __xinit__vial_unlock_counter:
      00C878 00                    2253 	.db #0x00	; 0
      00C879                       2254 __xinit__vial_unlock_combo_rows:
      00C879 00                    2255 	.db #0x00	; 0
      00C87A 00                    2256 	.db #0x00	; 0
      00C87B                       2257 __xinit__vial_unlock_combo_cols:
      00C87B 00                    2258 	.db #0x00	; 0
      00C87C 05                    2259 	.db #0x05	; 5
                                   2260 	.area CABS    (ABS,CODE)
                                   2261 
                                   2262 ; Experimental exact instruction outlining.
                                   2263 	.globl _ak820_outline_0007
                                   2264 	.globl _ak820_outline_0008
                                   2265 	.globl _ak820_outline_0009
                                   2266 	.globl _ak820_outline_0010
                                   2267 	.globl _ak820_outline_0011
                                   2268 	.globl _ak820_outline_0012
                                   2269 	.globl _ak820_outline_0013
                                   2270 	.globl _ak820_outline_0016
                                   2271 	.globl _ak820_outline_0018
                                   2272 	.globl _ak820_outline_0020
                                   2273 	.globl _ak820_outline_0025
                                   2274 	.globl _ak820_outline_0026
                                   2275 	.globl _ak820_outline_0033
                                   2276 	.globl _ak820_outline_0034
                                   2277 	.globl _ak820_outline_0038
                                   2278 	.globl _ak820_outline_0051
                                   2279 	.globl _ak820_outline_0056
                                   2280 	.globl _ak820_outline_0059
                                   2281 	.globl _ak820_outline_0061
                                   2282 	.globl _ak820_outline_0063
                                   2283 	.globl _ak820_outline_0064
                                   2284 	.globl _ak820_outline_0074
                                   2285 	.globl _ak820_outline_0109
                                   2286 	.globl _ak820_outline_0110
                                   2287 	.globl _ak820_outline_0120
                                   2288 	.globl _ak820_outline_0124
                                   2289 	.globl _ak820_outline_0128
                                   2290 	.globl _ak820_outline_0129
                                   2291 	.globl _ak820_outline_0131
                                   2292 	.globl _ak820_outline_0132
                                   2293 	.globl _ak820_outline_0139
                                   2294 	.globl _ak820_outline_0142
                                   2295 	.globl _ak820_outline_0143
                                   2296 	.globl _ak820_outline_0148
                                   2297 	.globl _ak820_outline_0154
                                   2298 	.globl _ak820_outline_0162
                                   2299 	.globl _ak820_outline_0163
                                   2300 	.globl _ak820_outline_0196
                                   2301 
                                   2302 	.area CSEG (CODE)
                                   2303 ; function ak820_outline_0010
      00B970                       2304 _ak820_outline_0010:
      00B970 A3               [24] 2305 	inc	dptr
      00B971 F0               [24] 2306 	movx	@dptr,a
      00B972 E4               [12] 2307 	clr	a
      00B973 A3               [24] 2308 	inc	dptr
      00B974 F0               [24] 2309 	movx	@dptr,a
      00B975 90 0E 32         [24] 2310 	mov	dptr,#___memcpy_PARM_3
      00B978 74 0A            [12] 2311 	mov	a,#0x0a
      00B97A F0               [24] 2312 	movx	@dptr,a
      00B97B E4               [12] 2313 	clr	a
      00B97C A3               [24] 2314 	inc	dptr
      00B97D F0               [24] 2315 	movx	@dptr,a
      00B97E 22               [24] 2316 	ret
                                   2317 
                                   2318 	.area CSEG (CODE)
                                   2319 ; function ak820_outline_0026
      00B97F                       2320 _ak820_outline_0026:
      00B97F E0               [24] 2321 	movx	a,@dptr
      00B980 FE               [12] 2322 	mov	r6,a
      00B981 A3               [24] 2323 	inc	dptr
      00B982 E0               [24] 2324 	movx	a,@dptr
      00B983 FF               [12] 2325 	mov	r7,a
      00B984 90 0D 07         [24] 2326 	mov	dptr,#_g_vial_magic_keycode_override
      00B987 EE               [12] 2327 	mov	a,r6
      00B988 F0               [24] 2328 	movx	@dptr,a
      00B989 EF               [12] 2329 	mov	a,r7
      00B98A A3               [24] 2330 	inc	dptr
      00B98B F0               [24] 2331 	movx	@dptr,a
      00B98C 8E 04            [24] 2332 	mov	ar4,r6
      00B98E 8F 05            [24] 2333 	mov	ar5,r7
      00B990 C3               [12] 2334 	clr	c
      00B991 74 FF            [12] 2335 	mov	a,#0xff
      00B993 9C               [12] 2336 	subb	a,r4
      00B994 74 1F            [12] 2337 	mov	a,#0x1f
      00B996 9D               [12] 2338 	subb	a,r5
      00B997 22               [24] 2339 	ret
                                   2340 
                                   2341 	.area CSEG (CODE)
                                   2342 ; function ak820_outline_0131
      00B998                       2343 _ak820_outline_0131:
      00B998 24 B7            [12] 2344 	add	a,#_vial_unlock_combo_cols
      00B99A F5 82            [12] 2345 	mov	dpl,a
      00B99C E4               [12] 2346 	clr	a
      00B99D 34 0E            [12] 2347 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B99F F5 83            [12] 2348 	mov	dph,a
      00B9A1 E0               [24] 2349 	movx	a,@dptr
      00B9A2 22               [24] 2350 	ret
                                   2351 
                                   2352 	.area CSEG (CODE)
                                   2353 ; function ak820_outline_0132
      00B9A3                       2354 _ak820_outline_0132:
      00B9A3 24 B5            [12] 2355 	add	a,#_vial_unlock_combo_rows
      00B9A5 F5 82            [12] 2356 	mov	dpl,a
      00B9A7 E4               [12] 2357 	clr	a
      00B9A8 34 0E            [12] 2358 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B9AA F5 83            [12] 2359 	mov	dph,a
      00B9AC E0               [24] 2360 	movx	a,@dptr
      00B9AD 22               [24] 2361 	ret
