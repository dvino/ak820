                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_key_override_valid
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_write_block_xdata
                                     16 	.globl _ak820_eeprom_read_block_xdata
                                     17 	.globl _ak820_nvm_flush
                                     18 	.globl _ak820_nvm_ok
                                     19 	.globl _ak820_macro_reset
                                     20 	.globl _ak820_macro_write
                                     21 	.globl _ak820_macro_length
                                     22 	.globl _ak820_macro_ready
                                     23 	.globl _send_char
                                     24 	.globl _keycode_at_encodermap_location_raw
                                     25 	.globl _keycode_at_keymap_location_raw
                                     26 	.globl _vial_keycode_tap
                                     27 	.globl _vial_keycode_up
                                     28 	.globl _vial_keycode_down
                                     29 	.globl _clear_keyboard
                                     30 	.globl _tap_code
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _mDelaymS
                                     34 	.globl ___memcpy
                                     35 	.globl _memset
                                     36 	.globl _eeprom_update_byte
                                     37 	.globl _eeprom_read_byte
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    284 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    285 	.globl _keycode_at_encodermap_location_PARM_3
                                    286 	.globl _keycode_at_encodermap_location_PARM_2
                                    287 	.globl _keycode_at_keymap_location_PARM_3
                                    288 	.globl _keycode_at_keymap_location_PARM_2
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    292 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    293 	.globl _dynamic_keymap_set_key_override_PARM_2
                                    294 	.globl _dynamic_keymap_get_key_override_PARM_2
                                    295 	.globl _dynamic_keymap_set_combo_PARM_2
                                    296 	.globl _dynamic_keymap_get_combo_PARM_2
                                    297 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    298 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    299 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    300 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    301 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    302 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    303 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    304 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    305 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    306 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    307 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    309 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    310 	.globl _dynamic_keymap_get_layer_count
                                    311 	.globl _dynamic_keymap_key_to_eeprom_address
                                    312 	.globl _dynamic_keymap_get_keycode
                                    313 	.globl _dynamic_keymap_set_keycode
                                    314 	.globl _dynamic_keymap_get_encoder
                                    315 	.globl _dynamic_keymap_set_encoder
                                    316 	.globl _dynamic_keymap_get_combo
                                    317 	.globl _dynamic_keymap_set_combo
                                    318 	.globl _dynamic_keymap_get_key_override
                                    319 	.globl _dynamic_keymap_set_key_override
                                    320 	.globl _dynamic_keymap_reset
                                    321 	.globl _dynamic_keymap_get_buffer
                                    322 	.globl _dynamic_keymap_set_buffer
                                    323 	.globl _keycode_at_keymap_location
                                    324 	.globl _keycode_at_encodermap_location
                                    325 	.globl _dynamic_keymap_macro_get_count
                                    326 	.globl _dynamic_keymap_macro_get_buffer_size
                                    327 	.globl _dynamic_keymap_macro_get_buffer
                                    328 	.globl _dynamic_keymap_macro_set_buffer
                                    329 	.globl _dynamic_keymap_macro_reset
                                    330 	.globl _dynamic_keymap_macro_send
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000032                        593 _dynamic_keymap_set_encoder_sloc0_1_0:
      000032                        594 	.ds 2
      000034                        595 _dynamic_keymap_get_combo_sloc0_1_0:
      000034                        596 	.ds 1
      000035                        597 _ak820_dynamic_read_buffer_sloc0_1_0:
      000035                        598 	.ds 1
      000036                        599 _dynamic_keymap_set_buffer_sloc0_1_0:
      000036                        600 	.ds 2
      000038                        601 _dynamic_keymap_set_buffer_sloc1_1_0:
      000038                        602 	.ds 2
      00003A                        603 _dynamic_keymap_set_buffer_sloc2_1_0:
      00003A                        604 	.ds 1
      00003B                        605 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      00003B                        606 	.ds 2
                                    607 ;--------------------------------------------------------
                                    608 ; overlayable items in internal ram
                                    609 ;--------------------------------------------------------
                                    610 ;--------------------------------------------------------
                                    611 ; indirectly addressable internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area ISEG    (DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; absolute internal ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area IABS    (ABS,DATA)
                                    618 	.area IABS    (ABS,DATA)
                                    619 ;--------------------------------------------------------
                                    620 ; bit data
                                    621 ;--------------------------------------------------------
                                    622 	.area BSEG    (BIT)
      000025                        623 _dynamic_keymap_macro_send_sloc0_1_0:
      000025                        624 	.ds 1
                                    625 ;--------------------------------------------------------
                                    626 ; paged external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area PSEG    (PAG,XDATA)
                                    629 ;--------------------------------------------------------
                                    630 ; uninitialized external ram data
                                    631 ;--------------------------------------------------------
                                    632 	.area XSEG    (XDATA)
      000B5E                        633 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B5E                        634 	.ds 1
      000B5F                        635 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B5F                        636 	.ds 1
      000B60                        637 _dynamic_keymap_key_to_eeprom_address_layer_10000_374:
      000B60                        638 	.ds 1
      000B61                        639 _dynamic_keymap_get_keycode_PARM_2:
      000B61                        640 	.ds 1
      000B62                        641 _dynamic_keymap_get_keycode_PARM_3:
      000B62                        642 	.ds 1
      000B63                        643 _dynamic_keymap_get_keycode_layer_10000_376:
      000B63                        644 	.ds 1
      000B64                        645 _dynamic_keymap_set_keycode_PARM_2:
      000B64                        646 	.ds 1
      000B65                        647 _dynamic_keymap_set_keycode_PARM_3:
      000B65                        648 	.ds 1
      000B66                        649 _dynamic_keymap_set_keycode_PARM_4:
      000B66                        650 	.ds 2
      000B68                        651 _dynamic_keymap_set_keycode_layer_10000_380:
      000B68                        652 	.ds 1
      000B69                        653 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B69                        654 	.ds 1
      000B6A                        655 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_384:
      000B6A                        656 	.ds 1
      000B6B                        657 _dynamic_keymap_get_encoder_PARM_2:
      000B6B                        658 	.ds 1
      000B6C                        659 _dynamic_keymap_get_encoder_PARM_3:
      000B6C                        660 	.ds 1
      000B6D                        661 _dynamic_keymap_get_encoder_layer_10000_386:
      000B6D                        662 	.ds 1
      000B6E                        663 _dynamic_keymap_set_encoder_PARM_2:
      000B6E                        664 	.ds 1
      000B6F                        665 _dynamic_keymap_set_encoder_PARM_3:
      000B6F                        666 	.ds 1
      000B70                        667 _dynamic_keymap_set_encoder_PARM_4:
      000B70                        668 	.ds 2
      000B72                        669 _dynamic_keymap_set_encoder_layer_10000_390:
      000B72                        670 	.ds 1
      000B73                        671 _dynamic_keymap_get_combo_PARM_2:
      000B73                        672 	.ds 3
      000B76                        673 _dynamic_keymap_get_combo_index_10000_394:
      000B76                        674 	.ds 1
      000B77                        675 _dynamic_keymap_set_combo_PARM_2:
      000B77                        676 	.ds 3
      000B7A                        677 _dynamic_keymap_set_combo_index_10000_400:
      000B7A                        678 	.ds 1
      000B7B                        679 _dynamic_keymap_set_combo_stored_10002_405:
      000B7B                        680 	.ds 10
      000B85                        681 _dynamic_keymap_get_key_override_PARM_2:
      000B85                        682 	.ds 3
      000B88                        683 _dynamic_keymap_get_key_override_index_10000_407:
      000B88                        684 	.ds 1
      000B89                        685 _dynamic_keymap_set_key_override_PARM_2:
      000B89                        686 	.ds 3
      000B8C                        687 _dynamic_keymap_set_key_override_index_10000_411:
      000B8C                        688 	.ds 1
      000B8D                        689 _dynamic_keymap_reset_vial_unlocked_prev_10000_415:
      000B8D                        690 	.ds 1
      000B8E                        691 _dynamic_keymap_reset_combo_10001_424:
      000B8E                        692 	.ds 10
      000B98                        693 _dynamic_keymap_reset_ko_10002_426:
      000B98                        694 	.ds 10
      000BA2                        695 _ak820_dynamic_read_buffer_PARM_2:
      000BA2                        696 	.ds 2
      000BA4                        697 _ak820_dynamic_read_buffer_PARM_3:
      000BA4                        698 	.ds 2
      000BA6                        699 _ak820_dynamic_read_buffer_PARM_4:
      000BA6                        700 	.ds 2
      000BA8                        701 _ak820_dynamic_read_buffer_PARM_5:
      000BA8                        702 	.ds 3
      000BAB                        703 _ak820_dynamic_read_buffer_base_10000_428:
      000BAB                        704 	.ds 2
      000BAD                        705 _ak820_dynamic_read_buffer_available_10000_429:
      000BAD                        706 	.ds 1
      000BAE                        707 _dynamic_keymap_get_buffer_PARM_2:
      000BAE                        708 	.ds 2
      000BB0                        709 _dynamic_keymap_get_buffer_PARM_3:
      000BB0                        710 	.ds 3
      000BB3                        711 _dynamic_keymap_get_buffer_offset_10000_435:
      000BB3                        712 	.ds 2
      000BB5                        713 _dynamic_keymap_set_buffer_PARM_2:
      000BB5                        714 	.ds 2
      000BB7                        715 _dynamic_keymap_set_buffer_PARM_3:
      000BB7                        716 	.ds 3
      000BBA                        717 _dynamic_keymap_set_buffer_offset_10000_437:
      000BBA                        718 	.ds 2
      000BBC                        719 _dynamic_keymap_set_buffer_chk_offset_30001_444:
      000BBC                        720 	.ds 1
      000BBD                        721 _dynamic_keymap_set_buffer_chk_sz_30001_444:
      000BBD                        722 	.ds 1
      000BBE                        723 _dynamic_keymap_set_buffer_i_40001_451:
      000BBE                        724 	.ds 1
      000BBF                        725 _keycode_at_keymap_location_PARM_2:
      000BBF                        726 	.ds 1
      000BC0                        727 _keycode_at_keymap_location_PARM_3:
      000BC0                        728 	.ds 1
      000BC1                        729 _keycode_at_keymap_location_layer_num_10000_455:
      000BC1                        730 	.ds 1
      000BC2                        731 _keycode_at_encodermap_location_PARM_2:
      000BC2                        732 	.ds 1
      000BC3                        733 _keycode_at_encodermap_location_PARM_3:
      000BC3                        734 	.ds 1
      000BC4                        735 _keycode_at_encodermap_location_layer_num_10000_459:
      000BC4                        736 	.ds 1
      000BC5                        737 _dynamic_keymap_macro_get_buffer_PARM_2:
      000BC5                        738 	.ds 2
      000BC7                        739 _dynamic_keymap_macro_get_buffer_PARM_3:
      000BC7                        740 	.ds 3
      000BCA                        741 _dynamic_keymap_macro_get_buffer_offset_10000_467:
      000BCA                        742 	.ds 2
      000BCC                        743 _dynamic_keymap_macro_set_buffer_PARM_2:
      000BCC                        744 	.ds 2
      000BCE                        745 _dynamic_keymap_macro_set_buffer_PARM_3:
      000BCE                        746 	.ds 3
      000BD1                        747 _dynamic_keymap_macro_set_buffer_offset_10000_469:
      000BD1                        748 	.ds 2
      000BD3                        749 _decode_keycode_kc_10000_473:
      000BD3                        750 	.ds 2
      000BD5                        751 _dynamic_keymap_macro_send_id_10000_476:
      000BD5                        752 	.ds 1
      000BD6                        753 _dynamic_keymap_macro_send_sending_10000_477:
      000BD6                        754 	.ds 1
      000BD7                        755 _dynamic_keymap_macro_send_p_10001_482:
      000BD7                        756 	.ds 2
      000BD9                        757 _dynamic_keymap_macro_send_data_10003_489:
      000BD9                        758 	.ds 4
                                    759 ;--------------------------------------------------------
                                    760 ; absolute external ram data
                                    761 ;--------------------------------------------------------
                                    762 	.area XABS    (ABS,XDATA)
                                    763 ;--------------------------------------------------------
                                    764 ; initialized external ram data
                                    765 ;--------------------------------------------------------
                                    766 	.area XISEG   (XDATA)
                                    767 	.area HOME    (CODE)
                                    768 	.area GSINIT0 (CODE)
                                    769 	.area GSINIT1 (CODE)
                                    770 	.area GSINIT2 (CODE)
                                    771 	.area GSINIT3 (CODE)
                                    772 	.area GSINIT4 (CODE)
                                    773 	.area GSINIT5 (CODE)
                                    774 	.area GSINIT  (CODE)
                                    775 	.area GSFINAL (CODE)
                                    776 	.area CSEG    (CODE)
                                    777 ;--------------------------------------------------------
                                    778 ; global & static initialisations
                                    779 ;--------------------------------------------------------
                                    780 	.area HOME    (CODE)
                                    781 	.area GSINIT  (CODE)
                                    782 	.area GSFINAL (CODE)
                                    783 	.area GSINIT  (CODE)
                                    784 ;--------------------------------------------------------
                                    785 ; Home
                                    786 ;--------------------------------------------------------
                                    787 	.area HOME    (CODE)
                                    788 	.area HOME    (CODE)
                                    789 ;--------------------------------------------------------
                                    790 ; code
                                    791 ;--------------------------------------------------------
                                    792 	.area CSEG    (CODE)
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    795 ;------------------------------------------------------------
                                    796 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_232'
                                    797 ;------------------------------------------------------------
                                    798 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    799 ;	-----------------------------------------
                           000007   800 	ar7 = 0x07
                           000006   801 	ar6 = 0x06
                           000005   802 	ar5 = 0x05
                           000004   803 	ar4 = 0x04
                           000003   804 	ar3 = 0x03
                           000002   805 	ar2 = 0x02
                           000001   806 	ar1 = 0x01
                           000000   807 	ar0 = 0x00
                                    808 ;	 function dynamic_keymap_get_layer_count
                                    809 ;	-----------------------------------------
      0089B3                        810 _dynamic_keymap_get_layer_count:
                                    811 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0089B3 75 82 06         [24]  812 	mov	dpl, #0x06
                                    813 ;	quantum/dynamic_keymap.c:201: }
      0089B6 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    817 ;------------------------------------------------------------
                                    818 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    819 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    820 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_374'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function dynamic_keymap_key_to_eeprom_address
                                    825 ;	-----------------------------------------
      0089B7                        826 _dynamic_keymap_key_to_eeprom_address:
      0089B7 E5 82            [12]  827 	mov	a,dpl
      0089B9 90 0B 60         [24]  828 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_374
      0089BC F0               [24]  829 	movx	@dptr,a
                                    830 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0089BD E0               [24]  831 	movx	a,@dptr
      0089BE FF               [12]  832 	mov	r7,a
      0089BF 7E 00            [12]  833 	mov	r6,#0x00
      0089C1 74 40            [12]  834 	mov	a,#0x40
      0089C3 12 49 73         [24]  835 	lcall	_ak820_outline_0141
      0089C6 7D 00            [12]  836 	mov	r5,#0x00
      0089C8 90 0B 5E         [24]  837 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0089CB E0               [24]  838 	movx	a,@dptr
      0089CC 75 F0 10         [24]  839 	mov	b,#0x10
      0089CF A4               [48]  840 	mul	ab
      0089D0 2E               [12]  841 	add	a, r6
      0089D1 FE               [12]  842 	mov	r6,a
      0089D2 EF               [12]  843 	mov	a,r7
      0089D3 35 F0            [12]  844 	addc	a, b
      0089D5 FF               [12]  845 	mov	r7,a
      0089D6 90 0B 5F         [24]  846 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0089D9 E0               [24]  847 	movx	a,@dptr
      0089DA 7C 00            [12]  848 	mov	r4,#0x00
      0089DC 25 E0            [12]  849 	add	a,acc
      0089DE FB               [12]  850 	mov	r3,a
      0089DF EC               [12]  851 	mov	a,r4
      0089E0 33               [12]  852 	rlc	a
      0089E1 FC               [12]  853 	mov	r4,a
      0089E2 EB               [12]  854 	mov	a,r3
      0089E3 2E               [12]  855 	add	a, r6
      0089E4 FE               [12]  856 	mov	r6,a
      0089E5 EC               [12]  857 	mov	a,r4
      0089E6 3F               [12]  858 	addc	a, r7
      0089E7 FF               [12]  859 	mov	r7,a
      0089E8 12 49 5D         [24]  860 	lcall	_ak820_outline_0120
      0089EB 8D F0            [24]  861 	mov	b, r5
                                    862 ;	quantum/dynamic_keymap.c:206: }
      0089ED 22               [24]  863 	ret
                                    864 ;------------------------------------------------------------
                                    865 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    866 ;------------------------------------------------------------
                                    867 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    868 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    869 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_376'
                                    870 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_379'
                                    871 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_379'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function dynamic_keymap_get_keycode
                                    876 ;	-----------------------------------------
      0089EE                        877 _dynamic_keymap_get_keycode:
      0089EE E5 82            [12]  878 	mov	a,dpl
      0089F0 90 0B 63         [24]  879 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_376
      0089F3 F0               [24]  880 	movx	@dptr,a
                                    881 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0089F4 E0               [24]  882 	movx	a,@dptr
      0089F5 FF               [12]  883 	mov	r7,a
      0089F6 BF 06 00         [24]  884 	cjne	r7,#0x06,00121$
      0089F9                        885 00121$:
      0089F9 50 14            [24]  886 	jnc	00101$
      0089FB 90 0B 61         [24]  887 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0089FE E0               [24]  888 	movx	a,@dptr
      0089FF FE               [12]  889 	mov	r6,a
      008A00 BE 10 00         [24]  890 	cjne	r6,#0x10,00123$
      008A03                        891 00123$:
      008A03 50 0A            [24]  892 	jnc	00101$
      008A05 90 0B 62         [24]  893 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008A08 E0               [24]  894 	movx	a,@dptr
      008A09 FD               [12]  895 	mov	r5,a
      008A0A BD 08 00         [24]  896 	cjne	r5,#0x08,00125$
      008A0D                        897 00125$:
      008A0D 40 04            [24]  898 	jc	00102$
      008A0F                        899 00101$:
      008A0F 90 00 00         [24]  900 	mov	dptr,#0x0000
      008A12 22               [24]  901 	ret
      008A13                        902 00102$:
                                    903 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008A13 12 95 A3         [24]  904 	lcall	_ak820_outline_0101
      008A16 31 B7            [12]  905 	acall	_dynamic_keymap_key_to_eeprom_address
                                    906 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008A18 12 95 B7         [24]  907 	lcall	_ak820_outline_0118
      008A1B 12 46 7B         [24]  908 	lcall	_eeprom_read_byte
      008A1E AB 82            [24]  909 	mov	r3,dpl
      008A20 7C 00            [12]  910 	mov	r4,#0x00
                                    911 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008A22 0D               [12]  912 	inc	r5
      008A23 BD 00 01         [24]  913 	cjne	r5,#0x00,00127$
      008A26 0E               [12]  914 	inc	r6
      008A27                        915 00127$:
      008A27 12 54 CB         [24]  916 	lcall	_ak820_outline_0049
      008A2A 12 46 7B         [24]  917 	lcall	_eeprom_read_byte
      008A2D AF 82            [24]  918 	mov	r7, dpl
      008A2F 7E 00            [12]  919 	mov	r6,#0x00
      008A31 EF               [12]  920 	mov	a,r7
      008A32 42 04            [12]  921 	orl	ar4,a
      008A34 EE               [12]  922 	mov	a,r6
      008A35 42 03            [12]  923 	orl	ar3,a
                                    924 ;	quantum/dynamic_keymap.c:214: return keycode;
      008A37 12 49 9F         [24]  925 	lcall	_ak820_outline_0189
                                    926 ;	quantum/dynamic_keymap.c:215: }
      008A3A 22               [24]  927 	ret
                                    928 ;------------------------------------------------------------
                                    929 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    930 ;------------------------------------------------------------
                                    931 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    932 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    933 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    934 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_380'
                                    935 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_383'
                                    936 ;------------------------------------------------------------
                                    937 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    938 ;	-----------------------------------------
                                    939 ;	 function dynamic_keymap_set_keycode
                                    940 ;	-----------------------------------------
      008A3B                        941 _dynamic_keymap_set_keycode:
      008A3B E5 82            [12]  942 	mov	a,dpl
      008A3D 90 0B 68         [24]  943 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_380
      008A40 F0               [24]  944 	movx	@dptr,a
                                    945 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008A41 E0               [24]  946 	movx	a,@dptr
      008A42 FF               [12]  947 	mov	r7,a
      008A43 BF 06 00         [24]  948 	cjne	r7,#0x06,00121$
      008A46                        949 00121$:
      008A46 50 14            [24]  950 	jnc	00101$
      008A48 90 0B 64         [24]  951 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008A4B E0               [24]  952 	movx	a,@dptr
      008A4C FE               [12]  953 	mov	r6,a
      008A4D BE 10 00         [24]  954 	cjne	r6,#0x10,00123$
      008A50                        955 00123$:
      008A50 50 0A            [24]  956 	jnc	00101$
      008A52 90 0B 65         [24]  957 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008A55 E0               [24]  958 	movx	a,@dptr
      008A56 FD               [12]  959 	mov	r5,a
      008A57 BD 08 00         [24]  960 	cjne	r5,#0x08,00125$
      008A5A                        961 00125$:
      008A5A 40 01            [24]  962 	jc	00102$
      008A5C                        963 00101$:
      008A5C 22               [24]  964 	ret
      008A5D                        965 00102$:
                                    966 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008A5D 12 95 A3         [24]  967 	lcall	_ak820_outline_0101
      008A60 31 B7            [12]  968 	acall	_dynamic_keymap_key_to_eeprom_address
      008A62 12 95 B7         [24]  969 	lcall	_ak820_outline_0118
                                    970 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008A65 90 0B 66         [24]  971 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008A68 E0               [24]  972 	movx	a,@dptr
      008A69 FB               [12]  973 	mov	r3,a
      008A6A A3               [24]  974 	inc	dptr
      008A6B E0               [24]  975 	movx	a,@dptr
      008A6C 90 07 03         [24]  976 	mov	dptr,#_eeprom_update_byte_PARM_2
      008A6F F0               [24]  977 	movx	@dptr,a
      008A70 12 54 CB         [24]  978 	lcall	_ak820_outline_0049
      008A73 12 53 B4         [24]  979 	lcall	_eeprom_update_byte
                                    980 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008A76 0D               [12]  981 	inc	r5
      008A77 BD 00 01         [24]  982 	cjne	r5,#0x00,00127$
      008A7A 0E               [12]  983 	inc	r6
      008A7B                        984 00127$:
      008A7B 90 07 03         [24]  985 	mov	dptr,#_eeprom_update_byte_PARM_2
      008A7E EB               [12]  986 	mov	a,r3
      008A7F F0               [24]  987 	movx	@dptr,a
      008A80 12 54 CB         [24]  988 	lcall	_ak820_outline_0049
                                    989 ;	quantum/dynamic_keymap.c:223: }
      008A83 02 53 B4         [24]  990 	ljmp	_eeprom_update_byte
                                    991 ;------------------------------------------------------------
                                    992 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    993 ;------------------------------------------------------------
                                    994 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    995 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_384'
                                    996 ;------------------------------------------------------------
                                    997 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    998 ;	-----------------------------------------
                                    999 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                   1000 ;	-----------------------------------------
      008A86                       1001 _dynamic_keymap_encoder_to_eeprom_address:
      008A86 E5 82            [12] 1002 	mov	a,dpl
      008A88 90 0B 6A         [24] 1003 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_384
      008A8B F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008A8C E0               [24] 1006 	movx	a,@dptr
      008A8D 75 F0 04         [24] 1007 	mov	b,#0x04
      008A90 A4               [48] 1008 	mul	ab
      008A91 24 40            [12] 1009 	add	a, #0x40
      008A93 FD               [12] 1010 	mov	r5,a
      008A94 74 06            [12] 1011 	mov	a,#0x06
      008A96 35 F0            [12] 1012 	addc	a, b
      008A98 FE               [12] 1013 	mov	r6,a
      008A99 7F 00            [12] 1014 	mov	r7,#0x00
      008A9B 90 0B 69         [24] 1015 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008A9E E0               [24] 1016 	movx	a,@dptr
      008A9F 75 F0 04         [24] 1017 	mov	b,#0x04
      008AA2 A4               [48] 1018 	mul	ab
      008AA3 2D               [12] 1019 	add	a, r5
      008AA4 FD               [12] 1020 	mov	r5,a
      008AA5 EE               [12] 1021 	mov	a,r6
      008AA6 35 F0            [12] 1022 	addc	a, b
      008AA8 FE               [12] 1023 	mov	r6,a
      008AA9 12 54 CB         [24] 1024 	lcall	_ak820_outline_0049
                                   1025 ;	quantum/dynamic_keymap.c:228: }
      008AAC 22               [24] 1026 	ret
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1029 ;------------------------------------------------------------
                                   1030 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1031 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1032 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_386'
                                   1033 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_389'
                                   1034 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_389'
                                   1035 ;------------------------------------------------------------
                                   1036 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1037 ;	-----------------------------------------
                                   1038 ;	 function dynamic_keymap_get_encoder
                                   1039 ;	-----------------------------------------
      008AAD                       1040 _dynamic_keymap_get_encoder:
      008AAD E5 82            [12] 1041 	mov	a,dpl
      008AAF 90 0B 6D         [24] 1042 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_386
      008AB2 F0               [24] 1043 	movx	@dptr,a
                                   1044 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008AB3 E0               [24] 1045 	movx	a,@dptr
      008AB4 FF               [12] 1046 	mov	r7,a
      008AB5 BF 06 00         [24] 1047 	cjne	r7,#0x06,00131$
      008AB8                       1048 00131$:
      008AB8 50 0A            [24] 1049 	jnc	00101$
      008ABA 90 0B 6B         [24] 1050 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008ABD E0               [24] 1051 	movx	a,@dptr
      008ABE FE               [12] 1052 	mov	r6,a
      008ABF BE 01 00         [24] 1053 	cjne	r6,#0x01,00133$
      008AC2                       1054 00133$:
      008AC2 40 04            [24] 1055 	jc	00102$
      008AC4                       1056 00101$:
      008AC4 90 00 00         [24] 1057 	mov	dptr,#0x0000
      008AC7 22               [24] 1058 	ret
      008AC8                       1059 00102$:
                                   1060 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008AC8 90 0B 69         [24] 1061 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008ACB E4               [12] 1062 	clr	a
      008ACC F0               [24] 1063 	movx	@dptr,a
      008ACD 8F 82            [24] 1064 	mov	dpl, r7
      008ACF 51 86            [12] 1065 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008AD1 12 95 B7         [24] 1066 	lcall	_ak820_outline_0118
                                   1067 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008AD4 90 0B 6C         [24] 1068 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008AD7 E0               [24] 1069 	movx	a,@dptr
      008AD8 FC               [12] 1070 	mov	r4,a
      008AD9 E0               [24] 1071 	movx	a,@dptr
      008ADA 60 04            [24] 1072 	jz	00106$
      008ADC 7B 00            [12] 1073 	mov	r3,#0x00
      008ADE 80 02            [24] 1074 	sjmp	00107$
      008AE0                       1075 00106$:
      008AE0 7B 02            [12] 1076 	mov	r3,#0x02
      008AE2                       1077 00107$:
      008AE2 EB               [12] 1078 	mov	a,r3
      008AE3 12 95 6C         [24] 1079 	lcall	_ak820_outline_0027
      008AE6 12 46 7B         [24] 1080 	lcall	_eeprom_read_byte
      008AE9 AA 82            [24] 1081 	mov	r2,dpl
      008AEB 7B 00            [12] 1082 	mov	r3,#0x00
                                   1083 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008AED EC               [12] 1084 	mov	a,r4
      008AEE 60 04            [24] 1085 	jz	00108$
      008AF0 7C 00            [12] 1086 	mov	r4,#0x00
      008AF2 80 02            [24] 1087 	sjmp	00109$
      008AF4                       1088 00108$:
      008AF4 7C 02            [12] 1089 	mov	r4,#0x02
      008AF6                       1090 00109$:
      008AF6 EC               [12] 1091 	mov	a,r4
      008AF7 12 38 73         [24] 1092 	lcall	_ak820_outline_0166
      008AFA 0D               [12] 1093 	inc	r5
      008AFB BD 00 01         [24] 1094 	cjne	r5,#0x00,00137$
      008AFE 0E               [12] 1095 	inc	r6
      008AFF                       1096 00137$:
      008AFF 12 54 CB         [24] 1097 	lcall	_ak820_outline_0049
      008B02 12 46 7B         [24] 1098 	lcall	_eeprom_read_byte
      008B05 AF 82            [24] 1099 	mov	r7, dpl
      008B07 7E 00            [12] 1100 	mov	r6,#0x00
      008B09 EF               [12] 1101 	mov	a,r7
      008B0A 42 03            [12] 1102 	orl	ar3,a
      008B0C EE               [12] 1103 	mov	a,r6
      008B0D 42 02            [12] 1104 	orl	ar2,a
                                   1105 ;	quantum/dynamic_keymap.c:236: return keycode;
      008B0F 8B 82            [24] 1106 	mov	dpl, r3
      008B11 8A 83            [24] 1107 	mov	dph, r2
                                   1108 ;	quantum/dynamic_keymap.c:237: }
      008B13 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1112 ;------------------------------------------------------------
                                   1113 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1114 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1115 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1116 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1117 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_390'
                                   1118 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_393'
                                   1119 ;------------------------------------------------------------
                                   1120 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1121 ;	-----------------------------------------
                                   1122 ;	 function dynamic_keymap_set_encoder
                                   1123 ;	-----------------------------------------
      008B14                       1124 _dynamic_keymap_set_encoder:
      008B14 E5 82            [12] 1125 	mov	a,dpl
      008B16 90 0B 72         [24] 1126 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_390
      008B19 F0               [24] 1127 	movx	@dptr,a
                                   1128 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008B1A E0               [24] 1129 	movx	a,@dptr
      008B1B FF               [12] 1130 	mov	r7,a
      008B1C BF 06 00         [24] 1131 	cjne	r7,#0x06,00131$
      008B1F                       1132 00131$:
      008B1F 50 0A            [24] 1133 	jnc	00101$
      008B21 90 0B 6E         [24] 1134 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008B24 E0               [24] 1135 	movx	a,@dptr
      008B25 FE               [12] 1136 	mov	r6,a
      008B26 BE 01 00         [24] 1137 	cjne	r6,#0x01,00133$
      008B29                       1138 00133$:
      008B29 40 01            [24] 1139 	jc	00102$
      008B2B                       1140 00101$:
      008B2B 22               [24] 1141 	ret
      008B2C                       1142 00102$:
                                   1143 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008B2C 90 0B 69         [24] 1144 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008B2F E4               [12] 1145 	clr	a
      008B30 F0               [24] 1146 	movx	@dptr,a
      008B31 8F 82            [24] 1147 	mov	dpl, r7
      008B33 51 86            [12] 1148 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008B35 12 95 B7         [24] 1149 	lcall	_ak820_outline_0118
                                   1150 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008B38 90 0B 6F         [24] 1151 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008B3B E0               [24] 1152 	movx	a,@dptr
      008B3C FC               [12] 1153 	mov	r4,a
      008B3D E0               [24] 1154 	movx	a,@dptr
      008B3E 60 04            [24] 1155 	jz	00106$
      008B40 7B 00            [12] 1156 	mov	r3,#0x00
      008B42 80 02            [24] 1157 	sjmp	00107$
      008B44                       1158 00106$:
      008B44 7B 02            [12] 1159 	mov	r3,#0x02
      008B46                       1160 00107$:
      008B46 EB               [12] 1161 	mov	a,r3
      008B47 12 95 C9         [24] 1162 	lcall	_ak820_outline_0140
      008B4A 8F 03            [24] 1163 	mov	ar3,r7
      008B4C 90 0B 70         [24] 1164 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008B4F E0               [24] 1165 	movx	a,@dptr
      008B50 F5 32            [12] 1166 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008B52 A3               [24] 1167 	inc	dptr
      008B53 E0               [24] 1168 	movx	a,@dptr
      008B54 F5 33            [12] 1169 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008B56 90 07 03         [24] 1170 	mov	dptr,#_eeprom_update_byte_PARM_2
      008B59 F0               [24] 1171 	movx	@dptr,a
      008B5A 12 49 89         [24] 1172 	lcall	_ak820_outline_0163
      008B5D 8B F0            [24] 1173 	mov	b, r3
      008B5F 12 53 B4         [24] 1174 	lcall	_eeprom_update_byte
                                   1175 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008B62 EC               [12] 1176 	mov	a,r4
      008B63 60 04            [24] 1177 	jz	00108$
      008B65 7C 00            [12] 1178 	mov	r4,#0x00
      008B67 80 02            [24] 1179 	sjmp	00109$
      008B69                       1180 00108$:
      008B69 7C 02            [12] 1181 	mov	r4,#0x02
      008B6B                       1182 00109$:
      008B6B EC               [12] 1183 	mov	a,r4
      008B6C 12 38 73         [24] 1184 	lcall	_ak820_outline_0166
      008B6F 0D               [12] 1185 	inc	r5
      008B70 BD 00 01         [24] 1186 	cjne	r5,#0x00,00137$
      008B73 0E               [12] 1187 	inc	r6
      008B74                       1188 00137$:
      008B74 90 07 03         [24] 1189 	mov	dptr,#_eeprom_update_byte_PARM_2
      008B77 E5 32            [12] 1190 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008B79 F0               [24] 1191 	movx	@dptr,a
      008B7A 12 54 CB         [24] 1192 	lcall	_ak820_outline_0049
                                   1193 ;	quantum/dynamic_keymap.c:245: }
      008B7D 02 53 B4         [24] 1194 	ljmp	_eeprom_update_byte
                                   1195 ;------------------------------------------------------------
                                   1196 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1197 ;------------------------------------------------------------
                                   1198 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1199 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1200 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_394'
                                   1201 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_395'
                                   1202 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_397'
                                   1203 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_398'
                                   1204 ;------------------------------------------------------------
                                   1205 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1206 ;	-----------------------------------------
                                   1207 ;	 function dynamic_keymap_get_combo
                                   1208 ;	-----------------------------------------
      008B80                       1209 _dynamic_keymap_get_combo:
      008B80 E5 82            [12] 1210 	mov	a,dpl
      008B82 90 0B 76         [24] 1211 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_394
      008B85 F0               [24] 1212 	movx	@dptr,a
                                   1213 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008B86 90 0B 73         [24] 1214 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008B89 12 37 FD         [24] 1215 	lcall	_ak820_outline_0056
                                   1216 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008B8C 90 0B 76         [24] 1217 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_394
      008B8F E0               [24] 1218 	movx	a,@dptr
      008B90 FD               [12] 1219 	mov	r5,a
      008B91 BD 08 00         [24] 1220 	cjne	r5,#0x08,00132$
      008B94                       1221 00132$:
      008B94 40 04            [24] 1222 	jc	00102$
                                   1223 ;	quantum/dynamic_keymap.c:315: return -1;
      008B96 90 FF FF         [24] 1224 	mov	dptr,#0xffff
      008B99 22               [24] 1225 	ret
      008B9A                       1226 00102$:
                                   1227 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008B9A 12 95 8F         [24] 1228 	lcall	_ak820_outline_0082
                                   1229 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008B9D 8E 02            [24] 1230 	mov	ar2,r6
      008B9F 8F 03            [24] 1231 	mov	ar3,r7
      008BA1 90 05 ED         [24] 1232 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008BA4 EC               [12] 1233 	mov	a,r4
      008BA5 F0               [24] 1234 	movx	@dptr,a
      008BA6 ED               [12] 1235 	mov	a,r5
      008BA7 12 38 1A         [24] 1236 	lcall	_ak820_outline_0074
      008BAA 90 05 F0         [24] 1237 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008BAD 12 95 B0         [24] 1238 	lcall	_ak820_outline_0114
      008BB0 12 49 7F         [24] 1239 	lcall	_ak820_outline_0148
      008BB3 C0 07            [24] 1240 	push	ar7
      008BB5 C0 06            [24] 1241 	push	ar6
      008BB7 12 46 B6         [24] 1242 	lcall	_ak820_eeprom_read_block_xdata
      008BBA D0 06            [24] 1243 	pop	ar6
      008BBC D0 07            [24] 1244 	pop	ar7
                                   1245 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008BBE 74 04            [12] 1246 	mov	a,#0x04
      008BC0 12 41 26         [24] 1247 	lcall	_ak820_outline_0012
      008BC3 FA               [12] 1248 	mov	r2,a
      008BC4 A3               [24] 1249 	inc	dptr
      008BC5 E0               [24] 1250 	movx	a,@dptr
      008BC6 FB               [12] 1251 	mov	r3,a
      008BC7 BA 20 14         [24] 1252 	cjne	r2,#0x20,00108$
      008BCA BB 08 11         [24] 1253 	cjne	r3,#0x08,00108$
      008BCD 74 06            [12] 1254 	mov	a,#0x06
      008BCF 12 37 D2         [24] 1255 	lcall	_ak820_outline_0013
      008BD2 FA               [12] 1256 	mov	r2,a
      008BD3 A3               [24] 1257 	inc	dptr
      008BD4 E0               [24] 1258 	movx	a,@dptr
      008BD5 FB               [12] 1259 	mov	r3,a
      008BD6 BA 01 05         [24] 1260 	cjne	r2,#0x01,00136$
      008BD9 BB 00 02         [24] 1261 	cjne	r3,#0x00,00136$
      008BDC 80 05            [24] 1262 	sjmp	00109$
      008BDE                       1263 00136$:
      008BDE                       1264 00108$:
      008BDE 75 34 00         [24] 1265 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008BE1 80 03            [24] 1266 	sjmp	00110$
      008BE3                       1267 00109$:
      008BE3 75 34 01         [24] 1268 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008BE6                       1269 00110$:
                                   1270 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008BE6 74 06            [12] 1271 	mov	a,#0x06
      008BE8 12 37 ED         [24] 1272 	lcall	_ak820_outline_0033
      008BEB 12 55 0D         [24] 1273 	lcall	_ak820_outline_0154
      008BEE 12 49 62         [24] 1274 	lcall	_ak820_outline_0124
      008BF1 A3               [24] 1275 	inc	dptr
      008BF2 F0               [24] 1276 	movx	@dptr,a
                                   1277 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008BF3 E5 34            [12] 1278 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008BF5 60 12            [24] 1279 	jz	00103$
      008BF7 12 49 5D         [24] 1280 	lcall	_ak820_outline_0120
      008BFA C0 07            [24] 1281 	push	ar7
      008BFC C0 06            [24] 1282 	push	ar6
      008BFE 12 34 68         [24] 1283 	lcall	_ak820_combo_valid
      008C01 E5 82            [12] 1284 	mov	a, dpl
      008C03 D0 06            [24] 1285 	pop	ar6
      008C05 D0 07            [24] 1286 	pop	ar7
      008C07 70 08            [24] 1287 	jnz	00104$
      008C09                       1288 00103$:
      008C09 7D 00            [12] 1289 	mov	r5,#0x00
      008C0B 12 95 7A         [24] 1290 	lcall	_ak820_outline_0041
      008C0E 12 BF B9         [24] 1291 	lcall	_memset
      008C11                       1292 00104$:
                                   1293 ;	quantum/dynamic_keymap.c:329: return 0;
      008C11 90 00 00         [24] 1294 	mov	dptr,#0x0000
                                   1295 ;	quantum/dynamic_keymap.c:330: }
      008C14 22               [24] 1296 	ret
                                   1297 ;------------------------------------------------------------
                                   1298 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1299 ;------------------------------------------------------------
                                   1300 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1301 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_400'
                                   1302 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_401'
                                   1303 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_404'
                                   1304 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_405'
                                   1305 ;------------------------------------------------------------
                                   1306 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1307 ;	-----------------------------------------
                                   1308 ;	 function dynamic_keymap_set_combo
                                   1309 ;	-----------------------------------------
      008C15                       1310 _dynamic_keymap_set_combo:
      008C15 E5 82            [12] 1311 	mov	a,dpl
      008C17 90 0B 7A         [24] 1312 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_400
      008C1A F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008C1B 90 0B 77         [24] 1315 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008C1E 12 37 BE         [24] 1316 	lcall	_ak820_outline_0007
                                   1317 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008C21 C0 07            [24] 1318 	push	ar7
      008C23 C0 06            [24] 1319 	push	ar6
      008C25 12 34 68         [24] 1320 	lcall	_ak820_combo_valid
      008C28 E5 82            [12] 1321 	mov	a, dpl
      008C2A D0 06            [24] 1322 	pop	ar6
      008C2C D0 07            [24] 1323 	pop	ar7
      008C2E 60 07            [24] 1324 	jz	00101$
      008C30 12 44 21         [24] 1325 	lcall	_ak820_nvm_ok
      008C33 E5 82            [12] 1326 	mov	a, dpl
      008C35 70 04            [24] 1327 	jnz	00102$
      008C37                       1328 00101$:
      008C37 90 FF FF         [24] 1329 	mov	dptr,#0xffff
      008C3A 22               [24] 1330 	ret
      008C3B                       1331 00102$:
                                   1332 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008C3B 90 0B 7A         [24] 1333 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_400
      008C3E E0               [24] 1334 	movx	a,@dptr
      008C3F FD               [12] 1335 	mov	r5,a
      008C40 BD 08 00         [24] 1336 	cjne	r5,#0x08,00133$
      008C43                       1337 00133$:
      008C43 40 04            [24] 1338 	jc	00105$
                                   1339 ;	quantum/dynamic_keymap.c:342: return -1;
      008C45 90 FF FF         [24] 1340 	mov	dptr,#0xffff
      008C48 22               [24] 1341 	ret
      008C49                       1342 00105$:
                                   1343 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008C49 12 95 8F         [24] 1344 	lcall	_ak820_outline_0082
                                   1345 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008C4C C0 07            [24] 1346 	push	ar7
      008C4E C0 06            [24] 1347 	push	ar6
      008C50 C0 05            [24] 1348 	push	ar5
      008C52 C0 04            [24] 1349 	push	ar4
      008C54 12 7B BD         [24] 1350 	lcall	_clear_keyboard
      008C57 D0 04            [24] 1351 	pop	ar4
      008C59 D0 05            [24] 1352 	pop	ar5
      008C5B D0 06            [24] 1353 	pop	ar6
      008C5D D0 07            [24] 1354 	pop	ar7
                                   1355 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008C5F 90 0E 2F         [24] 1356 	mov	dptr,#___memcpy_PARM_2
      008C62 12 4E 7D         [24] 1357 	lcall	_ak820_outline_0064
      008C65 E4               [12] 1358 	clr	a
      008C66 A3               [24] 1359 	inc	dptr
      008C67 F0               [24] 1360 	movx	@dptr,a
      008C68 90 0E 32         [24] 1361 	mov	dptr,#___memcpy_PARM_3
      008C6B 12 95 B0         [24] 1362 	lcall	_ak820_outline_0114
      008C6E 90 0B 7B         [24] 1363 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_405
      008C71 F5 F0            [12] 1364 	mov	b,a
      008C73 C0 05            [24] 1365 	push	ar5
      008C75 C0 04            [24] 1366 	push	ar4
      008C77 12 BF 43         [24] 1367 	lcall	___memcpy
      008C7A D0 04            [24] 1368 	pop	ar4
      008C7C D0 05            [24] 1369 	pop	ar5
                                   1370 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008C7E 90 0B 7F         [24] 1371 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_405 + 0x0004)
      008C81 74 20            [12] 1372 	mov	a,#0x20
      008C83 F0               [24] 1373 	movx	@dptr,a
      008C84 74 08            [12] 1374 	mov	a,#0x08
      008C86 A3               [24] 1375 	inc	dptr
      008C87 F0               [24] 1376 	movx	@dptr,a
                                   1377 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008C88 90 0B 81         [24] 1378 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_405 + 0x0006)
      008C8B 74 01            [12] 1379 	mov	a,#0x01
      008C8D 12 38 59         [24] 1380 	lcall	_ak820_outline_0129
                                   1381 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008C90 90 05 F6         [24] 1382 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008C93 EC               [12] 1383 	mov	a,r4
      008C94 F0               [24] 1384 	movx	@dptr,a
      008C95 ED               [12] 1385 	mov	a,r5
      008C96 12 38 1A         [24] 1386 	lcall	_ak820_outline_0074
      008C99 90 05 F9         [24] 1387 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008C9C 12 95 B0         [24] 1388 	lcall	_ak820_outline_0114
      008C9F 90 0B 7B         [24] 1389 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_405
      008CA2 12 47 42         [24] 1390 	lcall	_ak820_eeprom_write_block_xdata
                                   1391 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008CA5 12 44 30         [24] 1392 	lcall	_ak820_nvm_flush
                                   1393 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008CA8 12 44 21         [24] 1394 	lcall	_ak820_nvm_ok
      008CAB E5 82            [12] 1395 	mov	a, dpl
      008CAD 70 04            [24] 1396 	jnz	00107$
      008CAF 90 FF FF         [24] 1397 	mov	dptr,#0xffff
      008CB2 22               [24] 1398 	ret
      008CB3                       1399 00107$:
                                   1400 ;	quantum/dynamic_keymap.c:360: return 0;
      008CB3 90 00 00         [24] 1401 	mov	dptr,#0x0000
                                   1402 ;	quantum/dynamic_keymap.c:361: }
      008CB6 22               [24] 1403 	ret
                                   1404 ;------------------------------------------------------------
                                   1405 ;Allocation info for local variables in function 'dynamic_keymap_get_key_override'
                                   1406 ;------------------------------------------------------------
                                   1407 ;buffer        Allocated with name '_dynamic_keymap_get_key_override_PARM_2'
                                   1408 ;index         Allocated with name '_dynamic_keymap_get_key_override_index_10000_407'
                                   1409 ;entry         Allocated with name '_dynamic_keymap_get_key_override_entry_10000_408'
                                   1410 ;------------------------------------------------------------
                                   1411 ;	quantum/dynamic_keymap.c:366: int dynamic_keymap_get_key_override(uint8_t index, vial_key_override_entry_t *buffer) {
                                   1412 ;	-----------------------------------------
                                   1413 ;	 function dynamic_keymap_get_key_override
                                   1414 ;	-----------------------------------------
      008CB7                       1415 _dynamic_keymap_get_key_override:
      008CB7 E5 82            [12] 1416 	mov	a,dpl
      008CB9 90 0B 88         [24] 1417 	mov	dptr,#_dynamic_keymap_get_key_override_index_10000_407
      008CBC F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	quantum/dynamic_keymap.c:367: vial_key_override_entry_t AK820_STATE_MEM *entry = (vial_key_override_entry_t AK820_STATE_MEM *)buffer;
      008CBD 90 0B 85         [24] 1420 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      008CC0 12 37 FD         [24] 1421 	lcall	_ak820_outline_0056
                                   1422 ;	quantum/dynamic_keymap.c:368: if (index >= AK820_EXTENSION_ENTRIES) return -1;
      008CC3 90 0B 88         [24] 1423 	mov	dptr,#_dynamic_keymap_get_key_override_index_10000_407
      008CC6 E0               [24] 1424 	movx	a,@dptr
      008CC7 FD               [12] 1425 	mov	r5,a
      008CC8 BD 08 00         [24] 1426 	cjne	r5,#0x08,00130$
      008CCB                       1427 00130$:
      008CCB 40 04            [24] 1428 	jc	00102$
      008CCD 90 FF FF         [24] 1429 	mov	dptr,#0xffff
      008CD0 22               [24] 1430 	ret
      008CD1                       1431 00102$:
                                   1432 ;	quantum/dynamic_keymap.c:369: ak820_eeprom_read_block_xdata(entry, (const void *)(VIAL_KEY_OVERRIDE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008CD1 8E 03            [24] 1433 	mov	ar3,r6
      008CD3 8F 04            [24] 1434 	mov	ar4,r7
      008CD5 BD 06 00         [24] 1435 	cjne	r5,#0x06,00132$
      008CD8                       1436 00132$:
      008CD8 50 0B            [24] 1437 	jnc	00107$
      008CDA 8D 02            [24] 1438 	mov	ar2,r5
      008CDC EA               [12] 1439 	mov	a,r2
      008CDD 12 41 88         [24] 1440 	lcall	_ak820_outline_0195
      008CE0 F9               [12] 1441 	mov	r1,a
      008CE1 7A 00            [12] 1442 	mov	r2,#0x00
      008CE3 80 10            [24] 1443 	sjmp	00108$
      008CE5                       1444 00107$:
      008CE5 ED               [12] 1445 	mov	a,r5
      008CE6 24 FA            [12] 1446 	add	a,#0xfa
      008CE8 12 41 88         [24] 1447 	lcall	_ak820_outline_0195
      008CEB F8               [12] 1448 	mov	r0,a
      008CEC 7D 00            [12] 1449 	mov	r5,#0x00
      008CEE 74 40            [12] 1450 	mov	a,#0x40
      008CF0 28               [12] 1451 	add	a, r0
      008CF1 F9               [12] 1452 	mov	r1,a
      008CF2 E4               [12] 1453 	clr	a
      008CF3 3D               [12] 1454 	addc	a, r5
      008CF4 FA               [12] 1455 	mov	r2,a
      008CF5                       1456 00108$:
      008CF5 74 40            [12] 1457 	mov	a,#0x40
      008CF7 29               [12] 1458 	add	a, r1
      008CF8 F9               [12] 1459 	mov	r1,a
      008CF9 74 07            [12] 1460 	mov	a,#0x07
      008CFB 3A               [12] 1461 	addc	a, r2
      008CFC FA               [12] 1462 	mov	r2,a
      008CFD 90 05 ED         [24] 1463 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008D00 E9               [12] 1464 	mov	a,r1
      008D01 F0               [24] 1465 	movx	@dptr,a
      008D02 EA               [12] 1466 	mov	a,r2
      008D03 12 38 1A         [24] 1467 	lcall	_ak820_outline_0074
      008D06 90 05 F0         [24] 1468 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008D09 12 95 B0         [24] 1469 	lcall	_ak820_outline_0114
      008D0C 12 33 FC         [24] 1470 	lcall	_ak820_outline_0127
      008D0F C0 07            [24] 1471 	push	ar7
      008D11 C0 06            [24] 1472 	push	ar6
      008D13 12 46 B6         [24] 1473 	lcall	_ak820_eeprom_read_block_xdata
      008D16 D0 06            [24] 1474 	pop	ar6
      008D18 D0 07            [24] 1475 	pop	ar7
                                   1476 ;	quantum/dynamic_keymap.c:370: if (!ak820_key_override_valid(entry)) memset(entry, 0, sizeof(*entry));
      008D1A 12 49 5D         [24] 1477 	lcall	_ak820_outline_0120
      008D1D C0 07            [24] 1478 	push	ar7
      008D1F C0 06            [24] 1479 	push	ar6
      008D21 12 3B 3B         [24] 1480 	lcall	_ak820_key_override_valid
      008D24 E5 82            [12] 1481 	mov	a, dpl
      008D26 D0 06            [24] 1482 	pop	ar6
      008D28 D0 07            [24] 1483 	pop	ar7
      008D2A 70 07            [24] 1484 	jnz	00104$
      008D2C FD               [12] 1485 	mov	r5,a
      008D2D 12 95 7A         [24] 1486 	lcall	_ak820_outline_0041
      008D30 12 BF B9         [24] 1487 	lcall	_memset
      008D33                       1488 00104$:
                                   1489 ;	quantum/dynamic_keymap.c:371: return 0;
      008D33 90 00 00         [24] 1490 	mov	dptr,#0x0000
                                   1491 ;	quantum/dynamic_keymap.c:372: }
      008D36 22               [24] 1492 	ret
                                   1493 ;------------------------------------------------------------
                                   1494 ;Allocation info for local variables in function 'dynamic_keymap_set_key_override'
                                   1495 ;------------------------------------------------------------
                                   1496 ;buffer        Allocated with name '_dynamic_keymap_set_key_override_PARM_2'
                                   1497 ;index         Allocated with name '_dynamic_keymap_set_key_override_index_10000_411'
                                   1498 ;entry         Allocated with name '_dynamic_keymap_set_key_override_entry_10000_412'
                                   1499 ;------------------------------------------------------------
                                   1500 ;	quantum/dynamic_keymap.c:373: int dynamic_keymap_set_key_override(uint8_t index, const vial_key_override_entry_t *buffer) {
                                   1501 ;	-----------------------------------------
                                   1502 ;	 function dynamic_keymap_set_key_override
                                   1503 ;	-----------------------------------------
      008D37                       1504 _dynamic_keymap_set_key_override:
      008D37 E5 82            [12] 1505 	mov	a,dpl
      008D39 90 0B 8C         [24] 1506 	mov	dptr,#_dynamic_keymap_set_key_override_index_10000_411
      008D3C F0               [24] 1507 	movx	@dptr,a
                                   1508 ;	quantum/dynamic_keymap.c:374: const vial_key_override_entry_t AK820_STATE_MEM *entry = (const vial_key_override_entry_t AK820_STATE_MEM *)buffer;
      008D3D 90 0B 89         [24] 1509 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      008D40 12 37 FD         [24] 1510 	lcall	_ak820_outline_0056
                                   1511 ;	quantum/dynamic_keymap.c:375: if (index >= AK820_EXTENSION_ENTRIES || !ak820_key_override_valid(entry) || !ak820_nvm_ok()) return -1;
      008D43 90 0B 8C         [24] 1512 	mov	dptr,#_dynamic_keymap_set_key_override_index_10000_411
      008D46 E0               [24] 1513 	movx	a,@dptr
      008D47 FD               [12] 1514 	mov	r5,a
      008D48 BD 08 00         [24] 1515 	cjne	r5,#0x08,00139$
      008D4B                       1516 00139$:
      008D4B 50 1D            [24] 1517 	jnc	00101$
      008D4D 12 49 5D         [24] 1518 	lcall	_ak820_outline_0120
      008D50 C0 07            [24] 1519 	push	ar7
      008D52 C0 06            [24] 1520 	push	ar6
      008D54 C0 05            [24] 1521 	push	ar5
      008D56 12 3B 3B         [24] 1522 	lcall	_ak820_key_override_valid
      008D59 E5 82            [12] 1523 	mov	a, dpl
      008D5B D0 05            [24] 1524 	pop	ar5
      008D5D D0 06            [24] 1525 	pop	ar6
      008D5F D0 07            [24] 1526 	pop	ar7
      008D61 60 07            [24] 1527 	jz	00101$
      008D63 12 44 21         [24] 1528 	lcall	_ak820_nvm_ok
      008D66 E5 82            [12] 1529 	mov	a, dpl
      008D68 70 04            [24] 1530 	jnz	00102$
      008D6A                       1531 00101$:
      008D6A 90 FF FF         [24] 1532 	mov	dptr,#0xffff
      008D6D 22               [24] 1533 	ret
      008D6E                       1534 00102$:
                                   1535 ;	quantum/dynamic_keymap.c:376: clear_keyboard();
      008D6E C0 07            [24] 1536 	push	ar7
      008D70 C0 06            [24] 1537 	push	ar6
      008D72 C0 05            [24] 1538 	push	ar5
      008D74 12 7B BD         [24] 1539 	lcall	_clear_keyboard
      008D77 D0 05            [24] 1540 	pop	ar5
      008D79 D0 06            [24] 1541 	pop	ar6
      008D7B D0 07            [24] 1542 	pop	ar7
                                   1543 ;	quantum/dynamic_keymap.c:377: ak820_eeprom_update_block_xdata(entry, (void *)(VIAL_KEY_OVERRIDE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008D7D BD 06 00         [24] 1544 	cjne	r5,#0x06,00143$
      008D80                       1545 00143$:
      008D80 50 0B            [24] 1546 	jnc	00107$
      008D82 8D 04            [24] 1547 	mov	ar4,r5
      008D84 EC               [12] 1548 	mov	a,r4
      008D85 12 41 88         [24] 1549 	lcall	_ak820_outline_0195
      008D88 FB               [12] 1550 	mov	r3,a
      008D89 7C 00            [12] 1551 	mov	r4,#0x00
      008D8B 80 10            [24] 1552 	sjmp	00108$
      008D8D                       1553 00107$:
      008D8D ED               [12] 1554 	mov	a,r5
      008D8E 24 FA            [12] 1555 	add	a,#0xfa
      008D90 12 41 88         [24] 1556 	lcall	_ak820_outline_0195
      008D93 FD               [12] 1557 	mov	r5,a
      008D94 7A 00            [12] 1558 	mov	r2,#0x00
      008D96 74 40            [12] 1559 	mov	a,#0x40
      008D98 2D               [12] 1560 	add	a, r5
      008D99 FB               [12] 1561 	mov	r3,a
      008D9A E4               [12] 1562 	clr	a
      008D9B 3A               [12] 1563 	addc	a, r2
      008D9C FC               [12] 1564 	mov	r4,a
      008D9D                       1565 00108$:
      008D9D 74 40            [12] 1566 	mov	a,#0x40
      008D9F 2B               [12] 1567 	add	a, r3
      008DA0 FB               [12] 1568 	mov	r3,a
      008DA1 74 07            [12] 1569 	mov	a,#0x07
      008DA3 3C               [12] 1570 	addc	a, r4
      008DA4 FC               [12] 1571 	mov	r4,a
      008DA5 90 05 FD         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      008DA8 EB               [12] 1573 	mov	a,r3
      008DA9 F0               [24] 1574 	movx	@dptr,a
      008DAA EC               [12] 1575 	mov	a,r4
      008DAB 12 38 1A         [24] 1576 	lcall	_ak820_outline_0074
      008DAE 90 06 00         [24] 1577 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      008DB1 74 0A            [12] 1578 	mov	a,#0x0a
      008DB3 F0               [24] 1579 	movx	@dptr,a
      008DB4 E4               [12] 1580 	clr	a
      008DB5 A3               [24] 1581 	inc	dptr
      008DB6 12 49 3E         [24] 1582 	lcall	_ak820_outline_0063
      008DB9 12 48 25         [24] 1583 	lcall	_ak820_eeprom_update_block_xdata
                                   1584 ;	quantum/dynamic_keymap.c:378: ak820_nvm_flush();
      008DBC 12 44 30         [24] 1585 	lcall	_ak820_nvm_flush
                                   1586 ;	quantum/dynamic_keymap.c:379: return ak820_nvm_ok() ? 0 : -1;
      008DBF 12 44 21         [24] 1587 	lcall	_ak820_nvm_ok
      008DC2 E5 82            [12] 1588 	mov	a, dpl
      008DC4 60 06            [24] 1589 	jz	00109$
      008DC6 7E 00            [12] 1590 	mov	r6,#0x00
      008DC8 7F 00            [12] 1591 	mov	r7,#0x00
      008DCA 80 04            [24] 1592 	sjmp	00110$
      008DCC                       1593 00109$:
      008DCC 7E FF            [12] 1594 	mov	r6,#0xff
      008DCE 7F FF            [12] 1595 	mov	r7,#0xff
      008DD0                       1596 00110$:
      008DD0 12 49 5D         [24] 1597 	lcall	_ak820_outline_0120
                                   1598 ;	quantum/dynamic_keymap.c:380: }
      008DD3 22               [24] 1599 	ret
                                   1600 ;------------------------------------------------------------
                                   1601 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1602 ;------------------------------------------------------------
                                   1603 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_415'
                                   1604 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_416'
                                   1605 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_418'
                                   1606 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_420'
                                   1607 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_422'
                                   1608 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_424'
                                   1609 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_425'
                                   1610 ;ko            Allocated with name '_dynamic_keymap_reset_ko_10002_426'
                                   1611 ;i             Allocated with name '_dynamic_keymap_reset_i_20002_427'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function dynamic_keymap_reset
                                   1616 ;	-----------------------------------------
      008DD4                       1617 _dynamic_keymap_reset:
                                   1618 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008DD4 90 0E B2         [24] 1619 	mov	dptr,#_vial_unlocked
      008DD7 E0               [24] 1620 	movx	a,@dptr
      008DD8 90 0B 8D         [24] 1621 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_415
      008DDB F0               [24] 1622 	movx	@dptr,a
                                   1623 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008DDC 90 0E B2         [24] 1624 	mov	dptr,#_vial_unlocked
      008DDF 74 01            [12] 1625 	mov	a,#0x01
      008DE1 F0               [24] 1626 	movx	@dptr,a
                                   1627 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008DE2 7F 00            [12] 1628 	mov	r7,#0x00
      008DE4                       1629 00117$:
      008DE4 BF 06 00         [24] 1630 	cjne	r7,#0x06,00217$
      008DE7                       1631 00217$:
      008DE7 40 02            [24] 1632 	jc	00218$
      008DE9 C1 91            [12] 1633 	ajmp	00104$
      008DEB                       1634 00218$:
                                   1635 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008DEB 7E 00            [12] 1636 	mov	r6,#0x00
      008DED                       1637 00111$:
      008DED BE 10 00         [24] 1638 	cjne	r6,#0x10,00219$
      008DF0                       1639 00219$:
      008DF0 50 4B            [24] 1640 	jnc	00102$
                                   1641 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008DF2 7D 00            [12] 1642 	mov	r5,#0x00
      008DF4                       1643 00108$:
      008DF4 BD 08 00         [24] 1644 	cjne	r5,#0x08,00221$
      008DF7                       1645 00221$:
      008DF7 50 41            [24] 1646 	jnc	00112$
                                   1647 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008DF9 90 0C 33         [24] 1648 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008DFC EE               [12] 1649 	mov	a,r6
      008DFD F0               [24] 1650 	movx	@dptr,a
      008DFE 90 0C 34         [24] 1651 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008E01 12 41 83         [24] 1652 	lcall	_ak820_outline_0194
      008E04 C0 07            [24] 1653 	push	ar7
      008E06 C0 06            [24] 1654 	push	ar6
      008E08 C0 05            [24] 1655 	push	ar5
      008E0A 12 9D C1         [24] 1656 	lcall	_keycode_at_keymap_location_raw
      008E0D AB 82            [24] 1657 	mov	r3, dpl
      008E0F AC 83            [24] 1658 	mov	r4, dph
      008E11 D0 05            [24] 1659 	pop	ar5
      008E13 D0 06            [24] 1660 	pop	ar6
      008E15 D0 07            [24] 1661 	pop	ar7
      008E17 90 0B 64         [24] 1662 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008E1A EE               [12] 1663 	mov	a,r6
      008E1B F0               [24] 1664 	movx	@dptr,a
      008E1C 90 0B 65         [24] 1665 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008E1F ED               [12] 1666 	mov	a,r5
      008E20 F0               [24] 1667 	movx	@dptr,a
      008E21 90 0B 66         [24] 1668 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008E24 12 38 2C         [24] 1669 	lcall	_ak820_outline_0095
      008E27 8F 82            [24] 1670 	mov	dpl, r7
      008E29 C0 07            [24] 1671 	push	ar7
      008E2B C0 06            [24] 1672 	push	ar6
      008E2D C0 05            [24] 1673 	push	ar5
      008E2F 51 3B            [12] 1674 	acall	_dynamic_keymap_set_keycode
      008E31 D0 05            [24] 1675 	pop	ar5
      008E33 D0 06            [24] 1676 	pop	ar6
      008E35 D0 07            [24] 1677 	pop	ar7
                                   1678 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008E37 0D               [12] 1679 	inc	r5
      008E38 80 BA            [24] 1680 	sjmp	00108$
      008E3A                       1681 00112$:
                                   1682 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008E3A 0E               [12] 1683 	inc	r6
      008E3B 80 B0            [24] 1684 	sjmp	00111$
      008E3D                       1685 00102$:
                                   1686 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008E3D 7E 00            [12] 1687 	mov	r6,#0x00
      008E3F                       1688 00114$:
      008E3F BE 01 00         [24] 1689 	cjne	r6,#0x01,00223$
      008E42                       1690 00223$:
      008E42 50 4A            [24] 1691 	jnc	00118$
                                   1692 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008E44 12 95 E5         [24] 1693 	lcall	_ak820_outline_0185
      008E47 04               [12] 1694 	inc	a
      008E48 F0               [24] 1695 	movx	@dptr,a
      008E49 8F 82            [24] 1696 	mov	dpl, r7
      008E4B C0 07            [24] 1697 	push	ar7
      008E4D 12 9E 06         [24] 1698 	lcall	_keycode_at_encodermap_location_raw
      008E50 12 49 84         [24] 1699 	lcall	_ak820_outline_0155
      008E53 D0 07            [24] 1700 	pop	ar7
      008E55 12 95 DC         [24] 1701 	lcall	_ak820_outline_0184
      008E58 04               [12] 1702 	inc	a
      008E59 F0               [24] 1703 	movx	@dptr,a
      008E5A 90 0B 70         [24] 1704 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008E5D 12 38 20         [24] 1705 	lcall	_ak820_outline_0078
      008E60 8F 82            [24] 1706 	mov	dpl, r7
      008E62 C0 07            [24] 1707 	push	ar7
      008E64 71 14            [24] 1708 	acall	_dynamic_keymap_set_encoder
      008E66 D0 07            [24] 1709 	pop	ar7
                                   1710 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008E68 12 95 E5         [24] 1711 	lcall	_ak820_outline_0185
      008E6B F0               [24] 1712 	movx	@dptr,a
      008E6C 8F 82            [24] 1713 	mov	dpl, r7
      008E6E C0 07            [24] 1714 	push	ar7
      008E70 12 9E 06         [24] 1715 	lcall	_keycode_at_encodermap_location_raw
      008E73 12 49 84         [24] 1716 	lcall	_ak820_outline_0155
      008E76 D0 07            [24] 1717 	pop	ar7
      008E78 12 95 DC         [24] 1718 	lcall	_ak820_outline_0184
      008E7B F0               [24] 1719 	movx	@dptr,a
      008E7C 90 0B 70         [24] 1720 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008E7F 12 38 20         [24] 1721 	lcall	_ak820_outline_0078
      008E82 8F 82            [24] 1722 	mov	dpl, r7
      008E84 C0 07            [24] 1723 	push	ar7
      008E86 71 14            [24] 1724 	acall	_dynamic_keymap_set_encoder
      008E88 D0 07            [24] 1725 	pop	ar7
                                   1726 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008E8A 7E 01            [12] 1727 	mov	r6,#0x01
      008E8C 80 B1            [24] 1728 	sjmp	00114$
      008E8E                       1729 00118$:
                                   1730 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008E8E 0F               [12] 1731 	inc	r7
      008E8F A1 E4            [12] 1732 	ajmp	00117$
      008E91                       1733 00104$:
                                   1734 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008E91 90 0B 8E         [24] 1735 	mov	dptr,#_dynamic_keymap_reset_combo_10001_424
      008E94 12 55 0D         [24] 1736 	lcall	_ak820_outline_0154
      008E97 90 0B 90         [24] 1737 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0002)
      008E9A F0               [24] 1738 	movx	@dptr,a
      008E9B A3               [24] 1739 	inc	dptr
      008E9C F0               [24] 1740 	movx	@dptr,a
      008E9D 90 0B 92         [24] 1741 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0004)
      008EA0 F0               [24] 1742 	movx	@dptr,a
      008EA1 A3               [24] 1743 	inc	dptr
      008EA2 F0               [24] 1744 	movx	@dptr,a
      008EA3 90 0B 94         [24] 1745 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0006)
      008EA6 F0               [24] 1746 	movx	@dptr,a
      008EA7 A3               [24] 1747 	inc	dptr
      008EA8 F0               [24] 1748 	movx	@dptr,a
      008EA9 90 0B 96         [24] 1749 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0008)
      008EAC F0               [24] 1750 	movx	@dptr,a
      008EAD A3               [24] 1751 	inc	dptr
      008EAE F0               [24] 1752 	movx	@dptr,a
                                   1753 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008EAF FF               [12] 1754 	mov	r7,a
      008EB0                       1755 00120$:
      008EB0 BF 08 00         [24] 1756 	cjne	r7,#0x08,00225$
      008EB3                       1757 00225$:
      008EB3 50 16            [24] 1758 	jnc	00105$
                                   1759 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008EB5 90 0B 77         [24] 1760 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008EB8 74 8E            [12] 1761 	mov	a,#_dynamic_keymap_reset_combo_10001_424
      008EBA F0               [24] 1762 	movx	@dptr,a
      008EBB 74 0B            [12] 1763 	mov	a,#(_dynamic_keymap_reset_combo_10001_424 >> 8)
      008EBD 12 38 1A         [24] 1764 	lcall	_ak820_outline_0074
      008EC0 8F 82            [24] 1765 	mov	dpl, r7
      008EC2 C0 07            [24] 1766 	push	ar7
      008EC4 91 15            [24] 1767 	acall	_dynamic_keymap_set_combo
      008EC6 D0 07            [24] 1768 	pop	ar7
                                   1769 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008EC8 0F               [12] 1770 	inc	r7
      008EC9 80 E5            [24] 1771 	sjmp	00120$
      008ECB                       1772 00105$:
                                   1773 ;	quantum/dynamic_keymap.c:455: vial_key_override_entry_t ko = { 0 };
      008ECB 90 0B 98         [24] 1774 	mov	dptr,#_dynamic_keymap_reset_ko_10002_426
      008ECE 12 55 0D         [24] 1775 	lcall	_ak820_outline_0154
      008ED1 90 0B 9A         [24] 1776 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0002)
      008ED4 F0               [24] 1777 	movx	@dptr,a
      008ED5 A3               [24] 1778 	inc	dptr
      008ED6 F0               [24] 1779 	movx	@dptr,a
      008ED7 90 0B 9C         [24] 1780 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0004)
      008EDA F0               [24] 1781 	movx	@dptr,a
      008EDB A3               [24] 1782 	inc	dptr
      008EDC F0               [24] 1783 	movx	@dptr,a
      008EDD 90 0B 9E         [24] 1784 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0006)
      008EE0 F0               [24] 1785 	movx	@dptr,a
      008EE1 90 0B 9F         [24] 1786 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0007)
      008EE4 F0               [24] 1787 	movx	@dptr,a
      008EE5 90 0B A0         [24] 1788 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0008)
      008EE8 F0               [24] 1789 	movx	@dptr,a
      008EE9 90 0B A1         [24] 1790 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0009)
      008EEC F0               [24] 1791 	movx	@dptr,a
                                   1792 ;	quantum/dynamic_keymap.c:460: for (reset_index_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i)
      008EED FF               [12] 1793 	mov	r7,a
      008EEE                       1794 00123$:
      008EEE BF 08 00         [24] 1795 	cjne	r7,#0x08,00227$
      008EF1                       1796 00227$:
      008EF1 50 16            [24] 1797 	jnc	00106$
                                   1798 ;	quantum/dynamic_keymap.c:461: dynamic_keymap_set_key_override(i, &ko);
      008EF3 90 0B 89         [24] 1799 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      008EF6 74 98            [12] 1800 	mov	a,#_dynamic_keymap_reset_ko_10002_426
      008EF8 F0               [24] 1801 	movx	@dptr,a
      008EF9 74 0B            [12] 1802 	mov	a,#(_dynamic_keymap_reset_ko_10002_426 >> 8)
      008EFB 12 38 1A         [24] 1803 	lcall	_ak820_outline_0074
      008EFE 8F 82            [24] 1804 	mov	dpl, r7
      008F00 C0 07            [24] 1805 	push	ar7
      008F02 B1 37            [12] 1806 	acall	_dynamic_keymap_set_key_override
      008F04 D0 07            [24] 1807 	pop	ar7
                                   1808 ;	quantum/dynamic_keymap.c:460: for (reset_index_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i)
      008F06 0F               [12] 1809 	inc	r7
      008F07 80 E5            [24] 1810 	sjmp	00123$
      008F09                       1811 00106$:
                                   1812 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008F09 90 0B 8D         [24] 1813 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_415
      008F0C E0               [24] 1814 	movx	a,@dptr
      008F0D 90 0E B2         [24] 1815 	mov	dptr,#_vial_unlocked
      008F10 F0               [24] 1816 	movx	@dptr,a
                                   1817 ;	quantum/dynamic_keymap.c:468: }
      008F11 22               [24] 1818 	ret
                                   1819 ;------------------------------------------------------------
                                   1820 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1821 ;------------------------------------------------------------
                                   1822 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1823 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1824 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1825 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1826 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1827 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_428'
                                   1828 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_429'
                                   1829 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_429'
                                   1830 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_432'
                                   1831 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_434'
                                   1832 ;------------------------------------------------------------
                                   1833 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1834 ;	-----------------------------------------
                                   1835 ;	 function ak820_dynamic_read_buffer
                                   1836 ;	-----------------------------------------
      008F12                       1837 _ak820_dynamic_read_buffer:
      008F12 12 38 44         [24] 1838 	lcall	_ak820_outline_0109
      008F15 90 0B AB         [24] 1839 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_428
      008F18 12 38 49         [24] 1840 	lcall	_ak820_outline_0110
                                   1841 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008F1B 90 0B A8         [24] 1842 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008F1E 12 37 FD         [24] 1843 	lcall	_ak820_outline_0056
                                   1844 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008F21 90 0B AD         [24] 1845 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      008F24 E4               [12] 1846 	clr	a
      008F25 F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008F26 90 0B A6         [24] 1849 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008F29 12 38 14         [24] 1850 	lcall	_ak820_outline_0062
      008F2C 8C 02            [24] 1851 	mov	ar2,r4
      008F2E 8D 03            [24] 1852 	mov	ar3,r5
      008F30 C3               [12] 1853 	clr	c
      008F31 74 1C            [12] 1854 	mov	a,#0x1c
      008F33 9A               [12] 1855 	subb	a,r2
      008F34 E4               [12] 1856 	clr	a
      008F35 9B               [12] 1857 	subb	a,r3
      008F36 50 01            [24] 1858 	jnc	00102$
                                   1859 ;	free result
      008F38 22               [24] 1860 	ret
      008F39                       1861 00102$:
                                   1862 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008F39 90 0B A4         [24] 1863 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008F3C 12 49 68         [24] 1864 	lcall	_ak820_outline_0126
      008F3F 90 0B A2         [24] 1865 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008F42 12 38 3E         [24] 1866 	lcall	_ak820_outline_0105
      008F45 C3               [12] 1867 	clr	c
      008F46 EA               [12] 1868 	mov	a,r2
      008F47 98               [12] 1869 	subb	a,r0
      008F48 EB               [12] 1870 	mov	a,r3
      008F49 99               [12] 1871 	subb	a,r1
      008F4A 50 17            [24] 1872 	jnc	00104$
                                   1873 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008F4C E8               [12] 1874 	mov	a,r0
      008F4D C3               [12] 1875 	clr	c
      008F4E 9A               [12] 1876 	subb	a,r2
      008F4F F8               [12] 1877 	mov	r0,a
      008F50 E9               [12] 1878 	mov	a,r1
      008F51 9B               [12] 1879 	subb	a,r3
      008F52 F9               [12] 1880 	mov	r1,a
                                   1881 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008F53 C3               [12] 1882 	clr	c
      008F54 E8               [12] 1883 	mov	a,r0
      008F55 9C               [12] 1884 	subb	a,r4
      008F56 E9               [12] 1885 	mov	a,r1
      008F57 9D               [12] 1886 	subb	a,r5
      008F58 40 04            [24] 1887 	jc	00114$
      008F5A 8C 00            [24] 1888 	mov	ar0,r4
      008F5C 8D 01            [24] 1889 	mov	ar1,r5
      008F5E                       1890 00114$:
      008F5E 90 0B AD         [24] 1891 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      008F61 E8               [12] 1892 	mov	a,r0
      008F62 F0               [24] 1893 	movx	@dptr,a
      008F63                       1894 00104$:
                                   1895 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008F63 90 0B AD         [24] 1896 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      008F66 E0               [24] 1897 	movx	a,@dptr
      008F67 F5 35            [12] 1898 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008F69 E0               [24] 1899 	movx	a,@dptr
      008F6A 60 42            [24] 1900 	jz	00106$
      008F6C C0 04            [24] 1901 	push	ar4
      008F6E C0 05            [24] 1902 	push	ar5
      008F70 8E 00            [24] 1903 	mov	ar0,r6
      008F72 8F 05            [24] 1904 	mov	ar5,r7
      008F74 90 0B AB         [24] 1905 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_428
      008F77 E0               [24] 1906 	movx	a,@dptr
      008F78 F9               [12] 1907 	mov	r1,a
      008F79 A3               [24] 1908 	inc	dptr
      008F7A E0               [24] 1909 	movx	a,@dptr
      008F7B FC               [12] 1910 	mov	r4,a
      008F7C EA               [12] 1911 	mov	a,r2
      008F7D 29               [12] 1912 	add	a, r1
      008F7E FA               [12] 1913 	mov	r2,a
      008F7F EB               [12] 1914 	mov	a,r3
      008F80 3C               [12] 1915 	addc	a, r4
      008F81 FB               [12] 1916 	mov	r3,a
      008F82 90 05 ED         [24] 1917 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008F85 EA               [12] 1918 	mov	a,r2
      008F86 F0               [24] 1919 	movx	@dptr,a
      008F87 EB               [12] 1920 	mov	a,r3
      008F88 12 38 1A         [24] 1921 	lcall	_ak820_outline_0074
      008F8B 90 05 F0         [24] 1922 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008F8E E5 35            [12] 1923 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008F90 12 38 59         [24] 1924 	lcall	_ak820_outline_0129
      008F93 88 82            [24] 1925 	mov	dpl, r0
      008F95 8D 83            [24] 1926 	mov	dph, r5
      008F97 C0 07            [24] 1927 	push	ar7
      008F99 C0 06            [24] 1928 	push	ar6
      008F9B C0 05            [24] 1929 	push	ar5
      008F9D C0 04            [24] 1930 	push	ar4
      008F9F 12 46 B6         [24] 1931 	lcall	_ak820_eeprom_read_block_xdata
      008FA2 D0 04            [24] 1932 	pop	ar4
      008FA4 D0 05            [24] 1933 	pop	ar5
      008FA6 D0 06            [24] 1934 	pop	ar6
      008FA8 D0 07            [24] 1935 	pop	ar7
                                   1936 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008FAA D0 05            [24] 1937 	pop	ar5
      008FAC D0 04            [24] 1938 	pop	ar4
                                   1939 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008FAE                       1940 00106$:
                                   1941 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008FAE 90 0B AD         [24] 1942 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      008FB1 E0               [24] 1943 	movx	a,@dptr
      008FB2 FB               [12] 1944 	mov	r3,a
      008FB3                       1945 00109$:
      008FB3 8B 01            [24] 1946 	mov	ar1,r3
      008FB5 7A 00            [12] 1947 	mov	r2,#0x00
      008FB7 C3               [12] 1948 	clr	c
      008FB8 E9               [12] 1949 	mov	a,r1
      008FB9 9C               [12] 1950 	subb	a,r4
      008FBA EA               [12] 1951 	mov	a,r2
      008FBB 9D               [12] 1952 	subb	a,r5
      008FBC 50 09            [24] 1953 	jnc	00111$
      008FBE EB               [12] 1954 	mov	a,r3
      008FBF 12 37 ED         [24] 1955 	lcall	_ak820_outline_0033
      008FC2 E4               [12] 1956 	clr	a
      008FC3 F0               [24] 1957 	movx	@dptr,a
      008FC4 0B               [12] 1958 	inc	r3
      008FC5 80 EC            [24] 1959 	sjmp	00109$
      008FC7                       1960 00111$:
                                   1961 ;	quantum/dynamic_keymap.c:483: }
      008FC7 22               [24] 1962 	ret
                                   1963 ;------------------------------------------------------------
                                   1964 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1965 ;------------------------------------------------------------
                                   1966 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1967 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1968 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_435'
                                   1969 ;------------------------------------------------------------
                                   1970 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1971 ;	-----------------------------------------
                                   1972 ;	 function dynamic_keymap_get_buffer
                                   1973 ;	-----------------------------------------
      008FC8                       1974 _dynamic_keymap_get_buffer:
      008FC8 12 38 44         [24] 1975 	lcall	_ak820_outline_0109
      008FCB 90 0B B3         [24] 1976 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_435
      008FCE 12 38 49         [24] 1977 	lcall	_ak820_outline_0110
                                   1978 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008FD1 90 0B B3         [24] 1979 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_435
      008FD4 12 37 FD         [24] 1980 	lcall	_ak820_outline_0056
      008FD7 90 0B AE         [24] 1981 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008FDA 12 38 14         [24] 1982 	lcall	_ak820_outline_0062
      008FDD 90 0B B0         [24] 1983 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008FE0 12 54 F4         [24] 1984 	lcall	_ak820_outline_0093
      008FE3 90 0B A2         [24] 1985 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008FE6 E4               [12] 1986 	clr	a
      008FE7 F0               [24] 1987 	movx	@dptr,a
      008FE8 74 06            [12] 1988 	mov	a,#0x06
      008FEA A3               [24] 1989 	inc	dptr
      008FEB F0               [24] 1990 	movx	@dptr,a
      008FEC 90 0B A4         [24] 1991 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008FEF 12 4E 7D         [24] 1992 	lcall	_ak820_outline_0064
      008FF2 90 0B A6         [24] 1993 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008FF5 12 38 20         [24] 1994 	lcall	_ak820_outline_0078
      008FF8 90 0B A8         [24] 1995 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008FFB 12 4E 8A         [24] 1996 	lcall	_ak820_outline_0142
      008FFE EB               [12] 1997 	mov	a,r3
      008FFF A3               [24] 1998 	inc	dptr
      009000 F0               [24] 1999 	movx	@dptr,a
      009001 90 00 40         [24] 2000 	mov	dptr,#0x0040
                                   2001 ;	quantum/dynamic_keymap.c:511: }
      009004 02 8F 12         [24] 2002 	ljmp	_ak820_dynamic_read_buffer
                                   2003 ;------------------------------------------------------------
                                   2004 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   2005 ;------------------------------------------------------------
                                   2006 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   2007 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   2008 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   2009 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   2010 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   2011 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_437'
                                   2012 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_438'
                                   2013 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_438'
                                   2014 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_438'
                                   2015 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_441'
                                   2016 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_444'
                                   2017 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_444'
                                   2018 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_446'
                                   2019 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_449'
                                   2020 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_451'
                                   2021 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_452'
                                   2022 ;------------------------------------------------------------
                                   2023 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2024 ;	-----------------------------------------
                                   2025 ;	 function dynamic_keymap_set_buffer
                                   2026 ;	-----------------------------------------
      009007                       2027 _dynamic_keymap_set_buffer:
      009007 12 38 44         [24] 2028 	lcall	_ak820_outline_0109
      00900A 90 0B BA         [24] 2029 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      00900D 12 38 49         [24] 2030 	lcall	_ak820_outline_0110
                                   2031 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      009010 90 0B BA         [24] 2032 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      009013 12 37 C8         [24] 2033 	lcall	_ak820_outline_0009
      009016 74 40            [12] 2034 	mov	a,#0x40
      009018 2C               [12] 2035 	add	a, r4
      009019 FA               [12] 2036 	mov	r2,a
      00901A E4               [12] 2037 	clr	a
      00901B 3D               [12] 2038 	addc	a, r5
      00901C FB               [12] 2039 	mov	r3,a
                                   2040 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      00901D 90 0B B7         [24] 2041 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      009020 12 38 3E         [24] 2042 	lcall	_ak820_outline_0105
                                   2043 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      009023 90 0B B5         [24] 2044 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      009026 E0               [24] 2045 	movx	a,@dptr
      009027 F5 36            [12] 2046 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      009029 A3               [24] 2047 	inc	dptr
      00902A E0               [24] 2048 	movx	a,@dptr
      00902B F5 37            [12] 2049 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      00902D E5 36            [12] 2050 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00902F 45 37            [12] 2051 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009031 70 01            [24] 2052 	jnz	00102$
      009033 22               [24] 2053 	ret
      009034                       2054 00102$:
                                   2055 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      009034 85 36 38         [24] 2056 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      009037 85 37 39         [24] 2057 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00903A C3               [12] 2058 	clr	c
      00903B 74 1C            [12] 2059 	mov	a,#0x1c
      00903D 95 38            [12] 2060 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      00903F E4               [12] 2061 	clr	a
      009040 95 39            [12] 2062 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      009042 50 01            [24] 2063 	jnc	00104$
                                   2064 ;	free result
      009044 22               [24] 2065 	ret
      009045                       2066 00104$:
                                   2067 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      009045 85 36 3A         [24] 2068 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   2069 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      009048 74 FA            [12] 2070 	mov	a,#0x100 - 0x06
      00904A 2F               [12] 2071 	add	a,r7
      00904B 40 11            [24] 2072 	jc	00105$
      00904D E4               [12] 2073 	clr	a
      00904E C3               [12] 2074 	clr	c
      00904F 9E               [12] 2075 	subb	a,r6
      009050 FE               [12] 2076 	mov	r6,a
      009051 74 06            [12] 2077 	mov	a,#0x06
      009053 9F               [12] 2078 	subb	a,r7
      009054 FF               [12] 2079 	mov	r7,a
      009055 C3               [12] 2080 	clr	c
      009056 EE               [12] 2081 	mov	a,r6
      009057 95 36            [12] 2082 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      009059 EF               [12] 2083 	mov	a,r7
      00905A 95 37            [12] 2084 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00905C 50 01            [24] 2085 	jnc	00106$
      00905E                       2086 00105$:
                                   2087 ;	quantum/dynamic_keymap.c:529: return;
      00905E 22               [24] 2088 	ret
      00905F                       2089 00106$:
                                   2090 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      00905F 90 0E B2         [24] 2091 	mov	dptr,#_vial_unlocked
      009062 E0               [24] 2092 	movx	a,@dptr
      009063 60 02            [24] 2093 	jz	00207$
      009065 21 73            [12] 2094 	ajmp	00120$
      009067                       2095 00207$:
                                   2096 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      009067 90 0B BC         [24] 2097 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_444
      00906A E4               [12] 2098 	clr	a
      00906B F0               [24] 2099 	movx	@dptr,a
                                   2100 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      00906C 90 0B BD         [24] 2101 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_444
      00906F E5 3A            [12] 2102 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      009071 F0               [24] 2103 	movx	@dptr,a
                                   2104 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      009072 EC               [12] 2105 	mov	a,r4
      009073 30 E0 33         [24] 2106 	jnb	acc.0,00111$
                                   2107 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      009076 EA               [12] 2108 	mov	a,r2
      009077 24 FF            [12] 2109 	add	a,#0xff
      009079 FE               [12] 2110 	mov	r6,a
      00907A EB               [12] 2111 	mov	a,r3
      00907B 34 FF            [12] 2112 	addc	a,#0xff
      00907D FF               [12] 2113 	mov	r7,a
      00907E 7D 00            [12] 2114 	mov	r5,#0x00
      009080 12 49 5D         [24] 2115 	lcall	_ak820_outline_0120
      009083 8D F0            [24] 2116 	mov	b, r5
      009085 12 46 7B         [24] 2117 	lcall	_eeprom_read_byte
      009088 AE 82            [24] 2118 	mov	r6,dpl
      00908A 7F 00            [12] 2119 	mov	r7,#0x00
      00908C 12 38 6E         [24] 2120 	lcall	_ak820_outline_0162
      00908F E0               [24] 2121 	movx	a,@dptr
      009090 7C 00            [12] 2122 	mov	r4,#0x00
      009092 42 07            [12] 2123 	orl	ar7,a
      009094 EC               [12] 2124 	mov	a,r4
      009095 42 06            [12] 2125 	orl	ar6,a
                                   2126 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      009097 BF 00 09         [24] 2127 	cjne	r7,#0x00,00109$
      00909A BE 7C 06         [24] 2128 	cjne	r6,#0x7c,00109$
                                   2129 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      00909D 12 38 6E         [24] 2130 	lcall	_ak820_outline_0162
      0090A0 74 FF            [12] 2131 	mov	a,#0xff
      0090A2 F0               [24] 2132 	movx	@dptr,a
      0090A3                       2133 00109$:
                                   2134 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      0090A3 90 0B BC         [24] 2135 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_444
      0090A6 74 01            [12] 2136 	mov	a,#0x01
      0090A8 F0               [24] 2137 	movx	@dptr,a
      0090A9                       2138 00111$:
                                   2139 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      0090A9 90 0B BA         [24] 2140 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      0090AC 12 37 FD         [24] 2141 	lcall	_ak820_outline_0056
      0090AF E5 36            [12] 2142 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0090B1 2E               [12] 2143 	add	a, r6
      0090B2 FE               [12] 2144 	mov	r6,a
      0090B3 E5 37            [12] 2145 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0090B5 3F               [12] 2146 	addc	a, r7
      0090B6 EE               [12] 2147 	mov	a,r6
      0090B7 30 E0 5A         [24] 2148 	jnb	acc.0,00115$
                                   2149 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      0090BA AE 3A            [24] 2150 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      0090BC 7F 00            [12] 2151 	mov	r7,#0x00
      0090BE EE               [12] 2152 	mov	a,r6
      0090BF 24 FF            [12] 2153 	add	a,#0xff
      0090C1 FC               [12] 2154 	mov	r4,a
      0090C2 EF               [12] 2155 	mov	a,r7
      0090C3 34 FF            [12] 2156 	addc	a,#0xff
      0090C5 FD               [12] 2157 	mov	r5,a
      0090C6 EC               [12] 2158 	mov	a,r4
      0090C7 28               [12] 2159 	add	a, r0
      0090C8 F5 82            [12] 2160 	mov	dpl,a
      0090CA ED               [12] 2161 	mov	a,r5
      0090CB 39               [12] 2162 	addc	a, r1
      0090CC F5 83            [12] 2163 	mov	dph,a
      0090CE E0               [24] 2164 	movx	a,@dptr
      0090CF FC               [12] 2165 	mov	r4,a
      0090D0 7D 00            [12] 2166 	mov	r5,#0x00
      0090D2 E5 3A            [12] 2167 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0090D4 2A               [12] 2168 	add	a, r2
      0090D5 FA               [12] 2169 	mov	r2,a
      0090D6 E4               [12] 2170 	clr	a
      0090D7 3B               [12] 2171 	addc	a, r3
      0090D8 FB               [12] 2172 	mov	r3,a
      0090D9 C0 00            [24] 2173 	push	ar0
      0090DB C0 01            [24] 2174 	push	ar1
      0090DD 8B 01            [24] 2175 	mov	ar1,r3
      0090DF 7B 00            [12] 2176 	mov	r3,#0x00
      0090E1 8A 82            [24] 2177 	mov	dpl, r2
      0090E3 89 83            [24] 2178 	mov	dph, r1
      0090E5 8B F0            [24] 2179 	mov	b, r3
      0090E7 12 46 7B         [24] 2180 	lcall	_eeprom_read_byte
      0090EA AB 82            [24] 2181 	mov	r3, dpl
      0090EC 7A 00            [12] 2182 	mov	r2,#0x00
      0090EE EB               [12] 2183 	mov	a,r3
      0090EF 12 49 79         [24] 2184 	lcall	_ak820_outline_0147
                                   2185 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      0090F2 BD 00 05         [24] 2186 	cjne	r5,#0x00,00212$
      0090F5 BC 7C 02         [24] 2187 	cjne	r4,#0x7c,00212$
      0090F8 80 06            [24] 2188 	sjmp	00213$
      0090FA                       2189 00212$:
      0090FA D0 01            [24] 2190 	pop	ar1
      0090FC D0 00            [24] 2191 	pop	ar0
      0090FE 80 0D            [24] 2192 	sjmp	00113$
      009100                       2193 00213$:
      009100 D0 01            [24] 2194 	pop	ar1
      009102 D0 00            [24] 2195 	pop	ar0
                                   2196 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      009104 1E               [12] 2197 	dec	r6
      009105 BE FF 01         [24] 2198 	cjne	r6,#0xff,00214$
      009108 1F               [12] 2199 	dec	r7
      009109                       2200 00214$:
      009109 EE               [12] 2201 	mov	a,r6
      00910A 12 95 BE         [24] 2202 	lcall	_ak820_outline_0133
      00910D                       2203 00113$:
                                   2204 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      00910D E5 3A            [12] 2205 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00910F 14               [12] 2206 	dec	a
      009110 90 0B BD         [24] 2207 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_444
      009113 F0               [24] 2208 	movx	@dptr,a
      009114                       2209 00115$:
                                   2210 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      009114 90 0B BC         [24] 2211 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_444
      009117 E0               [24] 2212 	movx	a,@dptr
      009118 90 0B BE         [24] 2213 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_451
      00911B F0               [24] 2214 	movx	@dptr,a
      00911C                       2215 00122$:
      00911C 90 0B BE         [24] 2216 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_451
      00911F E0               [24] 2217 	movx	a,@dptr
      009120 FF               [12] 2218 	mov	r7,a
      009121 90 0B BD         [24] 2219 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_444
      009124 E0               [24] 2220 	movx	a,@dptr
      009125 FE               [12] 2221 	mov	r6,a
      009126 C3               [12] 2222 	clr	c
      009127 EF               [12] 2223 	mov	a,r7
      009128 9E               [12] 2224 	subb	a,r6
      009129 50 48            [24] 2225 	jnc	00120$
                                   2226 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      00912B EF               [12] 2227 	mov	a,r7
      00912C 28               [12] 2228 	add	a, r0
      00912D FD               [12] 2229 	mov	r5,a
      00912E E4               [12] 2230 	clr	a
      00912F 39               [12] 2231 	addc	a, r1
      009130 FE               [12] 2232 	mov	r6,a
      009131 12 4E 83         [24] 2233 	lcall	_ak820_outline_0076
      009134 7B 00            [12] 2234 	mov	r3,#0x00
      009136 8C 37            [24] 2235 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      009138 8B 36            [24] 2236 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      00913A 8F 02            [24] 2237 	mov	ar2,r7
      00913C 7F 00            [12] 2238 	mov	r7,#0x00
      00913E 74 01            [12] 2239 	mov	a,#0x01
      009140 2A               [12] 2240 	add	a, r2
      009141 FB               [12] 2241 	mov	r3,a
      009142 E4               [12] 2242 	clr	a
      009143 3F               [12] 2243 	addc	a, r7
      009144 FC               [12] 2244 	mov	r4,a
      009145 EB               [12] 2245 	mov	a,r3
      009146 28               [12] 2246 	add	a, r0
      009147 F5 82            [12] 2247 	mov	dpl,a
      009149 EC               [12] 2248 	mov	a,r4
      00914A 39               [12] 2249 	addc	a, r1
      00914B F5 83            [12] 2250 	mov	dph,a
      00914D E0               [24] 2251 	movx	a,@dptr
      00914E FC               [12] 2252 	mov	r4,a
      00914F 7B 00            [12] 2253 	mov	r3,#0x00
      009151 E5 37            [12] 2254 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009153 42 03            [12] 2255 	orl	ar3,a
                                   2256 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      009155 BC 00 12         [24] 2257 	cjne	r4,#0x00,00123$
      009158 BB 7C 0F         [24] 2258 	cjne	r3,#0x7c,00123$
                                   2259 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      00915B 12 38 5E         [24] 2260 	lcall	_ak820_outline_0138
      00915E 74 FF            [12] 2261 	mov	a,#0xff
      009160 F0               [24] 2262 	movx	@dptr,a
                                   2263 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      009161 0A               [12] 2264 	inc	r2
      009162 BA 00 01         [24] 2265 	cjne	r2,#0x00,00218$
      009165 0F               [12] 2266 	inc	r7
      009166                       2267 00218$:
      009166 EA               [12] 2268 	mov	a,r2
      009167 12 95 BE         [24] 2269 	lcall	_ak820_outline_0133
      00916A                       2270 00123$:
                                   2271 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      00916A 90 0B BE         [24] 2272 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_451
      00916D E0               [24] 2273 	movx	a,@dptr
      00916E 24 02            [12] 2274 	add	a,#0x02
      009170 F0               [24] 2275 	movx	@dptr,a
      009171 80 A9            [24] 2276 	sjmp	00122$
      009173                       2277 00120$:
                                   2278 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      009173 90 0B BA         [24] 2279 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      009176 12 37 FD         [24] 2280 	lcall	_ak820_outline_0056
      009179 74 40            [12] 2281 	mov	a,#0x40
      00917B 12 49 73         [24] 2282 	lcall	_ak820_outline_0141
      00917E 90 05 F6         [24] 2283 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      009181 12 4E 7D         [24] 2284 	lcall	_ak820_outline_0064
      009184 E4               [12] 2285 	clr	a
      009185 A3               [24] 2286 	inc	dptr
      009186 F0               [24] 2287 	movx	@dptr,a
      009187 90 05 F9         [24] 2288 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00918A E5 38            [12] 2289 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      00918C F0               [24] 2290 	movx	@dptr,a
      00918D E5 39            [12] 2291 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      00918F A3               [24] 2292 	inc	dptr
      009190 F0               [24] 2293 	movx	@dptr,a
      009191 12 38 6E         [24] 2294 	lcall	_ak820_outline_0162
                                   2295 ;	quantum/dynamic_keymap.c:584: }
      009194 02 47 42         [24] 2296 	ljmp	_ak820_eeprom_write_block_xdata
                                   2297 ;------------------------------------------------------------
                                   2298 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2299 ;------------------------------------------------------------
                                   2300 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2301 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2302 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_455'
                                   2303 ;------------------------------------------------------------
                                   2304 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2305 ;	-----------------------------------------
                                   2306 ;	 function keycode_at_keymap_location
                                   2307 ;	-----------------------------------------
      009197                       2308 _keycode_at_keymap_location:
      009197 E5 82            [12] 2309 	mov	a,dpl
      009199 90 0B C1         [24] 2310 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_455
      00919C F0               [24] 2311 	movx	@dptr,a
                                   2312 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      00919D E0               [24] 2313 	movx	a,@dptr
      00919E FF               [12] 2314 	mov	r7,a
      00919F BF 06 00         [24] 2315 	cjne	r7,#0x06,00128$
      0091A2                       2316 00128$:
      0091A2 50 22            [24] 2317 	jnc	00102$
      0091A4 90 0B BF         [24] 2318 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      0091A7 E0               [24] 2319 	movx	a,@dptr
      0091A8 FE               [12] 2320 	mov	r6,a
      0091A9 BE 10 00         [24] 2321 	cjne	r6,#0x10,00130$
      0091AC                       2322 00130$:
      0091AC 50 18            [24] 2323 	jnc	00102$
      0091AE 90 0B C0         [24] 2324 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      0091B1 E0               [24] 2325 	movx	a,@dptr
      0091B2 FD               [12] 2326 	mov	r5,a
      0091B3 BD 08 00         [24] 2327 	cjne	r5,#0x08,00132$
      0091B6                       2328 00132$:
      0091B6 50 0E            [24] 2329 	jnc	00102$
                                   2330 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      0091B8 90 0B 61         [24] 2331 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0091BB EE               [12] 2332 	mov	a,r6
      0091BC F0               [24] 2333 	movx	@dptr,a
      0091BD 90 0B 62         [24] 2334 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0091C0 12 41 83         [24] 2335 	lcall	_ak820_outline_0194
      0091C3 02 89 EE         [24] 2336 	ljmp	_dynamic_keymap_get_keycode
      0091C6                       2337 00102$:
                                   2338 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      0091C6 90 00 00         [24] 2339 	mov	dptr,#0x0000
                                   2340 ;	quantum/dynamic_keymap.c:591: }
      0091C9 22               [24] 2341 	ret
                                   2342 ;------------------------------------------------------------
                                   2343 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2344 ;------------------------------------------------------------
                                   2345 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2346 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2347 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_459'
                                   2348 ;------------------------------------------------------------
                                   2349 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2350 ;	-----------------------------------------
                                   2351 ;	 function keycode_at_encodermap_location
                                   2352 ;	-----------------------------------------
      0091CA                       2353 _keycode_at_encodermap_location:
      0091CA E5 82            [12] 2354 	mov	a,dpl
      0091CC 90 0B C4         [24] 2355 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_459
      0091CF F0               [24] 2356 	movx	@dptr,a
                                   2357 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      0091D0 E0               [24] 2358 	movx	a,@dptr
      0091D1 FF               [12] 2359 	mov	r7,a
      0091D2 BF 06 00         [24] 2360 	cjne	r7,#0x06,00120$
      0091D5                       2361 00120$:
      0091D5 50 1E            [24] 2362 	jnc	00102$
      0091D7 90 0B C2         [24] 2363 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0091DA E0               [24] 2364 	movx	a,@dptr
      0091DB FE               [12] 2365 	mov	r6,a
      0091DC BE 01 00         [24] 2366 	cjne	r6,#0x01,00122$
      0091DF                       2367 00122$:
      0091DF 50 14            [24] 2368 	jnc	00102$
                                   2369 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      0091E1 90 0B C3         [24] 2370 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0091E4 E0               [24] 2371 	movx	a,@dptr
      0091E5 FE               [12] 2372 	mov	r6,a
      0091E6 90 0B 6B         [24] 2373 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0091E9 E4               [12] 2374 	clr	a
      0091EA F0               [24] 2375 	movx	@dptr,a
      0091EB 90 0B 6C         [24] 2376 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0091EE EE               [12] 2377 	mov	a,r6
      0091EF F0               [24] 2378 	movx	@dptr,a
      0091F0 8F 82            [24] 2379 	mov	dpl, r7
      0091F2 02 8A AD         [24] 2380 	ljmp	_dynamic_keymap_get_encoder
      0091F5                       2381 00102$:
                                   2382 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      0091F5 90 00 00         [24] 2383 	mov	dptr,#0x0000
                                   2384 ;	quantum/dynamic_keymap.c:599: }
      0091F8 22               [24] 2385 	ret
                                   2386 ;------------------------------------------------------------
                                   2387 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2388 ;------------------------------------------------------------
                                   2389 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2390 ;	-----------------------------------------
                                   2391 ;	 function dynamic_keymap_macro_get_count
                                   2392 ;	-----------------------------------------
      0091F9                       2393 _dynamic_keymap_macro_get_count:
                                   2394 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      0091F9 75 82 10         [24] 2395 	mov	dpl, #0x10
                                   2396 ;	quantum/dynamic_keymap.c:604: }
      0091FC 22               [24] 2397 	ret
                                   2398 ;------------------------------------------------------------
                                   2399 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2400 ;------------------------------------------------------------
                                   2401 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2402 ;	-----------------------------------------
                                   2403 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2404 ;	-----------------------------------------
      0091FD                       2405 _dynamic_keymap_macro_get_buffer_size:
                                   2406 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      0091FD 90 20 00         [24] 2407 	mov	dptr,#0x2000
                                   2408 ;	quantum/dynamic_keymap.c:608: }
      009200 22               [24] 2409 	ret
                                   2410 ;------------------------------------------------------------
                                   2411 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2412 ;------------------------------------------------------------
                                   2413 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2414 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2415 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2416 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_467'
                                   2417 ;------------------------------------------------------------
                                   2418 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2419 ;	-----------------------------------------
                                   2420 ;	 function dynamic_keymap_macro_get_buffer
                                   2421 ;	-----------------------------------------
      009201                       2422 _dynamic_keymap_macro_get_buffer:
      009201 12 38 44         [24] 2423 	lcall	_ak820_outline_0109
      009204 90 0B CA         [24] 2424 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_467
      009207 12 38 49         [24] 2425 	lcall	_ak820_outline_0110
                                   2426 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      00920A 12 2B 2B         [24] 2427 	lcall	_ak820_macro_length
      00920D 12 49 6E         [24] 2428 	lcall	_ak820_outline_0139
      009210 90 0B CA         [24] 2429 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_467
      009213 12 38 14         [24] 2430 	lcall	_ak820_outline_0062
      009216 90 0B C5         [24] 2431 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      009219 E0               [24] 2432 	movx	a,@dptr
      00921A F5 3B            [12] 2433 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      00921C A3               [24] 2434 	inc	dptr
      00921D E0               [24] 2435 	movx	a,@dptr
      00921E F5 3C            [12] 2436 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      009220 90 0B C7         [24] 2437 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      009223 12 38 3E         [24] 2438 	lcall	_ak820_outline_0105
      009226 A3               [24] 2439 	inc	dptr
      009227 E0               [24] 2440 	movx	a,@dptr
      009228 FB               [12] 2441 	mov	r3,a
      009229 90 0B A2         [24] 2442 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00922C 12 4E 7D         [24] 2443 	lcall	_ak820_outline_0064
      00922F 90 0B A4         [24] 2444 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      009232 12 38 20         [24] 2445 	lcall	_ak820_outline_0078
      009235 90 0B A6         [24] 2446 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009238 E5 3B            [12] 2447 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      00923A F0               [24] 2448 	movx	@dptr,a
      00923B E5 3C            [12] 2449 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      00923D A3               [24] 2450 	inc	dptr
      00923E F0               [24] 2451 	movx	@dptr,a
      00923F 90 0B A8         [24] 2452 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009242 12 55 12         [24] 2453 	lcall	_ak820_outline_0168
      009245 EB               [12] 2454 	mov	a,r3
      009246 A3               [24] 2455 	inc	dptr
      009247 F0               [24] 2456 	movx	@dptr,a
      009248 90 08 00         [24] 2457 	mov	dptr,#0x0800
                                   2458 ;	quantum/dynamic_keymap.c:635: }
      00924B 02 8F 12         [24] 2459 	ljmp	_ak820_dynamic_read_buffer
                                   2460 ;------------------------------------------------------------
                                   2461 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2462 ;------------------------------------------------------------
                                   2463 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2464 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2465 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_469'
                                   2466 ;------------------------------------------------------------
                                   2467 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2468 ;	-----------------------------------------
                                   2469 ;	 function dynamic_keymap_macro_set_buffer
                                   2470 ;	-----------------------------------------
      00924E                       2471 _dynamic_keymap_macro_set_buffer:
      00924E 12 38 44         [24] 2472 	lcall	_ak820_outline_0109
      009251 90 0B D1         [24] 2473 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_469
      009254 12 38 49         [24] 2474 	lcall	_ak820_outline_0110
                                   2475 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      009257 90 0B D1         [24] 2476 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_469
      00925A 12 37 FD         [24] 2477 	lcall	_ak820_outline_0056
      00925D 90 0B CC         [24] 2478 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      009260 12 38 14         [24] 2479 	lcall	_ak820_outline_0062
      009263 90 0B CE         [24] 2480 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009266 12 54 F4         [24] 2481 	lcall	_ak820_outline_0093
      009269 90 05 7C         [24] 2482 	mov	dptr,#_ak820_macro_write_PARM_2
      00926C 12 38 20         [24] 2483 	lcall	_ak820_outline_0078
      00926F 90 05 7E         [24] 2484 	mov	dptr,#_ak820_macro_write_PARM_3
      009272 12 4E 8A         [24] 2485 	lcall	_ak820_outline_0142
      009275 EB               [12] 2486 	mov	a,r3
      009276 A3               [24] 2487 	inc	dptr
      009277 12 49 3E         [24] 2488 	lcall	_ak820_outline_0063
                                   2489 ;	quantum/dynamic_keymap.c:640: }
      00927A 02 2B 45         [24] 2490 	ljmp	_ak820_macro_write
                                   2491 ;------------------------------------------------------------
                                   2492 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2493 ;------------------------------------------------------------
                                   2494 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2495 ;	-----------------------------------------
                                   2496 ;	 function dynamic_keymap_macro_reset
                                   2497 ;	-----------------------------------------
      00927D                       2498 _dynamic_keymap_macro_reset:
                                   2499 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2500 ;	quantum/dynamic_keymap.c:666: }
      00927D 02 2E 64         [24] 2501 	ljmp	_ak820_macro_reset
                                   2502 ;------------------------------------------------------------
                                   2503 ;Allocation info for local variables in function 'decode_keycode'
                                   2504 ;------------------------------------------------------------
                                   2505 ;kc            Allocated with name '_decode_keycode_kc_10000_473'
                                   2506 ;------------------------------------------------------------
                                   2507 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2508 ;	-----------------------------------------
                                   2509 ;	 function decode_keycode
                                   2510 ;	-----------------------------------------
      009280                       2511 _decode_keycode:
      009280 12 38 44         [24] 2512 	lcall	_ak820_outline_0109
      009283 90 0B D3         [24] 2513 	mov	dptr,#_decode_keycode_kc_10000_473
      009286 12 38 49         [24] 2514 	lcall	_ak820_outline_0110
                                   2515 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      009289 90 0B D3         [24] 2516 	mov	dptr,#_decode_keycode_kc_10000_473
      00928C 12 37 C8         [24] 2517 	lcall	_ak820_outline_0009
      00928F C3               [12] 2518 	clr	c
      009290 E4               [12] 2519 	clr	a
      009291 9C               [12] 2520 	subb	a,r4
      009292 74 FF            [12] 2521 	mov	a,#0xff
      009294 9D               [12] 2522 	subb	a,r5
      009295 50 08            [24] 2523 	jnc	00102$
                                   2524 ;	free result
                                   2525 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      009297 8C 05            [24] 2526 	mov	ar5,r4
      009299 7C 00            [12] 2527 	mov	r4,#0x00
      00929B 12 38 54         [24] 2528 	lcall	_ak820_outline_0128
      00929E 22               [24] 2529 	ret
      00929F                       2530 00102$:
                                   2531 ;	quantum/dynamic_keymap.c:672: return kc;
      00929F 12 49 5D         [24] 2532 	lcall	_ak820_outline_0120
                                   2533 ;	quantum/dynamic_keymap.c:673: }
      0092A2 22               [24] 2534 	ret
                                   2535 ;------------------------------------------------------------
                                   2536 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2537 ;------------------------------------------------------------
                                   2538 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_476'
                                   2539 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_477'
                                   2540 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_482'
                                   2541 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_483'
                                   2542 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_489'
                                   2543 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_507'
                                   2544 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_511'
                                   2545 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_511'
                                   2546 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_513'
                                   2547 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_515'
                                   2548 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_519'
                                   2549 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_521'
                                   2550 ;------------------------------------------------------------
                                   2551 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2552 ;	-----------------------------------------
                                   2553 ;	 function dynamic_keymap_macro_send
                                   2554 ;	-----------------------------------------
      0092A3                       2555 _dynamic_keymap_macro_send:
      0092A3 E5 82            [12] 2556 	mov	a,dpl
      0092A5 90 0B D5         [24] 2557 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_476
      0092A8 F0               [24] 2558 	movx	@dptr,a
                                   2559 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      0092A9 90 0B D6         [24] 2560 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_477
      0092AC E0               [24] 2561 	movx	a,@dptr
      0092AD 60 01            [24] 2562 	jz	00102$
      0092AF 22               [24] 2563 	ret
      0092B0                       2564 00102$:
                                   2565 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      0092B0 90 0B D5         [24] 2566 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_476
      0092B3 E0               [24] 2567 	movx	a,@dptr
      0092B4 FF               [12] 2568 	mov	r7,a
      0092B5 BF 10 00         [24] 2569 	cjne	r7,#0x10,00422$
      0092B8                       2570 00422$:
      0092B8 40 01            [24] 2571 	jc	00104$
                                   2572 ;	quantum/dynamic_keymap.c:683: return;
      0092BA 22               [24] 2573 	ret
      0092BB                       2574 00104$:
                                   2575 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      0092BB C0 07            [24] 2576 	push	ar7
      0092BD 12 2A F2         [24] 2577 	lcall	_ak820_macro_ready
      0092C0 E5 82            [12] 2578 	mov	a, dpl
      0092C2 D0 07            [24] 2579 	pop	ar7
      0092C4 70 01            [24] 2580 	jnz	00106$
      0092C6 22               [24] 2581 	ret
      0092C7                       2582 00106$:
                                   2583 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      0092C7 90 0B D7         [24] 2584 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      0092CA E4               [12] 2585 	clr	a
      0092CB F0               [24] 2586 	movx	@dptr,a
      0092CC 74 08            [12] 2587 	mov	a,#0x08
      0092CE A3               [24] 2588 	inc	dptr
      0092CF F0               [24] 2589 	movx	@dptr,a
                                   2590 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      0092D0 C0 07            [24] 2591 	push	ar7
      0092D2 12 2B 2B         [24] 2592 	lcall	_ak820_macro_length
      0092D5 AD 82            [24] 2593 	mov	r5, dpl
      0092D7 AE 83            [24] 2594 	mov	r6, dph
      0092D9 D0 07            [24] 2595 	pop	ar7
      0092DB 74 08            [12] 2596 	mov	a,#0x08
      0092DD 2E               [12] 2597 	add	a, r6
      0092DE FE               [12] 2598 	mov	r6,a
                                   2599 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      0092DF 7B 00            [12] 2600 	mov	r3,#0x00
      0092E1 7C 08            [12] 2601 	mov	r4,#0x08
      0092E3                       2602 00111$:
      0092E3 EF               [12] 2603 	mov	a,r7
      0092E4 60 31            [24] 2604 	jz	00113$
                                   2605 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      0092E6 EB               [12] 2606 	mov	a,r3
      0092E7 B5 05 05         [24] 2607 	cjne	a,ar5,00108$
      0092EA EC               [12] 2608 	mov	a,r4
      0092EB B5 06 01         [24] 2609 	cjne	a,ar6,00108$
                                   2610 ;	quantum/dynamic_keymap.c:717: return;
      0092EE 22               [24] 2611 	ret
      0092EF                       2612 00108$:
                                   2613 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      0092EF 8B 01            [24] 2614 	mov	ar1,r3
      0092F1 8C 02            [24] 2615 	mov	ar2,r4
      0092F3 8A 00            [24] 2616 	mov	ar0,r2
      0092F5 7A 00            [12] 2617 	mov	r2,#0x00
      0092F7 89 82            [24] 2618 	mov	dpl, r1
      0092F9 88 83            [24] 2619 	mov	dph, r0
      0092FB 8A F0            [24] 2620 	mov	b, r2
      0092FD 12 46 7B         [24] 2621 	lcall	_eeprom_read_byte
      009300 E5 82            [12] 2622 	mov	a, dpl
      009302 70 06            [24] 2623 	jnz	00110$
                                   2624 ;	quantum/dynamic_keymap.c:720: --id;
      009304 1F               [12] 2625 	dec	r7
      009305 90 0B D5         [24] 2626 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_476
      009308 EF               [12] 2627 	mov	a,r7
      009309 F0               [24] 2628 	movx	@dptr,a
      00930A                       2629 00110$:
                                   2630 ;	quantum/dynamic_keymap.c:722: ++p;
      00930A 0B               [12] 2631 	inc	r3
      00930B BB 00 01         [24] 2632 	cjne	r3,#0x00,00429$
      00930E 0C               [12] 2633 	inc	r4
      00930F                       2634 00429$:
      00930F 90 0B D7         [24] 2635 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      009312 12 38 2C         [24] 2636 	lcall	_ak820_outline_0095
      009315 80 CC            [24] 2637 	sjmp	00111$
      009317                       2638 00113$:
                                   2639 ;	quantum/dynamic_keymap.c:728: sending = true;
      009317 90 0B D6         [24] 2640 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_477
      00931A 74 01            [12] 2641 	mov	a,#0x01
      00931C F0               [24] 2642 	movx	@dptr,a
                                   2643 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      00931D 12 95 D6         [24] 2644 	lcall	_ak820_outline_0173
      009320 90 09 E9         [24] 2645 	mov	dptr,#_ak820_macro_cancelled
      009323 F0               [24] 2646 	movx	@dptr,a
                                   2647 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      009324 90 0B D9         [24] 2648 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009327 F0               [24] 2649 	movx	@dptr,a
      009328 90 0B DA         [24] 2650 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      00932B F0               [24] 2651 	movx	@dptr,a
      00932C 90 0B DB         [24] 2652 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0002)
      00932F F0               [24] 2653 	movx	@dptr,a
      009330 90 0B DC         [24] 2654 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0003)
      009333 F0               [24] 2655 	movx	@dptr,a
                                   2656 ;	quantum/dynamic_keymap.c:738: while (p < end
      009334                       2657 00167$:
                                   2658 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      009334 90 0B D7         [24] 2659 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      009337 E0               [24] 2660 	movx	a,@dptr
      009338 FC               [12] 2661 	mov	r4,a
      009339 A3               [24] 2662 	inc	dptr
      00933A E0               [24] 2663 	movx	a,@dptr
      00933B FF               [12] 2664 	mov	r7,a
      00933C C3               [12] 2665 	clr	c
      00933D EC               [12] 2666 	mov	a,r4
      00933E 9D               [12] 2667 	subb	a,r5
      00933F EF               [12] 2668 	mov	a,r7
      009340 9E               [12] 2669 	subb	a,r6
      009341 40 02            [24] 2670 	jc	00430$
      009343 A1 48            [12] 2671 	ajmp	00169$
      009345                       2672 00430$:
      009345 90 09 E9         [24] 2673 	mov	dptr,#_ak820_macro_cancelled
      009348 E0               [24] 2674 	movx	a,@dptr
      009349 60 02            [24] 2675 	jz	00431$
      00934B A1 48            [12] 2676 	ajmp	00169$
      00934D                       2677 00431$:
                                   2678 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00934D 8C 02            [24] 2679 	mov	ar2,r4
      00934F 8F 03            [24] 2680 	mov	ar3,r7
      009351 90 0B D7         [24] 2681 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      009354 74 01            [12] 2682 	mov	a,#0x01
      009356 2C               [12] 2683 	add	a, r4
      009357 F0               [24] 2684 	movx	@dptr,a
      009358 E4               [12] 2685 	clr	a
      009359 3F               [12] 2686 	addc	a, r7
      00935A A3               [24] 2687 	inc	dptr
      00935B F0               [24] 2688 	movx	@dptr,a
      00935C 7F 00            [12] 2689 	mov	r7,#0x00
      00935E 12 49 7F         [24] 2690 	lcall	_ak820_outline_0148
      009361 8F F0            [24] 2691 	mov	b, r7
      009363 12 46 7B         [24] 2692 	lcall	_eeprom_read_byte
      009366 AF 82            [24] 2693 	mov	r7, dpl
      009368 90 0B D9         [24] 2694 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      00936B EF               [12] 2695 	mov	a,r7
      00936C F0               [24] 2696 	movx	@dptr,a
                                   2697 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      00936D 90 0B DA         [24] 2698 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      009370 E4               [12] 2699 	clr	a
      009371 F0               [24] 2700 	movx	@dptr,a
                                   2701 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      009372 90 0B D9         [24] 2702 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009375 E0               [24] 2703 	movx	a,@dptr
      009376 70 02            [24] 2704 	jnz	00432$
      009378 A1 48            [12] 2705 	ajmp	00169$
      00937A                       2706 00432$:
                                   2707 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      00937A 90 0B D9         [24] 2708 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      00937D E0               [24] 2709 	movx	a,@dptr
      00937E FF               [12] 2710 	mov	r7,a
      00937F BF 01 02         [24] 2711 	cjne	r7,#0x01,00433$
      009382 80 02            [24] 2712 	sjmp	00434$
      009384                       2713 00433$:
      009384 A1 2B            [12] 2714 	ajmp	00164$
      009386                       2715 00434$:
                                   2716 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009386 12 95 50         [24] 2717 	lcall	_ak820_outline_0000
      009389 12 46 7B         [24] 2718 	lcall	_eeprom_read_byte
      00938C AF 82            [24] 2719 	mov	r7, dpl
      00938E 90 0B DA         [24] 2720 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      009391 EF               [12] 2721 	mov	a,r7
      009392 F0               [24] 2722 	movx	@dptr,a
                                   2723 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      009393 EF               [12] 2724 	mov	a,r7
      009394 70 02            [24] 2725 	jnz	00435$
      009396 A1 48            [12] 2726 	ajmp	00169$
      009398                       2727 00435$:
                                   2728 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      009398 12 95 9D         [24] 2729 	lcall	_ak820_outline_0096
      00939B BF 01 02         [24] 2730 	cjne	r7,#0x01,00436$
      00939E 80 12            [24] 2731 	sjmp	00151$
      0093A0                       2732 00436$:
      0093A0 12 95 9D         [24] 2733 	lcall	_ak820_outline_0096
      0093A3 BF 02 02         [24] 2734 	cjne	r7,#0x02,00437$
      0093A6 80 0A            [24] 2735 	sjmp	00151$
      0093A8                       2736 00437$:
      0093A8 12 95 9D         [24] 2737 	lcall	_ak820_outline_0096
      0093AB BF 03 02         [24] 2738 	cjne	r7,#0x03,00438$
      0093AE 80 02            [24] 2739 	sjmp	00439$
      0093B0                       2740 00438$:
      0093B0 81 11            [12] 2741 	ajmp	00152$
      0093B2                       2742 00439$:
      0093B2                       2743 00151$:
                                   2744 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0093B2 12 95 50         [24] 2745 	lcall	_ak820_outline_0000
      0093B5 12 46 7B         [24] 2746 	lcall	_eeprom_read_byte
      0093B8 12 95 EE         [24] 2747 	lcall	_ak820_outline_0188
                                   2748 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      0093BB 70 02            [24] 2749 	jnz	00440$
      0093BD 61 34            [12] 2750 	ajmp	00167$
      0093BF                       2751 00440$:
                                   2752 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      0093BF 12 95 9D         [24] 2753 	lcall	_ak820_outline_0096
      0093C2 BF 01 03         [24] 2754 	cjne	r7,#0x01,00441$
      0093C5 D3               [12] 2755 	setb	c
      0093C6 80 01            [24] 2756 	sjmp	00442$
      0093C8                       2757 00441$:
      0093C8 C3               [12] 2758 	clr	c
      0093C9                       2759 00442$:
      0093C9 92 25            [24] 2760 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0093CB 90 09 E8         [24] 2761 	mov	dptr,#_ak820_macro_primitive
      0093CE B3               [12] 2762 	cpl	c
      0093CF E4               [12] 2763 	clr	a
      0093D0 33               [12] 2764 	rlc	a
      0093D1 F0               [24] 2765 	movx	@dptr,a
                                   2766 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0093D2 12 95 9D         [24] 2767 	lcall	_ak820_outline_0096
      0093D5 BF 01 10         [24] 2768 	cjne	r7,#0x01,00122$
      0093D8 12 95 CF         [24] 2769 	lcall	_ak820_outline_0158
      0093DB C0 06            [24] 2770 	push	ar6
      0093DD C0 05            [24] 2771 	push	ar5
      0093DF 12 7B 51         [24] 2772 	lcall	_tap_code
      0093E2 D0 05            [24] 2773 	pop	ar5
      0093E4 D0 06            [24] 2774 	pop	ar6
      0093E6 80 24            [24] 2775 	sjmp	00123$
      0093E8                       2776 00122$:
                                   2777 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0093E8 12 95 9D         [24] 2778 	lcall	_ak820_outline_0096
      0093EB BF 02 10         [24] 2779 	cjne	r7,#0x02,00119$
      0093EE 12 95 CF         [24] 2780 	lcall	_ak820_outline_0158
      0093F1 C0 06            [24] 2781 	push	ar6
      0093F3 C0 05            [24] 2782 	push	ar5
      0093F5 12 7A 53         [24] 2783 	lcall	_register_code
      0093F8 D0 05            [24] 2784 	pop	ar5
      0093FA D0 06            [24] 2785 	pop	ar6
      0093FC 80 0E            [24] 2786 	sjmp	00123$
      0093FE                       2787 00119$:
                                   2788 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      0093FE 12 95 CF         [24] 2789 	lcall	_ak820_outline_0158
      009401 C0 06            [24] 2790 	push	ar6
      009403 C0 05            [24] 2791 	push	ar5
      009405 12 7A BD         [24] 2792 	lcall	_unregister_code
      009408 D0 05            [24] 2793 	pop	ar5
      00940A D0 06            [24] 2794 	pop	ar6
      00940C                       2795 00123$:
                                   2796 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      00940C 12 95 D6         [24] 2797 	lcall	_ak820_outline_0173
      00940F 61 34            [12] 2798 	ajmp	00167$
      009411                       2799 00152$:
                                   2800 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      009411 12 95 9D         [24] 2801 	lcall	_ak820_outline_0096
      009414 BF 05 02         [24] 2802 	cjne	r7,#0x05,00447$
      009417 80 12            [24] 2803 	sjmp	00146$
      009419                       2804 00447$:
      009419 12 95 9D         [24] 2805 	lcall	_ak820_outline_0096
      00941C BF 06 02         [24] 2806 	cjne	r7,#0x06,00448$
      00941F 80 0A            [24] 2807 	sjmp	00146$
      009421                       2808 00448$:
      009421 12 95 9D         [24] 2809 	lcall	_ak820_outline_0096
      009424 BF 07 02         [24] 2810 	cjne	r7,#0x07,00449$
      009427 80 02            [24] 2811 	sjmp	00450$
      009429                       2812 00449$:
      009429 81 CD            [12] 2813 	ajmp	00147$
      00942B                       2814 00450$:
      00942B                       2815 00146$:
                                   2816 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00942B 12 95 50         [24] 2817 	lcall	_ak820_outline_0000
      00942E 12 46 7B         [24] 2818 	lcall	_eeprom_read_byte
      009431 12 95 EE         [24] 2819 	lcall	_ak820_outline_0188
                                   2820 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      009434 70 02            [24] 2821 	jnz	00451$
      009436 61 34            [12] 2822 	ajmp	00167$
      009438                       2823 00451$:
                                   2824 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009438 12 95 50         [24] 2825 	lcall	_ak820_outline_0000
      00943B 12 46 7B         [24] 2826 	lcall	_eeprom_read_byte
      00943E AF 82            [24] 2827 	mov	r7, dpl
      009440 90 0B DC         [24] 2828 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0003)
      009443 EF               [12] 2829 	mov	a,r7
      009444 F0               [24] 2830 	movx	@dptr,a
                                   2831 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      009445 EF               [12] 2832 	mov	a,r7
      009446 70 02            [24] 2833 	jnz	00452$
      009448 61 34            [12] 2834 	ajmp	00167$
      00944A                       2835 00452$:
                                   2836 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      00944A 90 0B DB         [24] 2837 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0002)
      00944D E0               [24] 2838 	movx	a,@dptr
      00944E FF               [12] 2839 	mov	r7,a
      00944F 90 0B DC         [24] 2840 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0003)
      009452 E0               [24] 2841 	movx	a,@dptr
      009453 FB               [12] 2842 	mov	r3,a
      009454 E4               [12] 2843 	clr	a
      009455 FC               [12] 2844 	mov	r4,a
      009456 FA               [12] 2845 	mov	r2,a
      009457 EF               [12] 2846 	mov	a,r7
      009458 42 04            [12] 2847 	orl	ar4,a
      00945A EA               [12] 2848 	mov	a,r2
      00945B 42 03            [12] 2849 	orl	ar3,a
                                   2850 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      00945D 12 49 9F         [24] 2851 	lcall	_ak820_outline_0189
      009460 C0 06            [24] 2852 	push	ar6
      009462 C0 05            [24] 2853 	push	ar5
      009464 51 80            [12] 2854 	acall	_decode_keycode
      009466 AC 82            [24] 2855 	mov	r4, dpl
      009468 AF 83            [24] 2856 	mov	r7, dph
      00946A D0 05            [24] 2857 	pop	ar5
      00946C D0 06            [24] 2858 	pop	ar6
                                   2859 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00946E 90 0B DA         [24] 2860 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      009471 E0               [24] 2861 	movx	a,@dptr
      009472 FB               [12] 2862 	mov	r3,a
      009473 BB 05 03         [24] 2863 	cjne	r3,#0x05,00453$
      009476 D3               [12] 2864 	setb	c
      009477 80 01            [24] 2865 	sjmp	00454$
      009479                       2866 00453$:
      009479 C3               [12] 2867 	clr	c
      00947A                       2868 00454$:
      00947A 92 25            [24] 2869 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00947C 90 09 E8         [24] 2870 	mov	dptr,#_ak820_macro_primitive
      00947F B3               [12] 2871 	cpl	c
      009480 E4               [12] 2872 	clr	a
      009481 33               [12] 2873 	rlc	a
      009482 F0               [24] 2874 	movx	@dptr,a
                                   2875 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      009483 90 0B DA         [24] 2876 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      009486 E0               [24] 2877 	movx	a,@dptr
      009487 FB               [12] 2878 	mov	r3,a
      009488 BB 05 02         [24] 2879 	cjne	r3,#0x05,00455$
      00948B 80 0A            [24] 2880 	sjmp	00126$
      00948D                       2881 00455$:
      00948D BB 06 02         [24] 2882 	cjne	r3,#0x06,00456$
      009490 80 16            [24] 2883 	sjmp	00127$
      009492                       2884 00456$:
                                   2885 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      009492 BB 07 33         [24] 2886 	cjne	r3,#0x07,00129$
      009495 80 22            [24] 2887 	sjmp	00128$
      009497                       2888 00126$:
                                   2889 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      009497 8C 82            [24] 2890 	mov	dpl, r4
      009499 8F 83            [24] 2891 	mov	dph, r7
      00949B C0 06            [24] 2892 	push	ar6
      00949D C0 05            [24] 2893 	push	ar5
      00949F 12 B9 52         [24] 2894 	lcall	_vial_keycode_tap
      0094A2 D0 05            [24] 2895 	pop	ar5
      0094A4 D0 06            [24] 2896 	pop	ar6
                                   2897 ;	quantum/dynamic_keymap.c:795: break;
                                   2898 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      0094A6 80 20            [24] 2899 	sjmp	00129$
      0094A8                       2900 00127$:
                                   2901 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      0094A8 8C 82            [24] 2902 	mov	dpl, r4
      0094AA 8F 83            [24] 2903 	mov	dph, r7
      0094AC C0 06            [24] 2904 	push	ar6
      0094AE C0 05            [24] 2905 	push	ar5
      0094B0 12 B8 87         [24] 2906 	lcall	_vial_keycode_down
      0094B3 D0 05            [24] 2907 	pop	ar5
      0094B5 D0 06            [24] 2908 	pop	ar6
                                   2909 ;	quantum/dynamic_keymap.c:798: break;
                                   2910 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      0094B7 80 0F            [24] 2911 	sjmp	00129$
      0094B9                       2912 00128$:
                                   2913 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      0094B9 8C 82            [24] 2914 	mov	dpl, r4
      0094BB 8F 83            [24] 2915 	mov	dph, r7
      0094BD C0 06            [24] 2916 	push	ar6
      0094BF C0 05            [24] 2917 	push	ar5
      0094C1 12 B8 ED         [24] 2918 	lcall	_vial_keycode_up
      0094C4 D0 05            [24] 2919 	pop	ar5
      0094C6 D0 06            [24] 2920 	pop	ar6
                                   2921 ;	quantum/dynamic_keymap.c:802: }
      0094C8                       2922 00129$:
                                   2923 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      0094C8 12 95 D6         [24] 2924 	lcall	_ak820_outline_0173
      0094CB 61 34            [12] 2925 	ajmp	00167$
      0094CD                       2926 00147$:
                                   2927 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      0094CD 12 95 9D         [24] 2928 	lcall	_ak820_outline_0096
      0094D0 BF 04 02         [24] 2929 	cjne	r7,#0x04,00458$
      0094D3 80 02            [24] 2930 	sjmp	00459$
      0094D5                       2931 00458$:
      0094D5 61 34            [12] 2932 	ajmp	00167$
      0094D7                       2933 00459$:
                                   2934 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0094D7 12 95 50         [24] 2935 	lcall	_ak820_outline_0000
      0094DA 12 46 7B         [24] 2936 	lcall	_eeprom_read_byte
      0094DD AF 82            [24] 2937 	mov	r7, dpl
                                   2938 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0094DF 90 0B D7         [24] 2939 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      0094E2 12 38 63         [24] 2940 	lcall	_ak820_outline_0145
      0094E5 90 0B D7         [24] 2941 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      0094E8 74 01            [12] 2942 	mov	a,#0x01
      0094EA 2B               [12] 2943 	add	a, r3
      0094EB F0               [24] 2944 	movx	@dptr,a
      0094EC E4               [12] 2945 	clr	a
      0094ED 3C               [12] 2946 	addc	a, r4
      0094EE A3               [24] 2947 	inc	dptr
      0094EF F0               [24] 2948 	movx	@dptr,a
      0094F0 7A 00            [12] 2949 	mov	r2,#0x00
      0094F2 12 33 FC         [24] 2950 	lcall	_ak820_outline_0127
      0094F5 8A F0            [24] 2951 	mov	b, r2
      0094F7 12 46 7B         [24] 2952 	lcall	_eeprom_read_byte
      0094FA AC 82            [24] 2953 	mov	r4, dpl
                                   2954 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      0094FC EF               [12] 2955 	mov	a,r7
      0094FD 60 49            [24] 2956 	jz	00169$
      0094FF EC               [12] 2957 	mov	a,r4
      009500 60 46            [24] 2958 	jz	00169$
                                   2959 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      009502 1F               [12] 2960 	dec	r7
      009503 1C               [12] 2961 	dec	r4
      009504 EC               [12] 2962 	mov	a,r4
      009505 75 F0 FF         [24] 2963 	mov	b,#0xff
      009508 A4               [48] 2964 	mul	ab
      009509 FC               [12] 2965 	mov	r4,a
      00950A AB F0            [24] 2966 	mov	r3,b
      00950C 7A 00            [12] 2967 	mov	r2,#0x00
      00950E EC               [12] 2968 	mov	a,r4
      00950F 2F               [12] 2969 	add	a, r7
      009510 FC               [12] 2970 	mov	r4,a
      009511 EB               [12] 2971 	mov	a,r3
      009512 3A               [12] 2972 	addc	a, r2
      009513 FB               [12] 2973 	mov	r3,a
                                   2974 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      009514                       2975 00141$:
      009514 8C 02            [24] 2976 	mov	ar2,r4
      009516 8B 07            [24] 2977 	mov	ar7,r3
      009518 1C               [12] 2978 	dec	r4
      009519 BC FF 01         [24] 2979 	cjne	r4,#0xff,00462$
      00951C 1B               [12] 2980 	dec	r3
      00951D                       2981 00462$:
      00951D EA               [12] 2982 	mov	a,r2
      00951E 4F               [12] 2983 	orl	a,r7
      00951F 70 02            [24] 2984 	jnz	00463$
      009521 61 34            [12] 2985 	ajmp	00167$
      009523                       2986 00463$:
      009523 90 00 01         [24] 2987 	mov	dptr,#0x0001
      009526 12 5E 7F         [24] 2988 	lcall	_mDelaymS
      009529 80 E9            [24] 2989 	sjmp	00141$
      00952B                       2990 00164$:
                                   2991 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      00952B 90 0B D9         [24] 2992 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      00952E E0               [24] 2993 	movx	a,@dptr
      00952F FF               [12] 2994 	mov	r7,a
      009530 BF 80 00         [24] 2995 	cjne	r7,#0x80,00464$
      009533                       2996 00464$:
      009533 50 13            [24] 2997 	jnc	00169$
                                   2998 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      009535 90 0B D9         [24] 2999 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009538 E0               [24] 3000 	movx	a,@dptr
      009539 F5 82            [12] 3001 	mov	dpl,a
      00953B C0 06            [24] 3002 	push	ar6
      00953D C0 05            [24] 3003 	push	ar5
      00953F 12 AB 63         [24] 3004 	lcall	_send_char
      009542 D0 05            [24] 3005 	pop	ar5
      009544 D0 06            [24] 3006 	pop	ar6
                                   3007 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009546 61 34            [12] 3008 	ajmp	00167$
      009548                       3009 00169$:
                                   3010 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      009548 12 95 D6         [24] 3011 	lcall	_ak820_outline_0173
                                   3012 ;	quantum/dynamic_keymap.c:837: sending = false;
      00954B 90 0B D6         [24] 3013 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_477
      00954E F0               [24] 3014 	movx	@dptr,a
                                   3015 ;	quantum/dynamic_keymap.c:839: }
      00954F 22               [24] 3016 	ret
                                   3017 	.area CSEG    (CODE)
                                   3018 	.area CONST   (CODE)
                                   3019 	.area XINIT   (CODE)
                                   3020 	.area CABS    (ABS,CODE)
                                   3021 
                                   3022 ; Experimental exact instruction outlining.
                                   3023 	.globl _ak820_outline_0000
                                   3024 	.globl _ak820_outline_0007
                                   3025 	.globl _ak820_outline_0009
                                   3026 	.globl _ak820_outline_0012
                                   3027 	.globl _ak820_outline_0013
                                   3028 	.globl _ak820_outline_0027
                                   3029 	.globl _ak820_outline_0033
                                   3030 	.globl _ak820_outline_0041
                                   3031 	.globl _ak820_outline_0049
                                   3032 	.globl _ak820_outline_0056
                                   3033 	.globl _ak820_outline_0062
                                   3034 	.globl _ak820_outline_0063
                                   3035 	.globl _ak820_outline_0064
                                   3036 	.globl _ak820_outline_0074
                                   3037 	.globl _ak820_outline_0076
                                   3038 	.globl _ak820_outline_0078
                                   3039 	.globl _ak820_outline_0082
                                   3040 	.globl _ak820_outline_0093
                                   3041 	.globl _ak820_outline_0095
                                   3042 	.globl _ak820_outline_0096
                                   3043 	.globl _ak820_outline_0101
                                   3044 	.globl _ak820_outline_0105
                                   3045 	.globl _ak820_outline_0109
                                   3046 	.globl _ak820_outline_0110
                                   3047 	.globl _ak820_outline_0114
                                   3048 	.globl _ak820_outline_0118
                                   3049 	.globl _ak820_outline_0120
                                   3050 	.globl _ak820_outline_0124
                                   3051 	.globl _ak820_outline_0126
                                   3052 	.globl _ak820_outline_0127
                                   3053 	.globl _ak820_outline_0128
                                   3054 	.globl _ak820_outline_0129
                                   3055 	.globl _ak820_outline_0133
                                   3056 	.globl _ak820_outline_0138
                                   3057 	.globl _ak820_outline_0139
                                   3058 	.globl _ak820_outline_0140
                                   3059 	.globl _ak820_outline_0141
                                   3060 	.globl _ak820_outline_0142
                                   3061 	.globl _ak820_outline_0145
                                   3062 	.globl _ak820_outline_0147
                                   3063 	.globl _ak820_outline_0148
                                   3064 	.globl _ak820_outline_0154
                                   3065 	.globl _ak820_outline_0155
                                   3066 	.globl _ak820_outline_0158
                                   3067 	.globl _ak820_outline_0162
                                   3068 	.globl _ak820_outline_0163
                                   3069 	.globl _ak820_outline_0166
                                   3070 	.globl _ak820_outline_0168
                                   3071 	.globl _ak820_outline_0173
                                   3072 	.globl _ak820_outline_0184
                                   3073 	.globl _ak820_outline_0185
                                   3074 	.globl _ak820_outline_0188
                                   3075 	.globl _ak820_outline_0189
                                   3076 	.globl _ak820_outline_0194
                                   3077 	.globl _ak820_outline_0195
                                   3078 
                                   3079 	.area CSEG (CODE)
                                   3080 ; function ak820_outline_0000
      009550                       3081 _ak820_outline_0000:
      009550 90 0B D7         [24] 3082 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      009553 E0               [24] 3083 	movx	a,@dptr
      009554 FC               [12] 3084 	mov	r4,a
      009555 A3               [24] 3085 	inc	dptr
      009556 E0               [24] 3086 	movx	a,@dptr
      009557 FF               [12] 3087 	mov	r7,a
      009558 90 0B D7         [24] 3088 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      00955B 74 01            [12] 3089 	mov	a,#0x01
      00955D 2C               [12] 3090 	add	a,r4
      00955E F0               [24] 3091 	movx	@dptr,a
      00955F E4               [12] 3092 	clr	a
      009560 3F               [12] 3093 	addc	a,r7
      009561 A3               [24] 3094 	inc	dptr
      009562 F0               [24] 3095 	movx	@dptr,a
      009563 7B 00            [12] 3096 	mov	r3,#0x00
      009565 8C 82            [24] 3097 	mov	dpl,r4
      009567 8F 83            [24] 3098 	mov	dph,r7
      009569 8B F0            [24] 3099 	mov	b,r3
      00956B 22               [24] 3100 	ret
                                   3101 
                                   3102 	.area CSEG (CODE)
                                   3103 ; function ak820_outline_0027
      00956C                       3104 _ak820_outline_0027:
      00956C 2D               [12] 3105 	add	a,r5
      00956D F9               [12] 3106 	mov	r1,a
      00956E E4               [12] 3107 	clr	a
      00956F 3E               [12] 3108 	addc	a,r6
      009570 FA               [12] 3109 	mov	r2,a
      009571 8F 03            [24] 3110 	mov	ar3,r7
      009573 89 82            [24] 3111 	mov	dpl,r1
      009575 8A 83            [24] 3112 	mov	dph,r2
      009577 8B F0            [24] 3113 	mov	b,r3
      009579 22               [24] 3114 	ret
                                   3115 
                                   3116 	.area CSEG (CODE)
                                   3117 ; function ak820_outline_0041
      00957A                       3118 _ak820_outline_0041:
      00957A 90 0E 37         [24] 3119 	mov	dptr,#_memset_PARM_2
      00957D E4               [12] 3120 	clr	a
      00957E F0               [24] 3121 	movx	@dptr,a
      00957F 90 0E 38         [24] 3122 	mov	dptr,#_memset_PARM_3
      009582 74 0A            [12] 3123 	mov	a,#0x0a
      009584 F0               [24] 3124 	movx	@dptr,a
      009585 E4               [12] 3125 	clr	a
      009586 A3               [24] 3126 	inc	dptr
      009587 F0               [24] 3127 	movx	@dptr,a
      009588 8E 82            [24] 3128 	mov	dpl,r6
      00958A 8F 83            [24] 3129 	mov	dph,r7
      00958C 8D F0            [24] 3130 	mov	b,r5
      00958E 22               [24] 3131 	ret
                                   3132 
                                   3133 	.area CSEG (CODE)
                                   3134 ; function ak820_outline_0082
      00958F                       3135 _ak820_outline_0082:
      00958F ED               [12] 3136 	mov	a,r5
      009590 75 F0 0A         [24] 3137 	mov	b,#0x0a
      009593 A4               [48] 3138 	mul	ab
      009594 24 58            [12] 3139 	add	a,#0x58
      009596 FC               [12] 3140 	mov	r4,a
      009597 74 06            [12] 3141 	mov	a,#0x06
      009599 35 F0            [12] 3142 	addc	a,b
      00959B FD               [12] 3143 	mov	r5,a
      00959C 22               [24] 3144 	ret
                                   3145 
                                   3146 	.area CSEG (CODE)
                                   3147 ; function ak820_outline_0096
      00959D                       3148 _ak820_outline_0096:
      00959D 90 0B DA         [24] 3149 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489+0x0001)
      0095A0 E0               [24] 3150 	movx	a,@dptr
      0095A1 FF               [12] 3151 	mov	r7,a
      0095A2 22               [24] 3152 	ret
                                   3153 
                                   3154 	.area CSEG (CODE)
                                   3155 ; function ak820_outline_0101
      0095A3                       3156 _ak820_outline_0101:
      0095A3 90 0B 5E         [24] 3157 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0095A6 EE               [12] 3158 	mov	a,r6
      0095A7 F0               [24] 3159 	movx	@dptr,a
      0095A8 90 0B 5F         [24] 3160 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0095AB ED               [12] 3161 	mov	a,r5
      0095AC F0               [24] 3162 	movx	@dptr,a
      0095AD 8F 82            [24] 3163 	mov	dpl,r7
      0095AF 22               [24] 3164 	ret
                                   3165 
                                   3166 	.area CSEG (CODE)
                                   3167 ; function ak820_outline_0114
      0095B0                       3168 _ak820_outline_0114:
      0095B0 74 0A            [12] 3169 	mov	a,#0x0a
      0095B2 F0               [24] 3170 	movx	@dptr,a
      0095B3 E4               [12] 3171 	clr	a
      0095B4 A3               [24] 3172 	inc	dptr
      0095B5 F0               [24] 3173 	movx	@dptr,a
      0095B6 22               [24] 3174 	ret
                                   3175 
                                   3176 	.area CSEG (CODE)
                                   3177 ; function ak820_outline_0118
      0095B7                       3178 _ak820_outline_0118:
      0095B7 AD 82            [24] 3179 	mov	r5,dpl
      0095B9 AE 83            [24] 3180 	mov	r6,dph
      0095BB AF F0            [24] 3181 	mov	r7,b
      0095BD 22               [24] 3182 	ret
                                   3183 
                                   3184 	.area CSEG (CODE)
                                   3185 ; function ak820_outline_0133
      0095BE                       3186 _ak820_outline_0133:
      0095BE 28               [12] 3187 	add	a,r0
      0095BF F5 82            [12] 3188 	mov	dpl,a
      0095C1 EF               [12] 3189 	mov	a,r7
      0095C2 39               [12] 3190 	addc	a,r1
      0095C3 F5 83            [12] 3191 	mov	dph,a
      0095C5 74 FF            [12] 3192 	mov	a,#0xff
      0095C7 F0               [24] 3193 	movx	@dptr,a
      0095C8 22               [24] 3194 	ret
                                   3195 
                                   3196 	.area CSEG (CODE)
                                   3197 ; function ak820_outline_0140
      0095C9                       3198 _ak820_outline_0140:
      0095C9 2D               [12] 3199 	add	a,r5
      0095CA F9               [12] 3200 	mov	r1,a
      0095CB E4               [12] 3201 	clr	a
      0095CC 3E               [12] 3202 	addc	a,r6
      0095CD FA               [12] 3203 	mov	r2,a
      0095CE 22               [24] 3204 	ret
                                   3205 
                                   3206 	.area CSEG (CODE)
                                   3207 ; function ak820_outline_0158
      0095CF                       3208 _ak820_outline_0158:
      0095CF 90 0B DB         [24] 3209 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489+0x0002)
      0095D2 E0               [24] 3210 	movx	a,@dptr
      0095D3 F5 82            [12] 3211 	mov	dpl,a
      0095D5 22               [24] 3212 	ret
                                   3213 
                                   3214 	.area CSEG (CODE)
                                   3215 ; function ak820_outline_0173
      0095D6                       3216 _ak820_outline_0173:
      0095D6 90 09 E8         [24] 3217 	mov	dptr,#_ak820_macro_primitive
      0095D9 E4               [12] 3218 	clr	a
      0095DA F0               [24] 3219 	movx	@dptr,a
      0095DB 22               [24] 3220 	ret
                                   3221 
                                   3222 	.area CSEG (CODE)
                                   3223 ; function ak820_outline_0184
      0095DC                       3224 _ak820_outline_0184:
      0095DC 90 0B 6E         [24] 3225 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0095DF E4               [12] 3226 	clr	a
      0095E0 F0               [24] 3227 	movx	@dptr,a
      0095E1 90 0B 6F         [24] 3228 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0095E4 22               [24] 3229 	ret
                                   3230 
                                   3231 	.area CSEG (CODE)
                                   3232 ; function ak820_outline_0185
      0095E5                       3233 _ak820_outline_0185:
      0095E5 90 0C 36         [24] 3234 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0095E8 E4               [12] 3235 	clr	a
      0095E9 F0               [24] 3236 	movx	@dptr,a
      0095EA 90 0C 37         [24] 3237 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0095ED 22               [24] 3238 	ret
                                   3239 
                                   3240 	.area CSEG (CODE)
                                   3241 ; function ak820_outline_0188
      0095EE                       3242 _ak820_outline_0188:
      0095EE AF 82            [24] 3243 	mov	r7,dpl
      0095F0 90 0B DB         [24] 3244 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489+0x0002)
      0095F3 EF               [12] 3245 	mov	a,r7
      0095F4 F0               [24] 3246 	movx	@dptr,a
      0095F5 EF               [12] 3247 	mov	a,r7
      0095F6 22               [24] 3248 	ret
