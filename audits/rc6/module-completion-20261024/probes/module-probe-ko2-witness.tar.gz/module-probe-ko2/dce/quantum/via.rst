                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000041                        553 _raw_hid_receive_sloc0_1_0:
      000041                        554 	.ds 4
      000045                        555 _raw_hid_receive_sloc1_1_0:
      000045                        556 	.ds 1
      000046                        557 _raw_hid_receive_sloc2_1_0:
      000046                        558 	.ds 1
      000047                        559 _raw_hid_receive_sloc3_1_0:
      000047                        560 	.ds 2
      000049                        561 _raw_hid_receive_sloc4_1_0:
      000049                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002A                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002A                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000CBF                        589 _via_eeprom_set_valid_valid_10000_611:
      000CBF                        590 	.ds 1
      000CC0                        591 _via_set_layout_options_value_10000_627:
      000CC0                        592 	.ds 4
      000CC4                        593 _process_record_via_PARM_2:
      000CC4                        594 	.ds 3
      000CC7                        595 _process_record_via_keycode_10000_629:
      000CC7                        596 	.ds 2
      000CC9                        597 _raw_hid_receive_kb_PARM_2:
      000CC9                        598 	.ds 1
      000CCA                        599 _raw_hid_receive_kb_data_10000_635:
      000CCA                        600 	.ds 3
      000CCD                        601 _raw_hid_receive_PARM_2:
      000CCD                        602 	.ds 1
      000CCE                        603 _raw_hid_receive_packet_10000_637:
      000CCE                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00AC25                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00AC25 90 00 25         [24]  658 	mov	dptr,#0x0025
      00AC28 75 F0 00         [24]  659 	mov	b, #0x00
      00AC2B 12 46 7B         [24]  660 	lcall	_eeprom_read_byte
      00AC2E AF 82            [24]  661 	mov	r7, dpl
      00AC30 BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00AC33 90 00 26         [24]  663 	mov	dptr,#0x0026
      00AC36 75 F0 00         [24]  664 	mov	b, #0x00
      00AC39 12 46 7B         [24]  665 	lcall	_eeprom_read_byte
      00AC3C AF 82            [24]  666 	mov	r7, dpl
      00AC3E BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00AC41 90 00 27         [24]  668 	mov	dptr,#0x0027
      00AC44 75 F0 00         [24]  669 	mov	b, #0x00
      00AC47 12 46 7B         [24]  670 	lcall	_eeprom_read_byte
      00AC4A AF 82            [24]  671 	mov	r7, dpl
      00AC4C BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00AC4F 80 04            [24]  673 	sjmp	00104$
      00AC51                        674 00126$:
      00AC51                        675 00103$:
                                    676 ;	assignBit
      00AC51 C2 2A            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00AC53 80 02            [24]  678 	sjmp	00105$
      00AC55                        679 00104$:
                                    680 ;	assignBit
      00AC55 D2 2A            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00AC57                        682 00105$:
      00AC57 A2 2A            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00AC59 12 38 69         [24]  684 	lcall	_ak820_outline_0149
                                    685 ;	quantum/via.c:104: }
      00AC5C 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_611'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_612'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_612'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_612'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00AC5D                        699 _via_eeprom_set_valid:
      00AC5D E5 82            [12]  700 	mov	a,dpl
      00AC5F 90 0C BF         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AC62 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00AC63 E0               [24]  704 	movx	a,@dptr
      00AC64 60 04            [24]  705 	jz	00103$
      00AC66 7F 03            [12]  706 	mov	r7,#0x03
      00AC68 80 02            [24]  707 	sjmp	00104$
      00AC6A                        708 00103$:
      00AC6A 7F FF            [12]  709 	mov	r7,#0xff
      00AC6C                        710 00104$:
      00AC6C 90 07 03         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AC6F EF               [12]  712 	mov	a,r7
      00AC70 F0               [24]  713 	movx	@dptr,a
      00AC71 90 00 25         [24]  714 	mov	dptr,#0x0025
      00AC74 75 F0 00         [24]  715 	mov	b, #0x00
      00AC77 12 53 B4         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00AC7A 90 0C BF         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AC7D E0               [24]  719 	movx	a,@dptr
      00AC7E 60 04            [24]  720 	jz	00105$
      00AC80 7F 20            [12]  721 	mov	r7,#0x20
      00AC82 80 02            [24]  722 	sjmp	00106$
      00AC84                        723 00105$:
      00AC84 7F FF            [12]  724 	mov	r7,#0xff
      00AC86                        725 00106$:
      00AC86 90 07 03         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AC89 EF               [12]  727 	mov	a,r7
      00AC8A F0               [24]  728 	movx	@dptr,a
      00AC8B 90 00 26         [24]  729 	mov	dptr,#0x0026
      00AC8E 75 F0 00         [24]  730 	mov	b, #0x00
      00AC91 12 53 B4         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00AC94 90 0C BF         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AC97 E0               [24]  734 	movx	a,@dptr
      00AC98 60 04            [24]  735 	jz	00107$
      00AC9A 7F 08            [12]  736 	mov	r7,#0x08
      00AC9C 80 02            [24]  737 	sjmp	00108$
      00AC9E                        738 00107$:
      00AC9E 7F FF            [12]  739 	mov	r7,#0xff
      00ACA0                        740 00108$:
      00ACA0 90 07 03         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00ACA3 EF               [12]  742 	mov	a,r7
      00ACA4 F0               [24]  743 	movx	@dptr,a
      00ACA5 90 00 27         [24]  744 	mov	dptr,#0x0027
      00ACA8 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00ACAB 02 53 B4         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00ACAE                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00ACAE 91 D1            [12]  757 	acall	_via_get_layout_options
      00ACB0 91 E9            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00ACB2 91 25            [12]  760 	acall	_via_eeprom_is_valid
      00ACB4 E5 82            [12]  761 	mov	a, dpl
      00ACB6 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00ACB8 02 44 2A         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00ACBB                        766 00103$:
      00ACBB 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00ACBC                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00ACBC 75 82 00         [24]  777 	mov	dpl, #0x00
      00ACBF 91 5D            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00ACC1 12 97 92         [24]  780 	lcall	_ak820_outline_0159
      00ACC4 91 EA            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00ACC6 12 8D D4         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00ACC9 12 92 7D         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00ACCC 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00ACCF 81 5D            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00ACD1                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00ACD1 90 00 28         [24]  799 	mov	dptr,#0x0028
      00ACD4 75 F0 00         [24]  800 	mov	b, #0x00
      00ACD7 12 46 7B         [24]  801 	lcall	_eeprom_read_byte
      00ACDA AF 82            [24]  802 	mov	r7, dpl
      00ACDC 7E 00            [12]  803 	mov	r6,#0x00
      00ACDE 7D 00            [12]  804 	mov	r5,#0x00
      00ACE0 7C 00            [12]  805 	mov	r4,#0x00
      00ACE2 12 49 8E         [24]  806 	lcall	_ak820_outline_0164
      00ACE5 8D F0            [24]  807 	mov	b, r5
      00ACE7 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00ACE8 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_624'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00ACE9                        820 _via_set_layout_options_kb:
      00ACE9 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_627'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00ACEA                        831 _via_set_layout_options:
      00ACEA 12 97 8A         [24]  832 	lcall	_ak820_outline_0122
      00ACED 90 0C C0         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_627
      00ACF0 12 97 78         [24]  834 	lcall	_ak820_outline_0046
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00ACF3 90 0C C0         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_627
      00ACF6 E0               [24]  837 	movx	a,@dptr
      00ACF7 90 07 03         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00ACFA F0               [24]  839 	movx	@dptr,a
      00ACFB 90 00 28         [24]  840 	mov	dptr,#0x0028
      00ACFE 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00AD01 02 53 B4         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_629'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_634'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00AD04                        855 _process_record_via:
      00AD04 12 38 44         [24]  856 	lcall	_ak820_outline_0109
      00AD07 90 0C C7         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_629
      00AD0A 12 38 49         [24]  858 	lcall	_ak820_outline_0110
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00AD0D 90 0C C4         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00AD10 12 54 C2         [24]  861 	lcall	_ak820_outline_0014
      00AD13 74 05            [12]  862 	mov	a,#0x05
      00AD15 12 38 73         [24]  863 	lcall	_ak820_outline_0166
      00AD18 12 54 CB         [24]  864 	lcall	_ak820_outline_0049
      00AD1B 12 C0 1C         [24]  865 	lcall	__gptrget
      00AD1E 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00AD20 90 0C C7         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_629
      00AD23 12 37 C8         [24]  869 	lcall	_ak820_outline_0009
      00AD26 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00AD28 2D               [12]  871 	add	a,r5
      00AD29 50 12            [24]  872 	jnc	00105$
      00AD2B C3               [12]  873 	clr	c
      00AD2C 74 7F            [12]  874 	mov	a,#0x7f
      00AD2E 9C               [12]  875 	subb	a,r4
      00AD2F 74 77            [12]  876 	mov	a,#0x77
      00AD31 9D               [12]  877 	subb	a,r5
      00AD32 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00AD34 8E 82            [24]  882 	mov	dpl, r6
      00AD36 12 92 A3         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00AD39 75 82 00         [24]  885 	mov	dpl, #0x00
      00AD3C 22               [24]  886 	ret
      00AD3D                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00AD3D 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00AD40 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_635'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_636'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00AD41                        903 _raw_hid_receive_kb:
      00AD41 12 49 1A         [24]  904 	lcall	_ak820_outline_0038
      00AD44 90 0C CA         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AD47 12 37 E5         [24]  906 	lcall	_ak820_outline_0020
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00AD4A 90 0C CA         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AD4D 12 54 9C         [24]  909 	lcall	_ak820_outline_0002
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00AD50 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00AD52 02 BF E1         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_637'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_638'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_638'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_638'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_644'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_652'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_653'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_656'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_657'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_658'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_663'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_665'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_674'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_675'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_675'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_680'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_680'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_687'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_687'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_692'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00AD55                        950 _raw_hid_receive:
      00AD55 12 49 1A         [24]  951 	lcall	_ak820_outline_0038
      00AD58 90 0C CE         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AD5B 12 37 E5         [24]  953 	lcall	_ak820_outline_0020
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00AD5E 90 0C CE         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AD61 12 37 FD         [24]  956 	lcall	_ak820_outline_0056
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00AD64 74 01            [12]  958 	mov	a,#0x01
      00AD66 12 49 93         [24]  959 	lcall	_ak820_outline_0167
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00AD69 90 0C CD         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00AD6C E0               [24]  962 	movx	a,@dptr
      00AD6D FB               [12]  963 	mov	r3,a
      00AD6E BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00AD71 80 01            [24]  965 	sjmp	00102$
      00AD73                        966 00520$:
      00AD73 22               [24]  967 	ret
      00AD74                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AD74 90 0E B3         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00AD77 E0               [24]  971 	movx	a,@dptr
      00AD78 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AD7A 12 38 32         [24]  974 	lcall	_ak820_outline_0098
      00AD7D FA               [12]  975 	mov	r2,a
      00AD7E BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00AD81 80 01            [24]  977 	sjmp	00104$
      00AD83                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00AD83 22               [24]  980 	ret
      00AD84                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AD84 12 49 4B         [24]  983 	lcall	_ak820_outline_0080
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AD87 FA               [12]  985 	mov	r2,a
      00AD88 60 21            [24]  986 	jz	00114$
      00AD8A BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00AD8D 80 1C            [24]  988 	sjmp	00114$
      00AD8F                        989 00524$:
      00AD8F BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00AD92 80 17            [24]  991 	sjmp	00114$
      00AD94                        992 00525$:
      00AD94 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00AD97 80 12            [24]  994 	sjmp	00114$
      00AD99                        995 00526$:
      00AD99 BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00AD9C 80 0D            [24]  997 	sjmp	00114$
      00AD9E                        998 00527$:
      00AD9E BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00ADA1 80 08            [24] 1000 	sjmp	00114$
      00ADA3                       1001 00528$:
      00ADA3 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00ADA6 80 03            [24] 1003 	sjmp	00530$
      00ADA8                       1004 00529$:
      00ADA8 02 B2 C8         [24] 1005 	ljmp	00171$
      00ADAB                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00ADAB                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00ADAB 12 38 32         [24] 1010 	lcall	_ak820_outline_0098
      00ADAE FA               [12] 1011 	mov	r2,a
      00ADAF BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00ADB2 80 6D            [24] 1013 	sjmp	00115$
      00ADB4                       1014 00531$:
      00ADB4 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00ADB7 80 75            [24] 1016 	sjmp	00116$
      00ADB9                       1017 00532$:
      00ADB9 BA 03 02         [24] 1018 	cjne	r2,#0x03,00533$
      00ADBC C1 EC            [24] 1019 	ajmp	00125$
      00ADBE                       1020 00533$:
      00ADBE BA 04 03         [24] 1021 	cjne	r2,#0x04,00534$
      00ADC1 02 AF 82         [24] 1022 	ljmp	00129$
      00ADC4                       1023 00534$:
      00ADC4 BA 05 03         [24] 1024 	cjne	r2,#0x05,00535$
      00ADC7 02 AF BF         [24] 1025 	ljmp	00130$
      00ADCA                       1026 00535$:
      00ADCA BA 06 03         [24] 1027 	cjne	r2,#0x06,00536$
      00ADCD 02 B0 28         [24] 1028 	ljmp	00135$
      00ADD0                       1029 00536$:
      00ADD0 BA 07 03         [24] 1030 	cjne	r2,#0x07,00537$
      00ADD3 02 B0 39         [24] 1031 	ljmp	00136$
      00ADD6                       1032 00537$:
      00ADD6 BA 08 03         [24] 1033 	cjne	r2,#0x08,00538$
      00ADD9 02 B0 53         [24] 1034 	ljmp	00137$
      00ADDC                       1035 00538$:
      00ADDC BA 09 03         [24] 1036 	cjne	r2,#0x09,00539$
      00ADDF 02 B0 6D         [24] 1037 	ljmp	00138$
      00ADE2                       1038 00539$:
      00ADE2 BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00ADE5 02 B2 58         [24] 1040 	ljmp	00161$
      00ADE8                       1041 00540$:
      00ADE8 BA 0C 03         [24] 1042 	cjne	r2,#0x0c,00541$
      00ADEB 02 B0 87         [24] 1043 	ljmp	00139$
      00ADEE                       1044 00541$:
      00ADEE BA 0D 03         [24] 1045 	cjne	r2,#0x0d,00542$
      00ADF1 02 B0 A7         [24] 1046 	ljmp	00140$
      00ADF4                       1047 00542$:
      00ADF4 BA 0E 03         [24] 1048 	cjne	r2,#0x0e,00543$
      00ADF7 02 B0 CF         [24] 1049 	ljmp	00141$
      00ADFA                       1050 00543$:
      00ADFA BA 0F 03         [24] 1051 	cjne	r2,#0x0f,00544$
      00ADFD 02 B1 15         [24] 1052 	ljmp	00144$
      00AE00                       1053 00544$:
      00AE00 BA 10 03         [24] 1054 	cjne	r2,#0x10,00545$
      00AE03 02 B1 83         [24] 1055 	ljmp	00151$
      00AE06                       1056 00545$:
      00AE06 BA 11 03         [24] 1057 	cjne	r2,#0x11,00546$
      00AE09 02 B1 9B         [24] 1058 	ljmp	00154$
      00AE0C                       1059 00546$:
      00AE0C BA 12 03         [24] 1060 	cjne	r2,#0x12,00547$
      00AE0F 02 B1 BB         [24] 1061 	ljmp	00155$
      00AE12                       1062 00547$:
      00AE12 BA 13 03         [24] 1063 	cjne	r2,#0x13,00548$
      00AE15 02 B2 01         [24] 1064 	ljmp	00158$
      00AE18                       1065 00548$:
      00AE18 BA FE 03         [24] 1066 	cjne	r2,#0xfe,00549$
      00AE1B 02 B2 97         [24] 1067 	ljmp	00168$
      00AE1E                       1068 00549$:
      00AE1E 02 B2 B0         [24] 1069 	ljmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00AE21                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00AE21 12 38 54         [24] 1073 	lcall	_ak820_outline_0128
      00AE24 E4               [12] 1074 	clr	a
      00AE25 12 49 12         [24] 1075 	lcall	_ak820_outline_0025
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00AE28 74 09            [12] 1077 	mov	a,#0x09
      00AE2A F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00AE2B 02 B2 C8         [24] 1080 	ljmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00AE2E                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00AE2E 12 49 4B         [24] 1084 	lcall	_ak820_outline_0080
      00AE31 FA               [12] 1085 	mov	r2,a
      00AE32 BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00AE35 80 0C            [24] 1087 	sjmp	00117$
      00AE37                       1088 00550$:
      00AE37 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00AE3A 80 32            [24] 1090 	sjmp	00118$
      00AE3C                       1091 00551$:
      00AE3C BA 03 02         [24] 1092 	cjne	r2,#0x03,00552$
      00AE3F C1 A8            [24] 1093 	ajmp	00119$
      00AE41                       1094 00552$:
      00AE41 C1 D2            [24] 1095 	ajmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00AE43                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00AE43 12 4E DC         [24] 1099 	lcall	_timer_read32
      00AE46 85 82 41         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AE49 85 83 42         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AE4C 85 F0 43         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AE4F F5 44            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00AE51 12 38 38         [24] 1105 	lcall	_ak820_outline_0103
      00AE54 A3               [24] 1106 	inc	dptr
      00AE55 E5 44            [12] 1107 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AE57 12 49 12         [24] 1108 	lcall	_ak820_outline_0025
                                   1109 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00AE5A A3               [24] 1110 	inc	dptr
      00AE5B E5 43            [12] 1111 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AE5D 12 49 12         [24] 1112 	lcall	_ak820_outline_0025
                                   1113 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00AE60 A3               [24] 1114 	inc	dptr
      00AE61 A3               [24] 1115 	inc	dptr
      00AE62 E5 42            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AE64 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00AE65 12 49 08         [24] 1119 	lcall	_ak820_outline_0011
      00AE68 E5 41            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00AE6A F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00AE6B 02 B2 C8         [24] 1123 	ljmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00AE6E                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00AE6E C0 03            [24] 1127 	push	ar3
      00AE70 C0 07            [24] 1128 	push	ar7
      00AE72 C0 06            [24] 1129 	push	ar6
      00AE74 C0 03            [24] 1130 	push	ar3
      00AE76 91 D1            [12] 1131 	acall	_via_get_layout_options
      00AE78 85 82 41         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AE7B 85 83 42         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AE7E 85 F0 43         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AE81 F5 44            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AE83 D0 03            [24] 1136 	pop	ar3
      00AE85 D0 06            [24] 1137 	pop	ar6
      00AE87 D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AE89 12 38 38         [24] 1140 	lcall	_ak820_outline_0103
      00AE8C A3               [24] 1141 	inc	dptr
      00AE8D E5 44            [12] 1142 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AE8F 12 49 12         [24] 1143 	lcall	_ak820_outline_0025
                                   1144 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00AE92 A3               [24] 1145 	inc	dptr
      00AE93 E5 43            [12] 1146 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AE95 12 49 12         [24] 1147 	lcall	_ak820_outline_0025
                                   1148 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00AE98 A3               [24] 1149 	inc	dptr
      00AE99 A3               [24] 1150 	inc	dptr
      00AE9A E5 42            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AE9C F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AE9D 12 49 08         [24] 1154 	lcall	_ak820_outline_0011
      00AEA0 E5 41            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00AEA2 F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00AEA3 D0 03            [24] 1158 	pop	ar3
      00AEA5 02 B2 C8         [24] 1159 	ljmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AEA8                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00AEA8 90 0E B2         [24] 1163 	mov	dptr,#_vial_unlocked
      00AEAB E0               [24] 1164 	movx	a,@dptr
      00AEAC 70 03            [24] 1165 	jnz	00553$
      00AEAE 02 B2 C8         [24] 1166 	ljmp	00171$
      00AEB1                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AEB1 7A 01            [12] 1169 	mov	r2,#0x01
      00AEB3 79 00            [12] 1170 	mov	r1,#0x00
      00AEB5                       1171 00173$:
      00AEB5 B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00AEB8                       1173 00554$:
      00AEB8 40 03            [24] 1174 	jc	00555$
      00AEBA 02 B2 C8         [24] 1175 	ljmp	00171$
      00AEBD                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AEBD 89 82            [24] 1178 	mov	dpl, r1
      00AEBF 12 5F 40         [24] 1179 	lcall	_matrix_get_row
      00AEC2 A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AEC4 EA               [12] 1182 	mov	a,r2
      00AEC5 2C               [12] 1183 	add	a, r4
      00AEC6 F5 82            [12] 1184 	mov	dpl,a
      00AEC8 E4               [12] 1185 	clr	a
      00AEC9 3D               [12] 1186 	addc	a, r5
      00AECA F5 83            [12] 1187 	mov	dph,a
      00AECC 0A               [12] 1188 	inc	r2
      00AECD E8               [12] 1189 	mov	a,r0
      00AECE F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AECF 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00AED0 80 E3            [24] 1194 	sjmp	00173$
      00AED2                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00AED2 12 B3 12         [24] 1197 	lcall	_ak820_outline_0097
      00AED5 90 0C C9         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AED8 12 B2 ED         [24] 1199 	lcall	_ak820_outline_0043
      00AEDB C0 07            [24] 1200 	push	ar7
      00AEDD C0 06            [24] 1201 	push	ar6
      00AEDF C0 03            [24] 1202 	push	ar3
      00AEE1 B1 41            [24] 1203 	acall	_raw_hid_receive_kb
      00AEE3 D0 03            [24] 1204 	pop	ar3
      00AEE5 D0 06            [24] 1205 	pop	ar6
      00AEE7 D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00AEE9 02 B2 C8         [24] 1208 	ljmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00AEEC                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00AEEC 12 49 4B         [24] 1212 	lcall	_ak820_outline_0080
      00AEEF FA               [12] 1213 	mov	r2,a
      00AEF0 BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00AEF3 80 03            [24] 1215 	sjmp	00557$
      00AEF5                       1216 00556$:
      00AEF5 02 AF 67         [24] 1217 	ljmp	00127$
      00AEF8                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00AEF8 C0 03            [24] 1220 	push	ar3
      00AEFA 12 37 F5         [24] 1221 	lcall	_ak820_outline_0034
      00AEFD F8               [12] 1222 	mov	r0,a
      00AEFE 79 00            [12] 1223 	mov	r1,#0x00
      00AF00 7B 00            [12] 1224 	mov	r3,#0x00
      00AF02 88 44            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00AF04 8B 41            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00AF06 8B 42            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00AF08 8B 43            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00AF0A 12 41 31         [24] 1229 	lcall	_ak820_outline_0016
      00AF0D F8               [12] 1230 	mov	r0,a
      00AF0E 89 03            [24] 1231 	mov	ar3,r1
      00AF10 88 02            [24] 1232 	mov	ar2,r0
      00AF12 E4               [12] 1233 	clr	a
      00AF13 42 41            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00AF15 E9               [12] 1235 	mov	a,r1
      00AF16 42 42            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AF18 EA               [12] 1237 	mov	a,r2
      00AF19 42 43            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AF1B EB               [12] 1239 	mov	a,r3
      00AF1C 42 44            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AF1E 12 41 47         [24] 1241 	lcall	_ak820_outline_0018
      00AF21 F8               [12] 1242 	mov	r0,a
      00AF22 79 00            [12] 1243 	mov	r1,#0x00
      00AF24 7A 00            [12] 1244 	mov	r2,#0x00
      00AF26 8A 03            [24] 1245 	mov	ar3,r2
      00AF28 89 02            [24] 1246 	mov	ar2,r1
      00AF2A 88 01            [24] 1247 	mov	ar1,r0
      00AF2C E4               [12] 1248 	clr	a
      00AF2D 42 41            [12] 1249 	orl	_raw_hid_receive_sloc0_1_0,a
      00AF2F E9               [12] 1250 	mov	a,r1
      00AF30 42 42            [12] 1251 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AF32 EA               [12] 1252 	mov	a,r2
      00AF33 42 43            [12] 1253 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AF35 EB               [12] 1254 	mov	a,r3
      00AF36 42 44            [12] 1255 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AF38 12 49 08         [24] 1256 	lcall	_ak820_outline_0011
      00AF3B E0               [24] 1257 	movx	a,@dptr
      00AF3C F8               [12] 1258 	mov	r0,a
      00AF3D E4               [12] 1259 	clr	a
      00AF3E F9               [12] 1260 	mov	r1,a
      00AF3F FA               [12] 1261 	mov	r2,a
      00AF40 FB               [12] 1262 	mov	r3,a
      00AF41 E5 42            [12] 1263 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AF43 42 01            [12] 1264 	orl	ar1,a
      00AF45 E5 43            [12] 1265 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AF47 42 02            [12] 1266 	orl	ar2,a
      00AF49 E5 44            [12] 1267 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AF4B 42 03            [12] 1268 	orl	ar3,a
                                   1269 ;	quantum/via.c:323: via_set_layout_options(value);
      00AF4D 12 38 6E         [24] 1270 	lcall	_ak820_outline_0162
      00AF50 8A F0            [24] 1271 	mov	b, r2
      00AF52 EB               [12] 1272 	mov	a, r3
      00AF53 C0 07            [24] 1273 	push	ar7
      00AF55 C0 06            [24] 1274 	push	ar6
      00AF57 C0 03            [24] 1275 	push	ar3
      00AF59 12 AC EA         [24] 1276 	lcall	_via_set_layout_options
      00AF5C D0 03            [24] 1277 	pop	ar3
      00AF5E D0 06            [24] 1278 	pop	ar6
      00AF60 D0 07            [24] 1279 	pop	ar7
                                   1280 ;	quantum/via.c:324: break;
      00AF62 D0 03            [24] 1281 	pop	ar3
      00AF64 02 B2 C8         [24] 1282 	ljmp	00171$
                                   1283 ;	quantum/via.c:326: default: {
      00AF67                       1284 00127$:
                                   1285 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00AF67 12 B3 12         [24] 1286 	lcall	_ak820_outline_0097
      00AF6A 90 0C C9         [24] 1287 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AF6D 12 B2 ED         [24] 1288 	lcall	_ak820_outline_0043
      00AF70 C0 07            [24] 1289 	push	ar7
      00AF72 C0 06            [24] 1290 	push	ar6
      00AF74 C0 03            [24] 1291 	push	ar3
      00AF76 12 AD 41         [24] 1292 	lcall	_raw_hid_receive_kb
      00AF79 D0 03            [24] 1293 	pop	ar3
      00AF7B D0 06            [24] 1294 	pop	ar6
      00AF7D D0 07            [24] 1295 	pop	ar7
                                   1296 ;	quantum/via.c:331: break;
      00AF7F 02 B2 C8         [24] 1297 	ljmp	00171$
                                   1298 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AF82                       1299 00129$:
                                   1300 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AF82 12 49 4B         [24] 1301 	lcall	_ak820_outline_0080
      00AF85 FA               [12] 1302 	mov	r2,a
      00AF86 12 37 F5         [24] 1303 	lcall	_ak820_outline_0034
      00AF89 F9               [12] 1304 	mov	r1,a
      00AF8A 12 41 31         [24] 1305 	lcall	_ak820_outline_0016
      00AF8D F8               [12] 1306 	mov	r0,a
      00AF8E 90 0B 61         [24] 1307 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AF91 E9               [12] 1308 	mov	a,r1
      00AF92 F0               [24] 1309 	movx	@dptr,a
      00AF93 90 0B 62         [24] 1310 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AF96 E8               [12] 1311 	mov	a,r0
      00AF97 F0               [24] 1312 	movx	@dptr,a
      00AF98 8A 82            [24] 1313 	mov	dpl, r2
      00AF9A C0 07            [24] 1314 	push	ar7
      00AF9C C0 06            [24] 1315 	push	ar6
      00AF9E C0 03            [24] 1316 	push	ar3
      00AFA0 12 89 EE         [24] 1317 	lcall	_dynamic_keymap_get_keycode
      00AFA3 A9 82            [24] 1318 	mov	r1, dpl
      00AFA5 AA 83            [24] 1319 	mov	r2, dph
      00AFA7 D0 03            [24] 1320 	pop	ar3
      00AFA9 D0 06            [24] 1321 	pop	ar6
      00AFAB D0 07            [24] 1322 	pop	ar7
                                   1323 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AFAD 12 38 38         [24] 1324 	lcall	_ak820_outline_0103
      00AFB0 A3               [24] 1325 	inc	dptr
      00AFB1 A3               [24] 1326 	inc	dptr
      00AFB2 A3               [24] 1327 	inc	dptr
      00AFB3 8A 00            [24] 1328 	mov	ar0,r2
      00AFB5 E8               [12] 1329 	mov	a,r0
      00AFB6 F0               [24] 1330 	movx	@dptr,a
                                   1331 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AFB7 12 49 08         [24] 1332 	lcall	_ak820_outline_0011
      00AFBA E9               [12] 1333 	mov	a,r1
      00AFBB F0               [24] 1334 	movx	@dptr,a
                                   1335 ;	quantum/via.c:337: break;
      00AFBC 02 B2 C8         [24] 1336 	ljmp	00171$
                                   1337 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AFBF                       1338 00130$:
                                   1339 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AFBF 90 0E B2         [24] 1340 	mov	dptr,#_vial_unlocked
      00AFC2 E0               [24] 1341 	movx	a,@dptr
      00AFC3 70 18            [24] 1342 	jnz	00132$
      00AFC5 12 41 47         [24] 1343 	lcall	_ak820_outline_0018
      00AFC8 FA               [12] 1344 	mov	r2,a
      00AFC9 BA 7C 11         [24] 1345 	cjne	r2,#0x7c,00132$
      00AFCC 74 05            [12] 1346 	mov	a,#0x05
      00AFCE 2E               [12] 1347 	add	a, r6
      00AFCF 12 37 DB         [24] 1348 	lcall	_ak820_outline_0019
      00AFD2 70 09            [24] 1349 	jnz	00132$
                                   1350 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AFD4 12 49 5D         [24] 1351 	lcall	_ak820_outline_0120
      00AFD7 74 FF            [12] 1352 	mov	a,#0xff
      00AFD9 F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/via.c:345: break;
      00AFDA 02 B2 C8         [24] 1355 	ljmp	00171$
      00AFDD                       1356 00132$:
                                   1357 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AFDD C0 03            [24] 1358 	push	ar3
      00AFDF 12 49 4B         [24] 1359 	lcall	_ak820_outline_0080
      00AFE2 F5 46            [12] 1360 	mov	_raw_hid_receive_sloc2_1_0,a
      00AFE4 12 37 F5         [24] 1361 	lcall	_ak820_outline_0034
      00AFE7 F5 45            [12] 1362 	mov	_raw_hid_receive_sloc1_1_0,a
      00AFE9 12 41 31         [24] 1363 	lcall	_ak820_outline_0016
      00AFEC F5 41            [12] 1364 	mov	_raw_hid_receive_sloc0_1_0,a
      00AFEE 12 41 47         [24] 1365 	lcall	_ak820_outline_0018
      00AFF1 FB               [12] 1366 	mov	r3,a
      00AFF2 78 00            [12] 1367 	mov	r0,#0x00
      00AFF4 12 49 08         [24] 1368 	lcall	_ak820_outline_0011
      00AFF7 E0               [24] 1369 	movx	a,@dptr
      00AFF8 7A 00            [12] 1370 	mov	r2,#0x00
      00AFFA 42 00            [12] 1371 	orl	ar0,a
      00AFFC EA               [12] 1372 	mov	a,r2
      00AFFD 42 03            [12] 1373 	orl	ar3,a
      00AFFF 90 0B 64         [24] 1374 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00B002 E5 45            [12] 1375 	mov	a,_raw_hid_receive_sloc1_1_0
      00B004 F0               [24] 1376 	movx	@dptr,a
      00B005 90 0B 65         [24] 1377 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00B008 E5 41            [12] 1378 	mov	a,_raw_hid_receive_sloc0_1_0
      00B00A F0               [24] 1379 	movx	@dptr,a
      00B00B 90 0B 66         [24] 1380 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00B00E E8               [12] 1381 	mov	a,r0
      00B00F 12 55 18         [24] 1382 	lcall	_ak820_outline_0196
      00B012 85 46 82         [24] 1383 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00B015 C0 07            [24] 1384 	push	ar7
      00B017 C0 06            [24] 1385 	push	ar6
      00B019 C0 03            [24] 1386 	push	ar3
      00B01B 12 8A 3B         [24] 1387 	lcall	_dynamic_keymap_set_keycode
      00B01E D0 03            [24] 1388 	pop	ar3
      00B020 D0 06            [24] 1389 	pop	ar6
      00B022 D0 07            [24] 1390 	pop	ar7
                                   1391 ;	quantum/via.c:349: break;
      00B024 D0 03            [24] 1392 	pop	ar3
      00B026 41 C8            [12] 1393 	ajmp	00171$
                                   1394 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00B028                       1395 00135$:
                                   1396 ;	quantum/via.c:352: dynamic_keymap_reset();
      00B028 C0 07            [24] 1397 	push	ar7
      00B02A C0 06            [24] 1398 	push	ar6
      00B02C C0 03            [24] 1399 	push	ar3
      00B02E 12 8D D4         [24] 1400 	lcall	_dynamic_keymap_reset
      00B031 D0 03            [24] 1401 	pop	ar3
      00B033 D0 06            [24] 1402 	pop	ar6
      00B035 D0 07            [24] 1403 	pop	ar7
                                   1404 ;	quantum/via.c:353: break;
      00B037 41 C8            [12] 1405 	ajmp	00171$
                                   1406 ;	quantum/via.c:355: case id_lighting_set_value: {
      00B039                       1407 00136$:
                                   1408 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00B039 12 B3 12         [24] 1409 	lcall	_ak820_outline_0097
      00B03C 90 0E 28         [24] 1410 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B03F 12 B2 ED         [24] 1411 	lcall	_ak820_outline_0043
      00B042 C0 07            [24] 1412 	push	ar7
      00B044 C0 06            [24] 1413 	push	ar6
      00B046 C0 03            [24] 1414 	push	ar3
      00B048 12 BD BF         [24] 1415 	lcall	_vialrgb_set_value
      00B04B D0 03            [24] 1416 	pop	ar3
      00B04D D0 06            [24] 1417 	pop	ar6
      00B04F D0 07            [24] 1418 	pop	ar7
                                   1419 ;	quantum/via.c:375: break;
      00B051 41 C8            [12] 1420 	ajmp	00171$
                                   1421 ;	quantum/via.c:377: case id_lighting_get_value: {
      00B053                       1422 00137$:
                                   1423 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00B053 12 B3 12         [24] 1424 	lcall	_ak820_outline_0097
      00B056 90 0E 24         [24] 1425 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B059 12 B2 ED         [24] 1426 	lcall	_ak820_outline_0043
      00B05C C0 07            [24] 1427 	push	ar7
      00B05E C0 06            [24] 1428 	push	ar6
      00B060 C0 03            [24] 1429 	push	ar3
      00B062 12 BC 59         [24] 1430 	lcall	_vialrgb_get_value
      00B065 D0 03            [24] 1431 	pop	ar3
      00B067 D0 06            [24] 1432 	pop	ar6
      00B069 D0 07            [24] 1433 	pop	ar7
                                   1434 ;	quantum/via.c:397: break;
      00B06B 41 C8            [12] 1435 	ajmp	00171$
                                   1436 ;	quantum/via.c:399: case id_lighting_save: {
      00B06D                       1437 00138$:
                                   1438 ;	quantum/via.c:407: vialrgb_save(data, length);
      00B06D 12 B3 12         [24] 1439 	lcall	_ak820_outline_0097
      00B070 90 0E 2C         [24] 1440 	mov	dptr,#_vialrgb_save_PARM_2
      00B073 12 B2 ED         [24] 1441 	lcall	_ak820_outline_0043
      00B076 C0 07            [24] 1442 	push	ar7
      00B078 C0 06            [24] 1443 	push	ar6
      00B07A C0 03            [24] 1444 	push	ar3
      00B07C 12 BE 4E         [24] 1445 	lcall	_vialrgb_save
      00B07F D0 03            [24] 1446 	pop	ar3
      00B081 D0 06            [24] 1447 	pop	ar6
      00B083 D0 07            [24] 1448 	pop	ar7
                                   1449 ;	quantum/via.c:419: break;
      00B085 41 C8            [12] 1450 	ajmp	00171$
                                   1451 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00B087                       1452 00139$:
                                   1453 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00B087 C0 07            [24] 1454 	push	ar7
      00B089 C0 06            [24] 1455 	push	ar6
      00B08B C0 05            [24] 1456 	push	ar5
      00B08D C0 04            [24] 1457 	push	ar4
      00B08F C0 03            [24] 1458 	push	ar3
      00B091 12 91 F9         [24] 1459 	lcall	_dynamic_keymap_macro_get_count
      00B094 AA 82            [24] 1460 	mov	r2, dpl
      00B096 D0 03            [24] 1461 	pop	ar3
      00B098 D0 04            [24] 1462 	pop	ar4
      00B09A D0 05            [24] 1463 	pop	ar5
      00B09C D0 06            [24] 1464 	pop	ar6
      00B09E D0 07            [24] 1465 	pop	ar7
      00B0A0 12 38 54         [24] 1466 	lcall	_ak820_outline_0128
      00B0A3 EA               [12] 1467 	mov	a,r2
      00B0A4 F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	quantum/via.c:430: break;
      00B0A5 41 C8            [12] 1470 	ajmp	00171$
                                   1471 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00B0A7                       1472 00140$:
                                   1473 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00B0A7 C0 07            [24] 1474 	push	ar7
      00B0A9 C0 06            [24] 1475 	push	ar6
      00B0AB C0 05            [24] 1476 	push	ar5
      00B0AD C0 04            [24] 1477 	push	ar4
      00B0AF C0 03            [24] 1478 	push	ar3
      00B0B1 12 91 FD         [24] 1479 	lcall	_dynamic_keymap_macro_get_buffer_size
      00B0B4 A9 82            [24] 1480 	mov	r1, dpl
      00B0B6 AA 83            [24] 1481 	mov	r2, dph
      00B0B8 D0 03            [24] 1482 	pop	ar3
      00B0BA D0 04            [24] 1483 	pop	ar4
      00B0BC D0 05            [24] 1484 	pop	ar5
      00B0BE D0 06            [24] 1485 	pop	ar6
      00B0C0 D0 07            [24] 1486 	pop	ar7
                                   1487 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00B0C2 8A 00            [24] 1488 	mov	ar0,r2
      00B0C4 12 38 54         [24] 1489 	lcall	_ak820_outline_0128
      00B0C7 E8               [12] 1490 	mov	a,r0
      00B0C8 12 49 12         [24] 1491 	lcall	_ak820_outline_0025
                                   1492 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00B0CB E9               [12] 1493 	mov	a,r1
      00B0CC F0               [24] 1494 	movx	@dptr,a
                                   1495 ;	quantum/via.c:436: break;
      00B0CD 41 C8            [12] 1496 	ajmp	00171$
                                   1497 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00B0CF                       1498 00141$:
                                   1499 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B0CF C0 03            [24] 1500 	push	ar3
      00B0D1 12 B2 D6         [24] 1501 	lcall	_ak820_outline_0004
      00B0D4 89 41            [24] 1502 	mov	_raw_hid_receive_sloc0_1_0,r1
      00B0D6 8A 42            [24] 1503 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1504 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00B0D8 12 41 31         [24] 1505 	lcall	_ak820_outline_0016
      00B0DB FB               [12] 1506 	mov	r3,a
                                   1507 ;	quantum/via.c:441: if (size <= 28)
      00B0DC 8B 47            [24] 1508 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B0DE 75 48 00         [24] 1509 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B0E1 C3               [12] 1510 	clr	c
      00B0E2 74 1C            [12] 1511 	mov	a,#0x1c
      00B0E4 9B               [12] 1512 	subb	a,r3
      00B0E5 D0 03            [24] 1513 	pop	ar3
      00B0E7 50 02            [24] 1514 	jnc	00562$
      00B0E9 41 C8            [12] 1515 	ajmp	00171$
      00B0EB                       1516 00562$:
                                   1517 ;	free result
                                   1518 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00B0EB 12 B2 F6         [24] 1519 	lcall	_ak820_outline_0072
      00B0EE 90 0B C5         [24] 1520 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00B0F1 E5 47            [12] 1521 	mov	a,_raw_hid_receive_sloc3_1_0
      00B0F3 F0               [24] 1522 	movx	@dptr,a
      00B0F4 E5 48            [12] 1523 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B0F6 A3               [24] 1524 	inc	dptr
      00B0F7 F0               [24] 1525 	movx	@dptr,a
      00B0F8 90 0B C7         [24] 1526 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00B0FB 12 B3 00         [24] 1527 	lcall	_ak820_outline_0087
      00B0FE 85 41 82         [24] 1528 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00B101 85 42 83         [24] 1529 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00B104 C0 07            [24] 1530 	push	ar7
      00B106 C0 06            [24] 1531 	push	ar6
      00B108 C0 03            [24] 1532 	push	ar3
      00B10A 12 92 01         [24] 1533 	lcall	_dynamic_keymap_macro_get_buffer
      00B10D D0 03            [24] 1534 	pop	ar3
      00B10F D0 06            [24] 1535 	pop	ar6
      00B111 D0 07            [24] 1536 	pop	ar7
                                   1537 ;	quantum/via.c:443: break;
      00B113 41 C8            [12] 1538 	ajmp	00171$
                                   1539 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00B115                       1540 00144$:
                                   1541 ;	quantum/via.c:448: if (!vial_unlocked) {
      00B115 90 0E B2         [24] 1542 	mov	dptr,#_vial_unlocked
      00B118 E0               [24] 1543 	movx	a,@dptr
      00B119 70 01            [24] 1544 	jnz	00146$
                                   1545 ;	quantum/via.c:450: return;
      00B11B 22               [24] 1546 	ret
      00B11C                       1547 00146$:
                                   1548 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B11C C0 03            [24] 1549 	push	ar3
      00B11E 12 B2 D6         [24] 1550 	lcall	_ak820_outline_0004
      00B121 89 47            [24] 1551 	mov	_raw_hid_receive_sloc3_1_0,r1
      00B123 8A 48            [24] 1552 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1553 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00B125 12 41 31         [24] 1554 	lcall	_ak820_outline_0016
      00B128 F5 41            [12] 1555 	mov	_raw_hid_receive_sloc0_1_0, a
      00B12A 75 42 00         [24] 1556 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1557 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00B12D 85 41 49         [24] 1558 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00B130 85 42 4A         [24] 1559 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00B133 C3               [12] 1560 	clr	c
      00B134 74 1C            [12] 1561 	mov	a,#0x1c
      00B136 95 49            [12] 1562 	subb	a,_raw_hid_receive_sloc4_1_0
      00B138 E4               [12] 1563 	clr	a
      00B139 95 4A            [12] 1564 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B13B D0 03            [24] 1565 	pop	ar3
      00B13D 40 43            [24] 1566 	jc	00147$
                                   1567 ;	free result
      00B13F 8B 01            [24] 1568 	mov	ar1,r3
      00B141 7A 00            [12] 1569 	mov	r2,#0x00
      00B143 E9               [12] 1570 	mov	a,r1
      00B144 24 FC            [12] 1571 	add	a,#0xfc
      00B146 F9               [12] 1572 	mov	r1,a
      00B147 EA               [12] 1573 	mov	a,r2
      00B148 34 FF            [12] 1574 	addc	a,#0xff
      00B14A FA               [12] 1575 	mov	r2,a
      00B14B C3               [12] 1576 	clr	c
      00B14C E9               [12] 1577 	mov	a,r1
      00B14D 95 49            [12] 1578 	subb	a,_raw_hid_receive_sloc4_1_0
      00B14F EA               [12] 1579 	mov	a,r2
      00B150 95 4A            [12] 1580 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B152 40 2E            [24] 1581 	jc	00147$
                                   1582 ;	free result
      00B154 12 B2 F6         [24] 1583 	lcall	_ak820_outline_0072
      00B157 90 0B CC         [24] 1584 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00B15A E5 41            [12] 1585 	mov	a,_raw_hid_receive_sloc0_1_0
      00B15C F0               [24] 1586 	movx	@dptr,a
      00B15D E5 42            [12] 1587 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B15F A3               [24] 1588 	inc	dptr
      00B160 F0               [24] 1589 	movx	@dptr,a
      00B161 90 0B CE         [24] 1590 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00B164 12 B3 00         [24] 1591 	lcall	_ak820_outline_0087
      00B167 85 47 82         [24] 1592 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00B16A 85 48 83         [24] 1593 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00B16D C0 07            [24] 1594 	push	ar7
      00B16F C0 06            [24] 1595 	push	ar6
      00B171 C0 03            [24] 1596 	push	ar3
      00B173 12 92 4E         [24] 1597 	lcall	_dynamic_keymap_macro_set_buffer
      00B176 E5 82            [12] 1598 	mov	a, dpl
      00B178 D0 03            [24] 1599 	pop	ar3
      00B17A D0 06            [24] 1600 	pop	ar6
      00B17C D0 07            [24] 1601 	pop	ar7
      00B17E 60 02            [24] 1602 	jz	00566$
      00B180 41 C8            [12] 1603 	ajmp	00171$
      00B182                       1604 00566$:
      00B182                       1605 00147$:
      00B182 22               [24] 1606 	ret
                                   1607 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00B183                       1608 00151$:
                                   1609 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00B183 90 0E B2         [24] 1610 	mov	dptr,#_vial_unlocked
      00B186 E0               [24] 1611 	movx	a,@dptr
      00B187 70 01            [24] 1612 	jnz	00153$
      00B189 22               [24] 1613 	ret
      00B18A                       1614 00153$:
                                   1615 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00B18A C0 07            [24] 1616 	push	ar7
      00B18C C0 06            [24] 1617 	push	ar6
      00B18E C0 03            [24] 1618 	push	ar3
      00B190 12 92 7D         [24] 1619 	lcall	_dynamic_keymap_macro_reset
      00B193 D0 03            [24] 1620 	pop	ar3
      00B195 D0 06            [24] 1621 	pop	ar6
      00B197 D0 07            [24] 1622 	pop	ar7
                                   1623 ;	quantum/via.c:473: break;
      00B199 41 C8            [12] 1624 	ajmp	00171$
                                   1625 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00B19B                       1626 00154$:
                                   1627 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00B19B C0 07            [24] 1628 	push	ar7
      00B19D C0 06            [24] 1629 	push	ar6
      00B19F C0 05            [24] 1630 	push	ar5
      00B1A1 C0 04            [24] 1631 	push	ar4
      00B1A3 C0 03            [24] 1632 	push	ar3
      00B1A5 12 89 B3         [24] 1633 	lcall	_dynamic_keymap_get_layer_count
      00B1A8 AA 82            [24] 1634 	mov	r2, dpl
      00B1AA D0 03            [24] 1635 	pop	ar3
      00B1AC D0 04            [24] 1636 	pop	ar4
      00B1AE D0 05            [24] 1637 	pop	ar5
      00B1B0 D0 06            [24] 1638 	pop	ar6
      00B1B2 D0 07            [24] 1639 	pop	ar7
      00B1B4 12 38 54         [24] 1640 	lcall	_ak820_outline_0128
      00B1B7 EA               [12] 1641 	mov	a,r2
      00B1B8 F0               [24] 1642 	movx	@dptr,a
                                   1643 ;	quantum/via.c:477: break;
      00B1B9 41 C8            [12] 1644 	ajmp	00171$
                                   1645 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00B1BB                       1646 00155$:
                                   1647 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B1BB C0 03            [24] 1648 	push	ar3
      00B1BD 12 B2 D6         [24] 1649 	lcall	_ak820_outline_0004
      00B1C0 89 49            [24] 1650 	mov	_raw_hid_receive_sloc4_1_0,r1
      00B1C2 8A 4A            [24] 1651 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1652 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00B1C4 12 41 31         [24] 1653 	lcall	_ak820_outline_0016
      00B1C7 FB               [12] 1654 	mov	r3,a
                                   1655 ;	quantum/via.c:482: if (size <= 28)
      00B1C8 8B 47            [24] 1656 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B1CA 75 48 00         [24] 1657 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B1CD C3               [12] 1658 	clr	c
      00B1CE 74 1C            [12] 1659 	mov	a,#0x1c
      00B1D0 9B               [12] 1660 	subb	a,r3
      00B1D1 D0 03            [24] 1661 	pop	ar3
      00B1D3 50 02            [24] 1662 	jnc	00568$
      00B1D5 41 C8            [12] 1663 	ajmp	00171$
      00B1D7                       1664 00568$:
                                   1665 ;	free result
                                   1666 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00B1D7 12 B2 F6         [24] 1667 	lcall	_ak820_outline_0072
      00B1DA 90 0B AE         [24] 1668 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00B1DD E5 47            [12] 1669 	mov	a,_raw_hid_receive_sloc3_1_0
      00B1DF F0               [24] 1670 	movx	@dptr,a
      00B1E0 E5 48            [12] 1671 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B1E2 A3               [24] 1672 	inc	dptr
      00B1E3 F0               [24] 1673 	movx	@dptr,a
      00B1E4 90 0B B0         [24] 1674 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00B1E7 12 B3 00         [24] 1675 	lcall	_ak820_outline_0087
      00B1EA 85 49 82         [24] 1676 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B1ED 85 4A 83         [24] 1677 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B1F0 C0 07            [24] 1678 	push	ar7
      00B1F2 C0 06            [24] 1679 	push	ar6
      00B1F4 C0 03            [24] 1680 	push	ar3
      00B1F6 12 8F C8         [24] 1681 	lcall	_dynamic_keymap_get_buffer
      00B1F9 D0 03            [24] 1682 	pop	ar3
      00B1FB D0 06            [24] 1683 	pop	ar6
      00B1FD D0 07            [24] 1684 	pop	ar7
                                   1685 ;	quantum/via.c:484: break;
      00B1FF 41 C8            [12] 1686 	ajmp	00171$
                                   1687 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00B201                       1688 00158$:
                                   1689 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B201 12 49 4B         [24] 1690 	lcall	_ak820_outline_0080
      00B204 FD               [12] 1691 	mov	r5,a
      00B205 7C 00            [12] 1692 	mov	r4,#0x00
      00B207 12 37 F5         [24] 1693 	lcall	_ak820_outline_0034
      00B20A 7A 00            [12] 1694 	mov	r2,#0x00
      00B20C 42 04            [12] 1695 	orl	ar4,a
      00B20E EA               [12] 1696 	mov	a,r2
      00B20F 42 05            [12] 1697 	orl	ar5,a
      00B211 8C 49            [24] 1698 	mov	_raw_hid_receive_sloc4_1_0,r4
      00B213 8D 4A            [24] 1699 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1700 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00B215 12 41 31         [24] 1701 	lcall	_ak820_outline_0016
      00B218 F9               [12] 1702 	mov	r1,a
      00B219 7A 00            [12] 1703 	mov	r2,#0x00
                                   1704 ;	quantum/via.c:489: if (size <= 28)
      00B21B 89 00            [24] 1705 	mov	ar0,r1
      00B21D E8               [12] 1706 	mov	a,r0
      00B21E 24 E3            [12] 1707 	add	a,#0xff - 0x1c
      00B220 50 02            [24] 1708 	jnc	00569$
      00B222 41 C8            [12] 1709 	ajmp	00171$
      00B224                       1710 00569$:
                                   1711 ;	free result
                                   1712 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00B224 C0 03            [24] 1713 	push	ar3
      00B226 74 04            [12] 1714 	mov	a,#0x04
      00B228 2E               [12] 1715 	add	a, r6
      00B229 F8               [12] 1716 	mov	r0,a
      00B22A E4               [12] 1717 	clr	a
      00B22B 3F               [12] 1718 	addc	a, r7
      00B22C FB               [12] 1719 	mov	r3,a
      00B22D 7D 00            [12] 1720 	mov	r5,#0x00
      00B22F 90 0B B5         [24] 1721 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00B232 12 4E 8A         [24] 1722 	lcall	_ak820_outline_0142
      00B235 90 0B B7         [24] 1723 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00B238 E8               [12] 1724 	mov	a,r0
      00B239 12 55 18         [24] 1725 	lcall	_ak820_outline_0196
      00B23C ED               [12] 1726 	mov	a,r5
      00B23D A3               [24] 1727 	inc	dptr
      00B23E F0               [24] 1728 	movx	@dptr,a
      00B23F 85 49 82         [24] 1729 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B242 85 4A 83         [24] 1730 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B245 C0 07            [24] 1731 	push	ar7
      00B247 C0 06            [24] 1732 	push	ar6
      00B249 C0 03            [24] 1733 	push	ar3
      00B24B 12 90 07         [24] 1734 	lcall	_dynamic_keymap_set_buffer
      00B24E D0 03            [24] 1735 	pop	ar3
      00B250 D0 06            [24] 1736 	pop	ar6
      00B252 D0 07            [24] 1737 	pop	ar7
                                   1738 ;	quantum/via.c:491: break;
      00B254 D0 03            [24] 1739 	pop	ar3
      00B256 41 C8            [12] 1740 	ajmp	00171$
                                   1741 ;	quantum/via.c:495: case id_bootloader_jump: {
      00B258                       1742 00161$:
                                   1743 ;	quantum/via.c:497: if (!vial_unlocked)
      00B258 90 0E B2         [24] 1744 	mov	dptr,#_vial_unlocked
      00B25B E0               [24] 1745 	movx	a,@dptr
      00B25C 70 02            [24] 1746 	jnz	00570$
      00B25E 41 C8            [12] 1747 	ajmp	00171$
      00B260                       1748 00570$:
                                   1749 ;	quantum/via.c:501: raw_hid_send(data, length);
      00B260 12 B3 19         [24] 1750 	lcall	_ak820_outline_0157
      00B263 90 06 DD         [24] 1751 	mov	dptr,#_raw_hid_send_PARM_2
      00B266 12 B3 09         [24] 1752 	lcall	_ak820_outline_0088
      00B269 C0 07            [24] 1753 	push	ar7
      00B26B C0 06            [24] 1754 	push	ar6
      00B26D C0 03            [24] 1755 	push	ar3
      00B26F 12 50 C8         [24] 1756 	lcall	_raw_hid_send
      00B272 D0 03            [24] 1757 	pop	ar3
      00B274 D0 06            [24] 1758 	pop	ar6
      00B276 D0 07            [24] 1759 	pop	ar7
                                   1760 ;	quantum/via.c:503: wait_ms(100);
      00B278 7D 64            [12] 1761 	mov	r5,#0x64
      00B27A                       1762 00176$:
      00B27A ED               [12] 1763 	mov	a,r5
      00B27B 60 09            [24] 1764 	jz	00166$
      00B27D 90 00 01         [24] 1765 	mov	dptr,#0x0001
      00B280 12 5E 7F         [24] 1766 	lcall	_mDelaymS
      00B283 1D               [12] 1767 	dec	r5
      00B284 80 F4            [24] 1768 	sjmp	00176$
      00B286                       1769 00166$:
                                   1770 ;	quantum/via.c:504: bootloader_jump();
      00B286 C0 07            [24] 1771 	push	ar7
      00B288 C0 06            [24] 1772 	push	ar6
      00B28A C0 03            [24] 1773 	push	ar3
      00B28C 12 34 0E         [24] 1774 	lcall	_bootloader_jump
      00B28F D0 03            [24] 1775 	pop	ar3
      00B291 D0 06            [24] 1776 	pop	ar6
      00B293 D0 07            [24] 1777 	pop	ar7
                                   1778 ;	quantum/via.c:505: break;
                                   1779 ;	quantum/via.c:509: case id_vial_prefix: {
      00B295 80 31            [24] 1780 	sjmp	00171$
      00B297                       1781 00168$:
                                   1782 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B297 12 B3 19         [24] 1783 	lcall	_ak820_outline_0157
      00B29A 90 0C DB         [24] 1784 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B29D 12 B3 09         [24] 1785 	lcall	_ak820_outline_0088
      00B2A0 C0 07            [24] 1786 	push	ar7
      00B2A2 C0 06            [24] 1787 	push	ar6
      00B2A4 C0 03            [24] 1788 	push	ar3
      00B2A6 91 09            [12] 1789 	acall	_vial_handle_cmd
      00B2A8 D0 03            [24] 1790 	pop	ar3
      00B2AA D0 06            [24] 1791 	pop	ar6
      00B2AC D0 07            [24] 1792 	pop	ar7
                                   1793 ;	quantum/via.c:511: break;
                                   1794 ;	quantum/via.c:514: default: {
      00B2AE 80 18            [24] 1795 	sjmp	00171$
      00B2B0                       1796 00169$:
                                   1797 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B2B0 12 B3 19         [24] 1798 	lcall	_ak820_outline_0157
      00B2B3 90 0C C9         [24] 1799 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B2B6 12 B3 09         [24] 1800 	lcall	_ak820_outline_0088
      00B2B9 C0 07            [24] 1801 	push	ar7
      00B2BB C0 06            [24] 1802 	push	ar6
      00B2BD C0 03            [24] 1803 	push	ar3
      00B2BF 12 AD 41         [24] 1804 	lcall	_raw_hid_receive_kb
      00B2C2 D0 03            [24] 1805 	pop	ar3
      00B2C4 D0 06            [24] 1806 	pop	ar6
      00B2C6 D0 07            [24] 1807 	pop	ar7
                                   1808 ;	quantum/via.c:521: skip:
      00B2C8                       1809 00171$:
                                   1810 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B2C8 7D 00            [12] 1811 	mov	r5,#0x00
      00B2CA 90 06 DD         [24] 1812 	mov	dptr,#_raw_hid_send_PARM_2
      00B2CD EB               [12] 1813 	mov	a,r3
      00B2CE 12 49 3E         [24] 1814 	lcall	_ak820_outline_0063
      00B2D1 8D F0            [24] 1815 	mov	b, r5
                                   1816 ;	quantum/via.c:526: }
      00B2D3 02 50 C8         [24] 1817 	ljmp	_raw_hid_send
                                   1818 	.area CSEG    (CODE)
                                   1819 	.area CONST   (CODE)
                                   1820 	.area XINIT   (CODE)
                                   1821 	.area CABS    (ABS,CODE)
                                   1822 
                                   1823 ; Experimental exact instruction outlining.
                                   1824 	.globl _ak820_outline_0002
                                   1825 	.globl _ak820_outline_0004
                                   1826 	.globl _ak820_outline_0009
                                   1827 	.globl _ak820_outline_0011
                                   1828 	.globl _ak820_outline_0014
                                   1829 	.globl _ak820_outline_0016
                                   1830 	.globl _ak820_outline_0018
                                   1831 	.globl _ak820_outline_0019
                                   1832 	.globl _ak820_outline_0020
                                   1833 	.globl _ak820_outline_0025
                                   1834 	.globl _ak820_outline_0034
                                   1835 	.globl _ak820_outline_0038
                                   1836 	.globl _ak820_outline_0043
                                   1837 	.globl _ak820_outline_0046
                                   1838 	.globl _ak820_outline_0049
                                   1839 	.globl _ak820_outline_0056
                                   1840 	.globl _ak820_outline_0063
                                   1841 	.globl _ak820_outline_0072
                                   1842 	.globl _ak820_outline_0080
                                   1843 	.globl _ak820_outline_0087
                                   1844 	.globl _ak820_outline_0088
                                   1845 	.globl _ak820_outline_0097
                                   1846 	.globl _ak820_outline_0098
                                   1847 	.globl _ak820_outline_0103
                                   1848 	.globl _ak820_outline_0109
                                   1849 	.globl _ak820_outline_0110
                                   1850 	.globl _ak820_outline_0120
                                   1851 	.globl _ak820_outline_0122
                                   1852 	.globl _ak820_outline_0128
                                   1853 	.globl _ak820_outline_0142
                                   1854 	.globl _ak820_outline_0149
                                   1855 	.globl _ak820_outline_0157
                                   1856 	.globl _ak820_outline_0159
                                   1857 	.globl _ak820_outline_0162
                                   1858 	.globl _ak820_outline_0164
                                   1859 	.globl _ak820_outline_0166
                                   1860 	.globl _ak820_outline_0167
                                   1861 	.globl _ak820_outline_0196
                                   1862 
                                   1863 	.area CSEG (CODE)
                                   1864 ; function ak820_outline_0004
      00B2D6                       1865 _ak820_outline_0004:
      00B2D6 8C 82            [24] 1866 	mov	dpl,r4
      00B2D8 8D 83            [24] 1867 	mov	dph,r5
      00B2DA E0               [24] 1868 	movx	a,@dptr
      00B2DB FA               [12] 1869 	mov	r2,a
      00B2DC 79 00            [12] 1870 	mov	r1,#0x00
      00B2DE 8E 82            [24] 1871 	mov	dpl,r6
      00B2E0 8F 83            [24] 1872 	mov	dph,r7
      00B2E2 A3               [24] 1873 	inc	dptr
      00B2E3 A3               [24] 1874 	inc	dptr
      00B2E4 E0               [24] 1875 	movx	a,@dptr
      00B2E5 7B 00            [12] 1876 	mov	r3,#0x00
      00B2E7 42 01            [12] 1877 	orl	ar1,a
      00B2E9 EB               [12] 1878 	mov	a,r3
      00B2EA 42 02            [12] 1879 	orl	ar2,a
      00B2EC 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0043
      00B2ED                       1884 _ak820_outline_0043:
      00B2ED EB               [12] 1885 	mov	a,r3
      00B2EE F0               [24] 1886 	movx	@dptr,a
      00B2EF 88 82            [24] 1887 	mov	dpl,r0
      00B2F1 89 83            [24] 1888 	mov	dph,r1
      00B2F3 8A F0            [24] 1889 	mov	b,r2
      00B2F5 22               [24] 1890 	ret
                                   1891 
                                   1892 	.area CSEG (CODE)
                                   1893 ; function ak820_outline_0072
      00B2F6                       1894 _ak820_outline_0072:
      00B2F6 74 04            [12] 1895 	mov	a,#0x04
      00B2F8 2E               [12] 1896 	add	a,r6
      00B2F9 F9               [12] 1897 	mov	r1,a
      00B2FA E4               [12] 1898 	clr	a
      00B2FB 3F               [12] 1899 	addc	a,r7
      00B2FC F8               [12] 1900 	mov	r0,a
      00B2FD 7A 00            [12] 1901 	mov	r2,#0x00
      00B2FF 22               [24] 1902 	ret
                                   1903 
                                   1904 	.area CSEG (CODE)
                                   1905 ; function ak820_outline_0087
      00B300                       1906 _ak820_outline_0087:
      00B300 E9               [12] 1907 	mov	a,r1
      00B301 F0               [24] 1908 	movx	@dptr,a
      00B302 E8               [12] 1909 	mov	a,r0
      00B303 A3               [24] 1910 	inc	dptr
      00B304 F0               [24] 1911 	movx	@dptr,a
      00B305 EA               [12] 1912 	mov	a,r2
      00B306 A3               [24] 1913 	inc	dptr
      00B307 F0               [24] 1914 	movx	@dptr,a
      00B308 22               [24] 1915 	ret
                                   1916 
                                   1917 	.area CSEG (CODE)
                                   1918 ; function ak820_outline_0088
      00B309                       1919 _ak820_outline_0088:
      00B309 EB               [12] 1920 	mov	a,r3
      00B30A F0               [24] 1921 	movx	@dptr,a
      00B30B 8A 82            [24] 1922 	mov	dpl,r2
      00B30D 8C 83            [24] 1923 	mov	dph,r4
      00B30F 8D F0            [24] 1924 	mov	b,r5
      00B311 22               [24] 1925 	ret
                                   1926 
                                   1927 	.area CSEG (CODE)
                                   1928 ; function ak820_outline_0097
      00B312                       1929 _ak820_outline_0097:
      00B312 8E 00            [24] 1930 	mov	ar0,r6
      00B314 8F 01            [24] 1931 	mov	ar1,r7
      00B316 7A 00            [12] 1932 	mov	r2,#0x00
      00B318 22               [24] 1933 	ret
                                   1934 
                                   1935 	.area CSEG (CODE)
                                   1936 ; function ak820_outline_0157
      00B319                       1937 _ak820_outline_0157:
      00B319 8E 02            [24] 1938 	mov	ar2,r6
      00B31B 8F 04            [24] 1939 	mov	ar4,r7
      00B31D 7D 00            [12] 1940 	mov	r5,#0x00
      00B31F 22               [24] 1941 	ret
