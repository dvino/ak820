                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      000015                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      000015                         68 	.ds 2
      000017                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      000017                         70 	.ds 2
      000019                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000019                         72 	.ds 2
      00001B                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      00001B                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      00000A                         91 _page_valid:
      00000A                         92 	.ds 1
      00000B                         93 _page_dirty:
      00000B                         94 	.ds 1
      00000C                         95 _storage_failed:
      00000C                         96 	.ds 1
      00000D                         97 _ak820_nvm_ok_sloc0_1_0:
      00000D                         98 	.ds 1
      00000E                         99 _load_page_sloc0_1_0:
      00000E                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000585                        109 _page_data:
      000585                        110 	.ds 64
      0005C5                        111 _cached_page:
      0005C5                        112 	.ds 1
      0005C6                        113 _batch_depth:
      0005C6                        114 	.ds 1
      0005C7                        115 _first_failure_stage:
      0005C7                        116 	.ds 1
      0005C8                        117 _nvm_fail_stage_10000_20:
      0005C8                        118 	.ds 1
      0005C9                        119 _ak820_nvm_diagnostic_out_10000_23:
      0005C9                        120 	.ds 2
      0005CB                        121 _crc_byte_PARM_2:
      0005CB                        122 	.ds 1
      0005CC                        123 _crc_byte_crc_10000_25:
      0005CC                        124 	.ds 2
      0005CE                        125 _page_crc_crc_10000_30:
      0005CE                        126 	.ds 2
      0005D0                        127 _write_page_address_10000_32:
      0005D0                        128 	.ds 2
      0005D2                        129 _journal_header_valid_header_10000_39:
      0005D2                        130 	.ds 2
      0005D4                        131 _recover_journal_header_10000_46:
      0005D4                        132 	.ds 9
      0005DD                        133 _ak820_nvm_flush_header_10000_62:
      0005DD                        134 	.ds 9
      0005E6                        135 _ak820_nvm_flush_stage_10000_62:
      0005E6                        136 	.ds 1
      0005E7                        137 _load_page_page_10000_87:
      0005E7                        138 	.ds 1
      0005E8                        139 _read_offset_offset_10000_93:
      0005E8                        140 	.ds 2
      0005EA                        141 _eeprom_read_byte_addr_10000_97:
      0005EA                        142 	.ds 3
      0005ED                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      0005ED                        144 	.ds 3
      0005F0                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      0005F0                        146 	.ds 2
      0005F2                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005F2                        148 	.ds 2
      0005F4                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005F4                        150 	.ds 2
      0005F6                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005F6                        152 	.ds 3
      0005F9                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005F9                        154 	.ds 2
      0005FB                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005FB                        156 	.ds 2
      0005FD                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005FD                        158 	.ds 3
      000600                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000600                        160 	.ds 2
      000602                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000602                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      00418D                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      00418D E5 82            [12]  215 	mov	a,dpl
      00418F 90 05 C8         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      004192 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      004193 20 0C 08         [24]  219 	jb	_storage_failed,00102$
      004196 90 05 C8         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      004199 E0               [24]  221 	movx	a,@dptr
      00419A 90 05 C7         [24]  222 	mov	dptr,#_first_failure_stage
      00419D F0               [24]  223 	movx	@dptr,a
      00419E                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      00419E D2 0C            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      0041A0 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      0041A1                        239 _ak820_nvm_diagnostic:
      0041A1 12 38 44         [24]  240 	lcall	_ak820_outline_0109
      0041A4 90 05 C9         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      0041A7 12 38 49         [24]  242 	lcall	_ak820_outline_0110
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      0041AA 90 05 C9         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      0041AD 12 37 FD         [24]  245 	lcall	_ak820_outline_0056
      0041B0 A2 0C            [12]  246 	mov	c,_storage_failed
      0041B2 E4               [12]  247 	clr	a
      0041B3 33               [12]  248 	rlc	a
      0041B4 12 49 5D         [24]  249 	lcall	_ak820_outline_0120
      0041B7 12 49 3E         [24]  250 	lcall	_ak820_outline_0063
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      0041BA A3               [24]  252 	inc	dptr
      0041BB A2 0A            [12]  253 	mov	c,_page_valid
      0041BD E4               [12]  254 	clr	a
      0041BE 33               [12]  255 	rlc	a
      0041BF 12 49 12         [24]  256 	lcall	_ak820_outline_0025
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      0041C2 A2 0B            [12]  258 	mov	c,_page_dirty
      0041C4 E4               [12]  259 	clr	a
      0041C5 33               [12]  260 	rlc	a
      0041C6 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      0041C7 74 03            [12]  263 	mov	a,#0x03
      0041C9 12 49 93         [24]  264 	lcall	_ak820_outline_0167
      0041CC 90 05 C6         [24]  265 	mov	dptr,#_batch_depth
      0041CF E0               [24]  266 	movx	a,@dptr
      0041D0 12 49 62         [24]  267 	lcall	_ak820_outline_0124
                                    268 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      0041D3 74 04            [12]  269 	mov	a,#0x04
      0041D5 12 49 93         [24]  270 	lcall	_ak820_outline_0167
      0041D8 90 05 C5         [24]  271 	mov	dptr,#_cached_page
      0041DB E0               [24]  272 	movx	a,@dptr
      0041DC 12 49 62         [24]  273 	lcall	_ak820_outline_0124
                                    274 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      0041DF 12 49 08         [24]  275 	lcall	_ak820_outline_0011
      0041E2 E4               [12]  276 	clr	a
      0041E3 F0               [24]  277 	movx	@dptr,a
                                    278 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      0041E4 74 06            [12]  279 	mov	a,#0x06
      0041E6 12 49 73         [24]  280 	lcall	_ak820_outline_0141
      0041E9 90 05 C7         [24]  281 	mov	dptr,#_first_failure_stage
      0041EC E0               [24]  282 	movx	a,@dptr
      0041ED 12 49 5D         [24]  283 	lcall	_ak820_outline_0120
      0041F0 F0               [24]  284 	movx	@dptr,a
                                    285 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      0041F1 22               [24]  286 	ret
                                    287 ;------------------------------------------------------------
                                    288 ;Allocation info for local variables in function 'crc_byte'
                                    289 ;------------------------------------------------------------
                                    290 ;value         Allocated with name '_crc_byte_PARM_2'
                                    291 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    292 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    293 ;------------------------------------------------------------
                                    294 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    295 ;	-----------------------------------------
                                    296 ;	 function crc_byte
                                    297 ;	-----------------------------------------
      0041F2                        298 _crc_byte:
      0041F2 12 38 44         [24]  299 	lcall	_ak820_outline_0109
      0041F5 90 05 CC         [24]  300 	mov	dptr,#_crc_byte_crc_10000_25
      0041F8 12 38 49         [24]  301 	lcall	_ak820_outline_0110
                                    302 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      0041FB 90 05 CB         [24]  303 	mov	dptr,#_crc_byte_PARM_2
      0041FE E0               [24]  304 	movx	a,@dptr
      0041FF FF               [12]  305 	mov	r7,a
      004200 7E 00            [12]  306 	mov	r6,#0x00
      004202 90 05 CC         [24]  307 	mov	dptr,#_crc_byte_crc_10000_25
      004205 E0               [24]  308 	movx	a,@dptr
      004206 6E               [12]  309 	xrl	a,r6
      004207 F0               [24]  310 	movx	@dptr,a
      004208 A3               [24]  311 	inc	dptr
      004209 E0               [24]  312 	movx	a,@dptr
      00420A 6F               [12]  313 	xrl	a,r7
      00420B F0               [24]  314 	movx	@dptr,a
                                    315 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      00420C 7F 00            [12]  316 	mov	r7,#0x00
      00420E                        317 00102$:
                                    318 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      00420E 90 05 CC         [24]  319 	mov	dptr,#_crc_byte_crc_10000_25
      004211 12 38 26         [24]  320 	lcall	_ak820_outline_0081
      004214 30 E7 0E         [24]  321 	jnb	acc.7,00106$
      004217 ED               [12]  322 	mov	a,r5
      004218 2D               [12]  323 	add	a,r5
      004219 FB               [12]  324 	mov	r3,a
      00421A EE               [12]  325 	mov	a,r6
      00421B 33               [12]  326 	rlc	a
      00421C FC               [12]  327 	mov	r4,a
      00421D 63 03 21         [24]  328 	xrl	ar3,#0x21
      004220 63 04 10         [24]  329 	xrl	ar4,#0x10
      004223 80 06            [24]  330 	sjmp	00107$
      004225                        331 00106$:
      004225 ED               [12]  332 	mov	a,r5
      004226 2D               [12]  333 	add	a,r5
      004227 FB               [12]  334 	mov	r3,a
      004228 EE               [12]  335 	mov	a,r6
      004229 33               [12]  336 	rlc	a
      00422A FC               [12]  337 	mov	r4,a
      00422B                        338 00107$:
      00422B 90 05 CC         [24]  339 	mov	dptr,#_crc_byte_crc_10000_25
      00422E 12 38 2C         [24]  340 	lcall	_ak820_outline_0095
                                    341 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      004231 0F               [12]  342 	inc	r7
      004232 BF 08 D9         [24]  343 	cjne	r7,#0x08,00102$
                                    344 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      004235 12 33 FC         [24]  345 	lcall	_ak820_outline_0127
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      004238 22               [24]  347 	ret
                                    348 ;------------------------------------------------------------
                                    349 ;Allocation info for local variables in function 'page_crc'
                                    350 ;------------------------------------------------------------
                                    351 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    352 ;i             Allocated with name '_page_crc_i_10000_30'
                                    353 ;------------------------------------------------------------
                                    354 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    355 ;	-----------------------------------------
                                    356 ;	 function page_crc
                                    357 ;	-----------------------------------------
      004239                        358 _page_crc:
                                    359 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      004239 90 05 CE         [24]  360 	mov	dptr,#_page_crc_crc_10000_30
      00423C 74 FF            [12]  361 	mov	a,#0xff
      00423E F0               [24]  362 	movx	@dptr,a
      00423F A3               [24]  363 	inc	dptr
      004240 F0               [24]  364 	movx	@dptr,a
                                    365 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      004241 7F 00            [12]  366 	mov	r7,#0x00
      004243                        367 00102$:
      004243 90 05 CE         [24]  368 	mov	dptr,#_page_crc_crc_10000_30
      004246 12 38 26         [24]  369 	lcall	_ak820_outline_0081
      004249 12 49 51         [24]  370 	lcall	_ak820_outline_0107
      00424C 90 05 CB         [24]  371 	mov	dptr,#_crc_byte_PARM_2
      00424F F0               [24]  372 	movx	@dptr,a
      004250 12 38 5E         [24]  373 	lcall	_ak820_outline_0138
      004253 C0 07            [24]  374 	push	ar7
      004255 12 41 F2         [24]  375 	lcall	_crc_byte
      004258 AD 82            [24]  376 	mov	r5, dpl
      00425A AE 83            [24]  377 	mov	r6, dph
      00425C D0 07            [24]  378 	pop	ar7
      00425E 90 05 CE         [24]  379 	mov	dptr,#_page_crc_crc_10000_30
      004261 12 49 99         [24]  380 	lcall	_ak820_outline_0169
      004264 0F               [12]  381 	inc	r7
      004265 BF 40 DB         [24]  382 	cjne	r7,#0x40,00102$
                                    383 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      004268 12 38 5E         [24]  384 	lcall	_ak820_outline_0138
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      00426B 22               [24]  386 	ret
                                    387 ;------------------------------------------------------------
                                    388 ;Allocation info for local variables in function 'write_page'
                                    389 ;------------------------------------------------------------
                                    390 ;address       Allocated with name '_write_page_address_10000_32'
                                    391 ;i             Allocated with name '_write_page_i_10000_33'
                                    392 ;------------------------------------------------------------
                                    393 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    394 ;	-----------------------------------------
                                    395 ;	 function write_page
                                    396 ;	-----------------------------------------
      00426C                        397 _write_page:
      00426C 12 38 44         [24]  398 	lcall	_ak820_outline_0109
      00426F 90 05 D0         [24]  399 	mov	dptr,#_write_page_address_10000_32
      004272 12 38 49         [24]  400 	lcall	_ak820_outline_0110
                                    401 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      004275 90 05 D0         [24]  402 	mov	dptr,#_write_page_address_10000_32
      004278 12 37 BE         [24]  403 	lcall	_ak820_outline_0007
      00427B C0 07            [24]  404 	push	ar7
      00427D C0 06            [24]  405 	push	ar6
      00427F 12 39 B4         [24]  406 	lcall	_ak820_flash_erase
      004282 E5 82            [12]  407 	mov	a, dpl
      004284 D0 06            [24]  408 	pop	ar6
      004286 D0 07            [24]  409 	pop	ar7
      004288 70 03            [24]  410 	jnz	00102$
      00428A F5 82            [12]  411 	mov	dpl,a
      00428C 22               [24]  412 	ret
      00428D                        413 00102$:
                                    414 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      00428D 90 04 F5         [24]  415 	mov	dptr,#_ak820_flash_program_page_PARM_2
      004290 74 85            [12]  416 	mov	a,#_page_data
      004292 F0               [24]  417 	movx	@dptr,a
      004293 74 05            [12]  418 	mov	a,#(_page_data >> 8)
      004295 A3               [24]  419 	inc	dptr
      004296 12 49 3E         [24]  420 	lcall	_ak820_outline_0063
      004299 12 3A C8         [24]  421 	lcall	_ak820_flash_program_page
      00429C E5 82            [12]  422 	mov	a, dpl
      00429E 70 03            [24]  423 	jnz	00120$
      0042A0 F5 82            [12]  424 	mov	dpl,a
                                    425 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042A2 22               [24]  426 	ret
      0042A3                        427 00120$:
      0042A3 7F 00            [12]  428 	mov	r7,#0x00
      0042A5                        429 00108$:
                                    430 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      0042A5 8F 05            [24]  431 	mov	ar5,r7
      0042A7 7E 00            [12]  432 	mov	r6,#0x00
      0042A9 90 05 D0         [24]  433 	mov	dptr,#_write_page_address_10000_32
      0042AC 12 38 63         [24]  434 	lcall	_ak820_outline_0145
      0042AF ED               [12]  435 	mov	a,r5
      0042B0 2B               [12]  436 	add	a, r3
      0042B1 FB               [12]  437 	mov	r3,a
      0042B2 EE               [12]  438 	mov	a,r6
      0042B3 3C               [12]  439 	addc	a, r4
      0042B4 FC               [12]  440 	mov	r4,a
      0042B5 12 33 FC         [24]  441 	lcall	_ak820_outline_0127
      0042B8 12 38 A7         [24]  442 	lcall	_ak820_flash_read
      0042BB AE 82            [24]  443 	mov	r6, dpl
      0042BD 12 49 51         [24]  444 	lcall	_ak820_outline_0107
      0042C0 FD               [12]  445 	mov	r5,a
      0042C1 EE               [12]  446 	mov	a,r6
      0042C2 B5 05 02         [24]  447 	cjne	a,ar5,00149$
      0042C5 80 04            [24]  448 	sjmp	00109$
      0042C7                        449 00149$:
      0042C7 75 82 00         [24]  450 	mov	dpl, #0x00
      0042CA 22               [24]  451 	ret
      0042CB                        452 00109$:
                                    453 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042CB 0F               [12]  454 	inc	r7
      0042CC BF 40 D6         [24]  455 	cjne	r7,#0x40,00108$
                                    456 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      0042CF 75 82 01         [24]  457 	mov	dpl, #0x01
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      0042D2 22               [24]  459 	ret
                                    460 ;------------------------------------------------------------
                                    461 ;Allocation info for local variables in function 'journal_header_valid'
                                    462 ;------------------------------------------------------------
                                    463 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    464 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    465 ;------------------------------------------------------------
                                    466 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    467 ;	-----------------------------------------
                                    468 ;	 function journal_header_valid
                                    469 ;	-----------------------------------------
      0042D3                        470 _journal_header_valid:
      0042D3 12 38 44         [24]  471 	lcall	_ak820_outline_0109
      0042D6 90 05 D2         [24]  472 	mov	dptr,#_journal_header_valid_header_10000_39
      0042D9 12 38 49         [24]  473 	lcall	_ak820_outline_0110
                                    474 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      0042DC 90 05 D2         [24]  475 	mov	dptr,#_journal_header_valid_header_10000_39
      0042DF 12 37 BE         [24]  476 	lcall	_ak820_outline_0007
      0042E2 E0               [24]  477 	movx	a,@dptr
      0042E3 FD               [12]  478 	mov	r5,a
      0042E4 BD A5 02         [24]  479 	cjne	r5,#0xa5,00138$
      0042E7 80 04            [24]  480 	sjmp	00116$
      0042E9                        481 00138$:
      0042E9 75 82 00         [24]  482 	mov	dpl, #0x00
                                    483 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      0042EC 22               [24]  484 	ret
      0042ED                        485 00116$:
      0042ED 7D 01            [12]  486 	mov	r5,#0x01
      0042EF                        487 00106$:
                                    488 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      0042EF ED               [12]  489 	mov	a,r5
      0042F0 12 37 D2         [24]  490 	lcall	_ak820_outline_0013
      0042F3 FC               [12]  491 	mov	r4,a
      0042F4 8D 02            [24]  492 	mov	ar2,r5
      0042F6 7B 00            [12]  493 	mov	r3,#0x00
      0042F8 74 04            [12]  494 	mov	a,#0x04
      0042FA 2A               [12]  495 	add	a, r2
      0042FB FA               [12]  496 	mov	r2,a
      0042FC E4               [12]  497 	clr	a
      0042FD 3B               [12]  498 	addc	a, r3
      0042FE FB               [12]  499 	mov	r3,a
      0042FF EA               [12]  500 	mov	a,r2
      004300 2E               [12]  501 	add	a, r6
      004301 F5 82            [12]  502 	mov	dpl,a
      004303 EB               [12]  503 	mov	a,r3
      004304 3F               [12]  504 	addc	a, r7
      004305 F5 83            [12]  505 	mov	dph,a
      004307 E0               [24]  506 	movx	a,@dptr
      004308 62 04            [12]  507 	xrl	ar4,a
      00430A BC FF 02         [24]  508 	cjne	r4,#0xff,00139$
      00430D 80 04            [24]  509 	sjmp	00107$
      00430F                        510 00139$:
      00430F 75 82 00         [24]  511 	mov	dpl, #0x00
      004312 22               [24]  512 	ret
      004313                        513 00107$:
                                    514 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004313 0D               [12]  515 	inc	r5
      004314 BD 05 D8         [24]  516 	cjne	r5,#0x05,00106$
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      004317 75 82 01         [24]  518 	mov	dpl, #0x01
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      00431A 22               [24]  520 	ret
                                    521 ;------------------------------------------------------------
                                    522 ;Allocation info for local variables in function 'recover_journal'
                                    523 ;------------------------------------------------------------
                                    524 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    525 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    526 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    527 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    528 ;------------------------------------------------------------
                                    529 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    530 ;	-----------------------------------------
                                    531 ;	 function recover_journal
                                    532 ;	-----------------------------------------
      00431B                        533 _recover_journal:
                                    534 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      00431B 7F 00            [12]  535 	mov	r7,#0x00
      00431D                        536 00115$:
      00431D EF               [12]  537 	mov	a,r7
      00431E 24 D4            [12]  538 	add	a, #_recover_journal_header_10000_46
      004320 FD               [12]  539 	mov	r5,a
      004321 E4               [12]  540 	clr	a
      004322 34 05            [12]  541 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      004324 FE               [12]  542 	mov	r6,a
      004325 8F 04            [24]  543 	mov	ar4,r7
      004327 7B 00            [12]  544 	mov	r3,#0x00
      004329 74 40            [12]  545 	mov	a,#0x40
      00432B 2C               [12]  546 	add	a, r4
      00432C FC               [12]  547 	mov	r4,a
      00432D 74 EF            [12]  548 	mov	a,#0xef
      00432F 3B               [12]  549 	addc	a, r3
      004330 FB               [12]  550 	mov	r3,a
      004331 12 49 9F         [24]  551 	lcall	_ak820_outline_0189
      004334 12 38 A7         [24]  552 	lcall	_ak820_flash_read
      004337 AC 82            [24]  553 	mov	r4, dpl
      004339 12 49 44         [24]  554 	lcall	_ak820_outline_0067
      00433C 0F               [12]  555 	inc	r7
      00433D BF 09 DD         [24]  556 	cjne	r7,#0x09,00115$
                                    557 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      004340 90 05 D4         [24]  558 	mov	dptr,#_recover_journal_header_10000_46
      004343 12 42 D3         [24]  559 	lcall	_journal_header_valid
      004346 E5 82            [12]  560 	mov	a, dpl
      004348 70 01            [24]  561 	jnz	00103$
      00434A 22               [24]  562 	ret
      00434B                        563 00103$:
                                    564 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      00434B 90 05 D5         [24]  565 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      00434E E0               [24]  566 	movx	a,@dptr
      00434F FF               [12]  567 	mov	r7,a
      004350 7E 00            [12]  568 	mov	r6,#0x00
      004352 90 05 D6         [24]  569 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      004355 E0               [24]  570 	movx	a,@dptr
      004356 FC               [12]  571 	mov	r4,a
      004357 E4               [12]  572 	clr	a
      004358 42 07            [12]  573 	orl	ar7,a
      00435A EC               [12]  574 	mov	a,r4
      00435B 42 06            [12]  575 	orl	ar6,a
                                    576 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      00435D 90 05 D7         [24]  577 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      004360 E0               [24]  578 	movx	a,@dptr
      004361 FD               [12]  579 	mov	r5,a
      004362 7C 00            [12]  580 	mov	r4,#0x00
      004364 90 05 D8         [24]  581 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      004367 E0               [24]  582 	movx	a,@dptr
      004368 FA               [12]  583 	mov	r2,a
      004369 E4               [12]  584 	clr	a
      00436A 12 49 79         [24]  585 	lcall	_ak820_outline_0147
                                    586 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      00436D C3               [12]  587 	clr	c
      00436E EF               [12]  588 	mov	a,r7
      00436F 94 A0            [12]  589 	subb	a,#0xa0
      004371 EE               [12]  590 	mov	a,r6
      004372 94 00            [12]  591 	subb	a,#0x00
      004374 40 06            [24]  592 	jc	00134$
                                    593 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      004376 75 82 01         [24]  594 	mov	dpl, #0x01
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      004379 02 41 8D         [24]  596 	ljmp	_nvm_fail
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      00437C                        598 00134$:
      00437C 7B 00            [12]  599 	mov	r3,#0x00
      00437E                        600 00117$:
      00437E C0 05            [24]  601 	push	ar5
      004380 C0 04            [24]  602 	push	ar4
      004382 EB               [12]  603 	mov	a,r3
      004383 24 85            [12]  604 	add	a, #_page_data
      004385 F9               [12]  605 	mov	r1,a
      004386 E4               [12]  606 	clr	a
      004387 34 05            [12]  607 	addc	a, #(_page_data >> 8)
      004389 FA               [12]  608 	mov	r2,a
      00438A 8B 00            [24]  609 	mov	ar0,r3
      00438C 7D 00            [12]  610 	mov	r5,#0x00
      00438E 74 EF            [12]  611 	mov	a,#0xef
      004390 2D               [12]  612 	add	a, r5
      004391 FD               [12]  613 	mov	r5,a
      004392 88 82            [24]  614 	mov	dpl, r0
      004394 8D 83            [24]  615 	mov	dph, r5
      004396 12 38 A7         [24]  616 	lcall	_ak820_flash_read
      004399 AD 82            [24]  617 	mov	r5, dpl
      00439B 12 49 89         [24]  618 	lcall	_ak820_outline_0163
      00439E ED               [12]  619 	mov	a,r5
      00439F F0               [24]  620 	movx	@dptr,a
      0043A0 0B               [12]  621 	inc	r3
      0043A1 BB 40 02         [24]  622 	cjne	r3,#0x40,00190$
      0043A4 80 06            [24]  623 	sjmp	00191$
      0043A6                        624 00190$:
      0043A6 D0 04            [24]  625 	pop	ar4
      0043A8 D0 05            [24]  626 	pop	ar5
      0043AA 80 D2            [24]  627 	sjmp	00117$
      0043AC                        628 00191$:
      0043AC D0 04            [24]  629 	pop	ar4
      0043AE D0 05            [24]  630 	pop	ar5
                                    631 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      0043B0 C0 07            [24]  632 	push	ar7
      0043B2 C0 06            [24]  633 	push	ar6
      0043B4 C0 05            [24]  634 	push	ar5
      0043B6 C0 04            [24]  635 	push	ar4
      0043B8 12 42 39         [24]  636 	lcall	_page_crc
      0043BB AA 82            [24]  637 	mov	r2, dpl
      0043BD AB 83            [24]  638 	mov	r3, dph
      0043BF D0 04            [24]  639 	pop	ar4
      0043C1 D0 05            [24]  640 	pop	ar5
      0043C3 D0 06            [24]  641 	pop	ar6
      0043C5 D0 07            [24]  642 	pop	ar7
      0043C7 EA               [12]  643 	mov	a,r2
      0043C8 B5 05 06         [24]  644 	cjne	a,ar5,00192$
      0043CB EB               [12]  645 	mov	a,r3
      0043CC B5 04 02         [24]  646 	cjne	a,ar4,00192$
      0043CF 80 06            [24]  647 	sjmp	00113$
      0043D1                        648 00192$:
      0043D1 75 82 02         [24]  649 	mov	dpl, #0x02
      0043D4 02 41 8D         [24]  650 	ljmp	_nvm_fail
      0043D7                        651 00113$:
                                    652 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      0043D7 EE               [12]  653 	mov	a,r6
      0043D8 54 03            [12]  654 	anl	a,#0x03
      0043DA A2 E0            [12]  655 	mov	c,acc.0
      0043DC CF               [12]  656 	xch	a,r7
      0043DD 13               [12]  657 	rrc	a
      0043DE CF               [12]  658 	xch	a,r7
      0043DF 13               [12]  659 	rrc	a
      0043E0 A2 E0            [12]  660 	mov	c,acc.0
      0043E2 CF               [12]  661 	xch	a,r7
      0043E3 13               [12]  662 	rrc	a
      0043E4 CF               [12]  663 	xch	a,r7
      0043E5 13               [12]  664 	rrc	a
      0043E6 CF               [12]  665 	xch	a,r7
      0043E7 24 C7            [12]  666 	add	a,#0xc7
      0043E9 FE               [12]  667 	mov	r6,a
      0043EA 12 49 8E         [24]  668 	lcall	_ak820_outline_0164
      0043ED 12 42 6C         [24]  669 	lcall	_write_page
      0043F0 E5 82            [12]  670 	mov	a, dpl
      0043F2 70 06            [24]  671 	jnz	00110$
      0043F4 75 82 03         [24]  672 	mov	dpl, #0x03
      0043F7 02 41 8D         [24]  673 	ljmp	_nvm_fail
      0043FA                        674 00110$:
                                    675 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      0043FA 90 EF 40         [24]  676 	mov	dptr,#0xef40
      0043FD 12 39 B4         [24]  677 	lcall	_ak820_flash_erase
      004400 E5 82            [12]  678 	mov	a, dpl
      004402 70 06            [24]  679 	jnz	00119$
      004404 75 82 04         [24]  680 	mov	dpl, #0x04
                                    681 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      004407 02 41 8D         [24]  682 	ljmp	_nvm_fail
      00440A                        683 00119$:
      00440A 22               [24]  684 	ret
                                    685 ;------------------------------------------------------------
                                    686 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    687 ;------------------------------------------------------------
                                    688 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    689 ;	-----------------------------------------
                                    690 ;	 function eeprom_driver_init
                                    691 ;	-----------------------------------------
      00440B                        692 _eeprom_driver_init:
                                    693 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    694 ;	assignBit
      00440B C2 0C            [12]  695 	clr	_storage_failed
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      00440D 90 05 C7         [24]  697 	mov	dptr,#_first_failure_stage
      004410 E4               [12]  698 	clr	a
      004411 F0               [24]  699 	movx	@dptr,a
                                    700 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    701 ;	assignBit
      004412 C2 0B            [12]  702 	clr	_page_dirty
                                    703 ;	assignBit
      004414 C2 0A            [12]  704 	clr	_page_valid
                                    705 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      004416 90 05 C6         [24]  706 	mov	dptr,#_batch_depth
      004419 E4               [12]  707 	clr	a
      00441A F0               [24]  708 	movx	@dptr,a
                                    709 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      00441B 12 43 1B         [24]  710 	lcall	_recover_journal
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      00441E 02 2A B7         [24]  713 	ljmp	_ak820_macro_init
                                    714 ;------------------------------------------------------------
                                    715 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    716 ;------------------------------------------------------------
                                    717 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    718 ;	-----------------------------------------
                                    719 ;	 function ak820_nvm_ok
                                    720 ;	-----------------------------------------
      004421                        721 _ak820_nvm_ok:
      004421 A2 0C            [12]  722 	mov	c,_storage_failed
      004423 B3               [12]  723 	cpl	c
      004424 92 0D            [24]  724 	mov  _ak820_nvm_ok_sloc0_1_0,c
      004426 12 38 69         [24]  725 	lcall	_ak820_outline_0149
      004429 22               [24]  726 	ret
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    729 ;------------------------------------------------------------
                                    730 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    731 ;	-----------------------------------------
                                    732 ;	 function ak820_nvm_schema_fault
                                    733 ;	-----------------------------------------
      00442A                        734 _ak820_nvm_schema_fault:
      00442A 75 82 10         [24]  735 	mov	dpl, #0x10
      00442D 02 41 8D         [24]  736 	ljmp	_nvm_fail
                                    737 ;------------------------------------------------------------
                                    738 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    739 ;------------------------------------------------------------
                                    740 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    741 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    742 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    743 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    744 ;------------------------------------------------------------
                                    745 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    746 ;	-----------------------------------------
                                    747 ;	 function ak820_nvm_flush
                                    748 ;	-----------------------------------------
      004430                        749 _ak820_nvm_flush:
                                    750 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      004430 30 0B 03         [24]  751 	jnb	_page_dirty,00101$
      004433 30 0C 01         [24]  752 	jnb	_storage_failed,00102$
      004436                        753 00101$:
      004436 22               [24]  754 	ret
      004437                        755 00102$:
                                    756 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      004437 12 42 39         [24]  757 	lcall	_page_crc
      00443A 12 49 6E         [24]  758 	lcall	_ak820_outline_0139
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      00443D 90 05 DD         [24]  760 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004440 74 A5            [12]  761 	mov	a,#0xa5
      004442 F0               [24]  762 	movx	@dptr,a
                                    763 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      004443 90 05 C5         [24]  764 	mov	dptr,#_cached_page
      004446 E0               [24]  765 	movx	a,@dptr
      004447 90 05 DE         [24]  766 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      00444A F0               [24]  767 	movx	@dptr,a
                                    768 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      00444B 90 05 DF         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      00444E E4               [12]  770 	clr	a
      00444F F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      004450 8E 05            [24]  773 	mov	ar5,r6
      004452 90 05 E0         [24]  774 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      004455 ED               [12]  775 	mov	a,r5
      004456 F0               [24]  776 	movx	@dptr,a
                                    777 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      004457 8F 06            [24]  778 	mov	ar6,r7
      004459 90 05 E1         [24]  779 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      00445C EE               [12]  780 	mov	a,r6
      00445D F0               [24]  781 	movx	@dptr,a
                                    782 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      00445E 7F 01            [12]  783 	mov	r7,#0x01
      004460                        784 00128$:
      004460 8F 06            [24]  785 	mov	ar6,r7
      004462 EE               [12]  786 	mov	a,r6
      004463 24 04            [12]  787 	add	a,#0x04
      004465 FE               [12]  788 	mov	r6,a
      004466 33               [12]  789 	rlc	a
      004467 95 E0            [12]  790 	subb	a,acc
      004469 FD               [12]  791 	mov	r5,a
      00446A EE               [12]  792 	mov	a,r6
      00446B 24 DD            [12]  793 	add	a, #_ak820_nvm_flush_header_10000_62
      00446D FE               [12]  794 	mov	r6,a
      00446E ED               [12]  795 	mov	a,r5
      00446F 34 05            [12]  796 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      004471 FD               [12]  797 	mov	r5,a
      004472 12 49 21         [24]  798 	lcall	_ak820_outline_0045
      004475 FC               [12]  799 	mov	r4,a
      004476 63 04 FF         [24]  800 	xrl	ar4,#0xff
      004479 8E 82            [24]  801 	mov	dpl,r6
      00447B 8D 83            [24]  802 	mov	dph,r5
      00447D EC               [12]  803 	mov	a,r4
      00447E F0               [24]  804 	movx	@dptr,a
      00447F 0F               [12]  805 	inc	r7
      004480 BF 05 DD         [24]  806 	cjne	r7,#0x05,00128$
                                    807 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      004483 90 05 E6         [24]  808 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004486 74 05            [12]  809 	mov	a,#0x05
      004488 F0               [24]  810 	movx	@dptr,a
                                    811 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004489 90 EF 40         [24]  812 	mov	dptr,#0xef40
      00448C 12 39 B4         [24]  813 	lcall	_ak820_flash_erase
      00448F E5 82            [12]  814 	mov	a, dpl
      004491 70 03            [24]  815 	jnz	00269$
      004493 02 45 7A         [24]  816 	ljmp	00127$
      004496                        817 00269$:
                                    818 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      004496 90 05 E6         [24]  819 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004499 74 06            [12]  820 	mov	a,#0x06
      00449B F0               [24]  821 	movx	@dptr,a
                                    822 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00449C 7F 00            [12]  823 	mov	r7,#0x00
      00449E                        824 00130$:
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      00449E 12 49 2D         [24]  826 	lcall	_ak820_outline_0057
      0044A1 12 38 A7         [24]  827 	lcall	_ak820_flash_read
      0044A4 E5 82            [12]  828 	mov	a, dpl
      0044A6 60 03            [24]  829 	jz	00270$
      0044A8 02 45 7A         [24]  830 	ljmp	00127$
      0044AB                        831 00270$:
                                    832 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0044AB 0F               [12]  833 	inc	r7
      0044AC BF 40 EF         [24]  834 	cjne	r7,#0x40,00130$
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      0044AF 90 05 E6         [24]  836 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044B2 74 07            [12]  837 	mov	a,#0x07
      0044B4 F0               [24]  838 	movx	@dptr,a
                                    839 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      0044B5 90 EF 00         [24]  840 	mov	dptr,#0xef00
      0044B8 12 42 6C         [24]  841 	lcall	_write_page
      0044BB E5 82            [12]  842 	mov	a, dpl
      0044BD 70 03            [24]  843 	jnz	00273$
      0044BF 02 45 7A         [24]  844 	ljmp	00127$
      0044C2                        845 00273$:
                                    846 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      0044C2 90 05 E6         [24]  847 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044C5 74 08            [12]  848 	mov	a,#0x08
      0044C7 F0               [24]  849 	movx	@dptr,a
                                    850 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0044C8 7F 01            [12]  851 	mov	r7,#0x01
      0044CA                        852 00132$:
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      0044CA 12 49 21         [24]  854 	lcall	_ak820_outline_0045
      0044CD FE               [12]  855 	mov	r6,a
      0044CE 60 23            [24]  856 	jz	00133$
      0044D0 8F 05            [24]  857 	mov	ar5,r7
      0044D2 7C 00            [12]  858 	mov	r4,#0x00
      0044D4 74 40            [12]  859 	mov	a,#0x40
      0044D6 2D               [12]  860 	add	a, r5
      0044D7 FD               [12]  861 	mov	r5,a
      0044D8 74 EF            [12]  862 	mov	a,#0xef
      0044DA 3C               [12]  863 	addc	a, r4
      0044DB FC               [12]  864 	mov	r4,a
      0044DC 90 04 F2         [24]  865 	mov	dptr,#_ak820_flash_program_PARM_2
      0044DF EE               [12]  866 	mov	a,r6
      0044E0 F0               [24]  867 	movx	@dptr,a
      0044E1 8D 82            [24]  868 	mov	dpl, r5
      0044E3 8C 83            [24]  869 	mov	dph, r4
      0044E5 C0 07            [24]  870 	push	ar7
      0044E7 12 3A 14         [24]  871 	lcall	_ak820_flash_program
      0044EA E5 82            [12]  872 	mov	a, dpl
      0044EC D0 07            [24]  873 	pop	ar7
      0044EE 70 03            [24]  874 	jnz	00275$
      0044F0 02 45 7A         [24]  875 	ljmp	00127$
      0044F3                        876 00275$:
      0044F3                        877 00133$:
                                    878 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0044F3 0F               [12]  879 	inc	r7
      0044F4 BF 09 D3         [24]  880 	cjne	r7,#0x09,00132$
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      0044F7 90 05 E6         [24]  882 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044FA 74 09            [12]  883 	mov	a,#0x09
      0044FC F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      0044FD 7F 01            [12]  886 	mov	r7,#0x01
      0044FF                        887 00134$:
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      0044FF 12 49 2D         [24]  889 	lcall	_ak820_outline_0057
      004502 12 38 A7         [24]  890 	lcall	_ak820_flash_read
      004505 AE 82            [24]  891 	mov	r6, dpl
      004507 12 49 21         [24]  892 	lcall	_ak820_outline_0045
      00450A FD               [12]  893 	mov	r5,a
      00450B EE               [12]  894 	mov	a,r6
      00450C B5 05 6B         [24]  895 	cjne	a,ar5,00127$
                                    896 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      00450F 0F               [12]  897 	inc	r7
      004510 BF 09 EC         [24]  898 	cjne	r7,#0x09,00134$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004513 90 05 E6         [24]  900 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004516 74 0A            [12]  901 	mov	a,#0x0a
      004518 F0               [24]  902 	movx	@dptr,a
                                    903 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      004519 90 05 DD         [24]  904 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00451C E0               [24]  905 	movx	a,@dptr
      00451D 90 04 F2         [24]  906 	mov	dptr,#_ak820_flash_program_PARM_2
      004520 F0               [24]  907 	movx	@dptr,a
      004521 90 EF 40         [24]  908 	mov	dptr,#0xef40
      004524 12 3A 14         [24]  909 	lcall	_ak820_flash_program
      004527 E5 82            [12]  910 	mov	a, dpl
      004529 60 4F            [24]  911 	jz	00127$
                                    912 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      00452B 90 05 E6         [24]  913 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00452E 74 0B            [12]  914 	mov	a,#0x0b
      004530 F0               [24]  915 	movx	@dptr,a
                                    916 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004531 90 EF 40         [24]  917 	mov	dptr,#0xef40
      004534 12 38 A7         [24]  918 	lcall	_ak820_flash_read
      004537 AF 82            [24]  919 	mov	r7, dpl
      004539 90 05 DD         [24]  920 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00453C E0               [24]  921 	movx	a,@dptr
      00453D FE               [12]  922 	mov	r6,a
      00453E EF               [12]  923 	mov	a,r7
      00453F B5 06 38         [24]  924 	cjne	a,ar6,00127$
                                    925 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      004542 90 05 E6         [24]  926 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004545 74 0C            [12]  927 	mov	a,#0x0c
      004547 F0               [24]  928 	movx	@dptr,a
                                    929 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      004548 90 05 C5         [24]  930 	mov	dptr,#_cached_page
      00454B E0               [24]  931 	movx	a,@dptr
      00454C FE               [12]  932 	mov	r6,a
      00454D E4               [12]  933 	clr	a
      00454E C3               [12]  934 	clr	c
      00454F CE               [12]  935 	xch	a,r6
      004550 13               [12]  936 	rrc	a
      004551 CE               [12]  937 	xch	a,r6
      004552 13               [12]  938 	rrc	a
      004553 A2 E0            [12]  939 	mov	c,acc.0
      004555 CE               [12]  940 	xch	a,r6
      004556 13               [12]  941 	rrc	a
      004557 CE               [12]  942 	xch	a,r6
      004558 13               [12]  943 	rrc	a
      004559 CE               [12]  944 	xch	a,r6
      00455A 24 C7            [12]  945 	add	a,#0xc7
      00455C FF               [12]  946 	mov	r7,a
      00455D 12 49 5D         [24]  947 	lcall	_ak820_outline_0120
      004560 12 42 6C         [24]  948 	lcall	_write_page
      004563 E5 82            [12]  949 	mov	a, dpl
      004565 60 13            [24]  950 	jz	00127$
                                    951 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      004567 90 05 E6         [24]  952 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00456A 74 0D            [12]  953 	mov	a,#0x0d
      00456C F0               [24]  954 	movx	@dptr,a
                                    955 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      00456D 90 EF 40         [24]  956 	mov	dptr,#0xef40
      004570 12 39 B4         [24]  957 	lcall	_ak820_flash_erase
      004573 E5 82            [12]  958 	mov	a, dpl
      004575 60 03            [24]  959 	jz	00127$
                                    960 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    961 ;	assignBit
      004577 C2 0B            [12]  962 	clr	_page_dirty
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      004579 22               [24]  965 	ret
      00457A                        966 00127$:
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      00457A 90 05 E6         [24]  968 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00457D E0               [24]  969 	movx	a,@dptr
      00457E F5 82            [12]  970 	mov	dpl,a
                                    971 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      004580 02 41 8D         [24]  972 	ljmp	_nvm_fail
                                    973 ;------------------------------------------------------------
                                    974 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    975 ;------------------------------------------------------------
                                    976 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    977 ;	-----------------------------------------
                                    978 ;	 function ak820_nvm_begin
                                    979 ;	-----------------------------------------
      004583                        980 _ak820_nvm_begin:
                                    981 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      004583 90 05 C6         [24]  982 	mov	dptr,#_batch_depth
      004586 E0               [24]  983 	movx	a,@dptr
      004587 FF               [12]  984 	mov	r7,a
      004588 BF FF 06         [24]  985 	cjne	r7,#0xff,00102$
      00458B 75 82 0F         [24]  986 	mov	dpl, #0x0f
      00458E 02 41 8D         [24]  987 	ljmp	_nvm_fail
      004591                        988 00102$:
                                    989 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      004591 90 05 C6         [24]  990 	mov	dptr,#_batch_depth
      004594 EF               [12]  991 	mov	a,r7
      004595 04               [12]  992 	inc	a
      004596 F0               [24]  993 	movx	@dptr,a
                                    994 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      004597 22               [24]  995 	ret
                                    996 ;------------------------------------------------------------
                                    997 ;Allocation info for local variables in function 'ak820_nvm_end'
                                    998 ;------------------------------------------------------------
                                    999 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1000 ;	-----------------------------------------
                                   1001 ;	 function ak820_nvm_end
                                   1002 ;	-----------------------------------------
      004598                       1003 _ak820_nvm_end:
                                   1004 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      004598 90 05 C6         [24] 1005 	mov	dptr,#_batch_depth
      00459B E0               [24] 1006 	movx	a,@dptr
      00459C FF               [12] 1007 	mov	r7,a
      00459D E0               [24] 1008 	movx	a,@dptr
      00459E 60 06            [24] 1009 	jz	00102$
      0045A0 EF               [12] 1010 	mov	a,r7
      0045A1 14               [12] 1011 	dec	a
      0045A2 90 05 C6         [24] 1012 	mov	dptr,#_batch_depth
      0045A5 F0               [24] 1013 	movx	@dptr,a
      0045A6                       1014 00102$:
                                   1015 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      0045A6 90 05 C6         [24] 1016 	mov	dptr,#_batch_depth
      0045A9 E0               [24] 1017 	movx	a,@dptr
      0045AA 70 03            [24] 1018 	jnz	00105$
                                   1019 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      0045AC 02 44 30         [24] 1020 	ljmp	_ak820_nvm_flush
      0045AF                       1021 00105$:
      0045AF 22               [24] 1022 	ret
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'load_page'
                                   1025 ;------------------------------------------------------------
                                   1026 ;page          Allocated with name '_load_page_page_10000_87'
                                   1027 ;i             Allocated with name '_load_page_i_10000_88'
                                   1028 ;------------------------------------------------------------
                                   1029 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1030 ;	-----------------------------------------
                                   1031 ;	 function load_page
                                   1032 ;	-----------------------------------------
      0045B0                       1033 _load_page:
      0045B0 E5 82            [12] 1034 	mov	a,dpl
      0045B2 90 05 E7         [24] 1035 	mov	dptr,#_load_page_page_10000_87
      0045B5 F0               [24] 1036 	movx	@dptr,a
                                   1037 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      0045B6 30 0A 17         [24] 1038 	jnb	_page_valid,00102$
      0045B9 90 05 C5         [24] 1039 	mov	dptr,#_cached_page
      0045BC E0               [24] 1040 	movx	a,@dptr
      0045BD FF               [12] 1041 	mov	r7,a
      0045BE 90 05 E7         [24] 1042 	mov	dptr,#_load_page_page_10000_87
      0045C1 E0               [24] 1043 	movx	a,@dptr
      0045C2 FE               [12] 1044 	mov	r6,a
      0045C3 EF               [12] 1045 	mov	a,r7
      0045C4 B5 06 09         [24] 1046 	cjne	a,ar6,00102$
      0045C7 A2 0C            [12] 1047 	mov	c,_storage_failed
      0045C9 B3               [12] 1048 	cpl	c
      0045CA 92 0E            [24] 1049 	mov  _load_page_sloc0_1_0,c
      0045CC 12 38 69         [24] 1050 	lcall	_ak820_outline_0149
      0045CF 22               [24] 1051 	ret
      0045D0                       1052 00102$:
                                   1053 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      0045D0 12 44 30         [24] 1054 	lcall	_ak820_nvm_flush
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      0045D3 30 0C 04         [24] 1056 	jnb	_storage_failed,00119$
      0045D6 75 82 00         [24] 1057 	mov	dpl, #0x00
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0045D9 22               [24] 1059 	ret
      0045DA                       1060 00119$:
      0045DA 7F 00            [12] 1061 	mov	r7,#0x00
      0045DC                       1062 00107$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      0045DC EF               [12] 1064 	mov	a,r7
      0045DD 24 85            [12] 1065 	add	a, #_page_data
      0045DF FD               [12] 1066 	mov	r5,a
      0045E0 E4               [12] 1067 	clr	a
      0045E1 34 05            [12] 1068 	addc	a, #(_page_data >> 8)
      0045E3 FE               [12] 1069 	mov	r6,a
      0045E4 90 05 E7         [24] 1070 	mov	dptr,#_load_page_page_10000_87
      0045E7 E0               [24] 1071 	movx	a,@dptr
      0045E8 FC               [12] 1072 	mov	r4,a
      0045E9 FA               [12] 1073 	mov	r2,a
      0045EA E4               [12] 1074 	clr	a
      0045EB C3               [12] 1075 	clr	c
      0045EC CA               [12] 1076 	xch	a,r2
      0045ED 13               [12] 1077 	rrc	a
      0045EE CA               [12] 1078 	xch	a,r2
      0045EF 13               [12] 1079 	rrc	a
      0045F0 A2 E0            [12] 1080 	mov	c,acc.0
      0045F2 CA               [12] 1081 	xch	a,r2
      0045F3 13               [12] 1082 	rrc	a
      0045F4 CA               [12] 1083 	xch	a,r2
      0045F5 13               [12] 1084 	rrc	a
      0045F6 CA               [12] 1085 	xch	a,r2
      0045F7 24 C7            [12] 1086 	add	a,#0xc7
      0045F9 FB               [12] 1087 	mov	r3,a
      0045FA 8F 01            [24] 1088 	mov	ar1,r7
      0045FC 89 00            [24] 1089 	mov	ar0,r1
      0045FE 79 00            [12] 1090 	mov	r1,#0x00
      004600 E8               [12] 1091 	mov	a,r0
      004601 2A               [12] 1092 	add	a, r2
      004602 FA               [12] 1093 	mov	r2,a
      004603 E9               [12] 1094 	mov	a,r1
      004604 3B               [12] 1095 	addc	a, r3
      004605 FB               [12] 1096 	mov	r3,a
      004606 12 49 7F         [24] 1097 	lcall	_ak820_outline_0148
      004609 12 38 A7         [24] 1098 	lcall	_ak820_flash_read
      00460C AB 82            [24] 1099 	mov	r3, dpl
      00460E 12 38 5E         [24] 1100 	lcall	_ak820_outline_0138
      004611 EB               [12] 1101 	mov	a,r3
      004612 F0               [24] 1102 	movx	@dptr,a
                                   1103 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004613 0F               [12] 1104 	inc	r7
      004614 BF 40 C5         [24] 1105 	cjne	r7,#0x40,00107$
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004617 90 05 C5         [24] 1107 	mov	dptr,#_cached_page
      00461A EC               [12] 1108 	mov	a,r4
      00461B F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1111 ;	assignBit
      00461C D2 0A            [12] 1112 	setb	_page_valid
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00461E 75 82 01         [24] 1114 	mov	dpl, #0x01
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004621 22               [24] 1116 	ret
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'read_offset'
                                   1119 ;------------------------------------------------------------
                                   1120 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function read_offset
                                   1125 ;	-----------------------------------------
      004622                       1126 _read_offset:
      004622 12 38 44         [24] 1127 	lcall	_ak820_outline_0109
      004625 90 05 E8         [24] 1128 	mov	dptr,#_read_offset_offset_10000_93
      004628 12 38 49         [24] 1129 	lcall	_ak820_outline_0110
                                   1130 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00462B 90 05 E8         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      00462E 12 37 FD         [24] 1132 	lcall	_ak820_outline_0056
      004631 C3               [12] 1133 	clr	c
      004632 94 28            [12] 1134 	subb	a,#0x28
      004634 40 04            [24] 1135 	jc	00102$
      004636 75 82 00         [24] 1136 	mov	dpl, #0x00
      004639 22               [24] 1137 	ret
      00463A                       1138 00102$:
                                   1139 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      00463A 30 0A 34         [24] 1140 	jnb	_page_valid,00104$
      00463D 8E 04            [24] 1141 	mov	ar4,r6
      00463F EF               [12] 1142 	mov	a,r7
      004640 A2 E7            [12] 1143 	mov	c,acc.7
      004642 CC               [12] 1144 	xch	a,r4
      004643 33               [12] 1145 	rlc	a
      004644 CC               [12] 1146 	xch	a,r4
      004645 33               [12] 1147 	rlc	a
      004646 A2 E7            [12] 1148 	mov	c,acc.7
      004648 CC               [12] 1149 	xch	a,r4
      004649 33               [12] 1150 	rlc	a
      00464A CC               [12] 1151 	xch	a,r4
      00464B 33               [12] 1152 	rlc	a
      00464C CC               [12] 1153 	xch	a,r4
      00464D 54 03            [12] 1154 	anl	a,#0x03
      00464F FD               [12] 1155 	mov	r5,a
      004650 90 05 C5         [24] 1156 	mov	dptr,#_cached_page
      004653 E0               [24] 1157 	movx	a,@dptr
      004654 FA               [12] 1158 	mov	r2,a
      004655 7B 00            [12] 1159 	mov	r3,#0x00
      004657 EC               [12] 1160 	mov	a,r4
      004658 B5 02 16         [24] 1161 	cjne	a,ar2,00104$
      00465B ED               [12] 1162 	mov	a,r5
      00465C B5 03 12         [24] 1163 	cjne	a,ar3,00104$
                                   1164 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      00465F 74 3F            [12] 1165 	mov	a,#0x3f
      004661 5E               [12] 1166 	anl	a,r6
      004662 7D 00            [12] 1167 	mov	r5,#0x00
      004664 24 85            [12] 1168 	add	a, #_page_data
      004666 F5 82            [12] 1169 	mov	dpl,a
      004668 ED               [12] 1170 	mov	a,r5
      004669 34 05            [12] 1171 	addc	a, #(_page_data >> 8)
      00466B F5 83            [12] 1172 	mov	dph,a
      00466D E0               [24] 1173 	movx	a,@dptr
      00466E F5 82            [12] 1174 	mov	dpl,a
      004670 22               [24] 1175 	ret
      004671                       1176 00104$:
                                   1177 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004671 74 C7            [12] 1178 	mov	a,#0xc7
      004673 2F               [12] 1179 	add	a, r7
      004674 FF               [12] 1180 	mov	r7,a
      004675 12 49 5D         [24] 1181 	lcall	_ak820_outline_0120
                                   1182 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004678 02 38 A7         [24] 1183 	ljmp	_ak820_flash_read
                                   1184 ;------------------------------------------------------------
                                   1185 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1186 ;------------------------------------------------------------
                                   1187 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function eeprom_read_byte
                                   1192 ;	-----------------------------------------
      00467B                       1193 _eeprom_read_byte:
      00467B C0 07            [24] 1194 	push	ar7
      00467D C0 06            [24] 1195 	push	ar6
      00467F 12 49 1A         [24] 1196 	lcall	_ak820_outline_0038
      004682 90 05 EA         [24] 1197 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004685 12 37 E5         [24] 1198 	lcall	_ak820_outline_0020
                                   1199 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004688 90 05 EA         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00468B 12 37 BE         [24] 1201 	lcall	_ak820_outline_0007
      00468E C0 06            [24] 1202 	push	ar6
      004690 C0 05            [24] 1203 	push	ar5
      004692 C0 04            [24] 1204 	push	ar4
      004694 C0 03            [24] 1205 	push	ar3
      004696 C0 02            [24] 1206 	push	ar2
      004698 C0 01            [24] 1207 	push	ar1
      00469A C0 00            [24] 1208 	push	ar0
      00469C 12 46 22         [24] 1209 	lcall	_read_offset
      00469F AF 82            [24] 1210 	mov	r7, dpl
      0046A1 D0 00            [24] 1211 	pop	ar0
      0046A3 D0 01            [24] 1212 	pop	ar1
      0046A5 D0 02            [24] 1213 	pop	ar2
      0046A7 D0 03            [24] 1214 	pop	ar3
      0046A9 D0 04            [24] 1215 	pop	ar4
      0046AB D0 05            [24] 1216 	pop	ar5
      0046AD D0 06            [24] 1217 	pop	ar6
      0046AF 8F 82            [24] 1218 	mov	dpl, r7
                                   1219 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0046B1 D0 06            [24] 1220 	pop	ar6
      0046B3 D0 07            [24] 1221 	pop	ar7
      0046B5 22               [24] 1222 	ret
                                   1223 ;------------------------------------------------------------
                                   1224 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1225 ;------------------------------------------------------------
                                   1226 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1227 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1228 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1229 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1230 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1231 ;------------------------------------------------------------
                                   1232 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1233 ;	-----------------------------------------
                                   1234 ;	 function ak820_eeprom_read_block_xdata
                                   1235 ;	-----------------------------------------
      0046B6                       1236 _ak820_eeprom_read_block_xdata:
      0046B6 12 38 44         [24] 1237 	lcall	_ak820_outline_0109
      0046B9 90 05 F2         [24] 1238 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0046BC 12 38 49         [24] 1239 	lcall	_ak820_outline_0110
                                   1240 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0046BF 90 05 ED         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0046C2 12 37 FD         [24] 1242 	lcall	_ak820_outline_0056
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0046C5 90 05 F2         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0046C8 12 38 14         [24] 1245 	lcall	_ak820_outline_0062
      0046CB 90 05 F4         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0046CE 12 38 20         [24] 1247 	lcall	_ak820_outline_0078
                                   1248 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0046D1 90 05 F0         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0046D4 12 38 14         [24] 1250 	lcall	_ak820_outline_0062
      0046D7                       1251 00103$:
      0046D7 8C 02            [24] 1252 	mov	ar2,r4
      0046D9 8D 03            [24] 1253 	mov	ar3,r5
      0046DB 1C               [12] 1254 	dec	r4
      0046DC BC FF 01         [24] 1255 	cjne	r4,#0xff,00130$
      0046DF 1D               [12] 1256 	dec	r5
      0046E0                       1257 00130$:
      0046E0 EA               [12] 1258 	mov	a,r2
      0046E1 4B               [12] 1259 	orl	a,r3
      0046E2 60 5D            [24] 1260 	jz	00106$
                                   1261 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0046E4 8E 02            [24] 1262 	mov	ar2,r6
      0046E6 8F 03            [24] 1263 	mov	ar3,r7
      0046E8 74 D8            [12] 1264 	mov	a,#0x100 - 0x28
      0046EA 2B               [12] 1265 	add	a,r3
      0046EB 50 17            [24] 1266 	jnc	00102$
      0046ED 90 05 F4         [24] 1267 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0046F0 12 49 68         [24] 1268 	lcall	_ak820_outline_0126
      0046F3 12 49 7F         [24] 1269 	lcall	_ak820_outline_0148
      0046F6 E4               [12] 1270 	clr	a
      0046F7 F0               [24] 1271 	movx	@dptr,a
      0046F8 90 05 F4         [24] 1272 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0046FB 04               [12] 1273 	inc	a
      0046FC 2A               [12] 1274 	add	a, r2
      0046FD F0               [24] 1275 	movx	@dptr,a
      0046FE E4               [12] 1276 	clr	a
      0046FF 3B               [12] 1277 	addc	a, r3
      004700 A3               [24] 1278 	inc	dptr
      004701 F0               [24] 1279 	movx	@dptr,a
      004702 80 D3            [24] 1280 	sjmp	00103$
      004704                       1281 00102$:
                                   1282 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004704 90 05 F4         [24] 1283 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004707 12 49 68         [24] 1284 	lcall	_ak820_outline_0126
      00470A 12 49 5D         [24] 1285 	lcall	_ak820_outline_0120
      00470D C0 07            [24] 1286 	push	ar7
      00470F C0 06            [24] 1287 	push	ar6
      004711 C0 05            [24] 1288 	push	ar5
      004713 C0 04            [24] 1289 	push	ar4
      004715 C0 03            [24] 1290 	push	ar3
      004717 C0 02            [24] 1291 	push	ar2
      004719 12 46 22         [24] 1292 	lcall	_read_offset
      00471C A9 82            [24] 1293 	mov	r1, dpl
      00471E D0 02            [24] 1294 	pop	ar2
      004720 D0 03            [24] 1295 	pop	ar3
      004722 D0 04            [24] 1296 	pop	ar4
      004724 D0 05            [24] 1297 	pop	ar5
      004726 D0 06            [24] 1298 	pop	ar6
      004728 D0 07            [24] 1299 	pop	ar7
      00472A 12 49 7F         [24] 1300 	lcall	_ak820_outline_0148
      00472D E9               [12] 1301 	mov	a,r1
      00472E F0               [24] 1302 	movx	@dptr,a
      00472F 90 05 F4         [24] 1303 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004732 74 01            [12] 1304 	mov	a,#0x01
      004734 2A               [12] 1305 	add	a, r2
      004735 F0               [24] 1306 	movx	@dptr,a
      004736 E4               [12] 1307 	clr	a
      004737 3B               [12] 1308 	addc	a, r3
      004738 A3               [24] 1309 	inc	dptr
      004739 F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00473A 0E               [12] 1312 	inc	r6
      00473B BE 00 99         [24] 1313 	cjne	r6,#0x00,00103$
      00473E 0F               [12] 1314 	inc	r7
      00473F 80 96            [24] 1315 	sjmp	00103$
      004741                       1316 00106$:
                                   1317 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004741 22               [24] 1318 	ret
                                   1319 ;------------------------------------------------------------
                                   1320 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1321 ;------------------------------------------------------------
                                   1322 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1323 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1324 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1325 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1326 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1327 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1328 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1329 ;------------------------------------------------------------
                                   1330 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1331 ;	-----------------------------------------
                                   1332 ;	 function ak820_eeprom_write_block_xdata
                                   1333 ;	-----------------------------------------
      004742                       1334 _ak820_eeprom_write_block_xdata:
      004742 12 38 44         [24] 1335 	lcall	_ak820_outline_0109
      004745 90 05 FB         [24] 1336 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004748 12 38 49         [24] 1337 	lcall	_ak820_outline_0110
                                   1338 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00474B 90 05 F6         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00474E 12 37 FD         [24] 1340 	lcall	_ak820_outline_0056
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004751 90 05 FB         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004754 12 38 14         [24] 1343 	lcall	_ak820_outline_0062
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004757 8E 02            [24] 1345 	mov	ar2,r6
      004759 8F 03            [24] 1346 	mov	ar3,r7
      00475B C3               [12] 1347 	clr	c
      00475C E4               [12] 1348 	clr	a
      00475D 9A               [12] 1349 	subb	a,r2
      00475E 74 28            [12] 1350 	mov	a,#0x28
      004760 9B               [12] 1351 	subb	a,r3
      004761 40 15            [24] 1352 	jc	00101$
                                   1353 ;	free result
      004763 E4               [12] 1354 	clr	a
      004764 C3               [12] 1355 	clr	c
      004765 9E               [12] 1356 	subb	a,r6
      004766 FA               [12] 1357 	mov	r2,a
      004767 74 28            [12] 1358 	mov	a,#0x28
      004769 9F               [12] 1359 	subb	a,r7
      00476A FB               [12] 1360 	mov	r3,a
      00476B 90 05 F9         [24] 1361 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00476E 12 38 3E         [24] 1362 	lcall	_ak820_outline_0105
      004771 C3               [12] 1363 	clr	c
      004772 EA               [12] 1364 	mov	a,r2
      004773 98               [12] 1365 	subb	a,r0
      004774 EB               [12] 1366 	mov	a,r3
      004775 99               [12] 1367 	subb	a,r1
      004776 50 06            [24] 1368 	jnc	00125$
                                   1369 ;	free result
      004778                       1370 00101$:
                                   1371 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004778 75 82 0E         [24] 1372 	mov	dpl, #0x0e
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00477B 02 41 8D         [24] 1374 	ljmp	_nvm_fail
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      00477E                       1376 00125$:
      00477E 90 05 F9         [24] 1377 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004781 12 49 68         [24] 1378 	lcall	_ak820_outline_0126
      004784                       1379 00108$:
      004784 8A 00            [24] 1380 	mov	ar0,r2
      004786 8B 01            [24] 1381 	mov	ar1,r3
      004788 1A               [12] 1382 	dec	r2
      004789 BA FF 01         [24] 1383 	cjne	r2,#0xff,00159$
      00478C 1B               [12] 1384 	dec	r3
      00478D                       1385 00159$:
      00478D E8               [12] 1386 	mov	a,r0
      00478E 49               [12] 1387 	orl	a,r1
      00478F 70 03            [24] 1388 	jnz	00160$
      004791 02 48 1B         [24] 1389 	ljmp	00110$
      004794                       1390 00160$:
                                   1391 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004794 C0 02            [24] 1392 	push	ar2
      004796 C0 03            [24] 1393 	push	ar3
      004798 12 49 4B         [24] 1394 	lcall	_ak820_outline_0080
      00479B F9               [12] 1395 	mov	r1,a
      00479C A3               [24] 1396 	inc	dptr
      00479D 12 49 84         [24] 1397 	lcall	_ak820_outline_0155
                                   1398 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0047A0 8E 15            [24] 1399 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0047A2 8F 16            [24] 1400 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0047A4 A8 15            [24] 1401 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0047A6 E5 16            [12] 1402 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0047A8 A2 E7            [12] 1403 	mov	c,acc.7
      0047AA C8               [12] 1404 	xch	a,r0
      0047AB 33               [12] 1405 	rlc	a
      0047AC C8               [12] 1406 	xch	a,r0
      0047AD 33               [12] 1407 	rlc	a
      0047AE A2 E7            [12] 1408 	mov	c,acc.7
      0047B0 C8               [12] 1409 	xch	a,r0
      0047B1 33               [12] 1410 	rlc	a
      0047B2 C8               [12] 1411 	xch	a,r0
      0047B3 33               [12] 1412 	rlc	a
      0047B4 C8               [12] 1413 	xch	a,r0
      0047B5 54 03            [12] 1414 	anl	a,#0x03
      0047B7 FB               [12] 1415 	mov	r3,a
      0047B8 88 82            [24] 1416 	mov	dpl, r0
      0047BA C0 07            [24] 1417 	push	ar7
      0047BC C0 06            [24] 1418 	push	ar6
      0047BE C0 05            [24] 1419 	push	ar5
      0047C0 C0 04            [24] 1420 	push	ar4
      0047C2 C0 03            [24] 1421 	push	ar3
      0047C4 C0 02            [24] 1422 	push	ar2
      0047C6 C0 01            [24] 1423 	push	ar1
      0047C8 12 45 B0         [24] 1424 	lcall	_load_page
      0047CB E5 82            [12] 1425 	mov	a, dpl
      0047CD D0 01            [24] 1426 	pop	ar1
      0047CF D0 02            [24] 1427 	pop	ar2
      0047D1 D0 03            [24] 1428 	pop	ar3
      0047D3 D0 04            [24] 1429 	pop	ar4
      0047D5 D0 05            [24] 1430 	pop	ar5
      0047D7 D0 06            [24] 1431 	pop	ar6
      0047D9 D0 07            [24] 1432 	pop	ar7
      0047DB D0 03            [24] 1433 	pop	ar3
      0047DD D0 02            [24] 1434 	pop	ar2
      0047DF 70 01            [24] 1435 	jnz	00105$
      0047E1 22               [24] 1436 	ret
      0047E2                       1437 00105$:
                                   1438 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0047E2 C0 06            [24] 1439 	push	ar6
      0047E4 C0 07            [24] 1440 	push	ar7
      0047E6 74 3F            [12] 1441 	mov	a,#0x3f
      0047E8 55 15            [12] 1442 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0047EA 7F 00            [12] 1443 	mov	r7,#0x00
      0047EC 24 85            [12] 1444 	add	a, #_page_data
      0047EE F5 15            [12] 1445 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0047F0 EF               [12] 1446 	mov	a,r7
      0047F1 34 05            [12] 1447 	addc	a, #(_page_data >> 8)
      0047F3 F5 16            [12] 1448 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0047F5 85 15 82         [24] 1449 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0047F8 85 16 83         [24] 1450 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0047FB E0               [24] 1451 	movx	a,@dptr
      0047FC B5 01 06         [24] 1452 	cjne	a,ar1,00162$
      0047FF D0 07            [24] 1453 	pop	ar7
      004801 D0 06            [24] 1454 	pop	ar6
      004803 80 0E            [24] 1455 	sjmp	00107$
      004805                       1456 00162$:
      004805 D0 07            [24] 1457 	pop	ar7
      004807 D0 06            [24] 1458 	pop	ar6
                                   1459 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004809 85 15 82         [24] 1460 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00480C 85 16 83         [24] 1461 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00480F E9               [12] 1462 	mov	a,r1
      004810 F0               [24] 1463 	movx	@dptr,a
                                   1464 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1465 ;	assignBit
      004811 D2 0B            [12] 1466 	setb	_page_dirty
      004813                       1467 00107$:
                                   1468 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004813 0E               [12] 1469 	inc	r6
      004814 BE 00 01         [24] 1470 	cjne	r6,#0x00,00163$
      004817 0F               [12] 1471 	inc	r7
      004818                       1472 00163$:
      004818 02 47 84         [24] 1473 	ljmp	00108$
      00481B                       1474 00110$:
                                   1475 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00481B 90 05 C6         [24] 1476 	mov	dptr,#_batch_depth
      00481E E0               [24] 1477 	movx	a,@dptr
      00481F 70 03            [24] 1478 	jnz	00113$
                                   1479 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004821 02 44 30         [24] 1480 	ljmp	_ak820_nvm_flush
      004824                       1481 00113$:
      004824 22               [24] 1482 	ret
                                   1483 ;------------------------------------------------------------
                                   1484 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1485 ;------------------------------------------------------------
                                   1486 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1487 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1488 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1489 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1490 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1491 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1492 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1493 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1494 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1495 ;------------------------------------------------------------
                                   1496 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1497 ;	-----------------------------------------
                                   1498 ;	 function ak820_eeprom_update_block_xdata
                                   1499 ;	-----------------------------------------
      004825                       1500 _ak820_eeprom_update_block_xdata:
      004825 12 38 44         [24] 1501 	lcall	_ak820_outline_0109
      004828 90 06 02         [24] 1502 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00482B 12 38 49         [24] 1503 	lcall	_ak820_outline_0110
                                   1504 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00482E 90 06 02         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004831 12 37 FD         [24] 1506 	lcall	_ak820_outline_0056
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004834 90 05 FD         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004837 E0               [24] 1509 	movx	a,@dptr
      004838 F5 1B            [12] 1510 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00483A A3               [24] 1511 	inc	dptr
      00483B E0               [24] 1512 	movx	a,@dptr
      00483C F5 1C            [12] 1513 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      00483E A3               [24] 1514 	inc	dptr
      00483F E0               [24] 1515 	movx	a,@dptr
      004840 F5 1D            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004842 A9 1B            [24] 1517 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004844 AA 1C            [24] 1518 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1519 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004846 E4               [12] 1520 	clr	a
      004847 F5 17            [12] 1521 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004849 F5 18            [12] 1522 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00484B                       1523 00105$:
      00484B 90 06 00         [24] 1524 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00484E E0               [24] 1525 	movx	a,@dptr
      00484F F5 19            [12] 1526 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004851 A3               [24] 1527 	inc	dptr
      004852 E0               [24] 1528 	movx	a,@dptr
      004853 F5 1A            [12] 1529 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004855 C3               [12] 1530 	clr	c
      004856 E5 17            [12] 1531 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004858 95 19            [12] 1532 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00485A E5 18            [12] 1533 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00485C 95 1A            [12] 1534 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00485E 50 68            [24] 1535 	jnc	00107$
                                   1536 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004860 89 00            [24] 1537 	mov	ar0,r1
      004862 8A 05            [24] 1538 	mov	ar5,r2
      004864 E5 17            [12] 1539 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004866 28               [12] 1540 	add	a, r0
      004867 F8               [12] 1541 	mov	r0,a
      004868 E5 18            [12] 1542 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00486A 3D               [12] 1543 	addc	a, r5
      00486B FD               [12] 1544 	mov	r5,a
      00486C 88 82            [24] 1545 	mov	dpl, r0
      00486E 8D 83            [24] 1546 	mov	dph, r5
      004870 C0 07            [24] 1547 	push	ar7
      004872 C0 06            [24] 1548 	push	ar6
      004874 C0 02            [24] 1549 	push	ar2
      004876 C0 01            [24] 1550 	push	ar1
      004878 12 46 22         [24] 1551 	lcall	_read_offset
      00487B AD 82            [24] 1552 	mov	r5, dpl
      00487D D0 01            [24] 1553 	pop	ar1
      00487F D0 02            [24] 1554 	pop	ar2
      004881 D0 06            [24] 1555 	pop	ar6
      004883 D0 07            [24] 1556 	pop	ar7
      004885 E5 17            [12] 1557 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004887 2E               [12] 1558 	add	a, r6
      004888 F5 82            [12] 1559 	mov	dpl,a
      00488A E5 18            [12] 1560 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00488C 3F               [12] 1561 	addc	a, r7
      00488D F5 83            [12] 1562 	mov	dph,a
      00488F E0               [24] 1563 	movx	a,@dptr
      004890 FC               [12] 1564 	mov	r4,a
      004891 ED               [12] 1565 	mov	a,r5
      004892 B5 04 02         [24] 1566 	cjne	a,ar4,00131$
      004895 80 27            [24] 1567 	sjmp	00106$
      004897                       1568 00131$:
                                   1569 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004897 90 06 02         [24] 1570 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00489A E0               [24] 1571 	movx	a,@dptr
      00489B F8               [12] 1572 	mov	r0,a
      00489C A3               [24] 1573 	inc	dptr
      00489D E0               [24] 1574 	movx	a,@dptr
      00489E FD               [12] 1575 	mov	r5,a
      00489F 90 05 F6         [24] 1576 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0048A2 E5 1B            [12] 1577 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0048A4 F0               [24] 1578 	movx	@dptr,a
      0048A5 E5 1C            [12] 1579 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0048A7 A3               [24] 1580 	inc	dptr
      0048A8 F0               [24] 1581 	movx	@dptr,a
      0048A9 E5 1D            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0048AB A3               [24] 1583 	inc	dptr
      0048AC F0               [24] 1584 	movx	@dptr,a
      0048AD 90 05 F9         [24] 1585 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0048B0 E5 19            [12] 1586 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0048B2 F0               [24] 1587 	movx	@dptr,a
      0048B3 E5 1A            [12] 1588 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0048B5 A3               [24] 1589 	inc	dptr
      0048B6 F0               [24] 1590 	movx	@dptr,a
      0048B7 88 82            [24] 1591 	mov	dpl, r0
      0048B9 8D 83            [24] 1592 	mov	dph, r5
                                   1593 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0048BB 02 47 42         [24] 1594 	ljmp	_ak820_eeprom_write_block_xdata
      0048BE                       1595 00106$:
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0048BE 05 17            [12] 1597 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0048C0 E4               [12] 1598 	clr	a
      0048C1 B5 17 87         [24] 1599 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0048C4 05 18            [12] 1600 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0048C6 80 83            [24] 1601 	sjmp	00105$
      0048C8                       1602 00107$:
                                   1603 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0048C8 22               [24] 1604 	ret
                                   1605 ;------------------------------------------------------------
                                   1606 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1607 ;------------------------------------------------------------
                                   1608 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1609 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1610 ;------------------------------------------------------------
                                   1611 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1612 ;	-----------------------------------------
                                   1613 ;	 function eeprom_driver_erase
                                   1614 ;	-----------------------------------------
      0048C9                       1615 _eeprom_driver_erase:
                                   1616 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0048C9 12 44 30         [24] 1617 	lcall	_ak820_nvm_flush
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0048CC 7F 00            [12] 1619 	mov	r7,#0x00
      0048CE                       1620 00111$:
      0048CE BF A0 01         [24] 1621 	cjne	r7,#0xa0,00165$
      0048D1 22               [24] 1622 	ret
      0048D2                       1623 00165$:
      0048D2 20 0C 32         [24] 1624 	jb	_storage_failed,00113$
                                   1625 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0048D5 8F 82            [24] 1626 	mov	dpl, r7
      0048D7 C0 07            [24] 1627 	push	ar7
      0048D9 12 45 B0         [24] 1628 	lcall	_load_page
      0048DC E5 82            [12] 1629 	mov	a, dpl
      0048DE D0 07            [24] 1630 	pop	ar7
      0048E0 70 01            [24] 1631 	jnz	00126$
                                   1632 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0048E2 22               [24] 1633 	ret
      0048E3                       1634 00126$:
      0048E3 7E 00            [12] 1635 	mov	r6,#0x00
      0048E5                       1636 00107$:
                                   1637 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0048E5 EE               [12] 1638 	mov	a,r6
      0048E6 24 85            [12] 1639 	add	a, #_page_data
      0048E8 FC               [12] 1640 	mov	r4,a
      0048E9 E4               [12] 1641 	clr	a
      0048EA 34 05            [12] 1642 	addc	a, #(_page_data >> 8)
      0048EC FD               [12] 1643 	mov	r5,a
      0048ED 12 49 4B         [24] 1644 	lcall	_ak820_outline_0080
      0048F0 60 07            [24] 1645 	jz	00108$
      0048F2 12 38 54         [24] 1646 	lcall	_ak820_outline_0128
      0048F5 E4               [12] 1647 	clr	a
      0048F6 F0               [24] 1648 	movx	@dptr,a
                                   1649 ;	assignBit
      0048F7 D2 0B            [12] 1650 	setb	_page_dirty
      0048F9                       1651 00108$:
                                   1652 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0048F9 0E               [12] 1653 	inc	r6
      0048FA BE 40 E8         [24] 1654 	cjne	r6,#0x40,00107$
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0048FD C0 07            [24] 1656 	push	ar7
      0048FF 12 44 30         [24] 1657 	lcall	_ak820_nvm_flush
      004902 D0 07            [24] 1658 	pop	ar7
                                   1659 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004904 0F               [12] 1660 	inc	r7
      004905 80 C7            [24] 1661 	sjmp	00111$
      004907                       1662 00113$:
                                   1663 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004907 22               [24] 1664 	ret
                                   1665 	.area CSEG    (CODE)
                                   1666 	.area CONST   (CODE)
                                   1667 	.area XINIT   (CODE)
                                   1668 	.area CABS    (ABS,CODE)
                                   1669 
                                   1670 ; Experimental exact instruction outlining.
                                   1671 	.globl _ak820_outline_0007
                                   1672 	.globl _ak820_outline_0011
                                   1673 	.globl _ak820_outline_0013
                                   1674 	.globl _ak820_outline_0020
                                   1675 	.globl _ak820_outline_0025
                                   1676 	.globl _ak820_outline_0038
                                   1677 	.globl _ak820_outline_0045
                                   1678 	.globl _ak820_outline_0056
                                   1679 	.globl _ak820_outline_0057
                                   1680 	.globl _ak820_outline_0062
                                   1681 	.globl _ak820_outline_0063
                                   1682 	.globl _ak820_outline_0067
                                   1683 	.globl _ak820_outline_0078
                                   1684 	.globl _ak820_outline_0080
                                   1685 	.globl _ak820_outline_0081
                                   1686 	.globl _ak820_outline_0095
                                   1687 	.globl _ak820_outline_0105
                                   1688 	.globl _ak820_outline_0107
                                   1689 	.globl _ak820_outline_0109
                                   1690 	.globl _ak820_outline_0110
                                   1691 	.globl _ak820_outline_0120
                                   1692 	.globl _ak820_outline_0124
                                   1693 	.globl _ak820_outline_0126
                                   1694 	.globl _ak820_outline_0127
                                   1695 	.globl _ak820_outline_0128
                                   1696 	.globl _ak820_outline_0138
                                   1697 	.globl _ak820_outline_0139
                                   1698 	.globl _ak820_outline_0141
                                   1699 	.globl _ak820_outline_0145
                                   1700 	.globl _ak820_outline_0147
                                   1701 	.globl _ak820_outline_0148
                                   1702 	.globl _ak820_outline_0149
                                   1703 	.globl _ak820_outline_0155
                                   1704 	.globl _ak820_outline_0163
                                   1705 	.globl _ak820_outline_0164
                                   1706 	.globl _ak820_outline_0167
                                   1707 	.globl _ak820_outline_0169
                                   1708 	.globl _ak820_outline_0189
                                   1709 
                                   1710 	.area CSEG (CODE)
                                   1711 ; function ak820_outline_0011
      004908                       1712 _ak820_outline_0011:
      004908 8E 82            [24] 1713 	mov	dpl,r6
      00490A 8F 83            [24] 1714 	mov	dph,r7
      00490C A3               [24] 1715 	inc	dptr
      00490D A3               [24] 1716 	inc	dptr
      00490E A3               [24] 1717 	inc	dptr
      00490F A3               [24] 1718 	inc	dptr
      004910 A3               [24] 1719 	inc	dptr
      004911 22               [24] 1720 	ret
                                   1721 
                                   1722 	.area CSEG (CODE)
                                   1723 ; function ak820_outline_0025
      004912                       1724 _ak820_outline_0025:
      004912 F0               [24] 1725 	movx	@dptr,a
      004913 8E 82            [24] 1726 	mov	dpl,r6
      004915 8F 83            [24] 1727 	mov	dph,r7
      004917 A3               [24] 1728 	inc	dptr
      004918 A3               [24] 1729 	inc	dptr
      004919 22               [24] 1730 	ret
                                   1731 
                                   1732 	.area CSEG (CODE)
                                   1733 ; function ak820_outline_0038
      00491A                       1734 _ak820_outline_0038:
      00491A AF F0            [24] 1735 	mov	r7,b
      00491C AE 83            [24] 1736 	mov	r6,dph
      00491E E5 82            [12] 1737 	mov	a,dpl
      004920 22               [24] 1738 	ret
                                   1739 
                                   1740 	.area CSEG (CODE)
                                   1741 ; function ak820_outline_0045
      004921                       1742 _ak820_outline_0045:
      004921 EF               [12] 1743 	mov	a,r7
      004922 24 DD            [12] 1744 	add	a,#_ak820_nvm_flush_header_10000_62
      004924 F5 82            [12] 1745 	mov	dpl,a
      004926 E4               [12] 1746 	clr	a
      004927 34 05            [12] 1747 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004929 F5 83            [12] 1748 	mov	dph,a
      00492B E0               [24] 1749 	movx	a,@dptr
      00492C 22               [24] 1750 	ret
                                   1751 
                                   1752 	.area CSEG (CODE)
                                   1753 ; function ak820_outline_0057
      00492D                       1754 _ak820_outline_0057:
      00492D 8F 06            [24] 1755 	mov	ar6,r7
      00492F 7D 00            [12] 1756 	mov	r5,#0x00
      004931 74 40            [12] 1757 	mov	a,#0x40
      004933 2E               [12] 1758 	add	a,r6
      004934 FE               [12] 1759 	mov	r6,a
      004935 74 EF            [12] 1760 	mov	a,#0xef
      004937 3D               [12] 1761 	addc	a,r5
      004938 FD               [12] 1762 	mov	r5,a
      004939 8E 82            [24] 1763 	mov	dpl,r6
      00493B 8D 83            [24] 1764 	mov	dph,r5
      00493D 22               [24] 1765 	ret
                                   1766 
                                   1767 	.area CSEG (CODE)
                                   1768 ; function ak820_outline_0063
      00493E                       1769 _ak820_outline_0063:
      00493E F0               [24] 1770 	movx	@dptr,a
      00493F 8E 82            [24] 1771 	mov	dpl,r6
      004941 8F 83            [24] 1772 	mov	dph,r7
      004943 22               [24] 1773 	ret
                                   1774 
                                   1775 	.area CSEG (CODE)
                                   1776 ; function ak820_outline_0067
      004944                       1777 _ak820_outline_0067:
      004944 8D 82            [24] 1778 	mov	dpl,r5
      004946 8E 83            [24] 1779 	mov	dph,r6
      004948 EC               [12] 1780 	mov	a,r4
      004949 F0               [24] 1781 	movx	@dptr,a
      00494A 22               [24] 1782 	ret
                                   1783 
                                   1784 	.area CSEG (CODE)
                                   1785 ; function ak820_outline_0080
      00494B                       1786 _ak820_outline_0080:
      00494B 8C 82            [24] 1787 	mov	dpl,r4
      00494D 8D 83            [24] 1788 	mov	dph,r5
      00494F E0               [24] 1789 	movx	a,@dptr
      004950 22               [24] 1790 	ret
                                   1791 
                                   1792 	.area CSEG (CODE)
                                   1793 ; function ak820_outline_0107
      004951                       1794 _ak820_outline_0107:
      004951 EF               [12] 1795 	mov	a,r7
      004952 24 85            [12] 1796 	add	a,#_page_data
      004954 F5 82            [12] 1797 	mov	dpl,a
      004956 E4               [12] 1798 	clr	a
      004957 34 05            [12] 1799 	addc	a,#(_page_data>>8)
      004959 F5 83            [12] 1800 	mov	dph,a
      00495B E0               [24] 1801 	movx	a,@dptr
      00495C 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0120
      00495D                       1806 _ak820_outline_0120:
      00495D 8E 82            [24] 1807 	mov	dpl,r6
      00495F 8F 83            [24] 1808 	mov	dph,r7
      004961 22               [24] 1809 	ret
                                   1810 
                                   1811 	.area CSEG (CODE)
                                   1812 ; function ak820_outline_0124
      004962                       1813 _ak820_outline_0124:
      004962 8C 82            [24] 1814 	mov	dpl,r4
      004964 8D 83            [24] 1815 	mov	dph,r5
      004966 F0               [24] 1816 	movx	@dptr,a
      004967 22               [24] 1817 	ret
                                   1818 
                                   1819 	.area CSEG (CODE)
                                   1820 ; function ak820_outline_0126
      004968                       1821 _ak820_outline_0126:
      004968 E0               [24] 1822 	movx	a,@dptr
      004969 FA               [12] 1823 	mov	r2,a
      00496A A3               [24] 1824 	inc	dptr
      00496B E0               [24] 1825 	movx	a,@dptr
      00496C FB               [12] 1826 	mov	r3,a
      00496D 22               [24] 1827 	ret
                                   1828 
                                   1829 	.area CSEG (CODE)
                                   1830 ; function ak820_outline_0139
      00496E                       1831 _ak820_outline_0139:
      00496E AE 82            [24] 1832 	mov	r6,dpl
      004970 AF 83            [24] 1833 	mov	r7,dph
      004972 22               [24] 1834 	ret
                                   1835 
                                   1836 	.area CSEG (CODE)
                                   1837 ; function ak820_outline_0141
      004973                       1838 _ak820_outline_0141:
      004973 2E               [12] 1839 	add	a,r6
      004974 FE               [12] 1840 	mov	r6,a
      004975 E4               [12] 1841 	clr	a
      004976 3F               [12] 1842 	addc	a,r7
      004977 FF               [12] 1843 	mov	r7,a
      004978 22               [24] 1844 	ret
                                   1845 
                                   1846 	.area CSEG (CODE)
                                   1847 ; function ak820_outline_0147
      004979                       1848 _ak820_outline_0147:
      004979 42 05            [12] 1849 	orl	ar5,a
      00497B EA               [12] 1850 	mov	a,r2
      00497C 42 04            [12] 1851 	orl	ar4,a
      00497E 22               [24] 1852 	ret
                                   1853 
                                   1854 	.area CSEG (CODE)
                                   1855 ; function ak820_outline_0148
      00497F                       1856 _ak820_outline_0148:
      00497F 8A 82            [24] 1857 	mov	dpl,r2
      004981 8B 83            [24] 1858 	mov	dph,r3
      004983 22               [24] 1859 	ret
                                   1860 
                                   1861 	.area CSEG (CODE)
                                   1862 ; function ak820_outline_0155
      004984                       1863 _ak820_outline_0155:
      004984 AC 82            [24] 1864 	mov	r4,dpl
      004986 AD 83            [24] 1865 	mov	r5,dph
      004988 22               [24] 1866 	ret
                                   1867 
                                   1868 	.area CSEG (CODE)
                                   1869 ; function ak820_outline_0163
      004989                       1870 _ak820_outline_0163:
      004989 89 82            [24] 1871 	mov	dpl,r1
      00498B 8A 83            [24] 1872 	mov	dph,r2
      00498D 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0164
      00498E                       1877 _ak820_outline_0164:
      00498E 8F 82            [24] 1878 	mov	dpl,r7
      004990 8E 83            [24] 1879 	mov	dph,r6
      004992 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0167
      004993                       1884 _ak820_outline_0167:
      004993 2E               [12] 1885 	add	a,r6
      004994 FC               [12] 1886 	mov	r4,a
      004995 E4               [12] 1887 	clr	a
      004996 3F               [12] 1888 	addc	a,r7
      004997 FD               [12] 1889 	mov	r5,a
      004998 22               [24] 1890 	ret
                                   1891 
                                   1892 	.area CSEG (CODE)
                                   1893 ; function ak820_outline_0169
      004999                       1894 _ak820_outline_0169:
      004999 ED               [12] 1895 	mov	a,r5
      00499A F0               [24] 1896 	movx	@dptr,a
      00499B EE               [12] 1897 	mov	a,r6
      00499C A3               [24] 1898 	inc	dptr
      00499D F0               [24] 1899 	movx	@dptr,a
      00499E 22               [24] 1900 	ret
                                   1901 
                                   1902 	.area CSEG (CODE)
                                   1903 ; function ak820_outline_0189
      00499F                       1904 _ak820_outline_0189:
      00499F 8C 82            [24] 1905 	mov	dpl,r4
      0049A1 8B 83            [24] 1906 	mov	dph,r3
      0049A3 22               [24] 1907 	ret
