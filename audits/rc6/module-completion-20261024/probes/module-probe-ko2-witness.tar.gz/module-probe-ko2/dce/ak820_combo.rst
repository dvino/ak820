                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _ak820_combo_valid_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _ak820_combo_process_sloc0_1_0:
      000001                        542 	.ds 1
                                    543 ;--------------------------------------------------------
                                    544 ; paged external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area PSEG    (PAG,XDATA)
                                    547 ;--------------------------------------------------------
                                    548 ; uninitialized external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area XSEG    (XDATA)
      000422                        551 _combos:
      000422                        552 	.ds 32
      000442                        553 _saved:
      000442                        554 	.ds 9
      00044B                        555 _active:
      00044B                        556 	.ds 1
      00044C                        557 _ak820_combo_valid_entry_10000_594:
      00044C                        558 	.ds 2
      00044E                        559 _ak820_combo_reload_entry_30000_606:
      00044E                        560 	.ds 10
      000458                        561 _ak820_combo_tick_now_10000_611:
      000458                        562 	.ds 2
      00045A                        563 _ak820_combo_process_record_10000_614:
      00045A                        564 	.ds 2
      00045C                        565 _ak820_combo_process_eligible_10001_629:
      00045C                        566 	.ds 1
      00045D                        567 _ak820_combo_process_i_40001_632:
      00045D                        568 	.ds 1
      00045E                        569 _ak820_combo_process_a_50001_633:
      00045E                        570 	.ds 1
      00045F                        571 _ak820_combo_process_b_50001_633:
      00045F                        572 	.ds 1
                                    573 ;--------------------------------------------------------
                                    574 ; absolute external ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area XABS    (ABS,XDATA)
                                    577 ;--------------------------------------------------------
                                    578 ; initialized external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XISEG   (XDATA)
      000E3D                        581 _first:
      000E3D                        582 	.ds 1
      000E3E                        583 _second:
      000E3E                        584 	.ds 1
                                    585 	.area HOME    (CODE)
                                    586 	.area GSINIT0 (CODE)
                                    587 	.area GSINIT1 (CODE)
                                    588 	.area GSINIT2 (CODE)
                                    589 	.area GSINIT3 (CODE)
                                    590 	.area GSINIT4 (CODE)
                                    591 	.area GSINIT5 (CODE)
                                    592 	.area GSINIT  (CODE)
                                    593 	.area GSFINAL (CODE)
                                    594 	.area CSEG    (CODE)
                                    595 ;--------------------------------------------------------
                                    596 ; global & static initialisations
                                    597 ;--------------------------------------------------------
                                    598 	.area HOME    (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 	.area GSFINAL (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 ;--------------------------------------------------------
                                    603 ; Home
                                    604 ;--------------------------------------------------------
                                    605 	.area HOME    (CODE)
                                    606 	.area HOME    (CODE)
                                    607 ;--------------------------------------------------------
                                    608 ; code
                                    609 ;--------------------------------------------------------
                                    610 	.area CSEG    (CODE)
                                    611 ;------------------------------------------------------------
                                    612 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    613 ;------------------------------------------------------------
                                    614 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    615 ;------------------------------------------------------------
                                    616 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    617 ;	-----------------------------------------
                           000007   618 	ar7 = 0x07
                           000006   619 	ar6 = 0x06
                           000005   620 	ar5 = 0x05
                           000004   621 	ar4 = 0x04
                           000003   622 	ar3 = 0x03
                           000002   623 	ar2 = 0x02
                           000001   624 	ar1 = 0x01
                           000000   625 	ar0 = 0x00
                                    626 ;	 function ak820_combo_valid
                                    627 ;	-----------------------------------------
      003468                        628 _ak820_combo_valid:
      003468 12 38 44         [24]  629 	lcall	_ak820_outline_0109
      00346B 90 04 4C         [24]  630 	mov	dptr,#_ak820_combo_valid_entry_10000_594
      00346E 12 38 49         [24]  631 	lcall	_ak820_outline_0110
                                    632 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (entry->input[2] || entry->input[3]) return false;
      003471 90 04 4C         [24]  633 	mov	dptr,#_ak820_combo_valid_entry_10000_594
      003474 12 37 BE         [24]  634 	lcall	_ak820_outline_0007
      003477 A3               [24]  635 	inc	dptr
      003478 A3               [24]  636 	inc	dptr
      003479 A3               [24]  637 	inc	dptr
      00347A A3               [24]  638 	inc	dptr
      00347B E0               [24]  639 	movx	a,@dptr
      00347C FC               [12]  640 	mov	r4,a
      00347D A3               [24]  641 	inc	dptr
      00347E E0               [24]  642 	movx	a,@dptr
      00347F 4C               [12]  643 	orl	a,r4
      003480 70 0B            [24]  644 	jnz	00101$
      003482 74 06            [12]  645 	mov	a,#0x06
      003484 12 37 D2         [24]  646 	lcall	_ak820_outline_0013
      003487 FC               [12]  647 	mov	r4,a
      003488 A3               [24]  648 	inc	dptr
      003489 E0               [24]  649 	movx	a,@dptr
      00348A 4C               [12]  650 	orl	a,r4
      00348B 60 04            [24]  651 	jz	00102$
      00348D                        652 00101$:
      00348D 75 82 00         [24]  653 	mov	dpl, #0x00
      003490 22               [24]  654 	ret
      003491                        655 00102$:
                                    656 ;	keyboards/ajazz/ak820/ak820_combo.c:25: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      003491 8E 04            [24]  657 	mov	ar4,r6
      003493 8F 05            [24]  658 	mov	ar5,r7
      003495 12 37 F5         [24]  659 	lcall	_ak820_outline_0034
      003498 FA               [12]  660 	mov	r2,a
      003499 A3               [24]  661 	inc	dptr
      00349A E0               [24]  662 	movx	a,@dptr
      00349B FB               [12]  663 	mov	r3,a
      00349C 12 38 54         [24]  664 	lcall	_ak820_outline_0128
      00349F 12 38 14         [24]  665 	lcall	_ak820_outline_0062
      0034A2 EA               [12]  666 	mov	a,r2
      0034A3 4C               [12]  667 	orl	a,r4
      0034A4 F8               [12]  668 	mov	r0,a
      0034A5 EB               [12]  669 	mov	a,r3
      0034A6 4D               [12]  670 	orl	a,r5
      0034A7 48               [12]  671 	orl	a,r0
      0034A8 70 12            [24]  672 	jnz	00105$
      0034AA 74 08            [12]  673 	mov	a,#0x08
      0034AC 12 37 D2         [24]  674 	lcall	_ak820_outline_0013
      0034AF F8               [12]  675 	mov	r0,a
      0034B0 A3               [24]  676 	inc	dptr
      0034B1 E0               [24]  677 	movx	a,@dptr
      0034B2 48               [12]  678 	orl	a,r0
      0034B3 B4 01 00         [24]  679 	cjne	a,#0x01,00187$
      0034B6                        680 00187$:
      0034B6 92 00            [24]  681 	mov  _ak820_combo_valid_sloc0_1_0,c
      0034B8 12 38 69         [24]  682 	lcall	_ak820_outline_0149
      0034BB 22               [24]  683 	ret
      0034BC                        684 00105$:
                                    685 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[0] == entry->input[1]) return false;
      0034BC EC               [12]  686 	mov	a,r4
      0034BD B5 02 08         [24]  687 	cjne	a,ar2,00107$
      0034C0 ED               [12]  688 	mov	a,r5
      0034C1 B5 03 04         [24]  689 	cjne	a,ar3,00107$
      0034C4 75 82 00         [24]  690 	mov	dpl, #0x00
      0034C7 22               [24]  691 	ret
      0034C8                        692 00107$:
                                    693 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!COMBO_INPUT(entry->input[0])) return false;
      0034C8 C3               [12]  694 	clr	c
      0034C9 EC               [12]  695 	mov	a,r4
      0034CA 94 04            [12]  696 	subb	a,#0x04
      0034CC ED               [12]  697 	mov	a,r5
      0034CD 94 00            [12]  698 	subb	a,#0x00
      0034CF 40 07            [24]  699 	jc	00108$
      0034D1 74 A4            [12]  700 	mov	a,#0xa4
      0034D3 9C               [12]  701 	subb	a,r4
      0034D4 E4               [12]  702 	clr	a
      0034D5 9D               [12]  703 	subb	a,r5
      0034D6 50 04            [24]  704 	jnc	00109$
                                    705 ;	free result
      0034D8                        706 00108$:
      0034D8 75 82 00         [24]  707 	mov	dpl, #0x00
      0034DB 22               [24]  708 	ret
      0034DC                        709 00109$:
                                    710 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (!COMBO_INPUT(entry->input[1])) return false;
      0034DC C3               [12]  711 	clr	c
      0034DD EA               [12]  712 	mov	a,r2
      0034DE 94 04            [12]  713 	subb	a,#0x04
      0034E0 EB               [12]  714 	mov	a,r3
      0034E1 94 00            [12]  715 	subb	a,#0x00
      0034E3 40 07            [24]  716 	jc	00111$
      0034E5 74 A4            [12]  717 	mov	a,#0xa4
      0034E7 9A               [12]  718 	subb	a,r2
      0034E8 E4               [12]  719 	clr	a
      0034E9 9B               [12]  720 	subb	a,r3
      0034EA 50 04            [24]  721 	jnc	00112$
                                    722 ;	free result
      0034EC                        723 00111$:
      0034EC 75 82 00         [24]  724 	mov	dpl, #0x00
      0034EF 22               [24]  725 	ret
      0034F0                        726 00112$:
                                    727 ;	keyboards/ajazz/ak820/ak820_combo.c:29: return COMBO_OUTPUT(entry->output);
      0034F0 74 08            [12]  728 	mov	a,#0x08
      0034F2 12 37 ED         [24]  729 	lcall	_ak820_outline_0033
      0034F5 12 37 C8         [24]  730 	lcall	_ak820_outline_0009
      0034F8 74 E0            [12]  731 	mov	a,#0x100 - 0x20
      0034FA 2D               [12]  732 	add	a,r5
      0034FB 40 20            [24]  733 	jc	00116$
      0034FD BE 04 00         [24]  734 	cjne	r6,#0x04,00195$
      003500                        735 00195$:
      003500 40 05            [24]  736 	jc	00124$
      003502 EE               [12]  737 	mov	a,r6
      003503 24 5B            [12]  738 	add	a,#0xff - 0xa4
      003505 50 1A            [24]  739 	jnc	00117$
                                    740 ;	free result
      003507                        741 00124$:
      003507 90 04 4C         [24]  742 	mov	dptr,#_ak820_combo_valid_entry_10000_594
      00350A 12 37 FD         [24]  743 	lcall	_ak820_outline_0056
      00350D 74 08            [12]  744 	mov	a,#0x08
      00350F 12 37 D2         [24]  745 	lcall	_ak820_outline_0013
      003512 FF               [12]  746 	mov	r7,a
      003513 BF E0 00         [24]  747 	cjne	r7,#0xe0,00198$
      003516                        748 00198$:
      003516 40 05            [24]  749 	jc	00116$
      003518 EF               [12]  750 	mov	a,r7
      003519 24 18            [12]  751 	add	a,#0xff - 0xe7
      00351B 50 04            [24]  752 	jnc	00117$
                                    753 ;	free result
      00351D                        754 00116$:
                                    755 ;	assignBit
      00351D C2 00            [12]  756 	clr	_ak820_combo_valid_sloc0_1_0
      00351F 80 02            [24]  757 	sjmp	00118$
      003521                        758 00117$:
                                    759 ;	assignBit
      003521 D2 00            [12]  760 	setb	_ak820_combo_valid_sloc0_1_0
      003523                        761 00118$:
      003523 A2 00            [12]  762 	mov	c,_ak820_combo_valid_sloc0_1_0
      003525 12 38 69         [24]  763 	lcall	_ak820_outline_0149
                                    764 ;	keyboards/ajazz/ak820/ak820_combo.c:30: }
      003528 22               [24]  765 	ret
                                    766 ;------------------------------------------------------------
                                    767 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    768 ;------------------------------------------------------------
                                    769 ;	keyboards/ajazz/ak820/ak820_combo.c:33: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    770 ;	-----------------------------------------
                                    771 ;	 function ak820_combo_cancel
                                    772 ;	-----------------------------------------
      003529                        773 _ak820_combo_cancel:
      003529 90 0E 3E         [24]  774 	mov	dptr,#_second
      00352C 74 FF            [12]  775 	mov	a,#0xff
      00352E F0               [24]  776 	movx	@dptr,a
      00352F 90 0E 3D         [24]  777 	mov	dptr,#_first
      003532 F0               [24]  778 	movx	@dptr,a
      003533 90 04 4B         [24]  779 	mov	dptr,#_active
      003536 E4               [12]  780 	clr	a
      003537 F0               [24]  781 	movx	@dptr,a
      003538 22               [24]  782 	ret
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    785 ;------------------------------------------------------------
                                    786 ;i             Allocated with name '_ak820_combo_reload_i_20000_605'
                                    787 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_606'
                                    788 ;------------------------------------------------------------
                                    789 ;	keyboards/ajazz/ak820/ak820_combo.c:34: void ak820_combo_reload(void) {
                                    790 ;	-----------------------------------------
                                    791 ;	 function ak820_combo_reload
                                    792 ;	-----------------------------------------
      003539                        793 _ak820_combo_reload:
                                    794 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003539 7F 00            [12]  795 	mov	r7,#0x00
      00353B                        796 00105$:
      00353B BF 08 00         [24]  797 	cjne	r7,#0x08,00131$
      00353E                        798 00131$:
      00353E 40 01            [24]  799 	jc	00132$
      003540 22               [24]  800 	ret
      003541                        801 00132$:
                                    802 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].a = 0;
      003541 EF               [12]  803 	mov	a,r7
      003542 75 F0 04         [24]  804 	mov	b,#0x04
      003545 A4               [48]  805 	mul	ab
      003546 24 22            [12]  806 	add	a, #_combos
      003548 FD               [12]  807 	mov	r5,a
      003549 74 04            [12]  808 	mov	a,#(_combos >> 8)
      00354B 35 F0            [12]  809 	addc	a, b
      00354D FE               [12]  810 	mov	r6,a
      00354E 8D 03            [24]  811 	mov	ar3,r5
      003550 8E 04            [24]  812 	mov	ar4,r6
      003552 12 33 FC         [24]  813 	lcall	_ak820_outline_0127
      003555 E4               [12]  814 	clr	a
      003556 F0               [24]  815 	movx	@dptr,a
                                    816 ;	keyboards/ajazz/ak820/ak820_combo.c:38: if (!dynamic_keymap_get_combo(i, &entry)) {
      003557 90 0B 73         [24]  817 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00355A 74 4E            [12]  818 	mov	a,#_ak820_combo_reload_entry_30000_606
      00355C F0               [24]  819 	movx	@dptr,a
      00355D 74 04            [12]  820 	mov	a,#(_ak820_combo_reload_entry_30000_606 >> 8)
      00355F 12 38 1A         [24]  821 	lcall	_ak820_outline_0074
      003562 8F 82            [24]  822 	mov	dpl, r7
      003564 C0 07            [24]  823 	push	ar7
      003566 C0 06            [24]  824 	push	ar6
      003568 C0 05            [24]  825 	push	ar5
      00356A C0 04            [24]  826 	push	ar4
      00356C C0 03            [24]  827 	push	ar3
      00356E 12 8B 80         [24]  828 	lcall	_dynamic_keymap_get_combo
      003571 12 38 4E         [24]  829 	lcall	_ak820_outline_0123
      003574 D0 03            [24]  830 	pop	ar3
      003576 D0 04            [24]  831 	pop	ar4
      003578 D0 05            [24]  832 	pop	ar5
      00357A D0 06            [24]  833 	pop	ar6
      00357C D0 07            [24]  834 	pop	ar7
      00357E 45 F0            [12]  835 	orl	a,b
      003580 70 28            [24]  836 	jnz	00106$
                                    837 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = entry.input[0];
      003582 90 04 4E         [24]  838 	mov	dptr,#_ak820_combo_reload_entry_30000_606
      003585 E0               [24]  839 	movx	a,@dptr
      003586 12 33 FC         [24]  840 	lcall	_ak820_outline_0127
      003589 F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_combo.c:40: combos[i].b = entry.input[1];
      00358A 74 01            [12]  843 	mov	a,#0x01
      00358C 2D               [12]  844 	add	a, r5
      00358D FB               [12]  845 	mov	r3,a
      00358E E4               [12]  846 	clr	a
      00358F 3E               [12]  847 	addc	a, r6
      003590 FC               [12]  848 	mov	r4,a
      003591 90 04 50         [24]  849 	mov	dptr,#(_ak820_combo_reload_entry_30000_606 + 0x0002)
      003594 E0               [24]  850 	movx	a,@dptr
      003595 12 33 FC         [24]  851 	lcall	_ak820_outline_0127
      003598 F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].output = entry.output;
      003599 74 02            [12]  854 	mov	a,#0x02
      00359B 12 38 73         [24]  855 	lcall	_ak820_outline_0166
      00359E 90 04 56         [24]  856 	mov	dptr,#(_ak820_combo_reload_entry_30000_606 + 0x0008)
      0035A1 12 38 63         [24]  857 	lcall	_ak820_outline_0145
      0035A4 12 38 5E         [24]  858 	lcall	_ak820_outline_0138
      0035A7 12 38 2C         [24]  859 	lcall	_ak820_outline_0095
      0035AA                        860 00106$:
                                    861 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035AA 0F               [12]  862 	inc	r7
                                    863 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      0035AB A1 3B            [12]  864 	ajmp	00105$
                                    865 ;------------------------------------------------------------
                                    866 ;Allocation info for local variables in function 'flush'
                                    867 ;------------------------------------------------------------
                                    868 ;	keyboards/ajazz/ak820/ak820_combo.c:45: static void flush(void) {
                                    869 ;	-----------------------------------------
                                    870 ;	 function flush
                                    871 ;	-----------------------------------------
      0035AD                        872 _flush:
                                    873 ;	keyboards/ajazz/ak820/ak820_combo.c:46: first = NONE;
      0035AD 90 0E 3D         [24]  874 	mov	dptr,#_first
      0035B0 74 FF            [12]  875 	mov	a,#0xff
      0035B2 F0               [24]  876 	movx	@dptr,a
                                    877 ;	keyboards/ajazz/ak820/ak820_combo.c:47: process_record(&saved);
      0035B3 90 04 42         [24]  878 	mov	dptr,#_saved
                                    879 ;	keyboards/ajazz/ak820/ak820_combo.c:48: }
      0035B6 02 76 47         [24]  880 	ljmp	_process_record
                                    881 ;------------------------------------------------------------
                                    882 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    883 ;------------------------------------------------------------
                                    884 ;now           Allocated with name '_ak820_combo_tick_now_10000_611'
                                    885 ;------------------------------------------------------------
                                    886 ;	keyboards/ajazz/ak820/ak820_combo.c:49: void ak820_combo_tick(uint16_t now) {
                                    887 ;	-----------------------------------------
                                    888 ;	 function ak820_combo_tick
                                    889 ;	-----------------------------------------
      0035B9                        890 _ak820_combo_tick:
      0035B9 12 38 44         [24]  891 	lcall	_ak820_outline_0109
      0035BC 90 04 58         [24]  892 	mov	dptr,#_ak820_combo_tick_now_10000_611
      0035BF 12 38 49         [24]  893 	lcall	_ak820_outline_0110
                                    894 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      0035C2 12 38 79         [24]  895 	lcall	_ak820_outline_0191
      0035C5 FF               [12]  896 	mov	r7,a
      0035C6 BF FF 01         [24]  897 	cjne	r7,#0xff,00128$
      0035C9 22               [24]  898 	ret
      0035CA                        899 00128$:
      0035CA 90 04 4B         [24]  900 	mov	dptr,#_active
      0035CD E0               [24]  901 	movx	a,@dptr
      0035CE 70 1E            [24]  902 	jnz	00105$
      0035D0 90 04 44         [24]  903 	mov	dptr,#(_saved + 0x0002)
      0035D3 12 37 FD         [24]  904 	lcall	_ak820_outline_0056
      0035D6 90 04 58         [24]  905 	mov	dptr,#_ak820_combo_tick_now_10000_611
      0035D9 12 38 14         [24]  906 	lcall	_ak820_outline_0062
      0035DC EC               [12]  907 	mov	a,r4
      0035DD C3               [12]  908 	clr	c
      0035DE 9E               [12]  909 	subb	a,r6
      0035DF FE               [12]  910 	mov	r6,a
      0035E0 ED               [12]  911 	mov	a,r5
      0035E1 9F               [12]  912 	subb	a,r7
      0035E2 FF               [12]  913 	mov	r7,a
      0035E3 C3               [12]  914 	clr	c
      0035E4 EE               [12]  915 	mov	a,r6
      0035E5 94 28            [12]  916 	subb	a,#0x28
      0035E7 EF               [12]  917 	mov	a,r7
      0035E8 94 00            [12]  918 	subb	a,#0x00
      0035EA 40 02            [24]  919 	jc	00105$
                                    920 ;	keyboards/ajazz/ak820/ak820_combo.c:51: }
      0035EC A1 AD            [24]  921 	ajmp	_flush
      0035EE                        922 00105$:
      0035EE 22               [24]  923 	ret
                                    924 ;------------------------------------------------------------
                                    925 ;Allocation info for local variables in function 'ak820_combo_process'
                                    926 ;------------------------------------------------------------
                                    927 ;record        Allocated with name '_ak820_combo_process_record_10000_614'
                                    928 ;id            Allocated with name '_ak820_combo_process_id_10000_615'
                                    929 ;code          Allocated with name '_ak820_combo_process_code_10000_615'
                                    930 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_629'
                                    931 ;previous      Allocated with name '_ak820_combo_process_previous_30001_631'
                                    932 ;i             Allocated with name '_ak820_combo_process_i_40001_632'
                                    933 ;a             Allocated with name '_ak820_combo_process_a_50001_633'
                                    934 ;b             Allocated with name '_ak820_combo_process_b_50001_633'
                                    935 ;------------------------------------------------------------
                                    936 ;	keyboards/ajazz/ak820/ak820_combo.c:52: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    937 ;	-----------------------------------------
                                    938 ;	 function ak820_combo_process
                                    939 ;	-----------------------------------------
      0035EF                        940 _ak820_combo_process:
      0035EF 12 38 44         [24]  941 	lcall	_ak820_outline_0109
      0035F2 90 04 5A         [24]  942 	mov	dptr,#_ak820_combo_process_record_10000_614
      0035F5 12 38 49         [24]  943 	lcall	_ak820_outline_0110
                                    944 ;	keyboards/ajazz/ak820/ak820_combo.c:53: uint8_t id, code = record->keycode;
      0035F8 90 04 5A         [24]  945 	mov	dptr,#_ak820_combo_process_record_10000_614
      0035FB 12 37 9D         [24]  946 	lcall	_ak820_outline_0001
      0035FE 8C 03            [24]  947 	mov	ar3,r4
                                    948 ;	keyboards/ajazz/ak820/ak820_combo.c:54: if (IS_NOEVENT(record->event)) return true;
      003600 74 04            [12]  949 	mov	a,#0x04
      003602 2E               [12]  950 	add	a, r6
      003603 12 37 DB         [24]  951 	lcall	_ak820_outline_0019
      003606 70 04            [24]  952 	jnz	00102$
      003608 75 82 01         [24]  953 	mov	dpl, #0x01
      00360B 22               [24]  954 	ret
      00360C                        955 00102$:
                                    956 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00360C 12 38 38         [24]  957 	lcall	_ak820_outline_0103
      00360F E0               [24]  958 	movx	a,@dptr
      003610 FA               [12]  959 	mov	r2,a
      003611 BA 10 00         [24]  960 	cjne	r2,#0x10,00308$
      003614                        961 00308$:
      003614 50 09            [24]  962 	jnc	00106$
      003616 12 38 32         [24]  963 	lcall	_ak820_outline_0098
      003619 F9               [12]  964 	mov	r1,a
      00361A B9 08 00         [24]  965 	cjne	r1,#0x08,00310$
      00361D                        966 00310$:
      00361D 40 15            [24]  967 	jc	00107$
      00361F                        968 00106$:
                                    969 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (first != NONE && !active) flush();
      00361F 12 38 79         [24]  970 	lcall	_ak820_outline_0191
      003622 F8               [12]  971 	mov	r0,a
      003623 B8 FF 02         [24]  972 	cjne	r0,#0xff,00312$
      003626 80 08            [24]  973 	sjmp	00104$
      003628                        974 00312$:
      003628 90 04 4B         [24]  975 	mov	dptr,#_active
      00362B E0               [24]  976 	movx	a,@dptr
      00362C 70 02            [24]  977 	jnz	00104$
      00362E B1 AD            [24]  978 	acall	_flush
      003630                        979 00104$:
                                    980 ;	keyboards/ajazz/ak820/ak820_combo.c:58: return true;
      003630 75 82 01         [24]  981 	mov	dpl, #0x01
      003633 22               [24]  982 	ret
      003634                        983 00107$:
                                    984 ;	keyboards/ajazz/ak820/ak820_combo.c:60: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003634 EA               [12]  985 	mov	a,r2
      003635 12 38 7E         [24]  986 	lcall	_ak820_outline_0193
      003638 29               [12]  987 	add	a,r1
      003639 FA               [12]  988 	mov	r2,a
                                    989 ;	keyboards/ajazz/ak820/ak820_combo.c:61: if (active) {
      00363A 90 04 4B         [24]  990 	mov	dptr,#_active
      00363D E0               [24]  991 	movx	a,@dptr
      00363E 60 6F            [24]  992 	jz	00123$
                                    993 ;	keyboards/ajazz/ak820/ak820_combo.c:62: if (id != first && id != second) return true;
      003640 12 38 79         [24]  994 	lcall	_ak820_outline_0191
      003643 F9               [12]  995 	mov	r1,a
      003644 EA               [12]  996 	mov	a,r2
      003645 B5 01 02         [24]  997 	cjne	a,ar1,00315$
      003648 80 0F            [24]  998 	sjmp	00110$
      00364A                        999 00315$:
      00364A 90 0E 3E         [24] 1000 	mov	dptr,#_second
      00364D E0               [24] 1001 	movx	a,@dptr
      00364E F9               [12] 1002 	mov	r1,a
      00364F EA               [12] 1003 	mov	a,r2
      003650 B5 01 02         [24] 1004 	cjne	a,ar1,00316$
      003653 80 04            [24] 1005 	sjmp	00110$
      003655                       1006 00316$:
      003655 75 82 01         [24] 1007 	mov	dpl, #0x01
      003658 22               [24] 1008 	ret
      003659                       1009 00110$:
                                   1010 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (!record->event.pressed) {
      003659 90 04 5A         [24] 1011 	mov	dptr,#_ak820_combo_process_record_10000_614
      00365C 12 38 3E         [24] 1012 	lcall	_ak820_outline_0105
      00365F 74 05            [12] 1013 	mov	a,#0x05
      003661 28               [12] 1014 	add	a, r0
      003662 F8               [12] 1015 	mov	r0,a
      003663 E4               [12] 1016 	clr	a
      003664 39               [12] 1017 	addc	a, r1
      003665 F9               [12] 1018 	mov	r1,a
      003666 12 38 6E         [24] 1019 	lcall	_ak820_outline_0162
      003669 E0               [24] 1020 	movx	a,@dptr
      00366A 70 3F            [24] 1021 	jnz	00121$
                                   1022 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (saved.event.pressed) {
      00366C 90 04 47         [24] 1023 	mov	dptr,#(_saved + 0x0005)
      00366F E0               [24] 1024 	movx	a,@dptr
      003670 60 0F            [24] 1025 	jz	00113$
                                   1026 ;	keyboards/ajazz/ak820/ak820_combo.c:65: saved.event.pressed = false;
      003672 90 04 47         [24] 1027 	mov	dptr,#(_saved + 0x0005)
      003675 E4               [12] 1028 	clr	a
      003676 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_combo.c:66: process_record(&saved);
      003677 90 04 42         [24] 1031 	mov	dptr,#_saved
      00367A C0 02            [24] 1032 	push	ar2
      00367C 12 76 47         [24] 1033 	lcall	_process_record
      00367F D0 02            [24] 1034 	pop	ar2
      003681                       1035 00113$:
                                   1036 ;	keyboards/ajazz/ak820/ak820_combo.c:68: if (id == first) first = NONE;
      003681 12 38 79         [24] 1037 	lcall	_ak820_outline_0191
      003684 F9               [12] 1038 	mov	r1,a
      003685 EA               [12] 1039 	mov	a,r2
      003686 B5 01 08         [24] 1040 	cjne	a,ar1,00115$
      003689 90 0E 3D         [24] 1041 	mov	dptr,#_first
      00368C 74 FF            [12] 1042 	mov	a,#0xff
      00368E F0               [24] 1043 	movx	@dptr,a
      00368F 80 06            [24] 1044 	sjmp	00116$
      003691                       1045 00115$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_combo.c:69: else second = NONE;
      003691 90 0E 3E         [24] 1047 	mov	dptr,#_second
      003694 74 FF            [12] 1048 	mov	a,#0xff
      003696 F0               [24] 1049 	movx	@dptr,a
      003697                       1050 00116$:
                                   1051 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (first == NONE && second == NONE) active = false;
      003697 12 38 79         [24] 1052 	lcall	_ak820_outline_0191
      00369A F9               [12] 1053 	mov	r1,a
      00369B B9 FF 0D         [24] 1054 	cjne	r1,#0xff,00121$
      00369E 90 0E 3E         [24] 1055 	mov	dptr,#_second
      0036A1 E0               [24] 1056 	movx	a,@dptr
      0036A2 F9               [12] 1057 	mov	r1,a
      0036A3 B9 FF 05         [24] 1058 	cjne	r1,#0xff,00121$
      0036A6 90 04 4B         [24] 1059 	mov	dptr,#_active
      0036A9 E4               [12] 1060 	clr	a
      0036AA F0               [24] 1061 	movx	@dptr,a
      0036AB                       1062 00121$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_combo.c:72: return false;
      0036AB 75 82 00         [24] 1064 	mov	dpl, #0x00
      0036AE 22               [24] 1065 	ret
      0036AF                       1066 00123$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_combo.c:74: bool eligible = false;
      0036AF 90 04 5C         [24] 1068 	mov	dptr,#_ak820_combo_process_eligible_10001_629
      0036B2 E4               [12] 1069 	clr	a
      0036B3 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (record->event.pressed && COMBO_INPUT(record->keycode)) {
      0036B4 12 37 B1         [24] 1072 	lcall	_ak820_outline_0006
      0036B7 70 02            [24] 1073 	jnz	00325$
      0036B9 E1 5C            [24] 1074 	ajmp	00134$
      0036BB                       1075 00325$:
      0036BB C3               [12] 1076 	clr	c
      0036BC EC               [12] 1077 	mov	a,r4
      0036BD 94 04            [12] 1078 	subb	a,#0x04
      0036BF ED               [12] 1079 	mov	a,r5
      0036C0 94 00            [12] 1080 	subb	a,#0x00
      0036C2 50 02            [24] 1081 	jnc	00326$
      0036C4 E1 5C            [24] 1082 	ajmp	00134$
      0036C6                       1083 00326$:
      0036C6 C3               [12] 1084 	clr	c
      0036C7 74 A4            [12] 1085 	mov	a,#0xa4
      0036C9 9C               [12] 1086 	subb	a,r4
      0036CA E4               [12] 1087 	clr	a
      0036CB 9D               [12] 1088 	subb	a,r5
      0036CC 50 02            [24] 1089 	jnc	00327$
      0036CE E1 5C            [24] 1090 	ajmp	00134$
      0036D0                       1091 00327$:
                                   1092 ;	free result
                                   1093 ;	keyboards/ajazz/ak820/ak820_combo.c:76: uint8_t previous = saved.keycode;
      0036D0 90 04 49         [24] 1094 	mov	dptr,#(_saved + 0x0007)
      0036D3 E0               [24] 1095 	movx	a,@dptr
      0036D4 FF               [12] 1096 	mov	r7,a
                                   1097 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0036D5 90 04 5D         [24] 1098 	mov	dptr,#_ak820_combo_process_i_40001_632
      0036D8 E4               [12] 1099 	clr	a
      0036D9 F0               [24] 1100 	movx	@dptr,a
      0036DA EB               [12] 1101 	mov	a,r3
      0036DB B5 07 03         [24] 1102 	cjne	a,ar7,00328$
      0036DE D3               [12] 1103 	setb	c
      0036DF 80 01            [24] 1104 	sjmp	00329$
      0036E1                       1105 00328$:
      0036E1 C3               [12] 1106 	clr	c
      0036E2                       1107 00329$:
      0036E2 92 01            [24] 1108 	mov	_ak820_combo_process_sloc0_1_0,c
      0036E4 7E 00            [12] 1109 	mov	r6,#0x00
      0036E6                       1110 00142$:
      0036E6 BE 08 00         [24] 1111 	cjne	r6,#0x08,00330$
      0036E9                       1112 00330$:
      0036E9 40 02            [24] 1113 	jc	00331$
      0036EB E1 5C            [24] 1114 	ajmp	00134$
      0036ED                       1115 00331$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t a = combos[i].a, b = combos[i].b;
      0036ED EE               [12] 1117 	mov	a,r6
      0036EE 12 38 03         [24] 1118 	lcall	_ak820_outline_0058
      0036F1 E0               [24] 1119 	movx	a,@dptr
      0036F2 F9               [12] 1120 	mov	r1,a
      0036F3 90 04 5E         [24] 1121 	mov	dptr,#_ak820_combo_process_a_50001_633
      0036F6 F0               [24] 1122 	movx	@dptr,a
      0036F7 12 38 54         [24] 1123 	lcall	_ak820_outline_0128
      0036FA A3               [24] 1124 	inc	dptr
      0036FB E0               [24] 1125 	movx	a,@dptr
      0036FC FD               [12] 1126 	mov	r5,a
      0036FD 90 04 5F         [24] 1127 	mov	dptr,#_ak820_combo_process_b_50001_633
      003700 F0               [24] 1128 	movx	@dptr,a
                                   1129 ;	keyboards/ajazz/ak820/ak820_combo.c:79: if (a == code || b == code) {
      003701 E9               [12] 1130 	mov	a,r1
      003702 B5 03 02         [24] 1131 	cjne	a,ar3,00332$
      003705 80 04            [24] 1132 	sjmp	00129$
      003707                       1133 00332$:
      003707 ED               [12] 1134 	mov	a,r5
      003708 B5 03 49         [24] 1135 	cjne	a,ar3,00143$
      00370B                       1136 00129$:
                                   1137 ;	keyboards/ajazz/ak820/ak820_combo.c:80: eligible = true;
      00370B 90 04 5C         [24] 1138 	mov	dptr,#_ak820_combo_process_eligible_10001_629
      00370E 74 01            [12] 1139 	mov	a,#0x01
      003710 F0               [24] 1140 	movx	@dptr,a
                                   1141 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (first != NONE && code != previous && (a == previous || b == previous)) {
      003711 12 38 79         [24] 1142 	lcall	_ak820_outline_0191
      003714 FD               [12] 1143 	mov	r5,a
      003715 BD FF 02         [24] 1144 	cjne	r5,#0xff,00335$
      003718 80 3A            [24] 1145 	sjmp	00143$
      00371A                       1146 00335$:
      00371A 20 01 37         [24] 1147 	jb	_ak820_combo_process_sloc0_1_0,00143$
      00371D 90 04 5E         [24] 1148 	mov	dptr,#_ak820_combo_process_a_50001_633
      003720 E0               [24] 1149 	movx	a,@dptr
      003721 B5 07 02         [24] 1150 	cjne	a,ar7,00337$
      003724 80 07            [24] 1151 	sjmp	00124$
      003726                       1152 00337$:
      003726 90 04 5F         [24] 1153 	mov	dptr,#_ak820_combo_process_b_50001_633
      003729 E0               [24] 1154 	movx	a,@dptr
      00372A B5 07 27         [24] 1155 	cjne	a,ar7,00143$
      00372D                       1156 00124$:
                                   1157 ;	keyboards/ajazz/ak820/ak820_combo.c:82: second = id;
      00372D 90 0E 3E         [24] 1158 	mov	dptr,#_second
      003730 EA               [12] 1159 	mov	a,r2
      003731 F0               [24] 1160 	movx	@dptr,a
                                   1161 ;	keyboards/ajazz/ak820/ak820_combo.c:83: active = true;
      003732 90 04 4B         [24] 1162 	mov	dptr,#_active
      003735 74 01            [12] 1163 	mov	a,#0x01
      003737 F0               [24] 1164 	movx	@dptr,a
                                   1165 ;	keyboards/ajazz/ak820/ak820_combo.c:84: saved.keycode = combos[i].output;
      003738 90 04 5D         [24] 1166 	mov	dptr,#_ak820_combo_process_i_40001_632
      00373B E0               [24] 1167 	movx	a,@dptr
      00373C 12 38 03         [24] 1168 	lcall	_ak820_outline_0058
      00373F A3               [24] 1169 	inc	dptr
      003740 A3               [24] 1170 	inc	dptr
      003741 12 38 14         [24] 1171 	lcall	_ak820_outline_0062
      003744 90 04 49         [24] 1172 	mov	dptr,#(_saved + 0x0007)
      003747 12 38 20         [24] 1173 	lcall	_ak820_outline_0078
                                   1174 ;	keyboards/ajazz/ak820/ak820_combo.c:85: process_record(&saved);
      00374A 90 04 42         [24] 1175 	mov	dptr,#_saved
      00374D 12 76 47         [24] 1176 	lcall	_process_record
                                   1177 ;	keyboards/ajazz/ak820/ak820_combo.c:86: return false;
      003750 75 82 00         [24] 1178 	mov	dpl, #0x00
      003753 22               [24] 1179 	ret
      003754                       1180 00143$:
                                   1181 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003754 0E               [12] 1182 	inc	r6
      003755 90 04 5D         [24] 1183 	mov	dptr,#_ak820_combo_process_i_40001_632
      003758 EE               [12] 1184 	mov	a,r6
      003759 F0               [24] 1185 	movx	@dptr,a
      00375A C1 E6            [24] 1186 	ajmp	00142$
      00375C                       1187 00134$:
                                   1188 ;	keyboards/ajazz/ak820/ak820_combo.c:91: if (first != NONE) flush();
      00375C 12 38 79         [24] 1189 	lcall	_ak820_outline_0191
      00375F FF               [12] 1190 	mov	r7,a
      003760 BF FF 02         [24] 1191 	cjne	r7,#0xff,00340$
      003763 80 06            [24] 1192 	sjmp	00138$
      003765                       1193 00340$:
      003765 C0 02            [24] 1194 	push	ar2
      003767 B1 AD            [24] 1195 	acall	_flush
      003769 D0 02            [24] 1196 	pop	ar2
      00376B                       1197 00138$:
                                   1198 ;	keyboards/ajazz/ak820/ak820_combo.c:92: if (eligible) {
      00376B 90 04 5C         [24] 1199 	mov	dptr,#_ak820_combo_process_eligible_10001_629
      00376E E0               [24] 1200 	movx	a,@dptr
      00376F 60 28            [24] 1201 	jz	00140$
                                   1202 ;	keyboards/ajazz/ak820/ak820_combo.c:93: first = id;
      003771 90 0E 3D         [24] 1203 	mov	dptr,#_first
      003774 EA               [12] 1204 	mov	a,r2
      003775 F0               [24] 1205 	movx	@dptr,a
                                   1206 ;	keyboards/ajazz/ak820/ak820_combo.c:94: saved = *record;
      003776 90 04 5A         [24] 1207 	mov	dptr,#_ak820_combo_process_record_10000_614
      003779 12 38 26         [24] 1208 	lcall	_ak820_outline_0081
      00377C 7F 00            [12] 1209 	mov	r7,#0x00
      00377E 90 0E 2F         [24] 1210 	mov	dptr,#___memcpy_PARM_2
      003781 ED               [12] 1211 	mov	a,r5
      003782 12 37 E5         [24] 1212 	lcall	_ak820_outline_0020
      003785 90 0E 32         [24] 1213 	mov	dptr,#___memcpy_PARM_3
      003788 74 09            [12] 1214 	mov	a,#0x09
      00378A 12 38 59         [24] 1215 	lcall	_ak820_outline_0129
      00378D 90 04 42         [24] 1216 	mov	dptr,#_saved
      003790 F5 F0            [12] 1217 	mov	b,a
      003792 12 BF 43         [24] 1218 	lcall	___memcpy
                                   1219 ;	keyboards/ajazz/ak820/ak820_combo.c:95: return false;
      003795 75 82 00         [24] 1220 	mov	dpl, #0x00
      003798 22               [24] 1221 	ret
      003799                       1222 00140$:
                                   1223 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return true;
      003799 75 82 01         [24] 1224 	mov	dpl, #0x01
                                   1225 ;	keyboards/ajazz/ak820/ak820_combo.c:98: }
      00379C 22               [24] 1226 	ret
                                   1227 	.area CSEG    (CODE)
                                   1228 	.area CONST   (CODE)
                                   1229 	.area XINIT   (CODE)
      00C801                       1230 __xinit__first:
      00C801 FF                    1231 	.db #0xff	; 255
      00C802                       1232 __xinit__second:
      00C802 FF                    1233 	.db #0xff	; 255
                                   1234 	.area CABS    (ABS,CODE)
                                   1235 
                                   1236 ; Experimental exact instruction outlining.
                                   1237 	.globl _ak820_outline_0001
                                   1238 	.globl _ak820_outline_0006
                                   1239 	.globl _ak820_outline_0007
                                   1240 	.globl _ak820_outline_0009
                                   1241 	.globl _ak820_outline_0013
                                   1242 	.globl _ak820_outline_0019
                                   1243 	.globl _ak820_outline_0020
                                   1244 	.globl _ak820_outline_0033
                                   1245 	.globl _ak820_outline_0034
                                   1246 	.globl _ak820_outline_0056
                                   1247 	.globl _ak820_outline_0058
                                   1248 	.globl _ak820_outline_0062
                                   1249 	.globl _ak820_outline_0074
                                   1250 	.globl _ak820_outline_0078
                                   1251 	.globl _ak820_outline_0081
                                   1252 	.globl _ak820_outline_0095
                                   1253 	.globl _ak820_outline_0098
                                   1254 	.globl _ak820_outline_0103
                                   1255 	.globl _ak820_outline_0105
                                   1256 	.globl _ak820_outline_0109
                                   1257 	.globl _ak820_outline_0110
                                   1258 	.globl _ak820_outline_0123
                                   1259 	.globl _ak820_outline_0127
                                   1260 	.globl _ak820_outline_0128
                                   1261 	.globl _ak820_outline_0129
                                   1262 	.globl _ak820_outline_0138
                                   1263 	.globl _ak820_outline_0145
                                   1264 	.globl _ak820_outline_0149
                                   1265 	.globl _ak820_outline_0162
                                   1266 	.globl _ak820_outline_0166
                                   1267 	.globl _ak820_outline_0191
                                   1268 	.globl _ak820_outline_0193
                                   1269 
                                   1270 	.area CSEG (CODE)
                                   1271 ; function ak820_outline_0001
      00379D                       1272 _ak820_outline_0001:
      00379D E0               [24] 1273 	movx	a,@dptr
      00379E FE               [12] 1274 	mov	r6,a
      00379F A3               [24] 1275 	inc	dptr
      0037A0 E0               [24] 1276 	movx	a,@dptr
      0037A1 FF               [12] 1277 	mov	r7,a
      0037A2 74 07            [12] 1278 	mov	a,#0x07
      0037A4 2E               [12] 1279 	add	a,r6
      0037A5 F5 82            [12] 1280 	mov	dpl,a
      0037A7 E4               [12] 1281 	clr	a
      0037A8 3F               [12] 1282 	addc	a,r7
      0037A9 F5 83            [12] 1283 	mov	dph,a
      0037AB E0               [24] 1284 	movx	a,@dptr
      0037AC FC               [12] 1285 	mov	r4,a
      0037AD A3               [24] 1286 	inc	dptr
      0037AE E0               [24] 1287 	movx	a,@dptr
      0037AF FD               [12] 1288 	mov	r5,a
      0037B0 22               [24] 1289 	ret
                                   1290 
                                   1291 	.area CSEG (CODE)
                                   1292 ; function ak820_outline_0006
      0037B1                       1293 _ak820_outline_0006:
      0037B1 74 05            [12] 1294 	mov	a,#0x05
      0037B3 2E               [12] 1295 	add	a,r6
      0037B4 FE               [12] 1296 	mov	r6,a
      0037B5 E4               [12] 1297 	clr	a
      0037B6 3F               [12] 1298 	addc	a,r7
      0037B7 FF               [12] 1299 	mov	r7,a
      0037B8 8E 82            [24] 1300 	mov	dpl,r6
      0037BA 8F 83            [24] 1301 	mov	dph,r7
      0037BC E0               [24] 1302 	movx	a,@dptr
      0037BD 22               [24] 1303 	ret
                                   1304 
                                   1305 	.area CSEG (CODE)
                                   1306 ; function ak820_outline_0007
      0037BE                       1307 _ak820_outline_0007:
      0037BE E0               [24] 1308 	movx	a,@dptr
      0037BF FE               [12] 1309 	mov	r6,a
      0037C0 A3               [24] 1310 	inc	dptr
      0037C1 E0               [24] 1311 	movx	a,@dptr
      0037C2 FF               [12] 1312 	mov	r7,a
      0037C3 8E 82            [24] 1313 	mov	dpl,r6
      0037C5 8F 83            [24] 1314 	mov	dph,r7
      0037C7 22               [24] 1315 	ret
                                   1316 
                                   1317 	.area CSEG (CODE)
                                   1318 ; function ak820_outline_0009
      0037C8                       1319 _ak820_outline_0009:
      0037C8 E0               [24] 1320 	movx	a,@dptr
      0037C9 FE               [12] 1321 	mov	r6,a
      0037CA A3               [24] 1322 	inc	dptr
      0037CB E0               [24] 1323 	movx	a,@dptr
      0037CC FF               [12] 1324 	mov	r7,a
      0037CD 8E 04            [24] 1325 	mov	ar4,r6
      0037CF 8F 05            [24] 1326 	mov	ar5,r7
      0037D1 22               [24] 1327 	ret
                                   1328 
                                   1329 	.area CSEG (CODE)
                                   1330 ; function ak820_outline_0013
      0037D2                       1331 _ak820_outline_0013:
      0037D2 2E               [12] 1332 	add	a,r6
      0037D3 F5 82            [12] 1333 	mov	dpl,a
      0037D5 E4               [12] 1334 	clr	a
      0037D6 3F               [12] 1335 	addc	a,r7
      0037D7 F5 83            [12] 1336 	mov	dph,a
      0037D9 E0               [24] 1337 	movx	a,@dptr
      0037DA 22               [24] 1338 	ret
                                   1339 
                                   1340 	.area CSEG (CODE)
                                   1341 ; function ak820_outline_0019
      0037DB                       1342 _ak820_outline_0019:
      0037DB F9               [12] 1343 	mov	r1,a
      0037DC E4               [12] 1344 	clr	a
      0037DD 3F               [12] 1345 	addc	a,r7
      0037DE FA               [12] 1346 	mov	r2,a
      0037DF 89 82            [24] 1347 	mov	dpl,r1
      0037E1 8A 83            [24] 1348 	mov	dph,r2
      0037E3 E0               [24] 1349 	movx	a,@dptr
      0037E4 22               [24] 1350 	ret
                                   1351 
                                   1352 	.area CSEG (CODE)
                                   1353 ; function ak820_outline_0020
      0037E5                       1354 _ak820_outline_0020:
      0037E5 F0               [24] 1355 	movx	@dptr,a
      0037E6 EE               [12] 1356 	mov	a,r6
      0037E7 A3               [24] 1357 	inc	dptr
      0037E8 F0               [24] 1358 	movx	@dptr,a
      0037E9 EF               [12] 1359 	mov	a,r7
      0037EA A3               [24] 1360 	inc	dptr
      0037EB F0               [24] 1361 	movx	@dptr,a
      0037EC 22               [24] 1362 	ret
                                   1363 
                                   1364 	.area CSEG (CODE)
                                   1365 ; function ak820_outline_0033
      0037ED                       1366 _ak820_outline_0033:
      0037ED 2E               [12] 1367 	add	a,r6
      0037EE F5 82            [12] 1368 	mov	dpl,a
      0037F0 E4               [12] 1369 	clr	a
      0037F1 3F               [12] 1370 	addc	a,r7
      0037F2 F5 83            [12] 1371 	mov	dph,a
      0037F4 22               [24] 1372 	ret
                                   1373 
                                   1374 	.area CSEG (CODE)
                                   1375 ; function ak820_outline_0034
      0037F5                       1376 _ak820_outline_0034:
      0037F5 8E 82            [24] 1377 	mov	dpl,r6
      0037F7 8F 83            [24] 1378 	mov	dph,r7
      0037F9 A3               [24] 1379 	inc	dptr
      0037FA A3               [24] 1380 	inc	dptr
      0037FB E0               [24] 1381 	movx	a,@dptr
      0037FC 22               [24] 1382 	ret
                                   1383 
                                   1384 	.area CSEG (CODE)
                                   1385 ; function ak820_outline_0056
      0037FD                       1386 _ak820_outline_0056:
      0037FD E0               [24] 1387 	movx	a,@dptr
      0037FE FE               [12] 1388 	mov	r6,a
      0037FF A3               [24] 1389 	inc	dptr
      003800 E0               [24] 1390 	movx	a,@dptr
      003801 FF               [12] 1391 	mov	r7,a
      003802 22               [24] 1392 	ret
                                   1393 
                                   1394 	.area CSEG (CODE)
                                   1395 ; function ak820_outline_0058
      003803                       1396 _ak820_outline_0058:
      003803 75 F0 04         [24] 1397 	mov	b,#0x04
      003806 A4               [48] 1398 	mul	ab
      003807 24 22            [12] 1399 	add	a,#_combos
      003809 FC               [12] 1400 	mov	r4,a
      00380A 74 04            [12] 1401 	mov	a,#(_combos>>8)
      00380C 35 F0            [12] 1402 	addc	a,b
      00380E FD               [12] 1403 	mov	r5,a
      00380F 8C 82            [24] 1404 	mov	dpl,r4
      003811 8D 83            [24] 1405 	mov	dph,r5
      003813 22               [24] 1406 	ret
                                   1407 
                                   1408 	.area CSEG (CODE)
                                   1409 ; function ak820_outline_0062
      003814                       1410 _ak820_outline_0062:
      003814 E0               [24] 1411 	movx	a,@dptr
      003815 FC               [12] 1412 	mov	r4,a
      003816 A3               [24] 1413 	inc	dptr
      003817 E0               [24] 1414 	movx	a,@dptr
      003818 FD               [12] 1415 	mov	r5,a
      003819 22               [24] 1416 	ret
                                   1417 
                                   1418 	.area CSEG (CODE)
                                   1419 ; function ak820_outline_0074
      00381A                       1420 _ak820_outline_0074:
      00381A A3               [24] 1421 	inc	dptr
      00381B F0               [24] 1422 	movx	@dptr,a
      00381C E4               [12] 1423 	clr	a
      00381D A3               [24] 1424 	inc	dptr
      00381E F0               [24] 1425 	movx	@dptr,a
      00381F 22               [24] 1426 	ret
                                   1427 
                                   1428 	.area CSEG (CODE)
                                   1429 ; function ak820_outline_0078
      003820                       1430 _ak820_outline_0078:
      003820 EC               [12] 1431 	mov	a,r4
      003821 F0               [24] 1432 	movx	@dptr,a
      003822 ED               [12] 1433 	mov	a,r5
      003823 A3               [24] 1434 	inc	dptr
      003824 F0               [24] 1435 	movx	@dptr,a
      003825 22               [24] 1436 	ret
                                   1437 
                                   1438 	.area CSEG (CODE)
                                   1439 ; function ak820_outline_0081
      003826                       1440 _ak820_outline_0081:
      003826 E0               [24] 1441 	movx	a,@dptr
      003827 FD               [12] 1442 	mov	r5,a
      003828 A3               [24] 1443 	inc	dptr
      003829 E0               [24] 1444 	movx	a,@dptr
      00382A FE               [12] 1445 	mov	r6,a
      00382B 22               [24] 1446 	ret
                                   1447 
                                   1448 	.area CSEG (CODE)
                                   1449 ; function ak820_outline_0095
      00382C                       1450 _ak820_outline_0095:
      00382C EB               [12] 1451 	mov	a,r3
      00382D F0               [24] 1452 	movx	@dptr,a
      00382E EC               [12] 1453 	mov	a,r4
      00382F A3               [24] 1454 	inc	dptr
      003830 F0               [24] 1455 	movx	@dptr,a
      003831 22               [24] 1456 	ret
                                   1457 
                                   1458 	.area CSEG (CODE)
                                   1459 ; function ak820_outline_0098
      003832                       1460 _ak820_outline_0098:
      003832 8E 82            [24] 1461 	mov	dpl,r6
      003834 8F 83            [24] 1462 	mov	dph,r7
      003836 E0               [24] 1463 	movx	a,@dptr
      003837 22               [24] 1464 	ret
                                   1465 
                                   1466 	.area CSEG (CODE)
                                   1467 ; function ak820_outline_0103
      003838                       1468 _ak820_outline_0103:
      003838 8E 82            [24] 1469 	mov	dpl,r6
      00383A 8F 83            [24] 1470 	mov	dph,r7
      00383C A3               [24] 1471 	inc	dptr
      00383D 22               [24] 1472 	ret
                                   1473 
                                   1474 	.area CSEG (CODE)
                                   1475 ; function ak820_outline_0105
      00383E                       1476 _ak820_outline_0105:
      00383E E0               [24] 1477 	movx	a,@dptr
      00383F F8               [12] 1478 	mov	r0,a
      003840 A3               [24] 1479 	inc	dptr
      003841 E0               [24] 1480 	movx	a,@dptr
      003842 F9               [12] 1481 	mov	r1,a
      003843 22               [24] 1482 	ret
                                   1483 
                                   1484 	.area CSEG (CODE)
                                   1485 ; function ak820_outline_0109
      003844                       1486 _ak820_outline_0109:
      003844 AF 83            [24] 1487 	mov	r7,dph
      003846 E5 82            [12] 1488 	mov	a,dpl
      003848 22               [24] 1489 	ret
                                   1490 
                                   1491 	.area CSEG (CODE)
                                   1492 ; function ak820_outline_0110
      003849                       1493 _ak820_outline_0110:
      003849 F0               [24] 1494 	movx	@dptr,a
      00384A EF               [12] 1495 	mov	a,r7
      00384B A3               [24] 1496 	inc	dptr
      00384C F0               [24] 1497 	movx	@dptr,a
      00384D 22               [24] 1498 	ret
                                   1499 
                                   1500 	.area CSEG (CODE)
                                   1501 ; function ak820_outline_0123
      00384E                       1502 _ak820_outline_0123:
      00384E E5 82            [12] 1503 	mov	a,dpl
      003850 85 83 F0         [24] 1504 	mov	b,dph
      003853 22               [24] 1505 	ret
                                   1506 
                                   1507 	.area CSEG (CODE)
                                   1508 ; function ak820_outline_0128
      003854                       1509 _ak820_outline_0128:
      003854 8C 82            [24] 1510 	mov	dpl,r4
      003856 8D 83            [24] 1511 	mov	dph,r5
      003858 22               [24] 1512 	ret
                                   1513 
                                   1514 	.area CSEG (CODE)
                                   1515 ; function ak820_outline_0129
      003859                       1516 _ak820_outline_0129:
      003859 F0               [24] 1517 	movx	@dptr,a
      00385A E4               [12] 1518 	clr	a
      00385B A3               [24] 1519 	inc	dptr
      00385C F0               [24] 1520 	movx	@dptr,a
      00385D 22               [24] 1521 	ret
                                   1522 
                                   1523 	.area CSEG (CODE)
                                   1524 ; function ak820_outline_0138
      00385E                       1525 _ak820_outline_0138:
      00385E 8D 82            [24] 1526 	mov	dpl,r5
      003860 8E 83            [24] 1527 	mov	dph,r6
      003862 22               [24] 1528 	ret
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0145
      003863                       1532 _ak820_outline_0145:
      003863 E0               [24] 1533 	movx	a,@dptr
      003864 FB               [12] 1534 	mov	r3,a
      003865 A3               [24] 1535 	inc	dptr
      003866 E0               [24] 1536 	movx	a,@dptr
      003867 FC               [12] 1537 	mov	r4,a
      003868 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0149
      003869                       1542 _ak820_outline_0149:
      003869 E4               [12] 1543 	clr	a
      00386A 33               [12] 1544 	rlc	a
      00386B F5 82            [12] 1545 	mov	dpl,a
      00386D 22               [24] 1546 	ret
                                   1547 
                                   1548 	.area CSEG (CODE)
                                   1549 ; function ak820_outline_0162
      00386E                       1550 _ak820_outline_0162:
      00386E 88 82            [24] 1551 	mov	dpl,r0
      003870 89 83            [24] 1552 	mov	dph,r1
      003872 22               [24] 1553 	ret
                                   1554 
                                   1555 	.area CSEG (CODE)
                                   1556 ; function ak820_outline_0166
      003873                       1557 _ak820_outline_0166:
      003873 2D               [12] 1558 	add	a,r5
      003874 FD               [12] 1559 	mov	r5,a
      003875 E4               [12] 1560 	clr	a
      003876 3E               [12] 1561 	addc	a,r6
      003877 FE               [12] 1562 	mov	r6,a
      003878 22               [24] 1563 	ret
                                   1564 
                                   1565 	.area CSEG (CODE)
                                   1566 ; function ak820_outline_0191
      003879                       1567 _ak820_outline_0191:
      003879 90 0E 3D         [24] 1568 	mov	dptr,#_first
      00387C E0               [24] 1569 	movx	a,@dptr
      00387D 22               [24] 1570 	ret
                                   1571 
                                   1572 	.area CSEG (CODE)
                                   1573 ; function ak820_outline_0193
      00387E                       1574 _ak820_outline_0193:
      00387E C4               [12] 1575 	swap	a
      00387F 03               [12] 1576 	rr	a
      003880 54 F8            [12] 1577 	anl	a,#0xf8
      003882 22               [24] 1578 	ret
