                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006E7                         85 _eeprom_read_word_addr_10000_91:
      0006E7                         86 	.ds 3
      0006EA                         87 _eeprom_read_word_ret_10000_92:
      0006EA                         88 	.ds 2
      0006EC                         89 _eeprom_read_dword_addr_10000_93:
      0006EC                         90 	.ds 3
      0006EF                         91 _eeprom_read_dword_ret_10000_94:
      0006EF                         92 	.ds 4
      0006F3                         93 _eeprom_write_byte_PARM_2:
      0006F3                         94 	.ds 1
      0006F4                         95 _eeprom_write_byte_addr_10000_95:
      0006F4                         96 	.ds 3
      0006F7                         97 _eeprom_write_word_PARM_2:
      0006F7                         98 	.ds 2
      0006F9                         99 _eeprom_write_word_addr_10000_97:
      0006F9                        100 	.ds 3
      0006FC                        101 _eeprom_write_dword_PARM_2:
      0006FC                        102 	.ds 4
      000700                        103 _eeprom_write_dword_addr_10000_99:
      000700                        104 	.ds 3
      000703                        105 _eeprom_update_byte_PARM_2:
      000703                        106 	.ds 1
      000704                        107 _eeprom_update_byte_addr_10000_107:
      000704                        108 	.ds 3
      000707                        109 _eeprom_update_word_PARM_2:
      000707                        110 	.ds 2
      000709                        111 _eeprom_update_word_addr_10000_111:
      000709                        112 	.ds 3
      00070C                        113 _eeprom_update_dword_PARM_2:
      00070C                        114 	.ds 4
      000710                        115 _eeprom_update_dword_addr_10000_115:
      000710                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      005308                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      005308 12 49 1A         [24]  170 	lcall	_ak820_outline_0038
      00530B 90 06 E7         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      00530E 12 37 E5         [24]  172 	lcall	_ak820_outline_0020
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      005311 90 06 EA         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005314 12 55 0D         [24]  175 	lcall	_ak820_outline_0154
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      005317 90 06 E7         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      00531A 12 54 C2         [24]  178 	lcall	_ak820_outline_0014
      00531D 90 05 ED         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005320 ED               [12]  180 	mov	a,r5
      005321 12 37 E5         [24]  181 	lcall	_ak820_outline_0020
      005324 90 05 F0         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005327 12 55 06         [24]  183 	lcall	_ak820_outline_0112
      00532A 90 06 EA         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00532D 12 46 B6         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      005330 90 06 EA         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005333 12 54 FD         [24]  188 	lcall	_ak820_outline_0094
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      005336 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      005337                        201 _eeprom_read_dword:
      005337 12 49 1A         [24]  202 	lcall	_ak820_outline_0038
      00533A 90 06 EC         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      00533D 12 37 E5         [24]  204 	lcall	_ak820_outline_0020
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      005340 90 06 EF         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005343 12 54 D2         [24]  207 	lcall	_ak820_outline_0054
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      005346 90 06 EC         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005349 12 54 C2         [24]  210 	lcall	_ak820_outline_0014
      00534C 90 05 ED         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00534F ED               [12]  212 	mov	a,r5
      005350 12 37 E5         [24]  213 	lcall	_ak820_outline_0020
      005353 90 05 F0         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005356 74 04            [12]  215 	mov	a,#0x04
      005358 12 38 59         [24]  216 	lcall	_ak820_outline_0129
      00535B 90 06 EF         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00535E 12 46 B6         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      005361 90 06 EF         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005364 12 54 DB         [24]  221 	lcall	_ak820_outline_0059
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      005367 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      005368                        234 _eeprom_write_byte:
      005368 12 49 1A         [24]  235 	lcall	_ak820_outline_0038
      00536B 90 06 F4         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      00536E 12 37 E5         [24]  237 	lcall	_ak820_outline_0020
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      005371 90 06 F4         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005374 12 54 AB         [24]  240 	lcall	_ak820_outline_0005
      005377 74 01            [12]  241 	mov	a,#0x01
      005379 12 38 59         [24]  242 	lcall	_ak820_outline_0129
      00537C 90 06 F3         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      00537F 02 47 42         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005382                        256 _eeprom_write_word:
      005382 12 49 1A         [24]  257 	lcall	_ak820_outline_0038
      005385 90 06 F9         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005388 12 37 E5         [24]  259 	lcall	_ak820_outline_0020
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      00538B 90 06 F9         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00538E 12 54 AB         [24]  262 	lcall	_ak820_outline_0005
      005391 12 55 06         [24]  263 	lcall	_ak820_outline_0112
      005394 90 06 F7         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      005397 02 47 42         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      00539A                        277 _eeprom_write_dword:
      00539A 12 49 1A         [24]  278 	lcall	_ak820_outline_0038
      00539D 90 07 00         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      0053A0 12 37 E5         [24]  280 	lcall	_ak820_outline_0020
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      0053A3 90 07 00         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      0053A6 12 54 AB         [24]  283 	lcall	_ak820_outline_0005
      0053A9 74 04            [12]  284 	mov	a,#0x04
      0053AB 12 38 59         [24]  285 	lcall	_ak820_outline_0129
      0053AE 90 06 FC         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      0053B1 02 47 42         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      0053B4                        307 _eeprom_update_byte:
      0053B4 C0 07            [24]  308 	push	ar7
      0053B6 C0 06            [24]  309 	push	ar6
      0053B8 C0 05            [24]  310 	push	ar5
      0053BA C0 04            [24]  311 	push	ar4
      0053BC 12 49 1A         [24]  312 	lcall	_ak820_outline_0038
      0053BF 90 07 04         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0053C2 12 37 E5         [24]  314 	lcall	_ak820_outline_0020
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      0053C5 90 07 04         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0053C8 12 54 9C         [24]  317 	lcall	_ak820_outline_0002
      0053CB 12 46 7B         [24]  318 	lcall	_eeprom_read_byte
      0053CE AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      0053D0 90 07 03         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      0053D3 E0               [24]  322 	movx	a,@dptr
      0053D4 FE               [12]  323 	mov	r6,a
      0053D5 EF               [12]  324 	mov	a,r7
      0053D6 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      0053D9 80 36            [24]  326 	sjmp	00103$
      0053DB                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      0053DB 90 07 04         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0053DE 12 38 14         [24]  330 	lcall	_ak820_outline_0062
      0053E1 A3               [24]  331 	inc	dptr
      0053E2 E0               [24]  332 	movx	a,@dptr
      0053E3 FF               [12]  333 	mov	r7,a
      0053E4 90 06 F3         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      0053E7 EE               [12]  335 	mov	a,r6
      0053E8 F0               [24]  336 	movx	@dptr,a
      0053E9 12 38 54         [24]  337 	lcall	_ak820_outline_0128
      0053EC 8F F0            [24]  338 	mov	b, r7
      0053EE C0 07            [24]  339 	push	ar7
      0053F0 C0 06            [24]  340 	push	ar6
      0053F2 C0 05            [24]  341 	push	ar5
      0053F4 C0 04            [24]  342 	push	ar4
      0053F6 C0 03            [24]  343 	push	ar3
      0053F8 C0 02            [24]  344 	push	ar2
      0053FA C0 01            [24]  345 	push	ar1
      0053FC C0 00            [24]  346 	push	ar0
      0053FE 12 53 68         [24]  347 	lcall	_eeprom_write_byte
      005401 D0 00            [24]  348 	pop	ar0
      005403 D0 01            [24]  349 	pop	ar1
      005405 D0 02            [24]  350 	pop	ar2
      005407 D0 03            [24]  351 	pop	ar3
      005409 D0 04            [24]  352 	pop	ar4
      00540B D0 05            [24]  353 	pop	ar5
      00540D D0 06            [24]  354 	pop	ar6
      00540F D0 07            [24]  355 	pop	ar7
      005411                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      005411 D0 04            [24]  358 	pop	ar4
      005413 D0 05            [24]  359 	pop	ar5
      005415 D0 06            [24]  360 	pop	ar6
      005417 D0 07            [24]  361 	pop	ar7
      005419 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      00541A                        374 _eeprom_update_word:
      00541A 12 49 1A         [24]  375 	lcall	_ak820_outline_0038
      00541D 90 07 09         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005420 12 37 E5         [24]  377 	lcall	_ak820_outline_0020
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005423 90 07 09         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005426 12 54 9C         [24]  380 	lcall	_ak820_outline_0002
      005429 12 53 08         [24]  381 	lcall	_eeprom_read_word
      00542C 12 49 6E         [24]  382 	lcall	_ak820_outline_0139
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      00542F 90 07 07         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      005432 12 38 14         [24]  385 	lcall	_ak820_outline_0062
      005435 EE               [12]  386 	mov	a,r6
      005436 B5 04 05         [24]  387 	cjne	a,ar4,00112$
      005439 EF               [12]  388 	mov	a,r7
      00543A B5 05 01         [24]  389 	cjne	a,ar5,00112$
      00543D 22               [24]  390 	ret
      00543E                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      00543E 90 07 09         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005441 E0               [24]  394 	movx	a,@dptr
      005442 FB               [12]  395 	mov	r3,a
      005443 A3               [24]  396 	inc	dptr
      005444 12 37 FD         [24]  397 	lcall	_ak820_outline_0056
      005447 90 06 F7         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      00544A 12 38 20         [24]  399 	lcall	_ak820_outline_0078
      00544D 8B 82            [24]  400 	mov	dpl, r3
      00544F 8E 83            [24]  401 	mov	dph, r6
      005451 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      005453 02 53 82         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      005456                        416 _eeprom_update_dword:
      005456 12 49 1A         [24]  417 	lcall	_ak820_outline_0038
      005459 90 07 10         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00545C 12 37 E5         [24]  419 	lcall	_ak820_outline_0020
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      00545F 90 07 10         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005462 12 54 9C         [24]  422 	lcall	_ak820_outline_0002
      005465 12 53 37         [24]  423 	lcall	_eeprom_read_dword
      005468 12 54 EC         [24]  424 	lcall	_ak820_outline_0061
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      00546B 90 07 0C         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      00546E E0               [24]  427 	movx	a,@dptr
      00546F F8               [12]  428 	mov	r0,a
      005470 A3               [24]  429 	inc	dptr
      005471 12 54 F4         [24]  430 	lcall	_ak820_outline_0093
      005474 EC               [12]  431 	mov	a,r4
      005475 B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      005478 ED               [12]  433 	mov	a,r5
      005479 B5 01 09         [24]  434 	cjne	a,ar1,00112$
      00547C EE               [12]  435 	mov	a,r6
      00547D B5 02 05         [24]  436 	cjne	a,ar2,00112$
      005480 EF               [12]  437 	mov	a,r7
      005481 B5 03 01         [24]  438 	cjne	a,ar3,00112$
      005484 22               [24]  439 	ret
      005485                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      005485 90 07 10         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005488 12 54 C2         [24]  443 	lcall	_ak820_outline_0014
      00548B 90 06 FC         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      00548E 12 55 12         [24]  445 	lcall	_ak820_outline_0168
      005491 EA               [12]  446 	mov	a,r2
      005492 A3               [24]  447 	inc	dptr
      005493 12 55 18         [24]  448 	lcall	_ak820_outline_0196
      005496 12 54 CB         [24]  449 	lcall	_ak820_outline_0049
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      005499 02 53 9A         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0002
                                    459 	.globl _ak820_outline_0005
                                    460 	.globl _ak820_outline_0014
                                    461 	.globl _ak820_outline_0020
                                    462 	.globl _ak820_outline_0038
                                    463 	.globl _ak820_outline_0049
                                    464 	.globl _ak820_outline_0054
                                    465 	.globl _ak820_outline_0056
                                    466 	.globl _ak820_outline_0059
                                    467 	.globl _ak820_outline_0061
                                    468 	.globl _ak820_outline_0062
                                    469 	.globl _ak820_outline_0078
                                    470 	.globl _ak820_outline_0093
                                    471 	.globl _ak820_outline_0094
                                    472 	.globl _ak820_outline_0112
                                    473 	.globl _ak820_outline_0128
                                    474 	.globl _ak820_outline_0129
                                    475 	.globl _ak820_outline_0139
                                    476 	.globl _ak820_outline_0154
                                    477 	.globl _ak820_outline_0168
                                    478 	.globl _ak820_outline_0196
                                    479 
                                    480 	.area CSEG (CODE)
                                    481 ; function ak820_outline_0002
      00549C                        482 _ak820_outline_0002:
      00549C E0               [24]  483 	movx	a,@dptr
      00549D FD               [12]  484 	mov	r5,a
      00549E A3               [24]  485 	inc	dptr
      00549F E0               [24]  486 	movx	a,@dptr
      0054A0 FE               [12]  487 	mov	r6,a
      0054A1 A3               [24]  488 	inc	dptr
      0054A2 E0               [24]  489 	movx	a,@dptr
      0054A3 FF               [12]  490 	mov	r7,a
      0054A4 8D 82            [24]  491 	mov	dpl,r5
      0054A6 8E 83            [24]  492 	mov	dph,r6
      0054A8 8F F0            [24]  493 	mov	b,r7
      0054AA 22               [24]  494 	ret
                                    495 
                                    496 	.area CSEG (CODE)
                                    497 ; function ak820_outline_0005
      0054AB                        498 _ak820_outline_0005:
      0054AB E0               [24]  499 	movx	a,@dptr
      0054AC FD               [12]  500 	mov	r5,a
      0054AD A3               [24]  501 	inc	dptr
      0054AE E0               [24]  502 	movx	a,@dptr
      0054AF FE               [12]  503 	mov	r6,a
      0054B0 A3               [24]  504 	inc	dptr
      0054B1 E0               [24]  505 	movx	a,@dptr
      0054B2 FF               [12]  506 	mov	r7,a
      0054B3 90 05 F6         [24]  507 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0054B6 ED               [12]  508 	mov	a,r5
      0054B7 F0               [24]  509 	movx	@dptr,a
      0054B8 EE               [12]  510 	mov	a,r6
      0054B9 A3               [24]  511 	inc	dptr
      0054BA F0               [24]  512 	movx	@dptr,a
      0054BB EF               [12]  513 	mov	a,r7
      0054BC A3               [24]  514 	inc	dptr
      0054BD F0               [24]  515 	movx	@dptr,a
      0054BE 90 05 F9         [24]  516 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0054C1 22               [24]  517 	ret
                                    518 
                                    519 	.area CSEG (CODE)
                                    520 ; function ak820_outline_0014
      0054C2                        521 _ak820_outline_0014:
      0054C2 E0               [24]  522 	movx	a,@dptr
      0054C3 FD               [12]  523 	mov	r5,a
      0054C4 A3               [24]  524 	inc	dptr
      0054C5 E0               [24]  525 	movx	a,@dptr
      0054C6 FE               [12]  526 	mov	r6,a
      0054C7 A3               [24]  527 	inc	dptr
      0054C8 E0               [24]  528 	movx	a,@dptr
      0054C9 FF               [12]  529 	mov	r7,a
      0054CA 22               [24]  530 	ret
                                    531 
                                    532 	.area CSEG (CODE)
                                    533 ; function ak820_outline_0049
      0054CB                        534 _ak820_outline_0049:
      0054CB 8D 82            [24]  535 	mov	dpl,r5
      0054CD 8E 83            [24]  536 	mov	dph,r6
      0054CF 8F F0            [24]  537 	mov	b,r7
      0054D1 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0054
      0054D2                        542 _ak820_outline_0054:
      0054D2 E4               [12]  543 	clr	a
      0054D3 F0               [24]  544 	movx	@dptr,a
      0054D4 A3               [24]  545 	inc	dptr
      0054D5 F0               [24]  546 	movx	@dptr,a
      0054D6 A3               [24]  547 	inc	dptr
      0054D7 F0               [24]  548 	movx	@dptr,a
      0054D8 A3               [24]  549 	inc	dptr
      0054D9 F0               [24]  550 	movx	@dptr,a
      0054DA 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0059
      0054DB                        555 _ak820_outline_0059:
      0054DB E0               [24]  556 	movx	a,@dptr
      0054DC FC               [12]  557 	mov	r4,a
      0054DD A3               [24]  558 	inc	dptr
      0054DE E0               [24]  559 	movx	a,@dptr
      0054DF FD               [12]  560 	mov	r5,a
      0054E0 A3               [24]  561 	inc	dptr
      0054E1 E0               [24]  562 	movx	a,@dptr
      0054E2 FE               [12]  563 	mov	r6,a
      0054E3 A3               [24]  564 	inc	dptr
      0054E4 E0               [24]  565 	movx	a,@dptr
      0054E5 8C 82            [24]  566 	mov	dpl,r4
      0054E7 8D 83            [24]  567 	mov	dph,r5
      0054E9 8E F0            [24]  568 	mov	b,r6
      0054EB 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0061
      0054EC                        573 _ak820_outline_0061:
      0054EC AC 82            [24]  574 	mov	r4,dpl
      0054EE AD 83            [24]  575 	mov	r5,dph
      0054F0 AE F0            [24]  576 	mov	r6,b
      0054F2 FF               [12]  577 	mov	r7,a
      0054F3 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0093
      0054F4                        582 _ak820_outline_0093:
      0054F4 E0               [24]  583 	movx	a,@dptr
      0054F5 F9               [12]  584 	mov	r1,a
      0054F6 A3               [24]  585 	inc	dptr
      0054F7 E0               [24]  586 	movx	a,@dptr
      0054F8 FA               [12]  587 	mov	r2,a
      0054F9 A3               [24]  588 	inc	dptr
      0054FA E0               [24]  589 	movx	a,@dptr
      0054FB FB               [12]  590 	mov	r3,a
      0054FC 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0094
      0054FD                        595 _ak820_outline_0094:
      0054FD E0               [24]  596 	movx	a,@dptr
      0054FE FE               [12]  597 	mov	r6,a
      0054FF A3               [24]  598 	inc	dptr
      005500 E0               [24]  599 	movx	a,@dptr
      005501 8E 82            [24]  600 	mov	dpl,r6
      005503 F5 83            [12]  601 	mov	dph,a
      005505 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0112
      005506                        606 _ak820_outline_0112:
      005506 74 02            [12]  607 	mov	a,#0x02
      005508 F0               [24]  608 	movx	@dptr,a
      005509 E4               [12]  609 	clr	a
      00550A A3               [24]  610 	inc	dptr
      00550B F0               [24]  611 	movx	@dptr,a
      00550C 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0154
      00550D                        616 _ak820_outline_0154:
      00550D E4               [12]  617 	clr	a
      00550E F0               [24]  618 	movx	@dptr,a
      00550F A3               [24]  619 	inc	dptr
      005510 F0               [24]  620 	movx	@dptr,a
      005511 22               [24]  621 	ret
                                    622 
                                    623 	.area CSEG (CODE)
                                    624 ; function ak820_outline_0168
      005512                        625 _ak820_outline_0168:
      005512 E8               [12]  626 	mov	a,r0
      005513 F0               [24]  627 	movx	@dptr,a
      005514 E9               [12]  628 	mov	a,r1
      005515 A3               [24]  629 	inc	dptr
      005516 F0               [24]  630 	movx	@dptr,a
      005517 22               [24]  631 	ret
                                    632 
                                    633 	.area CSEG (CODE)
                                    634 ; function ak820_outline_0196
      005518                        635 _ak820_outline_0196:
      005518 F0               [24]  636 	movx	@dptr,a
      005519 EB               [12]  637 	mov	a,r3
      00551A A3               [24]  638 	inc	dptr
      00551B F0               [24]  639 	movx	@dptr,a
      00551C 22               [24]  640 	ret
