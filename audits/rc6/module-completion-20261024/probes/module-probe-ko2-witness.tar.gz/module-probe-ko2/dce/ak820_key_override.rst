                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_key_override
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_key_override
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _ak820_key_override_process_PARM_3
                                    256 	.globl _ak820_key_override_process_PARM_2
                                    257 	.globl _ak820_key_override_sync_PARM_2
                                    258 	.globl _ak820_key_override_valid
                                    259 	.globl _ak820_key_override_cancel
                                    260 	.globl _ak820_key_override_reload
                                    261 	.globl _ak820_key_override_sync
                                    262 	.globl _ak820_key_override_process
                                    263 	.globl _ak820_key_override_key
                                    264 	.globl _ak820_key_override_mods
                                    265 ;--------------------------------------------------------
                                    266 ; special function registers
                                    267 ;--------------------------------------------------------
                                    268 	.area RSEG    (ABS,DATA)
      000000                        269 	.org 0x0000
                           0000D0   270 _PSW	=	0x00d0
                           0000E0   271 _ACC	=	0x00e0
                           0000F0   272 _B	=	0x00f0
                           0000FD   273 _A_INV	=	0x00fd
                           000081   274 _SP	=	0x0081
                           000082   275 _DPL	=	0x0082
                           000083   276 _DPH	=	0x0083
                           0000A1   277 _SAFE_MOD	=	0x00a1
                           0000B1   278 _GLOBAL_CFG	=	0x00b1
                           000087   279 _PCON	=	0x0087
                           0000BA   280 _POWER_CFG	=	0x00ba
                           0000B9   281 _CLOCK_CFG	=	0x00b9
                           0000A9   282 _WAKE_CTRL	=	0x00a9
                           0000FE   283 _RESET_KEEP	=	0x00fe
                           0000FF   284 _WDOG_COUNT	=	0x00ff
                           0000A8   285 _IE	=	0x00a8
                           0000B8   286 _IP	=	0x00b8
                           0000E8   287 _IE_EX	=	0x00e8
                           0000E9   288 _IP_EX	=	0x00e9
                           0000B2   289 _GPIO_IE	=	0x00b2
                           008584   290 _ROM_ADDR	=	0x8584
                           000084   291 _ROM_ADDR_L	=	0x0084
                           000085   292 _ROM_ADDR_H	=	0x0085
                           008F8E   293 _ROM_DATA_HI	=	0x8f8e
                           00008E   294 _ROM_DATA_HL	=	0x008e
                           00008F   295 _ROM_DATA_HH	=	0x008f
                           000086   296 _ROM_CTRL	=	0x0086
                           000080   297 _P0	=	0x0080
                           0000C4   298 _P0_MOD_OC	=	0x00c4
                           0000C5   299 _P0_DIR_PU	=	0x00c5
                           000090   300 _P1	=	0x0090
                           000092   301 _P1_MOD_OC	=	0x0092
                           000093   302 _P1_DIR_PU	=	0x0093
                           0000A0   303 _P2	=	0x00a0
                           000094   304 _P2_MOD_OC	=	0x0094
                           000095   305 _P2_DIR_PU	=	0x0095
                           0000B0   306 _P3	=	0x00b0
                           000096   307 _P3_MOD_OC	=	0x0096
                           000097   308 _P3_DIR_PU	=	0x0097
                           0000C0   309 _P4	=	0x00c0
                           0000C2   310 _P4_MOD_OC	=	0x00c2
                           0000C3   311 _P4_DIR_PU	=	0x00c3
                           0000C1   312 _P4_LED_KEY	=	0x00c1
                           0000AA   313 _P5_IN	=	0x00aa
                           0000AB   314 _P5_OUT_PU	=	0x00ab
                           0000AC   315 _P5_DIR	=	0x00ac
                           0000AD   316 _P6_IN	=	0x00ad
                           0000AE   317 _P6_OUT_PU	=	0x00ae
                           0000AF   318 _P6_DIR	=	0x00af
                           0000F1   319 _P7	=	0x00f1
                           0000A2   320 _XBUS_AUX	=	0x00a2
                           000088   321 _TCON	=	0x0088
                           000089   322 _TMOD	=	0x0089
                           00008A   323 _TL0	=	0x008a
                           00008B   324 _TL1	=	0x008b
                           00008C   325 _TH0	=	0x008c
                           00008D   326 _TH1	=	0x008d
                           000098   327 _SCON	=	0x0098
                           000099   328 _SBUF	=	0x0099
                           0000C8   329 _T2CON	=	0x00c8
                           0000C9   330 _T2MOD	=	0x00c9
                           00CBCA   331 _RCAP2	=	0xcbca
                           0000CA   332 _RCAP2L	=	0x00ca
                           0000CB   333 _RCAP2H	=	0x00cb
                           00CDCC   334 _T2COUNT	=	0xcdcc
                           0000CC   335 _TL2	=	0x00cc
                           0000CD   336 _TH2	=	0x00cd
                           00CFCE   337 _T2CAP1	=	0xcfce
                           0000CE   338 _T2CAP1L	=	0x00ce
                           0000CF   339 _T2CAP1H	=	0x00cf
                           0000F8   340 _SPI0_STAT	=	0x00f8
                           0000F9   341 _SPI0_DATA	=	0x00f9
                           0000FA   342 _SPI0_CTRL	=	0x00fa
                           0000FB   343 _SPI0_CK_SE	=	0x00fb
                           0000FC   344 _SPI0_SETUP	=	0x00fc
                           0000BC   345 _SCON1	=	0x00bc
                           0000BD   346 _SBUF1	=	0x00bd
                           0000BE   347 _SBAUD1	=	0x00be
                           0000BF   348 _SIF1	=	0x00bf
                           0000B4   349 _SPI1_STAT	=	0x00b4
                           0000B5   350 _SPI1_DATA	=	0x00b5
                           0000B6   351 _SPI1_CTRL	=	0x00b6
                           0000B7   352 _SPI1_CK_SE	=	0x00b7
                           0000F3   353 _ADC_CTRL	=	0x00f3
                           00F5F4   354 _ADC_DAT	=	0xf5f4
                           0000F4   355 _ADC_DAT_L	=	0x00f4
                           0000F5   356 _ADC_DAT_H	=	0x00f5
                           0000F6   357 _ADC_CHAN	=	0x00f6
                           0000A6   358 _LED_COMMON	=	0x00a6
                           0000A7   359 _LED_PWM_OE	=	0x00a7
                           00C7C6   360 _LED_DMA	=	0xc7c6
                           0000C6   361 _LED_DMA_L	=	0x00c6
                           0000C7   362 _LED_DMA_H	=	0x00c7
                           0000F7   363 _LED_STATUS	=	0x00f7
                           0000B3   364 _I2CX_INT	=	0x00b3
                           0000BB   365 _I2CS_INT_ST	=	0x00bb
                                    366 ;--------------------------------------------------------
                                    367 ; special function bits
                                    368 ;--------------------------------------------------------
                                    369 	.area RSEG    (ABS,DATA)
      000000                        370 	.org 0x0000
                           0000D7   371 _CY	=	0x00d7
                           0000D6   372 _AC	=	0x00d6
                           0000D5   373 _F0	=	0x00d5
                           0000D4   374 _RS1	=	0x00d4
                           0000D3   375 _RS0	=	0x00d3
                           0000D2   376 _OV	=	0x00d2
                           0000D1   377 _F1	=	0x00d1
                           0000D0   378 _P	=	0x00d0
                           0000AF   379 _EA	=	0x00af
                           0000AE   380 _E_DIS	=	0x00ae
                           0000AD   381 _ET2	=	0x00ad
                           0000AC   382 _ES	=	0x00ac
                           0000AB   383 _ET1	=	0x00ab
                           0000AA   384 _EX1	=	0x00aa
                           0000A9   385 _ET0	=	0x00a9
                           0000A8   386 _EX0	=	0x00a8
                           0000BF   387 _PH_FLAG	=	0x00bf
                           0000BE   388 _PL_FLAG	=	0x00be
                           0000BD   389 _PT2	=	0x00bd
                           0000BC   390 _PS	=	0x00bc
                           0000BB   391 _PT1	=	0x00bb
                           0000BA   392 _PX1	=	0x00ba
                           0000B9   393 _PT0	=	0x00b9
                           0000B8   394 _PX0	=	0x00b8
                           0000EF   395 _IE_WDOG	=	0x00ef
                           0000EE   396 _IE_GPIO	=	0x00ee
                           0000ED   397 _IE_PWM_I2C	=	0x00ed
                           0000EC   398 _IE_UART1	=	0x00ec
                           0000EB   399 _IE_ADC	=	0x00eb
                           0000E9   400 _IE_USB	=	0x00e9
                           0000E8   401 _IE_SPI0	=	0x00e8
                           000087   402 _P0_7	=	0x0087
                           000086   403 _P0_6	=	0x0086
                           000085   404 _P0_5	=	0x0085
                           000084   405 _P0_4	=	0x0084
                           000083   406 _P0_3	=	0x0083
                           000082   407 _P0_2	=	0x0082
                           000081   408 _P0_1	=	0x0081
                           000080   409 _P0_0	=	0x0080
                           000081   410 _SDA0	=	0x0081
                           000080   411 _SCL0	=	0x0080
                           000083   412 _TXD_	=	0x0083
                           000082   413 _RXD_	=	0x0082
                           000085   414 _AIN13	=	0x0085
                           000084   415 _AIN12	=	0x0084
                           000083   416 _AIN11	=	0x0083
                           000082   417 _AIN10	=	0x0082
                           000081   418 _AIN9	=	0x0081
                           000080   419 _AIN8	=	0x0080
                           000097   420 _P1_7	=	0x0097
                           000096   421 _P1_6	=	0x0096
                           000095   422 _P1_5	=	0x0095
                           000094   423 _P1_4	=	0x0094
                           000093   424 _P1_3	=	0x0093
                           000092   425 _P1_2	=	0x0092
                           000091   426 _P1_1	=	0x0091
                           000090   427 _P1_0	=	0x0090
                           000097   428 _TXD1_	=	0x0097
                           000096   429 _RXD1_	=	0x0096
                           000097   430 _SCK	=	0x0097
                           000096   431 _MISO	=	0x0096
                           000095   432 _MOSI	=	0x0095
                           000094   433 _SCS	=	0x0094
                           000092   434 _INT0_	=	0x0092
                           000091   435 _T2EX	=	0x0091
                           000091   436 _CAP2	=	0x0091
                           000090   437 _T2	=	0x0090
                           000090   438 _CAP1	=	0x0090
                           000097   439 _AIN7	=	0x0097
                           000096   440 _AIN6	=	0x0096
                           000095   441 _AIN5	=	0x0095
                           000094   442 _AIN4	=	0x0094
                           000093   443 _AIN3	=	0x0093
                           000092   444 _AIN2	=	0x0092
                           000091   445 _AIN1	=	0x0091
                           000090   446 _AIN0	=	0x0090
                           0000A7   447 _P2_7	=	0x00a7
                           0000A6   448 _P2_6	=	0x00a6
                           0000A5   449 _P2_5	=	0x00a5
                           0000A4   450 _P2_4	=	0x00a4
                           0000A3   451 _P2_3	=	0x00a3
                           0000A2   452 _P2_2	=	0x00a2
                           0000A1   453 _P2_1	=	0x00a1
                           0000A0   454 _P2_0	=	0x00a0
                           0000A7   455 _TXD1	=	0x00a7
                           0000A6   456 _RXD1	=	0x00a6
                           0000A5   457 _T2EX_	=	0x00a5
                           0000A5   458 _CAP2_	=	0x00a5
                           0000A4   459 _T2_	=	0x00a4
                           0000A4   460 _CAP1_	=	0x00a4
                           0000B7   461 _P3_7	=	0x00b7
                           0000B6   462 _P3_6	=	0x00b6
                           0000B5   463 _P3_5	=	0x00b5
                           0000B4   464 _P3_4	=	0x00b4
                           0000B3   465 _P3_3	=	0x00b3
                           0000B2   466 _P3_2	=	0x00b2
                           0000B1   467 _P3_1	=	0x00b1
                           0000B0   468 _P3_0	=	0x00b0
                           0000B7   469 _SCK1	=	0x00b7
                           0000B6   470 _MISO1	=	0x00b6
                           0000B5   471 _MOSI1	=	0x00b5
                           0000B5   472 _T1	=	0x00b5
                           0000B4   473 _T0	=	0x00b4
                           0000B3   474 _INT1	=	0x00b3
                           0000B2   475 _INT0	=	0x00b2
                           0000B1   476 _TXD	=	0x00b1
                           0000B0   477 _RXD	=	0x00b0
                           0000C6   478 _P4_6	=	0x00c6
                           0000C5   479 _P4_5	=	0x00c5
                           0000C4   480 _P4_4	=	0x00c4
                           0000C3   481 _P4_3	=	0x00c3
                           0000C2   482 _P4_2	=	0x00c2
                           0000C1   483 _P4_1	=	0x00c1
                           0000C0   484 _P4_0	=	0x00c0
                           00008F   485 _TF1	=	0x008f
                           00008E   486 _TR1	=	0x008e
                           00008D   487 _TF0	=	0x008d
                           00008C   488 _TR0	=	0x008c
                           00008B   489 _IE1	=	0x008b
                           00008A   490 _IT1	=	0x008a
                           000089   491 _IE0	=	0x0089
                           000088   492 _IT0	=	0x0088
                           00009F   493 _SM0	=	0x009f
                           00009E   494 _SM1	=	0x009e
                           00009D   495 _SM2	=	0x009d
                           00009C   496 _REN	=	0x009c
                           00009B   497 _TB8	=	0x009b
                           00009A   498 _RB8	=	0x009a
                           000099   499 _TI	=	0x0099
                           000098   500 _RI	=	0x0098
                           0000CF   501 _TF2	=	0x00cf
                           0000CF   502 _CAP1F	=	0x00cf
                           0000CE   503 _EXF2	=	0x00ce
                           0000CD   504 _RCLK	=	0x00cd
                           0000CC   505 _TCLK	=	0x00cc
                           0000CB   506 _EXEN2	=	0x00cb
                           0000CA   507 _TR2	=	0x00ca
                           0000C9   508 _C_T2	=	0x00c9
                           0000C8   509 _CP_RL2	=	0x00c8
                           0000FF   510 _S0_FST_ACT	=	0x00ff
                           0000FE   511 _S0_IF_OV	=	0x00fe
                           0000FD   512 _S0_IF_FIRST	=	0x00fd
                           0000FC   513 _S0_IF_BYTE	=	0x00fc
                           0000FB   514 _S0_FREE	=	0x00fb
                           0000FA   515 _S0_T_FIFO	=	0x00fa
                           0000F8   516 _S0_R_FIFO	=	0x00f8
                           0000F7   517 _ADC_START	=	0x00f7
                                    518 ;--------------------------------------------------------
                                    519 ; overlayable register banks
                                    520 ;--------------------------------------------------------
                                    521 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        522 	.ds 8
                                    523 ;--------------------------------------------------------
                                    524 ; internal ram data
                                    525 ;--------------------------------------------------------
                                    526 	.area DSEG    (DATA)
      00000A                        527 _activate_sloc0_1_0:
      00000A                        528 	.ds 2
      00000C                        529 _activate_sloc1_1_0:
      00000C                        530 	.ds 1
      00000D                        531 _activate_sloc2_1_0:
      00000D                        532 	.ds 2
      00000F                        533 _ak820_key_override_process_sloc0_1_0:
      00000F                        534 	.ds 1
      000010                        535 _ak820_key_override_process_sloc1_1_0:
      000010                        536 	.ds 1
      000011                        537 _ak820_key_override_process_sloc2_1_0:
      000011                        538 	.ds 2
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable items in internal ram
                                    541 ;--------------------------------------------------------
                                    542 ;--------------------------------------------------------
                                    543 ; indirectly addressable internal ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area ISEG    (DATA)
                                    546 ;--------------------------------------------------------
                                    547 ; absolute internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area IABS    (ABS,DATA)
                                    550 	.area IABS    (ABS,DATA)
                                    551 ;--------------------------------------------------------
                                    552 ; bit data
                                    553 ;--------------------------------------------------------
                                    554 	.area BSEG    (BIT)
      000004                        555 _ak820_key_override_valid_sloc0_1_0:
      000004                        556 	.ds 1
      000005                        557 _matches_sloc0_1_0:
      000005                        558 	.ds 1
      000006                        559 _eligible_sloc0_1_0:
      000006                        560 	.ds 1
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      0004F9                        569 _entries:
      0004F9                        570 	.ds 80
      000549                        571 _trigger:
      000549                        572 	.ds 1
      00054A                        573 _previous_mods:
      00054A                        574 	.ds 1
      00054B                        575 _blocked:
      00054B                        576 	.ds 1
      00054C                        577 _hidden:
      00054C                        578 	.ds 1
      00054D                        579 _ak820_key_override_valid_e_10000_597:
      00054D                        580 	.ds 2
      00054F                        581 _ak820_key_override_valid_any_10000_598:
      00054F                        582 	.ds 1
      000550                        583 _replacement_mods_key_10000_605:
      000550                        584 	.ds 2
      000552                        585 _matches_PARM_2:
      000552                        586 	.ds 1
      000553                        587 _matches_PARM_3:
      000553                        588 	.ds 1
      000554                        589 _matches_mods_10000_607:
      000554                        590 	.ds 1
      000555                        591 _eligible_PARM_2:
      000555                        592 	.ds 1
      000556                        593 _eligible_PARM_3:
      000556                        594 	.ds 1
      000557                        595 _eligible_index_10000_610:
      000557                        596 	.ds 1
      000558                        597 _activate_PARM_2:
      000558                        598 	.ds 1
      000559                        599 _activate_PARM_3:
      000559                        600 	.ds 1
      00055A                        601 _activate_reason_10000_622:
      00055A                        602 	.ds 1
      00055B                        603 _activate_e_30000_626:
      00055B                        604 	.ds 2
      00055D                        605 _ak820_key_override_sync_PARM_2:
      00055D                        606 	.ds 1
      00055E                        607 _ak820_key_override_sync_mods_10000_629:
      00055E                        608 	.ds 1
      00055F                        609 _ak820_key_override_sync_reason_10000_630:
      00055F                        610 	.ds 1
      000560                        611 _ak820_key_override_process_PARM_2:
      000560                        612 	.ds 1
      000561                        613 _ak820_key_override_process_PARM_3:
      000561                        614 	.ds 1
      000562                        615 _ak820_key_override_process_record_10000_634:
      000562                        616 	.ds 2
      000564                        617 _ak820_key_override_mods_mods_10000_659:
      000564                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; absolute external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area XABS    (ABS,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; initialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XISEG   (XDATA)
      000E3F                        627 _source:
      000E3F                        628 	.ds 1
      000E40                        629 _active:
      000E40                        630 	.ds 1
      000E41                        631 _enabled:
      000E41                        632 	.ds 1
                                    633 	.area HOME    (CODE)
                                    634 	.area GSINIT0 (CODE)
                                    635 	.area GSINIT1 (CODE)
                                    636 	.area GSINIT2 (CODE)
                                    637 	.area GSINIT3 (CODE)
                                    638 	.area GSINIT4 (CODE)
                                    639 	.area GSINIT5 (CODE)
                                    640 	.area GSINIT  (CODE)
                                    641 	.area GSFINAL (CODE)
                                    642 	.area CSEG    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; global & static initialisations
                                    645 ;--------------------------------------------------------
                                    646 	.area HOME    (CODE)
                                    647 	.area GSINIT  (CODE)
                                    648 	.area GSFINAL (CODE)
                                    649 	.area GSINIT  (CODE)
                                    650 ;--------------------------------------------------------
                                    651 ; Home
                                    652 ;--------------------------------------------------------
                                    653 	.area HOME    (CODE)
                                    654 	.area HOME    (CODE)
                                    655 ;--------------------------------------------------------
                                    656 ; code
                                    657 ;--------------------------------------------------------
                                    658 	.area CSEG    (CODE)
                                    659 ;------------------------------------------------------------
                                    660 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    661 ;------------------------------------------------------------
                                    662 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    663 ;------------------------------------------------------------
                                    664 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    665 ;	-----------------------------------------
                           000007   666 	ar7 = 0x07
                           000006   667 	ar6 = 0x06
                           000005   668 	ar5 = 0x05
                           000004   669 	ar4 = 0x04
                           000003   670 	ar3 = 0x03
                           000002   671 	ar2 = 0x02
                           000001   672 	ar1 = 0x01
                           000000   673 	ar0 = 0x00
                                    674 ;	 function ak820_key_override_valid
                                    675 ;	-----------------------------------------
      003B3B                        676 _ak820_key_override_valid:
      003B3B 12 38 44         [24]  677 	lcall	_ak820_outline_0109
      003B3E 90 05 4D         [24]  678 	mov	dptr,#_ak820_key_override_valid_e_10000_597
      003B41 12 38 49         [24]  679 	lcall	_ak820_outline_0110
                                    680 ;	keyboards/ajazz/ak820/ak820_key_override.c:17: const uint8_t AK820_STATE_MEM *bytes = (const uint8_t AK820_STATE_MEM *)e;
      003B44 90 05 4D         [24]  681 	mov	dptr,#_ak820_key_override_valid_e_10000_597
      003B47 12 37 FD         [24]  682 	lcall	_ak820_outline_0056
                                    683 ;	keyboards/ajazz/ak820/ak820_key_override.c:18: uint8_t any = 0;
      003B4A 90 05 4F         [24]  684 	mov	dptr,#_ak820_key_override_valid_any_10000_598
      003B4D E4               [12]  685 	clr	a
      003B4E F0               [24]  686 	movx	@dptr,a
                                    687 ;	keyboards/ajazz/ak820/ak820_key_override.c:21: for (uint8_t i = 0; i < 10; ++i) any |= bytes[i];
      003B4F FD               [12]  688 	mov	r5,a
      003B50                        689 00118$:
      003B50 BD 0A 00         [24]  690 	cjne	r5,#0x0a,00206$
      003B53                        691 00206$:
      003B53 50 0E            [24]  692 	jnc	00101$
      003B55 ED               [12]  693 	mov	a,r5
      003B56 12 37 D2         [24]  694 	lcall	_ak820_outline_0013
      003B59 FC               [12]  695 	mov	r4,a
      003B5A 90 05 4F         [24]  696 	mov	dptr,#_ak820_key_override_valid_any_10000_598
      003B5D E0               [24]  697 	movx	a,@dptr
      003B5E 4C               [12]  698 	orl	a,r4
      003B5F F0               [24]  699 	movx	@dptr,a
      003B60 0D               [12]  700 	inc	r5
      003B61 80 ED            [24]  701 	sjmp	00118$
      003B63                        702 00101$:
                                    703 ;	keyboards/ajazz/ak820/ak820_key_override.c:22: if (!any) return true;
      003B63 90 05 4F         [24]  704 	mov	dptr,#_ak820_key_override_valid_any_10000_598
      003B66 E0               [24]  705 	movx	a,@dptr
      003B67 70 04            [24]  706 	jnz	00103$
      003B69 75 82 01         [24]  707 	mov	dpl, #0x01
      003B6C 22               [24]  708 	ret
      003B6D                        709 00103$:
                                    710 ;	keyboards/ajazz/ak820/ak820_key_override.c:23: if (bytes[1] || !basic(bytes[0])) return false;
      003B6D 74 01            [12]  711 	mov	a,#0x01
      003B6F 12 41 26         [24]  712 	lcall	_ak820_outline_0012
      003B72 70 0E            [24]  713 	jnz	00104$
      003B74 12 38 32         [24]  714 	lcall	_ak820_outline_0098
      003B77 FD               [12]  715 	mov	r5,a
      003B78 BD 04 00         [24]  716 	cjne	r5,#0x04,00210$
      003B7B                        717 00210$:
      003B7B 40 05            [24]  718 	jc	00104$
      003B7D ED               [12]  719 	mov	a,r5
      003B7E 24 5B            [12]  720 	add	a,#0xff - 0xa4
      003B80 50 04            [24]  721 	jnc	00105$
                                    722 ;	free result
      003B82                        723 00104$:
      003B82 75 82 00         [24]  724 	mov	dpl, #0x00
      003B85 22               [24]  725 	ret
      003B86                        726 00105$:
                                    727 ;	keyboards/ajazz/ak820/ak820_key_override.c:24: if (bytes[5] || !bytes[4] || (bytes[4] & 0xC0)) return false;
      003B86 74 05            [12]  728 	mov	a,#0x05
      003B88 12 41 26         [24]  729 	lcall	_ak820_outline_0012
      003B8B 70 0B            [24]  730 	jnz	00108$
      003B8D 12 41 47         [24]  731 	lcall	_ak820_outline_0018
      003B90 FD               [12]  732 	mov	r5,a
      003B91 60 05            [24]  733 	jz	00108$
      003B93 ED               [12]  734 	mov	a,r5
      003B94 54 C0            [12]  735 	anl	a,#0xc0
      003B96 60 04            [24]  736 	jz	00109$
      003B98                        737 00108$:
      003B98 75 82 00         [24]  738 	mov	dpl, #0x00
      003B9B 22               [24]  739 	ret
      003B9C                        740 00109$:
                                    741 ;	keyboards/ajazz/ak820/ak820_key_override.c:25: if ((bytes[9] & 0x40) || !(bytes[9] & ACTIVATIONS)) return false;
      003B9C 74 09            [12]  742 	mov	a,#0x09
      003B9E 12 37 D2         [24]  743 	lcall	_ak820_outline_0013
      003BA1 FD               [12]  744 	mov	r5,a
      003BA2 20 E6 05         [24]  745 	jb	acc.6,00112$
      003BA5 ED               [12]  746 	mov	a,r5
      003BA6 54 07            [12]  747 	anl	a,#0x07
      003BA8 70 04            [24]  748 	jnz	00113$
      003BAA                        749 00112$:
      003BAA 75 82 00         [24]  750 	mov	dpl, #0x00
      003BAD 22               [24]  751 	ret
      003BAE                        752 00113$:
                                    753 ;	keyboards/ajazz/ak820/ak820_key_override.c:27: if (bytes[2] | bytes[3]) return bytes[3] < 32 && basic(bytes[2]);
      003BAE 12 37 F5         [24]  754 	lcall	_ak820_outline_0034
      003BB1 FD               [12]  755 	mov	r5,a
      003BB2 12 41 31         [24]  756 	lcall	_ak820_outline_0016
      003BB5 FF               [12]  757 	mov	r7,a
      003BB6 4D               [12]  758 	orl	a,r5
      003BB7 60 1B            [24]  759 	jz	00116$
      003BB9 BF 20 00         [24]  760 	cjne	r7,#0x20,00220$
      003BBC                        761 00220$:
      003BBC 50 0A            [24]  762 	jnc	00122$
      003BBE BD 04 00         [24]  763 	cjne	r5,#0x04,00222$
      003BC1                        764 00222$:
      003BC1 40 05            [24]  765 	jc	00122$
      003BC3 ED               [12]  766 	mov	a,r5
      003BC4 24 5B            [12]  767 	add	a,#0xff - 0xa4
      003BC6 50 04            [24]  768 	jnc	00123$
                                    769 ;	free result
      003BC8                        770 00122$:
                                    771 ;	assignBit
      003BC8 C2 04            [12]  772 	clr	_ak820_key_override_valid_sloc0_1_0
      003BCA 80 02            [24]  773 	sjmp	00124$
      003BCC                        774 00123$:
                                    775 ;	assignBit
      003BCC D2 04            [12]  776 	setb	_ak820_key_override_valid_sloc0_1_0
      003BCE                        777 00124$:
      003BCE A2 04            [12]  778 	mov	c,_ak820_key_override_valid_sloc0_1_0
      003BD0 12 38 69         [24]  779 	lcall	_ak820_outline_0149
      003BD3 22               [24]  780 	ret
      003BD4                        781 00116$:
                                    782 ;	keyboards/ajazz/ak820/ak820_key_override.c:28: return true;
      003BD4 75 82 01         [24]  783 	mov	dpl, #0x01
                                    784 ;	keyboards/ajazz/ak820/ak820_key_override.c:29: }
      003BD7 22               [24]  785 	ret
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'replacement_mods'
                                    788 ;------------------------------------------------------------
                                    789 ;key           Allocated with name '_replacement_mods_key_10000_605'
                                    790 ;mods          Allocated with name '_replacement_mods_mods_10000_606'
                                    791 ;------------------------------------------------------------
                                    792 ;	keyboards/ajazz/ak820/ak820_key_override.c:30: static uint8_t replacement_mods(uint16_t key) {
                                    793 ;	-----------------------------------------
                                    794 ;	 function replacement_mods
                                    795 ;	-----------------------------------------
      003BD8                        796 _replacement_mods:
      003BD8 12 38 44         [24]  797 	lcall	_ak820_outline_0109
      003BDB 90 05 50         [24]  798 	mov	dptr,#_replacement_mods_key_10000_605
      003BDE 12 38 49         [24]  799 	lcall	_ak820_outline_0110
                                    800 ;	keyboards/ajazz/ak820/ak820_key_override.c:31: uint8_t mods = QK_MODS_GET_MODS(key);
      003BE1 90 05 50         [24]  801 	mov	dptr,#_replacement_mods_key_10000_605
      003BE4 E0               [24]  802 	movx	a,@dptr
      003BE5 A3               [24]  803 	inc	dptr
      003BE6 E0               [24]  804 	movx	a,@dptr
      003BE7 FE               [12]  805 	mov	r6,a
      003BE8 74 1F            [12]  806 	mov	a,#0x1f
      003BEA 5E               [12]  807 	anl	a,r6
                                    808 ;	keyboards/ajazz/ak820/ak820_key_override.c:32: return (mods & 0x10) ? (mods & 15) << 4 : mods;
      003BEB FF               [12]  809 	mov	r7,a
      003BEC 30 E4 0C         [24]  810 	jnb	acc.4,00103$
      003BEF 8F 06            [24]  811 	mov	ar6,r7
      003BF1 53 06 0F         [24]  812 	anl	ar6,#0x0f
      003BF4 EE               [12]  813 	mov	a,r6
      003BF5 C4               [12]  814 	swap	a
      003BF6 54 F0            [12]  815 	anl	a,#0xf0
      003BF8 FE               [12]  816 	mov	r6,a
      003BF9 80 02            [24]  817 	sjmp	00104$
      003BFB                        818 00103$:
      003BFB 8F 06            [24]  819 	mov	ar6,r7
      003BFD                        820 00104$:
      003BFD 8E 82            [24]  821 	mov	dpl, r6
                                    822 ;	keyboards/ajazz/ak820/ak820_key_override.c:33: }
      003BFF 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'matches'
                                    826 ;------------------------------------------------------------
                                    827 ;required      Allocated with name '_matches_PARM_2'
                                    828 ;one           Allocated with name '_matches_PARM_3'
                                    829 ;mods          Allocated with name '_matches_mods_10000_607'
                                    830 ;low           Allocated with name '_matches_low_10000_608'
                                    831 ;high          Allocated with name '_matches_high_10000_608'
                                    832 ;------------------------------------------------------------
                                    833 ;	keyboards/ajazz/ak820/ak820_key_override.c:35: static bool matches(uint8_t mods, uint8_t required, bool one) {
                                    834 ;	-----------------------------------------
                                    835 ;	 function matches
                                    836 ;	-----------------------------------------
      003C00                        837 _matches:
      003C00 E5 82            [12]  838 	mov	a,dpl
      003C02 90 05 54         [24]  839 	mov	dptr,#_matches_mods_10000_607
      003C05 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_key_override.c:36: uint8_t low = required & 15, high = required >> 4;
      003C06 90 05 52         [24]  842 	mov	dptr,#_matches_PARM_2
      003C09 E0               [24]  843 	movx	a,@dptr
      003C0A FF               [12]  844 	mov	r7,a
      003C0B 74 0F            [12]  845 	mov	a,#0x0f
      003C0D 5F               [12]  846 	anl	a,r7
      003C0E FE               [12]  847 	mov	r6,a
      003C0F EF               [12]  848 	mov	a,r7
      003C10 C4               [12]  849 	swap	a
      003C11 54 0F            [12]  850 	anl	a,#0x0f
      003C13 FD               [12]  851 	mov	r5,a
                                    852 ;	keyboards/ajazz/ak820/ak820_key_override.c:37: if (one) return !required || (mods & required);
      003C14 90 05 53         [24]  853 	mov	dptr,#_matches_PARM_3
      003C17 E0               [24]  854 	movx	a,@dptr
      003C18 60 16            [24]  855 	jz	00102$
      003C1A EF               [12]  856 	mov	a,r7
      003C1B 60 0B            [24]  857 	jz	00106$
      003C1D 90 05 54         [24]  858 	mov	dptr,#_matches_mods_10000_607
      003C20 E0               [24]  859 	movx	a,@dptr
      003C21 5F               [12]  860 	anl	a,r7
      003C22 70 04            [24]  861 	jnz	00106$
                                    862 ;	assignBit
      003C24 C2 05            [12]  863 	clr	_matches_sloc0_1_0
      003C26 80 02            [24]  864 	sjmp	00107$
      003C28                        865 00106$:
                                    866 ;	assignBit
      003C28 D2 05            [12]  867 	setb	_matches_sloc0_1_0
      003C2A                        868 00107$:
      003C2A A2 05            [12]  869 	mov	c,_matches_sloc0_1_0
      003C2C 12 38 69         [24]  870 	lcall	_ak820_outline_0149
      003C2F 22               [24]  871 	ret
      003C30                        872 00102$:
                                    873 ;	keyboards/ajazz/ak820/ak820_key_override.c:38: return ((mods & low) | ((mods >> 4) & high)) == (low | high);
      003C30 90 05 54         [24]  874 	mov	dptr,#_matches_mods_10000_607
      003C33 E0               [24]  875 	movx	a,@dptr
      003C34 FF               [12]  876 	mov	r7,a
      003C35 EE               [12]  877 	mov	a,r6
      003C36 5F               [12]  878 	anl	a,r7
      003C37 FC               [12]  879 	mov	r4,a
      003C38 EF               [12]  880 	mov	a,r7
      003C39 C4               [12]  881 	swap	a
      003C3A 54 0F            [12]  882 	anl	a,#0x0f
      003C3C FF               [12]  883 	mov	r7,a
      003C3D ED               [12]  884 	mov	a,r5
      003C3E 5F               [12]  885 	anl	a,r7
      003C3F 42 04            [12]  886 	orl	ar4,a
      003C41 ED               [12]  887 	mov	a,r5
      003C42 42 06            [12]  888 	orl	ar6,a
      003C44 EC               [12]  889 	mov	a,r4
      003C45 B5 06 03         [24]  890 	cjne	a,ar6,00132$
      003C48 D3               [12]  891 	setb	c
      003C49 80 01            [24]  892 	sjmp	00133$
      003C4B                        893 00132$:
      003C4B C3               [12]  894 	clr	c
      003C4C                        895 00133$:
      003C4C 92 05            [24]  896 	mov  _matches_sloc0_1_0,c
      003C4E 12 38 69         [24]  897 	lcall	_ak820_outline_0149
                                    898 ;	keyboards/ajazz/ak820/ak820_key_override.c:39: }
      003C51 22               [24]  899 	ret
                                    900 ;------------------------------------------------------------
                                    901 ;Allocation info for local variables in function 'eligible'
                                    902 ;------------------------------------------------------------
                                    903 ;mods          Allocated with name '_eligible_PARM_2'
                                    904 ;layer         Allocated with name '_eligible_PARM_3'
                                    905 ;index         Allocated with name '_eligible_index_10000_610'
                                    906 ;e             Allocated with name '_eligible_e_10000_611'
                                    907 ;------------------------------------------------------------
                                    908 ;	keyboards/ajazz/ak820/ak820_key_override.c:40: static bool eligible(uint8_t index, uint8_t mods, uint8_t layer) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function eligible
                                    911 ;	-----------------------------------------
      003C52                        912 _eligible:
      003C52 E5 82            [12]  913 	mov	a,dpl
      003C54 90 05 57         [24]  914 	mov	dptr,#_eligible_index_10000_610
      003C57 F0               [24]  915 	movx	@dptr,a
                                    916 ;	keyboards/ajazz/ak820/ak820_key_override.c:41: vial_key_override_entry_t AK820_STATE_MEM *e = &entries[index];
      003C58 E0               [24]  917 	movx	a,@dptr
      003C59 12 41 3A         [24]  918 	lcall	_ak820_outline_0017
                                    919 ;	keyboards/ajazz/ak820/ak820_key_override.c:42: return layer < 6 && ((uint8_t)e->layers & ((uint8_t)1 << layer)) &&
      003C5C 90 05 56         [24]  920 	mov	dptr,#_eligible_PARM_3
      003C5F E0               [24]  921 	movx	a,@dptr
      003C60 FD               [12]  922 	mov	r5,a
      003C61 BD 06 00         [24]  923 	cjne	r5,#0x06,00131$
      003C64                        924 00131$:
      003C64 50 53            [24]  925 	jnc	00103$
      003C66 12 41 47         [24]  926 	lcall	_ak820_outline_0018
      003C69 FC               [12]  927 	mov	r4,a
      003C6A 8D F0            [24]  928 	mov	b,r5
      003C6C 05 F0            [12]  929 	inc	b
      003C6E 7D 01            [12]  930 	mov	r5,#0x01
      003C70 7B 00            [12]  931 	mov	r3,#0x00
      003C72 80 06            [24]  932 	sjmp	00134$
      003C74                        933 00133$:
      003C74 ED               [12]  934 	mov	a,r5
      003C75 2D               [12]  935 	add	a,r5
      003C76 FD               [12]  936 	mov	r5,a
      003C77 EB               [12]  937 	mov	a,r3
      003C78 33               [12]  938 	rlc	a
      003C79 FB               [12]  939 	mov	r3,a
      003C7A                        940 00134$:
      003C7A D5 F0 F7         [24]  941 	djnz	b,00133$
      003C7D 7A 00            [12]  942 	mov	r2,#0x00
      003C7F EC               [12]  943 	mov	a,r4
      003C80 52 05            [12]  944 	anl	ar5,a
      003C82 EA               [12]  945 	mov	a,r2
      003C83 52 03            [12]  946 	anl	ar3,a
      003C85 ED               [12]  947 	mov	a,r5
      003C86 4B               [12]  948 	orl	a,r3
      003C87 60 30            [24]  949 	jz	00103$
                                    950 ;	keyboards/ajazz/ak820/ak820_key_override.c:43: !(mods & e->negative_mod_mask) && matches(mods, e->trigger_mods, e->options & 8);
      003C89 74 07            [12]  951 	mov	a,#0x07
      003C8B 12 37 D2         [24]  952 	lcall	_ak820_outline_0013
      003C8E FD               [12]  953 	mov	r5,a
      003C8F 90 05 55         [24]  954 	mov	dptr,#_eligible_PARM_2
      003C92 E0               [24]  955 	movx	a,@dptr
      003C93 FC               [12]  956 	mov	r4,a
      003C94 ED               [12]  957 	mov	a,r5
      003C95 5C               [12]  958 	anl	a,r4
      003C96 70 21            [24]  959 	jnz	00103$
      003C98 74 06            [12]  960 	mov	a,#0x06
      003C9A 12 37 D2         [24]  961 	lcall	_ak820_outline_0013
      003C9D FD               [12]  962 	mov	r5,a
      003C9E 74 09            [12]  963 	mov	a,#0x09
      003CA0 12 37 D2         [24]  964 	lcall	_ak820_outline_0013
      003CA3 90 05 53         [24]  965 	mov	dptr,#_matches_PARM_3
      003CA6 A2 E3            [12]  966 	mov	c,acc.3
      003CA8 E4               [12]  967 	clr	a
      003CA9 33               [12]  968 	rlc	a
      003CAA F0               [24]  969 	movx	@dptr,a
      003CAB 90 05 52         [24]  970 	mov	dptr,#_matches_PARM_2
      003CAE ED               [12]  971 	mov	a,r5
      003CAF F0               [24]  972 	movx	@dptr,a
      003CB0 8C 82            [24]  973 	mov	dpl, r4
      003CB2 12 3C 00         [24]  974 	lcall	_matches
      003CB5 E5 82            [12]  975 	mov	a, dpl
      003CB7 70 04            [24]  976 	jnz	00104$
      003CB9                        977 00103$:
                                    978 ;	assignBit
      003CB9 C2 06            [12]  979 	clr	_eligible_sloc0_1_0
      003CBB 80 02            [24]  980 	sjmp	00105$
      003CBD                        981 00104$:
                                    982 ;	assignBit
      003CBD D2 06            [12]  983 	setb	_eligible_sloc0_1_0
      003CBF                        984 00105$:
      003CBF A2 06            [12]  985 	mov	c,_eligible_sloc0_1_0
      003CC1 12 38 69         [24]  986 	lcall	_ak820_outline_0149
                                    987 ;	keyboards/ajazz/ak820/ak820_key_override.c:44: }
      003CC4 22               [24]  988 	ret
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'deactivate'
                                    991 ;------------------------------------------------------------
                                    992 ;	keyboards/ajazz/ak820/ak820_key_override.c:45: static void deactivate(void) {
                                    993 ;	-----------------------------------------
                                    994 ;	 function deactivate
                                    995 ;	-----------------------------------------
      003CC5                        996 _deactivate:
                                    997 ;	keyboards/ajazz/ak820/ak820_key_override.c:46: if (active != NONE && (entries[active].options & 16)) hidden = true;
      003CC5 12 41 66         [24]  998 	lcall	_ak820_outline_0125
      003CC8 BF FF 02         [24]  999 	cjne	r7,#0xff,00120$
      003CCB 80 12            [24] 1000 	sjmp	00102$
      003CCD                       1001 00120$:
      003CCD EF               [12] 1002 	mov	a,r7
      003CCE 12 41 3A         [24] 1003 	lcall	_ak820_outline_0017
      003CD1 74 09            [12] 1004 	mov	a,#0x09
      003CD3 12 37 D2         [24] 1005 	lcall	_ak820_outline_0013
      003CD6 30 E4 06         [24] 1006 	jnb	acc.4,00102$
      003CD9 90 05 4C         [24] 1007 	mov	dptr,#_hidden
      003CDC 74 01            [12] 1008 	mov	a,#0x01
      003CDE F0               [24] 1009 	movx	@dptr,a
      003CDF                       1010 00102$:
                                   1011 ;	keyboards/ajazz/ak820/ak820_key_override.c:47: active = NONE;
      003CDF 90 0E 40         [24] 1012 	mov	dptr,#_active
      003CE2 74 FF            [12] 1013 	mov	a,#0xff
      003CE4 F0               [24] 1014 	movx	@dptr,a
                                   1015 ;	keyboards/ajazz/ak820/ak820_key_override.c:48: }
      003CE5 22               [24] 1016 	ret
                                   1017 ;------------------------------------------------------------
                                   1018 ;Allocation info for local variables in function 'ak820_key_override_cancel'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	keyboards/ajazz/ak820/ak820_key_override.c:49: void ak820_key_override_cancel(void) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function ak820_key_override_cancel
                                   1023 ;	-----------------------------------------
      003CE6                       1024 _ak820_key_override_cancel:
                                   1025 ;	keyboards/ajazz/ak820/ak820_key_override.c:50: source = active = NONE;
      003CE6 90 0E 40         [24] 1026 	mov	dptr,#_active
      003CE9 74 FF            [12] 1027 	mov	a,#0xff
      003CEB F0               [24] 1028 	movx	@dptr,a
      003CEC 90 0E 3F         [24] 1029 	mov	dptr,#_source
      003CEF F0               [24] 1030 	movx	@dptr,a
                                   1031 ;	keyboards/ajazz/ak820/ak820_key_override.c:51: previous_mods = 0;
      003CF0 90 05 4A         [24] 1032 	mov	dptr,#_previous_mods
      003CF3 E4               [12] 1033 	clr	a
      003CF4 F0               [24] 1034 	movx	@dptr,a
                                   1035 ;	keyboards/ajazz/ak820/ak820_key_override.c:52: blocked = hidden = false;
      003CF5 90 05 4C         [24] 1036 	mov	dptr,#_hidden
      003CF8 F0               [24] 1037 	movx	@dptr,a
      003CF9 90 05 4B         [24] 1038 	mov	dptr,#_blocked
      003CFC F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_key_override.c:53: }
      003CFD 22               [24] 1041 	ret
                                   1042 ;------------------------------------------------------------
                                   1043 ;Allocation info for local variables in function 'ak820_key_override_reload'
                                   1044 ;------------------------------------------------------------
                                   1045 ;i             Allocated with name '_ak820_key_override_reload_i_20000_619'
                                   1046 ;------------------------------------------------------------
                                   1047 ;	keyboards/ajazz/ak820/ak820_key_override.c:54: void ak820_key_override_reload(void) {
                                   1048 ;	-----------------------------------------
                                   1049 ;	 function ak820_key_override_reload
                                   1050 ;	-----------------------------------------
      003CFE                       1051 _ak820_key_override_reload:
                                   1052 ;	keyboards/ajazz/ak820/ak820_key_override.c:55: ak820_key_override_cancel();
      003CFE 12 3C E6         [24] 1053 	lcall	_ak820_key_override_cancel
                                   1054 ;	keyboards/ajazz/ak820/ak820_key_override.c:56: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003D01 7F 00            [12] 1055 	mov	r7,#0x00
      003D03                       1056 00106$:
      003D03 BF 08 00         [24] 1057 	cjne	r7,#0x08,00132$
      003D06                       1058 00132$:
      003D06 50 45            [24] 1059 	jnc	00108$
                                   1060 ;	keyboards/ajazz/ak820/ak820_key_override.c:57: if (dynamic_keymap_get_key_override(i, &entries[i]) || !ak820_key_override_valid(&entries[i]))
      003D08 12 41 51         [24] 1061 	lcall	_ak820_outline_0037
      003D0B FE               [12] 1062 	mov	r6,a
      003D0C 90 0B 85         [24] 1063 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      003D0F ED               [12] 1064 	mov	a,r5
      003D10 F0               [24] 1065 	movx	@dptr,a
      003D11 EE               [12] 1066 	mov	a,r6
      003D12 12 38 1A         [24] 1067 	lcall	_ak820_outline_0074
      003D15 8F 82            [24] 1068 	mov	dpl, r7
      003D17 C0 07            [24] 1069 	push	ar7
      003D19 C0 06            [24] 1070 	push	ar6
      003D1B C0 05            [24] 1071 	push	ar5
      003D1D 12 8C B7         [24] 1072 	lcall	_dynamic_keymap_get_key_override
      003D20 12 38 4E         [24] 1073 	lcall	_ak820_outline_0123
      003D23 D0 05            [24] 1074 	pop	ar5
      003D25 D0 06            [24] 1075 	pop	ar6
      003D27 D0 07            [24] 1076 	pop	ar7
      003D29 45 F0            [12] 1077 	orl	a,b
      003D2B 70 0E            [24] 1078 	jnz	00101$
      003D2D 12 38 5E         [24] 1079 	lcall	_ak820_outline_0138
      003D30 C0 07            [24] 1080 	push	ar7
      003D32 12 3B 3B         [24] 1081 	lcall	_ak820_key_override_valid
      003D35 E5 82            [12] 1082 	mov	a, dpl
      003D37 D0 07            [24] 1083 	pop	ar7
      003D39 70 0F            [24] 1084 	jnz	00107$
      003D3B                       1085 00101$:
                                   1086 ;	keyboards/ajazz/ak820/ak820_key_override.c:58: entries[i].options = 0;
      003D3B 12 41 51         [24] 1087 	lcall	_ak820_outline_0037
      003D3E FE               [12] 1088 	mov	r6,a
      003D3F 74 09            [12] 1089 	mov	a,#0x09
      003D41 2D               [12] 1090 	add	a, r5
      003D42 F5 82            [12] 1091 	mov	dpl,a
      003D44 E4               [12] 1092 	clr	a
      003D45 3E               [12] 1093 	addc	a, r6
      003D46 F5 83            [12] 1094 	mov	dph,a
      003D48 E4               [12] 1095 	clr	a
      003D49 F0               [24] 1096 	movx	@dptr,a
      003D4A                       1097 00107$:
                                   1098 ;	keyboards/ajazz/ak820/ak820_key_override.c:56: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003D4A 0F               [12] 1099 	inc	r7
      003D4B 80 B6            [24] 1100 	sjmp	00106$
      003D4D                       1101 00108$:
                                   1102 ;	keyboards/ajazz/ak820/ak820_key_override.c:60: }
      003D4D 22               [24] 1103 	ret
                                   1104 ;------------------------------------------------------------
                                   1105 ;Allocation info for local variables in function 'activate'
                                   1106 ;------------------------------------------------------------
                                   1107 ;sloc0         Allocated with name '_activate_sloc0_1_0'
                                   1108 ;sloc1         Allocated with name '_activate_sloc1_1_0'
                                   1109 ;sloc2         Allocated with name '_activate_sloc2_1_0'
                                   1110 ;mods          Allocated with name '_activate_PARM_2'
                                   1111 ;layer         Allocated with name '_activate_PARM_3'
                                   1112 ;reason        Allocated with name '_activate_reason_10000_622'
                                   1113 ;i             Allocated with name '_activate_i_20000_625'
                                   1114 ;e             Allocated with name '_activate_e_30000_626'
                                   1115 ;------------------------------------------------------------
                                   1116 ;	keyboards/ajazz/ak820/ak820_key_override.c:61: static void activate(uint8_t reason, uint8_t mods, uint8_t layer) {
                                   1117 ;	-----------------------------------------
                                   1118 ;	 function activate
                                   1119 ;	-----------------------------------------
      003D4E                       1120 _activate:
      003D4E E5 82            [12] 1121 	mov	a,dpl
      003D50 90 05 5A         [24] 1122 	mov	dptr,#_activate_reason_10000_622
      003D53 F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	keyboards/ajazz/ak820/ak820_key_override.c:62: if (!enabled || source == NONE || blocked || hidden || active != NONE) return;
      003D54 90 0E 41         [24] 1125 	mov	dptr,#_enabled
      003D57 E0               [24] 1126 	movx	a,@dptr
      003D58 60 1D            [24] 1127 	jz	00101$
      003D5A 90 0E 3F         [24] 1128 	mov	dptr,#_source
      003D5D E0               [24] 1129 	movx	a,@dptr
      003D5E FF               [12] 1130 	mov	r7,a
      003D5F BF FF 01         [24] 1131 	cjne	r7,#0xff,00215$
      003D62 22               [24] 1132 	ret
      003D63                       1133 00215$:
      003D63 90 05 4B         [24] 1134 	mov	dptr,#_blocked
      003D66 E0               [24] 1135 	movx	a,@dptr
      003D67 70 0E            [24] 1136 	jnz	00101$
      003D69 90 05 4C         [24] 1137 	mov	dptr,#_hidden
      003D6C E0               [24] 1138 	movx	a,@dptr
      003D6D 70 08            [24] 1139 	jnz	00101$
      003D6F 12 41 66         [24] 1140 	lcall	_ak820_outline_0125
      003D72 BF FF 02         [24] 1141 	cjne	r7,#0xff,00218$
      003D75 80 01            [24] 1142 	sjmp	00148$
      003D77                       1143 00218$:
      003D77                       1144 00101$:
      003D77 22               [24] 1145 	ret
                                   1146 ;	keyboards/ajazz/ak820/ak820_key_override.c:63: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003D78                       1147 00148$:
      003D78 90 05 58         [24] 1148 	mov	dptr,#_activate_PARM_2
      003D7B E0               [24] 1149 	movx	a,@dptr
      003D7C FF               [12] 1150 	mov	r7,a
      003D7D 8F 0C            [24] 1151 	mov	_activate_sloc1_1_0,r7
      003D7F 90 05 59         [24] 1152 	mov	dptr,#_activate_PARM_3
      003D82 E0               [24] 1153 	movx	a,@dptr
      003D83 FD               [12] 1154 	mov	r5,a
      003D84 90 05 5A         [24] 1155 	mov	dptr,#_activate_reason_10000_622
      003D87 E0               [24] 1156 	movx	a,@dptr
      003D88 FC               [12] 1157 	mov	r4,a
      003D89 74 04            [12] 1158 	mov	a,#0x04
      003D8B 5C               [12] 1159 	anl	a,r4
      003D8C F5 0D            [12] 1160 	mov	_activate_sloc2_1_0,a
      003D8E 75 0E 00         [24] 1161 	mov	(_activate_sloc2_1_0 + 1),#0x00
      003D91 79 00            [12] 1162 	mov	r1,#0x00
      003D93                       1163 00119$:
      003D93 B9 08 00         [24] 1164 	cjne	r1,#0x08,00219$
      003D96                       1165 00219$:
      003D96 40 01            [24] 1166 	jc	00220$
      003D98 22               [24] 1167 	ret
      003D99                       1168 00220$:
                                   1169 ;	keyboards/ajazz/ak820/ak820_key_override.c:64: vial_key_override_entry_t AK820_STATE_MEM *e = &entries[i];
      003D99 C0 05            [24] 1170 	push	ar5
      003D9B E9               [12] 1171 	mov	a,r1
      003D9C 12 41 88         [24] 1172 	lcall	_ak820_outline_0195
      003D9F 24 F9            [12] 1173 	add	a, #_entries
      003DA1 F5 0A            [12] 1174 	mov	_activate_sloc0_1_0,a
      003DA3 74 04            [12] 1175 	mov	a,#(_entries >> 8)
      003DA5 35 F0            [12] 1176 	addc	a, b
      003DA7 F5 0B            [12] 1177 	mov	(_activate_sloc0_1_0 + 1),a
      003DA9 90 05 5B         [24] 1178 	mov	dptr,#_activate_e_30000_626
      003DAC E5 0A            [12] 1179 	mov	a,_activate_sloc0_1_0
      003DAE F0               [24] 1180 	movx	@dptr,a
      003DAF E5 0B            [12] 1181 	mov	a,(_activate_sloc0_1_0 + 1)
      003DB1 A3               [24] 1182 	inc	dptr
      003DB2 F0               [24] 1183 	movx	@dptr,a
                                   1184 ;	keyboards/ajazz/ak820/ak820_key_override.c:65: if ((uint8_t)e->trigger == trigger && (e->options & ENABLED) && (e->options & reason) &&
      003DB3 85 0A 82         [24] 1185 	mov	dpl,_activate_sloc0_1_0
      003DB6 85 0B 83         [24] 1186 	mov	dph,(_activate_sloc0_1_0 + 1)
      003DB9 E0               [24] 1187 	movx	a,@dptr
      003DBA F8               [12] 1188 	mov	r0,a
      003DBB 90 05 49         [24] 1189 	mov	dptr,#_trigger
      003DBE E0               [24] 1190 	movx	a,@dptr
      003DBF FD               [12] 1191 	mov	r5,a
      003DC0 E8               [12] 1192 	mov	a,r0
      003DC1 B5 05 02         [24] 1193 	cjne	a,ar5,00221$
      003DC4 80 05            [24] 1194 	sjmp	00222$
      003DC6                       1195 00221$:
      003DC6 D0 05            [24] 1196 	pop	ar5
      003DC8 02 3E 78         [24] 1197 	ljmp	00120$
      003DCB                       1198 00222$:
      003DCB D0 05            [24] 1199 	pop	ar5
      003DCD 85 0A 82         [24] 1200 	mov	dpl,_activate_sloc0_1_0
      003DD0 85 0B 83         [24] 1201 	mov	dph,(_activate_sloc0_1_0 + 1)
      003DD3 A3               [24] 1202 	inc	dptr
      003DD4 A3               [24] 1203 	inc	dptr
      003DD5 A3               [24] 1204 	inc	dptr
      003DD6 A3               [24] 1205 	inc	dptr
      003DD7 12 41 77         [24] 1206 	lcall	_ak820_outline_0156
      003DDA F8               [12] 1207 	mov	r0,a
      003DDB 20 E7 03         [24] 1208 	jb	acc.7,00223$
      003DDE 02 3E 78         [24] 1209 	ljmp	00120$
      003DE1                       1210 00223$:
      003DE1 EC               [12] 1211 	mov	a,r4
      003DE2 58               [12] 1212 	anl	a,r0
      003DE3 70 03            [24] 1213 	jnz	00224$
      003DE5 02 3E 78         [24] 1214 	ljmp	00120$
      003DE8                       1215 00224$:
                                   1216 ;	keyboards/ajazz/ak820/ak820_key_override.c:66: ((reason & 1) || ((reason & 2) && (e->trigger_mods & mods & ~previous_mods)) ||
      003DE8 EC               [12] 1217 	mov	a,r4
      003DE9 20 E0 62         [24] 1218 	jb	acc.0,00116$
      003DEC EC               [12] 1219 	mov	a,r4
      003DED 30 E1 2B         [24] 1220 	jnb	acc.1,00114$
      003DF0 C0 05            [24] 1221 	push	ar5
      003DF2 85 0A 82         [24] 1222 	mov	dpl,_activate_sloc0_1_0
      003DF5 85 0B 83         [24] 1223 	mov	dph,(_activate_sloc0_1_0 + 1)
      003DF8 A3               [24] 1224 	inc	dptr
      003DF9 12 41 77         [24] 1225 	lcall	_ak820_outline_0156
      003DFC F8               [12] 1226 	mov	r0,a
      003DFD EF               [12] 1227 	mov	a,r7
      003DFE 52 00            [12] 1228 	anl	ar0,a
      003E00 90 05 4A         [24] 1229 	mov	dptr,#_previous_mods
      003E03 E0               [24] 1230 	movx	a,@dptr
      003E04 FD               [12] 1231 	mov	r5,a
      003E05 7E 00            [12] 1232 	mov	r6,#0x00
      003E07 63 05 FF         [24] 1233 	xrl	ar5,#0xff
      003E0A 63 06 FF         [24] 1234 	xrl	ar6,#0xff
      003E0D 7B 00            [12] 1235 	mov	r3,#0x00
      003E0F E8               [12] 1236 	mov	a,r0
      003E10 52 05            [12] 1237 	anl	ar5,a
      003E12 EB               [12] 1238 	mov	a,r3
      003E13 52 06            [12] 1239 	anl	ar6,a
      003E15 ED               [12] 1240 	mov	a,r5
      003E16 4E               [12] 1241 	orl	a,r6
      003E17 D0 05            [24] 1242 	pop	ar5
      003E19 70 33            [24] 1243 	jnz	00116$
      003E1B                       1244 00114$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_key_override.c:67: ((reason & 4) && (e->negative_mod_mask & previous_mods & ~mods))) && eligible(i, mods, layer)) {
      003E1B E5 0D            [12] 1246 	mov	a,_activate_sloc2_1_0
      003E1D 45 0E            [12] 1247 	orl	a,(_activate_sloc2_1_0 + 1)
      003E1F 60 57            [24] 1248 	jz	00120$
      003E21 90 05 5B         [24] 1249 	mov	dptr,#_activate_e_30000_626
      003E24 E0               [24] 1250 	movx	a,@dptr
      003E25 FB               [12] 1251 	mov	r3,a
      003E26 A3               [24] 1252 	inc	dptr
      003E27 E0               [24] 1253 	movx	a,@dptr
      003E28 FE               [12] 1254 	mov	r6,a
      003E29 74 07            [12] 1255 	mov	a,#0x07
      003E2B 2B               [12] 1256 	add	a, r3
      003E2C 12 41 5E         [24] 1257 	lcall	_ak820_outline_0079
      003E2F FE               [12] 1258 	mov	r6,a
      003E30 90 05 4A         [24] 1259 	mov	dptr,#_previous_mods
      003E33 E0               [24] 1260 	movx	a,@dptr
      003E34 52 06            [12] 1261 	anl	ar6,a
      003E36 8F 02            [24] 1262 	mov	ar2,r7
      003E38 7B 00            [12] 1263 	mov	r3,#0x00
      003E3A 63 02 FF         [24] 1264 	xrl	ar2,#0xff
      003E3D 63 03 FF         [24] 1265 	xrl	ar3,#0xff
      003E40 8E 00            [24] 1266 	mov	ar0,r6
      003E42 7E 00            [12] 1267 	mov	r6,#0x00
      003E44 E8               [12] 1268 	mov	a,r0
      003E45 52 02            [12] 1269 	anl	ar2,a
      003E47 EE               [12] 1270 	mov	a,r6
      003E48 52 03            [12] 1271 	anl	ar3,a
      003E4A EA               [12] 1272 	mov	a,r2
      003E4B 4B               [12] 1273 	orl	a,r3
      003E4C 60 2A            [24] 1274 	jz	00120$
      003E4E                       1275 00116$:
      003E4E 90 05 55         [24] 1276 	mov	dptr,#_eligible_PARM_2
      003E51 E5 0C            [12] 1277 	mov	a,_activate_sloc1_1_0
      003E53 F0               [24] 1278 	movx	@dptr,a
      003E54 90 05 56         [24] 1279 	mov	dptr,#_eligible_PARM_3
      003E57 ED               [12] 1280 	mov	a,r5
      003E58 F0               [24] 1281 	movx	@dptr,a
      003E59 89 82            [24] 1282 	mov	dpl, r1
      003E5B C0 07            [24] 1283 	push	ar7
      003E5D C0 05            [24] 1284 	push	ar5
      003E5F C0 04            [24] 1285 	push	ar4
      003E61 C0 01            [24] 1286 	push	ar1
      003E63 12 3C 52         [24] 1287 	lcall	_eligible
      003E66 E5 82            [12] 1288 	mov	a, dpl
      003E68 D0 01            [24] 1289 	pop	ar1
      003E6A D0 04            [24] 1290 	pop	ar4
      003E6C D0 05            [24] 1291 	pop	ar5
      003E6E D0 07            [24] 1292 	pop	ar7
      003E70 60 06            [24] 1293 	jz	00120$
                                   1294 ;	keyboards/ajazz/ak820/ak820_key_override.c:68: active = i;
      003E72 90 0E 40         [24] 1295 	mov	dptr,#_active
      003E75 E9               [12] 1296 	mov	a,r1
      003E76 F0               [24] 1297 	movx	@dptr,a
                                   1298 ;	keyboards/ajazz/ak820/ak820_key_override.c:69: return;
      003E77 22               [24] 1299 	ret
      003E78                       1300 00120$:
                                   1301 ;	keyboards/ajazz/ak820/ak820_key_override.c:63: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003E78 09               [12] 1302 	inc	r1
                                   1303 ;	keyboards/ajazz/ak820/ak820_key_override.c:72: }
      003E79 02 3D 93         [24] 1304 	ljmp	00119$
                                   1305 ;------------------------------------------------------------
                                   1306 ;Allocation info for local variables in function 'ak820_key_override_sync'
                                   1307 ;------------------------------------------------------------
                                   1308 ;layer         Allocated with name '_ak820_key_override_sync_PARM_2'
                                   1309 ;mods          Allocated with name '_ak820_key_override_sync_mods_10000_629'
                                   1310 ;reason        Allocated with name '_ak820_key_override_sync_reason_10000_630'
                                   1311 ;------------------------------------------------------------
                                   1312 ;	keyboards/ajazz/ak820/ak820_key_override.c:73: void ak820_key_override_sync(uint8_t mods, uint8_t layer) {
                                   1313 ;	-----------------------------------------
                                   1314 ;	 function ak820_key_override_sync
                                   1315 ;	-----------------------------------------
      003E7C                       1316 _ak820_key_override_sync:
      003E7C E5 82            [12] 1317 	mov	a,dpl
      003E7E 90 05 5E         [24] 1318 	mov	dptr,#_ak820_key_override_sync_mods_10000_629
      003E81 F0               [24] 1319 	movx	@dptr,a
                                   1320 ;	keyboards/ajazz/ak820/ak820_key_override.c:74: uint8_t reason = 0;
      003E82 90 05 5F         [24] 1321 	mov	dptr,#_ak820_key_override_sync_reason_10000_630
      003E85 E4               [12] 1322 	clr	a
      003E86 F0               [24] 1323 	movx	@dptr,a
                                   1324 ;	keyboards/ajazz/ak820/ak820_key_override.c:75: if (active != NONE && !eligible(active, mods, layer)) deactivate();
      003E87 12 41 66         [24] 1325 	lcall	_ak820_outline_0125
      003E8A BF FF 02         [24] 1326 	cjne	r7,#0xff,00138$
      003E8D 80 18            [24] 1327 	sjmp	00102$
      003E8F                       1328 00138$:
      003E8F 12 41 6C         [24] 1329 	lcall	_ak820_outline_0135
      003E92 90 05 55         [24] 1330 	mov	dptr,#_eligible_PARM_2
      003E95 EE               [12] 1331 	mov	a,r6
      003E96 F0               [24] 1332 	movx	@dptr,a
      003E97 90 05 56         [24] 1333 	mov	dptr,#_eligible_PARM_3
      003E9A 12 41 83         [24] 1334 	lcall	_ak820_outline_0194
      003E9D 12 3C 52         [24] 1335 	lcall	_eligible
      003EA0 E5 82            [12] 1336 	mov	a, dpl
      003EA2 70 03            [24] 1337 	jnz	00102$
      003EA4 12 3C C5         [24] 1338 	lcall	_deactivate
      003EA7                       1339 00102$:
                                   1340 ;	keyboards/ajazz/ak820/ak820_key_override.c:76: if (mods & ~previous_mods) reason |= 2;
      003EA7 90 05 4A         [24] 1341 	mov	dptr,#_previous_mods
      003EAA E0               [24] 1342 	movx	a,@dptr
      003EAB FE               [12] 1343 	mov	r6,a
      003EAC 7F 00            [12] 1344 	mov	r7,#0x00
      003EAE 74 FF            [12] 1345 	mov	a,#0xff
      003EB0 6E               [12] 1346 	xrl	a,r6
      003EB1 FC               [12] 1347 	mov	r4,a
      003EB2 74 FF            [12] 1348 	mov	a,#0xff
      003EB4 6F               [12] 1349 	xrl	a,r7
      003EB5 FD               [12] 1350 	mov	r5,a
      003EB6 90 05 5E         [24] 1351 	mov	dptr,#_ak820_key_override_sync_mods_10000_629
      003EB9 E0               [24] 1352 	movx	a,@dptr
      003EBA FA               [12] 1353 	mov	r2,a
      003EBB 7B 00            [12] 1354 	mov	r3,#0x00
      003EBD 52 04            [12] 1355 	anl	ar4,a
      003EBF EB               [12] 1356 	mov	a,r3
      003EC0 52 05            [12] 1357 	anl	ar5,a
      003EC2 EC               [12] 1358 	mov	a,r4
      003EC3 4D               [12] 1359 	orl	a,r5
      003EC4 60 06            [24] 1360 	jz	00105$
      003EC6 90 05 5F         [24] 1361 	mov	dptr,#_ak820_key_override_sync_reason_10000_630
      003EC9 74 02            [12] 1362 	mov	a,#0x02
      003ECB F0               [24] 1363 	movx	@dptr,a
      003ECC                       1364 00105$:
                                   1365 ;	keyboards/ajazz/ak820/ak820_key_override.c:77: if (previous_mods & ~mods) reason |= 4;
      003ECC 63 02 FF         [24] 1366 	xrl	ar2,#0xff
      003ECF 63 03 FF         [24] 1367 	xrl	ar3,#0xff
      003ED2 EA               [12] 1368 	mov	a,r2
      003ED3 52 06            [12] 1369 	anl	ar6,a
      003ED5 EB               [12] 1370 	mov	a,r3
      003ED6 52 07            [12] 1371 	anl	ar7,a
      003ED8 EE               [12] 1372 	mov	a,r6
      003ED9 4F               [12] 1373 	orl	a,r7
      003EDA 60 08            [24] 1374 	jz	00107$
      003EDC 90 05 5F         [24] 1375 	mov	dptr,#_ak820_key_override_sync_reason_10000_630
      003EDF E0               [24] 1376 	movx	a,@dptr
      003EE0 43 E0 04         [24] 1377 	orl	acc,#0x04
      003EE3 F0               [24] 1378 	movx	@dptr,a
      003EE4                       1379 00107$:
                                   1380 ;	keyboards/ajazz/ak820/ak820_key_override.c:78: activate(reason, mods, layer);
      003EE4 90 05 5F         [24] 1381 	mov	dptr,#_ak820_key_override_sync_reason_10000_630
      003EE7 E0               [24] 1382 	movx	a,@dptr
      003EE8 FF               [12] 1383 	mov	r7,a
      003EE9 12 41 6C         [24] 1384 	lcall	_ak820_outline_0135
      003EEC 90 05 58         [24] 1385 	mov	dptr,#_activate_PARM_2
      003EEF EE               [12] 1386 	mov	a,r6
      003EF0 F0               [24] 1387 	movx	@dptr,a
      003EF1 90 05 59         [24] 1388 	mov	dptr,#_activate_PARM_3
      003EF4 12 41 83         [24] 1389 	lcall	_ak820_outline_0194
      003EF7 C0 06            [24] 1390 	push	ar6
      003EF9 12 3D 4E         [24] 1391 	lcall	_activate
      003EFC D0 06            [24] 1392 	pop	ar6
                                   1393 ;	keyboards/ajazz/ak820/ak820_key_override.c:79: previous_mods = mods;
      003EFE 90 05 4A         [24] 1394 	mov	dptr,#_previous_mods
      003F01 EE               [12] 1395 	mov	a,r6
      003F02 F0               [24] 1396 	movx	@dptr,a
                                   1397 ;	keyboards/ajazz/ak820/ak820_key_override.c:80: }
      003F03 22               [24] 1398 	ret
                                   1399 ;------------------------------------------------------------
                                   1400 ;Allocation info for local variables in function 'ak820_key_override_process'
                                   1401 ;------------------------------------------------------------
                                   1402 ;sloc0         Allocated with name '_ak820_key_override_process_sloc0_1_0'
                                   1403 ;sloc1         Allocated with name '_ak820_key_override_process_sloc1_1_0'
                                   1404 ;sloc2         Allocated with name '_ak820_key_override_process_sloc2_1_0'
                                   1405 ;mods          Allocated with name '_ak820_key_override_process_PARM_2'
                                   1406 ;layer         Allocated with name '_ak820_key_override_process_PARM_3'
                                   1407 ;record        Allocated with name '_ak820_key_override_process_record_10000_634'
                                   1408 ;key           Allocated with name '_ak820_key_override_process_key_10000_635'
                                   1409 ;id            Allocated with name '_ak820_key_override_process_id_10000_635'
                                   1410 ;i             Allocated with name '_ak820_key_override_process_i_20000_652'
                                   1411 ;------------------------------------------------------------
                                   1412 ;	keyboards/ajazz/ak820/ak820_key_override.c:81: bool ak820_key_override_process(keyrecord_t AK820_STATE_MEM *record, uint8_t mods, uint8_t layer) {
                                   1413 ;	-----------------------------------------
                                   1414 ;	 function ak820_key_override_process
                                   1415 ;	-----------------------------------------
      003F04                       1416 _ak820_key_override_process:
      003F04 12 38 44         [24] 1417 	lcall	_ak820_outline_0109
      003F07 90 05 62         [24] 1418 	mov	dptr,#_ak820_key_override_process_record_10000_634
      003F0A 12 38 49         [24] 1419 	lcall	_ak820_outline_0110
                                   1420 ;	keyboards/ajazz/ak820/ak820_key_override.c:82: uint16_t key = record->keycode;
      003F0D 90 05 62         [24] 1421 	mov	dptr,#_ak820_key_override_process_record_10000_634
      003F10 12 37 9D         [24] 1422 	lcall	_ak820_outline_0001
                                   1423 ;	keyboards/ajazz/ak820/ak820_key_override.c:84: ak820_key_override_sync(mods, layer);
      003F13 90 05 60         [24] 1424 	mov	dptr,#_ak820_key_override_process_PARM_2
      003F16 E0               [24] 1425 	movx	a,@dptr
      003F17 FB               [12] 1426 	mov	r3,a
      003F18 90 05 61         [24] 1427 	mov	dptr,#_ak820_key_override_process_PARM_3
      003F1B E0               [24] 1428 	movx	a,@dptr
      003F1C FA               [12] 1429 	mov	r2,a
      003F1D 90 05 5D         [24] 1430 	mov	dptr,#_ak820_key_override_sync_PARM_2
      003F20 F0               [24] 1431 	movx	@dptr,a
      003F21 8B 82            [24] 1432 	mov	dpl, r3
      003F23 C0 07            [24] 1433 	push	ar7
      003F25 C0 06            [24] 1434 	push	ar6
      003F27 C0 05            [24] 1435 	push	ar5
      003F29 C0 04            [24] 1436 	push	ar4
      003F2B C0 03            [24] 1437 	push	ar3
      003F2D C0 02            [24] 1438 	push	ar2
      003F2F 12 3E 7C         [24] 1439 	lcall	_ak820_key_override_sync
      003F32 D0 02            [24] 1440 	pop	ar2
      003F34 D0 03            [24] 1441 	pop	ar3
      003F36 D0 04            [24] 1442 	pop	ar4
      003F38 D0 05            [24] 1443 	pop	ar5
      003F3A D0 06            [24] 1444 	pop	ar6
      003F3C D0 07            [24] 1445 	pop	ar7
                                   1446 ;	keyboards/ajazz/ak820/ak820_key_override.c:85: if (key >= QK_KEY_OVERRIDE_TOGGLE && key <= QK_KEY_OVERRIDE_OFF) {
      003F3E 8C 00            [24] 1447 	mov	ar0,r4
      003F40 8D 01            [24] 1448 	mov	ar1,r5
      003F42 C3               [12] 1449 	clr	c
      003F43 E8               [12] 1450 	mov	a,r0
      003F44 94 5D            [12] 1451 	subb	a,#0x5d
      003F46 E9               [12] 1452 	mov	a,r1
      003F47 94 7C            [12] 1453 	subb	a,#0x7c
      003F49 40 45            [24] 1454 	jc	00112$
      003F4B 74 5F            [12] 1455 	mov	a,#0x5f
      003F4D 98               [12] 1456 	subb	a,r0
      003F4E 74 7C            [12] 1457 	mov	a,#0x7c
      003F50 99               [12] 1458 	subb	a,r1
      003F51 40 3D            [24] 1459 	jc	00112$
                                   1460 ;	free result
                                   1461 ;	keyboards/ajazz/ak820/ak820_key_override.c:86: if (record->event.pressed) {
      003F53 12 37 B1         [24] 1462 	lcall	_ak820_outline_0006
      003F56 60 34            [24] 1463 	jz	00110$
                                   1464 ;	keyboards/ajazz/ak820/ak820_key_override.c:87: if (key == QK_KEY_OVERRIDE_ON) enabled = true;
      003F58 B8 5E 0B         [24] 1465 	cjne	r0,#0x5e,00105$
      003F5B B9 7C 08         [24] 1466 	cjne	r1,#0x7c,00105$
      003F5E 90 0E 41         [24] 1467 	mov	dptr,#_enabled
      003F61 74 01            [12] 1468 	mov	a,#0x01
      003F63 F0               [24] 1469 	movx	@dptr,a
      003F64 80 17            [24] 1470 	sjmp	00106$
      003F66                       1471 00105$:
                                   1472 ;	keyboards/ajazz/ak820/ak820_key_override.c:88: else if (key == QK_KEY_OVERRIDE_OFF) enabled = false;
      003F66 B8 5F 0A         [24] 1473 	cjne	r0,#0x5f,00102$
      003F69 B9 7C 07         [24] 1474 	cjne	r1,#0x7c,00102$
      003F6C 90 0E 41         [24] 1475 	mov	dptr,#_enabled
      003F6F E4               [12] 1476 	clr	a
      003F70 F0               [24] 1477 	movx	@dptr,a
      003F71 80 0A            [24] 1478 	sjmp	00106$
      003F73                       1479 00102$:
                                   1480 ;	keyboards/ajazz/ak820/ak820_key_override.c:89: else enabled = !enabled;
      003F73 90 0E 41         [24] 1481 	mov	dptr,#_enabled
      003F76 E0               [24] 1482 	movx	a,@dptr
      003F77 B4 01 00         [24] 1483 	cjne	a,#0x01,00289$
      003F7A                       1484 00289$:
      003F7A E4               [12] 1485 	clr	a
      003F7B 33               [12] 1486 	rlc	a
      003F7C F0               [24] 1487 	movx	@dptr,a
      003F7D                       1488 00106$:
                                   1489 ;	keyboards/ajazz/ak820/ak820_key_override.c:90: if (!enabled) { deactivate(); blocked = true; }
      003F7D 90 0E 41         [24] 1490 	mov	dptr,#_enabled
      003F80 E0               [24] 1491 	movx	a,@dptr
      003F81 70 09            [24] 1492 	jnz	00110$
      003F83 12 3C C5         [24] 1493 	lcall	_deactivate
      003F86 90 05 4B         [24] 1494 	mov	dptr,#_blocked
      003F89 74 01            [12] 1495 	mov	a,#0x01
      003F8B F0               [24] 1496 	movx	@dptr,a
      003F8C                       1497 00110$:
                                   1498 ;	keyboards/ajazz/ak820/ak820_key_override.c:92: return false;
      003F8C 75 82 00         [24] 1499 	mov	dpl, #0x00
      003F8F 22               [24] 1500 	ret
      003F90                       1501 00112$:
                                   1502 ;	keyboards/ajazz/ak820/ak820_key_override.c:94: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) return true;
      003F90 90 05 62         [24] 1503 	mov	dptr,#_ak820_key_override_process_record_10000_634
      003F93 E0               [24] 1504 	movx	a,@dptr
      003F94 F5 11            [12] 1505 	mov	_ak820_key_override_process_sloc2_1_0,a
      003F96 A3               [24] 1506 	inc	dptr
      003F97 E0               [24] 1507 	movx	a,@dptr
      003F98 F5 12            [12] 1508 	mov	(_ak820_key_override_process_sloc2_1_0 + 1),a
      003F9A 85 11 82         [24] 1509 	mov	dpl,_ak820_key_override_process_sloc2_1_0
      003F9D 85 12 83         [24] 1510 	mov	dph,(_ak820_key_override_process_sloc2_1_0 + 1)
      003FA0 A3               [24] 1511 	inc	dptr
      003FA1 E0               [24] 1512 	movx	a,@dptr
      003FA2 F5 0F            [12] 1513 	mov	_ak820_key_override_process_sloc0_1_0,a
      003FA4 C3               [12] 1514 	clr	c
      003FA5 94 10            [12] 1515 	subb	a,#0x10
      003FA7 50 0E            [24] 1516 	jnc	00114$
      003FA9 85 11 82         [24] 1517 	mov	dpl,_ak820_key_override_process_sloc2_1_0
      003FAC 85 12 83         [24] 1518 	mov	dph,(_ak820_key_override_process_sloc2_1_0 + 1)
      003FAF E0               [24] 1519 	movx	a,@dptr
      003FB0 F5 10            [12] 1520 	mov	_ak820_key_override_process_sloc1_1_0,a
      003FB2 C3               [12] 1521 	clr	c
      003FB3 94 08            [12] 1522 	subb	a,#0x08
      003FB5 40 04            [24] 1523 	jc	00115$
      003FB7                       1524 00114$:
      003FB7 75 82 01         [24] 1525 	mov	dpl, #0x01
      003FBA 22               [24] 1526 	ret
      003FBB                       1527 00115$:
                                   1528 ;	keyboards/ajazz/ak820/ak820_key_override.c:95: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003FBB C0 02            [24] 1529 	push	ar2
      003FBD E5 0F            [12] 1530 	mov	a,_ak820_key_override_process_sloc0_1_0
      003FBF 12 38 7E         [24] 1531 	lcall	_ak820_outline_0193
      003FC2 F5 0F            [12] 1532 	mov	_ak820_key_override_process_sloc0_1_0,a
      003FC4 25 10            [12] 1533 	add	a,_ak820_key_override_process_sloc1_1_0
      003FC6 F5 10            [12] 1534 	mov	_ak820_key_override_process_sloc1_1_0,a
                                   1535 ;	keyboards/ajazz/ak820/ak820_key_override.c:96: if (source == id) {
      003FC8 90 0E 3F         [24] 1536 	mov	dptr,#_source
      003FCB E0               [24] 1537 	movx	a,@dptr
      003FCC B5 10 02         [24] 1538 	cjne	a,_ak820_key_override_process_sloc1_1_0,00293$
      003FCF 80 04            [24] 1539 	sjmp	00294$
      003FD1                       1540 00293$:
      003FD1 D0 02            [24] 1541 	pop	ar2
      003FD3 80 17            [24] 1542 	sjmp	00120$
      003FD5                       1543 00294$:
      003FD5 D0 02            [24] 1544 	pop	ar2
                                   1545 ;	keyboards/ajazz/ak820/ak820_key_override.c:97: if (!record->event.pressed) ak820_key_override_cancel();
      003FD7 74 05            [12] 1546 	mov	a,#0x05
      003FD9 25 11            [12] 1547 	add	a, _ak820_key_override_process_sloc2_1_0
      003FDB FE               [12] 1548 	mov	r6,a
      003FDC E4               [12] 1549 	clr	a
      003FDD 35 12            [12] 1550 	addc	a, (_ak820_key_override_process_sloc2_1_0 + 1)
      003FDF FF               [12] 1551 	mov	r7,a
      003FE0 12 38 32         [24] 1552 	lcall	_ak820_outline_0098
      003FE3 70 03            [24] 1553 	jnz	00118$
      003FE5 12 3C E6         [24] 1554 	lcall	_ak820_key_override_cancel
      003FE8                       1555 00118$:
                                   1556 ;	keyboards/ajazz/ak820/ak820_key_override.c:98: return false;
      003FE8 75 82 00         [24] 1557 	mov	dpl, #0x00
      003FEB 22               [24] 1558 	ret
      003FEC                       1559 00120$:
                                   1560 ;	keyboards/ajazz/ak820/ak820_key_override.c:100: if (!record->event.pressed) return true;
      003FEC 74 05            [12] 1561 	mov	a,#0x05
      003FEE 25 11            [12] 1562 	add	a, _ak820_key_override_process_sloc2_1_0
      003FF0 FE               [12] 1563 	mov	r6,a
      003FF1 E4               [12] 1564 	clr	a
      003FF2 35 12            [12] 1565 	addc	a, (_ak820_key_override_process_sloc2_1_0 + 1)
      003FF4 FF               [12] 1566 	mov	r7,a
      003FF5 12 38 32         [24] 1567 	lcall	_ak820_outline_0098
      003FF8 70 04            [24] 1568 	jnz	00122$
      003FFA 75 82 01         [24] 1569 	mov	dpl, #0x01
      003FFD 22               [24] 1570 	ret
      003FFE                       1571 00122$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_key_override.c:101: if (active != NONE && !(entries[active].options & 32) && !(key >= KC_LEFT_CTRL && key <= KC_RIGHT_GUI)) {
      003FFE 12 41 66         [24] 1573 	lcall	_ak820_outline_0125
      004001 BF FF 02         [24] 1574 	cjne	r7,#0xff,00297$
      004004 80 3D            [24] 1575 	sjmp	00124$
      004006                       1576 00297$:
      004006 EF               [12] 1577 	mov	a,r7
      004007 12 41 3A         [24] 1578 	lcall	_ak820_outline_0017
      00400A 74 09            [12] 1579 	mov	a,#0x09
      00400C 12 37 D2         [24] 1580 	lcall	_ak820_outline_0013
      00400F 20 E5 31         [24] 1581 	jb	acc.5,00124$
      004012 C3               [12] 1582 	clr	c
      004013 E8               [12] 1583 	mov	a,r0
      004014 94 E0            [12] 1584 	subb	a,#0xe0
      004016 E9               [12] 1585 	mov	a,r1
      004017 94 00            [12] 1586 	subb	a,#0x00
      004019 40 07            [24] 1587 	jc	00123$
      00401B 74 E7            [12] 1588 	mov	a,#0xe7
      00401D 98               [12] 1589 	subb	a,r0
      00401E E4               [12] 1590 	clr	a
      00401F 99               [12] 1591 	subb	a,r1
      004020 50 21            [24] 1592 	jnc	00124$
                                   1593 ;	free result
      004022                       1594 00123$:
                                   1595 ;	keyboards/ajazz/ak820/ak820_key_override.c:102: deactivate(); blocked = true;
      004022 C0 05            [24] 1596 	push	ar5
      004024 C0 04            [24] 1597 	push	ar4
      004026 C0 03            [24] 1598 	push	ar3
      004028 C0 02            [24] 1599 	push	ar2
      00402A C0 01            [24] 1600 	push	ar1
      00402C C0 00            [24] 1601 	push	ar0
      00402E 12 3C C5         [24] 1602 	lcall	_deactivate
      004031 D0 00            [24] 1603 	pop	ar0
      004033 D0 01            [24] 1604 	pop	ar1
      004035 D0 02            [24] 1605 	pop	ar2
      004037 D0 03            [24] 1606 	pop	ar3
      004039 D0 04            [24] 1607 	pop	ar4
      00403B D0 05            [24] 1608 	pop	ar5
      00403D 90 05 4B         [24] 1609 	mov	dptr,#_blocked
      004040 74 01            [12] 1610 	mov	a,#0x01
      004042 F0               [24] 1611 	movx	@dptr,a
      004043                       1612 00124$:
                                   1613 ;	keyboards/ajazz/ak820/ak820_key_override.c:104: if (source != NONE || !enabled || !basic(key)) return true;
      004043 90 0E 3F         [24] 1614 	mov	dptr,#_source
      004046 E0               [24] 1615 	movx	a,@dptr
      004047 FF               [12] 1616 	mov	r7,a
      004048 BF FF 16         [24] 1617 	cjne	r7,#0xff,00128$
      00404B 90 0E 41         [24] 1618 	mov	dptr,#_enabled
      00404E E0               [24] 1619 	movx	a,@dptr
      00404F 60 10            [24] 1620 	jz	00128$
      004051 C3               [12] 1621 	clr	c
      004052 E8               [12] 1622 	mov	a,r0
      004053 94 04            [12] 1623 	subb	a,#0x04
      004055 E9               [12] 1624 	mov	a,r1
      004056 94 00            [12] 1625 	subb	a,#0x00
      004058 40 07            [24] 1626 	jc	00128$
      00405A 74 A4            [12] 1627 	mov	a,#0xa4
      00405C 98               [12] 1628 	subb	a,r0
      00405D E4               [12] 1629 	clr	a
      00405E 99               [12] 1630 	subb	a,r1
      00405F 50 04            [24] 1631 	jnc	00181$
                                   1632 ;	free result
      004061                       1633 00128$:
      004061 75 82 01         [24] 1634 	mov	dpl, #0x01
                                   1635 ;	keyboards/ajazz/ak820/ak820_key_override.c:105: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      004064 22               [24] 1636 	ret
      004065                       1637 00181$:
      004065 7F 00            [12] 1638 	mov	r7,#0x00
      004067                       1639 00138$:
      004067 BF 08 00         [24] 1640 	cjne	r7,#0x08,00306$
      00406A                       1641 00306$:
      00406A 50 4B            [24] 1642 	jnc	00136$
                                   1643 ;	keyboards/ajazz/ak820/ak820_key_override.c:106: if ((uint8_t)entries[i].trigger == (uint8_t)key && (entries[i].options & ENABLED)) {
      00406C EF               [12] 1644 	mov	a,r7
      00406D 12 41 88         [24] 1645 	lcall	_ak820_outline_0195
      004070 24 F9            [12] 1646 	add	a, #_entries
      004072 F9               [12] 1647 	mov	r1,a
      004073 74 04            [12] 1648 	mov	a,#(_entries >> 8)
      004075 35 F0            [12] 1649 	addc	a, b
      004077 FE               [12] 1650 	mov	r6,a
      004078 89 82            [24] 1651 	mov	dpl,r1
      00407A 8E 83            [24] 1652 	mov	dph,r6
      00407C E0               [24] 1653 	movx	a,@dptr
      00407D 8C 11            [24] 1654 	mov	_ak820_key_override_process_sloc2_1_0,r4
      00407F B5 11 32         [24] 1655 	cjne	a,_ak820_key_override_process_sloc2_1_0,00139$
      004082 74 09            [12] 1656 	mov	a,#0x09
      004084 29               [12] 1657 	add	a, r1
      004085 12 41 5E         [24] 1658 	lcall	_ak820_outline_0079
      004088 30 E7 29         [24] 1659 	jnb	acc.7,00139$
                                   1660 ;	keyboards/ajazz/ak820/ak820_key_override.c:107: source = id; trigger = key; hidden = blocked = false;
      00408B 90 0E 3F         [24] 1661 	mov	dptr,#_source
      00408E E5 10            [12] 1662 	mov	a,_ak820_key_override_process_sloc1_1_0
      004090 F0               [24] 1663 	movx	@dptr,a
      004091 90 05 49         [24] 1664 	mov	dptr,#_trigger
      004094 E5 11            [12] 1665 	mov	a,_ak820_key_override_process_sloc2_1_0
      004096 F0               [24] 1666 	movx	@dptr,a
      004097 90 05 4B         [24] 1667 	mov	dptr,#_blocked
      00409A E4               [12] 1668 	clr	a
      00409B F0               [24] 1669 	movx	@dptr,a
      00409C 90 05 4C         [24] 1670 	mov	dptr,#_hidden
      00409F F0               [24] 1671 	movx	@dptr,a
                                   1672 ;	keyboards/ajazz/ak820/ak820_key_override.c:108: activate(1, mods, layer);
      0040A0 90 05 58         [24] 1673 	mov	dptr,#_activate_PARM_2
      0040A3 EB               [12] 1674 	mov	a,r3
      0040A4 F0               [24] 1675 	movx	@dptr,a
      0040A5 90 05 59         [24] 1676 	mov	dptr,#_activate_PARM_3
      0040A8 EA               [12] 1677 	mov	a,r2
      0040A9 F0               [24] 1678 	movx	@dptr,a
      0040AA 75 82 01         [24] 1679 	mov	dpl, #0x01
      0040AD 12 3D 4E         [24] 1680 	lcall	_activate
                                   1681 ;	keyboards/ajazz/ak820/ak820_key_override.c:109: return false;
      0040B0 75 82 00         [24] 1682 	mov	dpl, #0x00
      0040B3 22               [24] 1683 	ret
      0040B4                       1684 00139$:
                                   1685 ;	keyboards/ajazz/ak820/ak820_key_override.c:105: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      0040B4 0F               [12] 1686 	inc	r7
      0040B5 80 B0            [24] 1687 	sjmp	00138$
      0040B7                       1688 00136$:
                                   1689 ;	keyboards/ajazz/ak820/ak820_key_override.c:112: return true;
      0040B7 75 82 01         [24] 1690 	mov	dpl, #0x01
                                   1691 ;	keyboards/ajazz/ak820/ak820_key_override.c:113: }
      0040BA 22               [24] 1692 	ret
                                   1693 ;------------------------------------------------------------
                                   1694 ;Allocation info for local variables in function 'ak820_key_override_key'
                                   1695 ;------------------------------------------------------------
                                   1696 ;	keyboards/ajazz/ak820/ak820_key_override.c:114: uint8_t ak820_key_override_key(void) {
                                   1697 ;	-----------------------------------------
                                   1698 ;	 function ak820_key_override_key
                                   1699 ;	-----------------------------------------
      0040BB                       1700 _ak820_key_override_key:
                                   1701 ;	keyboards/ajazz/ak820/ak820_key_override.c:115: if (source == NONE || hidden) return 0;
      0040BB 90 0E 3F         [24] 1702 	mov	dptr,#_source
      0040BE E0               [24] 1703 	movx	a,@dptr
      0040BF FF               [12] 1704 	mov	r7,a
      0040C0 BF FF 02         [24] 1705 	cjne	r7,#0xff,00122$
      0040C3 80 06            [24] 1706 	sjmp	00101$
      0040C5                       1707 00122$:
      0040C5 90 05 4C         [24] 1708 	mov	dptr,#_hidden
      0040C8 E0               [24] 1709 	movx	a,@dptr
      0040C9 60 04            [24] 1710 	jz	00102$
      0040CB                       1711 00101$:
      0040CB 75 82 00         [24] 1712 	mov	dpl, #0x00
      0040CE 22               [24] 1713 	ret
      0040CF                       1714 00102$:
                                   1715 ;	keyboards/ajazz/ak820/ak820_key_override.c:116: return active == NONE ? trigger : (uint8_t)entries[active].replacement;
      0040CF 12 41 66         [24] 1716 	lcall	_ak820_outline_0125
      0040D2 BF FF 07         [24] 1717 	cjne	r7,#0xff,00106$
      0040D5 90 05 49         [24] 1718 	mov	dptr,#_trigger
      0040D8 E0               [24] 1719 	movx	a,@dptr
      0040D9 FE               [12] 1720 	mov	r6,a
      0040DA 80 0B            [24] 1721 	sjmp	00107$
      0040DC                       1722 00106$:
      0040DC 12 41 51         [24] 1723 	lcall	_ak820_outline_0037
      0040DF FF               [12] 1724 	mov	r7,a
      0040E0 12 41 7E         [24] 1725 	lcall	_ak820_outline_0190
      0040E3 A3               [24] 1726 	inc	dptr
      0040E4 A3               [24] 1727 	inc	dptr
      0040E5 E0               [24] 1728 	movx	a,@dptr
      0040E6 FE               [12] 1729 	mov	r6,a
      0040E7                       1730 00107$:
      0040E7 8E 82            [24] 1731 	mov	dpl, r6
                                   1732 ;	keyboards/ajazz/ak820/ak820_key_override.c:117: }
      0040E9 22               [24] 1733 	ret
                                   1734 ;------------------------------------------------------------
                                   1735 ;Allocation info for local variables in function 'ak820_key_override_mods'
                                   1736 ;------------------------------------------------------------
                                   1737 ;mods          Allocated with name '_ak820_key_override_mods_mods_10000_659'
                                   1738 ;------------------------------------------------------------
                                   1739 ;	keyboards/ajazz/ak820/ak820_key_override.c:118: uint8_t ak820_key_override_mods(uint8_t mods) {
                                   1740 ;	-----------------------------------------
                                   1741 ;	 function ak820_key_override_mods
                                   1742 ;	-----------------------------------------
      0040EA                       1743 _ak820_key_override_mods:
      0040EA E5 82            [12] 1744 	mov	a,dpl
      0040EC 90 05 64         [24] 1745 	mov	dptr,#_ak820_key_override_mods_mods_10000_659
      0040EF F0               [24] 1746 	movx	@dptr,a
                                   1747 ;	keyboards/ajazz/ak820/ak820_key_override.c:119: if (active == NONE) return mods;
      0040F0 12 41 66         [24] 1748 	lcall	_ak820_outline_0125
      0040F3 BF FF 07         [24] 1749 	cjne	r7,#0xff,00102$
      0040F6 90 05 64         [24] 1750 	mov	dptr,#_ak820_key_override_mods_mods_10000_659
      0040F9 E0               [24] 1751 	movx	a,@dptr
      0040FA F5 82            [12] 1752 	mov	dpl,a
      0040FC 22               [24] 1753 	ret
      0040FD                       1754 00102$:
                                   1755 ;	keyboards/ajazz/ak820/ak820_key_override.c:120: return (mods & ~entries[active].suppressed_mods) | replacement_mods(entries[active].replacement);
      0040FD EF               [12] 1756 	mov	a,r7
      0040FE 12 41 3A         [24] 1757 	lcall	_ak820_outline_0017
      004101 74 08            [12] 1758 	mov	a,#0x08
      004103 12 37 D2         [24] 1759 	lcall	_ak820_outline_0013
      004106 FD               [12] 1760 	mov	r5,a
      004107 63 05 FF         [24] 1761 	xrl	ar5,#0xff
      00410A 90 05 64         [24] 1762 	mov	dptr,#_ak820_key_override_mods_mods_10000_659
      00410D E0               [24] 1763 	movx	a,@dptr
      00410E 52 05            [12] 1764 	anl	ar5,a
      004110 12 38 38         [24] 1765 	lcall	_ak820_outline_0103
      004113 A3               [24] 1766 	inc	dptr
      004114 12 37 BE         [24] 1767 	lcall	_ak820_outline_0007
      004117 C0 05            [24] 1768 	push	ar5
      004119 12 3B D8         [24] 1769 	lcall	_replacement_mods
      00411C AF 82            [24] 1770 	mov	r7, dpl
      00411E D0 05            [24] 1771 	pop	ar5
      004120 EF               [12] 1772 	mov	a,r7
      004121 42 05            [12] 1773 	orl	ar5,a
      004123 8D 82            [24] 1774 	mov	dpl, r5
                                   1775 ;	keyboards/ajazz/ak820/ak820_key_override.c:121: }
      004125 22               [24] 1776 	ret
                                   1777 ;------------------------------------------------------------
                                   1778 ;Allocation info for local variables in function 'ak820_key_override_enabled'
                                   1779 ;------------------------------------------------------------
                                   1780 ;	keyboards/ajazz/ak820/ak820_key_override.c:122: bool ak820_key_override_enabled(void) { return enabled; }
                                   1781 ;	-----------------------------------------
                                   1782 	.area CSEG    (CODE)
                                   1783 	.area CONST   (CODE)
                                   1784 	.area XINIT   (CODE)
      00C803                       1785 __xinit__source:
      00C803 FF                    1786 	.db #0xff	; 255
      00C804                       1787 __xinit__active:
      00C804 FF                    1788 	.db #0xff	; 255
      00C805                       1789 __xinit__enabled:
      00C805 01                    1790 	.db #0x01	;  1
                                   1791 	.area CABS    (ABS,CODE)
                                   1792 
                                   1793 ; Experimental exact instruction outlining.
                                   1794 	.globl _ak820_outline_0001
                                   1795 	.globl _ak820_outline_0006
                                   1796 	.globl _ak820_outline_0007
                                   1797 	.globl _ak820_outline_0012
                                   1798 	.globl _ak820_outline_0013
                                   1799 	.globl _ak820_outline_0016
                                   1800 	.globl _ak820_outline_0017
                                   1801 	.globl _ak820_outline_0018
                                   1802 	.globl _ak820_outline_0034
                                   1803 	.globl _ak820_outline_0037
                                   1804 	.globl _ak820_outline_0056
                                   1805 	.globl _ak820_outline_0074
                                   1806 	.globl _ak820_outline_0079
                                   1807 	.globl _ak820_outline_0098
                                   1808 	.globl _ak820_outline_0103
                                   1809 	.globl _ak820_outline_0109
                                   1810 	.globl _ak820_outline_0110
                                   1811 	.globl _ak820_outline_0123
                                   1812 	.globl _ak820_outline_0125
                                   1813 	.globl _ak820_outline_0135
                                   1814 	.globl _ak820_outline_0138
                                   1815 	.globl _ak820_outline_0149
                                   1816 	.globl _ak820_outline_0156
                                   1817 	.globl _ak820_outline_0190
                                   1818 	.globl _ak820_outline_0193
                                   1819 	.globl _ak820_outline_0194
                                   1820 	.globl _ak820_outline_0195
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0012
      004126                       1824 _ak820_outline_0012:
      004126 2E               [12] 1825 	add	a,r6
      004127 FC               [12] 1826 	mov	r4,a
      004128 E4               [12] 1827 	clr	a
      004129 3F               [12] 1828 	addc	a,r7
      00412A FD               [12] 1829 	mov	r5,a
      00412B 8C 82            [24] 1830 	mov	dpl,r4
      00412D 8D 83            [24] 1831 	mov	dph,r5
      00412F E0               [24] 1832 	movx	a,@dptr
      004130 22               [24] 1833 	ret
                                   1834 
                                   1835 	.area CSEG (CODE)
                                   1836 ; function ak820_outline_0016
      004131                       1837 _ak820_outline_0016:
      004131 8E 82            [24] 1838 	mov	dpl,r6
      004133 8F 83            [24] 1839 	mov	dph,r7
      004135 A3               [24] 1840 	inc	dptr
      004136 A3               [24] 1841 	inc	dptr
      004137 A3               [24] 1842 	inc	dptr
      004138 E0               [24] 1843 	movx	a,@dptr
      004139 22               [24] 1844 	ret
                                   1845 
                                   1846 	.area CSEG (CODE)
                                   1847 ; function ak820_outline_0017
      00413A                       1848 _ak820_outline_0017:
      00413A 75 F0 0A         [24] 1849 	mov	b,#0x0a
      00413D A4               [48] 1850 	mul	ab
      00413E 24 F9            [12] 1851 	add	a,#_entries
      004140 FE               [12] 1852 	mov	r6,a
      004141 74 04            [12] 1853 	mov	a,#(_entries>>8)
      004143 35 F0            [12] 1854 	addc	a,b
      004145 FF               [12] 1855 	mov	r7,a
      004146 22               [24] 1856 	ret
                                   1857 
                                   1858 	.area CSEG (CODE)
                                   1859 ; function ak820_outline_0018
      004147                       1860 _ak820_outline_0018:
      004147 8E 82            [24] 1861 	mov	dpl,r6
      004149 8F 83            [24] 1862 	mov	dph,r7
      00414B A3               [24] 1863 	inc	dptr
      00414C A3               [24] 1864 	inc	dptr
      00414D A3               [24] 1865 	inc	dptr
      00414E A3               [24] 1866 	inc	dptr
      00414F E0               [24] 1867 	movx	a,@dptr
      004150 22               [24] 1868 	ret
                                   1869 
                                   1870 	.area CSEG (CODE)
                                   1871 ; function ak820_outline_0037
      004151                       1872 _ak820_outline_0037:
      004151 EF               [12] 1873 	mov	a,r7
      004152 75 F0 0A         [24] 1874 	mov	b,#0x0a
      004155 A4               [48] 1875 	mul	ab
      004156 24 F9            [12] 1876 	add	a,#_entries
      004158 FD               [12] 1877 	mov	r5,a
      004159 74 04            [12] 1878 	mov	a,#(_entries>>8)
      00415B 35 F0            [12] 1879 	addc	a,b
      00415D 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0079
      00415E                       1884 _ak820_outline_0079:
      00415E F5 82            [12] 1885 	mov	dpl,a
      004160 E4               [12] 1886 	clr	a
      004161 3E               [12] 1887 	addc	a,r6
      004162 F5 83            [12] 1888 	mov	dph,a
      004164 E0               [24] 1889 	movx	a,@dptr
      004165 22               [24] 1890 	ret
                                   1891 
                                   1892 	.area CSEG (CODE)
                                   1893 ; function ak820_outline_0125
      004166                       1894 _ak820_outline_0125:
      004166 90 0E 40         [24] 1895 	mov	dptr,#_active
      004169 E0               [24] 1896 	movx	a,@dptr
      00416A FF               [12] 1897 	mov	r7,a
      00416B 22               [24] 1898 	ret
                                   1899 
                                   1900 	.area CSEG (CODE)
                                   1901 ; function ak820_outline_0135
      00416C                       1902 _ak820_outline_0135:
      00416C 90 05 5E         [24] 1903 	mov	dptr,#_ak820_key_override_sync_mods_10000_629
      00416F E0               [24] 1904 	movx	a,@dptr
      004170 FE               [12] 1905 	mov	r6,a
      004171 90 05 5D         [24] 1906 	mov	dptr,#_ak820_key_override_sync_PARM_2
      004174 E0               [24] 1907 	movx	a,@dptr
      004175 FD               [12] 1908 	mov	r5,a
      004176 22               [24] 1909 	ret
                                   1910 
                                   1911 	.area CSEG (CODE)
                                   1912 ; function ak820_outline_0156
      004177                       1913 _ak820_outline_0156:
      004177 A3               [24] 1914 	inc	dptr
      004178 A3               [24] 1915 	inc	dptr
      004179 A3               [24] 1916 	inc	dptr
      00417A A3               [24] 1917 	inc	dptr
      00417B A3               [24] 1918 	inc	dptr
      00417C E0               [24] 1919 	movx	a,@dptr
      00417D 22               [24] 1920 	ret
                                   1921 
                                   1922 	.area CSEG (CODE)
                                   1923 ; function ak820_outline_0190
      00417E                       1924 _ak820_outline_0190:
      00417E 8D 82            [24] 1925 	mov	dpl,r5
      004180 8F 83            [24] 1926 	mov	dph,r7
      004182 22               [24] 1927 	ret
                                   1928 
                                   1929 	.area CSEG (CODE)
                                   1930 ; function ak820_outline_0194
      004183                       1931 _ak820_outline_0194:
      004183 ED               [12] 1932 	mov	a,r5
      004184 F0               [24] 1933 	movx	@dptr,a
      004185 8F 82            [24] 1934 	mov	dpl,r7
      004187 22               [24] 1935 	ret
                                   1936 
                                   1937 	.area CSEG (CODE)
                                   1938 ; function ak820_outline_0195
      004188                       1939 _ak820_outline_0195:
      004188 75 F0 0A         [24] 1940 	mov	b,#0x0a
      00418B A4               [48] 1941 	mul	ab
      00418C 22               [24] 1942 	ret
