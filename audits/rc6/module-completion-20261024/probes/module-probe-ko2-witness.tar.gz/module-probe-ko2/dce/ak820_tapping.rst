                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000F                        552 _ak820_tapping_before_sloc0_1_0:
      00000F                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      000606                        562 _source_state:
      000606                        563 	.ds 130
      000688                        564 _pending_time:
      000688                        565 	.ds 2
      00068A                        566 _pending_code:
      00068A                        567 	.ds 2
      00068C                        568 _ak820_tapping_source_PARM_1:
      00068C                        569 	.ds 2
      00068E                        570 _hold_PARM_2:
      00068E                        571 	.ds 1
      00068F                        572 _hold_code_10000_603:
      00068F                        573 	.ds 2
      000691                        574 _hold_mods_30000_606:
      000691                        575 	.ds 1
      000692                        576 _commit_pending_id_10000_612:
      000692                        577 	.ds 1
      000693                        578 _ak820_tapping_before_event_10000_613:
      000693                        579 	.ds 2
      000695                        580 _ak820_tapping_process_record_10000_624:
      000695                        581 	.ds 2
      000697                        582 _ak820_tapping_process_code_10000_625:
      000697                        583 	.ds 2
      000699                        584 _ak820_tapping_process_sc_mods_10000_625:
      000699                        585 	.ds 1
      00069A                        586 _ak820_oneshot_mods::
      00069A                        587 	.ds 1
      00069B                        588 _ak820_oneshot_consumed::
      00069B                        589 	.ds 1
      00069C                        590 _ak820_oneshot_process_PARM_2:
      00069C                        591 	.ds 1
      00069D                        592 _ak820_oneshot_process_PARM_3:
      00069D                        593 	.ds 1
      00069E                        594 _ak820_oneshot_process_code_10000_650:
      00069E                        595 	.ds 2
      0006A0                        596 _ak820_oneshot_process_mods_10000_651:
      0006A0                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E42                        606 _pending:
      000E42                        607 	.ds 1
      000E43                        608 _ak820_oneshot_target::
      000E43                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0049A4                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0049A4 90 06 8D         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0049A7 E0               [24]  656 	movx	a,@dptr
      0049A8 FF               [12]  657 	mov	r7,a
      0049A9 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0049AC                        659 00147$:
      0049AC 50 14            [24]  660 	jnc	00102$
      0049AE 90 06 8C         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0049B1 E0               [24]  662 	movx	a,@dptr
      0049B2 FE               [12]  663 	mov	r6,a
      0049B3 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0049B6                        665 00149$:
      0049B6 50 0A            [24]  666 	jnc	00102$
      0049B8 8F 05            [24]  667 	mov	ar5,r7
      0049BA ED               [12]  668 	mov	a,r5
      0049BB 12 38 7E         [24]  669 	lcall	_ak820_outline_0193
      0049BE 2E               [12]  670 	add	a,r6
      0049BF F5 82            [12]  671 	mov	dpl,a
      0049C1 22               [24]  672 	ret
      0049C2                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0049C2 90 06 8C         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0049C5 E0               [24]  676 	movx	a,@dptr
      0049C6 FE               [12]  677 	mov	r6,a
      0049C7 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0049CA                        679 00151$:
      0049CA 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0049CC BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0049CF 75 82 80         [24]  683 	mov	dpl, #0x80
      0049D2 22               [24]  684 	ret
      0049D3                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0049D3 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0049D6 75 82 81         [24]  688 	mov	dpl, #0x81
      0049D9 22               [24]  689 	ret
      0049DA                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0049DA 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      0049DD 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0049DE                        707 _hold:
      0049DE 12 38 44         [24]  708 	lcall	_ak820_outline_0109
      0049E1 90 06 8F         [24]  709 	mov	dptr,#_hold_code_10000_603
      0049E4 12 38 49         [24]  710 	lcall	_ak820_outline_0110
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      0049E7 90 06 8F         [24]  712 	mov	dptr,#_hold_code_10000_603
      0049EA 12 37 C8         [24]  713 	lcall	_ak820_outline_0009
      0049ED 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0049EF 2D               [12]  715 	add	a,r5
      0049F0 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0049F2 8F 05            [24]  718 	mov	ar5,r7
      0049F4 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0049F7 90 06 91         [24]  720 	mov	dptr,#_hold_mods_30000_606
      0049FA ED               [12]  721 	mov	a,r5
      0049FB F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0049FC ED               [12]  724 	mov	a,r5
      0049FD 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004A00 ED               [12]  726 	mov	a,r5
      004A01 C4               [12]  727 	swap	a
      004A02 54 F0            [12]  728 	anl	a,#0xf0
      004A04 90 06 91         [24]  729 	mov	dptr,#_hold_mods_30000_606
      004A07 F0               [24]  730 	movx	@dptr,a
      004A08                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004A08 90 06 8E         [24]  733 	mov	dptr,#_hold_PARM_2
      004A0B E0               [24]  734 	movx	a,@dptr
      004A0C 60 09            [24]  735 	jz	00104$
      004A0E 90 06 91         [24]  736 	mov	dptr,#_hold_mods_30000_606
      004A11 E0               [24]  737 	movx	a,@dptr
      004A12 F5 82            [12]  738 	mov	dpl,a
      004A14 02 7B 6D         [24]  739 	ljmp	_register_mods
      004A17                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004A17 90 06 91         [24]  742 	mov	dptr,#_hold_mods_30000_606
      004A1A E0               [24]  743 	movx	a,@dptr
      004A1B F5 82            [12]  744 	mov	dpl,a
      004A1D 02 7B 81         [24]  745 	ljmp	_unregister_mods
      004A20                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004A20 8F 06            [24]  748 	mov	ar6,r7
      004A22 74 0F            [12]  749 	mov	a,#0x0f
      004A24 5E               [12]  750 	anl	a,r6
      004A25 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004A26 90 06 8E         [24]  753 	mov	dptr,#_hold_PARM_2
      004A29 E0               [24]  754 	movx	a,@dptr
      004A2A 60 05            [24]  755 	jz	00107$
      004A2C 8F 82            [24]  756 	mov	dpl, r7
      004A2E 02 7D 2C         [24]  757 	ljmp	_layer_hold_on
      004A31                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004A31 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004A33 02 7D 63         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004A36                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004A36 90 0E 42         [24]  774 	mov	dptr,#_pending
      004A39 E0               [24]  775 	movx	a,@dptr
      004A3A 90 06 92         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      004A3D F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004A3E 12 4E 90         [24]  779 	lcall	_ak820_outline_0161
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004A41 90 06 92         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      004A44 E0               [24]  782 	movx	a,@dptr
      004A45 24 06            [12]  783 	add	a,#_source_state
      004A47 FF               [12]  784 	mov	r7,a
      004A48 E4               [12]  785 	clr	a
      004A49 34 06            [12]  786 	addc	a, #(_source_state >> 8)
      004A4B FE               [12]  787 	mov	r6,a
      004A4C 12 49 8E         [24]  788 	lcall	_ak820_outline_0164
      004A4F E0               [24]  789 	movx	a,@dptr
      004A50 FD               [12]  790 	mov	r5,a
      004A51 43 05 04         [24]  791 	orl	ar5,#0x04
      004A54 12 49 8E         [24]  792 	lcall	_ak820_outline_0164
      004A57 ED               [12]  793 	mov	a,r5
      004A58 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004A59 90 06 8A         [24]  796 	mov	dptr,#_pending_code
      004A5C 12 37 FD         [24]  797 	lcall	_ak820_outline_0056
      004A5F 90 06 8E         [24]  798 	mov	dptr,#_hold_PARM_2
      004A62 74 01            [12]  799 	mov	a,#0x01
      004A64 12 49 3E         [24]  800 	lcall	_ak820_outline_0063
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004A67 21 DE            [12]  802 	ajmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      004A69                        813 _ak820_tapping_before:
      004A69 12 38 44         [24]  814 	lcall	_ak820_outline_0109
      004A6C 90 06 93         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004A6F 12 38 49         [24]  816 	lcall	_ak820_outline_0110
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004A72 90 06 93         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004A75 12 37 C8         [24]  819 	lcall	_ak820_outline_0009
      004A78 12 4E 50         [24]  820 	lcall	_ak820_outline_0024
      004A7B C0 07            [24]  821 	push	ar7
      004A7D C0 06            [24]  822 	push	ar6
      004A7F 12 BF 43         [24]  823 	lcall	___memcpy
      004A82 31 A4            [12]  824 	acall	_ak820_tapping_source
      004A84 AD 82            [24]  825 	mov	r5, dpl
      004A86 D0 06            [24]  826 	pop	ar6
      004A88 D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004A8A 90 0E B3         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      004A8D E0               [24]  830 	movx	a,@dptr
      004A8E 60 29            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004A90 74 04            [12]  833 	mov	a,#0x04
      004A92 12 4E 36         [24]  834 	lcall	_ak820_outline_0015
      004A95 60 1E            [24]  835 	jz	00102$
      004A97 BD FF 02         [24]  836 	cjne	r5,#0xff,00218$
      004A9A 80 19            [24]  837 	sjmp	00102$
      004A9C                        838 00218$:
      004A9C 74 05            [12]  839 	mov	a,#0x05
      004A9E 12 4E 36         [24]  840 	lcall	_ak820_outline_0015
      004AA1 70 12            [24]  841 	jnz	00102$
      004AA3 ED               [12]  842 	mov	a,r5
      004AA4 24 06            [12]  843 	add	a, #_source_state
      004AA6 FB               [12]  844 	mov	r3,a
      004AA7 E4               [12]  845 	clr	a
      004AA8 34 06            [12]  846 	addc	a, #(_source_state >> 8)
      004AAA 12 4E 75         [24]  847 	lcall	_ak820_outline_0060
      004AAD 53 02 FD         [24]  848 	anl	ar2,#0xfd
      004AB0 12 33 FC         [24]  849 	lcall	_ak820_outline_0127
      004AB3 EA               [12]  850 	mov	a,r2
      004AB4 F0               [24]  851 	movx	@dptr,a
      004AB5                        852 00102$:
                                    853 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004AB5 75 82 00         [24]  854 	mov	dpl, #0x00
      004AB8 22               [24]  855 	ret
      004AB9                        856 00106$:
                                    857 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004AB9 90 0E 42         [24]  858 	mov	dptr,#_pending
      004ABC E0               [24]  859 	movx	a,@dptr
      004ABD FC               [12]  860 	mov	r4,a
      004ABE BC FF 02         [24]  861 	cjne	r4,#0xff,00220$
      004AC1 80 3A            [24]  862 	sjmp	00108$
      004AC3                        863 00220$:
      004AC3 12 37 F5         [24]  864 	lcall	_ak820_outline_0034
      004AC6 FA               [12]  865 	mov	r2,a
      004AC7 A3               [24]  866 	inc	dptr
      004AC8 E0               [24]  867 	movx	a,@dptr
      004AC9 FB               [12]  868 	mov	r3,a
      004ACA 90 06 88         [24]  869 	mov	dptr,#_pending_time
      004ACD 12 38 3E         [24]  870 	lcall	_ak820_outline_0105
      004AD0 EA               [12]  871 	mov	a,r2
      004AD1 C3               [12]  872 	clr	c
      004AD2 98               [12]  873 	subb	a,r0
      004AD3 FA               [12]  874 	mov	r2,a
      004AD4 EB               [12]  875 	mov	a,r3
      004AD5 99               [12]  876 	subb	a,r1
      004AD6 FB               [12]  877 	mov	r3,a
      004AD7 C3               [12]  878 	clr	c
      004AD8 EA               [12]  879 	mov	a,r2
      004AD9 94 C8            [12]  880 	subb	a,#0xc8
      004ADB EB               [12]  881 	mov	a,r3
      004ADC 94 00            [12]  882 	subb	a,#0x00
      004ADE 50 17            [24]  883 	jnc	00107$
                                    884 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004AE0 74 04            [12]  885 	mov	a,#0x04
      004AE2 12 4E 6A         [24]  886 	lcall	_ak820_outline_0051
      004AE5 60 16            [24]  887 	jz	00108$
      004AE7 12 37 B1         [24]  888 	lcall	_ak820_outline_0006
      004AEA 60 11            [24]  889 	jz	00108$
      004AEC BD FF 02         [24]  890 	cjne	r5,#0xff,00224$
      004AEF 80 06            [24]  891 	sjmp	00107$
      004AF1                        892 00224$:
      004AF1 ED               [12]  893 	mov	a,r5
      004AF2 B5 04 02         [24]  894 	cjne	a,ar4,00225$
      004AF5 80 06            [24]  895 	sjmp	00108$
      004AF7                        896 00225$:
      004AF7                        897 00107$:
      004AF7 C0 05            [24]  898 	push	ar5
      004AF9 51 36            [12]  899 	acall	_commit_pending
      004AFB D0 05            [24]  900 	pop	ar5
      004AFD                        901 00108$:
                                    902 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004AFD 90 06 93         [24]  903 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004B00 12 37 FD         [24]  904 	lcall	_ak820_outline_0056
      004B03 74 04            [12]  905 	mov	a,#0x04
      004B05 12 4E 36         [24]  906 	lcall	_ak820_outline_0015
      004B08 60 03            [24]  907 	jz	00114$
      004B0A BD FF 04         [24]  908 	cjne	r5,#0xff,00115$
      004B0D                        909 00114$:
      004B0D 75 82 01         [24]  910 	mov	dpl, #0x01
      004B10 22               [24]  911 	ret
      004B11                        912 00115$:
                                    913 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004B11 ED               [12]  914 	mov	a,r5
      004B12 24 06            [12]  915 	add	a, #_source_state
      004B14 FC               [12]  916 	mov	r4,a
      004B15 E4               [12]  917 	clr	a
      004B16 34 06            [12]  918 	addc	a, #(_source_state >> 8)
      004B18 FD               [12]  919 	mov	r5,a
      004B19 12 49 4B         [24]  920 	lcall	_ak820_outline_0080
      004B1C FB               [12]  921 	mov	r3,a
      004B1D 30 E1 12         [24]  922 	jnb	acc.1,00120$
                                    923 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004B20 74 05            [12]  924 	mov	a,#0x05
      004B22 2E               [12]  925 	add	a, r6
      004B23 12 37 DB         [24]  926 	lcall	_ak820_outline_0019
      004B26 70 06            [24]  927 	jnz	00118$
      004B28 74 FD            [12]  928 	mov	a,#0xfd
      004B2A 5B               [12]  929 	anl	a,r3
      004B2B 12 49 62         [24]  930 	lcall	_ak820_outline_0124
      004B2E                        931 00118$:
                                    932 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004B2E 75 82 00         [24]  933 	mov	dpl, #0x00
      004B31 22               [24]  934 	ret
      004B32                        935 00120$:
                                    936 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004B32 12 49 08         [24]  937 	lcall	_ak820_outline_0011
      004B35 E0               [24]  938 	movx	a,@dptr
      004B36 FF               [12]  939 	mov	r7,a
      004B37 8B 06            [24]  940 	mov	ar6,r3
      004B39 53 06 01         [24]  941 	anl	ar6,#0x01
      004B3C EE               [12]  942 	mov	a,r6
      004B3D B4 01 00         [24]  943 	cjne	a,#0x01,00231$
      004B40                        944 00231$:
      004B40 B3               [12]  945 	cpl	c
      004B41 92 0F            [24]  946 	mov	_ak820_tapping_before_sloc0_1_0,c
      004B43 8F F0            [24]  947 	mov	b,r7
      004B45 E4               [12]  948 	clr	a
      004B46 33               [12]  949 	rlc	a
      004B47 B5 F0 04         [24]  950 	cjne	a,b,00122$
      004B4A 75 82 00         [24]  951 	mov	dpl, #0x00
      004B4D 22               [24]  952 	ret
      004B4E                        953 00122$:
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004B4E 63 03 01         [24]  955 	xrl	ar3,#0x01
      004B51 12 38 54         [24]  956 	lcall	_ak820_outline_0128
      004B54 EB               [12]  957 	mov	a,r3
      004B55 F0               [24]  958 	movx	@dptr,a
                                    959 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004B56 75 82 01         [24]  960 	mov	dpl, #0x01
                                    961 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004B59 22               [24]  962 	ret
                                    963 ;------------------------------------------------------------
                                    964 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    965 ;------------------------------------------------------------
                                    966 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    967 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    968 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    969 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    970 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    971 ;------------------------------------------------------------
                                    972 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    973 ;	-----------------------------------------
                                    974 ;	 function ak820_tapping_process
                                    975 ;	-----------------------------------------
      004B5A                        976 _ak820_tapping_process:
      004B5A 12 38 44         [24]  977 	lcall	_ak820_outline_0109
      004B5D 90 06 95         [24]  978 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B60 12 38 49         [24]  979 	lcall	_ak820_outline_0110
                                    980 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004B63 90 06 99         [24]  981 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B66 E4               [12]  982 	clr	a
      004B67 F0               [24]  983 	movx	@dptr,a
                                    984 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004B68 90 06 95         [24]  985 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B6B 12 37 FD         [24]  986 	lcall	_ak820_outline_0056
      004B6E 74 04            [12]  987 	mov	a,#0x04
      004B70 12 41 26         [24]  988 	lcall	_ak820_outline_0012
      004B73 70 04            [24]  989 	jnz	00102$
      004B75 75 82 01         [24]  990 	mov	dpl, #0x01
      004B78 22               [24]  991 	ret
      004B79                        992 00102$:
                                    993 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004B79 8E 04            [24]  994 	mov	ar4,r6
      004B7B 8F 05            [24]  995 	mov	ar5,r7
      004B7D 12 4E 50         [24]  996 	lcall	_ak820_outline_0024
      004B80 C0 07            [24]  997 	push	ar7
      004B82 C0 06            [24]  998 	push	ar6
      004B84 12 BF 43         [24]  999 	lcall	___memcpy
      004B87 31 A4            [12] 1000 	acall	_ak820_tapping_source
      004B89 AD 82            [24] 1001 	mov	r5, dpl
      004B8B D0 06            [24] 1002 	pop	ar6
      004B8D D0 07            [24] 1003 	pop	ar7
                                   1004 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004B8F BD FF 04         [24] 1005 	cjne	r5,#0xff,00104$
      004B92 75 82 01         [24] 1006 	mov	dpl, #0x01
      004B95 22               [24] 1007 	ret
      004B96                       1008 00104$:
                                   1009 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004B96 74 07            [12] 1010 	mov	a,#0x07
      004B98 12 37 D2         [24] 1011 	lcall	_ak820_outline_0013
      004B9B FE               [12] 1012 	mov	r6,a
      004B9C A3               [24] 1013 	inc	dptr
      004B9D E0               [24] 1014 	movx	a,@dptr
      004B9E FF               [12] 1015 	mov	r7,a
      004B9F 90 06 97         [24] 1016 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BA2 12 4E 7D         [24] 1017 	lcall	_ak820_outline_0064
                                   1018 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004BA5 BE 1A 15         [24] 1019 	cjne	r6,#0x1a,00111$
      004BA8 BF 7C 12         [24] 1020 	cjne	r7,#0x7c,00111$
      004BAB 90 06 97         [24] 1021 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BAE 74 26            [12] 1022 	mov	a,#0x26
      004BB0 F0               [24] 1023 	movx	@dptr,a
      004BB1 74 22            [12] 1024 	mov	a,#0x22
      004BB3 A3               [24] 1025 	inc	dptr
      004BB4 F0               [24] 1026 	movx	@dptr,a
      004BB5 90 06 99         [24] 1027 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004BB8 74 02            [12] 1028 	mov	a,#0x02
      004BBA F0               [24] 1029 	movx	@dptr,a
      004BBB 80 28            [24] 1030 	sjmp	00112$
      004BBD                       1031 00111$:
                                   1032 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004BBD BE 1B 15         [24] 1033 	cjne	r6,#0x1b,00108$
      004BC0 BF 7C 12         [24] 1034 	cjne	r7,#0x7c,00108$
      004BC3 90 06 97         [24] 1035 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BC6 74 27            [12] 1036 	mov	a,#0x27
      004BC8 F0               [24] 1037 	movx	@dptr,a
      004BC9 74 32            [12] 1038 	mov	a,#0x32
      004BCB A3               [24] 1039 	inc	dptr
      004BCC F0               [24] 1040 	movx	@dptr,a
      004BCD 90 06 99         [24] 1041 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004BD0 74 20            [12] 1042 	mov	a,#0x20
      004BD2 F0               [24] 1043 	movx	@dptr,a
      004BD3 80 10            [24] 1044 	sjmp	00112$
      004BD5                       1045 00108$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004BD5 BE 1E 0D         [24] 1047 	cjne	r6,#0x1e,00112$
      004BD8 BF 7C 0A         [24] 1048 	cjne	r7,#0x7c,00112$
      004BDB 90 06 97         [24] 1049 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BDE 74 28            [12] 1050 	mov	a,#0x28
      004BE0 F0               [24] 1051 	movx	@dptr,a
      004BE1 74 32            [12] 1052 	mov	a,#0x32
      004BE3 A3               [24] 1053 	inc	dptr
      004BE4 F0               [24] 1054 	movx	@dptr,a
      004BE5                       1055 00112$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004BE5 90 06 97         [24] 1057 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BE8 E0               [24] 1058 	movx	a,@dptr
      004BE9 A3               [24] 1059 	inc	dptr
      004BEA E0               [24] 1060 	movx	a,@dptr
      004BEB FF               [12] 1061 	mov	r7,a
                                   1062 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004BEC BF 20 00         [24] 1063 	cjne	r7,#0x20,00242$
      004BEF                       1064 00242$:
      004BEF 40 05            [24] 1065 	jc	00113$
      004BF1 BF 50 00         [24] 1066 	cjne	r7,#0x50,00244$
      004BF4                       1067 00244$:
      004BF4 40 04            [24] 1068 	jc	00114$
      004BF6                       1069 00113$:
      004BF6 75 82 01         [24] 1070 	mov	dpl, #0x01
      004BF9 22               [24] 1071 	ret
      004BFA                       1072 00114$:
                                   1073 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004BFA BF 40 00         [24] 1074 	cjne	r7,#0x40,00246$
      004BFD                       1075 00246$:
      004BFD 40 0C            [24] 1076 	jc	00117$
      004BFF 53 07 0F         [24] 1077 	anl	ar7,#0x0f
      004C02 BF 06 00         [24] 1078 	cjne	r7,#0x06,00248$
      004C05                       1079 00248$:
      004C05 40 04            [24] 1080 	jc	00117$
      004C07 75 82 00         [24] 1081 	mov	dpl, #0x00
      004C0A 22               [24] 1082 	ret
      004C0B                       1083 00117$:
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004C0B 90 06 95         [24] 1085 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004C0E 12 37 FD         [24] 1086 	lcall	_ak820_outline_0056
      004C11 74 05            [12] 1087 	mov	a,#0x05
      004C13 12 4E 36         [24] 1088 	lcall	_ak820_outline_0015
      004C16 60 1E            [24] 1089 	jz	00131$
                                   1090 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004C18 90 0E 42         [24] 1091 	mov	dptr,#_pending
      004C1B ED               [12] 1092 	mov	a,r5
      004C1C 12 49 12         [24] 1093 	lcall	_ak820_outline_0025
                                   1094 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004C1F 12 37 FD         [24] 1095 	lcall	_ak820_outline_0056
      004C22 90 06 88         [24] 1096 	mov	dptr,#_pending_time
      004C25 12 4E 7D         [24] 1097 	lcall	_ak820_outline_0064
                                   1098 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004C28 90 06 97         [24] 1099 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C2B 12 37 FD         [24] 1100 	lcall	_ak820_outline_0056
      004C2E 90 06 8A         [24] 1101 	mov	dptr,#_pending_code
      004C31 12 4E 7D         [24] 1102 	lcall	_ak820_outline_0064
      004C34 81 D1            [12] 1103 	ajmp	00132$
      004C36                       1104 00131$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004C36 90 0E 42         [24] 1106 	mov	dptr,#_pending
      004C39 E0               [24] 1107 	movx	a,@dptr
      004C3A FF               [12] 1108 	mov	r7,a
      004C3B ED               [12] 1109 	mov	a,r5
      004C3C B5 07 02         [24] 1110 	cjne	a,ar7,00251$
      004C3F 80 02            [24] 1111 	sjmp	00252$
      004C41                       1112 00251$:
      004C41 81 AB            [12] 1113 	ajmp	00128$
      004C43                       1114 00252$:
                                   1115 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004C43 12 4E 90         [24] 1116 	lcall	_ak820_outline_0161
                                   1117 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004C46 90 06 99         [24] 1118 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004C49 E0               [24] 1119 	movx	a,@dptr
      004C4A FF               [12] 1120 	mov	r7,a
      004C4B E0               [24] 1121 	movx	a,@dptr
      004C4C 60 05            [24] 1122 	jz	00120$
      004C4E 8F 82            [24] 1123 	mov	dpl, r7
      004C50 12 81 A0         [24] 1124 	lcall	_add_owned_mods
      004C53                       1125 00120$:
                                   1126 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004C53 90 06 95         [24] 1127 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004C56 12 37 FD         [24] 1128 	lcall	_ak820_outline_0056
      004C59 74 07            [12] 1129 	mov	a,#0x07
      004C5B 2E               [12] 1130 	add	a, r6
      004C5C FB               [12] 1131 	mov	r3,a
      004C5D E4               [12] 1132 	clr	a
      004C5E 3F               [12] 1133 	addc	a, r7
      004C5F FC               [12] 1134 	mov	r4,a
      004C60 90 06 97         [24] 1135 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C63 E0               [24] 1136 	movx	a,@dptr
      004C64 F9               [12] 1137 	mov	r1,a
      004C65 7A 00            [12] 1138 	mov	r2,#0x00
      004C67 12 33 FC         [24] 1139 	lcall	_ak820_outline_0127
      004C6A 12 4E 8A         [24] 1140 	lcall	_ak820_outline_0142
                                   1141 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004C6D C3               [12] 1142 	clr	c
      004C6E 04               [12] 1143 	inc	a
      004C6F 99               [12] 1144 	subb	a,r1
      004C70 50 27            [24] 1145 	jnc	00122$
                                   1146 ;	free result
                                   1147 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004C72 74 06            [12] 1148 	mov	a,#0x06
      004C74 12 37 D2         [24] 1149 	lcall	_ak820_outline_0013
      004C77 54 0F            [12] 1150 	anl	a,#0x0f
      004C79 44 10            [12] 1151 	orl	a,#0x10
      004C7B F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004C7C 12 49 08         [24] 1154 	lcall	_ak820_outline_0011
      004C7F 74 01            [12] 1155 	mov	a,#0x01
      004C81 12 49 3E         [24] 1156 	lcall	_ak820_outline_0063
                                   1157 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004C84 12 76 47         [24] 1158 	lcall	_process_record
                                   1159 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004C87 90 06 95         [24] 1160 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004C8A 12 37 BE         [24] 1161 	lcall	_ak820_outline_0007
      004C8D A3               [24] 1162 	inc	dptr
      004C8E A3               [24] 1163 	inc	dptr
      004C8F A3               [24] 1164 	inc	dptr
      004C90 A3               [24] 1165 	inc	dptr
      004C91 A3               [24] 1166 	inc	dptr
      004C92 E4               [12] 1167 	clr	a
      004C93 12 49 3E         [24] 1168 	lcall	_ak820_outline_0063
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004C96 12 76 47         [24] 1170 	lcall	_process_record
      004C99                       1171 00122$:
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004C99 90 06 99         [24] 1173 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004C9C E0               [24] 1174 	movx	a,@dptr
      004C9D FF               [12] 1175 	mov	r7,a
      004C9E E0               [24] 1176 	movx	a,@dptr
      004C9F 60 30            [24] 1177 	jz	00132$
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004CA1 8F 82            [24] 1179 	mov	dpl, r7
      004CA3 12 81 AF         [24] 1180 	lcall	_del_owned_mods
                                   1181 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004CA6 12 84 D2         [24] 1182 	lcall	_send_keyboard_report
      004CA9 80 26            [24] 1183 	sjmp	00132$
      004CAB                       1184 00128$:
                                   1185 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004CAB ED               [12] 1186 	mov	a,r5
      004CAC 24 06            [12] 1187 	add	a, #_source_state
      004CAE FE               [12] 1188 	mov	r6,a
      004CAF E4               [12] 1189 	clr	a
      004CB0 34 06            [12] 1190 	addc	a, #(_source_state >> 8)
      004CB2 FF               [12] 1191 	mov	r7,a
      004CB3 12 38 32         [24] 1192 	lcall	_ak820_outline_0098
      004CB6 FD               [12] 1193 	mov	r5,a
      004CB7 30 E2 17         [24] 1194 	jnb	acc.2,00132$
                                   1195 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004CBA 53 05 FB         [24] 1196 	anl	ar5,#0xfb
      004CBD 12 49 5D         [24] 1197 	lcall	_ak820_outline_0120
      004CC0 ED               [12] 1198 	mov	a,r5
      004CC1 F0               [24] 1199 	movx	@dptr,a
                                   1200 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004CC2 90 06 97         [24] 1201 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004CC5 12 37 FD         [24] 1202 	lcall	_ak820_outline_0056
      004CC8 90 06 8E         [24] 1203 	mov	dptr,#_hold_PARM_2
      004CCB E4               [12] 1204 	clr	a
      004CCC 12 49 3E         [24] 1205 	lcall	_ak820_outline_0063
      004CCF 31 DE            [12] 1206 	acall	_hold
      004CD1                       1207 00132$:
                                   1208 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004CD1 75 82 00         [24] 1209 	mov	dpl, #0x00
                                   1210 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004CD4 22               [24] 1211 	ret
                                   1212 ;------------------------------------------------------------
                                   1213 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1214 ;------------------------------------------------------------
                                   1215 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1216 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1217 ;------------------------------------------------------------
                                   1218 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1219 ;	-----------------------------------------
                                   1220 ;	 function ak820_tapping_cancel
                                   1221 ;	-----------------------------------------
      004CD5                       1222 _ak820_tapping_cancel:
                                   1223 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004CD5 12 4E 90         [24] 1224 	lcall	_ak820_outline_0161
                                   1225 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004CD8 7F 00            [12] 1226 	mov	r7,#0x00
      004CDA                       1227 00103$:
      004CDA BF 82 00         [24] 1228 	cjne	r7,#0x82,00122$
      004CDD                       1229 00122$:
      004CDD 50 16            [24] 1230 	jnc	00105$
                                   1231 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004CDF 12 4E 41         [24] 1232 	lcall	_ak820_outline_0022
                                   1233 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004CE2 74 02            [12] 1234 	mov	a,#0x02
      004CE4 5C               [12] 1235 	anl	a,r4
      004CE5 FB               [12] 1236 	mov	r3,a
      004CE6 53 04 01         [24] 1237 	anl	ar4,#0x01
      004CE9 EC               [12] 1238 	mov	a,r4
      004CEA 2C               [12] 1239 	add	a,r4
      004CEB 42 03            [12] 1240 	orl	ar3,a
      004CED 12 38 5E         [24] 1241 	lcall	_ak820_outline_0138
      004CF0 EB               [12] 1242 	mov	a,r3
      004CF1 F0               [24] 1243 	movx	@dptr,a
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004CF2 0F               [12] 1245 	inc	r7
      004CF3 80 E5            [24] 1246 	sjmp	00103$
      004CF5                       1247 00105$:
                                   1248 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004CF5 22               [24] 1249 	ret
                                   1250 ;------------------------------------------------------------
                                   1251 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1252 ;------------------------------------------------------------
                                   1253 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1254 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1255 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1256 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1257 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1258 ;------------------------------------------------------------
                                   1259 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1260 ;	-----------------------------------------
                                   1261 ;	 function ak820_oneshot_process
                                   1262 ;	-----------------------------------------
      004CF6                       1263 _ak820_oneshot_process:
      004CF6 12 38 44         [24] 1264 	lcall	_ak820_outline_0109
      004CF9 90 06 9E         [24] 1265 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004CFC 12 38 49         [24] 1266 	lcall	_ak820_outline_0110
                                   1267 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004CFF 90 06 9C         [24] 1268 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004D02 E0               [24] 1269 	movx	a,@dptr
      004D03 FF               [12] 1270 	mov	r7,a
      004D04 BF FF 02         [24] 1271 	cjne	r7,#0xff,00248$
      004D07 80 0B            [24] 1272 	sjmp	00101$
      004D09                       1273 00248$:
      004D09 C0 07            [24] 1274 	push	ar7
      004D0B 12 A8 B4         [24] 1275 	lcall	_get_repeat_key_count
      004D0E E5 82            [12] 1276 	mov	a, dpl
      004D10 D0 07            [24] 1277 	pop	ar7
      004D12 60 04            [24] 1278 	jz	00102$
      004D14                       1279 00101$:
      004D14 75 82 01         [24] 1280 	mov	dpl, #0x01
      004D17 22               [24] 1281 	ret
      004D18                       1282 00102$:
                                   1283 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004D18 90 06 9E         [24] 1284 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004D1B E0               [24] 1285 	movx	a,@dptr
      004D1C FD               [12] 1286 	mov	r5,a
      004D1D A3               [24] 1287 	inc	dptr
      004D1E E0               [24] 1288 	movx	a,@dptr
      004D1F FB               [12] 1289 	mov	r3,a
      004D20 BB 52 02         [24] 1290 	cjne	r3,#0x52,00250$
      004D23 80 02            [24] 1291 	sjmp	00251$
      004D25                       1292 00250$:
      004D25 A1 C8            [12] 1293 	ajmp	00116$
      004D27                       1294 00251$:
      004D27 8D 04            [24] 1295 	mov	ar4,r5
      004D29 53 04 E0         [24] 1296 	anl	ar4,#0xe0
      004D2C BC A0 02         [24] 1297 	cjne	r4,#0xa0,00252$
      004D2F 80 02            [24] 1298 	sjmp	00253$
      004D31                       1299 00252$:
      004D31 A1 C8            [12] 1300 	ajmp	00116$
      004D33                       1301 00253$:
                                   1302 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004D33 8D 04            [24] 1303 	mov	ar4,r5
      004D35 53 04 0F         [24] 1304 	anl	ar4,#0x0f
      004D38 90 06 A0         [24] 1305 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D3B EC               [12] 1306 	mov	a,r4
      004D3C F0               [24] 1307 	movx	@dptr,a
                                   1308 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004D3D ED               [12] 1309 	mov	a,r5
      004D3E 30 E4 08         [24] 1310 	jnb	acc.4,00105$
      004D41 EC               [12] 1311 	mov	a,r4
      004D42 C4               [12] 1312 	swap	a
      004D43 54 F0            [12] 1313 	anl	a,#0xf0
      004D45 90 06 A0         [24] 1314 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D48 F0               [24] 1315 	movx	@dptr,a
      004D49                       1316 00105$:
                                   1317 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004D49 90 06 9D         [24] 1318 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004D4C E0               [24] 1319 	movx	a,@dptr
      004D4D 60 2D            [24] 1320 	jz	00113$
                                   1321 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004D4F 12 4E 41         [24] 1322 	lcall	_ak820_outline_0022
      004D52 43 04 08         [24] 1323 	orl	ar4,#0x08
      004D55 12 49 44         [24] 1324 	lcall	_ak820_outline_0067
                                   1325 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004D58 53 04 EF         [24] 1326 	anl	ar4,#0xef
      004D5B 12 49 44         [24] 1327 	lcall	_ak820_outline_0067
                                   1328 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004D5E 90 0E 43         [24] 1329 	mov	dptr,#_ak820_oneshot_target
      004D61 E0               [24] 1330 	movx	a,@dptr
      004D62 FC               [12] 1331 	mov	r4,a
      004D63 BC FF 02         [24] 1332 	cjne	r4,#0xff,00256$
      004D66 80 09            [24] 1333 	sjmp	00107$
      004D68                       1334 00256$:
      004D68 12 4E 83         [24] 1335 	lcall	_ak820_outline_0076
      004D6B 43 04 10         [24] 1336 	orl	ar4,#0x10
      004D6E 12 49 44         [24] 1337 	lcall	_ak820_outline_0067
      004D71                       1338 00107$:
                                   1339 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004D71 90 06 A0         [24] 1340 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D74 E0               [24] 1341 	movx	a,@dptr
      004D75 F5 82            [12] 1342 	mov	dpl,a
      004D77 12 7B 6D         [24] 1343 	lcall	_register_mods
      004D7A 80 48            [24] 1344 	sjmp	00114$
      004D7C                       1345 00113$:
                                   1346 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004D7C 12 4E 41         [24] 1347 	lcall	_ak820_outline_0022
      004D7F 30 E3 42         [24] 1348 	jnb	acc.3,00114$
                                   1349 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004D82 EC               [12] 1350 	mov	a,r4
      004D83 20 E4 24         [24] 1351 	jb	acc.4,00109$
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004D86 90 06 9A         [24] 1353 	mov	dptr,#_ak820_oneshot_mods
      004D89 E0               [24] 1354 	movx	a,@dptr
      004D8A F4               [12] 1355 	cpl	a
      004D8B FC               [12] 1356 	mov	r4,a
      004D8C 90 06 A0         [24] 1357 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D8F E0               [24] 1358 	movx	a,@dptr
      004D90 FB               [12] 1359 	mov	r3,a
      004D91 52 04            [12] 1360 	anl	ar4,a
      004D93 8C 82            [24] 1361 	mov	dpl, r4
      004D95 C0 06            [24] 1362 	push	ar6
      004D97 C0 05            [24] 1363 	push	ar5
      004D99 C0 03            [24] 1364 	push	ar3
      004D9B 12 81 A0         [24] 1365 	lcall	_add_owned_mods
      004D9E D0 03            [24] 1366 	pop	ar3
      004DA0 D0 05            [24] 1367 	pop	ar5
      004DA2 D0 06            [24] 1368 	pop	ar6
                                   1369 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004DA4 90 06 9A         [24] 1370 	mov	dptr,#_ak820_oneshot_mods
      004DA7 E0               [24] 1371 	movx	a,@dptr
      004DA8 4B               [12] 1372 	orl	a,r3
      004DA9 F0               [24] 1373 	movx	@dptr,a
      004DAA                       1374 00109$:
                                   1375 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004DAA 90 06 A0         [24] 1376 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004DAD E0               [24] 1377 	movx	a,@dptr
      004DAE F5 82            [12] 1378 	mov	dpl,a
      004DB0 C0 06            [24] 1379 	push	ar6
      004DB2 C0 05            [24] 1380 	push	ar5
      004DB4 12 7B 81         [24] 1381 	lcall	_unregister_mods
      004DB7 D0 05            [24] 1382 	pop	ar5
      004DB9 D0 06            [24] 1383 	pop	ar6
                                   1384 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004DBB 12 4E 83         [24] 1385 	lcall	_ak820_outline_0076
      004DBE 53 04 E7         [24] 1386 	anl	ar4,#0xe7
      004DC1 12 49 44         [24] 1387 	lcall	_ak820_outline_0067
      004DC4                       1388 00114$:
                                   1389 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004DC4 75 82 00         [24] 1390 	mov	dpl, #0x00
      004DC7 22               [24] 1391 	ret
      004DC8                       1392 00116$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004DC8 90 06 9D         [24] 1394 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004DCB E0               [24] 1395 	movx	a,@dptr
      004DCC 60 64            [24] 1396 	jz	00124$
      004DCE 90 06 9E         [24] 1397 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004DD1 12 38 26         [24] 1398 	lcall	_ak820_outline_0081
      004DD4 C3               [12] 1399 	clr	c
      004DD5 74 01            [12] 1400 	mov	a,#0x01
      004DD7 9D               [12] 1401 	subb	a,r5
      004DD8 E4               [12] 1402 	clr	a
      004DD9 9E               [12] 1403 	subb	a,r6
      004DDA 50 56            [24] 1404 	jnc	00124$
                                   1405 ;	free result
                                   1406 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004DDC C3               [12] 1407 	clr	c
      004DDD ED               [12] 1408 	mov	a,r5
      004DDE 94 E0            [12] 1409 	subb	a,#0xe0
      004DE0 EE               [12] 1410 	mov	a,r6
      004DE1 94 00            [12] 1411 	subb	a,#0x00
      004DE3 40 07            [24] 1412 	jc	00129$
      004DE5 74 E7            [12] 1413 	mov	a,#0xe7
      004DE7 9D               [12] 1414 	subb	a,r5
      004DE8 E4               [12] 1415 	clr	a
      004DE9 9E               [12] 1416 	subb	a,r6
      004DEA 50 46            [24] 1417 	jnc	00124$
                                   1418 ;	free result
      004DEC                       1419 00129$:
                                   1420 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004DEC 74 AE            [12] 1421 	mov	a,#0x100 - 0x52
      004DEE 2E               [12] 1422 	add	a,r6
      004DEF 50 09            [24] 1423 	jnc	00165$
      004DF1 C3               [12] 1424 	clr	c
      004DF2 74 DF            [12] 1425 	mov	a,#0xdf
      004DF4 9D               [12] 1426 	subb	a,r5
      004DF5 74 52            [12] 1427 	mov	a,#0x52
      004DF7 9E               [12] 1428 	subb	a,r6
      004DF8 50 38            [24] 1429 	jnc	00124$
                                   1430 ;	free result
                                   1431 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004DFA                       1432 00165$:
      004DFA 7E 00            [12] 1433 	mov	r6,#0x00
      004DFC                       1434 00131$:
      004DFC BE 82 00         [24] 1435 	cjne	r6,#0x82,00265$
      004DFF                       1436 00265$:
      004DFF 50 1A            [24] 1437 	jnc	00120$
                                   1438 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004E01 EE               [12] 1439 	mov	a,r6
      004E02 24 06            [12] 1440 	add	a, #_source_state
      004E04 FC               [12] 1441 	mov	r4,a
      004E05 E4               [12] 1442 	clr	a
      004E06 34 06            [12] 1443 	addc	a, #(_source_state >> 8)
      004E08 FD               [12] 1444 	mov	r5,a
      004E09 12 49 4B         [24] 1445 	lcall	_ak820_outline_0080
      004E0C FB               [12] 1446 	mov	r3,a
      004E0D 30 E3 08         [24] 1447 	jnb	acc.3,00132$
      004E10 43 03 10         [24] 1448 	orl	ar3,#0x10
      004E13 12 38 54         [24] 1449 	lcall	_ak820_outline_0128
      004E16 EB               [12] 1450 	mov	a,r3
      004E17 F0               [24] 1451 	movx	@dptr,a
      004E18                       1452 00132$:
                                   1453 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004E18 0E               [12] 1454 	inc	r6
      004E19 80 E1            [24] 1455 	sjmp	00131$
      004E1B                       1456 00120$:
                                   1457 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004E1B 90 06 9A         [24] 1458 	mov	dptr,#_ak820_oneshot_mods
      004E1E E0               [24] 1459 	movx	a,@dptr
      004E1F FE               [12] 1460 	mov	r6,a
      004E20 E0               [24] 1461 	movx	a,@dptr
      004E21 60 0F            [24] 1462 	jz	00124$
                                   1463 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004E23 90 06 9B         [24] 1464 	mov	dptr,#_ak820_oneshot_consumed
      004E26 EE               [12] 1465 	mov	a,r6
      004E27 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004E28 90 0E 43         [24] 1468 	mov	dptr,#_ak820_oneshot_target
      004E2B EF               [12] 1469 	mov	a,r7
      004E2C F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004E2D 90 06 9A         [24] 1472 	mov	dptr,#_ak820_oneshot_mods
      004E30 E4               [12] 1473 	clr	a
      004E31 F0               [24] 1474 	movx	@dptr,a
      004E32                       1475 00124$:
                                   1476 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004E32 75 82 01         [24] 1477 	mov	dpl, #0x01
                                   1478 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004E35 22               [24] 1479 	ret
                                   1480 	.area CSEG    (CODE)
                                   1481 	.area CONST   (CODE)
                                   1482 	.area XINIT   (CODE)
      00C806                       1483 __xinit__pending:
      00C806 FF                    1484 	.db #0xff	; 255
      00C807                       1485 __xinit__ak820_oneshot_target:
      00C807 FF                    1486 	.db #0xff	; 255
                                   1487 	.area CABS    (ABS,CODE)
                                   1488 
                                   1489 ; Experimental exact instruction outlining.
                                   1490 	.globl _ak820_outline_0006
                                   1491 	.globl _ak820_outline_0007
                                   1492 	.globl _ak820_outline_0009
                                   1493 	.globl _ak820_outline_0011
                                   1494 	.globl _ak820_outline_0012
                                   1495 	.globl _ak820_outline_0013
                                   1496 	.globl _ak820_outline_0015
                                   1497 	.globl _ak820_outline_0019
                                   1498 	.globl _ak820_outline_0022
                                   1499 	.globl _ak820_outline_0024
                                   1500 	.globl _ak820_outline_0025
                                   1501 	.globl _ak820_outline_0034
                                   1502 	.globl _ak820_outline_0051
                                   1503 	.globl _ak820_outline_0056
                                   1504 	.globl _ak820_outline_0060
                                   1505 	.globl _ak820_outline_0063
                                   1506 	.globl _ak820_outline_0064
                                   1507 	.globl _ak820_outline_0067
                                   1508 	.globl _ak820_outline_0076
                                   1509 	.globl _ak820_outline_0080
                                   1510 	.globl _ak820_outline_0081
                                   1511 	.globl _ak820_outline_0098
                                   1512 	.globl _ak820_outline_0105
                                   1513 	.globl _ak820_outline_0109
                                   1514 	.globl _ak820_outline_0110
                                   1515 	.globl _ak820_outline_0120
                                   1516 	.globl _ak820_outline_0124
                                   1517 	.globl _ak820_outline_0127
                                   1518 	.globl _ak820_outline_0128
                                   1519 	.globl _ak820_outline_0138
                                   1520 	.globl _ak820_outline_0142
                                   1521 	.globl _ak820_outline_0161
                                   1522 	.globl _ak820_outline_0164
                                   1523 	.globl _ak820_outline_0193
                                   1524 
                                   1525 	.area CSEG (CODE)
                                   1526 ; function ak820_outline_0015
      004E36                       1527 _ak820_outline_0015:
      004E36 2E               [12] 1528 	add	a,r6
      004E37 FB               [12] 1529 	mov	r3,a
      004E38 E4               [12] 1530 	clr	a
      004E39 3F               [12] 1531 	addc	a,r7
      004E3A FC               [12] 1532 	mov	r4,a
      004E3B 8B 82            [24] 1533 	mov	dpl,r3
      004E3D 8C 83            [24] 1534 	mov	dph,r4
      004E3F E0               [24] 1535 	movx	a,@dptr
      004E40 22               [24] 1536 	ret
                                   1537 
                                   1538 	.area CSEG (CODE)
                                   1539 ; function ak820_outline_0022
      004E41                       1540 _ak820_outline_0022:
      004E41 EF               [12] 1541 	mov	a,r7
      004E42 24 06            [12] 1542 	add	a,#_source_state
      004E44 FD               [12] 1543 	mov	r5,a
      004E45 E4               [12] 1544 	clr	a
      004E46 34 06            [12] 1545 	addc	a,#(_source_state>>8)
      004E48 FE               [12] 1546 	mov	r6,a
      004E49 8D 82            [24] 1547 	mov	dpl,r5
      004E4B 8E 83            [24] 1548 	mov	dph,r6
      004E4D E0               [24] 1549 	movx	a,@dptr
      004E4E FC               [12] 1550 	mov	r4,a
      004E4F 22               [24] 1551 	ret
                                   1552 
                                   1553 	.area CSEG (CODE)
                                   1554 ; function ak820_outline_0024
      004E50                       1555 _ak820_outline_0024:
      004E50 90 0E 2F         [24] 1556 	mov	dptr,#___memcpy_PARM_2
      004E53 EC               [12] 1557 	mov	a,r4
      004E54 F0               [24] 1558 	movx	@dptr,a
      004E55 ED               [12] 1559 	mov	a,r5
      004E56 A3               [24] 1560 	inc	dptr
      004E57 F0               [24] 1561 	movx	@dptr,a
      004E58 E4               [12] 1562 	clr	a
      004E59 A3               [24] 1563 	inc	dptr
      004E5A F0               [24] 1564 	movx	@dptr,a
      004E5B 90 0E 32         [24] 1565 	mov	dptr,#___memcpy_PARM_3
      004E5E 74 02            [12] 1566 	mov	a,#0x02
      004E60 F0               [24] 1567 	movx	@dptr,a
      004E61 E4               [12] 1568 	clr	a
      004E62 A3               [24] 1569 	inc	dptr
      004E63 F0               [24] 1570 	movx	@dptr,a
      004E64 90 06 8C         [24] 1571 	mov	dptr,#_ak820_tapping_source_PARM_1
      004E67 F5 F0            [12] 1572 	mov	b,a
      004E69 22               [24] 1573 	ret
                                   1574 
                                   1575 	.area CSEG (CODE)
                                   1576 ; function ak820_outline_0051
      004E6A                       1577 _ak820_outline_0051:
      004E6A 2E               [12] 1578 	add	a,r6
      004E6B FA               [12] 1579 	mov	r2,a
      004E6C E4               [12] 1580 	clr	a
      004E6D 3F               [12] 1581 	addc	a,r7
      004E6E FB               [12] 1582 	mov	r3,a
      004E6F 8A 82            [24] 1583 	mov	dpl,r2
      004E71 8B 83            [24] 1584 	mov	dph,r3
      004E73 E0               [24] 1585 	movx	a,@dptr
      004E74 22               [24] 1586 	ret
                                   1587 
                                   1588 	.area CSEG (CODE)
                                   1589 ; function ak820_outline_0060
      004E75                       1590 _ak820_outline_0060:
      004E75 FC               [12] 1591 	mov	r4,a
      004E76 8B 82            [24] 1592 	mov	dpl,r3
      004E78 8C 83            [24] 1593 	mov	dph,r4
      004E7A E0               [24] 1594 	movx	a,@dptr
      004E7B FA               [12] 1595 	mov	r2,a
      004E7C 22               [24] 1596 	ret
                                   1597 
                                   1598 	.area CSEG (CODE)
                                   1599 ; function ak820_outline_0064
      004E7D                       1600 _ak820_outline_0064:
      004E7D EE               [12] 1601 	mov	a,r6
      004E7E F0               [24] 1602 	movx	@dptr,a
      004E7F EF               [12] 1603 	mov	a,r7
      004E80 A3               [24] 1604 	inc	dptr
      004E81 F0               [24] 1605 	movx	@dptr,a
      004E82 22               [24] 1606 	ret
                                   1607 
                                   1608 	.area CSEG (CODE)
                                   1609 ; function ak820_outline_0076
      004E83                       1610 _ak820_outline_0076:
      004E83 8D 82            [24] 1611 	mov	dpl,r5
      004E85 8E 83            [24] 1612 	mov	dph,r6
      004E87 E0               [24] 1613 	movx	a,@dptr
      004E88 FC               [12] 1614 	mov	r4,a
      004E89 22               [24] 1615 	ret
                                   1616 
                                   1617 	.area CSEG (CODE)
                                   1618 ; function ak820_outline_0142
      004E8A                       1619 _ak820_outline_0142:
      004E8A E9               [12] 1620 	mov	a,r1
      004E8B F0               [24] 1621 	movx	@dptr,a
      004E8C EA               [12] 1622 	mov	a,r2
      004E8D A3               [24] 1623 	inc	dptr
      004E8E F0               [24] 1624 	movx	@dptr,a
      004E8F 22               [24] 1625 	ret
                                   1626 
                                   1627 	.area CSEG (CODE)
                                   1628 ; function ak820_outline_0161
      004E90                       1629 _ak820_outline_0161:
      004E90 90 0E 42         [24] 1630 	mov	dptr,#_pending
      004E93 74 FF            [12] 1631 	mov	a,#0xff
      004E95 F0               [24] 1632 	movx	@dptr,a
      004E96 22               [24] 1633 	ret
