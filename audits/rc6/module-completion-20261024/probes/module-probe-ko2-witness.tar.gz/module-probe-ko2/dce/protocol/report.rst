                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _biton
                                     12 	.globl _memset
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _del_key_from_report_PARM_2
                                    257 	.globl _add_key_to_report_PARM_2
                                    258 	.globl _del_key_bit_PARM_2
                                    259 	.globl _add_key_bit_PARM_2
                                    260 	.globl _del_key_byte_PARM_2
                                    261 	.globl _add_key_byte_PARM_2
                                    262 	.globl _KEYCODE2CONSUMER
                                    263 	.globl _add_key_byte
                                    264 	.globl _del_key_byte
                                    265 	.globl _add_key_bit
                                    266 	.globl _del_key_bit
                                    267 	.globl _add_key_to_report
                                    268 	.globl _del_key_from_report
                                    269 	.globl _clear_keys_from_report
                                    270 ;--------------------------------------------------------
                                    271 ; special function registers
                                    272 ;--------------------------------------------------------
                                    273 	.area RSEG    (ABS,DATA)
      000000                        274 	.org 0x0000
                           0000D0   275 _PSW	=	0x00d0
                           0000E0   276 _ACC	=	0x00e0
                           0000F0   277 _B	=	0x00f0
                           0000FD   278 _A_INV	=	0x00fd
                           000081   279 _SP	=	0x0081
                           000082   280 _DPL	=	0x0082
                           000083   281 _DPH	=	0x0083
                           0000A1   282 _SAFE_MOD	=	0x00a1
                           0000B1   283 _GLOBAL_CFG	=	0x00b1
                           000087   284 _PCON	=	0x0087
                           0000BA   285 _POWER_CFG	=	0x00ba
                           0000B9   286 _CLOCK_CFG	=	0x00b9
                           0000A9   287 _WAKE_CTRL	=	0x00a9
                           0000FE   288 _RESET_KEEP	=	0x00fe
                           0000FF   289 _WDOG_COUNT	=	0x00ff
                           0000A8   290 _IE	=	0x00a8
                           0000B8   291 _IP	=	0x00b8
                           0000E8   292 _IE_EX	=	0x00e8
                           0000E9   293 _IP_EX	=	0x00e9
                           0000B2   294 _GPIO_IE	=	0x00b2
                           008584   295 _ROM_ADDR	=	0x8584
                           000084   296 _ROM_ADDR_L	=	0x0084
                           000085   297 _ROM_ADDR_H	=	0x0085
                           008F8E   298 _ROM_DATA_HI	=	0x8f8e
                           00008E   299 _ROM_DATA_HL	=	0x008e
                           00008F   300 _ROM_DATA_HH	=	0x008f
                           000086   301 _ROM_CTRL	=	0x0086
                           000080   302 _P0	=	0x0080
                           0000C4   303 _P0_MOD_OC	=	0x00c4
                           0000C5   304 _P0_DIR_PU	=	0x00c5
                           000090   305 _P1	=	0x0090
                           000092   306 _P1_MOD_OC	=	0x0092
                           000093   307 _P1_DIR_PU	=	0x0093
                           0000A0   308 _P2	=	0x00a0
                           000094   309 _P2_MOD_OC	=	0x0094
                           000095   310 _P2_DIR_PU	=	0x0095
                           0000B0   311 _P3	=	0x00b0
                           000096   312 _P3_MOD_OC	=	0x0096
                           000097   313 _P3_DIR_PU	=	0x0097
                           0000C0   314 _P4	=	0x00c0
                           0000C2   315 _P4_MOD_OC	=	0x00c2
                           0000C3   316 _P4_DIR_PU	=	0x00c3
                           0000C1   317 _P4_LED_KEY	=	0x00c1
                           0000AA   318 _P5_IN	=	0x00aa
                           0000AB   319 _P5_OUT_PU	=	0x00ab
                           0000AC   320 _P5_DIR	=	0x00ac
                           0000AD   321 _P6_IN	=	0x00ad
                           0000AE   322 _P6_OUT_PU	=	0x00ae
                           0000AF   323 _P6_DIR	=	0x00af
                           0000F1   324 _P7	=	0x00f1
                           0000A2   325 _XBUS_AUX	=	0x00a2
                           000088   326 _TCON	=	0x0088
                           000089   327 _TMOD	=	0x0089
                           00008A   328 _TL0	=	0x008a
                           00008B   329 _TL1	=	0x008b
                           00008C   330 _TH0	=	0x008c
                           00008D   331 _TH1	=	0x008d
                           000098   332 _SCON	=	0x0098
                           000099   333 _SBUF	=	0x0099
                           0000C8   334 _T2CON	=	0x00c8
                           0000C9   335 _T2MOD	=	0x00c9
                           00CBCA   336 _RCAP2	=	0xcbca
                           0000CA   337 _RCAP2L	=	0x00ca
                           0000CB   338 _RCAP2H	=	0x00cb
                           00CDCC   339 _T2COUNT	=	0xcdcc
                           0000CC   340 _TL2	=	0x00cc
                           0000CD   341 _TH2	=	0x00cd
                           00CFCE   342 _T2CAP1	=	0xcfce
                           0000CE   343 _T2CAP1L	=	0x00ce
                           0000CF   344 _T2CAP1H	=	0x00cf
                           0000F8   345 _SPI0_STAT	=	0x00f8
                           0000F9   346 _SPI0_DATA	=	0x00f9
                           0000FA   347 _SPI0_CTRL	=	0x00fa
                           0000FB   348 _SPI0_CK_SE	=	0x00fb
                           0000FC   349 _SPI0_SETUP	=	0x00fc
                           0000BC   350 _SCON1	=	0x00bc
                           0000BD   351 _SBUF1	=	0x00bd
                           0000BE   352 _SBAUD1	=	0x00be
                           0000BF   353 _SIF1	=	0x00bf
                           0000B4   354 _SPI1_STAT	=	0x00b4
                           0000B5   355 _SPI1_DATA	=	0x00b5
                           0000B6   356 _SPI1_CTRL	=	0x00b6
                           0000B7   357 _SPI1_CK_SE	=	0x00b7
                           0000F3   358 _ADC_CTRL	=	0x00f3
                           00F5F4   359 _ADC_DAT	=	0xf5f4
                           0000F4   360 _ADC_DAT_L	=	0x00f4
                           0000F5   361 _ADC_DAT_H	=	0x00f5
                           0000F6   362 _ADC_CHAN	=	0x00f6
                           0000A6   363 _LED_COMMON	=	0x00a6
                           0000A7   364 _LED_PWM_OE	=	0x00a7
                           00C7C6   365 _LED_DMA	=	0xc7c6
                           0000C6   366 _LED_DMA_L	=	0x00c6
                           0000C7   367 _LED_DMA_H	=	0x00c7
                           0000F7   368 _LED_STATUS	=	0x00f7
                           0000B3   369 _I2CX_INT	=	0x00b3
                           0000BB   370 _I2CS_INT_ST	=	0x00bb
                                    371 ;--------------------------------------------------------
                                    372 ; special function bits
                                    373 ;--------------------------------------------------------
                                    374 	.area RSEG    (ABS,DATA)
      000000                        375 	.org 0x0000
                           0000D7   376 _CY	=	0x00d7
                           0000D6   377 _AC	=	0x00d6
                           0000D5   378 _F0	=	0x00d5
                           0000D4   379 _RS1	=	0x00d4
                           0000D3   380 _RS0	=	0x00d3
                           0000D2   381 _OV	=	0x00d2
                           0000D1   382 _F1	=	0x00d1
                           0000D0   383 _P	=	0x00d0
                           0000AF   384 _EA	=	0x00af
                           0000AE   385 _E_DIS	=	0x00ae
                           0000AD   386 _ET2	=	0x00ad
                           0000AC   387 _ES	=	0x00ac
                           0000AB   388 _ET1	=	0x00ab
                           0000AA   389 _EX1	=	0x00aa
                           0000A9   390 _ET0	=	0x00a9
                           0000A8   391 _EX0	=	0x00a8
                           0000BF   392 _PH_FLAG	=	0x00bf
                           0000BE   393 _PL_FLAG	=	0x00be
                           0000BD   394 _PT2	=	0x00bd
                           0000BC   395 _PS	=	0x00bc
                           0000BB   396 _PT1	=	0x00bb
                           0000BA   397 _PX1	=	0x00ba
                           0000B9   398 _PT0	=	0x00b9
                           0000B8   399 _PX0	=	0x00b8
                           0000EF   400 _IE_WDOG	=	0x00ef
                           0000EE   401 _IE_GPIO	=	0x00ee
                           0000ED   402 _IE_PWM_I2C	=	0x00ed
                           0000EC   403 _IE_UART1	=	0x00ec
                           0000EB   404 _IE_ADC	=	0x00eb
                           0000E9   405 _IE_USB	=	0x00e9
                           0000E8   406 _IE_SPI0	=	0x00e8
                           000087   407 _P0_7	=	0x0087
                           000086   408 _P0_6	=	0x0086
                           000085   409 _P0_5	=	0x0085
                           000084   410 _P0_4	=	0x0084
                           000083   411 _P0_3	=	0x0083
                           000082   412 _P0_2	=	0x0082
                           000081   413 _P0_1	=	0x0081
                           000080   414 _P0_0	=	0x0080
                           000081   415 _SDA0	=	0x0081
                           000080   416 _SCL0	=	0x0080
                           000083   417 _TXD_	=	0x0083
                           000082   418 _RXD_	=	0x0082
                           000085   419 _AIN13	=	0x0085
                           000084   420 _AIN12	=	0x0084
                           000083   421 _AIN11	=	0x0083
                           000082   422 _AIN10	=	0x0082
                           000081   423 _AIN9	=	0x0081
                           000080   424 _AIN8	=	0x0080
                           000097   425 _P1_7	=	0x0097
                           000096   426 _P1_6	=	0x0096
                           000095   427 _P1_5	=	0x0095
                           000094   428 _P1_4	=	0x0094
                           000093   429 _P1_3	=	0x0093
                           000092   430 _P1_2	=	0x0092
                           000091   431 _P1_1	=	0x0091
                           000090   432 _P1_0	=	0x0090
                           000097   433 _TXD1_	=	0x0097
                           000096   434 _RXD1_	=	0x0096
                           000097   435 _SCK	=	0x0097
                           000096   436 _MISO	=	0x0096
                           000095   437 _MOSI	=	0x0095
                           000094   438 _SCS	=	0x0094
                           000092   439 _INT0_	=	0x0092
                           000091   440 _T2EX	=	0x0091
                           000091   441 _CAP2	=	0x0091
                           000090   442 _T2	=	0x0090
                           000090   443 _CAP1	=	0x0090
                           000097   444 _AIN7	=	0x0097
                           000096   445 _AIN6	=	0x0096
                           000095   446 _AIN5	=	0x0095
                           000094   447 _AIN4	=	0x0094
                           000093   448 _AIN3	=	0x0093
                           000092   449 _AIN2	=	0x0092
                           000091   450 _AIN1	=	0x0091
                           000090   451 _AIN0	=	0x0090
                           0000A7   452 _P2_7	=	0x00a7
                           0000A6   453 _P2_6	=	0x00a6
                           0000A5   454 _P2_5	=	0x00a5
                           0000A4   455 _P2_4	=	0x00a4
                           0000A3   456 _P2_3	=	0x00a3
                           0000A2   457 _P2_2	=	0x00a2
                           0000A1   458 _P2_1	=	0x00a1
                           0000A0   459 _P2_0	=	0x00a0
                           0000A7   460 _TXD1	=	0x00a7
                           0000A6   461 _RXD1	=	0x00a6
                           0000A5   462 _T2EX_	=	0x00a5
                           0000A5   463 _CAP2_	=	0x00a5
                           0000A4   464 _T2_	=	0x00a4
                           0000A4   465 _CAP1_	=	0x00a4
                           0000B7   466 _P3_7	=	0x00b7
                           0000B6   467 _P3_6	=	0x00b6
                           0000B5   468 _P3_5	=	0x00b5
                           0000B4   469 _P3_4	=	0x00b4
                           0000B3   470 _P3_3	=	0x00b3
                           0000B2   471 _P3_2	=	0x00b2
                           0000B1   472 _P3_1	=	0x00b1
                           0000B0   473 _P3_0	=	0x00b0
                           0000B7   474 _SCK1	=	0x00b7
                           0000B6   475 _MISO1	=	0x00b6
                           0000B5   476 _MOSI1	=	0x00b5
                           0000B5   477 _T1	=	0x00b5
                           0000B4   478 _T0	=	0x00b4
                           0000B3   479 _INT1	=	0x00b3
                           0000B2   480 _INT0	=	0x00b2
                           0000B1   481 _TXD	=	0x00b1
                           0000B0   482 _RXD	=	0x00b0
                           0000C6   483 _P4_6	=	0x00c6
                           0000C5   484 _P4_5	=	0x00c5
                           0000C4   485 _P4_4	=	0x00c4
                           0000C3   486 _P4_3	=	0x00c3
                           0000C2   487 _P4_2	=	0x00c2
                           0000C1   488 _P4_1	=	0x00c1
                           0000C0   489 _P4_0	=	0x00c0
                           00008F   490 _TF1	=	0x008f
                           00008E   491 _TR1	=	0x008e
                           00008D   492 _TF0	=	0x008d
                           00008C   493 _TR0	=	0x008c
                           00008B   494 _IE1	=	0x008b
                           00008A   495 _IT1	=	0x008a
                           000089   496 _IE0	=	0x0089
                           000088   497 _IT0	=	0x0088
                           00009F   498 _SM0	=	0x009f
                           00009E   499 _SM1	=	0x009e
                           00009D   500 _SM2	=	0x009d
                           00009C   501 _REN	=	0x009c
                           00009B   502 _TB8	=	0x009b
                           00009A   503 _RB8	=	0x009a
                           000099   504 _TI	=	0x0099
                           000098   505 _RI	=	0x0098
                           0000CF   506 _TF2	=	0x00cf
                           0000CF   507 _CAP1F	=	0x00cf
                           0000CE   508 _EXF2	=	0x00ce
                           0000CD   509 _RCLK	=	0x00cd
                           0000CC   510 _TCLK	=	0x00cc
                           0000CB   511 _EXEN2	=	0x00cb
                           0000CA   512 _TR2	=	0x00ca
                           0000C9   513 _C_T2	=	0x00c9
                           0000C8   514 _CP_RL2	=	0x00c8
                           0000FF   515 _S0_FST_ACT	=	0x00ff
                           0000FE   516 _S0_IF_OV	=	0x00fe
                           0000FD   517 _S0_IF_FIRST	=	0x00fd
                           0000FC   518 _S0_IF_BYTE	=	0x00fc
                           0000FB   519 _S0_FREE	=	0x00fb
                           0000FA   520 _S0_T_FIFO	=	0x00fa
                           0000F8   521 _S0_R_FIFO	=	0x00f8
                           0000F7   522 _ADC_START	=	0x00f7
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable register banks
                                    525 ;--------------------------------------------------------
                                    526 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        527 	.ds 8
                                    528 ;--------------------------------------------------------
                                    529 ; internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area DSEG    (DATA)
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable items in internal ram
                                    534 ;--------------------------------------------------------
                                    535 ;--------------------------------------------------------
                                    536 ; indirectly addressable internal ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area ISEG    (DATA)
                                    539 ;--------------------------------------------------------
                                    540 ; absolute internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area IABS    (ABS,DATA)
                                    543 	.area IABS    (ABS,DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; bit data
                                    546 ;--------------------------------------------------------
                                    547 	.area BSEG    (BIT)
                                    548 ;--------------------------------------------------------
                                    549 ; paged external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area PSEG    (PAG,XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; uninitialized external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XSEG    (XDATA)
      000859                        556 _KEYCODE2CONSUMER_key_10000_117:
      000859                        557 	.ds 1
      00085A                        558 _add_key_byte_PARM_2:
      00085A                        559 	.ds 1
      00085B                        560 _add_key_byte_report_arg_10000_144:
      00085B                        561 	.ds 2
      00085D                        562 _add_key_byte_empty_10000_145:
      00085D                        563 	.ds 1
      00085E                        564 _del_key_byte_PARM_2:
      00085E                        565 	.ds 1
      00085F                        566 _del_key_byte_report_arg_10000_156:
      00085F                        567 	.ds 2
      000861                        568 _add_key_bit_PARM_2:
      000861                        569 	.ds 1
      000862                        570 _add_key_bit_report_arg_10000_162:
      000862                        571 	.ds 2
      000864                        572 _del_key_bit_PARM_2:
      000864                        573 	.ds 1
      000865                        574 _del_key_bit_report_arg_10000_167:
      000865                        575 	.ds 2
      000867                        576 _add_key_to_report_PARM_2:
      000867                        577 	.ds 1
      000868                        578 _add_key_to_report_report_arg_10000_172:
      000868                        579 	.ds 2
      00086A                        580 _del_key_from_report_PARM_2:
      00086A                        581 	.ds 1
      00086B                        582 _del_key_from_report_report_arg_10000_176:
      00086B                        583 	.ds 2
      00086D                        584 _clear_keys_from_report_report_arg_10000_180:
      00086D                        585 	.ds 2
                                    586 ;--------------------------------------------------------
                                    587 ; absolute external ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area XABS    (ABS,XDATA)
                                    590 ;--------------------------------------------------------
                                    591 ; initialized external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XISEG   (XDATA)
                                    594 	.area HOME    (CODE)
                                    595 	.area GSINIT0 (CODE)
                                    596 	.area GSINIT1 (CODE)
                                    597 	.area GSINIT2 (CODE)
                                    598 	.area GSINIT3 (CODE)
                                    599 	.area GSINIT4 (CODE)
                                    600 	.area GSINIT5 (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.area GSFINAL (CODE)
                                    603 	.area CSEG    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; global & static initialisations
                                    606 ;--------------------------------------------------------
                                    607 	.area HOME    (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 	.area GSFINAL (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 ;--------------------------------------------------------
                                    612 ; Home
                                    613 ;--------------------------------------------------------
                                    614 	.area HOME    (CODE)
                                    615 	.area HOME    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; code
                                    618 ;--------------------------------------------------------
                                    619 	.area CSEG    (CODE)
                                    620 ;------------------------------------------------------------
                                    621 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    622 ;------------------------------------------------------------
                                    623 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    624 ;------------------------------------------------------------
                                    625 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    626 ;	-----------------------------------------
                           000007   627 	ar7 = 0x07
                           000006   628 	ar6 = 0x06
                           000005   629 	ar5 = 0x05
                           000004   630 	ar4 = 0x04
                           000003   631 	ar3 = 0x03
                           000002   632 	ar2 = 0x02
                           000001   633 	ar1 = 0x01
                           000000   634 	ar0 = 0x00
                                    635 ;	 function KEYCODE2CONSUMER
                                    636 ;	-----------------------------------------
      007319                        637 _KEYCODE2CONSUMER:
      007319 E5 82            [12]  638 	mov	a,dpl
      00731B 90 08 59         [24]  639 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      00731E F0               [24]  640 	movx	@dptr,a
                                    641 ;	tmk_core/protocol/report.c:43: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      00731F E0               [24]  642 	movx	a,@dptr
      007320 FF               [12]  643 	mov	r7,a
      007321 BF A8 00         [24]  644 	cjne	r7,#0xa8,00113$
      007324                        645 00113$:
      007324 40 05            [24]  646 	jc	00101$
      007326 EF               [12]  647 	mov	a,r7
      007327 24 3D            [12]  648 	add	a,#0xff - 0xc2
      007329 50 04            [24]  649 	jnc	00102$
                                    650 ;	free result
      00732B                        651 00101$:
      00732B 90 00 00         [24]  652 	mov	dptr,#0x0000
      00732E 22               [24]  653 	ret
      00732F                        654 00102$:
                                    655 ;	tmk_core/protocol/report.c:44: return usages[key - KC_AUDIO_MUTE];
      00732F EF               [12]  656 	mov	a,r7
      007330 24 58            [12]  657 	add	a,#0x58
      007332 FF               [12]  658 	mov	r7,a
      007333 C2 D5            [12]  659 	clr	F0
      007335 75 F0 02         [24]  660 	mov	b,#0x02
      007338 EF               [12]  661 	mov	a,r7
      007339 30 E7 04         [24]  662 	jnb	acc.7,00116$
      00733C B2 D5            [12]  663 	cpl	F0
      00733E F4               [12]  664 	cpl	a
      00733F 04               [12]  665 	inc	a
      007340                        666 00116$:
      007340 A4               [48]  667 	mul	ab
      007341 30 D5 03         [24]  668 	jnb	F0,00117$
      007344 12 75 27         [24]  669 	lcall	_ak820_outline_0134
      007347                        670 00117$:
      007347 24 C8            [12]  671 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      007349 F5 82            [12]  672 	mov	dpl,a
      00734B 74 C0            [12]  673 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      00734D 12 5C C7         [24]  674 	lcall	_ak820_outline_0111
      007350 FE               [12]  675 	mov	r6,a
      007351 A3               [24]  676 	inc	dptr
      007352 E4               [12]  677 	clr	a
      007353 93               [24]  678 	movc	a,@a+dptr
                                    679 ;	tmk_core/protocol/report.c:45: }
      007354 8E 82            [24]  680 	mov	dpl,r6
      007356 F5 83            [12]  681 	mov	dph,a
      007358 22               [24]  682 	ret
                                    683 ;------------------------------------------------------------
                                    684 ;Allocation info for local variables in function 'has_anykey'
                                    685 ;------------------------------------------------------------
                                    686 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    687 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    688 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    689 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    690 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.c:62: uint8_t has_anykey(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function add_key_byte
                                    695 ;	-----------------------------------------
      007359                        696 _add_key_byte:
      007359 12 38 44         [24]  697 	lcall	_ak820_outline_0109
      00735C 90 08 5B         [24]  698 	mov	dptr,#_add_key_byte_report_arg_10000_144
      00735F 12 38 49         [24]  699 	lcall	_ak820_outline_0110
                                    700 ;	tmk_core/protocol/report.c:139: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007362 90 08 5B         [24]  701 	mov	dptr,#_add_key_byte_report_arg_10000_144
      007365 12 37 FD         [24]  702 	lcall	_ak820_outline_0056
                                    703 ;	tmk_core/protocol/report.c:185: int8_t empty = -1;
      007368 90 08 5D         [24]  704 	mov	dptr,#_add_key_byte_empty_10000_145
      00736B 74 FF            [12]  705 	mov	a,#0xff
      00736D F0               [24]  706 	movx	@dptr,a
                                    707 ;	tmk_core/protocol/report.c:200: }
      00736E 7D 00            [12]  708 	mov	r5,#0x00
      007370                        709 00112$:
                                    710 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      007370 C3               [12]  711 	clr	c
      007371 ED               [12]  712 	mov	a,r5
      007372 64 80            [12]  713 	xrl	a,#0x80
      007374 94 86            [12]  714 	subb	a,#0x86
      007376 50 29            [24]  715 	jnc	00106$
                                    716 ;	tmk_core/protocol/report.c:187: if (keyboard_report->keys[i] == code) {
      007378 12 75 32         [24]  717 	lcall	_ak820_outline_0151
      00737B F5 82            [12]  718 	mov	dpl,a
      00737D E4               [12]  719 	clr	a
      00737E 3C               [12]  720 	addc	a, r4
      00737F F5 83            [12]  721 	mov	dph,a
      007381 E0               [24]  722 	movx	a,@dptr
      007382 FC               [12]  723 	mov	r4,a
      007383 90 08 5A         [24]  724 	mov	dptr,#_add_key_byte_PARM_2
      007386 E0               [24]  725 	movx	a,@dptr
      007387 FB               [12]  726 	mov	r3,a
      007388 EC               [12]  727 	mov	a,r4
      007389 B5 03 02         [24]  728 	cjne	a,ar3,00167$
      00738C 80 13            [24]  729 	sjmp	00106$
      00738E                        730 00167$:
                                    731 ;	tmk_core/protocol/report.c:190: if (empty == -1 && keyboard_report->keys[i] == 0) {
      00738E 90 08 5D         [24]  732 	mov	dptr,#_add_key_byte_empty_10000_145
      007391 E0               [24]  733 	movx	a,@dptr
      007392 FB               [12]  734 	mov	r3,a
      007393 BB FF 08         [24]  735 	cjne	r3,#0xff,00113$
      007396 EC               [12]  736 	mov	a,r4
      007397 70 05            [24]  737 	jnz	00113$
                                    738 ;	tmk_core/protocol/report.c:191: empty = i;
      007399 90 08 5D         [24]  739 	mov	dptr,#_add_key_byte_empty_10000_145
      00739C ED               [12]  740 	mov	a,r5
      00739D F0               [24]  741 	movx	@dptr,a
      00739E                        742 00113$:
                                    743 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      00739E 0D               [12]  744 	inc	r5
      00739F 80 CF            [24]  745 	sjmp	00112$
      0073A1                        746 00106$:
                                    747 ;	tmk_core/protocol/report.c:194: if (i == KEYBOARD_REPORT_KEYS) {
      0073A1 BD 06 1D         [24]  748 	cjne	r5,#0x06,00114$
                                    749 ;	tmk_core/protocol/report.c:195: if (empty != -1) {
      0073A4 90 08 5D         [24]  750 	mov	dptr,#_add_key_byte_empty_10000_145
      0073A7 E0               [24]  751 	movx	a,@dptr
      0073A8 FD               [12]  752 	mov	r5,a
      0073A9 BD FF 01         [24]  753 	cjne	r5,#0xff,00173$
      0073AC 22               [24]  754 	ret
      0073AD                        755 00173$:
                                    756 ;	tmk_core/protocol/report.c:196: keyboard_report->keys[empty] = code;
      0073AD 74 02            [12]  757 	mov	a,#0x02
      0073AF 12 49 73         [24]  758 	lcall	_ak820_outline_0141
      0073B2 ED               [12]  759 	mov	a,r5
      0073B3 2E               [12]  760 	add	a, r6
      0073B4 FD               [12]  761 	mov	r5,a
      0073B5 E4               [12]  762 	clr	a
      0073B6 3F               [12]  763 	addc	a, r7
      0073B7 FC               [12]  764 	mov	r4,a
      0073B8 90 08 5A         [24]  765 	mov	dptr,#_add_key_byte_PARM_2
      0073BB E0               [24]  766 	movx	a,@dptr
      0073BC 8D 82            [24]  767 	mov	dpl,r5
      0073BE 8C 83            [24]  768 	mov	dph,r4
      0073C0 F0               [24]  769 	movx	@dptr,a
      0073C1                        770 00114$:
                                    771 ;	tmk_core/protocol/report.c:200: }
      0073C1 22               [24]  772 	ret
                                    773 ;------------------------------------------------------------
                                    774 ;Allocation info for local variables in function 'del_key_byte'
                                    775 ;------------------------------------------------------------
                                    776 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    777 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    778 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    779 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    780 ;------------------------------------------------------------
                                    781 ;	tmk_core/protocol/report.c:206: void del_key_byte(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function del_key_byte
                                    784 ;	-----------------------------------------
      0073C2                        785 _del_key_byte:
      0073C2 12 38 44         [24]  786 	lcall	_ak820_outline_0109
      0073C5 90 08 5F         [24]  787 	mov	dptr,#_del_key_byte_report_arg_10000_156
      0073C8 12 38 49         [24]  788 	lcall	_ak820_outline_0110
                                    789 ;	tmk_core/protocol/report.c:207: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0073CB 90 08 5F         [24]  790 	mov	dptr,#_del_key_byte_report_arg_10000_156
      0073CE 12 37 FD         [24]  791 	lcall	_ak820_outline_0056
                                    792 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0073D1 7D 00            [12]  793 	mov	r5,#0x00
      0073D3                        794 00105$:
      0073D3 BD 06 00         [24]  795 	cjne	r5,#0x06,00131$
      0073D6                        796 00131$:
      0073D6 50 1A            [24]  797 	jnc	00107$
                                    798 ;	tmk_core/protocol/report.c:235: if (keyboard_report->keys[i] == code) {
      0073D8 12 75 32         [24]  799 	lcall	_ak820_outline_0151
      0073DB FB               [12]  800 	mov	r3,a
      0073DC E4               [12]  801 	clr	a
      0073DD 3C               [12]  802 	addc	a, r4
      0073DE 12 4E 75         [24]  803 	lcall	_ak820_outline_0060
      0073E1 90 08 5E         [24]  804 	mov	dptr,#_del_key_byte_PARM_2
      0073E4 E0               [24]  805 	movx	a,@dptr
      0073E5 F9               [12]  806 	mov	r1,a
      0073E6 EA               [12]  807 	mov	a,r2
      0073E7 B5 01 05         [24]  808 	cjne	a,ar1,00106$
                                    809 ;	tmk_core/protocol/report.c:236: keyboard_report->keys[i] = 0;
      0073EA 12 33 FC         [24]  810 	lcall	_ak820_outline_0127
      0073ED E4               [12]  811 	clr	a
      0073EE F0               [24]  812 	movx	@dptr,a
      0073EF                        813 00106$:
                                    814 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0073EF 0D               [12]  815 	inc	r5
      0073F0 80 E1            [24]  816 	sjmp	00105$
      0073F2                        817 00107$:
                                    818 ;	tmk_core/protocol/report.c:240: }
      0073F2 22               [24]  819 	ret
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'add_key_bit'
                                    822 ;------------------------------------------------------------
                                    823 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    824 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    825 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    826 ;------------------------------------------------------------
                                    827 ;	tmk_core/protocol/report.c:247: void add_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function add_key_bit
                                    830 ;	-----------------------------------------
      0073F3                        831 _add_key_bit:
      0073F3 12 38 44         [24]  832 	lcall	_ak820_outline_0109
      0073F6 90 08 62         [24]  833 	mov	dptr,#_add_key_bit_report_arg_10000_162
      0073F9 12 38 49         [24]  834 	lcall	_ak820_outline_0110
                                    835 ;	tmk_core/protocol/report.c:248: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0073FC 90 08 62         [24]  836 	mov	dptr,#_add_key_bit_report_arg_10000_162
      0073FF 12 37 FD         [24]  837 	lcall	_ak820_outline_0056
                                    838 ;	tmk_core/protocol/report.c:249: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      007402 90 08 61         [24]  839 	mov	dptr,#_add_key_bit_PARM_2
      007405 E0               [24]  840 	movx	a,@dptr
      007406 FD               [12]  841 	mov	r5,a
      007407 C4               [12]  842 	swap	a
      007408 23               [12]  843 	rl	a
      007409 54 1F            [12]  844 	anl	a,#0x1f
      00740B FC               [12]  845 	mov	r4,a
      00740C BC 1E 00         [24]  846 	cjne	r4,#0x1e,00112$
      00740F                        847 00112$:
      00740F 50 16            [24]  848 	jnc	00103$
                                    849 ;	tmk_core/protocol/report.c:250: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      007411 12 75 10         [24]  850 	lcall	_ak820_outline_0035
      007414 80 02            [24]  851 	sjmp	00115$
      007416                        852 00114$:
      007416 25 E0            [12]  853 	add	a,acc
      007418                        854 00115$:
      007418 D5 F0 FB         [24]  855 	djnz	b,00114$
      00741B FF               [12]  856 	mov	r7,a
      00741C 12 49 9F         [24]  857 	lcall	_ak820_outline_0189
      00741F E0               [24]  858 	movx	a,@dptr
      007420 42 07            [12]  859 	orl	ar7,a
      007422 12 49 9F         [24]  860 	lcall	_ak820_outline_0189
      007425 EF               [12]  861 	mov	a,r7
      007426 F0               [24]  862 	movx	@dptr,a
      007427                        863 00103$:
                                    864 ;	tmk_core/protocol/report.c:254: }
      007427 22               [24]  865 	ret
                                    866 ;------------------------------------------------------------
                                    867 ;Allocation info for local variables in function 'del_key_bit'
                                    868 ;------------------------------------------------------------
                                    869 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    870 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    871 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    872 ;------------------------------------------------------------
                                    873 ;	tmk_core/protocol/report.c:260: void del_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function del_key_bit
                                    876 ;	-----------------------------------------
      007428                        877 _del_key_bit:
      007428 12 38 44         [24]  878 	lcall	_ak820_outline_0109
      00742B 90 08 65         [24]  879 	mov	dptr,#_del_key_bit_report_arg_10000_167
      00742E 12 38 49         [24]  880 	lcall	_ak820_outline_0110
                                    881 ;	tmk_core/protocol/report.c:261: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007431 90 08 65         [24]  882 	mov	dptr,#_del_key_bit_report_arg_10000_167
      007434 12 37 FD         [24]  883 	lcall	_ak820_outline_0056
                                    884 ;	tmk_core/protocol/report.c:262: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      007437 90 08 64         [24]  885 	mov	dptr,#_del_key_bit_PARM_2
      00743A E0               [24]  886 	movx	a,@dptr
      00743B FD               [12]  887 	mov	r5,a
      00743C C4               [12]  888 	swap	a
      00743D 23               [12]  889 	rl	a
      00743E 54 1F            [12]  890 	anl	a,#0x1f
      007440 FC               [12]  891 	mov	r4,a
      007441 BC 1E 00         [24]  892 	cjne	r4,#0x1e,00112$
      007444                        893 00112$:
      007444 50 17            [24]  894 	jnc	00103$
                                    895 ;	tmk_core/protocol/report.c:263: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      007446 12 75 10         [24]  896 	lcall	_ak820_outline_0035
      007449 80 02            [24]  897 	sjmp	00115$
      00744B                        898 00114$:
      00744B 25 E0            [12]  899 	add	a,acc
      00744D                        900 00115$:
      00744D D5 F0 FB         [24]  901 	djnz	b,00114$
      007450 F4               [12]  902 	cpl	a
      007451 FF               [12]  903 	mov	r7,a
      007452 12 49 9F         [24]  904 	lcall	_ak820_outline_0189
      007455 E0               [24]  905 	movx	a,@dptr
      007456 52 07            [12]  906 	anl	ar7,a
      007458 12 49 9F         [24]  907 	lcall	_ak820_outline_0189
      00745B EF               [12]  908 	mov	a,r7
      00745C F0               [24]  909 	movx	@dptr,a
      00745D                        910 00103$:
                                    911 ;	tmk_core/protocol/report.c:267: }
      00745D 22               [24]  912 	ret
                                    913 ;------------------------------------------------------------
                                    914 ;Allocation info for local variables in function 'add_key_to_report'
                                    915 ;------------------------------------------------------------
                                    916 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    917 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    918 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    919 ;------------------------------------------------------------
                                    920 ;	tmk_core/protocol/report.c:274: void add_key_to_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function add_key_to_report
                                    923 ;	-----------------------------------------
      00745E                        924 _add_key_to_report:
      00745E 12 38 44         [24]  925 	lcall	_ak820_outline_0109
      007461 90 08 68         [24]  926 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      007464 12 38 49         [24]  927 	lcall	_ak820_outline_0110
                                    928 ;	tmk_core/protocol/report.c:275: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007467 90 08 68         [24]  929 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      00746A 12 37 FD         [24]  930 	lcall	_ak820_outline_0056
                                    931 ;	tmk_core/protocol/report.c:277: if (keyboard_protocol && keymap_config.nkro) {
      00746D 90 0E 44         [24]  932 	mov	dptr,#_keyboard_protocol
      007470 E0               [24]  933 	movx	a,@dptr
      007471 60 13            [24]  934 	jz	00102$
      007473 90 0B 44         [24]  935 	mov	dptr,#_keymap_config
      007476 E0               [24]  936 	movx	a,@dptr
      007477 30 E7 0C         [24]  937 	jnb	acc.7,00102$
                                    938 ;	tmk_core/protocol/report.c:278: add_key_bit(keyboard_report, key);
      00747A 90 08 67         [24]  939 	mov	dptr,#_add_key_to_report_PARM_2
      00747D E0               [24]  940 	movx	a,@dptr
      00747E 90 08 61         [24]  941 	mov	dptr,#_add_key_bit_PARM_2
      007481 12 49 3E         [24]  942 	lcall	_ak820_outline_0063
                                    943 ;	tmk_core/protocol/report.c:279: return;
      007484 61 F3            [12]  944 	ajmp	_add_key_bit
      007486                        945 00102$:
                                    946 ;	tmk_core/protocol/report.c:282: add_key_byte(keyboard_report, key);
      007486 90 08 67         [24]  947 	mov	dptr,#_add_key_to_report_PARM_2
      007489 E0               [24]  948 	movx	a,@dptr
      00748A 90 08 5A         [24]  949 	mov	dptr,#_add_key_byte_PARM_2
      00748D 12 49 3E         [24]  950 	lcall	_ak820_outline_0063
                                    951 ;	tmk_core/protocol/report.c:283: }
      007490 61 59            [12]  952 	ajmp	_add_key_byte
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'del_key_from_report'
                                    955 ;------------------------------------------------------------
                                    956 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    957 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    958 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    959 ;------------------------------------------------------------
                                    960 ;	tmk_core/protocol/report.c:289: void del_key_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function del_key_from_report
                                    963 ;	-----------------------------------------
      007492                        964 _del_key_from_report:
      007492 12 38 44         [24]  965 	lcall	_ak820_outline_0109
      007495 90 08 6B         [24]  966 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      007498 12 38 49         [24]  967 	lcall	_ak820_outline_0110
                                    968 ;	tmk_core/protocol/report.c:290: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00749B 90 08 6B         [24]  969 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      00749E 12 37 FD         [24]  970 	lcall	_ak820_outline_0056
                                    971 ;	tmk_core/protocol/report.c:292: if (keyboard_protocol && keymap_config.nkro) {
      0074A1 90 0E 44         [24]  972 	mov	dptr,#_keyboard_protocol
      0074A4 E0               [24]  973 	movx	a,@dptr
      0074A5 60 13            [24]  974 	jz	00102$
      0074A7 90 0B 44         [24]  975 	mov	dptr,#_keymap_config
      0074AA E0               [24]  976 	movx	a,@dptr
      0074AB 30 E7 0C         [24]  977 	jnb	acc.7,00102$
                                    978 ;	tmk_core/protocol/report.c:293: del_key_bit(keyboard_report, key);
      0074AE 90 08 6A         [24]  979 	mov	dptr,#_del_key_from_report_PARM_2
      0074B1 E0               [24]  980 	movx	a,@dptr
      0074B2 90 08 64         [24]  981 	mov	dptr,#_del_key_bit_PARM_2
      0074B5 12 49 3E         [24]  982 	lcall	_ak820_outline_0063
                                    983 ;	tmk_core/protocol/report.c:294: return;
      0074B8 81 28            [24]  984 	ajmp	_del_key_bit
      0074BA                        985 00102$:
                                    986 ;	tmk_core/protocol/report.c:297: del_key_byte(keyboard_report, key);
      0074BA 90 08 6A         [24]  987 	mov	dptr,#_del_key_from_report_PARM_2
      0074BD E0               [24]  988 	movx	a,@dptr
      0074BE 90 08 5E         [24]  989 	mov	dptr,#_del_key_byte_PARM_2
      0074C1 12 49 3E         [24]  990 	lcall	_ak820_outline_0063
                                    991 ;	tmk_core/protocol/report.c:298: }
      0074C4 61 C2            [12]  992 	ajmp	_del_key_byte
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    995 ;------------------------------------------------------------
                                    996 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                    997 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                    998 ;------------------------------------------------------------
                                    999 ;	tmk_core/protocol/report.c:304: void clear_keys_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                   1000 ;	-----------------------------------------
                                   1001 ;	 function clear_keys_from_report
                                   1002 ;	-----------------------------------------
      0074C6                       1003 _clear_keys_from_report:
      0074C6 12 38 44         [24] 1004 	lcall	_ak820_outline_0109
      0074C9 90 08 6D         [24] 1005 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      0074CC 12 38 49         [24] 1006 	lcall	_ak820_outline_0110
                                   1007 ;	tmk_core/protocol/report.c:305: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0074CF 90 08 6D         [24] 1008 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      0074D2 12 37 FD         [24] 1009 	lcall	_ak820_outline_0056
                                   1010 ;	tmk_core/protocol/report.c:308: if (keyboard_protocol && keymap_config.nkro) {
      0074D5 90 0E 44         [24] 1011 	mov	dptr,#_keyboard_protocol
      0074D8 E0               [24] 1012 	movx	a,@dptr
      0074D9 60 1E            [24] 1013 	jz	00102$
      0074DB 90 0B 44         [24] 1014 	mov	dptr,#_keymap_config
      0074DE E0               [24] 1015 	movx	a,@dptr
      0074DF 30 E7 17         [24] 1016 	jnb	acc.7,00102$
                                   1017 ;	tmk_core/protocol/report.c:309: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      0074E2 74 02            [12] 1018 	mov	a,#0x02
      0074E4 12 49 93         [24] 1019 	lcall	_ak820_outline_0167
      0074E7 7B 00            [12] 1020 	mov	r3,#0x00
      0074E9 12 75 3C         [24] 1021 	lcall	_ak820_outline_0187
      0074EC 74 1E            [12] 1022 	mov	a,#0x1e
      0074EE 12 38 59         [24] 1023 	lcall	_ak820_outline_0129
      0074F1 12 38 54         [24] 1024 	lcall	_ak820_outline_0128
      0074F4 8B F0            [24] 1025 	mov	b, r3
                                   1026 ;	tmk_core/protocol/report.c:310: return;
      0074F6 02 BF B9         [24] 1027 	ljmp	_memset
      0074F9                       1028 00102$:
                                   1029 ;	tmk_core/protocol/report.c:313: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      0074F9 74 02            [12] 1030 	mov	a,#0x02
      0074FB 12 49 73         [24] 1031 	lcall	_ak820_outline_0141
      0074FE 7D 00            [12] 1032 	mov	r5,#0x00
      007500 12 75 3C         [24] 1033 	lcall	_ak820_outline_0187
      007503 74 06            [12] 1034 	mov	a,#0x06
      007505 F0               [24] 1035 	movx	@dptr,a
      007506 E4               [12] 1036 	clr	a
      007507 A3               [24] 1037 	inc	dptr
      007508 12 49 3E         [24] 1038 	lcall	_ak820_outline_0063
      00750B 8D F0            [24] 1039 	mov	b, r5
                                   1040 ;	tmk_core/protocol/report.c:314: }
      00750D 02 BF B9         [24] 1041 	ljmp	_memset
                                   1042 	.area CSEG    (CODE)
                                   1043 	.area CONST   (CODE)
                                   1044 	.area CONST   (CODE)
      00C0C8                       1045 _KEYCODE2CONSUMER_usages_10000_118:
      00C0C8 E2 00                 1046 	.byte #0xe2, #0x00	; 226
      00C0CA E9 00                 1047 	.byte #0xe9, #0x00	; 233
      00C0CC EA 00                 1048 	.byte #0xea, #0x00	; 234
      00C0CE B5 00                 1049 	.byte #0xb5, #0x00	; 181
      00C0D0 B6 00                 1050 	.byte #0xb6, #0x00	; 182
      00C0D2 B7 00                 1051 	.byte #0xb7, #0x00	; 183
      00C0D4 CD 00                 1052 	.byte #0xcd, #0x00	; 205
      00C0D6 83 01                 1053 	.byte #0x83, #0x01	; 387
      00C0D8 CC 00                 1054 	.byte #0xcc, #0x00	; 204
      00C0DA 8A 01                 1055 	.byte #0x8a, #0x01	; 394
      00C0DC 92 01                 1056 	.byte #0x92, #0x01	; 402
      00C0DE 94 01                 1057 	.byte #0x94, #0x01	; 404
      00C0E0 21 02                 1058 	.byte #0x21, #0x02	; 545
      00C0E2 23 02                 1059 	.byte #0x23, #0x02	; 547
      00C0E4 24 02                 1060 	.byte #0x24, #0x02	; 548
      00C0E6 25 02                 1061 	.byte #0x25, #0x02	; 549
      00C0E8 26 02                 1062 	.byte #0x26, #0x02	; 550
      00C0EA 27 02                 1063 	.byte #0x27, #0x02	; 551
      00C0EC 2A 02                 1064 	.byte #0x2a, #0x02	; 554
      00C0EE B3 00                 1065 	.byte #0xb3, #0x00	; 179
      00C0F0 B4 00                 1066 	.byte #0xb4, #0x00	; 180
      00C0F2 6F 00                 1067 	.byte #0x6f, #0x00	; 111
      00C0F4 70 00                 1068 	.byte #0x70, #0x00	; 112
      00C0F6 9F 01                 1069 	.byte #0x9f, #0x01	; 415
      00C0F8 CB 01                 1070 	.byte #0xcb, #0x01	; 459
      00C0FA 9F 02                 1071 	.byte #0x9f, #0x02	; 671
      00C0FC A0 02                 1072 	.byte #0xa0, #0x02	; 672
                                   1073 	.area CSEG    (CODE)
                                   1074 	.area XINIT   (CODE)
                                   1075 	.area CABS    (ABS,CODE)
                                   1076 
                                   1077 ; Experimental exact instruction outlining.
                                   1078 	.globl _ak820_outline_0035
                                   1079 	.globl _ak820_outline_0056
                                   1080 	.globl _ak820_outline_0060
                                   1081 	.globl _ak820_outline_0063
                                   1082 	.globl _ak820_outline_0109
                                   1083 	.globl _ak820_outline_0110
                                   1084 	.globl _ak820_outline_0111
                                   1085 	.globl _ak820_outline_0127
                                   1086 	.globl _ak820_outline_0128
                                   1087 	.globl _ak820_outline_0129
                                   1088 	.globl _ak820_outline_0134
                                   1089 	.globl _ak820_outline_0141
                                   1090 	.globl _ak820_outline_0151
                                   1091 	.globl _ak820_outline_0167
                                   1092 	.globl _ak820_outline_0187
                                   1093 	.globl _ak820_outline_0189
                                   1094 
                                   1095 	.area CSEG (CODE)
                                   1096 ; function ak820_outline_0035
      007510                       1097 _ak820_outline_0035:
      007510 74 02            [12] 1098 	mov	a,#0x02
      007512 2E               [12] 1099 	add	a,r6
      007513 FE               [12] 1100 	mov	r6,a
      007514 E4               [12] 1101 	clr	a
      007515 3F               [12] 1102 	addc	a,r7
      007516 FF               [12] 1103 	mov	r7,a
      007517 EC               [12] 1104 	mov	a,r4
      007518 2E               [12] 1105 	add	a,r6
      007519 FC               [12] 1106 	mov	r4,a
      00751A E4               [12] 1107 	clr	a
      00751B 3F               [12] 1108 	addc	a,r7
      00751C FB               [12] 1109 	mov	r3,a
      00751D 74 07            [12] 1110 	mov	a,#0x07
      00751F 5D               [12] 1111 	anl	a,r5
      007520 F5 F0            [12] 1112 	mov	b,a
      007522 05 F0            [12] 1113 	inc	b
      007524 74 01            [12] 1114 	mov	a,#0x01
      007526 22               [24] 1115 	ret
                                   1116 
                                   1117 	.area CSEG (CODE)
                                   1118 ; function ak820_outline_0134
      007527                       1119 _ak820_outline_0134:
      007527 F4               [12] 1120 	cpl	a
      007528 24 01            [12] 1121 	add	a,#0x01
      00752A C5 F0            [12] 1122 	xch	a,b
      00752C F4               [12] 1123 	cpl	a
      00752D 34 00            [12] 1124 	addc	a,#0x00
      00752F C5 F0            [12] 1125 	xch	a,b
      007531 22               [24] 1126 	ret
                                   1127 
                                   1128 	.area CSEG (CODE)
                                   1129 ; function ak820_outline_0151
      007532                       1130 _ak820_outline_0151:
      007532 74 02            [12] 1131 	mov	a,#0x02
      007534 2E               [12] 1132 	add	a,r6
      007535 FB               [12] 1133 	mov	r3,a
      007536 E4               [12] 1134 	clr	a
      007537 3F               [12] 1135 	addc	a,r7
      007538 FC               [12] 1136 	mov	r4,a
      007539 ED               [12] 1137 	mov	a,r5
      00753A 2B               [12] 1138 	add	a,r3
      00753B 22               [24] 1139 	ret
                                   1140 
                                   1141 	.area CSEG (CODE)
                                   1142 ; function ak820_outline_0187
      00753C                       1143 _ak820_outline_0187:
      00753C 90 0E 37         [24] 1144 	mov	dptr,#_memset_PARM_2
      00753F E4               [12] 1145 	clr	a
      007540 F0               [24] 1146 	movx	@dptr,a
      007541 90 0E 38         [24] 1147 	mov	dptr,#_memset_PARM_3
      007544 22               [24] 1148 	ret
