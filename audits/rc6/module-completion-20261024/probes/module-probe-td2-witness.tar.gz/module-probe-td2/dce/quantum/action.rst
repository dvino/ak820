                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_tap_dance_cancel
                                     21 	.globl _ak820_tap_dance_before
                                     22 	.globl _pre_process_record_quantum
                                     23 	.globl _get_record_keycode
                                     24 	.globl _repeat_key_cancel
                                     25 	.globl _clear_owned_usages
                                     26 	.globl _owned_usage_key
                                     27 	.globl _clear_owned_keys
                                     28 	.globl _del_owned_key
                                     29 	.globl _add_owned_key
                                     30 	.globl _clear_owned_mods
                                     31 	.globl _del_owned_weak_mods
                                     32 	.globl _add_owned_weak_mods
                                     33 	.globl _del_owned_mods
                                     34 	.globl _add_owned_mods
                                     35 	.globl _clear_weak_mods
                                     36 	.globl _clear_mods
                                     37 	.globl _send_keyboard_report
                                     38 	.globl _layer_hold_clear
                                     39 	.globl _layer_hold_off
                                     40 	.globl _layer_hold_on
                                     41 	.globl _ak820_resolve_key
                                     42 	.globl _layer_xor
                                     43 	.globl _layer_and
                                     44 	.globl _layer_or
                                     45 	.globl _layer_off
                                     46 	.globl _layer_on
                                     47 	.globl _layer_move
                                     48 	.globl _layer_clear
                                     49 	.globl _layer_state_set
                                     50 	.globl _default_layer_xor
                                     51 	.globl _default_layer_and
                                     52 	.globl _default_layer_or
                                     53 	.globl _default_layer_set
                                     54 	.globl _post_process_record_quantum
                                     55 	.globl _process_record_quantum
                                     56 	.globl _action_for_keycode
                                     57 	.globl _mDelaymS
                                     58 	.globl _host_consumer_send
                                     59 	.globl _host_system_send
                                     60 	.globl _host_keyboard_leds
                                     61 	.globl _led_set
                                     62 	.globl _clear_keys_from_report
                                     63 	.globl ___memcpy
                                     64 	.globl _ADC_START
                                     65 	.globl _S0_R_FIFO
                                     66 	.globl _S0_T_FIFO
                                     67 	.globl _S0_FREE
                                     68 	.globl _S0_IF_BYTE
                                     69 	.globl _S0_IF_FIRST
                                     70 	.globl _S0_IF_OV
                                     71 	.globl _S0_FST_ACT
                                     72 	.globl _CP_RL2
                                     73 	.globl _C_T2
                                     74 	.globl _TR2
                                     75 	.globl _EXEN2
                                     76 	.globl _TCLK
                                     77 	.globl _RCLK
                                     78 	.globl _EXF2
                                     79 	.globl _CAP1F
                                     80 	.globl _TF2
                                     81 	.globl _RI
                                     82 	.globl _TI
                                     83 	.globl _RB8
                                     84 	.globl _TB8
                                     85 	.globl _REN
                                     86 	.globl _SM2
                                     87 	.globl _SM1
                                     88 	.globl _SM0
                                     89 	.globl _IT0
                                     90 	.globl _IE0
                                     91 	.globl _IT1
                                     92 	.globl _IE1
                                     93 	.globl _TR0
                                     94 	.globl _TF0
                                     95 	.globl _TR1
                                     96 	.globl _TF1
                                     97 	.globl _P4_0
                                     98 	.globl _P4_1
                                     99 	.globl _P4_2
                                    100 	.globl _P4_3
                                    101 	.globl _P4_4
                                    102 	.globl _P4_5
                                    103 	.globl _P4_6
                                    104 	.globl _RXD
                                    105 	.globl _TXD
                                    106 	.globl _INT0
                                    107 	.globl _INT1
                                    108 	.globl _T0
                                    109 	.globl _T1
                                    110 	.globl _MOSI1
                                    111 	.globl _MISO1
                                    112 	.globl _SCK1
                                    113 	.globl _P3_0
                                    114 	.globl _P3_1
                                    115 	.globl _P3_2
                                    116 	.globl _P3_3
                                    117 	.globl _P3_4
                                    118 	.globl _P3_5
                                    119 	.globl _P3_6
                                    120 	.globl _P3_7
                                    121 	.globl _CAP1_
                                    122 	.globl _T2_
                                    123 	.globl _CAP2_
                                    124 	.globl _T2EX_
                                    125 	.globl _RXD1
                                    126 	.globl _TXD1
                                    127 	.globl _P2_0
                                    128 	.globl _P2_1
                                    129 	.globl _P2_2
                                    130 	.globl _P2_3
                                    131 	.globl _P2_4
                                    132 	.globl _P2_5
                                    133 	.globl _P2_6
                                    134 	.globl _P2_7
                                    135 	.globl _AIN0
                                    136 	.globl _AIN1
                                    137 	.globl _AIN2
                                    138 	.globl _AIN3
                                    139 	.globl _AIN4
                                    140 	.globl _AIN5
                                    141 	.globl _AIN6
                                    142 	.globl _AIN7
                                    143 	.globl _CAP1
                                    144 	.globl _T2
                                    145 	.globl _CAP2
                                    146 	.globl _T2EX
                                    147 	.globl _INT0_
                                    148 	.globl _SCS
                                    149 	.globl _MOSI
                                    150 	.globl _MISO
                                    151 	.globl _SCK
                                    152 	.globl _RXD1_
                                    153 	.globl _TXD1_
                                    154 	.globl _P1_0
                                    155 	.globl _P1_1
                                    156 	.globl _P1_2
                                    157 	.globl _P1_3
                                    158 	.globl _P1_4
                                    159 	.globl _P1_5
                                    160 	.globl _P1_6
                                    161 	.globl _P1_7
                                    162 	.globl _AIN8
                                    163 	.globl _AIN9
                                    164 	.globl _AIN10
                                    165 	.globl _AIN11
                                    166 	.globl _AIN12
                                    167 	.globl _AIN13
                                    168 	.globl _RXD_
                                    169 	.globl _TXD_
                                    170 	.globl _SCL0
                                    171 	.globl _SDA0
                                    172 	.globl _P0_0
                                    173 	.globl _P0_1
                                    174 	.globl _P0_2
                                    175 	.globl _P0_3
                                    176 	.globl _P0_4
                                    177 	.globl _P0_5
                                    178 	.globl _P0_6
                                    179 	.globl _P0_7
                                    180 	.globl _IE_SPI0
                                    181 	.globl _IE_USB
                                    182 	.globl _IE_ADC
                                    183 	.globl _IE_UART1
                                    184 	.globl _IE_PWM_I2C
                                    185 	.globl _IE_GPIO
                                    186 	.globl _IE_WDOG
                                    187 	.globl _PX0
                                    188 	.globl _PT0
                                    189 	.globl _PX1
                                    190 	.globl _PT1
                                    191 	.globl _PS
                                    192 	.globl _PT2
                                    193 	.globl _PL_FLAG
                                    194 	.globl _PH_FLAG
                                    195 	.globl _EX0
                                    196 	.globl _ET0
                                    197 	.globl _EX1
                                    198 	.globl _ET1
                                    199 	.globl _ES
                                    200 	.globl _ET2
                                    201 	.globl _E_DIS
                                    202 	.globl _EA
                                    203 	.globl _P
                                    204 	.globl _F1
                                    205 	.globl _OV
                                    206 	.globl _RS0
                                    207 	.globl _RS1
                                    208 	.globl _F0
                                    209 	.globl _AC
                                    210 	.globl _CY
                                    211 	.globl _I2CS_INT_ST
                                    212 	.globl _I2CX_INT
                                    213 	.globl _LED_STATUS
                                    214 	.globl _LED_DMA_H
                                    215 	.globl _LED_DMA_L
                                    216 	.globl _LED_DMA
                                    217 	.globl _LED_PWM_OE
                                    218 	.globl _LED_COMMON
                                    219 	.globl _ADC_CHAN
                                    220 	.globl _ADC_DAT_H
                                    221 	.globl _ADC_DAT_L
                                    222 	.globl _ADC_DAT
                                    223 	.globl _ADC_CTRL
                                    224 	.globl _SPI1_CK_SE
                                    225 	.globl _SPI1_CTRL
                                    226 	.globl _SPI1_DATA
                                    227 	.globl _SPI1_STAT
                                    228 	.globl _SIF1
                                    229 	.globl _SBAUD1
                                    230 	.globl _SBUF1
                                    231 	.globl _SCON1
                                    232 	.globl _SPI0_SETUP
                                    233 	.globl _SPI0_CK_SE
                                    234 	.globl _SPI0_CTRL
                                    235 	.globl _SPI0_DATA
                                    236 	.globl _SPI0_STAT
                                    237 	.globl _T2CAP1H
                                    238 	.globl _T2CAP1L
                                    239 	.globl _T2CAP1
                                    240 	.globl _TH2
                                    241 	.globl _TL2
                                    242 	.globl _T2COUNT
                                    243 	.globl _RCAP2H
                                    244 	.globl _RCAP2L
                                    245 	.globl _RCAP2
                                    246 	.globl _T2MOD
                                    247 	.globl _T2CON
                                    248 	.globl _SBUF
                                    249 	.globl _SCON
                                    250 	.globl _TH1
                                    251 	.globl _TH0
                                    252 	.globl _TL1
                                    253 	.globl _TL0
                                    254 	.globl _TMOD
                                    255 	.globl _TCON
                                    256 	.globl _XBUS_AUX
                                    257 	.globl _P7
                                    258 	.globl _P6_DIR
                                    259 	.globl _P6_OUT_PU
                                    260 	.globl _P6_IN
                                    261 	.globl _P5_DIR
                                    262 	.globl _P5_OUT_PU
                                    263 	.globl _P5_IN
                                    264 	.globl _P4_LED_KEY
                                    265 	.globl _P4_DIR_PU
                                    266 	.globl _P4_MOD_OC
                                    267 	.globl _P4
                                    268 	.globl _P3_DIR_PU
                                    269 	.globl _P3_MOD_OC
                                    270 	.globl _P3
                                    271 	.globl _P2_DIR_PU
                                    272 	.globl _P2_MOD_OC
                                    273 	.globl _P2
                                    274 	.globl _P1_DIR_PU
                                    275 	.globl _P1_MOD_OC
                                    276 	.globl _P1
                                    277 	.globl _P0_DIR_PU
                                    278 	.globl _P0_MOD_OC
                                    279 	.globl _P0
                                    280 	.globl _ROM_CTRL
                                    281 	.globl _ROM_DATA_HH
                                    282 	.globl _ROM_DATA_HL
                                    283 	.globl _ROM_DATA_HI
                                    284 	.globl _ROM_ADDR_H
                                    285 	.globl _ROM_ADDR_L
                                    286 	.globl _ROM_ADDR
                                    287 	.globl _GPIO_IE
                                    288 	.globl _IP_EX
                                    289 	.globl _IE_EX
                                    290 	.globl _IP
                                    291 	.globl _IE
                                    292 	.globl _WDOG_COUNT
                                    293 	.globl _RESET_KEEP
                                    294 	.globl _WAKE_CTRL
                                    295 	.globl _CLOCK_CFG
                                    296 	.globl _POWER_CFG
                                    297 	.globl _PCON
                                    298 	.globl _GLOBAL_CFG
                                    299 	.globl _SAFE_MOD
                                    300 	.globl _DPH
                                    301 	.globl _DPL
                                    302 	.globl _SP
                                    303 	.globl _A_INV
                                    304 	.globl _B
                                    305 	.globl _ACC
                                    306 	.globl _PSW
                                    307 	.globl _disable_action_cache
                                    308 	.globl _tap_code_delay_PARM_2
                                    309 	.globl _process_action_PARM_2
                                    310 	.globl _action_exec_PARM_1
                                    311 	.globl _tp_buttons
                                    312 	.globl _action_exec
                                    313 	.globl _ak820_action_exec
                                    314 	.globl _process_record
                                    315 	.globl _process_record_handler
                                    316 	.globl _process_action
                                    317 	.globl _register_code
                                    318 	.globl _unregister_code
                                    319 	.globl _tap_code_delay
                                    320 	.globl _tap_code
                                    321 	.globl _register_mods
                                    322 	.globl _unregister_mods
                                    323 	.globl _register_weak_mods
                                    324 	.globl _unregister_weak_mods
                                    325 	.globl _clear_keyboard
                                    326 	.globl _clear_keyboard_but_mods
                                    327 	.globl _clear_keyboard_but_mods_and_keys
                                    328 ;--------------------------------------------------------
                                    329 ; special function registers
                                    330 ;--------------------------------------------------------
                                    331 	.area RSEG    (ABS,DATA)
      000000                        332 	.org 0x0000
                           0000D0   333 _PSW	=	0x00d0
                           0000E0   334 _ACC	=	0x00e0
                           0000F0   335 _B	=	0x00f0
                           0000FD   336 _A_INV	=	0x00fd
                           000081   337 _SP	=	0x0081
                           000082   338 _DPL	=	0x0082
                           000083   339 _DPH	=	0x0083
                           0000A1   340 _SAFE_MOD	=	0x00a1
                           0000B1   341 _GLOBAL_CFG	=	0x00b1
                           000087   342 _PCON	=	0x0087
                           0000BA   343 _POWER_CFG	=	0x00ba
                           0000B9   344 _CLOCK_CFG	=	0x00b9
                           0000A9   345 _WAKE_CTRL	=	0x00a9
                           0000FE   346 _RESET_KEEP	=	0x00fe
                           0000FF   347 _WDOG_COUNT	=	0x00ff
                           0000A8   348 _IE	=	0x00a8
                           0000B8   349 _IP	=	0x00b8
                           0000E8   350 _IE_EX	=	0x00e8
                           0000E9   351 _IP_EX	=	0x00e9
                           0000B2   352 _GPIO_IE	=	0x00b2
                           008584   353 _ROM_ADDR	=	0x8584
                           000084   354 _ROM_ADDR_L	=	0x0084
                           000085   355 _ROM_ADDR_H	=	0x0085
                           008F8E   356 _ROM_DATA_HI	=	0x8f8e
                           00008E   357 _ROM_DATA_HL	=	0x008e
                           00008F   358 _ROM_DATA_HH	=	0x008f
                           000086   359 _ROM_CTRL	=	0x0086
                           000080   360 _P0	=	0x0080
                           0000C4   361 _P0_MOD_OC	=	0x00c4
                           0000C5   362 _P0_DIR_PU	=	0x00c5
                           000090   363 _P1	=	0x0090
                           000092   364 _P1_MOD_OC	=	0x0092
                           000093   365 _P1_DIR_PU	=	0x0093
                           0000A0   366 _P2	=	0x00a0
                           000094   367 _P2_MOD_OC	=	0x0094
                           000095   368 _P2_DIR_PU	=	0x0095
                           0000B0   369 _P3	=	0x00b0
                           000096   370 _P3_MOD_OC	=	0x0096
                           000097   371 _P3_DIR_PU	=	0x0097
                           0000C0   372 _P4	=	0x00c0
                           0000C2   373 _P4_MOD_OC	=	0x00c2
                           0000C3   374 _P4_DIR_PU	=	0x00c3
                           0000C1   375 _P4_LED_KEY	=	0x00c1
                           0000AA   376 _P5_IN	=	0x00aa
                           0000AB   377 _P5_OUT_PU	=	0x00ab
                           0000AC   378 _P5_DIR	=	0x00ac
                           0000AD   379 _P6_IN	=	0x00ad
                           0000AE   380 _P6_OUT_PU	=	0x00ae
                           0000AF   381 _P6_DIR	=	0x00af
                           0000F1   382 _P7	=	0x00f1
                           0000A2   383 _XBUS_AUX	=	0x00a2
                           000088   384 _TCON	=	0x0088
                           000089   385 _TMOD	=	0x0089
                           00008A   386 _TL0	=	0x008a
                           00008B   387 _TL1	=	0x008b
                           00008C   388 _TH0	=	0x008c
                           00008D   389 _TH1	=	0x008d
                           000098   390 _SCON	=	0x0098
                           000099   391 _SBUF	=	0x0099
                           0000C8   392 _T2CON	=	0x00c8
                           0000C9   393 _T2MOD	=	0x00c9
                           00CBCA   394 _RCAP2	=	0xcbca
                           0000CA   395 _RCAP2L	=	0x00ca
                           0000CB   396 _RCAP2H	=	0x00cb
                           00CDCC   397 _T2COUNT	=	0xcdcc
                           0000CC   398 _TL2	=	0x00cc
                           0000CD   399 _TH2	=	0x00cd
                           00CFCE   400 _T2CAP1	=	0xcfce
                           0000CE   401 _T2CAP1L	=	0x00ce
                           0000CF   402 _T2CAP1H	=	0x00cf
                           0000F8   403 _SPI0_STAT	=	0x00f8
                           0000F9   404 _SPI0_DATA	=	0x00f9
                           0000FA   405 _SPI0_CTRL	=	0x00fa
                           0000FB   406 _SPI0_CK_SE	=	0x00fb
                           0000FC   407 _SPI0_SETUP	=	0x00fc
                           0000BC   408 _SCON1	=	0x00bc
                           0000BD   409 _SBUF1	=	0x00bd
                           0000BE   410 _SBAUD1	=	0x00be
                           0000BF   411 _SIF1	=	0x00bf
                           0000B4   412 _SPI1_STAT	=	0x00b4
                           0000B5   413 _SPI1_DATA	=	0x00b5
                           0000B6   414 _SPI1_CTRL	=	0x00b6
                           0000B7   415 _SPI1_CK_SE	=	0x00b7
                           0000F3   416 _ADC_CTRL	=	0x00f3
                           00F5F4   417 _ADC_DAT	=	0xf5f4
                           0000F4   418 _ADC_DAT_L	=	0x00f4
                           0000F5   419 _ADC_DAT_H	=	0x00f5
                           0000F6   420 _ADC_CHAN	=	0x00f6
                           0000A6   421 _LED_COMMON	=	0x00a6
                           0000A7   422 _LED_PWM_OE	=	0x00a7
                           00C7C6   423 _LED_DMA	=	0xc7c6
                           0000C6   424 _LED_DMA_L	=	0x00c6
                           0000C7   425 _LED_DMA_H	=	0x00c7
                           0000F7   426 _LED_STATUS	=	0x00f7
                           0000B3   427 _I2CX_INT	=	0x00b3
                           0000BB   428 _I2CS_INT_ST	=	0x00bb
                                    429 ;--------------------------------------------------------
                                    430 ; special function bits
                                    431 ;--------------------------------------------------------
                                    432 	.area RSEG    (ABS,DATA)
      000000                        433 	.org 0x0000
                           0000D7   434 _CY	=	0x00d7
                           0000D6   435 _AC	=	0x00d6
                           0000D5   436 _F0	=	0x00d5
                           0000D4   437 _RS1	=	0x00d4
                           0000D3   438 _RS0	=	0x00d3
                           0000D2   439 _OV	=	0x00d2
                           0000D1   440 _F1	=	0x00d1
                           0000D0   441 _P	=	0x00d0
                           0000AF   442 _EA	=	0x00af
                           0000AE   443 _E_DIS	=	0x00ae
                           0000AD   444 _ET2	=	0x00ad
                           0000AC   445 _ES	=	0x00ac
                           0000AB   446 _ET1	=	0x00ab
                           0000AA   447 _EX1	=	0x00aa
                           0000A9   448 _ET0	=	0x00a9
                           0000A8   449 _EX0	=	0x00a8
                           0000BF   450 _PH_FLAG	=	0x00bf
                           0000BE   451 _PL_FLAG	=	0x00be
                           0000BD   452 _PT2	=	0x00bd
                           0000BC   453 _PS	=	0x00bc
                           0000BB   454 _PT1	=	0x00bb
                           0000BA   455 _PX1	=	0x00ba
                           0000B9   456 _PT0	=	0x00b9
                           0000B8   457 _PX0	=	0x00b8
                           0000EF   458 _IE_WDOG	=	0x00ef
                           0000EE   459 _IE_GPIO	=	0x00ee
                           0000ED   460 _IE_PWM_I2C	=	0x00ed
                           0000EC   461 _IE_UART1	=	0x00ec
                           0000EB   462 _IE_ADC	=	0x00eb
                           0000E9   463 _IE_USB	=	0x00e9
                           0000E8   464 _IE_SPI0	=	0x00e8
                           000087   465 _P0_7	=	0x0087
                           000086   466 _P0_6	=	0x0086
                           000085   467 _P0_5	=	0x0085
                           000084   468 _P0_4	=	0x0084
                           000083   469 _P0_3	=	0x0083
                           000082   470 _P0_2	=	0x0082
                           000081   471 _P0_1	=	0x0081
                           000080   472 _P0_0	=	0x0080
                           000081   473 _SDA0	=	0x0081
                           000080   474 _SCL0	=	0x0080
                           000083   475 _TXD_	=	0x0083
                           000082   476 _RXD_	=	0x0082
                           000085   477 _AIN13	=	0x0085
                           000084   478 _AIN12	=	0x0084
                           000083   479 _AIN11	=	0x0083
                           000082   480 _AIN10	=	0x0082
                           000081   481 _AIN9	=	0x0081
                           000080   482 _AIN8	=	0x0080
                           000097   483 _P1_7	=	0x0097
                           000096   484 _P1_6	=	0x0096
                           000095   485 _P1_5	=	0x0095
                           000094   486 _P1_4	=	0x0094
                           000093   487 _P1_3	=	0x0093
                           000092   488 _P1_2	=	0x0092
                           000091   489 _P1_1	=	0x0091
                           000090   490 _P1_0	=	0x0090
                           000097   491 _TXD1_	=	0x0097
                           000096   492 _RXD1_	=	0x0096
                           000097   493 _SCK	=	0x0097
                           000096   494 _MISO	=	0x0096
                           000095   495 _MOSI	=	0x0095
                           000094   496 _SCS	=	0x0094
                           000092   497 _INT0_	=	0x0092
                           000091   498 _T2EX	=	0x0091
                           000091   499 _CAP2	=	0x0091
                           000090   500 _T2	=	0x0090
                           000090   501 _CAP1	=	0x0090
                           000097   502 _AIN7	=	0x0097
                           000096   503 _AIN6	=	0x0096
                           000095   504 _AIN5	=	0x0095
                           000094   505 _AIN4	=	0x0094
                           000093   506 _AIN3	=	0x0093
                           000092   507 _AIN2	=	0x0092
                           000091   508 _AIN1	=	0x0091
                           000090   509 _AIN0	=	0x0090
                           0000A7   510 _P2_7	=	0x00a7
                           0000A6   511 _P2_6	=	0x00a6
                           0000A5   512 _P2_5	=	0x00a5
                           0000A4   513 _P2_4	=	0x00a4
                           0000A3   514 _P2_3	=	0x00a3
                           0000A2   515 _P2_2	=	0x00a2
                           0000A1   516 _P2_1	=	0x00a1
                           0000A0   517 _P2_0	=	0x00a0
                           0000A7   518 _TXD1	=	0x00a7
                           0000A6   519 _RXD1	=	0x00a6
                           0000A5   520 _T2EX_	=	0x00a5
                           0000A5   521 _CAP2_	=	0x00a5
                           0000A4   522 _T2_	=	0x00a4
                           0000A4   523 _CAP1_	=	0x00a4
                           0000B7   524 _P3_7	=	0x00b7
                           0000B6   525 _P3_6	=	0x00b6
                           0000B5   526 _P3_5	=	0x00b5
                           0000B4   527 _P3_4	=	0x00b4
                           0000B3   528 _P3_3	=	0x00b3
                           0000B2   529 _P3_2	=	0x00b2
                           0000B1   530 _P3_1	=	0x00b1
                           0000B0   531 _P3_0	=	0x00b0
                           0000B7   532 _SCK1	=	0x00b7
                           0000B6   533 _MISO1	=	0x00b6
                           0000B5   534 _MOSI1	=	0x00b5
                           0000B5   535 _T1	=	0x00b5
                           0000B4   536 _T0	=	0x00b4
                           0000B3   537 _INT1	=	0x00b3
                           0000B2   538 _INT0	=	0x00b2
                           0000B1   539 _TXD	=	0x00b1
                           0000B0   540 _RXD	=	0x00b0
                           0000C6   541 _P4_6	=	0x00c6
                           0000C5   542 _P4_5	=	0x00c5
                           0000C4   543 _P4_4	=	0x00c4
                           0000C3   544 _P4_3	=	0x00c3
                           0000C2   545 _P4_2	=	0x00c2
                           0000C1   546 _P4_1	=	0x00c1
                           0000C0   547 _P4_0	=	0x00c0
                           00008F   548 _TF1	=	0x008f
                           00008E   549 _TR1	=	0x008e
                           00008D   550 _TF0	=	0x008d
                           00008C   551 _TR0	=	0x008c
                           00008B   552 _IE1	=	0x008b
                           00008A   553 _IT1	=	0x008a
                           000089   554 _IE0	=	0x0089
                           000088   555 _IT0	=	0x0088
                           00009F   556 _SM0	=	0x009f
                           00009E   557 _SM1	=	0x009e
                           00009D   558 _SM2	=	0x009d
                           00009C   559 _REN	=	0x009c
                           00009B   560 _TB8	=	0x009b
                           00009A   561 _RB8	=	0x009a
                           000099   562 _TI	=	0x0099
                           000098   563 _RI	=	0x0098
                           0000CF   564 _TF2	=	0x00cf
                           0000CF   565 _CAP1F	=	0x00cf
                           0000CE   566 _EXF2	=	0x00ce
                           0000CD   567 _RCLK	=	0x00cd
                           0000CC   568 _TCLK	=	0x00cc
                           0000CB   569 _EXEN2	=	0x00cb
                           0000CA   570 _TR2	=	0x00ca
                           0000C9   571 _C_T2	=	0x00c9
                           0000C8   572 _CP_RL2	=	0x00c8
                           0000FF   573 _S0_FST_ACT	=	0x00ff
                           0000FE   574 _S0_IF_OV	=	0x00fe
                           0000FD   575 _S0_IF_FIRST	=	0x00fd
                           0000FC   576 _S0_IF_BYTE	=	0x00fc
                           0000FB   577 _S0_FREE	=	0x00fb
                           0000FA   578 _S0_T_FIFO	=	0x00fa
                           0000F8   579 _S0_R_FIFO	=	0x00f8
                           0000F7   580 _ADC_START	=	0x00f7
                                    581 ;--------------------------------------------------------
                                    582 ; overlayable register banks
                                    583 ;--------------------------------------------------------
                                    584 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        585 	.ds 8
                                    586 ;--------------------------------------------------------
                                    587 ; internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area DSEG    (DATA)
      000017                        590 _process_action_sloc0_1_0:
      000017                        591 	.ds 1
                                    592 ;--------------------------------------------------------
                                    593 ; overlayable items in internal ram
                                    594 ;--------------------------------------------------------
                                    595 ;--------------------------------------------------------
                                    596 ; indirectly addressable internal ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area ISEG    (DATA)
                                    599 ;--------------------------------------------------------
                                    600 ; absolute internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area IABS    (ABS,DATA)
                                    603 	.area IABS    (ABS,DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; bit data
                                    606 ;--------------------------------------------------------
                                    607 	.area BSEG    (BIT)
      000022                        608 _process_action_sloc1_1_0:
      000022                        609 	.ds 1
                                    610 ;--------------------------------------------------------
                                    611 ; paged external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area PSEG    (PAG,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; uninitialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XSEG    (XDATA)
      0008BE                        618 _tp_buttons::
      0008BE                        619 	.ds 2
      0008C0                        620 _action_exec_PARM_1:
      0008C0                        621 	.ds 6
      0008C6                        622 _action_exec_record_10001_632:
      0008C6                        623 	.ds 9
      0008CF                        624 _ak820_action_exec_event_10000_636:
      0008CF                        625 	.ds 2
      0008D1                        626 _ak820_action_exec_snapshot_10000_637:
      0008D1                        627 	.ds 6
      0008D7                        628 _process_record_record_10000_640:
      0008D7                        629 	.ds 3
      0008DA                        630 _process_record_handler_record_argument_10000_648:
      0008DA                        631 	.ds 3
      0008DD                        632 _process_record_handler_action_10000_649:
      0008DD                        633 	.ds 2
      0008DF                        634 _process_action_PARM_2:
      0008DF                        635 	.ds 2
      0008E1                        636 _process_action_record_argument_10000_660:
      0008E1                        637 	.ds 3
      0008E4                        638 _process_action_on_40000_683:
      0008E4                        639 	.ds 1
      0008E5                        640 _register_code_code_10000_717:
      0008E5                        641 	.ds 1
      0008E6                        642 _unregister_code_code_10000_731:
      0008E6                        643 	.ds 1
      0008E7                        644 _tap_code_delay_PARM_2:
      0008E7                        645 	.ds 2
      0008E9                        646 _tap_code_delay_code_10000_744:
      0008E9                        647 	.ds 1
      0008EA                        648 _tap_code_code_10000_751:
      0008EA                        649 	.ds 1
      0008EB                        650 _register_mods_mods_10000_753:
      0008EB                        651 	.ds 1
      0008EC                        652 _unregister_mods_mods_10000_757:
      0008EC                        653 	.ds 1
      0008ED                        654 _register_weak_mods_mods_10000_761:
      0008ED                        655 	.ds 1
      0008EE                        656 _unregister_weak_mods_mods_10000_765:
      0008EE                        657 	.ds 1
                                    658 ;--------------------------------------------------------
                                    659 ; absolute external ram data
                                    660 ;--------------------------------------------------------
                                    661 	.area XABS    (ABS,XDATA)
                                    662 ;--------------------------------------------------------
                                    663 ; initialized external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XISEG   (XDATA)
      000E94                        666 _disable_action_cache::
      000E94                        667 	.ds 1
                                    668 	.area HOME    (CODE)
                                    669 	.area GSINIT0 (CODE)
                                    670 	.area GSINIT1 (CODE)
                                    671 	.area GSINIT2 (CODE)
                                    672 	.area GSINIT3 (CODE)
                                    673 	.area GSINIT4 (CODE)
                                    674 	.area GSINIT5 (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area CSEG    (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; global & static initialisations
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; Home
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area HOME    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; code
                                    692 ;--------------------------------------------------------
                                    693 	.area CSEG    (CODE)
                                    694 ;------------------------------------------------------------
                                    695 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    696 ;------------------------------------------------------------
                                    697 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    698 ;------------------------------------------------------------
                                    699 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    700 ;	-----------------------------------------
                           000007   701 	ar7 = 0x07
                           000006   702 	ar6 = 0x06
                           000005   703 	ar5 = 0x05
                           000004   704 	ar4 = 0x04
                           000003   705 	ar3 = 0x03
                           000002   706 	ar2 = 0x02
                           000001   707 	ar1 = 0x01
                           000000   708 	ar0 = 0x00
                                    709 ;	 function action_exec
                                    710 ;	-----------------------------------------
      007936                        711 _action_exec:
                                    712 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      007936 90 08 C2         [24]  713 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007939 12 37 E7         [24]  714 	lcall	_ak820_outline_0005
      00793C 12 35 FF         [24]  715 	lcall	_ak820_combo_tick
                                    716 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      00793F 90 08 C0         [24]  717 	mov	dptr,#_action_exec_PARM_1
      007942 12 4D C0         [24]  718 	lcall	_ak820_tapping_before
      007945 E5 82            [12]  719 	mov	a, dpl
      007947 70 01            [24]  720 	jnz	00102$
      007949 22               [24]  721 	ret
      00794A                        722 00102$:
                                    723 ;	quantum/action.c:106: if (!ak820_tap_dance_before(&event)) return;
      00794A 90 08 C0         [24]  724 	mov	dptr,#_action_exec_PARM_1
      00794D 12 48 33         [24]  725 	lcall	_ak820_tap_dance_before
      007950 E5 82            [12]  726 	mov	a, dpl
      007952 70 01            [24]  727 	jnz	00104$
      007954 22               [24]  728 	ret
      007955                        729 00104$:
                                    730 ;	quantum/action.c:125: if (event.pressed) {
      007955 90 08 C5         [24]  731 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007958 E0               [24]  732 	movx	a,@dptr
      007959 60 03            [24]  733 	jz	00106$
                                    734 ;	quantum/action.c:127: clear_weak_mods();
      00795B 12 89 79         [24]  735 	lcall	_clear_weak_mods
      00795E                        736 00106$:
                                    737 ;	quantum/action.c:139: record.event = event;
      00795E 90 0E 73         [24]  738 	mov	dptr,#___memcpy_PARM_2
      007961 74 C0            [12]  739 	mov	a,#_action_exec_PARM_1
      007963 F0               [24]  740 	movx	@dptr,a
      007964 74 08            [12]  741 	mov	a,#(_action_exec_PARM_1 >> 8)
      007966 12 38 51         [24]  742 	lcall	_ak820_outline_0074
      007969 12 80 09         [24]  743 	lcall	_ak820_outline_0073
      00796C 90 08 C6         [24]  744 	mov	dptr,#_action_exec_record_10001_632
      00796F F5 F0            [12]  745 	mov	b,a
      007971 12 C2 AA         [24]  746 	lcall	___memcpy
                                    747 ;	quantum/action.c:141: record.tap.count = 0;
      007974 90 08 CC         [24]  748 	mov	dptr,#(_action_exec_record_10001_632 + 0x0006)
      007977 E0               [24]  749 	movx	a,@dptr
      007978 54 0F            [12]  750 	anl	a,#0x0f
      00797A F0               [24]  751 	movx	@dptr,a
                                    752 ;	quantum/action.c:146: record.keycode = 0;
      00797B 90 08 CD         [24]  753 	mov	dptr,#(_action_exec_record_10001_632 + 0x0007)
      00797E 12 58 A4         [24]  754 	lcall	_ak820_outline_0156
                                    755 ;	quantum/action.c:177: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007981 90 08 CA         [24]  756 	mov	dptr,#(_action_exec_record_10001_632 + 0x0004)
      007984 E0               [24]  757 	movx	a,@dptr
      007985 60 0D            [24]  758 	jz	00109$
      007987 90 08 C6         [24]  759 	mov	dptr,#_action_exec_record_10001_632
      00798A 75 F0 00         [24]  760 	mov	b, #0x00
      00798D 12 A8 88         [24]  761 	lcall	_pre_process_record_quantum
      007990 E5 82            [12]  762 	mov	a, dpl
      007992 60 13            [24]  763 	jz	00112$
      007994                        764 00109$:
                                    765 ;	quantum/action.c:179: if (!ak820_tapping_process(&record)) return;
      007994 90 08 C6         [24]  766 	mov	dptr,#_action_exec_record_10001_632
      007997 12 4E A5         [24]  767 	lcall	_ak820_tapping_process
      00799A E5 82            [12]  768 	mov	a, dpl
      00799C 70 01            [24]  769 	jnz	00108$
      00799E 22               [24]  770 	ret
      00799F                        771 00108$:
                                    772 ;	quantum/action.c:184: process_record(&record);
      00799F 90 08 C6         [24]  773 	mov	dptr,#_action_exec_record_10001_632
      0079A2 75 F0 00         [24]  774 	mov	b, #0x00
                                    775 ;	quantum/action.c:199: }
      0079A5 21 E3            [12]  776 	ajmp	_process_record
      0079A7                        777 00112$:
      0079A7 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_action_exec'
                                    781 ;------------------------------------------------------------
                                    782 ;event         Allocated with name '_ak820_action_exec_event_10000_636'
                                    783 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_637'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/action.c:202: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function ak820_action_exec
                                    788 ;	-----------------------------------------
      0079A8                        789 _ak820_action_exec:
      0079A8 12 38 75         [24]  790 	lcall	_ak820_outline_0108
      0079AB 90 08 CF         [24]  791 	mov	dptr,#_ak820_action_exec_event_10000_636
      0079AE 12 38 7A         [24]  792 	lcall	_ak820_outline_0109
                                    793 ;	quantum/action.c:205: keyevent_t snapshot = *event;
      0079B1 90 08 CF         [24]  794 	mov	dptr,#_ak820_action_exec_event_10000_636
      0079B4 12 38 5D         [24]  795 	lcall	_ak820_outline_0080
      0079B7 7F 00            [12]  796 	mov	r7,#0x00
      0079B9 90 0E 73         [24]  797 	mov	dptr,#___memcpy_PARM_2
      0079BC ED               [12]  798 	mov	a,r5
      0079BD 12 38 1C         [24]  799 	lcall	_ak820_outline_0019
      0079C0 12 80 09         [24]  800 	lcall	_ak820_outline_0073
      0079C3 90 08 D1         [24]  801 	mov	dptr,#_ak820_action_exec_snapshot_10000_637
      0079C6 F5 F0            [12]  802 	mov	b,a
      0079C8 12 C2 AA         [24]  803 	lcall	___memcpy
                                    804 ;	quantum/action.c:206: action_exec(snapshot);
      0079CB 90 0E 73         [24]  805 	mov	dptr,#___memcpy_PARM_2
      0079CE 74 D1            [12]  806 	mov	a,#_ak820_action_exec_snapshot_10000_637
      0079D0 F0               [24]  807 	movx	@dptr,a
      0079D1 74 08            [12]  808 	mov	a,#(_ak820_action_exec_snapshot_10000_637 >> 8)
      0079D3 12 38 51         [24]  809 	lcall	_ak820_outline_0074
      0079D6 12 80 09         [24]  810 	lcall	_ak820_outline_0073
      0079D9 90 08 C0         [24]  811 	mov	dptr,#_action_exec_PARM_1
      0079DC F5 F0            [12]  812 	mov	b,a
      0079DE 12 C2 AA         [24]  813 	lcall	___memcpy
                                    814 ;	quantum/action.c:207: }
      0079E1 21 36            [12]  815 	ajmp	_action_exec
                                    816 ;------------------------------------------------------------
                                    817 ;Allocation info for local variables in function 'process_record_nocache'
                                    818 ;------------------------------------------------------------
                                    819 ;record        Allocated with name '_process_record_nocache_record_10000_638'
                                    820 ;------------------------------------------------------------
                                    821 ;	quantum/action.c:292: void process_record_nocache(keyrecord_t *record) {
                                    822 ;	-----------------------------------------
                                    823 ;	 function process_record
                                    824 ;	-----------------------------------------
      0079E3                        825 _process_record:
      0079E3 12 43 06         [24]  826 	lcall	_ak820_outline_0038
      0079E6 90 08 D7         [24]  827 	mov	dptr,#_process_record_record_10000_640
      0079E9 12 38 1C         [24]  828 	lcall	_ak820_outline_0019
                                    829 ;	quantum/action.c:346: if (IS_NOEVENT(record->event)) {
      0079EC 90 08 D7         [24]  830 	mov	dptr,#_process_record_record_10000_640
      0079EF 12 58 58         [24]  831 	lcall	_ak820_outline_0013
      0079F2 74 04            [12]  832 	mov	a,#0x04
      0079F4 12 7F DC         [24]  833 	lcall	_ak820_outline_0015
      0079F7 12 C3 83         [24]  834 	lcall	__gptrget
      0079FA 70 01            [24]  835 	jnz	00102$
                                    836 ;	quantum/action.c:347: return;
      0079FC 22               [24]  837 	ret
      0079FD                        838 00102$:
                                    839 ;	quantum/action.c:355: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0079FD 8D 02            [24]  840 	mov	ar2,r5
      0079FF 8E 03            [24]  841 	mov	ar3,r6
      007A01 8F 04            [24]  842 	mov	ar4,r7
      007A03 90 0E 73         [24]  843 	mov	dptr,#___memcpy_PARM_2
      007A06 EA               [12]  844 	mov	a,r2
      007A07 12 80 57         [24]  845 	lcall	_ak820_outline_0188
      007A0A EC               [12]  846 	mov	a,r4
      007A0B A3               [24]  847 	inc	dptr
      007A0C F0               [24]  848 	movx	@dptr,a
      007A0D 90 0E 76         [24]  849 	mov	dptr,#___memcpy_PARM_3
      007A10 12 58 9D         [24]  850 	lcall	_ak820_outline_0111
      007A13 90 06 D4         [24]  851 	mov	dptr,#_ak820_tapping_source_PARM_1
      007A16 F5 F0            [12]  852 	mov	b,a
      007A18 C0 07            [24]  853 	push	ar7
      007A1A C0 06            [24]  854 	push	ar6
      007A1C C0 05            [24]  855 	push	ar5
      007A1E 12 C2 AA         [24]  856 	lcall	___memcpy
      007A21 12 4C FB         [24]  857 	lcall	_ak820_tapping_source
      007A24 AC 82            [24]  858 	mov	r4, dpl
      007A26 D0 05            [24]  859 	pop	ar5
      007A28 D0 06            [24]  860 	pop	ar6
      007A2A D0 07            [24]  861 	pop	ar7
                                    862 ;	quantum/action.c:356: bool oneshot_pressed = record->event.pressed;
      007A2C 74 05            [12]  863 	mov	a,#0x05
      007A2E 12 7F CE         [24]  864 	lcall	_ak820_outline_0014
      007A31 12 C3 83         [24]  865 	lcall	__gptrget
      007A34 FB               [12]  866 	mov	r3,a
                                    867 ;	quantum/action.c:357: record->keycode = get_record_keycode(record, true);
      007A35 12 80 3C         [24]  868 	lcall	_ak820_outline_0147
      007A38 90 0C B6         [24]  869 	mov	dptr,#_get_record_keycode_PARM_2
      007A3B 74 01            [12]  870 	mov	a,#0x01
      007A3D 12 58 61         [24]  871 	lcall	_ak820_outline_0035
      007A40 C0 04            [24]  872 	push	ar4
      007A42 C0 03            [24]  873 	push	ar3
      007A44 C0 02            [24]  874 	push	ar2
      007A46 C0 01            [24]  875 	push	ar1
      007A48 C0 00            [24]  876 	push	ar0
      007A4A 12 A8 4A         [24]  877 	lcall	_get_record_keycode
      007A4D 12 43 4F         [24]  878 	lcall	_ak820_outline_0135
      007A50 D0 00            [24]  879 	pop	ar0
      007A52 D0 01            [24]  880 	pop	ar1
      007A54 D0 02            [24]  881 	pop	ar2
      007A56 D0 03            [24]  882 	pop	ar3
      007A58 D0 04            [24]  883 	pop	ar4
      007A5A 12 52 1E         [24]  884 	lcall	_ak820_outline_0113
      007A5D EE               [12]  885 	mov	a,r6
      007A5E 12 C3 48         [24]  886 	lcall	__gptrput
      007A61 A3               [24]  887 	inc	dptr
      007A62 EF               [12]  888 	mov	a,r7
      007A63 12 C3 48         [24]  889 	lcall	__gptrput
                                    890 ;	quantum/action.c:358: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007A66 90 08 D7         [24]  891 	mov	dptr,#_process_record_record_10000_640
      007A69 12 58 58         [24]  892 	lcall	_ak820_outline_0013
      007A6C 12 80 3C         [24]  893 	lcall	_ak820_outline_0147
      007A6F 12 52 1E         [24]  894 	lcall	_ak820_outline_0113
      007A72 12 C3 83         [24]  895 	lcall	__gptrget
      007A75 F8               [12]  896 	mov	r0,a
      007A76 A3               [24]  897 	inc	dptr
      007A77 12 C3 83         [24]  898 	lcall	__gptrget
      007A7A F9               [12]  899 	mov	r1,a
      007A7B 90 06 E4         [24]  900 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007A7E EC               [12]  901 	mov	a,r4
      007A7F F0               [24]  902 	movx	@dptr,a
      007A80 90 06 E5         [24]  903 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007A83 EB               [12]  904 	mov	a,r3
      007A84 F0               [24]  905 	movx	@dptr,a
      007A85 12 38 A9         [24]  906 	lcall	_ak820_outline_0158
      007A88 C0 07            [24]  907 	push	ar7
      007A8A C0 06            [24]  908 	push	ar6
      007A8C C0 05            [24]  909 	push	ar5
      007A8E C0 04            [24]  910 	push	ar4
      007A90 C0 03            [24]  911 	push	ar3
      007A92 12 50 54         [24]  912 	lcall	_ak820_oneshot_process
      007A95 E5 82            [12]  913 	mov	a, dpl
      007A97 D0 03            [24]  914 	pop	ar3
      007A99 D0 04            [24]  915 	pop	ar4
      007A9B D0 05            [24]  916 	pop	ar5
      007A9D D0 06            [24]  917 	pop	ar6
      007A9F D0 07            [24]  918 	pop	ar7
      007AA1 70 01            [24]  919 	jnz	00104$
      007AA3 22               [24]  920 	ret
      007AA4                        921 00104$:
                                    922 ;	quantum/action.c:360: if (!process_record_quantum(record)) {
      007AA4 12 76 9E         [24]  923 	lcall	_ak820_outline_0060
      007AA7 C0 04            [24]  924 	push	ar4
      007AA9 C0 03            [24]  925 	push	ar3
      007AAB 12 A9 2F         [24]  926 	lcall	_process_record_quantum
      007AAE E5 82            [12]  927 	mov	a, dpl
      007AB0 D0 03            [24]  928 	pop	ar3
      007AB2 D0 04            [24]  929 	pop	ar4
      007AB4 70 0A            [24]  930 	jnz	00106$
                                    931 ;	quantum/action.c:362: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007AB6 90 05 9C         [24]  932 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007AB9 EB               [12]  933 	mov	a,r3
      007ABA F0               [24]  934 	movx	@dptr,a
      007ABB 8C 82            [24]  935 	mov	dpl, r4
                                    936 ;	quantum/action.c:369: return;
      007ABD 02 2E BB         [24]  937 	ljmp	_ak820_oneshot_post
      007AC0                        938 00106$:
                                    939 ;	quantum/action.c:375: process_record_handler(record);
      007AC0 90 08 D7         [24]  940 	mov	dptr,#_process_record_record_10000_640
      007AC3 12 58 32         [24]  941 	lcall	_ak820_outline_0001
      007AC6 C0 04            [24]  942 	push	ar4
      007AC8 C0 03            [24]  943 	push	ar3
      007ACA 51 E3            [24]  944 	acall	_process_record_handler
                                    945 ;	quantum/action.c:379: post_process_record_quantum(record);
      007ACC 90 08 D7         [24]  946 	mov	dptr,#_process_record_record_10000_640
      007ACF 12 58 32         [24]  947 	lcall	_ak820_outline_0001
      007AD2 12 A9 06         [24]  948 	lcall	_post_process_record_quantum
      007AD5 D0 03            [24]  949 	pop	ar3
      007AD7 D0 04            [24]  950 	pop	ar4
                                    951 ;	quantum/action.c:381: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007AD9 90 05 9C         [24]  952 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007ADC EB               [12]  953 	mov	a,r3
      007ADD F0               [24]  954 	movx	@dptr,a
      007ADE 8C 82            [24]  955 	mov	dpl, r4
                                    956 ;	quantum/action.c:383: }
      007AE0 02 2E BB         [24]  957 	ljmp	_ak820_oneshot_post
                                    958 ;------------------------------------------------------------
                                    959 ;Allocation info for local variables in function 'process_record_handler'
                                    960 ;------------------------------------------------------------
                                    961 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_648'
                                    962 ;record        Allocated with name '_process_record_handler_record_10000_649'
                                    963 ;action        Allocated with name '_process_record_handler_action_10000_649'
                                    964 ;------------------------------------------------------------
                                    965 ;	quantum/action.c:385: void process_record_handler(keyrecord_t *record_argument) {
                                    966 ;	-----------------------------------------
                                    967 ;	 function process_record_handler
                                    968 ;	-----------------------------------------
      007AE3                        969 _process_record_handler:
      007AE3 12 43 06         [24]  970 	lcall	_ak820_outline_0038
      007AE6 90 08 DA         [24]  971 	mov	dptr,#_process_record_handler_record_argument_10000_648
      007AE9 12 38 1C         [24]  972 	lcall	_ak820_outline_0019
                                    973 ;	quantum/action.c:389: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007AEC 90 08 DA         [24]  974 	mov	dptr,#_process_record_handler_record_argument_10000_648
      007AEF 12 37 F1         [24]  975 	lcall	_ak820_outline_0007
                                    976 ;	quantum/action.c:396: if (record->keycode) {
      007AF2 4C               [12]  977 	orl	a,r4
      007AF3 60 19            [24]  978 	jz	00102$
                                    979 ;	quantum/action.c:397: action.code = action_for_keycode(record->keycode);
      007AF5 12 38 8A         [24]  980 	lcall	_ak820_outline_0126
      007AF8 C0 07            [24]  981 	push	ar7
      007AFA C0 06            [24]  982 	push	ar6
      007AFC 12 9E 98         [24]  983 	lcall	_action_for_keycode
      007AFF 12 43 60         [24]  984 	lcall	_ak820_outline_0150
      007B02 D0 06            [24]  985 	pop	ar6
      007B04 D0 07            [24]  986 	pop	ar7
      007B06 90 08 DD         [24]  987 	mov	dptr,#_process_record_handler_action_10000_649
      007B09 12 38 57         [24]  988 	lcall	_ak820_outline_0079
      007B0C 80 2B            [24]  989 	sjmp	00104$
      007B0E                        990 00102$:
                                    991 ;	quantum/action.c:400: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007B0E 12 7F EA         [24]  992 	lcall	_ak820_outline_0022
      007B11 7A 00            [12]  993 	mov	r2,#0x00
      007B13 12 43 5A         [24]  994 	lcall	_ak820_outline_0143
      007B16 12 42 F4         [24]  995 	lcall	_ak820_outline_0012
      007B19 E0               [24]  996 	movx	a,@dptr
      007B1A 90 0A 19         [24]  997 	mov	dptr,#_ak820_resolve_key_PARM_2
      007B1D F0               [24]  998 	movx	@dptr,a
      007B1E 8D 82            [24]  999 	mov	dpl, r5
      007B20 8C 83            [24] 1000 	mov	dph, r4
      007B22 C0 07            [24] 1001 	push	ar7
      007B24 C0 06            [24] 1002 	push	ar6
      007B26 12 83 7F         [24] 1003 	lcall	_ak820_resolve_key
      007B29 12 9E 98         [24] 1004 	lcall	_action_for_keycode
      007B2C 12 43 60         [24] 1005 	lcall	_ak820_outline_0150
      007B2F D0 06            [24] 1006 	pop	ar6
      007B31 D0 07            [24] 1007 	pop	ar7
      007B33 90 08 DD         [24] 1008 	mov	dptr,#_process_record_handler_action_10000_649
      007B36 12 38 57         [24] 1009 	lcall	_ak820_outline_0079
                                   1010 ;	quantum/action.c:409: ac_dprintf("ACTION: ");
      007B39                       1011 00104$:
                                   1012 ;	quantum/action.c:420: process_action(record, action);
      007B39 7D 00            [12] 1013 	mov	r5,#0x00
      007B3B 90 0E 73         [24] 1014 	mov	dptr,#___memcpy_PARM_2
      007B3E 74 DD            [12] 1015 	mov	a,#_process_record_handler_action_10000_649
      007B40 F0               [24] 1016 	movx	@dptr,a
      007B41 74 08            [12] 1017 	mov	a,#(_process_record_handler_action_10000_649 >> 8)
      007B43 12 38 51         [24] 1018 	lcall	_ak820_outline_0074
      007B46 90 0E 76         [24] 1019 	mov	dptr,#___memcpy_PARM_3
      007B49 12 58 9D         [24] 1020 	lcall	_ak820_outline_0111
      007B4C 90 08 DF         [24] 1021 	mov	dptr,#_process_action_PARM_2
      007B4F F5 F0            [12] 1022 	mov	b,a
      007B51 C0 07            [24] 1023 	push	ar7
      007B53 C0 06            [24] 1024 	push	ar6
      007B55 C0 05            [24] 1025 	push	ar5
      007B57 12 C2 AA         [24] 1026 	lcall	___memcpy
      007B5A D0 05            [24] 1027 	pop	ar5
      007B5C D0 06            [24] 1028 	pop	ar6
      007B5E D0 07            [24] 1029 	pop	ar7
      007B60 12 80 23         [24] 1030 	lcall	_ak820_outline_0114
                                   1031 ;	quantum/action.c:421: }
      007B63 61 65            [24] 1032 	ajmp	_process_action
                                   1033 ;------------------------------------------------------------
                                   1034 ;Allocation info for local variables in function 'register_mouse'
                                   1035 ;------------------------------------------------------------
                                   1036 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1037 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_657'
                                   1038 ;------------------------------------------------------------
                                   1039 ;	quantum/action.c:433: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1040 ;	-----------------------------------------
                                   1041 ;	 function process_action
                                   1042 ;	-----------------------------------------
      007B65                       1043 _process_action:
      007B65 12 43 06         [24] 1044 	lcall	_ak820_outline_0038
      007B68 90 08 E1         [24] 1045 	mov	dptr,#_process_action_record_argument_10000_660
      007B6B 12 38 1C         [24] 1046 	lcall	_ak820_outline_0019
                                   1047 ;	quantum/action.c:486: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007B6E 90 08 E1         [24] 1048 	mov	dptr,#_process_action_record_argument_10000_660
      007B71 12 37 E7         [24] 1049 	lcall	_ak820_outline_0005
                                   1050 ;	quantum/action.c:492: pressed = record->event.pressed;
      007B74 A3               [24] 1051 	inc	dptr
      007B75 A3               [24] 1052 	inc	dptr
      007B76 A3               [24] 1053 	inc	dptr
      007B77 A3               [24] 1054 	inc	dptr
      007B78 A3               [24] 1055 	inc	dptr
      007B79 E0               [24] 1056 	movx	a,@dptr
      007B7A F5 17            [12] 1057 	mov	_process_action_sloc0_1_0,a
                                   1058 ;	quantum/action.c:516: switch (action.kind.id) {
      007B7C 90 08 E0         [24] 1059 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007B7F E0               [24] 1060 	movx	a,@dptr
      007B80 C4               [12] 1061 	swap	a
      007B81 54 0F            [12] 1062 	anl	a,#0x0f
      007B83 FD               [12] 1063 	mov  r5,a
      007B84 24 F4            [12] 1064 	add	a,#0xff - 0x0b
      007B86 50 03            [24] 1065 	jnc	00434$
      007B88 02 7E 06         [24] 1066 	ljmp	00181$
      007B8B                       1067 00434$:
                                   1068 ;	free result
      007B8B ED               [12] 1069 	mov	a,r5
      007B8C 24 0A            [12] 1070 	add	a,#(00435$-3-.)
      007B8E 83               [24] 1071 	movc	a,@a+pc
      007B8F F5 82            [12] 1072 	mov	dpl,a
      007B91 ED               [12] 1073 	mov	a,r5
      007B92 24 10            [12] 1074 	add	a,#(00436$-3-.)
      007B94 83               [24] 1075 	movc	a,@a+pc
      007B95 F5 83            [12] 1076 	mov	dph,a
      007B97 E4               [12] 1077 	clr	a
      007B98 73               [24] 1078 	jmp	@a+dptr
      007B99                       1079 00435$:
      007B99 B1                    1080 	.db	00102$
      007B9A B1                    1081 	.db	00102$
      007B9B 06                    1082 	.db	00181$
      007B9C 06                    1083 	.db	00181$
      007B9D 3B                    1084 	.db	00123$
      007B9E 06                    1085 	.db	00181$
      007B9F 06                    1086 	.db	00181$
      007BA0 06                    1087 	.db	00181$
      007BA1 9B                    1088 	.db	00131$
      007BA2 6D                    1089 	.db	00147$
      007BA3 93                    1090 	.db	00152$
      007BA4 93                    1091 	.db	00152$
      007BA5                       1092 00436$:
      007BA5 7B                    1093 	.db	00102$>>8
      007BA6 7B                    1094 	.db	00102$>>8
      007BA7 7E                    1095 	.db	00181$>>8
      007BA8 7E                    1096 	.db	00181$>>8
      007BA9 7C                    1097 	.db	00123$>>8
      007BAA 7E                    1098 	.db	00181$>>8
      007BAB 7E                    1099 	.db	00181$>>8
      007BAC 7E                    1100 	.db	00181$>>8
      007BAD 7C                    1101 	.db	00131$>>8
      007BAE 7D                    1102 	.db	00147$>>8
      007BAF 7D                    1103 	.db	00152$>>8
      007BB0 7D                    1104 	.db	00152$>>8
                                   1105 ;	quantum/action.c:519: case ACT_RMODS: {
      007BB1                       1106 00102$:
                                   1107 ;	quantum/action.c:520: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007BB1 90 08 E0         [24] 1108 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007BB4 E0               [24] 1109 	movx	a,@dptr
      007BB5 54 F0            [12] 1110 	anl	a,#0xf0
      007BB7 70 06            [24] 1111 	jnz	00194$
      007BB9 12 80 2A         [24] 1112 	lcall	_ak820_outline_0115
      007BBC FD               [12] 1113 	mov	r5,a
      007BBD 80 07            [24] 1114 	sjmp	00195$
      007BBF                       1115 00194$:
      007BBF 12 80 2A         [24] 1116 	lcall	_ak820_outline_0115
      007BC2 C4               [12] 1117 	swap	a
      007BC3 54 F0            [12] 1118 	anl	a,#0xf0
      007BC5 FD               [12] 1119 	mov	r5,a
      007BC6                       1120 00195$:
                                   1121 ;	quantum/action.c:522: if (pressed) {
      007BC6 E5 17            [12] 1122 	mov	a,_process_action_sloc0_1_0
      007BC8 60 35            [24] 1123 	jz	00119$
                                   1124 ;	quantum/action.c:523: if (mods) {
      007BCA ED               [12] 1125 	mov	a,r5
      007BCB 60 29            [24] 1126 	jz	00110$
                                   1127 ;	quantum/action.c:524: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007BCD 12 80 46         [24] 1128 	lcall	_ak820_outline_0160
      007BD0 FC               [12] 1129 	mov	r4,a
      007BD1 BC E0 00         [24] 1130 	cjne	r4,#0xe0,00440$
      007BD4                       1131 00440$:
      007BD4 40 07            [24] 1132 	jc	00108$
      007BD6 12 80 46         [24] 1133 	lcall	_ak820_outline_0160
      007BD9 24 18            [12] 1134 	add	a,#0xff - 0xe7
      007BDB 50 0A            [24] 1135 	jnc	00104$
                                   1136 ;	free result
      007BDD                       1137 00108$:
      007BDD 7B DF            [12] 1138 	mov	r3,#_process_action_PARM_2
      007BDF 7C 08            [12] 1139 	mov	r4,#(_process_action_PARM_2 >> 8)
      007BE1 12 33 FC         [24] 1140 	lcall	_ak820_outline_0123
      007BE4 E0               [24] 1141 	movx	a,@dptr
      007BE5 70 07            [24] 1142 	jnz	00105$
      007BE7                       1143 00104$:
                                   1144 ;	quantum/action.c:528: add_owned_mods(mods);
      007BE7 8D 82            [24] 1145 	mov	dpl, r5
      007BE9 12 85 95         [24] 1146 	lcall	_add_owned_mods
      007BEC 80 05            [24] 1147 	sjmp	00106$
      007BEE                       1148 00105$:
                                   1149 ;	quantum/action.c:530: add_owned_weak_mods(mods);
      007BEE 8D 82            [24] 1150 	mov	dpl, r5
      007BF0 12 85 B2         [24] 1151 	lcall	_add_owned_weak_mods
      007BF3                       1152 00106$:
                                   1153 ;	quantum/action.c:532: send_keyboard_report();
      007BF3 12 88 C9         [24] 1154 	lcall	_send_keyboard_report
      007BF6                       1155 00110$:
                                   1156 ;	quantum/action.c:534: register_code(action.key.code);
      007BF6 12 80 13         [24] 1157 	lcall	_ak820_outline_0078
      007BF9 12 7E 1D         [24] 1158 	lcall	_register_code
      007BFC 02 7E 06         [24] 1159 	ljmp	00181$
      007BFF                       1160 00119$:
                                   1161 ;	quantum/action.c:536: unregister_code(action.key.code);
      007BFF 12 80 13         [24] 1162 	lcall	_ak820_outline_0078
      007C02 C0 05            [24] 1163 	push	ar5
      007C04 12 7E 8A         [24] 1164 	lcall	_unregister_code
      007C07 D0 05            [24] 1165 	pop	ar5
                                   1166 ;	quantum/action.c:537: if (mods) {
      007C09 ED               [12] 1167 	mov	a,r5
      007C0A 70 03            [24] 1168 	jnz	00444$
      007C0C 02 7E 06         [24] 1169 	ljmp	00181$
      007C0F                       1170 00444$:
                                   1171 ;	quantum/action.c:538: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007C0F 12 80 46         [24] 1172 	lcall	_ak820_outline_0160
      007C12 FC               [12] 1173 	mov	r4,a
      007C13 BC E0 00         [24] 1174 	cjne	r4,#0xe0,00445$
      007C16                       1175 00445$:
      007C16 40 07            [24] 1176 	jc	00115$
      007C18 12 80 46         [24] 1177 	lcall	_ak820_outline_0160
      007C1B 24 18            [12] 1178 	add	a,#0xff - 0xe7
      007C1D 50 0A            [24] 1179 	jnc	00111$
                                   1180 ;	free result
      007C1F                       1181 00115$:
      007C1F 7B DF            [12] 1182 	mov	r3,#_process_action_PARM_2
      007C21 7C 08            [12] 1183 	mov	r4,#(_process_action_PARM_2 >> 8)
      007C23 12 33 FC         [24] 1184 	lcall	_ak820_outline_0123
      007C26 E0               [24] 1185 	movx	a,@dptr
      007C27 70 07            [24] 1186 	jnz	00112$
      007C29                       1187 00111$:
                                   1188 ;	quantum/action.c:539: del_owned_mods(mods);
      007C29 8D 82            [24] 1189 	mov	dpl, r5
      007C2B 12 85 A4         [24] 1190 	lcall	_del_owned_mods
      007C2E 80 05            [24] 1191 	sjmp	00113$
      007C30                       1192 00112$:
                                   1193 ;	quantum/action.c:541: del_owned_weak_mods(mods);
      007C30 8D 82            [24] 1194 	mov	dpl, r5
      007C32 12 85 C1         [24] 1195 	lcall	_del_owned_weak_mods
      007C35                       1196 00113$:
                                   1197 ;	quantum/action.c:543: send_keyboard_report();
      007C35 12 88 C9         [24] 1198 	lcall	_send_keyboard_report
                                   1199 ;	quantum/action.c:546: } break;
      007C38 02 7E 06         [24] 1200 	ljmp	00181$
                                   1201 ;	quantum/action.c:623: case ACT_USAGE:
      007C3B                       1202 00123$:
                                   1203 ;	quantum/action.c:629: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007C3B 74 07            [12] 1204 	mov	a,#0x07
      007C3D 12 38 24         [24] 1205 	lcall	_ak820_outline_0023
      007C40 12 51 8C         [24] 1206 	lcall	_ak820_outline_0009
      007C43 C3               [12] 1207 	clr	c
      007C44 EC               [12] 1208 	mov	a,r4
      007C45 94 A5            [12] 1209 	subb	a,#0xa5
      007C47 ED               [12] 1210 	mov	a,r5
      007C48 94 00            [12] 1211 	subb	a,#0x00
      007C4A 40 15            [24] 1212 	jc	00125$
      007C4C 74 C2            [12] 1213 	mov	a,#0xc2
      007C4E 9C               [12] 1214 	subb	a,r4
      007C4F E4               [12] 1215 	clr	a
      007C50 9D               [12] 1216 	subb	a,r5
      007C51 40 0E            [24] 1217 	jc	00125$
                                   1218 ;	free result
                                   1219 ;	quantum/action.c:630: owned_usage_key((uint8_t)record->keycode, pressed);
      007C53 90 0B 40         [24] 1220 	mov	dptr,#_owned_usage_key_PARM_2
      007C56 E5 17            [12] 1221 	mov	a,_process_action_sloc0_1_0
      007C58 F0               [24] 1222 	movx	@dptr,a
      007C59 8E 82            [24] 1223 	mov	dpl, r6
      007C5B 12 87 74         [24] 1224 	lcall	_owned_usage_key
                                   1225 ;	quantum/action.c:631: break;
      007C5E 02 7E 06         [24] 1226 	ljmp	00181$
      007C61                       1227 00125$:
                                   1228 ;	quantum/action.c:634: switch (action.usage.page) {
      007C61 12 80 1A         [24] 1229 	lcall	_ak820_outline_0090
      007C64 FF               [12] 1230 	mov	r7,a
      007C65 60 08            [24] 1231 	jz	00127$
      007C67 BF 01 02         [24] 1232 	cjne	r7,#0x01,00452$
      007C6A 80 19            [24] 1233 	sjmp	00128$
      007C6C                       1234 00452$:
      007C6C 02 7E 06         [24] 1235 	ljmp	00181$
                                   1236 ;	quantum/action.c:635: case PAGE_SYSTEM:
      007C6F                       1237 00127$:
                                   1238 ;	quantum/action.c:636: host_system_send(pressed ? action.usage.code : 0);
      007C6F E5 17            [12] 1239 	mov	a,_process_action_sloc0_1_0
      007C71 60 05            [24] 1240 	jz	00196$
      007C73 12 80 31         [24] 1241 	lcall	_ak820_outline_0133
      007C76 80 04            [24] 1242 	sjmp	00197$
      007C78                       1243 00196$:
      007C78 7E 00            [12] 1244 	mov	r6,#0x00
      007C7A 7F 00            [12] 1245 	mov	r7,#0x00
      007C7C                       1246 00197$:
      007C7C 12 38 7F         [24] 1247 	lcall	_ak820_outline_0120
      007C7F 12 76 2A         [24] 1248 	lcall	_host_system_send
                                   1249 ;	quantum/action.c:637: break;
      007C82 02 7E 06         [24] 1250 	ljmp	00181$
                                   1251 ;	quantum/action.c:638: case PAGE_CONSUMER:
      007C85                       1252 00128$:
                                   1253 ;	quantum/action.c:639: host_consumer_send(pressed ? action.usage.code : 0);
      007C85 E5 17            [12] 1254 	mov	a,_process_action_sloc0_1_0
      007C87 60 05            [24] 1255 	jz	00198$
      007C89 12 80 31         [24] 1256 	lcall	_ak820_outline_0133
      007C8C 80 04            [24] 1257 	sjmp	00199$
      007C8E                       1258 00198$:
      007C8E 7E 00            [12] 1259 	mov	r6,#0x00
      007C90 7F 00            [12] 1260 	mov	r7,#0x00
      007C92                       1261 00199$:
      007C92 12 38 7F         [24] 1262 	lcall	_ak820_outline_0120
      007C95 12 76 59         [24] 1263 	lcall	_host_consumer_send
                                   1264 ;	quantum/action.c:642: break;
      007C98 02 7E 06         [24] 1265 	ljmp	00181$
                                   1266 ;	quantum/action.c:649: case ACT_LAYER: {
      007C9B                       1267 00131$:
                                   1268 ;	quantum/action.c:650: uint8_t on = action.layer_bitop.on;
      007C9B 90 08 E0         [24] 1269 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007C9E E0               [24] 1270 	movx	a,@dptr
      007C9F 54 03            [12] 1271 	anl	a,#0x03
      007CA1 90 08 E4         [24] 1272 	mov	dptr,#_process_action_on_40000_683
      007CA4 F0               [24] 1273 	movx	@dptr,a
                                   1274 ;	quantum/action.c:653: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007CA5 E0               [24] 1275 	movx	a,@dptr
      007CA6 FF               [12] 1276 	mov	r7,a
      007CA7 60 11            [24] 1277 	jz	00200$
      007CA9 E5 17            [12] 1278 	mov	a,_process_action_sloc0_1_0
      007CAB 60 07            [24] 1279 	jz	00202$
      007CAD 8F 06            [24] 1280 	mov	ar6,r7
      007CAF 53 06 01         [24] 1281 	anl	ar6,#0x01
      007CB2 80 10            [24] 1282 	sjmp	00201$
      007CB4                       1283 00202$:
      007CB4 74 02            [12] 1284 	mov	a,#0x02
      007CB6 5F               [12] 1285 	anl	a,r7
      007CB7 FE               [12] 1286 	mov	r6,a
      007CB8 80 0A            [24] 1287 	sjmp	00201$
      007CBA                       1288 00200$:
      007CBA E5 17            [12] 1289 	mov	a,_process_action_sloc0_1_0
      007CBC B4 01 00         [24] 1290 	cjne	a,#0x01,00457$
      007CBF                       1291 00457$:
      007CBF 92 22            [24] 1292 	mov  _process_action_sloc1_1_0,c
      007CC1 E4               [12] 1293 	clr	a
      007CC2 33               [12] 1294 	rlc	a
      007CC3 FE               [12] 1295 	mov	r6,a
      007CC4                       1296 00201$:
      007CC4 EE               [12] 1297 	mov	a,r6
      007CC5 70 03            [24] 1298 	jnz	00458$
      007CC7 02 7E 06         [24] 1299 	ljmp	00181$
      007CCA                       1300 00458$:
                                   1301 ;	quantum/action.c:654: uint8_t shift = action.layer_bitop.part * 4;
      007CCA 12 80 46         [24] 1302 	lcall	_ak820_outline_0160
      007CCD C4               [12] 1303 	swap	a
      007CCE 03               [12] 1304 	rr	a
      007CCF 54 07            [12] 1305 	anl	a,#0x07
      007CD1 25 E0            [12] 1306 	add	a,acc
      007CD3 25 E0            [12] 1307 	add	a,acc
      007CD5 FF               [12] 1308 	mov	r7,a
                                   1309 ;	quantum/action.c:655: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007CD6 12 80 46         [24] 1310 	lcall	_ak820_outline_0160
      007CD9 54 0F            [12] 1311 	anl	a,#0x0f
      007CDB FE               [12] 1312 	mov	r6,a
      007CDC 8F F0            [24] 1313 	mov	b,r7
      007CDE 05 F0            [12] 1314 	inc	b
      007CE0 EE               [12] 1315 	mov	a,r6
      007CE1 80 02            [24] 1316 	sjmp	00460$
      007CE3                       1317 00459$:
      007CE3 25 E0            [12] 1318 	add	a,acc
      007CE5                       1319 00460$:
      007CE5 D5 F0 FB         [24] 1320 	djnz	b,00459$
      007CE8 FE               [12] 1321 	mov	r6,a
                                   1322 ;	quantum/action.c:656: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007CE9 12 80 46         [24] 1323 	lcall	_ak820_outline_0160
      007CEC 30 E4 11         [24] 1324 	jnb	acc.4,00204$
      007CEF 8F F0            [24] 1325 	mov	b,r7
      007CF1 05 F0            [12] 1326 	inc	b
      007CF3 74 0F            [12] 1327 	mov	a,#0x0f
      007CF5 80 02            [24] 1328 	sjmp	00463$
      007CF7                       1329 00462$:
      007CF7 25 E0            [12] 1330 	add	a,acc
      007CF9                       1331 00463$:
      007CF9 D5 F0 FB         [24] 1332 	djnz	b,00462$
      007CFC F4               [12] 1333 	cpl	a
      007CFD FF               [12] 1334 	mov	r7,a
      007CFE 80 02            [24] 1335 	sjmp	00205$
      007D00                       1336 00204$:
      007D00 7F 00            [12] 1337 	mov	r7,#0x00
      007D02                       1338 00205$:
                                   1339 ;	quantum/action.c:657: bits |= mask;
      007D02 EE               [12] 1340 	mov	a,r6
      007D03 42 07            [12] 1341 	orl	ar7,a
                                   1342 ;	quantum/action.c:658: if (!on) {
      007D05 90 08 E4         [24] 1343 	mov	dptr,#_process_action_on_40000_683
      007D08 E0               [24] 1344 	movx	a,@dptr
      007D09 70 31            [24] 1345 	jnz	00143$
                                   1346 ;	quantum/action.c:659: switch (action.layer_bitop.op) {
      007D0B 12 80 1A         [24] 1347 	lcall	_ak820_outline_0090
      007D0E FE               [12] 1348 	mov	r6,a
      007D0F 2E               [12] 1349 	add	a,r6
                                   1350 ;	quantum/action.c:660: case OP_BIT_AND: default_layer_and(bits); break;
      007D10 90 7D 14         [24] 1351 	mov	dptr,#00465$
      007D13 73               [24] 1352 	jmp	@a+dptr
      007D14                       1353 00465$:
      007D14 80 06            [24] 1354 	sjmp	00132$
      007D16 80 0C            [24] 1355 	sjmp	00133$
      007D18 80 12            [24] 1356 	sjmp	00134$
      007D1A 80 18            [24] 1357 	sjmp	00135$
      007D1C                       1358 00132$:
      007D1C 8F 82            [24] 1359 	mov	dpl, r7
      007D1E 12 80 A1         [24] 1360 	lcall	_default_layer_and
      007D21 02 7E 06         [24] 1361 	ljmp	00181$
                                   1362 ;	quantum/action.c:661: case OP_BIT_OR: default_layer_or(bits); break;
      007D24                       1363 00133$:
      007D24 8F 82            [24] 1364 	mov	dpl, r7
      007D26 12 80 91         [24] 1365 	lcall	_default_layer_or
      007D29 02 7E 06         [24] 1366 	ljmp	00181$
                                   1367 ;	quantum/action.c:662: case OP_BIT_XOR: default_layer_xor(bits); break;
      007D2C                       1368 00134$:
      007D2C 8F 82            [24] 1369 	mov	dpl, r7
      007D2E 12 80 B6         [24] 1370 	lcall	_default_layer_xor
      007D31 02 7E 06         [24] 1371 	ljmp	00181$
                                   1372 ;	quantum/action.c:663: case OP_BIT_SET: default_layer_set(bits); break;
      007D34                       1373 00135$:
      007D34 8F 82            [24] 1374 	mov	dpl, r7
      007D36 12 80 87         [24] 1375 	lcall	_default_layer_set
                                   1376 ;	quantum/action.c:664: }
      007D39 02 7E 06         [24] 1377 	ljmp	00181$
      007D3C                       1378 00143$:
                                   1379 ;	quantum/action.c:666: switch (action.layer_bitop.op) {
      007D3C 12 80 1A         [24] 1380 	lcall	_ak820_outline_0090
      007D3F FE               [12] 1381 	mov	r6,a
      007D40 2E               [12] 1382 	add	a,r6
                                   1383 ;	quantum/action.c:667: case OP_BIT_AND: layer_and(bits); break;
      007D41 90 7D 45         [24] 1384 	mov	dptr,#00466$
      007D44 73               [24] 1385 	jmp	@a+dptr
      007D45                       1386 00466$:
      007D45 80 06            [24] 1387 	sjmp	00137$
      007D47 80 0C            [24] 1388 	sjmp	00138$
      007D49 80 12            [24] 1389 	sjmp	00139$
      007D4B 80 18            [24] 1390 	sjmp	00140$
      007D4D                       1391 00137$:
      007D4D 8F 82            [24] 1392 	mov	dpl, r7
      007D4F 12 82 2C         [24] 1393 	lcall	_layer_and
      007D52 02 7E 06         [24] 1394 	ljmp	00181$
                                   1395 ;	quantum/action.c:668: case OP_BIT_OR: layer_or(bits); break;
      007D55                       1396 00138$:
      007D55 8F 82            [24] 1397 	mov	dpl, r7
      007D57 12 82 1C         [24] 1398 	lcall	_layer_or
      007D5A 02 7E 06         [24] 1399 	ljmp	00181$
                                   1400 ;	quantum/action.c:669: case OP_BIT_XOR: layer_xor(bits); break;
      007D5D                       1401 00139$:
      007D5D 8F 82            [24] 1402 	mov	dpl, r7
      007D5F 12 82 41         [24] 1403 	lcall	_layer_xor
      007D62 02 7E 06         [24] 1404 	ljmp	00181$
                                   1405 ;	quantum/action.c:670: case OP_BIT_SET: layer_state_set(bits); break;
      007D65                       1406 00140$:
      007D65 8F 82            [24] 1407 	mov	dpl, r7
      007D67 12 81 BE         [24] 1408 	lcall	_layer_state_set
                                   1409 ;	quantum/action.c:674: break;
      007D6A 02 7E 06         [24] 1410 	ljmp	00181$
                                   1411 ;	quantum/action.c:676: case ACT_LAYER_MODS:
      007D6D                       1412 00147$:
                                   1413 ;	quantum/action.c:677: if (pressed) {
      007D6D E5 17            [12] 1414 	mov	a,_process_action_sloc0_1_0
      007D6F 60 11            [24] 1415 	jz	00149$
                                   1416 ;	quantum/action.c:678: layer_hold_on(action.layer_mods.layer);
      007D71 12 80 2A         [24] 1417 	lcall	_ak820_outline_0115
      007D74 F5 82            [12] 1418 	mov	dpl,a
      007D76 12 81 24         [24] 1419 	lcall	_layer_hold_on
                                   1420 ;	quantum/action.c:679: register_mods(action.layer_mods.mods);
      007D79 12 80 13         [24] 1421 	lcall	_ak820_outline_0078
      007D7C 12 7F 3D         [24] 1422 	lcall	_register_mods
      007D7F 02 7E 06         [24] 1423 	ljmp	00181$
      007D82                       1424 00149$:
                                   1425 ;	quantum/action.c:681: unregister_mods(action.layer_mods.mods);
      007D82 12 80 13         [24] 1426 	lcall	_ak820_outline_0078
      007D85 12 7F 51         [24] 1427 	lcall	_unregister_mods
                                   1428 ;	quantum/action.c:682: layer_hold_off(action.layer_mods.layer);
      007D88 12 80 2A         [24] 1429 	lcall	_ak820_outline_0115
      007D8B F5 82            [12] 1430 	mov	dpl,a
      007D8D 12 81 5A         [24] 1431 	lcall	_layer_hold_off
                                   1432 ;	quantum/action.c:684: break;
      007D90 02 7E 06         [24] 1433 	ljmp	00181$
                                   1434 ;	quantum/action.c:686: case ACT_LAYER_TAP_EXT:
      007D93                       1435 00152$:
                                   1436 ;	quantum/action.c:687: switch (action.layer_tap.code) {
      007D93 12 80 46         [24] 1437 	lcall	_ak820_outline_0160
      007D96 FF               [12] 1438 	mov	r7,a
      007D97 BF F1 02         [24] 1439 	cjne	r7,#0xf1,00468$
      007D9A 80 0A            [24] 1440 	sjmp	00154$
      007D9C                       1441 00468$:
      007D9C BF F2 02         [24] 1442 	cjne	r7,#0xf2,00469$
      007D9F 80 19            [24] 1443 	sjmp	00155$
      007DA1                       1444 00469$:
                                   1445 ;	quantum/action.c:703: momentary_layer_action:
      007DA1 BF F3 3B         [24] 1446 	cjne	r7,#0xf3,00160$
      007DA4 80 28            [24] 1447 	sjmp	00156$
      007DA6                       1448 00154$:
                                   1449 ;	quantum/action.c:704: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007DA6 E5 17            [12] 1450 	mov	a,_process_action_sloc0_1_0
      007DA8 60 08            [24] 1451 	jz	00206$
      007DAA 12 7F F9         [24] 1452 	lcall	_ak820_outline_0045
      007DAD 12 81 24         [24] 1453 	lcall	_layer_hold_on
      007DB0 80 54            [24] 1454 	sjmp	00181$
      007DB2                       1455 00206$:
      007DB2 12 7F F9         [24] 1456 	lcall	_ak820_outline_0045
      007DB5 12 81 5A         [24] 1457 	lcall	_layer_hold_off
                                   1458 ;	quantum/action.c:705: break;
                                   1459 ;	quantum/action.c:706: case OP_OFF_ON:
      007DB8 80 4C            [24] 1460 	sjmp	00181$
      007DBA                       1461 00155$:
                                   1462 ;	quantum/action.c:707: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007DBA E5 17            [12] 1463 	mov	a,_process_action_sloc0_1_0
      007DBC 60 08            [24] 1464 	jz	00208$
      007DBE 12 7F F9         [24] 1465 	lcall	_ak820_outline_0045
      007DC1 12 81 FF         [24] 1466 	lcall	_layer_off
      007DC4 80 40            [24] 1467 	sjmp	00181$
      007DC6                       1468 00208$:
      007DC6 12 7F F9         [24] 1469 	lcall	_ak820_outline_0045
      007DC9 12 81 E5         [24] 1470 	lcall	_layer_on
                                   1471 ;	quantum/action.c:708: break;
                                   1472 ;	quantum/action.c:709: case OP_SET_CLEAR:
      007DCC 80 38            [24] 1473 	sjmp	00181$
      007DCE                       1474 00156$:
                                   1475 ;	quantum/action.c:710: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007DCE E5 17            [12] 1476 	mov	a,_process_action_sloc0_1_0
      007DD0 60 08            [24] 1477 	jz	00210$
      007DD2 12 7F F9         [24] 1478 	lcall	_ak820_outline_0045
      007DD5 12 81 D0         [24] 1479 	lcall	_layer_move
      007DD8 80 2C            [24] 1480 	sjmp	00181$
      007DDA                       1481 00210$:
      007DDA 12 81 CB         [24] 1482 	lcall	_layer_clear
                                   1483 ;	quantum/action.c:711: break;
                                   1484 ;	quantum/action.c:757: default:
      007DDD 80 27            [24] 1485 	sjmp	00181$
      007DDF                       1486 00160$:
                                   1487 ;	quantum/action.c:764: if (pressed) {
      007DDF E5 17            [12] 1488 	mov	a,_process_action_sloc0_1_0
      007DE1 60 08            [24] 1489 	jz	00163$
                                   1490 ;	quantum/action.c:766: register_code(action.layer_tap.code);
      007DE3 12 80 13         [24] 1491 	lcall	_ak820_outline_0078
      007DE6 12 7E 1D         [24] 1492 	lcall	_register_code
                                   1493 ;	quantum/action.c:768: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007DE9 80 1B            [24] 1494 	sjmp	00181$
      007DEB                       1495 00163$:
                                   1496 ;	quantum/action.c:769: if (action.layer_tap.code == KC_CAPS) {
      007DEB 12 80 46         [24] 1497 	lcall	_ak820_outline_0160
      007DEE FF               [12] 1498 	mov	r7,a
      007DEF BF 39 0E         [24] 1499 	cjne	r7,#0x39,00175$
                                   1500 ;	quantum/action.c:770: wait_ms(TAP_HOLD_CAPS_DELAY);
      007DF2 7F 50            [12] 1501 	mov	r7,#0x50
      007DF4                       1502 00187$:
      007DF4 EF               [12] 1503 	mov	a,r7
      007DF5 60 09            [24] 1504 	jz	00175$
      007DF7 90 00 01         [24] 1505 	mov	dptr,#0x0001
      007DFA 12 62 04         [24] 1506 	lcall	_mDelaymS
      007DFD 1F               [12] 1507 	dec	r7
                                   1508 ;	quantum/action.c:772: wait_ms(TAP_CODE_DELAY);
      007DFE 80 F4            [24] 1509 	sjmp	00187$
      007E00                       1510 00175$:
                                   1511 ;	quantum/action.c:774: unregister_code(action.layer_tap.code);
      007E00 12 80 13         [24] 1512 	lcall	_ak820_outline_0078
      007E03 12 7E 8A         [24] 1513 	lcall	_unregister_code
                                   1514 ;	quantum/action.c:857: }
      007E06                       1515 00181$:
                                   1516 ;	quantum/action.c:878: switch (action.kind.id) {
      007E06 90 08 E0         [24] 1517 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007E09 E0               [24] 1518 	movx	a,@dptr
      007E0A C4               [12] 1519 	swap	a
      007E0B 54 0F            [12] 1520 	anl	a,#0x0f
      007E0D FF               [12] 1521 	mov	r7,a
      007E0E BF 08 02         [24] 1522 	cjne	r7,#0x08,00478$
      007E11 80 03            [24] 1523 	sjmp	00183$
      007E13                       1524 00478$:
      007E13 BF 09 06         [24] 1525 	cjne	r7,#0x09,00192$
                                   1526 ;	quantum/action.c:880: case ACT_LAYER_MODS:
      007E16                       1527 00183$:
                                   1528 ;	quantum/action.c:885: led_set(host_keyboard_leds());
      007E16 12 75 8F         [24] 1529 	lcall	_host_keyboard_leds
                                   1530 ;	quantum/action.c:889: }
                                   1531 ;	quantum/action.c:942: }
      007E19 02 A1 4B         [24] 1532 	ljmp	_led_set
      007E1C                       1533 00192$:
      007E1C 22               [24] 1534 	ret
                                   1535 ;------------------------------------------------------------
                                   1536 ;Allocation info for local variables in function 'register_code'
                                   1537 ;------------------------------------------------------------
                                   1538 ;code          Allocated with name '_register_code_code_10000_717'
                                   1539 ;------------------------------------------------------------
                                   1540 ;	quantum/action.c:948: __attribute__((weak)) void register_code(uint8_t code) {
                                   1541 ;	-----------------------------------------
                                   1542 ;	 function register_code
                                   1543 ;	-----------------------------------------
      007E1D                       1544 _register_code:
      007E1D E5 82            [12] 1545 	mov	a,dpl
      007E1F 90 08 E5         [24] 1546 	mov	dptr,#_register_code_code_10000_717
      007E22 F0               [24] 1547 	movx	@dptr,a
                                   1548 ;	quantum/action.c:949: if (code == KC_NO) {
      007E23 E0               [24] 1549 	movx	a,@dptr
      007E24 FF               [12] 1550 	mov	r7,a
      007E25 70 01            [24] 1551 	jnz	00123$
                                   1552 ;	quantum/action.c:950: return;
      007E27 22               [24] 1553 	ret
      007E28                       1554 00123$:
                                   1555 ;	quantum/action.c:985: } else if (IS_BASIC_KEYCODE(code)) {
      007E28 BF 04 00         [24] 1556 	cjne	r7,#0x04,00186$
      007E2B                       1557 00186$:
      007E2B 40 12            [24] 1558 	jc	00119$
      007E2D EF               [12] 1559 	mov	a,r7
      007E2E 24 5B            [12] 1560 	add	a,#0xff - 0xa4
      007E30 40 0D            [24] 1561 	jc	00119$
                                   1562 ;	free result
                                   1563 ;	quantum/action.c:990: if (!add_owned_key(code)) return;
      007E32 8F 82            [24] 1564 	mov	dpl, r7
      007E34 12 86 35         [24] 1565 	lcall	_add_owned_key
      007E37 E5 82            [12] 1566 	mov	a, dpl
      007E39 70 01            [24] 1567 	jnz	00104$
      007E3B 22               [24] 1568 	ret
      007E3C                       1569 00104$:
                                   1570 ;	quantum/action.c:1004: send_keyboard_report();
      007E3C 02 88 C9         [24] 1571 	ljmp	_send_keyboard_report
      007E3F                       1572 00119$:
                                   1573 ;	quantum/action.c:1005: } else if (IS_MODIFIER_KEYCODE(code)) {
      007E3F 12 80 4B         [24] 1574 	lcall	_ak820_outline_0168
      007E42 BF E0 00         [24] 1575 	cjne	r7,#0xe0,00190$
      007E45                       1576 00190$:
      007E45 40 1A            [24] 1577 	jc	00115$
      007E47 EF               [12] 1578 	mov	a,r7
      007E48 24 18            [12] 1579 	add	a,#0xff - 0xe7
      007E4A 40 15            [24] 1580 	jc	00115$
                                   1581 ;	free result
                                   1582 ;	quantum/action.c:1006: add_owned_mods(MOD_BIT(code));
      007E4C 74 07            [12] 1583 	mov	a,#0x07
      007E4E 5F               [12] 1584 	anl	a,r7
      007E4F 12 80 02         [24] 1585 	lcall	_ak820_outline_0064
      007E52 80 02            [24] 1586 	sjmp	00194$
      007E54                       1587 00193$:
      007E54 25 E0            [12] 1588 	add	a,acc
      007E56                       1589 00194$:
      007E56 D5 F0 FB         [24] 1590 	djnz	b,00193$
      007E59 F5 82            [12] 1591 	mov	dpl,a
      007E5B 12 85 95         [24] 1592 	lcall	_add_owned_mods
                                   1593 ;	quantum/action.c:1007: send_keyboard_report();
      007E5E 02 88 C9         [24] 1594 	ljmp	_send_keyboard_report
      007E61                       1595 00115$:
                                   1596 ;	quantum/action.c:1010: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007E61 12 80 4B         [24] 1597 	lcall	_ak820_outline_0168
      007E64 BF A5 00         [24] 1598 	cjne	r7,#0xa5,00195$
      007E67                       1599 00195$:
      007E67 40 05            [24] 1600 	jc	00113$
      007E69 EF               [12] 1601 	mov	a,r7
      007E6A 24 58            [12] 1602 	add	a,#0xff - 0xa7
      007E6C 50 0D            [24] 1603 	jnc	00108$
                                   1604 ;	free result
      007E6E                       1605 00113$:
      007E6E 12 80 4B         [24] 1606 	lcall	_ak820_outline_0168
      007E71 BF A8 00         [24] 1607 	cjne	r7,#0xa8,00198$
      007E74                       1608 00198$:
      007E74 40 13            [24] 1609 	jc	00125$
      007E76 EF               [12] 1610 	mov	a,r7
      007E77 24 3D            [12] 1611 	add	a,#0xff - 0xc2
      007E79 40 0E            [24] 1612 	jc	00125$
                                   1613 ;	free result
      007E7B                       1614 00108$:
                                   1615 ;	quantum/action.c:1012: owned_usage_key(code, true);
      007E7B 12 80 4B         [24] 1616 	lcall	_ak820_outline_0168
      007E7E 90 0B 40         [24] 1617 	mov	dptr,#_owned_usage_key_PARM_2
      007E81 74 01            [12] 1618 	mov	a,#0x01
      007E83 F0               [24] 1619 	movx	@dptr,a
      007E84 8F 82            [24] 1620 	mov	dpl, r7
                                   1621 ;	quantum/action.c:1020: register_mouse(code, true);
                                   1622 ;	quantum/action.c:1022: }
      007E86 02 87 74         [24] 1623 	ljmp	_owned_usage_key
      007E89                       1624 00125$:
      007E89 22               [24] 1625 	ret
                                   1626 ;------------------------------------------------------------
                                   1627 ;Allocation info for local variables in function 'unregister_code'
                                   1628 ;------------------------------------------------------------
                                   1629 ;code          Allocated with name '_unregister_code_code_10000_731'
                                   1630 ;------------------------------------------------------------
                                   1631 ;	quantum/action.c:1028: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1632 ;	-----------------------------------------
                                   1633 ;	 function unregister_code
                                   1634 ;	-----------------------------------------
      007E8A                       1635 _unregister_code:
      007E8A E5 82            [12] 1636 	mov	a,dpl
      007E8C 90 08 E6         [24] 1637 	mov	dptr,#_unregister_code_code_10000_731
      007E8F F0               [24] 1638 	movx	@dptr,a
                                   1639 ;	quantum/action.c:1029: if (code == KC_NO) {
      007E90 E0               [24] 1640 	movx	a,@dptr
      007E91 FF               [12] 1641 	mov	r7,a
      007E92 70 01            [24] 1642 	jnz	00121$
                                   1643 ;	quantum/action.c:1030: return;
      007E94 22               [24] 1644 	ret
      007E95                       1645 00121$:
                                   1646 ;	quantum/action.c:1062: } else if (IS_BASIC_KEYCODE(code)) {
      007E95 BF 04 00         [24] 1647 	cjne	r7,#0x04,00184$
      007E98                       1648 00184$:
      007E98 40 12            [24] 1649 	jc	00117$
      007E9A EF               [12] 1650 	mov	a,r7
      007E9B 24 5B            [12] 1651 	add	a,#0xff - 0xa4
      007E9D 40 0D            [24] 1652 	jc	00117$
                                   1653 ;	free result
                                   1654 ;	quantum/action.c:1064: if (!del_owned_key(code)) return;
      007E9F 8F 82            [24] 1655 	mov	dpl, r7
      007EA1 12 86 AE         [24] 1656 	lcall	_del_owned_key
      007EA4 E5 82            [12] 1657 	mov	a, dpl
      007EA6 70 01            [24] 1658 	jnz	00102$
      007EA8 22               [24] 1659 	ret
      007EA9                       1660 00102$:
                                   1661 ;	quantum/action.c:1071: send_keyboard_report();
      007EA9 02 88 C9         [24] 1662 	ljmp	_send_keyboard_report
      007EAC                       1663 00117$:
                                   1664 ;	quantum/action.c:1072: } else if (IS_MODIFIER_KEYCODE(code)) {
      007EAC 12 80 51         [24] 1665 	lcall	_ak820_outline_0169
      007EAF BF E0 00         [24] 1666 	cjne	r7,#0xe0,00188$
      007EB2                       1667 00188$:
      007EB2 40 1A            [24] 1668 	jc	00113$
      007EB4 EF               [12] 1669 	mov	a,r7
      007EB5 24 18            [12] 1670 	add	a,#0xff - 0xe7
      007EB7 40 15            [24] 1671 	jc	00113$
                                   1672 ;	free result
                                   1673 ;	quantum/action.c:1073: del_owned_mods(MOD_BIT(code));
      007EB9 74 07            [12] 1674 	mov	a,#0x07
      007EBB 5F               [12] 1675 	anl	a,r7
      007EBC 12 80 02         [24] 1676 	lcall	_ak820_outline_0064
      007EBF 80 02            [24] 1677 	sjmp	00192$
      007EC1                       1678 00191$:
      007EC1 25 E0            [12] 1679 	add	a,acc
      007EC3                       1680 00192$:
      007EC3 D5 F0 FB         [24] 1681 	djnz	b,00191$
      007EC6 F5 82            [12] 1682 	mov	dpl,a
      007EC8 12 85 A4         [24] 1683 	lcall	_del_owned_mods
                                   1684 ;	quantum/action.c:1074: send_keyboard_report();
      007ECB 02 88 C9         [24] 1685 	ljmp	_send_keyboard_report
      007ECE                       1686 00113$:
                                   1687 ;	quantum/action.c:1077: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007ECE 12 80 51         [24] 1688 	lcall	_ak820_outline_0169
      007ED1 BF A5 00         [24] 1689 	cjne	r7,#0xa5,00193$
      007ED4                       1690 00193$:
      007ED4 40 05            [24] 1691 	jc	00111$
      007ED6 EF               [12] 1692 	mov	a,r7
      007ED7 24 58            [12] 1693 	add	a,#0xff - 0xa7
      007ED9 50 0D            [24] 1694 	jnc	00106$
                                   1695 ;	free result
      007EDB                       1696 00111$:
      007EDB 12 80 51         [24] 1697 	lcall	_ak820_outline_0169
      007EDE BF A8 00         [24] 1698 	cjne	r7,#0xa8,00196$
      007EE1                       1699 00196$:
      007EE1 40 12            [24] 1700 	jc	00123$
      007EE3 EF               [12] 1701 	mov	a,r7
      007EE4 24 3D            [12] 1702 	add	a,#0xff - 0xc2
      007EE6 40 0D            [24] 1703 	jc	00123$
                                   1704 ;	free result
      007EE8                       1705 00106$:
                                   1706 ;	quantum/action.c:1079: owned_usage_key(code, false);
      007EE8 12 80 51         [24] 1707 	lcall	_ak820_outline_0169
      007EEB 90 0B 40         [24] 1708 	mov	dptr,#_owned_usage_key_PARM_2
      007EEE E4               [12] 1709 	clr	a
      007EEF F0               [24] 1710 	movx	@dptr,a
      007EF0 8F 82            [24] 1711 	mov	dpl, r7
                                   1712 ;	quantum/action.c:1087: register_mouse(code, false);
                                   1713 ;	quantum/action.c:1089: }
      007EF2 02 87 74         [24] 1714 	ljmp	_owned_usage_key
      007EF5                       1715 00123$:
      007EF5 22               [24] 1716 	ret
                                   1717 ;------------------------------------------------------------
                                   1718 ;Allocation info for local variables in function 'tap_code_delay'
                                   1719 ;------------------------------------------------------------
                                   1720 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1721 ;code          Allocated with name '_tap_code_delay_code_10000_744'
                                   1722 ;i             Allocated with name '_tap_code_delay_i_20000_746'
                                   1723 ;i             Allocated with name '_tap_code_delay_i_50000_749'
                                   1724 ;------------------------------------------------------------
                                   1725 ;	quantum/action.c:1096: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1726 ;	-----------------------------------------
                                   1727 ;	 function tap_code_delay
                                   1728 ;	-----------------------------------------
      007EF6                       1729 _tap_code_delay:
      007EF6 E5 82            [12] 1730 	mov	a,dpl
      007EF8 90 08 E9         [24] 1731 	mov	dptr,#_tap_code_delay_code_10000_744
      007EFB F0               [24] 1732 	movx	@dptr,a
                                   1733 ;	quantum/action.c:1097: register_code(code);
      007EFC E0               [24] 1734 	movx	a,@dptr
      007EFD FF               [12] 1735 	mov	r7,a
      007EFE F5 82            [12] 1736 	mov	dpl,a
      007F00 C0 07            [24] 1737 	push	ar7
      007F02 D1 1D            [12] 1738 	acall	_register_code
      007F04 D0 07            [24] 1739 	pop	ar7
                                   1740 ;	quantum/action.c:1098: for (uint16_t i = delay; i > 0; i--) {
      007F06 90 08 E7         [24] 1741 	mov	dptr,#_tap_code_delay_PARM_2
      007F09 12 38 5D         [24] 1742 	lcall	_ak820_outline_0080
      007F0C                       1743 00110$:
      007F0C ED               [12] 1744 	mov	a,r5
      007F0D 4E               [12] 1745 	orl	a,r6
      007F0E 60 0D            [24] 1746 	jz	00105$
                                   1747 ;	quantum/action.c:1099: wait_ms(1);
      007F10 90 00 01         [24] 1748 	mov	dptr,#0x0001
      007F13 12 62 04         [24] 1749 	lcall	_mDelaymS
                                   1750 ;	quantum/action.c:1098: for (uint16_t i = delay; i > 0; i--) {
      007F16 1D               [12] 1751 	dec	r5
      007F17 BD FF 01         [24] 1752 	cjne	r5,#0xff,00141$
      007F1A 1E               [12] 1753 	dec	r6
      007F1B                       1754 00141$:
      007F1B 80 EF            [24] 1755 	sjmp	00110$
      007F1D                       1756 00105$:
                                   1757 ;	quantum/action.c:1101: unregister_code(code);
      007F1D 8F 82            [24] 1758 	mov	dpl, r7
                                   1759 ;	quantum/action.c:1102: }
      007F1F C1 8A            [12] 1760 	ajmp	_unregister_code
                                   1761 ;------------------------------------------------------------
                                   1762 ;Allocation info for local variables in function 'tap_code'
                                   1763 ;------------------------------------------------------------
                                   1764 ;code          Allocated with name '_tap_code_code_10000_751'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	quantum/action.c:1108: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function tap_code
                                   1769 ;	-----------------------------------------
      007F21                       1770 _tap_code:
      007F21 E5 82            [12] 1771 	mov	a,dpl
      007F23 90 08 EA         [24] 1772 	mov	dptr,#_tap_code_code_10000_751
      007F26 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action.c:1109: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007F27 E0               [24] 1775 	movx	a,@dptr
      007F28 FF               [12] 1776 	mov	r7,a
      007F29 BF 39 04         [24] 1777 	cjne	r7,#0x39,00103$
      007F2C 7E 50            [12] 1778 	mov	r6,#0x50
      007F2E 80 02            [24] 1779 	sjmp	00104$
      007F30                       1780 00103$:
      007F30 7E 00            [12] 1781 	mov	r6,#0x00
      007F32                       1782 00104$:
      007F32 90 08 E7         [24] 1783 	mov	dptr,#_tap_code_delay_PARM_2
      007F35 EE               [12] 1784 	mov	a,r6
      007F36 12 38 8F         [24] 1785 	lcall	_ak820_outline_0127
      007F39 8F 82            [24] 1786 	mov	dpl, r7
                                   1787 ;	quantum/action.c:1110: }
      007F3B C1 F6            [12] 1788 	ajmp	_tap_code_delay
                                   1789 ;------------------------------------------------------------
                                   1790 ;Allocation info for local variables in function 'register_mods'
                                   1791 ;------------------------------------------------------------
                                   1792 ;mods          Allocated with name '_register_mods_mods_10000_753'
                                   1793 ;------------------------------------------------------------
                                   1794 ;	quantum/action.c:1116: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1795 ;	-----------------------------------------
                                   1796 ;	 function register_mods
                                   1797 ;	-----------------------------------------
      007F3D                       1798 _register_mods:
      007F3D E5 82            [12] 1799 	mov	a,dpl
      007F3F 90 08 EB         [24] 1800 	mov	dptr,#_register_mods_mods_10000_753
      007F42 F0               [24] 1801 	movx	@dptr,a
                                   1802 ;	quantum/action.c:1117: if (mods) {
      007F43 E0               [24] 1803 	movx	a,@dptr
      007F44 FF               [12] 1804 	mov	r7,a
      007F45 E0               [24] 1805 	movx	a,@dptr
      007F46 60 08            [24] 1806 	jz	00103$
                                   1807 ;	quantum/action.c:1118: add_owned_mods(mods);
      007F48 8F 82            [24] 1808 	mov	dpl, r7
      007F4A 12 85 95         [24] 1809 	lcall	_add_owned_mods
                                   1810 ;	quantum/action.c:1119: send_keyboard_report();
                                   1811 ;	quantum/action.c:1121: }
      007F4D 02 88 C9         [24] 1812 	ljmp	_send_keyboard_report
      007F50                       1813 00103$:
      007F50 22               [24] 1814 	ret
                                   1815 ;------------------------------------------------------------
                                   1816 ;Allocation info for local variables in function 'unregister_mods'
                                   1817 ;------------------------------------------------------------
                                   1818 ;mods          Allocated with name '_unregister_mods_mods_10000_757'
                                   1819 ;------------------------------------------------------------
                                   1820 ;	quantum/action.c:1127: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1821 ;	-----------------------------------------
                                   1822 ;	 function unregister_mods
                                   1823 ;	-----------------------------------------
      007F51                       1824 _unregister_mods:
      007F51 E5 82            [12] 1825 	mov	a,dpl
      007F53 90 08 EC         [24] 1826 	mov	dptr,#_unregister_mods_mods_10000_757
      007F56 F0               [24] 1827 	movx	@dptr,a
                                   1828 ;	quantum/action.c:1128: if (mods) {
      007F57 E0               [24] 1829 	movx	a,@dptr
      007F58 FF               [12] 1830 	mov	r7,a
      007F59 E0               [24] 1831 	movx	a,@dptr
      007F5A 60 08            [24] 1832 	jz	00103$
                                   1833 ;	quantum/action.c:1129: del_owned_mods(mods);
      007F5C 8F 82            [24] 1834 	mov	dpl, r7
      007F5E 12 85 A4         [24] 1835 	lcall	_del_owned_mods
                                   1836 ;	quantum/action.c:1130: send_keyboard_report();
                                   1837 ;	quantum/action.c:1132: }
      007F61 02 88 C9         [24] 1838 	ljmp	_send_keyboard_report
      007F64                       1839 00103$:
      007F64 22               [24] 1840 	ret
                                   1841 ;------------------------------------------------------------
                                   1842 ;Allocation info for local variables in function 'register_weak_mods'
                                   1843 ;------------------------------------------------------------
                                   1844 ;mods          Allocated with name '_register_weak_mods_mods_10000_761'
                                   1845 ;------------------------------------------------------------
                                   1846 ;	quantum/action.c:1138: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1847 ;	-----------------------------------------
                                   1848 ;	 function register_weak_mods
                                   1849 ;	-----------------------------------------
      007F65                       1850 _register_weak_mods:
      007F65 E5 82            [12] 1851 	mov	a,dpl
      007F67 90 08 ED         [24] 1852 	mov	dptr,#_register_weak_mods_mods_10000_761
      007F6A F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	quantum/action.c:1139: if (mods) {
      007F6B E0               [24] 1855 	movx	a,@dptr
      007F6C FF               [12] 1856 	mov	r7,a
      007F6D E0               [24] 1857 	movx	a,@dptr
      007F6E 60 08            [24] 1858 	jz	00103$
                                   1859 ;	quantum/action.c:1140: add_owned_weak_mods(mods);
      007F70 8F 82            [24] 1860 	mov	dpl, r7
      007F72 12 85 B2         [24] 1861 	lcall	_add_owned_weak_mods
                                   1862 ;	quantum/action.c:1141: send_keyboard_report();
                                   1863 ;	quantum/action.c:1143: }
      007F75 02 88 C9         [24] 1864 	ljmp	_send_keyboard_report
      007F78                       1865 00103$:
      007F78 22               [24] 1866 	ret
                                   1867 ;------------------------------------------------------------
                                   1868 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1869 ;------------------------------------------------------------
                                   1870 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_765'
                                   1871 ;------------------------------------------------------------
                                   1872 ;	quantum/action.c:1149: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1873 ;	-----------------------------------------
                                   1874 ;	 function unregister_weak_mods
                                   1875 ;	-----------------------------------------
      007F79                       1876 _unregister_weak_mods:
      007F79 E5 82            [12] 1877 	mov	a,dpl
      007F7B 90 08 EE         [24] 1878 	mov	dptr,#_unregister_weak_mods_mods_10000_765
      007F7E F0               [24] 1879 	movx	@dptr,a
                                   1880 ;	quantum/action.c:1150: if (mods) {
      007F7F E0               [24] 1881 	movx	a,@dptr
      007F80 FF               [12] 1882 	mov	r7,a
      007F81 E0               [24] 1883 	movx	a,@dptr
      007F82 60 08            [24] 1884 	jz	00103$
                                   1885 ;	quantum/action.c:1151: del_owned_weak_mods(mods);
      007F84 8F 82            [24] 1886 	mov	dpl, r7
      007F86 12 85 C1         [24] 1887 	lcall	_del_owned_weak_mods
                                   1888 ;	quantum/action.c:1152: send_keyboard_report();
                                   1889 ;	quantum/action.c:1154: }
      007F89 02 88 C9         [24] 1890 	ljmp	_send_keyboard_report
      007F8C                       1891 00103$:
      007F8C 22               [24] 1892 	ret
                                   1893 ;------------------------------------------------------------
                                   1894 ;Allocation info for local variables in function 'clear_keyboard'
                                   1895 ;------------------------------------------------------------
                                   1896 ;	quantum/action.c:1160: void clear_keyboard(void) {
                                   1897 ;	-----------------------------------------
                                   1898 ;	 function clear_keyboard
                                   1899 ;	-----------------------------------------
      007F8D                       1900 _clear_keyboard:
                                   1901 ;	quantum/action.c:1161: clear_mods();
      007F8D 12 89 44         [24] 1902 	lcall	_clear_mods
                                   1903 ;	quantum/action.c:1162: clear_keyboard_but_mods();
                                   1904 ;	quantum/action.c:1163: }
      007F90 E1 92            [12] 1905 	ajmp	_clear_keyboard_but_mods
                                   1906 ;------------------------------------------------------------
                                   1907 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1908 ;------------------------------------------------------------
                                   1909 ;	quantum/action.c:1169: void clear_keyboard_but_mods(void) {
                                   1910 ;	-----------------------------------------
                                   1911 ;	 function clear_keyboard_but_mods
                                   1912 ;	-----------------------------------------
      007F92                       1913 _clear_keyboard_but_mods:
                                   1914 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007F92 90 0E 99         [24] 1915 	mov	dptr,#_actual_keyboard_report
      007F95 11 54            [12] 1916 	acall	_clear_keys_from_report
                                   1917 ;	quantum/action.c:1171: clear_keyboard_but_mods_and_keys();
                                   1918 ;	quantum/action.c:1172: }
      007F97 E1 99            [12] 1919 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1920 ;------------------------------------------------------------
                                   1921 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1922 ;------------------------------------------------------------
                                   1923 ;	quantum/action.c:1178: void clear_keyboard_but_mods_and_keys(void) {
                                   1924 ;	-----------------------------------------
                                   1925 ;	 function clear_keyboard_but_mods_and_keys
                                   1926 ;	-----------------------------------------
      007F99                       1927 _clear_keyboard_but_mods_and_keys:
                                   1928 ;	quantum/action.c:1180: ak820_tapping_cancel();
      007F99 12 50 33         [24] 1929 	lcall	_ak820_tapping_cancel
                                   1930 ;	quantum/action.c:1182: ak820_tap_dance_cancel();
      007F9C 12 4C C8         [24] 1931 	lcall	_ak820_tap_dance_cancel
                                   1932 ;	quantum/action.c:1197: ak820_oneshot_cancel();
      007F9F 12 2E F0         [24] 1933 	lcall	_ak820_oneshot_cancel
                                   1934 ;	quantum/action.c:1200: ak820_combo_cancel();
      007FA2 12 35 6C         [24] 1935 	lcall	_ak820_combo_cancel
                                   1936 ;	quantum/action.c:1203: repeat_key_cancel();
      007FA5 12 AB 41         [24] 1937 	lcall	_repeat_key_cancel
                                   1938 ;	quantum/action.c:1205: clear_owned_mods();
      007FA8 12 85 D0         [24] 1939 	lcall	_clear_owned_mods
                                   1940 ;	quantum/action.c:1206: clear_owned_keys();
      007FAB 12 86 08         [24] 1941 	lcall	_clear_owned_keys
                                   1942 ;	quantum/action.c:1207: clear_owned_usages();
      007FAE 12 87 3C         [24] 1943 	lcall	_clear_owned_usages
                                   1944 ;	quantum/action.c:1208: layer_hold_clear();
      007FB1 12 81 91         [24] 1945 	lcall	_layer_hold_clear
                                   1946 ;	quantum/action.c:1210: clear_macro_tri_layer();
      007FB4 12 A5 F7         [24] 1947 	lcall	_clear_macro_tri_layer
                                   1948 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007FB7 90 0E 99         [24] 1949 	mov	dptr,#_actual_keyboard_report
      007FBA 11 54            [12] 1950 	acall	_clear_keys_from_report
                                   1951 ;	quantum/action.c:1215: host_system_send(0);
      007FBC 90 00 00         [24] 1952 	mov	dptr,#0x0000
      007FBF 12 76 2A         [24] 1953 	lcall	_host_system_send
                                   1954 ;	quantum/action.c:1216: host_consumer_send(0);
      007FC2 90 00 00         [24] 1955 	mov	dptr,#0x0000
      007FC5 12 76 59         [24] 1956 	lcall	_host_consumer_send
                                   1957 ;	quantum/action.c:1218: clear_weak_mods();
      007FC8 12 89 79         [24] 1958 	lcall	_clear_weak_mods
                                   1959 ;	quantum/action.c:1219: send_keyboard_report();
                                   1960 ;	quantum/action.c:1227: }
      007FCB 02 88 C9         [24] 1961 	ljmp	_send_keyboard_report
                                   1962 ;------------------------------------------------------------
                                   1963 ;Allocation info for local variables in function 'is_tap_record'
                                   1964 ;------------------------------------------------------------
                                   1965 ;record        Allocated with name '_is_tap_record_record_10000_781'
                                   1966 ;action        Allocated with name '_is_tap_record_action_10001_785'
                                   1967 ;------------------------------------------------------------
                                   1968 ;	quantum/action.c:1233: bool is_tap_record(keyrecord_t *record) {
                                   1969 ;	-----------------------------------------
                                   1970 	.area CSEG    (CODE)
                                   1971 	.area CONST   (CODE)
                                   1972 	.area XINIT   (CODE)
      00CB7B                       1973 __xinit__disable_action_cache:
      00CB7B 00                    1974 	.db #0x00	;  0
                                   1975 	.area CABS    (ABS,CODE)
                                   1976 
                                   1977 ; Experimental exact instruction outlining.
                                   1978 	.globl _ak820_outline_0001
                                   1979 	.globl _ak820_outline_0005
                                   1980 	.globl _ak820_outline_0007
                                   1981 	.globl _ak820_outline_0009
                                   1982 	.globl _ak820_outline_0012
                                   1983 	.globl _ak820_outline_0013
                                   1984 	.globl _ak820_outline_0014
                                   1985 	.globl _ak820_outline_0015
                                   1986 	.globl _ak820_outline_0019
                                   1987 	.globl _ak820_outline_0022
                                   1988 	.globl _ak820_outline_0023
                                   1989 	.globl _ak820_outline_0035
                                   1990 	.globl _ak820_outline_0038
                                   1991 	.globl _ak820_outline_0045
                                   1992 	.globl _ak820_outline_0060
                                   1993 	.globl _ak820_outline_0064
                                   1994 	.globl _ak820_outline_0073
                                   1995 	.globl _ak820_outline_0074
                                   1996 	.globl _ak820_outline_0078
                                   1997 	.globl _ak820_outline_0079
                                   1998 	.globl _ak820_outline_0080
                                   1999 	.globl _ak820_outline_0090
                                   2000 	.globl _ak820_outline_0108
                                   2001 	.globl _ak820_outline_0109
                                   2002 	.globl _ak820_outline_0111
                                   2003 	.globl _ak820_outline_0113
                                   2004 	.globl _ak820_outline_0114
                                   2005 	.globl _ak820_outline_0115
                                   2006 	.globl _ak820_outline_0120
                                   2007 	.globl _ak820_outline_0123
                                   2008 	.globl _ak820_outline_0126
                                   2009 	.globl _ak820_outline_0127
                                   2010 	.globl _ak820_outline_0133
                                   2011 	.globl _ak820_outline_0135
                                   2012 	.globl _ak820_outline_0143
                                   2013 	.globl _ak820_outline_0147
                                   2014 	.globl _ak820_outline_0150
                                   2015 	.globl _ak820_outline_0156
                                   2016 	.globl _ak820_outline_0158
                                   2017 	.globl _ak820_outline_0160
                                   2018 	.globl _ak820_outline_0168
                                   2019 	.globl _ak820_outline_0169
                                   2020 	.globl _ak820_outline_0188
                                   2021 
                                   2022 	.area CSEG (CODE)
                                   2023 ; function ak820_outline_0014
      007FCE                       2024 _ak820_outline_0014:
      007FCE 2D               [12] 2025 	add	a,r5
      007FCF F9               [12] 2026 	mov	r1,a
      007FD0 E4               [12] 2027 	clr	a
      007FD1 3E               [12] 2028 	addc	a,r6
      007FD2 FA               [12] 2029 	mov	r2,a
      007FD3 8F 03            [24] 2030 	mov	ar3,r7
      007FD5 89 82            [24] 2031 	mov	dpl,r1
      007FD7 8A 83            [24] 2032 	mov	dph,r2
      007FD9 8B F0            [24] 2033 	mov	b,r3
      007FDB 22               [24] 2034 	ret
                                   2035 
                                   2036 	.area CSEG (CODE)
                                   2037 ; function ak820_outline_0015
      007FDC                       2038 _ak820_outline_0015:
      007FDC 2D               [12] 2039 	add	a,r5
      007FDD FA               [12] 2040 	mov	r2,a
      007FDE E4               [12] 2041 	clr	a
      007FDF 3E               [12] 2042 	addc	a,r6
      007FE0 FB               [12] 2043 	mov	r3,a
      007FE1 8F 04            [24] 2044 	mov	ar4,r7
      007FE3 8A 82            [24] 2045 	mov	dpl,r2
      007FE5 8B 83            [24] 2046 	mov	dph,r3
      007FE7 8C F0            [24] 2047 	mov	b,r4
      007FE9 22               [24] 2048 	ret
                                   2049 
                                   2050 	.area CSEG (CODE)
                                   2051 ; function ak820_outline_0022
      007FEA                       2052 _ak820_outline_0022:
      007FEA 8E 82            [24] 2053 	mov	dpl,r6
      007FEC 8F 83            [24] 2054 	mov	dph,r7
      007FEE A3               [24] 2055 	inc	dptr
      007FEF E0               [24] 2056 	movx	a,@dptr
      007FF0 FC               [12] 2057 	mov	r4,a
      007FF1 7D 00            [12] 2058 	mov	r5,#0x00
      007FF3 8E 82            [24] 2059 	mov	dpl,r6
      007FF5 8F 83            [24] 2060 	mov	dph,r7
      007FF7 E0               [24] 2061 	movx	a,@dptr
      007FF8 22               [24] 2062 	ret
                                   2063 
                                   2064 	.area CSEG (CODE)
                                   2065 ; function ak820_outline_0045
      007FF9                       2066 _ak820_outline_0045:
      007FF9 90 08 E0         [24] 2067 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007FFC E0               [24] 2068 	movx	a,@dptr
      007FFD 54 1F            [12] 2069 	anl	a,#0x1f
      007FFF F5 82            [12] 2070 	mov	dpl,a
      008001 22               [24] 2071 	ret
                                   2072 
                                   2073 	.area CSEG (CODE)
                                   2074 ; function ak820_outline_0064
      008002                       2075 _ak820_outline_0064:
      008002 F5 F0            [12] 2076 	mov	b,a
      008004 05 F0            [12] 2077 	inc	b
      008006 74 01            [12] 2078 	mov	a,#0x01
      008008 22               [24] 2079 	ret
                                   2080 
                                   2081 	.area CSEG (CODE)
                                   2082 ; function ak820_outline_0073
      008009                       2083 _ak820_outline_0073:
      008009 90 0E 76         [24] 2084 	mov	dptr,#___memcpy_PARM_3
      00800C 74 06            [12] 2085 	mov	a,#0x06
      00800E F0               [24] 2086 	movx	@dptr,a
      00800F E4               [12] 2087 	clr	a
      008010 A3               [24] 2088 	inc	dptr
      008011 F0               [24] 2089 	movx	@dptr,a
      008012 22               [24] 2090 	ret
                                   2091 
                                   2092 	.area CSEG (CODE)
                                   2093 ; function ak820_outline_0078
      008013                       2094 _ak820_outline_0078:
      008013 90 08 DF         [24] 2095 	mov	dptr,#_process_action_PARM_2
      008016 E0               [24] 2096 	movx	a,@dptr
      008017 F5 82            [12] 2097 	mov	dpl,a
      008019 22               [24] 2098 	ret
                                   2099 
                                   2100 	.area CSEG (CODE)
                                   2101 ; function ak820_outline_0090
      00801A                       2102 _ak820_outline_0090:
      00801A 90 08 E0         [24] 2103 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00801D E0               [24] 2104 	movx	a,@dptr
      00801E 03               [12] 2105 	rr	a
      00801F 03               [12] 2106 	rr	a
      008020 54 03            [12] 2107 	anl	a,#0x03
      008022 22               [24] 2108 	ret
                                   2109 
                                   2110 	.area CSEG (CODE)
                                   2111 ; function ak820_outline_0114
      008023                       2112 _ak820_outline_0114:
      008023 8E 82            [24] 2113 	mov	dpl,r6
      008025 8F 83            [24] 2114 	mov	dph,r7
      008027 8D F0            [24] 2115 	mov	b,r5
      008029 22               [24] 2116 	ret
                                   2117 
                                   2118 	.area CSEG (CODE)
                                   2119 ; function ak820_outline_0115
      00802A                       2120 _ak820_outline_0115:
      00802A 90 08 E0         [24] 2121 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00802D E0               [24] 2122 	movx	a,@dptr
      00802E 54 0F            [12] 2123 	anl	a,#0x0f
      008030 22               [24] 2124 	ret
                                   2125 
                                   2126 	.area CSEG (CODE)
                                   2127 ; function ak820_outline_0133
      008031                       2128 _ak820_outline_0133:
      008031 90 08 DF         [24] 2129 	mov	dptr,#_process_action_PARM_2
      008034 E0               [24] 2130 	movx	a,@dptr
      008035 FE               [12] 2131 	mov	r6,a
      008036 A3               [24] 2132 	inc	dptr
      008037 E0               [24] 2133 	movx	a,@dptr
      008038 54 03            [12] 2134 	anl	a,#0x03
      00803A FF               [12] 2135 	mov	r7,a
      00803B 22               [24] 2136 	ret
                                   2137 
                                   2138 	.area CSEG (CODE)
                                   2139 ; function ak820_outline_0147
      00803C                       2140 _ak820_outline_0147:
      00803C 74 07            [12] 2141 	mov	a,#0x07
      00803E 2D               [12] 2142 	add	a,r5
      00803F F8               [12] 2143 	mov	r0,a
      008040 E4               [12] 2144 	clr	a
      008041 3E               [12] 2145 	addc	a,r6
      008042 F9               [12] 2146 	mov	r1,a
      008043 8F 02            [24] 2147 	mov	ar2,r7
      008045 22               [24] 2148 	ret
                                   2149 
                                   2150 	.area CSEG (CODE)
                                   2151 ; function ak820_outline_0160
      008046                       2152 _ak820_outline_0160:
      008046 90 08 DF         [24] 2153 	mov	dptr,#_process_action_PARM_2
      008049 E0               [24] 2154 	movx	a,@dptr
      00804A 22               [24] 2155 	ret
                                   2156 
                                   2157 	.area CSEG (CODE)
                                   2158 ; function ak820_outline_0168
      00804B                       2159 _ak820_outline_0168:
      00804B 90 08 E5         [24] 2160 	mov	dptr,#_register_code_code_10000_717
      00804E E0               [24] 2161 	movx	a,@dptr
      00804F FF               [12] 2162 	mov	r7,a
      008050 22               [24] 2163 	ret
                                   2164 
                                   2165 	.area CSEG (CODE)
                                   2166 ; function ak820_outline_0169
      008051                       2167 _ak820_outline_0169:
      008051 90 08 E6         [24] 2168 	mov	dptr,#_unregister_code_code_10000_731
      008054 E0               [24] 2169 	movx	a,@dptr
      008055 FF               [12] 2170 	mov	r7,a
      008056 22               [24] 2171 	ret
                                   2172 
                                   2173 	.area CSEG (CODE)
                                   2174 ; function ak820_outline_0188
      008057                       2175 _ak820_outline_0188:
      008057 F0               [24] 2176 	movx	@dptr,a
      008058 EB               [12] 2177 	mov	a,r3
      008059 A3               [24] 2178 	inc	dptr
      00805A F0               [24] 2179 	movx	@dptr,a
      00805B 22               [24] 2180 	ret
