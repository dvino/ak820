                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_tap_dance_process
                                     18 	.globl _process_repeat_key
                                     19 	.globl _process_last_key
                                     20 	.globl _process_caps_word
                                     21 	.globl _process_record_via
                                     22 	.globl _mcu_reset
                                     23 	.globl _bootloader_jump
                                     24 	.globl _ak820_resolve_key
                                     25 	.globl _default_layer_set
                                     26 	.globl _clear_keyboard
                                     27 	.globl _unregister_weak_mods
                                     28 	.globl _register_weak_mods
                                     29 	.globl _unregister_mods
                                     30 	.globl _register_mods
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _eeconfig_disable
                                     34 	.globl _rgb_matrix_set_suspend_state
                                     35 	.globl _rgb_matrix_task
                                     36 	.globl _mDelaymS
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _process_record_quantum_helper_PARM_2
                                    281 	.globl _get_record_keycode_PARM_2
                                    282 	.globl _post_process_record_user_PARM_2
                                    283 	.globl _post_process_record_kb_PARM_2
                                    284 	.globl _process_record_user_PARM_2
                                    285 	.globl _process_record_kb_PARM_2
                                    286 	.globl _pre_process_record_user_PARM_2
                                    287 	.globl _pre_process_record_kb_PARM_2
                                    288 	.globl _register_code16
                                    289 	.globl _unregister_code16
                                    290 	.globl _pre_process_record_kb
                                    291 	.globl _pre_process_record_user
                                    292 	.globl _process_action_kb
                                    293 	.globl _process_record_kb
                                    294 	.globl _process_record_user
                                    295 	.globl _post_process_record_kb
                                    296 	.globl _post_process_record_user
                                    297 	.globl _reset_keyboard
                                    298 	.globl _soft_reset_keyboard
                                    299 	.globl _get_record_keycode
                                    300 	.globl _pre_process_record_quantum
                                    301 	.globl _post_process_record_quantum
                                    302 	.globl _process_record_quantum
                                    303 	.globl _process_record_quantum_helper
                                    304 	.globl _shutdown_user
                                    305 ;--------------------------------------------------------
                                    306 ; special function registers
                                    307 ;--------------------------------------------------------
                                    308 	.area RSEG    (ABS,DATA)
      000000                        309 	.org 0x0000
                           0000D0   310 _PSW	=	0x00d0
                           0000E0   311 _ACC	=	0x00e0
                           0000F0   312 _B	=	0x00f0
                           0000FD   313 _A_INV	=	0x00fd
                           000081   314 _SP	=	0x0081
                           000082   315 _DPL	=	0x0082
                           000083   316 _DPH	=	0x0083
                           0000A1   317 _SAFE_MOD	=	0x00a1
                           0000B1   318 _GLOBAL_CFG	=	0x00b1
                           000087   319 _PCON	=	0x0087
                           0000BA   320 _POWER_CFG	=	0x00ba
                           0000B9   321 _CLOCK_CFG	=	0x00b9
                           0000A9   322 _WAKE_CTRL	=	0x00a9
                           0000FE   323 _RESET_KEEP	=	0x00fe
                           0000FF   324 _WDOG_COUNT	=	0x00ff
                           0000A8   325 _IE	=	0x00a8
                           0000B8   326 _IP	=	0x00b8
                           0000E8   327 _IE_EX	=	0x00e8
                           0000E9   328 _IP_EX	=	0x00e9
                           0000B2   329 _GPIO_IE	=	0x00b2
                           008584   330 _ROM_ADDR	=	0x8584
                           000084   331 _ROM_ADDR_L	=	0x0084
                           000085   332 _ROM_ADDR_H	=	0x0085
                           008F8E   333 _ROM_DATA_HI	=	0x8f8e
                           00008E   334 _ROM_DATA_HL	=	0x008e
                           00008F   335 _ROM_DATA_HH	=	0x008f
                           000086   336 _ROM_CTRL	=	0x0086
                           000080   337 _P0	=	0x0080
                           0000C4   338 _P0_MOD_OC	=	0x00c4
                           0000C5   339 _P0_DIR_PU	=	0x00c5
                           000090   340 _P1	=	0x0090
                           000092   341 _P1_MOD_OC	=	0x0092
                           000093   342 _P1_DIR_PU	=	0x0093
                           0000A0   343 _P2	=	0x00a0
                           000094   344 _P2_MOD_OC	=	0x0094
                           000095   345 _P2_DIR_PU	=	0x0095
                           0000B0   346 _P3	=	0x00b0
                           000096   347 _P3_MOD_OC	=	0x0096
                           000097   348 _P3_DIR_PU	=	0x0097
                           0000C0   349 _P4	=	0x00c0
                           0000C2   350 _P4_MOD_OC	=	0x00c2
                           0000C3   351 _P4_DIR_PU	=	0x00c3
                           0000C1   352 _P4_LED_KEY	=	0x00c1
                           0000AA   353 _P5_IN	=	0x00aa
                           0000AB   354 _P5_OUT_PU	=	0x00ab
                           0000AC   355 _P5_DIR	=	0x00ac
                           0000AD   356 _P6_IN	=	0x00ad
                           0000AE   357 _P6_OUT_PU	=	0x00ae
                           0000AF   358 _P6_DIR	=	0x00af
                           0000F1   359 _P7	=	0x00f1
                           0000A2   360 _XBUS_AUX	=	0x00a2
                           000088   361 _TCON	=	0x0088
                           000089   362 _TMOD	=	0x0089
                           00008A   363 _TL0	=	0x008a
                           00008B   364 _TL1	=	0x008b
                           00008C   365 _TH0	=	0x008c
                           00008D   366 _TH1	=	0x008d
                           000098   367 _SCON	=	0x0098
                           000099   368 _SBUF	=	0x0099
                           0000C8   369 _T2CON	=	0x00c8
                           0000C9   370 _T2MOD	=	0x00c9
                           00CBCA   371 _RCAP2	=	0xcbca
                           0000CA   372 _RCAP2L	=	0x00ca
                           0000CB   373 _RCAP2H	=	0x00cb
                           00CDCC   374 _T2COUNT	=	0xcdcc
                           0000CC   375 _TL2	=	0x00cc
                           0000CD   376 _TH2	=	0x00cd
                           00CFCE   377 _T2CAP1	=	0xcfce
                           0000CE   378 _T2CAP1L	=	0x00ce
                           0000CF   379 _T2CAP1H	=	0x00cf
                           0000F8   380 _SPI0_STAT	=	0x00f8
                           0000F9   381 _SPI0_DATA	=	0x00f9
                           0000FA   382 _SPI0_CTRL	=	0x00fa
                           0000FB   383 _SPI0_CK_SE	=	0x00fb
                           0000FC   384 _SPI0_SETUP	=	0x00fc
                           0000BC   385 _SCON1	=	0x00bc
                           0000BD   386 _SBUF1	=	0x00bd
                           0000BE   387 _SBAUD1	=	0x00be
                           0000BF   388 _SIF1	=	0x00bf
                           0000B4   389 _SPI1_STAT	=	0x00b4
                           0000B5   390 _SPI1_DATA	=	0x00b5
                           0000B6   391 _SPI1_CTRL	=	0x00b6
                           0000B7   392 _SPI1_CK_SE	=	0x00b7
                           0000F3   393 _ADC_CTRL	=	0x00f3
                           00F5F4   394 _ADC_DAT	=	0xf5f4
                           0000F4   395 _ADC_DAT_L	=	0x00f4
                           0000F5   396 _ADC_DAT_H	=	0x00f5
                           0000F6   397 _ADC_CHAN	=	0x00f6
                           0000A6   398 _LED_COMMON	=	0x00a6
                           0000A7   399 _LED_PWM_OE	=	0x00a7
                           00C7C6   400 _LED_DMA	=	0xc7c6
                           0000C6   401 _LED_DMA_L	=	0x00c6
                           0000C7   402 _LED_DMA_H	=	0x00c7
                           0000F7   403 _LED_STATUS	=	0x00f7
                           0000B3   404 _I2CX_INT	=	0x00b3
                           0000BB   405 _I2CS_INT_ST	=	0x00bb
                                    406 ;--------------------------------------------------------
                                    407 ; special function bits
                                    408 ;--------------------------------------------------------
                                    409 	.area RSEG    (ABS,DATA)
      000000                        410 	.org 0x0000
                           0000D7   411 _CY	=	0x00d7
                           0000D6   412 _AC	=	0x00d6
                           0000D5   413 _F0	=	0x00d5
                           0000D4   414 _RS1	=	0x00d4
                           0000D3   415 _RS0	=	0x00d3
                           0000D2   416 _OV	=	0x00d2
                           0000D1   417 _F1	=	0x00d1
                           0000D0   418 _P	=	0x00d0
                           0000AF   419 _EA	=	0x00af
                           0000AE   420 _E_DIS	=	0x00ae
                           0000AD   421 _ET2	=	0x00ad
                           0000AC   422 _ES	=	0x00ac
                           0000AB   423 _ET1	=	0x00ab
                           0000AA   424 _EX1	=	0x00aa
                           0000A9   425 _ET0	=	0x00a9
                           0000A8   426 _EX0	=	0x00a8
                           0000BF   427 _PH_FLAG	=	0x00bf
                           0000BE   428 _PL_FLAG	=	0x00be
                           0000BD   429 _PT2	=	0x00bd
                           0000BC   430 _PS	=	0x00bc
                           0000BB   431 _PT1	=	0x00bb
                           0000BA   432 _PX1	=	0x00ba
                           0000B9   433 _PT0	=	0x00b9
                           0000B8   434 _PX0	=	0x00b8
                           0000EF   435 _IE_WDOG	=	0x00ef
                           0000EE   436 _IE_GPIO	=	0x00ee
                           0000ED   437 _IE_PWM_I2C	=	0x00ed
                           0000EC   438 _IE_UART1	=	0x00ec
                           0000EB   439 _IE_ADC	=	0x00eb
                           0000E9   440 _IE_USB	=	0x00e9
                           0000E8   441 _IE_SPI0	=	0x00e8
                           000087   442 _P0_7	=	0x0087
                           000086   443 _P0_6	=	0x0086
                           000085   444 _P0_5	=	0x0085
                           000084   445 _P0_4	=	0x0084
                           000083   446 _P0_3	=	0x0083
                           000082   447 _P0_2	=	0x0082
                           000081   448 _P0_1	=	0x0081
                           000080   449 _P0_0	=	0x0080
                           000081   450 _SDA0	=	0x0081
                           000080   451 _SCL0	=	0x0080
                           000083   452 _TXD_	=	0x0083
                           000082   453 _RXD_	=	0x0082
                           000085   454 _AIN13	=	0x0085
                           000084   455 _AIN12	=	0x0084
                           000083   456 _AIN11	=	0x0083
                           000082   457 _AIN10	=	0x0082
                           000081   458 _AIN9	=	0x0081
                           000080   459 _AIN8	=	0x0080
                           000097   460 _P1_7	=	0x0097
                           000096   461 _P1_6	=	0x0096
                           000095   462 _P1_5	=	0x0095
                           000094   463 _P1_4	=	0x0094
                           000093   464 _P1_3	=	0x0093
                           000092   465 _P1_2	=	0x0092
                           000091   466 _P1_1	=	0x0091
                           000090   467 _P1_0	=	0x0090
                           000097   468 _TXD1_	=	0x0097
                           000096   469 _RXD1_	=	0x0096
                           000097   470 _SCK	=	0x0097
                           000096   471 _MISO	=	0x0096
                           000095   472 _MOSI	=	0x0095
                           000094   473 _SCS	=	0x0094
                           000092   474 _INT0_	=	0x0092
                           000091   475 _T2EX	=	0x0091
                           000091   476 _CAP2	=	0x0091
                           000090   477 _T2	=	0x0090
                           000090   478 _CAP1	=	0x0090
                           000097   479 _AIN7	=	0x0097
                           000096   480 _AIN6	=	0x0096
                           000095   481 _AIN5	=	0x0095
                           000094   482 _AIN4	=	0x0094
                           000093   483 _AIN3	=	0x0093
                           000092   484 _AIN2	=	0x0092
                           000091   485 _AIN1	=	0x0091
                           000090   486 _AIN0	=	0x0090
                           0000A7   487 _P2_7	=	0x00a7
                           0000A6   488 _P2_6	=	0x00a6
                           0000A5   489 _P2_5	=	0x00a5
                           0000A4   490 _P2_4	=	0x00a4
                           0000A3   491 _P2_3	=	0x00a3
                           0000A2   492 _P2_2	=	0x00a2
                           0000A1   493 _P2_1	=	0x00a1
                           0000A0   494 _P2_0	=	0x00a0
                           0000A7   495 _TXD1	=	0x00a7
                           0000A6   496 _RXD1	=	0x00a6
                           0000A5   497 _T2EX_	=	0x00a5
                           0000A5   498 _CAP2_	=	0x00a5
                           0000A4   499 _T2_	=	0x00a4
                           0000A4   500 _CAP1_	=	0x00a4
                           0000B7   501 _P3_7	=	0x00b7
                           0000B6   502 _P3_6	=	0x00b6
                           0000B5   503 _P3_5	=	0x00b5
                           0000B4   504 _P3_4	=	0x00b4
                           0000B3   505 _P3_3	=	0x00b3
                           0000B2   506 _P3_2	=	0x00b2
                           0000B1   507 _P3_1	=	0x00b1
                           0000B0   508 _P3_0	=	0x00b0
                           0000B7   509 _SCK1	=	0x00b7
                           0000B6   510 _MISO1	=	0x00b6
                           0000B5   511 _MOSI1	=	0x00b5
                           0000B5   512 _T1	=	0x00b5
                           0000B4   513 _T0	=	0x00b4
                           0000B3   514 _INT1	=	0x00b3
                           0000B2   515 _INT0	=	0x00b2
                           0000B1   516 _TXD	=	0x00b1
                           0000B0   517 _RXD	=	0x00b0
                           0000C6   518 _P4_6	=	0x00c6
                           0000C5   519 _P4_5	=	0x00c5
                           0000C4   520 _P4_4	=	0x00c4
                           0000C3   521 _P4_3	=	0x00c3
                           0000C2   522 _P4_2	=	0x00c2
                           0000C1   523 _P4_1	=	0x00c1
                           0000C0   524 _P4_0	=	0x00c0
                           00008F   525 _TF1	=	0x008f
                           00008E   526 _TR1	=	0x008e
                           00008D   527 _TF0	=	0x008d
                           00008C   528 _TR0	=	0x008c
                           00008B   529 _IE1	=	0x008b
                           00008A   530 _IT1	=	0x008a
                           000089   531 _IE0	=	0x0089
                           000088   532 _IT0	=	0x0088
                           00009F   533 _SM0	=	0x009f
                           00009E   534 _SM1	=	0x009e
                           00009D   535 _SM2	=	0x009d
                           00009C   536 _REN	=	0x009c
                           00009B   537 _TB8	=	0x009b
                           00009A   538 _RB8	=	0x009a
                           000099   539 _TI	=	0x0099
                           000098   540 _RI	=	0x0098
                           0000CF   541 _TF2	=	0x00cf
                           0000CF   542 _CAP1F	=	0x00cf
                           0000CE   543 _EXF2	=	0x00ce
                           0000CD   544 _RCLK	=	0x00cd
                           0000CC   545 _TCLK	=	0x00cc
                           0000CB   546 _EXEN2	=	0x00cb
                           0000CA   547 _TR2	=	0x00ca
                           0000C9   548 _C_T2	=	0x00c9
                           0000C8   549 _CP_RL2	=	0x00c8
                           0000FF   550 _S0_FST_ACT	=	0x00ff
                           0000FE   551 _S0_IF_OV	=	0x00fe
                           0000FD   552 _S0_IF_FIRST	=	0x00fd
                           0000FC   553 _S0_IF_BYTE	=	0x00fc
                           0000FB   554 _S0_FREE	=	0x00fb
                           0000FA   555 _S0_T_FIFO	=	0x00fa
                           0000F8   556 _S0_R_FIFO	=	0x00f8
                           0000F7   557 _ADC_START	=	0x00f7
                                    558 ;--------------------------------------------------------
                                    559 ; overlayable register banks
                                    560 ;--------------------------------------------------------
                                    561 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        562 	.ds 8
                                    563 ;--------------------------------------------------------
                                    564 ; internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area DSEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; overlayable items in internal ram
                                    569 ;--------------------------------------------------------
                                    570 ;--------------------------------------------------------
                                    571 ; indirectly addressable internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area ISEG    (DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; absolute internal ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area IABS    (ABS,DATA)
                                    578 	.area IABS    (ABS,DATA)
                                    579 ;--------------------------------------------------------
                                    580 ; bit data
                                    581 ;--------------------------------------------------------
                                    582 	.area BSEG    (BIT)
      000028                        583 _get_record_keycode_sloc0_1_0:
      000028                        584 	.ds 1
      000029                        585 _pre_process_record_quantum_sloc0_1_0:
      000029                        586 	.ds 1
      00002A                        587 _process_ak820_nkro_sloc0_1_0:
      00002A                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; paged external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area PSEG    (PAG,XDATA)
                                    593 ;--------------------------------------------------------
                                    594 ; uninitialized external ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area XSEG    (XDATA)
      000C98                        597 _extract_mod_bits_code_10000_606:
      000C98                        598 	.ds 2
      000C9A                        599 _register_code16_code_10000_612:
      000C9A                        600 	.ds 2
      000C9C                        601 _unregister_code16_code_10000_617:
      000C9C                        602 	.ds 2
      000C9E                        603 _pre_process_record_kb_PARM_2:
      000C9E                        604 	.ds 3
      000CA1                        605 _pre_process_record_kb_keycode_10000_631:
      000CA1                        606 	.ds 2
      000CA3                        607 _pre_process_record_user_PARM_2:
      000CA3                        608 	.ds 3
      000CA6                        609 _process_record_kb_PARM_2:
      000CA6                        610 	.ds 3
      000CA9                        611 _process_record_kb_keycode_10000_637:
      000CA9                        612 	.ds 2
      000CAB                        613 _process_record_user_PARM_2:
      000CAB                        614 	.ds 3
      000CAE                        615 _post_process_record_kb_PARM_2:
      000CAE                        616 	.ds 3
      000CB1                        617 _post_process_record_kb_keycode_10000_641:
      000CB1                        618 	.ds 2
      000CB3                        619 _post_process_record_user_PARM_2:
      000CB3                        620 	.ds 3
      000CB6                        621 _get_record_keycode_PARM_2:
      000CB6                        622 	.ds 1
      000CB7                        623 _get_record_keycode_record_argument_10000_655:
      000CB7                        624 	.ds 3
      000CBA                        625 _pre_process_record_quantum_record_argument_10000_661:
      000CBA                        626 	.ds 3
      000CBD                        627 _post_process_record_quantum_record_10000_664:
      000CBD                        628 	.ds 3
      000CC0                        629 _process_record_quantum_record_10000_666:
      000CC0                        630 	.ds 3
      000CC3                        631 _process_ak820_nkro_PARM_2:
      000CC3                        632 	.ds 3
      000CC6                        633 _process_ak820_nkro_keycode_10000_668:
      000CC6                        634 	.ds 2
      000CC8                        635 _process_record_quantum_helper_PARM_2:
      000CC8                        636 	.ds 3
      000CCB                        637 _process_record_quantum_helper_keycode_10000_673:
      000CCB                        638 	.ds 2
      000CCD                        639 _get_u8_str_last_num_10000_699:
      000CCD                        640 	.ds 1
      000CCE                        641 _get_u16_str_last_num_10000_703:
      000CCE                        642 	.ds 2
                                    643 ;--------------------------------------------------------
                                    644 ; absolute external ram data
                                    645 ;--------------------------------------------------------
                                    646 	.area XABS    (ABS,XDATA)
                                    647 ;--------------------------------------------------------
                                    648 ; initialized external ram data
                                    649 ;--------------------------------------------------------
                                    650 	.area XISEG   (XDATA)
                                    651 	.area HOME    (CODE)
                                    652 	.area GSINIT0 (CODE)
                                    653 	.area GSINIT1 (CODE)
                                    654 	.area GSINIT2 (CODE)
                                    655 	.area GSINIT3 (CODE)
                                    656 	.area GSINIT4 (CODE)
                                    657 	.area GSINIT5 (CODE)
                                    658 	.area GSINIT  (CODE)
                                    659 	.area GSFINAL (CODE)
                                    660 	.area CSEG    (CODE)
                                    661 ;--------------------------------------------------------
                                    662 ; global & static initialisations
                                    663 ;--------------------------------------------------------
                                    664 	.area HOME    (CODE)
                                    665 	.area GSINIT  (CODE)
                                    666 	.area GSFINAL (CODE)
                                    667 	.area GSINIT  (CODE)
                                    668 ;------------------------------------------------------------
                                    669 ;Allocation info for local variables in function 'get_u8_str'
                                    670 ;------------------------------------------------------------
                                    671 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    672 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_698'
                                    673 ;buf           Allocated with name '_get_u8_str_buf_10000_699'
                                    674 ;last_num      Allocated with name '_get_u8_str_last_num_10000_699'
                                    675 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_699'
                                    676 ;------------------------------------------------------------
                                    677 ;	quantum/quantum.c:778: static uint8_t last_num = 0xFF;
      0030F3 90 0C CD         [24]  678 	mov	dptr,#_get_u8_str_last_num_10000_699
      0030F6 74 FF            [12]  679 	mov	a,#0xff
      0030F8 F0               [24]  680 	movx	@dptr,a
                                    681 ;------------------------------------------------------------
                                    682 ;Allocation info for local variables in function 'get_u16_str'
                                    683 ;------------------------------------------------------------
                                    684 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    685 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_702'
                                    686 ;buf           Allocated with name '_get_u16_str_buf_10000_703'
                                    687 ;last_num      Allocated with name '_get_u16_str_last_num_10000_703'
                                    688 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_703'
                                    689 ;------------------------------------------------------------
                                    690 ;	quantum/quantum.c:798: static uint16_t last_num = 0xFF;
      0030F9 90 0C CE         [24]  691 	mov	dptr,#_get_u16_str_last_num_10000_703
      0030FC 74 FF            [12]  692 	mov	a,#0xff
      0030FE F0               [24]  693 	movx	@dptr,a
      0030FF E4               [12]  694 	clr	a
      003100 A3               [24]  695 	inc	dptr
      003101 F0               [24]  696 	movx	@dptr,a
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    708 ;------------------------------------------------------------
                                    709 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    710 ;------------------------------------------------------------
                                    711 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function extract_mod_bits
                                    722 ;	-----------------------------------------
      00A710                        723 _extract_mod_bits:
      00A710 12 38 75         [24]  724 	lcall	_ak820_outline_0108
      00A713 90 0C 98         [24]  725 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A716 12 38 7A         [24]  726 	lcall	_ak820_outline_0109
                                    727 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A719 90 0C 98         [24]  728 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A71C E0               [24]  729 	movx	a,@dptr
      00A71D A3               [24]  730 	inc	dptr
      00A71E E0               [24]  731 	movx	a,@dptr
                                    732 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A71F FF               [12]  733 	mov	r7,a
      00A720 60 05            [24]  734 	jz	00101$
      00A722 EF               [12]  735 	mov	a,r7
      00A723 24 E0            [12]  736 	add	a,#0xff - 0x1f
      00A725 50 04            [24]  737 	jnc	00102$
                                    738 ;	free result
      00A727                        739 00101$:
      00A727 75 82 00         [24]  740 	mov	dpl, #0x00
      00A72A 22               [24]  741 	ret
      00A72B                        742 00102$:
                                    743 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A72B EF               [12]  744 	mov	a,r7
      00A72C 30 E4 07         [24]  745 	jnb	acc.4,00106$
      00A72F EF               [12]  746 	mov	a,r7
      00A730 C4               [12]  747 	swap	a
      00A731 54 F0            [12]  748 	anl	a,#0xf0
      00A733 FE               [12]  749 	mov	r6,a
      00A734 80 02            [24]  750 	sjmp	00107$
      00A736                        751 00106$:
      00A736 8F 06            [24]  752 	mov	ar6,r7
      00A738                        753 00107$:
      00A738 8E 82            [24]  754 	mov	dpl, r6
                                    755 ;	quantum/quantum.c:143: }
      00A73A 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'do_code16'
                                    759 ;------------------------------------------------------------
                                    760 ;f             Allocated with name '_do_code16_PARM_2'
                                    761 ;code          Allocated with name '_do_code16_code_10000_609'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function register_code16
                                    766 ;	-----------------------------------------
      00A73B                        767 _register_code16:
      00A73B 12 38 75         [24]  768 	lcall	_ak820_outline_0108
      00A73E 90 0C 9A         [24]  769 	mov	dptr,#_register_code16_code_10000_612
      00A741 12 38 7A         [24]  770 	lcall	_ak820_outline_0109
                                    771 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A744 90 0C 9A         [24]  772 	mov	dptr,#_register_code16_code_10000_612
      00A747 12 37 E7         [24]  773 	lcall	_ak820_outline_0005
      00A74A C0 07            [24]  774 	push	ar7
      00A74C C0 06            [24]  775 	push	ar6
      00A74E F1 10            [12]  776 	acall	_extract_mod_bits
      00A750 AD 82            [24]  777 	mov	r5, dpl
      00A752 D0 06            [24]  778 	pop	ar6
      00A754 D0 07            [24]  779 	pop	ar7
                                    780 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A756 12 A5 49         [24]  781 	lcall	_ak820_outline_0121
      00A759 40 07            [24]  782 	jc	00105$
      00A75B 74 E7            [12]  783 	mov	a,#0xe7
      00A75D 9E               [12]  784 	subb	a,r6
      00A75E E4               [12]  785 	clr	a
      00A75F 9F               [12]  786 	subb	a,r7
      00A760 50 08            [24]  787 	jnc	00101$
                                    788 ;	free result
      00A762                        789 00105$:
      00A762 90 0C 9A         [24]  790 	mov	dptr,#_register_code16_code_10000_612
      00A765 12 76 96         [24]  791 	lcall	_ak820_outline_0041
      00A768 70 07            [24]  792 	jnz	00102$
      00A76A                        793 00101$:
                                    794 ;	quantum/quantum.c:153: register_mods(mods);
      00A76A 8D 82            [24]  795 	mov	dpl, r5
      00A76C 12 7F 3D         [24]  796 	lcall	_register_mods
      00A76F 80 05            [24]  797 	sjmp	00103$
      00A771                        798 00102$:
                                    799 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A771 8D 82            [24]  800 	mov	dpl, r5
      00A773 12 7F 65         [24]  801 	lcall	_register_weak_mods
      00A776                        802 00103$:
                                    803 ;	quantum/quantum.c:157: register_code(code);
      00A776 90 0C 9A         [24]  804 	mov	dptr,#_register_code16_code_10000_612
      00A779 E0               [24]  805 	movx	a,@dptr
      00A77A F5 82            [12]  806 	mov	dpl,a
                                    807 ;	quantum/quantum.c:167: }
      00A77C 02 7E 1D         [24]  808 	ljmp	_register_code
                                    809 ;------------------------------------------------------------
                                    810 ;Allocation info for local variables in function 'unregister_code16'
                                    811 ;------------------------------------------------------------
                                    812 ;code          Allocated with name '_unregister_code16_code_10000_617'
                                    813 ;mods          Allocated with name '_unregister_code16_mods_10000_618'
                                    814 ;------------------------------------------------------------
                                    815 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    816 ;	-----------------------------------------
                                    817 ;	 function unregister_code16
                                    818 ;	-----------------------------------------
      00A77F                        819 _unregister_code16:
      00A77F 12 38 75         [24]  820 	lcall	_ak820_outline_0108
      00A782 90 0C 9C         [24]  821 	mov	dptr,#_unregister_code16_code_10000_617
      00A785 12 38 7A         [24]  822 	lcall	_ak820_outline_0109
                                    823 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A788 90 0C 9C         [24]  824 	mov	dptr,#_unregister_code16_code_10000_617
      00A78B 12 37 E7         [24]  825 	lcall	_ak820_outline_0005
      00A78E C0 07            [24]  826 	push	ar7
      00A790 C0 06            [24]  827 	push	ar6
      00A792 12 A7 10         [24]  828 	lcall	_extract_mod_bits
      00A795 AD 82            [24]  829 	mov	r5, dpl
      00A797 D0 06            [24]  830 	pop	ar6
                                    831 ;	quantum/quantum.c:172: unregister_code(code);
      00A799 8E 04            [24]  832 	mov	ar4,r6
      00A79B 8C 82            [24]  833 	mov	dpl, r4
      00A79D C0 06            [24]  834 	push	ar6
      00A79F C0 05            [24]  835 	push	ar5
      00A7A1 12 7E 8A         [24]  836 	lcall	_unregister_code
      00A7A4 D0 05            [24]  837 	pop	ar5
      00A7A6 D0 06            [24]  838 	pop	ar6
      00A7A8 D0 07            [24]  839 	pop	ar7
                                    840 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A7AA 12 A5 49         [24]  841 	lcall	_ak820_outline_0121
      00A7AD 40 07            [24]  842 	jc	00105$
      00A7AF 74 E7            [12]  843 	mov	a,#0xe7
      00A7B1 9E               [12]  844 	subb	a,r6
      00A7B2 E4               [12]  845 	clr	a
      00A7B3 9F               [12]  846 	subb	a,r7
      00A7B4 50 08            [24]  847 	jnc	00101$
                                    848 ;	free result
      00A7B6                        849 00105$:
      00A7B6 90 0C 9C         [24]  850 	mov	dptr,#_unregister_code16_code_10000_617
      00A7B9 12 76 96         [24]  851 	lcall	_ak820_outline_0041
      00A7BC 70 05            [24]  852 	jnz	00102$
      00A7BE                        853 00101$:
                                    854 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A7BE 8D 82            [24]  855 	mov	dpl, r5
      00A7C0 02 7F 51         [24]  856 	ljmp	_unregister_mods
      00A7C3                        857 00102$:
                                    858 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A7C3 8D 82            [24]  859 	mov	dpl, r5
                                    860 ;	quantum/quantum.c:187: }
      00A7C5 02 7F 79         [24]  861 	ljmp	_unregister_weak_mods
                                    862 ;------------------------------------------------------------
                                    863 ;Allocation info for local variables in function 'tap_code16_delay'
                                    864 ;------------------------------------------------------------
                                    865 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    866 ;code          Allocated with name '_tap_code16_delay_code_10000_622'
                                    867 ;i             Allocated with name '_tap_code16_delay_i_20000_624'
                                    868 ;i             Allocated with name '_tap_code16_delay_i_50000_627'
                                    869 ;------------------------------------------------------------
                                    870 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function pre_process_record_kb
                                    873 ;	-----------------------------------------
      00A7C8                        874 _pre_process_record_kb:
      00A7C8 12 38 75         [24]  875 	lcall	_ak820_outline_0108
      00A7CB 90 0C A1         [24]  876 	mov	dptr,#_pre_process_record_kb_keycode_10000_631
      00A7CE 12 38 7A         [24]  877 	lcall	_ak820_outline_0109
                                    878 ;	quantum/quantum.c:211: return pre_process_record_user(keycode, record);
      00A7D1 90 0C A1         [24]  879 	mov	dptr,#_pre_process_record_kb_keycode_10000_631
      00A7D4 12 38 34         [24]  880 	lcall	_ak820_outline_0054
      00A7D7 90 0C 9E         [24]  881 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A7DA 12 A5 40         [24]  882 	lcall	_ak820_outline_0027
      00A7DD 90 0C A3         [24]  883 	mov	dptr,#_pre_process_record_user_PARM_2
      00A7E0 12 AB 34         [24]  884 	lcall	_ak820_outline_0011
                                    885 ;	quantum/quantum.c:212: }
      00A7E3 E1 E5            [12]  886 	ajmp	_pre_process_record_user
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'pre_process_record_user'
                                    889 ;------------------------------------------------------------
                                    890 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    891 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_633'
                                    892 ;------------------------------------------------------------
                                    893 ;	quantum/quantum.c:214: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    894 ;	-----------------------------------------
                                    895 ;	 function pre_process_record_user
                                    896 ;	-----------------------------------------
      00A7E5                        897 _pre_process_record_user:
                                    898 ;	quantum/quantum.c:215: return true;
      00A7E5 75 82 01         [24]  899 	mov	dpl, #0x01
                                    900 ;	quantum/quantum.c:216: }
      00A7E8 22               [24]  901 	ret
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'process_action_kb'
                                    904 ;------------------------------------------------------------
                                    905 ;record        Allocated with name '_process_action_kb_record_10000_635'
                                    906 ;------------------------------------------------------------
                                    907 ;	quantum/quantum.c:218: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    908 ;	-----------------------------------------
                                    909 ;	 function process_action_kb
                                    910 ;	-----------------------------------------
      00A7E9                        911 _process_action_kb:
                                    912 ;	quantum/quantum.c:219: return true;
      00A7E9 75 82 01         [24]  913 	mov	dpl, #0x01
                                    914 ;	quantum/quantum.c:220: }
      00A7EC 22               [24]  915 	ret
                                    916 ;------------------------------------------------------------
                                    917 ;Allocation info for local variables in function 'process_record_kb'
                                    918 ;------------------------------------------------------------
                                    919 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    920 ;keycode       Allocated with name '_process_record_kb_keycode_10000_637'
                                    921 ;------------------------------------------------------------
                                    922 ;	quantum/quantum.c:222: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function process_record_kb
                                    925 ;	-----------------------------------------
      00A7ED                        926 _process_record_kb:
      00A7ED 12 38 75         [24]  927 	lcall	_ak820_outline_0108
      00A7F0 90 0C A9         [24]  928 	mov	dptr,#_process_record_kb_keycode_10000_637
      00A7F3 12 38 7A         [24]  929 	lcall	_ak820_outline_0109
                                    930 ;	quantum/quantum.c:223: return process_record_user(keycode, record);
      00A7F6 90 0C A9         [24]  931 	mov	dptr,#_process_record_kb_keycode_10000_637
      00A7F9 12 38 34         [24]  932 	lcall	_ak820_outline_0054
      00A7FC 90 0C A6         [24]  933 	mov	dptr,#_process_record_kb_PARM_2
      00A7FF 12 A5 40         [24]  934 	lcall	_ak820_outline_0027
      00A802 90 0C AB         [24]  935 	mov	dptr,#_process_record_user_PARM_2
      00A805 12 AB 34         [24]  936 	lcall	_ak820_outline_0011
                                    937 ;	quantum/quantum.c:224: }
      00A808 01 0A            [12]  938 	ajmp	_process_record_user
                                    939 ;------------------------------------------------------------
                                    940 ;Allocation info for local variables in function 'process_record_user'
                                    941 ;------------------------------------------------------------
                                    942 ;record        Allocated with name '_process_record_user_PARM_2'
                                    943 ;keycode       Allocated with name '_process_record_user_keycode_10000_639'
                                    944 ;------------------------------------------------------------
                                    945 ;	quantum/quantum.c:226: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function process_record_user
                                    948 ;	-----------------------------------------
      00A80A                        949 _process_record_user:
                                    950 ;	quantum/quantum.c:227: return true;
      00A80A 75 82 01         [24]  951 	mov	dpl, #0x01
                                    952 ;	quantum/quantum.c:228: }
      00A80D 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'post_process_record_kb'
                                    956 ;------------------------------------------------------------
                                    957 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    958 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_641'
                                    959 ;------------------------------------------------------------
                                    960 ;	quantum/quantum.c:230: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function post_process_record_kb
                                    963 ;	-----------------------------------------
      00A80E                        964 _post_process_record_kb:
      00A80E 12 38 75         [24]  965 	lcall	_ak820_outline_0108
      00A811 90 0C B1         [24]  966 	mov	dptr,#_post_process_record_kb_keycode_10000_641
      00A814 12 38 7A         [24]  967 	lcall	_ak820_outline_0109
                                    968 ;	quantum/quantum.c:231: post_process_record_user(keycode, record);
      00A817 90 0C B1         [24]  969 	mov	dptr,#_post_process_record_kb_keycode_10000_641
      00A81A 12 38 34         [24]  970 	lcall	_ak820_outline_0054
      00A81D 90 0C AE         [24]  971 	mov	dptr,#_post_process_record_kb_PARM_2
      00A820 12 A5 40         [24]  972 	lcall	_ak820_outline_0027
      00A823 90 0C B3         [24]  973 	mov	dptr,#_post_process_record_user_PARM_2
      00A826 12 AB 34         [24]  974 	lcall	_ak820_outline_0011
                                    975 ;	quantum/quantum.c:232: }
      00A829 01 2B            [24]  976 	ajmp	_post_process_record_user
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'post_process_record_user'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    981 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_643'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/quantum.c:234: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    984 ;	-----------------------------------------
                                    985 ;	 function post_process_record_user
                                    986 ;	-----------------------------------------
      00A82B                        987 _post_process_record_user:
      00A82B 22               [24]  988 	ret
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'shutdown_quantum'
                                    991 ;------------------------------------------------------------
                                    992 ;i             Allocated with name '_shutdown_quantum_i_30000_649'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/quantum.c:236: void shutdown_quantum(void) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function shutdown_quantum
                                    997 ;	-----------------------------------------
      00A82C                        998 _shutdown_quantum:
                                    999 ;	quantum/quantum.c:237: clear_keyboard();
      00A82C 12 7F 8D         [24] 1000 	lcall	_clear_keyboard
                                   1001 ;	quantum/quantum.c:252: shutdown_user();
      00A82F 71 26            [12] 1002 	acall	_shutdown_user
                                   1003 ;	quantum/quantum.c:253: wait_ms(250);
      00A831 7F FA            [12] 1004 	mov	r7,#0xfa
      00A833                       1005 00106$:
      00A833 EF               [12] 1006 	mov	a,r7
      00A834 60 09            [24] 1007 	jz	00108$
      00A836 90 00 01         [24] 1008 	mov	dptr,#0x0001
      00A839 12 62 04         [24] 1009 	lcall	_mDelaymS
      00A83C 1F               [12] 1010 	dec	r7
      00A83D 80 F4            [24] 1011 	sjmp	00106$
      00A83F                       1012 00108$:
                                   1013 ;	quantum/quantum.c:258: }
      00A83F 22               [24] 1014 	ret
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'reset_keyboard'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function reset_keyboard
                                   1021 ;	-----------------------------------------
      00A840                       1022 _reset_keyboard:
                                   1023 ;	quantum/quantum.c:261: shutdown_quantum();
      00A840 11 2C            [24] 1024 	acall	_shutdown_quantum
                                   1025 ;	quantum/quantum.c:262: bootloader_jump();
                                   1026 ;	quantum/quantum.c:263: }
      00A842 02 34 0E         [24] 1027 	ljmp	_bootloader_jump
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function soft_reset_keyboard
                                   1034 ;	-----------------------------------------
      00A845                       1035 _soft_reset_keyboard:
                                   1036 ;	quantum/quantum.c:266: shutdown_quantum();
      00A845 11 2C            [24] 1037 	acall	_shutdown_quantum
                                   1038 ;	quantum/quantum.c:267: mcu_reset();
                                   1039 ;	quantum/quantum.c:268: }
      00A847 02 34 01         [24] 1040 	ljmp	_mcu_reset
                                   1041 ;------------------------------------------------------------
                                   1042 ;Allocation info for local variables in function 'get_record_keycode'
                                   1043 ;------------------------------------------------------------
                                   1044 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1045 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_655'
                                   1046 ;record        Allocated with name '_get_record_keycode_record_10000_656'
                                   1047 ;------------------------------------------------------------
                                   1048 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1049 ;	-----------------------------------------
                                   1050 ;	 function get_record_keycode
                                   1051 ;	-----------------------------------------
      00A84A                       1052 _get_record_keycode:
      00A84A 12 43 06         [24] 1053 	lcall	_ak820_outline_0038
      00A84D 90 0C B7         [24] 1054 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A850 12 38 1C         [24] 1055 	lcall	_ak820_outline_0019
                                   1056 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A853 90 0C B7         [24] 1057 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A856 12 37 F1         [24] 1058 	lcall	_ak820_outline_0007
                                   1059 ;	quantum/quantum.c:278: if (record->keycode) {
      00A859 4C               [12] 1060 	orl	a,r4
      00A85A 60 04            [24] 1061 	jz	00102$
                                   1062 ;	quantum/quantum.c:279: return record->keycode;
      00A85C 12 38 8A         [24] 1063 	lcall	_ak820_outline_0126
      00A85F 22               [24] 1064 	ret
      00A860                       1065 00102$:
                                   1066 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A860 12 7F EA         [24] 1067 	lcall	_ak820_outline_0022
      00A863 7A 00            [12] 1068 	mov	r2,#0x00
      00A865 12 43 5A         [24] 1069 	lcall	_ak820_outline_0143
      00A868 12 38 05         [24] 1070 	lcall	_ak820_outline_0010
      00A86B 60 06            [24] 1071 	jz	00105$
      00A86D 90 0C B6         [24] 1072 	mov	dptr,#_get_record_keycode_PARM_2
      00A870 E0               [24] 1073 	movx	a,@dptr
      00A871 70 04            [24] 1074 	jnz	00106$
      00A873                       1075 00105$:
                                   1076 ;	assignBit
      00A873 C2 28            [12] 1077 	clr	_get_record_keycode_sloc0_1_0
      00A875 80 02            [24] 1078 	sjmp	00107$
      00A877                       1079 00106$:
                                   1080 ;	assignBit
      00A877 D2 28            [12] 1081 	setb	_get_record_keycode_sloc0_1_0
      00A879                       1082 00107$:
      00A879 90 0A 19         [24] 1083 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A87C A2 28            [12] 1084 	mov	c,_get_record_keycode_sloc0_1_0
      00A87E E4               [12] 1085 	clr	a
      00A87F 33               [12] 1086 	rlc	a
      00A880 F0               [24] 1087 	movx	@dptr,a
      00A881 8D 82            [24] 1088 	mov	dpl, r5
      00A883 8C 83            [24] 1089 	mov	dph, r4
                                   1090 ;	quantum/quantum.c:287: }
      00A885 02 83 7F         [24] 1091 	ljmp	_ak820_resolve_key
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'get_event_keycode'
                                   1094 ;------------------------------------------------------------
                                   1095 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1096 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_659'
                                   1097 ;------------------------------------------------------------
                                   1098 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1099 ;	-----------------------------------------
                                   1100 ;	 function pre_process_record_quantum
                                   1101 ;	-----------------------------------------
      00A888                       1102 _pre_process_record_quantum:
      00A888 12 43 06         [24] 1103 	lcall	_ak820_outline_0038
      00A88B 90 0C BA         [24] 1104 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A88E 12 38 1C         [24] 1105 	lcall	_ak820_outline_0019
                                   1106 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A891 90 0C BA         [24] 1107 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A894 12 38 34         [24] 1108 	lcall	_ak820_outline_0054
                                   1109 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A897 8E 03            [24] 1110 	mov	ar3,r6
      00A899 8F 04            [24] 1111 	mov	ar4,r7
      00A89B 7D 00            [12] 1112 	mov	r5,#0x00
      00A89D 90 0C B6         [24] 1113 	mov	dptr,#_get_record_keycode_PARM_2
      00A8A0 74 01            [12] 1114 	mov	a,#0x01
      00A8A2 F0               [24] 1115 	movx	@dptr,a
      00A8A3 12 33 FC         [24] 1116 	lcall	_ak820_outline_0123
      00A8A6 8D F0            [24] 1117 	mov	b, r5
      00A8A8 C0 07            [24] 1118 	push	ar7
      00A8AA C0 06            [24] 1119 	push	ar6
      00A8AC 11 4A            [24] 1120 	acall	_get_record_keycode
      00A8AE 12 43 60         [24] 1121 	lcall	_ak820_outline_0150
      00A8B1 D0 06            [24] 1122 	pop	ar6
      00A8B3 D0 07            [24] 1123 	pop	ar7
                                   1124 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A8B5 74 07            [12] 1125 	mov	a,#0x07
      00A8B7 12 38 24         [24] 1126 	lcall	_ak820_outline_0023
      00A8BA EC               [12] 1127 	mov	a,r4
      00A8BB F0               [24] 1128 	movx	@dptr,a
      00A8BC ED               [12] 1129 	mov	a,r5
      00A8BD A3               [24] 1130 	inc	dptr
      00A8BE 12 43 31         [24] 1131 	lcall	_ak820_outline_0068
                                   1132 ;	quantum/quantum.c:351: if (!ak820_tap_dance_process((keyrecord_t AK820_STATE_MEM *)record)) return false;
      00A8C1 C0 07            [24] 1133 	push	ar7
      00A8C3 C0 06            [24] 1134 	push	ar6
      00A8C5 C0 05            [24] 1135 	push	ar5
      00A8C7 C0 04            [24] 1136 	push	ar4
      00A8C9 12 4A 0A         [24] 1137 	lcall	_ak820_tap_dance_process
      00A8CC E5 82            [12] 1138 	mov	a, dpl
      00A8CE D0 04            [24] 1139 	pop	ar4
      00A8D0 D0 05            [24] 1140 	pop	ar5
      00A8D2 D0 06            [24] 1141 	pop	ar6
      00A8D4 D0 07            [24] 1142 	pop	ar7
      00A8D6 70 03            [24] 1143 	jnz	00102$
      00A8D8 F5 82            [12] 1144 	mov	dpl,a
      00A8DA 22               [24] 1145 	ret
      00A8DB                       1146 00102$:
                                   1147 ;	quantum/quantum.c:353: return pre_process_record_kb(keycode, record) &&
      00A8DB 90 0C 9E         [24] 1148 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A8DE 12 AB 27         [24] 1149 	lcall	_ak820_outline_0002
      00A8E1 C0 07            [24] 1150 	push	ar7
      00A8E3 C0 06            [24] 1151 	push	ar6
      00A8E5 12 A7 C8         [24] 1152 	lcall	_pre_process_record_kb
      00A8E8 E5 82            [12] 1153 	mov	a, dpl
      00A8EA D0 06            [24] 1154 	pop	ar6
      00A8EC D0 07            [24] 1155 	pop	ar7
      00A8EE 60 0A            [24] 1156 	jz	00105$
                                   1157 ;	quantum/quantum.c:356: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A8F0 12 38 7F         [24] 1158 	lcall	_ak820_outline_0120
      00A8F3 12 36 35         [24] 1159 	lcall	_ak820_combo_process
      00A8F6 E5 82            [12] 1160 	mov	a, dpl
      00A8F8 70 04            [24] 1161 	jnz	00106$
                                   1162 ;	quantum/quantum.c:361: true;
      00A8FA                       1163 00105$:
                                   1164 ;	assignBit
      00A8FA C2 29            [12] 1165 	clr	_pre_process_record_quantum_sloc0_1_0
      00A8FC 80 02            [24] 1166 	sjmp	00107$
      00A8FE                       1167 00106$:
                                   1168 ;	assignBit
      00A8FE D2 29            [12] 1169 	setb	_pre_process_record_quantum_sloc0_1_0
      00A900                       1170 00107$:
      00A900 A2 29            [12] 1171 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A902 12 38 A4         [24] 1172 	lcall	_ak820_outline_0157
                                   1173 ;	quantum/quantum.c:362: }
      00A905 22               [24] 1174 	ret
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1177 ;------------------------------------------------------------
                                   1178 ;record        Allocated with name '_post_process_record_quantum_record_10000_664'
                                   1179 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_665'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/quantum.c:365: void post_process_record_quantum(keyrecord_t *record) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function post_process_record_quantum
                                   1184 ;	-----------------------------------------
      00A906                       1185 _post_process_record_quantum:
      00A906 12 43 06         [24] 1186 	lcall	_ak820_outline_0038
      00A909 90 0C BD         [24] 1187 	mov	dptr,#_post_process_record_quantum_record_10000_664
      00A90C 12 38 1C         [24] 1188 	lcall	_ak820_outline_0019
                                   1189 ;	quantum/quantum.c:366: uint16_t keycode = get_record_keycode(record, false);
      00A90F 90 0C BD         [24] 1190 	mov	dptr,#_post_process_record_quantum_record_10000_664
      00A912 12 58 58         [24] 1191 	lcall	_ak820_outline_0013
      00A915 90 0C B6         [24] 1192 	mov	dptr,#_get_record_keycode_PARM_2
      00A918 E4               [12] 1193 	clr	a
      00A919 12 58 61         [24] 1194 	lcall	_ak820_outline_0035
      00A91C 11 4A            [24] 1195 	acall	_get_record_keycode
      00A91E 12 43 4F         [24] 1196 	lcall	_ak820_outline_0135
                                   1197 ;	quantum/quantum.c:367: post_process_record_kb(keycode, record);
      00A921 90 0C BD         [24] 1198 	mov	dptr,#_post_process_record_quantum_record_10000_664
      00A924 12 A5 40         [24] 1199 	lcall	_ak820_outline_0027
      00A927 90 0C AE         [24] 1200 	mov	dptr,#_post_process_record_kb_PARM_2
      00A92A 12 AB 34         [24] 1201 	lcall	_ak820_outline_0011
                                   1202 ;	quantum/quantum.c:368: }
      00A92D 01 0E            [12] 1203 	ajmp	_post_process_record_kb
                                   1204 ;------------------------------------------------------------
                                   1205 ;Allocation info for local variables in function 'process_record_quantum'
                                   1206 ;------------------------------------------------------------
                                   1207 ;record        Allocated with name '_process_record_quantum_record_10000_666'
                                   1208 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_667'
                                   1209 ;------------------------------------------------------------
                                   1210 ;	quantum/quantum.c:370: bool process_record_quantum(keyrecord_t *record) {
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function process_record_quantum
                                   1213 ;	-----------------------------------------
      00A92F                       1214 _process_record_quantum:
      00A92F 12 43 06         [24] 1215 	lcall	_ak820_outline_0038
      00A932 90 0C C0         [24] 1216 	mov	dptr,#_process_record_quantum_record_10000_666
      00A935 12 38 1C         [24] 1217 	lcall	_ak820_outline_0019
                                   1218 ;	quantum/quantum.c:372: uint16_t keycode = get_record_keycode(record, false);
      00A938 90 0C C0         [24] 1219 	mov	dptr,#_process_record_quantum_record_10000_666
      00A93B 12 58 58         [24] 1220 	lcall	_ak820_outline_0013
      00A93E 90 0C B6         [24] 1221 	mov	dptr,#_get_record_keycode_PARM_2
      00A941 E4               [12] 1222 	clr	a
      00A942 12 58 61         [24] 1223 	lcall	_ak820_outline_0035
      00A945 11 4A            [24] 1224 	acall	_get_record_keycode
      00A947 12 43 4F         [24] 1225 	lcall	_ak820_outline_0135
                                   1226 ;	quantum/quantum.c:376: return process_record_quantum_helper(keycode, record);
      00A94A 90 0C C0         [24] 1227 	mov	dptr,#_process_record_quantum_record_10000_666
      00A94D 12 A5 40         [24] 1228 	lcall	_ak820_outline_0027
      00A950 90 0C C8         [24] 1229 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A953 12 AB 34         [24] 1230 	lcall	_ak820_outline_0011
                                   1231 ;	quantum/quantum.c:377: }
      00A956 21 C3            [24] 1232 	ajmp	_process_record_quantum_helper
                                   1233 ;------------------------------------------------------------
                                   1234 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1235 ;------------------------------------------------------------
                                   1236 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1237 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_668'
                                   1238 ;record        Allocated with name '_process_ak820_nkro_record_10000_669'
                                   1239 ;------------------------------------------------------------
                                   1240 ;	quantum/quantum.c:394: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1241 ;	-----------------------------------------
                                   1242 ;	 function process_ak820_nkro
                                   1243 ;	-----------------------------------------
      00A958                       1244 _process_ak820_nkro:
      00A958 12 38 75         [24] 1245 	lcall	_ak820_outline_0108
      00A95B 90 0C C6         [24] 1246 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A95E 12 38 7A         [24] 1247 	lcall	_ak820_outline_0109
                                   1248 ;	quantum/quantum.c:396: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A961 90 0C C3         [24] 1249 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A964 12 38 34         [24] 1250 	lcall	_ak820_outline_0054
                                   1251 ;	quantum/quantum.c:400: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A967 90 0C C6         [24] 1252 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A96A 12 38 4B         [24] 1253 	lcall	_ak820_outline_0062
      00A96D C3               [12] 1254 	clr	c
      00A96E EC               [12] 1255 	mov	a,r4
      00A96F 94 11            [12] 1256 	subb	a,#0x11
      00A971 ED               [12] 1257 	mov	a,r5
      00A972 94 70            [12] 1258 	subb	a,#0x70
      00A974 40 08            [24] 1259 	jc	00101$
      00A976 74 13            [12] 1260 	mov	a,#0x13
      00A978 9C               [12] 1261 	subb	a,r4
      00A979 74 70            [12] 1262 	mov	a,#0x70
      00A97B 9D               [12] 1263 	subb	a,r5
      00A97C 50 04            [24] 1264 	jnc	00102$
                                   1265 ;	free result
      00A97E                       1266 00101$:
      00A97E 75 82 01         [24] 1267 	mov	dpl, #0x01
      00A981 22               [24] 1268 	ret
      00A982                       1269 00102$:
                                   1270 ;	quantum/quantum.c:401: if (record->event.pressed) {
      00A982 12 38 05         [24] 1271 	lcall	_ak820_outline_0010
      00A985 60 38            [24] 1272 	jz	00105$
                                   1273 ;	quantum/quantum.c:402: clear_keyboard();
      00A987 C0 05            [24] 1274 	push	ar5
      00A989 C0 04            [24] 1275 	push	ar4
      00A98B 12 7F 8D         [24] 1276 	lcall	_clear_keyboard
      00A98E D0 04            [24] 1277 	pop	ar4
      00A990 D0 05            [24] 1278 	pop	ar5
                                   1279 ;	quantum/quantum.c:403: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A992 BC 13 14         [24] 1280 	cjne	r4,#0x13,00108$
      00A995 BD 70 11         [24] 1281 	cjne	r5,#0x70,00108$
      00A998 90 0B 6B         [24] 1282 	mov	dptr,#_keymap_config
      00A99B E0               [24] 1283 	movx	a,@dptr
      00A99C 23               [12] 1284 	rl	a
      00A99D 54 01            [12] 1285 	anl	a,#0x01
      00A99F B4 01 00         [24] 1286 	cjne	a,#0x01,00136$
      00A9A2                       1287 00136$:
      00A9A2 92 2A            [24] 1288 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A9A4 E4               [12] 1289 	clr	a
      00A9A5 33               [12] 1290 	rlc	a
      00A9A6 FF               [12] 1291 	mov	r7,a
      00A9A7 80 09            [24] 1292 	sjmp	00109$
      00A9A9                       1293 00108$:
      00A9A9 E4               [12] 1294 	clr	a
      00A9AA BC 11 04         [24] 1295 	cjne	r4,#0x11,00137$
      00A9AD BD 70 01         [24] 1296 	cjne	r5,#0x70,00137$
      00A9B0 04               [12] 1297 	inc	a
      00A9B1                       1298 00137$:
      00A9B1 FF               [12] 1299 	mov	r7,a
      00A9B2                       1300 00109$:
                                   1301 ;	assignBit
      00A9B2 EF               [12] 1302 	mov	a,r7
      00A9B3 24 FF            [12] 1303 	add	a,#0xff
      00A9B5 E4               [12] 1304 	clr	a
      00A9B6 33               [12] 1305 	rlc	a
      00A9B7 90 0B 6B         [24] 1306 	mov	dptr,#_keymap_config
      00A9BA 13               [12] 1307 	rrc	a
      00A9BB E0               [24] 1308 	movx	a,@dptr
      00A9BC 92 E7            [24] 1309 	mov	acc.7,c
      00A9BE F0               [24] 1310 	movx	@dptr,a
      00A9BF                       1311 00105$:
                                   1312 ;	quantum/quantum.c:405: return false;
      00A9BF 75 82 00         [24] 1313 	mov	dpl, #0x00
                                   1314 ;	quantum/quantum.c:406: }
      00A9C2 22               [24] 1315 	ret
                                   1316 ;------------------------------------------------------------
                                   1317 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1318 ;------------------------------------------------------------
                                   1319 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1320 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_673'
                                   1321 ;record        Allocated with name '_process_record_quantum_helper_record_10000_674'
                                   1322 ;------------------------------------------------------------
                                   1323 ;	quantum/quantum.c:409: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1324 ;	-----------------------------------------
                                   1325 ;	 function process_record_quantum_helper
                                   1326 ;	-----------------------------------------
      00A9C3                       1327 _process_record_quantum_helper:
      00A9C3 12 38 75         [24] 1328 	lcall	_ak820_outline_0108
      00A9C6 90 0C CB         [24] 1329 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A9C9 12 38 7A         [24] 1330 	lcall	_ak820_outline_0109
                                   1331 ;	quantum/quantum.c:411: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A9CC 90 0C C8         [24] 1332 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A9CF 12 38 34         [24] 1333 	lcall	_ak820_outline_0054
                                   1334 ;	quantum/quantum.c:454: process_ak820_nkro(keycode, record) &&
      00A9D2 90 0C CB         [24] 1335 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A9D5 12 38 4B         [24] 1336 	lcall	_ak820_outline_0062
      00A9D8 90 0C C3         [24] 1337 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A9DB 12 AB 27         [24] 1338 	lcall	_ak820_outline_0002
      00A9DE C0 07            [24] 1339 	push	ar7
      00A9E0 C0 06            [24] 1340 	push	ar6
      00A9E2 C0 05            [24] 1341 	push	ar5
      00A9E4 C0 04            [24] 1342 	push	ar4
      00A9E6 31 58            [24] 1343 	acall	_process_ak820_nkro
      00A9E8 E5 82            [12] 1344 	mov	a, dpl
      00A9EA D0 04            [24] 1345 	pop	ar4
      00A9EC D0 05            [24] 1346 	pop	ar5
      00A9EE D0 06            [24] 1347 	pop	ar6
      00A9F0 D0 07            [24] 1348 	pop	ar7
      00A9F2 70 02            [24] 1349 	jnz	00204$
      00A9F4 41 E6            [12] 1350 	ajmp	00101$
      00A9F6                       1351 00204$:
                                   1352 ;	quantum/quantum.c:465: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A9F6 90 0C 81         [24] 1353 	mov	dptr,#_process_last_key_PARM_2
      00A9F9 12 AB 27         [24] 1354 	lcall	_ak820_outline_0002
      00A9FC C0 07            [24] 1355 	push	ar7
      00A9FE C0 06            [24] 1356 	push	ar6
      00AA00 C0 05            [24] 1357 	push	ar5
      00AA02 C0 04            [24] 1358 	push	ar4
      00AA04 12 A4 7A         [24] 1359 	lcall	_process_last_key
      00AA07 E5 82            [12] 1360 	mov	a, dpl
      00AA09 D0 04            [24] 1361 	pop	ar4
      00AA0B D0 05            [24] 1362 	pop	ar5
      00AA0D D0 06            [24] 1363 	pop	ar6
      00AA0F D0 07            [24] 1364 	pop	ar7
      00AA11 70 02            [24] 1365 	jnz	00205$
      00AA13 41 E6            [12] 1366 	ajmp	00101$
      00AA15                       1367 00205$:
      00AA15 90 0C 87         [24] 1368 	mov	dptr,#_process_repeat_key_PARM_2
      00AA18 12 AB 27         [24] 1369 	lcall	_ak820_outline_0002
      00AA1B C0 07            [24] 1370 	push	ar7
      00AA1D C0 06            [24] 1371 	push	ar6
      00AA1F C0 05            [24] 1372 	push	ar5
      00AA21 C0 04            [24] 1373 	push	ar4
      00AA23 12 A4 F7         [24] 1374 	lcall	_process_repeat_key
      00AA26 E5 82            [12] 1375 	mov	a, dpl
      00AA28 D0 04            [24] 1376 	pop	ar4
      00AA2A D0 05            [24] 1377 	pop	ar5
      00AA2C D0 06            [24] 1378 	pop	ar6
      00AA2E D0 07            [24] 1379 	pop	ar7
      00AA30 70 02            [24] 1380 	jnz	00206$
      00AA32 41 E6            [12] 1381 	ajmp	00101$
      00AA34                       1382 00206$:
                                   1383 ;	quantum/quantum.c:474: process_record_via(keycode, record) &&
      00AA34 90 0D 08         [24] 1384 	mov	dptr,#_process_record_via_PARM_2
      00AA37 12 AB 27         [24] 1385 	lcall	_ak820_outline_0002
      00AA3A C0 07            [24] 1386 	push	ar7
      00AA3C C0 06            [24] 1387 	push	ar6
      00AA3E C0 05            [24] 1388 	push	ar5
      00AA40 C0 04            [24] 1389 	push	ar4
      00AA42 12 B0 2B         [24] 1390 	lcall	_process_record_via
      00AA45 E5 82            [12] 1391 	mov	a, dpl
      00AA47 D0 04            [24] 1392 	pop	ar4
      00AA49 D0 05            [24] 1393 	pop	ar5
      00AA4B D0 06            [24] 1394 	pop	ar6
      00AA4D D0 07            [24] 1395 	pop	ar7
      00AA4F 70 02            [24] 1396 	jnz	00207$
      00AA51 41 E6            [12] 1397 	ajmp	00101$
      00AA53                       1398 00207$:
                                   1399 ;	quantum/quantum.c:484: process_record_kb(keycode, record) &&
      00AA53 90 0C A6         [24] 1400 	mov	dptr,#_process_record_kb_PARM_2
      00AA56 12 AB 27         [24] 1401 	lcall	_ak820_outline_0002
      00AA59 C0 07            [24] 1402 	push	ar7
      00AA5B C0 06            [24] 1403 	push	ar6
      00AA5D C0 05            [24] 1404 	push	ar5
      00AA5F C0 04            [24] 1405 	push	ar4
      00AA61 12 A7 ED         [24] 1406 	lcall	_process_record_kb
      00AA64 E5 82            [12] 1407 	mov	a, dpl
      00AA66 D0 04            [24] 1408 	pop	ar4
      00AA68 D0 05            [24] 1409 	pop	ar5
      00AA6A D0 06            [24] 1410 	pop	ar6
      00AA6C D0 07            [24] 1411 	pop	ar7
      00AA6E 70 02            [24] 1412 	jnz	00208$
      00AA70 41 E6            [12] 1413 	ajmp	00101$
      00AA72                       1414 00208$:
                                   1415 ;	quantum/quantum.c:507: process_caps_word(keycode, record) &&
      00AA72 90 0C 69         [24] 1416 	mov	dptr,#_process_caps_word_PARM_2
      00AA75 12 AB 27         [24] 1417 	lcall	_ak820_outline_0002
      00AA78 C0 07            [24] 1418 	push	ar7
      00AA7A C0 06            [24] 1419 	push	ar6
      00AA7C C0 05            [24] 1420 	push	ar5
      00AA7E C0 04            [24] 1421 	push	ar4
      00AA80 12 A2 06         [24] 1422 	lcall	_process_caps_word
      00AA83 E5 82            [12] 1423 	mov	a, dpl
      00AA85 D0 04            [24] 1424 	pop	ar4
      00AA87 D0 05            [24] 1425 	pop	ar5
      00AA89 D0 06            [24] 1426 	pop	ar6
      00AA8B D0 07            [24] 1427 	pop	ar7
      00AA8D 60 57            [24] 1428 	jz	00101$
                                   1429 ;	quantum/quantum.c:537: process_grave_esc(keycode, record) &&
      00AA8F 90 0C 6E         [24] 1430 	mov	dptr,#_process_grave_esc_PARM_2
      00AA92 12 AB 27         [24] 1431 	lcall	_ak820_outline_0002
      00AA95 C0 07            [24] 1432 	push	ar7
      00AA97 C0 06            [24] 1433 	push	ar6
      00AA99 C0 05            [24] 1434 	push	ar5
      00AA9B C0 04            [24] 1435 	push	ar4
      00AA9D 12 A3 18         [24] 1436 	lcall	_process_grave_esc
      00AAA0 E5 82            [12] 1437 	mov	a, dpl
      00AAA2 D0 04            [24] 1438 	pop	ar4
      00AAA4 D0 05            [24] 1439 	pop	ar5
      00AAA6 D0 06            [24] 1440 	pop	ar6
      00AAA8 D0 07            [24] 1441 	pop	ar7
      00AAAA 60 3A            [24] 1442 	jz	00101$
                                   1443 ;	quantum/quantum.c:540: process_rgb(keycode, record) &&
      00AAAC 90 0C 8C         [24] 1444 	mov	dptr,#_process_rgb_PARM_2
      00AAAF 12 AB 27         [24] 1445 	lcall	_ak820_outline_0002
      00AAB2 C0 07            [24] 1446 	push	ar7
      00AAB4 C0 06            [24] 1447 	push	ar6
      00AAB6 C0 05            [24] 1448 	push	ar5
      00AAB8 C0 04            [24] 1449 	push	ar4
      00AABA 12 A5 51         [24] 1450 	lcall	_process_rgb
      00AABD E5 82            [12] 1451 	mov	a, dpl
      00AABF D0 04            [24] 1452 	pop	ar4
      00AAC1 D0 05            [24] 1453 	pop	ar5
      00AAC3 D0 06            [24] 1454 	pop	ar6
      00AAC5 D0 07            [24] 1455 	pop	ar7
      00AAC7 60 1D            [24] 1456 	jz	00101$
                                   1457 ;	quantum/quantum.c:552: process_tri_layer(keycode, record) &&
      00AAC9 90 0C 92         [24] 1458 	mov	dptr,#_process_tri_layer_PARM_2
      00AACC 12 AB 27         [24] 1459 	lcall	_ak820_outline_0002
      00AACF C0 07            [24] 1460 	push	ar7
      00AAD1 C0 06            [24] 1461 	push	ar6
      00AAD3 C0 05            [24] 1462 	push	ar5
      00AAD5 C0 04            [24] 1463 	push	ar4
      00AAD7 12 A6 02         [24] 1464 	lcall	_process_tri_layer
      00AADA E5 82            [12] 1465 	mov	a, dpl
      00AADC D0 04            [24] 1466 	pop	ar4
      00AADE D0 05            [24] 1467 	pop	ar5
      00AAE0 D0 06            [24] 1468 	pop	ar6
      00AAE2 D0 07            [24] 1469 	pop	ar7
      00AAE4 70 04            [24] 1470 	jnz	00102$
                                   1471 ;	quantum/quantum.c:554: true)) {
      00AAE6                       1472 00101$:
                                   1473 ;	quantum/quantum.c:555: return false;
      00AAE6 75 82 00         [24] 1474 	mov	dpl, #0x00
      00AAE9 22               [24] 1475 	ret
      00AAEA                       1476 00102$:
                                   1477 ;	quantum/quantum.c:558: if (record->event.pressed) {
      00AAEA 74 05            [12] 1478 	mov	a,#0x05
      00AAEC 12 51 CB         [24] 1479 	lcall	_ak820_outline_0033
      00AAEF 60 2D            [24] 1480 	jz	00117$
                                   1481 ;	quantum/quantum.c:559: switch (keycode) {
      00AAF1 BC 00 05         [24] 1482 	cjne	r4,#0x00,00214$
      00AAF4 BD 7C 02         [24] 1483 	cjne	r5,#0x7c,00214$
      00AAF7 80 10            [24] 1484 	sjmp	00112$
      00AAF9                       1485 00214$:
      00AAF9 BC 01 05         [24] 1486 	cjne	r4,#0x01,00215$
      00AAFC BD 7C 02         [24] 1487 	cjne	r5,#0x7c,00215$
      00AAFF 80 0E            [24] 1488 	sjmp	00113$
      00AB01                       1489 00215$:
                                   1490 ;	quantum/quantum.c:561: case QK_BOOTLOADER:
      00AB01 BC 03 1A         [24] 1491 	cjne	r4,#0x03,00117$
      00AB04 BD 7C 17         [24] 1492 	cjne	r5,#0x7c,00117$
      00AB07 80 0C            [24] 1493 	sjmp	00114$
      00AB09                       1494 00112$:
                                   1495 ;	quantum/quantum.c:562: reset_keyboard();
      00AB09 11 40            [24] 1496 	acall	_reset_keyboard
                                   1497 ;	quantum/quantum.c:563: return false;
      00AB0B 75 82 00         [24] 1498 	mov	dpl, #0x00
                                   1499 ;	quantum/quantum.c:564: case QK_REBOOT:
      00AB0E 22               [24] 1500 	ret
      00AB0F                       1501 00113$:
                                   1502 ;	quantum/quantum.c:565: soft_reset_keyboard();
      00AB0F 11 45            [24] 1503 	acall	_soft_reset_keyboard
                                   1504 ;	quantum/quantum.c:566: return false;
      00AB11 75 82 00         [24] 1505 	mov	dpl, #0x00
                                   1506 ;	quantum/quantum.c:578: case QK_CLEAR_EEPROM:
      00AB14 22               [24] 1507 	ret
      00AB15                       1508 00114$:
                                   1509 ;	quantum/quantum.c:585: eeconfig_disable();
      00AB15 12 99 8D         [24] 1510 	lcall	_eeconfig_disable
                                   1511 ;	quantum/quantum.c:586: soft_reset_keyboard();
      00AB18 11 45            [24] 1512 	acall	_soft_reset_keyboard
                                   1513 ;	quantum/quantum.c:588: return false;
      00AB1A 75 82 00         [24] 1514 	mov	dpl, #0x00
                                   1515 ;	quantum/quantum.c:643: }
      00AB1D 22               [24] 1516 	ret
      00AB1E                       1517 00117$:
                                   1518 ;	quantum/quantum.c:646: return process_action_kb(record);
      00AB1E 7D 00            [12] 1519 	mov	r5,#0x00
      00AB20 12 80 23         [24] 1520 	lcall	_ak820_outline_0114
                                   1521 ;	quantum/quantum.c:647: }
      00AB23 02 A7 E9         [24] 1522 	ljmp	_process_action_kb
                                   1523 ;------------------------------------------------------------
                                   1524 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1525 ;------------------------------------------------------------
                                   1526 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_681'
                                   1527 ;------------------------------------------------------------
                                   1528 ;	quantum/quantum.c:649: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1529 ;	-----------------------------------------
                                   1530 ;	 function shutdown_user
                                   1531 ;	-----------------------------------------
      00AB26                       1532 _shutdown_user:
      00AB26 22               [24] 1533 	ret
                                   1534 ;------------------------------------------------------------
                                   1535 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1536 ;------------------------------------------------------------
                                   1537 ;	quantum/quantum.c:665: void suspend_power_down_quantum(void) {
                                   1538 ;	-----------------------------------------
                                   1539 	.area CSEG    (CODE)
                                   1540 	.area CONST   (CODE)
                                   1541 	.area XINIT   (CODE)
                                   1542 	.area CABS    (ABS,CODE)
                                   1543 
                                   1544 ; Experimental exact instruction outlining.
                                   1545 	.globl _ak820_outline_0002
                                   1546 	.globl _ak820_outline_0005
                                   1547 	.globl _ak820_outline_0007
                                   1548 	.globl _ak820_outline_0010
                                   1549 	.globl _ak820_outline_0011
                                   1550 	.globl _ak820_outline_0013
                                   1551 	.globl _ak820_outline_0019
                                   1552 	.globl _ak820_outline_0022
                                   1553 	.globl _ak820_outline_0023
                                   1554 	.globl _ak820_outline_0027
                                   1555 	.globl _ak820_outline_0033
                                   1556 	.globl _ak820_outline_0035
                                   1557 	.globl _ak820_outline_0038
                                   1558 	.globl _ak820_outline_0041
                                   1559 	.globl _ak820_outline_0054
                                   1560 	.globl _ak820_outline_0062
                                   1561 	.globl _ak820_outline_0068
                                   1562 	.globl _ak820_outline_0108
                                   1563 	.globl _ak820_outline_0109
                                   1564 	.globl _ak820_outline_0114
                                   1565 	.globl _ak820_outline_0120
                                   1566 	.globl _ak820_outline_0121
                                   1567 	.globl _ak820_outline_0123
                                   1568 	.globl _ak820_outline_0126
                                   1569 	.globl _ak820_outline_0135
                                   1570 	.globl _ak820_outline_0143
                                   1571 	.globl _ak820_outline_0150
                                   1572 	.globl _ak820_outline_0157
                                   1573 
                                   1574 	.area CSEG (CODE)
                                   1575 ; function ak820_outline_0002
      00AB27                       1576 _ak820_outline_0002:
      00AB27 EE               [12] 1577 	mov	a,r6
      00AB28 F0               [24] 1578 	movx	@dptr,a
      00AB29 EF               [12] 1579 	mov	a,r7
      00AB2A A3               [24] 1580 	inc	dptr
      00AB2B F0               [24] 1581 	movx	@dptr,a
      00AB2C E4               [12] 1582 	clr	a
      00AB2D A3               [24] 1583 	inc	dptr
      00AB2E F0               [24] 1584 	movx	@dptr,a
      00AB2F 8C 82            [24] 1585 	mov	dpl,r4
      00AB31 8D 83            [24] 1586 	mov	dph,r5
      00AB33 22               [24] 1587 	ret
                                   1588 
                                   1589 	.area CSEG (CODE)
                                   1590 ; function ak820_outline_0011
      00AB34                       1591 _ak820_outline_0011:
      00AB34 EB               [12] 1592 	mov	a,r3
      00AB35 F0               [24] 1593 	movx	@dptr,a
      00AB36 EC               [12] 1594 	mov	a,r4
      00AB37 A3               [24] 1595 	inc	dptr
      00AB38 F0               [24] 1596 	movx	@dptr,a
      00AB39 ED               [12] 1597 	mov	a,r5
      00AB3A A3               [24] 1598 	inc	dptr
      00AB3B F0               [24] 1599 	movx	@dptr,a
      00AB3C 8E 82            [24] 1600 	mov	dpl,r6
      00AB3E 8F 83            [24] 1601 	mov	dph,r7
      00AB40 22               [24] 1602 	ret
