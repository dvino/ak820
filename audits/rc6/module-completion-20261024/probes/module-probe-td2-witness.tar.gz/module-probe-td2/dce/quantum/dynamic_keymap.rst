                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_tap_dance_valid
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_write_block_xdata
                                     16 	.globl _ak820_eeprom_read_block_xdata
                                     17 	.globl _ak820_nvm_flush
                                     18 	.globl _ak820_nvm_ok
                                     19 	.globl _ak820_macro_reset
                                     20 	.globl _ak820_macro_write
                                     21 	.globl _ak820_macro_length
                                     22 	.globl _ak820_macro_ready
                                     23 	.globl _send_char
                                     24 	.globl _keycode_at_encodermap_location_raw
                                     25 	.globl _keycode_at_keymap_location_raw
                                     26 	.globl _vial_keycode_tap
                                     27 	.globl _vial_keycode_up
                                     28 	.globl _vial_keycode_down
                                     29 	.globl _clear_keyboard
                                     30 	.globl _tap_code
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _mDelaymS
                                     34 	.globl ___memcpy
                                     35 	.globl _memset
                                     36 	.globl _eeprom_update_byte
                                     37 	.globl _eeprom_read_byte
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    284 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    285 	.globl _keycode_at_encodermap_location_PARM_3
                                    286 	.globl _keycode_at_encodermap_location_PARM_2
                                    287 	.globl _keycode_at_keymap_location_PARM_3
                                    288 	.globl _keycode_at_keymap_location_PARM_2
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    292 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    293 	.globl _dynamic_keymap_set_combo_PARM_2
                                    294 	.globl _dynamic_keymap_get_combo_PARM_2
                                    295 	.globl _dynamic_keymap_set_tap_dance_PARM_2
                                    296 	.globl _dynamic_keymap_get_tap_dance_PARM_2
                                    297 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    298 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    299 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    300 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    301 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    302 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    303 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    304 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    305 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    306 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    307 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    309 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    310 	.globl _dynamic_keymap_get_layer_count
                                    311 	.globl _dynamic_keymap_key_to_eeprom_address
                                    312 	.globl _dynamic_keymap_get_keycode
                                    313 	.globl _dynamic_keymap_set_keycode
                                    314 	.globl _dynamic_keymap_get_encoder
                                    315 	.globl _dynamic_keymap_set_encoder
                                    316 	.globl _dynamic_keymap_get_tap_dance
                                    317 	.globl _dynamic_keymap_set_tap_dance
                                    318 	.globl _dynamic_keymap_get_combo
                                    319 	.globl _dynamic_keymap_set_combo
                                    320 	.globl _dynamic_keymap_reset
                                    321 	.globl _dynamic_keymap_get_buffer
                                    322 	.globl _dynamic_keymap_set_buffer
                                    323 	.globl _keycode_at_keymap_location
                                    324 	.globl _keycode_at_encodermap_location
                                    325 	.globl _dynamic_keymap_macro_get_count
                                    326 	.globl _dynamic_keymap_macro_get_buffer_size
                                    327 	.globl _dynamic_keymap_macro_get_buffer
                                    328 	.globl _dynamic_keymap_macro_set_buffer
                                    329 	.globl _dynamic_keymap_macro_reset
                                    330 	.globl _dynamic_keymap_macro_send
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000031                        593 _dynamic_keymap_set_encoder_sloc0_1_0:
      000031                        594 	.ds 2
      000033                        595 _dynamic_keymap_get_combo_sloc0_1_0:
      000033                        596 	.ds 1
      000034                        597 _ak820_dynamic_read_buffer_sloc0_1_0:
      000034                        598 	.ds 1
      000035                        599 _dynamic_keymap_set_buffer_sloc0_1_0:
      000035                        600 	.ds 2
      000037                        601 _dynamic_keymap_set_buffer_sloc1_1_0:
      000037                        602 	.ds 2
      000039                        603 _dynamic_keymap_set_buffer_sloc2_1_0:
      000039                        604 	.ds 1
      00003A                        605 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      00003A                        606 	.ds 2
                                    607 ;--------------------------------------------------------
                                    608 ; overlayable items in internal ram
                                    609 ;--------------------------------------------------------
                                    610 ;--------------------------------------------------------
                                    611 ; indirectly addressable internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area ISEG    (DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; absolute internal ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area IABS    (ABS,DATA)
                                    618 	.area IABS    (ABS,DATA)
                                    619 ;--------------------------------------------------------
                                    620 ; bit data
                                    621 ;--------------------------------------------------------
                                    622 	.area BSEG    (BIT)
      000027                        623 _dynamic_keymap_macro_send_sloc0_1_0:
      000027                        624 	.ds 1
                                    625 ;--------------------------------------------------------
                                    626 ; paged external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area PSEG    (PAG,XDATA)
                                    629 ;--------------------------------------------------------
                                    630 ; uninitialized external ram data
                                    631 ;--------------------------------------------------------
                                    632 	.area XSEG    (XDATA)
      000B85                        633 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B85                        634 	.ds 1
      000B86                        635 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B86                        636 	.ds 1
      000B87                        637 _dynamic_keymap_key_to_eeprom_address_layer_10000_371:
      000B87                        638 	.ds 1
      000B88                        639 _dynamic_keymap_get_keycode_PARM_2:
      000B88                        640 	.ds 1
      000B89                        641 _dynamic_keymap_get_keycode_PARM_3:
      000B89                        642 	.ds 1
      000B8A                        643 _dynamic_keymap_get_keycode_layer_10000_373:
      000B8A                        644 	.ds 1
      000B8B                        645 _dynamic_keymap_set_keycode_PARM_2:
      000B8B                        646 	.ds 1
      000B8C                        647 _dynamic_keymap_set_keycode_PARM_3:
      000B8C                        648 	.ds 1
      000B8D                        649 _dynamic_keymap_set_keycode_PARM_4:
      000B8D                        650 	.ds 2
      000B8F                        651 _dynamic_keymap_set_keycode_layer_10000_377:
      000B8F                        652 	.ds 1
      000B90                        653 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B90                        654 	.ds 1
      000B91                        655 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_381:
      000B91                        656 	.ds 1
      000B92                        657 _dynamic_keymap_get_encoder_PARM_2:
      000B92                        658 	.ds 1
      000B93                        659 _dynamic_keymap_get_encoder_PARM_3:
      000B93                        660 	.ds 1
      000B94                        661 _dynamic_keymap_get_encoder_layer_10000_383:
      000B94                        662 	.ds 1
      000B95                        663 _dynamic_keymap_set_encoder_PARM_2:
      000B95                        664 	.ds 1
      000B96                        665 _dynamic_keymap_set_encoder_PARM_3:
      000B96                        666 	.ds 1
      000B97                        667 _dynamic_keymap_set_encoder_PARM_4:
      000B97                        668 	.ds 2
      000B99                        669 _dynamic_keymap_set_encoder_layer_10000_387:
      000B99                        670 	.ds 1
      000B9A                        671 _dynamic_keymap_get_tap_dance_PARM_2:
      000B9A                        672 	.ds 3
      000B9D                        673 _dynamic_keymap_get_tap_dance_index_10000_391:
      000B9D                        674 	.ds 1
      000B9E                        675 _dynamic_keymap_set_tap_dance_PARM_2:
      000B9E                        676 	.ds 3
      000BA1                        677 _dynamic_keymap_set_tap_dance_index_10000_395:
      000BA1                        678 	.ds 1
      000BA2                        679 _dynamic_keymap_get_combo_PARM_2:
      000BA2                        680 	.ds 3
      000BA5                        681 _dynamic_keymap_get_combo_index_10000_398:
      000BA5                        682 	.ds 1
      000BA6                        683 _dynamic_keymap_set_combo_PARM_2:
      000BA6                        684 	.ds 3
      000BA9                        685 _dynamic_keymap_set_combo_index_10000_404:
      000BA9                        686 	.ds 1
      000BAA                        687 _dynamic_keymap_set_combo_stored_10002_409:
      000BAA                        688 	.ds 10
      000BB4                        689 _dynamic_keymap_reset_vial_unlocked_prev_10000_412:
      000BB4                        690 	.ds 1
      000BB5                        691 _dynamic_keymap_reset_td_10001_421:
      000BB5                        692 	.ds 10
      000BBF                        693 _dynamic_keymap_reset_combo_10002_424:
      000BBF                        694 	.ds 10
      000BC9                        695 _ak820_dynamic_read_buffer_PARM_2:
      000BC9                        696 	.ds 2
      000BCB                        697 _ak820_dynamic_read_buffer_PARM_3:
      000BCB                        698 	.ds 2
      000BCD                        699 _ak820_dynamic_read_buffer_PARM_4:
      000BCD                        700 	.ds 2
      000BCF                        701 _ak820_dynamic_read_buffer_PARM_5:
      000BCF                        702 	.ds 3
      000BD2                        703 _ak820_dynamic_read_buffer_base_10000_426:
      000BD2                        704 	.ds 2
      000BD4                        705 _ak820_dynamic_read_buffer_available_10000_427:
      000BD4                        706 	.ds 1
      000BD5                        707 _dynamic_keymap_get_buffer_PARM_2:
      000BD5                        708 	.ds 2
      000BD7                        709 _dynamic_keymap_get_buffer_PARM_3:
      000BD7                        710 	.ds 3
      000BDA                        711 _dynamic_keymap_get_buffer_offset_10000_433:
      000BDA                        712 	.ds 2
      000BDC                        713 _dynamic_keymap_set_buffer_PARM_2:
      000BDC                        714 	.ds 2
      000BDE                        715 _dynamic_keymap_set_buffer_PARM_3:
      000BDE                        716 	.ds 3
      000BE1                        717 _dynamic_keymap_set_buffer_offset_10000_435:
      000BE1                        718 	.ds 2
      000BE3                        719 _dynamic_keymap_set_buffer_chk_offset_30001_442:
      000BE3                        720 	.ds 1
      000BE4                        721 _dynamic_keymap_set_buffer_chk_sz_30001_442:
      000BE4                        722 	.ds 1
      000BE5                        723 _dynamic_keymap_set_buffer_i_40001_449:
      000BE5                        724 	.ds 1
      000BE6                        725 _keycode_at_keymap_location_PARM_2:
      000BE6                        726 	.ds 1
      000BE7                        727 _keycode_at_keymap_location_PARM_3:
      000BE7                        728 	.ds 1
      000BE8                        729 _keycode_at_keymap_location_layer_num_10000_453:
      000BE8                        730 	.ds 1
      000BE9                        731 _keycode_at_encodermap_location_PARM_2:
      000BE9                        732 	.ds 1
      000BEA                        733 _keycode_at_encodermap_location_PARM_3:
      000BEA                        734 	.ds 1
      000BEB                        735 _keycode_at_encodermap_location_layer_num_10000_457:
      000BEB                        736 	.ds 1
      000BEC                        737 _dynamic_keymap_macro_get_buffer_PARM_2:
      000BEC                        738 	.ds 2
      000BEE                        739 _dynamic_keymap_macro_get_buffer_PARM_3:
      000BEE                        740 	.ds 3
      000BF1                        741 _dynamic_keymap_macro_get_buffer_offset_10000_465:
      000BF1                        742 	.ds 2
      000BF3                        743 _dynamic_keymap_macro_set_buffer_PARM_2:
      000BF3                        744 	.ds 2
      000BF5                        745 _dynamic_keymap_macro_set_buffer_PARM_3:
      000BF5                        746 	.ds 3
      000BF8                        747 _dynamic_keymap_macro_set_buffer_offset_10000_467:
      000BF8                        748 	.ds 2
      000BFA                        749 _decode_keycode_kc_10000_471:
      000BFA                        750 	.ds 2
      000BFC                        751 _dynamic_keymap_macro_send_id_10000_474:
      000BFC                        752 	.ds 1
      000BFD                        753 _dynamic_keymap_macro_send_sending_10000_475:
      000BFD                        754 	.ds 1
      000BFE                        755 _dynamic_keymap_macro_send_p_10001_480:
      000BFE                        756 	.ds 2
      000C00                        757 _dynamic_keymap_macro_send_data_10003_487:
      000C00                        758 	.ds 4
                                    759 ;--------------------------------------------------------
                                    760 ; absolute external ram data
                                    761 ;--------------------------------------------------------
                                    762 	.area XABS    (ABS,XDATA)
                                    763 ;--------------------------------------------------------
                                    764 ; initialized external ram data
                                    765 ;--------------------------------------------------------
                                    766 	.area XISEG   (XDATA)
                                    767 	.area HOME    (CODE)
                                    768 	.area GSINIT0 (CODE)
                                    769 	.area GSINIT1 (CODE)
                                    770 	.area GSINIT2 (CODE)
                                    771 	.area GSINIT3 (CODE)
                                    772 	.area GSINIT4 (CODE)
                                    773 	.area GSINIT5 (CODE)
                                    774 	.area GSINIT  (CODE)
                                    775 	.area GSFINAL (CODE)
                                    776 	.area CSEG    (CODE)
                                    777 ;--------------------------------------------------------
                                    778 ; global & static initialisations
                                    779 ;--------------------------------------------------------
                                    780 	.area HOME    (CODE)
                                    781 	.area GSINIT  (CODE)
                                    782 	.area GSFINAL (CODE)
                                    783 	.area GSINIT  (CODE)
                                    784 ;--------------------------------------------------------
                                    785 ; Home
                                    786 ;--------------------------------------------------------
                                    787 	.area HOME    (CODE)
                                    788 	.area HOME    (CODE)
                                    789 ;--------------------------------------------------------
                                    790 ; code
                                    791 ;--------------------------------------------------------
                                    792 	.area CSEG    (CODE)
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    795 ;------------------------------------------------------------
                                    796 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_232'
                                    797 ;------------------------------------------------------------
                                    798 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    799 ;	-----------------------------------------
                           000007   800 	ar7 = 0x07
                           000006   801 	ar6 = 0x06
                           000005   802 	ar5 = 0x05
                           000004   803 	ar4 = 0x04
                           000003   804 	ar3 = 0x03
                           000002   805 	ar2 = 0x02
                           000001   806 	ar1 = 0x01
                           000000   807 	ar0 = 0x00
                                    808 ;	 function dynamic_keymap_get_layer_count
                                    809 ;	-----------------------------------------
      008C6C                        810 _dynamic_keymap_get_layer_count:
                                    811 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008C6C 75 82 06         [24]  812 	mov	dpl, #0x06
                                    813 ;	quantum/dynamic_keymap.c:201: }
      008C6F 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    817 ;------------------------------------------------------------
                                    818 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    819 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    820 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_371'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function dynamic_keymap_key_to_eeprom_address
                                    825 ;	-----------------------------------------
      008C70                        826 _dynamic_keymap_key_to_eeprom_address:
      008C70 E5 82            [12]  827 	mov	a,dpl
      008C72 90 0B 87         [24]  828 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_371
      008C75 F0               [24]  829 	movx	@dptr,a
                                    830 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008C76 E0               [24]  831 	movx	a,@dptr
      008C77 FF               [12]  832 	mov	r7,a
      008C78 7E 00            [12]  833 	mov	r6,#0x00
      008C7A 74 40            [12]  834 	mov	a,#0x40
      008C7C 12 43 54         [24]  835 	lcall	_ak820_outline_0138
      008C7F 7D 00            [12]  836 	mov	r5,#0x00
      008C81 90 0B 85         [24]  837 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008C84 E0               [24]  838 	movx	a,@dptr
      008C85 75 F0 10         [24]  839 	mov	b,#0x10
      008C88 A4               [48]  840 	mul	ab
      008C89 2E               [12]  841 	add	a, r6
      008C8A FE               [12]  842 	mov	r6,a
      008C8B EF               [12]  843 	mov	a,r7
      008C8C 35 F0            [12]  844 	addc	a, b
      008C8E FF               [12]  845 	mov	r7,a
      008C8F 90 0B 86         [24]  846 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008C92 E0               [24]  847 	movx	a,@dptr
      008C93 7C 00            [12]  848 	mov	r4,#0x00
      008C95 25 E0            [12]  849 	add	a,acc
      008C97 FB               [12]  850 	mov	r3,a
      008C98 EC               [12]  851 	mov	a,r4
      008C99 33               [12]  852 	rlc	a
      008C9A FC               [12]  853 	mov	r4,a
      008C9B EB               [12]  854 	mov	a,r3
      008C9C 2E               [12]  855 	add	a, r6
      008C9D FE               [12]  856 	mov	r6,a
      008C9E EC               [12]  857 	mov	a,r4
      008C9F 3F               [12]  858 	addc	a, r7
      008CA0 FF               [12]  859 	mov	r7,a
      008CA1 12 80 23         [24]  860 	lcall	_ak820_outline_0114
                                    861 ;	quantum/dynamic_keymap.c:206: }
      008CA4 22               [24]  862 	ret
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    865 ;------------------------------------------------------------
                                    866 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    867 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    868 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_373'
                                    869 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_376'
                                    870 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_376'
                                    871 ;------------------------------------------------------------
                                    872 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    873 ;	-----------------------------------------
                                    874 ;	 function dynamic_keymap_get_keycode
                                    875 ;	-----------------------------------------
      008CA5                        876 _dynamic_keymap_get_keycode:
      008CA5 E5 82            [12]  877 	mov	a,dpl
      008CA7 90 0B 8A         [24]  878 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_373
      008CAA F0               [24]  879 	movx	@dptr,a
                                    880 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008CAB E0               [24]  881 	movx	a,@dptr
      008CAC FF               [12]  882 	mov	r7,a
      008CAD BF 06 00         [24]  883 	cjne	r7,#0x06,00121$
      008CB0                        884 00121$:
      008CB0 50 14            [24]  885 	jnc	00101$
      008CB2 90 0B 88         [24]  886 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008CB5 E0               [24]  887 	movx	a,@dptr
      008CB6 FE               [12]  888 	mov	r6,a
      008CB7 BE 10 00         [24]  889 	cjne	r6,#0x10,00123$
      008CBA                        890 00123$:
      008CBA 50 0A            [24]  891 	jnc	00101$
      008CBC 90 0B 89         [24]  892 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008CBF E0               [24]  893 	movx	a,@dptr
      008CC0 FD               [12]  894 	mov	r5,a
      008CC1 BD 08 00         [24]  895 	cjne	r5,#0x08,00125$
      008CC4                        896 00125$:
      008CC4 40 04            [24]  897 	jc	00102$
      008CC6                        898 00101$:
      008CC6 90 00 00         [24]  899 	mov	dptr,#0x0000
      008CC9 22               [24]  900 	ret
      008CCA                        901 00102$:
                                    902 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008CCA 12 98 5D         [24]  903 	lcall	_ak820_outline_0099
      008CCD 91 70            [12]  904 	acall	_dynamic_keymap_key_to_eeprom_address
                                    905 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008CCF 12 98 71         [24]  906 	lcall	_ak820_outline_0118
      008CD2 12 40 67         [24]  907 	lcall	_eeprom_read_byte
      008CD5 AB 82            [24]  908 	mov	r3,dpl
      008CD7 7C 00            [12]  909 	mov	r4,#0x00
                                    910 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008CD9 0D               [12]  911 	inc	r5
      008CDA BD 00 01         [24]  912 	cjne	r5,#0x00,00127$
      008CDD 0E               [12]  913 	inc	r6
      008CDE                        914 00127$:
      008CDE 12 76 9E         [24]  915 	lcall	_ak820_outline_0060
      008CE1 12 40 67         [24]  916 	lcall	_eeprom_read_byte
      008CE4 AF 82            [24]  917 	mov	r7, dpl
      008CE6 7E 00            [12]  918 	mov	r6,#0x00
      008CE8 EF               [12]  919 	mov	a,r7
      008CE9 42 04            [12]  920 	orl	ar4,a
      008CEB EE               [12]  921 	mov	a,r6
      008CEC 42 03            [12]  922 	orl	ar3,a
                                    923 ;	quantum/dynamic_keymap.c:214: return keycode;
      008CEE 12 43 7B         [24]  924 	lcall	_ak820_outline_0184
                                    925 ;	quantum/dynamic_keymap.c:215: }
      008CF1 22               [24]  926 	ret
                                    927 ;------------------------------------------------------------
                                    928 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    929 ;------------------------------------------------------------
                                    930 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    931 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    932 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    933 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_377'
                                    934 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_380'
                                    935 ;------------------------------------------------------------
                                    936 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    937 ;	-----------------------------------------
                                    938 ;	 function dynamic_keymap_set_keycode
                                    939 ;	-----------------------------------------
      008CF2                        940 _dynamic_keymap_set_keycode:
      008CF2 E5 82            [12]  941 	mov	a,dpl
      008CF4 90 0B 8F         [24]  942 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_377
      008CF7 F0               [24]  943 	movx	@dptr,a
                                    944 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008CF8 E0               [24]  945 	movx	a,@dptr
      008CF9 FF               [12]  946 	mov	r7,a
      008CFA BF 06 00         [24]  947 	cjne	r7,#0x06,00121$
      008CFD                        948 00121$:
      008CFD 50 14            [24]  949 	jnc	00101$
      008CFF 90 0B 8B         [24]  950 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008D02 E0               [24]  951 	movx	a,@dptr
      008D03 FE               [12]  952 	mov	r6,a
      008D04 BE 10 00         [24]  953 	cjne	r6,#0x10,00123$
      008D07                        954 00123$:
      008D07 50 0A            [24]  955 	jnc	00101$
      008D09 90 0B 8C         [24]  956 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008D0C E0               [24]  957 	movx	a,@dptr
      008D0D FD               [12]  958 	mov	r5,a
      008D0E BD 08 00         [24]  959 	cjne	r5,#0x08,00125$
      008D11                        960 00125$:
      008D11 40 01            [24]  961 	jc	00102$
      008D13                        962 00101$:
      008D13 22               [24]  963 	ret
      008D14                        964 00102$:
                                    965 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008D14 12 98 5D         [24]  966 	lcall	_ak820_outline_0099
      008D17 91 70            [12]  967 	acall	_dynamic_keymap_key_to_eeprom_address
      008D19 12 98 71         [24]  968 	lcall	_ak820_outline_0118
                                    969 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008D1C 90 0B 8D         [24]  970 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008D1F E0               [24]  971 	movx	a,@dptr
      008D20 FB               [12]  972 	mov	r3,a
      008D21 A3               [24]  973 	inc	dptr
      008D22 E0               [24]  974 	movx	a,@dptr
      008D23 90 07 4B         [24]  975 	mov	dptr,#_eeprom_update_byte_PARM_2
      008D26 12 58 61         [24]  976 	lcall	_ak820_outline_0035
      008D29 12 57 49         [24]  977 	lcall	_eeprom_update_byte
                                    978 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008D2C 0D               [12]  979 	inc	r5
      008D2D BD 00 01         [24]  980 	cjne	r5,#0x00,00127$
      008D30 0E               [12]  981 	inc	r6
      008D31                        982 00127$:
      008D31 90 07 4B         [24]  983 	mov	dptr,#_eeprom_update_byte_PARM_2
      008D34 EB               [12]  984 	mov	a,r3
      008D35 12 58 61         [24]  985 	lcall	_ak820_outline_0035
                                    986 ;	quantum/dynamic_keymap.c:223: }
      008D38 02 57 49         [24]  987 	ljmp	_eeprom_update_byte
                                    988 ;------------------------------------------------------------
                                    989 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    990 ;------------------------------------------------------------
                                    991 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    992 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    997 ;	-----------------------------------------
      008D3B                        998 _dynamic_keymap_encoder_to_eeprom_address:
      008D3B E5 82            [12]  999 	mov	a,dpl
      008D3D 90 0B 91         [24] 1000 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381
      008D40 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008D41 E0               [24] 1003 	movx	a,@dptr
      008D42 75 F0 04         [24] 1004 	mov	b,#0x04
      008D45 A4               [48] 1005 	mul	ab
      008D46 24 40            [12] 1006 	add	a, #0x40
      008D48 FD               [12] 1007 	mov	r5,a
      008D49 74 06            [12] 1008 	mov	a,#0x06
      008D4B 35 F0            [12] 1009 	addc	a, b
      008D4D FE               [12] 1010 	mov	r6,a
      008D4E 7F 00            [12] 1011 	mov	r7,#0x00
      008D50 90 0B 90         [24] 1012 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008D53 E0               [24] 1013 	movx	a,@dptr
      008D54 75 F0 04         [24] 1014 	mov	b,#0x04
      008D57 A4               [48] 1015 	mul	ab
      008D58 2D               [12] 1016 	add	a, r5
      008D59 FD               [12] 1017 	mov	r5,a
      008D5A EE               [12] 1018 	mov	a,r6
      008D5B 35 F0            [12] 1019 	addc	a, b
      008D5D FE               [12] 1020 	mov	r6,a
      008D5E 12 76 9E         [24] 1021 	lcall	_ak820_outline_0060
                                   1022 ;	quantum/dynamic_keymap.c:228: }
      008D61 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1026 ;------------------------------------------------------------
                                   1027 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1028 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1029 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_383'
                                   1030 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_386'
                                   1031 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_386'
                                   1032 ;------------------------------------------------------------
                                   1033 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1034 ;	-----------------------------------------
                                   1035 ;	 function dynamic_keymap_get_encoder
                                   1036 ;	-----------------------------------------
      008D62                       1037 _dynamic_keymap_get_encoder:
      008D62 E5 82            [12] 1038 	mov	a,dpl
      008D64 90 0B 94         [24] 1039 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_383
      008D67 F0               [24] 1040 	movx	@dptr,a
                                   1041 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008D68 E0               [24] 1042 	movx	a,@dptr
      008D69 FF               [12] 1043 	mov	r7,a
      008D6A BF 06 00         [24] 1044 	cjne	r7,#0x06,00131$
      008D6D                       1045 00131$:
      008D6D 50 0A            [24] 1046 	jnc	00101$
      008D6F 90 0B 92         [24] 1047 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008D72 E0               [24] 1048 	movx	a,@dptr
      008D73 FE               [12] 1049 	mov	r6,a
      008D74 BE 01 00         [24] 1050 	cjne	r6,#0x01,00133$
      008D77                       1051 00133$:
      008D77 40 04            [24] 1052 	jc	00102$
      008D79                       1053 00101$:
      008D79 90 00 00         [24] 1054 	mov	dptr,#0x0000
      008D7C 22               [24] 1055 	ret
      008D7D                       1056 00102$:
                                   1057 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008D7D 90 0B 90         [24] 1058 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008D80 E4               [12] 1059 	clr	a
      008D81 F0               [24] 1060 	movx	@dptr,a
      008D82 8F 82            [24] 1061 	mov	dpl, r7
      008D84 B1 3B            [12] 1062 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008D86 12 98 71         [24] 1063 	lcall	_ak820_outline_0118
                                   1064 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008D89 90 0B 93         [24] 1065 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008D8C E0               [24] 1066 	movx	a,@dptr
      008D8D FC               [12] 1067 	mov	r4,a
      008D8E E0               [24] 1068 	movx	a,@dptr
      008D8F 60 04            [24] 1069 	jz	00106$
      008D91 7B 00            [12] 1070 	mov	r3,#0x00
      008D93 80 02            [24] 1071 	sjmp	00107$
      008D95                       1072 00106$:
      008D95 7B 02            [12] 1073 	mov	r3,#0x02
      008D97                       1074 00107$:
      008D97 EB               [12] 1075 	mov	a,r3
      008D98 12 7F CE         [24] 1076 	lcall	_ak820_outline_0014
      008D9B 12 40 67         [24] 1077 	lcall	_eeprom_read_byte
      008D9E AA 82            [24] 1078 	mov	r2,dpl
      008DA0 7B 00            [12] 1079 	mov	r3,#0x00
                                   1080 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008DA2 EC               [12] 1081 	mov	a,r4
      008DA3 60 04            [24] 1082 	jz	00108$
      008DA5 7C 00            [12] 1083 	mov	r4,#0x00
      008DA7 80 02            [24] 1084 	sjmp	00109$
      008DA9                       1085 00108$:
      008DA9 7C 02            [12] 1086 	mov	r4,#0x02
      008DAB                       1087 00109$:
      008DAB EC               [12] 1088 	mov	a,r4
      008DAC 12 38 AE         [24] 1089 	lcall	_ak820_outline_0161
      008DAF 0D               [12] 1090 	inc	r5
      008DB0 BD 00 01         [24] 1091 	cjne	r5,#0x00,00137$
      008DB3 0E               [12] 1092 	inc	r6
      008DB4                       1093 00137$:
      008DB4 12 76 9E         [24] 1094 	lcall	_ak820_outline_0060
      008DB7 12 40 67         [24] 1095 	lcall	_eeprom_read_byte
      008DBA AF 82            [24] 1096 	mov	r7, dpl
      008DBC 7E 00            [12] 1097 	mov	r6,#0x00
      008DBE EF               [12] 1098 	mov	a,r7
      008DBF 42 03            [12] 1099 	orl	ar3,a
      008DC1 EE               [12] 1100 	mov	a,r6
      008DC2 42 02            [12] 1101 	orl	ar2,a
                                   1102 ;	quantum/dynamic_keymap.c:236: return keycode;
      008DC4 8B 82            [24] 1103 	mov	dpl, r3
      008DC6 8A 83            [24] 1104 	mov	dph, r2
                                   1105 ;	quantum/dynamic_keymap.c:237: }
      008DC8 22               [24] 1106 	ret
                                   1107 ;------------------------------------------------------------
                                   1108 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1109 ;------------------------------------------------------------
                                   1110 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1111 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1112 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1113 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1114 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_387'
                                   1115 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_390'
                                   1116 ;------------------------------------------------------------
                                   1117 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1118 ;	-----------------------------------------
                                   1119 ;	 function dynamic_keymap_set_encoder
                                   1120 ;	-----------------------------------------
      008DC9                       1121 _dynamic_keymap_set_encoder:
      008DC9 E5 82            [12] 1122 	mov	a,dpl
      008DCB 90 0B 99         [24] 1123 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_387
      008DCE F0               [24] 1124 	movx	@dptr,a
                                   1125 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008DCF E0               [24] 1126 	movx	a,@dptr
      008DD0 FF               [12] 1127 	mov	r7,a
      008DD1 BF 06 00         [24] 1128 	cjne	r7,#0x06,00131$
      008DD4                       1129 00131$:
      008DD4 50 0A            [24] 1130 	jnc	00101$
      008DD6 90 0B 95         [24] 1131 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008DD9 E0               [24] 1132 	movx	a,@dptr
      008DDA FE               [12] 1133 	mov	r6,a
      008DDB BE 01 00         [24] 1134 	cjne	r6,#0x01,00133$
      008DDE                       1135 00133$:
      008DDE 40 01            [24] 1136 	jc	00102$
      008DE0                       1137 00101$:
      008DE0 22               [24] 1138 	ret
      008DE1                       1139 00102$:
                                   1140 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008DE1 90 0B 90         [24] 1141 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008DE4 E4               [12] 1142 	clr	a
      008DE5 F0               [24] 1143 	movx	@dptr,a
      008DE6 8F 82            [24] 1144 	mov	dpl, r7
      008DE8 B1 3B            [12] 1145 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008DEA 12 98 71         [24] 1146 	lcall	_ak820_outline_0118
                                   1147 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008DED 90 0B 96         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008DF0 E0               [24] 1149 	movx	a,@dptr
      008DF1 FC               [12] 1150 	mov	r4,a
      008DF2 E0               [24] 1151 	movx	a,@dptr
      008DF3 60 04            [24] 1152 	jz	00106$
      008DF5 7B 00            [12] 1153 	mov	r3,#0x00
      008DF7 80 02            [24] 1154 	sjmp	00107$
      008DF9                       1155 00106$:
      008DF9 7B 02            [12] 1156 	mov	r3,#0x02
      008DFB                       1157 00107$:
      008DFB EB               [12] 1158 	mov	a,r3
      008DFC 12 98 83         [24] 1159 	lcall	_ak820_outline_0137
      008DFF 8F 03            [24] 1160 	mov	ar3,r7
      008E01 90 0B 97         [24] 1161 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008E04 E0               [24] 1162 	movx	a,@dptr
      008E05 F5 31            [12] 1163 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008E07 A3               [24] 1164 	inc	dptr
      008E08 E0               [24] 1165 	movx	a,@dptr
      008E09 F5 32            [12] 1166 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008E0B 90 07 4B         [24] 1167 	mov	dptr,#_eeprom_update_byte_PARM_2
      008E0E F0               [24] 1168 	movx	@dptr,a
      008E0F 12 43 76         [24] 1169 	lcall	_ak820_outline_0171
      008E12 8B F0            [24] 1170 	mov	b, r3
      008E14 12 57 49         [24] 1171 	lcall	_eeprom_update_byte
                                   1172 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008E17 EC               [12] 1173 	mov	a,r4
      008E18 60 04            [24] 1174 	jz	00108$
      008E1A 7C 00            [12] 1175 	mov	r4,#0x00
      008E1C 80 02            [24] 1176 	sjmp	00109$
      008E1E                       1177 00108$:
      008E1E 7C 02            [12] 1178 	mov	r4,#0x02
      008E20                       1179 00109$:
      008E20 EC               [12] 1180 	mov	a,r4
      008E21 12 38 AE         [24] 1181 	lcall	_ak820_outline_0161
      008E24 0D               [12] 1182 	inc	r5
      008E25 BD 00 01         [24] 1183 	cjne	r5,#0x00,00137$
      008E28 0E               [12] 1184 	inc	r6
      008E29                       1185 00137$:
      008E29 90 07 4B         [24] 1186 	mov	dptr,#_eeprom_update_byte_PARM_2
      008E2C E5 31            [12] 1187 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008E2E 12 58 61         [24] 1188 	lcall	_ak820_outline_0035
                                   1189 ;	quantum/dynamic_keymap.c:245: }
      008E31 02 57 49         [24] 1190 	ljmp	_eeprom_update_byte
                                   1191 ;------------------------------------------------------------
                                   1192 ;Allocation info for local variables in function 'dynamic_keymap_get_tap_dance'
                                   1193 ;------------------------------------------------------------
                                   1194 ;buffer        Allocated with name '_dynamic_keymap_get_tap_dance_PARM_2'
                                   1195 ;index         Allocated with name '_dynamic_keymap_get_tap_dance_index_10000_391'
                                   1196 ;entry         Allocated with name '_dynamic_keymap_get_tap_dance_entry_10000_392'
                                   1197 ;------------------------------------------------------------
                                   1198 ;	quantum/dynamic_keymap.c:268: int dynamic_keymap_get_tap_dance(uint8_t index, vial_tap_dance_entry_t *buffer) {
                                   1199 ;	-----------------------------------------
                                   1200 ;	 function dynamic_keymap_get_tap_dance
                                   1201 ;	-----------------------------------------
      008E34                       1202 _dynamic_keymap_get_tap_dance:
      008E34 E5 82            [12] 1203 	mov	a,dpl
      008E36 90 0B 9D         [24] 1204 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      008E39 F0               [24] 1205 	movx	@dptr,a
                                   1206 ;	quantum/dynamic_keymap.c:269: vial_tap_dance_entry_t AK820_STATE_MEM *entry = (vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      008E3A 90 0B 9A         [24] 1207 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      008E3D 12 38 34         [24] 1208 	lcall	_ak820_outline_0054
                                   1209 ;	quantum/dynamic_keymap.c:270: if (index >= AK820_EXTENSION_ENTRIES) return -1;
      008E40 90 0B 9D         [24] 1210 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      008E43 E0               [24] 1211 	movx	a,@dptr
      008E44 FD               [12] 1212 	mov	r5,a
      008E45 BD 08 00         [24] 1213 	cjne	r5,#0x08,00130$
      008E48                       1214 00130$:
      008E48 40 04            [24] 1215 	jc	00102$
      008E4A 90 FF FF         [24] 1216 	mov	dptr,#0xffff
      008E4D 22               [24] 1217 	ret
      008E4E                       1218 00102$:
                                   1219 ;	quantum/dynamic_keymap.c:271: ak820_eeprom_read_block_xdata(entry, (const void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008E4E 8E 03            [24] 1220 	mov	ar3,r6
      008E50 8F 04            [24] 1221 	mov	ar4,r7
      008E52 BD 06 00         [24] 1222 	cjne	r5,#0x06,00132$
      008E55                       1223 00132$:
      008E55 50 0C            [24] 1224 	jnc	00107$
      008E57 8D 02            [24] 1225 	mov	ar2,r5
      008E59 EA               [12] 1226 	mov	a,r2
      008E5A 75 F0 0A         [24] 1227 	mov	b,#0x0a
      008E5D A4               [48] 1228 	mul	ab
      008E5E F9               [12] 1229 	mov	r1,a
      008E5F 7A 00            [12] 1230 	mov	r2,#0x00
      008E61 80 11            [24] 1231 	sjmp	00108$
      008E63                       1232 00107$:
      008E63 ED               [12] 1233 	mov	a,r5
      008E64 24 FA            [12] 1234 	add	a,#0xfa
      008E66 75 F0 0A         [24] 1235 	mov	b,#0x0a
      008E69 A4               [48] 1236 	mul	ab
      008E6A F8               [12] 1237 	mov	r0,a
      008E6B 7D 00            [12] 1238 	mov	r5,#0x00
      008E6D 74 40            [12] 1239 	mov	a,#0x40
      008E6F 28               [12] 1240 	add	a, r0
      008E70 F9               [12] 1241 	mov	r1,a
      008E71 E4               [12] 1242 	clr	a
      008E72 3D               [12] 1243 	addc	a, r5
      008E73 FA               [12] 1244 	mov	r2,a
      008E74                       1245 00108$:
      008E74 74 C0            [12] 1246 	mov	a,#0xc0
      008E76 29               [12] 1247 	add	a, r1
      008E77 F9               [12] 1248 	mov	r1,a
      008E78 74 06            [12] 1249 	mov	a,#0x06
      008E7A 3A               [12] 1250 	addc	a, r2
      008E7B FA               [12] 1251 	mov	r2,a
      008E7C 90 05 85         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008E7F E9               [12] 1253 	mov	a,r1
      008E80 F0               [24] 1254 	movx	@dptr,a
      008E81 EA               [12] 1255 	mov	a,r2
      008E82 12 38 51         [24] 1256 	lcall	_ak820_outline_0074
      008E85 90 05 88         [24] 1257 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008E88 12 98 6A         [24] 1258 	lcall	_ak820_outline_0112
      008E8B 12 33 FC         [24] 1259 	lcall	_ak820_outline_0123
      008E8E C0 07            [24] 1260 	push	ar7
      008E90 C0 06            [24] 1261 	push	ar6
      008E92 12 40 A2         [24] 1262 	lcall	_ak820_eeprom_read_block_xdata
      008E95 D0 06            [24] 1263 	pop	ar6
      008E97 D0 07            [24] 1264 	pop	ar7
                                   1265 ;	quantum/dynamic_keymap.c:272: if (!ak820_tap_dance_valid(entry)) memset(entry, 0, sizeof(*entry));
      008E99 12 38 7F         [24] 1266 	lcall	_ak820_outline_0120
      008E9C C0 07            [24] 1267 	push	ar7
      008E9E C0 06            [24] 1268 	push	ar6
      008EA0 12 43 BE         [24] 1269 	lcall	_ak820_tap_dance_valid
      008EA3 E5 82            [12] 1270 	mov	a, dpl
      008EA5 D0 06            [24] 1271 	pop	ar6
      008EA7 D0 07            [24] 1272 	pop	ar7
      008EA9 70 07            [24] 1273 	jnz	00104$
      008EAB FD               [12] 1274 	mov	r5,a
      008EAC 12 98 34         [24] 1275 	lcall	_ak820_outline_0042
      008EAF 12 C3 20         [24] 1276 	lcall	_memset
      008EB2                       1277 00104$:
                                   1278 ;	quantum/dynamic_keymap.c:273: return 0;
      008EB2 90 00 00         [24] 1279 	mov	dptr,#0x0000
                                   1280 ;	quantum/dynamic_keymap.c:274: }
      008EB5 22               [24] 1281 	ret
                                   1282 ;------------------------------------------------------------
                                   1283 ;Allocation info for local variables in function 'dynamic_keymap_set_tap_dance'
                                   1284 ;------------------------------------------------------------
                                   1285 ;buffer        Allocated with name '_dynamic_keymap_set_tap_dance_PARM_2'
                                   1286 ;index         Allocated with name '_dynamic_keymap_set_tap_dance_index_10000_395'
                                   1287 ;entry         Allocated with name '_dynamic_keymap_set_tap_dance_entry_10000_396'
                                   1288 ;------------------------------------------------------------
                                   1289 ;	quantum/dynamic_keymap.c:275: int dynamic_keymap_set_tap_dance(uint8_t index, const vial_tap_dance_entry_t *buffer) {
                                   1290 ;	-----------------------------------------
                                   1291 ;	 function dynamic_keymap_set_tap_dance
                                   1292 ;	-----------------------------------------
      008EB6                       1293 _dynamic_keymap_set_tap_dance:
      008EB6 E5 82            [12] 1294 	mov	a,dpl
      008EB8 90 0B A1         [24] 1295 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      008EBB F0               [24] 1296 	movx	@dptr,a
                                   1297 ;	quantum/dynamic_keymap.c:276: const vial_tap_dance_entry_t AK820_STATE_MEM *entry = (const vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      008EBC 90 0B 9E         [24] 1298 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      008EBF 12 38 34         [24] 1299 	lcall	_ak820_outline_0054
                                   1300 ;	quantum/dynamic_keymap.c:277: if (index >= AK820_EXTENSION_ENTRIES || !ak820_tap_dance_valid(entry) || !ak820_nvm_ok()) return -1;
      008EC2 90 0B A1         [24] 1301 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      008EC5 E0               [24] 1302 	movx	a,@dptr
      008EC6 FD               [12] 1303 	mov	r5,a
      008EC7 BD 08 00         [24] 1304 	cjne	r5,#0x08,00139$
      008ECA                       1305 00139$:
      008ECA 50 1D            [24] 1306 	jnc	00101$
      008ECC 12 38 7F         [24] 1307 	lcall	_ak820_outline_0120
      008ECF C0 07            [24] 1308 	push	ar7
      008ED1 C0 06            [24] 1309 	push	ar6
      008ED3 C0 05            [24] 1310 	push	ar5
      008ED5 12 43 BE         [24] 1311 	lcall	_ak820_tap_dance_valid
      008ED8 E5 82            [12] 1312 	mov	a, dpl
      008EDA D0 05            [24] 1313 	pop	ar5
      008EDC D0 06            [24] 1314 	pop	ar6
      008EDE D0 07            [24] 1315 	pop	ar7
      008EE0 60 07            [24] 1316 	jz	00101$
      008EE2 12 3E 0D         [24] 1317 	lcall	_ak820_nvm_ok
      008EE5 E5 82            [12] 1318 	mov	a, dpl
      008EE7 70 04            [24] 1319 	jnz	00102$
      008EE9                       1320 00101$:
      008EE9 90 FF FF         [24] 1321 	mov	dptr,#0xffff
      008EEC 22               [24] 1322 	ret
      008EED                       1323 00102$:
                                   1324 ;	quantum/dynamic_keymap.c:278: clear_keyboard();
      008EED C0 07            [24] 1325 	push	ar7
      008EEF C0 06            [24] 1326 	push	ar6
      008EF1 C0 05            [24] 1327 	push	ar5
      008EF3 12 7F 8D         [24] 1328 	lcall	_clear_keyboard
      008EF6 D0 05            [24] 1329 	pop	ar5
      008EF8 D0 06            [24] 1330 	pop	ar6
      008EFA D0 07            [24] 1331 	pop	ar7
                                   1332 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_update_block_xdata(entry, (void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008EFC BD 06 00         [24] 1333 	cjne	r5,#0x06,00143$
      008EFF                       1334 00143$:
      008EFF 50 0C            [24] 1335 	jnc	00107$
      008F01 8D 04            [24] 1336 	mov	ar4,r5
      008F03 EC               [12] 1337 	mov	a,r4
      008F04 75 F0 0A         [24] 1338 	mov	b,#0x0a
      008F07 A4               [48] 1339 	mul	ab
      008F08 FB               [12] 1340 	mov	r3,a
      008F09 7C 00            [12] 1341 	mov	r4,#0x00
      008F0B 80 11            [24] 1342 	sjmp	00108$
      008F0D                       1343 00107$:
      008F0D ED               [12] 1344 	mov	a,r5
      008F0E 24 FA            [12] 1345 	add	a,#0xfa
      008F10 75 F0 0A         [24] 1346 	mov	b,#0x0a
      008F13 A4               [48] 1347 	mul	ab
      008F14 FD               [12] 1348 	mov	r5,a
      008F15 7A 00            [12] 1349 	mov	r2,#0x00
      008F17 74 40            [12] 1350 	mov	a,#0x40
      008F19 2D               [12] 1351 	add	a, r5
      008F1A FB               [12] 1352 	mov	r3,a
      008F1B E4               [12] 1353 	clr	a
      008F1C 3A               [12] 1354 	addc	a, r2
      008F1D FC               [12] 1355 	mov	r4,a
      008F1E                       1356 00108$:
      008F1E 74 C0            [12] 1357 	mov	a,#0xc0
      008F20 2B               [12] 1358 	add	a, r3
      008F21 FB               [12] 1359 	mov	r3,a
      008F22 74 06            [12] 1360 	mov	a,#0x06
      008F24 3C               [12] 1361 	addc	a, r4
      008F25 FC               [12] 1362 	mov	r4,a
      008F26 90 05 95         [24] 1363 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      008F29 EB               [12] 1364 	mov	a,r3
      008F2A F0               [24] 1365 	movx	@dptr,a
      008F2B EC               [12] 1366 	mov	a,r4
      008F2C 12 38 51         [24] 1367 	lcall	_ak820_outline_0074
      008F2F 90 05 98         [24] 1368 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      008F32 74 0A            [12] 1369 	mov	a,#0x0a
      008F34 F0               [24] 1370 	movx	@dptr,a
      008F35 E4               [12] 1371 	clr	a
      008F36 A3               [24] 1372 	inc	dptr
      008F37 12 43 31         [24] 1373 	lcall	_ak820_outline_0068
      008F3A 12 42 11         [24] 1374 	lcall	_ak820_eeprom_update_block_xdata
                                   1375 ;	quantum/dynamic_keymap.c:280: ak820_nvm_flush();
      008F3D 12 3E 1C         [24] 1376 	lcall	_ak820_nvm_flush
                                   1377 ;	quantum/dynamic_keymap.c:281: return ak820_nvm_ok() ? 0 : -1;
      008F40 12 3E 0D         [24] 1378 	lcall	_ak820_nvm_ok
      008F43 E5 82            [12] 1379 	mov	a, dpl
      008F45 60 06            [24] 1380 	jz	00109$
      008F47 7E 00            [12] 1381 	mov	r6,#0x00
      008F49 7F 00            [12] 1382 	mov	r7,#0x00
      008F4B 80 04            [24] 1383 	sjmp	00110$
      008F4D                       1384 00109$:
      008F4D 7E FF            [12] 1385 	mov	r6,#0xff
      008F4F 7F FF            [12] 1386 	mov	r7,#0xff
      008F51                       1387 00110$:
      008F51 12 38 7F         [24] 1388 	lcall	_ak820_outline_0120
                                   1389 ;	quantum/dynamic_keymap.c:282: }
      008F54 22               [24] 1390 	ret
                                   1391 ;------------------------------------------------------------
                                   1392 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1393 ;------------------------------------------------------------
                                   1394 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1395 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1396 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_398'
                                   1397 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_399'
                                   1398 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_401'
                                   1399 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_402'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function dynamic_keymap_get_combo
                                   1404 ;	-----------------------------------------
      008F55                       1405 _dynamic_keymap_get_combo:
      008F55 E5 82            [12] 1406 	mov	a,dpl
      008F57 90 0B A5         [24] 1407 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008F5A F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008F5B 90 0B A2         [24] 1410 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008F5E 12 38 34         [24] 1411 	lcall	_ak820_outline_0054
                                   1412 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008F61 90 0B A5         [24] 1413 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008F64 E0               [24] 1414 	movx	a,@dptr
      008F65 FD               [12] 1415 	mov	r5,a
      008F66 BD 08 00         [24] 1416 	cjne	r5,#0x08,00132$
      008F69                       1417 00132$:
      008F69 40 04            [24] 1418 	jc	00102$
                                   1419 ;	quantum/dynamic_keymap.c:315: return -1;
      008F6B 90 FF FF         [24] 1420 	mov	dptr,#0xffff
      008F6E 22               [24] 1421 	ret
      008F6F                       1422 00102$:
                                   1423 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008F6F 12 98 49         [24] 1424 	lcall	_ak820_outline_0082
                                   1425 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008F72 8E 02            [24] 1426 	mov	ar2,r6
      008F74 8F 03            [24] 1427 	mov	ar3,r7
      008F76 90 05 85         [24] 1428 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008F79 EC               [12] 1429 	mov	a,r4
      008F7A F0               [24] 1430 	movx	@dptr,a
      008F7B ED               [12] 1431 	mov	a,r5
      008F7C 12 38 51         [24] 1432 	lcall	_ak820_outline_0074
      008F7F 90 05 88         [24] 1433 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008F82 12 98 6A         [24] 1434 	lcall	_ak820_outline_0112
      008F85 12 38 9F         [24] 1435 	lcall	_ak820_outline_0144
      008F88 C0 07            [24] 1436 	push	ar7
      008F8A C0 06            [24] 1437 	push	ar6
      008F8C 12 40 A2         [24] 1438 	lcall	_ak820_eeprom_read_block_xdata
      008F8F D0 06            [24] 1439 	pop	ar6
      008F91 D0 07            [24] 1440 	pop	ar7
                                   1441 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008F93 74 04            [12] 1442 	mov	a,#0x04
      008F95 12 51 D6         [24] 1443 	lcall	_ak820_outline_0034
      008F98 FA               [12] 1444 	mov	r2,a
      008F99 A3               [24] 1445 	inc	dptr
      008F9A E0               [24] 1446 	movx	a,@dptr
      008F9B FB               [12] 1447 	mov	r3,a
      008F9C BA 20 13         [24] 1448 	cjne	r2,#0x20,00108$
      008F9F BB 08 10         [24] 1449 	cjne	r3,#0x08,00108$
      008FA2 74 06            [12] 1450 	mov	a,#0x06
      008FA4 12 38 24         [24] 1451 	lcall	_ak820_outline_0023
      008FA7 12 43 3D         [24] 1452 	lcall	_ak820_outline_0104
      008FAA BA 01 05         [24] 1453 	cjne	r2,#0x01,00136$
      008FAD BB 00 02         [24] 1454 	cjne	r3,#0x00,00136$
      008FB0 80 05            [24] 1455 	sjmp	00109$
      008FB2                       1456 00136$:
      008FB2                       1457 00108$:
      008FB2 75 33 00         [24] 1458 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008FB5 80 03            [24] 1459 	sjmp	00110$
      008FB7                       1460 00109$:
      008FB7 75 33 01         [24] 1461 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008FBA                       1462 00110$:
                                   1463 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008FBA 74 06            [12] 1464 	mov	a,#0x06
      008FBC 12 38 24         [24] 1465 	lcall	_ak820_outline_0023
      008FBF E4               [12] 1466 	clr	a
      008FC0 F0               [24] 1467 	movx	@dptr,a
      008FC1 A3               [24] 1468 	inc	dptr
      008FC2 12 38 69         [24] 1469 	lcall	_ak820_outline_0102
      008FC5 F0               [24] 1470 	movx	@dptr,a
      008FC6 A3               [24] 1471 	inc	dptr
      008FC7 F0               [24] 1472 	movx	@dptr,a
                                   1473 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008FC8 E5 33            [12] 1474 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008FCA 60 12            [24] 1475 	jz	00103$
      008FCC 12 38 7F         [24] 1476 	lcall	_ak820_outline_0120
      008FCF C0 07            [24] 1477 	push	ar7
      008FD1 C0 06            [24] 1478 	push	ar6
      008FD3 12 34 D0         [24] 1479 	lcall	_ak820_combo_valid
      008FD6 E5 82            [12] 1480 	mov	a, dpl
      008FD8 D0 06            [24] 1481 	pop	ar6
      008FDA D0 07            [24] 1482 	pop	ar7
      008FDC 70 08            [24] 1483 	jnz	00104$
      008FDE                       1484 00103$:
      008FDE 7D 00            [12] 1485 	mov	r5,#0x00
      008FE0 12 98 34         [24] 1486 	lcall	_ak820_outline_0042
      008FE3 12 C3 20         [24] 1487 	lcall	_memset
      008FE6                       1488 00104$:
                                   1489 ;	quantum/dynamic_keymap.c:329: return 0;
      008FE6 90 00 00         [24] 1490 	mov	dptr,#0x0000
                                   1491 ;	quantum/dynamic_keymap.c:330: }
      008FE9 22               [24] 1492 	ret
                                   1493 ;------------------------------------------------------------
                                   1494 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1495 ;------------------------------------------------------------
                                   1496 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1497 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_404'
                                   1498 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_405'
                                   1499 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_408'
                                   1500 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_409'
                                   1501 ;------------------------------------------------------------
                                   1502 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1503 ;	-----------------------------------------
                                   1504 ;	 function dynamic_keymap_set_combo
                                   1505 ;	-----------------------------------------
      008FEA                       1506 _dynamic_keymap_set_combo:
      008FEA E5 82            [12] 1507 	mov	a,dpl
      008FEC 90 0B A9         [24] 1508 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      008FEF F0               [24] 1509 	movx	@dptr,a
                                   1510 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008FF0 90 0B A6         [24] 1511 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008FF3 12 37 E7         [24] 1512 	lcall	_ak820_outline_0005
                                   1513 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008FF6 C0 07            [24] 1514 	push	ar7
      008FF8 C0 06            [24] 1515 	push	ar6
      008FFA 12 34 D0         [24] 1516 	lcall	_ak820_combo_valid
      008FFD E5 82            [12] 1517 	mov	a, dpl
      008FFF D0 06            [24] 1518 	pop	ar6
      009001 D0 07            [24] 1519 	pop	ar7
      009003 60 07            [24] 1520 	jz	00101$
      009005 12 3E 0D         [24] 1521 	lcall	_ak820_nvm_ok
      009008 E5 82            [12] 1522 	mov	a, dpl
      00900A 70 04            [24] 1523 	jnz	00102$
      00900C                       1524 00101$:
      00900C 90 FF FF         [24] 1525 	mov	dptr,#0xffff
      00900F 22               [24] 1526 	ret
      009010                       1527 00102$:
                                   1528 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      009010 90 0B A9         [24] 1529 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      009013 E0               [24] 1530 	movx	a,@dptr
      009014 FD               [12] 1531 	mov	r5,a
      009015 BD 08 00         [24] 1532 	cjne	r5,#0x08,00133$
      009018                       1533 00133$:
      009018 40 04            [24] 1534 	jc	00105$
                                   1535 ;	quantum/dynamic_keymap.c:342: return -1;
      00901A 90 FF FF         [24] 1536 	mov	dptr,#0xffff
      00901D 22               [24] 1537 	ret
      00901E                       1538 00105$:
                                   1539 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00901E 12 98 49         [24] 1540 	lcall	_ak820_outline_0082
                                   1541 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      009021 C0 07            [24] 1542 	push	ar7
      009023 C0 06            [24] 1543 	push	ar6
      009025 C0 05            [24] 1544 	push	ar5
      009027 C0 04            [24] 1545 	push	ar4
      009029 12 7F 8D         [24] 1546 	lcall	_clear_keyboard
      00902C D0 04            [24] 1547 	pop	ar4
      00902E D0 05            [24] 1548 	pop	ar5
      009030 D0 06            [24] 1549 	pop	ar6
      009032 D0 07            [24] 1550 	pop	ar7
                                   1551 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      009034 90 0E 73         [24] 1552 	mov	dptr,#___memcpy_PARM_2
      009037 12 51 E9         [24] 1553 	lcall	_ak820_outline_0061
      00903A E4               [12] 1554 	clr	a
      00903B A3               [24] 1555 	inc	dptr
      00903C F0               [24] 1556 	movx	@dptr,a
      00903D 90 0E 76         [24] 1557 	mov	dptr,#___memcpy_PARM_3
      009040 12 98 6A         [24] 1558 	lcall	_ak820_outline_0112
      009043 90 0B AA         [24] 1559 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      009046 F5 F0            [12] 1560 	mov	b,a
      009048 C0 05            [24] 1561 	push	ar5
      00904A C0 04            [24] 1562 	push	ar4
      00904C 12 C2 AA         [24] 1563 	lcall	___memcpy
      00904F D0 04            [24] 1564 	pop	ar4
      009051 D0 05            [24] 1565 	pop	ar5
                                   1566 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      009053 90 0B AE         [24] 1567 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0004)
      009056 74 20            [12] 1568 	mov	a,#0x20
      009058 F0               [24] 1569 	movx	@dptr,a
      009059 74 08            [12] 1570 	mov	a,#0x08
      00905B A3               [24] 1571 	inc	dptr
      00905C F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      00905D 90 0B B0         [24] 1574 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0006)
      009060 74 01            [12] 1575 	mov	a,#0x01
      009062 12 38 8F         [24] 1576 	lcall	_ak820_outline_0127
                                   1577 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      009065 90 05 8E         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      009068 EC               [12] 1579 	mov	a,r4
      009069 F0               [24] 1580 	movx	@dptr,a
      00906A ED               [12] 1581 	mov	a,r5
      00906B 12 38 51         [24] 1582 	lcall	_ak820_outline_0074
      00906E 90 05 91         [24] 1583 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      009071 12 98 6A         [24] 1584 	lcall	_ak820_outline_0112
      009074 90 0B AA         [24] 1585 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      009077 12 41 2E         [24] 1586 	lcall	_ak820_eeprom_write_block_xdata
                                   1587 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      00907A 12 3E 1C         [24] 1588 	lcall	_ak820_nvm_flush
                                   1589 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      00907D 12 3E 0D         [24] 1590 	lcall	_ak820_nvm_ok
      009080 E5 82            [12] 1591 	mov	a, dpl
      009082 70 04            [24] 1592 	jnz	00107$
      009084 90 FF FF         [24] 1593 	mov	dptr,#0xffff
      009087 22               [24] 1594 	ret
      009088                       1595 00107$:
                                   1596 ;	quantum/dynamic_keymap.c:360: return 0;
      009088 90 00 00         [24] 1597 	mov	dptr,#0x0000
                                   1598 ;	quantum/dynamic_keymap.c:361: }
      00908B 22               [24] 1599 	ret
                                   1600 ;------------------------------------------------------------
                                   1601 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1602 ;------------------------------------------------------------
                                   1603 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_412'
                                   1604 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_413'
                                   1605 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_415'
                                   1606 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_417'
                                   1607 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_419'
                                   1608 ;td            Allocated with name '_dynamic_keymap_reset_td_10001_421'
                                   1609 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_422'
                                   1610 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10002_424'
                                   1611 ;i             Allocated with name '_dynamic_keymap_reset_i_20002_425'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function dynamic_keymap_reset
                                   1616 ;	-----------------------------------------
      00908C                       1617 _dynamic_keymap_reset:
                                   1618 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      00908C 90 0E F4         [24] 1619 	mov	dptr,#_vial_unlocked
      00908F E0               [24] 1620 	movx	a,@dptr
      009090 90 0B B4         [24] 1621 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      009093 F0               [24] 1622 	movx	@dptr,a
                                   1623 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      009094 90 0E F4         [24] 1624 	mov	dptr,#_vial_unlocked
      009097 74 01            [12] 1625 	mov	a,#0x01
      009099 F0               [24] 1626 	movx	@dptr,a
                                   1627 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00909A 7F 00            [12] 1628 	mov	r7,#0x00
      00909C                       1629 00117$:
      00909C BF 06 00         [24] 1630 	cjne	r7,#0x06,00217$
      00909F                       1631 00217$:
      00909F 40 02            [24] 1632 	jc	00218$
      0090A1 21 4D            [12] 1633 	ajmp	00104$
      0090A3                       1634 00218$:
                                   1635 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0090A3 7E 00            [12] 1636 	mov	r6,#0x00
      0090A5                       1637 00111$:
      0090A5 BE 10 00         [24] 1638 	cjne	r6,#0x10,00219$
      0090A8                       1639 00219$:
      0090A8 50 4D            [24] 1640 	jnc	00102$
                                   1641 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0090AA 7D 00            [12] 1642 	mov	r5,#0x00
      0090AC                       1643 00108$:
      0090AC BD 08 00         [24] 1644 	cjne	r5,#0x08,00221$
      0090AF                       1645 00221$:
      0090AF 50 43            [24] 1646 	jnc	00112$
                                   1647 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0090B1 90 0C 5A         [24] 1648 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0090B4 EE               [12] 1649 	mov	a,r6
      0090B5 F0               [24] 1650 	movx	@dptr,a
      0090B6 90 0C 5B         [24] 1651 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0090B9 ED               [12] 1652 	mov	a,r5
      0090BA F0               [24] 1653 	movx	@dptr,a
      0090BB 8F 82            [24] 1654 	mov	dpl, r7
      0090BD C0 07            [24] 1655 	push	ar7
      0090BF C0 06            [24] 1656 	push	ar6
      0090C1 C0 05            [24] 1657 	push	ar5
      0090C3 12 A0 7B         [24] 1658 	lcall	_keycode_at_keymap_location_raw
      0090C6 AB 82            [24] 1659 	mov	r3, dpl
      0090C8 AC 83            [24] 1660 	mov	r4, dph
      0090CA D0 05            [24] 1661 	pop	ar5
      0090CC D0 06            [24] 1662 	pop	ar6
      0090CE D0 07            [24] 1663 	pop	ar7
      0090D0 90 0B 8B         [24] 1664 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0090D3 EE               [12] 1665 	mov	a,r6
      0090D4 F0               [24] 1666 	movx	@dptr,a
      0090D5 90 0B 8C         [24] 1667 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0090D8 ED               [12] 1668 	mov	a,r5
      0090D9 F0               [24] 1669 	movx	@dptr,a
      0090DA 90 0B 8D         [24] 1670 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0090DD 12 38 63         [24] 1671 	lcall	_ak820_outline_0086
      0090E0 8F 82            [24] 1672 	mov	dpl, r7
      0090E2 C0 07            [24] 1673 	push	ar7
      0090E4 C0 06            [24] 1674 	push	ar6
      0090E6 C0 05            [24] 1675 	push	ar5
      0090E8 12 8C F2         [24] 1676 	lcall	_dynamic_keymap_set_keycode
      0090EB D0 05            [24] 1677 	pop	ar5
      0090ED D0 06            [24] 1678 	pop	ar6
      0090EF D0 07            [24] 1679 	pop	ar7
                                   1680 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0090F1 0D               [12] 1681 	inc	r5
      0090F2 80 B8            [24] 1682 	sjmp	00108$
      0090F4                       1683 00112$:
                                   1684 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0090F4 0E               [12] 1685 	inc	r6
      0090F5 80 AE            [24] 1686 	sjmp	00111$
      0090F7                       1687 00102$:
                                   1688 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0090F7 7E 00            [12] 1689 	mov	r6,#0x00
      0090F9                       1690 00114$:
      0090F9 BE 01 00         [24] 1691 	cjne	r6,#0x01,00223$
      0090FC                       1692 00223$:
      0090FC 50 4C            [24] 1693 	jnc	00118$
                                   1694 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      0090FE 12 98 9F         [24] 1695 	lcall	_ak820_outline_0180
      009101 04               [12] 1696 	inc	a
      009102 F0               [24] 1697 	movx	@dptr,a
      009103 8F 82            [24] 1698 	mov	dpl, r7
      009105 C0 07            [24] 1699 	push	ar7
      009107 12 A0 C0         [24] 1700 	lcall	_keycode_at_encodermap_location_raw
      00910A 12 43 60         [24] 1701 	lcall	_ak820_outline_0150
      00910D D0 07            [24] 1702 	pop	ar7
      00910F 12 98 96         [24] 1703 	lcall	_ak820_outline_0179
      009112 04               [12] 1704 	inc	a
      009113 F0               [24] 1705 	movx	@dptr,a
      009114 90 0B 97         [24] 1706 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      009117 12 38 57         [24] 1707 	lcall	_ak820_outline_0079
      00911A 8F 82            [24] 1708 	mov	dpl, r7
      00911C C0 07            [24] 1709 	push	ar7
      00911E 12 8D C9         [24] 1710 	lcall	_dynamic_keymap_set_encoder
      009121 D0 07            [24] 1711 	pop	ar7
                                   1712 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      009123 12 98 9F         [24] 1713 	lcall	_ak820_outline_0180
      009126 F0               [24] 1714 	movx	@dptr,a
      009127 8F 82            [24] 1715 	mov	dpl, r7
      009129 C0 07            [24] 1716 	push	ar7
      00912B 12 A0 C0         [24] 1717 	lcall	_keycode_at_encodermap_location_raw
      00912E 12 43 60         [24] 1718 	lcall	_ak820_outline_0150
      009131 D0 07            [24] 1719 	pop	ar7
      009133 12 98 96         [24] 1720 	lcall	_ak820_outline_0179
      009136 F0               [24] 1721 	movx	@dptr,a
      009137 90 0B 97         [24] 1722 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00913A 12 38 57         [24] 1723 	lcall	_ak820_outline_0079
      00913D 8F 82            [24] 1724 	mov	dpl, r7
      00913F C0 07            [24] 1725 	push	ar7
      009141 12 8D C9         [24] 1726 	lcall	_dynamic_keymap_set_encoder
      009144 D0 07            [24] 1727 	pop	ar7
                                   1728 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      009146 7E 01            [12] 1729 	mov	r6,#0x01
      009148 80 AF            [24] 1730 	sjmp	00114$
      00914A                       1731 00118$:
                                   1732 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00914A 0F               [12] 1733 	inc	r7
      00914B 01 9C            [12] 1734 	ajmp	00117$
      00914D                       1735 00104$:
                                   1736 ;	quantum/dynamic_keymap.c:442: vial_tap_dance_entry_t td = { KC_NO, KC_NO, KC_NO, KC_NO, TAPPING_TERM };
      00914D 90 0B B5         [24] 1737 	mov	dptr,#_dynamic_keymap_reset_td_10001_421
      009150 12 58 A4         [24] 1738 	lcall	_ak820_outline_0156
      009153 90 0B B7         [24] 1739 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0002)
      009156 F0               [24] 1740 	movx	@dptr,a
      009157 A3               [24] 1741 	inc	dptr
      009158 F0               [24] 1742 	movx	@dptr,a
      009159 90 0B B9         [24] 1743 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0004)
      00915C F0               [24] 1744 	movx	@dptr,a
      00915D A3               [24] 1745 	inc	dptr
      00915E F0               [24] 1746 	movx	@dptr,a
      00915F 90 0B BB         [24] 1747 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0006)
      009162 F0               [24] 1748 	movx	@dptr,a
      009163 A3               [24] 1749 	inc	dptr
      009164 F0               [24] 1750 	movx	@dptr,a
      009165 90 0B BD         [24] 1751 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0008)
      009168 74 C8            [12] 1752 	mov	a,#0xc8
      00916A 12 38 8F         [24] 1753 	lcall	_ak820_outline_0127
                                   1754 ;	quantum/dynamic_keymap.c:443: for (size_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      00916D FF               [12] 1755 	mov	r7,a
      00916E                       1756 00120$:
      00916E BF 08 00         [24] 1757 	cjne	r7,#0x08,00225$
      009171                       1758 00225$:
      009171 50 19            [24] 1759 	jnc	00105$
                                   1760 ;	quantum/dynamic_keymap.c:444: dynamic_keymap_set_tap_dance(i, &td);
      009173 8F 06            [24] 1761 	mov	ar6,r7
      009175 90 0B 9E         [24] 1762 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      009178 74 B5            [12] 1763 	mov	a,#_dynamic_keymap_reset_td_10001_421
      00917A F0               [24] 1764 	movx	@dptr,a
      00917B 74 0B            [12] 1765 	mov	a,#(_dynamic_keymap_reset_td_10001_421 >> 8)
      00917D 12 38 51         [24] 1766 	lcall	_ak820_outline_0074
      009180 8E 82            [24] 1767 	mov	dpl, r6
      009182 C0 07            [24] 1768 	push	ar7
      009184 12 8E B6         [24] 1769 	lcall	_dynamic_keymap_set_tap_dance
      009187 D0 07            [24] 1770 	pop	ar7
                                   1771 ;	quantum/dynamic_keymap.c:443: for (size_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      009189 0F               [12] 1772 	inc	r7
      00918A 80 E2            [24] 1773 	sjmp	00120$
      00918C                       1774 00105$:
                                   1775 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      00918C 90 0B BF         [24] 1776 	mov	dptr,#_dynamic_keymap_reset_combo_10002_424
      00918F 12 58 A4         [24] 1777 	lcall	_ak820_outline_0156
      009192 90 0B C1         [24] 1778 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0002)
      009195 F0               [24] 1779 	movx	@dptr,a
      009196 A3               [24] 1780 	inc	dptr
      009197 F0               [24] 1781 	movx	@dptr,a
      009198 90 0B C3         [24] 1782 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0004)
      00919B F0               [24] 1783 	movx	@dptr,a
      00919C A3               [24] 1784 	inc	dptr
      00919D F0               [24] 1785 	movx	@dptr,a
      00919E 90 0B C5         [24] 1786 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0006)
      0091A1 F0               [24] 1787 	movx	@dptr,a
      0091A2 A3               [24] 1788 	inc	dptr
      0091A3 F0               [24] 1789 	movx	@dptr,a
      0091A4 90 0B C7         [24] 1790 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0008)
      0091A7 F0               [24] 1791 	movx	@dptr,a
      0091A8 A3               [24] 1792 	inc	dptr
      0091A9 F0               [24] 1793 	movx	@dptr,a
                                   1794 ;	quantum/dynamic_keymap.c:450: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0091AA FF               [12] 1795 	mov	r7,a
      0091AB                       1796 00123$:
      0091AB BF 08 00         [24] 1797 	cjne	r7,#0x08,00227$
      0091AE                       1798 00227$:
      0091AE 50 19            [24] 1799 	jnc	00106$
                                   1800 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      0091B0 8F 06            [24] 1801 	mov	ar6,r7
      0091B2 90 0B A6         [24] 1802 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0091B5 74 BF            [12] 1803 	mov	a,#_dynamic_keymap_reset_combo_10002_424
      0091B7 F0               [24] 1804 	movx	@dptr,a
      0091B8 74 0B            [12] 1805 	mov	a,#(_dynamic_keymap_reset_combo_10002_424 >> 8)
      0091BA 12 38 51         [24] 1806 	lcall	_ak820_outline_0074
      0091BD 8E 82            [24] 1807 	mov	dpl, r6
      0091BF C0 07            [24] 1808 	push	ar7
      0091C1 12 8F EA         [24] 1809 	lcall	_dynamic_keymap_set_combo
      0091C4 D0 07            [24] 1810 	pop	ar7
                                   1811 ;	quantum/dynamic_keymap.c:450: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0091C6 0F               [12] 1812 	inc	r7
      0091C7 80 E2            [24] 1813 	sjmp	00123$
      0091C9                       1814 00106$:
                                   1815 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      0091C9 90 0B B4         [24] 1816 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      0091CC E0               [24] 1817 	movx	a,@dptr
      0091CD 90 0E F4         [24] 1818 	mov	dptr,#_vial_unlocked
      0091D0 F0               [24] 1819 	movx	@dptr,a
                                   1820 ;	quantum/dynamic_keymap.c:468: }
      0091D1 22               [24] 1821 	ret
                                   1822 ;------------------------------------------------------------
                                   1823 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1824 ;------------------------------------------------------------
                                   1825 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1826 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1827 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1828 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1829 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1830 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_426'
                                   1831 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_427'
                                   1832 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_427'
                                   1833 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_430'
                                   1834 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_432'
                                   1835 ;------------------------------------------------------------
                                   1836 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1837 ;	-----------------------------------------
                                   1838 ;	 function ak820_dynamic_read_buffer
                                   1839 ;	-----------------------------------------
      0091D2                       1840 _ak820_dynamic_read_buffer:
      0091D2 12 38 75         [24] 1841 	lcall	_ak820_outline_0108
      0091D5 90 0B D2         [24] 1842 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      0091D8 12 38 7A         [24] 1843 	lcall	_ak820_outline_0109
                                   1844 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0091DB 90 0B CF         [24] 1845 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0091DE 12 38 34         [24] 1846 	lcall	_ak820_outline_0054
                                   1847 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      0091E1 90 0B D4         [24] 1848 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      0091E4 E4               [12] 1849 	clr	a
      0091E5 F0               [24] 1850 	movx	@dptr,a
                                   1851 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      0091E6 90 0B CD         [24] 1852 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0091E9 12 38 4B         [24] 1853 	lcall	_ak820_outline_0062
      0091EC 8C 02            [24] 1854 	mov	ar2,r4
      0091EE 8D 03            [24] 1855 	mov	ar3,r5
      0091F0 C3               [12] 1856 	clr	c
      0091F1 74 1C            [12] 1857 	mov	a,#0x1c
      0091F3 9A               [12] 1858 	subb	a,r2
      0091F4 E4               [12] 1859 	clr	a
      0091F5 9B               [12] 1860 	subb	a,r3
      0091F6 50 01            [24] 1861 	jnc	00102$
                                   1862 ;	free result
      0091F8 22               [24] 1863 	ret
      0091F9                       1864 00102$:
                                   1865 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      0091F9 90 0B CB         [24] 1866 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0091FC 12 43 3D         [24] 1867 	lcall	_ak820_outline_0104
      0091FF 90 0B C9         [24] 1868 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      009202 12 38 6F         [24] 1869 	lcall	_ak820_outline_0103
      009205 C3               [12] 1870 	clr	c
      009206 EA               [12] 1871 	mov	a,r2
      009207 98               [12] 1872 	subb	a,r0
      009208 EB               [12] 1873 	mov	a,r3
      009209 99               [12] 1874 	subb	a,r1
      00920A 50 17            [24] 1875 	jnc	00104$
                                   1876 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      00920C E8               [12] 1877 	mov	a,r0
      00920D C3               [12] 1878 	clr	c
      00920E 9A               [12] 1879 	subb	a,r2
      00920F F8               [12] 1880 	mov	r0,a
      009210 E9               [12] 1881 	mov	a,r1
      009211 9B               [12] 1882 	subb	a,r3
      009212 F9               [12] 1883 	mov	r1,a
                                   1884 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      009213 C3               [12] 1885 	clr	c
      009214 E8               [12] 1886 	mov	a,r0
      009215 9C               [12] 1887 	subb	a,r4
      009216 E9               [12] 1888 	mov	a,r1
      009217 9D               [12] 1889 	subb	a,r5
      009218 40 04            [24] 1890 	jc	00114$
      00921A 8C 00            [24] 1891 	mov	ar0,r4
      00921C 8D 01            [24] 1892 	mov	ar1,r5
      00921E                       1893 00114$:
      00921E 90 0B D4         [24] 1894 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      009221 E8               [12] 1895 	mov	a,r0
      009222 F0               [24] 1896 	movx	@dptr,a
      009223                       1897 00104$:
                                   1898 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      009223 90 0B D4         [24] 1899 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      009226 E0               [24] 1900 	movx	a,@dptr
      009227 F5 34            [12] 1901 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      009229 E0               [24] 1902 	movx	a,@dptr
      00922A 60 42            [24] 1903 	jz	00106$
      00922C C0 04            [24] 1904 	push	ar4
      00922E C0 05            [24] 1905 	push	ar5
      009230 8E 00            [24] 1906 	mov	ar0,r6
      009232 8F 05            [24] 1907 	mov	ar5,r7
      009234 90 0B D2         [24] 1908 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      009237 E0               [24] 1909 	movx	a,@dptr
      009238 F9               [12] 1910 	mov	r1,a
      009239 A3               [24] 1911 	inc	dptr
      00923A E0               [24] 1912 	movx	a,@dptr
      00923B FC               [12] 1913 	mov	r4,a
      00923C EA               [12] 1914 	mov	a,r2
      00923D 29               [12] 1915 	add	a, r1
      00923E FA               [12] 1916 	mov	r2,a
      00923F EB               [12] 1917 	mov	a,r3
      009240 3C               [12] 1918 	addc	a, r4
      009241 FB               [12] 1919 	mov	r3,a
      009242 90 05 85         [24] 1920 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      009245 EA               [12] 1921 	mov	a,r2
      009246 F0               [24] 1922 	movx	@dptr,a
      009247 EB               [12] 1923 	mov	a,r3
      009248 12 38 51         [24] 1924 	lcall	_ak820_outline_0074
      00924B 90 05 88         [24] 1925 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00924E E5 34            [12] 1926 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      009250 12 38 8F         [24] 1927 	lcall	_ak820_outline_0127
      009253 88 82            [24] 1928 	mov	dpl, r0
      009255 8D 83            [24] 1929 	mov	dph, r5
      009257 C0 07            [24] 1930 	push	ar7
      009259 C0 06            [24] 1931 	push	ar6
      00925B C0 05            [24] 1932 	push	ar5
      00925D C0 04            [24] 1933 	push	ar4
      00925F 12 40 A2         [24] 1934 	lcall	_ak820_eeprom_read_block_xdata
      009262 D0 04            [24] 1935 	pop	ar4
      009264 D0 05            [24] 1936 	pop	ar5
      009266 D0 06            [24] 1937 	pop	ar6
      009268 D0 07            [24] 1938 	pop	ar7
                                   1939 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      00926A D0 05            [24] 1940 	pop	ar5
      00926C D0 04            [24] 1941 	pop	ar4
                                   1942 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      00926E                       1943 00106$:
                                   1944 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      00926E 90 0B D4         [24] 1945 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      009271 E0               [24] 1946 	movx	a,@dptr
      009272 FB               [12] 1947 	mov	r3,a
      009273                       1948 00109$:
      009273 8B 01            [24] 1949 	mov	ar1,r3
      009275 7A 00            [12] 1950 	mov	r2,#0x00
      009277 C3               [12] 1951 	clr	c
      009278 E9               [12] 1952 	mov	a,r1
      009279 9C               [12] 1953 	subb	a,r4
      00927A EA               [12] 1954 	mov	a,r2
      00927B 9D               [12] 1955 	subb	a,r5
      00927C 50 09            [24] 1956 	jnc	00111$
      00927E EB               [12] 1957 	mov	a,r3
      00927F 12 38 24         [24] 1958 	lcall	_ak820_outline_0023
      009282 E4               [12] 1959 	clr	a
      009283 F0               [24] 1960 	movx	@dptr,a
      009284 0B               [12] 1961 	inc	r3
      009285 80 EC            [24] 1962 	sjmp	00109$
      009287                       1963 00111$:
                                   1964 ;	quantum/dynamic_keymap.c:483: }
      009287 22               [24] 1965 	ret
                                   1966 ;------------------------------------------------------------
                                   1967 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1968 ;------------------------------------------------------------
                                   1969 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1970 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1971 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_433'
                                   1972 ;------------------------------------------------------------
                                   1973 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1974 ;	-----------------------------------------
                                   1975 ;	 function dynamic_keymap_get_buffer
                                   1976 ;	-----------------------------------------
      009288                       1977 _dynamic_keymap_get_buffer:
      009288 12 38 75         [24] 1978 	lcall	_ak820_outline_0108
      00928B 90 0B DA         [24] 1979 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      00928E 12 38 7A         [24] 1980 	lcall	_ak820_outline_0109
                                   1981 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      009291 90 0B DA         [24] 1982 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      009294 12 38 34         [24] 1983 	lcall	_ak820_outline_0054
      009297 90 0B D5         [24] 1984 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00929A 12 38 4B         [24] 1985 	lcall	_ak820_outline_0062
      00929D 90 0B D7         [24] 1986 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      0092A0 12 58 8B         [24] 1987 	lcall	_ak820_outline_0092
      0092A3 90 0B C9         [24] 1988 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0092A6 E4               [12] 1989 	clr	a
      0092A7 F0               [24] 1990 	movx	@dptr,a
      0092A8 74 06            [12] 1991 	mov	a,#0x06
      0092AA A3               [24] 1992 	inc	dptr
      0092AB F0               [24] 1993 	movx	@dptr,a
      0092AC 90 0B CB         [24] 1994 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0092AF 12 51 E9         [24] 1995 	lcall	_ak820_outline_0061
      0092B2 90 0B CD         [24] 1996 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0092B5 12 38 57         [24] 1997 	lcall	_ak820_outline_0079
      0092B8 90 0B CF         [24] 1998 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0092BB 12 52 18         [24] 1999 	lcall	_ak820_outline_0100
      0092BE EB               [12] 2000 	mov	a,r3
      0092BF A3               [24] 2001 	inc	dptr
      0092C0 F0               [24] 2002 	movx	@dptr,a
      0092C1 90 00 40         [24] 2003 	mov	dptr,#0x0040
                                   2004 ;	quantum/dynamic_keymap.c:511: }
      0092C4 21 D2            [12] 2005 	ajmp	_ak820_dynamic_read_buffer
                                   2006 ;------------------------------------------------------------
                                   2007 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   2008 ;------------------------------------------------------------
                                   2009 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   2010 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   2011 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   2012 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   2013 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   2014 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_435'
                                   2015 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_436'
                                   2016 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_436'
                                   2017 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_436'
                                   2018 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_439'
                                   2019 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_442'
                                   2020 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_442'
                                   2021 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_444'
                                   2022 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_447'
                                   2023 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_449'
                                   2024 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_450'
                                   2025 ;------------------------------------------------------------
                                   2026 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2027 ;	-----------------------------------------
                                   2028 ;	 function dynamic_keymap_set_buffer
                                   2029 ;	-----------------------------------------
      0092C6                       2030 _dynamic_keymap_set_buffer:
      0092C6 12 38 75         [24] 2031 	lcall	_ak820_outline_0108
      0092C9 90 0B E1         [24] 2032 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      0092CC 12 38 7A         [24] 2033 	lcall	_ak820_outline_0109
                                   2034 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      0092CF 90 0B E1         [24] 2035 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      0092D2 12 51 8C         [24] 2036 	lcall	_ak820_outline_0009
      0092D5 74 40            [12] 2037 	mov	a,#0x40
      0092D7 2C               [12] 2038 	add	a, r4
      0092D8 FA               [12] 2039 	mov	r2,a
      0092D9 E4               [12] 2040 	clr	a
      0092DA 3D               [12] 2041 	addc	a, r5
      0092DB FB               [12] 2042 	mov	r3,a
                                   2043 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0092DC 90 0B DE         [24] 2044 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      0092DF 12 38 6F         [24] 2045 	lcall	_ak820_outline_0103
                                   2046 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      0092E2 90 0B DC         [24] 2047 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      0092E5 E0               [24] 2048 	movx	a,@dptr
      0092E6 F5 35            [12] 2049 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      0092E8 A3               [24] 2050 	inc	dptr
      0092E9 E0               [24] 2051 	movx	a,@dptr
      0092EA F5 36            [12] 2052 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      0092EC E5 35            [12] 2053 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0092EE 45 36            [12] 2054 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0092F0 70 01            [24] 2055 	jnz	00102$
      0092F2 22               [24] 2056 	ret
      0092F3                       2057 00102$:
                                   2058 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      0092F3 85 35 37         [24] 2059 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      0092F6 85 36 38         [24] 2060 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0092F9 C3               [12] 2061 	clr	c
      0092FA 74 1C            [12] 2062 	mov	a,#0x1c
      0092FC 95 37            [12] 2063 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0092FE E4               [12] 2064 	clr	a
      0092FF 95 38            [12] 2065 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      009301 50 01            [24] 2066 	jnc	00104$
                                   2067 ;	free result
      009303 22               [24] 2068 	ret
      009304                       2069 00104$:
                                   2070 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      009304 85 35 39         [24] 2071 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   2072 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      009307 74 FA            [12] 2073 	mov	a,#0x100 - 0x06
      009309 2F               [12] 2074 	add	a,r7
      00930A 40 11            [24] 2075 	jc	00105$
      00930C E4               [12] 2076 	clr	a
      00930D C3               [12] 2077 	clr	c
      00930E 9E               [12] 2078 	subb	a,r6
      00930F FE               [12] 2079 	mov	r6,a
      009310 74 06            [12] 2080 	mov	a,#0x06
      009312 9F               [12] 2081 	subb	a,r7
      009313 FF               [12] 2082 	mov	r7,a
      009314 C3               [12] 2083 	clr	c
      009315 EE               [12] 2084 	mov	a,r6
      009316 95 35            [12] 2085 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      009318 EF               [12] 2086 	mov	a,r7
      009319 95 36            [12] 2087 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00931B 50 01            [24] 2088 	jnc	00106$
      00931D                       2089 00105$:
                                   2090 ;	quantum/dynamic_keymap.c:529: return;
      00931D 22               [24] 2091 	ret
      00931E                       2092 00106$:
                                   2093 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      00931E 90 0E F4         [24] 2094 	mov	dptr,#_vial_unlocked
      009321 E0               [24] 2095 	movx	a,@dptr
      009322 60 02            [24] 2096 	jz	00207$
      009324 81 30            [12] 2097 	ajmp	00120$
      009326                       2098 00207$:
                                   2099 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      009326 90 0B E3         [24] 2100 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      009329 E4               [12] 2101 	clr	a
      00932A F0               [24] 2102 	movx	@dptr,a
                                   2103 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      00932B 90 0B E4         [24] 2104 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      00932E E5 39            [12] 2105 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      009330 F0               [24] 2106 	movx	@dptr,a
                                   2107 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      009331 EC               [12] 2108 	mov	a,r4
      009332 30 E0 31         [24] 2109 	jnb	acc.0,00111$
                                   2110 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      009335 EA               [12] 2111 	mov	a,r2
      009336 24 FF            [12] 2112 	add	a,#0xff
      009338 FE               [12] 2113 	mov	r6,a
      009339 EB               [12] 2114 	mov	a,r3
      00933A 34 FF            [12] 2115 	addc	a,#0xff
      00933C FF               [12] 2116 	mov	r7,a
      00933D 7D 00            [12] 2117 	mov	r5,#0x00
      00933F 12 80 23         [24] 2118 	lcall	_ak820_outline_0114
      009342 12 40 67         [24] 2119 	lcall	_eeprom_read_byte
      009345 AE 82            [24] 2120 	mov	r6,dpl
      009347 7F 00            [12] 2121 	mov	r7,#0x00
      009349 12 38 A9         [24] 2122 	lcall	_ak820_outline_0158
      00934C E0               [24] 2123 	movx	a,@dptr
      00934D 7C 00            [12] 2124 	mov	r4,#0x00
      00934F 42 07            [12] 2125 	orl	ar7,a
      009351 EC               [12] 2126 	mov	a,r4
      009352 42 06            [12] 2127 	orl	ar6,a
                                   2128 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      009354 BF 00 09         [24] 2129 	cjne	r7,#0x00,00109$
      009357 BE 7C 06         [24] 2130 	cjne	r6,#0x7c,00109$
                                   2131 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      00935A 12 38 A9         [24] 2132 	lcall	_ak820_outline_0158
      00935D 74 FF            [12] 2133 	mov	a,#0xff
      00935F F0               [24] 2134 	movx	@dptr,a
      009360                       2135 00109$:
                                   2136 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      009360 90 0B E3         [24] 2137 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      009363 74 01            [12] 2138 	mov	a,#0x01
      009365 F0               [24] 2139 	movx	@dptr,a
      009366                       2140 00111$:
                                   2141 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      009366 90 0B E1         [24] 2142 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      009369 12 38 34         [24] 2143 	lcall	_ak820_outline_0054
      00936C E5 35            [12] 2144 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00936E 2E               [12] 2145 	add	a, r6
      00936F FE               [12] 2146 	mov	r6,a
      009370 E5 36            [12] 2147 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009372 3F               [12] 2148 	addc	a, r7
      009373 EE               [12] 2149 	mov	a,r6
      009374 30 E0 5A         [24] 2150 	jnb	acc.0,00115$
                                   2151 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      009377 AE 39            [24] 2152 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      009379 7F 00            [12] 2153 	mov	r7,#0x00
      00937B EE               [12] 2154 	mov	a,r6
      00937C 24 FF            [12] 2155 	add	a,#0xff
      00937E FC               [12] 2156 	mov	r4,a
      00937F EF               [12] 2157 	mov	a,r7
      009380 34 FF            [12] 2158 	addc	a,#0xff
      009382 FD               [12] 2159 	mov	r5,a
      009383 EC               [12] 2160 	mov	a,r4
      009384 28               [12] 2161 	add	a, r0
      009385 F5 82            [12] 2162 	mov	dpl,a
      009387 ED               [12] 2163 	mov	a,r5
      009388 39               [12] 2164 	addc	a, r1
      009389 F5 83            [12] 2165 	mov	dph,a
      00938B E0               [24] 2166 	movx	a,@dptr
      00938C FC               [12] 2167 	mov	r4,a
      00938D 7D 00            [12] 2168 	mov	r5,#0x00
      00938F E5 39            [12] 2169 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      009391 2A               [12] 2170 	add	a, r2
      009392 FA               [12] 2171 	mov	r2,a
      009393 E4               [12] 2172 	clr	a
      009394 3B               [12] 2173 	addc	a, r3
      009395 FB               [12] 2174 	mov	r3,a
      009396 C0 00            [24] 2175 	push	ar0
      009398 C0 01            [24] 2176 	push	ar1
      00939A 8B 01            [24] 2177 	mov	ar1,r3
      00939C 7B 00            [12] 2178 	mov	r3,#0x00
      00939E 8A 82            [24] 2179 	mov	dpl, r2
      0093A0 89 83            [24] 2180 	mov	dph, r1
      0093A2 8B F0            [24] 2181 	mov	b, r3
      0093A4 12 40 67         [24] 2182 	lcall	_eeprom_read_byte
      0093A7 AB 82            [24] 2183 	mov	r3, dpl
      0093A9 7A 00            [12] 2184 	mov	r2,#0x00
      0093AB EB               [12] 2185 	mov	a,r3
      0093AC 12 43 5A         [24] 2186 	lcall	_ak820_outline_0143
                                   2187 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      0093AF BD 00 05         [24] 2188 	cjne	r5,#0x00,00212$
      0093B2 BC 7C 02         [24] 2189 	cjne	r4,#0x7c,00212$
      0093B5 80 06            [24] 2190 	sjmp	00213$
      0093B7                       2191 00212$:
      0093B7 D0 01            [24] 2192 	pop	ar1
      0093B9 D0 00            [24] 2193 	pop	ar0
      0093BB 80 0D            [24] 2194 	sjmp	00113$
      0093BD                       2195 00213$:
      0093BD D0 01            [24] 2196 	pop	ar1
      0093BF D0 00            [24] 2197 	pop	ar0
                                   2198 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      0093C1 1E               [12] 2199 	dec	r6
      0093C2 BE FF 01         [24] 2200 	cjne	r6,#0xff,00214$
      0093C5 1F               [12] 2201 	dec	r7
      0093C6                       2202 00214$:
      0093C6 EE               [12] 2203 	mov	a,r6
      0093C7 12 98 78         [24] 2204 	lcall	_ak820_outline_0131
      0093CA                       2205 00113$:
                                   2206 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      0093CA E5 39            [12] 2207 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0093CC 14               [12] 2208 	dec	a
      0093CD 90 0B E4         [24] 2209 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      0093D0 F0               [24] 2210 	movx	@dptr,a
      0093D1                       2211 00115$:
                                   2212 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0093D1 90 0B E3         [24] 2213 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      0093D4 E0               [24] 2214 	movx	a,@dptr
      0093D5 90 0B E5         [24] 2215 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      0093D8 F0               [24] 2216 	movx	@dptr,a
      0093D9                       2217 00122$:
      0093D9 90 0B E5         [24] 2218 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      0093DC E0               [24] 2219 	movx	a,@dptr
      0093DD FF               [12] 2220 	mov	r7,a
      0093DE 90 0B E4         [24] 2221 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      0093E1 E0               [24] 2222 	movx	a,@dptr
      0093E2 FE               [12] 2223 	mov	r6,a
      0093E3 C3               [12] 2224 	clr	c
      0093E4 EF               [12] 2225 	mov	a,r7
      0093E5 9E               [12] 2226 	subb	a,r6
      0093E6 50 48            [24] 2227 	jnc	00120$
                                   2228 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      0093E8 EF               [12] 2229 	mov	a,r7
      0093E9 28               [12] 2230 	add	a, r0
      0093EA FD               [12] 2231 	mov	r5,a
      0093EB E4               [12] 2232 	clr	a
      0093EC 39               [12] 2233 	addc	a, r1
      0093ED FE               [12] 2234 	mov	r6,a
      0093EE 12 51 F6         [24] 2235 	lcall	_ak820_outline_0077
      0093F1 7B 00            [12] 2236 	mov	r3,#0x00
      0093F3 8C 36            [24] 2237 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      0093F5 8B 35            [24] 2238 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      0093F7 8F 02            [24] 2239 	mov	ar2,r7
      0093F9 7F 00            [12] 2240 	mov	r7,#0x00
      0093FB 74 01            [12] 2241 	mov	a,#0x01
      0093FD 2A               [12] 2242 	add	a, r2
      0093FE FB               [12] 2243 	mov	r3,a
      0093FF E4               [12] 2244 	clr	a
      009400 3F               [12] 2245 	addc	a, r7
      009401 FC               [12] 2246 	mov	r4,a
      009402 EB               [12] 2247 	mov	a,r3
      009403 28               [12] 2248 	add	a, r0
      009404 F5 82            [12] 2249 	mov	dpl,a
      009406 EC               [12] 2250 	mov	a,r4
      009407 39               [12] 2251 	addc	a, r1
      009408 F5 83            [12] 2252 	mov	dph,a
      00940A E0               [24] 2253 	movx	a,@dptr
      00940B FC               [12] 2254 	mov	r4,a
      00940C 7B 00            [12] 2255 	mov	r3,#0x00
      00940E E5 36            [12] 2256 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009410 42 03            [12] 2257 	orl	ar3,a
                                   2258 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      009412 BC 00 12         [24] 2259 	cjne	r4,#0x00,00123$
      009415 BB 7C 0F         [24] 2260 	cjne	r3,#0x7c,00123$
                                   2261 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      009418 12 38 94         [24] 2262 	lcall	_ak820_outline_0136
      00941B 74 FF            [12] 2263 	mov	a,#0xff
      00941D F0               [24] 2264 	movx	@dptr,a
                                   2265 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      00941E 0A               [12] 2266 	inc	r2
      00941F BA 00 01         [24] 2267 	cjne	r2,#0x00,00218$
      009422 0F               [12] 2268 	inc	r7
      009423                       2269 00218$:
      009423 EA               [12] 2270 	mov	a,r2
      009424 12 98 78         [24] 2271 	lcall	_ak820_outline_0131
      009427                       2272 00123$:
                                   2273 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      009427 90 0B E5         [24] 2274 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      00942A E0               [24] 2275 	movx	a,@dptr
      00942B 24 02            [12] 2276 	add	a,#0x02
      00942D F0               [24] 2277 	movx	@dptr,a
      00942E 80 A9            [24] 2278 	sjmp	00122$
      009430                       2279 00120$:
                                   2280 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      009430 90 0B E1         [24] 2281 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      009433 12 38 34         [24] 2282 	lcall	_ak820_outline_0054
      009436 74 40            [12] 2283 	mov	a,#0x40
      009438 12 43 54         [24] 2284 	lcall	_ak820_outline_0138
      00943B 90 05 8E         [24] 2285 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00943E 12 51 E9         [24] 2286 	lcall	_ak820_outline_0061
      009441 E4               [12] 2287 	clr	a
      009442 A3               [24] 2288 	inc	dptr
      009443 F0               [24] 2289 	movx	@dptr,a
      009444 90 05 91         [24] 2290 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      009447 E5 37            [12] 2291 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      009449 F0               [24] 2292 	movx	@dptr,a
      00944A E5 38            [12] 2293 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      00944C A3               [24] 2294 	inc	dptr
      00944D F0               [24] 2295 	movx	@dptr,a
      00944E 12 38 A9         [24] 2296 	lcall	_ak820_outline_0158
                                   2297 ;	quantum/dynamic_keymap.c:584: }
      009451 02 41 2E         [24] 2298 	ljmp	_ak820_eeprom_write_block_xdata
                                   2299 ;------------------------------------------------------------
                                   2300 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2301 ;------------------------------------------------------------
                                   2302 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2303 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2304 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_453'
                                   2305 ;------------------------------------------------------------
                                   2306 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2307 ;	-----------------------------------------
                                   2308 ;	 function keycode_at_keymap_location
                                   2309 ;	-----------------------------------------
      009454                       2310 _keycode_at_keymap_location:
      009454 E5 82            [12] 2311 	mov	a,dpl
      009456 90 0B E8         [24] 2312 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_453
      009459 F0               [24] 2313 	movx	@dptr,a
                                   2314 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      00945A E0               [24] 2315 	movx	a,@dptr
      00945B FF               [12] 2316 	mov	r7,a
      00945C BF 06 00         [24] 2317 	cjne	r7,#0x06,00128$
      00945F                       2318 00128$:
      00945F 50 23            [24] 2319 	jnc	00102$
      009461 90 0B E6         [24] 2320 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      009464 E0               [24] 2321 	movx	a,@dptr
      009465 FE               [12] 2322 	mov	r6,a
      009466 BE 10 00         [24] 2323 	cjne	r6,#0x10,00130$
      009469                       2324 00130$:
      009469 50 19            [24] 2325 	jnc	00102$
      00946B 90 0B E7         [24] 2326 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      00946E E0               [24] 2327 	movx	a,@dptr
      00946F FD               [12] 2328 	mov	r5,a
      009470 BD 08 00         [24] 2329 	cjne	r5,#0x08,00132$
      009473                       2330 00132$:
      009473 50 0F            [24] 2331 	jnc	00102$
                                   2332 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      009475 90 0B 88         [24] 2333 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      009478 EE               [12] 2334 	mov	a,r6
      009479 F0               [24] 2335 	movx	@dptr,a
      00947A 90 0B 89         [24] 2336 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00947D ED               [12] 2337 	mov	a,r5
      00947E F0               [24] 2338 	movx	@dptr,a
      00947F 8F 82            [24] 2339 	mov	dpl, r7
      009481 02 8C A5         [24] 2340 	ljmp	_dynamic_keymap_get_keycode
      009484                       2341 00102$:
                                   2342 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      009484 90 00 00         [24] 2343 	mov	dptr,#0x0000
                                   2344 ;	quantum/dynamic_keymap.c:591: }
      009487 22               [24] 2345 	ret
                                   2346 ;------------------------------------------------------------
                                   2347 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2348 ;------------------------------------------------------------
                                   2349 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2350 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2351 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_457'
                                   2352 ;------------------------------------------------------------
                                   2353 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2354 ;	-----------------------------------------
                                   2355 ;	 function keycode_at_encodermap_location
                                   2356 ;	-----------------------------------------
      009488                       2357 _keycode_at_encodermap_location:
      009488 E5 82            [12] 2358 	mov	a,dpl
      00948A 90 0B EB         [24] 2359 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_457
      00948D F0               [24] 2360 	movx	@dptr,a
                                   2361 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      00948E E0               [24] 2362 	movx	a,@dptr
      00948F FF               [12] 2363 	mov	r7,a
      009490 BF 06 00         [24] 2364 	cjne	r7,#0x06,00120$
      009493                       2365 00120$:
      009493 50 1E            [24] 2366 	jnc	00102$
      009495 90 0B E9         [24] 2367 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      009498 E0               [24] 2368 	movx	a,@dptr
      009499 FE               [12] 2369 	mov	r6,a
      00949A BE 01 00         [24] 2370 	cjne	r6,#0x01,00122$
      00949D                       2371 00122$:
      00949D 50 14            [24] 2372 	jnc	00102$
                                   2373 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      00949F 90 0B EA         [24] 2374 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0094A2 E0               [24] 2375 	movx	a,@dptr
      0094A3 FE               [12] 2376 	mov	r6,a
      0094A4 90 0B 92         [24] 2377 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0094A7 E4               [12] 2378 	clr	a
      0094A8 F0               [24] 2379 	movx	@dptr,a
      0094A9 90 0B 93         [24] 2380 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0094AC EE               [12] 2381 	mov	a,r6
      0094AD F0               [24] 2382 	movx	@dptr,a
      0094AE 8F 82            [24] 2383 	mov	dpl, r7
      0094B0 02 8D 62         [24] 2384 	ljmp	_dynamic_keymap_get_encoder
      0094B3                       2385 00102$:
                                   2386 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      0094B3 90 00 00         [24] 2387 	mov	dptr,#0x0000
                                   2388 ;	quantum/dynamic_keymap.c:599: }
      0094B6 22               [24] 2389 	ret
                                   2390 ;------------------------------------------------------------
                                   2391 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2392 ;------------------------------------------------------------
                                   2393 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2394 ;	-----------------------------------------
                                   2395 ;	 function dynamic_keymap_macro_get_count
                                   2396 ;	-----------------------------------------
      0094B7                       2397 _dynamic_keymap_macro_get_count:
                                   2398 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      0094B7 75 82 10         [24] 2399 	mov	dpl, #0x10
                                   2400 ;	quantum/dynamic_keymap.c:604: }
      0094BA 22               [24] 2401 	ret
                                   2402 ;------------------------------------------------------------
                                   2403 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2404 ;------------------------------------------------------------
                                   2405 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2406 ;	-----------------------------------------
                                   2407 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2408 ;	-----------------------------------------
      0094BB                       2409 _dynamic_keymap_macro_get_buffer_size:
                                   2410 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      0094BB 90 20 00         [24] 2411 	mov	dptr,#0x2000
                                   2412 ;	quantum/dynamic_keymap.c:608: }
      0094BE 22               [24] 2413 	ret
                                   2414 ;------------------------------------------------------------
                                   2415 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2416 ;------------------------------------------------------------
                                   2417 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2418 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2419 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2420 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_465'
                                   2421 ;------------------------------------------------------------
                                   2422 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2423 ;	-----------------------------------------
                                   2424 ;	 function dynamic_keymap_macro_get_buffer
                                   2425 ;	-----------------------------------------
      0094BF                       2426 _dynamic_keymap_macro_get_buffer:
      0094BF 12 38 75         [24] 2427 	lcall	_ak820_outline_0108
      0094C2 90 0B F1         [24] 2428 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      0094C5 12 38 7A         [24] 2429 	lcall	_ak820_outline_0109
                                   2430 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      0094C8 12 2B 2B         [24] 2431 	lcall	_ak820_macro_length
      0094CB 12 43 4F         [24] 2432 	lcall	_ak820_outline_0135
      0094CE 90 0B F1         [24] 2433 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      0094D1 12 38 4B         [24] 2434 	lcall	_ak820_outline_0062
      0094D4 90 0B EC         [24] 2435 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      0094D7 E0               [24] 2436 	movx	a,@dptr
      0094D8 F5 3A            [12] 2437 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      0094DA A3               [24] 2438 	inc	dptr
      0094DB E0               [24] 2439 	movx	a,@dptr
      0094DC F5 3B            [12] 2440 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      0094DE 90 0B EE         [24] 2441 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      0094E1 12 38 6F         [24] 2442 	lcall	_ak820_outline_0103
      0094E4 A3               [24] 2443 	inc	dptr
      0094E5 E0               [24] 2444 	movx	a,@dptr
      0094E6 FB               [12] 2445 	mov	r3,a
      0094E7 90 0B C9         [24] 2446 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0094EA 12 51 E9         [24] 2447 	lcall	_ak820_outline_0061
      0094ED 90 0B CB         [24] 2448 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0094F0 12 38 57         [24] 2449 	lcall	_ak820_outline_0079
      0094F3 90 0B CD         [24] 2450 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0094F6 E5 3A            [12] 2451 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      0094F8 F0               [24] 2452 	movx	@dptr,a
      0094F9 E5 3B            [12] 2453 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      0094FB A3               [24] 2454 	inc	dptr
      0094FC F0               [24] 2455 	movx	@dptr,a
      0094FD 90 0B CF         [24] 2456 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009500 E8               [12] 2457 	mov	a,r0
      009501 F0               [24] 2458 	movx	@dptr,a
      009502 E9               [12] 2459 	mov	a,r1
      009503 A3               [24] 2460 	inc	dptr
      009504 12 80 57         [24] 2461 	lcall	_ak820_outline_0188
      009507 90 08 00         [24] 2462 	mov	dptr,#0x0800
                                   2463 ;	quantum/dynamic_keymap.c:635: }
      00950A 21 D2            [12] 2464 	ajmp	_ak820_dynamic_read_buffer
                                   2465 ;------------------------------------------------------------
                                   2466 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2467 ;------------------------------------------------------------
                                   2468 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2469 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2470 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_467'
                                   2471 ;------------------------------------------------------------
                                   2472 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2473 ;	-----------------------------------------
                                   2474 ;	 function dynamic_keymap_macro_set_buffer
                                   2475 ;	-----------------------------------------
      00950C                       2476 _dynamic_keymap_macro_set_buffer:
      00950C 12 38 75         [24] 2477 	lcall	_ak820_outline_0108
      00950F 90 0B F8         [24] 2478 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      009512 12 38 7A         [24] 2479 	lcall	_ak820_outline_0109
                                   2480 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      009515 90 0B F8         [24] 2481 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      009518 12 38 34         [24] 2482 	lcall	_ak820_outline_0054
      00951B 90 0B F3         [24] 2483 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00951E 12 38 4B         [24] 2484 	lcall	_ak820_outline_0062
      009521 90 0B F5         [24] 2485 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009524 12 58 8B         [24] 2486 	lcall	_ak820_outline_0092
      009527 90 05 14         [24] 2487 	mov	dptr,#_ak820_macro_write_PARM_2
      00952A 12 38 57         [24] 2488 	lcall	_ak820_outline_0079
      00952D 90 05 16         [24] 2489 	mov	dptr,#_ak820_macro_write_PARM_3
      009530 12 52 18         [24] 2490 	lcall	_ak820_outline_0100
      009533 EB               [12] 2491 	mov	a,r3
      009534 A3               [24] 2492 	inc	dptr
      009535 12 43 31         [24] 2493 	lcall	_ak820_outline_0068
                                   2494 ;	quantum/dynamic_keymap.c:640: }
      009538 02 2B 45         [24] 2495 	ljmp	_ak820_macro_write
                                   2496 ;------------------------------------------------------------
                                   2497 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2498 ;------------------------------------------------------------
                                   2499 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2500 ;	-----------------------------------------
                                   2501 ;	 function dynamic_keymap_macro_reset
                                   2502 ;	-----------------------------------------
      00953B                       2503 _dynamic_keymap_macro_reset:
                                   2504 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2505 ;	quantum/dynamic_keymap.c:666: }
      00953B 02 2E 64         [24] 2506 	ljmp	_ak820_macro_reset
                                   2507 ;------------------------------------------------------------
                                   2508 ;Allocation info for local variables in function 'decode_keycode'
                                   2509 ;------------------------------------------------------------
                                   2510 ;kc            Allocated with name '_decode_keycode_kc_10000_471'
                                   2511 ;------------------------------------------------------------
                                   2512 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2513 ;	-----------------------------------------
                                   2514 ;	 function decode_keycode
                                   2515 ;	-----------------------------------------
      00953E                       2516 _decode_keycode:
      00953E 12 38 75         [24] 2517 	lcall	_ak820_outline_0108
      009541 90 0B FA         [24] 2518 	mov	dptr,#_decode_keycode_kc_10000_471
      009544 12 38 7A         [24] 2519 	lcall	_ak820_outline_0109
                                   2520 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      009547 90 0B FA         [24] 2521 	mov	dptr,#_decode_keycode_kc_10000_471
      00954A 12 51 8C         [24] 2522 	lcall	_ak820_outline_0009
      00954D C3               [12] 2523 	clr	c
      00954E E4               [12] 2524 	clr	a
      00954F 9C               [12] 2525 	subb	a,r4
      009550 74 FF            [12] 2526 	mov	a,#0xff
      009552 9D               [12] 2527 	subb	a,r5
      009553 50 08            [24] 2528 	jnc	00102$
                                   2529 ;	free result
                                   2530 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      009555 8C 05            [24] 2531 	mov	ar5,r4
      009557 7C 00            [12] 2532 	mov	r4,#0x00
      009559 12 38 8A         [24] 2533 	lcall	_ak820_outline_0126
      00955C 22               [24] 2534 	ret
      00955D                       2535 00102$:
                                   2536 ;	quantum/dynamic_keymap.c:672: return kc;
      00955D 12 38 7F         [24] 2537 	lcall	_ak820_outline_0120
                                   2538 ;	quantum/dynamic_keymap.c:673: }
      009560 22               [24] 2539 	ret
                                   2540 ;------------------------------------------------------------
                                   2541 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2542 ;------------------------------------------------------------
                                   2543 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_474'
                                   2544 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_475'
                                   2545 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_480'
                                   2546 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_481'
                                   2547 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_487'
                                   2548 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_505'
                                   2549 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_509'
                                   2550 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_509'
                                   2551 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_511'
                                   2552 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_513'
                                   2553 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_517'
                                   2554 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_519'
                                   2555 ;------------------------------------------------------------
                                   2556 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2557 ;	-----------------------------------------
                                   2558 ;	 function dynamic_keymap_macro_send
                                   2559 ;	-----------------------------------------
      009561                       2560 _dynamic_keymap_macro_send:
      009561 E5 82            [12] 2561 	mov	a,dpl
      009563 90 0B FC         [24] 2562 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      009566 F0               [24] 2563 	movx	@dptr,a
                                   2564 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      009567 90 0B FD         [24] 2565 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      00956A E0               [24] 2566 	movx	a,@dptr
      00956B 60 01            [24] 2567 	jz	00102$
      00956D 22               [24] 2568 	ret
      00956E                       2569 00102$:
                                   2570 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      00956E 90 0B FC         [24] 2571 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      009571 E0               [24] 2572 	movx	a,@dptr
      009572 FF               [12] 2573 	mov	r7,a
      009573 BF 10 00         [24] 2574 	cjne	r7,#0x10,00422$
      009576                       2575 00422$:
      009576 40 01            [24] 2576 	jc	00104$
                                   2577 ;	quantum/dynamic_keymap.c:683: return;
      009578 22               [24] 2578 	ret
      009579                       2579 00104$:
                                   2580 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      009579 C0 07            [24] 2581 	push	ar7
      00957B 12 2A F2         [24] 2582 	lcall	_ak820_macro_ready
      00957E E5 82            [12] 2583 	mov	a, dpl
      009580 D0 07            [24] 2584 	pop	ar7
      009582 70 01            [24] 2585 	jnz	00106$
      009584 22               [24] 2586 	ret
      009585                       2587 00106$:
                                   2588 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      009585 90 0B FE         [24] 2589 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009588 E4               [12] 2590 	clr	a
      009589 F0               [24] 2591 	movx	@dptr,a
      00958A 74 08            [12] 2592 	mov	a,#0x08
      00958C A3               [24] 2593 	inc	dptr
      00958D F0               [24] 2594 	movx	@dptr,a
                                   2595 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      00958E C0 07            [24] 2596 	push	ar7
      009590 12 2B 2B         [24] 2597 	lcall	_ak820_macro_length
      009593 AD 82            [24] 2598 	mov	r5, dpl
      009595 AE 83            [24] 2599 	mov	r6, dph
      009597 D0 07            [24] 2600 	pop	ar7
      009599 74 08            [12] 2601 	mov	a,#0x08
      00959B 2E               [12] 2602 	add	a, r6
      00959C FE               [12] 2603 	mov	r6,a
                                   2604 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      00959D 7B 00            [12] 2605 	mov	r3,#0x00
      00959F 7C 08            [12] 2606 	mov	r4,#0x08
      0095A1                       2607 00111$:
      0095A1 EF               [12] 2608 	mov	a,r7
      0095A2 60 31            [24] 2609 	jz	00113$
                                   2610 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      0095A4 EB               [12] 2611 	mov	a,r3
      0095A5 B5 05 05         [24] 2612 	cjne	a,ar5,00108$
      0095A8 EC               [12] 2613 	mov	a,r4
      0095A9 B5 06 01         [24] 2614 	cjne	a,ar6,00108$
                                   2615 ;	quantum/dynamic_keymap.c:717: return;
      0095AC 22               [24] 2616 	ret
      0095AD                       2617 00108$:
                                   2618 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      0095AD 8B 01            [24] 2619 	mov	ar1,r3
      0095AF 8C 02            [24] 2620 	mov	ar2,r4
      0095B1 8A 00            [24] 2621 	mov	ar0,r2
      0095B3 7A 00            [12] 2622 	mov	r2,#0x00
      0095B5 89 82            [24] 2623 	mov	dpl, r1
      0095B7 88 83            [24] 2624 	mov	dph, r0
      0095B9 8A F0            [24] 2625 	mov	b, r2
      0095BB 12 40 67         [24] 2626 	lcall	_eeprom_read_byte
      0095BE E5 82            [12] 2627 	mov	a, dpl
      0095C0 70 06            [24] 2628 	jnz	00110$
                                   2629 ;	quantum/dynamic_keymap.c:720: --id;
      0095C2 1F               [12] 2630 	dec	r7
      0095C3 90 0B FC         [24] 2631 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      0095C6 EF               [12] 2632 	mov	a,r7
      0095C7 F0               [24] 2633 	movx	@dptr,a
      0095C8                       2634 00110$:
                                   2635 ;	quantum/dynamic_keymap.c:722: ++p;
      0095C8 0B               [12] 2636 	inc	r3
      0095C9 BB 00 01         [24] 2637 	cjne	r3,#0x00,00429$
      0095CC 0C               [12] 2638 	inc	r4
      0095CD                       2639 00429$:
      0095CD 90 0B FE         [24] 2640 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0095D0 12 38 63         [24] 2641 	lcall	_ak820_outline_0086
      0095D3 80 CC            [24] 2642 	sjmp	00111$
      0095D5                       2643 00113$:
                                   2644 ;	quantum/dynamic_keymap.c:728: sending = true;
      0095D5 90 0B FD         [24] 2645 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      0095D8 74 01            [12] 2646 	mov	a,#0x01
      0095DA F0               [24] 2647 	movx	@dptr,a
                                   2648 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      0095DB 12 98 90         [24] 2649 	lcall	_ak820_outline_0166
      0095DE 90 0A 34         [24] 2650 	mov	dptr,#_ak820_macro_cancelled
      0095E1 F0               [24] 2651 	movx	@dptr,a
                                   2652 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      0095E2 90 0C 00         [24] 2653 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      0095E5 F0               [24] 2654 	movx	@dptr,a
      0095E6 90 0C 01         [24] 2655 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      0095E9 F0               [24] 2656 	movx	@dptr,a
      0095EA 90 0C 02         [24] 2657 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      0095ED F0               [24] 2658 	movx	@dptr,a
      0095EE 90 0C 03         [24] 2659 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      0095F1 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	quantum/dynamic_keymap.c:738: while (p < end
      0095F2                       2662 00167$:
                                   2663 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      0095F2 90 0B FE         [24] 2664 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0095F5 E0               [24] 2665 	movx	a,@dptr
      0095F6 FC               [12] 2666 	mov	r4,a
      0095F7 A3               [24] 2667 	inc	dptr
      0095F8 E0               [24] 2668 	movx	a,@dptr
      0095F9 FF               [12] 2669 	mov	r7,a
      0095FA C3               [12] 2670 	clr	c
      0095FB EC               [12] 2671 	mov	a,r4
      0095FC 9D               [12] 2672 	subb	a,r5
      0095FD EF               [12] 2673 	mov	a,r7
      0095FE 9E               [12] 2674 	subb	a,r6
      0095FF 40 03            [24] 2675 	jc	00430$
      009601 02 98 10         [24] 2676 	ljmp	00169$
      009604                       2677 00430$:
      009604 90 0A 34         [24] 2678 	mov	dptr,#_ak820_macro_cancelled
      009607 E0               [24] 2679 	movx	a,@dptr
      009608 60 03            [24] 2680 	jz	00431$
      00960A 02 98 10         [24] 2681 	ljmp	00169$
      00960D                       2682 00431$:
                                   2683 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00960D 8C 02            [24] 2684 	mov	ar2,r4
      00960F 8F 03            [24] 2685 	mov	ar3,r7
      009611 90 0B FE         [24] 2686 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009614 74 01            [12] 2687 	mov	a,#0x01
      009616 2C               [12] 2688 	add	a, r4
      009617 F0               [24] 2689 	movx	@dptr,a
      009618 E4               [12] 2690 	clr	a
      009619 3F               [12] 2691 	addc	a, r7
      00961A A3               [24] 2692 	inc	dptr
      00961B F0               [24] 2693 	movx	@dptr,a
      00961C 7F 00            [12] 2694 	mov	r7,#0x00
      00961E 12 38 9F         [24] 2695 	lcall	_ak820_outline_0144
      009621 8F F0            [24] 2696 	mov	b, r7
      009623 12 40 67         [24] 2697 	lcall	_eeprom_read_byte
      009626 AF 82            [24] 2698 	mov	r7, dpl
      009628 90 0C 00         [24] 2699 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      00962B EF               [12] 2700 	mov	a,r7
      00962C F0               [24] 2701 	movx	@dptr,a
                                   2702 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      00962D 90 0C 01         [24] 2703 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009630 E4               [12] 2704 	clr	a
      009631 F0               [24] 2705 	movx	@dptr,a
                                   2706 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      009632 90 0C 00         [24] 2707 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009635 E0               [24] 2708 	movx	a,@dptr
      009636 70 03            [24] 2709 	jnz	00432$
      009638 02 98 10         [24] 2710 	ljmp	00169$
      00963B                       2711 00432$:
                                   2712 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      00963B 90 0C 00         [24] 2713 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      00963E E0               [24] 2714 	movx	a,@dptr
      00963F FF               [12] 2715 	mov	r7,a
      009640 BF 01 02         [24] 2716 	cjne	r7,#0x01,00433$
      009643 80 03            [24] 2717 	sjmp	00434$
      009645                       2718 00433$:
      009645 02 97 F2         [24] 2719 	ljmp	00164$
      009648                       2720 00434$:
                                   2721 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009648 12 98 18         [24] 2722 	lcall	_ak820_outline_0000
      00964B 12 40 67         [24] 2723 	lcall	_eeprom_read_byte
      00964E AF 82            [24] 2724 	mov	r7, dpl
      009650 90 0C 01         [24] 2725 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009653 EF               [12] 2726 	mov	a,r7
      009654 F0               [24] 2727 	movx	@dptr,a
                                   2728 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      009655 EF               [12] 2729 	mov	a,r7
      009656 70 03            [24] 2730 	jnz	00435$
      009658 02 98 10         [24] 2731 	ljmp	00169$
      00965B                       2732 00435$:
                                   2733 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      00965B 12 98 57         [24] 2734 	lcall	_ak820_outline_0094
      00965E BF 01 02         [24] 2735 	cjne	r7,#0x01,00436$
      009661 80 12            [24] 2736 	sjmp	00151$
      009663                       2737 00436$:
      009663 12 98 57         [24] 2738 	lcall	_ak820_outline_0094
      009666 BF 02 02         [24] 2739 	cjne	r7,#0x02,00437$
      009669 80 0A            [24] 2740 	sjmp	00151$
      00966B                       2741 00437$:
      00966B 12 98 57         [24] 2742 	lcall	_ak820_outline_0094
      00966E BF 03 02         [24] 2743 	cjne	r7,#0x03,00438$
      009671 80 02            [24] 2744 	sjmp	00439$
      009673                       2745 00438$:
      009673 C1 D4            [12] 2746 	ajmp	00152$
      009675                       2747 00439$:
      009675                       2748 00151$:
                                   2749 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009675 12 98 18         [24] 2750 	lcall	_ak820_outline_0000
      009678 12 40 67         [24] 2751 	lcall	_eeprom_read_byte
      00967B 12 98 A8         [24] 2752 	lcall	_ak820_outline_0183
                                   2753 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      00967E 70 02            [24] 2754 	jnz	00440$
      009680 A1 F2            [12] 2755 	ajmp	00167$
      009682                       2756 00440$:
                                   2757 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      009682 12 98 57         [24] 2758 	lcall	_ak820_outline_0094
      009685 BF 01 03         [24] 2759 	cjne	r7,#0x01,00441$
      009688 D3               [12] 2760 	setb	c
      009689 80 01            [24] 2761 	sjmp	00442$
      00968B                       2762 00441$:
      00968B C3               [12] 2763 	clr	c
      00968C                       2764 00442$:
      00968C 92 27            [24] 2765 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00968E 90 0A 33         [24] 2766 	mov	dptr,#_ak820_macro_primitive
      009691 B3               [12] 2767 	cpl	c
      009692 E4               [12] 2768 	clr	a
      009693 33               [12] 2769 	rlc	a
      009694 F0               [24] 2770 	movx	@dptr,a
                                   2771 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      009695 12 98 57         [24] 2772 	lcall	_ak820_outline_0094
      009698 BF 01 10         [24] 2773 	cjne	r7,#0x01,00122$
      00969B 12 98 89         [24] 2774 	lcall	_ak820_outline_0152
      00969E C0 06            [24] 2775 	push	ar6
      0096A0 C0 05            [24] 2776 	push	ar5
      0096A2 12 7F 21         [24] 2777 	lcall	_tap_code
      0096A5 D0 05            [24] 2778 	pop	ar5
      0096A7 D0 06            [24] 2779 	pop	ar6
      0096A9 80 24            [24] 2780 	sjmp	00123$
      0096AB                       2781 00122$:
                                   2782 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0096AB 12 98 57         [24] 2783 	lcall	_ak820_outline_0094
      0096AE BF 02 10         [24] 2784 	cjne	r7,#0x02,00119$
      0096B1 12 98 89         [24] 2785 	lcall	_ak820_outline_0152
      0096B4 C0 06            [24] 2786 	push	ar6
      0096B6 C0 05            [24] 2787 	push	ar5
      0096B8 12 7E 1D         [24] 2788 	lcall	_register_code
      0096BB D0 05            [24] 2789 	pop	ar5
      0096BD D0 06            [24] 2790 	pop	ar6
      0096BF 80 0E            [24] 2791 	sjmp	00123$
      0096C1                       2792 00119$:
                                   2793 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      0096C1 12 98 89         [24] 2794 	lcall	_ak820_outline_0152
      0096C4 C0 06            [24] 2795 	push	ar6
      0096C6 C0 05            [24] 2796 	push	ar5
      0096C8 12 7E 8A         [24] 2797 	lcall	_unregister_code
      0096CB D0 05            [24] 2798 	pop	ar5
      0096CD D0 06            [24] 2799 	pop	ar6
      0096CF                       2800 00123$:
                                   2801 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      0096CF 12 98 90         [24] 2802 	lcall	_ak820_outline_0166
      0096D2 A1 F2            [12] 2803 	ajmp	00167$
      0096D4                       2804 00152$:
                                   2805 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0096D4 12 98 57         [24] 2806 	lcall	_ak820_outline_0094
      0096D7 BF 05 02         [24] 2807 	cjne	r7,#0x05,00447$
      0096DA 80 13            [24] 2808 	sjmp	00146$
      0096DC                       2809 00447$:
      0096DC 12 98 57         [24] 2810 	lcall	_ak820_outline_0094
      0096DF BF 06 02         [24] 2811 	cjne	r7,#0x06,00448$
      0096E2 80 0B            [24] 2812 	sjmp	00146$
      0096E4                       2813 00448$:
      0096E4 12 98 57         [24] 2814 	lcall	_ak820_outline_0094
      0096E7 BF 07 02         [24] 2815 	cjne	r7,#0x07,00449$
      0096EA 80 03            [24] 2816 	sjmp	00450$
      0096EC                       2817 00449$:
      0096EC 02 97 92         [24] 2818 	ljmp	00147$
      0096EF                       2819 00450$:
      0096EF                       2820 00146$:
                                   2821 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0096EF 12 98 18         [24] 2822 	lcall	_ak820_outline_0000
      0096F2 12 40 67         [24] 2823 	lcall	_eeprom_read_byte
      0096F5 12 98 A8         [24] 2824 	lcall	_ak820_outline_0183
                                   2825 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      0096F8 70 02            [24] 2826 	jnz	00451$
      0096FA A1 F2            [12] 2827 	ajmp	00167$
      0096FC                       2828 00451$:
                                   2829 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0096FC 12 98 18         [24] 2830 	lcall	_ak820_outline_0000
      0096FF 12 40 67         [24] 2831 	lcall	_eeprom_read_byte
      009702 AF 82            [24] 2832 	mov	r7, dpl
      009704 90 0C 03         [24] 2833 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      009707 EF               [12] 2834 	mov	a,r7
      009708 F0               [24] 2835 	movx	@dptr,a
                                   2836 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      009709 EF               [12] 2837 	mov	a,r7
      00970A 70 02            [24] 2838 	jnz	00452$
      00970C A1 F2            [12] 2839 	ajmp	00167$
      00970E                       2840 00452$:
                                   2841 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      00970E 90 0C 02         [24] 2842 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      009711 E0               [24] 2843 	movx	a,@dptr
      009712 FF               [12] 2844 	mov	r7,a
      009713 90 0C 03         [24] 2845 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      009716 E0               [24] 2846 	movx	a,@dptr
      009717 FB               [12] 2847 	mov	r3,a
      009718 E4               [12] 2848 	clr	a
      009719 FC               [12] 2849 	mov	r4,a
      00971A FA               [12] 2850 	mov	r2,a
      00971B EF               [12] 2851 	mov	a,r7
      00971C 42 04            [12] 2852 	orl	ar4,a
      00971E EA               [12] 2853 	mov	a,r2
      00971F 42 03            [12] 2854 	orl	ar3,a
                                   2855 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      009721 12 43 7B         [24] 2856 	lcall	_ak820_outline_0184
      009724 C0 06            [24] 2857 	push	ar6
      009726 C0 05            [24] 2858 	push	ar5
      009728 B1 3E            [12] 2859 	acall	_decode_keycode
      00972A AC 82            [24] 2860 	mov	r4, dpl
      00972C AF 83            [24] 2861 	mov	r7, dph
      00972E D0 05            [24] 2862 	pop	ar5
      009730 D0 06            [24] 2863 	pop	ar6
                                   2864 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      009732 90 0C 01         [24] 2865 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009735 E0               [24] 2866 	movx	a,@dptr
      009736 FB               [12] 2867 	mov	r3,a
      009737 BB 05 03         [24] 2868 	cjne	r3,#0x05,00453$
      00973A D3               [12] 2869 	setb	c
      00973B 80 01            [24] 2870 	sjmp	00454$
      00973D                       2871 00453$:
      00973D C3               [12] 2872 	clr	c
      00973E                       2873 00454$:
      00973E 92 27            [24] 2874 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009740 90 0A 33         [24] 2875 	mov	dptr,#_ak820_macro_primitive
      009743 B3               [12] 2876 	cpl	c
      009744 E4               [12] 2877 	clr	a
      009745 33               [12] 2878 	rlc	a
      009746 F0               [24] 2879 	movx	@dptr,a
                                   2880 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      009747 90 0C 01         [24] 2881 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      00974A E0               [24] 2882 	movx	a,@dptr
      00974B FB               [12] 2883 	mov	r3,a
      00974C BB 05 02         [24] 2884 	cjne	r3,#0x05,00455$
      00974F 80 0A            [24] 2885 	sjmp	00126$
      009751                       2886 00455$:
      009751 BB 06 02         [24] 2887 	cjne	r3,#0x06,00456$
      009754 80 16            [24] 2888 	sjmp	00127$
      009756                       2889 00456$:
                                   2890 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      009756 BB 07 33         [24] 2891 	cjne	r3,#0x07,00129$
      009759 80 22            [24] 2892 	sjmp	00128$
      00975B                       2893 00126$:
                                   2894 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      00975B 8C 82            [24] 2895 	mov	dpl, r4
      00975D 8F 83            [24] 2896 	mov	dph, r7
      00975F C0 06            [24] 2897 	push	ar6
      009761 C0 05            [24] 2898 	push	ar5
      009763 12 BC 9F         [24] 2899 	lcall	_vial_keycode_tap
      009766 D0 05            [24] 2900 	pop	ar5
      009768 D0 06            [24] 2901 	pop	ar6
                                   2902 ;	quantum/dynamic_keymap.c:795: break;
                                   2903 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      00976A 80 20            [24] 2904 	sjmp	00129$
      00976C                       2905 00127$:
                                   2906 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      00976C 8C 82            [24] 2907 	mov	dpl, r4
      00976E 8F 83            [24] 2908 	mov	dph, r7
      009770 C0 06            [24] 2909 	push	ar6
      009772 C0 05            [24] 2910 	push	ar5
      009774 12 BB D4         [24] 2911 	lcall	_vial_keycode_down
      009777 D0 05            [24] 2912 	pop	ar5
      009779 D0 06            [24] 2913 	pop	ar6
                                   2914 ;	quantum/dynamic_keymap.c:798: break;
                                   2915 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      00977B 80 0F            [24] 2916 	sjmp	00129$
      00977D                       2917 00128$:
                                   2918 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      00977D 8C 82            [24] 2919 	mov	dpl, r4
      00977F 8F 83            [24] 2920 	mov	dph, r7
      009781 C0 06            [24] 2921 	push	ar6
      009783 C0 05            [24] 2922 	push	ar5
      009785 12 BC 3A         [24] 2923 	lcall	_vial_keycode_up
      009788 D0 05            [24] 2924 	pop	ar5
      00978A D0 06            [24] 2925 	pop	ar6
                                   2926 ;	quantum/dynamic_keymap.c:802: }
      00978C                       2927 00129$:
                                   2928 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      00978C 12 98 90         [24] 2929 	lcall	_ak820_outline_0166
      00978F 02 95 F2         [24] 2930 	ljmp	00167$
      009792                       2931 00147$:
                                   2932 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      009792 12 98 57         [24] 2933 	lcall	_ak820_outline_0094
      009795 BF 04 02         [24] 2934 	cjne	r7,#0x04,00458$
      009798 80 03            [24] 2935 	sjmp	00459$
      00979A                       2936 00458$:
      00979A 02 95 F2         [24] 2937 	ljmp	00167$
      00979D                       2938 00459$:
                                   2939 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00979D 12 98 18         [24] 2940 	lcall	_ak820_outline_0000
      0097A0 12 40 67         [24] 2941 	lcall	_eeprom_read_byte
      0097A3 AF 82            [24] 2942 	mov	r7, dpl
                                   2943 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0097A5 90 0B FE         [24] 2944 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0097A8 12 38 84         [24] 2945 	lcall	_ak820_outline_0125
      0097AB 90 0B FE         [24] 2946 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0097AE 74 01            [12] 2947 	mov	a,#0x01
      0097B0 2B               [12] 2948 	add	a, r3
      0097B1 F0               [24] 2949 	movx	@dptr,a
      0097B2 E4               [12] 2950 	clr	a
      0097B3 3C               [12] 2951 	addc	a, r4
      0097B4 A3               [24] 2952 	inc	dptr
      0097B5 F0               [24] 2953 	movx	@dptr,a
      0097B6 7A 00            [12] 2954 	mov	r2,#0x00
      0097B8 12 33 FC         [24] 2955 	lcall	_ak820_outline_0123
      0097BB 8A F0            [24] 2956 	mov	b, r2
      0097BD 12 40 67         [24] 2957 	lcall	_eeprom_read_byte
      0097C0 AC 82            [24] 2958 	mov	r4, dpl
                                   2959 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      0097C2 EF               [12] 2960 	mov	a,r7
      0097C3 60 4B            [24] 2961 	jz	00169$
      0097C5 EC               [12] 2962 	mov	a,r4
      0097C6 60 48            [24] 2963 	jz	00169$
                                   2964 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0097C8 1F               [12] 2965 	dec	r7
      0097C9 1C               [12] 2966 	dec	r4
      0097CA EC               [12] 2967 	mov	a,r4
      0097CB 75 F0 FF         [24] 2968 	mov	b,#0xff
      0097CE A4               [48] 2969 	mul	ab
      0097CF FC               [12] 2970 	mov	r4,a
      0097D0 AB F0            [24] 2971 	mov	r3,b
      0097D2 7A 00            [12] 2972 	mov	r2,#0x00
      0097D4 EC               [12] 2973 	mov	a,r4
      0097D5 2F               [12] 2974 	add	a, r7
      0097D6 FC               [12] 2975 	mov	r4,a
      0097D7 EB               [12] 2976 	mov	a,r3
      0097D8 3A               [12] 2977 	addc	a, r2
      0097D9 FB               [12] 2978 	mov	r3,a
                                   2979 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      0097DA                       2980 00141$:
      0097DA 8C 02            [24] 2981 	mov	ar2,r4
      0097DC 8B 07            [24] 2982 	mov	ar7,r3
      0097DE 1C               [12] 2983 	dec	r4
      0097DF BC FF 01         [24] 2984 	cjne	r4,#0xff,00462$
      0097E2 1B               [12] 2985 	dec	r3
      0097E3                       2986 00462$:
      0097E3 EA               [12] 2987 	mov	a,r2
      0097E4 4F               [12] 2988 	orl	a,r7
      0097E5 70 03            [24] 2989 	jnz	00463$
      0097E7 02 95 F2         [24] 2990 	ljmp	00167$
      0097EA                       2991 00463$:
      0097EA 90 00 01         [24] 2992 	mov	dptr,#0x0001
      0097ED 12 62 04         [24] 2993 	lcall	_mDelaymS
      0097F0 80 E8            [24] 2994 	sjmp	00141$
      0097F2                       2995 00164$:
                                   2996 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      0097F2 90 0C 00         [24] 2997 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      0097F5 E0               [24] 2998 	movx	a,@dptr
      0097F6 FF               [12] 2999 	mov	r7,a
      0097F7 BF 80 00         [24] 3000 	cjne	r7,#0x80,00464$
      0097FA                       3001 00464$:
      0097FA 50 14            [24] 3002 	jnc	00169$
                                   3003 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      0097FC 90 0C 00         [24] 3004 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      0097FF E0               [24] 3005 	movx	a,@dptr
      009800 F5 82            [12] 3006 	mov	dpl,a
      009802 C0 06            [24] 3007 	push	ar6
      009804 C0 05            [24] 3008 	push	ar5
      009806 12 AE 87         [24] 3009 	lcall	_send_char
      009809 D0 05            [24] 3010 	pop	ar5
      00980B D0 06            [24] 3011 	pop	ar6
                                   3012 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      00980D 02 95 F2         [24] 3013 	ljmp	00167$
      009810                       3014 00169$:
                                   3015 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      009810 12 98 90         [24] 3016 	lcall	_ak820_outline_0166
                                   3017 ;	quantum/dynamic_keymap.c:837: sending = false;
      009813 90 0B FD         [24] 3018 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      009816 F0               [24] 3019 	movx	@dptr,a
                                   3020 ;	quantum/dynamic_keymap.c:839: }
      009817 22               [24] 3021 	ret
                                   3022 	.area CSEG    (CODE)
                                   3023 	.area CONST   (CODE)
                                   3024 	.area XINIT   (CODE)
                                   3025 	.area CABS    (ABS,CODE)
                                   3026 
                                   3027 ; Experimental exact instruction outlining.
                                   3028 	.globl _ak820_outline_0000
                                   3029 	.globl _ak820_outline_0005
                                   3030 	.globl _ak820_outline_0009
                                   3031 	.globl _ak820_outline_0014
                                   3032 	.globl _ak820_outline_0023
                                   3033 	.globl _ak820_outline_0034
                                   3034 	.globl _ak820_outline_0035
                                   3035 	.globl _ak820_outline_0042
                                   3036 	.globl _ak820_outline_0054
                                   3037 	.globl _ak820_outline_0060
                                   3038 	.globl _ak820_outline_0061
                                   3039 	.globl _ak820_outline_0062
                                   3040 	.globl _ak820_outline_0068
                                   3041 	.globl _ak820_outline_0074
                                   3042 	.globl _ak820_outline_0077
                                   3043 	.globl _ak820_outline_0079
                                   3044 	.globl _ak820_outline_0082
                                   3045 	.globl _ak820_outline_0086
                                   3046 	.globl _ak820_outline_0092
                                   3047 	.globl _ak820_outline_0094
                                   3048 	.globl _ak820_outline_0099
                                   3049 	.globl _ak820_outline_0100
                                   3050 	.globl _ak820_outline_0102
                                   3051 	.globl _ak820_outline_0103
                                   3052 	.globl _ak820_outline_0104
                                   3053 	.globl _ak820_outline_0108
                                   3054 	.globl _ak820_outline_0109
                                   3055 	.globl _ak820_outline_0112
                                   3056 	.globl _ak820_outline_0114
                                   3057 	.globl _ak820_outline_0118
                                   3058 	.globl _ak820_outline_0120
                                   3059 	.globl _ak820_outline_0123
                                   3060 	.globl _ak820_outline_0125
                                   3061 	.globl _ak820_outline_0126
                                   3062 	.globl _ak820_outline_0127
                                   3063 	.globl _ak820_outline_0131
                                   3064 	.globl _ak820_outline_0135
                                   3065 	.globl _ak820_outline_0136
                                   3066 	.globl _ak820_outline_0137
                                   3067 	.globl _ak820_outline_0138
                                   3068 	.globl _ak820_outline_0143
                                   3069 	.globl _ak820_outline_0144
                                   3070 	.globl _ak820_outline_0150
                                   3071 	.globl _ak820_outline_0152
                                   3072 	.globl _ak820_outline_0156
                                   3073 	.globl _ak820_outline_0158
                                   3074 	.globl _ak820_outline_0161
                                   3075 	.globl _ak820_outline_0166
                                   3076 	.globl _ak820_outline_0171
                                   3077 	.globl _ak820_outline_0179
                                   3078 	.globl _ak820_outline_0180
                                   3079 	.globl _ak820_outline_0183
                                   3080 	.globl _ak820_outline_0184
                                   3081 	.globl _ak820_outline_0188
                                   3082 
                                   3083 	.area CSEG (CODE)
                                   3084 ; function ak820_outline_0000
      009818                       3085 _ak820_outline_0000:
      009818 90 0B FE         [24] 3086 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00981B E0               [24] 3087 	movx	a,@dptr
      00981C FC               [12] 3088 	mov	r4,a
      00981D A3               [24] 3089 	inc	dptr
      00981E E0               [24] 3090 	movx	a,@dptr
      00981F FF               [12] 3091 	mov	r7,a
      009820 90 0B FE         [24] 3092 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009823 74 01            [12] 3093 	mov	a,#0x01
      009825 2C               [12] 3094 	add	a,r4
      009826 F0               [24] 3095 	movx	@dptr,a
      009827 E4               [12] 3096 	clr	a
      009828 3F               [12] 3097 	addc	a,r7
      009829 A3               [24] 3098 	inc	dptr
      00982A F0               [24] 3099 	movx	@dptr,a
      00982B 7B 00            [12] 3100 	mov	r3,#0x00
      00982D 8C 82            [24] 3101 	mov	dpl,r4
      00982F 8F 83            [24] 3102 	mov	dph,r7
      009831 8B F0            [24] 3103 	mov	b,r3
      009833 22               [24] 3104 	ret
                                   3105 
                                   3106 	.area CSEG (CODE)
                                   3107 ; function ak820_outline_0042
      009834                       3108 _ak820_outline_0042:
      009834 90 0E 7B         [24] 3109 	mov	dptr,#_memset_PARM_2
      009837 E4               [12] 3110 	clr	a
      009838 F0               [24] 3111 	movx	@dptr,a
      009839 90 0E 7C         [24] 3112 	mov	dptr,#_memset_PARM_3
      00983C 74 0A            [12] 3113 	mov	a,#0x0a
      00983E F0               [24] 3114 	movx	@dptr,a
      00983F E4               [12] 3115 	clr	a
      009840 A3               [24] 3116 	inc	dptr
      009841 F0               [24] 3117 	movx	@dptr,a
      009842 8E 82            [24] 3118 	mov	dpl,r6
      009844 8F 83            [24] 3119 	mov	dph,r7
      009846 8D F0            [24] 3120 	mov	b,r5
      009848 22               [24] 3121 	ret
                                   3122 
                                   3123 	.area CSEG (CODE)
                                   3124 ; function ak820_outline_0082
      009849                       3125 _ak820_outline_0082:
      009849 ED               [12] 3126 	mov	a,r5
      00984A 75 F0 0A         [24] 3127 	mov	b,#0x0a
      00984D A4               [48] 3128 	mul	ab
      00984E 24 58            [12] 3129 	add	a,#0x58
      009850 FC               [12] 3130 	mov	r4,a
      009851 74 06            [12] 3131 	mov	a,#0x06
      009853 35 F0            [12] 3132 	addc	a,b
      009855 FD               [12] 3133 	mov	r5,a
      009856 22               [24] 3134 	ret
                                   3135 
                                   3136 	.area CSEG (CODE)
                                   3137 ; function ak820_outline_0094
      009857                       3138 _ak820_outline_0094:
      009857 90 0C 01         [24] 3139 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0001)
      00985A E0               [24] 3140 	movx	a,@dptr
      00985B FF               [12] 3141 	mov	r7,a
      00985C 22               [24] 3142 	ret
                                   3143 
                                   3144 	.area CSEG (CODE)
                                   3145 ; function ak820_outline_0099
      00985D                       3146 _ak820_outline_0099:
      00985D 90 0B 85         [24] 3147 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      009860 EE               [12] 3148 	mov	a,r6
      009861 F0               [24] 3149 	movx	@dptr,a
      009862 90 0B 86         [24] 3150 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009865 ED               [12] 3151 	mov	a,r5
      009866 F0               [24] 3152 	movx	@dptr,a
      009867 8F 82            [24] 3153 	mov	dpl,r7
      009869 22               [24] 3154 	ret
                                   3155 
                                   3156 	.area CSEG (CODE)
                                   3157 ; function ak820_outline_0112
      00986A                       3158 _ak820_outline_0112:
      00986A 74 0A            [12] 3159 	mov	a,#0x0a
      00986C F0               [24] 3160 	movx	@dptr,a
      00986D E4               [12] 3161 	clr	a
      00986E A3               [24] 3162 	inc	dptr
      00986F F0               [24] 3163 	movx	@dptr,a
      009870 22               [24] 3164 	ret
                                   3165 
                                   3166 	.area CSEG (CODE)
                                   3167 ; function ak820_outline_0118
      009871                       3168 _ak820_outline_0118:
      009871 AD 82            [24] 3169 	mov	r5,dpl
      009873 AE 83            [24] 3170 	mov	r6,dph
      009875 AF F0            [24] 3171 	mov	r7,b
      009877 22               [24] 3172 	ret
                                   3173 
                                   3174 	.area CSEG (CODE)
                                   3175 ; function ak820_outline_0131
      009878                       3176 _ak820_outline_0131:
      009878 28               [12] 3177 	add	a,r0
      009879 F5 82            [12] 3178 	mov	dpl,a
      00987B EF               [12] 3179 	mov	a,r7
      00987C 39               [12] 3180 	addc	a,r1
      00987D F5 83            [12] 3181 	mov	dph,a
      00987F 74 FF            [12] 3182 	mov	a,#0xff
      009881 F0               [24] 3183 	movx	@dptr,a
      009882 22               [24] 3184 	ret
                                   3185 
                                   3186 	.area CSEG (CODE)
                                   3187 ; function ak820_outline_0137
      009883                       3188 _ak820_outline_0137:
      009883 2D               [12] 3189 	add	a,r5
      009884 F9               [12] 3190 	mov	r1,a
      009885 E4               [12] 3191 	clr	a
      009886 3E               [12] 3192 	addc	a,r6
      009887 FA               [12] 3193 	mov	r2,a
      009888 22               [24] 3194 	ret
                                   3195 
                                   3196 	.area CSEG (CODE)
                                   3197 ; function ak820_outline_0152
      009889                       3198 _ak820_outline_0152:
      009889 90 0C 02         [24] 3199 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      00988C E0               [24] 3200 	movx	a,@dptr
      00988D F5 82            [12] 3201 	mov	dpl,a
      00988F 22               [24] 3202 	ret
                                   3203 
                                   3204 	.area CSEG (CODE)
                                   3205 ; function ak820_outline_0166
      009890                       3206 _ak820_outline_0166:
      009890 90 0A 33         [24] 3207 	mov	dptr,#_ak820_macro_primitive
      009893 E4               [12] 3208 	clr	a
      009894 F0               [24] 3209 	movx	@dptr,a
      009895 22               [24] 3210 	ret
                                   3211 
                                   3212 	.area CSEG (CODE)
                                   3213 ; function ak820_outline_0179
      009896                       3214 _ak820_outline_0179:
      009896 90 0B 95         [24] 3215 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009899 E4               [12] 3216 	clr	a
      00989A F0               [24] 3217 	movx	@dptr,a
      00989B 90 0B 96         [24] 3218 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00989E 22               [24] 3219 	ret
                                   3220 
                                   3221 	.area CSEG (CODE)
                                   3222 ; function ak820_outline_0180
      00989F                       3223 _ak820_outline_0180:
      00989F 90 0C 5D         [24] 3224 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0098A2 E4               [12] 3225 	clr	a
      0098A3 F0               [24] 3226 	movx	@dptr,a
      0098A4 90 0C 5E         [24] 3227 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0098A7 22               [24] 3228 	ret
                                   3229 
                                   3230 	.area CSEG (CODE)
                                   3231 ; function ak820_outline_0183
      0098A8                       3232 _ak820_outline_0183:
      0098A8 AF 82            [24] 3233 	mov	r7,dpl
      0098AA 90 0C 02         [24] 3234 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      0098AD EF               [12] 3235 	mov	a,r7
      0098AE F0               [24] 3236 	movx	@dptr,a
      0098AF EF               [12] 3237 	mov	a,r7
      0098B0 22               [24] 3238 	ret
