                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_tap_dance
                                     17 	.globl _dynamic_keymap_get_tap_dance
                                     18 	.globl _dynamic_keymap_set_encoder
                                     19 	.globl _dynamic_keymap_get_encoder
                                     20 	.globl _repeat_key_cancel
                                     21 	.globl _ak820_combo_reload
                                     22 	.globl _clear_keyboard
                                     23 	.globl _ak820_action_exec
                                     24 	.globl _timer_elapsed32
                                     25 	.globl _timer_read32
                                     26 	.globl _timer_read
                                     27 	.globl ___memcpy
                                     28 	.globl _ADC_START
                                     29 	.globl _S0_R_FIFO
                                     30 	.globl _S0_T_FIFO
                                     31 	.globl _S0_FREE
                                     32 	.globl _S0_IF_BYTE
                                     33 	.globl _S0_IF_FIRST
                                     34 	.globl _S0_IF_OV
                                     35 	.globl _S0_FST_ACT
                                     36 	.globl _CP_RL2
                                     37 	.globl _C_T2
                                     38 	.globl _TR2
                                     39 	.globl _EXEN2
                                     40 	.globl _TCLK
                                     41 	.globl _RCLK
                                     42 	.globl _EXF2
                                     43 	.globl _CAP1F
                                     44 	.globl _TF2
                                     45 	.globl _RI
                                     46 	.globl _TI
                                     47 	.globl _RB8
                                     48 	.globl _TB8
                                     49 	.globl _REN
                                     50 	.globl _SM2
                                     51 	.globl _SM1
                                     52 	.globl _SM0
                                     53 	.globl _IT0
                                     54 	.globl _IE0
                                     55 	.globl _IT1
                                     56 	.globl _IE1
                                     57 	.globl _TR0
                                     58 	.globl _TF0
                                     59 	.globl _TR1
                                     60 	.globl _TF1
                                     61 	.globl _P4_0
                                     62 	.globl _P4_1
                                     63 	.globl _P4_2
                                     64 	.globl _P4_3
                                     65 	.globl _P4_4
                                     66 	.globl _P4_5
                                     67 	.globl _P4_6
                                     68 	.globl _RXD
                                     69 	.globl _TXD
                                     70 	.globl _INT0
                                     71 	.globl _INT1
                                     72 	.globl _T0
                                     73 	.globl _T1
                                     74 	.globl _MOSI1
                                     75 	.globl _MISO1
                                     76 	.globl _SCK1
                                     77 	.globl _P3_0
                                     78 	.globl _P3_1
                                     79 	.globl _P3_2
                                     80 	.globl _P3_3
                                     81 	.globl _P3_4
                                     82 	.globl _P3_5
                                     83 	.globl _P3_6
                                     84 	.globl _P3_7
                                     85 	.globl _CAP1_
                                     86 	.globl _T2_
                                     87 	.globl _CAP2_
                                     88 	.globl _T2EX_
                                     89 	.globl _RXD1
                                     90 	.globl _TXD1
                                     91 	.globl _P2_0
                                     92 	.globl _P2_1
                                     93 	.globl _P2_2
                                     94 	.globl _P2_3
                                     95 	.globl _P2_4
                                     96 	.globl _P2_5
                                     97 	.globl _P2_6
                                     98 	.globl _P2_7
                                     99 	.globl _AIN0
                                    100 	.globl _AIN1
                                    101 	.globl _AIN2
                                    102 	.globl _AIN3
                                    103 	.globl _AIN4
                                    104 	.globl _AIN5
                                    105 	.globl _AIN6
                                    106 	.globl _AIN7
                                    107 	.globl _CAP1
                                    108 	.globl _T2
                                    109 	.globl _CAP2
                                    110 	.globl _T2EX
                                    111 	.globl _INT0_
                                    112 	.globl _SCS
                                    113 	.globl _MOSI
                                    114 	.globl _MISO
                                    115 	.globl _SCK
                                    116 	.globl _RXD1_
                                    117 	.globl _TXD1_
                                    118 	.globl _P1_0
                                    119 	.globl _P1_1
                                    120 	.globl _P1_2
                                    121 	.globl _P1_3
                                    122 	.globl _P1_4
                                    123 	.globl _P1_5
                                    124 	.globl _P1_6
                                    125 	.globl _P1_7
                                    126 	.globl _AIN8
                                    127 	.globl _AIN9
                                    128 	.globl _AIN10
                                    129 	.globl _AIN11
                                    130 	.globl _AIN12
                                    131 	.globl _AIN13
                                    132 	.globl _RXD_
                                    133 	.globl _TXD_
                                    134 	.globl _SCL0
                                    135 	.globl _SDA0
                                    136 	.globl _P0_0
                                    137 	.globl _P0_1
                                    138 	.globl _P0_2
                                    139 	.globl _P0_3
                                    140 	.globl _P0_4
                                    141 	.globl _P0_5
                                    142 	.globl _P0_6
                                    143 	.globl _P0_7
                                    144 	.globl _IE_SPI0
                                    145 	.globl _IE_USB
                                    146 	.globl _IE_ADC
                                    147 	.globl _IE_UART1
                                    148 	.globl _IE_PWM_I2C
                                    149 	.globl _IE_GPIO
                                    150 	.globl _IE_WDOG
                                    151 	.globl _PX0
                                    152 	.globl _PT0
                                    153 	.globl _PX1
                                    154 	.globl _PT1
                                    155 	.globl _PS
                                    156 	.globl _PT2
                                    157 	.globl _PL_FLAG
                                    158 	.globl _PH_FLAG
                                    159 	.globl _EX0
                                    160 	.globl _ET0
                                    161 	.globl _EX1
                                    162 	.globl _ET1
                                    163 	.globl _ES
                                    164 	.globl _ET2
                                    165 	.globl _E_DIS
                                    166 	.globl _EA
                                    167 	.globl _P
                                    168 	.globl _F1
                                    169 	.globl _OV
                                    170 	.globl _RS0
                                    171 	.globl _RS1
                                    172 	.globl _F0
                                    173 	.globl _AC
                                    174 	.globl _CY
                                    175 	.globl _I2CS_INT_ST
                                    176 	.globl _I2CX_INT
                                    177 	.globl _LED_STATUS
                                    178 	.globl _LED_DMA_H
                                    179 	.globl _LED_DMA_L
                                    180 	.globl _LED_DMA
                                    181 	.globl _LED_PWM_OE
                                    182 	.globl _LED_COMMON
                                    183 	.globl _ADC_CHAN
                                    184 	.globl _ADC_DAT_H
                                    185 	.globl _ADC_DAT_L
                                    186 	.globl _ADC_DAT
                                    187 	.globl _ADC_CTRL
                                    188 	.globl _SPI1_CK_SE
                                    189 	.globl _SPI1_CTRL
                                    190 	.globl _SPI1_DATA
                                    191 	.globl _SPI1_STAT
                                    192 	.globl _SIF1
                                    193 	.globl _SBAUD1
                                    194 	.globl _SBUF1
                                    195 	.globl _SCON1
                                    196 	.globl _SPI0_SETUP
                                    197 	.globl _SPI0_CK_SE
                                    198 	.globl _SPI0_CTRL
                                    199 	.globl _SPI0_DATA
                                    200 	.globl _SPI0_STAT
                                    201 	.globl _T2CAP1H
                                    202 	.globl _T2CAP1L
                                    203 	.globl _T2CAP1
                                    204 	.globl _TH2
                                    205 	.globl _TL2
                                    206 	.globl _T2COUNT
                                    207 	.globl _RCAP2H
                                    208 	.globl _RCAP2L
                                    209 	.globl _RCAP2
                                    210 	.globl _T2MOD
                                    211 	.globl _T2CON
                                    212 	.globl _SBUF
                                    213 	.globl _SCON
                                    214 	.globl _TH1
                                    215 	.globl _TH0
                                    216 	.globl _TL1
                                    217 	.globl _TL0
                                    218 	.globl _TMOD
                                    219 	.globl _TCON
                                    220 	.globl _XBUS_AUX
                                    221 	.globl _P7
                                    222 	.globl _P6_DIR
                                    223 	.globl _P6_OUT_PU
                                    224 	.globl _P6_IN
                                    225 	.globl _P5_DIR
                                    226 	.globl _P5_OUT_PU
                                    227 	.globl _P5_IN
                                    228 	.globl _P4_LED_KEY
                                    229 	.globl _P4_DIR_PU
                                    230 	.globl _P4_MOD_OC
                                    231 	.globl _P4
                                    232 	.globl _P3_DIR_PU
                                    233 	.globl _P3_MOD_OC
                                    234 	.globl _P3
                                    235 	.globl _P2_DIR_PU
                                    236 	.globl _P2_MOD_OC
                                    237 	.globl _P2
                                    238 	.globl _P1_DIR_PU
                                    239 	.globl _P1_MOD_OC
                                    240 	.globl _P1
                                    241 	.globl _P0_DIR_PU
                                    242 	.globl _P0_MOD_OC
                                    243 	.globl _P0
                                    244 	.globl _ROM_CTRL
                                    245 	.globl _ROM_DATA_HH
                                    246 	.globl _ROM_DATA_HL
                                    247 	.globl _ROM_DATA_HI
                                    248 	.globl _ROM_ADDR_H
                                    249 	.globl _ROM_ADDR_L
                                    250 	.globl _ROM_ADDR
                                    251 	.globl _GPIO_IE
                                    252 	.globl _IP_EX
                                    253 	.globl _IE_EX
                                    254 	.globl _IP
                                    255 	.globl _IE
                                    256 	.globl _WDOG_COUNT
                                    257 	.globl _RESET_KEEP
                                    258 	.globl _WAKE_CTRL
                                    259 	.globl _CLOCK_CFG
                                    260 	.globl _POWER_CFG
                                    261 	.globl _PCON
                                    262 	.globl _GLOBAL_CFG
                                    263 	.globl _SAFE_MOD
                                    264 	.globl _DPH
                                    265 	.globl _DPL
                                    266 	.globl _SP
                                    267 	.globl _A_INV
                                    268 	.globl _B
                                    269 	.globl _ACC
                                    270 	.globl _PSW
                                    271 	.globl _vial_unlock_in_progress
                                    272 	.globl _vial_unlocked
                                    273 	.globl _g_vial_magic_keycode_override
                                    274 	.globl _vial_handle_cmd_PARM_2
                                    275 	.globl _vial_unlock_task
                                    276 	.globl _vial_init
                                    277 	.globl _vial_handle_cmd
                                    278 	.globl _vial_keycode_down
                                    279 	.globl _vial_keycode_up
                                    280 	.globl _vial_keycode_tap
                                    281 ;--------------------------------------------------------
                                    282 ; special function registers
                                    283 ;--------------------------------------------------------
                                    284 	.area RSEG    (ABS,DATA)
      000000                        285 	.org 0x0000
                           0000D0   286 _PSW	=	0x00d0
                           0000E0   287 _ACC	=	0x00e0
                           0000F0   288 _B	=	0x00f0
                           0000FD   289 _A_INV	=	0x00fd
                           000081   290 _SP	=	0x0081
                           000082   291 _DPL	=	0x0082
                           000083   292 _DPH	=	0x0083
                           0000A1   293 _SAFE_MOD	=	0x00a1
                           0000B1   294 _GLOBAL_CFG	=	0x00b1
                           000087   295 _PCON	=	0x0087
                           0000BA   296 _POWER_CFG	=	0x00ba
                           0000B9   297 _CLOCK_CFG	=	0x00b9
                           0000A9   298 _WAKE_CTRL	=	0x00a9
                           0000FE   299 _RESET_KEEP	=	0x00fe
                           0000FF   300 _WDOG_COUNT	=	0x00ff
                           0000A8   301 _IE	=	0x00a8
                           0000B8   302 _IP	=	0x00b8
                           0000E8   303 _IE_EX	=	0x00e8
                           0000E9   304 _IP_EX	=	0x00e9
                           0000B2   305 _GPIO_IE	=	0x00b2
                           008584   306 _ROM_ADDR	=	0x8584
                           000084   307 _ROM_ADDR_L	=	0x0084
                           000085   308 _ROM_ADDR_H	=	0x0085
                           008F8E   309 _ROM_DATA_HI	=	0x8f8e
                           00008E   310 _ROM_DATA_HL	=	0x008e
                           00008F   311 _ROM_DATA_HH	=	0x008f
                           000086   312 _ROM_CTRL	=	0x0086
                           000080   313 _P0	=	0x0080
                           0000C4   314 _P0_MOD_OC	=	0x00c4
                           0000C5   315 _P0_DIR_PU	=	0x00c5
                           000090   316 _P1	=	0x0090
                           000092   317 _P1_MOD_OC	=	0x0092
                           000093   318 _P1_DIR_PU	=	0x0093
                           0000A0   319 _P2	=	0x00a0
                           000094   320 _P2_MOD_OC	=	0x0094
                           000095   321 _P2_DIR_PU	=	0x0095
                           0000B0   322 _P3	=	0x00b0
                           000096   323 _P3_MOD_OC	=	0x0096
                           000097   324 _P3_DIR_PU	=	0x0097
                           0000C0   325 _P4	=	0x00c0
                           0000C2   326 _P4_MOD_OC	=	0x00c2
                           0000C3   327 _P4_DIR_PU	=	0x00c3
                           0000C1   328 _P4_LED_KEY	=	0x00c1
                           0000AA   329 _P5_IN	=	0x00aa
                           0000AB   330 _P5_OUT_PU	=	0x00ab
                           0000AC   331 _P5_DIR	=	0x00ac
                           0000AD   332 _P6_IN	=	0x00ad
                           0000AE   333 _P6_OUT_PU	=	0x00ae
                           0000AF   334 _P6_DIR	=	0x00af
                           0000F1   335 _P7	=	0x00f1
                           0000A2   336 _XBUS_AUX	=	0x00a2
                           000088   337 _TCON	=	0x0088
                           000089   338 _TMOD	=	0x0089
                           00008A   339 _TL0	=	0x008a
                           00008B   340 _TL1	=	0x008b
                           00008C   341 _TH0	=	0x008c
                           00008D   342 _TH1	=	0x008d
                           000098   343 _SCON	=	0x0098
                           000099   344 _SBUF	=	0x0099
                           0000C8   345 _T2CON	=	0x00c8
                           0000C9   346 _T2MOD	=	0x00c9
                           00CBCA   347 _RCAP2	=	0xcbca
                           0000CA   348 _RCAP2L	=	0x00ca
                           0000CB   349 _RCAP2H	=	0x00cb
                           00CDCC   350 _T2COUNT	=	0xcdcc
                           0000CC   351 _TL2	=	0x00cc
                           0000CD   352 _TH2	=	0x00cd
                           00CFCE   353 _T2CAP1	=	0xcfce
                           0000CE   354 _T2CAP1L	=	0x00ce
                           0000CF   355 _T2CAP1H	=	0x00cf
                           0000F8   356 _SPI0_STAT	=	0x00f8
                           0000F9   357 _SPI0_DATA	=	0x00f9
                           0000FA   358 _SPI0_CTRL	=	0x00fa
                           0000FB   359 _SPI0_CK_SE	=	0x00fb
                           0000FC   360 _SPI0_SETUP	=	0x00fc
                           0000BC   361 _SCON1	=	0x00bc
                           0000BD   362 _SBUF1	=	0x00bd
                           0000BE   363 _SBAUD1	=	0x00be
                           0000BF   364 _SIF1	=	0x00bf
                           0000B4   365 _SPI1_STAT	=	0x00b4
                           0000B5   366 _SPI1_DATA	=	0x00b5
                           0000B6   367 _SPI1_CTRL	=	0x00b6
                           0000B7   368 _SPI1_CK_SE	=	0x00b7
                           0000F3   369 _ADC_CTRL	=	0x00f3
                           00F5F4   370 _ADC_DAT	=	0xf5f4
                           0000F4   371 _ADC_DAT_L	=	0x00f4
                           0000F5   372 _ADC_DAT_H	=	0x00f5
                           0000F6   373 _ADC_CHAN	=	0x00f6
                           0000A6   374 _LED_COMMON	=	0x00a6
                           0000A7   375 _LED_PWM_OE	=	0x00a7
                           00C7C6   376 _LED_DMA	=	0xc7c6
                           0000C6   377 _LED_DMA_L	=	0x00c6
                           0000C7   378 _LED_DMA_H	=	0x00c7
                           0000F7   379 _LED_STATUS	=	0x00f7
                           0000B3   380 _I2CX_INT	=	0x00b3
                           0000BB   381 _I2CS_INT_ST	=	0x00bb
                                    382 ;--------------------------------------------------------
                                    383 ; special function bits
                                    384 ;--------------------------------------------------------
                                    385 	.area RSEG    (ABS,DATA)
      000000                        386 	.org 0x0000
                           0000D7   387 _CY	=	0x00d7
                           0000D6   388 _AC	=	0x00d6
                           0000D5   389 _F0	=	0x00d5
                           0000D4   390 _RS1	=	0x00d4
                           0000D3   391 _RS0	=	0x00d3
                           0000D2   392 _OV	=	0x00d2
                           0000D1   393 _F1	=	0x00d1
                           0000D0   394 _P	=	0x00d0
                           0000AF   395 _EA	=	0x00af
                           0000AE   396 _E_DIS	=	0x00ae
                           0000AD   397 _ET2	=	0x00ad
                           0000AC   398 _ES	=	0x00ac
                           0000AB   399 _ET1	=	0x00ab
                           0000AA   400 _EX1	=	0x00aa
                           0000A9   401 _ET0	=	0x00a9
                           0000A8   402 _EX0	=	0x00a8
                           0000BF   403 _PH_FLAG	=	0x00bf
                           0000BE   404 _PL_FLAG	=	0x00be
                           0000BD   405 _PT2	=	0x00bd
                           0000BC   406 _PS	=	0x00bc
                           0000BB   407 _PT1	=	0x00bb
                           0000BA   408 _PX1	=	0x00ba
                           0000B9   409 _PT0	=	0x00b9
                           0000B8   410 _PX0	=	0x00b8
                           0000EF   411 _IE_WDOG	=	0x00ef
                           0000EE   412 _IE_GPIO	=	0x00ee
                           0000ED   413 _IE_PWM_I2C	=	0x00ed
                           0000EC   414 _IE_UART1	=	0x00ec
                           0000EB   415 _IE_ADC	=	0x00eb
                           0000E9   416 _IE_USB	=	0x00e9
                           0000E8   417 _IE_SPI0	=	0x00e8
                           000087   418 _P0_7	=	0x0087
                           000086   419 _P0_6	=	0x0086
                           000085   420 _P0_5	=	0x0085
                           000084   421 _P0_4	=	0x0084
                           000083   422 _P0_3	=	0x0083
                           000082   423 _P0_2	=	0x0082
                           000081   424 _P0_1	=	0x0081
                           000080   425 _P0_0	=	0x0080
                           000081   426 _SDA0	=	0x0081
                           000080   427 _SCL0	=	0x0080
                           000083   428 _TXD_	=	0x0083
                           000082   429 _RXD_	=	0x0082
                           000085   430 _AIN13	=	0x0085
                           000084   431 _AIN12	=	0x0084
                           000083   432 _AIN11	=	0x0083
                           000082   433 _AIN10	=	0x0082
                           000081   434 _AIN9	=	0x0081
                           000080   435 _AIN8	=	0x0080
                           000097   436 _P1_7	=	0x0097
                           000096   437 _P1_6	=	0x0096
                           000095   438 _P1_5	=	0x0095
                           000094   439 _P1_4	=	0x0094
                           000093   440 _P1_3	=	0x0093
                           000092   441 _P1_2	=	0x0092
                           000091   442 _P1_1	=	0x0091
                           000090   443 _P1_0	=	0x0090
                           000097   444 _TXD1_	=	0x0097
                           000096   445 _RXD1_	=	0x0096
                           000097   446 _SCK	=	0x0097
                           000096   447 _MISO	=	0x0096
                           000095   448 _MOSI	=	0x0095
                           000094   449 _SCS	=	0x0094
                           000092   450 _INT0_	=	0x0092
                           000091   451 _T2EX	=	0x0091
                           000091   452 _CAP2	=	0x0091
                           000090   453 _T2	=	0x0090
                           000090   454 _CAP1	=	0x0090
                           000097   455 _AIN7	=	0x0097
                           000096   456 _AIN6	=	0x0096
                           000095   457 _AIN5	=	0x0095
                           000094   458 _AIN4	=	0x0094
                           000093   459 _AIN3	=	0x0093
                           000092   460 _AIN2	=	0x0092
                           000091   461 _AIN1	=	0x0091
                           000090   462 _AIN0	=	0x0090
                           0000A7   463 _P2_7	=	0x00a7
                           0000A6   464 _P2_6	=	0x00a6
                           0000A5   465 _P2_5	=	0x00a5
                           0000A4   466 _P2_4	=	0x00a4
                           0000A3   467 _P2_3	=	0x00a3
                           0000A2   468 _P2_2	=	0x00a2
                           0000A1   469 _P2_1	=	0x00a1
                           0000A0   470 _P2_0	=	0x00a0
                           0000A7   471 _TXD1	=	0x00a7
                           0000A6   472 _RXD1	=	0x00a6
                           0000A5   473 _T2EX_	=	0x00a5
                           0000A5   474 _CAP2_	=	0x00a5
                           0000A4   475 _T2_	=	0x00a4
                           0000A4   476 _CAP1_	=	0x00a4
                           0000B7   477 _P3_7	=	0x00b7
                           0000B6   478 _P3_6	=	0x00b6
                           0000B5   479 _P3_5	=	0x00b5
                           0000B4   480 _P3_4	=	0x00b4
                           0000B3   481 _P3_3	=	0x00b3
                           0000B2   482 _P3_2	=	0x00b2
                           0000B1   483 _P3_1	=	0x00b1
                           0000B0   484 _P3_0	=	0x00b0
                           0000B7   485 _SCK1	=	0x00b7
                           0000B6   486 _MISO1	=	0x00b6
                           0000B5   487 _MOSI1	=	0x00b5
                           0000B5   488 _T1	=	0x00b5
                           0000B4   489 _T0	=	0x00b4
                           0000B3   490 _INT1	=	0x00b3
                           0000B2   491 _INT0	=	0x00b2
                           0000B1   492 _TXD	=	0x00b1
                           0000B0   493 _RXD	=	0x00b0
                           0000C6   494 _P4_6	=	0x00c6
                           0000C5   495 _P4_5	=	0x00c5
                           0000C4   496 _P4_4	=	0x00c4
                           0000C3   497 _P4_3	=	0x00c3
                           0000C2   498 _P4_2	=	0x00c2
                           0000C1   499 _P4_1	=	0x00c1
                           0000C0   500 _P4_0	=	0x00c0
                           00008F   501 _TF1	=	0x008f
                           00008E   502 _TR1	=	0x008e
                           00008D   503 _TF0	=	0x008d
                           00008C   504 _TR0	=	0x008c
                           00008B   505 _IE1	=	0x008b
                           00008A   506 _IT1	=	0x008a
                           000089   507 _IE0	=	0x0089
                           000088   508 _IT0	=	0x0088
                           00009F   509 _SM0	=	0x009f
                           00009E   510 _SM1	=	0x009e
                           00009D   511 _SM2	=	0x009d
                           00009C   512 _REN	=	0x009c
                           00009B   513 _TB8	=	0x009b
                           00009A   514 _RB8	=	0x009a
                           000099   515 _TI	=	0x0099
                           000098   516 _RI	=	0x0098
                           0000CF   517 _TF2	=	0x00cf
                           0000CF   518 _CAP1F	=	0x00cf
                           0000CE   519 _EXF2	=	0x00ce
                           0000CD   520 _RCLK	=	0x00cd
                           0000CC   521 _TCLK	=	0x00cc
                           0000CB   522 _EXEN2	=	0x00cb
                           0000CA   523 _TR2	=	0x00ca
                           0000C9   524 _C_T2	=	0x00c9
                           0000C8   525 _CP_RL2	=	0x00c8
                           0000FF   526 _S0_FST_ACT	=	0x00ff
                           0000FE   527 _S0_IF_OV	=	0x00fe
                           0000FD   528 _S0_IF_FIRST	=	0x00fd
                           0000FC   529 _S0_IF_BYTE	=	0x00fc
                           0000FB   530 _S0_FREE	=	0x00fb
                           0000FA   531 _S0_T_FIFO	=	0x00fa
                           0000F8   532 _S0_R_FIFO	=	0x00f8
                           0000F7   533 _ADC_START	=	0x00f7
                                    534 ;--------------------------------------------------------
                                    535 ; overlayable register banks
                                    536 ;--------------------------------------------------------
                                    537 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        538 	.ds 8
                                    539 ;--------------------------------------------------------
                                    540 ; internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area DSEG    (DATA)
      000046                        543 _vial_handle_cmd_sloc0_1_0:
      000046                        544 	.ds 2
      000048                        545 _vial_handle_cmd_sloc1_1_0:
      000048                        546 	.ds 2
      00004A                        547 _vial_handle_cmd_sloc2_1_0:
      00004A                        548 	.ds 2
      00004C                        549 _vial_handle_cmd_sloc3_1_0:
      00004C                        550 	.ds 2
                                    551 ;--------------------------------------------------------
                                    552 ; overlayable items in internal ram
                                    553 ;--------------------------------------------------------
                                    554 ;--------------------------------------------------------
                                    555 ; indirectly addressable internal ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area ISEG    (DATA)
                                    558 ;--------------------------------------------------------
                                    559 ; absolute internal ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area IABS    (ABS,DATA)
                                    562 	.area IABS    (ABS,DATA)
                                    563 ;--------------------------------------------------------
                                    564 ; bit data
                                    565 ;--------------------------------------------------------
                                    566 	.area BSEG    (BIT)
                                    567 ;--------------------------------------------------------
                                    568 ; paged external ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area PSEG    (PAG,XDATA)
                                    571 ;--------------------------------------------------------
                                    572 ; uninitialized external ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area XSEG    (XDATA)
      000D15                        575 _vial_unlock_timer:
      000D15                        576 	.ds 4
      000D19                        577 _vial_unlock_holding:
      000D19                        578 	.ds 1
      000D1A                        579 _vial_keycode_firewall_in_10000_611:
      000D1A                        580 	.ds 2
      000D1C                        581 _vial_fill_packet_PARM_2:
      000D1C                        582 	.ds 1
      000D1D                        583 _vial_fill_packet_msg_10000_614:
      000D1D                        584 	.ds 2
      000D1F                        585 _vial_handle_cmd_PARM_2:
      000D1F                        586 	.ds 1
      000D20                        587 _vial_handle_cmd_data_10000_619:
      000D20                        588 	.ds 3
      000D23                        589 _vial_handle_cmd_td_70000_647:
      000D23                        590 	.ds 10
      000D2D                        591 _vial_handle_cmd_td_70000_648:
      000D2D                        592 	.ds 10
      000D37                        593 _vial_handle_cmd_entry_70000_649:
      000D37                        594 	.ds 10
      000D41                        595 _vial_handle_cmd_entry_70000_650:
      000D41                        596 	.ds 10
      000D4B                        597 _g_vial_magic_keycode_override::
      000D4B                        598 	.ds 2
      000D4D                        599 _vial_keycode_down_keycode_10000_652:
      000D4D                        600 	.ds 2
      000D4F                        601 _vial_keycode_down_dummy_event_30000_659:
      000D4F                        602 	.ds 6
      000D55                        603 _vial_keycode_up_keycode_10000_660:
      000D55                        604 	.ds 2
      000D57                        605 _vial_keycode_up_dummy_event_30000_667:
      000D57                        606 	.ds 6
      000D5D                        607 _vial_keycode_tap_keycode_10000_668:
      000D5D                        608 	.ds 2
                                    609 ;--------------------------------------------------------
                                    610 ; absolute external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XABS    (ABS,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; initialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XISEG   (XDATA)
      000EF4                        617 _vial_unlocked::
      000EF4                        618 	.ds 1
      000EF5                        619 _vial_unlock_in_progress::
      000EF5                        620 	.ds 1
      000EF6                        621 _vial_unlock_counter:
      000EF6                        622 	.ds 1
      000EF7                        623 _vial_unlock_combo_rows:
      000EF7                        624 	.ds 2
      000EF9                        625 _vial_unlock_combo_cols:
      000EF9                        626 	.ds 2
                                    627 	.area HOME    (CODE)
                                    628 	.area GSINIT0 (CODE)
                                    629 	.area GSINIT1 (CODE)
                                    630 	.area GSINIT2 (CODE)
                                    631 	.area GSINIT3 (CODE)
                                    632 	.area GSINIT4 (CODE)
                                    633 	.area GSINIT5 (CODE)
                                    634 	.area GSINIT  (CODE)
                                    635 	.area GSFINAL (CODE)
                                    636 	.area CSEG    (CODE)
                                    637 ;--------------------------------------------------------
                                    638 ; global & static initialisations
                                    639 ;--------------------------------------------------------
                                    640 	.area HOME    (CODE)
                                    641 	.area GSINIT  (CODE)
                                    642 	.area GSFINAL (CODE)
                                    643 	.area GSINIT  (CODE)
                                    644 ;--------------------------------------------------------
                                    645 ; Home
                                    646 ;--------------------------------------------------------
                                    647 	.area HOME    (CODE)
                                    648 	.area HOME    (CODE)
                                    649 ;--------------------------------------------------------
                                    650 ; code
                                    651 ;--------------------------------------------------------
                                    652 	.area CSEG    (CODE)
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    655 ;------------------------------------------------------------
                                    656 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    657 ;------------------------------------------------------------
                                    658 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    659 ;	-----------------------------------------
                           000007   660 	ar7 = 0x07
                           000006   661 	ar6 = 0x06
                           000005   662 	ar5 = 0x05
                           000004   663 	ar4 = 0x04
                           000003   664 	ar3 = 0x03
                           000002   665 	ar2 = 0x02
                           000001   666 	ar1 = 0x01
                           000000   667 	ar0 = 0x00
                                    668 ;	 function vial_unlock_task
                                    669 ;	-----------------------------------------
      00B637                        670 _vial_unlock_task:
                                    671 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B637 90 0E F5         [24]  672 	mov	dptr,#_vial_unlock_in_progress
      00B63A E0               [24]  673 	movx	a,@dptr
      00B63B 70 01            [24]  674 	jnz	00131$
      00B63D 22               [24]  675 	ret
                                    676 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B63E                        677 00131$:
      00B63E 7F 00            [12]  678 	mov	r7,#0x00
      00B640                        679 00115$:
      00B640 BF 02 00         [24]  680 	cjne	r7,#0x02,00184$
      00B643                        681 00184$:
      00B643 50 29            [24]  682 	jnc	00105$
                                    683 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B645 EF               [12]  684 	mov	a,r7
      00B646 12 BC FA         [24]  685 	lcall	_ak820_outline_0130
      00B649 FE               [12]  686 	mov	r6,a
      00B64A EF               [12]  687 	mov	a,r7
      00B64B 12 BC EF         [24]  688 	lcall	_ak820_outline_0129
      00B64E 90 08 0F         [24]  689 	mov	dptr,#_matrix_is_on_PARM_2
      00B651 F0               [24]  690 	movx	@dptr,a
      00B652 8E 82            [24]  691 	mov	dpl, r6
      00B654 C0 07            [24]  692 	push	ar7
      00B656 12 62 76         [24]  693 	lcall	_matrix_is_on
      00B659 E5 82            [12]  694 	mov	a, dpl
      00B65B D0 07            [24]  695 	pop	ar7
      00B65D 70 0C            [24]  696 	jnz	00116$
                                    697 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B65F 90 0D 19         [24]  698 	mov	dptr,#_vial_unlock_holding
      00B662 E4               [12]  699 	clr	a
      00B663 F0               [24]  700 	movx	@dptr,a
                                    701 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B664 90 0E F6         [24]  702 	mov	dptr,#_vial_unlock_counter
      00B667 74 1E            [12]  703 	mov	a,#0x1e
      00B669 F0               [24]  704 	movx	@dptr,a
                                    705 ;	quantum/vial.c:69: return;
      00B66A 22               [24]  706 	ret
      00B66B                        707 00116$:
                                    708 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B66B 0F               [12]  709 	inc	r7
      00B66C 80 D2            [24]  710 	sjmp	00115$
      00B66E                        711 00105$:
                                    712 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B66E 90 0D 19         [24]  713 	mov	dptr,#_vial_unlock_holding
      00B671 E0               [24]  714 	movx	a,@dptr
      00B672 70 12            [24]  715 	jnz	00107$
                                    716 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B674 90 0D 19         [24]  717 	mov	dptr,#_vial_unlock_holding
      00B677 74 01            [12]  718 	mov	a,#0x01
      00B679 F0               [24]  719 	movx	@dptr,a
                                    720 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B67A 12 52 71         [24]  721 	lcall	_timer_read32
      00B67D 12 58 83         [24]  722 	lcall	_ak820_outline_0059
      00B680 90 0D 15         [24]  723 	mov	dptr,#_vial_unlock_timer
      00B683 12 9A 26         [24]  724 	lcall	_ak820_outline_0006
      00B686                        725 00107$:
                                    726 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B686 90 0D 15         [24]  727 	mov	dptr,#_vial_unlock_timer
      00B689 12 58 72         [24]  728 	lcall	_ak820_outline_0057
      00B68C 12 52 CA         [24]  729 	lcall	_timer_elapsed32
      00B68F 12 58 83         [24]  730 	lcall	_ak820_outline_0059
                                    731 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B692 7B 1E            [12]  732 	mov	r3,#0x1e
      00B694                        733 00109$:
      00B694 EB               [12]  734 	mov	a,r3
      00B695 60 22            [24]  735 	jz	00111$
      00B697 C3               [12]  736 	clr	c
      00B698 EC               [12]  737 	mov	a,r4
      00B699 94 64            [12]  738 	subb	a,#0x64
      00B69B ED               [12]  739 	mov	a,r5
      00B69C 94 00            [12]  740 	subb	a,#0x00
      00B69E EE               [12]  741 	mov	a,r6
      00B69F 94 00            [12]  742 	subb	a,#0x00
      00B6A1 EF               [12]  743 	mov	a,r7
      00B6A2 94 00            [12]  744 	subb	a,#0x00
      00B6A4 40 13            [24]  745 	jc	00111$
                                    746 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B6A6 EC               [12]  747 	mov	a,r4
      00B6A7 24 9C            [12]  748 	add	a,#0x9c
      00B6A9 FC               [12]  749 	mov	r4,a
      00B6AA ED               [12]  750 	mov	a,r5
      00B6AB 34 FF            [12]  751 	addc	a,#0xff
      00B6AD FD               [12]  752 	mov	r5,a
      00B6AE EE               [12]  753 	mov	a,r6
      00B6AF 34 FF            [12]  754 	addc	a,#0xff
      00B6B1 FE               [12]  755 	mov	r6,a
      00B6B2 EF               [12]  756 	mov	a,r7
      00B6B3 34 FF            [12]  757 	addc	a,#0xff
      00B6B5 FF               [12]  758 	mov	r7,a
                                    759 ;	quantum/vial.c:82: --counter;
      00B6B6 1B               [12]  760 	dec	r3
      00B6B7 80 DB            [24]  761 	sjmp	00109$
      00B6B9                        762 00111$:
                                    763 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B6B9 90 0E F6         [24]  764 	mov	dptr,#_vial_unlock_counter
      00B6BC EB               [12]  765 	mov	a,r3
      00B6BD F0               [24]  766 	movx	@dptr,a
                                    767 ;	quantum/vial.c:85: if (!counter) {
      00B6BE EB               [12]  768 	mov	a,r3
      00B6BF 70 0A            [24]  769 	jnz	00117$
                                    770 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B6C1 90 0E F5         [24]  771 	mov	dptr,#_vial_unlock_in_progress
      00B6C4 E4               [12]  772 	clr	a
      00B6C5 F0               [24]  773 	movx	@dptr,a
                                    774 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B6C6 90 0E F4         [24]  775 	mov	dptr,#_vial_unlocked
      00B6C9 04               [12]  776 	inc	a
      00B6CA F0               [24]  777 	movx	@dptr,a
      00B6CB                        778 00117$:
                                    779 ;	quantum/vial.c:90: }
      00B6CB 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'vial_init'
                                    783 ;------------------------------------------------------------
                                    784 ;	quantum/vial.c:117: void vial_init(void) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function vial_init
                                    787 ;	-----------------------------------------
      00B6CC                        788 _vial_init:
                                    789 ;	quantum/vial.c:125: reload_combo();
                                    790 ;	quantum/vial.c:130: }
      00B6CC 02 35 7C         [24]  791 	ljmp	_ak820_combo_reload
                                    792 ;------------------------------------------------------------
                                    793 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    794 ;------------------------------------------------------------
                                    795 ;in            Allocated with name '_vial_keycode_firewall_in_10000_611'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function vial_keycode_firewall
                                    800 ;	-----------------------------------------
      00B6CF                        801 _vial_keycode_firewall:
      00B6CF 12 38 75         [24]  802 	lcall	_ak820_outline_0108
      00B6D2 90 0D 1A         [24]  803 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B6D5 12 38 7A         [24]  804 	lcall	_ak820_outline_0109
                                    805 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B6D8 90 0D 1A         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B6DB 12 51 8C         [24]  807 	lcall	_ak820_outline_0009
      00B6DE BC 00 0D         [24]  808 	cjne	r4,#0x00,00102$
      00B6E1 BD 7C 0A         [24]  809 	cjne	r5,#0x7c,00102$
      00B6E4 90 0E F4         [24]  810 	mov	dptr,#_vial_unlocked
      00B6E7 E0               [24]  811 	movx	a,@dptr
      00B6E8 70 04            [24]  812 	jnz	00102$
                                    813 ;	quantum/vial.c:134: return 0;
      00B6EA 90 00 00         [24]  814 	mov	dptr,#0x0000
      00B6ED 22               [24]  815 	ret
      00B6EE                        816 00102$:
                                    817 ;	quantum/vial.c:135: return in;
      00B6EE 12 38 7F         [24]  818 	lcall	_ak820_outline_0120
                                    819 ;	quantum/vial.c:136: }
      00B6F1 22               [24]  820 	ret
                                    821 ;------------------------------------------------------------
                                    822 ;Allocation info for local variables in function 'vial_fill_packet'
                                    823 ;------------------------------------------------------------
                                    824 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    825 ;msg           Allocated with name '_vial_fill_packet_msg_10000_614'
                                    826 ;i             Allocated with name '_vial_fill_packet_i_20000_616'
                                    827 ;------------------------------------------------------------
                                    828 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    829 ;	-----------------------------------------
                                    830 ;	 function vial_fill_packet
                                    831 ;	-----------------------------------------
      00B6F2                        832 _vial_fill_packet:
      00B6F2 12 38 75         [24]  833 	lcall	_ak820_outline_0108
      00B6F5 90 0D 1D         [24]  834 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B6F8 12 38 7A         [24]  835 	lcall	_ak820_outline_0109
                                    836 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B6FB 90 0D 1D         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B6FE 12 38 34         [24]  838 	lcall	_ak820_outline_0054
      00B701 90 0D 1C         [24]  839 	mov	dptr,#_vial_fill_packet_PARM_2
      00B704 E0               [24]  840 	movx	a,@dptr
      00B705 FD               [12]  841 	mov	r5,a
      00B706 7C 00            [12]  842 	mov	r4,#0x00
      00B708                        843 00103$:
      00B708 BC 20 00         [24]  844 	cjne	r4,#0x20,00122$
      00B70B                        845 00122$:
      00B70B 50 09            [24]  846 	jnc	00105$
      00B70D EC               [12]  847 	mov	a,r4
      00B70E 12 38 24         [24]  848 	lcall	_ak820_outline_0023
      00B711 ED               [12]  849 	mov	a,r5
      00B712 F0               [24]  850 	movx	@dptr,a
      00B713 0C               [12]  851 	inc	r4
      00B714 80 F2            [24]  852 	sjmp	00103$
      00B716                        853 00105$:
                                    854 ;	quantum/vial.c:141: }
      00B716 22               [24]  855 	ret
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'vial_release_held_state'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function vial_release_held_state
                                    862 ;	-----------------------------------------
      00B717                        863 _vial_release_held_state:
                                    864 ;	quantum/vial.c:174: repeat_key_cancel();
      00B717 12 AB 41         [24]  865 	lcall	_repeat_key_cancel
                                    866 ;	quantum/vial.c:176: clear_keyboard();
                                    867 ;	quantum/vial.c:177: }
      00B71A 02 7F 8D         [24]  868 	ljmp	_clear_keyboard
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    871 ;------------------------------------------------------------
                                    872 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    873 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    874 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    875 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    876 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    877 ;data          Allocated with name '_vial_handle_cmd_data_10000_619'
                                    878 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_620'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50000_625'
                                    880 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_626'
                                    881 ;page          Allocated with name '_vial_handle_cmd_page_40001_629'
                                    882 ;start         Allocated with name '_vial_handle_cmd_start_40002_631'
                                    883 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_631'
                                    884 ;count         Allocated with name '_vial_handle_cmd_count_40002_631'
                                    885 ;i             Allocated with name '_vial_handle_cmd_i_50002_632'
                                    886 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_633'
                                    887 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_633'
                                    888 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_633'
                                    889 ;i             Allocated with name '_vial_handle_cmd_i_50000_636'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    891 ;td            Allocated with name '_vial_handle_cmd_td_70000_647'
                                    892 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_648'
                                    893 ;td            Allocated with name '_vial_handle_cmd_td_70000_648'
                                    894 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_649'
                                    895 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_649'
                                    896 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_650'
                                    897 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_650'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function vial_handle_cmd
                                    902 ;	-----------------------------------------
      00B71D                        903 _vial_handle_cmd:
      00B71D 12 43 06         [24]  904 	lcall	_ak820_outline_0038
      00B720 90 0D 20         [24]  905 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B723 12 38 1C         [24]  906 	lcall	_ak820_outline_0019
                                    907 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B726 90 0D 20         [24]  908 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B729 12 38 34         [24]  909 	lcall	_ak820_outline_0054
                                    910 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B72C 90 0D 1F         [24]  911 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B72F E0               [24]  912 	movx	a,@dptr
      00B730 FD               [12]  913 	mov	r5,a
      00B731 BD 20 02         [24]  914 	cjne	r5,#0x20,00246$
      00B734 80 01            [24]  915 	sjmp	00102$
      00B736                        916 00246$:
                                    917 ;	quantum/vial.c:190: return;
      00B736 22               [24]  918 	ret
      00B737                        919 00102$:
                                    920 ;	quantum/vial.c:193: switch (msg[1]) {
      00B737 74 01            [12]  921 	mov	a,#0x01
      00B739 12 51 D6         [24]  922 	lcall	_ak820_outline_0034
      00B73C FB               [12]  923 	mov  r3,a
      00B73D 24 F2            [12]  924 	add	a,#0xff - 0x0d
      00B73F 50 01            [24]  925 	jnc	00247$
      00B741 22               [24]  926 	ret
      00B742                        927 00247$:
                                    928 ;	free result
      00B742 EB               [12]  929 	mov	a,r3
      00B743 24 0A            [12]  930 	add	a,#(00248$-3-.)
      00B745 83               [24]  931 	movc	a,@a+pc
      00B746 F5 82            [12]  932 	mov	dpl,a
      00B748 EB               [12]  933 	mov	a,r3
      00B749 24 12            [12]  934 	add	a,#(00249$-3-.)
      00B74B 83               [24]  935 	movc	a,@a+pc
      00B74C F5 83            [12]  936 	mov	dph,a
      00B74E E4               [12]  937 	clr	a
      00B74F 73               [24]  938 	jmp	@a+dptr
      00B750                        939 00248$:
      00B750 6C                     940 	.db	00103$
      00B751 B4                     941 	.db	00105$
      00B752 C8                     942 	.db	00106$
      00B753 54                     943 	.db	00112$
      00B754 DA                     944 	.db	00113$
      00B755 25                     945 	.db	00114$
      00B756 94                     946 	.db	00116$
      00B757 AF                     947 	.db	00119$
      00B758 CF                     948 	.db	00120$
      00B759 DD                     949 	.db	00121$
      00B75A D3                     950 	.db	00141$
      00B75B D3                     951 	.db	00141$
      00B75C D3                     952 	.db	00141$
      00B75D E8                     953 	.db	00122$
      00B75E                        954 00249$:
      00B75E B7                     955 	.db	00103$>>8
      00B75F B7                     956 	.db	00105$>>8
      00B760 B7                     957 	.db	00106$>>8
      00B761 B8                     958 	.db	00112$>>8
      00B762 B8                     959 	.db	00113$>>8
      00B763 B9                     960 	.db	00114$>>8
      00B764 B9                     961 	.db	00116$>>8
      00B765 B9                     962 	.db	00119$>>8
      00B766 B9                     963 	.db	00120$>>8
      00B767 B9                     964 	.db	00121$>>8
      00B768 BB                     965 	.db	00141$>>8
      00B769 BB                     966 	.db	00141$>>8
      00B76A BB                     967 	.db	00141$>>8
      00B76B B9                     968 	.db	00122$>>8
                                    969 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B76C                        970 00103$:
                                    971 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B76C 90 0D 1C         [24]  972 	mov	dptr,#_vial_fill_packet_PARM_2
      00B76F E4               [12]  973 	clr	a
      00B770 12 43 31         [24]  974 	lcall	_ak820_outline_0068
      00B773 C0 07            [24]  975 	push	ar7
      00B775 C0 06            [24]  976 	push	ar6
      00B777 12 B6 F2         [24]  977 	lcall	_vial_fill_packet
      00B77A D0 06            [24]  978 	pop	ar6
      00B77C D0 07            [24]  979 	pop	ar7
                                    980 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B77E 12 38 7F         [24]  981 	lcall	_ak820_outline_0120
      00B781 74 06            [12]  982 	mov	a,#0x06
      00B783 12 43 31         [24]  983 	lcall	_ak820_outline_0068
                                    984 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B786 A3               [24]  985 	inc	dptr
      00B787 E4               [12]  986 	clr	a
      00B788 12 42 FE         [24]  987 	lcall	_ak820_outline_0032
                                    988 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B78B 12 42 FE         [24]  989 	lcall	_ak820_outline_0032
                                    990 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B78E A3               [24]  991 	inc	dptr
      00B78F F0               [24]  992 	movx	@dptr,a
                                    993 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B790 FB               [12]  994 	mov	r3,a
      00B791                        995 00133$:
      00B791 BB 08 00         [24]  996 	cjne	r3,#0x08,00250$
      00B794                        997 00250$:
      00B794 50 15            [24]  998 	jnc	00104$
      00B796 8B 02            [24]  999 	mov	ar2,r3
      00B798 74 04            [12] 1000 	mov	a,#0x04
      00B79A 2A               [12] 1001 	add	a, r2
      00B79B 2E               [12] 1002 	add	a, r6
      00B79C F9               [12] 1003 	mov	r1,a
      00B79D E4               [12] 1004 	clr	a
      00B79E 3F               [12] 1005 	addc	a,r7
      00B79F FA               [12] 1006 	mov	r2,a
      00B7A0 EB               [12] 1007 	mov	a,r3
      00B7A1 90 C9 A4         [24] 1008 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_624
      00B7A4 93               [24] 1009 	movc	a,@a+dptr
      00B7A5 12 75 67         [24] 1010 	lcall	_ak820_outline_0140
      00B7A8 0B               [12] 1011 	inc	r3
      00B7A9 80 E6            [24] 1012 	sjmp	00133$
      00B7AB                       1013 00104$:
                                   1014 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B7AB 74 0C            [12] 1015 	mov	a,#0x0c
      00B7AD 12 38 24         [24] 1016 	lcall	_ak820_outline_0023
      00B7B0 74 01            [12] 1017 	mov	a,#0x01
      00B7B2 F0               [24] 1018 	movx	@dptr,a
                                   1019 ;	quantum/vial.c:207: break;
      00B7B3 22               [24] 1020 	ret
                                   1021 ;	quantum/vial.c:210: case vial_get_size: {
      00B7B4                       1022 00105$:
                                   1023 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B7B4 12 38 7F         [24] 1024 	lcall	_ak820_outline_0120
      00B7B7 74 7C            [12] 1025 	mov	a,#0x7c
      00B7B9 12 38 69         [24] 1026 	lcall	_ak820_outline_0102
                                   1027 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B7BC 74 01            [12] 1028 	mov	a,#0x01
      00B7BE 12 42 FE         [24] 1029 	lcall	_ak820_outline_0032
                                   1030 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B7C1 E4               [12] 1031 	clr	a
      00B7C2 12 42 FE         [24] 1032 	lcall	_ak820_outline_0032
                                   1033 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B7C5 A3               [24] 1034 	inc	dptr
      00B7C6 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/vial.c:216: break;
      00B7C7 22               [24] 1037 	ret
                                   1038 ;	quantum/vial.c:219: case vial_get_def: {
      00B7C8                       1039 00106$:
                                   1040 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B7C8 12 B5 FD         [24] 1041 	lcall	_ak820_outline_0024
      00B7CB E0               [24] 1042 	movx	a,@dptr
      00B7CC FB               [12] 1043 	mov	r3,a
      00B7CD 12 42 F4         [24] 1044 	lcall	_ak820_outline_0012
      00B7D0 E0               [24] 1045 	movx	a,@dptr
      00B7D1 4B               [12] 1046 	orl	a,r3
      00B7D2 60 01            [24] 1047 	jz	00108$
      00B7D4 22               [24] 1048 	ret
      00B7D5                       1049 00108$:
                                   1050 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B7D5 12 38 2C         [24] 1051 	lcall	_ak820_outline_0037
      00B7D8 FB               [12] 1052 	mov	r3,a
      00B7D9 7A 00            [12] 1053 	mov	r2,#0x00
      00B7DB 12 B5 F4         [24] 1054 	lcall	_ak820_outline_0017
      00B7DE F9               [12] 1055 	mov	r1,a
      00B7DF E4               [12] 1056 	clr	a
      00B7E0 42 03            [12] 1057 	orl	ar3,a
      00B7E2 E9               [12] 1058 	mov	a,r1
      00B7E3 42 02            [12] 1059 	orl	ar2,a
                                   1060 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B7E5 C3               [12] 1061 	clr	c
      00B7E6 EB               [12] 1062 	mov	a,r3
      00B7E7 94 0C            [12] 1063 	subb	a,#0x0c
      00B7E9 EA               [12] 1064 	mov	a,r2
      00B7EA 94 00            [12] 1065 	subb	a,#0x00
      00B7EC 40 01            [24] 1066 	jc	00110$
      00B7EE 22               [24] 1067 	ret
      00B7EF                       1068 00110$:
                                   1069 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B7EF EA               [12] 1070 	mov	a,r2
      00B7F0 C4               [12] 1071 	swap	a
      00B7F1 23               [12] 1072 	rl	a
      00B7F2 54 E0            [12] 1073 	anl	a,#0xe0
      00B7F4 CB               [12] 1074 	xch	a,r3
      00B7F5 C4               [12] 1075 	swap	a
      00B7F6 23               [12] 1076 	rl	a
      00B7F7 CB               [12] 1077 	xch	a,r3
      00B7F8 6B               [12] 1078 	xrl	a,r3
      00B7F9 CB               [12] 1079 	xch	a,r3
      00B7FA 54 E0            [12] 1080 	anl	a,#0xe0
      00B7FC CB               [12] 1081 	xch	a,r3
      00B7FD 6B               [12] 1082 	xrl	a,r3
      00B7FE FA               [12] 1083 	mov	r2,a
      00B7FF 8B 46            [24] 1084 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B801 8A 47            [24] 1085 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1086 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B803 74 7C            [12] 1087 	mov	a,#0x7c
      00B805 C3               [12] 1088 	clr	c
      00B806 95 46            [12] 1089 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B808 F8               [12] 1090 	mov	r0,a
      00B809 74 01            [12] 1091 	mov	a,#0x01
      00B80B 95 47            [12] 1092 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B80D F9               [12] 1093 	mov	r1,a
                                   1094 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B80E C3               [12] 1095 	clr	c
      00B80F E8               [12] 1096 	mov	a,r0
      00B810 94 20            [12] 1097 	subb	a,#0x20
      00B812 E9               [12] 1098 	mov	a,r1
      00B813 94 00            [12] 1099 	subb	a,#0x00
      00B815 40 02            [24] 1100 	jc	00144$
      00B817 78 20            [12] 1101 	mov	r0,#0x20
      00B819                       1102 00144$:
                                   1103 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B819 79 00            [12] 1104 	mov	r1,#0x00
      00B81B                       1105 00136$:
      00B81B C3               [12] 1106 	clr	c
      00B81C E9               [12] 1107 	mov	a,r1
      00B81D 98               [12] 1108 	subb	a,r0
      00B81E 40 01            [24] 1109 	jc	00255$
      00B820 22               [24] 1110 	ret
      00B821                       1111 00255$:
      00B821 C0 00            [24] 1112 	push	ar0
      00B823 E9               [12] 1113 	mov	a,r1
      00B824 2E               [12] 1114 	add	a, r6
      00B825 F5 48            [12] 1115 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B827 E4               [12] 1116 	clr	a
      00B828 3F               [12] 1117 	addc	a, r7
      00B829 F5 49            [12] 1118 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B82B 89 4A            [24] 1119 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B82D 75 4B 00         [24] 1120 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B830 A8 46            [24] 1121 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B832 AB 47            [24] 1122 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B834 E5 4A            [12] 1123 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B836 28               [12] 1124 	add	a, r0
      00B837 F8               [12] 1125 	mov	r0,a
      00B838 E5 4B            [12] 1126 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B83A 3B               [12] 1127 	addc	a, r3
      00B83B FB               [12] 1128 	mov	r3,a
      00B83C E8               [12] 1129 	mov	a,r0
      00B83D 24 28            [12] 1130 	add	a, #_keyboard_definition
      00B83F F5 82            [12] 1131 	mov	dpl,a
      00B841 EB               [12] 1132 	mov	a,r3
      00B842 34 C8            [12] 1133 	addc	a, #(_keyboard_definition >> 8)
      00B844 F5 83            [12] 1134 	mov	dph,a
      00B846 E4               [12] 1135 	clr	a
      00B847 93               [24] 1136 	movc	a,@a+dptr
      00B848 85 48 82         [24] 1137 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B84B 85 49 83         [24] 1138 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B84E F0               [24] 1139 	movx	@dptr,a
      00B84F 09               [12] 1140 	inc	r1
      00B850 D0 00            [24] 1141 	pop	ar0
                                   1142 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B852 80 C7            [24] 1143 	sjmp	00136$
      00B854                       1144 00112$:
                                   1145 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B854 74 02            [12] 1146 	mov	a,#0x02
      00B856 12 51 CB         [24] 1147 	lcall	_ak820_outline_0033
      00B859 F5 4A            [12] 1148 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1149 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B85B 74 03            [12] 1150 	mov	a,#0x03
      00B85D 2E               [12] 1151 	add	a, r6
      00B85E F5 48            [12] 1152 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B860 E4               [12] 1153 	clr	a
      00B861 3F               [12] 1154 	addc	a, r7
      00B862 F5 49            [12] 1155 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B864 85 48 82         [24] 1156 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B867 85 49 83         [24] 1157 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B86A E0               [24] 1158 	movx	a,@dptr
                                   1159 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B86B F5 46            [12] 1160 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B86D 90 0B 92         [24] 1161 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B870 F0               [24] 1162 	movx	@dptr,a
      00B871 90 0B 93         [24] 1163 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B874 E4               [12] 1164 	clr	a
      00B875 F0               [24] 1165 	movx	@dptr,a
      00B876 85 4A 82         [24] 1166 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B879 C0 07            [24] 1167 	push	ar7
      00B87B C0 06            [24] 1168 	push	ar6
      00B87D C0 05            [24] 1169 	push	ar5
      00B87F C0 04            [24] 1170 	push	ar4
      00B881 C0 03            [24] 1171 	push	ar3
      00B883 C0 02            [24] 1172 	push	ar2
      00B885 12 8D 62         [24] 1173 	lcall	_dynamic_keymap_get_encoder
      00B888 85 82 4C         [24] 1174 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B88B 85 83 4D         [24] 1175 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B88E D0 02            [24] 1176 	pop	ar2
      00B890 D0 03            [24] 1177 	pop	ar3
      00B892 D0 04            [24] 1178 	pop	ar4
      00B894 D0 05            [24] 1179 	pop	ar5
      00B896 D0 06            [24] 1180 	pop	ar6
      00B898 D0 07            [24] 1181 	pop	ar7
                                   1182 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B89A A9 4D            [24] 1183 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B89C 12 38 7F         [24] 1184 	lcall	_ak820_outline_0120
      00B89F E9               [12] 1185 	mov	a,r1
      00B8A0 F0               [24] 1186 	movx	@dptr,a
                                   1187 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B8A1 A8 4C            [24] 1188 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B8A3 12 38 8A         [24] 1189 	lcall	_ak820_outline_0126
      00B8A6 E8               [12] 1190 	mov	a,r0
      00B8A7 F0               [24] 1191 	movx	@dptr,a
                                   1192 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B8A8 90 0B 92         [24] 1193 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B8AB E5 46            [12] 1194 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B8AD F0               [24] 1195 	movx	@dptr,a
      00B8AE 90 0B 93         [24] 1196 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B8B1 74 01            [12] 1197 	mov	a,#0x01
      00B8B3 F0               [24] 1198 	movx	@dptr,a
      00B8B4 85 4A 82         [24] 1199 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B8B7 C0 03            [24] 1200 	push	ar3
      00B8B9 C0 02            [24] 1201 	push	ar2
      00B8BB 12 8D 62         [24] 1202 	lcall	_dynamic_keymap_get_encoder
      00B8BE 85 82 4C         [24] 1203 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B8C1 85 83 4D         [24] 1204 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B8C4 D0 02            [24] 1205 	pop	ar2
      00B8C6 D0 03            [24] 1206 	pop	ar3
                                   1207 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B8C8 A9 4D            [24] 1208 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B8CA 12 38 9F         [24] 1209 	lcall	_ak820_outline_0144
      00B8CD E9               [12] 1210 	mov	a,r1
      00B8CE F0               [24] 1211 	movx	@dptr,a
                                   1212 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B8CF A8 4C            [24] 1213 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B8D1 85 48 82         [24] 1214 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B8D4 85 49 83         [24] 1215 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B8D7 E8               [12] 1216 	mov	a,r0
      00B8D8 F0               [24] 1217 	movx	@dptr,a
                                   1218 ;	quantum/vial.c:255: break;
      00B8D9 22               [24] 1219 	ret
                                   1220 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B8DA                       1221 00113$:
                                   1222 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B8DA 12 38 2C         [24] 1223 	lcall	_ak820_outline_0037
      00B8DD F5 48            [12] 1224 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B8DF 12 B5 F4         [24] 1225 	lcall	_ak820_outline_0017
      00B8E2 F5 4A            [12] 1226 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B8E4 12 B5 FD         [24] 1227 	lcall	_ak820_outline_0024
      00B8E7 E0               [24] 1228 	movx	a,@dptr
                                   1229 ;	assignBit
      00B8E8 24 FF            [12] 1230 	add	a,#0xff
      00B8EA E4               [12] 1231 	clr	a
      00B8EB 33               [12] 1232 	rlc	a
      00B8EC F5 4C            [12] 1233 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B8EE 12 42 F4         [24] 1234 	lcall	_ak820_outline_0012
      00B8F1 E0               [24] 1235 	movx	a,@dptr
      00B8F2 F9               [12] 1236 	mov	r1,a
      00B8F3 78 00            [12] 1237 	mov	r0,#0x00
      00B8F5 74 06            [12] 1238 	mov	a,#0x06
      00B8F7 12 38 24         [24] 1239 	lcall	_ak820_outline_0023
      00B8FA E0               [24] 1240 	movx	a,@dptr
      00B8FB 7B 00            [12] 1241 	mov	r3,#0x00
      00B8FD 42 00            [12] 1242 	orl	ar0,a
      00B8FF EB               [12] 1243 	mov	a,r3
      00B900 42 01            [12] 1244 	orl	ar1,a
      00B902 12 38 A9         [24] 1245 	lcall	_ak820_outline_0158
      00B905 12 B6 CF         [24] 1246 	lcall	_vial_keycode_firewall
      00B908 AA 82            [24] 1247 	mov	r2, dpl
      00B90A AB 83            [24] 1248 	mov	r3, dph
      00B90C 90 0B 95         [24] 1249 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B90F E5 4A            [12] 1250 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B911 F0               [24] 1251 	movx	@dptr,a
      00B912 90 0B 96         [24] 1252 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B915 E5 4C            [12] 1253 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B917 F0               [24] 1254 	movx	@dptr,a
      00B918 90 0B 97         [24] 1255 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B91B EA               [12] 1256 	mov	a,r2
      00B91C 12 80 57         [24] 1257 	lcall	_ak820_outline_0188
      00B91F 85 48 82         [24] 1258 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1259 ;	quantum/vial.c:259: break;
      00B922 02 8D C9         [24] 1260 	ljmp	_dynamic_keymap_set_encoder
                                   1261 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B925                       1262 00114$:
                                   1263 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B925 90 0D 1C         [24] 1264 	mov	dptr,#_vial_fill_packet_PARM_2
      00B928 74 FF            [12] 1265 	mov	a,#0xff
      00B92A 12 43 31         [24] 1266 	lcall	_ak820_outline_0068
      00B92D C0 07            [24] 1267 	push	ar7
      00B92F C0 06            [24] 1268 	push	ar6
      00B931 12 B6 F2         [24] 1269 	lcall	_vial_fill_packet
      00B934 D0 06            [24] 1270 	pop	ar6
      00B936 D0 07            [24] 1271 	pop	ar7
                                   1272 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B938 90 0E F4         [24] 1273 	mov	dptr,#_vial_unlocked
      00B93B E0               [24] 1274 	movx	a,@dptr
      00B93C 12 38 7F         [24] 1275 	lcall	_ak820_outline_0120
      00B93F F0               [24] 1276 	movx	@dptr,a
                                   1277 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B940 74 01            [12] 1278 	mov	a,#0x01
      00B942 2E               [12] 1279 	add	a, r6
      00B943 FA               [12] 1280 	mov	r2,a
      00B944 E4               [12] 1281 	clr	a
      00B945 3F               [12] 1282 	addc	a, r7
      00B946 FB               [12] 1283 	mov	r3,a
      00B947 90 0E F5         [24] 1284 	mov	dptr,#_vial_unlock_in_progress
      00B94A E0               [24] 1285 	movx	a,@dptr
      00B94B 12 38 9F         [24] 1286 	lcall	_ak820_outline_0144
      00B94E F0               [24] 1287 	movx	@dptr,a
                                   1288 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B94F 7B 00            [12] 1289 	mov	r3,#0x00
      00B951                       1290 00139$:
      00B951 BB 02 00         [24] 1291 	cjne	r3,#0x02,00256$
      00B954                       1292 00256$:
      00B954 40 01            [24] 1293 	jc	00257$
      00B956 22               [24] 1294 	ret
      00B957                       1295 00257$:
                                   1296 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B957 8B 01            [24] 1297 	mov	ar1,r3
      00B959 7A 00            [12] 1298 	mov	r2,#0x00
      00B95B E9               [12] 1299 	mov	a,r1
      00B95C 29               [12] 1300 	add	a,r1
      00B95D F5 4C            [12] 1301 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B95F EA               [12] 1302 	mov	a,r2
      00B960 33               [12] 1303 	rlc	a
      00B961 F5 4D            [12] 1304 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B963 74 02            [12] 1305 	mov	a,#0x02
      00B965 25 4C            [12] 1306 	add	a, _vial_handle_cmd_sloc3_1_0
      00B967 F8               [12] 1307 	mov	r0,a
      00B968 E4               [12] 1308 	clr	a
      00B969 35 4D            [12] 1309 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B96B FA               [12] 1310 	mov	r2,a
      00B96C E8               [12] 1311 	mov	a,r0
      00B96D 2E               [12] 1312 	add	a, r6
      00B96E F8               [12] 1313 	mov	r0,a
      00B96F EA               [12] 1314 	mov	a,r2
      00B970 3F               [12] 1315 	addc	a, r7
      00B971 FA               [12] 1316 	mov	r2,a
      00B972 EB               [12] 1317 	mov	a,r3
      00B973 12 BC FA         [24] 1318 	lcall	_ak820_outline_0130
      00B976 88 82            [24] 1319 	mov	dpl,r0
      00B978 8A 83            [24] 1320 	mov	dph,r2
      00B97A F0               [24] 1321 	movx	@dptr,a
                                   1322 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B97B 74 03            [12] 1323 	mov	a,#0x03
      00B97D 25 4C            [12] 1324 	add	a, _vial_handle_cmd_sloc3_1_0
      00B97F F9               [12] 1325 	mov	r1,a
      00B980 E4               [12] 1326 	clr	a
      00B981 35 4D            [12] 1327 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B983 FA               [12] 1328 	mov	r2,a
      00B984 E9               [12] 1329 	mov	a,r1
      00B985 2E               [12] 1330 	add	a, r6
      00B986 F9               [12] 1331 	mov	r1,a
      00B987 EA               [12] 1332 	mov	a,r2
      00B988 3F               [12] 1333 	addc	a, r7
      00B989 FA               [12] 1334 	mov	r2,a
      00B98A EB               [12] 1335 	mov	a,r3
      00B98B 12 BC EF         [24] 1336 	lcall	_ak820_outline_0129
      00B98E 12 75 67         [24] 1337 	lcall	_ak820_outline_0140
                                   1338 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B991 0B               [12] 1339 	inc	r3
                                   1340 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B992 80 BD            [24] 1341 	sjmp	00139$
      00B994                       1342 00116$:
                                   1343 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B994 90 0E F5         [24] 1344 	mov	dptr,#_vial_unlock_in_progress
      00B997 E0               [24] 1345 	movx	a,@dptr
      00B998 70 03            [24] 1346 	jnz	00118$
      00B99A 12 B7 17         [24] 1347 	lcall	_vial_release_held_state
      00B99D                       1348 00118$:
                                   1349 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B99D 90 0E F5         [24] 1350 	mov	dptr,#_vial_unlock_in_progress
      00B9A0 74 01            [12] 1351 	mov	a,#0x01
      00B9A2 F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B9A3 90 0E F6         [24] 1354 	mov	dptr,#_vial_unlock_counter
      00B9A6 74 1E            [12] 1355 	mov	a,#0x1e
      00B9A8 F0               [24] 1356 	movx	@dptr,a
                                   1357 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B9A9 90 0D 19         [24] 1358 	mov	dptr,#_vial_unlock_holding
      00B9AC E4               [12] 1359 	clr	a
      00B9AD F0               [24] 1360 	movx	@dptr,a
                                   1361 ;	quantum/vial.c:287: break;
      00B9AE 22               [24] 1362 	ret
                                   1363 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B9AF                       1364 00119$:
                                   1365 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B9AF 90 0E F4         [24] 1366 	mov	dptr,#_vial_unlocked
      00B9B2 E0               [24] 1367 	movx	a,@dptr
      00B9B3 12 38 7F         [24] 1368 	lcall	_ak820_outline_0120
      00B9B6 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B9B7 90 0E F5         [24] 1371 	mov	dptr,#_vial_unlock_in_progress
      00B9BA E0               [24] 1372 	movx	a,@dptr
      00B9BB 12 38 8A         [24] 1373 	lcall	_ak820_outline_0126
      00B9BE F0               [24] 1374 	movx	@dptr,a
                                   1375 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B9BF 74 02            [12] 1376 	mov	a,#0x02
      00B9C1 2E               [12] 1377 	add	a, r6
      00B9C2 FA               [12] 1378 	mov	r2,a
      00B9C3 E4               [12] 1379 	clr	a
      00B9C4 3F               [12] 1380 	addc	a, r7
      00B9C5 FB               [12] 1381 	mov	r3,a
      00B9C6 90 0E F6         [24] 1382 	mov	dptr,#_vial_unlock_counter
      00B9C9 E0               [24] 1383 	movx	a,@dptr
      00B9CA 12 38 9F         [24] 1384 	lcall	_ak820_outline_0144
      00B9CD F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/vial.c:293: break;
      00B9CE 22               [24] 1387 	ret
                                   1388 ;	quantum/vial.c:295: case vial_lock: {
      00B9CF                       1389 00120$:
                                   1390 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B9CF 90 0E F4         [24] 1391 	mov	dptr,#_vial_unlocked
      00B9D2 E4               [12] 1392 	clr	a
      00B9D3 F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B9D4 90 0E F5         [24] 1395 	mov	dptr,#_vial_unlock_in_progress
      00B9D7 F0               [24] 1396 	movx	@dptr,a
                                   1397 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B9D8 90 0D 19         [24] 1398 	mov	dptr,#_vial_unlock_holding
      00B9DB F0               [24] 1399 	movx	@dptr,a
                                   1400 ;	quantum/vial.c:301: break;
      00B9DC 22               [24] 1401 	ret
                                   1402 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B9DD                       1403 00121$:
                                   1404 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B9DD 90 0D 1C         [24] 1405 	mov	dptr,#_vial_fill_packet_PARM_2
      00B9E0 74 FF            [12] 1406 	mov	a,#0xff
      00B9E2 12 43 31         [24] 1407 	lcall	_ak820_outline_0068
                                   1408 ;	quantum/vial.c:314: break;
      00B9E5 02 B6 F2         [24] 1409 	ljmp	_vial_fill_packet
                                   1410 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B9E8                       1411 00122$:
                                   1412 ;	quantum/vial.c:347: switch (msg[2]) {
      00B9E8 12 38 2C         [24] 1413 	lcall	_ak820_outline_0037
      00B9EB FB               [12] 1414 	mov  r3,a
      00B9EC 24 FB            [12] 1415 	add	a,#0xff - 0x04
      00B9EE 50 01            [24] 1416 	jnc	00259$
      00B9F0 22               [24] 1417 	ret
      00B9F1                       1418 00259$:
                                   1419 ;	free result
      00B9F1 EB               [12] 1420 	mov	a,r3
      00B9F2 2B               [12] 1421 	add	a,r3
      00B9F3 2B               [12] 1422 	add	a,r3
      00B9F4 90 B9 F8         [24] 1423 	mov	dptr,#00260$
      00B9F7 73               [24] 1424 	jmp	@a+dptr
      00B9F8                       1425 00260$:
      00B9F8 02 BA 07         [24] 1426 	ljmp	00123$
      00B9FB 02 BA 30         [24] 1427 	ljmp	00124$
      00B9FE 02 BA 92         [24] 1428 	ljmp	00125$
      00BA01 02 BB 1A         [24] 1429 	ljmp	00126$
      00BA04 02 BB 78         [24] 1430 	ljmp	00127$
                                   1431 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00BA07                       1432 00123$:
                                   1433 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00BA07 90 0D 1C         [24] 1434 	mov	dptr,#_vial_fill_packet_PARM_2
      00BA0A E4               [12] 1435 	clr	a
      00BA0B 12 43 31         [24] 1436 	lcall	_ak820_outline_0068
      00BA0E C0 07            [24] 1437 	push	ar7
      00BA10 C0 06            [24] 1438 	push	ar6
      00BA12 12 B6 F2         [24] 1439 	lcall	_vial_fill_packet
      00BA15 D0 06            [24] 1440 	pop	ar6
      00BA17 D0 07            [24] 1441 	pop	ar7
                                   1442 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00BA19 12 38 7F         [24] 1443 	lcall	_ak820_outline_0120
      00BA1C 74 08            [12] 1444 	mov	a,#0x08
      00BA1E 12 43 31         [24] 1445 	lcall	_ak820_outline_0068
                                   1446 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00BA21 A3               [24] 1447 	inc	dptr
      00BA22 12 42 FE         [24] 1448 	lcall	_ak820_outline_0032
                                   1449 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00BA25 E4               [12] 1450 	clr	a
      00BA26 F0               [24] 1451 	movx	@dptr,a
                                   1452 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00BA27 74 1F            [12] 1453 	mov	a,#0x1f
      00BA29 12 38 24         [24] 1454 	lcall	_ak820_outline_0023
      00BA2C 74 01            [12] 1455 	mov	a,#0x01
      00BA2E F0               [24] 1456 	movx	@dptr,a
                                   1457 ;	quantum/vial.c:356: break;
      00BA2F 22               [24] 1458 	ret
                                   1459 ;	quantum/vial.c:359: case dynamic_vial_tap_dance_get: {
      00BA30                       1460 00124$:
                                   1461 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00BA30 12 B5 F4         [24] 1462 	lcall	_ak820_outline_0017
      00BA33 FB               [12] 1463 	mov	r3,a
                                   1464 ;	quantum/vial.c:361: vial_tap_dance_entry_t td = { 0 };
      00BA34 90 0D 23         [24] 1465 	mov	dptr,#_vial_handle_cmd_td_70000_647
      00BA37 12 58 A4         [24] 1466 	lcall	_ak820_outline_0156
      00BA3A 90 0D 25         [24] 1467 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0002)
      00BA3D F0               [24] 1468 	movx	@dptr,a
      00BA3E A3               [24] 1469 	inc	dptr
      00BA3F F0               [24] 1470 	movx	@dptr,a
      00BA40 90 0D 27         [24] 1471 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0004)
      00BA43 F0               [24] 1472 	movx	@dptr,a
      00BA44 A3               [24] 1473 	inc	dptr
      00BA45 F0               [24] 1474 	movx	@dptr,a
      00BA46 90 0D 29         [24] 1475 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0006)
      00BA49 F0               [24] 1476 	movx	@dptr,a
      00BA4A A3               [24] 1477 	inc	dptr
      00BA4B F0               [24] 1478 	movx	@dptr,a
      00BA4C 90 0D 2B         [24] 1479 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0008)
      00BA4F F0               [24] 1480 	movx	@dptr,a
      00BA50 A3               [24] 1481 	inc	dptr
      00BA51 F0               [24] 1482 	movx	@dptr,a
                                   1483 ;	quantum/vial.c:362: msg[0] = dynamic_keymap_get_tap_dance(idx, &td);
      00BA52 90 0B 9A         [24] 1484 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      00BA55 74 23            [12] 1485 	mov	a,#_vial_handle_cmd_td_70000_647
      00BA57 F0               [24] 1486 	movx	@dptr,a
      00BA58 74 0D            [12] 1487 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00BA5A 12 38 51         [24] 1488 	lcall	_ak820_outline_0074
      00BA5D 8B 82            [24] 1489 	mov	dpl, r3
      00BA5F C0 07            [24] 1490 	push	ar7
      00BA61 C0 06            [24] 1491 	push	ar6
      00BA63 C0 05            [24] 1492 	push	ar5
      00BA65 C0 04            [24] 1493 	push	ar4
      00BA67 12 8E 34         [24] 1494 	lcall	_dynamic_keymap_get_tap_dance
      00BA6A AA 82            [24] 1495 	mov	r2, dpl
      00BA6C D0 04            [24] 1496 	pop	ar4
      00BA6E D0 05            [24] 1497 	pop	ar5
      00BA70 D0 06            [24] 1498 	pop	ar6
      00BA72 D0 07            [24] 1499 	pop	ar7
      00BA74 12 38 7F         [24] 1500 	lcall	_ak820_outline_0120
      00BA77 EA               [12] 1501 	mov	a,r2
      00BA78 F0               [24] 1502 	movx	@dptr,a
                                   1503 ;	quantum/vial.c:363: memcpy(&msg[1], &td, sizeof(td));
      00BA79 8C 01            [24] 1504 	mov	ar1,r4
      00BA7B 8D 02            [24] 1505 	mov	ar2,r5
      00BA7D 7B 00            [12] 1506 	mov	r3,#0x00
      00BA7F 90 0E 73         [24] 1507 	mov	dptr,#___memcpy_PARM_2
      00BA82 74 23            [12] 1508 	mov	a,#_vial_handle_cmd_td_70000_647
      00BA84 F0               [24] 1509 	movx	@dptr,a
      00BA85 74 0D            [12] 1510 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00BA87 12 BC BD         [24] 1511 	lcall	_ak820_outline_0008
      00BA8A 12 43 76         [24] 1512 	lcall	_ak820_outline_0171
      00BA8D 8B F0            [24] 1513 	mov	b, r3
                                   1514 ;	quantum/vial.c:364: break;
      00BA8F 02 C2 AA         [24] 1515 	ljmp	___memcpy
                                   1516 ;	quantum/vial.c:366: case dynamic_vial_tap_dance_set: {
      00BA92                       1517 00125$:
                                   1518 ;	quantum/vial.c:367: uint8_t idx = msg[3];
      00BA92 12 B5 F4         [24] 1519 	lcall	_ak820_outline_0017
      00BA95 FB               [12] 1520 	mov	r3,a
                                   1521 ;	quantum/vial.c:369: memcpy(&td, &msg[4], sizeof(td));
      00BA96 74 04            [12] 1522 	mov	a,#0x04
      00BA98 2E               [12] 1523 	add	a, r6
      00BA99 F9               [12] 1524 	mov	r1,a
      00BA9A E4               [12] 1525 	clr	a
      00BA9B 3F               [12] 1526 	addc	a, r7
      00BA9C FA               [12] 1527 	mov	r2,a
      00BA9D 90 0E 73         [24] 1528 	mov	dptr,#___memcpy_PARM_2
      00BAA0 E9               [12] 1529 	mov	a,r1
      00BAA1 F0               [24] 1530 	movx	@dptr,a
      00BAA2 EA               [12] 1531 	mov	a,r2
      00BAA3 12 BC BD         [24] 1532 	lcall	_ak820_outline_0008
      00BAA6 90 0D 2D         [24] 1533 	mov	dptr,#_vial_handle_cmd_td_70000_648
      00BAA9 F5 F0            [12] 1534 	mov	b,a
      00BAAB C0 07            [24] 1535 	push	ar7
      00BAAD C0 06            [24] 1536 	push	ar6
      00BAAF C0 03            [24] 1537 	push	ar3
      00BAB1 12 C2 AA         [24] 1538 	lcall	___memcpy
                                   1539 ;	quantum/vial.c:370: td.on_tap = vial_keycode_firewall(td.on_tap);
      00BAB4 90 0D 2D         [24] 1540 	mov	dptr,#_vial_handle_cmd_td_70000_648
      00BAB7 12 BC E5         [24] 1541 	lcall	_ak820_outline_0043
      00BABA 12 B6 CF         [24] 1542 	lcall	_vial_keycode_firewall
      00BABD 12 B6 32         [24] 1543 	lcall	_ak820_outline_0187
      00BAC0 90 0D 2D         [24] 1544 	mov	dptr,#_vial_handle_cmd_td_70000_648
      00BAC3 12 52 18         [24] 1545 	lcall	_ak820_outline_0100
                                   1546 ;	quantum/vial.c:371: td.on_hold = vial_keycode_firewall(td.on_hold);
      00BAC6 90 0D 2F         [24] 1547 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0002)
      00BAC9 12 BC E5         [24] 1548 	lcall	_ak820_outline_0043
      00BACC 12 B6 CF         [24] 1549 	lcall	_vial_keycode_firewall
      00BACF 12 B6 32         [24] 1550 	lcall	_ak820_outline_0187
      00BAD2 90 0D 2F         [24] 1551 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0002)
      00BAD5 12 52 18         [24] 1552 	lcall	_ak820_outline_0100
                                   1553 ;	quantum/vial.c:372: td.on_double_tap = vial_keycode_firewall(td.on_double_tap);
      00BAD8 90 0D 31         [24] 1554 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0004)
      00BADB 12 BC E5         [24] 1555 	lcall	_ak820_outline_0043
      00BADE 12 B6 CF         [24] 1556 	lcall	_vial_keycode_firewall
      00BAE1 12 B6 32         [24] 1557 	lcall	_ak820_outline_0187
      00BAE4 90 0D 31         [24] 1558 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0004)
      00BAE7 12 52 18         [24] 1559 	lcall	_ak820_outline_0100
                                   1560 ;	quantum/vial.c:373: td.on_tap_hold = vial_keycode_firewall(td.on_tap_hold);
      00BAEA 90 0D 33         [24] 1561 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0006)
      00BAED 12 BC E5         [24] 1562 	lcall	_ak820_outline_0043
      00BAF0 12 B6 CF         [24] 1563 	lcall	_vial_keycode_firewall
      00BAF3 12 B6 32         [24] 1564 	lcall	_ak820_outline_0187
      00BAF6 D0 03            [24] 1565 	pop	ar3
      00BAF8 90 0D 33         [24] 1566 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0006)
      00BAFB 12 52 18         [24] 1567 	lcall	_ak820_outline_0100
                                   1568 ;	quantum/vial.c:374: msg[0] = dynamic_keymap_set_tap_dance(idx, &td);
      00BAFE 90 0B 9E         [24] 1569 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      00BB01 74 2D            [12] 1570 	mov	a,#_vial_handle_cmd_td_70000_648
      00BB03 F0               [24] 1571 	movx	@dptr,a
      00BB04 74 0D            [12] 1572 	mov	a,#(_vial_handle_cmd_td_70000_648 >> 8)
      00BB06 12 38 51         [24] 1573 	lcall	_ak820_outline_0074
      00BB09 8B 82            [24] 1574 	mov	dpl, r3
      00BB0B 12 8E B6         [24] 1575 	lcall	_dynamic_keymap_set_tap_dance
      00BB0E AA 82            [24] 1576 	mov	r2, dpl
      00BB10 D0 06            [24] 1577 	pop	ar6
      00BB12 D0 07            [24] 1578 	pop	ar7
      00BB14 12 38 7F         [24] 1579 	lcall	_ak820_outline_0120
      00BB17 EA               [12] 1580 	mov	a,r2
      00BB18 F0               [24] 1581 	movx	@dptr,a
                                   1582 ;	quantum/vial.c:376: break;
      00BB19 22               [24] 1583 	ret
                                   1584 ;	quantum/vial.c:380: case dynamic_vial_combo_get: {
      00BB1A                       1585 00126$:
                                   1586 ;	quantum/vial.c:381: uint8_t idx = msg[3];
      00BB1A 12 B5 F4         [24] 1587 	lcall	_ak820_outline_0017
      00BB1D FB               [12] 1588 	mov	r3,a
                                   1589 ;	quantum/vial.c:382: vial_combo_entry_t entry = { { 0 }, 0 };
      00BB1E 90 0D 37         [24] 1590 	mov	dptr,#_vial_handle_cmd_entry_70000_649
      00BB21 12 58 A4         [24] 1591 	lcall	_ak820_outline_0156
      00BB24 90 0D 39         [24] 1592 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0002)
      00BB27 F0               [24] 1593 	movx	@dptr,a
      00BB28 A3               [24] 1594 	inc	dptr
      00BB29 F0               [24] 1595 	movx	@dptr,a
      00BB2A 90 0D 3B         [24] 1596 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0004)
      00BB2D F0               [24] 1597 	movx	@dptr,a
      00BB2E A3               [24] 1598 	inc	dptr
      00BB2F F0               [24] 1599 	movx	@dptr,a
      00BB30 90 0D 3D         [24] 1600 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0006)
      00BB33 F0               [24] 1601 	movx	@dptr,a
      00BB34 A3               [24] 1602 	inc	dptr
      00BB35 F0               [24] 1603 	movx	@dptr,a
      00BB36 90 0D 3F         [24] 1604 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0008)
      00BB39 F0               [24] 1605 	movx	@dptr,a
      00BB3A A3               [24] 1606 	inc	dptr
      00BB3B F0               [24] 1607 	movx	@dptr,a
                                   1608 ;	quantum/vial.c:383: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00BB3C 90 0B A2         [24] 1609 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00BB3F 74 37            [12] 1610 	mov	a,#_vial_handle_cmd_entry_70000_649
      00BB41 F0               [24] 1611 	movx	@dptr,a
      00BB42 74 0D            [12] 1612 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00BB44 12 38 51         [24] 1613 	lcall	_ak820_outline_0074
      00BB47 8B 82            [24] 1614 	mov	dpl, r3
      00BB49 C0 07            [24] 1615 	push	ar7
      00BB4B C0 06            [24] 1616 	push	ar6
      00BB4D C0 05            [24] 1617 	push	ar5
      00BB4F C0 04            [24] 1618 	push	ar4
      00BB51 12 8F 55         [24] 1619 	lcall	_dynamic_keymap_get_combo
      00BB54 AA 82            [24] 1620 	mov	r2, dpl
      00BB56 D0 04            [24] 1621 	pop	ar4
      00BB58 D0 05            [24] 1622 	pop	ar5
      00BB5A D0 06            [24] 1623 	pop	ar6
      00BB5C D0 07            [24] 1624 	pop	ar7
      00BB5E 12 38 7F         [24] 1625 	lcall	_ak820_outline_0120
      00BB61 EA               [12] 1626 	mov	a,r2
      00BB62 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	quantum/vial.c:384: memcpy(&msg[1], &entry, sizeof(entry));
      00BB63 7B 00            [12] 1629 	mov	r3,#0x00
      00BB65 90 0E 73         [24] 1630 	mov	dptr,#___memcpy_PARM_2
      00BB68 74 37            [12] 1631 	mov	a,#_vial_handle_cmd_entry_70000_649
      00BB6A F0               [24] 1632 	movx	@dptr,a
      00BB6B 74 0D            [12] 1633 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00BB6D 12 BC BD         [24] 1634 	lcall	_ak820_outline_0008
      00BB70 12 38 8A         [24] 1635 	lcall	_ak820_outline_0126
      00BB73 8B F0            [24] 1636 	mov	b, r3
                                   1637 ;	quantum/vial.c:385: break;
      00BB75 02 C2 AA         [24] 1638 	ljmp	___memcpy
                                   1639 ;	quantum/vial.c:387: case dynamic_vial_combo_set: {
      00BB78                       1640 00127$:
                                   1641 ;	quantum/vial.c:388: uint8_t idx = msg[3];
      00BB78 12 B5 F4         [24] 1642 	lcall	_ak820_outline_0017
      00BB7B FD               [12] 1643 	mov	r5,a
                                   1644 ;	quantum/vial.c:390: memcpy(&entry, &msg[4], sizeof(entry));
      00BB7C 74 04            [12] 1645 	mov	a,#0x04
      00BB7E 2E               [12] 1646 	add	a, r6
      00BB7F FB               [12] 1647 	mov	r3,a
      00BB80 E4               [12] 1648 	clr	a
      00BB81 3F               [12] 1649 	addc	a, r7
      00BB82 FC               [12] 1650 	mov	r4,a
      00BB83 90 0E 73         [24] 1651 	mov	dptr,#___memcpy_PARM_2
      00BB86 EB               [12] 1652 	mov	a,r3
      00BB87 F0               [24] 1653 	movx	@dptr,a
      00BB88 EC               [12] 1654 	mov	a,r4
      00BB89 12 BC BD         [24] 1655 	lcall	_ak820_outline_0008
      00BB8C 90 0D 41         [24] 1656 	mov	dptr,#_vial_handle_cmd_entry_70000_650
      00BB8F F5 F0            [12] 1657 	mov	b,a
      00BB91 C0 07            [24] 1658 	push	ar7
      00BB93 C0 06            [24] 1659 	push	ar6
      00BB95 C0 05            [24] 1660 	push	ar5
      00BB97 12 C2 AA         [24] 1661 	lcall	___memcpy
                                   1662 ;	quantum/vial.c:391: entry.output = vial_keycode_firewall(entry.output);
      00BB9A 90 0D 49         [24] 1663 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00BB9D 12 38 84         [24] 1664 	lcall	_ak820_outline_0125
      00BBA0 12 33 FC         [24] 1665 	lcall	_ak820_outline_0123
      00BBA3 12 B6 CF         [24] 1666 	lcall	_vial_keycode_firewall
      00BBA6 AB 82            [24] 1667 	mov	r3, dpl
      00BBA8 AC 83            [24] 1668 	mov	r4, dph
      00BBAA D0 05            [24] 1669 	pop	ar5
      00BBAC 90 0D 49         [24] 1670 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00BBAF 12 38 63         [24] 1671 	lcall	_ak820_outline_0086
                                   1672 ;	quantum/vial.c:392: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00BBB2 90 0B A6         [24] 1673 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00BBB5 74 41            [12] 1674 	mov	a,#_vial_handle_cmd_entry_70000_650
      00BBB7 F0               [24] 1675 	movx	@dptr,a
      00BBB8 74 0D            [12] 1676 	mov	a,#(_vial_handle_cmd_entry_70000_650 >> 8)
      00BBBA 12 38 51         [24] 1677 	lcall	_ak820_outline_0074
      00BBBD 8D 82            [24] 1678 	mov	dpl, r5
      00BBBF 12 8F EA         [24] 1679 	lcall	_dynamic_keymap_set_combo
      00BBC2 AC 82            [24] 1680 	mov	r4, dpl
      00BBC4 D0 06            [24] 1681 	pop	ar6
      00BBC6 D0 07            [24] 1682 	pop	ar7
      00BBC8 12 38 7F         [24] 1683 	lcall	_ak820_outline_0120
      00BBCB EC               [12] 1684 	mov	a,r4
      00BBCC F0               [24] 1685 	movx	@dptr,a
                                   1686 ;	quantum/vial.c:393: if (!msg[0]) reload_combo();
      00BBCD EC               [12] 1687 	mov	a,r4
      00BBCE 70 03            [24] 1688 	jnz	00141$
                                   1689 ;	quantum/vial.c:419: }
                                   1690 ;	quantum/vial.c:420: }
      00BBD0 02 35 7C         [24] 1691 	ljmp	_ak820_combo_reload
      00BBD3                       1692 00141$:
      00BBD3 22               [24] 1693 	ret
                                   1694 ;------------------------------------------------------------
                                   1695 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1696 ;------------------------------------------------------------
                                   1697 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_652'
                                   1698 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_659'
                                   1699 ;------------------------------------------------------------
                                   1700 ;	quantum/vial.c:424: void vial_keycode_down(uint16_t keycode) {
                                   1701 ;	-----------------------------------------
                                   1702 ;	 function vial_keycode_down
                                   1703 ;	-----------------------------------------
      00BBD4                       1704 _vial_keycode_down:
      00BBD4 12 38 75         [24] 1705 	lcall	_ak820_outline_0108
      00BBD7 90 0D 4D         [24] 1706 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00BBDA 12 38 7A         [24] 1707 	lcall	_ak820_outline_0109
                                   1708 ;	quantum/vial.c:428: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00BBDD 90 0D 4D         [24] 1709 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00BBE0 12 51 8C         [24] 1710 	lcall	_ak820_outline_0009
      00BBE3 74 E0            [12] 1711 	mov	a,#0x100 - 0x20
      00BBE5 2D               [12] 1712 	add	a,r5
      00BBE6 50 19            [24] 1713 	jnc	00104$
      00BBE8 C3               [12] 1714 	clr	c
      00BBE9 74 FF            [12] 1715 	mov	a,#0xff
      00BBEB 9C               [12] 1716 	subb	a,r4
      00BBEC 74 4F            [12] 1717 	mov	a,#0x4f
      00BBEE 9D               [12] 1718 	subb	a,r5
      00BBEF 40 10            [24] 1719 	jc	00104$
                                   1720 ;	free result
                                   1721 ;	quantum/vial.c:429: keycode = (uint8_t)keycode;
      00BBF1 90 0D 4D         [24] 1722 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00BBF4 EE               [12] 1723 	mov	a,r6
      00BBF5 12 38 8F         [24] 1724 	lcall	_ak820_outline_0127
                                   1725 ;	quantum/vial.c:430: if (keycode <= KC_TRANSPARENT) return;
      00BBF8 90 0D 4D         [24] 1726 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00BBFB E0               [24] 1727 	movx	a,@dptr
      00BBFC 24 FE            [12] 1728 	add	a,#0xff - 0x01
      00BBFE 40 01            [24] 1729 	jc	00104$
                                   1730 ;	free result
      00BC00 22               [24] 1731 	ret
      00BC01                       1732 00104$:
                                   1733 ;	quantum/vial.c:433: g_vial_magic_keycode_override = keycode;
      00BC01 90 0D 4D         [24] 1734 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00BC04 12 BC CC         [24] 1735 	lcall	_ak820_outline_0026
                                   1736 ;	quantum/vial.c:435: if (keycode <= QK_MODS_MAX) {
      00BC07 40 06            [24] 1737 	jc	00107$
                                   1738 ;	free result
                                   1739 ;	quantum/vial.c:436: register_code16(keycode);
      00BC09 12 38 7F         [24] 1740 	lcall	_ak820_outline_0120
      00BC0C 02 A7 3B         [24] 1741 	ljmp	_register_code16
      00BC0F                       1742 00107$:
                                   1743 ;	quantum/vial.c:438: keyevent_t dummy_event = {
      00BC0F 90 0D 53         [24] 1744 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0004)
      00BC12 74 01            [12] 1745 	mov	a,#0x01
      00BC14 F0               [24] 1746 	movx	@dptr,a
      00BC15 90 0D 50         [24] 1747 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0001)
      00BC18 74 F0            [12] 1748 	mov	a,#0xf0
      00BC1A F0               [24] 1749 	movx	@dptr,a
      00BC1B 90 0D 4F         [24] 1750 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
      00BC1E F0               [24] 1751 	movx	@dptr,a
      00BC1F 90 0D 54         [24] 1752 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0005)
      00BC22 74 01            [12] 1753 	mov	a,#0x01
      00BC24 F0               [24] 1754 	movx	@dptr,a
      00BC25 12 52 A2         [24] 1755 	lcall	_timer_read
      00BC28 12 43 4F         [24] 1756 	lcall	_ak820_outline_0135
      00BC2B 43 06 01         [24] 1757 	orl	ar6,#0x01
      00BC2E 90 0D 51         [24] 1758 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0002)
      00BC31 12 51 E9         [24] 1759 	lcall	_ak820_outline_0061
                                   1760 ;	quantum/vial.c:442: AK820_ACTION_EXEC(dummy_event);
      00BC34 90 0D 4F         [24] 1761 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
                                   1762 ;	quantum/vial.c:444: }
      00BC37 02 79 A8         [24] 1763 	ljmp	_ak820_action_exec
                                   1764 ;------------------------------------------------------------
                                   1765 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1766 ;------------------------------------------------------------
                                   1767 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_660'
                                   1768 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_667'
                                   1769 ;------------------------------------------------------------
                                   1770 ;	quantum/vial.c:446: void vial_keycode_up(uint16_t keycode) {
                                   1771 ;	-----------------------------------------
                                   1772 ;	 function vial_keycode_up
                                   1773 ;	-----------------------------------------
      00BC3A                       1774 _vial_keycode_up:
      00BC3A 12 38 75         [24] 1775 	lcall	_ak820_outline_0108
      00BC3D 90 0D 55         [24] 1776 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00BC40 12 38 7A         [24] 1777 	lcall	_ak820_outline_0109
                                   1778 ;	quantum/vial.c:450: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00BC43 90 0D 55         [24] 1779 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00BC46 12 51 8C         [24] 1780 	lcall	_ak820_outline_0009
      00BC49 74 E0            [12] 1781 	mov	a,#0x100 - 0x20
      00BC4B 2D               [12] 1782 	add	a,r5
      00BC4C 50 19            [24] 1783 	jnc	00104$
      00BC4E C3               [12] 1784 	clr	c
      00BC4F 74 FF            [12] 1785 	mov	a,#0xff
      00BC51 9C               [12] 1786 	subb	a,r4
      00BC52 74 4F            [12] 1787 	mov	a,#0x4f
      00BC54 9D               [12] 1788 	subb	a,r5
      00BC55 40 10            [24] 1789 	jc	00104$
                                   1790 ;	free result
                                   1791 ;	quantum/vial.c:451: keycode = (uint8_t)keycode;
      00BC57 90 0D 55         [24] 1792 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00BC5A EE               [12] 1793 	mov	a,r6
      00BC5B 12 38 8F         [24] 1794 	lcall	_ak820_outline_0127
                                   1795 ;	quantum/vial.c:452: if (keycode <= KC_TRANSPARENT) return;
      00BC5E 90 0D 55         [24] 1796 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00BC61 E0               [24] 1797 	movx	a,@dptr
      00BC62 24 FE            [12] 1798 	add	a,#0xff - 0x01
      00BC64 40 01            [24] 1799 	jc	00104$
                                   1800 ;	free result
      00BC66 22               [24] 1801 	ret
      00BC67                       1802 00104$:
                                   1803 ;	quantum/vial.c:455: g_vial_magic_keycode_override = keycode;
      00BC67 90 0D 55         [24] 1804 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00BC6A 12 BC CC         [24] 1805 	lcall	_ak820_outline_0026
                                   1806 ;	quantum/vial.c:457: if (keycode <= QK_MODS_MAX) {
      00BC6D 40 06            [24] 1807 	jc	00107$
                                   1808 ;	free result
                                   1809 ;	quantum/vial.c:458: unregister_code16(keycode);
      00BC6F 12 38 7F         [24] 1810 	lcall	_ak820_outline_0120
      00BC72 02 A7 7F         [24] 1811 	ljmp	_unregister_code16
      00BC75                       1812 00107$:
                                   1813 ;	quantum/vial.c:460: keyevent_t dummy_event = {
      00BC75 90 0D 5B         [24] 1814 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0004)
      00BC78 74 01            [12] 1815 	mov	a,#0x01
      00BC7A F0               [24] 1816 	movx	@dptr,a
      00BC7B 90 0D 58         [24] 1817 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0001)
      00BC7E 74 F0            [12] 1818 	mov	a,#0xf0
      00BC80 F0               [24] 1819 	movx	@dptr,a
      00BC81 90 0D 57         [24] 1820 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
      00BC84 F0               [24] 1821 	movx	@dptr,a
      00BC85 90 0D 5C         [24] 1822 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0005)
      00BC88 E4               [12] 1823 	clr	a
      00BC89 F0               [24] 1824 	movx	@dptr,a
      00BC8A 12 52 A2         [24] 1825 	lcall	_timer_read
      00BC8D 12 43 4F         [24] 1826 	lcall	_ak820_outline_0135
      00BC90 43 06 01         [24] 1827 	orl	ar6,#0x01
      00BC93 90 0D 59         [24] 1828 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0002)
      00BC96 12 51 E9         [24] 1829 	lcall	_ak820_outline_0061
                                   1830 ;	quantum/vial.c:464: AK820_ACTION_EXEC(dummy_event);
      00BC99 90 0D 57         [24] 1831 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
                                   1832 ;	quantum/vial.c:466: }
      00BC9C 02 79 A8         [24] 1833 	ljmp	_ak820_action_exec
                                   1834 ;------------------------------------------------------------
                                   1835 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1836 ;------------------------------------------------------------
                                   1837 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_668'
                                   1838 ;i             Allocated with name '_vial_keycode_tap_i_30000_671'
                                   1839 ;------------------------------------------------------------
                                   1840 ;	quantum/vial.c:468: void vial_keycode_tap(uint16_t keycode) {
                                   1841 ;	-----------------------------------------
                                   1842 ;	 function vial_keycode_tap
                                   1843 ;	-----------------------------------------
      00BC9F                       1844 _vial_keycode_tap:
      00BC9F 12 38 75         [24] 1845 	lcall	_ak820_outline_0108
      00BCA2 90 0D 5D         [24] 1846 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00BCA5 12 38 7A         [24] 1847 	lcall	_ak820_outline_0109
                                   1848 ;	quantum/vial.c:469: vial_keycode_down(keycode);
      00BCA8 90 0D 5D         [24] 1849 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00BCAB 12 37 E7         [24] 1850 	lcall	_ak820_outline_0005
      00BCAE C0 07            [24] 1851 	push	ar7
      00BCB0 C0 06            [24] 1852 	push	ar6
      00BCB2 71 D4            [12] 1853 	acall	_vial_keycode_down
      00BCB4 D0 06            [24] 1854 	pop	ar6
      00BCB6 D0 07            [24] 1855 	pop	ar7
                                   1856 ;	quantum/vial.c:471: vial_keycode_up(keycode);
      00BCB8 12 38 7F         [24] 1857 	lcall	_ak820_outline_0120
                                   1858 ;	quantum/vial.c:472: }
      00BCBB 81 3A            [12] 1859 	ajmp	_vial_keycode_up
                                   1860 ;------------------------------------------------------------
                                   1861 ;Allocation info for local variables in function 'process_record_vial'
                                   1862 ;------------------------------------------------------------
                                   1863 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1864 ;keycode       Allocated with name '_process_record_vial_keycode_10000_673'
                                   1865 ;------------------------------------------------------------
                                   1866 ;	quantum/vial.c:682: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1867 ;	-----------------------------------------
                                   1868 	.area CSEG    (CODE)
                                   1869 	.area CONST   (CODE)
                                   1870 	.area CONST   (CODE)
      00C828                       1871 _keyboard_definition:
      00C828 FD                    1872 	.db #0xfd	; 253
      00C829 37                    1873 	.db #0x37	; 55	'7'
      00C82A 7A                    1874 	.db #0x7a	; 122	'z'
      00C82B 58                    1875 	.db #0x58	; 88	'X'
      00C82C 5A                    1876 	.db #0x5a	; 90	'Z'
      00C82D 00                    1877 	.db #0x00	; 0
      00C82E 00                    1878 	.db #0x00	; 0
      00C82F 04                    1879 	.db #0x04	; 4
      00C830 E6                    1880 	.db #0xe6	; 230
      00C831 D6                    1881 	.db #0xd6	; 214
      00C832 B4                    1882 	.db #0xb4	; 180
      00C833 46                    1883 	.db #0x46	; 70	'F'
      00C834 02                    1884 	.db #0x02	; 2
      00C835 00                    1885 	.db #0x00	; 0
      00C836 21                    1886 	.db #0x21	; 33
      00C837 01                    1887 	.db #0x01	; 1
      00C838 00                    1888 	.db #0x00	; 0
      00C839 00                    1889 	.db #0x00	; 0
      00C83A 00                    1890 	.db #0x00	; 0
      00C83B 00                    1891 	.db #0x00	; 0
      00C83C 37                    1892 	.db #0x37	; 55	'7'
      00C83D 27                    1893 	.db #0x27	; 39
      00C83E 97                    1894 	.db #0x97	; 151
      00C83F D6                    1895 	.db #0xd6	; 214
      00C840 E0                    1896 	.db #0xe0	; 224
      00C841 03                    1897 	.db #0x03	; 3
      00C842 CB                    1898 	.db #0xcb	; 203
      00C843 01                    1899 	.db #0x01	; 1
      00C844 3C                    1900 	.db #0x3c	; 60
      00C845 00                    1901 	.db #0x00	; 0
      00C846 00                    1902 	.db #0x00	; 0
      00C847 3D                    1903 	.db #0x3d	; 61
      00C848 88                    1904 	.db #0x88	; 136
      00C849 CD                    1905 	.db #0xcd	; 205
      00C84A A5                    1906 	.db #0xa5	; 165
      00C84B AA                    1907 	.db #0xaa	; 170
      00C84C E5                    1908 	.db #0xe5	; 229
      00C84D A8                    1909 	.db #0xa8	; 168
      00C84E 76                    1910 	.db #0x76	; 118	'v'
      00C84F F6                    1911 	.db #0xf6	; 246
      00C850 43                    1912 	.db #0x43	; 67	'C'
      00C851 0E                    1913 	.db #0x0e	; 14
      00C852 D2                    1914 	.db #0xd2	; 210
      00C853 90                    1915 	.db #0x90	; 144
      00C854 7D                    1916 	.db #0x7d	; 125
      00C855 94                    1917 	.db #0x94	; 148
      00C856 79                    1918 	.db #0x79	; 121	'y'
      00C857 78                    1919 	.db #0x78	; 120	'x'
      00C858 EF                    1920 	.db #0xef	; 239
      00C859 49                    1921 	.db #0x49	; 73	'I'
      00C85A 3E                    1922 	.db #0x3e	; 62
      00C85B EF                    1923 	.db #0xef	; 239
      00C85C FD                    1924 	.db #0xfd	; 253
      00C85D 8F                    1925 	.db #0x8f	; 143
      00C85E EF                    1926 	.db #0xef	; 239
      00C85F 00                    1927 	.db #0x00	; 0
      00C860 C6                    1928 	.db #0xc6	; 198
      00C861 D1                    1929 	.db #0xd1	; 209
      00C862 DB                    1930 	.db #0xdb	; 219
      00C863 FB                    1931 	.db #0xfb	; 251
      00C864 EB                    1932 	.db #0xeb	; 235
      00C865 DE                    1933 	.db #0xde	; 222
      00C866 66                    1934 	.db #0x66	; 102	'f'
      00C867 63                    1935 	.db #0x63	; 99	'c'
      00C868 0C                    1936 	.db #0x0c	; 12
      00C869 92                    1937 	.db #0x92	; 146
      00C86A 7B                    1938 	.db #0x7b	; 123
      00C86B F9                    1939 	.db #0xf9	; 249
      00C86C D4                    1940 	.db #0xd4	; 212
      00C86D 7A                    1941 	.db #0x7a	; 122	'z'
      00C86E 4F                    1942 	.db #0x4f	; 79	'O'
      00C86F 83                    1943 	.db #0x83	; 131
      00C870 4B                    1944 	.db #0x4b	; 75	'K'
      00C871 86                    1945 	.db #0x86	; 134
      00C872 0E                    1946 	.db #0x0e	; 14
      00C873 6A                    1947 	.db #0x6a	; 106	'j'
      00C874 F2                    1948 	.db #0xf2	; 242
      00C875 22                    1949 	.db #0x22	; 34
      00C876 22                    1950 	.db #0x22	; 34
      00C877 0B                    1951 	.db #0x0b	; 11
      00C878 03                    1952 	.db #0x03	; 3
      00C879 BA                    1953 	.db #0xba	; 186
      00C87A 67                    1954 	.db #0x67	; 103	'g'
      00C87B 9B                    1955 	.db #0x9b	; 155
      00C87C 7A                    1956 	.db #0x7a	; 122	'z'
      00C87D E1                    1957 	.db #0xe1	; 225
      00C87E BC                    1958 	.db #0xbc	; 188
      00C87F 37                    1959 	.db #0x37	; 55	'7'
      00C880 26                    1960 	.db #0x26	; 38
      00C881 46                    1961 	.db #0x46	; 70	'F'
      00C882 78                    1962 	.db #0x78	; 120	'x'
      00C883 05                    1963 	.db #0x05	; 5
      00C884 0D                    1964 	.db #0x0d	; 13
      00C885 95                    1965 	.db #0x95	; 149
      00C886 02                    1966 	.db #0x02	; 2
      00C887 E4                    1967 	.db #0xe4	; 228
      00C888 18                    1968 	.db #0x18	; 24
      00C889 CA                    1969 	.db #0xca	; 202
      00C88A 33                    1970 	.db #0x33	; 51	'3'
      00C88B EA                    1971 	.db #0xea	; 234
      00C88C 24                    1972 	.db #0x24	; 36
      00C88D C8                    1973 	.db #0xc8	; 200
      00C88E 81                    1974 	.db #0x81	; 129
      00C88F 4E                    1975 	.db #0x4e	; 78	'N'
      00C890 47                    1976 	.db #0x47	; 71	'G'
      00C891 A8                    1977 	.db #0xa8	; 168
      00C892 44                    1978 	.db #0x44	; 68	'D'
      00C893 DD                    1979 	.db #0xdd	; 221
      00C894 91                    1980 	.db #0x91	; 145
      00C895 6D                    1981 	.db #0x6d	; 109	'm'
      00C896 69                    1982 	.db #0x69	; 105	'i'
      00C897 DB                    1983 	.db #0xdb	; 219
      00C898 4F                    1984 	.db #0x4f	; 79	'O'
      00C899 3A                    1985 	.db #0x3a	; 58
      00C89A 43                    1986 	.db #0x43	; 67	'C'
      00C89B 9D                    1987 	.db #0x9d	; 157
      00C89C 26                    1988 	.db #0x26	; 38
      00C89D 49                    1989 	.db #0x49	; 73	'I'
      00C89E 4C                    1990 	.db #0x4c	; 76	'L'
      00C89F EF                    1991 	.db #0xef	; 239
      00C8A0 2B                    1992 	.db #0x2b	; 43
      00C8A1 D8                    1993 	.db #0xd8	; 216
      00C8A2 55                    1994 	.db #0x55	; 85	'U'
      00C8A3 95                    1995 	.db #0x95	; 149
      00C8A4 70                    1996 	.db #0x70	; 112	'p'
      00C8A5 B1                    1997 	.db #0xb1	; 177
      00C8A6 CC                    1998 	.db #0xcc	; 204
      00C8A7 CF                    1999 	.db #0xcf	; 207
      00C8A8 13                    2000 	.db #0x13	; 19
      00C8A9 32                    2001 	.db #0x32	; 50	'2'
      00C8AA 6A                    2002 	.db #0x6a	; 106	'j'
      00C8AB A1                    2003 	.db #0xa1	; 161
      00C8AC FF                    2004 	.db #0xff	; 255
      00C8AD 99                    2005 	.db #0x99	; 153
      00C8AE 61                    2006 	.db #0x61	; 97	'a'
      00C8AF 95                    2007 	.db #0x95	; 149
      00C8B0 B1                    2008 	.db #0xb1	; 177
      00C8B1 89                    2009 	.db #0x89	; 137
      00C8B2 9B                    2010 	.db #0x9b	; 155
      00C8B3 11                    2011 	.db #0x11	; 17
      00C8B4 D9                    2012 	.db #0xd9	; 217
      00C8B5 35                    2013 	.db #0x35	; 53	'5'
      00C8B6 78                    2014 	.db #0x78	; 120	'x'
      00C8B7 ED                    2015 	.db #0xed	; 237
      00C8B8 CD                    2016 	.db #0xcd	; 205
      00C8B9 94                    2017 	.db #0x94	; 148
      00C8BA 6E                    2018 	.db #0x6e	; 110	'n'
      00C8BB 60                    2019 	.db #0x60	; 96
      00C8BC 8E                    2020 	.db #0x8e	; 142
      00C8BD 63                    2021 	.db #0x63	; 99	'c'
      00C8BE 8B                    2022 	.db #0x8b	; 139
      00C8BF FF                    2023 	.db #0xff	; 255
      00C8C0 4E                    2024 	.db #0x4e	; 78	'N'
      00C8C1 20                    2025 	.db #0x20	; 32
      00C8C2 7A                    2026 	.db #0x7a	; 122	'z'
      00C8C3 B5                    2027 	.db #0xb5	; 181
      00C8C4 87                    2028 	.db #0x87	; 135
      00C8C5 C2                    2029 	.db #0xc2	; 194
      00C8C6 35                    2030 	.db #0x35	; 53	'5'
      00C8C7 A4                    2031 	.db #0xa4	; 164
      00C8C8 6D                    2032 	.db #0x6d	; 109	'm'
      00C8C9 18                    2033 	.db #0x18	; 24
      00C8CA C1                    2034 	.db #0xc1	; 193
      00C8CB A3                    2035 	.db #0xa3	; 163
      00C8CC DB                    2036 	.db #0xdb	; 219
      00C8CD 53                    2037 	.db #0x53	; 83	'S'
      00C8CE 1D                    2038 	.db #0x1d	; 29
      00C8CF EC                    2039 	.db #0xec	; 236
      00C8D0 F0                    2040 	.db #0xf0	; 240
      00C8D1 BF                    2041 	.db #0xbf	; 191
      00C8D2 4A                    2042 	.db #0x4a	; 74	'J'
      00C8D3 4C                    2043 	.db #0x4c	; 76	'L'
      00C8D4 4A                    2044 	.db #0x4a	; 74	'J'
      00C8D5 C4                    2045 	.db #0xc4	; 196
      00C8D6 AA                    2046 	.db #0xaa	; 170
      00C8D7 37                    2047 	.db #0x37	; 55	'7'
      00C8D8 19                    2048 	.db #0x19	; 25
      00C8D9 34                    2049 	.db #0x34	; 52	'4'
      00C8DA 3F                    2050 	.db #0x3f	; 63
      00C8DB A1                    2051 	.db #0xa1	; 161
      00C8DC D3                    2052 	.db #0xd3	; 211
      00C8DD 1A                    2053 	.db #0x1a	; 26
      00C8DE 5C                    2054 	.db #0x5c	; 92
      00C8DF 03                    2055 	.db #0x03	; 3
      00C8E0 4D                    2056 	.db #0x4d	; 77	'M'
      00C8E1 BC                    2057 	.db #0xbc	; 188
      00C8E2 10                    2058 	.db #0x10	; 16
      00C8E3 2E                    2059 	.db #0x2e	; 46
      00C8E4 80                    2060 	.db #0x80	; 128
      00C8E5 F7                    2061 	.db #0xf7	; 247
      00C8E6 D6                    2062 	.db #0xd6	; 214
      00C8E7 82                    2063 	.db #0x82	; 130
      00C8E8 24                    2064 	.db #0x24	; 36
      00C8E9 4C                    2065 	.db #0x4c	; 76	'L'
      00C8EA 87                    2066 	.db #0x87	; 135
      00C8EB B9                    2067 	.db #0xb9	; 185
      00C8EC F8                    2068 	.db #0xf8	; 248
      00C8ED BE                    2069 	.db #0xbe	; 190
      00C8EE 67                    2070 	.db #0x67	; 103	'g'
      00C8EF 96                    2071 	.db #0x96	; 150
      00C8F0 89                    2072 	.db #0x89	; 137
      00C8F1 30                    2073 	.db #0x30	; 48	'0'
      00C8F2 C8                    2074 	.db #0xc8	; 200
      00C8F3 8D                    2075 	.db #0x8d	; 141
      00C8F4 2C                    2076 	.db #0x2c	; 44
      00C8F5 F5                    2077 	.db #0xf5	; 245
      00C8F6 06                    2078 	.db #0x06	; 6
      00C8F7 05                    2079 	.db #0x05	; 5
      00C8F8 7C                    2080 	.db #0x7c	; 124
      00C8F9 48                    2081 	.db #0x48	; 72	'H'
      00C8FA 1B                    2082 	.db #0x1b	; 27
      00C8FB 76                    2083 	.db #0x76	; 118	'v'
      00C8FC AA                    2084 	.db #0xaa	; 170
      00C8FD 3D                    2085 	.db #0x3d	; 61
      00C8FE 28                    2086 	.db #0x28	; 40
      00C8FF FC                    2087 	.db #0xfc	; 252
      00C900 80                    2088 	.db #0x80	; 128
      00C901 75                    2089 	.db #0x75	; 117	'u'
      00C902 EB                    2090 	.db #0xeb	; 235
      00C903 78                    2091 	.db #0x78	; 120	'x'
      00C904 D0                    2092 	.db #0xd0	; 208
      00C905 8A                    2093 	.db #0x8a	; 138
      00C906 8F                    2094 	.db #0x8f	; 143
      00C907 27                    2095 	.db #0x27	; 39
      00C908 F7                    2096 	.db #0xf7	; 247
      00C909 F2                    2097 	.db #0xf2	; 242
      00C90A EB                    2098 	.db #0xeb	; 235
      00C90B 58                    2099 	.db #0x58	; 88	'X'
      00C90C 37                    2100 	.db #0x37	; 55	'7'
      00C90D 3C                    2101 	.db #0x3c	; 60
      00C90E 2B                    2102 	.db #0x2b	; 43
      00C90F 6F                    2103 	.db #0x6f	; 111	'o'
      00C910 0E                    2104 	.db #0x0e	; 14
      00C911 C7                    2105 	.db #0xc7	; 199
      00C912 E2                    2106 	.db #0xe2	; 226
      00C913 A0                    2107 	.db #0xa0	; 160
      00C914 97                    2108 	.db #0x97	; 151
      00C915 EE                    2109 	.db #0xee	; 238
      00C916 FD                    2110 	.db #0xfd	; 253
      00C917 9F                    2111 	.db #0x9f	; 159
      00C918 45                    2112 	.db #0x45	; 69	'E'
      00C919 17                    2113 	.db #0x17	; 23
      00C91A 94                    2114 	.db #0x94	; 148
      00C91B E6                    2115 	.db #0xe6	; 230
      00C91C E7                    2116 	.db #0xe7	; 231
      00C91D FA                    2117 	.db #0xfa	; 250
      00C91E 4C                    2118 	.db #0x4c	; 76	'L'
      00C91F 7A                    2119 	.db #0x7a	; 122	'z'
      00C920 D6                    2120 	.db #0xd6	; 214
      00C921 7A                    2121 	.db #0x7a	; 122	'z'
      00C922 7B                    2122 	.db #0x7b	; 123
      00C923 ED                    2123 	.db #0xed	; 237
      00C924 10                    2124 	.db #0x10	; 16
      00C925 C5                    2125 	.db #0xc5	; 197
      00C926 BC                    2126 	.db #0xbc	; 188
      00C927 E3                    2127 	.db #0xe3	; 227
      00C928 A9                    2128 	.db #0xa9	; 169
      00C929 1F                    2129 	.db #0x1f	; 31
      00C92A CF                    2130 	.db #0xcf	; 207
      00C92B C4                    2131 	.db #0xc4	; 196
      00C92C 9D                    2132 	.db #0x9d	; 157
      00C92D DC                    2133 	.db #0xdc	; 220
      00C92E 45                    2134 	.db #0x45	; 69	'E'
      00C92F 2A                    2135 	.db #0x2a	; 42
      00C930 69                    2136 	.db #0x69	; 105	'i'
      00C931 57                    2137 	.db #0x57	; 87	'W'
      00C932 8F                    2138 	.db #0x8f	; 143
      00C933 EC                    2139 	.db #0xec	; 236
      00C934 85                    2140 	.db #0x85	; 133
      00C935 6C                    2141 	.db #0x6c	; 108	'l'
      00C936 43                    2142 	.db #0x43	; 67	'C'
      00C937 1C                    2143 	.db #0x1c	; 28
      00C938 BA                    2144 	.db #0xba	; 186
      00C939 89                    2145 	.db #0x89	; 137
      00C93A 68                    2146 	.db #0x68	; 104	'h'
      00C93B 4A                    2147 	.db #0x4a	; 74	'J'
      00C93C 1C                    2148 	.db #0x1c	; 28
      00C93D 91                    2149 	.db #0x91	; 145
      00C93E 3F                    2150 	.db #0x3f	; 63
      00C93F D1                    2151 	.db #0xd1	; 209
      00C940 B3                    2152 	.db #0xb3	; 179
      00C941 96                    2153 	.db #0x96	; 150
      00C942 1D                    2154 	.db #0x1d	; 29
      00C943 7C                    2155 	.db #0x7c	; 124
      00C944 14                    2156 	.db #0x14	; 20
      00C945 77                    2157 	.db #0x77	; 119	'w'
      00C946 9C                    2158 	.db #0x9c	; 156
      00C947 74                    2159 	.db #0x74	; 116	't'
      00C948 36                    2160 	.db #0x36	; 54	'6'
      00C949 FF                    2161 	.db #0xff	; 255
      00C94A 2C                    2162 	.db #0x2c	; 44
      00C94B 66                    2163 	.db #0x66	; 102	'f'
      00C94C AF                    2164 	.db #0xaf	; 175
      00C94D 0F                    2165 	.db #0x0f	; 15
      00C94E 3C                    2166 	.db #0x3c	; 60
      00C94F A2                    2167 	.db #0xa2	; 162
      00C950 23                    2168 	.db #0x23	; 35
      00C951 85                    2169 	.db #0x85	; 133
      00C952 05                    2170 	.db #0x05	; 5
      00C953 87                    2171 	.db #0x87	; 135
      00C954 DA                    2172 	.db #0xda	; 218
      00C955 61                    2173 	.db #0x61	; 97	'a'
      00C956 5E                    2174 	.db #0x5e	; 94
      00C957 42                    2175 	.db #0x42	; 66	'B'
      00C958 54                    2176 	.db #0x54	; 84	'T'
      00C959 60                    2177 	.db #0x60	; 96
      00C95A 23                    2178 	.db #0x23	; 35
      00C95B CA                    2179 	.db #0xca	; 202
      00C95C BC                    2180 	.db #0xbc	; 188
      00C95D B3                    2181 	.db #0xb3	; 179
      00C95E 18                    2182 	.db #0x18	; 24
      00C95F 1D                    2183 	.db #0x1d	; 29
      00C960 F8                    2184 	.db #0xf8	; 248
      00C961 0A                    2185 	.db #0x0a	; 10
      00C962 55                    2186 	.db #0x55	; 85	'U'
      00C963 CD                    2187 	.db #0xcd	; 205
      00C964 A3                    2188 	.db #0xa3	; 163
      00C965 DE                    2189 	.db #0xde	; 222
      00C966 FF                    2190 	.db #0xff	; 255
      00C967 B2                    2191 	.db #0xb2	; 178
      00C968 2A                    2192 	.db #0x2a	; 42
      00C969 35                    2193 	.db #0x35	; 53	'5'
      00C96A 00                    2194 	.db #0x00	; 0
      00C96B D6                    2195 	.db #0xd6	; 214
      00C96C 7B                    2196 	.db #0x7b	; 123
      00C96D E8                    2197 	.db #0xe8	; 232
      00C96E F2                    2198 	.db #0xf2	; 242
      00C96F 1A                    2199 	.db #0x1a	; 26
      00C970 BC                    2200 	.db #0xbc	; 188
      00C971 F5                    2201 	.db #0xf5	; 245
      00C972 7E                    2202 	.db #0x7e	; 126
      00C973 48                    2203 	.db #0x48	; 72	'H'
      00C974 72                    2204 	.db #0x72	; 114	'r'
      00C975 E0                    2205 	.db #0xe0	; 224
      00C976 E4                    2206 	.db #0xe4	; 228
      00C977 E0                    2207 	.db #0xe0	; 224
      00C978 27                    2208 	.db #0x27	; 39
      00C979 87                    2209 	.db #0x87	; 135
      00C97A 9A                    2210 	.db #0x9a	; 154
      00C97B 51                    2211 	.db #0x51	; 81	'Q'
      00C97C D4                    2212 	.db #0xd4	; 212
      00C97D DD                    2213 	.db #0xdd	; 221
      00C97E C3                    2214 	.db #0xc3	; 195
      00C97F AA                    2215 	.db #0xaa	; 170
      00C980 49                    2216 	.db #0x49	; 73	'I'
      00C981 5A                    2217 	.db #0x5a	; 90	'Z'
      00C982 2A                    2218 	.db #0x2a	; 42
      00C983 00                    2219 	.db #0x00	; 0
      00C984 A0                    2220 	.db #0xa0	; 160
      00C985 8C                    2221 	.db #0x8c	; 140
      00C986 FF                    2222 	.db #0xff	; 255
      00C987 74                    2223 	.db #0x74	; 116	't'
      00C988 BF                    2224 	.db #0xbf	; 191
      00C989 EC                    2225 	.db #0xec	; 236
      00C98A 1D                    2226 	.db #0x1d	; 29
      00C98B F1                    2227 	.db #0xf1	; 241
      00C98C 00                    2228 	.db #0x00	; 0
      00C98D 01                    2229 	.db #0x01	; 1
      00C98E D8                    2230 	.db #0xd8	; 216
      00C98F 02                    2231 	.db #0x02	; 2
      00C990 CC                    2232 	.db #0xcc	; 204
      00C991 07                    2233 	.db #0x07	; 7
      00C992 00                    2234 	.db #0x00	; 0
      00C993 00                    2235 	.db #0x00	; 0
      00C994 C4                    2236 	.db #0xc4	; 196
      00C995 5E                    2237 	.db #0x5e	; 94
      00C996 2C                    2238 	.db #0x2c	; 44
      00C997 7E                    2239 	.db #0x7e	; 126
      00C998 B1                    2240 	.db #0xb1	; 177
      00C999 C4                    2241 	.db #0xc4	; 196
      00C99A 67                    2242 	.db #0x67	; 103	'g'
      00C99B FB                    2243 	.db #0xfb	; 251
      00C99C 02                    2244 	.db #0x02	; 2
      00C99D 00                    2245 	.db #0x00	; 0
      00C99E 00                    2246 	.db #0x00	; 0
      00C99F 00                    2247 	.db #0x00	; 0
      00C9A0 00                    2248 	.db #0x00	; 0
      00C9A1 04                    2249 	.db #0x04	; 4
      00C9A2 59                    2250 	.db #0x59	; 89	'Y'
      00C9A3 5A                    2251 	.db #0x5a	; 90	'Z'
                                   2252 	.area CSEG    (CODE)
                                   2253 	.area CONST   (CODE)
      00C9A4                       2254 _vial_handle_cmd_keyboard_uid_40000_624:
      00C9A4 04                    2255 	.db #0x04	; 4
      00C9A5 70                    2256 	.db #0x70	; 112	'p'
      00C9A6 FF                    2257 	.db #0xff	; 255
      00C9A7 90                    2258 	.db #0x90	; 144
      00C9A8 01                    2259 	.db #0x01	; 1
      00C9A9 B9                    2260 	.db #0xb9	; 185
      00C9AA 15                    2261 	.db #0x15	; 21
      00C9AB D3                    2262 	.db #0xd3	; 211
                                   2263 	.area CSEG    (CODE)
                                   2264 	.area XINIT   (CODE)
      00CBDB                       2265 __xinit__vial_unlocked:
      00CBDB 00                    2266 	.db #0x00	;  0
      00CBDC                       2267 __xinit__vial_unlock_in_progress:
      00CBDC 00                    2268 	.db #0x00	;  0
      00CBDD                       2269 __xinit__vial_unlock_counter:
      00CBDD 00                    2270 	.db #0x00	; 0
      00CBDE                       2271 __xinit__vial_unlock_combo_rows:
      00CBDE 00                    2272 	.db #0x00	; 0
      00CBDF 00                    2273 	.db #0x00	; 0
      00CBE0                       2274 __xinit__vial_unlock_combo_cols:
      00CBE0 00                    2275 	.db #0x00	; 0
      00CBE1 05                    2276 	.db #0x05	; 5
                                   2277 	.area CABS    (ABS,CODE)
                                   2278 
                                   2279 ; Experimental exact instruction outlining.
                                   2280 	.globl _ak820_outline_0005
                                   2281 	.globl _ak820_outline_0006
                                   2282 	.globl _ak820_outline_0008
                                   2283 	.globl _ak820_outline_0009
                                   2284 	.globl _ak820_outline_0012
                                   2285 	.globl _ak820_outline_0017
                                   2286 	.globl _ak820_outline_0019
                                   2287 	.globl _ak820_outline_0023
                                   2288 	.globl _ak820_outline_0024
                                   2289 	.globl _ak820_outline_0026
                                   2290 	.globl _ak820_outline_0032
                                   2291 	.globl _ak820_outline_0033
                                   2292 	.globl _ak820_outline_0034
                                   2293 	.globl _ak820_outline_0037
                                   2294 	.globl _ak820_outline_0038
                                   2295 	.globl _ak820_outline_0043
                                   2296 	.globl _ak820_outline_0054
                                   2297 	.globl _ak820_outline_0057
                                   2298 	.globl _ak820_outline_0059
                                   2299 	.globl _ak820_outline_0061
                                   2300 	.globl _ak820_outline_0068
                                   2301 	.globl _ak820_outline_0074
                                   2302 	.globl _ak820_outline_0086
                                   2303 	.globl _ak820_outline_0100
                                   2304 	.globl _ak820_outline_0102
                                   2305 	.globl _ak820_outline_0108
                                   2306 	.globl _ak820_outline_0109
                                   2307 	.globl _ak820_outline_0120
                                   2308 	.globl _ak820_outline_0123
                                   2309 	.globl _ak820_outline_0125
                                   2310 	.globl _ak820_outline_0126
                                   2311 	.globl _ak820_outline_0127
                                   2312 	.globl _ak820_outline_0129
                                   2313 	.globl _ak820_outline_0130
                                   2314 	.globl _ak820_outline_0135
                                   2315 	.globl _ak820_outline_0140
                                   2316 	.globl _ak820_outline_0144
                                   2317 	.globl _ak820_outline_0156
                                   2318 	.globl _ak820_outline_0158
                                   2319 	.globl _ak820_outline_0171
                                   2320 	.globl _ak820_outline_0187
                                   2321 	.globl _ak820_outline_0188
                                   2322 
                                   2323 	.area CSEG (CODE)
                                   2324 ; function ak820_outline_0008
      00BCBD                       2325 _ak820_outline_0008:
      00BCBD A3               [24] 2326 	inc	dptr
      00BCBE F0               [24] 2327 	movx	@dptr,a
      00BCBF E4               [12] 2328 	clr	a
      00BCC0 A3               [24] 2329 	inc	dptr
      00BCC1 F0               [24] 2330 	movx	@dptr,a
      00BCC2 90 0E 76         [24] 2331 	mov	dptr,#___memcpy_PARM_3
      00BCC5 74 0A            [12] 2332 	mov	a,#0x0a
      00BCC7 F0               [24] 2333 	movx	@dptr,a
      00BCC8 E4               [12] 2334 	clr	a
      00BCC9 A3               [24] 2335 	inc	dptr
      00BCCA F0               [24] 2336 	movx	@dptr,a
      00BCCB 22               [24] 2337 	ret
                                   2338 
                                   2339 	.area CSEG (CODE)
                                   2340 ; function ak820_outline_0026
      00BCCC                       2341 _ak820_outline_0026:
      00BCCC E0               [24] 2342 	movx	a,@dptr
      00BCCD FE               [12] 2343 	mov	r6,a
      00BCCE A3               [24] 2344 	inc	dptr
      00BCCF E0               [24] 2345 	movx	a,@dptr
      00BCD0 FF               [12] 2346 	mov	r7,a
      00BCD1 90 0D 4B         [24] 2347 	mov	dptr,#_g_vial_magic_keycode_override
      00BCD4 EE               [12] 2348 	mov	a,r6
      00BCD5 F0               [24] 2349 	movx	@dptr,a
      00BCD6 EF               [12] 2350 	mov	a,r7
      00BCD7 A3               [24] 2351 	inc	dptr
      00BCD8 F0               [24] 2352 	movx	@dptr,a
      00BCD9 8E 04            [24] 2353 	mov	ar4,r6
      00BCDB 8F 05            [24] 2354 	mov	ar5,r7
      00BCDD C3               [12] 2355 	clr	c
      00BCDE 74 FF            [12] 2356 	mov	a,#0xff
      00BCE0 9C               [12] 2357 	subb	a,r4
      00BCE1 74 1F            [12] 2358 	mov	a,#0x1f
      00BCE3 9D               [12] 2359 	subb	a,r5
      00BCE4 22               [24] 2360 	ret
                                   2361 
                                   2362 	.area CSEG (CODE)
                                   2363 ; function ak820_outline_0043
      00BCE5                       2364 _ak820_outline_0043:
      00BCE5 E0               [24] 2365 	movx	a,@dptr
      00BCE6 F9               [12] 2366 	mov	r1,a
      00BCE7 A3               [24] 2367 	inc	dptr
      00BCE8 E0               [24] 2368 	movx	a,@dptr
      00BCE9 FA               [12] 2369 	mov	r2,a
      00BCEA 89 82            [24] 2370 	mov	dpl,r1
      00BCEC 8A 83            [24] 2371 	mov	dph,r2
      00BCEE 22               [24] 2372 	ret
                                   2373 
                                   2374 	.area CSEG (CODE)
                                   2375 ; function ak820_outline_0129
      00BCEF                       2376 _ak820_outline_0129:
      00BCEF 24 F9            [12] 2377 	add	a,#_vial_unlock_combo_cols
      00BCF1 F5 82            [12] 2378 	mov	dpl,a
      00BCF3 E4               [12] 2379 	clr	a
      00BCF4 34 0E            [12] 2380 	addc	a,#(_vial_unlock_combo_cols>>8)
      00BCF6 F5 83            [12] 2381 	mov	dph,a
      00BCF8 E0               [24] 2382 	movx	a,@dptr
      00BCF9 22               [24] 2383 	ret
                                   2384 
                                   2385 	.area CSEG (CODE)
                                   2386 ; function ak820_outline_0130
      00BCFA                       2387 _ak820_outline_0130:
      00BCFA 24 F7            [12] 2388 	add	a,#_vial_unlock_combo_rows
      00BCFC F5 82            [12] 2389 	mov	dpl,a
      00BCFE E4               [12] 2390 	clr	a
      00BCFF 34 0E            [12] 2391 	addc	a,#(_vial_unlock_combo_rows>>8)
      00BD01 F5 83            [12] 2392 	mov	dph,a
      00BD03 E0               [24] 2393 	movx	a,@dptr
      00BD04 22               [24] 2394 	ret
