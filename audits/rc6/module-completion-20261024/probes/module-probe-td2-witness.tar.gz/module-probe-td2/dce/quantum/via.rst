                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      00003C                        553 _raw_hid_receive_sloc0_1_0:
      00003C                        554 	.ds 4
      000040                        555 _raw_hid_receive_sloc1_1_0:
      000040                        556 	.ds 1
      000041                        557 _raw_hid_receive_sloc2_1_0:
      000041                        558 	.ds 1
      000042                        559 _raw_hid_receive_sloc3_1_0:
      000042                        560 	.ds 2
      000044                        561 _raw_hid_receive_sloc4_1_0:
      000044                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002C                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002C                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000D03                        589 _via_eeprom_set_valid_valid_10000_611:
      000D03                        590 	.ds 1
      000D04                        591 _via_set_layout_options_value_10000_627:
      000D04                        592 	.ds 4
      000D08                        593 _process_record_via_PARM_2:
      000D08                        594 	.ds 3
      000D0B                        595 _process_record_via_keycode_10000_629:
      000D0B                        596 	.ds 2
      000D0D                        597 _raw_hid_receive_kb_PARM_2:
      000D0D                        598 	.ds 1
      000D0E                        599 _raw_hid_receive_kb_data_10000_635:
      000D0E                        600 	.ds 3
      000D11                        601 _raw_hid_receive_PARM_2:
      000D11                        602 	.ds 1
      000D12                        603 _raw_hid_receive_packet_10000_637:
      000D12                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00AF4A                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00AF4A 90 00 25         [24]  658 	mov	dptr,#0x0025
      00AF4D 75 F0 00         [24]  659 	mov	b, #0x00
      00AF50 12 40 67         [24]  660 	lcall	_eeprom_read_byte
      00AF53 AF 82            [24]  661 	mov	r7, dpl
      00AF55 BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00AF58 90 00 26         [24]  663 	mov	dptr,#0x0026
      00AF5B 75 F0 00         [24]  664 	mov	b, #0x00
      00AF5E 12 40 67         [24]  665 	lcall	_eeprom_read_byte
      00AF61 AF 82            [24]  666 	mov	r7, dpl
      00AF63 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00AF66 90 00 27         [24]  668 	mov	dptr,#0x0027
      00AF69 75 F0 00         [24]  669 	mov	b, #0x00
      00AF6C 12 40 67         [24]  670 	lcall	_eeprom_read_byte
      00AF6F AF 82            [24]  671 	mov	r7, dpl
      00AF71 BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00AF74 80 04            [24]  673 	sjmp	00104$
      00AF76                        674 00126$:
      00AF76                        675 00103$:
                                    676 ;	assignBit
      00AF76 C2 2C            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00AF78 80 02            [24]  678 	sjmp	00105$
      00AF7A                        679 00104$:
                                    680 ;	assignBit
      00AF7A D2 2C            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00AF7C                        682 00105$:
      00AF7C A2 2C            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00AF7E 12 38 A4         [24]  684 	lcall	_ak820_outline_0157
                                    685 ;	quantum/via.c:104: }
      00AF81 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_611'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_612'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_612'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_612'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00AF82                        699 _via_eeprom_set_valid:
      00AF82 E5 82            [12]  700 	mov	a,dpl
      00AF84 90 0D 03         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AF87 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00AF88 E0               [24]  704 	movx	a,@dptr
      00AF89 60 04            [24]  705 	jz	00103$
      00AF8B 7F 03            [12]  706 	mov	r7,#0x03
      00AF8D 80 02            [24]  707 	sjmp	00104$
      00AF8F                        708 00103$:
      00AF8F 7F FF            [12]  709 	mov	r7,#0xff
      00AF91                        710 00104$:
      00AF91 90 07 4B         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AF94 EF               [12]  712 	mov	a,r7
      00AF95 F0               [24]  713 	movx	@dptr,a
      00AF96 90 00 25         [24]  714 	mov	dptr,#0x0025
      00AF99 75 F0 00         [24]  715 	mov	b, #0x00
      00AF9C 12 57 49         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00AF9F 90 0D 03         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AFA2 E0               [24]  719 	movx	a,@dptr
      00AFA3 60 04            [24]  720 	jz	00105$
      00AFA5 7F 20            [12]  721 	mov	r7,#0x20
      00AFA7 80 02            [24]  722 	sjmp	00106$
      00AFA9                        723 00105$:
      00AFA9 7F FF            [12]  724 	mov	r7,#0xff
      00AFAB                        725 00106$:
      00AFAB 90 07 4B         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AFAE EF               [12]  727 	mov	a,r7
      00AFAF F0               [24]  728 	movx	@dptr,a
      00AFB0 90 00 26         [24]  729 	mov	dptr,#0x0026
      00AFB3 75 F0 00         [24]  730 	mov	b, #0x00
      00AFB6 12 57 49         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00AFB9 90 0D 03         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AFBC E0               [24]  734 	movx	a,@dptr
      00AFBD 60 04            [24]  735 	jz	00107$
      00AFBF 7F 08            [12]  736 	mov	r7,#0x08
      00AFC1 80 02            [24]  737 	sjmp	00108$
      00AFC3                        738 00107$:
      00AFC3 7F FF            [12]  739 	mov	r7,#0xff
      00AFC5                        740 00108$:
      00AFC5 90 07 4B         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AFC8 EF               [12]  742 	mov	a,r7
      00AFC9 F0               [24]  743 	movx	@dptr,a
      00AFCA 90 00 27         [24]  744 	mov	dptr,#0x0027
      00AFCD 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00AFD0 02 57 49         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00AFD3                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00AFD3 F1 F8            [12]  757 	acall	_via_get_layout_options
      00AFD5 12 B0 10         [24]  758 	lcall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00AFD8 F1 4A            [12]  760 	acall	_via_eeprom_is_valid
      00AFDA E5 82            [12]  761 	mov	a, dpl
      00AFDC 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00AFDE 02 3E 16         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00AFE1                        766 00103$:
      00AFE1 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00AFE2                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00AFE2 75 82 00         [24]  777 	mov	dpl, #0x00
      00AFE5 F1 82            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00AFE7 12 9A 4C         [24]  780 	lcall	_ak820_outline_0153
      00AFEA 12 B0 11         [24]  781 	lcall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00AFED 12 90 8C         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00AFF0 12 95 3B         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00AFF3 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00AFF6 E1 82            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00AFF8                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00AFF8 90 00 28         [24]  799 	mov	dptr,#0x0028
      00AFFB 75 F0 00         [24]  800 	mov	b, #0x00
      00AFFE 12 40 67         [24]  801 	lcall	_eeprom_read_byte
      00B001 AF 82            [24]  802 	mov	r7, dpl
      00B003 7E 00            [12]  803 	mov	r6,#0x00
      00B005 7D 00            [12]  804 	mov	r5,#0x00
      00B007 7C 00            [12]  805 	mov	r4,#0x00
      00B009 12 43 65         [24]  806 	lcall	_ak820_outline_0159
      00B00C 8D F0            [24]  807 	mov	b, r5
      00B00E EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00B00F 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_624'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00B010                        820 _via_set_layout_options_kb:
      00B010 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_627'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00B011                        831 _via_set_layout_options:
      00B011 12 9A 44         [24]  832 	lcall	_ak820_outline_0122
      00B014 90 0D 04         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_627
      00B017 12 9A 32         [24]  834 	lcall	_ak820_outline_0047
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00B01A 90 0D 04         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_627
      00B01D E0               [24]  837 	movx	a,@dptr
      00B01E 90 07 4B         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00B021 F0               [24]  839 	movx	@dptr,a
      00B022 90 00 28         [24]  840 	mov	dptr,#0x0028
      00B025 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00B028 02 57 49         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_629'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_634'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00B02B                        855 _process_record_via:
      00B02B 12 38 75         [24]  856 	lcall	_ak820_outline_0108
      00B02E 90 0D 0B         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_629
      00B031 12 38 7A         [24]  858 	lcall	_ak820_outline_0109
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00B034 90 0D 08         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00B037 12 58 58         [24]  861 	lcall	_ak820_outline_0013
      00B03A 74 05            [12]  862 	mov	a,#0x05
      00B03C 12 38 AE         [24]  863 	lcall	_ak820_outline_0161
      00B03F 12 76 9E         [24]  864 	lcall	_ak820_outline_0060
      00B042 12 C3 83         [24]  865 	lcall	__gptrget
      00B045 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00B047 90 0D 0B         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_629
      00B04A 12 51 8C         [24]  869 	lcall	_ak820_outline_0009
      00B04D 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00B04F 2D               [12]  871 	add	a,r5
      00B050 50 12            [24]  872 	jnc	00105$
      00B052 C3               [12]  873 	clr	c
      00B053 74 7F            [12]  874 	mov	a,#0x7f
      00B055 9C               [12]  875 	subb	a,r4
      00B056 74 77            [12]  876 	mov	a,#0x77
      00B058 9D               [12]  877 	subb	a,r5
      00B059 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00B05B 8E 82            [24]  882 	mov	dpl, r6
      00B05D 12 95 61         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00B060 75 82 00         [24]  885 	mov	dpl, #0x00
      00B063 22               [24]  886 	ret
      00B064                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00B064 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00B067 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_635'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_636'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00B068                        903 _raw_hid_receive_kb:
      00B068 12 43 06         [24]  904 	lcall	_ak820_outline_0038
      00B06B 90 0D 0E         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00B06E 12 38 1C         [24]  906 	lcall	_ak820_outline_0019
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00B071 90 0D 0E         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00B074 12 58 32         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00B077 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00B079 02 C3 48         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_637'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_638'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_638'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_638'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_644'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_652'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_653'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_656'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_657'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_658'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_663'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_665'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_674'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_675'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_675'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_680'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_680'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_687'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_687'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_692'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00B07C                        950 _raw_hid_receive:
      00B07C 12 43 06         [24]  951 	lcall	_ak820_outline_0038
      00B07F 90 0D 12         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00B082 12 38 1C         [24]  953 	lcall	_ak820_outline_0019
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00B085 90 0D 12         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00B088 12 38 34         [24]  956 	lcall	_ak820_outline_0054
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00B08B 74 01            [12]  958 	mov	a,#0x01
      00B08D 12 43 6A         [24]  959 	lcall	_ak820_outline_0162
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00B090 90 0D 11         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00B093 E0               [24]  962 	movx	a,@dptr
      00B094 FB               [12]  963 	mov	r3,a
      00B095 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00B098 80 01            [24]  965 	sjmp	00102$
      00B09A                        966 00520$:
      00B09A 22               [24]  967 	ret
      00B09B                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00B09B 90 0E F5         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00B09E E0               [24]  971 	movx	a,@dptr
      00B09F 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00B0A1 12 38 7F         [24]  974 	lcall	_ak820_outline_0120
      00B0A4 E0               [24]  975 	movx	a,@dptr
      00B0A5 FA               [12]  976 	mov	r2,a
      00B0A6 BA FE 02         [24]  977 	cjne	r2,#0xfe,00522$
      00B0A9 80 01            [24]  978 	sjmp	00104$
      00B0AB                        979 00522$:
                                    980 ;	quantum/via.c:252: return;
      00B0AB 22               [24]  981 	ret
      00B0AC                        982 00104$:
                                    983 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00B0AC 12 43 37         [24]  984 	lcall	_ak820_outline_0095
                                    985 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00B0AF FA               [12]  986 	mov	r2,a
      00B0B0 60 20            [24]  987 	jz	00114$
      00B0B2 BA 01 02         [24]  988 	cjne	r2,#0x01,00524$
      00B0B5 80 1B            [24]  989 	sjmp	00114$
      00B0B7                        990 00524$:
      00B0B7 BA 02 02         [24]  991 	cjne	r2,#0x02,00525$
      00B0BA 80 16            [24]  992 	sjmp	00114$
      00B0BC                        993 00525$:
      00B0BC BA 05 02         [24]  994 	cjne	r2,#0x05,00526$
      00B0BF 80 11            [24]  995 	sjmp	00114$
      00B0C1                        996 00526$:
      00B0C1 BA 06 02         [24]  997 	cjne	r2,#0x06,00527$
      00B0C4 80 0C            [24]  998 	sjmp	00114$
      00B0C6                        999 00527$:
      00B0C6 BA 07 02         [24] 1000 	cjne	r2,#0x07,00528$
      00B0C9 80 07            [24] 1001 	sjmp	00114$
      00B0CB                       1002 00528$:
      00B0CB BA 08 02         [24] 1003 	cjne	r2,#0x08,00529$
      00B0CE 80 02            [24] 1004 	sjmp	00530$
      00B0D0                       1005 00529$:
      00B0D0 A1 CF            [12] 1006 	ajmp	00171$
      00B0D2                       1007 00530$:
                                   1008 ;	quantum/via.c:259: goto skip;
      00B0D2                       1009 00114$:
                                   1010 ;	quantum/via.c:263: switch (*command_id) {
      00B0D2 12 38 7F         [24] 1011 	lcall	_ak820_outline_0120
      00B0D5 E0               [24] 1012 	movx	a,@dptr
      00B0D6 FA               [12] 1013 	mov	r2,a
      00B0D7 BA 01 02         [24] 1014 	cjne	r2,#0x01,00531$
      00B0DA 80 5C            [24] 1015 	sjmp	00115$
      00B0DC                       1016 00531$:
      00B0DC BA 02 02         [24] 1017 	cjne	r2,#0x02,00532$
      00B0DF 80 63            [24] 1018 	sjmp	00116$
      00B0E1                       1019 00532$:
      00B0E1 BA 03 02         [24] 1020 	cjne	r2,#0x03,00533$
      00B0E4 21 FE            [24] 1021 	ajmp	00125$
      00B0E6                       1022 00533$:
      00B0E6 BA 04 02         [24] 1023 	cjne	r2,#0x04,00534$
      00B0E9 41 8E            [12] 1024 	ajmp	00129$
      00B0EB                       1025 00534$:
      00B0EB BA 05 02         [24] 1026 	cjne	r2,#0x05,00535$
      00B0EE 41 C6            [12] 1027 	ajmp	00130$
      00B0F0                       1028 00535$:
      00B0F0 BA 06 02         [24] 1029 	cjne	r2,#0x06,00536$
      00B0F3 61 30            [12] 1030 	ajmp	00135$
      00B0F5                       1031 00536$:
      00B0F5 BA 07 02         [24] 1032 	cjne	r2,#0x07,00537$
      00B0F8 61 41            [12] 1033 	ajmp	00136$
      00B0FA                       1034 00537$:
      00B0FA BA 08 02         [24] 1035 	cjne	r2,#0x08,00538$
      00B0FD 61 5B            [12] 1036 	ajmp	00137$
      00B0FF                       1037 00538$:
      00B0FF BA 09 02         [24] 1038 	cjne	r2,#0x09,00539$
      00B102 61 75            [12] 1039 	ajmp	00138$
      00B104                       1040 00539$:
      00B104 BA 0B 02         [24] 1041 	cjne	r2,#0x0b,00540$
      00B107 A1 5F            [12] 1042 	ajmp	00161$
      00B109                       1043 00540$:
      00B109 BA 0C 02         [24] 1044 	cjne	r2,#0x0c,00541$
      00B10C 61 8F            [12] 1045 	ajmp	00139$
      00B10E                       1046 00541$:
      00B10E BA 0D 02         [24] 1047 	cjne	r2,#0x0d,00542$
      00B111 61 AF            [12] 1048 	ajmp	00140$
      00B113                       1049 00542$:
      00B113 BA 0E 02         [24] 1050 	cjne	r2,#0x0e,00543$
      00B116 61 D6            [12] 1051 	ajmp	00141$
      00B118                       1052 00543$:
      00B118 BA 0F 02         [24] 1053 	cjne	r2,#0x0f,00544$
      00B11B 81 1C            [12] 1054 	ajmp	00144$
      00B11D                       1055 00544$:
      00B11D BA 10 02         [24] 1056 	cjne	r2,#0x10,00545$
      00B120 81 8A            [12] 1057 	ajmp	00151$
      00B122                       1058 00545$:
      00B122 BA 11 02         [24] 1059 	cjne	r2,#0x11,00546$
      00B125 81 A2            [12] 1060 	ajmp	00154$
      00B127                       1061 00546$:
      00B127 BA 12 02         [24] 1062 	cjne	r2,#0x12,00547$
      00B12A 81 C2            [12] 1063 	ajmp	00155$
      00B12C                       1064 00547$:
      00B12C BA 13 02         [24] 1065 	cjne	r2,#0x13,00548$
      00B12F A1 08            [12] 1066 	ajmp	00158$
      00B131                       1067 00548$:
      00B131 BA FE 02         [24] 1068 	cjne	r2,#0xfe,00549$
      00B134 A1 9E            [12] 1069 	ajmp	00168$
      00B136                       1070 00549$:
      00B136 A1 B8            [12] 1071 	ajmp	00169$
                                   1072 ;	quantum/via.c:264: case id_get_protocol_version: {
      00B138                       1073 00115$:
                                   1074 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00B138 12 38 8A         [24] 1075 	lcall	_ak820_outline_0126
      00B13B E4               [12] 1076 	clr	a
      00B13C 12 42 FE         [24] 1077 	lcall	_ak820_outline_0032
                                   1078 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00B13F 74 09            [12] 1079 	mov	a,#0x09
      00B141 F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/via.c:267: break;
      00B142 A1 CF            [12] 1082 	ajmp	00171$
                                   1083 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00B144                       1084 00116$:
                                   1085 ;	quantum/via.c:270: switch (command_data[0]) {
      00B144 12 43 37         [24] 1086 	lcall	_ak820_outline_0095
      00B147 FA               [12] 1087 	mov	r2,a
      00B148 BA 01 02         [24] 1088 	cjne	r2,#0x01,00550$
      00B14B 80 0C            [24] 1089 	sjmp	00117$
      00B14D                       1090 00550$:
      00B14D BA 02 02         [24] 1091 	cjne	r2,#0x02,00551$
      00B150 80 31            [24] 1092 	sjmp	00118$
      00B152                       1093 00551$:
      00B152 BA 03 02         [24] 1094 	cjne	r2,#0x03,00552$
      00B155 21 BD            [24] 1095 	ajmp	00119$
      00B157                       1096 00552$:
      00B157 21 E5            [24] 1097 	ajmp	00123$
                                   1098 ;	quantum/via.c:271: case id_uptime: {
      00B159                       1099 00117$:
                                   1100 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00B159 12 52 71         [24] 1101 	lcall	_timer_read32
      00B15C 85 82 3C         [24] 1102 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00B15F 85 83 3D         [24] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00B162 85 F0 3E         [24] 1104 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00B165 F5 3F            [12] 1105 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1106 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00B167 12 38 7F         [24] 1107 	lcall	_ak820_outline_0120
      00B16A A3               [24] 1108 	inc	dptr
      00B16B A3               [24] 1109 	inc	dptr
      00B16C E5 3F            [12] 1110 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00B16E 12 42 FE         [24] 1111 	lcall	_ak820_outline_0032
                                   1112 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00B171 A3               [24] 1113 	inc	dptr
      00B172 E5 3E            [12] 1114 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00B174 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00B175 12 B5 FD         [24] 1117 	lcall	_ak820_outline_0024
      00B178 E5 3D            [12] 1118 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B17A F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00B17B 12 42 F4         [24] 1121 	lcall	_ak820_outline_0012
      00B17E E5 3C            [12] 1122 	mov	a,_raw_hid_receive_sloc0_1_0
      00B180 F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	quantum/via.c:277: break;
      00B181 A1 CF            [12] 1125 	ajmp	00171$
                                   1126 ;	quantum/via.c:279: case id_layout_options: {
      00B183                       1127 00118$:
                                   1128 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00B183 C0 03            [24] 1129 	push	ar3
      00B185 C0 07            [24] 1130 	push	ar7
      00B187 C0 06            [24] 1131 	push	ar6
      00B189 C0 03            [24] 1132 	push	ar3
      00B18B 12 AF F8         [24] 1133 	lcall	_via_get_layout_options
      00B18E 85 82 3C         [24] 1134 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00B191 85 83 3D         [24] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00B194 85 F0 3E         [24] 1136 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00B197 F5 3F            [12] 1137 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00B199 D0 03            [24] 1138 	pop	ar3
      00B19B D0 06            [24] 1139 	pop	ar6
      00B19D D0 07            [24] 1140 	pop	ar7
                                   1141 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00B19F 12 38 7F         [24] 1142 	lcall	_ak820_outline_0120
      00B1A2 A3               [24] 1143 	inc	dptr
      00B1A3 A3               [24] 1144 	inc	dptr
      00B1A4 E5 3F            [12] 1145 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00B1A6 12 42 FE         [24] 1146 	lcall	_ak820_outline_0032
                                   1147 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00B1A9 A3               [24] 1148 	inc	dptr
      00B1AA E5 3E            [12] 1149 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00B1AC F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00B1AD 12 B5 FD         [24] 1152 	lcall	_ak820_outline_0024
      00B1B0 E5 3D            [12] 1153 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B1B2 F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00B1B3 12 42 F4         [24] 1156 	lcall	_ak820_outline_0012
      00B1B6 E5 3C            [12] 1157 	mov	a,_raw_hid_receive_sloc0_1_0
      00B1B8 F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	quantum/via.c:285: break;
      00B1B9 D0 03            [24] 1160 	pop	ar3
      00B1BB A1 CF            [12] 1161 	ajmp	00171$
                                   1162 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00B1BD                       1163 00119$:
                                   1164 ;	quantum/via.c:290: if (!vial_unlocked)
      00B1BD 90 0E F4         [24] 1165 	mov	dptr,#_vial_unlocked
      00B1C0 E0               [24] 1166 	movx	a,@dptr
      00B1C1 70 02            [24] 1167 	jnz	00553$
      00B1C3 A1 CF            [12] 1168 	ajmp	00171$
      00B1C5                       1169 00553$:
                                   1170 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00B1C5 7A 01            [12] 1171 	mov	r2,#0x01
      00B1C7 79 00            [12] 1172 	mov	r1,#0x00
      00B1C9                       1173 00173$:
      00B1C9 B9 10 00         [24] 1174 	cjne	r1,#0x10,00554$
      00B1CC                       1175 00554$:
      00B1CC 40 02            [24] 1176 	jc	00555$
      00B1CE A1 CF            [12] 1177 	ajmp	00171$
      00B1D0                       1178 00555$:
                                   1179 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00B1D0 89 82            [24] 1180 	mov	dpl, r1
      00B1D2 12 62 C5         [24] 1181 	lcall	_matrix_get_row
      00B1D5 A8 82            [24] 1182 	mov	r0, dpl
                                   1183 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00B1D7 EA               [12] 1184 	mov	a,r2
      00B1D8 2C               [12] 1185 	add	a, r4
      00B1D9 F5 82            [12] 1186 	mov	dpl,a
      00B1DB E4               [12] 1187 	clr	a
      00B1DC 3D               [12] 1188 	addc	a, r5
      00B1DD F5 83            [12] 1189 	mov	dph,a
      00B1DF 0A               [12] 1190 	inc	r2
      00B1E0 E8               [12] 1191 	mov	a,r0
      00B1E1 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00B1E2 09               [12] 1194 	inc	r1
                                   1195 ;	quantum/via.c:312: default: {
      00B1E3 80 E4            [24] 1196 	sjmp	00173$
      00B1E5                       1197 00123$:
                                   1198 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00B1E5 12 51 EF         [24] 1199 	lcall	_ak820_outline_0076
      00B1E8 90 0D 0D         [24] 1200 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B1EB 12 B6 06         [24] 1201 	lcall	_ak820_outline_0044
      00B1EE C0 07            [24] 1202 	push	ar7
      00B1F0 C0 06            [24] 1203 	push	ar6
      00B1F2 C0 03            [24] 1204 	push	ar3
      00B1F4 11 68            [24] 1205 	acall	_raw_hid_receive_kb
      00B1F6 D0 03            [24] 1206 	pop	ar3
      00B1F8 D0 06            [24] 1207 	pop	ar6
      00B1FA D0 07            [24] 1208 	pop	ar7
                                   1209 ;	quantum/via.c:317: break;
      00B1FC A1 CF            [12] 1210 	ajmp	00171$
                                   1211 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00B1FE                       1212 00125$:
                                   1213 ;	quantum/via.c:320: switch (command_data[0]) {
      00B1FE 12 43 37         [24] 1214 	lcall	_ak820_outline_0095
      00B201 FA               [12] 1215 	mov	r2,a
      00B202 BA 02 02         [24] 1216 	cjne	r2,#0x02,00556$
      00B205 80 02            [24] 1217 	sjmp	00557$
      00B207                       1218 00556$:
      00B207 41 75            [12] 1219 	ajmp	00127$
      00B209                       1220 00557$:
                                   1221 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00B209 C0 03            [24] 1222 	push	ar3
      00B20B 12 38 2C         [24] 1223 	lcall	_ak820_outline_0037
      00B20E F8               [12] 1224 	mov	r0,a
      00B20F 79 00            [12] 1225 	mov	r1,#0x00
      00B211 7B 00            [12] 1226 	mov	r3,#0x00
      00B213 88 3F            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00B215 8B 3C            [24] 1228 	mov	_raw_hid_receive_sloc0_1_0,r3
      00B217 8B 3D            [24] 1229 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00B219 8B 3E            [24] 1230 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00B21B 12 B5 F4         [24] 1231 	lcall	_ak820_outline_0017
      00B21E F8               [12] 1232 	mov	r0,a
      00B21F 89 03            [24] 1233 	mov	ar3,r1
      00B221 88 02            [24] 1234 	mov	ar2,r0
      00B223 E4               [12] 1235 	clr	a
      00B224 42 3C            [12] 1236 	orl	_raw_hid_receive_sloc0_1_0,a
      00B226 E9               [12] 1237 	mov	a,r1
      00B227 42 3D            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00B229 EA               [12] 1239 	mov	a,r2
      00B22A 42 3E            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00B22C EB               [12] 1241 	mov	a,r3
      00B22D 42 3F            [12] 1242 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00B22F 12 B5 FD         [24] 1243 	lcall	_ak820_outline_0024
      00B232 E0               [24] 1244 	movx	a,@dptr
      00B233 F8               [12] 1245 	mov	r0,a
      00B234 79 00            [12] 1246 	mov	r1,#0x00
      00B236 7A 00            [12] 1247 	mov	r2,#0x00
      00B238 8A 03            [24] 1248 	mov	ar3,r2
      00B23A 89 02            [24] 1249 	mov	ar2,r1
      00B23C 88 01            [24] 1250 	mov	ar1,r0
      00B23E E4               [12] 1251 	clr	a
      00B23F 42 3C            [12] 1252 	orl	_raw_hid_receive_sloc0_1_0,a
      00B241 E9               [12] 1253 	mov	a,r1
      00B242 42 3D            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00B244 EA               [12] 1255 	mov	a,r2
      00B245 42 3E            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00B247 EB               [12] 1257 	mov	a,r3
      00B248 42 3F            [12] 1258 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00B24A 12 42 F4         [24] 1259 	lcall	_ak820_outline_0012
      00B24D E0               [24] 1260 	movx	a,@dptr
      00B24E F8               [12] 1261 	mov	r0,a
      00B24F E4               [12] 1262 	clr	a
      00B250 F9               [12] 1263 	mov	r1,a
      00B251 FA               [12] 1264 	mov	r2,a
      00B252 FB               [12] 1265 	mov	r3,a
      00B253 E5 3D            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B255 42 01            [12] 1267 	orl	ar1,a
      00B257 E5 3E            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00B259 42 02            [12] 1269 	orl	ar2,a
      00B25B E5 3F            [12] 1270 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00B25D 42 03            [12] 1271 	orl	ar3,a
                                   1272 ;	quantum/via.c:323: via_set_layout_options(value);
      00B25F 12 52 1E         [24] 1273 	lcall	_ak820_outline_0113
      00B262 EB               [12] 1274 	mov	a, r3
      00B263 C0 07            [24] 1275 	push	ar7
      00B265 C0 06            [24] 1276 	push	ar6
      00B267 C0 03            [24] 1277 	push	ar3
      00B269 11 11            [12] 1278 	acall	_via_set_layout_options
      00B26B D0 03            [24] 1279 	pop	ar3
      00B26D D0 06            [24] 1280 	pop	ar6
      00B26F D0 07            [24] 1281 	pop	ar7
                                   1282 ;	quantum/via.c:324: break;
      00B271 D0 03            [24] 1283 	pop	ar3
      00B273 A1 CF            [12] 1284 	ajmp	00171$
                                   1285 ;	quantum/via.c:326: default: {
      00B275                       1286 00127$:
                                   1287 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00B275 12 51 EF         [24] 1288 	lcall	_ak820_outline_0076
      00B278 90 0D 0D         [24] 1289 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B27B 12 B6 06         [24] 1290 	lcall	_ak820_outline_0044
      00B27E C0 07            [24] 1291 	push	ar7
      00B280 C0 06            [24] 1292 	push	ar6
      00B282 C0 03            [24] 1293 	push	ar3
      00B284 11 68            [24] 1294 	acall	_raw_hid_receive_kb
      00B286 D0 03            [24] 1295 	pop	ar3
      00B288 D0 06            [24] 1296 	pop	ar6
      00B28A D0 07            [24] 1297 	pop	ar7
                                   1298 ;	quantum/via.c:331: break;
      00B28C A1 CF            [12] 1299 	ajmp	00171$
                                   1300 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00B28E                       1301 00129$:
                                   1302 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00B28E 12 43 37         [24] 1303 	lcall	_ak820_outline_0095
      00B291 FA               [12] 1304 	mov	r2,a
      00B292 12 38 2C         [24] 1305 	lcall	_ak820_outline_0037
      00B295 F9               [12] 1306 	mov	r1,a
      00B296 12 B5 F4         [24] 1307 	lcall	_ak820_outline_0017
      00B299 F8               [12] 1308 	mov	r0,a
      00B29A 90 0B 88         [24] 1309 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00B29D E9               [12] 1310 	mov	a,r1
      00B29E F0               [24] 1311 	movx	@dptr,a
      00B29F 90 0B 89         [24] 1312 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00B2A2 E8               [12] 1313 	mov	a,r0
      00B2A3 F0               [24] 1314 	movx	@dptr,a
      00B2A4 8A 82            [24] 1315 	mov	dpl, r2
      00B2A6 C0 07            [24] 1316 	push	ar7
      00B2A8 C0 06            [24] 1317 	push	ar6
      00B2AA C0 03            [24] 1318 	push	ar3
      00B2AC 12 8C A5         [24] 1319 	lcall	_dynamic_keymap_get_keycode
      00B2AF 12 B6 32         [24] 1320 	lcall	_ak820_outline_0187
      00B2B2 D0 03            [24] 1321 	pop	ar3
      00B2B4 D0 06            [24] 1322 	pop	ar6
      00B2B6 D0 07            [24] 1323 	pop	ar7
                                   1324 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00B2B8 12 B5 FD         [24] 1325 	lcall	_ak820_outline_0024
      00B2BB 8A 00            [24] 1326 	mov	ar0,r2
      00B2BD E8               [12] 1327 	mov	a,r0
      00B2BE F0               [24] 1328 	movx	@dptr,a
                                   1329 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00B2BF 12 42 F4         [24] 1330 	lcall	_ak820_outline_0012
      00B2C2 E9               [12] 1331 	mov	a,r1
      00B2C3 F0               [24] 1332 	movx	@dptr,a
                                   1333 ;	quantum/via.c:337: break;
      00B2C4 A1 CF            [12] 1334 	ajmp	00171$
                                   1335 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00B2C6                       1336 00130$:
                                   1337 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00B2C6 90 0E F4         [24] 1338 	mov	dptr,#_vial_unlocked
      00B2C9 E0               [24] 1339 	movx	a,@dptr
      00B2CA 70 18            [24] 1340 	jnz	00132$
      00B2CC 12 B5 FD         [24] 1341 	lcall	_ak820_outline_0024
      00B2CF E0               [24] 1342 	movx	a,@dptr
      00B2D0 FA               [12] 1343 	mov	r2,a
      00B2D1 BA 7C 10         [24] 1344 	cjne	r2,#0x7c,00132$
      00B2D4 74 05            [12] 1345 	mov	a,#0x05
      00B2D6 2E               [12] 1346 	add	a, r6
      00B2D7 12 38 12         [24] 1347 	lcall	_ak820_outline_0018
      00B2DA 70 08            [24] 1348 	jnz	00132$
                                   1349 ;	quantum/via.c:344: *command_id = id_unhandled;
      00B2DC 12 38 7F         [24] 1350 	lcall	_ak820_outline_0120
      00B2DF 74 FF            [12] 1351 	mov	a,#0xff
      00B2E1 F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/via.c:345: break;
      00B2E2 A1 CF            [12] 1354 	ajmp	00171$
      00B2E4                       1355 00132$:
                                   1356 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00B2E4 C0 03            [24] 1357 	push	ar3
      00B2E6 12 43 37         [24] 1358 	lcall	_ak820_outline_0095
      00B2E9 F5 41            [12] 1359 	mov	_raw_hid_receive_sloc2_1_0,a
      00B2EB 12 38 2C         [24] 1360 	lcall	_ak820_outline_0037
      00B2EE F5 40            [12] 1361 	mov	_raw_hid_receive_sloc1_1_0,a
      00B2F0 12 B5 F4         [24] 1362 	lcall	_ak820_outline_0017
      00B2F3 F5 3C            [12] 1363 	mov	_raw_hid_receive_sloc0_1_0,a
      00B2F5 12 B5 FD         [24] 1364 	lcall	_ak820_outline_0024
      00B2F8 E0               [24] 1365 	movx	a,@dptr
      00B2F9 FB               [12] 1366 	mov	r3,a
      00B2FA 78 00            [12] 1367 	mov	r0,#0x00
      00B2FC 12 42 F4         [24] 1368 	lcall	_ak820_outline_0012
      00B2FF E0               [24] 1369 	movx	a,@dptr
      00B300 7A 00            [12] 1370 	mov	r2,#0x00
      00B302 42 00            [12] 1371 	orl	ar0,a
      00B304 EA               [12] 1372 	mov	a,r2
      00B305 42 03            [12] 1373 	orl	ar3,a
      00B307 90 0B 8B         [24] 1374 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00B30A E5 40            [12] 1375 	mov	a,_raw_hid_receive_sloc1_1_0
      00B30C F0               [24] 1376 	movx	@dptr,a
      00B30D 90 0B 8C         [24] 1377 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00B310 E5 3C            [12] 1378 	mov	a,_raw_hid_receive_sloc0_1_0
      00B312 F0               [24] 1379 	movx	@dptr,a
      00B313 90 0B 8D         [24] 1380 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00B316 E8               [12] 1381 	mov	a,r0
      00B317 12 80 57         [24] 1382 	lcall	_ak820_outline_0188
      00B31A 85 41 82         [24] 1383 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00B31D C0 07            [24] 1384 	push	ar7
      00B31F C0 06            [24] 1385 	push	ar6
      00B321 C0 03            [24] 1386 	push	ar3
      00B323 12 8C F2         [24] 1387 	lcall	_dynamic_keymap_set_keycode
      00B326 D0 03            [24] 1388 	pop	ar3
      00B328 D0 06            [24] 1389 	pop	ar6
      00B32A D0 07            [24] 1390 	pop	ar7
                                   1391 ;	quantum/via.c:349: break;
      00B32C D0 03            [24] 1392 	pop	ar3
      00B32E A1 CF            [12] 1393 	ajmp	00171$
                                   1394 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00B330                       1395 00135$:
                                   1396 ;	quantum/via.c:352: dynamic_keymap_reset();
      00B330 C0 07            [24] 1397 	push	ar7
      00B332 C0 06            [24] 1398 	push	ar6
      00B334 C0 03            [24] 1399 	push	ar3
      00B336 12 90 8C         [24] 1400 	lcall	_dynamic_keymap_reset
      00B339 D0 03            [24] 1401 	pop	ar3
      00B33B D0 06            [24] 1402 	pop	ar6
      00B33D D0 07            [24] 1403 	pop	ar7
                                   1404 ;	quantum/via.c:353: break;
      00B33F A1 CF            [12] 1405 	ajmp	00171$
                                   1406 ;	quantum/via.c:355: case id_lighting_set_value: {
      00B341                       1407 00136$:
                                   1408 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00B341 12 51 EF         [24] 1409 	lcall	_ak820_outline_0076
      00B344 90 0E 6C         [24] 1410 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B347 12 B6 06         [24] 1411 	lcall	_ak820_outline_0044
      00B34A C0 07            [24] 1412 	push	ar7
      00B34C C0 06            [24] 1413 	push	ar6
      00B34E C0 03            [24] 1414 	push	ar3
      00B350 12 C1 1D         [24] 1415 	lcall	_vialrgb_set_value
      00B353 D0 03            [24] 1416 	pop	ar3
      00B355 D0 06            [24] 1417 	pop	ar6
      00B357 D0 07            [24] 1418 	pop	ar7
                                   1419 ;	quantum/via.c:375: break;
      00B359 A1 CF            [12] 1420 	ajmp	00171$
                                   1421 ;	quantum/via.c:377: case id_lighting_get_value: {
      00B35B                       1422 00137$:
                                   1423 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00B35B 12 51 EF         [24] 1424 	lcall	_ak820_outline_0076
      00B35E 90 0E 68         [24] 1425 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B361 12 B6 06         [24] 1426 	lcall	_ak820_outline_0044
      00B364 C0 07            [24] 1427 	push	ar7
      00B366 C0 06            [24] 1428 	push	ar6
      00B368 C0 03            [24] 1429 	push	ar3
      00B36A 12 BF B2         [24] 1430 	lcall	_vialrgb_get_value
      00B36D D0 03            [24] 1431 	pop	ar3
      00B36F D0 06            [24] 1432 	pop	ar6
      00B371 D0 07            [24] 1433 	pop	ar7
                                   1434 ;	quantum/via.c:397: break;
      00B373 A1 CF            [12] 1435 	ajmp	00171$
                                   1436 ;	quantum/via.c:399: case id_lighting_save: {
      00B375                       1437 00138$:
                                   1438 ;	quantum/via.c:407: vialrgb_save(data, length);
      00B375 12 51 EF         [24] 1439 	lcall	_ak820_outline_0076
      00B378 90 0E 70         [24] 1440 	mov	dptr,#_vialrgb_save_PARM_2
      00B37B 12 B6 06         [24] 1441 	lcall	_ak820_outline_0044
      00B37E C0 07            [24] 1442 	push	ar7
      00B380 C0 06            [24] 1443 	push	ar6
      00B382 C0 03            [24] 1444 	push	ar3
      00B384 12 C1 AC         [24] 1445 	lcall	_vialrgb_save
      00B387 D0 03            [24] 1446 	pop	ar3
      00B389 D0 06            [24] 1447 	pop	ar6
      00B38B D0 07            [24] 1448 	pop	ar7
                                   1449 ;	quantum/via.c:419: break;
      00B38D A1 CF            [12] 1450 	ajmp	00171$
                                   1451 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00B38F                       1452 00139$:
                                   1453 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00B38F C0 07            [24] 1454 	push	ar7
      00B391 C0 06            [24] 1455 	push	ar6
      00B393 C0 05            [24] 1456 	push	ar5
      00B395 C0 04            [24] 1457 	push	ar4
      00B397 C0 03            [24] 1458 	push	ar3
      00B399 12 94 B7         [24] 1459 	lcall	_dynamic_keymap_macro_get_count
      00B39C AA 82            [24] 1460 	mov	r2, dpl
      00B39E D0 03            [24] 1461 	pop	ar3
      00B3A0 D0 04            [24] 1462 	pop	ar4
      00B3A2 D0 05            [24] 1463 	pop	ar5
      00B3A4 D0 06            [24] 1464 	pop	ar6
      00B3A6 D0 07            [24] 1465 	pop	ar7
      00B3A8 12 38 8A         [24] 1466 	lcall	_ak820_outline_0126
      00B3AB EA               [12] 1467 	mov	a,r2
      00B3AC F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	quantum/via.c:430: break;
      00B3AD A1 CF            [12] 1470 	ajmp	00171$
                                   1471 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00B3AF                       1472 00140$:
                                   1473 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00B3AF C0 07            [24] 1474 	push	ar7
      00B3B1 C0 06            [24] 1475 	push	ar6
      00B3B3 C0 05            [24] 1476 	push	ar5
      00B3B5 C0 04            [24] 1477 	push	ar4
      00B3B7 C0 03            [24] 1478 	push	ar3
      00B3B9 12 94 BB         [24] 1479 	lcall	_dynamic_keymap_macro_get_buffer_size
      00B3BC 12 B6 32         [24] 1480 	lcall	_ak820_outline_0187
      00B3BF D0 03            [24] 1481 	pop	ar3
      00B3C1 D0 04            [24] 1482 	pop	ar4
      00B3C3 D0 05            [24] 1483 	pop	ar5
      00B3C5 D0 06            [24] 1484 	pop	ar6
      00B3C7 D0 07            [24] 1485 	pop	ar7
                                   1486 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00B3C9 8A 00            [24] 1487 	mov	ar0,r2
      00B3CB 12 38 8A         [24] 1488 	lcall	_ak820_outline_0126
      00B3CE E8               [12] 1489 	mov	a,r0
      00B3CF 12 42 FE         [24] 1490 	lcall	_ak820_outline_0032
                                   1491 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00B3D2 E9               [12] 1492 	mov	a,r1
      00B3D3 F0               [24] 1493 	movx	@dptr,a
                                   1494 ;	quantum/via.c:436: break;
      00B3D4 A1 CF            [12] 1495 	ajmp	00171$
                                   1496 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00B3D6                       1497 00141$:
                                   1498 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B3D6 C0 03            [24] 1499 	push	ar3
      00B3D8 12 B5 DD         [24] 1500 	lcall	_ak820_outline_0003
      00B3DB 89 3C            [24] 1501 	mov	_raw_hid_receive_sloc0_1_0,r1
      00B3DD 8A 3D            [24] 1502 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1503 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00B3DF 12 B5 F4         [24] 1504 	lcall	_ak820_outline_0017
      00B3E2 FB               [12] 1505 	mov	r3,a
                                   1506 ;	quantum/via.c:441: if (size <= 28)
      00B3E3 8B 42            [24] 1507 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B3E5 75 43 00         [24] 1508 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B3E8 C3               [12] 1509 	clr	c
      00B3E9 74 1C            [12] 1510 	mov	a,#0x1c
      00B3EB 9B               [12] 1511 	subb	a,r3
      00B3EC D0 03            [24] 1512 	pop	ar3
      00B3EE 50 02            [24] 1513 	jnc	00562$
      00B3F0 A1 CF            [12] 1514 	ajmp	00171$
      00B3F2                       1515 00562$:
                                   1516 ;	free result
                                   1517 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00B3F2 12 B6 0F         [24] 1518 	lcall	_ak820_outline_0071
      00B3F5 90 0B EC         [24] 1519 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00B3F8 E5 42            [12] 1520 	mov	a,_raw_hid_receive_sloc3_1_0
      00B3FA F0               [24] 1521 	movx	@dptr,a
      00B3FB E5 43            [12] 1522 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B3FD A3               [24] 1523 	inc	dptr
      00B3FE F0               [24] 1524 	movx	@dptr,a
      00B3FF 90 0B EE         [24] 1525 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00B402 12 B6 19         [24] 1526 	lcall	_ak820_outline_0088
      00B405 85 3C 82         [24] 1527 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00B408 85 3D 83         [24] 1528 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00B40B C0 07            [24] 1529 	push	ar7
      00B40D C0 06            [24] 1530 	push	ar6
      00B40F C0 03            [24] 1531 	push	ar3
      00B411 12 94 BF         [24] 1532 	lcall	_dynamic_keymap_macro_get_buffer
      00B414 D0 03            [24] 1533 	pop	ar3
      00B416 D0 06            [24] 1534 	pop	ar6
      00B418 D0 07            [24] 1535 	pop	ar7
                                   1536 ;	quantum/via.c:443: break;
      00B41A A1 CF            [12] 1537 	ajmp	00171$
                                   1538 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00B41C                       1539 00144$:
                                   1540 ;	quantum/via.c:448: if (!vial_unlocked) {
      00B41C 90 0E F4         [24] 1541 	mov	dptr,#_vial_unlocked
      00B41F E0               [24] 1542 	movx	a,@dptr
      00B420 70 01            [24] 1543 	jnz	00146$
                                   1544 ;	quantum/via.c:450: return;
      00B422 22               [24] 1545 	ret
      00B423                       1546 00146$:
                                   1547 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B423 C0 03            [24] 1548 	push	ar3
      00B425 12 B5 DD         [24] 1549 	lcall	_ak820_outline_0003
      00B428 89 42            [24] 1550 	mov	_raw_hid_receive_sloc3_1_0,r1
      00B42A 8A 43            [24] 1551 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1552 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00B42C 12 B5 F4         [24] 1553 	lcall	_ak820_outline_0017
      00B42F F5 3C            [12] 1554 	mov	_raw_hid_receive_sloc0_1_0, a
      00B431 75 3D 00         [24] 1555 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1556 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00B434 85 3C 44         [24] 1557 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00B437 85 3D 45         [24] 1558 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00B43A C3               [12] 1559 	clr	c
      00B43B 74 1C            [12] 1560 	mov	a,#0x1c
      00B43D 95 44            [12] 1561 	subb	a,_raw_hid_receive_sloc4_1_0
      00B43F E4               [12] 1562 	clr	a
      00B440 95 45            [12] 1563 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B442 D0 03            [24] 1564 	pop	ar3
      00B444 40 43            [24] 1565 	jc	00147$
                                   1566 ;	free result
      00B446 8B 01            [24] 1567 	mov	ar1,r3
      00B448 7A 00            [12] 1568 	mov	r2,#0x00
      00B44A E9               [12] 1569 	mov	a,r1
      00B44B 24 FC            [12] 1570 	add	a,#0xfc
      00B44D F9               [12] 1571 	mov	r1,a
      00B44E EA               [12] 1572 	mov	a,r2
      00B44F 34 FF            [12] 1573 	addc	a,#0xff
      00B451 FA               [12] 1574 	mov	r2,a
      00B452 C3               [12] 1575 	clr	c
      00B453 E9               [12] 1576 	mov	a,r1
      00B454 95 44            [12] 1577 	subb	a,_raw_hid_receive_sloc4_1_0
      00B456 EA               [12] 1578 	mov	a,r2
      00B457 95 45            [12] 1579 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B459 40 2E            [24] 1580 	jc	00147$
                                   1581 ;	free result
      00B45B 12 B6 0F         [24] 1582 	lcall	_ak820_outline_0071
      00B45E 90 0B F3         [24] 1583 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00B461 E5 3C            [12] 1584 	mov	a,_raw_hid_receive_sloc0_1_0
      00B463 F0               [24] 1585 	movx	@dptr,a
      00B464 E5 3D            [12] 1586 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B466 A3               [24] 1587 	inc	dptr
      00B467 F0               [24] 1588 	movx	@dptr,a
      00B468 90 0B F5         [24] 1589 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00B46B 12 B6 19         [24] 1590 	lcall	_ak820_outline_0088
      00B46E 85 42 82         [24] 1591 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00B471 85 43 83         [24] 1592 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00B474 C0 07            [24] 1593 	push	ar7
      00B476 C0 06            [24] 1594 	push	ar6
      00B478 C0 03            [24] 1595 	push	ar3
      00B47A 12 95 0C         [24] 1596 	lcall	_dynamic_keymap_macro_set_buffer
      00B47D E5 82            [12] 1597 	mov	a, dpl
      00B47F D0 03            [24] 1598 	pop	ar3
      00B481 D0 06            [24] 1599 	pop	ar6
      00B483 D0 07            [24] 1600 	pop	ar7
      00B485 60 02            [24] 1601 	jz	00566$
      00B487 A1 CF            [12] 1602 	ajmp	00171$
      00B489                       1603 00566$:
      00B489                       1604 00147$:
      00B489 22               [24] 1605 	ret
                                   1606 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00B48A                       1607 00151$:
                                   1608 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00B48A 90 0E F4         [24] 1609 	mov	dptr,#_vial_unlocked
      00B48D E0               [24] 1610 	movx	a,@dptr
      00B48E 70 01            [24] 1611 	jnz	00153$
      00B490 22               [24] 1612 	ret
      00B491                       1613 00153$:
                                   1614 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00B491 C0 07            [24] 1615 	push	ar7
      00B493 C0 06            [24] 1616 	push	ar6
      00B495 C0 03            [24] 1617 	push	ar3
      00B497 12 95 3B         [24] 1618 	lcall	_dynamic_keymap_macro_reset
      00B49A D0 03            [24] 1619 	pop	ar3
      00B49C D0 06            [24] 1620 	pop	ar6
      00B49E D0 07            [24] 1621 	pop	ar7
                                   1622 ;	quantum/via.c:473: break;
      00B4A0 A1 CF            [12] 1623 	ajmp	00171$
                                   1624 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00B4A2                       1625 00154$:
                                   1626 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00B4A2 C0 07            [24] 1627 	push	ar7
      00B4A4 C0 06            [24] 1628 	push	ar6
      00B4A6 C0 05            [24] 1629 	push	ar5
      00B4A8 C0 04            [24] 1630 	push	ar4
      00B4AA C0 03            [24] 1631 	push	ar3
      00B4AC 12 8C 6C         [24] 1632 	lcall	_dynamic_keymap_get_layer_count
      00B4AF AA 82            [24] 1633 	mov	r2, dpl
      00B4B1 D0 03            [24] 1634 	pop	ar3
      00B4B3 D0 04            [24] 1635 	pop	ar4
      00B4B5 D0 05            [24] 1636 	pop	ar5
      00B4B7 D0 06            [24] 1637 	pop	ar6
      00B4B9 D0 07            [24] 1638 	pop	ar7
      00B4BB 12 38 8A         [24] 1639 	lcall	_ak820_outline_0126
      00B4BE EA               [12] 1640 	mov	a,r2
      00B4BF F0               [24] 1641 	movx	@dptr,a
                                   1642 ;	quantum/via.c:477: break;
      00B4C0 A1 CF            [12] 1643 	ajmp	00171$
                                   1644 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00B4C2                       1645 00155$:
                                   1646 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B4C2 C0 03            [24] 1647 	push	ar3
      00B4C4 12 B5 DD         [24] 1648 	lcall	_ak820_outline_0003
      00B4C7 89 44            [24] 1649 	mov	_raw_hid_receive_sloc4_1_0,r1
      00B4C9 8A 45            [24] 1650 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1651 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00B4CB 12 B5 F4         [24] 1652 	lcall	_ak820_outline_0017
      00B4CE FB               [12] 1653 	mov	r3,a
                                   1654 ;	quantum/via.c:482: if (size <= 28)
      00B4CF 8B 42            [24] 1655 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B4D1 75 43 00         [24] 1656 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B4D4 C3               [12] 1657 	clr	c
      00B4D5 74 1C            [12] 1658 	mov	a,#0x1c
      00B4D7 9B               [12] 1659 	subb	a,r3
      00B4D8 D0 03            [24] 1660 	pop	ar3
      00B4DA 50 02            [24] 1661 	jnc	00568$
      00B4DC A1 CF            [12] 1662 	ajmp	00171$
      00B4DE                       1663 00568$:
                                   1664 ;	free result
                                   1665 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00B4DE 12 B6 0F         [24] 1666 	lcall	_ak820_outline_0071
      00B4E1 90 0B D5         [24] 1667 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00B4E4 E5 42            [12] 1668 	mov	a,_raw_hid_receive_sloc3_1_0
      00B4E6 F0               [24] 1669 	movx	@dptr,a
      00B4E7 E5 43            [12] 1670 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B4E9 A3               [24] 1671 	inc	dptr
      00B4EA F0               [24] 1672 	movx	@dptr,a
      00B4EB 90 0B D7         [24] 1673 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00B4EE 12 B6 19         [24] 1674 	lcall	_ak820_outline_0088
      00B4F1 85 44 82         [24] 1675 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B4F4 85 45 83         [24] 1676 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B4F7 C0 07            [24] 1677 	push	ar7
      00B4F9 C0 06            [24] 1678 	push	ar6
      00B4FB C0 03            [24] 1679 	push	ar3
      00B4FD 12 92 88         [24] 1680 	lcall	_dynamic_keymap_get_buffer
      00B500 D0 03            [24] 1681 	pop	ar3
      00B502 D0 06            [24] 1682 	pop	ar6
      00B504 D0 07            [24] 1683 	pop	ar7
                                   1684 ;	quantum/via.c:484: break;
      00B506 A1 CF            [12] 1685 	ajmp	00171$
                                   1686 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00B508                       1687 00158$:
                                   1688 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B508 12 43 37         [24] 1689 	lcall	_ak820_outline_0095
      00B50B FD               [12] 1690 	mov	r5,a
      00B50C 7C 00            [12] 1691 	mov	r4,#0x00
      00B50E 12 38 2C         [24] 1692 	lcall	_ak820_outline_0037
      00B511 7A 00            [12] 1693 	mov	r2,#0x00
      00B513 42 04            [12] 1694 	orl	ar4,a
      00B515 EA               [12] 1695 	mov	a,r2
      00B516 42 05            [12] 1696 	orl	ar5,a
      00B518 8C 44            [24] 1697 	mov	_raw_hid_receive_sloc4_1_0,r4
      00B51A 8D 45            [24] 1698 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1699 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00B51C 12 B5 F4         [24] 1700 	lcall	_ak820_outline_0017
      00B51F F9               [12] 1701 	mov	r1,a
      00B520 7A 00            [12] 1702 	mov	r2,#0x00
                                   1703 ;	quantum/via.c:489: if (size <= 28)
      00B522 89 00            [24] 1704 	mov	ar0,r1
      00B524 E8               [12] 1705 	mov	a,r0
      00B525 24 E3            [12] 1706 	add	a,#0xff - 0x1c
      00B527 50 02            [24] 1707 	jnc	00569$
      00B529 A1 CF            [12] 1708 	ajmp	00171$
      00B52B                       1709 00569$:
                                   1710 ;	free result
                                   1711 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00B52B C0 03            [24] 1712 	push	ar3
      00B52D 74 04            [12] 1713 	mov	a,#0x04
      00B52F 2E               [12] 1714 	add	a, r6
      00B530 F8               [12] 1715 	mov	r0,a
      00B531 E4               [12] 1716 	clr	a
      00B532 3F               [12] 1717 	addc	a, r7
      00B533 FB               [12] 1718 	mov	r3,a
      00B534 7D 00            [12] 1719 	mov	r5,#0x00
      00B536 90 0B DC         [24] 1720 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00B539 12 52 18         [24] 1721 	lcall	_ak820_outline_0100
      00B53C 90 0B DE         [24] 1722 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00B53F E8               [12] 1723 	mov	a,r0
      00B540 12 80 57         [24] 1724 	lcall	_ak820_outline_0188
      00B543 ED               [12] 1725 	mov	a,r5
      00B544 A3               [24] 1726 	inc	dptr
      00B545 F0               [24] 1727 	movx	@dptr,a
      00B546 85 44 82         [24] 1728 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B549 85 45 83         [24] 1729 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B54C C0 07            [24] 1730 	push	ar7
      00B54E C0 06            [24] 1731 	push	ar6
      00B550 C0 03            [24] 1732 	push	ar3
      00B552 12 92 C6         [24] 1733 	lcall	_dynamic_keymap_set_buffer
      00B555 D0 03            [24] 1734 	pop	ar3
      00B557 D0 06            [24] 1735 	pop	ar6
      00B559 D0 07            [24] 1736 	pop	ar7
                                   1737 ;	quantum/via.c:491: break;
      00B55B D0 03            [24] 1738 	pop	ar3
      00B55D A1 CF            [12] 1739 	ajmp	00171$
                                   1740 ;	quantum/via.c:495: case id_bootloader_jump: {
      00B55F                       1741 00161$:
                                   1742 ;	quantum/via.c:497: if (!vial_unlocked)
      00B55F 90 0E F4         [24] 1743 	mov	dptr,#_vial_unlocked
      00B562 E0               [24] 1744 	movx	a,@dptr
      00B563 70 02            [24] 1745 	jnz	00570$
      00B565 A1 CF            [12] 1746 	ajmp	00171$
      00B567                       1747 00570$:
                                   1748 ;	quantum/via.c:501: raw_hid_send(data, length);
      00B567 12 B6 2B         [24] 1749 	lcall	_ak820_outline_0151
      00B56A 90 07 25         [24] 1750 	mov	dptr,#_raw_hid_send_PARM_2
      00B56D 12 B6 22         [24] 1751 	lcall	_ak820_outline_0089
      00B570 C0 07            [24] 1752 	push	ar7
      00B572 C0 06            [24] 1753 	push	ar6
      00B574 C0 03            [24] 1754 	push	ar3
      00B576 12 54 5D         [24] 1755 	lcall	_raw_hid_send
      00B579 D0 03            [24] 1756 	pop	ar3
      00B57B D0 06            [24] 1757 	pop	ar6
      00B57D D0 07            [24] 1758 	pop	ar7
                                   1759 ;	quantum/via.c:503: wait_ms(100);
      00B57F 7D 64            [12] 1760 	mov	r5,#0x64
      00B581                       1761 00176$:
      00B581 ED               [12] 1762 	mov	a,r5
      00B582 60 09            [24] 1763 	jz	00166$
      00B584 90 00 01         [24] 1764 	mov	dptr,#0x0001
      00B587 12 62 04         [24] 1765 	lcall	_mDelaymS
      00B58A 1D               [12] 1766 	dec	r5
      00B58B 80 F4            [24] 1767 	sjmp	00176$
      00B58D                       1768 00166$:
                                   1769 ;	quantum/via.c:504: bootloader_jump();
      00B58D C0 07            [24] 1770 	push	ar7
      00B58F C0 06            [24] 1771 	push	ar6
      00B591 C0 03            [24] 1772 	push	ar3
      00B593 12 34 0E         [24] 1773 	lcall	_bootloader_jump
      00B596 D0 03            [24] 1774 	pop	ar3
      00B598 D0 06            [24] 1775 	pop	ar6
      00B59A D0 07            [24] 1776 	pop	ar7
                                   1777 ;	quantum/via.c:505: break;
                                   1778 ;	quantum/via.c:509: case id_vial_prefix: {
      00B59C 80 31            [24] 1779 	sjmp	00171$
      00B59E                       1780 00168$:
                                   1781 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B59E 12 B6 2B         [24] 1782 	lcall	_ak820_outline_0151
      00B5A1 90 0D 1F         [24] 1783 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B5A4 12 B6 22         [24] 1784 	lcall	_ak820_outline_0089
      00B5A7 C0 07            [24] 1785 	push	ar7
      00B5A9 C0 06            [24] 1786 	push	ar6
      00B5AB C0 03            [24] 1787 	push	ar3
      00B5AD 12 B7 1D         [24] 1788 	lcall	_vial_handle_cmd
      00B5B0 D0 03            [24] 1789 	pop	ar3
      00B5B2 D0 06            [24] 1790 	pop	ar6
      00B5B4 D0 07            [24] 1791 	pop	ar7
                                   1792 ;	quantum/via.c:511: break;
                                   1793 ;	quantum/via.c:514: default: {
      00B5B6 80 17            [24] 1794 	sjmp	00171$
      00B5B8                       1795 00169$:
                                   1796 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B5B8 12 B6 2B         [24] 1797 	lcall	_ak820_outline_0151
      00B5BB 90 0D 0D         [24] 1798 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B5BE 12 B6 22         [24] 1799 	lcall	_ak820_outline_0089
      00B5C1 C0 07            [24] 1800 	push	ar7
      00B5C3 C0 06            [24] 1801 	push	ar6
      00B5C5 C0 03            [24] 1802 	push	ar3
      00B5C7 11 68            [24] 1803 	acall	_raw_hid_receive_kb
      00B5C9 D0 03            [24] 1804 	pop	ar3
      00B5CB D0 06            [24] 1805 	pop	ar6
      00B5CD D0 07            [24] 1806 	pop	ar7
                                   1807 ;	quantum/via.c:521: skip:
      00B5CF                       1808 00171$:
                                   1809 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B5CF 7D 00            [12] 1810 	mov	r5,#0x00
      00B5D1 90 07 25         [24] 1811 	mov	dptr,#_raw_hid_send_PARM_2
      00B5D4 EB               [12] 1812 	mov	a,r3
      00B5D5 12 43 31         [24] 1813 	lcall	_ak820_outline_0068
      00B5D8 8D F0            [24] 1814 	mov	b, r5
                                   1815 ;	quantum/via.c:526: }
      00B5DA 02 54 5D         [24] 1816 	ljmp	_raw_hid_send
                                   1817 	.area CSEG    (CODE)
                                   1818 	.area CONST   (CODE)
                                   1819 	.area XINIT   (CODE)
                                   1820 	.area CABS    (ABS,CODE)
                                   1821 
                                   1822 ; Experimental exact instruction outlining.
                                   1823 	.globl _ak820_outline_0001
                                   1824 	.globl _ak820_outline_0003
                                   1825 	.globl _ak820_outline_0009
                                   1826 	.globl _ak820_outline_0012
                                   1827 	.globl _ak820_outline_0013
                                   1828 	.globl _ak820_outline_0017
                                   1829 	.globl _ak820_outline_0018
                                   1830 	.globl _ak820_outline_0019
                                   1831 	.globl _ak820_outline_0024
                                   1832 	.globl _ak820_outline_0032
                                   1833 	.globl _ak820_outline_0037
                                   1834 	.globl _ak820_outline_0038
                                   1835 	.globl _ak820_outline_0044
                                   1836 	.globl _ak820_outline_0047
                                   1837 	.globl _ak820_outline_0054
                                   1838 	.globl _ak820_outline_0060
                                   1839 	.globl _ak820_outline_0068
                                   1840 	.globl _ak820_outline_0071
                                   1841 	.globl _ak820_outline_0076
                                   1842 	.globl _ak820_outline_0088
                                   1843 	.globl _ak820_outline_0089
                                   1844 	.globl _ak820_outline_0095
                                   1845 	.globl _ak820_outline_0100
                                   1846 	.globl _ak820_outline_0108
                                   1847 	.globl _ak820_outline_0109
                                   1848 	.globl _ak820_outline_0113
                                   1849 	.globl _ak820_outline_0120
                                   1850 	.globl _ak820_outline_0122
                                   1851 	.globl _ak820_outline_0126
                                   1852 	.globl _ak820_outline_0151
                                   1853 	.globl _ak820_outline_0153
                                   1854 	.globl _ak820_outline_0157
                                   1855 	.globl _ak820_outline_0159
                                   1856 	.globl _ak820_outline_0161
                                   1857 	.globl _ak820_outline_0162
                                   1858 	.globl _ak820_outline_0187
                                   1859 	.globl _ak820_outline_0188
                                   1860 
                                   1861 	.area CSEG (CODE)
                                   1862 ; function ak820_outline_0003
      00B5DD                       1863 _ak820_outline_0003:
      00B5DD 8C 82            [24] 1864 	mov	dpl,r4
      00B5DF 8D 83            [24] 1865 	mov	dph,r5
      00B5E1 E0               [24] 1866 	movx	a,@dptr
      00B5E2 FA               [12] 1867 	mov	r2,a
      00B5E3 79 00            [12] 1868 	mov	r1,#0x00
      00B5E5 8E 82            [24] 1869 	mov	dpl,r6
      00B5E7 8F 83            [24] 1870 	mov	dph,r7
      00B5E9 A3               [24] 1871 	inc	dptr
      00B5EA A3               [24] 1872 	inc	dptr
      00B5EB E0               [24] 1873 	movx	a,@dptr
      00B5EC 7B 00            [12] 1874 	mov	r3,#0x00
      00B5EE 42 01            [12] 1875 	orl	ar1,a
      00B5F0 EB               [12] 1876 	mov	a,r3
      00B5F1 42 02            [12] 1877 	orl	ar2,a
      00B5F3 22               [24] 1878 	ret
                                   1879 
                                   1880 	.area CSEG (CODE)
                                   1881 ; function ak820_outline_0017
      00B5F4                       1882 _ak820_outline_0017:
      00B5F4 8E 82            [24] 1883 	mov	dpl,r6
      00B5F6 8F 83            [24] 1884 	mov	dph,r7
      00B5F8 A3               [24] 1885 	inc	dptr
      00B5F9 A3               [24] 1886 	inc	dptr
      00B5FA A3               [24] 1887 	inc	dptr
      00B5FB E0               [24] 1888 	movx	a,@dptr
      00B5FC 22               [24] 1889 	ret
                                   1890 
                                   1891 	.area CSEG (CODE)
                                   1892 ; function ak820_outline_0024
      00B5FD                       1893 _ak820_outline_0024:
      00B5FD 8E 82            [24] 1894 	mov	dpl,r6
      00B5FF 8F 83            [24] 1895 	mov	dph,r7
      00B601 A3               [24] 1896 	inc	dptr
      00B602 A3               [24] 1897 	inc	dptr
      00B603 A3               [24] 1898 	inc	dptr
      00B604 A3               [24] 1899 	inc	dptr
      00B605 22               [24] 1900 	ret
                                   1901 
                                   1902 	.area CSEG (CODE)
                                   1903 ; function ak820_outline_0044
      00B606                       1904 _ak820_outline_0044:
      00B606 EB               [12] 1905 	mov	a,r3
      00B607 F0               [24] 1906 	movx	@dptr,a
      00B608 88 82            [24] 1907 	mov	dpl,r0
      00B60A 89 83            [24] 1908 	mov	dph,r1
      00B60C 8A F0            [24] 1909 	mov	b,r2
      00B60E 22               [24] 1910 	ret
                                   1911 
                                   1912 	.area CSEG (CODE)
                                   1913 ; function ak820_outline_0071
      00B60F                       1914 _ak820_outline_0071:
      00B60F 74 04            [12] 1915 	mov	a,#0x04
      00B611 2E               [12] 1916 	add	a,r6
      00B612 F9               [12] 1917 	mov	r1,a
      00B613 E4               [12] 1918 	clr	a
      00B614 3F               [12] 1919 	addc	a,r7
      00B615 F8               [12] 1920 	mov	r0,a
      00B616 7A 00            [12] 1921 	mov	r2,#0x00
      00B618 22               [24] 1922 	ret
                                   1923 
                                   1924 	.area CSEG (CODE)
                                   1925 ; function ak820_outline_0088
      00B619                       1926 _ak820_outline_0088:
      00B619 E9               [12] 1927 	mov	a,r1
      00B61A F0               [24] 1928 	movx	@dptr,a
      00B61B E8               [12] 1929 	mov	a,r0
      00B61C A3               [24] 1930 	inc	dptr
      00B61D F0               [24] 1931 	movx	@dptr,a
      00B61E EA               [12] 1932 	mov	a,r2
      00B61F A3               [24] 1933 	inc	dptr
      00B620 F0               [24] 1934 	movx	@dptr,a
      00B621 22               [24] 1935 	ret
                                   1936 
                                   1937 	.area CSEG (CODE)
                                   1938 ; function ak820_outline_0089
      00B622                       1939 _ak820_outline_0089:
      00B622 EB               [12] 1940 	mov	a,r3
      00B623 F0               [24] 1941 	movx	@dptr,a
      00B624 8A 82            [24] 1942 	mov	dpl,r2
      00B626 8C 83            [24] 1943 	mov	dph,r4
      00B628 8D F0            [24] 1944 	mov	b,r5
      00B62A 22               [24] 1945 	ret
                                   1946 
                                   1947 	.area CSEG (CODE)
                                   1948 ; function ak820_outline_0151
      00B62B                       1949 _ak820_outline_0151:
      00B62B 8E 02            [24] 1950 	mov	ar2,r6
      00B62D 8F 04            [24] 1951 	mov	ar4,r7
      00B62F 7D 00            [12] 1952 	mov	r5,#0x00
      00B631 22               [24] 1953 	ret
                                   1954 
                                   1955 	.area CSEG (CODE)
                                   1956 ; function ak820_outline_0187
      00B632                       1957 _ak820_outline_0187:
      00B632 A9 82            [24] 1958 	mov	r1,dpl
      00B634 AA 83            [24] 1959 	mov	r2,dph
      00B636 22               [24] 1960 	ret
