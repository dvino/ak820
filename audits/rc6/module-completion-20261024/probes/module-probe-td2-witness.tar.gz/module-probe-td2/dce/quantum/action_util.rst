                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000058                        551 _change_owned_sloc1_1_0:
      000058                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000023                        566 _ak820_macro_change_sloc0_1_0:
      000023                        567 	.ds 1
      000024                        568 _change_owned_sloc0_1_0:
      000024                        569 	.ds 1
      000025                        570 _owned_usage_key_sloc0_1_0:
      000025                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000A1F                        580 _owned_mod_refs:
      000A1F                        581 	.ds 8
      000A27                        582 _owned_weak_refs:
      000A27                        583 	.ds 8
      000A2F                        584 _owned_mods:
      000A2F                        585 	.ds 1
      000A30                        586 _owned_weak_mods:
      000A30                        587 	.ds 1
      000A31                        588 _macro_mods:
      000A31                        589 	.ds 2
      000A33                        590 _ak820_macro_primitive::
      000A33                        591 	.ds 1
      000A34                        592 _ak820_macro_cancelled::
      000A34                        593 	.ds 1
      000A35                        594 _ak820_macro_change_PARM_2:
      000A35                        595 	.ds 1
      000A36                        596 _ak820_macro_change_PARM_3:
      000A36                        597 	.ds 1
      000A37                        598 _ak820_macro_change_bits_10000_293:
      000A37                        599 	.ds 2
      000A39                        600 _change_owned_PARM_2:
      000A39                        601 	.ds 1
      000A3A                        602 _change_owned_mods_10000_298:
      000A3A                        603 	.ds 1
      000A3B                        604 _change_owned_result_10001_302:
      000A3B                        605 	.ds 1
      000A3C                        606 _change_owned_bit_20001_303:
      000A3C                        607 	.ds 1
      000A3D                        608 _add_owned_mods_mods_10000_311:
      000A3D                        609 	.ds 1
      000A3E                        610 _del_owned_mods_mods_10000_313:
      000A3E                        611 	.ds 1
      000A3F                        612 _add_owned_weak_mods_mods_10000_315:
      000A3F                        613 	.ds 1
      000A40                        614 _del_owned_weak_mods_mods_10000_317:
      000A40                        615 	.ds 1
      000A41                        616 _key_refs:
      000A41                        617 	.ds 165
      000AE6                        618 _distinct_keys:
      000AE6                        619 	.ds 1
      000AE7                        620 _macro_keys:
      000AE7                        621 	.ds 21
      000AFC                        622 _add_owned_key_code_10000_326:
      000AFC                        623 	.ds 1
      000AFD                        624 _del_owned_key_code_10000_341:
      000AFD                        625 	.ds 1
      000AFE                        626 _usage_refs:
      000AFE                        627 	.ds 30
      000B1C                        628 _usage_order:
      000B1C                        629 	.ds 30
      000B3A                        630 _usage_lengths:
      000B3A                        631 	.ds 2
      000B3C                        632 _macro_usages:
      000B3C                        633 	.ds 4
      000B40                        634 _owned_usage_key_PARM_2:
      000B40                        635 	.ds 1
      000B41                        636 _owned_usage_key_code_10000_368:
      000B41                        637 	.ds 1
      000B42                        638 _owned_usage_key___200000085_20000_369:
      000B42                        639 	.ds 2
      000B44                        640 _owned_usage_key_which_10000_369:
      000B44                        641 	.ds 1
      000B45                        642 _owned_usage_key_count_10000_369:
      000B45                        643 	.ds 1
      000B46                        644 _owned_usage_key_pos_30001_376:
      000B46                        645 	.ds 1
      000B47                        646 _owned_usage_key_key_40000_381:
      000B47                        647 	.ds 1
      000B48                        648 _send_keyboard_report_last_report_10001_388:
      000B48                        649 	.ds 32
      000B68                        650 _send_keyboard_report_changed_10001_388:
      000B68                        651 	.ds 1
      000B69                        652 _add_weak_mods_mods_10000_406:
      000B69                        653 	.ds 1
      000B6A                        654 _del_weak_mods_mods_10000_408:
      000B6A                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000E97                        664 _real_mods:
      000E97                        665 	.ds 1
      000E98                        666 _weak_mods:
      000E98                        667 	.ds 1
      000E99                        668 _actual_keyboard_report::
      000E99                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      00845A                        713 _ak820_macro_change:
      00845A 12 38 75         [24]  714 	lcall	_ak820_outline_0108
      00845D 90 0A 37         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      008460 12 38 7A         [24]  716 	lcall	_ak820_outline_0109
                                    717 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      008463 90 0A 33         [24]  718 	mov	dptr,#_ak820_macro_primitive
      008466 E0               [24]  719 	movx	a,@dptr
      008467 70 04            [24]  720 	jnz	00102$
      008469 75 82 01         [24]  721 	mov	dpl, #0x01
      00846C 22               [24]  722 	ret
      00846D                        723 00102$:
                                    724 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      00846D 90 0A 35         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      008470 E0               [24]  726 	movx	a,@dptr
      008471 FF               [12]  727 	mov	r7,a
      008472 74 07            [12]  728 	mov	a,#0x07
      008474 5F               [12]  729 	anl	a,r7
      008475 12 80 02         [24]  730 	lcall	_ak820_outline_0064
      008478 80 02            [24]  731 	sjmp	00123$
      00847A                        732 00122$:
      00847A 25 E0            [12]  733 	add	a,acc
      00847C                        734 00123$:
      00847C D5 F0 FB         [24]  735 	djnz	b,00122$
      00847F FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:101: bits += index >> 3;
      008480 EF               [12]  738 	mov	a,r7
      008481 12 60 7D         [24]  739 	lcall	_ak820_outline_0189
      008484 FF               [12]  740 	mov	r7,a
      008485 90 0A 37         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      008488 12 38 4B         [24]  742 	lcall	_ak820_outline_0062
      00848B 90 0A 37         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      00848E EF               [12]  744 	mov	a,r7
      00848F 2C               [12]  745 	add	a, r4
      008490 F0               [24]  746 	movx	@dptr,a
      008491 E4               [12]  747 	clr	a
      008492 3D               [12]  748 	addc	a, r5
      008493 A3               [24]  749 	inc	dptr
      008494 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      008495 90 0A 37         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      008498 E0               [24]  753 	movx	a,@dptr
      008499 FD               [12]  754 	mov	r5,a
      00849A A3               [24]  755 	inc	dptr
      00849B E0               [24]  756 	movx	a,@dptr
      00849C FF               [12]  757 	mov	r7,a
      00849D 12 89 D9         [24]  758 	lcall	_ak820_outline_0190
      0084A0 E0               [24]  759 	movx	a,@dptr
      0084A1 FC               [12]  760 	mov	r4,a
      0084A2 EE               [12]  761 	mov	a,r6
      0084A3 5C               [12]  762 	anl	a,r4
      0084A4 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      0084A7                        764 00124$:
      0084A7 B3               [12]  765 	cpl	c
      0084A8 92 23            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      0084AA 90 0A 36         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      0084AD E0               [24]  768 	movx	a,@dptr
      0084AE FB               [12]  769 	mov	r3,a
      0084AF A2 23            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      0084B1 E4               [12]  771 	clr	a
      0084B2 33               [12]  772 	rlc	a
      0084B3 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      0084B6 75 82 00         [24]  774 	mov	dpl, #0x00
      0084B9 22               [24]  775 	ret
      0084BA                        776 00104$:
                                    777 ;	quantum/action_util.c:103: *bits ^= mask;
      0084BA EC               [12]  778 	mov	a,r4
      0084BB 62 06            [12]  779 	xrl	ar6,a
      0084BD 12 89 D9         [24]  780 	lcall	_ak820_outline_0190
      0084C0 EE               [12]  781 	mov	a,r6
      0084C1 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:104: return true;
      0084C2 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:105: }
      0084C5 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      0084C6                        805 _change_owned:
      0084C6 E5 82            [12]  806 	mov	a,dpl
      0084C8 90 0A 3A         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      0084CB F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      0084CC 90 0A 39         [24]  810 	mov	dptr,#_change_owned_PARM_2
      0084CF E0               [24]  811 	movx	a,@dptr
      0084D0 FF               [12]  812 	mov	r7,a
      0084D1 C3               [12]  813 	clr	c
      0084D2 13               [12]  814 	rrc	a
      0084D3 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      0084D4 53 07 01         [24]  817 	anl	ar7,#0x01
      0084D7 EF               [12]  818 	mov	a,r7
      0084D8 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      0084DB                        820 00205$:
      0084DB 92 24            [24]  821 	mov  _change_owned_sloc0_1_0,c
      0084DD B3               [12]  822 	cpl	c
      0084DE E4               [12]  823 	clr	a
      0084DF 33               [12]  824 	rlc	a
      0084E0 F5 58            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      0084E2 EE               [12]  827 	mov	a,r6
      0084E3 60 06            [24]  828 	jz	00121$
      0084E5 7D 27            [12]  829 	mov	r5,#_owned_weak_refs
      0084E7 7F 0A            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      0084E9 80 04            [24]  831 	sjmp	00122$
      0084EB                        832 00121$:
      0084EB 7D 1F            [12]  833 	mov	r5,#_owned_mod_refs
      0084ED 7F 0A            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      0084EF                        835 00122$:
                                    836 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      0084EF 90 0A 33         [24]  837 	mov	dptr,#_ak820_macro_primitive
      0084F2 E0               [24]  838 	movx	a,@dptr
      0084F3 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      0084F5 EE               [12]  841 	mov	a,r6
      0084F6 24 31            [12]  842 	add	a, #_macro_mods
      0084F8 FB               [12]  843 	mov	r3,a
      0084F9 E4               [12]  844 	clr	a
      0084FA 34 0A            [12]  845 	addc	a, #(_macro_mods >> 8)
      0084FC 12 51 E1         [24]  846 	lcall	_ak820_outline_0058
                                    847 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      0084FF E5 58            [12]  848 	mov	a,_change_owned_sloc1_1_0
      008501 60 0A            [24]  849 	jz	00123$
      008503 90 0A 3A         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      008506 E0               [24]  851 	movx	a,@dptr
      008507 F9               [12]  852 	mov	r1,a
      008508 EA               [12]  853 	mov	a,r2
      008509 42 01            [12]  854 	orl	ar1,a
      00850B 80 07            [24]  855 	sjmp	00124$
      00850D                        856 00123$:
      00850D 90 0A 3A         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      008510 E0               [24]  858 	movx	a,@dptr
      008511 F4               [12]  859 	cpl	a
      008512 5A               [12]  860 	anl	a,r2
      008513 F9               [12]  861 	mov	r1,a
      008514                        862 00124$:
      008514 12 33 FC         [24]  863 	lcall	_ak820_outline_0123
      008517 E9               [12]  864 	mov	a,r1
      008518 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      008519 E5 58            [12]  867 	mov	a,_change_owned_sloc1_1_0
      00851B 60 06            [24]  868 	jz	00125$
      00851D 74 FF            [12]  869 	mov	a,#0xff
      00851F 6A               [12]  870 	xrl	a,r2
      008520 FC               [12]  871 	mov	r4,a
      008521 80 02            [24]  872 	sjmp	00126$
      008523                        873 00125$:
      008523 8A 04            [24]  874 	mov	ar4,r2
      008525                        875 00126$:
      008525 90 0A 3A         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      008528 E0               [24]  877 	movx	a,@dptr
      008529 5C               [12]  878 	anl	a,r4
      00852A F0               [24]  879 	movx	@dptr,a
      00852B                        880 00102$:
                                    881 ;	quantum/action_util.c:115: uint8_t result = 0;
      00852B 90 0A 3B         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      00852E E4               [12]  883 	clr	a
      00852F F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      008530 90 0A 3C         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      008533 04               [12]  887 	inc	a
      008534 F0               [24]  888 	movx	@dptr,a
      008535 90 0A 3A         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      008538 E0               [24]  890 	movx	a,@dptr
      008539 FC               [12]  891 	mov	r4,a
      00853A 7B 00            [12]  892 	mov	r3,#0x00
      00853C                        893 00117$:
      00853C BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      00853F                        895 00210$:
      00853F 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:117: if (mods & bit) {
      008541 90 0A 3C         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      008544 E0               [24]  899 	movx	a,@dptr
      008545 5C               [12]  900 	anl	a,r4
      008546 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      008548 E5 58            [12]  903 	mov	a,_change_owned_sloc1_1_0
      00854A 60 0C            [24]  904 	jz	00106$
      00854C EB               [12]  905 	mov	a,r3
      00854D 2D               [12]  906 	add	a, r5
      00854E 12 38 12         [24]  907 	lcall	_ak820_outline_0018
      008551 F8               [12]  908 	mov	r0,a
      008552 08               [12]  909 	inc	r0
      008553 12 89 8D         [24]  910 	lcall	_ak820_outline_0065
      008556 80 0C            [24]  911 	sjmp	00109$
      008558                        912 00106$:
                                    913 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      008558 EB               [12]  914 	mov	a,r3
      008559 2D               [12]  915 	add	a, r5
      00855A 12 38 12         [24]  916 	lcall	_ak820_outline_0018
      00855D F8               [12]  917 	mov	r0,a
      00855E 60 04            [24]  918 	jz	00109$
      008560 18               [12]  919 	dec	r0
      008561 12 89 8D         [24]  920 	lcall	_ak820_outline_0065
      008564                        921 00109$:
                                    922 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      008564 EB               [12]  923 	mov	a,r3
      008565 2D               [12]  924 	add	a, r5
      008566 12 38 12         [24]  925 	lcall	_ak820_outline_0018
      008569 60 0B            [24]  926 	jz	00118$
      00856B 90 0A 3C         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      00856E E0               [24]  928 	movx	a,@dptr
      00856F FA               [12]  929 	mov	r2,a
      008570 90 0A 3B         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      008573 E0               [24]  931 	movx	a,@dptr
      008574 4A               [12]  932 	orl	a,r2
      008575 F0               [24]  933 	movx	@dptr,a
      008576                        934 00118$:
                                    935 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      008576 0B               [12]  936 	inc	r3
      008577 90 0A 3C         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      00857A E0               [24]  938 	movx	a,@dptr
      00857B 25 E0            [12]  939 	add	a,acc
      00857D F0               [24]  940 	movx	@dptr,a
      00857E 80 BC            [24]  941 	sjmp	00117$
      008580                        942 00112$:
                                    943 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      008580 EE               [12]  944 	mov	a,r6
      008581 60 09            [24]  945 	jz	00114$
      008583 90 0A 3B         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      008586 E0               [24]  947 	movx	a,@dptr
      008587 90 0A 30         [24]  948 	mov	dptr,#_owned_weak_mods
      00858A F0               [24]  949 	movx	@dptr,a
      00858B 22               [24]  950 	ret
      00858C                        951 00114$:
                                    952 ;	quantum/action_util.c:124: else owned_mods = result;
      00858C 90 0A 3B         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      00858F E0               [24]  954 	movx	a,@dptr
      008590 90 0A 2F         [24]  955 	mov	dptr,#_owned_mods
      008593 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:125: }
      008594 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      008595                        968 _add_owned_mods:
      008595 E5 82            [12]  969 	mov	a,dpl
      008597 90 0A 3D         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      00859A 12 89 AD         [24]  971 	lcall	_ak820_outline_0119
      00859D 74 01            [12]  972 	mov	a,#0x01
      00859F F0               [24]  973 	movx	@dptr,a
      0085A0 8F 82            [24]  974 	mov	dpl, r7
      0085A2 81 C6            [12]  975 	ajmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      0085A4                        985 _del_owned_mods:
      0085A4 E5 82            [12]  986 	mov	a,dpl
      0085A6 90 0A 3E         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      0085A9 12 89 AD         [24]  988 	lcall	_ak820_outline_0119
      0085AC E4               [12]  989 	clr	a
      0085AD F0               [24]  990 	movx	@dptr,a
      0085AE 8F 82            [24]  991 	mov	dpl, r7
      0085B0 81 C6            [12]  992 	ajmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      0085B2                       1002 _add_owned_weak_mods:
      0085B2 E5 82            [12] 1003 	mov	a,dpl
      0085B4 90 0A 3F         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      0085B7 12 89 AD         [24] 1005 	lcall	_ak820_outline_0119
      0085BA 74 03            [12] 1006 	mov	a,#0x03
      0085BC F0               [24] 1007 	movx	@dptr,a
      0085BD 8F 82            [24] 1008 	mov	dpl, r7
      0085BF 81 C6            [12] 1009 	ajmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      0085C1                       1019 _del_owned_weak_mods:
      0085C1 E5 82            [12] 1020 	mov	a,dpl
      0085C3 90 0A 40         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      0085C6 12 89 AD         [24] 1022 	lcall	_ak820_outline_0119
      0085C9 74 02            [12] 1023 	mov	a,#0x02
      0085CB F0               [24] 1024 	movx	@dptr,a
      0085CC 8F 82            [24] 1025 	mov	dpl, r7
      0085CE 81 C6            [12] 1026 	ajmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      0085D0                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      0085D0 7F 00            [12] 1038 	mov	r7,#0x00
      0085D2                       1039 00103$:
      0085D2 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      0085D5                       1041 00122$:
      0085D5 50 1A            [24] 1042 	jnc	00101$
      0085D7 EF               [12] 1043 	mov	a,r7
      0085D8 24 1F            [12] 1044 	add	a, #_owned_mod_refs
      0085DA FD               [12] 1045 	mov	r5,a
      0085DB E4               [12] 1046 	clr	a
      0085DC 34 0A            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      0085DE FE               [12] 1048 	mov	r6,a
      0085DF EF               [12] 1049 	mov	a,r7
      0085E0 24 27            [12] 1050 	add	a, #_owned_weak_refs
      0085E2 F5 82            [12] 1051 	mov	dpl,a
      0085E4 E4               [12] 1052 	clr	a
      0085E5 34 0A            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      0085E7 F5 83            [12] 1054 	mov	dph,a
      0085E9 E4               [12] 1055 	clr	a
      0085EA F0               [24] 1056 	movx	@dptr,a
      0085EB 12 89 B4         [24] 1057 	lcall	_ak820_outline_0124
      0085EE 0F               [12] 1058 	inc	r7
      0085EF 80 E1            [24] 1059 	sjmp	00103$
      0085F1                       1060 00101$:
                                   1061 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      0085F1 90 0A 32         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      0085F4 E4               [12] 1063 	clr	a
      0085F5 F0               [24] 1064 	movx	@dptr,a
      0085F6 90 0A 31         [24] 1065 	mov	dptr,#_macro_mods
      0085F9 F0               [24] 1066 	movx	@dptr,a
      0085FA 90 0A 30         [24] 1067 	mov	dptr,#_owned_weak_mods
      0085FD F0               [24] 1068 	movx	@dptr,a
      0085FE 90 0A 2F         [24] 1069 	mov	dptr,#_owned_mods
      008601 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      008602 90 0A 34         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      008605 04               [12] 1073 	inc	a
      008606 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:134: }
      008607 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      008608                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      008608 7F 00            [12] 1089 	mov	r7,#0x00
      00860A                       1090 00104$:
      00860A EF               [12] 1091 	mov	a,r7
      00860B 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      00860D 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      00860F EF               [12] 1095 	mov	a,r7
      008610 24 41            [12] 1096 	add	a, #_key_refs
      008612 F5 82            [12] 1097 	mov	dpl,a
      008614 E4               [12] 1098 	clr	a
      008615 34 0A            [12] 1099 	addc	a, #(_key_refs >> 8)
      008617 12 84 4B         [24] 1100 	lcall	_ak820_outline_0164
      00861A 80 EE            [24] 1101 	sjmp	00104$
      00861C                       1102 00101$:
                                   1103 ;	quantum/action_util.c:142: distinct_keys = 0;
      00861C 90 0A E6         [24] 1104 	mov	dptr,#_distinct_keys
      00861F E4               [12] 1105 	clr	a
      008620 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      008621 FF               [12] 1108 	mov	r7,a
      008622                       1109 00107$:
      008622 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      008625                       1111 00142$:
      008625 50 0D            [24] 1112 	jnc	00109$
      008627 EF               [12] 1113 	mov	a,r7
      008628 24 E7            [12] 1114 	add	a, #_macro_keys
      00862A F5 82            [12] 1115 	mov	dpl,a
      00862C E4               [12] 1116 	clr	a
      00862D 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      00862F 12 84 4B         [24] 1118 	lcall	_ak820_outline_0164
      008632 80 EE            [24] 1119 	sjmp	00107$
      008634                       1120 00109$:
                                   1121 ;	quantum/action_util.c:144: }
      008634 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      008635                       1137 _add_owned_key:
      008635 E5 82            [12] 1138 	mov	a,dpl
      008637 90 0A FC         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      00863A 12 89 C5         [24] 1140 	lcall	_ak820_outline_0134
                                   1141 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      00863D 74 01            [12] 1142 	mov	a,#0x01
      00863F F0               [24] 1143 	movx	@dptr,a
      008640 90 0A E7         [24] 1144 	mov	dptr,#_macro_keys
      008643 C0 07            [24] 1145 	push	ar7
      008645 91 5A            [12] 1146 	acall	_ak820_macro_change
      008647 E5 82            [12] 1147 	mov	a, dpl
      008649 D0 07            [24] 1148 	pop	ar7
      00864B 70 03            [24] 1149 	jnz	00102$
      00864D F5 82            [12] 1150 	mov	dpl,a
      00864F 22               [24] 1151 	ret
      008650                       1152 00102$:
                                   1153 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      008650 12 89 7F         [24] 1154 	lcall	_ak820_outline_0031
      008653 FC               [12] 1155 	mov	r4,a
      008654 04               [12] 1156 	inc	a
      008655 12 89 B4         [24] 1157 	lcall	_ak820_outline_0124
      008658 EC               [12] 1158 	mov	a,r4
      008659 60 04            [24] 1159 	jz	00104$
      00865B 75 82 00         [24] 1160 	mov	dpl, #0x00
      00865E 22               [24] 1161 	ret
      00865F                       1162 00104$:
                                   1163 ;	quantum/action_util.c:148: ++distinct_keys;
      00865F 90 0A E6         [24] 1164 	mov	dptr,#_distinct_keys
      008662 E0               [24] 1165 	movx	a,@dptr
      008663 24 01            [12] 1166 	add	a, #0x01
      008665 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      008666 90 0E 86         [24] 1169 	mov	dptr,#_keyboard_protocol
      008669 E0               [24] 1170 	movx	a,@dptr
      00866A 60 11            [24] 1171 	jz	00106$
      00866C 90 0B 6B         [24] 1172 	mov	dptr,#_keymap_config
      00866F E0               [24] 1173 	movx	a,@dptr
      008670 30 E7 0A         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008673 12 89 D0         [24] 1176 	lcall	_ak820_outline_0177
      008676 12 77 E8         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      008679 75 82 01         [24] 1179 	mov	dpl, #0x01
      00867C 22               [24] 1180 	ret
      00867D                       1181 00106$:
                                   1182 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      00867D 90 0A E6         [24] 1183 	mov	dptr,#_distinct_keys
      008680 E0               [24] 1184 	movx	a,@dptr
      008681 24 F9            [12] 1185 	add	a,#0xff - 0x06
      008683 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      008685 7F 00            [12] 1189 	mov	r7,#0x00
      008687                       1190 00115$:
      008687 BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      00868A                       1192 00174$:
      00868A 50 1E            [24] 1193 	jnc	00111$
      00868C EF               [12] 1194 	mov	a,r7
      00868D 24 9B            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      00868F F5 82            [12] 1196 	mov	dpl,a
      008691 E4               [12] 1197 	clr	a
      008692 34 0E            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      008694 F5 83            [12] 1199 	mov	dph,a
      008696 74 01            [12] 1200 	mov	a,#0x01
      008698 F0               [24] 1201 	movx	@dptr,a
      008699 0F               [12] 1202 	inc	r7
      00869A 80 EB            [24] 1203 	sjmp	00115$
      00869C                       1204 00110$:
                                   1205 ;	quantum/action_util.c:154: } else add_key(code);
      00869C 90 0A FC         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_326
      00869F E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0086A0 90 08 AF         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      0086A3 F0               [24] 1210 	movx	@dptr,a
      0086A4 90 0E 99         [24] 1211 	mov	dptr,#_actual_keyboard_report
      0086A7 12 77 E8         [24] 1212 	lcall	_add_key_to_report
                                   1213 ;	quantum/action_util.c:154: } else add_key(code);
      0086AA                       1214 00111$:
                                   1215 ;	quantum/action_util.c:155: return true;
      0086AA 75 82 01         [24] 1216 	mov	dpl, #0x01
                                   1217 ;	quantum/action_util.c:156: }
      0086AD 22               [24] 1218 	ret
                                   1219 ;------------------------------------------------------------
                                   1220 ;Allocation info for local variables in function 'del_owned_key'
                                   1221 ;------------------------------------------------------------
                                   1222 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1223 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1224 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1225 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1226 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1227 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1228 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1229 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function del_owned_key
                                   1234 ;	-----------------------------------------
      0086AE                       1235 _del_owned_key:
      0086AE E5 82            [12] 1236 	mov	a,dpl
      0086B0 90 0A FD         [24] 1237 	mov	dptr,#_del_owned_key_code_10000_341
      0086B3 12 89 C5         [24] 1238 	lcall	_ak820_outline_0134
                                   1239 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      0086B6 E4               [12] 1240 	clr	a
      0086B7 F0               [24] 1241 	movx	@dptr,a
      0086B8 90 0A E7         [24] 1242 	mov	dptr,#_macro_keys
      0086BB C0 07            [24] 1243 	push	ar7
      0086BD 91 5A            [12] 1244 	acall	_ak820_macro_change
      0086BF E5 82            [12] 1245 	mov	a, dpl
      0086C1 D0 07            [24] 1246 	pop	ar7
      0086C3 70 03            [24] 1247 	jnz	00102$
      0086C5 F5 82            [12] 1248 	mov	dpl,a
      0086C7 22               [24] 1249 	ret
      0086C8                       1250 00102$:
                                   1251 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      0086C8 12 89 7F         [24] 1252 	lcall	_ak820_outline_0031
      0086CB FC               [12] 1253 	mov	r4,a
      0086CC 60 07            [24] 1254 	jz	00103$
      0086CE 1C               [12] 1255 	dec	r4
      0086CF 12 43 2A         [24] 1256 	lcall	_ak820_outline_0066
      0086D2 EC               [12] 1257 	mov	a,r4
      0086D3 60 04            [24] 1258 	jz	00104$
      0086D5                       1259 00103$:
      0086D5 75 82 00         [24] 1260 	mov	dpl, #0x00
      0086D8 22               [24] 1261 	ret
      0086D9                       1262 00104$:
                                   1263 ;	quantum/action_util.c:160: --distinct_keys;
      0086D9 90 0A E6         [24] 1264 	mov	dptr,#_distinct_keys
      0086DC E0               [24] 1265 	movx	a,@dptr
      0086DD 14               [12] 1266 	dec	a
      0086DE F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      0086DF 90 0E 86         [24] 1269 	mov	dptr,#_keyboard_protocol
      0086E2 E0               [24] 1270 	movx	a,@dptr
      0086E3 60 16            [24] 1271 	jz	00107$
      0086E5 90 0B 6B         [24] 1272 	mov	dptr,#_keymap_config
      0086E8 E0               [24] 1273 	movx	a,@dptr
      0086E9 30 E7 0F         [24] 1274 	jnb	acc.7,00107$
                                   1275 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      0086EC 90 08 B2         [24] 1276 	mov	dptr,#_del_key_from_report_PARM_2
      0086EF EF               [12] 1277 	mov	a,r7
      0086F0 F0               [24] 1278 	movx	@dptr,a
      0086F1 90 0E 99         [24] 1279 	mov	dptr,#_actual_keyboard_report
      0086F4 12 78 1E         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      0086F7 75 82 01         [24] 1282 	mov	dpl, #0x01
      0086FA 22               [24] 1283 	ret
      0086FB                       1284 00107$:
                                   1285 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      0086FB 90 0A E6         [24] 1286 	mov	dptr,#_distinct_keys
      0086FE E0               [24] 1287 	movx	a,@dptr
      0086FF FF               [12] 1288 	mov  r7,a
      008700 24 F9            [12] 1289 	add	a,#0xff - 0x06
      008702 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      008704 75 82 01         [24] 1292 	mov	dpl, #0x01
      008707 22               [24] 1293 	ret
      008708                       1294 00110$:
                                   1295 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008708 BF 06 1F         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00870B 90 0E 99         [24] 1298 	mov	dptr,#_actual_keyboard_report
      00870E 12 78 54         [24] 1299 	lcall	_clear_keys_from_report
                                   1300 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008711 7F 04            [12] 1301 	mov	r7,#0x04
      008713                       1302 00122$:
      008713 EF               [12] 1303 	mov	a,r7
      008714 24 5B            [12] 1304 	add	a,#0xff - 0xa4
      008716 40 20            [24] 1305 	jc	00116$
                                   1306 ;	free result
      008718 12 89 7F         [24] 1307 	lcall	_ak820_outline_0031
      00871B 60 0A            [24] 1308 	jz	00123$
                                   1309 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00871D 12 89 D0         [24] 1310 	lcall	_ak820_outline_0177
      008720 C0 07            [24] 1311 	push	ar7
      008722 12 77 E8         [24] 1312 	lcall	_add_key_to_report
      008725 D0 07            [24] 1313 	pop	ar7
                                   1314 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008727                       1315 00123$:
      008727 0F               [12] 1316 	inc	r7
      008728 80 E9            [24] 1317 	sjmp	00122$
      00872A                       1318 00115$:
                                   1319 ;	quantum/action_util.c:169: } else del_key(code);
      00872A 90 0A FD         [24] 1320 	mov	dptr,#_del_owned_key_code_10000_341
      00872D E0               [24] 1321 	movx	a,@dptr
                                   1322 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00872E 90 08 B2         [24] 1323 	mov	dptr,#_del_key_from_report_PARM_2
      008731 F0               [24] 1324 	movx	@dptr,a
      008732 90 0E 99         [24] 1325 	mov	dptr,#_actual_keyboard_report
      008735 12 78 1E         [24] 1326 	lcall	_del_key_from_report
                                   1327 ;	quantum/action_util.c:169: } else del_key(code);
      008738                       1328 00116$:
                                   1329 ;	quantum/action_util.c:170: return true;
      008738 75 82 01         [24] 1330 	mov	dpl, #0x01
                                   1331 ;	quantum/action_util.c:171: }
      00873B 22               [24] 1332 	ret
                                   1333 ;------------------------------------------------------------
                                   1334 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1335 ;------------------------------------------------------------
                                   1336 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1337 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1338 ;------------------------------------------------------------
                                   1339 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function clear_owned_usages
                                   1342 ;	-----------------------------------------
      00873C                       1343 _clear_owned_usages:
                                   1344 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      00873C 7F 00            [12] 1345 	mov	r7,#0x00
      00873E                       1346 00104$:
      00873E BF 1E 00         [24] 1347 	cjne	r7,#0x1e,00141$
      008741                       1348 00141$:
      008741 50 14            [24] 1349 	jnc	00101$
      008743 EF               [12] 1350 	mov	a,r7
      008744 24 FE            [12] 1351 	add	a, #_usage_refs
      008746 FD               [12] 1352 	mov	r5,a
      008747 E4               [12] 1353 	clr	a
      008748 34 0A            [12] 1354 	addc	a, #(_usage_refs >> 8)
      00874A FE               [12] 1355 	mov	r6,a
      00874B EF               [12] 1356 	mov	a,r7
      00874C 12 89 94         [24] 1357 	lcall	_ak820_outline_0070
      00874F E4               [12] 1358 	clr	a
      008750 F0               [24] 1359 	movx	@dptr,a
      008751 12 89 B4         [24] 1360 	lcall	_ak820_outline_0124
      008754 0F               [12] 1361 	inc	r7
      008755 80 E7            [24] 1362 	sjmp	00104$
      008757                       1363 00101$:
                                   1364 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      008757 90 0B 3B         [24] 1365 	mov	dptr,#(_usage_lengths + 0x0001)
      00875A E4               [12] 1366 	clr	a
      00875B F0               [24] 1367 	movx	@dptr,a
      00875C 90 0B 3A         [24] 1368 	mov	dptr,#_usage_lengths
      00875F F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      008760 FF               [12] 1371 	mov	r7,a
      008761                       1372 00107$:
      008761 BF 04 00         [24] 1373 	cjne	r7,#0x04,00143$
      008764                       1374 00143$:
      008764 50 0D            [24] 1375 	jnc	00109$
      008766 EF               [12] 1376 	mov	a,r7
      008767 24 3C            [12] 1377 	add	a, #_macro_usages
      008769 F5 82            [12] 1378 	mov	dpl,a
      00876B E4               [12] 1379 	clr	a
      00876C 34 0B            [12] 1380 	addc	a, #(_macro_usages >> 8)
      00876E 12 84 4B         [24] 1381 	lcall	_ak820_outline_0164
      008771 80 EE            [24] 1382 	sjmp	00107$
      008773                       1383 00109$:
                                   1384 ;	quantum/action_util.c:185: }
      008773 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'owned_usage_key'
                                   1388 ;------------------------------------------------------------
                                   1389 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1390 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1391 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1392 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1393 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1394 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1395 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1396 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1397 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1398 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1399 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function owned_usage_key
                                   1404 ;	-----------------------------------------
      008774                       1405 _owned_usage_key:
      008774 E5 82            [12] 1406 	mov	a,dpl
      008776 90 0B 41         [24] 1407 	mov	dptr,#_owned_usage_key_code_10000_368
      008779 F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      00877A E0               [24] 1410 	movx	a,@dptr
      00877B FF               [12] 1411 	mov	r7,a
      00877C BF A8 00         [24] 1412 	cjne	r7,#0xa8,00244$
      00877F                       1413 00244$:
      00877F B3               [12] 1414 	cpl	c
      008780 92 25            [24] 1415 	mov	_owned_usage_key_sloc0_1_0,c
      008782 E4               [12] 1416 	clr	a
      008783 33               [12] 1417 	rlc	a
      008784 FF               [12] 1418 	mov	r7,a
      008785 90 0B 44         [24] 1419 	mov	dptr,#_owned_usage_key_which_10000_369
      008788 F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      008789 EF               [12] 1422 	mov	a,r7
      00878A 60 02            [24] 1423 	jz	00129$
      00878C 74 03            [12] 1424 	mov	a,#0x03
      00878E                       1425 00129$:
      00878E FE               [12] 1426 	mov	r6,a
                                   1427 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      00878F EF               [12] 1428 	mov	a,r7
      008790 24 3A            [12] 1429 	add	a, #_usage_lengths
      008792 FD               [12] 1430 	mov	r5,a
      008793 E4               [12] 1431 	clr	a
      008794 34 0B            [12] 1432 	addc	a, #(_usage_lengths >> 8)
      008796 FF               [12] 1433 	mov	r7,a
      008797 12 89 D9         [24] 1434 	lcall	_ak820_outline_0190
      00879A E0               [24] 1435 	movx	a,@dptr
      00879B FC               [12] 1436 	mov	r4,a
                                   1437 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      00879C 90 0B 41         [24] 1438 	mov	dptr,#_owned_usage_key_code_10000_368
      00879F E0               [24] 1439 	movx	a,@dptr
      0087A0 24 5B            [12] 1440 	add	a,#0x5b
      0087A2 FB               [12] 1441 	mov	r3,a
                                   1442 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      0087A3 90 0B 40         [24] 1443 	mov	dptr,#_owned_usage_key_PARM_2
      0087A6 E0               [24] 1444 	movx	a,@dptr
      0087A7 FA               [12] 1445 	mov	r2,a
      0087A8 90 0A 35         [24] 1446 	mov	dptr,#_ak820_macro_change_PARM_2
      0087AB EB               [12] 1447 	mov	a,r3
      0087AC F0               [24] 1448 	movx	@dptr,a
      0087AD 90 0A 36         [24] 1449 	mov	dptr,#_ak820_macro_change_PARM_3
      0087B0 EA               [12] 1450 	mov	a,r2
      0087B1 F0               [24] 1451 	movx	@dptr,a
      0087B2 90 0B 3C         [24] 1452 	mov	dptr,#_macro_usages
      0087B5 C0 07            [24] 1453 	push	ar7
      0087B7 C0 06            [24] 1454 	push	ar6
      0087B9 C0 05            [24] 1455 	push	ar5
      0087BB C0 04            [24] 1456 	push	ar4
      0087BD C0 03            [24] 1457 	push	ar3
      0087BF C0 02            [24] 1458 	push	ar2
      0087C1 12 84 5A         [24] 1459 	lcall	_ak820_macro_change
      0087C4 E5 82            [12] 1460 	mov	a, dpl
      0087C6 D0 02            [24] 1461 	pop	ar2
      0087C8 D0 03            [24] 1462 	pop	ar3
      0087CA D0 04            [24] 1463 	pop	ar4
      0087CC D0 05            [24] 1464 	pop	ar5
      0087CE D0 06            [24] 1465 	pop	ar6
      0087D0 D0 07            [24] 1466 	pop	ar7
      0087D2 70 01            [24] 1467 	jnz	00102$
      0087D4 22               [24] 1468 	ret
      0087D5                       1469 00102$:
                                   1470 ;	quantum/action_util.c:192: if (pressed) {
      0087D5 EA               [12] 1471 	mov	a,r2
      0087D6 60 1B            [24] 1472 	jz	00115$
                                   1473 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      0087D8 12 89 9E         [24] 1474 	lcall	_ak820_outline_0075
      0087DB 04               [12] 1475 	inc	a
      0087DC 12 75 67         [24] 1476 	lcall	_ak820_outline_0140
      0087DF E8               [12] 1477 	mov	a,r0
      0087E0 60 01            [24] 1478 	jz	00104$
      0087E2 22               [24] 1479 	ret
      0087E3                       1480 00104$:
                                   1481 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      0087E3 90 0B 45         [24] 1482 	mov	dptr,#_owned_usage_key_count_10000_369
      0087E6 EC               [12] 1483 	mov	a,r4
      0087E7 04               [12] 1484 	inc	a
      0087E8 F0               [24] 1485 	movx	@dptr,a
      0087E9 EC               [12] 1486 	mov	a,r4
      0087EA 2E               [12] 1487 	add	a, r6
      0087EB 12 89 94         [24] 1488 	lcall	_ak820_outline_0070
      0087EE EB               [12] 1489 	mov	a,r3
      0087EF F0               [24] 1490 	movx	@dptr,a
      0087F0 02 88 54         [24] 1491 	ljmp	00116$
      0087F3                       1492 00115$:
                                   1493 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      0087F3 12 89 9E         [24] 1494 	lcall	_ak820_outline_0075
      0087F6 60 07            [24] 1495 	jz	00105$
      0087F8 18               [12] 1496 	dec	r0
      0087F9 12 89 8D         [24] 1497 	lcall	_ak820_outline_0065
      0087FC E8               [12] 1498 	mov	a,r0
      0087FD 60 01            [24] 1499 	jz	00106$
      0087FF                       1500 00105$:
      0087FF 22               [24] 1501 	ret
      008800                       1502 00106$:
                                   1503 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      008800 7A 00            [12] 1504 	mov	r2,#0x00
      008802                       1505 00108$:
      008802 EA               [12] 1506 	mov	a,r2
      008803 2E               [12] 1507 	add	a, r6
      008804 12 89 94         [24] 1508 	lcall	_ak820_outline_0070
      008807 E0               [24] 1509 	movx	a,@dptr
      008808 B5 03 02         [24] 1510 	cjne	a,ar3,00251$
      00880B 80 03            [24] 1511 	sjmp	00167$
      00880D                       1512 00251$:
      00880D 0A               [12] 1513 	inc	r2
      00880E 80 F2            [24] 1514 	sjmp	00108$
      008810                       1515 00167$:
      008810 90 0B 46         [24] 1516 	mov	dptr,#_owned_usage_key_pos_30001_376
      008813 EA               [12] 1517 	mov	a,r2
      008814 F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	quantum/action_util.c:199: --count;
      008815 1C               [12] 1520 	dec	r4
      008816 90 0B 45         [24] 1521 	mov	dptr,#_owned_usage_key_count_10000_369
      008819 EC               [12] 1522 	mov	a,r4
      00881A F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      00881B 8A 03            [24] 1525 	mov	ar3,r2
      00881D                       1526 00125$:
      00881D C3               [12] 1527 	clr	c
      00881E EB               [12] 1528 	mov	a,r3
      00881F 9C               [12] 1529 	subb	a,r4
      008820 50 23            [24] 1530 	jnc	00111$
      008822 C0 05            [24] 1531 	push	ar5
      008824 C0 07            [24] 1532 	push	ar7
      008826 EB               [12] 1533 	mov	a,r3
      008827 2E               [12] 1534 	add	a, r6
      008828 FA               [12] 1535 	mov	r2,a
      008829 24 1C            [12] 1536 	add	a, #_usage_order
      00882B F8               [12] 1537 	mov	r0,a
      00882C E4               [12] 1538 	clr	a
      00882D 34 0B            [12] 1539 	addc	a, #(_usage_order >> 8)
      00882F F9               [12] 1540 	mov	r1,a
      008830 0A               [12] 1541 	inc	r2
      008831 EA               [12] 1542 	mov	a,r2
      008832 33               [12] 1543 	rlc	a
      008833 95 E0            [12] 1544 	subb	a,acc
      008835 FF               [12] 1545 	mov	r7,a
      008836 EA               [12] 1546 	mov	a,r2
      008837 12 89 BA         [24] 1547 	lcall	_ak820_outline_0128
      00883A 12 38 A9         [24] 1548 	lcall	_ak820_outline_0158
      00883D F0               [24] 1549 	movx	@dptr,a
      00883E 0B               [12] 1550 	inc	r3
      00883F D0 07            [24] 1551 	pop	ar7
      008841 D0 05            [24] 1552 	pop	ar5
      008843 80 D8            [24] 1553 	sjmp	00125$
      008845                       1554 00111$:
                                   1555 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      008845 12 89 D9         [24] 1556 	lcall	_ak820_outline_0190
      008848 EC               [12] 1557 	mov	a,r4
      008849 F0               [24] 1558 	movx	@dptr,a
                                   1559 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      00884A 90 0B 46         [24] 1560 	mov	dptr,#_owned_usage_key_pos_30001_376
      00884D E0               [24] 1561 	movx	a,@dptr
      00884E B5 04 02         [24] 1562 	cjne	a,ar4,00253$
      008851 80 01            [24] 1563 	sjmp	00116$
      008853                       1564 00253$:
      008853 22               [24] 1565 	ret
      008854                       1566 00116$:
                                   1567 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      008854 90 0B 45         [24] 1568 	mov	dptr,#_owned_usage_key_count_10000_369
      008857 E0               [24] 1569 	movx	a,@dptr
      008858 FC               [12] 1570 	mov	r4,a
      008859 12 89 D9         [24] 1571 	lcall	_ak820_outline_0190
      00885C F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      00885D EC               [12] 1574 	mov	a,r4
      00885E 60 15            [24] 1575 	jz	00131$
      008860 EC               [12] 1576 	mov	a,r4
      008861 2E               [12] 1577 	add	a, r6
      008862 FE               [12] 1578 	mov	r6,a
      008863 1E               [12] 1579 	dec	r6
      008864 EE               [12] 1580 	mov	a,r6
      008865 33               [12] 1581 	rlc	a
      008866 95 E0            [12] 1582 	subb	a,acc
      008868 FF               [12] 1583 	mov	r7,a
      008869 EE               [12] 1584 	mov	a,r6
      00886A 12 89 BA         [24] 1585 	lcall	_ak820_outline_0128
      00886D 24 A5            [12] 1586 	add	a,#0xa5
      00886F FE               [12] 1587 	mov	r6,a
      008870 33               [12] 1588 	rlc	a
      008871 95 E0            [12] 1589 	subb	a,acc
      008873 80 02            [24] 1590 	sjmp	00132$
      008875                       1591 00131$:
      008875 7E 00            [12] 1592 	mov	r6,#0x00
      008877                       1593 00132$:
      008877 90 0B 41         [24] 1594 	mov	dptr,#_owned_usage_key_code_10000_368
      00887A EE               [12] 1595 	mov	a,r6
      00887B F0               [24] 1596 	movx	@dptr,a
                                   1597 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      00887C 90 0B 44         [24] 1598 	mov	dptr,#_owned_usage_key_which_10000_369
      00887F E0               [24] 1599 	movx	a,@dptr
      008880 60 18            [24] 1600 	jz	00118$
      008882 EE               [12] 1601 	mov	a,r6
      008883 60 0B            [24] 1602 	jz	00133$
      008885 8E 82            [24] 1603 	mov	dpl, r6
      008887 12 76 A5         [24] 1604 	lcall	_KEYCODE2CONSUMER
      00888A AD 82            [24] 1605 	mov	r5, dpl
      00888C AF 83            [24] 1606 	mov	r7, dph
      00888E 80 04            [24] 1607 	sjmp	00134$
      008890                       1608 00133$:
      008890 7D 00            [12] 1609 	mov	r5,#0x00
      008892 7F 00            [12] 1610 	mov	r7,#0x00
      008894                       1611 00134$:
      008894 12 89 D9         [24] 1612 	lcall	_ak820_outline_0190
      008897 02 76 59         [24] 1613 	ljmp	_host_consumer_send
      00889A                       1614 00118$:
                                   1615 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00889A EE               [12] 1616 	mov	a,r6
      00889B 60 22            [24] 1617 	jz	00135$
                                   1618 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      00889D BE A5 00         [24] 1619 	cjne	r6,#0xa5,00258$
      0088A0                       1620 00258$:
      0088A0 40 05            [24] 1621 	jc	00121$
      0088A2 EE               [12] 1622 	mov	a,r6
      0088A3 24 58            [12] 1623 	add	a,#0xff - 0xa7
      0088A5 50 08            [24] 1624 	jnc	00122$
                                   1625 ;	free result
      0088A7                       1626 00121$:
      0088A7 90 0B 42         [24] 1627 	mov	dptr,#_owned_usage_key___200000085_20000_369
      0088AA 12 58 A4         [24] 1628 	lcall	_ak820_outline_0156
      0088AD 80 09            [24] 1629 	sjmp	00123$
      0088AF                       1630 00122$:
                                   1631 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      0088AF 74 DC            [12] 1632 	mov	a,#0xdc
      0088B1 2E               [12] 1633 	add	a, r6
      0088B2 90 0B 42         [24] 1634 	mov	dptr,#_owned_usage_key___200000085_20000_369
      0088B5 12 38 8F         [24] 1635 	lcall	_ak820_outline_0127
                                   1636 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0088B8                       1637 00123$:
      0088B8 90 0B 42         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_369
      0088BB E0               [24] 1639 	movx	a,@dptr
      0088BC FF               [12] 1640 	mov	r7,a
      0088BD 80 02            [24] 1641 	sjmp	00136$
      0088BF                       1642 00135$:
      0088BF 7F 00            [12] 1643 	mov	r7,#0x00
      0088C1                       1644 00136$:
      0088C1 7E 00            [12] 1645 	mov	r6,#0x00
      0088C3 12 43 65         [24] 1646 	lcall	_ak820_outline_0159
                                   1647 ;	quantum/action_util.c:208: }
      0088C6 02 76 2A         [24] 1648 	ljmp	_host_system_send
                                   1649 ;------------------------------------------------------------
                                   1650 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1651 ;------------------------------------------------------------
                                   1652 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1653 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1654 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1655 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1656 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1657 ;------------------------------------------------------------
                                   1658 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1659 ;	-----------------------------------------
                                   1660 ;	 function send_keyboard_report
                                   1661 ;	-----------------------------------------
      0088C9                       1662 _send_keyboard_report:
                                   1663 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      0088C9 90 0E 97         [24] 1664 	mov	dptr,#_real_mods
      0088CC E0               [24] 1665 	movx	a,@dptr
      0088CD FF               [12] 1666 	mov	r7,a
      0088CE 90 0E 99         [24] 1667 	mov	dptr,#_actual_keyboard_report
      0088D1 F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      0088D2 90 0E 98         [24] 1670 	mov	dptr,#_weak_mods
      0088D5 E0               [24] 1671 	movx	a,@dptr
      0088D6 42 07            [12] 1672 	orl	ar7,a
      0088D8 90 0E 99         [24] 1673 	mov	dptr,#_actual_keyboard_report
      0088DB EF               [12] 1674 	mov	a,r7
      0088DC F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      0088DD 90 0A 30         [24] 1677 	mov	dptr,#_owned_weak_mods
      0088E0 E0               [24] 1678 	movx	a,@dptr
      0088E1 FE               [12] 1679 	mov	r6,a
      0088E2 90 0A 2F         [24] 1680 	mov	dptr,#_owned_mods
      0088E5 E0               [24] 1681 	movx	a,@dptr
      0088E6 4E               [12] 1682 	orl	a,r6
      0088E7 42 07            [12] 1683 	orl	ar7,a
      0088E9 90 0E 99         [24] 1684 	mov	dptr,#_actual_keyboard_report
      0088EC EF               [12] 1685 	mov	a,r7
      0088ED F0               [24] 1686 	movx	@dptr,a
                                   1687 ;	quantum/action_util.c:517: bool changed = false;
      0088EE 90 0B 68         [24] 1688 	mov	dptr,#_send_keyboard_report_changed_10001_388
      0088F1 E4               [12] 1689 	clr	a
      0088F2 F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:519: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1692 ;	quantum/action_util.c:520: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1693 ;	quantum/action_util.c:525: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0088F3 FF               [12] 1694 	mov	r7,a
      0088F4                       1695 00107$:
      0088F4 BF 20 00         [24] 1696 	cjne	r7,#0x20,00140$
      0088F7                       1697 00140$:
      0088F7 50 2B            [24] 1698 	jnc	00103$
                                   1699 ;	quantum/action_util.c:526: if (dest[i] != src[i]) {
      0088F9 EF               [12] 1700 	mov	a,r7
      0088FA 24 48            [12] 1701 	add	a, #_send_keyboard_report_last_report_10001_388
      0088FC FD               [12] 1702 	mov	r5,a
      0088FD E4               [12] 1703 	clr	a
      0088FE 34 0B            [12] 1704 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      008900 FE               [12] 1705 	mov	r6,a
      008901 12 51 F6         [24] 1706 	lcall	_ak820_outline_0077
      008904 EF               [12] 1707 	mov	a,r7
      008905 24 99            [12] 1708 	add	a, #_actual_keyboard_report
      008907 F5 82            [12] 1709 	mov	dpl,a
      008909 E4               [12] 1710 	clr	a
      00890A 34 0E            [12] 1711 	addc	a, #(_actual_keyboard_report >> 8)
      00890C F5 83            [12] 1712 	mov	dph,a
      00890E E0               [24] 1713 	movx	a,@dptr
      00890F FB               [12] 1714 	mov	r3,a
      008910 EC               [12] 1715 	mov	a,r4
      008911 B5 03 02         [24] 1716 	cjne	a,ar3,00142$
      008914 80 0B            [24] 1717 	sjmp	00108$
      008916                       1718 00142$:
                                   1719 ;	quantum/action_util.c:527: dest[i] = src[i];
      008916 12 38 94         [24] 1720 	lcall	_ak820_outline_0136
      008919 EB               [12] 1721 	mov	a,r3
      00891A F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:528: changed = true;
      00891B 90 0B 68         [24] 1724 	mov	dptr,#_send_keyboard_report_changed_10001_388
      00891E 74 01            [12] 1725 	mov	a,#0x01
      008920 F0               [24] 1726 	movx	@dptr,a
      008921                       1727 00108$:
                                   1728 ;	quantum/action_util.c:525: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008921 0F               [12] 1729 	inc	r7
      008922 80 D0            [24] 1730 	sjmp	00107$
      008924                       1731 00103$:
                                   1732 ;	quantum/action_util.c:531: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      008924 90 0B 68         [24] 1733 	mov	dptr,#_send_keyboard_report_changed_10001_388
      008927 E0               [24] 1734 	movx	a,@dptr
      008928 60 09            [24] 1735 	jz	00109$
      00892A 90 0E 99         [24] 1736 	mov	dptr,#_actual_keyboard_report
      00892D 75 F0 00         [24] 1737 	mov	b, #0x00
                                   1738 ;	quantum/action_util.c:540: }
      008930 02 75 9F         [24] 1739 	ljmp	_host_keyboard_send
      008933                       1740 00109$:
      008933 22               [24] 1741 	ret
                                   1742 ;------------------------------------------------------------
                                   1743 ;Allocation info for local variables in function 'get_mods'
                                   1744 ;------------------------------------------------------------
                                   1745 ;	quantum/action_util.c:546: uint8_t get_mods(void) {
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function get_mods
                                   1748 ;	-----------------------------------------
      008934                       1749 _get_mods:
      008934 C0 07            [24] 1750 	push	ar7
                                   1751 ;	quantum/action_util.c:551: ;
      008936 90 0A 2F         [24] 1752 	mov	dptr,#_owned_mods
      008939 E0               [24] 1753 	movx	a,@dptr
      00893A FF               [12] 1754 	mov	r7,a
      00893B 90 0E 97         [24] 1755 	mov	dptr,#_real_mods
      00893E 12 84 45         [24] 1756 	lcall	_ak820_outline_0142
                                   1757 ;	quantum/action_util.c:552: }
      008941 D0 07            [24] 1758 	pop	ar7
      008943 22               [24] 1759 	ret
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'add_mods'
                                   1762 ;------------------------------------------------------------
                                   1763 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/action_util.c:557: void add_mods(uint8_t mods) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function clear_mods
                                   1768 ;	-----------------------------------------
      008944                       1769 _clear_mods:
                                   1770 ;	quantum/action_util.c:579: real_mods = 0;
      008944 90 0E 97         [24] 1771 	mov	dptr,#_real_mods
      008947 E4               [12] 1772 	clr	a
      008948 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action_util.c:580: }
      008949 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'get_weak_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;	quantum/action_util.c:586: uint8_t get_weak_mods(void) {
                                   1780 ;	-----------------------------------------
                                   1781 ;	 function get_weak_mods
                                   1782 ;	-----------------------------------------
      00894A                       1783 _get_weak_mods:
      00894A C0 07            [24] 1784 	push	ar7
                                   1785 ;	quantum/action_util.c:591: ;
      00894C 90 0A 30         [24] 1786 	mov	dptr,#_owned_weak_mods
      00894F E0               [24] 1787 	movx	a,@dptr
      008950 FF               [12] 1788 	mov	r7,a
      008951 90 0E 98         [24] 1789 	mov	dptr,#_weak_mods
      008954 12 84 45         [24] 1790 	lcall	_ak820_outline_0142
                                   1791 ;	quantum/action_util.c:592: }
      008957 D0 07            [24] 1792 	pop	ar7
      008959 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'add_weak_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action_util.c:597: void add_weak_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function add_weak_mods
                                   1802 ;	-----------------------------------------
      00895A                       1803 _add_weak_mods:
      00895A E5 82            [12] 1804 	mov	a,dpl
      00895C 90 0B 69         [24] 1805 	mov	dptr,#_add_weak_mods_mods_10000_406
      00895F F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action_util.c:598: weak_mods |= mods;
      008960 E0               [24] 1808 	movx	a,@dptr
      008961 FF               [12] 1809 	mov	r7,a
      008962 90 0E 98         [24] 1810 	mov	dptr,#_weak_mods
      008965 E0               [24] 1811 	movx	a,@dptr
      008966 4F               [12] 1812 	orl	a,r7
      008967 F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:599: }
      008968 22               [24] 1815 	ret
                                   1816 ;------------------------------------------------------------
                                   1817 ;Allocation info for local variables in function 'del_weak_mods'
                                   1818 ;------------------------------------------------------------
                                   1819 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/action_util.c:604: void del_weak_mods(uint8_t mods) {
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function del_weak_mods
                                   1824 ;	-----------------------------------------
      008969                       1825 _del_weak_mods:
      008969 E5 82            [12] 1826 	mov	a,dpl
      00896B 90 0B 6A         [24] 1827 	mov	dptr,#_del_weak_mods_mods_10000_408
      00896E F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action_util.c:605: weak_mods &= ~mods;
      00896F E0               [24] 1830 	movx	a,@dptr
      008970 F4               [12] 1831 	cpl	a
      008971 FF               [12] 1832 	mov	r7,a
      008972 90 0E 98         [24] 1833 	mov	dptr,#_weak_mods
      008975 E0               [24] 1834 	movx	a,@dptr
      008976 5F               [12] 1835 	anl	a,r7
      008977 F0               [24] 1836 	movx	@dptr,a
                                   1837 ;	quantum/action_util.c:606: }
      008978 22               [24] 1838 	ret
                                   1839 ;------------------------------------------------------------
                                   1840 ;Allocation info for local variables in function 'set_weak_mods'
                                   1841 ;------------------------------------------------------------
                                   1842 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/action_util.c:611: void set_weak_mods(uint8_t mods) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function clear_weak_mods
                                   1847 ;	-----------------------------------------
      008979                       1848 _clear_weak_mods:
                                   1849 ;	quantum/action_util.c:619: weak_mods = 0;
      008979 90 0E 98         [24] 1850 	mov	dptr,#_weak_mods
      00897C E4               [12] 1851 	clr	a
      00897D F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action_util.c:620: }
      00897E 22               [24] 1854 	ret
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1857 ;------------------------------------------------------------
                                   1858 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	quantum/action_util.c:702: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1861 ;	-----------------------------------------
                                   1862 	.area CSEG    (CODE)
                                   1863 	.area CONST   (CODE)
                                   1864 	.area XINIT   (CODE)
      00CB7E                       1865 __xinit__real_mods:
      00CB7E 00                    1866 	.db #0x00	; 0
      00CB7F                       1867 __xinit__weak_mods:
      00CB7F 00                    1868 	.db #0x00	; 0
      00CB80                       1869 __xinit__actual_keyboard_report:
      00CB80 00                    1870 	.db #0x00	; 0
      00CB81 00                    1871 	.db #0x00	; 0
      00CB82 00                    1872 	.db #0x00	; 0
      00CB83 00                    1873 	.db #0x00	; 0
      00CB84 00                    1874 	.db #0x00	; 0
      00CB85 00                    1875 	.db #0x00	; 0
      00CB86 00                    1876 	.db #0x00	; 0
      00CB87 00                    1877 	.db #0x00	; 0
      00CB88 00                    1878 	.db 0x00
      00CB89 00                    1879 	.db 0x00
      00CB8A 00                    1880 	.db 0x00
      00CB8B 00                    1881 	.db 0x00
      00CB8C 00                    1882 	.db 0x00
      00CB8D 00                    1883 	.db 0x00
      00CB8E 00                    1884 	.db 0x00
      00CB8F 00                    1885 	.db 0x00
      00CB90 00                    1886 	.db 0x00
      00CB91 00                    1887 	.db 0x00
      00CB92 00                    1888 	.db 0x00
      00CB93 00                    1889 	.db 0x00
      00CB94 00                    1890 	.db 0x00
      00CB95 00                    1891 	.db 0x00
      00CB96 00                    1892 	.db 0x00
      00CB97 00                    1893 	.db 0x00
      00CB98 00                    1894 	.db 0x00
      00CB99 00                    1895 	.db 0x00
      00CB9A 00                    1896 	.db 0x00
      00CB9B 00                    1897 	.db 0x00
      00CB9C 00                    1898 	.db 0x00
      00CB9D 00                    1899 	.db 0x00
      00CB9E 00                    1900 	.db 0x00
      00CB9F 00                    1901 	.db 0x00
                                   1902 	.area CABS    (ABS,CODE)
                                   1903 
                                   1904 ; Experimental exact instruction outlining.
                                   1905 	.globl _ak820_outline_0018
                                   1906 	.globl _ak820_outline_0031
                                   1907 	.globl _ak820_outline_0058
                                   1908 	.globl _ak820_outline_0062
                                   1909 	.globl _ak820_outline_0064
                                   1910 	.globl _ak820_outline_0065
                                   1911 	.globl _ak820_outline_0066
                                   1912 	.globl _ak820_outline_0070
                                   1913 	.globl _ak820_outline_0075
                                   1914 	.globl _ak820_outline_0077
                                   1915 	.globl _ak820_outline_0108
                                   1916 	.globl _ak820_outline_0109
                                   1917 	.globl _ak820_outline_0119
                                   1918 	.globl _ak820_outline_0123
                                   1919 	.globl _ak820_outline_0124
                                   1920 	.globl _ak820_outline_0127
                                   1921 	.globl _ak820_outline_0128
                                   1922 	.globl _ak820_outline_0134
                                   1923 	.globl _ak820_outline_0136
                                   1924 	.globl _ak820_outline_0140
                                   1925 	.globl _ak820_outline_0142
                                   1926 	.globl _ak820_outline_0156
                                   1927 	.globl _ak820_outline_0158
                                   1928 	.globl _ak820_outline_0159
                                   1929 	.globl _ak820_outline_0164
                                   1930 	.globl _ak820_outline_0177
                                   1931 	.globl _ak820_outline_0189
                                   1932 	.globl _ak820_outline_0190
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0031
      00897F                       1936 _ak820_outline_0031:
      00897F EF               [12] 1937 	mov	a,r7
      008980 24 41            [12] 1938 	add	a,#_key_refs
      008982 FD               [12] 1939 	mov	r5,a
      008983 E4               [12] 1940 	clr	a
      008984 34 0A            [12] 1941 	addc	a,#(_key_refs>>8)
      008986 FE               [12] 1942 	mov	r6,a
      008987 8D 82            [24] 1943 	mov	dpl,r5
      008989 8E 83            [24] 1944 	mov	dph,r6
      00898B E0               [24] 1945 	movx	a,@dptr
      00898C 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0065
      00898D                       1950 _ak820_outline_0065:
      00898D 89 82            [24] 1951 	mov	dpl,r1
      00898F 8A 83            [24] 1952 	mov	dph,r2
      008991 E8               [12] 1953 	mov	a,r0
      008992 F0               [24] 1954 	movx	@dptr,a
      008993 22               [24] 1955 	ret
                                   1956 
                                   1957 	.area CSEG (CODE)
                                   1958 ; function ak820_outline_0070
      008994                       1959 _ak820_outline_0070:
      008994 24 1C            [12] 1960 	add	a,#_usage_order
      008996 F5 82            [12] 1961 	mov	dpl,a
      008998 E4               [12] 1962 	clr	a
      008999 34 0B            [12] 1963 	addc	a,#(_usage_order>>8)
      00899B F5 83            [12] 1964 	mov	dph,a
      00899D 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0075
      00899E                       1969 _ak820_outline_0075:
      00899E EB               [12] 1970 	mov	a,r3
      00899F 24 FE            [12] 1971 	add	a,#_usage_refs
      0089A1 F9               [12] 1972 	mov	r1,a
      0089A2 E4               [12] 1973 	clr	a
      0089A3 34 0A            [12] 1974 	addc	a,#(_usage_refs>>8)
      0089A5 FA               [12] 1975 	mov	r2,a
      0089A6 89 82            [24] 1976 	mov	dpl,r1
      0089A8 8A 83            [24] 1977 	mov	dph,r2
      0089AA E0               [24] 1978 	movx	a,@dptr
      0089AB F8               [12] 1979 	mov	r0,a
      0089AC 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0119
      0089AD                       1984 _ak820_outline_0119:
      0089AD F0               [24] 1985 	movx	@dptr,a
      0089AE E0               [24] 1986 	movx	a,@dptr
      0089AF FF               [12] 1987 	mov	r7,a
      0089B0 90 0A 39         [24] 1988 	mov	dptr,#_change_owned_PARM_2
      0089B3 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0124
      0089B4                       1993 _ak820_outline_0124:
      0089B4 8D 82            [24] 1994 	mov	dpl,r5
      0089B6 8E 83            [24] 1995 	mov	dph,r6
      0089B8 F0               [24] 1996 	movx	@dptr,a
      0089B9 22               [24] 1997 	ret
                                   1998 
                                   1999 	.area CSEG (CODE)
                                   2000 ; function ak820_outline_0128
      0089BA                       2001 _ak820_outline_0128:
      0089BA 24 1C            [12] 2002 	add	a,#_usage_order
      0089BC F5 82            [12] 2003 	mov	dpl,a
      0089BE EF               [12] 2004 	mov	a,r7
      0089BF 34 0B            [12] 2005 	addc	a,#(_usage_order>>8)
      0089C1 F5 83            [12] 2006 	mov	dph,a
      0089C3 E0               [24] 2007 	movx	a,@dptr
      0089C4 22               [24] 2008 	ret
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0134
      0089C5                       2012 _ak820_outline_0134:
      0089C5 F0               [24] 2013 	movx	@dptr,a
      0089C6 E0               [24] 2014 	movx	a,@dptr
      0089C7 FF               [12] 2015 	mov	r7,a
      0089C8 90 0A 35         [24] 2016 	mov	dptr,#_ak820_macro_change_PARM_2
      0089CB F0               [24] 2017 	movx	@dptr,a
      0089CC 90 0A 36         [24] 2018 	mov	dptr,#_ak820_macro_change_PARM_3
      0089CF 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0177
      0089D0                       2023 _ak820_outline_0177:
      0089D0 90 08 AF         [24] 2024 	mov	dptr,#_add_key_to_report_PARM_2
      0089D3 EF               [12] 2025 	mov	a,r7
      0089D4 F0               [24] 2026 	movx	@dptr,a
      0089D5 90 0E 99         [24] 2027 	mov	dptr,#_actual_keyboard_report
      0089D8 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0190
      0089D9                       2032 _ak820_outline_0190:
      0089D9 8D 82            [24] 2033 	mov	dpl,r5
      0089DB 8F 83            [24] 2034 	mov	dph,r7
      0089DD 22               [24] 2035 	ret
