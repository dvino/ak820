                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_layer
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_macro_change
                                     12 	.globl _ak820_tri_layer_derived
                                     13 	.globl _ak820_keycode_at
                                     14 	.globl _action_for_keycode
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _layer_state
                                    259 	.globl _default_layer_state
                                    260 	.globl _ak820_resolve_key_PARM_2
                                    261 	.globl _ak820_cache_layer_PARM_2
                                    262 	.globl _ak820_cache_keycode_PARM_2
                                    263 	.globl _default_layer_state_set_user
                                    264 	.globl _default_layer_state_set_kb
                                    265 	.globl _default_layer_set
                                    266 	.globl _default_layer_or
                                    267 	.globl _default_layer_and
                                    268 	.globl _default_layer_xor
                                    269 	.globl _ak820_layer_refresh
                                    270 	.globl _layer_hold_on
                                    271 	.globl _layer_hold_off
                                    272 	.globl _layer_hold_clear
                                    273 	.globl _layer_state_set_user
                                    274 	.globl _layer_state_set_kb
                                    275 	.globl _layer_state_set
                                    276 	.globl _layer_clear
                                    277 	.globl _layer_move
                                    278 	.globl _layer_on
                                    279 	.globl _layer_off
                                    280 	.globl _layer_or
                                    281 	.globl _layer_and
                                    282 	.globl _layer_xor
                                    283 	.globl _ak820_cache_keycode
                                    284 	.globl _ak820_cache_layer
                                    285 	.globl _ak820_cached_key
                                    286 	.globl _ak820_resolve_key
                                    287 	.globl _ak820_layer_for_key
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; overlayable items in internal ram
                                    552 ;--------------------------------------------------------
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
                                    566 ;--------------------------------------------------------
                                    567 ; paged external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area PSEG    (PAG,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; uninitialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XSEG    (XDATA)
      0008EF                        574 _default_layer_state_set_user_state_10000_317:
      0008EF                        575 	.ds 1
      0008F0                        576 _default_layer_state_set_kb_state_10000_319:
      0008F0                        577 	.ds 1
      0008F1                        578 _default_layer_state_set_state_10000_321:
      0008F1                        579 	.ds 1
      0008F2                        580 _default_layer_set_state_10000_326:
      0008F2                        581 	.ds 1
      0008F3                        582 _default_layer_or_state_10000_328:
      0008F3                        583 	.ds 1
      0008F4                        584 _default_layer_and_state_10000_330:
      0008F4                        585 	.ds 1
      0008F5                        586 _default_layer_xor_state_10000_332:
      0008F5                        587 	.ds 1
      0008F6                        588 _persistent_layers:
      0008F6                        589 	.ds 1
      0008F7                        590 _layer_refs:
      0008F7                        591 	.ds 6
      0008FD                        592 _macro_layers:
      0008FD                        593 	.ds 1
      0008FE                        594 _ak820_layer_refresh_state_10000_335:
      0008FE                        595 	.ds 1
      0008FF                        596 _layer_hold_on_layer_10000_338:
      0008FF                        597 	.ds 1
      000900                        598 _layer_hold_off_layer_10000_342:
      000900                        599 	.ds 1
      000901                        600 _layer_state_set_user_state_10000_349:
      000901                        601 	.ds 1
      000902                        602 _layer_state_set_kb_state_10000_351:
      000902                        603 	.ds 1
      000903                        604 _layer_state_set_state_10000_353:
      000903                        605 	.ds 1
      000904                        606 _layer_move_layer_10000_366:
      000904                        607 	.ds 1
      000905                        608 _layer_on_layer_10000_368:
      000905                        609 	.ds 1
      000906                        610 _layer_off_layer_10000_370:
      000906                        611 	.ds 1
      000907                        612 _layer_or_state_10000_374:
      000907                        613 	.ds 1
      000908                        614 _layer_and_state_10000_376:
      000908                        615 	.ds 1
      000909                        616 _layer_xor_state_10000_378:
      000909                        617 	.ds 1
      00090A                        618 _source_keycodes_cache:
      00090A                        619 	.ds 256
      000A0A                        620 _encoder_source_keycodes_cache:
      000A0A                        621 	.ds 4
      000A0E                        622 _source_keycode_cache_slot_position_10000_380:
      000A0E                        623 	.ds 2
      000A10                        624 _ak820_cache_keycode_PARM_2:
      000A10                        625 	.ds 2
      000A12                        626 _ak820_cache_keycode_position_10000_386:
      000A12                        627 	.ds 2
      000A14                        628 _ak820_cache_layer_PARM_2:
      000A14                        629 	.ds 1
      000A15                        630 _ak820_cache_layer_position_10000_389:
      000A15                        631 	.ds 2
      000A17                        632 _ak820_cached_key_position_10000_392:
      000A17                        633 	.ds 2
      000A19                        634 _ak820_resolve_key_PARM_2:
      000A19                        635 	.ds 1
      000A1A                        636 _ak820_resolve_key_position_10000_403:
      000A1A                        637 	.ds 2
      000A1C                        638 _ak820_layer_for_key_position_10000_410:
      000A1C                        639 	.ds 2
      000A1E                        640 _ak820_layer_for_key_layers_10000_411:
      000A1E                        641 	.ds 1
                                    642 ;--------------------------------------------------------
                                    643 ; absolute external ram data
                                    644 ;--------------------------------------------------------
                                    645 	.area XABS    (ABS,XDATA)
                                    646 ;--------------------------------------------------------
                                    647 ; initialized external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XISEG   (XDATA)
      000E95                        650 _default_layer_state::
      000E95                        651 	.ds 1
      000E96                        652 _layer_state::
      000E96                        653 	.ds 1
                                    654 	.area HOME    (CODE)
                                    655 	.area GSINIT0 (CODE)
                                    656 	.area GSINIT1 (CODE)
                                    657 	.area GSINIT2 (CODE)
                                    658 	.area GSINIT3 (CODE)
                                    659 	.area GSINIT4 (CODE)
                                    660 	.area GSINIT5 (CODE)
                                    661 	.area GSINIT  (CODE)
                                    662 	.area GSFINAL (CODE)
                                    663 	.area CSEG    (CODE)
                                    664 ;--------------------------------------------------------
                                    665 ; global & static initialisations
                                    666 ;--------------------------------------------------------
                                    667 	.area HOME    (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area GSINIT  (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; Home
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area HOME    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; code
                                    678 ;--------------------------------------------------------
                                    679 	.area CSEG    (CODE)
                                    680 ;------------------------------------------------------------
                                    681 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    682 ;------------------------------------------------------------
                                    683 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_190'
                                    684 ;------------------------------------------------------------
                                    685 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    686 ;	-----------------------------------------
                           000007   687 	ar7 = 0x07
                           000006   688 	ar6 = 0x06
                           000005   689 	ar5 = 0x05
                           000004   690 	ar4 = 0x04
                           000003   691 	ar3 = 0x03
                           000002   692 	ar2 = 0x02
                           000001   693 	ar1 = 0x01
                           000000   694 	ar0 = 0x00
                                    695 ;	 function default_layer_state_set_user
                                    696 ;	-----------------------------------------
      00805C                        697 _default_layer_state_set_user:
      00805C E5 82            [12]  698 	mov	a,dpl
      00805E 90 08 EF         [24]  699 	mov	dptr,#_default_layer_state_set_user_state_10000_317
      008061 12 60 61         [24]  700 	lcall	_ak820_outline_0172
                                    701 ;	quantum/action_layer.c:32: return state;
                                    702 ;	quantum/action_layer.c:33: }
      008064 22               [24]  703 	ret
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'default_layer_state_set_kb'
                                    706 ;------------------------------------------------------------
                                    707 ;state         Allocated with name '_default_layer_state_set_kb_state_10000_319'
                                    708 ;------------------------------------------------------------
                                    709 ;	quantum/action_layer.c:39: __attribute__((weak)) layer_state_t default_layer_state_set_kb(layer_state_t state) {
                                    710 ;	-----------------------------------------
                                    711 ;	 function default_layer_state_set_kb
                                    712 ;	-----------------------------------------
      008065                        713 _default_layer_state_set_kb:
      008065 E5 82            [12]  714 	mov	a,dpl
      008067 90 08 F0         [24]  715 	mov	dptr,#_default_layer_state_set_kb_state_10000_319
      00806A 12 60 61         [24]  716 	lcall	_ak820_outline_0172
                                    717 ;	quantum/action_layer.c:40: return default_layer_state_set_user(state);
                                    718 ;	quantum/action_layer.c:41: }
      00806D 01 5C            [12]  719 	ajmp	_default_layer_state_set_user
                                    720 ;------------------------------------------------------------
                                    721 ;Allocation info for local variables in function 'default_layer_state_set'
                                    722 ;------------------------------------------------------------
                                    723 ;state         Allocated with name '_default_layer_state_set_state_10000_321'
                                    724 ;------------------------------------------------------------
                                    725 ;	quantum/action_layer.c:47: static void default_layer_state_set(layer_state_t state) {
                                    726 ;	-----------------------------------------
                                    727 ;	 function default_layer_state_set
                                    728 ;	-----------------------------------------
      00806F                        729 _default_layer_state_set:
      00806F E5 82            [12]  730 	mov	a,dpl
      008071 90 08 F1         [24]  731 	mov	dptr,#_default_layer_state_set_state_10000_321
      008074 12 60 61         [24]  732 	lcall	_ak820_outline_0172
                                    733 ;	quantum/action_layer.c:48: state = default_layer_state_set_kb(state);
      008077 11 65            [12]  734 	acall	_default_layer_state_set_kb
      008079 AF 82            [24]  735 	mov	r7, dpl
      00807B 90 08 F1         [24]  736 	mov	dptr,#_default_layer_state_set_state_10000_321
      00807E EF               [12]  737 	mov	a,r7
      00807F F0               [24]  738 	movx	@dptr,a
                                    739 ;	quantum/action_layer.c:52: default_layer_state = state;
      008080 90 0E 95         [24]  740 	mov	dptr,#_default_layer_state
      008083 EF               [12]  741 	mov	a,r7
      008084 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action_layer.c:54: ak820_layer_refresh();
                                    744 ;	quantum/action_layer.c:57: ac_dprintf("\n");
                                    745 ;	quantum/action_layer.c:63: }
      008085 01 C8            [12]  746 	ajmp	_ak820_layer_refresh
                                    747 ;------------------------------------------------------------
                                    748 ;Allocation info for local variables in function 'default_layer_set'
                                    749 ;------------------------------------------------------------
                                    750 ;state         Allocated with name '_default_layer_set_state_10000_326'
                                    751 ;------------------------------------------------------------
                                    752 ;	quantum/action_layer.c:79: void default_layer_set(layer_state_t state) {
                                    753 ;	-----------------------------------------
                                    754 ;	 function default_layer_set
                                    755 ;	-----------------------------------------
      008087                        756 _default_layer_set:
      008087 E5 82            [12]  757 	mov	a,dpl
      008089 90 08 F2         [24]  758 	mov	dptr,#_default_layer_set_state_10000_326
      00808C 12 60 61         [24]  759 	lcall	_ak820_outline_0172
                                    760 ;	quantum/action_layer.c:80: default_layer_state_set(state);
                                    761 ;	quantum/action_layer.c:81: }
      00808F 01 6F            [12]  762 	ajmp	_default_layer_state_set
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'default_layer_or'
                                    765 ;------------------------------------------------------------
                                    766 ;state         Allocated with name '_default_layer_or_state_10000_328'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/action_layer.c:88: void default_layer_or(layer_state_t state) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function default_layer_or
                                    771 ;	-----------------------------------------
      008091                        772 _default_layer_or:
      008091 E5 82            [12]  773 	mov	a,dpl
      008093 90 08 F3         [24]  774 	mov	dptr,#_default_layer_or_state_10000_328
      008096 F0               [24]  775 	movx	@dptr,a
                                    776 ;	quantum/action_layer.c:89: default_layer_state_set(default_layer_state | state);
      008097 E0               [24]  777 	movx	a,@dptr
      008098 FF               [12]  778 	mov	r7,a
      008099 90 0E 95         [24]  779 	mov	dptr,#_default_layer_state
      00809C 12 84 45         [24]  780 	lcall	_ak820_outline_0142
                                    781 ;	quantum/action_layer.c:90: }
      00809F 01 6F            [12]  782 	ajmp	_default_layer_state_set
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'default_layer_and'
                                    785 ;------------------------------------------------------------
                                    786 ;state         Allocated with name '_default_layer_and_state_10000_330'
                                    787 ;------------------------------------------------------------
                                    788 ;	quantum/action_layer.c:95: void default_layer_and(layer_state_t state) {
                                    789 ;	-----------------------------------------
                                    790 ;	 function default_layer_and
                                    791 ;	-----------------------------------------
      0080A1                        792 _default_layer_and:
      0080A1 E5 82            [12]  793 	mov	a,dpl
      0080A3 90 08 F4         [24]  794 	mov	dptr,#_default_layer_and_state_10000_330
      0080A6 F0               [24]  795 	movx	@dptr,a
                                    796 ;	quantum/action_layer.c:96: default_layer_state_set(default_layer_state & state);
      0080A7 90 0E 95         [24]  797 	mov	dptr,#_default_layer_state
      0080AA E0               [24]  798 	movx	a,@dptr
      0080AB FF               [12]  799 	mov	r7,a
      0080AC 90 08 F4         [24]  800 	mov	dptr,#_default_layer_and_state_10000_330
      0080AF E0               [24]  801 	movx	a,@dptr
      0080B0 52 07            [12]  802 	anl	ar7,a
      0080B2 8F 82            [24]  803 	mov	dpl, r7
                                    804 ;	quantum/action_layer.c:97: }
      0080B4 01 6F            [12]  805 	ajmp	_default_layer_state_set
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'default_layer_xor'
                                    808 ;------------------------------------------------------------
                                    809 ;state         Allocated with name '_default_layer_xor_state_10000_332'
                                    810 ;------------------------------------------------------------
                                    811 ;	quantum/action_layer.c:102: void default_layer_xor(layer_state_t state) {
                                    812 ;	-----------------------------------------
                                    813 ;	 function default_layer_xor
                                    814 ;	-----------------------------------------
      0080B6                        815 _default_layer_xor:
      0080B6 E5 82            [12]  816 	mov	a,dpl
      0080B8 90 08 F5         [24]  817 	mov	dptr,#_default_layer_xor_state_10000_332
      0080BB F0               [24]  818 	movx	@dptr,a
                                    819 ;	quantum/action_layer.c:103: default_layer_state_set(default_layer_state ^ state);
      0080BC E0               [24]  820 	movx	a,@dptr
      0080BD FF               [12]  821 	mov	r7,a
      0080BE 90 0E 95         [24]  822 	mov	dptr,#_default_layer_state
      0080C1 E0               [24]  823 	movx	a,@dptr
      0080C2 62 07            [12]  824 	xrl	ar7,a
      0080C4 8F 82            [24]  825 	mov	dpl, r7
                                    826 ;	quantum/action_layer.c:104: }
      0080C6 01 6F            [12]  827 	ajmp	_default_layer_state_set
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'ak820_layer_refresh'
                                    830 ;------------------------------------------------------------
                                    831 ;state         Allocated with name '_ak820_layer_refresh_state_10000_335'
                                    832 ;i             Allocated with name '_ak820_layer_refresh_i_20000_336'
                                    833 ;------------------------------------------------------------
                                    834 ;	quantum/action_layer.c:114: void ak820_layer_refresh(void) {
                                    835 ;	-----------------------------------------
                                    836 ;	 function ak820_layer_refresh
                                    837 ;	-----------------------------------------
      0080C8                        838 _ak820_layer_refresh:
                                    839 ;	quantum/action_layer.c:115: layer_state_t state = persistent_layers;
      0080C8 90 08 F6         [24]  840 	mov	dptr,#_persistent_layers
      0080CB E0               [24]  841 	movx	a,@dptr
      0080CC 90 08 FE         [24]  842 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      0080CF F0               [24]  843 	movx	@dptr,a
                                    844 ;	quantum/action_layer.c:116: for (uint8_t i = 0; i < MAX_LAYER; ++i) if (layer_refs[i]) state |= (layer_state_t)1 << i;
      0080D0 7F 00            [12]  845 	mov	r7,#0x00
      0080D2                        846 00105$:
      0080D2 BF 06 00         [24]  847 	cjne	r7,#0x06,00131$
      0080D5                        848 00131$:
      0080D5 50 25            [24]  849 	jnc	00103$
      0080D7 EF               [12]  850 	mov	a,r7
      0080D8 24 F7            [12]  851 	add	a, #_layer_refs
      0080DA FD               [12]  852 	mov	r5,a
      0080DB E4               [12]  853 	clr	a
      0080DC 34 08            [12]  854 	addc	a, #(_layer_refs >> 8)
      0080DE FE               [12]  855 	mov	r6,a
      0080DF 12 38 94         [24]  856 	lcall	_ak820_outline_0136
      0080E2 E0               [24]  857 	movx	a,@dptr
      0080E3 60 14            [24]  858 	jz	00106$
      0080E5 8F F0            [24]  859 	mov	b,r7
      0080E7 05 F0            [12]  860 	inc	b
      0080E9 74 01            [12]  861 	mov	a,#0x01
      0080EB 80 02            [24]  862 	sjmp	00135$
      0080ED                        863 00134$:
      0080ED 25 E0            [12]  864 	add	a,acc
      0080EF                        865 00135$:
      0080EF D5 F0 FB         [24]  866 	djnz	b,00134$
      0080F2 FE               [12]  867 	mov	r6,a
      0080F3 90 08 FE         [24]  868 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      0080F6 E0               [24]  869 	movx	a,@dptr
      0080F7 4E               [12]  870 	orl	a,r6
      0080F8 F0               [24]  871 	movx	@dptr,a
      0080F9                        872 00106$:
      0080F9 0F               [12]  873 	inc	r7
      0080FA 80 D6            [24]  874 	sjmp	00105$
      0080FC                        875 00103$:
                                    876 ;	quantum/action_layer.c:118: state |= ak820_tri_layer_derived(state | default_layer_state);
      0080FC 90 0E 95         [24]  877 	mov	dptr,#_default_layer_state
      0080FF E0               [24]  878 	movx	a,@dptr
      008100 FF               [12]  879 	mov	r7,a
      008101 90 08 FE         [24]  880 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      008104 E0               [24]  881 	movx	a,@dptr
      008105 FE               [12]  882 	mov	r6,a
      008106 42 07            [12]  883 	orl	ar7,a
      008108 8F 82            [24]  884 	mov	dpl, r7
      00810A C0 06            [24]  885 	push	ar6
      00810C 12 AF 1D         [24]  886 	lcall	_ak820_tri_layer_derived
      00810F AF 82            [24]  887 	mov	r7, dpl
      008111 D0 06            [24]  888 	pop	ar6
      008113 90 08 FE         [24]  889 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      008116 EF               [12]  890 	mov	a,r7
      008117 4E               [12]  891 	orl	a,r6
      008118 12 60 61         [24]  892 	lcall	_ak820_outline_0172
                                    893 ;	quantum/action_layer.c:120: layer_state = layer_state_set_kb(state);
      00811B 31 B4            [24]  894 	acall	_layer_state_set_kb
      00811D E5 82            [12]  895 	mov	a, dpl
      00811F 90 0E 96         [24]  896 	mov	dptr,#_layer_state
      008122 F0               [24]  897 	movx	@dptr,a
                                    898 ;	quantum/action_layer.c:121: }
      008123 22               [24]  899 	ret
                                    900 ;------------------------------------------------------------
                                    901 ;Allocation info for local variables in function 'layer_hold_on'
                                    902 ;------------------------------------------------------------
                                    903 ;layer         Allocated with name '_layer_hold_on_layer_10000_338'
                                    904 ;------------------------------------------------------------
                                    905 ;	quantum/action_layer.c:122: void layer_hold_on(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, true)) { ++layer_refs[layer]; ak820_layer_refresh(); } }
                                    906 ;	-----------------------------------------
                                    907 ;	 function layer_hold_on
                                    908 ;	-----------------------------------------
      008124                        909 _layer_hold_on:
      008124 E5 82            [12]  910 	mov	a,dpl
      008126 90 08 FF         [24]  911 	mov	dptr,#_layer_hold_on_layer_10000_338
      008129 F0               [24]  912 	movx	@dptr,a
      00812A E0               [24]  913 	movx	a,@dptr
      00812B FF               [12]  914 	mov	r7,a
      00812C BF 06 00         [24]  915 	cjne	r7,#0x06,00120$
      00812F                        916 00120$:
      00812F 50 28            [24]  917 	jnc	00104$
      008131 12 84 51         [24]  918 	lcall	_ak820_outline_0178
      008134 74 01            [12]  919 	mov	a,#0x01
      008136 F0               [24]  920 	movx	@dptr,a
      008137 90 08 FD         [24]  921 	mov	dptr,#_macro_layers
      00813A C0 07            [24]  922 	push	ar7
      00813C 91 5A            [12]  923 	acall	_ak820_macro_change
      00813E E5 82            [12]  924 	mov	a, dpl
      008140 D0 07            [24]  925 	pop	ar7
      008142 60 15            [24]  926 	jz	00104$
      008144 EF               [12]  927 	mov	a,r7
      008145 24 F7            [12]  928 	add	a, #_layer_refs
      008147 FF               [12]  929 	mov	r7,a
      008148 E4               [12]  930 	clr	a
      008149 34 08            [12]  931 	addc	a, #(_layer_refs >> 8)
      00814B FE               [12]  932 	mov	r6,a
      00814C 12 43 65         [24]  933 	lcall	_ak820_outline_0159
      00814F E0               [24]  934 	movx	a,@dptr
      008150 FD               [12]  935 	mov	r5,a
      008151 0D               [12]  936 	inc	r5
      008152 12 43 65         [24]  937 	lcall	_ak820_outline_0159
      008155 ED               [12]  938 	mov	a,r5
      008156 F0               [24]  939 	movx	@dptr,a
      008157 01 C8            [12]  940 	ajmp	_ak820_layer_refresh
      008159                        941 00104$:
      008159 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'layer_hold_off'
                                    945 ;------------------------------------------------------------
                                    946 ;layer         Allocated with name '_layer_hold_off_layer_10000_342'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action_layer.c:123: void layer_hold_off(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, false) && layer_refs[layer]) { --layer_refs[layer]; ak820_layer_refresh(); } }
                                    949 ;	-----------------------------------------
                                    950 ;	 function layer_hold_off
                                    951 ;	-----------------------------------------
      00815A                        952 _layer_hold_off:
      00815A E5 82            [12]  953 	mov	a,dpl
      00815C 90 09 00         [24]  954 	mov	dptr,#_layer_hold_off_layer_10000_342
      00815F F0               [24]  955 	movx	@dptr,a
      008160 E0               [24]  956 	movx	a,@dptr
      008161 FF               [12]  957 	mov	r7,a
      008162 BF 06 00         [24]  958 	cjne	r7,#0x06,00128$
      008165                        959 00128$:
      008165 50 29            [24]  960 	jnc	00105$
      008167 12 84 51         [24]  961 	lcall	_ak820_outline_0178
      00816A E4               [12]  962 	clr	a
      00816B F0               [24]  963 	movx	@dptr,a
      00816C 90 08 FD         [24]  964 	mov	dptr,#_macro_layers
      00816F C0 07            [24]  965 	push	ar7
      008171 91 5A            [12]  966 	acall	_ak820_macro_change
      008173 E5 82            [12]  967 	mov	a, dpl
      008175 D0 07            [24]  968 	pop	ar7
      008177 60 17            [24]  969 	jz	00105$
      008179 EF               [12]  970 	mov	a,r7
      00817A 24 F7            [12]  971 	add	a, #_layer_refs
      00817C FE               [12]  972 	mov	r6,a
      00817D E4               [12]  973 	clr	a
      00817E 34 08            [12]  974 	addc	a, #(_layer_refs >> 8)
      008180 FF               [12]  975 	mov	r7,a
      008181 12 38 7F         [24]  976 	lcall	_ak820_outline_0120
      008184 E0               [24]  977 	movx	a,@dptr
      008185 FD               [12]  978 	mov	r5,a
      008186 60 08            [24]  979 	jz	00105$
      008188 1D               [12]  980 	dec	r5
      008189 12 38 7F         [24]  981 	lcall	_ak820_outline_0120
      00818C ED               [12]  982 	mov	a,r5
      00818D F0               [24]  983 	movx	@dptr,a
      00818E 01 C8            [12]  984 	ajmp	_ak820_layer_refresh
      008190                        985 00105$:
      008190 22               [24]  986 	ret
                                    987 ;------------------------------------------------------------
                                    988 ;Allocation info for local variables in function 'layer_hold_clear'
                                    989 ;------------------------------------------------------------
                                    990 ;i             Allocated with name '_layer_hold_clear_i_20000_348'
                                    991 ;------------------------------------------------------------
                                    992 ;	quantum/action_layer.c:124: void layer_hold_clear(void) { macro_layers = 0; for (uint8_t i = 0; i < MAX_LAYER; ++i) layer_refs[i] = 0; ak820_layer_refresh(); }
                                    993 ;	-----------------------------------------
                                    994 ;	 function layer_hold_clear
                                    995 ;	-----------------------------------------
      008191                        996 _layer_hold_clear:
      008191 90 08 FD         [24]  997 	mov	dptr,#_macro_layers
      008194 E4               [12]  998 	clr	a
      008195 F0               [24]  999 	movx	@dptr,a
      008196 FF               [12] 1000 	mov	r7,a
      008197                       1001 00103$:
      008197 BF 06 00         [24] 1002 	cjne	r7,#0x06,00122$
      00819A                       1003 00122$:
      00819A 50 0D            [24] 1004 	jnc	00101$
      00819C EF               [12] 1005 	mov	a,r7
      00819D 24 F7            [12] 1006 	add	a, #_layer_refs
      00819F F5 82            [12] 1007 	mov	dpl,a
      0081A1 E4               [12] 1008 	clr	a
      0081A2 34 08            [12] 1009 	addc	a, #(_layer_refs >> 8)
      0081A4 12 84 4B         [24] 1010 	lcall	_ak820_outline_0164
      0081A7 80 EE            [24] 1011 	sjmp	00103$
      0081A9                       1012 00101$:
      0081A9 01 C8            [12] 1013 	ajmp	_ak820_layer_refresh
                                   1014 ;------------------------------------------------------------
                                   1015 ;Allocation info for local variables in function 'layer_state_set_user'
                                   1016 ;------------------------------------------------------------
                                   1017 ;state         Allocated with name '_layer_state_set_user_state_10000_349'
                                   1018 ;------------------------------------------------------------
                                   1019 ;	quantum/action_layer.c:131: __attribute__((weak)) layer_state_t layer_state_set_user(layer_state_t state) {
                                   1020 ;	-----------------------------------------
                                   1021 ;	 function layer_state_set_user
                                   1022 ;	-----------------------------------------
      0081AB                       1023 _layer_state_set_user:
      0081AB E5 82            [12] 1024 	mov	a,dpl
      0081AD 90 09 01         [24] 1025 	mov	dptr,#_layer_state_set_user_state_10000_349
      0081B0 12 60 61         [24] 1026 	lcall	_ak820_outline_0172
                                   1027 ;	quantum/action_layer.c:132: return state;
                                   1028 ;	quantum/action_layer.c:133: }
      0081B3 22               [24] 1029 	ret
                                   1030 ;------------------------------------------------------------
                                   1031 ;Allocation info for local variables in function 'layer_state_set_kb'
                                   1032 ;------------------------------------------------------------
                                   1033 ;state         Allocated with name '_layer_state_set_kb_state_10000_351'
                                   1034 ;------------------------------------------------------------
                                   1035 ;	quantum/action_layer.c:139: __attribute__((weak)) layer_state_t layer_state_set_kb(layer_state_t state) {
                                   1036 ;	-----------------------------------------
                                   1037 ;	 function layer_state_set_kb
                                   1038 ;	-----------------------------------------
      0081B4                       1039 _layer_state_set_kb:
      0081B4 E5 82            [12] 1040 	mov	a,dpl
      0081B6 90 09 02         [24] 1041 	mov	dptr,#_layer_state_set_kb_state_10000_351
      0081B9 12 60 61         [24] 1042 	lcall	_ak820_outline_0172
                                   1043 ;	quantum/action_layer.c:140: return layer_state_set_user(state);
                                   1044 ;	quantum/action_layer.c:141: }
      0081BC 21 AB            [24] 1045 	ajmp	_layer_state_set_user
                                   1046 ;------------------------------------------------------------
                                   1047 ;Allocation info for local variables in function 'layer_state_set'
                                   1048 ;------------------------------------------------------------
                                   1049 ;state         Allocated with name '_layer_state_set_state_10000_353'
                                   1050 ;------------------------------------------------------------
                                   1051 ;	quantum/action_layer.c:147: void layer_state_set(layer_state_t state) {
                                   1052 ;	-----------------------------------------
                                   1053 ;	 function layer_state_set
                                   1054 ;	-----------------------------------------
      0081BE                       1055 _layer_state_set:
      0081BE E5 82            [12] 1056 	mov	a,dpl
      0081C0 90 09 03         [24] 1057 	mov	dptr,#_layer_state_set_state_10000_353
      0081C3 F0               [24] 1058 	movx	@dptr,a
                                   1059 ;	quantum/action_layer.c:149: persistent_layers = state;
      0081C4 E0               [24] 1060 	movx	a,@dptr
      0081C5 90 08 F6         [24] 1061 	mov	dptr,#_persistent_layers
      0081C8 F0               [24] 1062 	movx	@dptr,a
                                   1063 ;	quantum/action_layer.c:150: ak820_layer_refresh();
                                   1064 ;	quantum/action_layer.c:151: return;
                                   1065 ;	quantum/action_layer.c:159: ac_dprintf("\n");
                                   1066 ;	quantum/action_layer.c:165: }
      0081C9 01 C8            [12] 1067 	ajmp	_ak820_layer_refresh
                                   1068 ;------------------------------------------------------------
                                   1069 ;Allocation info for local variables in function 'layer_clear'
                                   1070 ;------------------------------------------------------------
                                   1071 ;	quantum/action_layer.c:171: void layer_clear(void) {
                                   1072 ;	-----------------------------------------
                                   1073 ;	 function layer_clear
                                   1074 ;	-----------------------------------------
      0081CB                       1075 _layer_clear:
                                   1076 ;	quantum/action_layer.c:172: layer_state_set(0);
      0081CB 75 82 00         [24] 1077 	mov	dpl, #0x00
                                   1078 ;	quantum/action_layer.c:173: }
      0081CE 21 BE            [24] 1079 	ajmp	_layer_state_set
                                   1080 ;------------------------------------------------------------
                                   1081 ;Allocation info for local variables in function 'layer_state_is'
                                   1082 ;------------------------------------------------------------
                                   1083 ;layer         Allocated with name '_layer_state_is_layer_10000_360'
                                   1084 ;------------------------------------------------------------
                                   1085 ;	quantum/action_layer.c:179: bool layer_state_is(uint8_t layer) {
                                   1086 ;	-----------------------------------------
                                   1087 ;	 function layer_move
                                   1088 ;	-----------------------------------------
      0081D0                       1089 _layer_move:
      0081D0 E5 82            [12] 1090 	mov	a,dpl
      0081D2 90 09 04         [24] 1091 	mov	dptr,#_layer_move_layer_10000_366
      0081D5 F0               [24] 1092 	movx	@dptr,a
                                   1093 ;	quantum/action_layer.c:199: layer_state_set((layer_state_t)1 << layer);
      0081D6 E0               [24] 1094 	movx	a,@dptr
      0081D7 12 80 02         [24] 1095 	lcall	_ak820_outline_0064
      0081DA 80 02            [24] 1096 	sjmp	00104$
      0081DC                       1097 00103$:
      0081DC 25 E0            [12] 1098 	add	a,acc
      0081DE                       1099 00104$:
      0081DE D5 F0 FB         [24] 1100 	djnz	b,00103$
      0081E1 F5 82            [12] 1101 	mov	dpl,a
                                   1102 ;	quantum/action_layer.c:200: }
      0081E3 21 BE            [24] 1103 	ajmp	_layer_state_set
                                   1104 ;------------------------------------------------------------
                                   1105 ;Allocation info for local variables in function 'layer_on'
                                   1106 ;------------------------------------------------------------
                                   1107 ;layer         Allocated with name '_layer_on_layer_10000_368'
                                   1108 ;------------------------------------------------------------
                                   1109 ;	quantum/action_layer.c:206: void layer_on(uint8_t layer) {
                                   1110 ;	-----------------------------------------
                                   1111 ;	 function layer_on
                                   1112 ;	-----------------------------------------
      0081E5                       1113 _layer_on:
      0081E5 E5 82            [12] 1114 	mov	a,dpl
      0081E7 90 09 05         [24] 1115 	mov	dptr,#_layer_on_layer_10000_368
      0081EA F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	quantum/action_layer.c:213: ((layer_state_t)1 << layer));
      0081EB E0               [24] 1118 	movx	a,@dptr
      0081EC 12 80 02         [24] 1119 	lcall	_ak820_outline_0064
      0081EF 80 02            [24] 1120 	sjmp	00104$
      0081F1                       1121 00103$:
      0081F1 25 E0            [12] 1122 	add	a,acc
      0081F3                       1123 00104$:
      0081F3 D5 F0 FB         [24] 1124 	djnz	b,00103$
      0081F6 FF               [12] 1125 	mov	r7,a
      0081F7 90 08 F6         [24] 1126 	mov	dptr,#_persistent_layers
      0081FA 12 84 45         [24] 1127 	lcall	_ak820_outline_0142
                                   1128 ;	quantum/action_layer.c:214: }
      0081FD 21 BE            [24] 1129 	ajmp	_layer_state_set
                                   1130 ;------------------------------------------------------------
                                   1131 ;Allocation info for local variables in function 'layer_off'
                                   1132 ;------------------------------------------------------------
                                   1133 ;layer         Allocated with name '_layer_off_layer_10000_370'
                                   1134 ;------------------------------------------------------------
                                   1135 ;	quantum/action_layer.c:220: void layer_off(uint8_t layer) {
                                   1136 ;	-----------------------------------------
                                   1137 ;	 function layer_off
                                   1138 ;	-----------------------------------------
      0081FF                       1139 _layer_off:
      0081FF E5 82            [12] 1140 	mov	a,dpl
      008201 90 09 06         [24] 1141 	mov	dptr,#_layer_off_layer_10000_370
      008204 F0               [24] 1142 	movx	@dptr,a
                                   1143 ;	quantum/action_layer.c:227: ~((layer_state_t)1 << layer));
      008205 E0               [24] 1144 	movx	a,@dptr
      008206 12 80 02         [24] 1145 	lcall	_ak820_outline_0064
      008209 80 02            [24] 1146 	sjmp	00104$
      00820B                       1147 00103$:
      00820B 25 E0            [12] 1148 	add	a,acc
      00820D                       1149 00104$:
      00820D D5 F0 FB         [24] 1150 	djnz	b,00103$
      008210 F4               [12] 1151 	cpl	a
      008211 FF               [12] 1152 	mov	r7,a
      008212 90 08 F6         [24] 1153 	mov	dptr,#_persistent_layers
      008215 E0               [24] 1154 	movx	a,@dptr
      008216 52 07            [12] 1155 	anl	ar7,a
      008218 8F 82            [24] 1156 	mov	dpl, r7
                                   1157 ;	quantum/action_layer.c:228: }
      00821A 21 BE            [24] 1158 	ajmp	_layer_state_set
                                   1159 ;------------------------------------------------------------
                                   1160 ;Allocation info for local variables in function 'layer_invert'
                                   1161 ;------------------------------------------------------------
                                   1162 ;layer         Allocated with name '_layer_invert_layer_10000_372'
                                   1163 ;------------------------------------------------------------
                                   1164 ;	quantum/action_layer.c:234: void layer_invert(uint8_t layer) {
                                   1165 ;	-----------------------------------------
                                   1166 ;	 function layer_or
                                   1167 ;	-----------------------------------------
      00821C                       1168 _layer_or:
      00821C E5 82            [12] 1169 	mov	a,dpl
      00821E 90 09 07         [24] 1170 	mov	dptr,#_layer_or_state_10000_374
      008221 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	quantum/action_layer.c:255: state);
      008222 E0               [24] 1173 	movx	a,@dptr
      008223 FF               [12] 1174 	mov	r7,a
      008224 90 08 F6         [24] 1175 	mov	dptr,#_persistent_layers
      008227 12 84 45         [24] 1176 	lcall	_ak820_outline_0142
                                   1177 ;	quantum/action_layer.c:256: }
      00822A 21 BE            [24] 1178 	ajmp	_layer_state_set
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'layer_and'
                                   1181 ;------------------------------------------------------------
                                   1182 ;state         Allocated with name '_layer_and_state_10000_376'
                                   1183 ;------------------------------------------------------------
                                   1184 ;	quantum/action_layer.c:261: void layer_and(layer_state_t state) {
                                   1185 ;	-----------------------------------------
                                   1186 ;	 function layer_and
                                   1187 ;	-----------------------------------------
      00822C                       1188 _layer_and:
      00822C E5 82            [12] 1189 	mov	a,dpl
      00822E 90 09 08         [24] 1190 	mov	dptr,#_layer_and_state_10000_376
      008231 F0               [24] 1191 	movx	@dptr,a
                                   1192 ;	quantum/action_layer.c:268: state);
      008232 90 08 F6         [24] 1193 	mov	dptr,#_persistent_layers
      008235 E0               [24] 1194 	movx	a,@dptr
      008236 FF               [12] 1195 	mov	r7,a
      008237 90 09 08         [24] 1196 	mov	dptr,#_layer_and_state_10000_376
      00823A E0               [24] 1197 	movx	a,@dptr
      00823B 52 07            [12] 1198 	anl	ar7,a
      00823D 8F 82            [24] 1199 	mov	dpl, r7
                                   1200 ;	quantum/action_layer.c:269: }
      00823F 21 BE            [24] 1201 	ajmp	_layer_state_set
                                   1202 ;------------------------------------------------------------
                                   1203 ;Allocation info for local variables in function 'layer_xor'
                                   1204 ;------------------------------------------------------------
                                   1205 ;state         Allocated with name '_layer_xor_state_10000_378'
                                   1206 ;------------------------------------------------------------
                                   1207 ;	quantum/action_layer.c:274: void layer_xor(layer_state_t state) {
                                   1208 ;	-----------------------------------------
                                   1209 ;	 function layer_xor
                                   1210 ;	-----------------------------------------
      008241                       1211 _layer_xor:
      008241 E5 82            [12] 1212 	mov	a,dpl
      008243 90 09 09         [24] 1213 	mov	dptr,#_layer_xor_state_10000_378
      008246 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	quantum/action_layer.c:281: state);
      008247 E0               [24] 1216 	movx	a,@dptr
      008248 FF               [12] 1217 	mov	r7,a
      008249 90 08 F6         [24] 1218 	mov	dptr,#_persistent_layers
      00824C E0               [24] 1219 	movx	a,@dptr
      00824D 62 07            [12] 1220 	xrl	ar7,a
      00824F 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	quantum/action_layer.c:282: }
      008251 21 BE            [24] 1223 	ajmp	_layer_state_set
                                   1224 ;------------------------------------------------------------
                                   1225 ;Allocation info for local variables in function 'source_keycode_cache_slot'
                                   1226 ;------------------------------------------------------------
                                   1227 ;position      Allocated with name '_source_keycode_cache_slot_position_10000_380'
                                   1228 ;row           Allocated with name '_source_keycode_cache_slot_row_10000_381'
                                   1229 ;col           Allocated with name '_source_keycode_cache_slot_col_10000_381'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_layer.c:324: static uint16_t SOURCE_CACHE_MEM *source_keycode_cache_slot(uint16_t position) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function source_keycode_cache_slot
                                   1234 ;	-----------------------------------------
      008253                       1235 _source_keycode_cache_slot:
      008253 12 38 75         [24] 1236 	lcall	_ak820_outline_0108
      008256 90 0A 0E         [24] 1237 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      008259 12 38 7A         [24] 1238 	lcall	_ak820_outline_0109
                                   1239 ;	quantum/action_layer.c:325: uint8_t row = position >> 8, col = position;
      00825C 90 0A 0E         [24] 1240 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      00825F E0               [24] 1241 	movx	a,@dptr
      008260 FE               [12] 1242 	mov	r6,a
      008261 A3               [24] 1243 	inc	dptr
      008262 E0               [24] 1244 	movx	a,@dptr
      008263 FD               [12] 1245 	mov	r5,a
                                   1246 ;	quantum/action_layer.c:326: if (row < MATRIX_ROWS && col < MATRIX_COLS) {
      008264 BD 10 00         [24] 1247 	cjne	r5,#0x10,00147$
      008267                       1248 00147$:
      008267 50 21            [24] 1249 	jnc	00102$
      008269 BE 08 00         [24] 1250 	cjne	r6,#0x08,00149$
      00826C                       1251 00149$:
      00826C 50 1C            [24] 1252 	jnc	00102$
                                   1253 ;	quantum/action_layer.c:327: return &source_keycodes_cache[(uint8_t)(row * MATRIX_COLS + col)];
      00826E 8D 07            [24] 1254 	mov	ar7,r5
      008270 EF               [12] 1255 	mov	a,r7
      008271 12 38 B9         [24] 1256 	lcall	_ak820_outline_0191
      008274 FF               [12] 1257 	mov	r7,a
      008275 8E 04            [24] 1258 	mov	ar4,r6
      008277 EC               [12] 1259 	mov	a,r4
      008278 2F               [12] 1260 	add	a, r7
      008279 75 F0 02         [24] 1261 	mov	b,#0x02
      00827C A4               [48] 1262 	mul	ab
      00827D 24 0A            [12] 1263 	add	a, #_source_keycodes_cache
      00827F FC               [12] 1264 	mov	r4,a
      008280 74 09            [12] 1265 	mov	a,#(_source_keycodes_cache >> 8)
      008282 35 F0            [12] 1266 	addc	a, b
      008284 FF               [12] 1267 	mov	r7,a
      008285 8C 82            [24] 1268 	mov	dpl, r4
      008287 8F 83            [24] 1269 	mov	dph, r7
      008289 22               [24] 1270 	ret
      00828A                       1271 00102$:
                                   1272 ;	quantum/action_layer.c:330: if ((row == KEYLOC_ENCODER_CW || row == KEYLOC_ENCODER_CCW) && col < NUM_ENCODERS) {
      00828A BD FD 02         [24] 1273 	cjne	r5,#0xfd,00151$
      00828D 80 03            [24] 1274 	sjmp	00107$
      00828F                       1275 00151$:
      00828F BD FC 2E         [24] 1276 	cjne	r5,#0xfc,00105$
      008292                       1277 00107$:
      008292 BE 01 00         [24] 1278 	cjne	r6,#0x01,00154$
      008295                       1279 00154$:
      008295 50 29            [24] 1280 	jnc	00105$
                                   1281 ;	quantum/action_layer.c:331: return &encoder_source_keycodes_cache[col + (row == KEYLOC_ENCODER_CCW ? NUM_ENCODERS : 0)];
      008297 BD FC 04         [24] 1282 	cjne	r5,#0xfc,00110$
      00829A 7F 01            [12] 1283 	mov	r7,#0x01
      00829C 80 02            [24] 1284 	sjmp	00111$
      00829E                       1285 00110$:
      00829E 7F 00            [12] 1286 	mov	r7,#0x00
      0082A0                       1287 00111$:
      0082A0 C2 D5            [12] 1288 	clr	F0
      0082A2 75 F0 02         [24] 1289 	mov	b,#0x02
      0082A5 EF               [12] 1290 	mov	a,r7
      0082A6 30 E7 04         [24] 1291 	jnb	acc.7,00158$
      0082A9 B2 D5            [12] 1292 	cpl	F0
      0082AB F4               [12] 1293 	cpl	a
      0082AC 04               [12] 1294 	inc	a
      0082AD                       1295 00158$:
      0082AD A4               [48] 1296 	mul	ab
      0082AE 30 D5 03         [24] 1297 	jnb	F0,00159$
      0082B1 12 78 B5         [24] 1298 	lcall	_ak820_outline_0132
      0082B4                       1299 00159$:
      0082B4 24 0A            [12] 1300 	add	a, #_encoder_source_keycodes_cache
      0082B6 FE               [12] 1301 	mov	r6,a
      0082B7 74 0A            [12] 1302 	mov	a,#(_encoder_source_keycodes_cache >> 8)
      0082B9 35 F0            [12] 1303 	addc	a, b
      0082BB FF               [12] 1304 	mov	r7,a
      0082BC 12 38 7F         [24] 1305 	lcall	_ak820_outline_0120
      0082BF 22               [24] 1306 	ret
      0082C0                       1307 00105$:
                                   1308 ;	quantum/action_layer.c:334: return 0;
      0082C0 90 00 00         [24] 1309 	mov	dptr,#0x0000
                                   1310 ;	quantum/action_layer.c:335: }
      0082C3 22               [24] 1311 	ret
                                   1312 ;------------------------------------------------------------
                                   1313 ;Allocation info for local variables in function 'ak820_cache_keycode'
                                   1314 ;------------------------------------------------------------
                                   1315 ;keycode       Allocated with name '_ak820_cache_keycode_PARM_2'
                                   1316 ;position      Allocated with name '_ak820_cache_keycode_position_10000_386'
                                   1317 ;slot          Allocated with name '_ak820_cache_keycode_slot_10000_387'
                                   1318 ;------------------------------------------------------------
                                   1319 ;	quantum/action_layer.c:339: bool ak820_cache_keycode(uint16_t position, uint16_t keycode) {
                                   1320 ;	-----------------------------------------
                                   1321 ;	 function ak820_cache_keycode
                                   1322 ;	-----------------------------------------
      0082C4                       1323 _ak820_cache_keycode:
      0082C4 12 38 75         [24] 1324 	lcall	_ak820_outline_0108
      0082C7 90 0A 12         [24] 1325 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      0082CA 12 38 7A         [24] 1326 	lcall	_ak820_outline_0109
                                   1327 ;	quantum/action_layer.c:340: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      0082CD 90 0A 12         [24] 1328 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      0082D0 12 37 E7         [24] 1329 	lcall	_ak820_outline_0005
      0082D3 51 53            [24] 1330 	acall	_source_keycode_cache_slot
      0082D5 12 43 4F         [24] 1331 	lcall	_ak820_outline_0135
                                   1332 ;	quantum/action_layer.c:341: if (!slot) return false;
      0082D8 EE               [12] 1333 	mov	a,r6
      0082D9 4F               [12] 1334 	orl	a,r7
      0082DA 70 03            [24] 1335 	jnz	00102$
      0082DC F5 82            [12] 1336 	mov	dpl,a
      0082DE 22               [24] 1337 	ret
      0082DF                       1338 00102$:
                                   1339 ;	quantum/action_layer.c:342: *slot = keycode;
      0082DF 90 0A 10         [24] 1340 	mov	dptr,#_ak820_cache_keycode_PARM_2
      0082E2 12 38 4B         [24] 1341 	lcall	_ak820_outline_0062
      0082E5 12 38 7F         [24] 1342 	lcall	_ak820_outline_0120
      0082E8 12 38 57         [24] 1343 	lcall	_ak820_outline_0079
                                   1344 ;	quantum/action_layer.c:343: return true;
      0082EB 75 82 01         [24] 1345 	mov	dpl, #0x01
                                   1346 ;	quantum/action_layer.c:344: }
      0082EE 22               [24] 1347 	ret
                                   1348 ;------------------------------------------------------------
                                   1349 ;Allocation info for local variables in function 'ak820_cache_layer'
                                   1350 ;------------------------------------------------------------
                                   1351 ;layer         Allocated with name '_ak820_cache_layer_PARM_2'
                                   1352 ;position      Allocated with name '_ak820_cache_layer_position_10000_389'
                                   1353 ;slot          Allocated with name '_ak820_cache_layer_slot_10000_390'
                                   1354 ;------------------------------------------------------------
                                   1355 ;	quantum/action_layer.c:346: void ak820_cache_layer(uint16_t position, uint8_t layer) {
                                   1356 ;	-----------------------------------------
                                   1357 ;	 function ak820_cache_layer
                                   1358 ;	-----------------------------------------
      0082EF                       1359 _ak820_cache_layer:
      0082EF 12 38 75         [24] 1360 	lcall	_ak820_outline_0108
      0082F2 90 0A 15         [24] 1361 	mov	dptr,#_ak820_cache_layer_position_10000_389
      0082F5 12 38 7A         [24] 1362 	lcall	_ak820_outline_0109
                                   1363 ;	quantum/action_layer.c:347: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      0082F8 90 0A 15         [24] 1364 	mov	dptr,#_ak820_cache_layer_position_10000_389
      0082FB 12 37 E7         [24] 1365 	lcall	_ak820_outline_0005
      0082FE C0 07            [24] 1366 	push	ar7
      008300 C0 06            [24] 1367 	push	ar6
      008302 51 53            [24] 1368 	acall	_source_keycode_cache_slot
      008304 12 43 60         [24] 1369 	lcall	_ak820_outline_0150
      008307 D0 06            [24] 1370 	pop	ar6
      008309 D0 07            [24] 1371 	pop	ar7
                                   1372 ;	quantum/action_layer.c:348: if (!slot) return;
      00830B EC               [12] 1373 	mov	a,r4
      00830C 4D               [12] 1374 	orl	a,r5
      00830D 70 01            [24] 1375 	jnz	00102$
      00830F 22               [24] 1376 	ret
      008310                       1377 00102$:
                                   1378 ;	quantum/action_layer.c:349: layer &= (1u << MAX_LAYER_BITS) - 1;
      008310 90 0A 14         [24] 1379 	mov	dptr,#_ak820_cache_layer_PARM_2
      008313 E0               [24] 1380 	movx	a,@dptr
      008314 53 E0 07         [24] 1381 	anl	acc,#0x07
      008317 F0               [24] 1382 	movx	@dptr,a
                                   1383 ;	quantum/action_layer.c:361: *slot = ak820_keycode_at(layer, position);
      008318 90 0A 14         [24] 1384 	mov	dptr,#_ak820_cache_layer_PARM_2
      00831B E0               [24] 1385 	movx	a,@dptr
      00831C FB               [12] 1386 	mov	r3,a
      00831D 90 0C 57         [24] 1387 	mov	dptr,#_ak820_keycode_at_PARM_2
      008320 12 51 E9         [24] 1388 	lcall	_ak820_outline_0061
      008323 8B 82            [24] 1389 	mov	dpl, r3
      008325 C0 05            [24] 1390 	push	ar5
      008327 C0 04            [24] 1391 	push	ar4
      008329 12 9F FC         [24] 1392 	lcall	_ak820_keycode_at
      00832C 12 43 4F         [24] 1393 	lcall	_ak820_outline_0135
      00832F D0 04            [24] 1394 	pop	ar4
      008331 D0 05            [24] 1395 	pop	ar5
      008333 12 38 8A         [24] 1396 	lcall	_ak820_outline_0126
      008336 12 51 E9         [24] 1397 	lcall	_ak820_outline_0061
                                   1398 ;	quantum/action_layer.c:362: }
      008339 22               [24] 1399 	ret
                                   1400 ;------------------------------------------------------------
                                   1401 ;Allocation info for local variables in function 'ak820_cached_key'
                                   1402 ;------------------------------------------------------------
                                   1403 ;position      Allocated with name '_ak820_cached_key_position_10000_392'
                                   1404 ;slot          Allocated with name '_ak820_cached_key_slot_10001_396'
                                   1405 ;------------------------------------------------------------
                                   1406 ;	quantum/action_layer.c:383: uint16_t ak820_cached_key(uint16_t position) {
                                   1407 ;	-----------------------------------------
                                   1408 ;	 function ak820_cached_key
                                   1409 ;	-----------------------------------------
      00833A                       1410 _ak820_cached_key:
      00833A 12 38 75         [24] 1411 	lcall	_ak820_outline_0108
      00833D 90 0A 17         [24] 1412 	mov	dptr,#_ak820_cached_key_position_10000_392
      008340 12 38 7A         [24] 1413 	lcall	_ak820_outline_0109
                                   1414 ;	quantum/action_layer.c:386: if (vial_unlock_in_progress) return KC_NO;
      008343 90 0E F5         [24] 1415 	mov	dptr,#_vial_unlock_in_progress
      008346 E0               [24] 1416 	movx	a,@dptr
      008347 60 04            [24] 1417 	jz	00102$
      008349 90 00 00         [24] 1418 	mov	dptr,#0x0000
      00834C 22               [24] 1419 	ret
      00834D                       1420 00102$:
                                   1421 ;	quantum/action_layer.c:387: if (position == (((uint16_t)VIAL_MATRIX_MAGIC << 8) | VIAL_MATRIX_MAGIC)) return g_vial_magic_keycode_override;
      00834D 90 0A 17         [24] 1422 	mov	dptr,#_ak820_cached_key_position_10000_392
      008350 12 38 34         [24] 1423 	lcall	_ak820_outline_0054
      008353 BE F0 0D         [24] 1424 	cjne	r6,#0xf0,00104$
      008356 BF F0 0A         [24] 1425 	cjne	r7,#0xf0,00104$
      008359 90 0D 4B         [24] 1426 	mov	dptr,#_g_vial_magic_keycode_override
      00835C 12 38 4B         [24] 1427 	lcall	_ak820_outline_0062
      00835F 12 38 8A         [24] 1428 	lcall	_ak820_outline_0126
      008362 22               [24] 1429 	ret
      008363                       1430 00104$:
                                   1431 ;	quantum/action_layer.c:389: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      008363 12 38 7F         [24] 1432 	lcall	_ak820_outline_0120
      008366 51 53            [24] 1433 	acall	_source_keycode_cache_slot
      008368 12 43 4F         [24] 1434 	lcall	_ak820_outline_0135
                                   1435 ;	quantum/action_layer.c:390: return slot ? *slot : KC_NO;
      00836B EE               [12] 1436 	mov	a,r6
      00836C 4F               [12] 1437 	orl	a,r7
      00836D 60 08            [24] 1438 	jz	00107$
      00836F 12 38 7F         [24] 1439 	lcall	_ak820_outline_0120
      008372 12 38 34         [24] 1440 	lcall	_ak820_outline_0054
      008375 80 04            [24] 1441 	sjmp	00108$
      008377                       1442 00107$:
      008377 7E 00            [12] 1443 	mov	r6,#0x00
      008379 7F 00            [12] 1444 	mov	r7,#0x00
      00837B                       1445 00108$:
      00837B 12 38 7F         [24] 1446 	lcall	_ak820_outline_0120
                                   1447 ;	quantum/action_layer.c:391: }
      00837E 22               [24] 1448 	ret
                                   1449 ;------------------------------------------------------------
                                   1450 ;Allocation info for local variables in function 'update_source_keycode_cache'
                                   1451 ;------------------------------------------------------------
                                   1452 ;key           Allocated with name '_update_source_keycode_cache_PARM_1'
                                   1453 ;keycode       Allocated with name '_update_source_keycode_cache_keycode_10000_397'
                                   1454 ;------------------------------------------------------------
                                   1455 ;	quantum/action_layer.c:394: bool update_source_keycode_cache(keypos_t key, uint16_t keycode) {
                                   1456 ;	-----------------------------------------
                                   1457 ;	 function ak820_resolve_key
                                   1458 ;	-----------------------------------------
      00837F                       1459 _ak820_resolve_key:
      00837F 12 38 75         [24] 1460 	lcall	_ak820_outline_0108
      008382 90 0A 1A         [24] 1461 	mov	dptr,#_ak820_resolve_key_position_10000_403
      008385 12 38 7A         [24] 1462 	lcall	_ak820_outline_0109
                                   1463 ;	quantum/action_layer.c:493: if (disable_action_cache) {
      008388 90 0E 94         [24] 1464 	mov	dptr,#_disable_action_cache
      00838B E0               [24] 1465 	movx	a,@dptr
      00838C 60 1D            [24] 1466 	jz	00102$
                                   1467 ;	quantum/action_layer.c:494: return ak820_keycode_at(ak820_layer_for_key(position), position);
      00838E 90 0A 1A         [24] 1468 	mov	dptr,#_ak820_resolve_key_position_10000_403
      008391 12 37 E7         [24] 1469 	lcall	_ak820_outline_0005
      008394 C0 07            [24] 1470 	push	ar7
      008396 C0 06            [24] 1471 	push	ar6
      008398 71 D3            [12] 1472 	acall	_ak820_layer_for_key
      00839A AD 82            [24] 1473 	mov	r5, dpl
      00839C D0 06            [24] 1474 	pop	ar6
      00839E D0 07            [24] 1475 	pop	ar7
      0083A0 90 0C 57         [24] 1476 	mov	dptr,#_ak820_keycode_at_PARM_2
      0083A3 12 51 E9         [24] 1477 	lcall	_ak820_outline_0061
      0083A6 8D 82            [24] 1478 	mov	dpl, r5
      0083A8 02 9F FC         [24] 1479 	ljmp	_ak820_keycode_at
      0083AB                       1480 00102$:
                                   1481 ;	quantum/action_layer.c:496: if (cache_press) ak820_cache_layer(position, ak820_layer_for_key(position));
      0083AB 90 0A 19         [24] 1482 	mov	dptr,#_ak820_resolve_key_PARM_2
      0083AE E0               [24] 1483 	movx	a,@dptr
      0083AF 60 1A            [24] 1484 	jz	00104$
      0083B1 90 0A 1A         [24] 1485 	mov	dptr,#_ak820_resolve_key_position_10000_403
      0083B4 12 37 E7         [24] 1486 	lcall	_ak820_outline_0005
      0083B7 C0 07            [24] 1487 	push	ar7
      0083B9 C0 06            [24] 1488 	push	ar6
      0083BB 71 D3            [12] 1489 	acall	_ak820_layer_for_key
      0083BD E5 82            [12] 1490 	mov	a, dpl
      0083BF D0 06            [24] 1491 	pop	ar6
      0083C1 D0 07            [24] 1492 	pop	ar7
      0083C3 90 0A 14         [24] 1493 	mov	dptr,#_ak820_cache_layer_PARM_2
      0083C6 12 43 31         [24] 1494 	lcall	_ak820_outline_0068
      0083C9 51 EF            [24] 1495 	acall	_ak820_cache_layer
      0083CB                       1496 00104$:
                                   1497 ;	quantum/action_layer.c:497: return ak820_cached_key(position);
      0083CB 90 0A 1A         [24] 1498 	mov	dptr,#_ak820_resolve_key_position_10000_403
      0083CE 12 37 E7         [24] 1499 	lcall	_ak820_outline_0005
                                   1500 ;	quantum/action_layer.c:498: }
      0083D1 61 3A            [24] 1501 	ajmp	_ak820_cached_key
                                   1502 ;------------------------------------------------------------
                                   1503 ;Allocation info for local variables in function 'store_or_get_action'
                                   1504 ;------------------------------------------------------------
                                   1505 ;key           Allocated with name '_store_or_get_action_PARM_2'
                                   1506 ;pressed       Allocated with name '_store_or_get_action_pressed_10000_408'
                                   1507 ;------------------------------------------------------------
                                   1508 ;	quantum/action_layer.c:499: uint16_t store_or_get_action(bool pressed, keypos_t key) {
                                   1509 ;	-----------------------------------------
                                   1510 ;	 function ak820_layer_for_key
                                   1511 ;	-----------------------------------------
      0083D3                       1512 _ak820_layer_for_key:
      0083D3 12 38 75         [24] 1513 	lcall	_ak820_outline_0108
      0083D6 90 0A 1C         [24] 1514 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      0083D9 12 38 7A         [24] 1515 	lcall	_ak820_outline_0109
                                   1516 ;	quantum/action_layer.c:539: layer_state_t layers = layer_state | default_layer_state;
      0083DC 90 0E 95         [24] 1517 	mov	dptr,#_default_layer_state
      0083DF E0               [24] 1518 	movx	a,@dptr
      0083E0 FF               [12] 1519 	mov	r7,a
      0083E1 90 0E 96         [24] 1520 	mov	dptr,#_layer_state
      0083E4 E0               [24] 1521 	movx	a,@dptr
      0083E5 90 0A 1E         [24] 1522 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      0083E8 4F               [12] 1523 	orl	a,r7
      0083E9 F0               [24] 1524 	movx	@dptr,a
                                   1525 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      0083EA 90 0A 1C         [24] 1526 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      0083ED 12 38 34         [24] 1527 	lcall	_ak820_outline_0054
      0083F0 7D 05            [12] 1528 	mov	r5,#0x05
      0083F2                       1529 00107$:
      0083F2 ED               [12] 1530 	mov	a,r5
      0083F3 20 E7 4B         [24] 1531 	jb	acc.7,00105$
                                   1532 ;	quantum/action_layer.c:542: if (layers & ((layer_state_t)1 << i)) {
      0083F6 8D F0            [24] 1533 	mov	b,r5
      0083F8 05 F0            [12] 1534 	inc	b
      0083FA 7B 01            [12] 1535 	mov	r3,#0x01
      0083FC 7C 00            [12] 1536 	mov	r4,#0x00
      0083FE 80 06            [24] 1537 	sjmp	00141$
      008400                       1538 00140$:
      008400 EB               [12] 1539 	mov	a,r3
      008401 2B               [12] 1540 	add	a,r3
      008402 FB               [12] 1541 	mov	r3,a
      008403 EC               [12] 1542 	mov	a,r4
      008404 33               [12] 1543 	rlc	a
      008405 FC               [12] 1544 	mov	r4,a
      008406                       1545 00141$:
      008406 D5 F0 F7         [24] 1546 	djnz	b,00140$
      008409 90 0A 1E         [24] 1547 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      00840C E0               [24] 1548 	movx	a,@dptr
      00840D 7A 00            [12] 1549 	mov	r2,#0x00
      00840F 52 03            [12] 1550 	anl	ar3,a
      008411 EA               [12] 1551 	mov	a,r2
      008412 52 04            [12] 1552 	anl	ar4,a
      008414 EB               [12] 1553 	mov	a,r3
      008415 4C               [12] 1554 	orl	a,r4
      008416 60 26            [24] 1555 	jz	00108$
                                   1556 ;	quantum/action_layer.c:546: if (ak820_keycode_at(i, position) != KC_TRANSPARENT) {
      008418 90 0C 57         [24] 1557 	mov	dptr,#_ak820_keycode_at_PARM_2
      00841B 12 51 E9         [24] 1558 	lcall	_ak820_outline_0061
      00841E 8D 82            [24] 1559 	mov	dpl, r5
      008420 C0 07            [24] 1560 	push	ar7
      008422 C0 06            [24] 1561 	push	ar6
      008424 C0 05            [24] 1562 	push	ar5
      008426 12 9F FC         [24] 1563 	lcall	_ak820_keycode_at
      008429 AB 82            [24] 1564 	mov	r3, dpl
      00842B AC 83            [24] 1565 	mov	r4, dph
      00842D D0 05            [24] 1566 	pop	ar5
      00842F D0 06            [24] 1567 	pop	ar6
      008431 D0 07            [24] 1568 	pop	ar7
      008433 BB 01 05         [24] 1569 	cjne	r3,#0x01,00143$
      008436 BC 00 02         [24] 1570 	cjne	r4,#0x00,00143$
      008439 80 03            [24] 1571 	sjmp	00108$
      00843B                       1572 00143$:
                                   1573 ;	quantum/action_layer.c:555: return i;
      00843B 8D 82            [24] 1574 	mov	dpl, r5
      00843D 22               [24] 1575 	ret
      00843E                       1576 00108$:
                                   1577 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      00843E 1D               [12] 1578 	dec	r5
      00843F 80 B1            [24] 1579 	sjmp	00107$
      008441                       1580 00105$:
                                   1581 ;	quantum/action_layer.c:560: return 0;
      008441 75 82 00         [24] 1582 	mov	dpl, #0x00
                                   1583 ;	quantum/action_layer.c:565: }
      008444 22               [24] 1584 	ret
                                   1585 ;------------------------------------------------------------
                                   1586 ;Allocation info for local variables in function 'layer_switch_get_layer'
                                   1587 ;------------------------------------------------------------
                                   1588 ;key           Allocated with name '_layer_switch_get_layer_PARM_1'
                                   1589 ;------------------------------------------------------------
                                   1590 ;	quantum/action_layer.c:567: uint8_t layer_switch_get_layer(keypos_t key) {
                                   1591 ;	-----------------------------------------
                                   1592 	.area CSEG    (CODE)
                                   1593 	.area CONST   (CODE)
                                   1594 	.area XINIT   (CODE)
      00CB7C                       1595 __xinit__default_layer_state:
      00CB7C 00                    1596 	.db #0x00	; 0
      00CB7D                       1597 __xinit__layer_state:
      00CB7D 00                    1598 	.db #0x00	; 0
                                   1599 	.area CABS    (ABS,CODE)
                                   1600 
                                   1601 ; Experimental exact instruction outlining.
                                   1602 	.globl _ak820_outline_0005
                                   1603 	.globl _ak820_outline_0054
                                   1604 	.globl _ak820_outline_0061
                                   1605 	.globl _ak820_outline_0062
                                   1606 	.globl _ak820_outline_0064
                                   1607 	.globl _ak820_outline_0068
                                   1608 	.globl _ak820_outline_0079
                                   1609 	.globl _ak820_outline_0108
                                   1610 	.globl _ak820_outline_0109
                                   1611 	.globl _ak820_outline_0120
                                   1612 	.globl _ak820_outline_0126
                                   1613 	.globl _ak820_outline_0132
                                   1614 	.globl _ak820_outline_0135
                                   1615 	.globl _ak820_outline_0136
                                   1616 	.globl _ak820_outline_0142
                                   1617 	.globl _ak820_outline_0150
                                   1618 	.globl _ak820_outline_0159
                                   1619 	.globl _ak820_outline_0164
                                   1620 	.globl _ak820_outline_0172
                                   1621 	.globl _ak820_outline_0178
                                   1622 	.globl _ak820_outline_0191
                                   1623 
                                   1624 	.area CSEG (CODE)
                                   1625 ; function ak820_outline_0142
      008445                       1626 _ak820_outline_0142:
      008445 E0               [24] 1627 	movx	a,@dptr
      008446 42 07            [12] 1628 	orl	ar7,a
      008448 8F 82            [24] 1629 	mov	dpl,r7
      00844A 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0164
      00844B                       1634 _ak820_outline_0164:
      00844B F5 83            [12] 1635 	mov	dph,a
      00844D E4               [12] 1636 	clr	a
      00844E F0               [24] 1637 	movx	@dptr,a
      00844F 0F               [12] 1638 	inc	r7
      008450 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0178
      008451                       1643 _ak820_outline_0178:
      008451 90 0A 35         [24] 1644 	mov	dptr,#_ak820_macro_change_PARM_2
      008454 EF               [12] 1645 	mov	a,r7
      008455 F0               [24] 1646 	movx	@dptr,a
      008456 90 0A 36         [24] 1647 	mov	dptr,#_ak820_macro_change_PARM_3
      008459 22               [24] 1648 	ret
