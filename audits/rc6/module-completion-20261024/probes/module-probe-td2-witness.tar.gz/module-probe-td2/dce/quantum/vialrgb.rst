                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004E                        535 _fast_set_leds_sloc0_1_0:
      00004E                        536 	.ds 2
      000050                        537 _fast_set_leds_sloc1_1_0:
      000050                        538 	.ds 2
      000052                        539 _vialrgb_get_value_sloc0_1_0:
      000052                        540 	.ds 2
      000054                        541 _vialrgb_get_value_sloc1_1_0:
      000054                        542 	.ds 2
      000056                        543 _vialrgb_set_value_sloc0_1_0:
      000056                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000D5F                        569 _g_direct_mode_colors::
      000D5F                        570 	.ds 246
      000E55                        571 _get_supported_PARM_2:
      000E55                        572 	.ds 1
      000E56                        573 _get_supported_args_10000_255:
      000E56                        574 	.ds 2
      000E58                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000E58                        576 	.ds 2
      000E5A                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000E5A                        578 	.ds 2
      000E5C                        579 _set_mode_mode_10000_275:
      000E5C                        580 	.ds 2
      000E5E                        581 _get_matrix_pos_for_led_PARM_2:
      000E5E                        582 	.ds 2
      000E60                        583 _get_matrix_pos_for_led_led_10000_280:
      000E60                        584 	.ds 2
      000E62                        585 _fast_set_leds_PARM_2:
      000E62                        586 	.ds 1
      000E63                        587 _fast_set_leds_args_10000_282:
      000E63                        588 	.ds 2
      000E65                        589 _fast_set_leds_first_index_10001_285:
      000E65                        590 	.ds 2
      000E67                        591 _fast_set_leds_num_leds_10001_285:
      000E67                        592 	.ds 1
      000E68                        593 _vialrgb_get_value_PARM_2:
      000E68                        594 	.ds 1
      000E69                        595 _vialrgb_get_value_data_10000_291:
      000E69                        596 	.ds 3
      000E6C                        597 _vialrgb_set_value_PARM_2:
      000E6C                        598 	.ds 1
      000E6D                        599 _vialrgb_set_value_data_10000_302:
      000E6D                        600 	.ds 3
      000E70                        601 _vialrgb_save_PARM_2:
      000E70                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00BD05                        654 _get_supported:
      00BD05 12 38 75         [24]  655 	lcall	_ak820_outline_0108
      00BD08 90 0E 56         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00BD0B 12 38 7A         [24]  657 	lcall	_ak820_outline_0109
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BD0E 90 0E 56         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00BD11 12 37 E7         [24]  660 	lcall	_ak820_outline_0005
      00BD14 E0               [24]  661 	movx	a,@dptr
      00BD15 FD               [12]  662 	mov	r5,a
      00BD16 7C 00            [12]  663 	mov	r4,#0x00
      00BD18 12 38 7F         [24]  664 	lcall	_ak820_outline_0120
      00BD1B A3               [24]  665 	inc	dptr
      00BD1C E0               [24]  666 	movx	a,@dptr
      00BD1D FA               [12]  667 	mov	r2,a
      00BD1E E4               [12]  668 	clr	a
      00BD1F 12 43 5A         [24]  669 	lcall	_ak820_outline_0143
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00BD22 90 0E 55         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00BD25 E0               [24]  672 	movx	a,@dptr
      00BD26 FB               [12]  673 	mov	r3,a
      00BD27 7A 00            [12]  674 	mov	r2,#0x00
      00BD29                        675 00107$:
      00BD29 C3               [12]  676 	clr	c
      00BD2A EA               [12]  677 	mov	a,r2
      00BD2B 9B               [12]  678 	subb	a,r3
      00BD2C 50 0A            [24]  679 	jnc	00101$
      00BD2E EA               [12]  680 	mov	a,r2
      00BD2F 12 38 24         [24]  681 	lcall	_ak820_outline_0023
      00BD32 74 FF            [12]  682 	mov	a,#0xff
      00BD34 F0               [24]  683 	movx	@dptr,a
      00BD35 0A               [12]  684 	inc	r2
      00BD36 80 F1            [24]  685 	sjmp	00107$
      00BD38                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BD38 8D 06            [24]  688 	mov	ar6,r5
      00BD3A 8C 07            [24]  689 	mov	ar7,r4
      00BD3C 8B 05            [24]  690 	mov	ar5,r3
      00BD3E 90 0E 56         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00BD41 12 38 84         [24]  692 	lcall	_ak820_outline_0125
      00BD44 7A 00            [12]  693 	mov	r2,#0x00
      00BD46                        694 00110$:
      00BD46 BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00BD49                        696 00159$:
      00BD49 50 46            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00BD4B EA               [12]  699 	mov	a,r2
      00BD4C 75 F0 02         [24]  700 	mov	b,#0x02
      00BD4F A4               [48]  701 	mul	ab
      00BD50 24 AC            [12]  702 	add	a, #_supported_modes
      00BD52 F5 82            [12]  703 	mov	dpl,a
      00BD54 74 C9            [12]  704 	mov	a,#(_supported_modes >> 8)
      00BD56 12 60 47         [24]  705 	lcall	_ak820_outline_0110
      00BD59 F8               [12]  706 	mov	r0,a
      00BD5A 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00BD5C C3               [12]  709 	clr	c
      00BD5D EE               [12]  710 	mov	a,r6
      00BD5E 98               [12]  711 	subb	a,r0
      00BD5F EF               [12]  712 	mov	a,r7
      00BD60 99               [12]  713 	subb	a,r1
      00BD61 50 2B            [24]  714 	jnc	00111$
                                    715 ;	free result
      00BD63 BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00BD66                        717 00162$:
      00BD66 40 26            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00BD68 C0 06            [24]  720 	push	ar6
      00BD6A C0 07            [24]  721 	push	ar7
      00BD6C 88 07            [24]  722 	mov	ar7,r0
      00BD6E 12 33 FC         [24]  723 	lcall	_ak820_outline_0123
      00BD71 EF               [12]  724 	mov	a,r7
      00BD72 F0               [24]  725 	movx	@dptr,a
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00BD73 12 33 FC         [24]  727 	lcall	_ak820_outline_0123
      00BD76 A3               [24]  728 	inc	dptr
      00BD77 89 00            [24]  729 	mov	ar0,r1
      00BD79 E8               [12]  730 	mov	a,r0
      00BD7A F0               [24]  731 	movx	@dptr,a
                                    732 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00BD7B 1D               [12]  733 	dec	r5
      00BD7C 1D               [12]  734 	dec	r5
                                    735 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00BD7D 74 02            [12]  736 	mov	a,#0x02
      00BD7F 2B               [12]  737 	add	a, r3
      00BD80 FB               [12]  738 	mov	r3,a
      00BD81 E4               [12]  739 	clr	a
      00BD82 3C               [12]  740 	addc	a, r4
      00BD83 FC               [12]  741 	mov	r4,a
      00BD84 90 0E 56         [24]  742 	mov	dptr,#_get_supported_args_10000_255
      00BD87 12 38 63         [24]  743 	lcall	_ak820_outline_0086
                                    744 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BD8A D0 07            [24]  745 	pop	ar7
      00BD8C D0 06            [24]  746 	pop	ar6
                                    747 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00BD8E                        748 00111$:
                                    749 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BD8E 0A               [12]  750 	inc	r2
      00BD8F 80 B5            [24]  751 	sjmp	00110$
      00BD91                        752 00127$:
      00BD91 90 0E 56         [24]  753 	mov	dptr,#_get_supported_args_10000_255
      00BD94 12 38 63         [24]  754 	lcall	_ak820_outline_0086
                                    755 ;	quantum/vialrgb.c:55: }
      00BD97 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    759 ;------------------------------------------------------------
                                    760 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    761 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    762 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    763 ;------------------------------------------------------------
                                    764 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function qmk_id_to_vialrgb_id
                                    767 ;	-----------------------------------------
      00BD98                        768 _qmk_id_to_vialrgb_id:
      00BD98 12 38 75         [24]  769 	lcall	_ak820_outline_0108
      00BD9B 90 0E 58         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00BD9E 12 38 7A         [24]  771 	lcall	_ak820_outline_0109
                                    772 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BDA1 90 0E 58         [24]  773 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00BDA4 12 38 34         [24]  774 	lcall	_ak820_outline_0054
      00BDA7 7D 00            [12]  775 	mov	r5,#0x00
      00BDA9                        776 00105$:
      00BDA9 BD 07 00         [24]  777 	cjne	r5,#0x07,00130$
      00BDAC                        778 00130$:
      00BDAC 50 19            [24]  779 	jnc	00103$
                                    780 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00BDAE 12 C1 CB         [24]  781 	lcall	_ak820_outline_0050
      00BDB1 A3               [24]  782 	inc	dptr
      00BDB2 E4               [12]  783 	clr	a
      00BDB3 93               [24]  784 	movc	a,@a+dptr
                                    785 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00BDB4 7A 00            [12]  786 	mov	r2,#0x00
      00BDB6 B5 06 0B         [24]  787 	cjne	a,ar6,00106$
      00BDB9 EA               [12]  788 	mov	a,r2
      00BDBA B5 07 07         [24]  789 	cjne	a,ar7,00106$
                                    790 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00BDBD 12 33 FC         [24]  791 	lcall	_ak820_outline_0123
      00BDC0 12 C1 F7         [24]  792 	lcall	_ak820_outline_0145
      00BDC3 22               [24]  793 	ret
      00BDC4                        794 00106$:
                                    795 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BDC4 0D               [12]  796 	inc	r5
      00BDC5 80 E2            [24]  797 	sjmp	00105$
      00BDC7                        798 00103$:
                                    799 ;	quantum/vialrgb.c:63: return 0;
      00BDC7 90 00 00         [24]  800 	mov	dptr,#0x0000
                                    801 ;	quantum/vialrgb.c:64: }
      00BDCA 22               [24]  802 	ret
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    805 ;------------------------------------------------------------
                                    806 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    807 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    808 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    809 ;------------------------------------------------------------
                                    810 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    811 ;	-----------------------------------------
                                    812 ;	 function vialrgb_id_to_qmk_id
                                    813 ;	-----------------------------------------
      00BDCB                        814 _vialrgb_id_to_qmk_id:
      00BDCB 12 38 75         [24]  815 	lcall	_ak820_outline_0108
      00BDCE 90 0E 5A         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00BDD1 12 38 7A         [24]  817 	lcall	_ak820_outline_0109
                                    818 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BDD4 90 0E 5A         [24]  819 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00BDD7 12 38 34         [24]  820 	lcall	_ak820_outline_0054
      00BDDA 7D 00            [12]  821 	mov	r5,#0x00
      00BDDC                        822 00105$:
      00BDDC BD 07 00         [24]  823 	cjne	r5,#0x07,00130$
      00BDDF                        824 00130$:
      00BDDF 50 19            [24]  825 	jnc	00103$
                                    826 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00BDE1 12 C1 CB         [24]  827 	lcall	_ak820_outline_0050
      00BDE4 E4               [12]  828 	clr	a
      00BDE5 93               [24]  829 	movc	a,@a+dptr
                                    830 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00BDE6 7A 00            [12]  831 	mov	r2,#0x00
      00BDE8 B5 06 0C         [24]  832 	cjne	a,ar6,00106$
      00BDEB EA               [12]  833 	mov	a,r2
      00BDEC B5 07 08         [24]  834 	cjne	a,ar7,00106$
                                    835 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00BDEF 12 33 FC         [24]  836 	lcall	_ak820_outline_0123
      00BDF2 A3               [24]  837 	inc	dptr
      00BDF3 12 C1 F7         [24]  838 	lcall	_ak820_outline_0145
      00BDF6 22               [24]  839 	ret
      00BDF7                        840 00106$:
                                    841 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00BDF7 0D               [12]  842 	inc	r5
      00BDF8 80 E2            [24]  843 	sjmp	00105$
      00BDFA                        844 00103$:
                                    845 ;	quantum/vialrgb.c:72: return 0;
      00BDFA 90 00 00         [24]  846 	mov	dptr,#0x0000
                                    847 ;	quantum/vialrgb.c:73: }
      00BDFD 22               [24]  848 	ret
                                    849 ;------------------------------------------------------------
                                    850 ;Allocation info for local variables in function 'get_mode'
                                    851 ;------------------------------------------------------------
                                    852 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    853 ;	-----------------------------------------
                                    854 ;	 function get_mode
                                    855 ;	-----------------------------------------
      00BDFE                        856 _get_mode:
                                    857 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00BDFE 12 5E 4C         [24]  858 	lcall	_rgb_matrix_is_enabled
      00BE01 E5 82            [12]  859 	mov	a, dpl
      00BE03 70 04            [24]  860 	jnz	00102$
                                    861 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00BE05 90 00 00         [24]  862 	mov	dptr,#0x0000
      00BE08 22               [24]  863 	ret
      00BE09                        864 00102$:
                                    865 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00BE09 12 5E 52         [24]  866 	lcall	_rgb_matrix_get_mode
      00BE0C 7E 00            [12]  867 	mov	r6,#0x00
      00BE0E 8E 83            [24]  868 	mov	dph, r6
                                    869 ;	quantum/vialrgb.c:80: }
      00BE10 A1 98            [12]  870 	ajmp	_qmk_id_to_vialrgb_id
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'set_mode'
                                    873 ;------------------------------------------------------------
                                    874 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    875 ;------------------------------------------------------------
                                    876 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    877 ;	-----------------------------------------
                                    878 ;	 function set_mode
                                    879 ;	-----------------------------------------
      00BE12                        880 _set_mode:
      00BE12 12 38 75         [24]  881 	lcall	_ak820_outline_0108
      00BE15 90 0E 5C         [24]  882 	mov	dptr,#_set_mode_mode_10000_275
      00BE18 12 38 7A         [24]  883 	lcall	_ak820_outline_0109
                                    884 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00BE1B 90 0E 5C         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00BE1E 12 38 34         [24]  886 	lcall	_ak820_outline_0054
      00BE21 90 0E 5C         [24]  887 	mov	dptr,#_set_mode_mode_10000_275
      00BE24 12 76 96         [24]  888 	lcall	_ak820_outline_0041
      00BE27 70 03            [24]  889 	jnz	00102$
                                    890 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00BE29 02 5E 9D         [24]  891 	ljmp	_rgb_matrix_disable_noeeprom
      00BE2C                        892 00102$:
                                    893 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00BE2C C0 07            [24]  894 	push	ar7
      00BE2E C0 06            [24]  895 	push	ar6
      00BE30 12 5E 8D         [24]  896 	lcall	_rgb_matrix_enable_noeeprom
      00BE33 D0 06            [24]  897 	pop	ar6
      00BE35 D0 07            [24]  898 	pop	ar7
                                    899 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00BE37 12 38 7F         [24]  900 	lcall	_ak820_outline_0120
      00BE3A B1 CB            [12]  901 	acall	_vialrgb_id_to_qmk_id
                                    902 ;	quantum/vialrgb.c:90: }
      00BE3C 02 5E A5         [24]  903 	ljmp	_rgb_matrix_mode_noeeprom
                                    904 ;------------------------------------------------------------
                                    905 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    906 ;------------------------------------------------------------
                                    907 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    908 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    909 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    910 ;------------------------------------------------------------
                                    911 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    912 ;	-----------------------------------------
                                    913 ;	 function get_matrix_pos_for_led
                                    914 ;	-----------------------------------------
      00BE3F                        915 _get_matrix_pos_for_led:
      00BE3F 12 38 75         [24]  916 	lcall	_ak820_outline_0108
      00BE42 90 0E 60         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00BE45 12 38 7A         [24]  918 	lcall	_ak820_outline_0109
                                    919 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00BE48 90 0E 60         [24]  920 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00BE4B 12 38 34         [24]  921 	lcall	_ak820_outline_0054
      00BE4E EE               [12]  922 	mov	a,r6
      00BE4F 24 B3            [12]  923 	add	a, #_ak820_rgb_slots
      00BE51 F5 82            [12]  924 	mov	dpl,a
      00BE53 EF               [12]  925 	mov	a,r7
      00BE54 34 C3            [12]  926 	addc	a, #(_ak820_rgb_slots >> 8)
      00BE56 F5 83            [12]  927 	mov	dph,a
      00BE58 E4               [12]  928 	clr	a
      00BE59 93               [24]  929 	movc	a,@a+dptr
      00BE5A FF               [12]  930 	mov	r7,a
                                    931 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00BE5B 90 0E 5E         [24]  932 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BE5E 12 38 5D         [24]  933 	lcall	_ak820_outline_0080
      00BE61 EF               [12]  934 	mov	a,r7
      00BE62 12 60 7D         [24]  935 	lcall	_ak820_outline_0189
      00BE65 12 89 B4         [24]  936 	lcall	_ak820_outline_0124
                                    937 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00BE68 12 38 94         [24]  938 	lcall	_ak820_outline_0136
      00BE6B A3               [24]  939 	inc	dptr
      00BE6C 53 07 07         [24]  940 	anl	ar7,#0x07
      00BE6F EF               [12]  941 	mov	a,r7
      00BE70 F0               [24]  942 	movx	@dptr,a
                                    943 ;	quantum/vialrgb.c:110: }
      00BE71 22               [24]  944 	ret
                                    945 ;------------------------------------------------------------
                                    946 ;Allocation info for local variables in function 'fast_set_leds'
                                    947 ;------------------------------------------------------------
                                    948 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    949 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    950 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    951 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    952 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    953 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    954 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    955 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    956 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function fast_set_leds
                                    961 ;	-----------------------------------------
      00BE72                        962 _fast_set_leds:
      00BE72 12 38 75         [24]  963 	lcall	_ak820_outline_0108
      00BE75 90 0E 63         [24]  964 	mov	dptr,#_fast_set_leds_args_10000_282
      00BE78 12 38 7A         [24]  965 	lcall	_ak820_outline_0109
                                    966 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00BE7B 90 0E 62         [24]  967 	mov	dptr,#_fast_set_leds_PARM_2
      00BE7E E0               [24]  968 	movx	a,@dptr
      00BE7F FF               [12]  969 	mov	r7,a
      00BE80 BF 03 00         [24]  970 	cjne	r7,#0x03,00159$
      00BE83                        971 00159$:
      00BE83 50 01            [24]  972 	jnc	00102$
      00BE85 22               [24]  973 	ret
      00BE86                        974 00102$:
                                    975 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BE86 90 0E 63         [24]  976 	mov	dptr,#_fast_set_leds_args_10000_282
      00BE89 12 38 5D         [24]  977 	lcall	_ak820_outline_0080
      00BE8C 12 51 F6         [24]  978 	lcall	_ak820_outline_0077
      00BE8F 7B 00            [12]  979 	mov	r3,#0x00
      00BE91 12 38 94         [24]  980 	lcall	_ak820_outline_0136
      00BE94 A3               [24]  981 	inc	dptr
      00BE95 E0               [24]  982 	movx	a,@dptr
      00BE96 FA               [12]  983 	mov	r2,a
      00BE97 79 00            [12]  984 	mov	r1,#0x00
      00BE99 90 0E 65         [24]  985 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BE9C E9               [12]  986 	mov	a,r1
      00BE9D 4C               [12]  987 	orl	a,r4
      00BE9E F0               [24]  988 	movx	@dptr,a
      00BE9F EA               [12]  989 	mov	a,r2
      00BEA0 4B               [12]  990 	orl	a,r3
      00BEA1 A3               [24]  991 	inc	dptr
      00BEA2 F0               [24]  992 	movx	@dptr,a
                                    993 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00BEA3 12 38 94         [24]  994 	lcall	_ak820_outline_0136
      00BEA6 A3               [24]  995 	inc	dptr
      00BEA7 A3               [24]  996 	inc	dptr
      00BEA8 E0               [24]  997 	movx	a,@dptr
      00BEA9 90 0E 67         [24]  998 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BEAC F0               [24]  999 	movx	@dptr,a
                                   1000 ;	quantum/vialrgb.c:119: length -= 3;
      00BEAD EF               [12] 1001 	mov	a,r7
      00BEAE 24 FD            [12] 1002 	add	a,#0xfd
      00BEB0 90 0E 62         [24] 1003 	mov	dptr,#_fast_set_leds_PARM_2
      00BEB3 F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	quantum/vialrgb.c:120: args += 3;
      00BEB4 90 0E 63         [24] 1006 	mov	dptr,#_fast_set_leds_args_10000_282
      00BEB7 74 03            [12] 1007 	mov	a,#0x03
      00BEB9 2D               [12] 1008 	add	a, r5
      00BEBA F0               [24] 1009 	movx	@dptr,a
      00BEBB E4               [12] 1010 	clr	a
      00BEBC 3E               [12] 1011 	addc	a, r6
      00BEBD A3               [24] 1012 	inc	dptr
      00BEBE F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00BEBF 90 0E 67         [24] 1015 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BEC2 E0               [24] 1016 	movx	a,@dptr
      00BEC3 FF               [12] 1017 	mov	r7,a
      00BEC4 75 F0 03         [24] 1018 	mov	b,#0x03
      00BEC7 A4               [48] 1019 	mul	ab
      00BEC8 FE               [12] 1020 	mov	r6,a
      00BEC9 AD F0            [24] 1021 	mov	r5,b
      00BECB 90 0E 62         [24] 1022 	mov	dptr,#_fast_set_leds_PARM_2
      00BECE E0               [24] 1023 	movx	a,@dptr
      00BECF FB               [12] 1024 	mov	r3,a
      00BED0 7C 00            [12] 1025 	mov	r4,#0x00
      00BED2 C3               [12] 1026 	clr	c
      00BED3 EB               [12] 1027 	mov	a,r3
      00BED4 9E               [12] 1028 	subb	a,r6
      00BED5 EC               [12] 1029 	mov	a,r4
      00BED6 9D               [12] 1030 	subb	a,r5
      00BED7 40 13            [24] 1031 	jc	00103$
                                   1032 ;	free result
      00BED9 90 0E 65         [24] 1033 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BEDC 12 38 5D         [24] 1034 	lcall	_ak820_outline_0080
      00BEDF 8D 03            [24] 1035 	mov	ar3,r5
      00BEE1 8E 04            [24] 1036 	mov	ar4,r6
      00BEE3 C3               [12] 1037 	clr	c
      00BEE4 EB               [12] 1038 	mov	a,r3
      00BEE5 94 52            [12] 1039 	subb	a,#0x52
      00BEE7 EC               [12] 1040 	mov	a,r4
      00BEE8 94 00            [12] 1041 	subb	a,#0x00
      00BEEA 40 01            [24] 1042 	jc	00104$
      00BEEC                       1043 00103$:
      00BEEC 22               [24] 1044 	ret
      00BEED                       1045 00104$:
                                   1046 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00BEED 74 52            [12] 1047 	mov	a,#0x52
      00BEEF C3               [12] 1048 	clr	c
      00BEF0 9D               [12] 1049 	subb	a,r5
      00BEF1 FB               [12] 1050 	mov	r3,a
      00BEF2 E4               [12] 1051 	clr	a
      00BEF3 9E               [12] 1052 	subb	a,r6
      00BEF4 FC               [12] 1053 	mov	r4,a
      00BEF5 7A 00            [12] 1054 	mov	r2,#0x00
      00BEF7 C3               [12] 1055 	clr	c
      00BEF8 EB               [12] 1056 	mov	a,r3
      00BEF9 9F               [12] 1057 	subb	a,r7
      00BEFA EC               [12] 1058 	mov	a,r4
      00BEFB 9A               [12] 1059 	subb	a,r2
      00BEFC 50 08            [24] 1060 	jnc	00127$
                                   1061 ;	free result
      00BEFE 90 0E 67         [24] 1062 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BF01 74 52            [12] 1063 	mov	a,#0x52
      00BF03 C3               [12] 1064 	clr	c
      00BF04 9D               [12] 1065 	subb	a,r5
      00BF05 F0               [24] 1066 	movx	@dptr,a
                                   1067 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BF06                       1068 00127$:
      00BF06 90 0E 67         [24] 1069 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BF09 E0               [24] 1070 	movx	a,@dptr
      00BF0A FF               [12] 1071 	mov	r7,a
      00BF0B 90 0E 65         [24] 1072 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BF0E 12 38 5D         [24] 1073 	lcall	_ak820_outline_0080
      00BF11 7C 00            [12] 1074 	mov	r4,#0x00
      00BF13                       1075 00110$:
      00BF13 C3               [12] 1076 	clr	c
      00BF14 EC               [12] 1077 	mov	a,r4
      00BF15 9F               [12] 1078 	subb	a,r7
      00BF16 40 01            [24] 1079 	jc	00164$
      00BF18 22               [24] 1080 	ret
      00BF19                       1081 00164$:
                                   1082 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00BF19 C0 07            [24] 1083 	push	ar7
      00BF1B 90 0E 7F         [24] 1084 	mov	dptr,#__mulint_PARM_2
      00BF1E 12 43 70         [24] 1085 	lcall	_ak820_outline_0163
      00BF21 90 00 03         [24] 1086 	mov	dptr,#0x0003
      00BF24 C0 07            [24] 1087 	push	ar7
      00BF26 C0 06            [24] 1088 	push	ar6
      00BF28 C0 05            [24] 1089 	push	ar5
      00BF2A C0 04            [24] 1090 	push	ar4
      00BF2C 12 C3 63         [24] 1091 	lcall	__mulint
      00BF2F AA 82            [24] 1092 	mov	r2, dpl
      00BF31 AB 83            [24] 1093 	mov	r3, dph
      00BF33 D0 04            [24] 1094 	pop	ar4
      00BF35 D0 05            [24] 1095 	pop	ar5
      00BF37 D0 06            [24] 1096 	pop	ar6
      00BF39 D0 07            [24] 1097 	pop	ar7
      00BF3B 0D               [12] 1098 	inc	r5
      00BF3C BD 00 01         [24] 1099 	cjne	r5,#0x00,00165$
      00BF3F 0E               [12] 1100 	inc	r6
      00BF40                       1101 00165$:
      00BF40 EA               [12] 1102 	mov	a,r2
      00BF41 24 5F            [12] 1103 	add	a, #_g_direct_mode_colors
      00BF43 FA               [12] 1104 	mov	r2,a
      00BF44 EB               [12] 1105 	mov	a,r3
      00BF45 34 0D            [12] 1106 	addc	a, #(_g_direct_mode_colors >> 8)
      00BF47 FB               [12] 1107 	mov	r3,a
                                   1108 ;	quantum/vialrgb.c:128: color->h = *args++;
      00BF48 8A 4E            [24] 1109 	mov	_fast_set_leds_sloc0_1_0,r2
      00BF4A 8B 4F            [24] 1110 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00BF4C 12 C1 DD         [24] 1111 	lcall	_ak820_outline_0085
      00BF4F F8               [12] 1112 	mov	r0,a
      00BF50 12 C1 EB         [24] 1113 	lcall	_ak820_outline_0107
      00BF53 85 4E 82         [24] 1114 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BF56 85 4F 83         [24] 1115 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BF59 E8               [12] 1116 	mov	a,r0
      00BF5A F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/vialrgb.c:129: color->s = *args++;
      00BF5B 74 01            [12] 1119 	mov	a,#0x01
      00BF5D 2A               [12] 1120 	add	a, r2
      00BF5E F5 4E            [12] 1121 	mov	_fast_set_leds_sloc0_1_0,a
      00BF60 E4               [12] 1122 	clr	a
      00BF61 3B               [12] 1123 	addc	a, r3
      00BF62 F5 4F            [12] 1124 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00BF64 90 0E 63         [24] 1125 	mov	dptr,#_fast_set_leds_args_10000_282
      00BF67 E0               [24] 1126 	movx	a,@dptr
      00BF68 F8               [12] 1127 	mov	r0,a
      00BF69 A3               [24] 1128 	inc	dptr
      00BF6A E0               [24] 1129 	movx	a,@dptr
      00BF6B FF               [12] 1130 	mov	r7,a
      00BF6C 88 82            [24] 1131 	mov	dpl,r0
      00BF6E 8F 83            [24] 1132 	mov	dph,r7
      00BF70 E0               [24] 1133 	movx	a,@dptr
      00BF71 F9               [12] 1134 	mov	r1,a
      00BF72 90 0E 63         [24] 1135 	mov	dptr,#_fast_set_leds_args_10000_282
      00BF75 74 01            [12] 1136 	mov	a,#0x01
      00BF77 28               [12] 1137 	add	a, r0
      00BF78 F0               [24] 1138 	movx	@dptr,a
      00BF79 E4               [12] 1139 	clr	a
      00BF7A 3F               [12] 1140 	addc	a, r7
      00BF7B A3               [24] 1141 	inc	dptr
      00BF7C F0               [24] 1142 	movx	@dptr,a
      00BF7D 85 4E 82         [24] 1143 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BF80 85 4F 83         [24] 1144 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BF83 E9               [12] 1145 	mov	a,r1
      00BF84 F0               [24] 1146 	movx	@dptr,a
                                   1147 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00BF85 12 C1 DD         [24] 1148 	lcall	_ak820_outline_0085
      00BF88 F5 4E            [12] 1149 	mov	_fast_set_leds_sloc0_1_0,a
      00BF8A 12 C1 EB         [24] 1150 	lcall	_ak820_outline_0107
                                   1151 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00BF8D 74 02            [12] 1152 	mov	a,#0x02
      00BF8F 2A               [12] 1153 	add	a, r2
      00BF90 F5 50            [12] 1154 	mov	_fast_set_leds_sloc1_1_0,a
      00BF92 E4               [12] 1155 	clr	a
      00BF93 3B               [12] 1156 	addc	a, r3
      00BF94 F5 51            [12] 1157 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00BF96 C3               [12] 1158 	clr	c
      00BF97 74 A0            [12] 1159 	mov	a,#0xa0
      00BF99 95 4E            [12] 1160 	subb	a,_fast_set_leds_sloc0_1_0
      00BF9B D0 07            [24] 1161 	pop	ar7
      00BF9D 50 04            [24] 1162 	jnc	00114$
                                   1163 ;	free result
      00BF9F 7B A0            [12] 1164 	mov	r3,#0xa0
      00BFA1 80 04            [24] 1165 	sjmp	00115$
      00BFA3                       1166 00114$:
      00BFA3 AA 4E            [24] 1167 	mov	r2,_fast_set_leds_sloc0_1_0
      00BFA5 8A 03            [24] 1168 	mov	ar3,r2
      00BFA7                       1169 00115$:
      00BFA7 85 50 82         [24] 1170 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BFAA 85 51 83         [24] 1171 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BFAD EB               [12] 1172 	mov	a,r3
      00BFAE F0               [24] 1173 	movx	@dptr,a
                                   1174 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BFAF 0C               [12] 1175 	inc	r4
                                   1176 ;	quantum/vialrgb.c:133: }
      00BFB0 E1 13            [24] 1177 	ajmp	00110$
                                   1178 ;------------------------------------------------------------
                                   1179 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1180 ;------------------------------------------------------------
                                   1181 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1182 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1183 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1184 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1185 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1186 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1187 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1188 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function vialrgb_get_value
                                   1193 ;	-----------------------------------------
      00BFB2                       1194 _vialrgb_get_value:
      00BFB2 12 43 06         [24] 1195 	lcall	_ak820_outline_0038
      00BFB5 90 0E 69         [24] 1196 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BFB8 12 38 1C         [24] 1197 	lcall	_ak820_outline_0019
                                   1198 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BFBB 90 0E 68         [24] 1199 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BFBE E0               [24] 1200 	movx	a,@dptr
      00BFBF FF               [12] 1201 	mov	r7,a
      00BFC0 BF 20 02         [24] 1202 	cjne	r7,#0x20,00162$
      00BFC3 80 01            [24] 1203 	sjmp	00102$
      00BFC5                       1204 00162$:
      00BFC5 22               [24] 1205 	ret
      00BFC6                       1206 00102$:
                                   1207 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BFC6 90 0E 69         [24] 1208 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BFC9 12 C1 B7         [24] 1209 	lcall	_ak820_outline_0049
                                   1210 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1211 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BFCC BA 40 02         [24] 1212 	cjne	r2,#0x40,00163$
      00BFCF 80 18            [24] 1213 	sjmp	00103$
      00BFD1                       1214 00163$:
      00BFD1 BA 41 02         [24] 1215 	cjne	r2,#0x41,00164$
      00BFD4 80 26            [24] 1216 	sjmp	00104$
      00BFD6                       1217 00164$:
      00BFD6 BA 42 03         [24] 1218 	cjne	r2,#0x42,00165$
      00BFD9 02 C0 8D         [24] 1219 	ljmp	00105$
      00BFDC                       1220 00165$:
      00BFDC BA 43 03         [24] 1221 	cjne	r2,#0x43,00166$
      00BFDF 02 C0 9A         [24] 1222 	ljmp	00106$
      00BFE2                       1223 00166$:
      00BFE2 BA 44 03         [24] 1224 	cjne	r2,#0x44,00167$
      00BFE5 02 C0 A6         [24] 1225 	ljmp	00107$
      00BFE8                       1226 00167$:
      00BFE8 22               [24] 1227 	ret
                                   1228 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BFE9                       1229 00103$:
                                   1230 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BFE9 12 33 FC         [24] 1231 	lcall	_ak820_outline_0123
      00BFEC 74 01            [12] 1232 	mov	a,#0x01
      00BFEE F0               [24] 1233 	movx	@dptr,a
                                   1234 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BFEF 12 C1 AF         [24] 1235 	lcall	_ak820_outline_0040
      00BFF2 E4               [12] 1236 	clr	a
      00BFF3 F0               [24] 1237 	movx	@dptr,a
                                   1238 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BFF4 12 C1 AF         [24] 1239 	lcall	_ak820_outline_0040
      00BFF7 A3               [24] 1240 	inc	dptr
      00BFF8 74 A0            [12] 1241 	mov	a,#0xa0
      00BFFA F0               [24] 1242 	movx	@dptr,a
                                   1243 ;	quantum/vialrgb.c:147: break;
      00BFFB 22               [24] 1244 	ret
                                   1245 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BFFC                       1246 00104$:
                                   1247 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BFFC C0 06            [24] 1248 	push	ar6
      00BFFE C0 05            [24] 1249 	push	ar5
      00C000 C0 04            [24] 1250 	push	ar4
      00C002 C0 03            [24] 1251 	push	ar3
      00C004 12 BD FE         [24] 1252 	lcall	_get_mode
      00C007 12 B6 32         [24] 1253 	lcall	_ak820_outline_0187
      00C00A D0 03            [24] 1254 	pop	ar3
      00C00C D0 04            [24] 1255 	pop	ar4
      00C00E D0 05            [24] 1256 	pop	ar5
      00C010 D0 06            [24] 1257 	pop	ar6
                                   1258 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00C012 89 00            [24] 1259 	mov	ar0,r1
      00C014 12 33 FC         [24] 1260 	lcall	_ak820_outline_0123
      00C017 E8               [12] 1261 	mov	a,r0
      00C018 F0               [24] 1262 	movx	@dptr,a
                                   1263 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00C019 12 C1 AF         [24] 1264 	lcall	_ak820_outline_0040
      00C01C 8A 01            [24] 1265 	mov	ar1,r2
      00C01E E9               [12] 1266 	mov	a,r1
      00C01F F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00C020 74 04            [12] 1269 	mov	a,#0x04
      00C022 12 98 83         [24] 1270 	lcall	_ak820_outline_0137
      00C025 C0 06            [24] 1271 	push	ar6
      00C027 C0 05            [24] 1272 	push	ar5
      00C029 C0 02            [24] 1273 	push	ar2
      00C02B C0 01            [24] 1274 	push	ar1
      00C02D 12 5E 6D         [24] 1275 	lcall	_rgb_matrix_get_speed
      00C030 A8 82            [24] 1276 	mov	r0, dpl
      00C032 D0 01            [24] 1277 	pop	ar1
      00C034 D0 02            [24] 1278 	pop	ar2
      00C036 D0 05            [24] 1279 	pop	ar5
      00C038 D0 06            [24] 1280 	pop	ar6
      00C03A 12 89 8D         [24] 1281 	lcall	_ak820_outline_0065
                                   1282 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00C03D 74 05            [12] 1283 	mov	a,#0x05
      00C03F 12 98 83         [24] 1284 	lcall	_ak820_outline_0137
      00C042 C0 06            [24] 1285 	push	ar6
      00C044 C0 05            [24] 1286 	push	ar5
      00C046 C0 02            [24] 1287 	push	ar2
      00C048 C0 01            [24] 1288 	push	ar1
      00C04A 12 5E 58         [24] 1289 	lcall	_rgb_matrix_get_hue
      00C04D A8 82            [24] 1290 	mov	r0, dpl
      00C04F D0 01            [24] 1291 	pop	ar1
      00C051 D0 02            [24] 1292 	pop	ar2
      00C053 D0 05            [24] 1293 	pop	ar5
      00C055 D0 06            [24] 1294 	pop	ar6
      00C057 12 89 8D         [24] 1295 	lcall	_ak820_outline_0065
                                   1296 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00C05A 74 06            [12] 1297 	mov	a,#0x06
      00C05C 12 98 83         [24] 1298 	lcall	_ak820_outline_0137
      00C05F C0 06            [24] 1299 	push	ar6
      00C061 C0 05            [24] 1300 	push	ar5
      00C063 C0 02            [24] 1301 	push	ar2
      00C065 C0 01            [24] 1302 	push	ar1
      00C067 12 5E 5F         [24] 1303 	lcall	_rgb_matrix_get_sat
      00C06A A8 82            [24] 1304 	mov	r0, dpl
      00C06C D0 01            [24] 1305 	pop	ar1
      00C06E D0 02            [24] 1306 	pop	ar2
      00C070 D0 05            [24] 1307 	pop	ar5
      00C072 D0 06            [24] 1308 	pop	ar6
      00C074 12 89 8D         [24] 1309 	lcall	_ak820_outline_0065
                                   1310 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00C077 74 07            [12] 1311 	mov	a,#0x07
      00C079 12 98 83         [24] 1312 	lcall	_ak820_outline_0137
      00C07C C0 02            [24] 1313 	push	ar2
      00C07E C0 01            [24] 1314 	push	ar1
      00C080 12 5E 66         [24] 1315 	lcall	_rgb_matrix_get_val
      00C083 A8 82            [24] 1316 	mov	r0, dpl
      00C085 D0 01            [24] 1317 	pop	ar1
      00C087 D0 02            [24] 1318 	pop	ar2
      00C089 12 89 8D         [24] 1319 	lcall	_ak820_outline_0065
                                   1320 ;	quantum/vialrgb.c:156: break;
      00C08C 22               [24] 1321 	ret
                                   1322 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00C08D                       1323 00105$:
                                   1324 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00C08D EF               [12] 1325 	mov	a,r7
      00C08E 24 FE            [12] 1326 	add	a,#0xfe
      00C090 90 0E 55         [24] 1327 	mov	dptr,#_get_supported_PARM_2
      00C093 F0               [24] 1328 	movx	@dptr,a
      00C094 12 33 FC         [24] 1329 	lcall	_ak820_outline_0123
                                   1330 ;	quantum/vialrgb.c:160: break;
      00C097 02 BD 05         [24] 1331 	ljmp	_get_supported
                                   1332 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00C09A                       1333 00106$:
                                   1334 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00C09A 12 33 FC         [24] 1335 	lcall	_ak820_outline_0123
      00C09D 74 52            [12] 1336 	mov	a,#0x52
      00C09F F0               [24] 1337 	movx	@dptr,a
                                   1338 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00C0A0 12 C1 AF         [24] 1339 	lcall	_ak820_outline_0040
      00C0A3 E4               [12] 1340 	clr	a
      00C0A4 F0               [24] 1341 	movx	@dptr,a
                                   1342 ;	quantum/vialrgb.c:166: break;
      00C0A5 22               [24] 1343 	ret
                                   1344 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00C0A6                       1345 00107$:
                                   1346 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00C0A6 12 33 FC         [24] 1347 	lcall	_ak820_outline_0123
      00C0A9 E0               [24] 1348 	movx	a,@dptr
      00C0AA FF               [12] 1349 	mov	r7,a
      00C0AB 7A 00            [12] 1350 	mov	r2,#0x00
      00C0AD 74 03            [12] 1351 	mov	a,#0x03
      00C0AF 2D               [12] 1352 	add	a, r5
      00C0B0 F8               [12] 1353 	mov	r0,a
      00C0B1 E4               [12] 1354 	clr	a
      00C0B2 3E               [12] 1355 	addc	a, r6
      00C0B3 F9               [12] 1356 	mov	r1,a
      00C0B4 C0 03            [24] 1357 	push	ar3
      00C0B6 C0 04            [24] 1358 	push	ar4
      00C0B8 12 38 A9         [24] 1359 	lcall	_ak820_outline_0158
      00C0BB E0               [24] 1360 	movx	a,@dptr
      00C0BC FB               [12] 1361 	mov	r3,a
      00C0BD E4               [12] 1362 	clr	a
      00C0BE 4F               [12] 1363 	orl	a,r7
      00C0BF F5 52            [12] 1364 	mov	_vialrgb_get_value_sloc0_1_0,a
      00C0C1 EB               [12] 1365 	mov	a,r3
      00C0C2 4A               [12] 1366 	orl	a,r2
      00C0C3 F5 53            [12] 1367 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1368 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00C0C5 AC 52            [24] 1369 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00C0C7 AF 53            [24] 1370 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00C0C9 C3               [12] 1371 	clr	c
      00C0CA EC               [12] 1372 	mov	a,r4
      00C0CB 94 52            [12] 1373 	subb	a,#0x52
      00C0CD EF               [12] 1374 	mov	a,r7
      00C0CE 94 00            [12] 1375 	subb	a,#0x00
      00C0D0 D0 04            [24] 1376 	pop	ar4
      00C0D2 D0 03            [24] 1377 	pop	ar3
      00C0D4 40 01            [24] 1378 	jc	00109$
      00C0D6 22               [24] 1379 	ret
      00C0D7                       1380 00109$:
                                   1381 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00C0D7 E5 52            [12] 1382 	mov	a,_vialrgb_get_value_sloc0_1_0
      00C0D9 25 52            [12] 1383 	add	a,_vialrgb_get_value_sloc0_1_0
      00C0DB FA               [12] 1384 	mov	r2,a
      00C0DC E5 53            [12] 1385 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00C0DE 33               [12] 1386 	rlc	a
      00C0DF FF               [12] 1387 	mov	r7,a
      00C0E0 EA               [12] 1388 	mov	a,r2
      00C0E1 24 6D            [12] 1389 	add	a, #_ak820_led_points
      00C0E3 F5 54            [12] 1390 	mov	_vialrgb_get_value_sloc1_1_0,a
      00C0E5 EF               [12] 1391 	mov	a,r7
      00C0E6 34 C6            [12] 1392 	addc	a, #(_ak820_led_points >> 8)
      00C0E8 F5 55            [12] 1393 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00C0EA 85 54 82         [24] 1394 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00C0ED 85 55 83         [24] 1395 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00C0F0 E4               [12] 1396 	clr	a
      00C0F1 93               [24] 1397 	movc	a,@a+dptr
      00C0F2 12 33 FC         [24] 1398 	lcall	_ak820_outline_0123
      00C0F5 F0               [24] 1399 	movx	@dptr,a
                                   1400 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00C0F6 85 54 82         [24] 1401 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00C0F9 85 55 83         [24] 1402 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00C0FC A3               [24] 1403 	inc	dptr
      00C0FD E4               [12] 1404 	clr	a
      00C0FE 93               [24] 1405 	movc	a,@a+dptr
      00C0FF 12 38 A9         [24] 1406 	lcall	_ak820_outline_0158
      00C102 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00C103 12 C1 AF         [24] 1409 	lcall	_ak820_outline_0040
      00C106 A3               [24] 1410 	inc	dptr
      00C107 74 04            [12] 1411 	mov	a,#0x04
      00C109 F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00C10A 90 0E 5E         [24] 1414 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00C10D 04               [12] 1415 	inc	a
      00C10E 2D               [12] 1416 	add	a, r5
      00C10F F0               [24] 1417 	movx	@dptr,a
      00C110 E4               [12] 1418 	clr	a
      00C111 3E               [12] 1419 	addc	a, r6
      00C112 A3               [24] 1420 	inc	dptr
      00C113 F0               [24] 1421 	movx	@dptr,a
      00C114 85 52 82         [24] 1422 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00C117 85 53 83         [24] 1423 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1424 ;	quantum/vialrgb.c:187: }
                                   1425 ;	quantum/vialrgb.c:188: }
      00C11A 02 BE 3F         [24] 1426 	ljmp	_get_matrix_pos_for_led
                                   1427 ;------------------------------------------------------------
                                   1428 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1429 ;------------------------------------------------------------
                                   1430 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1431 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1432 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1433 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1434 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1435 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1436 ;------------------------------------------------------------
                                   1437 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1438 ;	-----------------------------------------
                                   1439 ;	 function vialrgb_set_value
                                   1440 ;	-----------------------------------------
      00C11D                       1441 _vialrgb_set_value:
      00C11D 12 43 06         [24] 1442 	lcall	_ak820_outline_0038
      00C120 90 0E 6D         [24] 1443 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00C123 12 38 1C         [24] 1444 	lcall	_ak820_outline_0019
                                   1445 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00C126 90 0E 6C         [24] 1446 	mov	dptr,#_vialrgb_set_value_PARM_2
      00C129 E0               [24] 1447 	movx	a,@dptr
      00C12A FF               [12] 1448 	mov	r7,a
      00C12B BF 20 02         [24] 1449 	cjne	r7,#0x20,00129$
      00C12E 80 01            [24] 1450 	sjmp	00102$
      00C130                       1451 00129$:
      00C130 22               [24] 1452 	ret
      00C131                       1453 00102$:
                                   1454 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00C131 90 0E 6D         [24] 1455 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00C134 12 C1 B7         [24] 1456 	lcall	_ak820_outline_0049
                                   1457 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1458 ;	quantum/vialrgb.c:196: switch (cmd) {
      00C137 BA 41 02         [24] 1459 	cjne	r2,#0x41,00130$
      00C13A 80 06            [24] 1460 	sjmp	00103$
      00C13C                       1461 00130$:
      00C13C BA 42 02         [24] 1462 	cjne	r2,#0x42,00131$
      00C13F 80 5E            [24] 1463 	sjmp	00104$
      00C141                       1464 00131$:
      00C141 22               [24] 1465 	ret
                                   1466 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00C142                       1467 00103$:
                                   1468 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00C142 12 33 FC         [24] 1469 	lcall	_ak820_outline_0123
      00C145 E0               [24] 1470 	movx	a,@dptr
      00C146 FA               [12] 1471 	mov	r2,a
      00C147 12 C1 AF         [24] 1472 	lcall	_ak820_outline_0040
      00C14A E0               [24] 1473 	movx	a,@dptr
      00C14B F8               [12] 1474 	mov	r0,a
      00C14C 79 00            [12] 1475 	mov	r1,#0x00
      00C14E 88 57            [24] 1476 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00C150 89 56            [24] 1477 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00C152 8A 01            [24] 1478 	mov	ar1,r2
      00C154 7A 00            [12] 1479 	mov	r2,#0x00
      00C156 E5 57            [12] 1480 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00C158 42 02            [12] 1481 	orl	ar2,a
                                   1482 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00C15A 12 43 76         [24] 1483 	lcall	_ak820_outline_0171
      00C15D C0 06            [24] 1484 	push	ar6
      00C15F C0 05            [24] 1485 	push	ar5
      00C161 12 BE 12         [24] 1486 	lcall	_set_mode
      00C164 D0 05            [24] 1487 	pop	ar5
      00C166 D0 06            [24] 1488 	pop	ar6
                                   1489 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00C168 12 C1 AF         [24] 1490 	lcall	_ak820_outline_0040
      00C16B A3               [24] 1491 	inc	dptr
      00C16C E0               [24] 1492 	movx	a,@dptr
      00C16D F5 82            [12] 1493 	mov	dpl,a
      00C16F C0 06            [24] 1494 	push	ar6
      00C171 C0 05            [24] 1495 	push	ar5
      00C173 12 5F 35         [24] 1496 	lcall	_rgb_matrix_set_speed_noeeprom
      00C176 D0 05            [24] 1497 	pop	ar5
      00C178 D0 06            [24] 1498 	pop	ar6
                                   1499 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00C17A 12 C1 AF         [24] 1500 	lcall	_ak820_outline_0040
      00C17D A3               [24] 1501 	inc	dptr
      00C17E A3               [24] 1502 	inc	dptr
      00C17F E0               [24] 1503 	movx	a,@dptr
      00C180 F9               [12] 1504 	mov	r1,a
      00C181 7A 00            [12] 1505 	mov	r2,#0x00
      00C183 74 06            [12] 1506 	mov	a,#0x06
      00C185 12 C2 01         [24] 1507 	lcall	_ak820_outline_0173
      00C188 F8               [12] 1508 	mov	r0,a
      00C189 74 07            [12] 1509 	mov	a,#0x07
      00C18B 12 C2 01         [24] 1510 	lcall	_ak820_outline_0173
      00C18E FE               [12] 1511 	mov	r6,a
      00C18F 90 07 E0         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00C192 E8               [12] 1513 	mov	a,r0
      00C193 F0               [24] 1514 	movx	@dptr,a
      00C194 90 07 E1         [24] 1515 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00C197 EE               [12] 1516 	mov	a,r6
      00C198 F0               [24] 1517 	movx	@dptr,a
      00C199 12 43 76         [24] 1518 	lcall	_ak820_outline_0171
                                   1519 ;	quantum/vialrgb.c:202: break;
                                   1520 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00C19C 02 5F 06         [24] 1521 	ljmp	_rgb_matrix_sethsv_noeeprom
      00C19F                       1522 00104$:
                                   1523 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00C19F EF               [12] 1524 	mov	a,r7
      00C1A0 24 FE            [12] 1525 	add	a,#0xfe
      00C1A2 90 0E 62         [24] 1526 	mov	dptr,#_fast_set_leds_PARM_2
      00C1A5 F0               [24] 1527 	movx	@dptr,a
      00C1A6 12 33 FC         [24] 1528 	lcall	_ak820_outline_0123
                                   1529 ;	quantum/vialrgb.c:210: }
                                   1530 ;	quantum/vialrgb.c:211: }
      00C1A9 02 BE 72         [24] 1531 	ljmp	_fast_set_leds
                                   1532 ;------------------------------------------------------------
                                   1533 ;Allocation info for local variables in function 'vialrgb_save'
                                   1534 ;------------------------------------------------------------
                                   1535 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1536 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1537 ;------------------------------------------------------------
                                   1538 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1539 ;	-----------------------------------------
                                   1540 ;	 function vialrgb_save
                                   1541 ;	-----------------------------------------
      00C1AC                       1542 _vialrgb_save:
                                   1543 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1544 ;	quantum/vialrgb.c:218: }
      00C1AC 02 59 95         [24] 1545 	ljmp	_eeconfig_update_rgb_matrix
                                   1546 	.area CSEG    (CODE)
                                   1547 	.area CONST   (CODE)
                                   1548 	.area CONST   (CODE)
      00C9AC                       1549 _supported_modes:
      00C9AC 00                    1550 	.db #0x00	; 0
      00C9AD 00                    1551 	.db #0x00	; 0
      00C9AE 01                    1552 	.db #0x01	; 1
      00C9AF 05                    1553 	.db #0x05	; 5
      00C9B0 02                    1554 	.db #0x02	; 2
      00C9B1 01                    1555 	.db #0x01	; 1
      00C9B2 06                    1556 	.db #0x06	; 6
      00C9B3 02                    1557 	.db #0x02	; 2
      00C9B4 0D                    1558 	.db #0x0d	; 13
      00C9B5 03                    1559 	.db #0x03	; 3
      00C9B6 0E                    1560 	.db #0x0e	; 14
      00C9B7 04                    1561 	.db #0x04	; 4
      00C9B8 1F                    1562 	.db #0x1f	; 31
      00C9B9 06                    1563 	.db #0x06	; 6
                                   1564 	.area CSEG    (CODE)
                                   1565 	.area XINIT   (CODE)
                                   1566 	.area CABS    (ABS,CODE)
                                   1567 
                                   1568 ; Experimental exact instruction outlining.
                                   1569 	.globl _ak820_outline_0005
                                   1570 	.globl _ak820_outline_0019
                                   1571 	.globl _ak820_outline_0023
                                   1572 	.globl _ak820_outline_0038
                                   1573 	.globl _ak820_outline_0040
                                   1574 	.globl _ak820_outline_0041
                                   1575 	.globl _ak820_outline_0049
                                   1576 	.globl _ak820_outline_0050
                                   1577 	.globl _ak820_outline_0054
                                   1578 	.globl _ak820_outline_0065
                                   1579 	.globl _ak820_outline_0077
                                   1580 	.globl _ak820_outline_0080
                                   1581 	.globl _ak820_outline_0085
                                   1582 	.globl _ak820_outline_0086
                                   1583 	.globl _ak820_outline_0107
                                   1584 	.globl _ak820_outline_0108
                                   1585 	.globl _ak820_outline_0109
                                   1586 	.globl _ak820_outline_0110
                                   1587 	.globl _ak820_outline_0120
                                   1588 	.globl _ak820_outline_0123
                                   1589 	.globl _ak820_outline_0124
                                   1590 	.globl _ak820_outline_0125
                                   1591 	.globl _ak820_outline_0136
                                   1592 	.globl _ak820_outline_0137
                                   1593 	.globl _ak820_outline_0143
                                   1594 	.globl _ak820_outline_0145
                                   1595 	.globl _ak820_outline_0158
                                   1596 	.globl _ak820_outline_0163
                                   1597 	.globl _ak820_outline_0171
                                   1598 	.globl _ak820_outline_0173
                                   1599 	.globl _ak820_outline_0187
                                   1600 	.globl _ak820_outline_0189
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0040
      00C1AF                       1604 _ak820_outline_0040:
      00C1AF 8D 82            [24] 1605 	mov	dpl,r5
      00C1B1 8E 83            [24] 1606 	mov	dph,r6
      00C1B3 A3               [24] 1607 	inc	dptr
      00C1B4 A3               [24] 1608 	inc	dptr
      00C1B5 A3               [24] 1609 	inc	dptr
      00C1B6 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0049
      00C1B7                       1614 _ak820_outline_0049:
      00C1B7 E0               [24] 1615 	movx	a,@dptr
      00C1B8 FD               [12] 1616 	mov	r5,a
      00C1B9 A3               [24] 1617 	inc	dptr
      00C1BA E0               [24] 1618 	movx	a,@dptr
      00C1BB FE               [12] 1619 	mov	r6,a
      00C1BC 74 02            [12] 1620 	mov	a,#0x02
      00C1BE 2D               [12] 1621 	add	a,r5
      00C1BF FB               [12] 1622 	mov	r3,a
      00C1C0 E4               [12] 1623 	clr	a
      00C1C1 3E               [12] 1624 	addc	a,r6
      00C1C2 FC               [12] 1625 	mov	r4,a
      00C1C3 8D 82            [24] 1626 	mov	dpl,r5
      00C1C5 8E 83            [24] 1627 	mov	dph,r6
      00C1C7 A3               [24] 1628 	inc	dptr
      00C1C8 E0               [24] 1629 	movx	a,@dptr
      00C1C9 FA               [12] 1630 	mov	r2,a
      00C1CA 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0050
      00C1CB                       1635 _ak820_outline_0050:
      00C1CB ED               [12] 1636 	mov	a,r5
      00C1CC 75 F0 02         [24] 1637 	mov	b,#0x02
      00C1CF A4               [48] 1638 	mul	ab
      00C1D0 24 AC            [12] 1639 	add	a,#_supported_modes
      00C1D2 FB               [12] 1640 	mov	r3,a
      00C1D3 74 C9            [12] 1641 	mov	a,#(_supported_modes>>8)
      00C1D5 35 F0            [12] 1642 	addc	a,b
      00C1D7 FC               [12] 1643 	mov	r4,a
      00C1D8 8B 82            [24] 1644 	mov	dpl,r3
      00C1DA 8C 83            [24] 1645 	mov	dph,r4
      00C1DC 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0085
      00C1DD                       1650 _ak820_outline_0085:
      00C1DD 90 0E 63         [24] 1651 	mov	dptr,#_fast_set_leds_args_10000_282
      00C1E0 E0               [24] 1652 	movx	a,@dptr
      00C1E1 F9               [12] 1653 	mov	r1,a
      00C1E2 A3               [24] 1654 	inc	dptr
      00C1E3 E0               [24] 1655 	movx	a,@dptr
      00C1E4 FF               [12] 1656 	mov	r7,a
      00C1E5 89 82            [24] 1657 	mov	dpl,r1
      00C1E7 8F 83            [24] 1658 	mov	dph,r7
      00C1E9 E0               [24] 1659 	movx	a,@dptr
      00C1EA 22               [24] 1660 	ret
                                   1661 
                                   1662 	.area CSEG (CODE)
                                   1663 ; function ak820_outline_0107
      00C1EB                       1664 _ak820_outline_0107:
      00C1EB 90 0E 63         [24] 1665 	mov	dptr,#_fast_set_leds_args_10000_282
      00C1EE 74 01            [12] 1666 	mov	a,#0x01
      00C1F0 29               [12] 1667 	add	a,r1
      00C1F1 F0               [24] 1668 	movx	@dptr,a
      00C1F2 E4               [12] 1669 	clr	a
      00C1F3 3F               [12] 1670 	addc	a,r7
      00C1F4 A3               [24] 1671 	inc	dptr
      00C1F5 F0               [24] 1672 	movx	@dptr,a
      00C1F6 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0145
      00C1F7                       1677 _ak820_outline_0145:
      00C1F7 E4               [12] 1678 	clr	a
      00C1F8 93               [24] 1679 	movc	a,@a+dptr
      00C1F9 FC               [12] 1680 	mov	r4,a
      00C1FA 7B 00            [12] 1681 	mov	r3,#0x00
      00C1FC 8C 82            [24] 1682 	mov	dpl,r4
      00C1FE 8B 83            [24] 1683 	mov	dph,r3
      00C200 22               [24] 1684 	ret
                                   1685 
                                   1686 	.area CSEG (CODE)
                                   1687 ; function ak820_outline_0173
      00C201                       1688 _ak820_outline_0173:
      00C201 2D               [12] 1689 	add	a,r5
      00C202 F5 82            [12] 1690 	mov	dpl,a
      00C204 E4               [12] 1691 	clr	a
      00C205 3E               [12] 1692 	addc	a,r6
      00C206 F5 83            [12] 1693 	mov	dph,a
      00C208 E0               [24] 1694 	movx	a,@dptr
      00C209 22               [24] 1695 	ret
