                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tap_dance
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _dynamic_keymap_get_tap_dance
                                     13 	.globl _process_record
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_tap_dance_valid
                                    258 	.globl _ak820_tap_dance_task
                                    259 	.globl _ak820_tap_dance_before
                                    260 	.globl _ak820_tap_dance_process
                                    261 	.globl _ak820_tap_dance_cancel
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
      000015                        524 _ak820_tap_dance_process_sloc0_1_0:
      000015                        525 	.ds 1
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
      00000E                        542 _td_action_sloc0_1_0:
      00000E                        543 	.ds 1
      00000F                        544 _ak820_tap_dance_valid_sloc0_1_0:
      00000F                        545 	.ds 1
      000010                        546 _ak820_tap_dance_before_sloc0_1_0:
      000010                        547 	.ds 1
                                    548 ;--------------------------------------------------------
                                    549 ; paged external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area PSEG    (PAG,XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; uninitialized external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XSEG    (XDATA)
      00059E                        556 _td_entries:
      00059E                        557 	.ds 80
      0005EE                        558 _td_time:
      0005EE                        559 	.ds 16
      0005FE                        560 _td_output:
      0005FE                        561 	.ds 16
      00060E                        562 _td_source:
      00060E                        563 	.ds 8
      000616                        564 _td_state:
      000616                        565 	.ds 8
      00061E                        566 _td_suppressed:
      00061E                        567 	.ds 16
      00062E                        568 _td_record:
      00062E                        569 	.ds 9
      000637                        570 _td_action_code_10000_594:
      000637                        571 	.ds 2
      000639                        572 _ak820_tap_dance_valid_entry_10000_596:
      000639                        573 	.ds 2
      00063B                        574 _td_emit_PARM_2:
      00063B                        575 	.ds 2
      00063D                        576 _td_emit_PARM_3:
      00063D                        577 	.ds 1
      00063E                        578 _td_emit_slot_10000_598:
      00063E                        579 	.ds 1
      00063F                        580 _td_tap_PARM_2:
      00063F                        581 	.ds 2
      000641                        582 _td_tap_slot_10000_601:
      000641                        583 	.ds 1
      000642                        584 _td_finish_interrupted_10000_604:
      000642                        585 	.ds 1
      000643                        586 _td_finish_slot_10000_605:
      000643                        587 	.ds 1
      000644                        588 _td_finish_code_10000_605:
      000644                        589 	.ds 2
      000646                        590 _ak820_tap_dance_task_now_10000_624:
      000646                        591 	.ds 2
      000648                        592 _ak820_tap_dance_task_term_30000_627:
      000648                        593 	.ds 2
      00064A                        594 _ak820_tap_dance_before_event_10000_630:
      00064A                        595 	.ds 2
      00064C                        596 _ak820_tap_dance_process_record_10000_646:
      00064C                        597 	.ds 2
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E83                        606 _td_pending:
      000E83                        607 	.ds 1
                                    608 	.area HOME    (CODE)
                                    609 	.area GSINIT0 (CODE)
                                    610 	.area GSINIT1 (CODE)
                                    611 	.area GSINIT2 (CODE)
                                    612 	.area GSINIT3 (CODE)
                                    613 	.area GSINIT4 (CODE)
                                    614 	.area GSINIT5 (CODE)
                                    615 	.area GSINIT  (CODE)
                                    616 	.area GSFINAL (CODE)
                                    617 	.area CSEG    (CODE)
                                    618 ;--------------------------------------------------------
                                    619 ; global & static initialisations
                                    620 ;--------------------------------------------------------
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 	.area GSFINAL (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; Home
                                    627 ;--------------------------------------------------------
                                    628 	.area HOME    (CODE)
                                    629 	.area HOME    (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; code
                                    632 ;--------------------------------------------------------
                                    633 	.area CSEG    (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    636 ;------------------------------------------------------------
                                    637 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    638 ;------------------------------------------------------------
                                    639 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    640 ;	-----------------------------------------
                           000007   641 	ar7 = 0x07
                           000006   642 	ar6 = 0x06
                           000005   643 	ar5 = 0x05
                           000004   644 	ar4 = 0x04
                           000003   645 	ar3 = 0x03
                           000002   646 	ar2 = 0x02
                           000001   647 	ar1 = 0x01
                           000000   648 	ar0 = 0x00
                                    649 ;	 function td_action
                                    650 ;	-----------------------------------------
      004380                        651 _td_action:
      004380 AF 83            [24]  652 	mov	r7,dph
      004382 E5 82            [12]  653 	mov	a,dpl
      004384 90 06 37         [24]  654 	mov	dptr,#_td_action_code_10000_594
      004387 F0               [24]  655 	movx	@dptr,a
      004388 EF               [12]  656 	mov	a,r7
      004389 A3               [24]  657 	inc	dptr
      00438A F0               [24]  658 	movx	@dptr,a
                                    659 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:22: uint8_t basic = code;
      00438B 90 06 37         [24]  660 	mov	dptr,#_td_action_code_10000_594
      00438E E0               [24]  661 	movx	a,@dptr
      00438F FE               [12]  662 	mov	r6,a
      004390 A3               [24]  663 	inc	dptr
      004391 E0               [24]  664 	movx	a,@dptr
      004392 FF               [12]  665 	mov	r7,a
                                    666 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:23: return !code || (code < QK_MOD_TAP && ((basic >= KC_A && basic <= KC_EXSEL) ||
      004393 EE               [12]  667 	mov	a,r6
      004394 FD               [12]  668 	mov	r5,a
      004395 4F               [12]  669 	orl	a,r7
      004396 60 1D            [24]  670 	jz	00104$
      004398 74 E0            [12]  671 	mov	a,#0x100 - 0x20
      00439A 2F               [12]  672 	add	a,r7
      00439B 40 14            [24]  673 	jc	00103$
      00439D BD 04 00         [24]  674 	cjne	r5,#0x04,00148$
      0043A0                        675 00148$:
      0043A0 40 05            [24]  676 	jc	00114$
      0043A2 ED               [12]  677 	mov	a,r5
      0043A3 24 5B            [12]  678 	add	a,#0xff - 0xa4
      0043A5 50 0E            [24]  679 	jnc	00104$
                                    680 ;	free result
      0043A7                        681 00114$:
                                    682 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:24: (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI)));
      0043A7 BD E0 00         [24]  683 	cjne	r5,#0xe0,00151$
      0043AA                        684 00151$:
      0043AA 40 05            [24]  685 	jc	00103$
      0043AC ED               [12]  686 	mov	a,r5
      0043AD 24 18            [12]  687 	add	a,#0xff - 0xe7
      0043AF 50 04            [24]  688 	jnc	00104$
                                    689 ;	free result
      0043B1                        690 00103$:
                                    691 ;	assignBit
      0043B1 C2 0E            [12]  692 	clr	_td_action_sloc0_1_0
      0043B3 80 02            [24]  693 	sjmp	00105$
      0043B5                        694 00104$:
                                    695 ;	assignBit
      0043B5 D2 0E            [12]  696 	setb	_td_action_sloc0_1_0
      0043B7                        697 00105$:
      0043B7 A2 0E            [12]  698 	mov	c,_td_action_sloc0_1_0
      0043B9 E4               [12]  699 	clr	a
      0043BA 33               [12]  700 	rlc	a
      0043BB F5 82            [12]  701 	mov	dpl, a
                                    702 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:25: }
      0043BD 22               [24]  703 	ret
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'ak820_tap_dance_valid'
                                    706 ;------------------------------------------------------------
                                    707 ;entry         Allocated with name '_ak820_tap_dance_valid_entry_10000_596'
                                    708 ;------------------------------------------------------------
                                    709 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:26: bool ak820_tap_dance_valid(const vial_tap_dance_entry_t AK820_STATE_MEM *entry) {
                                    710 ;	-----------------------------------------
                                    711 ;	 function ak820_tap_dance_valid
                                    712 ;	-----------------------------------------
      0043BE                        713 _ak820_tap_dance_valid:
      0043BE AF 83            [24]  714 	mov	r7,dph
      0043C0 E5 82            [12]  715 	mov	a,dpl
      0043C2 90 06 39         [24]  716 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_596
      0043C5 F0               [24]  717 	movx	@dptr,a
      0043C6 EF               [12]  718 	mov	a,r7
      0043C7 A3               [24]  719 	inc	dptr
      0043C8 F0               [24]  720 	movx	@dptr,a
                                    721 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:27: return entry->custom_tapping_term <= 32767 && td_action(entry->on_tap) &&
      0043C9 90 06 39         [24]  722 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_596
      0043CC E0               [24]  723 	movx	a,@dptr
      0043CD FE               [12]  724 	mov	r6,a
      0043CE A3               [24]  725 	inc	dptr
      0043CF E0               [24]  726 	movx	a,@dptr
      0043D0 FF               [12]  727 	mov	r7,a
      0043D1 74 08            [12]  728 	mov	a,#0x08
      0043D3 2E               [12]  729 	add	a, r6
      0043D4 F5 82            [12]  730 	mov	dpl,a
      0043D6 E4               [12]  731 	clr	a
      0043D7 3F               [12]  732 	addc	a, r7
      0043D8 F5 83            [12]  733 	mov	dph,a
      0043DA E0               [24]  734 	movx	a,@dptr
      0043DB FC               [12]  735 	mov	r4,a
      0043DC A3               [24]  736 	inc	dptr
      0043DD E0               [24]  737 	movx	a,@dptr
      0043DE FD               [12]  738 	mov	r5,a
      0043DF C3               [12]  739 	clr	c
      0043E0 74 FF            [12]  740 	mov	a,#0xff
      0043E2 9C               [12]  741 	subb	a,r4
      0043E3 74 7F            [12]  742 	mov	a,#0x7f
      0043E5 9D               [12]  743 	subb	a,r5
      0043E6 40 73            [24]  744 	jc	00103$
                                    745 ;	free result
      0043E8 8E 82            [24]  746 	mov	dpl,r6
      0043EA 8F 83            [24]  747 	mov	dph,r7
      0043EC E0               [24]  748 	movx	a,@dptr
      0043ED FC               [12]  749 	mov	r4,a
      0043EE A3               [24]  750 	inc	dptr
      0043EF E0               [24]  751 	movx	a,@dptr
      0043F0 FD               [12]  752 	mov	r5,a
      0043F1 8C 82            [24]  753 	mov	dpl, r4
      0043F3 8D 83            [24]  754 	mov	dph, r5
      0043F5 C0 07            [24]  755 	push	ar7
      0043F7 C0 06            [24]  756 	push	ar6
      0043F9 12 43 80         [24]  757 	lcall	_td_action
      0043FC E5 82            [12]  758 	mov	a, dpl
      0043FE D0 06            [24]  759 	pop	ar6
      004400 D0 07            [24]  760 	pop	ar7
      004402 60 57            [24]  761 	jz	00103$
                                    762 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: td_action(entry->on_hold) && td_action(entry->on_double_tap) && td_action(entry->on_tap_hold);
      004404 8E 82            [24]  763 	mov	dpl,r6
      004406 8F 83            [24]  764 	mov	dph,r7
      004408 A3               [24]  765 	inc	dptr
      004409 A3               [24]  766 	inc	dptr
      00440A E0               [24]  767 	movx	a,@dptr
      00440B FC               [12]  768 	mov	r4,a
      00440C A3               [24]  769 	inc	dptr
      00440D E0               [24]  770 	movx	a,@dptr
      00440E FD               [12]  771 	mov	r5,a
      00440F 8C 82            [24]  772 	mov	dpl, r4
      004411 8D 83            [24]  773 	mov	dph, r5
      004413 C0 07            [24]  774 	push	ar7
      004415 C0 06            [24]  775 	push	ar6
      004417 12 43 80         [24]  776 	lcall	_td_action
      00441A E5 82            [12]  777 	mov	a, dpl
      00441C D0 06            [24]  778 	pop	ar6
      00441E D0 07            [24]  779 	pop	ar7
      004420 60 39            [24]  780 	jz	00103$
      004422 8E 82            [24]  781 	mov	dpl,r6
      004424 8F 83            [24]  782 	mov	dph,r7
      004426 A3               [24]  783 	inc	dptr
      004427 A3               [24]  784 	inc	dptr
      004428 A3               [24]  785 	inc	dptr
      004429 A3               [24]  786 	inc	dptr
      00442A E0               [24]  787 	movx	a,@dptr
      00442B FC               [12]  788 	mov	r4,a
      00442C A3               [24]  789 	inc	dptr
      00442D E0               [24]  790 	movx	a,@dptr
      00442E FD               [12]  791 	mov	r5,a
      00442F 8C 82            [24]  792 	mov	dpl, r4
      004431 8D 83            [24]  793 	mov	dph, r5
      004433 C0 07            [24]  794 	push	ar7
      004435 C0 06            [24]  795 	push	ar6
      004437 12 43 80         [24]  796 	lcall	_td_action
      00443A E5 82            [12]  797 	mov	a, dpl
      00443C D0 06            [24]  798 	pop	ar6
      00443E D0 07            [24]  799 	pop	ar7
      004440 60 19            [24]  800 	jz	00103$
      004442 74 06            [12]  801 	mov	a,#0x06
      004444 2E               [12]  802 	add	a, r6
      004445 F5 82            [12]  803 	mov	dpl,a
      004447 E4               [12]  804 	clr	a
      004448 3F               [12]  805 	addc	a, r7
      004449 F5 83            [12]  806 	mov	dph,a
      00444B E0               [24]  807 	movx	a,@dptr
      00444C FE               [12]  808 	mov	r6,a
      00444D A3               [24]  809 	inc	dptr
      00444E E0               [24]  810 	movx	a,@dptr
      00444F FF               [12]  811 	mov	r7,a
      004450 8E 82            [24]  812 	mov	dpl, r6
      004452 8F 83            [24]  813 	mov	dph, r7
      004454 12 43 80         [24]  814 	lcall	_td_action
      004457 E5 82            [12]  815 	mov	a, dpl
      004459 70 04            [24]  816 	jnz	00104$
      00445B                        817 00103$:
                                    818 ;	assignBit
      00445B C2 0F            [12]  819 	clr	_ak820_tap_dance_valid_sloc0_1_0
      00445D 80 02            [24]  820 	sjmp	00105$
      00445F                        821 00104$:
                                    822 ;	assignBit
      00445F D2 0F            [12]  823 	setb	_ak820_tap_dance_valid_sloc0_1_0
      004461                        824 00105$:
      004461 A2 0F            [12]  825 	mov	c,_ak820_tap_dance_valid_sloc0_1_0
      004463 E4               [12]  826 	clr	a
      004464 33               [12]  827 	rlc	a
      004465 F5 82            [12]  828 	mov	dpl, a
                                    829 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:29: }
      004467 22               [24]  830 	ret
                                    831 ;------------------------------------------------------------
                                    832 ;Allocation info for local variables in function 'td_emit'
                                    833 ;------------------------------------------------------------
                                    834 ;code          Allocated with name '_td_emit_PARM_2'
                                    835 ;pressed       Allocated with name '_td_emit_PARM_3'
                                    836 ;slot          Allocated with name '_td_emit_slot_10000_598'
                                    837 ;------------------------------------------------------------
                                    838 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:32: static void td_emit(uint8_t slot, uint16_t code, bool pressed) {
                                    839 ;	-----------------------------------------
                                    840 ;	 function td_emit
                                    841 ;	-----------------------------------------
      004468                        842 _td_emit:
      004468 E5 82            [12]  843 	mov	a,dpl
      00446A 90 06 3E         [24]  844 	mov	dptr,#_td_emit_slot_10000_598
      00446D F0               [24]  845 	movx	@dptr,a
                                    846 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:33: if (!code) return;
      00446E 90 06 3B         [24]  847 	mov	dptr,#_td_emit_PARM_2
      004471 E0               [24]  848 	movx	a,@dptr
      004472 FE               [12]  849 	mov	r6,a
      004473 A3               [24]  850 	inc	dptr
      004474 E0               [24]  851 	movx	a,@dptr
      004475 FF               [12]  852 	mov	r7,a
      004476 90 06 3B         [24]  853 	mov	dptr,#_td_emit_PARM_2
      004479 E0               [24]  854 	movx	a,@dptr
      00447A F5 F0            [12]  855 	mov	b,a
      00447C A3               [24]  856 	inc	dptr
      00447D E0               [24]  857 	movx	a,@dptr
      00447E 45 F0            [12]  858 	orl	a,b
      004480 70 01            [24]  859 	jnz	00102$
      004482 22               [24]  860 	ret
      004483                        861 00102$:
                                    862 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:34: td_record.event.key.row = td_source[slot] / MATRIX_COLS;
      004483 90 06 3E         [24]  863 	mov	dptr,#_td_emit_slot_10000_598
      004486 E0               [24]  864 	movx	a,@dptr
      004487 FD               [12]  865 	mov	r5,a
      004488 24 0E            [12]  866 	add	a, #_td_source
      00448A FB               [12]  867 	mov	r3,a
      00448B E4               [12]  868 	clr	a
      00448C 34 06            [12]  869 	addc	a, #(_td_source >> 8)
      00448E FC               [12]  870 	mov	r4,a
      00448F 8B 82            [24]  871 	mov	dpl,r3
      004491 8C 83            [24]  872 	mov	dph,r4
      004493 E0               [24]  873 	movx	a,@dptr
      004494 75 F0 08         [24]  874 	mov	b,#0x08
      004497 84               [48]  875 	div	ab
      004498 90 06 2F         [24]  876 	mov	dptr,#(_td_record + 0x0001)
      00449B F0               [24]  877 	movx	@dptr,a
                                    878 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:35: td_record.event.key.col = td_source[slot] % MATRIX_COLS;
      00449C 8B 82            [24]  879 	mov	dpl,r3
      00449E 8C 83            [24]  880 	mov	dph,r4
      0044A0 E0               [24]  881 	movx	a,@dptr
      0044A1 FB               [12]  882 	mov	r3,a
      0044A2 53 03 07         [24]  883 	anl	ar3,#0x07
      0044A5 90 06 2E         [24]  884 	mov	dptr,#_td_record
      0044A8 EB               [12]  885 	mov	a,r3
      0044A9 F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:36: td_record.event.type = KEY_EVENT;
      0044AA 90 06 32         [24]  888 	mov	dptr,#(_td_record + 0x0004)
      0044AD 74 01            [12]  889 	mov	a,#0x01
      0044AF F0               [24]  890 	movx	@dptr,a
                                    891 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:37: td_record.event.time = td_time[slot];
      0044B0 ED               [12]  892 	mov	a,r5
      0044B1 75 F0 02         [24]  893 	mov	b,#0x02
      0044B4 A4               [48]  894 	mul	ab
      0044B5 24 EE            [12]  895 	add	a, #_td_time
      0044B7 F5 82            [12]  896 	mov	dpl,a
      0044B9 74 05            [12]  897 	mov	a,#(_td_time >> 8)
      0044BB 35 F0            [12]  898 	addc	a, b
      0044BD F5 83            [12]  899 	mov	dph,a
      0044BF E0               [24]  900 	movx	a,@dptr
      0044C0 FC               [12]  901 	mov	r4,a
      0044C1 A3               [24]  902 	inc	dptr
      0044C2 E0               [24]  903 	movx	a,@dptr
      0044C3 FD               [12]  904 	mov	r5,a
      0044C4 90 06 30         [24]  905 	mov	dptr,#(_td_record + 0x0002)
      0044C7 EC               [12]  906 	mov	a,r4
      0044C8 F0               [24]  907 	movx	@dptr,a
      0044C9 ED               [12]  908 	mov	a,r5
      0044CA A3               [24]  909 	inc	dptr
      0044CB F0               [24]  910 	movx	@dptr,a
                                    911 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:38: td_record.event.pressed = pressed;
      0044CC 90 06 3D         [24]  912 	mov	dptr,#_td_emit_PARM_3
      0044CF E0               [24]  913 	movx	a,@dptr
      0044D0 90 06 33         [24]  914 	mov	dptr,#(_td_record + 0x0005)
      0044D3 F0               [24]  915 	movx	@dptr,a
                                    916 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:39: td_record.tap.count = 1;
      0044D4 90 06 34         [24]  917 	mov	dptr,#(_td_record + 0x0006)
      0044D7 E0               [24]  918 	movx	a,@dptr
      0044D8 54 0F            [12]  919 	anl	a,#0x0f
      0044DA 44 10            [12]  920 	orl	a,#0x10
      0044DC F0               [24]  921 	movx	@dptr,a
                                    922 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:40: td_record.keycode = code;
      0044DD 90 06 35         [24]  923 	mov	dptr,#(_td_record + 0x0007)
      0044E0 EE               [12]  924 	mov	a,r6
      0044E1 F0               [24]  925 	movx	@dptr,a
      0044E2 EF               [12]  926 	mov	a,r7
      0044E3 A3               [24]  927 	inc	dptr
      0044E4 F0               [24]  928 	movx	@dptr,a
                                    929 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:41: process_record(&td_record);
      0044E5 90 06 2E         [24]  930 	mov	dptr,#_td_record
      0044E8 75 F0 00         [24]  931 	mov	b, #0x00
                                    932 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:42: }
      0044EB 02 79 E3         [24]  933 	ljmp	_process_record
                                    934 ;------------------------------------------------------------
                                    935 ;Allocation info for local variables in function 'td_tap'
                                    936 ;------------------------------------------------------------
                                    937 ;code          Allocated with name '_td_tap_PARM_2'
                                    938 ;slot          Allocated with name '_td_tap_slot_10000_601'
                                    939 ;------------------------------------------------------------
                                    940 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:43: static void td_tap(uint8_t slot, uint16_t code) {
                                    941 ;	-----------------------------------------
                                    942 ;	 function td_tap
                                    943 ;	-----------------------------------------
      0044EE                        944 _td_tap:
      0044EE E5 82            [12]  945 	mov	a,dpl
      0044F0 90 06 41         [24]  946 	mov	dptr,#_td_tap_slot_10000_601
      0044F3 F0               [24]  947 	movx	@dptr,a
                                    948 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:44: td_emit(slot, code, true);
      0044F4 E0               [24]  949 	movx	a,@dptr
      0044F5 FF               [12]  950 	mov	r7,a
      0044F6 90 06 3F         [24]  951 	mov	dptr,#_td_tap_PARM_2
      0044F9 E0               [24]  952 	movx	a,@dptr
      0044FA FD               [12]  953 	mov	r5,a
      0044FB A3               [24]  954 	inc	dptr
      0044FC E0               [24]  955 	movx	a,@dptr
      0044FD FE               [12]  956 	mov	r6,a
      0044FE 90 06 3B         [24]  957 	mov	dptr,#_td_emit_PARM_2
      004501 ED               [12]  958 	mov	a,r5
      004502 F0               [24]  959 	movx	@dptr,a
      004503 EE               [12]  960 	mov	a,r6
      004504 A3               [24]  961 	inc	dptr
      004505 F0               [24]  962 	movx	@dptr,a
      004506 90 06 3D         [24]  963 	mov	dptr,#_td_emit_PARM_3
      004509 74 01            [12]  964 	mov	a,#0x01
      00450B F0               [24]  965 	movx	@dptr,a
      00450C 8F 82            [24]  966 	mov	dpl, r7
      00450E C0 07            [24]  967 	push	ar7
      004510 C0 06            [24]  968 	push	ar6
      004512 C0 05            [24]  969 	push	ar5
      004514 12 44 68         [24]  970 	lcall	_td_emit
      004517 D0 05            [24]  971 	pop	ar5
      004519 D0 06            [24]  972 	pop	ar6
      00451B D0 07            [24]  973 	pop	ar7
                                    974 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:46: if (td_state[slot]) td_emit(slot, code, false);
      00451D EF               [12]  975 	mov	a,r7
      00451E 24 16            [12]  976 	add	a, #_td_state
      004520 FB               [12]  977 	mov	r3,a
      004521 E4               [12]  978 	clr	a
      004522 34 06            [12]  979 	addc	a, #(_td_state >> 8)
      004524 FC               [12]  980 	mov	r4,a
      004525 8B 82            [24]  981 	mov	dpl,r3
      004527 8C 83            [24]  982 	mov	dph,r4
      004529 E0               [24]  983 	movx	a,@dptr
      00452A 60 12            [24]  984 	jz	00103$
      00452C 90 06 3B         [24]  985 	mov	dptr,#_td_emit_PARM_2
      00452F ED               [12]  986 	mov	a,r5
      004530 F0               [24]  987 	movx	@dptr,a
      004531 EE               [12]  988 	mov	a,r6
      004532 A3               [24]  989 	inc	dptr
      004533 F0               [24]  990 	movx	@dptr,a
      004534 90 06 3D         [24]  991 	mov	dptr,#_td_emit_PARM_3
      004537 E4               [12]  992 	clr	a
      004538 F0               [24]  993 	movx	@dptr,a
      004539 8F 82            [24]  994 	mov	dpl, r7
                                    995 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:47: }
      00453B 02 44 68         [24]  996 	ljmp	_td_emit
      00453E                        997 00103$:
      00453E 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'td_finish'
                                   1001 ;------------------------------------------------------------
                                   1002 ;interrupted   Allocated with name '_td_finish_interrupted_10000_604'
                                   1003 ;slot          Allocated with name '_td_finish_slot_10000_605'
                                   1004 ;code          Allocated with name '_td_finish_code_10000_605'
                                   1005 ;------------------------------------------------------------
                                   1006 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:48: static void td_finish(bool interrupted) {
                                   1007 ;	-----------------------------------------
                                   1008 ;	 function td_finish
                                   1009 ;	-----------------------------------------
      00453F                       1010 _td_finish:
      00453F E5 82            [12] 1011 	mov	a,dpl
      004541 90 06 42         [24] 1012 	mov	dptr,#_td_finish_interrupted_10000_604
      004544 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:49: uint8_t slot = td_pending;
      004545 90 0E 83         [24] 1015 	mov	dptr,#_td_pending
      004548 E0               [24] 1016 	movx	a,@dptr
      004549 FF               [12] 1017 	mov	r7,a
      00454A 90 06 43         [24] 1018 	mov	dptr,#_td_finish_slot_10000_605
      00454D F0               [24] 1019 	movx	@dptr,a
                                   1020 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:51: if (slot == TD_NONE) return;
      00454E BF FF 01         [24] 1021 	cjne	r7,#0xff,00102$
      004551 22               [24] 1022 	ret
      004552                       1023 00102$:
                                   1024 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:52: td_pending = TD_NONE;
      004552 90 0E 83         [24] 1025 	mov	dptr,#_td_pending
      004555 74 FF            [12] 1026 	mov	a,#0xff
      004557 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:53: td_state[slot] |= TD_DONE;
      004558 90 06 43         [24] 1029 	mov	dptr,#_td_finish_slot_10000_605
      00455B E0               [24] 1030 	movx	a,@dptr
      00455C FF               [12] 1031 	mov	r7,a
      00455D 24 16            [12] 1032 	add	a, #_td_state
      00455F FD               [12] 1033 	mov	r5,a
      004560 E4               [12] 1034 	clr	a
      004561 34 06            [12] 1035 	addc	a, #(_td_state >> 8)
      004563 FE               [12] 1036 	mov	r6,a
      004564 8D 82            [24] 1037 	mov	dpl,r5
      004566 8E 83            [24] 1038 	mov	dph,r6
      004568 E0               [24] 1039 	movx	a,@dptr
      004569 FC               [12] 1040 	mov	r4,a
      00456A 43 04 08         [24] 1041 	orl	ar4,#0x08
      00456D 8D 82            [24] 1042 	mov	dpl,r5
      00456F 8E 83            [24] 1043 	mov	dph,r6
      004571 EC               [12] 1044 	mov	a,r4
      004572 F0               [24] 1045 	movx	@dptr,a
                                   1046 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:54: if ((td_state[slot] & 3) == 1) {
      004573 53 04 03         [24] 1047 	anl	ar4,#0x03
      004576 BC 01 02         [24] 1048 	cjne	r4,#0x01,00241$
      004579 80 03            [24] 1049 	sjmp	00242$
      00457B                       1050 00241$:
      00457B 02 46 0C         [24] 1051 	ljmp	00120$
      00457E                       1052 00242$:
                                   1053 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:55: code = (td_state[slot] & TD_DOWN) && !interrupted ? td_entries[slot].on_hold : td_entries[slot].on_tap;
      00457E 8D 82            [24] 1054 	mov	dpl,r5
      004580 8E 83            [24] 1055 	mov	dph,r6
      004582 E0               [24] 1056 	movx	a,@dptr
      004583 03               [12] 1057 	rr	a
      004584 03               [12] 1058 	rr	a
      004585 54 01            [12] 1059 	anl	a,#0x01
      004587 60 20            [24] 1060 	jz	00130$
      004589 90 06 42         [24] 1061 	mov	dptr,#_td_finish_interrupted_10000_604
      00458C E0               [24] 1062 	movx	a,@dptr
      00458D 70 1A            [24] 1063 	jnz	00130$
      00458F EF               [12] 1064 	mov	a,r7
      004590 75 F0 0A         [24] 1065 	mov	b,#0x0a
      004593 A4               [48] 1066 	mul	ab
      004594 24 9E            [12] 1067 	add	a, #_td_entries
      004596 FB               [12] 1068 	mov	r3,a
      004597 74 05            [12] 1069 	mov	a,#(_td_entries >> 8)
      004599 35 F0            [12] 1070 	addc	a, b
      00459B FC               [12] 1071 	mov	r4,a
      00459C 8B 82            [24] 1072 	mov	dpl,r3
      00459E 8C 83            [24] 1073 	mov	dph,r4
      0045A0 A3               [24] 1074 	inc	dptr
      0045A1 A3               [24] 1075 	inc	dptr
      0045A2 E0               [24] 1076 	movx	a,@dptr
      0045A3 FB               [12] 1077 	mov	r3,a
      0045A4 A3               [24] 1078 	inc	dptr
      0045A5 E0               [24] 1079 	movx	a,@dptr
      0045A6 FC               [12] 1080 	mov	r4,a
      0045A7 80 17            [24] 1081 	sjmp	00131$
      0045A9                       1082 00130$:
      0045A9 90 06 43         [24] 1083 	mov	dptr,#_td_finish_slot_10000_605
      0045AC E0               [24] 1084 	movx	a,@dptr
      0045AD 75 F0 0A         [24] 1085 	mov	b,#0x0a
      0045B0 A4               [48] 1086 	mul	ab
      0045B1 24 9E            [12] 1087 	add	a, #_td_entries
      0045B3 F5 82            [12] 1088 	mov	dpl,a
      0045B5 74 05            [12] 1089 	mov	a,#(_td_entries >> 8)
      0045B7 35 F0            [12] 1090 	addc	a, b
      0045B9 F5 83            [12] 1091 	mov	dph,a
      0045BB E0               [24] 1092 	movx	a,@dptr
      0045BC FB               [12] 1093 	mov	r3,a
      0045BD A3               [24] 1094 	inc	dptr
      0045BE E0               [24] 1095 	movx	a,@dptr
      0045BF FC               [12] 1096 	mov	r4,a
      0045C0                       1097 00131$:
      0045C0 90 06 44         [24] 1098 	mov	dptr,#_td_finish_code_10000_605
      0045C3 EB               [12] 1099 	mov	a,r3
      0045C4 F0               [24] 1100 	movx	@dptr,a
      0045C5 EC               [12] 1101 	mov	a,r4
      0045C6 A3               [24] 1102 	inc	dptr
      0045C7 F0               [24] 1103 	movx	@dptr,a
                                   1104 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:56: if (!code && (td_state[slot] & TD_DOWN) && !interrupted) code = td_entries[slot].on_tap;
      0045C8 EB               [12] 1105 	mov	a,r3
      0045C9 4C               [12] 1106 	orl	a,r4
      0045CA 60 03            [24] 1107 	jz	00245$
      0045CC 02 47 2F         [24] 1108 	ljmp	00121$
      0045CF                       1109 00245$:
      0045CF 90 06 43         [24] 1110 	mov	dptr,#_td_finish_slot_10000_605
      0045D2 E0               [24] 1111 	movx	a,@dptr
      0045D3 FC               [12] 1112 	mov	r4,a
      0045D4 24 16            [12] 1113 	add	a, #_td_state
      0045D6 F5 82            [12] 1114 	mov	dpl,a
      0045D8 E4               [12] 1115 	clr	a
      0045D9 34 06            [12] 1116 	addc	a, #(_td_state >> 8)
      0045DB F5 83            [12] 1117 	mov	dph,a
      0045DD E0               [24] 1118 	movx	a,@dptr
      0045DE 20 E2 03         [24] 1119 	jb	acc.2,00246$
      0045E1 02 47 2F         [24] 1120 	ljmp	00121$
      0045E4                       1121 00246$:
      0045E4 90 06 42         [24] 1122 	mov	dptr,#_td_finish_interrupted_10000_604
      0045E7 E0               [24] 1123 	movx	a,@dptr
      0045E8 60 03            [24] 1124 	jz	00247$
      0045EA 02 47 2F         [24] 1125 	ljmp	00121$
      0045ED                       1126 00247$:
      0045ED EC               [12] 1127 	mov	a,r4
      0045EE 75 F0 0A         [24] 1128 	mov	b,#0x0a
      0045F1 A4               [48] 1129 	mul	ab
      0045F2 24 9E            [12] 1130 	add	a, #_td_entries
      0045F4 F5 82            [12] 1131 	mov	dpl,a
      0045F6 74 05            [12] 1132 	mov	a,#(_td_entries >> 8)
      0045F8 35 F0            [12] 1133 	addc	a, b
      0045FA F5 83            [12] 1134 	mov	dph,a
      0045FC E0               [24] 1135 	movx	a,@dptr
      0045FD FB               [12] 1136 	mov	r3,a
      0045FE A3               [24] 1137 	inc	dptr
      0045FF E0               [24] 1138 	movx	a,@dptr
      004600 FC               [12] 1139 	mov	r4,a
      004601 90 06 44         [24] 1140 	mov	dptr,#_td_finish_code_10000_605
      004604 EB               [12] 1141 	mov	a,r3
      004605 F0               [24] 1142 	movx	@dptr,a
      004606 EC               [12] 1143 	mov	a,r4
      004607 A3               [24] 1144 	inc	dptr
      004608 F0               [24] 1145 	movx	@dptr,a
      004609 02 47 2F         [24] 1146 	ljmp	00121$
      00460C                       1147 00120$:
                                   1148 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:57: } else if (interrupted) {
      00460C 90 06 42         [24] 1149 	mov	dptr,#_td_finish_interrupted_10000_604
      00460F E0               [24] 1150 	movx	a,@dptr
      004610 60 3F            [24] 1151 	jz	00117$
                                   1152 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:58: td_tap(slot, td_entries[slot].on_tap);
      004612 EF               [12] 1153 	mov	a,r7
      004613 75 F0 0A         [24] 1154 	mov	b,#0x0a
      004616 A4               [48] 1155 	mul	ab
      004617 24 9E            [12] 1156 	add	a, #_td_entries
      004619 FB               [12] 1157 	mov	r3,a
      00461A 74 05            [12] 1158 	mov	a,#(_td_entries >> 8)
      00461C 35 F0            [12] 1159 	addc	a, b
      00461E FC               [12] 1160 	mov	r4,a
      00461F 8B 82            [24] 1161 	mov	dpl,r3
      004621 8C 83            [24] 1162 	mov	dph,r4
      004623 E0               [24] 1163 	movx	a,@dptr
      004624 F9               [12] 1164 	mov	r1,a
      004625 A3               [24] 1165 	inc	dptr
      004626 E0               [24] 1166 	movx	a,@dptr
      004627 FA               [12] 1167 	mov	r2,a
      004628 90 06 3F         [24] 1168 	mov	dptr,#_td_tap_PARM_2
      00462B E9               [12] 1169 	mov	a,r1
      00462C F0               [24] 1170 	movx	@dptr,a
      00462D EA               [12] 1171 	mov	a,r2
      00462E A3               [24] 1172 	inc	dptr
      00462F F0               [24] 1173 	movx	@dptr,a
      004630 8F 82            [24] 1174 	mov	dpl, r7
      004632 C0 04            [24] 1175 	push	ar4
      004634 C0 03            [24] 1176 	push	ar3
      004636 12 44 EE         [24] 1177 	lcall	_td_tap
      004639 D0 03            [24] 1178 	pop	ar3
      00463B D0 04            [24] 1179 	pop	ar4
                                   1180 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:59: code = td_entries[slot].on_tap;
      00463D 8B 82            [24] 1181 	mov	dpl,r3
      00463F 8C 83            [24] 1182 	mov	dph,r4
      004641 E0               [24] 1183 	movx	a,@dptr
      004642 FB               [12] 1184 	mov	r3,a
      004643 A3               [24] 1185 	inc	dptr
      004644 E0               [24] 1186 	movx	a,@dptr
      004645 FC               [12] 1187 	mov	r4,a
      004646 90 06 44         [24] 1188 	mov	dptr,#_td_finish_code_10000_605
      004649 EB               [12] 1189 	mov	a,r3
      00464A F0               [24] 1190 	movx	@dptr,a
      00464B EC               [12] 1191 	mov	a,r4
      00464C A3               [24] 1192 	inc	dptr
      00464D F0               [24] 1193 	movx	@dptr,a
      00464E 02 47 2F         [24] 1194 	ljmp	00121$
      004651                       1195 00117$:
                                   1196 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:60: } else if (td_state[slot] & TD_DOWN) {
      004651 8D 82            [24] 1197 	mov	dpl,r5
      004653 8E 83            [24] 1198 	mov	dph,r6
      004655 E0               [24] 1199 	movx	a,@dptr
      004656 20 E2 03         [24] 1200 	jb	acc.2,00249$
      004659 02 46 DA         [24] 1201 	ljmp	00114$
      00465C                       1202 00249$:
                                   1203 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:61: code = td_entries[slot].on_tap_hold;
      00465C EF               [12] 1204 	mov	a,r7
      00465D 75 F0 0A         [24] 1205 	mov	b,#0x0a
      004660 A4               [48] 1206 	mul	ab
      004661 24 9E            [12] 1207 	add	a, #_td_entries
      004663 FD               [12] 1208 	mov	r5,a
      004664 74 05            [12] 1209 	mov	a,#(_td_entries >> 8)
      004666 35 F0            [12] 1210 	addc	a, b
      004668 FE               [12] 1211 	mov	r6,a
      004669 74 06            [12] 1212 	mov	a,#0x06
      00466B 2D               [12] 1213 	add	a, r5
      00466C F5 82            [12] 1214 	mov	dpl,a
      00466E E4               [12] 1215 	clr	a
      00466F 3E               [12] 1216 	addc	a, r6
      004670 F5 83            [12] 1217 	mov	dph,a
      004672 E0               [24] 1218 	movx	a,@dptr
      004673 FB               [12] 1219 	mov	r3,a
      004674 A3               [24] 1220 	inc	dptr
      004675 E0               [24] 1221 	movx	a,@dptr
      004676 FC               [12] 1222 	mov	r4,a
      004677 90 06 44         [24] 1223 	mov	dptr,#_td_finish_code_10000_605
      00467A EB               [12] 1224 	mov	a,r3
      00467B F0               [24] 1225 	movx	@dptr,a
      00467C EC               [12] 1226 	mov	a,r4
      00467D A3               [24] 1227 	inc	dptr
      00467E F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:62: if (!code) {
      00467F EB               [12] 1230 	mov	a,r3
      004680 4C               [12] 1231 	orl	a,r4
      004681 60 03            [24] 1232 	jz	00250$
      004683 02 47 2F         [24] 1233 	ljmp	00121$
      004686                       1234 00250$:
                                   1235 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:63: td_tap(slot, td_entries[slot].on_tap);
      004686 8D 03            [24] 1236 	mov	ar3,r5
      004688 8E 04            [24] 1237 	mov	ar4,r6
      00468A 8B 82            [24] 1238 	mov	dpl,r3
      00468C 8C 83            [24] 1239 	mov	dph,r4
      00468E E0               [24] 1240 	movx	a,@dptr
      00468F F9               [12] 1241 	mov	r1,a
      004690 A3               [24] 1242 	inc	dptr
      004691 E0               [24] 1243 	movx	a,@dptr
      004692 FA               [12] 1244 	mov	r2,a
      004693 90 06 3F         [24] 1245 	mov	dptr,#_td_tap_PARM_2
      004696 E9               [12] 1246 	mov	a,r1
      004697 F0               [24] 1247 	movx	@dptr,a
      004698 EA               [12] 1248 	mov	a,r2
      004699 A3               [24] 1249 	inc	dptr
      00469A F0               [24] 1250 	movx	@dptr,a
      00469B 8F 82            [24] 1251 	mov	dpl, r7
      00469D C0 06            [24] 1252 	push	ar6
      00469F C0 05            [24] 1253 	push	ar5
      0046A1 C0 04            [24] 1254 	push	ar4
      0046A3 C0 03            [24] 1255 	push	ar3
      0046A5 12 44 EE         [24] 1256 	lcall	_td_tap
      0046A8 D0 03            [24] 1257 	pop	ar3
      0046AA D0 04            [24] 1258 	pop	ar4
      0046AC D0 05            [24] 1259 	pop	ar5
      0046AE D0 06            [24] 1260 	pop	ar6
                                   1261 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:64: code = td_entries[slot].on_hold;
      0046B0 8D 82            [24] 1262 	mov	dpl,r5
      0046B2 8E 83            [24] 1263 	mov	dph,r6
      0046B4 A3               [24] 1264 	inc	dptr
      0046B5 A3               [24] 1265 	inc	dptr
      0046B6 E0               [24] 1266 	movx	a,@dptr
      0046B7 FD               [12] 1267 	mov	r5,a
      0046B8 A3               [24] 1268 	inc	dptr
      0046B9 E0               [24] 1269 	movx	a,@dptr
      0046BA FE               [12] 1270 	mov	r6,a
      0046BB 90 06 44         [24] 1271 	mov	dptr,#_td_finish_code_10000_605
      0046BE ED               [12] 1272 	mov	a,r5
      0046BF F0               [24] 1273 	movx	@dptr,a
      0046C0 EE               [12] 1274 	mov	a,r6
      0046C1 A3               [24] 1275 	inc	dptr
      0046C2 F0               [24] 1276 	movx	@dptr,a
                                   1277 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:65: if (!code) code = td_entries[slot].on_tap;
      0046C3 ED               [12] 1278 	mov	a,r5
      0046C4 4E               [12] 1279 	orl	a,r6
      0046C5 70 68            [24] 1280 	jnz	00121$
      0046C7 8B 82            [24] 1281 	mov	dpl,r3
      0046C9 8C 83            [24] 1282 	mov	dph,r4
      0046CB E0               [24] 1283 	movx	a,@dptr
      0046CC FB               [12] 1284 	mov	r3,a
      0046CD A3               [24] 1285 	inc	dptr
      0046CE E0               [24] 1286 	movx	a,@dptr
      0046CF FC               [12] 1287 	mov	r4,a
      0046D0 90 06 44         [24] 1288 	mov	dptr,#_td_finish_code_10000_605
      0046D3 EB               [12] 1289 	mov	a,r3
      0046D4 F0               [24] 1290 	movx	@dptr,a
      0046D5 EC               [12] 1291 	mov	a,r4
      0046D6 A3               [24] 1292 	inc	dptr
      0046D7 F0               [24] 1293 	movx	@dptr,a
      0046D8 80 55            [24] 1294 	sjmp	00121$
      0046DA                       1295 00114$:
                                   1296 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:68: code = td_entries[slot].on_double_tap;
      0046DA EF               [12] 1297 	mov	a,r7
      0046DB 75 F0 0A         [24] 1298 	mov	b,#0x0a
      0046DE A4               [48] 1299 	mul	ab
      0046DF 24 9E            [12] 1300 	add	a, #_td_entries
      0046E1 FD               [12] 1301 	mov	r5,a
      0046E2 74 05            [12] 1302 	mov	a,#(_td_entries >> 8)
      0046E4 35 F0            [12] 1303 	addc	a, b
      0046E6 FE               [12] 1304 	mov	r6,a
      0046E7 8D 82            [24] 1305 	mov	dpl,r5
      0046E9 8E 83            [24] 1306 	mov	dph,r6
      0046EB A3               [24] 1307 	inc	dptr
      0046EC A3               [24] 1308 	inc	dptr
      0046ED A3               [24] 1309 	inc	dptr
      0046EE A3               [24] 1310 	inc	dptr
      0046EF E0               [24] 1311 	movx	a,@dptr
      0046F0 FB               [12] 1312 	mov	r3,a
      0046F1 A3               [24] 1313 	inc	dptr
      0046F2 E0               [24] 1314 	movx	a,@dptr
      0046F3 FC               [12] 1315 	mov	r4,a
      0046F4 90 06 44         [24] 1316 	mov	dptr,#_td_finish_code_10000_605
      0046F7 EB               [12] 1317 	mov	a,r3
      0046F8 F0               [24] 1318 	movx	@dptr,a
      0046F9 EC               [12] 1319 	mov	a,r4
      0046FA A3               [24] 1320 	inc	dptr
      0046FB F0               [24] 1321 	movx	@dptr,a
                                   1322 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: if (!code) { td_tap(slot, td_entries[slot].on_tap); code = td_entries[slot].on_tap; }
      0046FC EB               [12] 1323 	mov	a,r3
      0046FD 4C               [12] 1324 	orl	a,r4
      0046FE 70 2F            [24] 1325 	jnz	00121$
      004700 8D 82            [24] 1326 	mov	dpl,r5
      004702 8E 83            [24] 1327 	mov	dph,r6
      004704 E0               [24] 1328 	movx	a,@dptr
      004705 FB               [12] 1329 	mov	r3,a
      004706 A3               [24] 1330 	inc	dptr
      004707 E0               [24] 1331 	movx	a,@dptr
      004708 FC               [12] 1332 	mov	r4,a
      004709 90 06 3F         [24] 1333 	mov	dptr,#_td_tap_PARM_2
      00470C EB               [12] 1334 	mov	a,r3
      00470D F0               [24] 1335 	movx	@dptr,a
      00470E EC               [12] 1336 	mov	a,r4
      00470F A3               [24] 1337 	inc	dptr
      004710 F0               [24] 1338 	movx	@dptr,a
      004711 8F 82            [24] 1339 	mov	dpl, r7
      004713 C0 06            [24] 1340 	push	ar6
      004715 C0 05            [24] 1341 	push	ar5
      004717 12 44 EE         [24] 1342 	lcall	_td_tap
      00471A D0 05            [24] 1343 	pop	ar5
      00471C D0 06            [24] 1344 	pop	ar6
      00471E 8D 82            [24] 1345 	mov	dpl,r5
      004720 8E 83            [24] 1346 	mov	dph,r6
      004722 E0               [24] 1347 	movx	a,@dptr
      004723 FD               [12] 1348 	mov	r5,a
      004724 A3               [24] 1349 	inc	dptr
      004725 E0               [24] 1350 	movx	a,@dptr
      004726 FE               [12] 1351 	mov	r6,a
      004727 90 06 44         [24] 1352 	mov	dptr,#_td_finish_code_10000_605
      00472A ED               [12] 1353 	mov	a,r5
      00472B F0               [24] 1354 	movx	@dptr,a
      00472C EE               [12] 1355 	mov	a,r6
      00472D A3               [24] 1356 	inc	dptr
      00472E F0               [24] 1357 	movx	@dptr,a
      00472F                       1358 00121$:
                                   1359 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:71: if (!td_state[slot]) return;
      00472F 90 06 43         [24] 1360 	mov	dptr,#_td_finish_slot_10000_605
      004732 E0               [24] 1361 	movx	a,@dptr
      004733 FF               [12] 1362 	mov	r7,a
      004734 24 16            [12] 1363 	add	a, #_td_state
      004736 FD               [12] 1364 	mov	r5,a
      004737 E4               [12] 1365 	clr	a
      004738 34 06            [12] 1366 	addc	a, #(_td_state >> 8)
      00473A FE               [12] 1367 	mov	r6,a
      00473B 8D 82            [24] 1368 	mov	dpl,r5
      00473D 8E 83            [24] 1369 	mov	dph,r6
      00473F E0               [24] 1370 	movx	a,@dptr
      004740 70 01            [24] 1371 	jnz	00123$
      004742 22               [24] 1372 	ret
      004743                       1373 00123$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:72: td_output[slot] = code;
      004743 EF               [12] 1375 	mov	a,r7
      004744 75 F0 02         [24] 1376 	mov	b,#0x02
      004747 A4               [48] 1377 	mul	ab
      004748 24 FE            [12] 1378 	add	a, #_td_output
      00474A FB               [12] 1379 	mov	r3,a
      00474B 74 05            [12] 1380 	mov	a,#(_td_output >> 8)
      00474D 35 F0            [12] 1381 	addc	a, b
      00474F FC               [12] 1382 	mov	r4,a
      004750 90 06 44         [24] 1383 	mov	dptr,#_td_finish_code_10000_605
      004753 E0               [24] 1384 	movx	a,@dptr
      004754 F9               [12] 1385 	mov	r1,a
      004755 A3               [24] 1386 	inc	dptr
      004756 E0               [24] 1387 	movx	a,@dptr
      004757 FA               [12] 1388 	mov	r2,a
      004758 8B 82            [24] 1389 	mov	dpl,r3
      00475A 8C 83            [24] 1390 	mov	dph,r4
      00475C E9               [12] 1391 	mov	a,r1
      00475D F0               [24] 1392 	movx	@dptr,a
      00475E EA               [12] 1393 	mov	a,r2
      00475F A3               [24] 1394 	inc	dptr
      004760 F0               [24] 1395 	movx	@dptr,a
                                   1396 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:73: td_emit(slot, code, true);
      004761 90 06 3B         [24] 1397 	mov	dptr,#_td_emit_PARM_2
      004764 E9               [12] 1398 	mov	a,r1
      004765 F0               [24] 1399 	movx	@dptr,a
      004766 EA               [12] 1400 	mov	a,r2
      004767 A3               [24] 1401 	inc	dptr
      004768 F0               [24] 1402 	movx	@dptr,a
      004769 90 06 3D         [24] 1403 	mov	dptr,#_td_emit_PARM_3
      00476C 74 01            [12] 1404 	mov	a,#0x01
      00476E F0               [24] 1405 	movx	@dptr,a
      00476F 8F 82            [24] 1406 	mov	dpl, r7
      004771 C0 07            [24] 1407 	push	ar7
      004773 C0 06            [24] 1408 	push	ar6
      004775 C0 05            [24] 1409 	push	ar5
      004777 C0 02            [24] 1410 	push	ar2
      004779 C0 01            [24] 1411 	push	ar1
      00477B 12 44 68         [24] 1412 	lcall	_td_emit
      00477E D0 01            [24] 1413 	pop	ar1
      004780 D0 02            [24] 1414 	pop	ar2
      004782 D0 05            [24] 1415 	pop	ar5
      004784 D0 06            [24] 1416 	pop	ar6
      004786 D0 07            [24] 1417 	pop	ar7
                                   1418 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:74: if (!td_state[slot]) return;
      004788 8D 82            [24] 1419 	mov	dpl,r5
      00478A 8E 83            [24] 1420 	mov	dph,r6
      00478C E0               [24] 1421 	movx	a,@dptr
      00478D FC               [12] 1422 	mov	r4,a
      00478E 70 01            [24] 1423 	jnz	00125$
      004790 22               [24] 1424 	ret
      004791                       1425 00125$:
                                   1426 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:75: if (!(td_state[slot] & TD_DOWN)) {
      004791 EC               [12] 1427 	mov	a,r4
      004792 20 E2 20         [24] 1428 	jb	acc.2,00128$
                                   1429 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:76: td_emit(slot, code, false);
      004795 90 06 3B         [24] 1430 	mov	dptr,#_td_emit_PARM_2
      004798 E9               [12] 1431 	mov	a,r1
      004799 F0               [24] 1432 	movx	@dptr,a
      00479A EA               [12] 1433 	mov	a,r2
      00479B A3               [24] 1434 	inc	dptr
      00479C F0               [24] 1435 	movx	@dptr,a
      00479D 90 06 3D         [24] 1436 	mov	dptr,#_td_emit_PARM_3
      0047A0 E4               [12] 1437 	clr	a
      0047A1 F0               [24] 1438 	movx	@dptr,a
      0047A2 8F 82            [24] 1439 	mov	dpl, r7
      0047A4 C0 06            [24] 1440 	push	ar6
      0047A6 C0 05            [24] 1441 	push	ar5
      0047A8 12 44 68         [24] 1442 	lcall	_td_emit
      0047AB D0 05            [24] 1443 	pop	ar5
      0047AD D0 06            [24] 1444 	pop	ar6
                                   1445 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:77: td_state[slot] = 0;
      0047AF 8D 82            [24] 1446 	mov	dpl,r5
      0047B1 8E 83            [24] 1447 	mov	dph,r6
      0047B3 E4               [12] 1448 	clr	a
      0047B4 F0               [24] 1449 	movx	@dptr,a
      0047B5                       1450 00128$:
                                   1451 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:79: }
      0047B5 22               [24] 1452 	ret
                                   1453 ;------------------------------------------------------------
                                   1454 ;Allocation info for local variables in function 'ak820_tap_dance_task'
                                   1455 ;------------------------------------------------------------
                                   1456 ;now           Allocated with name '_ak820_tap_dance_task_now_10000_624'
                                   1457 ;term          Allocated with name '_ak820_tap_dance_task_term_30000_627'
                                   1458 ;------------------------------------------------------------
                                   1459 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:80: void ak820_tap_dance_task(uint16_t now) {
                                   1460 ;	-----------------------------------------
                                   1461 ;	 function ak820_tap_dance_task
                                   1462 ;	-----------------------------------------
      0047B6                       1463 _ak820_tap_dance_task:
      0047B6 AF 83            [24] 1464 	mov	r7,dph
      0047B8 E5 82            [12] 1465 	mov	a,dpl
      0047BA 90 06 46         [24] 1466 	mov	dptr,#_ak820_tap_dance_task_now_10000_624
      0047BD F0               [24] 1467 	movx	@dptr,a
      0047BE EF               [12] 1468 	mov	a,r7
      0047BF A3               [24] 1469 	inc	dptr
      0047C0 F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:81: if (td_pending != TD_NONE) {
      0047C1 90 0E 83         [24] 1472 	mov	dptr,#_td_pending
      0047C4 E0               [24] 1473 	movx	a,@dptr
      0047C5 FF               [12] 1474 	mov	r7,a
      0047C6 BF FF 01         [24] 1475 	cjne	r7,#0xff,00130$
      0047C9 22               [24] 1476 	ret
      0047CA                       1477 00130$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:82: uint16_t term = td_entries[td_pending].custom_tapping_term;
      0047CA EF               [12] 1479 	mov	a,r7
      0047CB 75 F0 0A         [24] 1480 	mov	b,#0x0a
      0047CE A4               [48] 1481 	mul	ab
      0047CF 24 9E            [12] 1482 	add	a, #_td_entries
      0047D1 FD               [12] 1483 	mov	r5,a
      0047D2 74 05            [12] 1484 	mov	a,#(_td_entries >> 8)
      0047D4 35 F0            [12] 1485 	addc	a, b
      0047D6 FE               [12] 1486 	mov	r6,a
      0047D7 74 08            [12] 1487 	mov	a,#0x08
      0047D9 2D               [12] 1488 	add	a, r5
      0047DA F5 82            [12] 1489 	mov	dpl,a
      0047DC E4               [12] 1490 	clr	a
      0047DD 3E               [12] 1491 	addc	a, r6
      0047DE F5 83            [12] 1492 	mov	dph,a
      0047E0 E0               [24] 1493 	movx	a,@dptr
      0047E1 FD               [12] 1494 	mov	r5,a
      0047E2 A3               [24] 1495 	inc	dptr
      0047E3 E0               [24] 1496 	movx	a,@dptr
      0047E4 FE               [12] 1497 	mov	r6,a
      0047E5 90 06 48         [24] 1498 	mov	dptr,#_ak820_tap_dance_task_term_30000_627
      0047E8 ED               [12] 1499 	mov	a,r5
      0047E9 F0               [24] 1500 	movx	@dptr,a
      0047EA EE               [12] 1501 	mov	a,r6
      0047EB A3               [24] 1502 	inc	dptr
      0047EC F0               [24] 1503 	movx	@dptr,a
                                   1504 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:83: if (!term) term = 200;
      0047ED ED               [12] 1505 	mov	a,r5
      0047EE 4E               [12] 1506 	orl	a,r6
      0047EF 70 09            [24] 1507 	jnz	00102$
      0047F1 90 06 48         [24] 1508 	mov	dptr,#_ak820_tap_dance_task_term_30000_627
      0047F4 74 C8            [12] 1509 	mov	a,#0xc8
      0047F6 F0               [24] 1510 	movx	@dptr,a
      0047F7 E4               [12] 1511 	clr	a
      0047F8 A3               [24] 1512 	inc	dptr
      0047F9 F0               [24] 1513 	movx	@dptr,a
      0047FA                       1514 00102$:
                                   1515 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:84: if ((uint16_t)(now - td_time[td_pending]) >= term) td_finish(false);
      0047FA EF               [12] 1516 	mov	a,r7
      0047FB 75 F0 02         [24] 1517 	mov	b,#0x02
      0047FE A4               [48] 1518 	mul	ab
      0047FF 24 EE            [12] 1519 	add	a, #_td_time
      004801 F5 82            [12] 1520 	mov	dpl,a
      004803 74 05            [12] 1521 	mov	a,#(_td_time >> 8)
      004805 35 F0            [12] 1522 	addc	a, b
      004807 F5 83            [12] 1523 	mov	dph,a
      004809 E0               [24] 1524 	movx	a,@dptr
      00480A FE               [12] 1525 	mov	r6,a
      00480B A3               [24] 1526 	inc	dptr
      00480C E0               [24] 1527 	movx	a,@dptr
      00480D FF               [12] 1528 	mov	r7,a
      00480E 90 06 46         [24] 1529 	mov	dptr,#_ak820_tap_dance_task_now_10000_624
      004811 E0               [24] 1530 	movx	a,@dptr
      004812 FC               [12] 1531 	mov	r4,a
      004813 A3               [24] 1532 	inc	dptr
      004814 E0               [24] 1533 	movx	a,@dptr
      004815 FD               [12] 1534 	mov	r5,a
      004816 EC               [12] 1535 	mov	a,r4
      004817 C3               [12] 1536 	clr	c
      004818 9E               [12] 1537 	subb	a,r6
      004819 FE               [12] 1538 	mov	r6,a
      00481A ED               [12] 1539 	mov	a,r5
      00481B 9F               [12] 1540 	subb	a,r7
      00481C FF               [12] 1541 	mov	r7,a
      00481D 90 06 48         [24] 1542 	mov	dptr,#_ak820_tap_dance_task_term_30000_627
      004820 E0               [24] 1543 	movx	a,@dptr
      004821 FC               [12] 1544 	mov	r4,a
      004822 A3               [24] 1545 	inc	dptr
      004823 E0               [24] 1546 	movx	a,@dptr
      004824 FD               [12] 1547 	mov	r5,a
      004825 C3               [12] 1548 	clr	c
      004826 EE               [12] 1549 	mov	a,r6
      004827 9C               [12] 1550 	subb	a,r4
      004828 EF               [12] 1551 	mov	a,r7
      004829 9D               [12] 1552 	subb	a,r5
      00482A 40 06            [24] 1553 	jc	00107$
      00482C 75 82 00         [24] 1554 	mov	dpl, #0x00
                                   1555 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:86: }
      00482F 02 45 3F         [24] 1556 	ljmp	_td_finish
      004832                       1557 00107$:
      004832 22               [24] 1558 	ret
                                   1559 ;------------------------------------------------------------
                                   1560 ;Allocation info for local variables in function 'ak820_tap_dance_before'
                                   1561 ;------------------------------------------------------------
                                   1562 ;event         Allocated with name '_ak820_tap_dance_before_event_10000_630'
                                   1563 ;id            Allocated with name '_ak820_tap_dance_before_id_10000_631'
                                   1564 ;i             Allocated with name '_ak820_tap_dance_before_i_20000_640'
                                   1565 ;------------------------------------------------------------
                                   1566 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:87: bool ak820_tap_dance_before(const keyevent_t AK820_STATE_MEM *event) {
                                   1567 ;	-----------------------------------------
                                   1568 ;	 function ak820_tap_dance_before
                                   1569 ;	-----------------------------------------
      004833                       1570 _ak820_tap_dance_before:
      004833 AF 83            [24] 1571 	mov	r7,dph
      004835 E5 82            [12] 1572 	mov	a,dpl
      004837 90 06 4A         [24] 1573 	mov	dptr,#_ak820_tap_dance_before_event_10000_630
      00483A F0               [24] 1574 	movx	@dptr,a
      00483B EF               [12] 1575 	mov	a,r7
      00483C A3               [24] 1576 	inc	dptr
      00483D F0               [24] 1577 	movx	@dptr,a
                                   1578 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:89: ak820_tap_dance_task(event->time);
      00483E 90 06 4A         [24] 1579 	mov	dptr,#_ak820_tap_dance_before_event_10000_630
      004841 E0               [24] 1580 	movx	a,@dptr
      004842 FE               [12] 1581 	mov	r6,a
      004843 A3               [24] 1582 	inc	dptr
      004844 E0               [24] 1583 	movx	a,@dptr
      004845 FF               [12] 1584 	mov	r7,a
      004846 8E 82            [24] 1585 	mov	dpl,r6
      004848 8F 83            [24] 1586 	mov	dph,r7
      00484A A3               [24] 1587 	inc	dptr
      00484B A3               [24] 1588 	inc	dptr
      00484C E0               [24] 1589 	movx	a,@dptr
      00484D FC               [12] 1590 	mov	r4,a
      00484E A3               [24] 1591 	inc	dptr
      00484F E0               [24] 1592 	movx	a,@dptr
      004850 FD               [12] 1593 	mov	r5,a
      004851 8C 82            [24] 1594 	mov	dpl, r4
      004853 8D 83            [24] 1595 	mov	dph, r5
      004855 C0 07            [24] 1596 	push	ar7
      004857 C0 06            [24] 1597 	push	ar6
      004859 12 47 B6         [24] 1598 	lcall	_ak820_tap_dance_task
      00485C D0 06            [24] 1599 	pop	ar6
      00485E D0 07            [24] 1600 	pop	ar7
                                   1601 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:90: if (IS_NOEVENT(*event)) return true;
      004860 74 04            [12] 1602 	mov	a,#0x04
      004862 2E               [12] 1603 	add	a, r6
      004863 FC               [12] 1604 	mov	r4,a
      004864 E4               [12] 1605 	clr	a
      004865 3F               [12] 1606 	addc	a, r7
      004866 FD               [12] 1607 	mov	r5,a
      004867 8C 82            [24] 1608 	mov	dpl,r4
      004869 8D 83            [24] 1609 	mov	dph,r5
      00486B E0               [24] 1610 	movx	a,@dptr
      00486C 70 04            [24] 1611 	jnz	00102$
      00486E 75 82 01         [24] 1612 	mov	dpl, #0x01
      004871 22               [24] 1613 	ret
      004872                       1614 00102$:
                                   1615 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:91: if (event->key.row >= MATRIX_ROWS || event->key.col >= MATRIX_COLS) {
      004872 8E 82            [24] 1616 	mov	dpl,r6
      004874 8F 83            [24] 1617 	mov	dph,r7
      004876 A3               [24] 1618 	inc	dptr
      004877 E0               [24] 1619 	movx	a,@dptr
      004878 FD               [12] 1620 	mov	r5,a
      004879 BD 10 00         [24] 1621 	cjne	r5,#0x10,00229$
      00487C                       1622 00229$:
      00487C 50 0B            [24] 1623 	jnc	00105$
      00487E 8E 82            [24] 1624 	mov	dpl,r6
      004880 8F 83            [24] 1625 	mov	dph,r7
      004882 E0               [24] 1626 	movx	a,@dptr
      004883 FC               [12] 1627 	mov	r4,a
      004884 BC 08 00         [24] 1628 	cjne	r4,#0x08,00231$
      004887                       1629 00231$:
      004887 40 20            [24] 1630 	jc	00106$
      004889                       1631 00105$:
                                   1632 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:92: if (event->pressed) td_finish(true);
      004889 90 06 4A         [24] 1633 	mov	dptr,#_ak820_tap_dance_before_event_10000_630
      00488C E0               [24] 1634 	movx	a,@dptr
      00488D FA               [12] 1635 	mov	r2,a
      00488E A3               [24] 1636 	inc	dptr
      00488F E0               [24] 1637 	movx	a,@dptr
      004890 FB               [12] 1638 	mov	r3,a
      004891 74 05            [12] 1639 	mov	a,#0x05
      004893 2A               [12] 1640 	add	a, r2
      004894 FA               [12] 1641 	mov	r2,a
      004895 E4               [12] 1642 	clr	a
      004896 3B               [12] 1643 	addc	a, r3
      004897 FB               [12] 1644 	mov	r3,a
      004898 8A 82            [24] 1645 	mov	dpl,r2
      00489A 8B 83            [24] 1646 	mov	dph,r3
      00489C E0               [24] 1647 	movx	a,@dptr
      00489D 60 06            [24] 1648 	jz	00104$
      00489F 75 82 01         [24] 1649 	mov	dpl, #0x01
      0048A2 12 45 3F         [24] 1650 	lcall	_td_finish
      0048A5                       1651 00104$:
                                   1652 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:93: return true;
      0048A5 75 82 01         [24] 1653 	mov	dpl, #0x01
      0048A8 22               [24] 1654 	ret
      0048A9                       1655 00106$:
                                   1656 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:95: id = event->key.row * MATRIX_COLS + event->key.col;
      0048A9 ED               [12] 1657 	mov	a,r5
      0048AA C4               [12] 1658 	swap	a
      0048AB 03               [12] 1659 	rr	a
      0048AC 54 F8            [12] 1660 	anl	a,#0xf8
                                   1661 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:96: if (td_suppressed[id >> 3] & (1u << (id & 7))) {
      0048AE 2C               [12] 1662 	add	a,r4
      0048AF FD               [12] 1663 	mov	r5,a
      0048B0 C4               [12] 1664 	swap	a
      0048B1 23               [12] 1665 	rl	a
      0048B2 54 1F            [12] 1666 	anl	a,#0x1f
      0048B4 24 1E            [12] 1667 	add	a, #_td_suppressed
      0048B6 F5 82            [12] 1668 	mov	dpl,a
      0048B8 E4               [12] 1669 	clr	a
      0048B9 34 06            [12] 1670 	addc	a, #(_td_suppressed >> 8)
      0048BB F5 83            [12] 1671 	mov	dph,a
      0048BD E0               [24] 1672 	movx	a,@dptr
      0048BE FC               [12] 1673 	mov	r4,a
      0048BF 74 07            [12] 1674 	mov	a,#0x07
      0048C1 5D               [12] 1675 	anl	a,r5
      0048C2 F5 F0            [12] 1676 	mov	b, a
      0048C4 05 F0            [12] 1677 	inc	b
      0048C6 7B 01            [12] 1678 	mov	r3,#0x01
      0048C8 7A 00            [12] 1679 	mov	r2,#0x00
      0048CA 80 06            [24] 1680 	sjmp	00235$
      0048CC                       1681 00234$:
      0048CC EB               [12] 1682 	mov	a,r3
      0048CD 2B               [12] 1683 	add	a,r3
      0048CE FB               [12] 1684 	mov	r3,a
      0048CF EA               [12] 1685 	mov	a,r2
      0048D0 33               [12] 1686 	rlc	a
      0048D1 FA               [12] 1687 	mov	r2,a
      0048D2                       1688 00235$:
      0048D2 D5 F0 F7         [24] 1689 	djnz	b,00234$
      0048D5 8C 01            [24] 1690 	mov	ar1,r4
      0048D7 7C 00            [12] 1691 	mov	r4,#0x00
      0048D9 E9               [12] 1692 	mov	a,r1
      0048DA 52 03            [12] 1693 	anl	ar3,a
      0048DC EC               [12] 1694 	mov	a,r4
      0048DD 52 02            [12] 1695 	anl	ar2,a
      0048DF EB               [12] 1696 	mov	a,r3
      0048E0 4A               [12] 1697 	orl	a,r2
      0048E1 60 4B            [24] 1698 	jz	00111$
                                   1699 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:97: if (!event->pressed) td_suppressed[id >> 3] &= ~(1u << (id & 7));
      0048E3 74 05            [12] 1700 	mov	a,#0x05
      0048E5 2E               [12] 1701 	add	a, r6
      0048E6 FB               [12] 1702 	mov	r3,a
      0048E7 E4               [12] 1703 	clr	a
      0048E8 3F               [12] 1704 	addc	a, r7
      0048E9 FC               [12] 1705 	mov	r4,a
      0048EA 8B 82            [24] 1706 	mov	dpl,r3
      0048EC 8C 83            [24] 1707 	mov	dph,r4
      0048EE E0               [24] 1708 	movx	a,@dptr
      0048EF 70 39            [24] 1709 	jnz	00109$
      0048F1 8D 04            [24] 1710 	mov	ar4,r5
      0048F3 EC               [12] 1711 	mov	a,r4
      0048F4 C4               [12] 1712 	swap	a
      0048F5 23               [12] 1713 	rl	a
      0048F6 54 1F            [12] 1714 	anl	a,#0x1f
      0048F8 24 1E            [12] 1715 	add	a,#_td_suppressed
      0048FA FC               [12] 1716 	mov	r4,a
      0048FB E4               [12] 1717 	clr	a
      0048FC 34 06            [12] 1718 	addc	a, #(_td_suppressed >> 8)
      0048FE FB               [12] 1719 	mov	r3,a
      0048FF 8D 02            [24] 1720 	mov	ar2,r5
      004901 EA               [12] 1721 	mov	a,r2
      004902 C4               [12] 1722 	swap	a
      004903 23               [12] 1723 	rl	a
      004904 54 1F            [12] 1724 	anl	a,#0x1f
      004906 24 1E            [12] 1725 	add	a, #_td_suppressed
      004908 F5 82            [12] 1726 	mov	dpl,a
      00490A E4               [12] 1727 	clr	a
      00490B 34 06            [12] 1728 	addc	a, #(_td_suppressed >> 8)
      00490D F5 83            [12] 1729 	mov	dph,a
      00490F E0               [24] 1730 	movx	a,@dptr
      004910 FA               [12] 1731 	mov	r2,a
      004911 74 07            [12] 1732 	mov	a,#0x07
      004913 5D               [12] 1733 	anl	a,r5
      004914 F5 F0            [12] 1734 	mov	b,a
      004916 05 F0            [12] 1735 	inc	b
      004918 74 01            [12] 1736 	mov	a,#0x01
      00491A 80 02            [24] 1737 	sjmp	00239$
      00491C                       1738 00238$:
      00491C 25 E0            [12] 1739 	add	a,acc
      00491E                       1740 00239$:
      00491E D5 F0 FB         [24] 1741 	djnz	b,00238$
      004921 F4               [12] 1742 	cpl	a
      004922 52 02            [12] 1743 	anl	ar2,a
      004924 8C 82            [24] 1744 	mov	dpl,r4
      004926 8B 83            [24] 1745 	mov	dph,r3
      004928 EA               [12] 1746 	mov	a,r2
      004929 F0               [24] 1747 	movx	@dptr,a
      00492A                       1748 00109$:
                                   1749 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:98: return false;
      00492A 75 82 00         [24] 1750 	mov	dpl, #0x00
      00492D 22               [24] 1751 	ret
      00492E                       1752 00111$:
                                   1753 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:100: if (event->pressed && td_pending != TD_NONE &&
      00492E 74 05            [12] 1754 	mov	a,#0x05
      004930 2E               [12] 1755 	add	a, r6
      004931 FE               [12] 1756 	mov	r6,a
      004932 E4               [12] 1757 	clr	a
      004933 3F               [12] 1758 	addc	a, r7
      004934 FF               [12] 1759 	mov	r7,a
      004935 8E 82            [24] 1760 	mov	dpl,r6
      004937 8F 83            [24] 1761 	mov	dph,r7
      004939 E0               [24] 1762 	movx	a,@dptr
      00493A 60 34            [24] 1763 	jz	00157$
      00493C 90 0E 83         [24] 1764 	mov	dptr,#_td_pending
      00493F E0               [24] 1765 	movx	a,@dptr
      004940 FF               [12] 1766 	mov	r7,a
      004941 BF FF 02         [24] 1767 	cjne	r7,#0xff,00241$
      004944 80 2A            [24] 1768 	sjmp	00157$
      004946                       1769 00241$:
                                   1770 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:101: (td_source[td_pending] != id || (td_state[td_pending] & 3) == 2)) td_finish(true);
      004946 EF               [12] 1771 	mov	a,r7
      004947 24 0E            [12] 1772 	add	a, #_td_source
      004949 F5 82            [12] 1773 	mov	dpl,a
      00494B E4               [12] 1774 	clr	a
      00494C 34 06            [12] 1775 	addc	a, #(_td_source >> 8)
      00494E F5 83            [12] 1776 	mov	dph,a
      004950 E0               [24] 1777 	movx	a,@dptr
      004951 B5 05 12         [24] 1778 	cjne	a,ar5,00112$
      004954 EF               [12] 1779 	mov	a,r7
      004955 24 16            [12] 1780 	add	a, #_td_state
      004957 F5 82            [12] 1781 	mov	dpl,a
      004959 E4               [12] 1782 	clr	a
      00495A 34 06            [12] 1783 	addc	a, #(_td_state >> 8)
      00495C F5 83            [12] 1784 	mov	dph,a
      00495E E0               [24] 1785 	movx	a,@dptr
      00495F FF               [12] 1786 	mov	r7,a
      004960 53 07 03         [24] 1787 	anl	ar7,#0x03
      004963 BF 02 0A         [24] 1788 	cjne	r7,#0x02,00157$
      004966                       1789 00112$:
      004966 75 82 01         [24] 1790 	mov	dpl, #0x01
      004969 C0 05            [24] 1791 	push	ar5
      00496B 12 45 3F         [24] 1792 	lcall	_td_finish
      00496E D0 05            [24] 1793 	pop	ar5
                                   1794 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      004970                       1795 00157$:
      004970 7F 00            [12] 1796 	mov	r7,#0x00
      004972                       1797 00127$:
      004972 BF 08 00         [24] 1798 	cjne	r7,#0x08,00246$
      004975                       1799 00246$:
      004975 40 03            [24] 1800 	jc	00247$
      004977 02 4A 06         [24] 1801 	ljmp	00125$
      00497A                       1802 00247$:
                                   1803 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:103: if (!td_state[i] || td_source[i] != id) continue;
      00497A EF               [12] 1804 	mov	a,r7
      00497B 24 16            [12] 1805 	add	a, #_td_state
      00497D FC               [12] 1806 	mov	r4,a
      00497E E4               [12] 1807 	clr	a
      00497F 34 06            [12] 1808 	addc	a, #(_td_state >> 8)
      004981 FE               [12] 1809 	mov	r6,a
      004982 8C 82            [24] 1810 	mov	dpl,r4
      004984 8E 83            [24] 1811 	mov	dph,r6
      004986 E0               [24] 1812 	movx	a,@dptr
      004987 FB               [12] 1813 	mov	r3,a
      004988 60 78            [24] 1814 	jz	00124$
      00498A EF               [12] 1815 	mov	a,r7
      00498B 24 0E            [12] 1816 	add	a, #_td_source
      00498D F5 82            [12] 1817 	mov	dpl,a
      00498F E4               [12] 1818 	clr	a
      004990 34 06            [12] 1819 	addc	a, #(_td_source >> 8)
      004992 F5 83            [12] 1820 	mov	dph,a
      004994 E0               [24] 1821 	movx	a,@dptr
      004995 B5 05 6A         [24] 1822 	cjne	a,ar5,00124$
                                   1823 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:104: if (event->pressed) return !(td_state[i] & TD_DONE);
      004998 90 06 4A         [24] 1824 	mov	dptr,#_ak820_tap_dance_before_event_10000_630
      00499B E0               [24] 1825 	movx	a,@dptr
      00499C F9               [12] 1826 	mov	r1,a
      00499D A3               [24] 1827 	inc	dptr
      00499E E0               [24] 1828 	movx	a,@dptr
      00499F FA               [12] 1829 	mov	r2,a
      0049A0 74 05            [12] 1830 	mov	a,#0x05
      0049A2 29               [12] 1831 	add	a, r1
      0049A3 F9               [12] 1832 	mov	r1,a
      0049A4 E4               [12] 1833 	clr	a
      0049A5 3A               [12] 1834 	addc	a, r2
      0049A6 FA               [12] 1835 	mov	r2,a
      0049A7 89 82            [24] 1836 	mov	dpl,r1
      0049A9 8A 83            [24] 1837 	mov	dph,r2
      0049AB E0               [24] 1838 	movx	a,@dptr
      0049AC 60 0F            [24] 1839 	jz	00121$
      0049AE EB               [12] 1840 	mov	a,r3
      0049AF A2 E3            [12] 1841 	mov	c,acc.3
      0049B1 E4               [12] 1842 	clr	a
      0049B2 33               [12] 1843 	rlc	a
      0049B3 B4 01 00         [24] 1844 	cjne	a,#0x01,00252$
      0049B6                       1845 00252$:
      0049B6 92 10            [24] 1846 	mov  _ak820_tap_dance_before_sloc0_1_0,c
      0049B8 E4               [12] 1847 	clr	a
      0049B9 33               [12] 1848 	rlc	a
      0049BA F5 82            [12] 1849 	mov	dpl, a
      0049BC 22               [24] 1850 	ret
      0049BD                       1851 00121$:
                                   1852 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:105: td_state[i] &= ~TD_DOWN;
      0049BD 53 03 FB         [24] 1853 	anl	ar3,#0xfb
      0049C0 8C 82            [24] 1854 	mov	dpl,r4
      0049C2 8E 83            [24] 1855 	mov	dph,r6
      0049C4 EB               [12] 1856 	mov	a,r3
      0049C5 F0               [24] 1857 	movx	@dptr,a
                                   1858 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:106: if (td_state[i] & TD_DONE) {
      0049C6 EB               [12] 1859 	mov	a,r3
      0049C7 30 E3 34         [24] 1860 	jnb	acc.3,00123$
                                   1861 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:107: td_emit(i, td_output[i], false);
      0049CA EF               [12] 1862 	mov	a,r7
      0049CB 75 F0 02         [24] 1863 	mov	b,#0x02
      0049CE A4               [48] 1864 	mul	ab
      0049CF 24 FE            [12] 1865 	add	a, #_td_output
      0049D1 F5 82            [12] 1866 	mov	dpl,a
      0049D3 74 05            [12] 1867 	mov	a,#(_td_output >> 8)
      0049D5 35 F0            [12] 1868 	addc	a, b
      0049D7 F5 83            [12] 1869 	mov	dph,a
      0049D9 E0               [24] 1870 	movx	a,@dptr
      0049DA FA               [12] 1871 	mov	r2,a
      0049DB A3               [24] 1872 	inc	dptr
      0049DC E0               [24] 1873 	movx	a,@dptr
      0049DD FB               [12] 1874 	mov	r3,a
      0049DE 90 06 3B         [24] 1875 	mov	dptr,#_td_emit_PARM_2
      0049E1 EA               [12] 1876 	mov	a,r2
      0049E2 F0               [24] 1877 	movx	@dptr,a
      0049E3 EB               [12] 1878 	mov	a,r3
      0049E4 A3               [24] 1879 	inc	dptr
      0049E5 F0               [24] 1880 	movx	@dptr,a
      0049E6 90 06 3D         [24] 1881 	mov	dptr,#_td_emit_PARM_3
      0049E9 E4               [12] 1882 	clr	a
      0049EA F0               [24] 1883 	movx	@dptr,a
      0049EB 8F 82            [24] 1884 	mov	dpl, r7
      0049ED C0 06            [24] 1885 	push	ar6
      0049EF C0 04            [24] 1886 	push	ar4
      0049F1 12 44 68         [24] 1887 	lcall	_td_emit
      0049F4 D0 04            [24] 1888 	pop	ar4
      0049F6 D0 06            [24] 1889 	pop	ar6
                                   1890 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:108: td_state[i] = 0;
      0049F8 8C 82            [24] 1891 	mov	dpl,r4
      0049FA 8E 83            [24] 1892 	mov	dph,r6
      0049FC E4               [12] 1893 	clr	a
      0049FD F0               [24] 1894 	movx	@dptr,a
      0049FE                       1895 00123$:
                                   1896 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:110: return false;
      0049FE 75 82 00         [24] 1897 	mov	dpl, #0x00
      004A01 22               [24] 1898 	ret
      004A02                       1899 00124$:
                                   1900 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      004A02 0F               [12] 1901 	inc	r7
      004A03 02 49 72         [24] 1902 	ljmp	00127$
      004A06                       1903 00125$:
                                   1904 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:112: return true;
      004A06 75 82 01         [24] 1905 	mov	dpl, #0x01
                                   1906 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:113: }
      004A09 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'ak820_tap_dance_process'
                                   1910 ;------------------------------------------------------------
                                   1911 ;sloc0         Allocated with name '_ak820_tap_dance_process_sloc0_1_0'
                                   1912 ;record        Allocated with name '_ak820_tap_dance_process_record_10000_646'
                                   1913 ;slot          Allocated with name '_ak820_tap_dance_process_slot_10000_647'
                                   1914 ;id            Allocated with name '_ak820_tap_dance_process_id_10000_647'
                                   1915 ;------------------------------------------------------------
                                   1916 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:114: bool ak820_tap_dance_process(keyrecord_t AK820_STATE_MEM *record) {
                                   1917 ;	-----------------------------------------
                                   1918 ;	 function ak820_tap_dance_process
                                   1919 ;	-----------------------------------------
      004A0A                       1920 _ak820_tap_dance_process:
      004A0A AF 83            [24] 1921 	mov	r7,dph
      004A0C E5 82            [12] 1922 	mov	a,dpl
      004A0E 90 06 4C         [24] 1923 	mov	dptr,#_ak820_tap_dance_process_record_10000_646
      004A11 F0               [24] 1924 	movx	@dptr,a
      004A12 EF               [12] 1925 	mov	a,r7
      004A13 A3               [24] 1926 	inc	dptr
      004A14 F0               [24] 1927 	movx	@dptr,a
                                   1928 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:118: if (record->event.type == KEY_EVENT && record->event.key.row < MATRIX_ROWS &&
      004A15 90 06 4C         [24] 1929 	mov	dptr,#_ak820_tap_dance_process_record_10000_646
      004A18 E0               [24] 1930 	movx	a,@dptr
      004A19 FE               [12] 1931 	mov	r6,a
      004A1A A3               [24] 1932 	inc	dptr
      004A1B E0               [24] 1933 	movx	a,@dptr
      004A1C FF               [12] 1934 	mov	r7,a
      004A1D 8E 82            [24] 1935 	mov	dpl,r6
      004A1F 8F 83            [24] 1936 	mov	dph,r7
      004A21 A3               [24] 1937 	inc	dptr
      004A22 A3               [24] 1938 	inc	dptr
      004A23 A3               [24] 1939 	inc	dptr
      004A24 A3               [24] 1940 	inc	dptr
      004A25 E0               [24] 1941 	movx	a,@dptr
      004A26 FD               [12] 1942 	mov	r5,a
      004A27 BD 01 02         [24] 1943 	cjne	r5,#0x01,00258$
      004A2A 80 03            [24] 1944 	sjmp	00259$
      004A2C                       1945 00258$:
      004A2C 02 4A C2         [24] 1946 	ljmp	00102$
      004A2F                       1947 00259$:
      004A2F 8E 82            [24] 1948 	mov	dpl,r6
      004A31 8F 83            [24] 1949 	mov	dph,r7
      004A33 A3               [24] 1950 	inc	dptr
      004A34 E0               [24] 1951 	movx	a,@dptr
      004A35 FD               [12] 1952 	mov	r5,a
      004A36 BD 10 00         [24] 1953 	cjne	r5,#0x10,00260$
      004A39                       1954 00260$:
      004A39 40 03            [24] 1955 	jc	00261$
      004A3B 02 4A C2         [24] 1956 	ljmp	00102$
      004A3E                       1957 00261$:
                                   1958 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:119: record->event.key.col < MATRIX_COLS && record->event.pressed && td_pending != TD_NONE &&
      004A3E 8E 82            [24] 1959 	mov	dpl,r6
      004A40 8F 83            [24] 1960 	mov	dph,r7
      004A42 E0               [24] 1961 	movx	a,@dptr
      004A43 FC               [12] 1962 	mov	r4,a
      004A44 BC 08 00         [24] 1963 	cjne	r4,#0x08,00262$
      004A47                       1964 00262$:
      004A47 50 79            [24] 1965 	jnc	00102$
      004A49 74 05            [12] 1966 	mov	a,#0x05
      004A4B 2E               [12] 1967 	add	a, r6
      004A4C FA               [12] 1968 	mov	r2,a
      004A4D E4               [12] 1969 	clr	a
      004A4E 3F               [12] 1970 	addc	a, r7
      004A4F FB               [12] 1971 	mov	r3,a
      004A50 8A 82            [24] 1972 	mov	dpl,r2
      004A52 8B 83            [24] 1973 	mov	dph,r3
      004A54 E0               [24] 1974 	movx	a,@dptr
      004A55 60 6B            [24] 1975 	jz	00102$
      004A57 90 0E 83         [24] 1976 	mov	dptr,#_td_pending
      004A5A E0               [24] 1977 	movx	a,@dptr
      004A5B FB               [12] 1978 	mov	r3,a
      004A5C BB FF 02         [24] 1979 	cjne	r3,#0xff,00265$
      004A5F 80 61            [24] 1980 	sjmp	00102$
      004A61                       1981 00265$:
                                   1982 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:120: !(td_state[td_pending] & TD_DOWN) &&
      004A61 EB               [12] 1983 	mov	a,r3
      004A62 24 16            [12] 1984 	add	a, #_td_state
      004A64 F5 82            [12] 1985 	mov	dpl,a
      004A66 E4               [12] 1986 	clr	a
      004A67 34 06            [12] 1987 	addc	a, #(_td_state >> 8)
      004A69 F5 83            [12] 1988 	mov	dph,a
      004A6B E0               [24] 1989 	movx	a,@dptr
      004A6C 20 E2 53         [24] 1990 	jb	acc.2,00102$
                                   1991 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:121: td_source[td_pending] == record->event.key.row * MATRIX_COLS + record->event.key.col &&
      004A6F EB               [12] 1992 	mov	a,r3
      004A70 24 0E            [12] 1993 	add	a, #_td_source
      004A72 F5 82            [12] 1994 	mov	dpl,a
      004A74 E4               [12] 1995 	clr	a
      004A75 34 06            [12] 1996 	addc	a, #(_td_source >> 8)
      004A77 F5 83            [12] 1997 	mov	dph,a
      004A79 E0               [24] 1998 	movx	a,@dptr
      004A7A FA               [12] 1999 	mov	r2,a
      004A7B 8D 01            [24] 2000 	mov	ar1,r5
      004A7D E4               [12] 2001 	clr	a
      004A7E 03               [12] 2002 	rr	a
      004A7F 54 F8            [12] 2003 	anl	a,#0xf8
      004A81 C9               [12] 2004 	xch	a,r1
      004A82 C4               [12] 2005 	swap	a
      004A83 03               [12] 2006 	rr	a
      004A84 C9               [12] 2007 	xch	a,r1
      004A85 69               [12] 2008 	xrl	a,r1
      004A86 C9               [12] 2009 	xch	a,r1
      004A87 54 F8            [12] 2010 	anl	a,#0xf8
      004A89 C9               [12] 2011 	xch	a,r1
      004A8A 69               [12] 2012 	xrl	a,r1
      004A8B FD               [12] 2013 	mov	r5,a
      004A8C 8C 00            [24] 2014 	mov	ar0,r4
      004A8E 7C 00            [12] 2015 	mov	r4,#0x00
      004A90 E8               [12] 2016 	mov	a,r0
      004A91 29               [12] 2017 	add	a, r1
      004A92 F9               [12] 2018 	mov	r1,a
      004A93 EC               [12] 2019 	mov	a,r4
      004A94 3D               [12] 2020 	addc	a, r5
      004A95 FD               [12] 2021 	mov	r5,a
      004A96 EA               [12] 2022 	mov	a,r2
      004A97 B5 01 28         [24] 2023 	cjne	a,ar1,00102$
      004A9A EC               [12] 2024 	mov	a,r4
      004A9B B5 05 24         [24] 2025 	cjne	a,ar5,00102$
                                   2026 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:122: record->keycode != QK_TAP_DANCE + td_pending) td_finish(true);
      004A9E 74 07            [12] 2027 	mov	a,#0x07
      004AA0 2E               [12] 2028 	add	a, r6
      004AA1 F5 82            [12] 2029 	mov	dpl,a
      004AA3 E4               [12] 2030 	clr	a
      004AA4 3F               [12] 2031 	addc	a, r7
      004AA5 F5 83            [12] 2032 	mov	dph,a
      004AA7 E0               [24] 2033 	movx	a,@dptr
      004AA8 FE               [12] 2034 	mov	r6,a
      004AA9 A3               [24] 2035 	inc	dptr
      004AAA E0               [24] 2036 	movx	a,@dptr
      004AAB FF               [12] 2037 	mov	r7,a
      004AAC 7D 00            [12] 2038 	mov	r5,#0x00
      004AAE 74 57            [12] 2039 	mov	a,#0x57
      004AB0 2D               [12] 2040 	add	a, r5
      004AB1 FD               [12] 2041 	mov	r5,a
      004AB2 EE               [12] 2042 	mov	a,r6
      004AB3 B5 03 06         [24] 2043 	cjne	a,ar3,00269$
      004AB6 EF               [12] 2044 	mov	a,r7
      004AB7 B5 05 02         [24] 2045 	cjne	a,ar5,00269$
      004ABA 80 06            [24] 2046 	sjmp	00102$
      004ABC                       2047 00269$:
      004ABC 75 82 01         [24] 2048 	mov	dpl, #0x01
      004ABF 12 45 3F         [24] 2049 	lcall	_td_finish
      004AC2                       2050 00102$:
                                   2051 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:123: if (record->keycode < QK_TAP_DANCE || record->keycode > QK_TAP_DANCE_MAX) return true;
      004AC2 90 06 4C         [24] 2052 	mov	dptr,#_ak820_tap_dance_process_record_10000_646
      004AC5 E0               [24] 2053 	movx	a,@dptr
      004AC6 FE               [12] 2054 	mov	r6,a
      004AC7 A3               [24] 2055 	inc	dptr
      004AC8 E0               [24] 2056 	movx	a,@dptr
      004AC9 FF               [12] 2057 	mov	r7,a
      004ACA 74 07            [12] 2058 	mov	a,#0x07
      004ACC 2E               [12] 2059 	add	a, r6
      004ACD FC               [12] 2060 	mov	r4,a
      004ACE E4               [12] 2061 	clr	a
      004ACF 3F               [12] 2062 	addc	a, r7
      004AD0 FD               [12] 2063 	mov	r5,a
      004AD1 8C 82            [24] 2064 	mov	dpl,r4
      004AD3 8D 83            [24] 2065 	mov	dph,r5
      004AD5 E0               [24] 2066 	movx	a,@dptr
      004AD6 FA               [12] 2067 	mov	r2,a
      004AD7 A3               [24] 2068 	inc	dptr
      004AD8 E0               [24] 2069 	movx	a,@dptr
      004AD9 FB               [12] 2070 	mov	r3,a
      004ADA C3               [12] 2071 	clr	c
      004ADB 94 57            [12] 2072 	subb	a,#0x57
      004ADD 40 08            [24] 2073 	jc	00110$
      004ADF 74 FF            [12] 2074 	mov	a,#0xff
      004AE1 9A               [12] 2075 	subb	a,r2
      004AE2 74 57            [12] 2076 	mov	a,#0x57
      004AE4 9B               [12] 2077 	subb	a,r3
      004AE5 50 04            [24] 2078 	jnc	00111$
                                   2079 ;	free result
      004AE7                       2080 00110$:
      004AE7 75 82 01         [24] 2081 	mov	dpl, #0x01
      004AEA 22               [24] 2082 	ret
      004AEB                       2083 00111$:
                                   2084 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:125: if (record->event.type != KEY_EVENT || record->event.key.row >= MATRIX_ROWS ||
      004AEB 8E 82            [24] 2085 	mov	dpl,r6
      004AED 8F 83            [24] 2086 	mov	dph,r7
      004AEF A3               [24] 2087 	inc	dptr
      004AF0 A3               [24] 2088 	inc	dptr
      004AF1 A3               [24] 2089 	inc	dptr
      004AF2 A3               [24] 2090 	inc	dptr
      004AF3 E0               [24] 2091 	movx	a,@dptr
      004AF4 FB               [12] 2092 	mov	r3,a
      004AF5 BB 01 56         [24] 2093 	cjne	r3,#0x01,00113$
      004AF8 74 01            [12] 2094 	mov	a,#0x01
      004AFA 2E               [12] 2095 	add	a, r6
      004AFB FA               [12] 2096 	mov	r2,a
      004AFC E4               [12] 2097 	clr	a
      004AFD 3F               [12] 2098 	addc	a, r7
      004AFE FB               [12] 2099 	mov	r3,a
      004AFF 8A 82            [24] 2100 	mov	dpl,r2
      004B01 8B 83            [24] 2101 	mov	dph,r3
      004B03 E0               [24] 2102 	movx	a,@dptr
      004B04 F9               [12] 2103 	mov	r1,a
      004B05 B9 10 00         [24] 2104 	cjne	r1,#0x10,00274$
      004B08                       2105 00274$:
      004B08 50 44            [24] 2106 	jnc	00113$
                                   2107 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:126: record->event.key.col >= MATRIX_COLS || get_repeat_key_count() || ak820_macro_primitive) return false;
      004B0A C0 02            [24] 2108 	push	ar2
      004B0C C0 03            [24] 2109 	push	ar3
      004B0E 8E 00            [24] 2110 	mov	ar0,r6
      004B10 8F 01            [24] 2111 	mov	ar1,r7
      004B12 88 82            [24] 2112 	mov	dpl,r0
      004B14 89 83            [24] 2113 	mov	dph,r1
      004B16 E0               [24] 2114 	movx	a,@dptr
      004B17 FB               [12] 2115 	mov	r3,a
      004B18 BB 08 00         [24] 2116 	cjne	r3,#0x08,00276$
      004B1B                       2117 00276$:
      004B1B D0 03            [24] 2118 	pop	ar3
      004B1D D0 02            [24] 2119 	pop	ar2
      004B1F 50 2D            [24] 2120 	jnc	00113$
      004B21 C0 07            [24] 2121 	push	ar7
      004B23 C0 06            [24] 2122 	push	ar6
      004B25 C0 05            [24] 2123 	push	ar5
      004B27 C0 04            [24] 2124 	push	ar4
      004B29 C0 03            [24] 2125 	push	ar3
      004B2B C0 02            [24] 2126 	push	ar2
      004B2D C0 01            [24] 2127 	push	ar1
      004B2F C0 00            [24] 2128 	push	ar0
      004B31 12 AB D5         [24] 2129 	lcall	_get_repeat_key_count
      004B34 E5 82            [12] 2130 	mov	a, dpl
      004B36 D0 00            [24] 2131 	pop	ar0
      004B38 D0 01            [24] 2132 	pop	ar1
      004B3A D0 02            [24] 2133 	pop	ar2
      004B3C D0 03            [24] 2134 	pop	ar3
      004B3E D0 04            [24] 2135 	pop	ar4
      004B40 D0 05            [24] 2136 	pop	ar5
      004B42 D0 06            [24] 2137 	pop	ar6
      004B44 D0 07            [24] 2138 	pop	ar7
      004B46 70 06            [24] 2139 	jnz	00113$
      004B48 90 0A 33         [24] 2140 	mov	dptr,#_ak820_macro_primitive
      004B4B E0               [24] 2141 	movx	a,@dptr
      004B4C 60 04            [24] 2142 	jz	00114$
      004B4E                       2143 00113$:
      004B4E 75 82 00         [24] 2144 	mov	dpl, #0x00
      004B51 22               [24] 2145 	ret
      004B52                       2146 00114$:
                                   2147 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:127: if (!record->event.pressed) return false;
      004B52 74 05            [12] 2148 	mov	a,#0x05
      004B54 2E               [12] 2149 	add	a, r6
      004B55 FE               [12] 2150 	mov	r6,a
      004B56 E4               [12] 2151 	clr	a
      004B57 3F               [12] 2152 	addc	a, r7
      004B58 FF               [12] 2153 	mov	r7,a
      004B59 8E 82            [24] 2154 	mov	dpl,r6
      004B5B 8F 83            [24] 2155 	mov	dph,r7
      004B5D E0               [24] 2156 	movx	a,@dptr
      004B5E 70 03            [24] 2157 	jnz	00120$
      004B60 F5 82            [12] 2158 	mov	dpl,a
      004B62 22               [24] 2159 	ret
      004B63                       2160 00120$:
                                   2161 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:128: slot = (uint8_t)record->keycode;
      004B63 8C 82            [24] 2162 	mov	dpl,r4
      004B65 8D 83            [24] 2163 	mov	dph,r5
      004B67 E0               [24] 2164 	movx	a,@dptr
      004B68 FF               [12] 2165 	mov	r7,a
                                   2166 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:129: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      004B69 8A 82            [24] 2167 	mov	dpl,r2
      004B6B 8B 83            [24] 2168 	mov	dph,r3
      004B6D E0               [24] 2169 	movx	a,@dptr
      004B6E C4               [12] 2170 	swap	a
      004B6F 03               [12] 2171 	rr	a
      004B70 54 F8            [12] 2172 	anl	a,#0xf8
      004B72 FA               [12] 2173 	mov	r2,a
      004B73 88 82            [24] 2174 	mov	dpl,r0
      004B75 89 83            [24] 2175 	mov	dph,r1
      004B77 E0               [24] 2176 	movx	a,@dptr
      004B78 2A               [12] 2177 	add	a, r2
      004B79 FE               [12] 2178 	mov	r6,a
                                   2179 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:130: if (slot >= VIAL_TAP_DANCE_ENTRIES || (td_state[slot] && td_source[slot] != id)) {
      004B7A BF 08 00         [24] 2180 	cjne	r7,#0x08,00281$
      004B7D                       2181 00281$:
      004B7D 50 20            [24] 2182 	jnc	00121$
      004B7F EF               [12] 2183 	mov	a,r7
      004B80 24 16            [12] 2184 	add	a, #_td_state
      004B82 FC               [12] 2185 	mov	r4,a
      004B83 E4               [12] 2186 	clr	a
      004B84 34 06            [12] 2187 	addc	a, #(_td_state >> 8)
      004B86 FD               [12] 2188 	mov	r5,a
      004B87 8C 82            [24] 2189 	mov	dpl,r4
      004B89 8D 83            [24] 2190 	mov	dph,r5
      004B8B E0               [24] 2191 	movx	a,@dptr
      004B8C FB               [12] 2192 	mov	r3,a
      004B8D 60 50            [24] 2193 	jz	00122$
      004B8F EF               [12] 2194 	mov	a,r7
      004B90 24 0E            [12] 2195 	add	a, #_td_source
      004B92 F5 82            [12] 2196 	mov	dpl,a
      004B94 E4               [12] 2197 	clr	a
      004B95 34 06            [12] 2198 	addc	a, #(_td_source >> 8)
      004B97 F5 83            [12] 2199 	mov	dph,a
      004B99 E0               [24] 2200 	movx	a,@dptr
      004B9A B5 06 02         [24] 2201 	cjne	a,ar6,00284$
      004B9D 80 40            [24] 2202 	sjmp	00122$
      004B9F                       2203 00284$:
      004B9F                       2204 00121$:
                                   2205 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:131: td_suppressed[id >> 3] |= 1u << (id & 7);
      004B9F 8E 02            [24] 2206 	mov	ar2,r6
      004BA1 EA               [12] 2207 	mov	a,r2
      004BA2 C4               [12] 2208 	swap	a
      004BA3 23               [12] 2209 	rl	a
      004BA4 54 1F            [12] 2210 	anl	a,#0x1f
      004BA6 24 1E            [12] 2211 	add	a, #_td_suppressed
      004BA8 F9               [12] 2212 	mov	r1,a
      004BA9 E4               [12] 2213 	clr	a
      004BAA 34 06            [12] 2214 	addc	a, #(_td_suppressed >> 8)
      004BAC FA               [12] 2215 	mov	r2,a
      004BAD 8E 00            [24] 2216 	mov	ar0,r6
      004BAF E8               [12] 2217 	mov	a,r0
      004BB0 C4               [12] 2218 	swap	a
      004BB1 23               [12] 2219 	rl	a
      004BB2 54 1F            [12] 2220 	anl	a,#0x1f
      004BB4 24 1E            [12] 2221 	add	a, #_td_suppressed
      004BB6 F5 82            [12] 2222 	mov	dpl,a
      004BB8 E4               [12] 2223 	clr	a
      004BB9 34 06            [12] 2224 	addc	a, #(_td_suppressed >> 8)
      004BBB F5 83            [12] 2225 	mov	dph,a
      004BBD E0               [24] 2226 	movx	a,@dptr
      004BBE F5 15            [12] 2227 	mov	_ak820_tap_dance_process_sloc0_1_0,a
      004BC0 74 07            [12] 2228 	mov	a,#0x07
      004BC2 5E               [12] 2229 	anl	a,r6
      004BC3 F5 F0            [12] 2230 	mov	b,a
      004BC5 05 F0            [12] 2231 	inc	b
      004BC7 74 01            [12] 2232 	mov	a,#0x01
      004BC9 80 02            [24] 2233 	sjmp	00286$
      004BCB                       2234 00285$:
      004BCB 25 E0            [12] 2235 	add	a,acc
      004BCD                       2236 00286$:
      004BCD D5 F0 FB         [24] 2237 	djnz	b,00285$
      004BD0 F8               [12] 2238 	mov	r0,a
      004BD1 E5 15            [12] 2239 	mov	a,_ak820_tap_dance_process_sloc0_1_0
      004BD3 42 00            [12] 2240 	orl	ar0,a
      004BD5 89 82            [24] 2241 	mov	dpl,r1
      004BD7 8A 83            [24] 2242 	mov	dph,r2
      004BD9 E8               [12] 2243 	mov	a,r0
      004BDA F0               [24] 2244 	movx	@dptr,a
                                   2245 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:132: return false;
      004BDB 75 82 00         [24] 2246 	mov	dpl, #0x00
      004BDE 22               [24] 2247 	ret
      004BDF                       2248 00122$:
                                   2249 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:134: if (!td_state[slot]) {
      004BDF EB               [12] 2250 	mov	a,r3
      004BE0 60 03            [24] 2251 	jz	00287$
      004BE2 02 4C 86         [24] 2252 	ljmp	00129$
      004BE5                       2253 00287$:
                                   2254 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:135: if (dynamic_keymap_get_tap_dance(slot, &td_entries[slot]) || !ak820_tap_dance_valid(&td_entries[slot])) {
      004BE5 EF               [12] 2255 	mov	a,r7
      004BE6 75 F0 0A         [24] 2256 	mov	b,#0x0a
      004BE9 A4               [48] 2257 	mul	ab
      004BEA 24 9E            [12] 2258 	add	a, #_td_entries
      004BEC FA               [12] 2259 	mov	r2,a
      004BED 74 05            [12] 2260 	mov	a,#(_td_entries >> 8)
      004BEF 35 F0            [12] 2261 	addc	a, b
      004BF1 FB               [12] 2262 	mov	r3,a
      004BF2 90 0B 9A         [24] 2263 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      004BF5 EA               [12] 2264 	mov	a,r2
      004BF6 F0               [24] 2265 	movx	@dptr,a
      004BF7 EB               [12] 2266 	mov	a,r3
      004BF8 A3               [24] 2267 	inc	dptr
      004BF9 F0               [24] 2268 	movx	@dptr,a
      004BFA E4               [12] 2269 	clr	a
      004BFB A3               [24] 2270 	inc	dptr
      004BFC F0               [24] 2271 	movx	@dptr,a
      004BFD 8F 82            [24] 2272 	mov	dpl, r7
      004BFF C0 07            [24] 2273 	push	ar7
      004C01 C0 06            [24] 2274 	push	ar6
      004C03 C0 05            [24] 2275 	push	ar5
      004C05 C0 04            [24] 2276 	push	ar4
      004C07 C0 03            [24] 2277 	push	ar3
      004C09 C0 02            [24] 2278 	push	ar2
      004C0B 12 8E 34         [24] 2279 	lcall	_dynamic_keymap_get_tap_dance
      004C0E E5 82            [12] 2280 	mov	a, dpl
      004C10 85 83 F0         [24] 2281 	mov	b, dph
      004C13 D0 02            [24] 2282 	pop	ar2
      004C15 D0 03            [24] 2283 	pop	ar3
      004C17 D0 04            [24] 2284 	pop	ar4
      004C19 D0 05            [24] 2285 	pop	ar5
      004C1B D0 06            [24] 2286 	pop	ar6
      004C1D D0 07            [24] 2287 	pop	ar7
      004C1F 45 F0            [12] 2288 	orl	a,b
      004C21 70 1B            [24] 2289 	jnz	00125$
      004C23 8A 82            [24] 2290 	mov	dpl, r2
      004C25 8B 83            [24] 2291 	mov	dph, r3
      004C27 C0 07            [24] 2292 	push	ar7
      004C29 C0 06            [24] 2293 	push	ar6
      004C2B C0 05            [24] 2294 	push	ar5
      004C2D C0 04            [24] 2295 	push	ar4
      004C2F 12 43 BE         [24] 2296 	lcall	_ak820_tap_dance_valid
      004C32 E5 82            [12] 2297 	mov	a, dpl
      004C34 D0 04            [24] 2298 	pop	ar4
      004C36 D0 05            [24] 2299 	pop	ar5
      004C38 D0 06            [24] 2300 	pop	ar6
      004C3A D0 07            [24] 2301 	pop	ar7
      004C3C 70 3C            [24] 2302 	jnz	00126$
      004C3E                       2303 00125$:
                                   2304 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:136: td_suppressed[id >> 3] |= 1u << (id & 7);
      004C3E 8E 03            [24] 2305 	mov	ar3,r6
      004C40 EB               [12] 2306 	mov	a,r3
      004C41 C4               [12] 2307 	swap	a
      004C42 23               [12] 2308 	rl	a
      004C43 54 1F            [12] 2309 	anl	a,#0x1f
      004C45 24 1E            [12] 2310 	add	a,#_td_suppressed
      004C47 FB               [12] 2311 	mov	r3,a
      004C48 E4               [12] 2312 	clr	a
      004C49 34 06            [12] 2313 	addc	a, #(_td_suppressed >> 8)
      004C4B FA               [12] 2314 	mov	r2,a
      004C4C 8E 01            [24] 2315 	mov	ar1,r6
      004C4E E9               [12] 2316 	mov	a,r1
      004C4F C4               [12] 2317 	swap	a
      004C50 23               [12] 2318 	rl	a
      004C51 54 1F            [12] 2319 	anl	a,#0x1f
      004C53 24 1E            [12] 2320 	add	a, #_td_suppressed
      004C55 F5 82            [12] 2321 	mov	dpl,a
      004C57 E4               [12] 2322 	clr	a
      004C58 34 06            [12] 2323 	addc	a, #(_td_suppressed >> 8)
      004C5A F5 83            [12] 2324 	mov	dph,a
      004C5C E0               [24] 2325 	movx	a,@dptr
      004C5D F9               [12] 2326 	mov	r1,a
      004C5E 74 07            [12] 2327 	mov	a,#0x07
      004C60 5E               [12] 2328 	anl	a,r6
      004C61 F5 F0            [12] 2329 	mov	b,a
      004C63 05 F0            [12] 2330 	inc	b
      004C65 74 01            [12] 2331 	mov	a,#0x01
      004C67 80 02            [24] 2332 	sjmp	00291$
      004C69                       2333 00290$:
      004C69 25 E0            [12] 2334 	add	a,acc
      004C6B                       2335 00291$:
      004C6B D5 F0 FB         [24] 2336 	djnz	b,00290$
      004C6E 42 01            [12] 2337 	orl	ar1,a
      004C70 8B 82            [24] 2338 	mov	dpl,r3
      004C72 8A 83            [24] 2339 	mov	dph,r2
      004C74 E9               [12] 2340 	mov	a,r1
      004C75 F0               [24] 2341 	movx	@dptr,a
                                   2342 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:137: return false;
      004C76 75 82 00         [24] 2343 	mov	dpl, #0x00
      004C79 22               [24] 2344 	ret
      004C7A                       2345 00126$:
                                   2346 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:139: td_source[slot] = id;
      004C7A EF               [12] 2347 	mov	a,r7
      004C7B 24 0E            [12] 2348 	add	a, #_td_source
      004C7D F5 82            [12] 2349 	mov	dpl,a
      004C7F E4               [12] 2350 	clr	a
      004C80 34 06            [12] 2351 	addc	a, #(_td_source >> 8)
      004C82 F5 83            [12] 2352 	mov	dph,a
      004C84 EE               [12] 2353 	mov	a,r6
      004C85 F0               [24] 2354 	movx	@dptr,a
      004C86                       2355 00129$:
                                   2356 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:141: td_state[slot] = (td_state[slot] & 3) + 1 + TD_DOWN;
      004C86 8C 82            [24] 2357 	mov	dpl,r4
      004C88 8D 83            [24] 2358 	mov	dph,r5
      004C8A E0               [24] 2359 	movx	a,@dptr
      004C8B FE               [12] 2360 	mov	r6,a
      004C8C 74 03            [12] 2361 	mov	a,#0x03
      004C8E 5E               [12] 2362 	anl	a,r6
      004C8F 24 05            [12] 2363 	add	a, #0x05
      004C91 8C 82            [24] 2364 	mov	dpl,r4
      004C93 8D 83            [24] 2365 	mov	dph,r5
      004C95 F0               [24] 2366 	movx	@dptr,a
                                   2367 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:142: td_time[slot] = record->event.time;
      004C96 EF               [12] 2368 	mov	a,r7
      004C97 75 F0 02         [24] 2369 	mov	b,#0x02
      004C9A A4               [48] 2370 	mul	ab
      004C9B 24 EE            [12] 2371 	add	a, #_td_time
      004C9D FD               [12] 2372 	mov	r5,a
      004C9E 74 05            [12] 2373 	mov	a,#(_td_time >> 8)
      004CA0 35 F0            [12] 2374 	addc	a, b
      004CA2 FE               [12] 2375 	mov	r6,a
      004CA3 90 06 4C         [24] 2376 	mov	dptr,#_ak820_tap_dance_process_record_10000_646
      004CA6 E0               [24] 2377 	movx	a,@dptr
      004CA7 FB               [12] 2378 	mov	r3,a
      004CA8 A3               [24] 2379 	inc	dptr
      004CA9 E0               [24] 2380 	movx	a,@dptr
      004CAA FC               [12] 2381 	mov	r4,a
      004CAB 8B 82            [24] 2382 	mov	dpl,r3
      004CAD 8C 83            [24] 2383 	mov	dph,r4
      004CAF A3               [24] 2384 	inc	dptr
      004CB0 A3               [24] 2385 	inc	dptr
      004CB1 E0               [24] 2386 	movx	a,@dptr
      004CB2 FB               [12] 2387 	mov	r3,a
      004CB3 A3               [24] 2388 	inc	dptr
      004CB4 E0               [24] 2389 	movx	a,@dptr
      004CB5 FC               [12] 2390 	mov	r4,a
      004CB6 8D 82            [24] 2391 	mov	dpl,r5
      004CB8 8E 83            [24] 2392 	mov	dph,r6
      004CBA EB               [12] 2393 	mov	a,r3
      004CBB F0               [24] 2394 	movx	@dptr,a
      004CBC EC               [12] 2395 	mov	a,r4
      004CBD A3               [24] 2396 	inc	dptr
      004CBE F0               [24] 2397 	movx	@dptr,a
                                   2398 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:143: td_pending = slot;
      004CBF 90 0E 83         [24] 2399 	mov	dptr,#_td_pending
      004CC2 EF               [12] 2400 	mov	a,r7
      004CC3 F0               [24] 2401 	movx	@dptr,a
                                   2402 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:144: return false;
      004CC4 75 82 00         [24] 2403 	mov	dpl, #0x00
                                   2404 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:145: }
      004CC7 22               [24] 2405 	ret
                                   2406 ;------------------------------------------------------------
                                   2407 ;Allocation info for local variables in function 'ak820_tap_dance_cancel'
                                   2408 ;------------------------------------------------------------
                                   2409 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_660'
                                   2410 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_661'
                                   2411 ;------------------------------------------------------------
                                   2412 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:146: void ak820_tap_dance_cancel(void) {
                                   2413 ;	-----------------------------------------
                                   2414 ;	 function ak820_tap_dance_cancel
                                   2415 ;	-----------------------------------------
      004CC8                       2416 _ak820_tap_dance_cancel:
                                   2417 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:147: td_pending = TD_NONE;
      004CC8 90 0E 83         [24] 2418 	mov	dptr,#_td_pending
      004CCB 74 FF            [12] 2419 	mov	a,#0xff
      004CCD F0               [24] 2420 	movx	@dptr,a
                                   2421 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:148: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) td_state[i] = 0;
      004CCE 7F 00            [12] 2422 	mov	r7,#0x00
      004CD0                       2423 00104$:
      004CD0 BF 08 00         [24] 2424 	cjne	r7,#0x08,00141$
      004CD3                       2425 00141$:
      004CD3 50 0F            [24] 2426 	jnc	00101$
      004CD5 EF               [12] 2427 	mov	a,r7
      004CD6 24 16            [12] 2428 	add	a, #_td_state
      004CD8 F5 82            [12] 2429 	mov	dpl,a
      004CDA E4               [12] 2430 	clr	a
      004CDB 34 06            [12] 2431 	addc	a, #(_td_state >> 8)
      004CDD F5 83            [12] 2432 	mov	dph,a
      004CDF E4               [12] 2433 	clr	a
      004CE0 F0               [24] 2434 	movx	@dptr,a
      004CE1 0F               [12] 2435 	inc	r7
      004CE2 80 EC            [24] 2436 	sjmp	00104$
      004CE4                       2437 00101$:
                                   2438 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:149: for (uint8_t i = 0; i < sizeof(td_suppressed); ++i) td_suppressed[i] = 0;
      004CE4 7F 00            [12] 2439 	mov	r7,#0x00
      004CE6                       2440 00107$:
      004CE6 BF 10 00         [24] 2441 	cjne	r7,#0x10,00143$
      004CE9                       2442 00143$:
      004CE9 50 0F            [24] 2443 	jnc	00109$
      004CEB EF               [12] 2444 	mov	a,r7
      004CEC 24 1E            [12] 2445 	add	a, #_td_suppressed
      004CEE F5 82            [12] 2446 	mov	dpl,a
      004CF0 E4               [12] 2447 	clr	a
      004CF1 34 06            [12] 2448 	addc	a, #(_td_suppressed >> 8)
      004CF3 F5 83            [12] 2449 	mov	dph,a
      004CF5 E4               [12] 2450 	clr	a
      004CF6 F0               [24] 2451 	movx	@dptr,a
      004CF7 0F               [12] 2452 	inc	r7
      004CF8 80 EC            [24] 2453 	sjmp	00107$
      004CFA                       2454 00109$:
                                   2455 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:150: }
      004CFA 22               [24] 2456 	ret
                                   2457 	.area CSEG    (CODE)
                                   2458 	.area CONST   (CODE)
                                   2459 	.area XINIT   (CODE)
      00CB6A                       2460 __xinit__td_pending:
      00CB6A FF                    2461 	.db #0xff	; 255
                                   2462 	.area CABS    (ABS,CODE)
