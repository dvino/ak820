                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000027                        548 _control_setup_sloc1_1_0:
      000027                        549 	.ds 1
      000028                        550 _control_setup_sloc3_1_0:
      000028                        551 	.ds 2
      00002A                        552 _control_setup_sloc4_1_0:
      00002A                        553 	.ds 2
      00002C                        554 _ak820_usb_send_sloc0_1_0:
      00002C                        555 	.ds 2
      00002E                        556 _ak820_usb_send_sloc1_1_0:
      00002E                        557 	.ds 1
      00002F                        558 _ak820_usb_raw_task_sloc0_1_0:
      00002F                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000019                        576 _control_setup_valid_interface_10000_286:
      000019                        577 	.ds 1
      00001A                        578 _control_setup_zero_index_10000_286:
      00001A                        579 	.ds 1
      00001B                        580 _control_setup_zero_value_10000_286:
      00001B                        581 	.ds 1
      00001C                        582 _control_setup_zero_length_10000_286:
      00001C                        583 	.ds 1
      00001D                        584 _control_setup_sloc0_1_0:
      00001D                        585 	.ds 1
      00001E                        586 _control_setup_sloc2_1_0:
      00001E                        587 	.ds 1
      00001F                        588 _ak820_usb_try_send_sloc0_1_0:
      00001F                        589 	.ds 1
      000020                        590 _ak820_usb_raw_task_sloc1_1_0:
      000020                        591 	.ds 1
      000021                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      000021                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      000815                        602 _D0SetupReqCode::
      000815                        603 	.ds 1
      000816                        604 _D0SetupLen::
      000816                        605 	.ds 2
      000818                        606 _pD0Descr::
      000818                        607 	.ds 3
      00081B                        608 _D0UsbConfig::
      00081B                        609 	.ds 1
      00081C                        610 _USB_EnumStatus::
      00081C                        611 	.ds 1
      00081D                        612 _USB_SleepStatus::
      00081D                        613 	.ds 1
      00081E                        614 _MCU_Sleep_Operate::
      00081E                        615 	.ds 1
      00081F                        616 _KB_USB_UpStatus::
      00081F                        617 	.ds 1
      000820                        618 _KB_USB_SetReport::
      000820                        619 	.ds 1
      000821                        620 _ak820_boot_stage::
      000821                        621 	.ds 1
      000822                        622 _ak820_main_heartbeat::
      000822                        623 	.ds 1
      000823                        624 _raw_state:
      000823                        625 	.ds 1
      000824                        626 _raw_buffer:
      000824                        627 	.ds 32
      000844                        628 _raw_reply_without_nvm:
      000844                        629 	.ds 1
      000845                        630 _keyboard_reset:
      000845                        631 	.ds 1
      000846                        632 _input_snapshot:
      000846                        633 	.ds 46
      000874                        634 _control_phase:
      000874                        635 	.ds 1
      000875                        636 _output_kind:
      000875                        637 	.ds 1
      000876                        638 _output_report_id:
      000876                        639 	.ds 1
      000877                        640 _control_zlp:
      000877                        641 	.ds 1
      000878                        642 _control_pointer:
      000878                        643 	.ds 2
      00087A                        644 _descriptor_select_PARM_2:
      00087A                        645 	.ds 1
      00087B                        646 _descriptor_select_PARM_3:
      00087B                        647 	.ds 2
      00087D                        648 _descriptor_select_type_10000_268:
      00087D                        649 	.ds 1
      00087E                        650 _control_setup_length_10000_286:
      00087E                        651 	.ds 2
      000880                        652 _control_setup_offset_10000_286:
      000880                        653 	.ds 1
      000881                        654 _ak820_usb_send_PARM_2:
      000881                        655 	.ds 2
      000883                        656 _ak820_usb_send_PARM_3:
      000883                        657 	.ds 1
      000884                        658 _ak820_usb_send_endpoint_10000_422:
      000884                        659 	.ds 1
      000885                        660 _ak820_usb_send_offset_10000_423:
      000885                        661 	.ds 1
      000886                        662 _ak820_usb_try_send_PARM_2:
      000886                        663 	.ds 2
      000888                        664 _ak820_usb_try_send_PARM_3:
      000888                        665 	.ds 1
      000889                        666 _ak820_usb_try_send_endpoint_10000_443:
      000889                        667 	.ds 1
      00088A                        668 _ak820_usb_try_send_sent_10000_444:
      00088A                        669 	.ds 1
      00088B                        670 _ak820_usb_raw_send_PARM_2:
      00088B                        671 	.ds 1
      00088C                        672 _ak820_usb_raw_send_report_10000_459:
      00088C                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      006367                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      006367 90 08 23         [24]  727 	mov	dptr,#_raw_state
      00636A E0               [24]  728 	movx	a,@dptr
      00636B FF               [12]  729 	mov	r7,a
      00636C BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      00636F 80 1C            [24]  731 	sjmp	00101$
      006371                        732 00130$:
      006371 90 08 23         [24]  733 	mov	dptr,#_raw_state
      006374 E0               [24]  734 	movx	a,@dptr
      006375 FF               [12]  735 	mov	r7,a
      006376 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      006379 80 12            [24]  737 	sjmp	00101$
      00637B                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      00637B 90 08 23         [24]  740 	mov	dptr,#_raw_state
      00637E E0               [24]  741 	movx	a,@dptr
      00637F FF               [12]  742 	mov	r7,a
      006380 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      006383 80 08            [24]  744 	sjmp	00101$
      006385                        745 00132$:
      006385 90 08 23         [24]  746 	mov	dptr,#_raw_state
      006388 E0               [24]  747 	movx	a,@dptr
      006389 FF               [12]  748 	mov	r7,a
      00638A BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      00638D                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      00638D 90 08 23         [24]  752 	mov	dptr,#_raw_state
      006390 74 07            [12]  753 	mov	a,#0x07
      006392 F0               [24]  754 	movx	@dptr,a
      006393 80 05            [24]  755 	sjmp	00103$
      006395                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      006395 90 08 23         [24]  758 	mov	dptr,#_raw_state
      006398 E4               [12]  759 	clr	a
      006399 F0               [24]  760 	movx	@dptr,a
      00639A                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      00639A 90 08 75         [24]  763 	mov	dptr,#_output_kind
      00639D E4               [12]  764 	clr	a
      00639E F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      00639F 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      0063A0                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      0063A0 90 08 23         [24]  777 	mov	dptr,#_raw_state
      0063A3 E0               [24]  778 	movx	a,@dptr
      0063A4 FF               [12]  779 	mov	r7,a
      0063A5 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      0063A8 90 08 23         [24]  781 	mov	dptr,#_raw_state
      0063AB 74 06            [12]  782 	mov	a,#0x06
      0063AD F0               [24]  783 	movx	@dptr,a
      0063AE 22               [24]  784 	ret
      0063AF                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      0063AF 90 08 23         [24]  787 	mov	dptr,#_raw_state
      0063B2 E0               [24]  788 	movx	a,@dptr
      0063B3 FF               [12]  789 	mov	r7,a
      0063B4 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      0063B7 90 08 23         [24]  791 	mov	dptr,#_raw_state
      0063BA E4               [12]  792 	clr	a
      0063BB F0               [24]  793 	movx	@dptr,a
      0063BC                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      0063BC 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      0063BD                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      0063BD 90 22 0C         [24]  808 	mov	dptr,#0x220c
      0063C0 74 01            [12]  809 	mov	a,#0x01
      0063C2 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      0063C3 F5 82            [12]  812 	mov	dpl,a
      0063C5 74 12            [12]  813 	mov	a,#0x12
      0063C7 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      0063C8 A3               [24]  816 	inc	dptr
      0063C9 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      0063CA A3               [24]  819 	inc	dptr
      0063CB F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      0063CC 90 22 0B         [24]  822 	mov	dptr,#0x220b
      0063CF E4               [12]  823 	clr	a
      0063D0 F0               [24]  824 	movx	@dptr,a
      0063D1 15 82            [12]  825 	dec	dpl
      0063D3 F0               [24]  826 	movx	@dptr,a
      0063D4 15 82            [12]  827 	dec	dpl
      0063D6 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      0063D7 FF               [12]  830 	mov	r7,a
      0063D8                        831 00103$:
      0063D8 EF               [12]  832 	mov	a,r7
      0063D9 24 46            [12]  833 	add	a, #_input_snapshot
      0063DB F5 82            [12]  834 	mov	dpl,a
      0063DD E4               [12]  835 	clr	a
      0063DE 34 08            [12]  836 	addc	a, #(_input_snapshot >> 8)
      0063E0 F5 83            [12]  837 	mov	dph,a
      0063E2 E4               [12]  838 	clr	a
      0063E3 F0               [24]  839 	movx	@dptr,a
      0063E4 0F               [12]  840 	inc	r7
      0063E5 BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      0063E8                        842 00139$:
      0063E8 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      0063EA 90 08 4E         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      0063ED 74 06            [12]  846 	mov	a,#0x06
      0063EF F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      0063F0 90 08 6E         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      0063F3 03               [12]  850 	rr	a
      0063F4 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      0063F5 90 08 71         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      0063F8 04               [12]  854 	inc	a
      0063F9 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      0063FA 7F 00            [12]  857 	mov	r7,#0x00
      0063FC                        858 00105$:
      0063FC 8F 06            [24]  859 	mov	ar6,r7
      0063FE 74 C0            [12]  860 	mov	a,#0xc0
      006400 2E               [12]  861 	add	a, r6
      006401 F5 82            [12]  862 	mov	dpl,a
      006403 74 10            [12]  863 	mov	a,#0x10
      006405 24 00            [12]  864 	add	a, #0x00
      006407 F5 83            [12]  865 	mov	dph,a
      006409 E4               [12]  866 	clr	a
      00640A F0               [24]  867 	movx	@dptr,a
      00640B 0F               [12]  868 	inc	r7
      00640C BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      00640F                        870 00141$:
      00640F 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      006411 02 63 67         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      006414                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      006414 90 08 23         [24]  884 	mov	dptr,#_raw_state
      006417 E0               [24]  885 	movx	a,@dptr
      006418 FF               [12]  886 	mov	r7,a
      006419 BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      00641C 90 08 23         [24]  888 	mov	dptr,#_raw_state
      00641F E4               [12]  889 	clr	a
      006420 F0               [24]  890 	movx	@dptr,a
      006421                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      006421 90 08 75         [24]  893 	mov	dptr,#_output_kind
      006424 E4               [12]  894 	clr	a
      006425 F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      006426 90 08 74         [24]  897 	mov	dptr,#_control_phase
      006429 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      00642A 90 08 15         [24]  900 	mov	dptr,#_D0SetupReqCode
      00642D 14               [12]  901 	dec	a
      00642E F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      00642F 90 22 00         [24]  904 	mov	dptr,#0x2200
      006432 74 CF            [12]  905 	mov	a,#0xcf
      006434 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      006435 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      006436                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      006436 90 08 16         [24]  921 	mov	dptr,#_D0SetupLen
      006439 E0               [24]  922 	movx	a,@dptr
      00643A FE               [12]  923 	mov	r6,a
      00643B A3               [24]  924 	inc	dptr
      00643C E0               [24]  925 	movx	a,@dptr
      00643D FF               [12]  926 	mov	r7,a
      00643E C3               [12]  927 	clr	c
      00643F 74 40            [12]  928 	mov	a,#0x40
      006441 9E               [12]  929 	subb	a,r6
      006442 E4               [12]  930 	clr	a
      006443 9F               [12]  931 	subb	a,r7
      006444 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      006446 7E 40            [12]  934 	mov	r6,#0x40
      006448 80 07            [24]  935 	sjmp	00110$
      00644A                        936 00109$:
      00644A 90 08 16         [24]  937 	mov	dptr,#_D0SetupLen
      00644D E0               [24]  938 	movx	a,@dptr
      00644E FE               [12]  939 	mov	r6,a
      00644F A3               [24]  940 	inc	dptr
      006450 E0               [24]  941 	movx	a,@dptr
      006451                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      006451 7F 00            [12]  944 	mov	r7,#0x00
      006453                        945 00105$:
      006453 C3               [12]  946 	clr	c
      006454 EF               [12]  947 	mov	a,r7
      006455 9E               [12]  948 	subb	a,r6
      006456 50 2A            [24]  949 	jnc	00101$
      006458 8F 04            [24]  950 	mov	ar4,r7
      00645A 74 10            [12]  951 	mov	a,#0x10
      00645C 24 00            [12]  952 	add	a, #0x00
      00645E FD               [12]  953 	mov	r5,a
      00645F 90 08 78         [24]  954 	mov	dptr,#_control_pointer
      006462 E0               [24]  955 	movx	a,@dptr
      006463 FA               [12]  956 	mov	r2,a
      006464 A3               [24]  957 	inc	dptr
      006465 E0               [24]  958 	movx	a,@dptr
      006466 FB               [12]  959 	mov	r3,a
      006467 8A 82            [24]  960 	mov	dpl,r2
      006469 8B 83            [24]  961 	mov	dph,r3
      00646B E4               [12]  962 	clr	a
      00646C 93               [24]  963 	movc	a,@a+dptr
      00646D F9               [12]  964 	mov	r1,a
      00646E 90 08 78         [24]  965 	mov	dptr,#_control_pointer
      006471 74 01            [12]  966 	mov	a,#0x01
      006473 2A               [12]  967 	add	a, r2
      006474 F0               [24]  968 	movx	@dptr,a
      006475 E4               [12]  969 	clr	a
      006476 3B               [12]  970 	addc	a, r3
      006477 A3               [24]  971 	inc	dptr
      006478 F0               [24]  972 	movx	@dptr,a
      006479 8C 82            [24]  973 	mov	dpl,r4
      00647B 8D 83            [24]  974 	mov	dph,r5
      00647D E9               [12]  975 	mov	a,r1
      00647E F0               [24]  976 	movx	@dptr,a
      00647F 0F               [12]  977 	inc	r7
      006480 80 D1            [24]  978 	sjmp	00105$
      006482                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      006482 8E 05            [24]  981 	mov	ar5,r6
      006484 7F 00            [12]  982 	mov	r7,#0x00
      006486 90 08 16         [24]  983 	mov	dptr,#_D0SetupLen
      006489 E0               [24]  984 	movx	a,@dptr
      00648A FB               [12]  985 	mov	r3,a
      00648B A3               [24]  986 	inc	dptr
      00648C E0               [24]  987 	movx	a,@dptr
      00648D FC               [12]  988 	mov	r4,a
      00648E EB               [12]  989 	mov	a,r3
      00648F C3               [12]  990 	clr	c
      006490 9D               [12]  991 	subb	a,r5
      006491 FB               [12]  992 	mov	r3,a
      006492 EC               [12]  993 	mov	a,r4
      006493 9F               [12]  994 	subb	a,r7
      006494 FC               [12]  995 	mov	r4,a
      006495 90 08 16         [24]  996 	mov	dptr,#_D0SetupLen
      006498 EB               [12]  997 	mov	a,r3
      006499 F0               [24]  998 	movx	@dptr,a
      00649A EC               [12]  999 	mov	a,r4
      00649B A3               [24] 1000 	inc	dptr
      00649C F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      00649D EE               [12] 1003 	mov	a,r6
      00649E 70 05            [24] 1004 	jnz	00103$
      0064A0 90 08 77         [24] 1005 	mov	dptr,#_control_zlp
      0064A3 E4               [12] 1006 	clr	a
      0064A4 F0               [24] 1007 	movx	@dptr,a
      0064A5                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      0064A5 90 22 08         [24] 1010 	mov	dptr,#0x2208
      0064A8 EE               [12] 1011 	mov	a,r6
      0064A9 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      0064AA 90 22 00         [24] 1014 	mov	dptr,#0x2200
      0064AD E0               [24] 1015 	movx	a,@dptr
      0064AE 54 C0            [12] 1016 	anl	a,#0xc0
      0064B0 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      0064B1 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      0064B2                       1032 _descriptor_select:
      0064B2 E5 82            [12] 1033 	mov	a,dpl
      0064B4 90 08 7D         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      0064B7 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      0064B8 E0               [24] 1037 	movx	a,@dptr
      0064B9 FF               [12] 1038 	mov	r7,a
      0064BA BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      0064BD 90 08 7A         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      0064C0 E0               [24] 1041 	movx	a,@dptr
      0064C1 70 1A            [24] 1042 	jnz	00102$
      0064C3 90 08 7B         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      0064C6 E0               [24] 1044 	movx	a,@dptr
      0064C7 F5 F0            [12] 1045 	mov	b,a
      0064C9 A3               [24] 1046 	inc	dptr
      0064CA E0               [24] 1047 	movx	a,@dptr
      0064CB 45 F0            [12] 1048 	orl	a,b
      0064CD 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      0064CF 90 08 78         [24] 1051 	mov	dptr,#_control_pointer
      0064D2 74 9A            [12] 1052 	mov	a,#_DeviceDescriptor
      0064D4 F0               [24] 1053 	movx	@dptr,a
      0064D5 74 CA            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      0064D7 A3               [24] 1055 	inc	dptr
      0064D8 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      0064D9 90 00 12         [24] 1058 	mov	dptr,#0x0012
      0064DC 22               [24] 1059 	ret
      0064DD                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      0064DD 90 08 7D         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      0064E0 E0               [24] 1063 	movx	a,@dptr
      0064E1 FF               [12] 1064 	mov	r7,a
      0064E2 BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      0064E5 90 08 7A         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      0064E8 E0               [24] 1067 	movx	a,@dptr
      0064E9 70 1A            [24] 1068 	jnz	00106$
      0064EB 90 08 7B         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      0064EE E0               [24] 1070 	movx	a,@dptr
      0064EF F5 F0            [12] 1071 	mov	b,a
      0064F1 A3               [24] 1072 	inc	dptr
      0064F2 E0               [24] 1073 	movx	a,@dptr
      0064F3 45 F0            [12] 1074 	orl	a,b
      0064F5 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      0064F7 90 08 78         [24] 1077 	mov	dptr,#_control_pointer
      0064FA 74 AC            [12] 1078 	mov	a,#_ConfigurationDescriptor
      0064FC F0               [24] 1079 	movx	@dptr,a
      0064FD 74 CA            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      0064FF A3               [24] 1081 	inc	dptr
      006500 F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      006501 90 00 54         [24] 1084 	mov	dptr,#0x0054
      006504 22               [24] 1085 	ret
      006505                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      006505 90 08 7D         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      006508 E0               [24] 1089 	movx	a,@dptr
      006509 FF               [12] 1090 	mov	r7,a
      00650A BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      00650D 80 03            [24] 1092 	sjmp	00239$
      00650F                       1093 00238$:
      00650F 02 65 A9         [24] 1094 	ljmp	00119$
      006512                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      006512 90 08 7B         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      006515 E0               [24] 1098 	movx	a,@dptr
      006516 FD               [12] 1099 	mov	r5,a
      006517 A3               [24] 1100 	inc	dptr
      006518 E0               [24] 1101 	movx	a,@dptr
      006519 FE               [12] 1102 	mov	r6,a
      00651A 90 08 7B         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      00651D E0               [24] 1104 	movx	a,@dptr
      00651E F5 F0            [12] 1105 	mov	b,a
      006520 A3               [24] 1106 	inc	dptr
      006521 E0               [24] 1107 	movx	a,@dptr
      006522 45 F0            [12] 1108 	orl	a,b
      006524 60 0C            [24] 1109 	jz	00110$
      006526 BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      006529 BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      00652C 80 04            [24] 1112 	sjmp	00110$
      00652E                       1113 00241$:
      00652E 90 00 00         [24] 1114 	mov	dptr,#0x0000
      006531 22               [24] 1115 	ret
      006532                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      006532 90 08 7A         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      006535 E0               [24] 1119 	movx	a,@dptr
      006536 FE               [12] 1120 	mov  r6,a
      006537 24 FC            [12] 1121 	add	a,#0xff - 0x03
      006539 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      00653B EE               [12] 1124 	mov	a,r6
      00653C 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      00653D 90 65 41         [24] 1127 	mov	dptr,#00243$
      006540 73               [24] 1128 	jmp	@a+dptr
      006541                       1129 00243$:
      006541 80 06            [24] 1130 	sjmp	00112$
      006543 80 1B            [24] 1131 	sjmp	00113$
      006545 80 30            [24] 1132 	sjmp	00114$
      006547 80 45            [24] 1133 	sjmp	00115$
      006549                       1134 00112$:
      006549 90 08 78         [24] 1135 	mov	dptr,#_control_pointer
      00654C 74 00            [12] 1136 	mov	a,#_LanguageString
      00654E F0               [24] 1137 	movx	@dptr,a
      00654F 74 CB            [12] 1138 	mov	a,#(_LanguageString >> 8)
      006551 A3               [24] 1139 	inc	dptr
      006552 F0               [24] 1140 	movx	@dptr,a
      006553 90 CB 00         [24] 1141 	mov	dptr,#_LanguageString
      006556 E4               [12] 1142 	clr	a
      006557 93               [24] 1143 	movc	a,@a+dptr
      006558 FE               [12] 1144 	mov	r6,a
      006559 7D 00            [12] 1145 	mov	r5,#0x00
      00655B 8E 82            [24] 1146 	mov	dpl, r6
      00655D 8D 83            [24] 1147 	mov	dph, r5
      00655F 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      006560                       1150 00113$:
      006560 90 08 78         [24] 1151 	mov	dptr,#_control_pointer
      006563 74 04            [12] 1152 	mov	a,#_ManufacturerString
      006565 F0               [24] 1153 	movx	@dptr,a
      006566 74 CB            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      006568 A3               [24] 1155 	inc	dptr
      006569 F0               [24] 1156 	movx	@dptr,a
      00656A 90 CB 04         [24] 1157 	mov	dptr,#_ManufacturerString
      00656D E4               [12] 1158 	clr	a
      00656E 93               [24] 1159 	movc	a,@a+dptr
      00656F FE               [12] 1160 	mov	r6,a
      006570 7D 00            [12] 1161 	mov	r5,#0x00
      006572 8E 82            [24] 1162 	mov	dpl, r6
      006574 8D 83            [24] 1163 	mov	dph, r5
      006576 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      006577                       1166 00114$:
      006577 90 08 78         [24] 1167 	mov	dptr,#_control_pointer
      00657A 74 12            [12] 1168 	mov	a,#_ProductString
      00657C F0               [24] 1169 	movx	@dptr,a
      00657D 74 CB            [12] 1170 	mov	a,#(_ProductString >> 8)
      00657F A3               [24] 1171 	inc	dptr
      006580 F0               [24] 1172 	movx	@dptr,a
      006581 90 CB 12         [24] 1173 	mov	dptr,#_ProductString
      006584 E4               [12] 1174 	clr	a
      006585 93               [24] 1175 	movc	a,@a+dptr
      006586 FE               [12] 1176 	mov	r6,a
      006587 7D 00            [12] 1177 	mov	r5,#0x00
      006589 8E 82            [24] 1178 	mov	dpl, r6
      00658B 8D 83            [24] 1179 	mov	dph, r5
      00658D 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      00658E                       1182 00115$:
      00658E 90 08 78         [24] 1183 	mov	dptr,#_control_pointer
      006591 74 4A            [12] 1184 	mov	a,#_SerialNumberString
      006593 F0               [24] 1185 	movx	@dptr,a
      006594 74 CB            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      006596 A3               [24] 1187 	inc	dptr
      006597 F0               [24] 1188 	movx	@dptr,a
      006598 90 CB 4A         [24] 1189 	mov	dptr,#_SerialNumberString
      00659B E4               [12] 1190 	clr	a
      00659C 93               [24] 1191 	movc	a,@a+dptr
      00659D FE               [12] 1192 	mov	r6,a
      00659E 7D 00            [12] 1193 	mov	r5,#0x00
      0065A0 8E 82            [24] 1194 	mov	dpl, r6
      0065A2 8D 83            [24] 1195 	mov	dph, r5
      0065A4 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      0065A5                       1198 00116$:
      0065A5 90 00 00         [24] 1199 	mov	dptr,#0x0000
      0065A8 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      0065A9                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      0065A9 90 08 7A         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      0065AC E0               [24] 1205 	movx	a,@dptr
      0065AD 70 11            [24] 1206 	jnz	00120$
      0065AF 90 08 7B         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      0065B2 E0               [24] 1208 	movx	a,@dptr
      0065B3 FD               [12] 1209 	mov	r5,a
      0065B4 A3               [24] 1210 	inc	dptr
      0065B5 E0               [24] 1211 	movx	a,@dptr
      0065B6 FE               [12] 1212 	mov	r6,a
      0065B7 C3               [12] 1213 	clr	c
      0065B8 ED               [12] 1214 	mov	a,r5
      0065B9 94 03            [12] 1215 	subb	a,#0x03
      0065BB EE               [12] 1216 	mov	a,r6
      0065BC 94 00            [12] 1217 	subb	a,#0x00
      0065BE 40 04            [24] 1218 	jc	00121$
      0065C0                       1219 00120$:
      0065C0 90 00 00         [24] 1220 	mov	dptr,#0x0000
      0065C3 22               [24] 1221 	ret
      0065C4                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      0065C4 BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      0065C7 80 03            [24] 1225 	sjmp	00127$
      0065C9                       1226 00246$:
      0065C9 BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      0065CC                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      0065CC ED               [12] 1230 	mov	a,r5
      0065CD 75 F0 04         [24] 1231 	mov	b,#0x04
      0065D0 A4               [48] 1232 	mul	ab
      0065D1 24 23            [12] 1233 	add	a, #_interface_descriptors
      0065D3 FE               [12] 1234 	mov	r6,a
      0065D4 74 C4            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      0065D6 35 F0            [12] 1236 	addc	a, b
      0065D8 FF               [12] 1237 	mov	r7,a
      0065D9 8E 82            [24] 1238 	mov	dpl,r6
      0065DB 8F 83            [24] 1239 	mov	dph,r7
      0065DD A3               [24] 1240 	inc	dptr
      0065DE A3               [24] 1241 	inc	dptr
      0065DF E4               [12] 1242 	clr	a
      0065E0 93               [24] 1243 	movc	a,@a+dptr
      0065E1 FC               [12] 1244 	mov	r4,a
      0065E2 A3               [24] 1245 	inc	dptr
      0065E3 E4               [12] 1246 	clr	a
      0065E4 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      0065E5 FD               [12] 1249 	mov	r5,a
      0065E6 4C               [12] 1250 	orl	a,r4
      0065E7 70 04            [24] 1251 	jnz	00124$
      0065E9 90 00 00         [24] 1252 	mov	dptr,#0x0000
      0065EC 22               [24] 1253 	ret
      0065ED                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      0065ED 90 08 7D         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      0065F0 E0               [24] 1257 	movx	a,@dptr
      0065F1 FB               [12] 1258 	mov	r3,a
      0065F2 BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      0065F5 8E 82            [24] 1261 	mov	dpl,r6
      0065F7 8F 83            [24] 1262 	mov	dph,r7
      0065F9 E4               [12] 1263 	clr	a
      0065FA 93               [24] 1264 	movc	a,@a+dptr
      0065FB FE               [12] 1265 	mov	r6,a
      0065FC A3               [24] 1266 	inc	dptr
      0065FD E4               [12] 1267 	clr	a
      0065FE 93               [24] 1268 	movc	a,@a+dptr
      0065FF FF               [12] 1269 	mov	r7,a
      006600 90 08 78         [24] 1270 	mov	dptr,#_control_pointer
      006603 EE               [12] 1271 	mov	a,r6
      006604 F0               [24] 1272 	movx	@dptr,a
      006605 EF               [12] 1273 	mov	a,r7
      006606 A3               [24] 1274 	inc	dptr
      006607 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      006608 74 07            [12] 1277 	mov	a,#0x07
      00660A 2C               [12] 1278 	add	a, r4
      00660B F5 82            [12] 1279 	mov	dpl,a
      00660D E4               [12] 1280 	clr	a
      00660E 3D               [12] 1281 	addc	a, r5
      00660F F5 83            [12] 1282 	mov	dph,a
      006611 E4               [12] 1283 	clr	a
      006612 93               [24] 1284 	movc	a,@a+dptr
      006613 FE               [12] 1285 	mov	r6,a
      006614 A3               [24] 1286 	inc	dptr
      006615 E4               [12] 1287 	clr	a
      006616 93               [24] 1288 	movc	a,@a+dptr
      006617 FF               [12] 1289 	mov	r7,a
      006618 8E 82            [24] 1290 	mov	dpl, r6
      00661A 8F 83            [24] 1291 	mov	dph, r7
      00661C 22               [24] 1292 	ret
      00661D                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      00661D 90 08 78         [24] 1295 	mov	dptr,#_control_pointer
      006620 EC               [12] 1296 	mov	a,r4
      006621 F0               [24] 1297 	movx	@dptr,a
      006622 ED               [12] 1298 	mov	a,r5
      006623 A3               [24] 1299 	inc	dptr
      006624 F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      006625 90 00 09         [24] 1302 	mov	dptr,#0x0009
      006628 22               [24] 1303 	ret
      006629                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      006629 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      00662C 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      00662D                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      00662D 90 10 00         [24] 1330 	mov	dptr,#0x1000
      006630 E0               [24] 1331 	movx	a,@dptr
      006631 FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006632 A3               [24] 1334 	inc	dptr
      006633 A3               [24] 1335 	inc	dptr
      006634 E0               [24] 1336 	movx	a,@dptr
      006635 FE               [12] 1337 	mov	r6,a
      006636 A3               [24] 1338 	inc	dptr
      006637 E0               [24] 1339 	movx	a,@dptr
      006638 FC               [12] 1340 	mov	r4,a
      006639 7D 00            [12] 1341 	mov	r5,#0x00
      00663B 8E 03            [24] 1342 	mov	ar3,r6
      00663D 7E 00            [12] 1343 	mov	r6,#0x00
      00663F ED               [12] 1344 	mov	a,r5
      006640 4B               [12] 1345 	orl	a,r3
      006641 FD               [12] 1346 	mov	r5,a
      006642 EC               [12] 1347 	mov	a,r4
      006643 4E               [12] 1348 	orl	a,r6
      006644 FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      006645 A3               [24] 1351 	inc	dptr
      006646 E0               [24] 1352 	movx	a,@dptr
      006647 FC               [12] 1353 	mov	r4,a
      006648 A3               [24] 1354 	inc	dptr
      006649 E0               [24] 1355 	movx	a,@dptr
      00664A FA               [12] 1356 	mov	r2,a
      00664B 7B 00            [12] 1357 	mov	r3,#0x00
      00664D 8C 01            [24] 1358 	mov	ar1,r4
      00664F 7C 00            [12] 1359 	mov	r4,#0x00
      006651 EB               [12] 1360 	mov	a,r3
      006652 49               [12] 1361 	orl	a,r1
      006653 FB               [12] 1362 	mov	r3,a
      006654 EA               [12] 1363 	mov	a,r2
      006655 4C               [12] 1364 	orl	a,r4
      006656 FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      006657 C3               [12] 1367 	clr	c
      006658 EB               [12] 1368 	mov	a,r3
      006659 94 03            [12] 1369 	subb	a,#0x03
      00665B EC               [12] 1370 	mov	a,r4
      00665C 94 00            [12] 1371 	subb	a,#0x00
      00665E 92 19            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      006660 EB               [12] 1374 	mov	a,r3
      006661 4C               [12] 1375 	orl	a,r4
      006662 B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      006665                       1377 01201$:
      006665 92 1A            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      006667 ED               [12] 1380 	mov	a,r5
      006668 4E               [12] 1381 	orl	a,r6
      006669 B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      00666C                       1383 01202$:
                                   1384 ;	assignBit
      00666C 92 1D            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      00666E 92 1B            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      006670 90 08 80         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      006673 E4               [12] 1389 	clr	a
      006674 F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      006675 90 08 23         [24] 1392 	mov	dptr,#_raw_state
      006678 E0               [24] 1393 	movx	a,@dptr
      006679 FA               [12] 1394 	mov	r2,a
      00667A BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      00667D 90 08 23         [24] 1396 	mov	dptr,#_raw_state
      006680 E4               [12] 1397 	clr	a
      006681 F0               [24] 1398 	movx	@dptr,a
      006682                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      006682 C0 07            [24] 1401 	push	ar7
      006684 90 08 75         [24] 1402 	mov	dptr,#_output_kind
      006687 E4               [12] 1403 	clr	a
      006688 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      006689 90 08 74         [24] 1406 	mov	dptr,#_control_phase
      00668C F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      00668D 90 08 77         [24] 1409 	mov	dptr,#_control_zlp
      006690 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      006691 90 10 01         [24] 1412 	mov	dptr,#0x1001
      006694 E0               [24] 1413 	movx	a,@dptr
      006695 90 08 15         [24] 1414 	mov	dptr,#_D0SetupReqCode
      006698 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      006699 90 10 06         [24] 1417 	mov	dptr,#0x1006
      00669C E0               [24] 1418 	movx	a,@dptr
      00669D FA               [12] 1419 	mov	r2,a
      00669E A3               [24] 1420 	inc	dptr
      00669F E0               [24] 1421 	movx	a,@dptr
      0066A0 F9               [12] 1422 	mov	r1,a
      0066A1 78 00            [12] 1423 	mov	r0,#0x00
      0066A3 7F 00            [12] 1424 	mov	r7,#0x00
      0066A5 90 08 16         [24] 1425 	mov	dptr,#_D0SetupLen
      0066A8 E8               [12] 1426 	mov	a,r0
      0066A9 4A               [12] 1427 	orl	a,r2
      0066AA F0               [24] 1428 	movx	@dptr,a
      0066AB E9               [12] 1429 	mov	a,r1
      0066AC 4F               [12] 1430 	orl	a,r7
      0066AD A3               [24] 1431 	inc	dptr
      0066AE F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      0066AF 90 08 16         [24] 1434 	mov	dptr,#_D0SetupLen
      0066B2 E0               [24] 1435 	movx	a,@dptr
      0066B3 FA               [12] 1436 	mov	r2,a
      0066B4 A3               [24] 1437 	inc	dptr
      0066B5 E0               [24] 1438 	movx	a,@dptr
      0066B6 4A               [12] 1439 	orl	a,r2
      0066B7 B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      0066BA                       1441 01205$:
      0066BA 92 1C            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0066BC 90 22 00         [24] 1444 	mov	dptr,#0x2200
      0066BF 74 C2            [12] 1445 	mov	a,#0xc2
      0066C1 F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      0066C2 90 22 08         [24] 1448 	mov	dptr,#0x2208
      0066C5 E4               [12] 1449 	clr	a
      0066C6 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      0066C7 90 08 15         [24] 1452 	mov	dptr,#_D0SetupReqCode
      0066CA E0               [24] 1453 	movx	a,@dptr
      0066CB F5 27            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      0066CD C3               [12] 1455 	clr	c
      0066CE 74 0B            [12] 1456 	mov	a,#0x0b
      0066D0 95 27            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      0066D2 D0 07            [24] 1458 	pop	ar7
      0066D4 50 03            [24] 1459 	jnc	01206$
      0066D6 02 64 14         [24] 1460 	ljmp	_control_stall
      0066D9                       1461 01206$:
                                   1462 ;	free result
      0066D9 E5 27            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      0066DB F5 F0            [12] 1464 	mov	b,a
      0066DD 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      0066DF 83               [24] 1466 	movc	a,@a+pc
      0066E0 F5 82            [12] 1467 	mov	dpl,a
      0066E2 E5 F0            [12] 1468 	mov	a,b
      0066E4 24 10            [12] 1469 	add	a,#(01208$-3-.)
      0066E6 83               [24] 1470 	movc	a,@a+pc
      0066E7 F5 83            [12] 1471 	mov	dph,a
      0066E9 E4               [12] 1472 	clr	a
      0066EA 73               [24] 1473 	jmp	@a+dptr
      0066EB                       1474 01207$:
      0066EB 93                    1475 	.db	00188$
      0066EC 39                    1476 	.db	00205$
      0066ED 7C                    1477 	.db	00282$
      0066EE 39                    1478 	.db	00205$
      0066EF C0                    1479 	.db	00290$
      0066F0 BD                    1480 	.db	00116$
      0066F1 03                    1481 	.db	00103$
      0066F2 C0                    1482 	.db	00290$
      0066F3 C2                    1483 	.db	00150$
      0066F4 E6                    1484 	.db	00123$
      0066F5 F2                    1485 	.db	00157$
      0066F6 45                    1486 	.db	00173$
      0066F7                       1487 01208$:
      0066F7 69                    1488 	.db	00188$>>8
      0066F8 6A                    1489 	.db	00205$>>8
      0066F9 6D                    1490 	.db	00282$>>8
      0066FA 6A                    1491 	.db	00205$>>8
      0066FB 6D                    1492 	.db	00290$>>8
      0066FC 67                    1493 	.db	00116$>>8
      0066FD 67                    1494 	.db	00103$>>8
      0066FE 6D                    1495 	.db	00290$>>8
      0066FF 68                    1496 	.db	00150$>>8
      006700 67                    1497 	.db	00123$>>8
      006701 68                    1498 	.db	00157$>>8
      006702 69                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      006703                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      006703 BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      006706 80 08            [24] 1504 	sjmp	00112$
      006708                       1505 01209$:
      006708 BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      00670B 80 03            [24] 1507 	sjmp	01211$
      00670D                       1508 01210$:
      00670D 02 64 14         [24] 1509 	ljmp	_control_stall
      006710                       1510 01211$:
      006710                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006710 8E 01            [24] 1513 	mov	ar1,r6
      006712 B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      006715 80 09            [24] 1515 	sjmp	00301$
      006717                       1516 01212$:
      006717 B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      00671A 80 04            [24] 1518 	sjmp	00301$
      00671C                       1519 01213$:
                                   1520 ;	assignBit
      00671C C2 1E            [12] 1521 	clr	_control_setup_sloc2_1_0
      00671E 80 02            [24] 1522 	sjmp	00302$
      006720                       1523 00301$:
                                   1524 ;	assignBit
      006720 D2 1E            [12] 1525 	setb	_control_setup_sloc2_1_0
      006722                       1526 00302$:
      006722 E4               [12] 1527 	clr	a
      006723 BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      006726 04               [12] 1529 	inc	a
      006727                       1530 01214$:
      006727 FA               [12] 1531 	mov	r2,a
      006728 A2 1E            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      00672A E4               [12] 1533 	clr	a
      00672B 33               [12] 1534 	rlc	a
      00672C B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      00672F 80 03            [24] 1536 	sjmp	00105$
      006731                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      006731 02 64 14         [24] 1539 	ljmp	_control_stall
      006734                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      006734 8E 02            [24] 1542 	mov	ar2,r6
      006736 90 08 7A         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      006739 ED               [12] 1544 	mov	a,r5
      00673A F0               [24] 1545 	movx	@dptr,a
      00673B 90 08 7B         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      00673E EB               [12] 1547 	mov	a,r3
      00673F F0               [24] 1548 	movx	@dptr,a
      006740 EC               [12] 1549 	mov	a,r4
      006741 A3               [24] 1550 	inc	dptr
      006742 F0               [24] 1551 	movx	@dptr,a
      006743 8A 82            [24] 1552 	mov	dpl, r2
      006745 12 64 B2         [24] 1553 	lcall	_descriptor_select
      006748 85 82 28         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      00674B 85 83 29         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      00674E E5 28            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      006750 45 29            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      006752 70 03            [24] 1559 	jnz	00107$
      006754 02 64 14         [24] 1560 	ljmp	_control_stall
      006757                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      006757 90 08 16         [24] 1563 	mov	dptr,#_D0SetupLen
      00675A E0               [24] 1564 	movx	a,@dptr
      00675B F8               [12] 1565 	mov	r0,a
      00675C A3               [24] 1566 	inc	dptr
      00675D E0               [24] 1567 	movx	a,@dptr
      00675E FA               [12] 1568 	mov	r2,a
      00675F C3               [12] 1569 	clr	c
      006760 E5 28            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      006762 98               [12] 1571 	subb	a,r0
      006763 E5 29            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006765 9A               [12] 1573 	subb	a,r2
      006766 50 06            [24] 1574 	jnc	00303$
      006768 E5 28            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      00676A 54 3F            [12] 1576 	anl	a,#0x3f
      00676C 60 04            [24] 1577 	jz	00304$
      00676E                       1578 00303$:
                                   1579 ;	assignBit
      00676E C2 1E            [12] 1580 	clr	_control_setup_sloc2_1_0
      006770 80 02            [24] 1581 	sjmp	00305$
      006772                       1582 00304$:
                                   1583 ;	assignBit
      006772 D2 1E            [12] 1584 	setb	_control_setup_sloc2_1_0
      006774                       1585 00305$:
      006774 90 08 77         [24] 1586 	mov	dptr,#_control_zlp
      006777 A2 1E            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      006779 E4               [12] 1588 	clr	a
      00677A 33               [12] 1589 	rlc	a
      00677B F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      00677C 90 08 16         [24] 1592 	mov	dptr,#_D0SetupLen
      00677F E0               [24] 1593 	movx	a,@dptr
      006780 F9               [12] 1594 	mov	r1,a
      006781 A3               [24] 1595 	inc	dptr
      006782 E0               [24] 1596 	movx	a,@dptr
      006783 FA               [12] 1597 	mov	r2,a
      006784 C3               [12] 1598 	clr	c
      006785 E5 28            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      006787 99               [12] 1600 	subb	a,r1
      006788 E5 29            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00678A 9A               [12] 1602 	subb	a,r2
      00678B 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      00678D 90 08 16         [24] 1605 	mov	dptr,#_D0SetupLen
      006790 E5 28            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      006792 F0               [24] 1607 	movx	@dptr,a
      006793 E5 29            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006795 A3               [24] 1609 	inc	dptr
      006796 F0               [24] 1610 	movx	@dptr,a
      006797                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      006797 90 08 16         [24] 1613 	mov	dptr,#_D0SetupLen
      00679A E0               [24] 1614 	movx	a,@dptr
      00679B F9               [12] 1615 	mov	r1,a
      00679C A3               [24] 1616 	inc	dptr
      00679D E0               [24] 1617 	movx	a,@dptr
      00679E 49               [12] 1618 	orl	a,r1
      00679F 60 04            [24] 1619 	jz	00306$
      0067A1 7A 01            [12] 1620 	mov	r2,#0x01
      0067A3 80 02            [24] 1621 	sjmp	00307$
      0067A5                       1622 00306$:
      0067A5 7A 02            [12] 1623 	mov	r2,#0x02
      0067A7                       1624 00307$:
      0067A7 90 08 74         [24] 1625 	mov	dptr,#_control_phase
      0067AA EA               [12] 1626 	mov	a,r2
      0067AB F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      0067AC 90 08 16         [24] 1629 	mov	dptr,#_D0SetupLen
      0067AF E0               [24] 1630 	movx	a,@dptr
      0067B0 F9               [12] 1631 	mov	r1,a
      0067B1 A3               [24] 1632 	inc	dptr
      0067B2 E0               [24] 1633 	movx	a,@dptr
      0067B3 49               [12] 1634 	orl	a,r1
      0067B4 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      0067B6 02 64 36         [24] 1637 	ljmp	_control_next
      0067B9                       1638 00111$:
      0067B9 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      0067BA 02 64 14         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      0067BD                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      0067BD EF               [12] 1645 	mov	a,r7
      0067BE 70 23            [24] 1646 	jnz	00118$
      0067C0 30 1A 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      0067C3 30 1C 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      0067C6 8D 01            [24] 1649 	mov	ar1,r5
      0067C8 8E 02            [24] 1650 	mov	ar2,r6
      0067CA C3               [12] 1651 	clr	c
      0067CB 74 7F            [12] 1652 	mov	a,#0x7f
      0067CD 99               [12] 1653 	subb	a,r1
      0067CE E4               [12] 1654 	clr	a
      0067CF 9A               [12] 1655 	subb	a,r2
      0067D0 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      0067D2 90 08 16         [24] 1659 	mov	dptr,#_D0SetupLen
      0067D5 ED               [12] 1660 	mov	a,r5
      0067D6 F0               [24] 1661 	movx	@dptr,a
      0067D7 EE               [12] 1662 	mov	a,r6
      0067D8 A3               [24] 1663 	inc	dptr
      0067D9 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      0067DA 90 08 74         [24] 1666 	mov	dptr,#_control_phase
      0067DD 74 03            [12] 1667 	mov	a,#0x03
      0067DF F0               [24] 1668 	movx	@dptr,a
      0067E0 02 6D C3         [24] 1669 	ljmp	00291$
      0067E3                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      0067E3 02 64 14         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      0067E6                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      0067E6 EF               [12] 1676 	mov	a,r7
      0067E7 70 3C            [24] 1677 	jnz	00145$
      0067E9 30 1A 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      0067EC 30 1C 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      0067EF 8D 01            [24] 1680 	mov	ar1,r5
      0067F1 8E 02            [24] 1681 	mov	ar2,r6
      0067F3 C3               [12] 1682 	clr	c
      0067F4 74 01            [12] 1683 	mov	a,#0x01
      0067F6 99               [12] 1684 	subb	a,r1
      0067F7 E4               [12] 1685 	clr	a
      0067F8 9A               [12] 1686 	subb	a,r2
      0067F9 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      0067FB C0 06            [24] 1690 	push	ar6
      0067FD C0 05            [24] 1691 	push	ar5
      0067FF 12 63 BD         [24] 1692 	lcall	_endpoints_reset
      006802 D0 05            [24] 1693 	pop	ar5
      006804 D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      006806 90 08 1B         [24] 1696 	mov	dptr,#_D0UsbConfig
      006809 ED               [12] 1697 	mov	a,r5
      00680A F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      00680B A2 1D            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      00680D B3               [12] 1701 	cpl	c
      00680E 92 1E            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      006810 90 08 1C         [24] 1703 	mov	dptr,#_USB_EnumStatus
      006813 E4               [12] 1704 	clr	a
      006814 33               [12] 1705 	rlc	a
      006815 F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      006816 90 08 45         [24] 1708 	mov	dptr,#_keyboard_reset
      006819 74 01            [12] 1709 	mov	a,#0x01
      00681B F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      00681C 90 08 74         [24] 1712 	mov	dptr,#_control_phase
      00681F 74 03            [12] 1713 	mov	a,#0x03
      006821 F0               [24] 1714 	movx	@dptr,a
      006822 02 6D C3         [24] 1715 	ljmp	00291$
      006825                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      006825 BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      006828 80 03            [24] 1719 	sjmp	01232$
      00682A                       1720 01231$:
      00682A 02 64 14         [24] 1721 	ljmp	_control_stall
      00682D                       1722 01232$:
      00682D 90 08 1B         [24] 1723 	mov	dptr,#_D0UsbConfig
      006830 E0               [24] 1724 	movx	a,@dptr
      006831 70 03            [24] 1725 	jnz	01233$
      006833 02 64 14         [24] 1726 	ljmp	_control_stall
      006836                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      006836 BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      006839 BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      00683C 8D 01            [24] 1731 	mov	ar1,r5
      00683E 8E 02            [24] 1732 	mov	ar2,r6
      006840 B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      006843 BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      006846 90 08 16         [24] 1735 	mov	dptr,#_D0SetupLen
      006849 E0               [24] 1736 	movx	a,@dptr
      00684A F9               [12] 1737 	mov	r1,a
      00684B A3               [24] 1738 	inc	dptr
      00684C E0               [24] 1739 	movx	a,@dptr
      00684D FA               [12] 1740 	mov	r2,a
      00684E B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      006851 BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      006854 90 08 23         [24] 1743 	mov	dptr,#_raw_state
      006857 E0               [24] 1744 	movx	a,@dptr
      006858 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      00685A 90 08 23         [24] 1747 	mov	dptr,#_raw_state
      00685D 74 01            [12] 1748 	mov	a,#0x01
      00685F F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      006860 90 08 75         [24] 1751 	mov	dptr,#_output_kind
      006863 F0               [24] 1752 	movx	@dptr,a
      006864 80 52            [24] 1753 	sjmp	00136$
      006866                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006866 EB               [12] 1756 	mov	a,r3
      006867 4C               [12] 1757 	orl	a,r4
      006868 70 20            [24] 1758 	jnz	00130$
      00686A 8D 01            [24] 1759 	mov	ar1,r5
      00686C 8E 02            [24] 1760 	mov	ar2,r6
      00686E B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      006871 BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      006874 90 08 16         [24] 1763 	mov	dptr,#_D0SetupLen
      006877 E0               [24] 1764 	movx	a,@dptr
      006878 F9               [12] 1765 	mov	r1,a
      006879 A3               [24] 1766 	inc	dptr
      00687A E0               [24] 1767 	movx	a,@dptr
      00687B FA               [12] 1768 	mov	r2,a
      00687C B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      00687F BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      006882 90 08 75         [24] 1772 	mov	dptr,#_output_kind
      006885 74 02            [12] 1773 	mov	a,#0x02
      006887 F0               [24] 1774 	movx	@dptr,a
      006888 80 2E            [24] 1775 	sjmp	00136$
      00688A                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      00688A BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      00688D BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      006890 8D 01            [24] 1780 	mov	ar1,r5
      006892 8E 02            [24] 1781 	mov	ar2,r6
      006894 B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      006897 BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      00689A 90 08 16         [24] 1784 	mov	dptr,#_D0SetupLen
      00689D E0               [24] 1785 	movx	a,@dptr
      00689E F9               [12] 1786 	mov	r1,a
      00689F A3               [24] 1787 	inc	dptr
      0068A0 E0               [24] 1788 	movx	a,@dptr
      0068A1 FA               [12] 1789 	mov	r2,a
      0068A2 B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      0068A5 BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      0068A8 90 08 75         [24] 1793 	mov	dptr,#_output_kind
      0068AB 74 03            [12] 1794 	mov	a,#0x03
      0068AD F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      0068AE 90 08 76         [24] 1797 	mov	dptr,#_output_report_id
      0068B1 23               [12] 1798 	rl	a
      0068B2 F0               [24] 1799 	movx	@dptr,a
      0068B3 80 03            [24] 1800 	sjmp	00136$
      0068B5                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      0068B5 02 64 14         [24] 1803 	ljmp	_control_stall
      0068B8                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      0068B8 90 08 74         [24] 1806 	mov	dptr,#_control_phase
      0068BB 74 04            [12] 1807 	mov	a,#0x04
      0068BD F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      0068BE 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      0068BF 02 64 14         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      0068C2                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      0068C2 BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      0068C5 30 1A 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      0068C8 30 1B 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      0068CB 90 08 16         [24] 1819 	mov	dptr,#_D0SetupLen
      0068CE E0               [24] 1820 	movx	a,@dptr
      0068CF F9               [12] 1821 	mov	r1,a
      0068D0 A3               [24] 1822 	inc	dptr
      0068D1 E0               [24] 1823 	movx	a,@dptr
      0068D2 FA               [12] 1824 	mov	r2,a
      0068D3 B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      0068D6 BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      0068D9 90 08 1B         [24] 1828 	mov	dptr,#_D0UsbConfig
      0068DC E0               [24] 1829 	movx	a,@dptr
      0068DD 90 10 00         [24] 1830 	mov	dptr,#0x1000
      0068E0 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      0068E1 90 22 08         [24] 1833 	mov	dptr,#0x2208
      0068E4 74 01            [12] 1834 	mov	a,#0x01
      0068E6 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      0068E7 90 08 74         [24] 1837 	mov	dptr,#_control_phase
      0068EA 04               [12] 1838 	inc	a
      0068EB F0               [24] 1839 	movx	@dptr,a
      0068EC 02 6D C3         [24] 1840 	ljmp	00291$
      0068EF                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      0068EF 02 64 14         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0068F2                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0068F2 BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      0068F5 30 19 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      0068F8 30 1B 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      0068FB 90 08 16         [24] 1850 	mov	dptr,#_D0SetupLen
      0068FE E0               [24] 1851 	movx	a,@dptr
      0068FF F9               [12] 1852 	mov	r1,a
      006900 A3               [24] 1853 	inc	dptr
      006901 E0               [24] 1854 	movx	a,@dptr
      006902 FA               [12] 1855 	mov	r2,a
      006903 B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      006906 BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      006909 90 08 1B         [24] 1858 	mov	dptr,#_D0UsbConfig
      00690C E0               [24] 1859 	movx	a,@dptr
      00690D 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      00690F 90 10 00         [24] 1862 	mov	dptr,#0x1000
      006912 E4               [12] 1863 	clr	a
      006913 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      006914 90 22 08         [24] 1866 	mov	dptr,#0x2208
      006917 04               [12] 1867 	inc	a
      006918 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      006919 90 08 74         [24] 1870 	mov	dptr,#_control_phase
      00691C 04               [12] 1871 	inc	a
      00691D F0               [24] 1872 	movx	@dptr,a
      00691E 02 6D C3         [24] 1873 	ljmp	00291$
      006921                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      006921 30 19 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      006924 90 08 1B         [24] 1877 	mov	dptr,#_D0UsbConfig
      006927 E0               [24] 1878 	movx	a,@dptr
      006928 60 18            [24] 1879 	jz	00161$
      00692A BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      00692D 30 1C 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006930 EB               [12] 1883 	mov	a,r3
      006931 4C               [12] 1884 	orl	a,r4
      006932 70 05            [24] 1885 	jnz	00159$
      006934 90 06 F3         [24] 1886 	mov	dptr,#_keyboard_idle
      006937 EE               [12] 1887 	mov	a,r6
      006938 F0               [24] 1888 	movx	@dptr,a
      006939                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      006939 90 08 74         [24] 1891 	mov	dptr,#_control_phase
      00693C 74 03            [12] 1892 	mov	a,#0x03
      00693E F0               [24] 1893 	movx	@dptr,a
      00693F 02 6D C3         [24] 1894 	ljmp	00291$
      006942                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      006942 02 64 14         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006945                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006945 BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      006948 30 19 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      00694B 30 1B 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      00694E 30 1C 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      006951 90 08 1B         [24] 1905 	mov	dptr,#_D0UsbConfig
      006954 E0               [24] 1906 	movx	a,@dptr
      006955 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      006957 90 08 74         [24] 1909 	mov	dptr,#_control_phase
      00695A 74 03            [12] 1910 	mov	a,#0x03
      00695C F0               [24] 1911 	movx	@dptr,a
      00695D 02 6D C3         [24] 1912 	ljmp	00291$
      006960                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006960 EB               [12] 1915 	mov	a,r3
      006961 4C               [12] 1916 	orl	a,r4
      006962 70 2C            [24] 1917 	jnz	00175$
      006964 90 08 1B         [24] 1918 	mov	dptr,#_D0UsbConfig
      006967 E0               [24] 1919 	movx	a,@dptr
      006968 60 26            [24] 1920 	jz	00175$
      00696A BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      00696D 30 1C 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      006970 8D 01            [24] 1923 	mov	ar1,r5
      006972 8E 02            [24] 1924 	mov	ar2,r6
      006974 C3               [12] 1925 	clr	c
      006975 74 01            [12] 1926 	mov	a,#0x01
      006977 99               [12] 1927 	subb	a,r1
      006978 E4               [12] 1928 	clr	a
      006979 9A               [12] 1929 	subb	a,r2
      00697A 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      00697C 90 0E 86         [24] 1933 	mov	dptr,#_keyboard_protocol
      00697F ED               [12] 1934 	mov	a,r5
      006980 F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      006981 90 08 45         [24] 1937 	mov	dptr,#_keyboard_reset
      006984 74 01            [12] 1938 	mov	a,#0x01
      006986 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      006987 90 08 74         [24] 1941 	mov	dptr,#_control_phase
      00698A 74 03            [12] 1942 	mov	a,#0x03
      00698C F0               [24] 1943 	movx	@dptr,a
      00698D 02 6D C3         [24] 1944 	ljmp	00291$
      006990                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      006990 02 64 14         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      006993                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      006993 20 1B 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      006996 02 64 14         [24] 1952 	ljmp	_control_stall
      006999                       1953 01283$:
      006999 90 08 16         [24] 1954 	mov	dptr,#_D0SetupLen
      00699C E0               [24] 1955 	movx	a,@dptr
      00699D F9               [12] 1956 	mov	r1,a
      00699E A3               [24] 1957 	inc	dptr
      00699F E0               [24] 1958 	movx	a,@dptr
      0069A0 FA               [12] 1959 	mov	r2,a
      0069A1 B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      0069A4 BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      0069A7 80 03            [24] 1962 	sjmp	01285$
      0069A9                       1963 01284$:
      0069A9 02 64 14         [24] 1964 	ljmp	_control_stall
      0069AC                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      0069AC E4               [12] 1967 	clr	a
      0069AD BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      0069B0 04               [12] 1969 	inc	a
      0069B1                       1970 01286$:
      0069B1 FA               [12] 1971 	mov	r2,a
      0069B2 60 03            [24] 1972 	jz	00196$
      0069B4 20 1A 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      0069B7                       1974 00196$:
      0069B7 BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      0069BA 30 19 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      0069BD 90 08 1B         [24] 1977 	mov	dptr,#_D0UsbConfig
      0069C0 E0               [24] 1978 	movx	a,@dptr
      0069C1 70 29            [24] 1979 	jnz	00189$
      0069C3                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      0069C3 BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      0069C6 90 08 1B         [24] 1983 	mov	dptr,#_D0UsbConfig
      0069C9 E0               [24] 1984 	movx	a,@dptr
      0069CA 60 6A            [24] 1985 	jz	00190$
      0069CC EB               [12] 1986 	mov	a,r3
      0069CD 4C               [12] 1987 	orl	a,r4
      0069CE 60 1C            [24] 1988 	jz	00189$
      0069D0 8B 00            [24] 1989 	mov	ar0,r3
      0069D2 8C 01            [24] 1990 	mov	ar1,r4
      0069D4 B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      0069D7 B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      0069DA 80 10            [24] 1993 	sjmp	00189$
      0069DC                       1994 01298$:
      0069DC C3               [12] 1995 	clr	c
      0069DD E8               [12] 1996 	mov	a,r0
      0069DE 94 81            [12] 1997 	subb	a,#0x81
      0069E0 E9               [12] 1998 	mov	a,r1
      0069E1 94 00            [12] 1999 	subb	a,#0x00
      0069E3 40 51            [24] 2000 	jc	00190$
      0069E5 74 83            [12] 2001 	mov	a,#0x83
      0069E7 98               [12] 2002 	subb	a,r0
      0069E8 E4               [12] 2003 	clr	a
      0069E9 99               [12] 2004 	subb	a,r1
      0069EA 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      0069EC                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      0069EC 8B 01            [24] 2009 	mov	ar1,r3
      0069EE 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0069F1 EA               [12] 2012 	mov	a,r2
      0069F2 60 0B            [24] 2013 	jz	00308$
      0069F4 90 08 1D         [24] 2014 	mov	dptr,#_USB_SleepStatus
      0069F7 E0               [24] 2015 	movx	a,@dptr
      0069F8 54 01            [12] 2016 	anl	a,#0x01
      0069FA 25 E0            [12] 2017 	add	a,acc
      0069FC FA               [12] 2018 	mov	r2,a
      0069FD 80 22            [24] 2019 	sjmp	00309$
      0069FF                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0069FF BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      006A02 E9               [12] 2023 	mov	a,r1
      006A03 60 18            [24] 2024 	jz	00310$
      006A05 89 00            [24] 2025 	mov	ar0,r1
      006A07 79 00            [12] 2026 	mov	r1,#0x00
      006A09 74 22            [12] 2027 	mov	a,#0x22
      006A0B 29               [12] 2028 	add	a, r1
      006A0C F9               [12] 2029 	mov	r1,a
      006A0D 88 82            [24] 2030 	mov	dpl,r0
      006A0F 89 83            [24] 2031 	mov	dph,r1
      006A11 E0               [24] 2032 	movx	a,@dptr
      006A12 F9               [12] 2033 	mov	r1,a
      006A13 53 01 03         [24] 2034 	anl	ar1,#0x03
      006A16 B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      006A19 79 01            [12] 2036 	mov	r1,#0x01
      006A1B 80 02            [24] 2037 	sjmp	00311$
      006A1D                       2038 00310$:
      006A1D 79 00            [12] 2039 	mov	r1,#0x00
      006A1F                       2040 00311$:
      006A1F 89 02            [24] 2041 	mov	ar2,r1
      006A21                       2042 00309$:
      006A21 90 10 00         [24] 2043 	mov	dptr,#0x1000
      006A24 EA               [12] 2044 	mov	a,r2
      006A25 F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      006A26 A3               [24] 2047 	inc	dptr
      006A27 E4               [12] 2048 	clr	a
      006A28 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      006A29 90 22 08         [24] 2051 	mov	dptr,#0x2208
      006A2C 74 02            [12] 2052 	mov	a,#0x02
      006A2E F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      006A2F 90 08 74         [24] 2055 	mov	dptr,#_control_phase
      006A32 F0               [24] 2056 	movx	@dptr,a
      006A33 02 6D C3         [24] 2057 	ljmp	00291$
      006A36                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      006A36 02 64 14         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006A39                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      006A39 20 1C 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      006A3C 02 6A CC         [24] 2065 	ljmp	00279$
      006A3F                       2066 01307$:
      006A3F 90 08 1B         [24] 2067 	mov	dptr,#_D0UsbConfig
      006A42 E0               [24] 2068 	movx	a,@dptr
      006A43 70 03            [24] 2069 	jnz	01308$
      006A45 02 6A CC         [24] 2070 	ljmp	00279$
      006A48                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      006A48 EF               [12] 2073 	mov	a,r7
      006A49 70 29            [24] 2074 	jnz	00218$
      006A4B 8D 01            [24] 2075 	mov	ar1,r5
      006A4D 8E 02            [24] 2076 	mov	ar2,r6
      006A4F B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      006A52 BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      006A55 30 1A 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006A58 90 08 15         [24] 2081 	mov	dptr,#_D0SetupReqCode
      006A5B E0               [24] 2082 	movx	a,@dptr
      006A5C FA               [12] 2083 	mov	r2,a
      006A5D BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      006A60 90 08 1D         [24] 2085 	mov	dptr,#_USB_SleepStatus
      006A63 E0               [24] 2086 	movx	a,@dptr
      006A64 43 E0 01         [24] 2087 	orl	acc,#0x01
      006A67 F0               [24] 2088 	movx	@dptr,a
      006A68 80 59            [24] 2089 	sjmp	00219$
      006A6A                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      006A6A 90 08 1D         [24] 2092 	mov	dptr,#_USB_SleepStatus
      006A6D E0               [24] 2093 	movx	a,@dptr
      006A6E 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      006A71 F0               [24] 2095 	movx	@dptr,a
      006A72 80 4F            [24] 2096 	sjmp	00219$
      006A74                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006A74 BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      006A77 30 1B 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      006A7A 8B 01            [24] 2101 	mov	ar1,r3
      006A7C 8C 02            [24] 2102 	mov	ar2,r4
      006A7E C3               [12] 2103 	clr	c
      006A7F E9               [12] 2104 	mov	a,r1
      006A80 94 81            [12] 2105 	subb	a,#0x81
      006A82 EA               [12] 2106 	mov	a,r2
      006A83 94 00            [12] 2107 	subb	a,#0x00
      006A85 40 39            [24] 2108 	jc	00212$
      006A87 74 83            [12] 2109 	mov	a,#0x83
      006A89 99               [12] 2110 	subb	a,r1
      006A8A E4               [12] 2111 	clr	a
      006A8B 9A               [12] 2112 	subb	a,r2
      006A8C 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      006A8E 8B 02            [24] 2116 	mov	ar2,r3
      006A90 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006A93 8A 00            [24] 2119 	mov	ar0,r2
      006A95 79 00            [12] 2120 	mov	r1,#0x00
      006A97 74 22            [12] 2121 	mov	a,#0x22
      006A99 29               [12] 2122 	add	a, r1
      006A9A F9               [12] 2123 	mov	r1,a
      006A9B 88 28            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      006A9D 89 29            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006A9F 90 08 15         [24] 2126 	mov	dptr,#_D0SetupReqCode
      006AA2 E0               [24] 2127 	movx	a,@dptr
      006AA3 F9               [12] 2128 	mov	r1,a
      006AA4 B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      006AA7 79 03            [12] 2130 	mov	r1,#0x03
      006AA9 80 02            [24] 2131 	sjmp	00319$
      006AAB                       2132 00318$:
      006AAB 79 02            [12] 2133 	mov	r1,#0x02
      006AAD                       2134 00319$:
      006AAD 43 01 10         [24] 2135 	orl	ar1,#0x10
      006AB0 85 28 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      006AB3 85 29 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006AB6 E9               [12] 2138 	mov	a,r1
      006AB7 F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006AB8 BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      006ABB 12 63 A0         [24] 2142 	lcall	_raw_complete
      006ABE 80 03            [24] 2143 	sjmp	00219$
      006AC0                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      006AC0 02 64 14         [24] 2146 	ljmp	_control_stall
      006AC3                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      006AC3 90 08 74         [24] 2149 	mov	dptr,#_control_phase
      006AC6 74 03            [12] 2150 	mov	a,#0x03
      006AC8 F0               [24] 2151 	movx	@dptr,a
      006AC9 02 6D C3         [24] 2152 	ljmp	00291$
      006ACC                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006ACC E4               [12] 2155 	clr	a
      006ACD BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      006AD0 04               [12] 2157 	inc	a
      006AD1                       2158 01324$:
      006AD1 FA               [12] 2159 	mov	r2,a
      006AD2 70 03            [24] 2160 	jnz	01326$
      006AD4 02 6D 3E         [24] 2161 	ljmp	00273$
      006AD7                       2162 01326$:
      006AD7 90 08 15         [24] 2163 	mov	dptr,#_D0SetupReqCode
      006ADA E0               [24] 2164 	movx	a,@dptr
      006ADB F9               [12] 2165 	mov	r1,a
      006ADC B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      006ADF 80 03            [24] 2167 	sjmp	01328$
      006AE1                       2168 01327$:
      006AE1 02 6D 3E         [24] 2169 	ljmp	00273$
      006AE4                       2170 01328$:
      006AE4 90 08 1B         [24] 2171 	mov	dptr,#_D0UsbConfig
      006AE7 E0               [24] 2172 	movx	a,@dptr
      006AE8 70 03            [24] 2173 	jnz	01329$
      006AEA 02 6D 3E         [24] 2174 	ljmp	00273$
      006AED                       2175 01329$:
      006AED 90 08 16         [24] 2176 	mov	dptr,#_D0SetupLen
      006AF0 E0               [24] 2177 	movx	a,@dptr
      006AF1 F8               [12] 2178 	mov	r0,a
      006AF2 A3               [24] 2179 	inc	dptr
      006AF3 E0               [24] 2180 	movx	a,@dptr
      006AF4 48               [12] 2181 	orl	a,r0
      006AF5 70 03            [24] 2182 	jnz	01330$
      006AF7 02 6D 3E         [24] 2183 	ljmp	00273$
      006AFA                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      006AFA C0 03            [24] 2186 	push	ar3
      006AFC C0 04            [24] 2187 	push	ar4
      006AFE 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006B00 8E 00            [24] 2190 	mov	ar0,r6
      006B02 B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      006B05 E8               [12] 2192 	mov	a,r0
      006B06 80 01            [24] 2193 	sjmp	01332$
      006B08                       2194 01331$:
      006B08 E4               [12] 2195 	clr	a
      006B09                       2196 01332$:
      006B09 F5 28            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      006B0B D0 04            [24] 2198 	pop	ar4
      006B0D D0 03            [24] 2199 	pop	ar3
      006B0F E5 28            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      006B11 60 17            [24] 2201 	jz	00251$
      006B13 EB               [12] 2202 	mov	a,r3
      006B14 4C               [12] 2203 	orl	a,r4
      006B15 70 13            [24] 2204 	jnz	00251$
      006B17 E9               [12] 2205 	mov	a,r1
      006B18 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      006B1A 90 08 7E         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      006B1D 74 08            [12] 2209 	mov	a,#0x08
      006B1F F0               [24] 2210 	movx	@dptr,a
      006B20 E4               [12] 2211 	clr	a
      006B21 A3               [24] 2212 	inc	dptr
      006B22 F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      006B23 90 08 80         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      006B26 F0               [24] 2216 	movx	@dptr,a
      006B27 02 6C AE         [24] 2217 	ljmp	00252$
      006B2A                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006B2A E5 28            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      006B2C 60 27            [24] 2221 	jz	00245$
      006B2E BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      006B31 BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006B34 B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      006B37                       2226 01339$:
      006B37 50 1C            [24] 2227 	jnc	00245$
      006B39 E9               [12] 2228 	mov	a,r1
      006B3A 90 C4 1C         [24] 2229 	mov	dptr,#_shared_lengths
      006B3D 93               [24] 2230 	movc	a,@a+dptr
      006B3E F8               [12] 2231 	mov	r0,a
      006B3F 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      006B41 90 08 7E         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      006B44 E8               [12] 2235 	mov	a,r0
      006B45 F0               [24] 2236 	movx	@dptr,a
      006B46 E4               [12] 2237 	clr	a
      006B47 A3               [24] 2238 	inc	dptr
      006B48 F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      006B49 E9               [12] 2241 	mov	a,r1
      006B4A 90 C4 15         [24] 2242 	mov	dptr,#_shared_offsets
      006B4D 93               [24] 2243 	movc	a,@a+dptr
      006B4E 90 08 80         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      006B51 F0               [24] 2245 	movx	@dptr,a
      006B52 02 6C AE         [24] 2246 	ljmp	00252$
      006B55                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006B55 E5 28            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      006B57 60 7A            [24] 2250 	jz	00240$
      006B59 BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      006B5C BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      006B5F E9               [12] 2253 	mov	a,r1
      006B60 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006B62 90 08 16         [24] 2256 	mov	dptr,#_D0SetupLen
      006B65 E0               [24] 2257 	movx	a,@dptr
      006B66 F8               [12] 2258 	mov	r0,a
      006B67 A3               [24] 2259 	inc	dptr
      006B68 E0               [24] 2260 	movx	a,@dptr
      006B69 F9               [12] 2261 	mov	r1,a
      006B6A C3               [12] 2262 	clr	c
      006B6B E8               [12] 2263 	mov	a,r0
      006B6C 94 20            [12] 2264 	subb	a,#0x20
      006B6E E9               [12] 2265 	mov	a,r1
      006B6F 94 00            [12] 2266 	subb	a,#0x00
      006B71 50 0A            [24] 2267 	jnc	00320$
      006B73 90 08 16         [24] 2268 	mov	dptr,#_D0SetupLen
      006B76 E0               [24] 2269 	movx	a,@dptr
      006B77 F8               [12] 2270 	mov	r0,a
      006B78 A3               [24] 2271 	inc	dptr
      006B79 E0               [24] 2272 	movx	a,@dptr
      006B7A F9               [12] 2273 	mov	r1,a
      006B7B 80 04            [24] 2274 	sjmp	00321$
      006B7D                       2275 00320$:
      006B7D 78 20            [12] 2276 	mov	r0,#0x20
      006B7F 79 00            [12] 2277 	mov	r1,#0x00
      006B81                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006B81 75 28 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      006B84                       2281 00293$:
      006B84 C0 03            [24] 2282 	push	ar3
      006B86 C0 04            [24] 2283 	push	ar4
      006B88 AB 28            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      006B8A 7C 00            [12] 2285 	mov	r4,#0x00
      006B8C C3               [12] 2286 	clr	c
      006B8D EB               [12] 2287 	mov	a,r3
      006B8E 98               [12] 2288 	subb	a,r0
      006B8F EC               [12] 2289 	mov	a,r4
      006B90 99               [12] 2290 	subb	a,r1
      006B91 D0 04            [24] 2291 	pop	ar4
      006B93 D0 03            [24] 2292 	pop	ar3
      006B95 50 32            [24] 2293 	jnc	00222$
      006B97 C0 00            [24] 2294 	push	ar0
      006B99 C0 01            [24] 2295 	push	ar1
      006B9B 85 28 2A         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006B9E 74 10            [12] 2297 	mov	a,#0x10
      006BA0 24 00            [12] 2298 	add	a, #0x00
      006BA2 F5 2B            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      006BA4 A8 28            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      006BA6 79 00            [12] 2301 	mov	r1,#0x00
      006BA8 74 C0            [12] 2302 	mov	a,#0xc0
      006BAA 28               [12] 2303 	add	a, r0
      006BAB F8               [12] 2304 	mov	r0,a
      006BAC E4               [12] 2305 	clr	a
      006BAD 39               [12] 2306 	addc	a, r1
      006BAE F9               [12] 2307 	mov	r1,a
      006BAF 88 82            [24] 2308 	mov	dpl,r0
      006BB1 74 10            [12] 2309 	mov	a,#0x10
      006BB3 29               [12] 2310 	add	a, r1
      006BB4 F5 83            [12] 2311 	mov	dph,a
      006BB6 E0               [24] 2312 	movx	a,@dptr
      006BB7 85 2A 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      006BBA 85 2B 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006BBD F0               [24] 2315 	movx	@dptr,a
      006BBE E5 28            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      006BC0 04               [12] 2317 	inc	a
      006BC1 F5 28            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      006BC3 D0 01            [24] 2319 	pop	ar1
      006BC5 D0 00            [24] 2320 	pop	ar0
      006BC7 80 BB            [24] 2321 	sjmp	00293$
      006BC9                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      006BC9 90 08 7E         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      006BCC E4               [12] 2325 	clr	a
      006BCD F0               [24] 2326 	movx	@dptr,a
      006BCE A3               [24] 2327 	inc	dptr
      006BCF F0               [24] 2328 	movx	@dptr,a
      006BD0 02 6C AE         [24] 2329 	ljmp	00252$
      006BD3                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006BD3 8D 00            [24] 2332 	mov	ar0,r5
      006BD5 8E 01            [24] 2333 	mov	ar1,r6
      006BD7 B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      006BDA B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      006BDD EB               [12] 2336 	mov	a,r3
      006BDE 4C               [12] 2337 	orl	a,r4
      006BDF 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006BE1 90 08 20         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      006BE4 E0               [24] 2341 	movx	a,@dptr
      006BE5 90 10 00         [24] 2342 	mov	dptr,#0x1000
      006BE8 F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      006BE9 90 08 7E         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      006BEC E4               [12] 2346 	clr	a
      006BED F0               [24] 2347 	movx	@dptr,a
      006BEE A3               [24] 2348 	inc	dptr
      006BEF F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      006BF0 90 08 16         [24] 2351 	mov	dptr,#_D0SetupLen
      006BF3 04               [12] 2352 	inc	a
      006BF4 F0               [24] 2353 	movx	@dptr,a
      006BF5 E4               [12] 2354 	clr	a
      006BF6 A3               [24] 2355 	inc	dptr
      006BF7 F0               [24] 2356 	movx	@dptr,a
      006BF8 02 6C AE         [24] 2357 	ljmp	00252$
      006BFB                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006BFB B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      006BFE B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      006C01 BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      006C04 BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      006C07 C0 03            [24] 2365 	push	ar3
      006C09 C0 04            [24] 2366 	push	ar4
      006C0B 90 10 00         [24] 2367 	mov	dptr,#0x1000
      006C0E 74 06            [12] 2368 	mov	a,#0x06
      006C10 F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006C11 90 08 20         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      006C14 E0               [24] 2372 	movx	a,@dptr
      006C15 90 10 01         [24] 2373 	mov	dptr,#0x1001
      006C18 F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      006C19 90 08 7E         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      006C1C E4               [12] 2377 	clr	a
      006C1D F0               [24] 2378 	movx	@dptr,a
      006C1E A3               [24] 2379 	inc	dptr
      006C1F F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      006C20 90 08 16         [24] 2382 	mov	dptr,#_D0SetupLen
      006C23 E0               [24] 2383 	movx	a,@dptr
      006C24 FB               [12] 2384 	mov	r3,a
      006C25 A3               [24] 2385 	inc	dptr
      006C26 E0               [24] 2386 	movx	a,@dptr
      006C27 FC               [12] 2387 	mov	r4,a
      006C28 C3               [12] 2388 	clr	c
      006C29 74 02            [12] 2389 	mov	a,#0x02
      006C2B 9B               [12] 2390 	subb	a,r3
      006C2C E4               [12] 2391 	clr	a
      006C2D 9C               [12] 2392 	subb	a,r4
      006C2E D0 04            [24] 2393 	pop	ar4
      006C30 D0 03            [24] 2394 	pop	ar3
      006C32 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      006C34 90 08 16         [24] 2397 	mov	dptr,#_D0SetupLen
      006C37 74 02            [12] 2398 	mov	a,#0x02
      006C39 F0               [24] 2399 	movx	@dptr,a
      006C3A E4               [12] 2400 	clr	a
      006C3B A3               [24] 2401 	inc	dptr
      006C3C F0               [24] 2402 	movx	@dptr,a
      006C3D 80 6F            [24] 2403 	sjmp	00252$
      006C3F                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006C3F B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      006C42 B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      006C45 BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      006C48 BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      006C4B 90 10 00         [24] 2411 	mov	dptr,#0x1000
      006C4E 74 41            [12] 2412 	mov	a,#0x41
      006C50 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      006C51 A3               [24] 2415 	inc	dptr
      006C52 74 4B            [12] 2416 	mov	a,#0x4b
      006C54 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      006C55 A3               [24] 2419 	inc	dptr
      006C56 74 42            [12] 2420 	mov	a,#0x42
      006C58 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      006C59 A3               [24] 2423 	inc	dptr
      006C5A 74 54            [12] 2424 	mov	a,#0x54
      006C5C F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      006C5D A3               [24] 2427 	inc	dptr
      006C5E 74 01            [12] 2428 	mov	a,#0x01
      006C60 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      006C61 90 08 21         [24] 2431 	mov	dptr,#_ak820_boot_stage
      006C64 E0               [24] 2432 	movx	a,@dptr
      006C65 90 10 05         [24] 2433 	mov	dptr,#0x1005
      006C68 F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006C69 90 08 22         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      006C6C E0               [24] 2437 	movx	a,@dptr
      006C6D 90 10 06         [24] 2438 	mov	dptr,#0x1006
      006C70 F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006C71 90 08 1C         [24] 2441 	mov	dptr,#_USB_EnumStatus
      006C74 E0               [24] 2442 	movx	a,@dptr
      006C75 60 02            [24] 2443 	jz	00322$
      006C77 74 01            [12] 2444 	mov	a,#0x01
      006C79                       2445 00322$:
      006C79 F9               [12] 2446 	mov	r1,a
      006C7A 90 08 1D         [24] 2447 	mov	dptr,#_USB_SleepStatus
      006C7D E0               [24] 2448 	movx	a,@dptr
      006C7E 54 02            [12] 2449 	anl	a,#0x02
      006C80 F8               [12] 2450 	mov	r0,a
      006C81 E9               [12] 2451 	mov	a,r1
      006C82 42 00            [12] 2452 	orl	ar0,a
      006C84 90 10 07         [24] 2453 	mov	dptr,#0x1007
      006C87 E8               [12] 2454 	mov	a,r0
      006C88 F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      006C89 90 08 7E         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      006C8C E4               [12] 2458 	clr	a
      006C8D F0               [24] 2459 	movx	@dptr,a
      006C8E A3               [24] 2460 	inc	dptr
      006C8F F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      006C90 90 08 16         [24] 2463 	mov	dptr,#_D0SetupLen
      006C93 E0               [24] 2464 	movx	a,@dptr
      006C94 F8               [12] 2465 	mov	r0,a
      006C95 A3               [24] 2466 	inc	dptr
      006C96 E0               [24] 2467 	movx	a,@dptr
      006C97 F9               [12] 2468 	mov	r1,a
      006C98 C3               [12] 2469 	clr	c
      006C99 74 08            [12] 2470 	mov	a,#0x08
      006C9B 98               [12] 2471 	subb	a,r0
      006C9C E4               [12] 2472 	clr	a
      006C9D 99               [12] 2473 	subb	a,r1
      006C9E 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      006CA0 90 08 16         [24] 2476 	mov	dptr,#_D0SetupLen
      006CA3 74 08            [12] 2477 	mov	a,#0x08
      006CA5 F0               [24] 2478 	movx	@dptr,a
      006CA6 E4               [12] 2479 	clr	a
      006CA7 A3               [24] 2480 	inc	dptr
      006CA8 F0               [24] 2481 	movx	@dptr,a
      006CA9 80 03            [24] 2482 	sjmp	00252$
      006CAB                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      006CAB 02 64 14         [24] 2485 	ljmp	_control_stall
      006CAE                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      006CAE 90 08 7E         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      006CB1 E0               [24] 2489 	movx	a,@dptr
      006CB2 F5 2A            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      006CB4 A3               [24] 2491 	inc	dptr
      006CB5 E0               [24] 2492 	movx	a,@dptr
      006CB6 F5 2B            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      006CB8 E5 2A            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      006CBA 45 2B            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006CBC 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      006CBE 90 08 16         [24] 2498 	mov	dptr,#_D0SetupLen
      006CC1 E0               [24] 2499 	movx	a,@dptr
      006CC2 F8               [12] 2500 	mov	r0,a
      006CC3 A3               [24] 2501 	inc	dptr
      006CC4 E0               [24] 2502 	movx	a,@dptr
      006CC5 F9               [12] 2503 	mov	r1,a
      006CC6 C3               [12] 2504 	clr	c
      006CC7 E5 2A            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      006CC9 98               [12] 2506 	subb	a,r0
      006CCA E5 2B            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006CCC 99               [12] 2508 	subb	a,r1
      006CCD 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      006CCF 90 08 16         [24] 2511 	mov	dptr,#_D0SetupLen
      006CD2 E5 2A            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      006CD4 F0               [24] 2513 	movx	@dptr,a
      006CD5 E5 2B            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006CD7 A3               [24] 2515 	inc	dptr
      006CD8 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      006CD9                       2518 00559$:
      006CD9 75 2A 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      006CDC                       2520 00296$:
      006CDC 90 08 16         [24] 2521 	mov	dptr,#_D0SetupLen
      006CDF E0               [24] 2522 	movx	a,@dptr
      006CE0 F8               [12] 2523 	mov	r0,a
      006CE1 C3               [12] 2524 	clr	c
      006CE2 E5 2A            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      006CE4 98               [12] 2526 	subb	a,r0
      006CE5 50 46            [24] 2527 	jnc	00263$
      006CE7 85 2A 28         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006CEA 74 10            [12] 2529 	mov	a,#0x10
      006CEC 24 00            [12] 2530 	add	a, #0x00
      006CEE F5 29            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      006CF0 90 08 80         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      006CF3 E0               [24] 2533 	movx	a,@dptr
      006CF4 25 2A            [12] 2534 	add	a, _control_setup_sloc4_1_0
      006CF6 24 46            [12] 2535 	add	a, #_input_snapshot
      006CF8 F5 82            [12] 2536 	mov	dpl,a
      006CFA E4               [12] 2537 	clr	a
      006CFB 34 08            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      006CFD F5 83            [12] 2539 	mov	dph,a
      006CFF E0               [24] 2540 	movx	a,@dptr
      006D00 85 28 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      006D03 85 29 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006D06 F0               [24] 2543 	movx	@dptr,a
      006D07 E5 2A            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      006D09 04               [12] 2545 	inc	a
      006D0A F5 2A            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      006D0C 80 CE            [24] 2547 	sjmp	00296$
      006D0E                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006D0E BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      006D11 BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      006D14 90 08 16         [24] 2552 	mov	dptr,#_D0SetupLen
      006D17 E0               [24] 2553 	movx	a,@dptr
      006D18 F8               [12] 2554 	mov	r0,a
      006D19 A3               [24] 2555 	inc	dptr
      006D1A E0               [24] 2556 	movx	a,@dptr
      006D1B F9               [12] 2557 	mov	r1,a
      006D1C C3               [12] 2558 	clr	c
      006D1D 74 20            [12] 2559 	mov	a,#0x20
      006D1F 98               [12] 2560 	subb	a,r0
      006D20 E4               [12] 2561 	clr	a
      006D21 99               [12] 2562 	subb	a,r1
      006D22 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      006D24 90 08 16         [24] 2565 	mov	dptr,#_D0SetupLen
      006D27 74 20            [12] 2566 	mov	a,#0x20
      006D29 F0               [24] 2567 	movx	@dptr,a
      006D2A E4               [12] 2568 	clr	a
      006D2B A3               [24] 2569 	inc	dptr
      006D2C F0               [24] 2570 	movx	@dptr,a
      006D2D                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      006D2D 90 08 16         [24] 2573 	mov	dptr,#_D0SetupLen
      006D30 E0               [24] 2574 	movx	a,@dptr
      006D31 90 22 08         [24] 2575 	mov	dptr,#0x2208
      006D34 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      006D35 90 08 74         [24] 2578 	mov	dptr,#_control_phase
      006D38 74 02            [12] 2579 	mov	a,#0x02
      006D3A F0               [24] 2580 	movx	@dptr,a
      006D3B 02 6D C3         [24] 2581 	ljmp	00291$
      006D3E                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006D3E EB               [12] 2584 	mov	a,r3
      006D3F 4C               [12] 2585 	orl	a,r4
      006D40 70 37            [24] 2586 	jnz	00265$
      006D42 90 08 1B         [24] 2587 	mov	dptr,#_D0UsbConfig
      006D45 E0               [24] 2588 	movx	a,@dptr
      006D46 60 31            [24] 2589 	jz	00265$
      006D48 EA               [12] 2590 	mov	a,r2
      006D49 60 2E            [24] 2591 	jz	00265$
      006D4B 90 08 15         [24] 2592 	mov	dptr,#_D0SetupReqCode
      006D4E E0               [24] 2593 	movx	a,@dptr
      006D4F FA               [12] 2594 	mov	r2,a
      006D50 BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      006D53 30 1B 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      006D56 90 08 16         [24] 2597 	mov	dptr,#_D0SetupLen
      006D59 E0               [24] 2598 	movx	a,@dptr
      006D5A F9               [12] 2599 	mov	r1,a
      006D5B A3               [24] 2600 	inc	dptr
      006D5C E0               [24] 2601 	movx	a,@dptr
      006D5D FA               [12] 2602 	mov	r2,a
      006D5E B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      006D61 BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      006D64 90 0E 86         [24] 2606 	mov	dptr,#_keyboard_protocol
      006D67 E0               [24] 2607 	movx	a,@dptr
      006D68 90 10 00         [24] 2608 	mov	dptr,#0x1000
      006D6B F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006D6C 90 22 08         [24] 2611 	mov	dptr,#0x2208
      006D6F 74 01            [12] 2612 	mov	a,#0x01
      006D71 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      006D72 90 08 74         [24] 2615 	mov	dptr,#_control_phase
      006D75 04               [12] 2616 	inc	a
      006D76 F0               [24] 2617 	movx	@dptr,a
      006D77 80 4A            [24] 2618 	sjmp	00291$
      006D79                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      006D79 02 64 14         [24] 2622 	ljmp	_control_stall
      006D7C                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006D7C 30 19 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      006D7F 90 08 1B         [24] 2626 	mov	dptr,#_D0UsbConfig
      006D82 E0               [24] 2627 	movx	a,@dptr
      006D83 60 38            [24] 2628 	jz	00284$
      006D85 BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      006D88 8E 05            [24] 2630 	mov	ar5,r6
      006D8A 7E 00            [12] 2631 	mov	r6,#0x00
      006D8C ED               [12] 2632 	mov	a,r5
      006D8D 4E               [12] 2633 	orl	a,r6
      006D8E 70 2D            [24] 2634 	jnz	00284$
      006D90 90 08 16         [24] 2635 	mov	dptr,#_D0SetupLen
      006D93 E0               [24] 2636 	movx	a,@dptr
      006D94 FE               [12] 2637 	mov	r6,a
      006D95 A3               [24] 2638 	inc	dptr
      006D96 E0               [24] 2639 	movx	a,@dptr
      006D97 FF               [12] 2640 	mov	r7,a
      006D98 BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      006D9B BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006D9E EB               [12] 2644 	mov	a,r3
      006D9F 4C               [12] 2645 	orl	a,r4
      006DA0 70 07            [24] 2646 	jnz	00324$
      006DA2 90 06 F3         [24] 2647 	mov	dptr,#_keyboard_idle
      006DA5 E0               [24] 2648 	movx	a,@dptr
      006DA6 FF               [12] 2649 	mov	r7,a
      006DA7 80 02            [24] 2650 	sjmp	00325$
      006DA9                       2651 00324$:
      006DA9 7F 00            [12] 2652 	mov	r7,#0x00
      006DAB                       2653 00325$:
      006DAB 90 10 00         [24] 2654 	mov	dptr,#0x1000
      006DAE EF               [12] 2655 	mov	a,r7
      006DAF F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      006DB0 90 22 08         [24] 2658 	mov	dptr,#0x2208
      006DB3 74 01            [12] 2659 	mov	a,#0x01
      006DB5 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      006DB6 90 08 74         [24] 2662 	mov	dptr,#_control_phase
      006DB9 04               [12] 2663 	inc	a
      006DBA F0               [24] 2664 	movx	@dptr,a
      006DBB 80 06            [24] 2665 	sjmp	00291$
      006DBD                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006DBD 02 64 14         [24] 2669 	ljmp	_control_stall
      006DC0                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      006DC0 02 64 14         [24] 2672 	ljmp	_control_stall
      006DC3                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006DC3 90 22 00         [24] 2675 	mov	dptr,#0x2200
      006DC6 74 C0            [12] 2676 	mov	a,#0xc0
      006DC8 F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      006DC9 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      006DCA                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006DCA 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      006DCD E0               [24] 2692 	movx	a,@dptr
      006DCE 20 E6 01         [24] 2693 	jb	acc.6,00102$
      006DD1 22               [24] 2694 	ret
      006DD2                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006DD2 90 08 74         [24] 2697 	mov	dptr,#_control_phase
      006DD5 E0               [24] 2698 	movx	a,@dptr
      006DD6 FF               [12] 2699 	mov	r7,a
      006DD7 BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      006DDA 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      006DDD E0               [24] 2702 	movx	a,@dptr
      006DDE 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      006DE0 90 08 74         [24] 2705 	mov	dptr,#_control_phase
      006DE3 E4               [12] 2706 	clr	a
      006DE4 F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006DE5 90 22 00         [24] 2709 	mov	dptr,#0x2200
      006DE8 74 02            [12] 2710 	mov	a,#0x02
      006DEA F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006DEB 22               [24] 2713 	ret
      006DEC                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006DEC BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      006DEF 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      006DF2 E0               [24] 2718 	movx	a,@dptr
      006DF3 FF               [12] 2719 	mov	r7,a
      006DF4 90 08 16         [24] 2720 	mov	dptr,#_D0SetupLen
      006DF7 E0               [24] 2721 	movx	a,@dptr
      006DF8 FD               [12] 2722 	mov	r5,a
      006DF9 A3               [24] 2723 	inc	dptr
      006DFA E0               [24] 2724 	movx	a,@dptr
      006DFB FE               [12] 2725 	mov	r6,a
      006DFC 7C 00            [12] 2726 	mov	r4,#0x00
      006DFE EF               [12] 2727 	mov	a,r7
      006DFF B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      006E02 EC               [12] 2729 	mov	a,r4
      006E03 B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      006E06 80 03            [24] 2731 	sjmp	00107$
      006E08                       2732 00209$:
      006E08                       2733 00106$:
      006E08 02 64 14         [24] 2734 	ljmp	_control_stall
      006E0B                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006E0B 90 08 75         [24] 2737 	mov	dptr,#_output_kind
      006E0E E0               [24] 2738 	movx	a,@dptr
      006E0F FF               [12] 2739 	mov	r7,a
      006E10 BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      006E13 90 08 23         [24] 2741 	mov	dptr,#_raw_state
      006E16 E0               [24] 2742 	movx	a,@dptr
      006E17 FE               [12] 2743 	mov	r6,a
      006E18 BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006E1B 7E 00            [12] 2746 	mov	r6,#0x00
      006E1D                       2747 00121$:
      006E1D EE               [12] 2748 	mov	a,r6
      006E1E 24 24            [12] 2749 	add	a, #_raw_buffer
      006E20 FC               [12] 2750 	mov	r4,a
      006E21 E4               [12] 2751 	clr	a
      006E22 34 08            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      006E24 FD               [12] 2753 	mov	r5,a
      006E25 8E 82            [24] 2754 	mov	dpl,r6
      006E27 74 10            [12] 2755 	mov	a,#0x10
      006E29 24 00            [12] 2756 	add	a, #0x00
      006E2B F5 83            [12] 2757 	mov	dph,a
      006E2D E0               [24] 2758 	movx	a,@dptr
      006E2E 8C 82            [24] 2759 	mov	dpl,r4
      006E30 8D 83            [24] 2760 	mov	dph,r5
      006E32 F0               [24] 2761 	movx	@dptr,a
      006E33 0E               [12] 2762 	inc	r6
      006E34 BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      006E37                       2764 00214$:
      006E37 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006E39 90 08 23         [24] 2767 	mov	dptr,#_raw_state
      006E3C 74 02            [12] 2768 	mov	a,#0x02
      006E3E F0               [24] 2769 	movx	@dptr,a
      006E3F 80 2B            [24] 2770 	sjmp	00119$
      006E41                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      006E41 BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      006E44 90 10 00         [24] 2775 	mov	dptr,#0x1000
      006E47 E0               [24] 2776 	movx	a,@dptr
      006E48 90 08 20         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      006E4B F0               [24] 2778 	movx	@dptr,a
      006E4C 80 1E            [24] 2779 	sjmp	00119$
      006E4E                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006E4E BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      006E51 90 10 00         [24] 2783 	mov	dptr,#0x1000
      006E54 E0               [24] 2784 	movx	a,@dptr
      006E55 FF               [12] 2785 	mov	r7,a
      006E56 90 08 76         [24] 2786 	mov	dptr,#_output_report_id
      006E59 E0               [24] 2787 	movx	a,@dptr
      006E5A FE               [12] 2788 	mov	r6,a
      006E5B EF               [12] 2789 	mov	a,r7
      006E5C B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006E5F 90 10 01         [24] 2792 	mov	dptr,#0x1001
      006E62 E0               [24] 2793 	movx	a,@dptr
      006E63 90 08 20         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      006E66 F0               [24] 2795 	movx	@dptr,a
      006E67 80 03            [24] 2796 	sjmp	00119$
      006E69                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006E69 02 64 14         [24] 2799 	ljmp	_control_stall
      006E6C                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006E6C 90 08 75         [24] 2802 	mov	dptr,#_output_kind
      006E6F E4               [12] 2803 	clr	a
      006E70 F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      006E71 90 08 16         [24] 2806 	mov	dptr,#_D0SetupLen
      006E74 F0               [24] 2807 	movx	@dptr,a
      006E75 A3               [24] 2808 	inc	dptr
      006E76 F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      006E77 90 08 74         [24] 2811 	mov	dptr,#_control_phase
      006E7A 74 03            [12] 2812 	mov	a,#0x03
      006E7C F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006E7D 90 22 08         [24] 2815 	mov	dptr,#0x2208
      006E80 E4               [12] 2816 	clr	a
      006E81 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006E82 F5 82            [12] 2819 	mov	dpl,a
      006E84 74 48            [12] 2820 	mov	a,#0x48
      006E86 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006E87 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      006E88                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006E88 90 08 74         [24] 2833 	mov	dptr,#_control_phase
      006E8B E0               [24] 2834 	movx	a,@dptr
      006E8C FF               [12] 2835 	mov	r7,a
      006E8D BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      006E90 90 08 16         [24] 2838 	mov	dptr,#_D0SetupLen
      006E93 E0               [24] 2839 	movx	a,@dptr
      006E94 FD               [12] 2840 	mov	r5,a
      006E95 A3               [24] 2841 	inc	dptr
      006E96 E0               [24] 2842 	movx	a,@dptr
      006E97 4D               [12] 2843 	orl	a,r5
      006E98 70 06            [24] 2844 	jnz	00101$
      006E9A 90 08 77         [24] 2845 	mov	dptr,#_control_zlp
      006E9D E0               [24] 2846 	movx	a,@dptr
      006E9E 60 0A            [24] 2847 	jz	00102$
      006EA0                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      006EA0 90 22 00         [24] 2850 	mov	dptr,#0x2200
      006EA3 E0               [24] 2851 	movx	a,@dptr
      006EA4 64 40            [12] 2852 	xrl	a,#0x40
      006EA6 F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006EA7 02 64 36         [24] 2856 	ljmp	_control_next
      006EAA                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006EAA 90 08 74         [24] 2859 	mov	dptr,#_control_phase
      006EAD 74 02            [12] 2860 	mov	a,#0x02
      006EAF F0               [24] 2861 	movx	@dptr,a
      006EB0 80 18            [24] 2862 	sjmp	00110$
      006EB2                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006EB2 BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006EB5 90 08 15         [24] 2867 	mov	dptr,#_D0SetupReqCode
      006EB8 E0               [24] 2868 	movx	a,@dptr
      006EB9 FF               [12] 2869 	mov	r7,a
      006EBA BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      006EBD 90 08 16         [24] 2871 	mov	dptr,#_D0SetupLen
      006EC0 E0               [24] 2872 	movx	a,@dptr
      006EC1 90 22 07         [24] 2873 	mov	dptr,#0x2207
      006EC4 F0               [24] 2874 	movx	@dptr,a
      006EC5                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      006EC5 90 08 74         [24] 2877 	mov	dptr,#_control_phase
      006EC8 E4               [12] 2878 	clr	a
      006EC9 F0               [24] 2879 	movx	@dptr,a
      006ECA                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006ECA 90 22 00         [24] 2882 	mov	dptr,#0x2200
      006ECD 74 82            [12] 2883 	mov	a,#0x82
      006ECF F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      006ED0 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      006ED1                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      006ED1                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      006ED1 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      006ED4 E0               [24] 2902 	movx	a,@dptr
      006ED5 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006ED8 12 63 BD         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006EDB 90 22 07         [24] 2907 	mov	dptr,#0x2207
      006EDE E4               [12] 2908 	clr	a
      006EDF F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006EE0 90 08 1D         [24] 2911 	mov	dptr,#_USB_SleepStatus
      006EE3 F0               [24] 2912 	movx	@dptr,a
      006EE4 90 08 1C         [24] 2913 	mov	dptr,#_USB_EnumStatus
      006EE7 F0               [24] 2914 	movx	@dptr,a
      006EE8 90 08 1B         [24] 2915 	mov	dptr,#_D0UsbConfig
      006EEB F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006EEC 90 08 20         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      006EEF F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006EF0 90 0E 86         [24] 2921 	mov	dptr,#_keyboard_protocol
      006EF3 04               [12] 2922 	inc	a
      006EF4 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006EF5 90 06 F3         [24] 2925 	mov	dptr,#_keyboard_idle
      006EF8 E4               [12] 2926 	clr	a
      006EF9 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006EFA 90 08 45         [24] 2929 	mov	dptr,#_keyboard_reset
      006EFD 04               [12] 2930 	inc	a
      006EFE F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006EFF 90 08 15         [24] 2933 	mov	dptr,#_D0SetupReqCode
      006F02 74 FF            [12] 2934 	mov	a,#0xff
      006F04 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006F05 90 08 16         [24] 2937 	mov	dptr,#_D0SetupLen
      006F08 E4               [12] 2938 	clr	a
      006F09 F0               [24] 2939 	movx	@dptr,a
      006F0A A3               [24] 2940 	inc	dptr
      006F0B F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006F0C 90 08 74         [24] 2943 	mov	dptr,#_control_phase
      006F0F F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006F10 90 22 00         [24] 2946 	mov	dptr,#0x2200
      006F13 74 02            [12] 2947 	mov	a,#0x02
      006F15 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006F16 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      006F19 E4               [12] 2951 	clr	a
      006F1A F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006F1B 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      006F1E 04               [12] 2955 	inc	a
      006F1F F0               [24] 2956 	movx	@dptr,a
      006F20 02 6F B6         [24] 2957 	ljmp	00130$
      006F23                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006F23 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      006F26 E0               [24] 2961 	movx	a,@dptr
      006F27 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006F2A 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      006F2D E0               [24] 2965 	movx	a,@dptr
      006F2E FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006F2F 74 07            [12] 2968 	mov	a,#0x07
      006F31 5F               [12] 2969 	anl	a,r7
      006F32 FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006F33 EF               [12] 2972 	mov	a,r7
      006F34 54 18            [12] 2973 	anl	a,#0x18
      006F36 70 08            [24] 2974 	jnz	00115$
      006F38 EE               [12] 2975 	mov	a,r6
      006F39 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006F3B 12 6D CA         [24] 2978 	lcall	_control_out
      006F3E 80 43            [24] 2979 	sjmp	00116$
      006F40                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006F40 8F 05            [24] 2982 	mov	ar5,r7
      006F42 74 18            [12] 2983 	mov	a,#0x18
      006F44 5D               [12] 2984 	anl	a,r5
      006F45 FC               [12] 2985 	mov	r4,a
      006F46 BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006F49 EE               [12] 2988 	mov	a,r6
      006F4A 70 05            [24] 2989 	jnz	00106$
      006F4C 12 6E 88         [24] 2990 	lcall	_control_in
      006F4F 80 32            [24] 2991 	sjmp	00116$
      006F51                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006F51 EE               [12] 2994 	mov	a,r6
      006F52 24 FC            [12] 2995 	add	a,#0xff - 0x03
      006F54 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006F56 8E 04            [24] 2999 	mov	ar4,r6
      006F58 7B 00            [12] 3000 	mov	r3,#0x00
      006F5A 74 22            [12] 3001 	mov	a,#0x22
      006F5C 2B               [12] 3002 	add	a, r3
      006F5D FB               [12] 3003 	mov	r3,a
      006F5E 8C 82            [24] 3004 	mov	dpl,r4
      006F60 8B 83            [24] 3005 	mov	dph,r3
      006F62 E0               [24] 3006 	movx	a,@dptr
      006F63 FA               [12] 3007 	mov	r2,a
      006F64 74 FC            [12] 3008 	mov	a,#0xfc
      006F66 5A               [12] 3009 	anl	a,r2
      006F67 44 02            [12] 3010 	orl	a,#0x02
      006F69 8C 82            [24] 3011 	mov	dpl,r4
      006F6B 8B 83            [24] 3012 	mov	dph,r3
      006F6D F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006F6E BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      006F71 12 63 A0         [24] 3016 	lcall	_raw_complete
      006F74 80 0D            [24] 3017 	sjmp	00116$
      006F76                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006F76 53 05 18         [24] 3020 	anl	ar5,#0x18
      006F79 BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      006F7C EF               [12] 3022 	mov	a,r7
      006F7D 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006F80 12 66 2D         [24] 3025 	lcall	_control_setup
      006F83                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006F83 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      006F86 E4               [12] 3029 	clr	a
      006F87 F0               [24] 3030 	movx	@dptr,a
      006F88 80 2C            [24] 3031 	sjmp	00130$
      006F8A                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006F8A 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      006F8D E0               [24] 3035 	movx	a,@dptr
      006F8E 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006F91 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      006F94 E0               [24] 3039 	movx	a,@dptr
      006F95 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      006F98 90 08 1D         [24] 3041 	mov	dptr,#_USB_SleepStatus
      006F9B E0               [24] 3042 	movx	a,@dptr
      006F9C 43 E0 02         [24] 3043 	orl	acc,#0x02
      006F9F F0               [24] 3044 	movx	@dptr,a
      006FA0 80 0E            [24] 3045 	sjmp	00120$
      006FA2                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006FA2 90 08 1D         [24] 3048 	mov	dptr,#_USB_SleepStatus
      006FA5 E0               [24] 3049 	movx	a,@dptr
      006FA6 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      006FA9 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006FAA 90 08 45         [24] 3053 	mov	dptr,#_keyboard_reset
      006FAD 74 01            [12] 3054 	mov	a,#0x01
      006FAF F0               [24] 3055 	movx	@dptr,a
      006FB0                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      006FB0 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      006FB3 74 04            [12] 3059 	mov	a,#0x04
      006FB5 F0               [24] 3060 	movx	@dptr,a
      006FB6                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006FB6 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      006FB9 E0               [24] 3064 	movx	a,@dptr
      006FBA 54 25            [12] 3065 	anl	a,#0x25
      006FBC 60 03            [24] 3066 	jz	00242$
      006FBE 02 6E D1         [24] 3067 	ljmp	00129$
      006FC1                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      006FC1 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      006FC2                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3080 ;	assignBit
      006FC2 C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006FC4 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      006FC7 E4               [12] 3084 	clr	a
      006FC8 F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006FC9 90 08 23         [24] 3087 	mov	dptr,#_raw_state
      006FCC F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006FCD 12 63 BD         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006FD0 90 08 1D         [24] 3092 	mov	dptr,#_USB_SleepStatus
      006FD3 E4               [12] 3093 	clr	a
      006FD4 F0               [24] 3094 	movx	@dptr,a
      006FD5 90 08 1C         [24] 3095 	mov	dptr,#_USB_EnumStatus
      006FD8 F0               [24] 3096 	movx	@dptr,a
      006FD9 90 08 1B         [24] 3097 	mov	dptr,#_D0UsbConfig
      006FDC F0               [24] 3098 	movx	@dptr,a
      006FDD 90 22 07         [24] 3099 	mov	dptr,#0x2207
      006FE0 F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006FE1 90 08 1E         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      006FE4 F0               [24] 3103 	movx	@dptr,a
      006FE5 90 08 1F         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      006FE8 F0               [24] 3105 	movx	@dptr,a
      006FE9 90 08 20         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      006FEC F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006FED 90 0E 86         [24] 3109 	mov	dptr,#_keyboard_protocol
      006FF0 04               [12] 3110 	inc	a
      006FF1 F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006FF2 90 06 F3         [24] 3113 	mov	dptr,#_keyboard_idle
      006FF5 E4               [12] 3114 	clr	a
      006FF6 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006FF7 90 08 45         [24] 3117 	mov	dptr,#_keyboard_reset
      006FFA F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006FFB 90 08 74         [24] 3120 	mov	dptr,#_control_phase
      006FFE F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006FFF 90 08 15         [24] 3123 	mov	dptr,#_D0SetupReqCode
      007002 14               [12] 3124 	dec	a
      007003 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      007004 90 08 16         [24] 3127 	mov	dptr,#_D0SetupLen
      007007 E4               [12] 3128 	clr	a
      007008 F0               [24] 3129 	movx	@dptr,a
      007009 A3               [24] 3130 	inc	dptr
      00700A F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00700B 90 22 00         [24] 3133 	mov	dptr,#0x2200
      00700E 74 02            [12] 3134 	mov	a,#0x02
      007010 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      007011 90 22 37         [24] 3137 	mov	dptr,#0x2237
      007014 74 7F            [12] 3138 	mov	a,#0x7f
      007016 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      007017 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      00701A 74 FF            [12] 3142 	mov	a,#0xff
      00701C F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      00701D 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      007020 74 07            [12] 3146 	mov	a,#0x07
      007022 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      007023 A3               [24] 3149 	inc	dptr
      007024 74 80            [12] 3150 	mov	a,#0x80
      007026 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3153 ;	assignBit
      007027 D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      007029 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      00702A                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      00702A 90 08 1D         [24] 3169 	mov	dptr,#_USB_SleepStatus
      00702D E0               [24] 3170 	movx	a,@dptr
      00702E FF               [12] 3171 	mov	r7,a
      00702F BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      007032 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      007035 E0               [24] 3175 	movx	a,@dptr
      007036 FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      007037 E0               [24] 3178 	movx	a,@dptr
      007038 FE               [12] 3179 	mov	r6,a
      007039 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      00703C 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      00703F EE               [12] 3182 	mov	a,r6
      007040 F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      007041 7E 0A            [12] 3185 	mov	r6,#0x0a
      007043                       3186 00108$:
      007043 EE               [12] 3187 	mov	a,r6
      007044 60 09            [24] 3188 	jz	00105$
      007046 90 00 01         [24] 3189 	mov	dptr,#0x0001
      007049 12 62 04         [24] 3190 	lcall	_mDelaymS
      00704C 1E               [12] 3191 	dec	r6
      00704D 80 F4            [24] 3192 	sjmp	00108$
      00704F                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      00704F 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      007052 EF               [12] 3196 	mov	a,r7
      007053 F0               [24] 3197 	movx	@dptr,a
      007054                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      007054 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      007055                       3220 _ak820_usb_send:
      007055 E5 82            [12] 3221 	mov	a,dpl
      007057 90 08 84         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00705A F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      00705B 90 08 85         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      00705E 74 2E            [12] 3226 	mov	a,#0x2e
      007060 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      007061 90 08 84         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      007064 E0               [24] 3230 	movx	a,@dptr
      007065 FF               [12] 3231 	mov	r7,a
      007066 BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      007069                       3233 00306$:
      007069 40 14            [24] 3234 	jc	00101$
      00706B EF               [12] 3235 	mov	a,r7
      00706C 24 FC            [12] 3236 	add	a,#0xff - 0x03
      00706E 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      007070 90 08 83         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      007073 E0               [24] 3240 	movx	a,@dptr
      007074 FE               [12] 3241 	mov  r6,a
      007075 24 BF            [12] 3242 	add	a,#0xff - 0x40
      007077 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      007079 90 08 1C         [24] 3245 	mov	dptr,#_USB_EnumStatus
      00707C E0               [24] 3246 	movx	a,@dptr
      00707D 70 04            [24] 3247 	jnz	00102$
      00707F                       3248 00101$:
      00707F 75 82 00         [24] 3249 	mov	dpl, #0x00
      007082 22               [24] 3250 	ret
      007083                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      007083 BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      007086 BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      007089 80 04            [24] 3256 	sjmp	00107$
      00708B                       3257 00313$:
      00708B 75 82 00         [24] 3258 	mov	dpl, #0x00
      00708E 22               [24] 3259 	ret
      00708F                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      00708F 90 08 85         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      007092 E4               [12] 3263 	clr	a
      007093 F0               [24] 3264 	movx	@dptr,a
      007094 80 3C            [24] 3265 	sjmp	00119$
      007096                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      007096 BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      007099 90 08 81         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      00709C E0               [24] 3271 	movx	a,@dptr
      00709D FD               [12] 3272 	mov	r5,a
      00709E A3               [24] 3273 	inc	dptr
      00709F E0               [24] 3274 	movx	a,@dptr
      0070A0 FF               [12] 3275 	mov	r7,a
      0070A1 8D 82            [24] 3276 	mov	dpl,r5
      0070A3 8F 83            [24] 3277 	mov	dph,r7
      0070A5 E0               [24] 3278 	movx	a,@dptr
      0070A6 FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      0070A7 BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      0070AA                       3282 00316$:
      0070AA 50 0E            [24] 3283 	jnc	00108$
      0070AC EF               [12] 3284 	mov	a,r7
      0070AD 90 C4 1C         [24] 3285 	mov	dptr,#_shared_lengths
      0070B0 93               [24] 3286 	movc	a,@a+dptr
      0070B1 FD               [12] 3287 	mov	r5,a
      0070B2 60 06            [24] 3288 	jz	00108$
      0070B4 EE               [12] 3289 	mov	a,r6
      0070B5 B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      0070B8 80 04            [24] 3291 	sjmp	00109$
      0070BA                       3292 00319$:
      0070BA                       3293 00108$:
      0070BA 75 82 00         [24] 3294 	mov	dpl, #0x00
      0070BD 22               [24] 3295 	ret
      0070BE                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      0070BE EF               [12] 3298 	mov	a,r7
      0070BF 90 C4 15         [24] 3299 	mov	dptr,#_shared_offsets
      0070C2 93               [24] 3300 	movc	a,@a+dptr
      0070C3 90 08 85         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      0070C6 F0               [24] 3302 	movx	@dptr,a
      0070C7 80 09            [24] 3303 	sjmp	00119$
      0070C9                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      0070C9 BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      0070CC 80 04            [24] 3307 	sjmp	00119$
      0070CE                       3308 00320$:
      0070CE 75 82 00         [24] 3309 	mov	dpl, #0x00
      0070D1 22               [24] 3310 	ret
      0070D2                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      0070D2 90 08 1D         [24] 3313 	mov	dptr,#_USB_SleepStatus
      0070D5 E0               [24] 3314 	movx	a,@dptr
      0070D6 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      0070D9 12 70 2A         [24] 3316 	lcall	_USB_WakeUp_PC
      0070DC 75 82 00         [24] 3317 	mov	dpl, #0x00
      0070DF 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      0070E0                       3320 00184$:
      0070E0 7F FA            [12] 3321 	mov	r7,#0xfa
      0070E2                       3322 00127$:
      0070E2 90 08 84         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0070E5 E0               [24] 3324 	movx	a,@dptr
      0070E6 FC               [12] 3325 	mov	r4,a
      0070E7 7D 00            [12] 3326 	mov	r5,#0x00
      0070E9 8C 02            [24] 3327 	mov	ar2,r4
      0070EB 74 22            [12] 3328 	mov	a,#0x22
      0070ED 2D               [12] 3329 	add	a, r5
      0070EE FB               [12] 3330 	mov	r3,a
      0070EF 8A 82            [24] 3331 	mov	dpl,r2
      0070F1 8B 83            [24] 3332 	mov	dph,r3
      0070F3 E0               [24] 3333 	movx	a,@dptr
      0070F4 54 03            [12] 3334 	anl	a,#0x03
      0070F6 70 14            [24] 3335 	jnz	00129$
      0070F8 8F 03            [24] 3336 	mov	ar3,r7
      0070FA 1F               [12] 3337 	dec	r7
      0070FB EB               [12] 3338 	mov	a,r3
      0070FC 60 0E            [24] 3339 	jz	00129$
      0070FE 7B 28            [12] 3340 	mov	r3,#0x28
      007100                       3341 00141$:
      007100 EB               [12] 3342 	mov	a,r3
      007101 60 DF            [24] 3343 	jz	00127$
      007103 90 00 01         [24] 3344 	mov	dptr,#0x0001
      007106 12 61 C0         [24] 3345 	lcall	_mDelayuS
      007109 1B               [12] 3346 	dec	r3
      00710A 80 F4            [24] 3347 	sjmp	00141$
      00710C                       3348 00129$:
                                   3349 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      00710C A2 AF            [12] 3350 	mov	c,_EA
      00710E E4               [12] 3351 	clr	a
      00710F 33               [12] 3352 	rlc	a
      007110 FF               [12] 3353 	mov	r7,a
                                   3354 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3355 ;	assignBit
      007111 C2 AF            [12] 3356 	clr	_EA
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      007113 90 08 1C         [24] 3358 	mov	dptr,#_USB_EnumStatus
      007116 E0               [24] 3359 	movx	a,@dptr
      007117 60 25            [24] 3360 	jz	00130$
      007119 90 08 84         [24] 3361 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00711C E0               [24] 3362 	movx	a,@dptr
      00711D FB               [12] 3363 	mov	r3,a
      00711E F9               [12] 3364 	mov	r1,a
      00711F 7A 00            [12] 3365 	mov	r2,#0x00
      007121 74 22            [12] 3366 	mov	a,#0x22
      007123 2A               [12] 3367 	add	a, r2
      007124 FA               [12] 3368 	mov	r2,a
      007125 89 82            [24] 3369 	mov	dpl,r1
      007127 8A 83            [24] 3370 	mov	dph,r2
      007129 E0               [24] 3371 	movx	a,@dptr
      00712A FA               [12] 3372 	mov	r2,a
      00712B 53 02 03         [24] 3373 	anl	ar2,#0x03
      00712E BA 02 0D         [24] 3374 	cjne	r2,#0x02,00130$
                                   3375 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      007131 BB 03 13         [24] 3376 	cjne	r3,#0x03,00192$
      007134 90 08 23         [24] 3377 	mov	dptr,#_raw_state
      007137 E0               [24] 3378 	movx	a,@dptr
      007138 FB               [12] 3379 	mov	r3,a
      007139 BB 03 02         [24] 3380 	cjne	r3,#0x03,00331$
      00713C 80 09            [24] 3381 	sjmp	00192$
      00713E                       3382 00331$:
      00713E                       3383 00130$:
                                   3384 ;	assignBit
      00713E EF               [12] 3385 	mov	a,r7
      00713F 24 FF            [12] 3386 	add	a,#0xff
      007141 92 AF            [24] 3387 	mov	_EA,c
      007143 75 82 00         [24] 3388 	mov	dpl, #0x00
      007146 22               [24] 3389 	ret
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      007147                       3391 00192$:
      007147 7B 00            [12] 3392 	mov	r3,#0x00
      007149                       3393 00144$:
      007149 C3               [12] 3394 	clr	c
      00714A EB               [12] 3395 	mov	a,r3
      00714B 9E               [12] 3396 	subb	a,r6
      00714C 50 67            [24] 3397 	jnc	00137$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      00714E C0 07            [24] 3399 	push	ar7
      007150 90 08 84         [24] 3400 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      007153 E0               [24] 3401 	movx	a,@dptr
      007154 F9               [12] 3402 	mov	r1,a
      007155 E4               [12] 3403 	clr	a
      007156 C3               [12] 3404 	clr	c
      007157 C9               [12] 3405 	xch	a,r1
      007158 13               [12] 3406 	rrc	a
      007159 C9               [12] 3407 	xch	a,r1
      00715A 13               [12] 3408 	rrc	a
      00715B A2 E0            [12] 3409 	mov	c,acc.0
      00715D C9               [12] 3410 	xch	a,r1
      00715E 13               [12] 3411 	rrc	a
      00715F C9               [12] 3412 	xch	a,r1
      007160 13               [12] 3413 	rrc	a
      007161 C9               [12] 3414 	xch	a,r1
      007162 FA               [12] 3415 	mov	r2,a
      007163 8B 00            [24] 3416 	mov	ar0,r3
      007165 7F 00            [12] 3417 	mov	r7,#0x00
      007167 E8               [12] 3418 	mov	a,r0
      007168 29               [12] 3419 	add	a, r1
      007169 F9               [12] 3420 	mov	r1,a
      00716A EF               [12] 3421 	mov	a,r7
      00716B 3A               [12] 3422 	addc	a, r2
      00716C 24 10            [12] 3423 	add	a,#0x10
      00716E FA               [12] 3424 	mov	r2,a
      00716F 90 08 81         [24] 3425 	mov	dptr,#_ak820_usb_send_PARM_2
      007172 E0               [24] 3426 	movx	a,@dptr
      007173 F8               [12] 3427 	mov	r0,a
      007174 A3               [24] 3428 	inc	dptr
      007175 E0               [24] 3429 	movx	a,@dptr
      007176 FF               [12] 3430 	mov	r7,a
      007177 EB               [12] 3431 	mov	a,r3
      007178 28               [12] 3432 	add	a, r0
      007179 F5 2C            [12] 3433 	mov	_ak820_usb_send_sloc0_1_0,a
      00717B E4               [12] 3434 	clr	a
      00717C 3F               [12] 3435 	addc	a, r7
      00717D F5 2D            [12] 3436 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      00717F 85 2C 82         [24] 3437 	mov	dpl,_ak820_usb_send_sloc0_1_0
      007182 85 2D 83         [24] 3438 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      007185 E0               [24] 3439 	movx	a,@dptr
      007186 89 82            [24] 3440 	mov	dpl,r1
      007188 8A 83            [24] 3441 	mov	dph,r2
      00718A F0               [24] 3442 	movx	@dptr,a
                                   3443 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      00718B 90 08 85         [24] 3444 	mov	dptr,#_ak820_usb_send_offset_10000_423
      00718E E0               [24] 3445 	movx	a,@dptr
      00718F F5 2E            [12] 3446 	mov	_ak820_usb_send_sloc1_1_0,a
      007191 74 2E            [12] 3447 	mov	a,#0x2e
      007193 B5 2E 04         [24] 3448 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      007196 D0 07            [24] 3449 	pop	ar7
      007198 80 18            [24] 3450 	sjmp	00145$
      00719A                       3451 00333$:
      00719A D0 07            [24] 3452 	pop	ar7
      00719C EB               [12] 3453 	mov	a,r3
      00719D 25 2E            [12] 3454 	add	a, _ak820_usb_send_sloc1_1_0
      00719F 24 46            [12] 3455 	add	a, #_input_snapshot
      0071A1 F9               [12] 3456 	mov	r1,a
      0071A2 E4               [12] 3457 	clr	a
      0071A3 34 08            [12] 3458 	addc	a,#(_input_snapshot >> 8)
      0071A5 FA               [12] 3459 	mov	r2,a
      0071A6 85 2C 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      0071A9 85 2D 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      0071AC E0               [24] 3462 	movx	a,@dptr
      0071AD 89 82            [24] 3463 	mov	dpl,r1
      0071AF 8A 83            [24] 3464 	mov	dph,r2
      0071B1 F0               [24] 3465 	movx	@dptr,a
      0071B2                       3466 00145$:
                                   3467 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      0071B2 0B               [12] 3468 	inc	r3
      0071B3 80 94            [24] 3469 	sjmp	00144$
      0071B5                       3470 00137$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      0071B5 90 08 84         [24] 3472 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0071B8 E0               [24] 3473 	movx	a,@dptr
      0071B9 FB               [12] 3474 	mov	r3,a
      0071BA F9               [12] 3475 	mov	r1,a
      0071BB 7A 00            [12] 3476 	mov	r2,#0x00
      0071BD 74 08            [12] 3477 	mov	a,#0x08
      0071BF 29               [12] 3478 	add	a, r1
      0071C0 F9               [12] 3479 	mov	r1,a
      0071C1 74 22            [12] 3480 	mov	a,#0x22
      0071C3 3A               [12] 3481 	addc	a, r2
      0071C4 FA               [12] 3482 	mov	r2,a
      0071C5 89 82            [24] 3483 	mov	dpl,r1
      0071C7 8A 83            [24] 3484 	mov	dph,r2
      0071C9 EE               [12] 3485 	mov	a,r6
      0071CA F0               [24] 3486 	movx	@dptr,a
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      0071CB BB 03 06         [24] 3488 	cjne	r3,#0x03,00139$
      0071CE 90 08 23         [24] 3489 	mov	dptr,#_raw_state
      0071D1 74 04            [12] 3490 	mov	a,#0x04
      0071D3 F0               [24] 3491 	movx	@dptr,a
      0071D4                       3492 00139$:
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      0071D4 74 22            [12] 3494 	mov	a,#0x22
      0071D6 2D               [12] 3495 	add	a, r5
      0071D7 FD               [12] 3496 	mov	r5,a
      0071D8 8C 82            [24] 3497 	mov	dpl,r4
      0071DA 8D 83            [24] 3498 	mov	dph,r5
      0071DC E0               [24] 3499 	movx	a,@dptr
      0071DD FE               [12] 3500 	mov	r6,a
      0071DE 53 06 FC         [24] 3501 	anl	ar6,#0xfc
      0071E1 8C 82            [24] 3502 	mov	dpl,r4
      0071E3 8D 83            [24] 3503 	mov	dph,r5
      0071E5 EE               [12] 3504 	mov	a,r6
      0071E6 F0               [24] 3505 	movx	@dptr,a
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3507 ;	assignBit
      0071E7 EF               [12] 3508 	mov	a,r7
      0071E8 24 FF            [12] 3509 	add	a,#0xff
      0071EA 92 AF            [24] 3510 	mov	_EA,c
                                   3511 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      0071EC 75 82 01         [24] 3512 	mov	dpl, #0x01
                                   3513 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      0071EF 22               [24] 3514 	ret
                                   3515 ;------------------------------------------------------------
                                   3516 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3517 ;------------------------------------------------------------
                                   3518 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3519 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3520 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3521 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3522 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3523 ;------------------------------------------------------------
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3525 ;	-----------------------------------------
                                   3526 ;	 function ak820_usb_try_send
                                   3527 ;	-----------------------------------------
      0071F0                       3528 _ak820_usb_try_send:
      0071F0 E5 82            [12] 3529 	mov	a,dpl
      0071F2 90 08 89         [24] 3530 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      0071F5 F0               [24] 3531 	movx	@dptr,a
                                   3532 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3533 ;	assignBit
      0071F6 A2 AF            [12] 3534 	mov	c,_EA
      0071F8 92 1F            [24] 3535 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      0071FA 90 08 8A         [24] 3537 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      0071FD E4               [12] 3538 	clr	a
      0071FE F0               [24] 3539 	movx	@dptr,a
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3541 ;	assignBit
      0071FF C2 AF            [12] 3542 	clr	_EA
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      007201 90 08 89         [24] 3544 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      007204 E0               [24] 3545 	movx	a,@dptr
      007205 FF               [12] 3546 	mov	r7,a
      007206 BF 01 00         [24] 3547 	cjne	r7,#0x01,00152$
      007209                       3548 00152$:
      007209 40 4E            [24] 3549 	jc	00102$
      00720B EF               [12] 3550 	mov	a,r7
      00720C 24 FD            [12] 3551 	add	a,#0xff - 0x02
      00720E 40 49            [24] 3552 	jc	00102$
                                   3553 ;	free result
      007210 90 08 1C         [24] 3554 	mov	dptr,#_USB_EnumStatus
      007213 E0               [24] 3555 	movx	a,@dptr
      007214 60 43            [24] 3556 	jz	00102$
                                   3557 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      007216 90 08 1D         [24] 3558 	mov	dptr,#_USB_SleepStatus
      007219 E0               [24] 3559 	movx	a,@dptr
      00721A 20 E1 3C         [24] 3560 	jb	acc.1,00102$
      00721D 90 08 45         [24] 3561 	mov	dptr,#_keyboard_reset
      007220 E0               [24] 3562 	movx	a,@dptr
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      007221 70 36            [24] 3564 	jnz	00102$
      007223 8F 06            [24] 3565 	mov	ar6,r7
      007225 24 22            [12] 3566 	add	a,#0x22
      007227 FD               [12] 3567 	mov	r5,a
      007228 8E 82            [24] 3568 	mov	dpl,r6
      00722A 8D 83            [24] 3569 	mov	dph,r5
      00722C E0               [24] 3570 	movx	a,@dptr
      00722D FE               [12] 3571 	mov	r6,a
      00722E 53 06 03         [24] 3572 	anl	ar6,#0x03
      007231 BE 02 25         [24] 3573 	cjne	r6,#0x02,00102$
                                   3574 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      007234 90 08 86         [24] 3575 	mov	dptr,#_ak820_usb_try_send_PARM_2
      007237 E0               [24] 3576 	movx	a,@dptr
      007238 FD               [12] 3577 	mov	r5,a
      007239 A3               [24] 3578 	inc	dptr
      00723A E0               [24] 3579 	movx	a,@dptr
      00723B FE               [12] 3580 	mov	r6,a
      00723C 90 08 88         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_3
      00723F E0               [24] 3582 	movx	a,@dptr
      007240 FC               [12] 3583 	mov	r4,a
      007241 90 08 81         [24] 3584 	mov	dptr,#_ak820_usb_send_PARM_2
      007244 ED               [12] 3585 	mov	a,r5
      007245 F0               [24] 3586 	movx	@dptr,a
      007246 EE               [12] 3587 	mov	a,r6
      007247 A3               [24] 3588 	inc	dptr
      007248 F0               [24] 3589 	movx	@dptr,a
      007249 90 08 83         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_3
      00724C EC               [12] 3591 	mov	a,r4
      00724D F0               [24] 3592 	movx	@dptr,a
      00724E 8F 82            [24] 3593 	mov	dpl, r7
      007250 12 70 55         [24] 3594 	lcall	_ak820_usb_send
      007253 E5 82            [12] 3595 	mov	a, dpl
      007255 90 08 8A         [24] 3596 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      007258 F0               [24] 3597 	movx	@dptr,a
      007259                       3598 00102$:
                                   3599 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3600 ;	assignBit
      007259 A2 1F            [12] 3601 	mov	c,_ak820_usb_try_send_sloc0_1_0
      00725B 92 AF            [24] 3602 	mov	_EA,c
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      00725D 90 08 8A         [24] 3604 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      007260 E0               [24] 3605 	movx	a,@dptr
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      007261 F5 82            [12] 3607 	mov	dpl,a
      007263 22               [24] 3608 	ret
                                   3609 ;------------------------------------------------------------
                                   3610 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3611 ;------------------------------------------------------------
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3613 ;	-----------------------------------------
                                   3614 ;	 function raw_request_is_nonpersistent
                                   3615 ;	-----------------------------------------
      007264                       3616 _raw_request_is_nonpersistent:
                                   3617 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      007264 90 08 24         [24] 3618 	mov	dptr,#_raw_buffer
      007267 E0               [24] 3619 	movx	a,@dptr
      007268 FF               [12] 3620 	mov	r7,a
      007269 BF 01 02         [24] 3621 	cjne	r7,#0x01,00302$
      00726C 80 35            [24] 3622 	sjmp	00108$
      00726E                       3623 00302$:
      00726E BF 02 02         [24] 3624 	cjne	r7,#0x02,00303$
      007271 80 34            [24] 3625 	sjmp	00109$
      007273                       3626 00303$:
      007273 BF 04 02         [24] 3627 	cjne	r7,#0x04,00304$
      007276 80 2B            [24] 3628 	sjmp	00108$
      007278                       3629 00304$:
      007278 BF 08 02         [24] 3630 	cjne	r7,#0x08,00305$
      00727B 80 47            [24] 3631 	sjmp	00116$
      00727D                       3632 00305$:
      00727D BF 0B 02         [24] 3633 	cjne	r7,#0x0b,00306$
      007280 80 21            [24] 3634 	sjmp	00108$
      007282                       3635 00306$:
      007282 BF 0C 02         [24] 3636 	cjne	r7,#0x0c,00307$
      007285 80 1C            [24] 3637 	sjmp	00108$
      007287                       3638 00307$:
      007287 BF 0D 02         [24] 3639 	cjne	r7,#0x0d,00308$
      00728A 80 17            [24] 3640 	sjmp	00108$
      00728C                       3641 00308$:
      00728C BF 0E 02         [24] 3642 	cjne	r7,#0x0e,00309$
      00728F 80 12            [24] 3643 	sjmp	00108$
      007291                       3644 00309$:
      007291 BF 11 02         [24] 3645 	cjne	r7,#0x11,00310$
      007294 80 0D            [24] 3646 	sjmp	00108$
      007296                       3647 00310$:
      007296 BF 12 02         [24] 3648 	cjne	r7,#0x12,00311$
      007299 80 08            [24] 3649 	sjmp	00108$
      00729B                       3650 00311$:
      00729B BF FE 02         [24] 3651 	cjne	r7,#0xfe,00312$
      00729E 80 46            [24] 3652 	sjmp	00124$
      0072A0                       3653 00312$:
      0072A0 02 73 3B         [24] 3654 	ljmp	00144$
                                   3655 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      0072A3                       3656 00108$:
                                   3657 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      0072A3 75 82 01         [24] 3658 	mov	dpl, #0x01
      0072A6 22               [24] 3659 	ret
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      0072A7                       3661 00109$:
                                   3662 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      0072A7 12 75 6D         [24] 3663 	lcall	_ak820_outline_0165
      0072AA BF 01 02         [24] 3664 	cjne	r7,#0x01,00313$
      0072AD 80 0D            [24] 3665 	sjmp	00113$
      0072AF                       3666 00313$:
      0072AF BF 02 02         [24] 3667 	cjne	r7,#0x02,00314$
      0072B2 80 08            [24] 3668 	sjmp	00113$
      0072B4                       3669 00314$:
      0072B4 BF 03 02         [24] 3670 	cjne	r7,#0x03,00315$
      0072B7 80 03            [24] 3671 	sjmp	00113$
      0072B9                       3672 00315$:
      0072B9 BF 04 04         [24] 3673 	cjne	r7,#0x04,00114$
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      0072BC                       3675 00113$:
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      0072BC 75 82 01         [24] 3677 	mov	dpl, #0x01
      0072BF 22               [24] 3678 	ret
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      0072C0                       3680 00114$:
      0072C0 75 82 00         [24] 3681 	mov	dpl, #0x00
      0072C3 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      0072C4                       3684 00116$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      0072C4 12 75 6D         [24] 3686 	lcall	_ak820_outline_0165
      0072C7 BF 40 02         [24] 3687 	cjne	r7,#0x40,00318$
      0072CA 80 12            [24] 3688 	sjmp	00121$
      0072CC                       3689 00318$:
      0072CC BF 41 02         [24] 3690 	cjne	r7,#0x41,00319$
      0072CF 80 0D            [24] 3691 	sjmp	00121$
      0072D1                       3692 00319$:
      0072D1 BF 42 02         [24] 3693 	cjne	r7,#0x42,00320$
      0072D4 80 08            [24] 3694 	sjmp	00121$
      0072D6                       3695 00320$:
      0072D6 BF 43 02         [24] 3696 	cjne	r7,#0x43,00321$
      0072D9 80 03            [24] 3697 	sjmp	00121$
      0072DB                       3698 00321$:
      0072DB BF 44 04         [24] 3699 	cjne	r7,#0x44,00122$
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      0072DE                       3701 00121$:
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      0072DE 75 82 01         [24] 3703 	mov	dpl, #0x01
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      0072E1 22               [24] 3705 	ret
      0072E2                       3706 00122$:
      0072E2 75 82 00         [24] 3707 	mov	dpl, #0x00
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      0072E5 22               [24] 3709 	ret
      0072E6                       3710 00124$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      0072E6 12 75 6D         [24] 3712 	lcall	_ak820_outline_0165
      0072E9 24 F2            [12] 3713 	add	a,#0xff - 0x0d
      0072EB 40 4A            [24] 3714 	jc	00142$
                                   3715 ;	free result
      0072ED EF               [12] 3716 	mov	a,r7
      0072EE 24 0A            [12] 3717 	add	a,#(00325$-3-.)
      0072F0 83               [24] 3718 	movc	a,@a+pc
      0072F1 F5 82            [12] 3719 	mov	dpl,a
      0072F3 EF               [12] 3720 	mov	a,r7
      0072F4 24 12            [12] 3721 	add	a,#(00326$-3-.)
      0072F6 83               [24] 3722 	movc	a,@a+pc
      0072F7 F5 83            [12] 3723 	mov	dph,a
      0072F9 E4               [12] 3724 	clr	a
      0072FA 73               [24] 3725 	jmp	@a+dptr
      0072FB                       3726 00325$:
      0072FB 17                    3727 	.db	00134$
      0072FC 17                    3728 	.db	00134$
      0072FD 17                    3729 	.db	00134$
      0072FE 17                    3730 	.db	00134$
      0072FF 37                    3731 	.db	00142$
      007300 17                    3732 	.db	00134$
      007301 17                    3733 	.db	00134$
      007302 17                    3734 	.db	00134$
      007303 17                    3735 	.db	00134$
      007304 17                    3736 	.db	00134$
      007305 17                    3737 	.db	00134$
      007306 37                    3738 	.db	00142$
      007307 37                    3739 	.db	00142$
      007308 1B                    3740 	.db	00135$
      007309                       3741 00326$:
      007309 73                    3742 	.db	00134$>>8
      00730A 73                    3743 	.db	00134$>>8
      00730B 73                    3744 	.db	00134$>>8
      00730C 73                    3745 	.db	00134$>>8
      00730D 73                    3746 	.db	00142$>>8
      00730E 73                    3747 	.db	00134$>>8
      00730F 73                    3748 	.db	00134$>>8
      007310 73                    3749 	.db	00134$>>8
      007311 73                    3750 	.db	00134$>>8
      007312 73                    3751 	.db	00134$>>8
      007313 73                    3752 	.db	00134$>>8
      007314 73                    3753 	.db	00142$>>8
      007315 73                    3754 	.db	00142$>>8
      007316 73                    3755 	.db	00135$>>8
                                   3756 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      007317                       3757 00134$:
                                   3758 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      007317 75 82 01         [24] 3759 	mov	dpl, #0x01
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      00731A 22               [24] 3761 	ret
      00731B                       3762 00135$:
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      00731B 90 08 26         [24] 3764 	mov	dptr,#(_raw_buffer + 0x0002)
      00731E E0               [24] 3765 	movx	a,@dptr
      00731F FF               [12] 3766 	mov	r7,a
      007320 60 0D            [24] 3767 	jz	00139$
      007322 BF 01 02         [24] 3768 	cjne	r7,#0x01,00328$
      007325 80 08            [24] 3769 	sjmp	00139$
      007327                       3770 00328$:
      007327 BF 03 02         [24] 3771 	cjne	r7,#0x03,00329$
      00732A 80 03            [24] 3772 	sjmp	00139$
      00732C                       3773 00329$:
      00732C BF 05 04         [24] 3774 	cjne	r7,#0x05,00140$
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      00732F                       3776 00139$:
                                   3777 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      00732F 75 82 01         [24] 3778 	mov	dpl, #0x01
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      007332 22               [24] 3780 	ret
      007333                       3781 00140$:
      007333 75 82 00         [24] 3782 	mov	dpl, #0x00
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      007336 22               [24] 3784 	ret
      007337                       3785 00142$:
      007337 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      00733A 22               [24] 3788 	ret
      00733B                       3789 00144$:
      00733B 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      00733E 22               [24] 3793 	ret
                                   3794 ;------------------------------------------------------------
                                   3795 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3796 ;------------------------------------------------------------
                                   3797 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3798 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3799 ;------------------------------------------------------------
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3801 ;	-----------------------------------------
                                   3802 ;	 function ak820_usb_raw_send
                                   3803 ;	-----------------------------------------
      00733F                       3804 _ak820_usb_raw_send:
      00733F 12 43 06         [24] 3805 	lcall	_ak820_outline_0038
      007342 90 08 8C         [24] 3806 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      007345 12 38 1C         [24] 3807 	lcall	_ak820_outline_0019
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      007348 90 08 8B         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      00734B E0               [24] 3810 	movx	a,@dptr
      00734C FF               [12] 3811 	mov	r7,a
      00734D BF 20 2B         [24] 3812 	cjne	r7,#0x20,00106$
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      007350 C0 07            [24] 3814 	push	ar7
      007352 12 3E 1C         [24] 3815 	lcall	_ak820_nvm_flush
      007355 D0 07            [24] 3816 	pop	ar7
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      007357 90 08 44         [24] 3818 	mov	dptr,#_raw_reply_without_nvm
      00735A E0               [24] 3819 	movx	a,@dptr
      00735B 70 07            [24] 3820 	jnz	00103$
      00735D 12 3E 0D         [24] 3821 	lcall	_ak820_nvm_ok
      007360 E5 82            [12] 3822 	mov	a, dpl
      007362 60 17            [24] 3823 	jz	00106$
      007364                       3824 00103$:
      007364 90 08 8C         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      007367 12 38 5D         [24] 3826 	lcall	_ak820_outline_0080
      00736A 90 08 81         [24] 3827 	mov	dptr,#_ak820_usb_send_PARM_2
      00736D 12 43 70         [24] 3828 	lcall	_ak820_outline_0163
      007370 90 08 83         [24] 3829 	mov	dptr,#_ak820_usb_send_PARM_3
      007373 EF               [12] 3830 	mov	a,r7
      007374 F0               [24] 3831 	movx	@dptr,a
      007375 75 82 03         [24] 3832 	mov	dpl, #0x03
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      007378 02 70 55         [24] 3834 	ljmp	_ak820_usb_send
      00737B                       3835 00106$:
      00737B 22               [24] 3836 	ret
                                   3837 ;------------------------------------------------------------
                                   3838 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3839 ;------------------------------------------------------------
                                   3840 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3841 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3842 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3843 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3844 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3845 ;------------------------------------------------------------
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3847 ;	-----------------------------------------
                                   3848 ;	 function ak820_usb_raw_task
                                   3849 ;	-----------------------------------------
      00737C                       3850 _ak820_usb_raw_task:
                                   3851 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      00737C A2 AF            [12] 3852 	mov	c,_EA
      00737E E4               [12] 3853 	clr	a
      00737F 33               [12] 3854 	rlc	a
      007380 FF               [12] 3855 	mov	r7,a
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3857 ;	assignBit
      007381 C2 AF            [12] 3858 	clr	_EA
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      007383 90 08 1C         [24] 3860 	mov	dptr,#_USB_EnumStatus
      007386 E0               [24] 3861 	movx	a,@dptr
      007387 60 0A            [24] 3862 	jz	00101$
      007389 90 08 23         [24] 3863 	mov	dptr,#_raw_state
      00738C E0               [24] 3864 	movx	a,@dptr
      00738D FE               [12] 3865 	mov	r6,a
      00738E BE 02 02         [24] 3866 	cjne	r6,#0x02,00270$
      007391 80 06            [24] 3867 	sjmp	00102$
      007393                       3868 00270$:
      007393                       3869 00101$:
                                   3870 ;	assignBit
      007393 EF               [12] 3871 	mov	a,r7
      007394 24 FF            [12] 3872 	add	a,#0xff
      007396 92 AF            [24] 3873 	mov	_EA,c
      007398 22               [24] 3874 	ret
      007399                       3875 00102$:
                                   3876 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      007399 90 08 23         [24] 3877 	mov	dptr,#_raw_state
      00739C 74 03            [12] 3878 	mov	a,#0x03
      00739E F0               [24] 3879 	movx	@dptr,a
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3881 ;	assignBit
      00739F EF               [12] 3882 	mov	a,r7
      0073A0 24 FF            [12] 3883 	add	a,#0xff
      0073A2 92 AF            [24] 3884 	mov	_EA,c
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      0073A4 90 08 24         [24] 3886 	mov	dptr,#_raw_buffer
      0073A7 E0               [24] 3887 	movx	a,@dptr
      0073A8 FF               [12] 3888 	mov	r7,a
      0073A9 E4               [12] 3889 	clr	a
      0073AA BF FD 01         [24] 3890 	cjne	r7,#0xfd,00271$
      0073AD 04               [12] 3891 	inc	a
      0073AE                       3892 00271$:
      0073AE FF               [12] 3893 	mov	r7,a
      0073AF 70 03            [24] 3894 	jnz	00273$
      0073B1 02 74 51         [24] 3895 	ljmp	00118$
      0073B4                       3896 00273$:
      0073B4 90 08 25         [24] 3897 	mov	dptr,#(_raw_buffer + 0x0001)
      0073B7 E0               [24] 3898 	movx	a,@dptr
      0073B8 60 03            [24] 3899 	jz	00274$
      0073BA 02 74 51         [24] 3900 	ljmp	00118$
      0073BD                       3901 00274$:
                                   3902 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      0073BD 90 08 26         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0002)
      0073C0 E0               [24] 3904 	movx	a,@dptr
      0073C1 FD               [12] 3905 	mov	r5,a
      0073C2 7E 00            [12] 3906 	mov	r6,#0x00
      0073C4 90 08 27         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0003)
      0073C7 E0               [24] 3908 	movx	a,@dptr
      0073C8 7B 00            [12] 3909 	mov	r3,#0x00
      0073CA 42 06            [12] 3910 	orl	ar6,a
      0073CC EB               [12] 3911 	mov	a,r3
      0073CD 42 05            [12] 3912 	orl	ar5,a
                                   3913 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      0073CF 90 08 28         [24] 3914 	mov	dptr,#(_raw_buffer + 0x0004)
      0073D2 E0               [24] 3915 	movx	a,@dptr
      0073D3 FC               [12] 3916 	mov	r4,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0073D4 7B 05            [12] 3918 	mov	r3,#0x05
      0073D6                       3919 00128$:
      0073D6 EB               [12] 3920 	mov	a,r3
      0073D7 12 75 5B         [24] 3921 	lcall	_ak820_outline_0105
      0073DA 0B               [12] 3922 	inc	r3
      0073DB BB 20 00         [24] 3923 	cjne	r3,#0x20,00275$
      0073DE                       3924 00275$:
      0073DE 40 F6            [24] 3925 	jc	00128$
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      0073E0 EC               [12] 3927 	mov	a,r4
      0073E1 24 E4            [12] 3928 	add	a,#0xff - 0x1b
      0073E3 40 1C            [24] 3929 	jc	00106$
                                   3930 ;	free result
      0073E5 EC               [12] 3931 	mov	a,r4
      0073E6 60 26            [24] 3932 	jz	00165$
      0073E8 8C 03            [24] 3933 	mov	ar3,r4
      0073EA 1B               [12] 3934 	dec	r3
      0073EB 7A 00            [12] 3935 	mov	r2,#0x00
      0073ED 74 FF            [12] 3936 	mov	a,#0xff
      0073EF C3               [12] 3937 	clr	c
      0073F0 9B               [12] 3938 	subb	a,r3
      0073F1 FB               [12] 3939 	mov	r3,a
      0073F2 74 FF            [12] 3940 	mov	a,#0xff
      0073F4 9A               [12] 3941 	subb	a,r2
      0073F5 FA               [12] 3942 	mov	r2,a
      0073F6 8E 00            [24] 3943 	mov	ar0,r6
      0073F8 8D 01            [24] 3944 	mov	ar1,r5
      0073FA C3               [12] 3945 	clr	c
      0073FB EB               [12] 3946 	mov	a,r3
      0073FC 98               [12] 3947 	subb	a,r0
      0073FD EA               [12] 3948 	mov	a,r2
      0073FE 99               [12] 3949 	subb	a,r1
      0073FF 50 0D            [24] 3950 	jnc	00165$
                                   3951 ;	free result
      007401                       3952 00106$:
                                   3953 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      007401 90 08 25         [24] 3954 	mov	dptr,#(_raw_buffer + 0x0001)
      007404 74 FF            [12] 3955 	mov	a,#0xff
      007406 F0               [24] 3956 	movx	@dptr,a
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      007407 90 08 28         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0004)
      00740A E4               [12] 3959 	clr	a
      00740B F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      00740C 80 3A            [24] 3962 	sjmp	00108$
      00740E                       3963 00165$:
      00740E 7B 00            [12] 3964 	mov	r3,#0x00
      007410                       3965 00131$:
      007410 C3               [12] 3966 	clr	c
      007411 EB               [12] 3967 	mov	a,r3
      007412 9C               [12] 3968 	subb	a,r4
      007413 50 33            [24] 3969 	jnc	00108$
      007415 C0 04            [24] 3970 	push	ar4
      007417 8B 02            [24] 3971 	mov	ar2,r3
      007419 74 05            [12] 3972 	mov	a,#0x05
      00741B 2A               [12] 3973 	add	a, r2
      00741C F9               [12] 3974 	mov	r1,a
      00741D 33               [12] 3975 	rlc	a
      00741E 95 E0            [12] 3976 	subb	a,acc
      007420 FA               [12] 3977 	mov	r2,a
      007421 E9               [12] 3978 	mov	a,r1
      007422 24 24            [12] 3979 	add	a, #_raw_buffer
      007424 F9               [12] 3980 	mov	r1,a
      007425 EA               [12] 3981 	mov	a,r2
      007426 34 08            [12] 3982 	addc	a, #(_raw_buffer >> 8)
      007428 FA               [12] 3983 	mov	r2,a
      007429 8B 2F            [24] 3984 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      00742B 75 30 00         [24] 3985 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      00742E 8E 00            [24] 3986 	mov	ar0,r6
      007430 8D 04            [24] 3987 	mov	ar4,r5
      007432 E5 2F            [12] 3988 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      007434 28               [12] 3989 	add	a, r0
      007435 F8               [12] 3990 	mov	r0,a
      007436 E5 30            [12] 3991 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      007438 3C               [12] 3992 	addc	a, r4
      007439 FC               [12] 3993 	mov	r4,a
      00743A 88 82            [24] 3994 	mov	dpl,r0
      00743C 8C 83            [24] 3995 	mov	dph,r4
      00743E E4               [12] 3996 	clr	a
      00743F 93               [24] 3997 	movc	a,@a+dptr
      007440 12 75 67         [24] 3998 	lcall	_ak820_outline_0140
      007443 0B               [12] 3999 	inc	r3
      007444 D0 04            [24] 4000 	pop	ar4
      007446 80 C8            [24] 4001 	sjmp	00131$
      007448                       4002 00108$:
                                   4003 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007448 12 75 47         [24] 4004 	lcall	_ak820_outline_0048
      00744B 12 70 55         [24] 4005 	lcall	_ak820_usb_send
      00744E 02 74 F7         [24] 4006 	ljmp	00119$
      007451                       4007 00118$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      007451 EF               [12] 4009 	mov	a,r7
      007452 70 03            [24] 4010 	jnz	00281$
      007454 02 74 D4         [24] 4011 	ljmp	00114$
      007457                       4012 00281$:
      007457 12 75 6D         [24] 4013 	lcall	_ak820_outline_0165
      00745A BF 01 02         [24] 4014 	cjne	r7,#0x01,00282$
      00745D 80 03            [24] 4015 	sjmp	00283$
      00745F                       4016 00282$:
      00745F 02 74 D4         [24] 4017 	ljmp	00114$
      007462                       4018 00283$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      007462 7F 02            [12] 4020 	mov	r7,#0x02
      007464                       4021 00133$:
      007464 EF               [12] 4022 	mov	a,r7
      007465 12 75 5B         [24] 4023 	lcall	_ak820_outline_0105
      007468 0F               [12] 4024 	inc	r7
      007469 BF 20 00         [24] 4025 	cjne	r7,#0x20,00284$
      00746C                       4026 00284$:
      00746C 40 F6            [24] 4027 	jc	00133$
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      00746E 90 08 26         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0002)
      007471 74 01            [12] 4030 	mov	a,#0x01
      007473 F0               [24] 4031 	movx	@dptr,a
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      007474 90 08 27         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0003)
      007477 74 A8            [12] 4034 	mov	a,#0xa8
      007479 F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      00747A 90 08 28         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0004)
      00747D 12 3B 8A         [24] 4038 	lcall	_ak820_nvm_diagnostic
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      007480 7F 00            [12] 4040 	mov	r7,#0x00
      007482                       4041 00135$:
      007482 8F 06            [24] 4042 	mov	ar6,r7
      007484 74 0B            [12] 4043 	mov	a,#0x0b
      007486 2E               [12] 4044 	add	a, r6
      007487 24 24            [12] 4045 	add	a,#_raw_buffer
      007489 FE               [12] 4046 	mov	r6,a
      00748A E4               [12] 4047 	clr	a
      00748B 34 08            [12] 4048 	addc	a, #(_raw_buffer >> 8)
      00748D FD               [12] 4049 	mov	r5,a
      00748E EF               [12] 4050 	mov	a,r7
      00748F 24 64            [12] 4051 	add	a, #_ak820_flash_diagnostic
      007491 F5 82            [12] 4052 	mov	dpl,a
      007493 E4               [12] 4053 	clr	a
      007494 34 04            [12] 4054 	addc	a, #(_ak820_flash_diagnostic >> 8)
      007496 F5 83            [12] 4055 	mov	dph,a
      007498 E0               [24] 4056 	movx	a,@dptr
      007499 8E 82            [24] 4057 	mov	dpl,r6
      00749B 8D 83            [24] 4058 	mov	dph,r5
      00749D F0               [24] 4059 	movx	@dptr,a
      00749E 0F               [12] 4060 	inc	r7
      00749F BF 06 00         [24] 4061 	cjne	r7,#0x06,00286$
      0074A2                       4062 00286$:
      0074A2 40 DE            [24] 4063 	jc	00135$
                                   4064 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      0074A4 90 0E F4         [24] 4065 	mov	dptr,#_vial_unlocked
      0074A7 E0               [24] 4066 	movx	a,@dptr
      0074A8 90 08 35         [24] 4067 	mov	dptr,#(_raw_buffer + 0x0011)
      0074AB F0               [24] 4068 	movx	@dptr,a
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      0074AC 90 0E F5         [24] 4070 	mov	dptr,#_vial_unlock_in_progress
      0074AF E0               [24] 4071 	movx	a,@dptr
      0074B0 90 08 36         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0012)
      0074B3 F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      0074B4 90 08 1C         [24] 4075 	mov	dptr,#_USB_EnumStatus
      0074B7 E0               [24] 4076 	movx	a,@dptr
      0074B8 90 08 37         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0013)
      0074BB F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      0074BC 90 08 1D         [24] 4080 	mov	dptr,#_USB_SleepStatus
      0074BF E0               [24] 4081 	movx	a,@dptr
      0074C0 90 08 38         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0014)
      0074C3 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      0074C4 90 08 23         [24] 4085 	mov	dptr,#_raw_state
      0074C7 E0               [24] 4086 	movx	a,@dptr
      0074C8 90 08 39         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0015)
      0074CB F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      0074CC 12 75 47         [24] 4090 	lcall	_ak820_outline_0048
      0074CF 12 70 55         [24] 4091 	lcall	_ak820_usb_send
      0074D2 80 23            [24] 4092 	sjmp	00119$
      0074D4                       4093 00114$:
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      0074D4 12 72 64         [24] 4095 	lcall	_raw_request_is_nonpersistent
      0074D7 E5 82            [12] 4096 	mov	a, dpl
      0074D9 90 08 44         [24] 4097 	mov	dptr,#_raw_reply_without_nvm
      0074DC F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      0074DD 12 3F 6F         [24] 4100 	lcall	_ak820_nvm_begin
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      0074E0 90 0D 11         [24] 4102 	mov	dptr,#_raw_hid_receive_PARM_2
      0074E3 74 20            [12] 4103 	mov	a,#0x20
      0074E5 F0               [24] 4104 	movx	@dptr,a
      0074E6 90 08 24         [24] 4105 	mov	dptr,#_raw_buffer
      0074E9 75 F0 00         [24] 4106 	mov	b, #0x00
      0074EC 12 B0 7C         [24] 4107 	lcall	_raw_hid_receive
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      0074EF 12 3F 84         [24] 4109 	lcall	_ak820_nvm_end
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      0074F2 90 08 44         [24] 4111 	mov	dptr,#_raw_reply_without_nvm
      0074F5 E4               [12] 4112 	clr	a
      0074F6 F0               [24] 4113 	movx	@dptr,a
      0074F7                       4114 00119$:
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4116 ;	assignBit
      0074F7 A2 AF            [12] 4117 	mov	c,_EA
      0074F9 92 20            [24] 4118 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4120 ;	assignBit
      0074FB C2 AF            [12] 4121 	clr	_EA
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      0074FD 12 75 73         [24] 4123 	lcall	_ak820_outline_0167
      007500 BF 04 08         [24] 4124 	cjne	r7,#0x04,00126$
      007503 90 08 23         [24] 4125 	mov	dptr,#_raw_state
      007506 74 05            [12] 4126 	mov	a,#0x05
      007508 F0               [24] 4127 	movx	@dptr,a
      007509 80 1B            [24] 4128 	sjmp	00127$
      00750B                       4129 00126$:
                                   4130 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      00750B 12 75 73         [24] 4131 	lcall	_ak820_outline_0167
      00750E BF 03 02         [24] 4132 	cjne	r7,#0x03,00290$
      007511 80 0E            [24] 4133 	sjmp	00121$
      007513                       4134 00290$:
      007513 12 75 73         [24] 4135 	lcall	_ak820_outline_0167
      007516 BF 06 02         [24] 4136 	cjne	r7,#0x06,00291$
      007519 80 06            [24] 4137 	sjmp	00121$
      00751B                       4138 00291$:
      00751B 12 75 73         [24] 4139 	lcall	_ak820_outline_0167
      00751E BF 07 05         [24] 4140 	cjne	r7,#0x07,00127$
      007521                       4141 00121$:
      007521 90 08 23         [24] 4142 	mov	dptr,#_raw_state
      007524 E4               [12] 4143 	clr	a
      007525 F0               [24] 4144 	movx	@dptr,a
      007526                       4145 00127$:
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4147 ;	assignBit
      007526 A2 20            [12] 4148 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      007528 92 AF            [24] 4149 	mov	_EA,c
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      00752A 22               [24] 4151 	ret
                                   4152 ;------------------------------------------------------------
                                   4153 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4154 ;------------------------------------------------------------
                                   4155 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4156 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_take_keyboard_reset
                                   4161 ;	-----------------------------------------
      00752B                       4162 _ak820_usb_take_keyboard_reset:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4164 ;	assignBit
      00752B A2 AF            [12] 4165 	mov	c,_EA
      00752D 92 21            [24] 4166 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4168 ;	assignBit
      00752F C2 AF            [12] 4169 	clr	_EA
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      007531 90 08 45         [24] 4171 	mov	dptr,#_keyboard_reset
      007534 E0               [24] 4172 	movx	a,@dptr
      007535 FF               [12] 4173 	mov	r7,a
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      007536 E4               [12] 4175 	clr	a
      007537 F0               [24] 4176 	movx	@dptr,a
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4178 ;	assignBit
      007538 A2 21            [12] 4179 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      00753A 92 AF            [24] 4180 	mov	_EA,c
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      00753C EF               [12] 4182 	mov	a,r7
      00753D B4 01 00         [24] 4183 	cjne	a,#0x01,00103$
      007540                       4184 00103$:
      007540 B3               [12] 4185 	cpl	c
      007541 92 21            [24] 4186 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      007543 12 38 A4         [24] 4187 	lcall	_ak820_outline_0157
                                   4188 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      007546 22               [24] 4189 	ret
                                   4190 	.area CSEG    (CODE)
                                   4191 	.area CONST   (CODE)
                                   4192 	.area CONST   (CODE)
      00C415                       4193 _shared_offsets:
      00C415 00                    4194 	.db #0x00	; 0
      00C416 00                    4195 	.db #0x00	; 0
      00C417 28                    4196 	.db #0x28	; 40
      00C418 28                    4197 	.db #0x28	; 40
      00C419 2B                    4198 	.db #0x2b	; 43
      00C41A 00                    4199 	.db #0x00	; 0
      00C41B 08                    4200 	.db #0x08	; 8
                                   4201 	.area CSEG    (CODE)
                                   4202 	.area CONST   (CODE)
      00C41C                       4203 _shared_lengths:
      00C41C 00                    4204 	.db #0x00	; 0
      00C41D 00                    4205 	.db #0x00	; 0
      00C41E 00                    4206 	.db #0x00	; 0
      00C41F 03                    4207 	.db #0x03	; 3
      00C420 03                    4208 	.db #0x03	; 3
      00C421 00                    4209 	.db #0x00	; 0
      00C422 20                    4210 	.db #0x20	; 32
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00C423                       4213 _interface_descriptors:
      00C423 BE C9                 4214 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00C425 BE CA                 4215 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00C427 71 CA                 4216 	.byte _RawReport, (_RawReport >> 8)
      00C429 D7 CA                 4217 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00C42B 03 CA                 4218 	.byte _SharedReport, (_SharedReport >> 8)
      00C42D F0 CA                 4219 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4220 	.area CSEG    (CODE)
                                   4221 	.area XINIT   (CODE)
                                   4222 	.area CABS    (ABS,CODE)
                                   4223 
                                   4224 ; Experimental exact instruction outlining.
                                   4225 	.globl _ak820_outline_0019
                                   4226 	.globl _ak820_outline_0038
                                   4227 	.globl _ak820_outline_0048
                                   4228 	.globl _ak820_outline_0080
                                   4229 	.globl _ak820_outline_0105
                                   4230 	.globl _ak820_outline_0140
                                   4231 	.globl _ak820_outline_0157
                                   4232 	.globl _ak820_outline_0163
                                   4233 	.globl _ak820_outline_0165
                                   4234 	.globl _ak820_outline_0167
                                   4235 
                                   4236 	.area CSEG (CODE)
                                   4237 ; function ak820_outline_0048
      007547                       4238 _ak820_outline_0048:
      007547 90 08 81         [24] 4239 	mov	dptr,#_ak820_usb_send_PARM_2
      00754A 74 24            [12] 4240 	mov	a,#_raw_buffer
      00754C F0               [24] 4241 	movx	@dptr,a
      00754D 74 08            [12] 4242 	mov	a,#(_raw_buffer>>8)
      00754F A3               [24] 4243 	inc	dptr
      007550 F0               [24] 4244 	movx	@dptr,a
      007551 90 08 83         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_3
      007554 74 20            [12] 4246 	mov	a,#0x20
      007556 F0               [24] 4247 	movx	@dptr,a
      007557 75 82 03         [24] 4248 	mov	dpl,#0x03
      00755A 22               [24] 4249 	ret
                                   4250 
                                   4251 	.area CSEG (CODE)
                                   4252 ; function ak820_outline_0105
      00755B                       4253 _ak820_outline_0105:
      00755B 24 24            [12] 4254 	add	a,#_raw_buffer
      00755D F5 82            [12] 4255 	mov	dpl,a
      00755F E4               [12] 4256 	clr	a
      007560 34 08            [12] 4257 	addc	a,#(_raw_buffer>>8)
      007562 F5 83            [12] 4258 	mov	dph,a
      007564 E4               [12] 4259 	clr	a
      007565 F0               [24] 4260 	movx	@dptr,a
      007566 22               [24] 4261 	ret
                                   4262 
                                   4263 	.area CSEG (CODE)
                                   4264 ; function ak820_outline_0140
      007567                       4265 _ak820_outline_0140:
      007567 89 82            [24] 4266 	mov	dpl,r1
      007569 8A 83            [24] 4267 	mov	dph,r2
      00756B F0               [24] 4268 	movx	@dptr,a
      00756C 22               [24] 4269 	ret
                                   4270 
                                   4271 	.area CSEG (CODE)
                                   4272 ; function ak820_outline_0165
      00756D                       4273 _ak820_outline_0165:
      00756D 90 08 25         [24] 4274 	mov	dptr,#(_raw_buffer+0x0001)
      007570 E0               [24] 4275 	movx	a,@dptr
      007571 FF               [12] 4276 	mov	r7,a
      007572 22               [24] 4277 	ret
                                   4278 
                                   4279 	.area CSEG (CODE)
                                   4280 ; function ak820_outline_0167
      007573                       4281 _ak820_outline_0167:
      007573 90 08 23         [24] 4282 	mov	dptr,#_raw_state
      007576 E0               [24] 4283 	movx	a,@dptr
      007577 FF               [12] 4284 	mov	r7,a
      007578 22               [24] 4285 	ret
