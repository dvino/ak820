                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 ;--------------------------------------------------------
                                    535 ; indirectly addressable internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area ISEG    (DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; absolute internal ram data
                                    540 ;--------------------------------------------------------
                                    541 	.area IABS    (ABS,DATA)
                                    542 	.area IABS    (ABS,DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; bit data
                                    545 ;--------------------------------------------------------
                                    546 	.area BSEG    (BIT)
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      0008A1                        555 _KEYCODE2CONSUMER_key_10000_117:
      0008A1                        556 	.ds 1
      0008A2                        557 _add_key_byte_PARM_2:
      0008A2                        558 	.ds 1
      0008A3                        559 _add_key_byte_report_arg_10000_144:
      0008A3                        560 	.ds 2
      0008A5                        561 _add_key_byte_empty_10000_145:
      0008A5                        562 	.ds 1
      0008A6                        563 _del_key_byte_PARM_2:
      0008A6                        564 	.ds 1
      0008A7                        565 _del_key_byte_report_arg_10000_156:
      0008A7                        566 	.ds 2
      0008A9                        567 _add_key_bit_PARM_2:
      0008A9                        568 	.ds 1
      0008AA                        569 _add_key_bit_report_arg_10000_162:
      0008AA                        570 	.ds 2
      0008AC                        571 _del_key_bit_PARM_2:
      0008AC                        572 	.ds 1
      0008AD                        573 _del_key_bit_report_arg_10000_167:
      0008AD                        574 	.ds 2
      0008AF                        575 _add_key_to_report_PARM_2:
      0008AF                        576 	.ds 1
      0008B0                        577 _add_key_to_report_report_arg_10000_172:
      0008B0                        578 	.ds 2
      0008B2                        579 _del_key_from_report_PARM_2:
      0008B2                        580 	.ds 1
      0008B3                        581 _del_key_from_report_report_arg_10000_176:
      0008B3                        582 	.ds 2
      0008B5                        583 _clear_keys_from_report_report_arg_10000_180:
      0008B5                        584 	.ds 2
                                    585 ;--------------------------------------------------------
                                    586 ; absolute external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XABS    (ABS,XDATA)
                                    589 ;--------------------------------------------------------
                                    590 ; initialized external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area XISEG   (XDATA)
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    621 ;------------------------------------------------------------
                                    622 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    623 ;------------------------------------------------------------
                                    624 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function KEYCODE2CONSUMER
                                    635 ;	-----------------------------------------
      0076A5                        636 _KEYCODE2CONSUMER:
      0076A5 E5 82            [12]  637 	mov	a,dpl
      0076A7 90 08 A1         [24]  638 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      0076AA F0               [24]  639 	movx	@dptr,a
                                    640 ;	tmk_core/protocol/report.c:43: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      0076AB E0               [24]  641 	movx	a,@dptr
      0076AC FF               [12]  642 	mov	r7,a
      0076AD BF A8 00         [24]  643 	cjne	r7,#0xa8,00113$
      0076B0                        644 00113$:
      0076B0 40 05            [24]  645 	jc	00101$
      0076B2 EF               [12]  646 	mov	a,r7
      0076B3 24 3D            [12]  647 	add	a,#0xff - 0xc2
      0076B5 50 04            [24]  648 	jnc	00102$
                                    649 ;	free result
      0076B7                        650 00101$:
      0076B7 90 00 00         [24]  651 	mov	dptr,#0x0000
      0076BA 22               [24]  652 	ret
      0076BB                        653 00102$:
                                    654 ;	tmk_core/protocol/report.c:44: return usages[key - KC_AUDIO_MUTE];
      0076BB EF               [12]  655 	mov	a,r7
      0076BC 24 58            [12]  656 	add	a,#0x58
      0076BE FF               [12]  657 	mov	r7,a
      0076BF C2 D5            [12]  658 	clr	F0
      0076C1 75 F0 02         [24]  659 	mov	b,#0x02
      0076C4 EF               [12]  660 	mov	a,r7
      0076C5 30 E7 04         [24]  661 	jnb	acc.7,00116$
      0076C8 B2 D5            [12]  662 	cpl	F0
      0076CA F4               [12]  663 	cpl	a
      0076CB 04               [12]  664 	inc	a
      0076CC                        665 00116$:
      0076CC A4               [48]  666 	mul	ab
      0076CD 30 D5 03         [24]  667 	jnb	F0,00117$
      0076D0 12 78 B5         [24]  668 	lcall	_ak820_outline_0132
      0076D3                        669 00117$:
      0076D3 24 2F            [12]  670 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      0076D5 F5 82            [12]  671 	mov	dpl,a
      0076D7 74 C4            [12]  672 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      0076D9 12 60 47         [24]  673 	lcall	_ak820_outline_0110
      0076DC FE               [12]  674 	mov	r6,a
      0076DD A3               [24]  675 	inc	dptr
      0076DE E4               [12]  676 	clr	a
      0076DF 93               [24]  677 	movc	a,@a+dptr
                                    678 ;	tmk_core/protocol/report.c:45: }
      0076E0 8E 82            [24]  679 	mov	dpl,r6
      0076E2 F5 83            [12]  680 	mov	dph,a
      0076E4 22               [24]  681 	ret
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'has_anykey'
                                    684 ;------------------------------------------------------------
                                    685 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    686 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    687 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    688 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    689 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    690 ;------------------------------------------------------------
                                    691 ;	tmk_core/protocol/report.c:62: uint8_t has_anykey(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function add_key_byte
                                    694 ;	-----------------------------------------
      0076E5                        695 _add_key_byte:
      0076E5 12 38 75         [24]  696 	lcall	_ak820_outline_0108
      0076E8 90 08 A3         [24]  697 	mov	dptr,#_add_key_byte_report_arg_10000_144
      0076EB 12 38 7A         [24]  698 	lcall	_ak820_outline_0109
                                    699 ;	tmk_core/protocol/report.c:139: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0076EE 90 08 A3         [24]  700 	mov	dptr,#_add_key_byte_report_arg_10000_144
      0076F1 12 38 34         [24]  701 	lcall	_ak820_outline_0054
                                    702 ;	tmk_core/protocol/report.c:185: int8_t empty = -1;
      0076F4 90 08 A5         [24]  703 	mov	dptr,#_add_key_byte_empty_10000_145
      0076F7 74 FF            [12]  704 	mov	a,#0xff
      0076F9 F0               [24]  705 	movx	@dptr,a
                                    706 ;	tmk_core/protocol/report.c:200: }
      0076FA 7D 00            [12]  707 	mov	r5,#0x00
      0076FC                        708 00112$:
                                    709 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      0076FC C3               [12]  710 	clr	c
      0076FD ED               [12]  711 	mov	a,r5
      0076FE 64 80            [12]  712 	xrl	a,#0x80
      007700 94 86            [12]  713 	subb	a,#0x86
      007702 50 29            [24]  714 	jnc	00106$
                                    715 ;	tmk_core/protocol/report.c:187: if (keyboard_report->keys[i] == code) {
      007704 12 78 C0         [24]  716 	lcall	_ak820_outline_0146
      007707 F5 82            [12]  717 	mov	dpl,a
      007709 E4               [12]  718 	clr	a
      00770A 3C               [12]  719 	addc	a, r4
      00770B F5 83            [12]  720 	mov	dph,a
      00770D E0               [24]  721 	movx	a,@dptr
      00770E FC               [12]  722 	mov	r4,a
      00770F 90 08 A2         [24]  723 	mov	dptr,#_add_key_byte_PARM_2
      007712 E0               [24]  724 	movx	a,@dptr
      007713 FB               [12]  725 	mov	r3,a
      007714 EC               [12]  726 	mov	a,r4
      007715 B5 03 02         [24]  727 	cjne	a,ar3,00167$
      007718 80 13            [24]  728 	sjmp	00106$
      00771A                        729 00167$:
                                    730 ;	tmk_core/protocol/report.c:190: if (empty == -1 && keyboard_report->keys[i] == 0) {
      00771A 90 08 A5         [24]  731 	mov	dptr,#_add_key_byte_empty_10000_145
      00771D E0               [24]  732 	movx	a,@dptr
      00771E FB               [12]  733 	mov	r3,a
      00771F BB FF 08         [24]  734 	cjne	r3,#0xff,00113$
      007722 EC               [12]  735 	mov	a,r4
      007723 70 05            [24]  736 	jnz	00113$
                                    737 ;	tmk_core/protocol/report.c:191: empty = i;
      007725 90 08 A5         [24]  738 	mov	dptr,#_add_key_byte_empty_10000_145
      007728 ED               [12]  739 	mov	a,r5
      007729 F0               [24]  740 	movx	@dptr,a
      00772A                        741 00113$:
                                    742 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      00772A 0D               [12]  743 	inc	r5
      00772B 80 CF            [24]  744 	sjmp	00112$
      00772D                        745 00106$:
                                    746 ;	tmk_core/protocol/report.c:194: if (i == KEYBOARD_REPORT_KEYS) {
      00772D BD 06 1D         [24]  747 	cjne	r5,#0x06,00114$
                                    748 ;	tmk_core/protocol/report.c:195: if (empty != -1) {
      007730 90 08 A5         [24]  749 	mov	dptr,#_add_key_byte_empty_10000_145
      007733 E0               [24]  750 	movx	a,@dptr
      007734 FD               [12]  751 	mov	r5,a
      007735 BD FF 01         [24]  752 	cjne	r5,#0xff,00173$
      007738 22               [24]  753 	ret
      007739                        754 00173$:
                                    755 ;	tmk_core/protocol/report.c:196: keyboard_report->keys[empty] = code;
      007739 74 02            [12]  756 	mov	a,#0x02
      00773B 12 43 54         [24]  757 	lcall	_ak820_outline_0138
      00773E ED               [12]  758 	mov	a,r5
      00773F 2E               [12]  759 	add	a, r6
      007740 FD               [12]  760 	mov	r5,a
      007741 E4               [12]  761 	clr	a
      007742 3F               [12]  762 	addc	a, r7
      007743 FC               [12]  763 	mov	r4,a
      007744 90 08 A2         [24]  764 	mov	dptr,#_add_key_byte_PARM_2
      007747 E0               [24]  765 	movx	a,@dptr
      007748 8D 82            [24]  766 	mov	dpl,r5
      00774A 8C 83            [24]  767 	mov	dph,r4
      00774C F0               [24]  768 	movx	@dptr,a
      00774D                        769 00114$:
                                    770 ;	tmk_core/protocol/report.c:200: }
      00774D 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'del_key_byte'
                                    774 ;------------------------------------------------------------
                                    775 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    776 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    777 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    778 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    779 ;------------------------------------------------------------
                                    780 ;	tmk_core/protocol/report.c:206: void del_key_byte(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function del_key_byte
                                    783 ;	-----------------------------------------
      00774E                        784 _del_key_byte:
      00774E 12 38 75         [24]  785 	lcall	_ak820_outline_0108
      007751 90 08 A7         [24]  786 	mov	dptr,#_del_key_byte_report_arg_10000_156
      007754 12 38 7A         [24]  787 	lcall	_ak820_outline_0109
                                    788 ;	tmk_core/protocol/report.c:207: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007757 90 08 A7         [24]  789 	mov	dptr,#_del_key_byte_report_arg_10000_156
      00775A 12 38 34         [24]  790 	lcall	_ak820_outline_0054
                                    791 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      00775D 7D 00            [12]  792 	mov	r5,#0x00
      00775F                        793 00105$:
      00775F BD 06 00         [24]  794 	cjne	r5,#0x06,00131$
      007762                        795 00131$:
      007762 50 1A            [24]  796 	jnc	00107$
                                    797 ;	tmk_core/protocol/report.c:235: if (keyboard_report->keys[i] == code) {
      007764 12 78 C0         [24]  798 	lcall	_ak820_outline_0146
      007767 FB               [12]  799 	mov	r3,a
      007768 E4               [12]  800 	clr	a
      007769 3C               [12]  801 	addc	a, r4
      00776A 12 51 E1         [24]  802 	lcall	_ak820_outline_0058
      00776D 90 08 A6         [24]  803 	mov	dptr,#_del_key_byte_PARM_2
      007770 E0               [24]  804 	movx	a,@dptr
      007771 F9               [12]  805 	mov	r1,a
      007772 EA               [12]  806 	mov	a,r2
      007773 B5 01 05         [24]  807 	cjne	a,ar1,00106$
                                    808 ;	tmk_core/protocol/report.c:236: keyboard_report->keys[i] = 0;
      007776 12 33 FC         [24]  809 	lcall	_ak820_outline_0123
      007779 E4               [12]  810 	clr	a
      00777A F0               [24]  811 	movx	@dptr,a
      00777B                        812 00106$:
                                    813 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      00777B 0D               [12]  814 	inc	r5
      00777C 80 E1            [24]  815 	sjmp	00105$
      00777E                        816 00107$:
                                    817 ;	tmk_core/protocol/report.c:240: }
      00777E 22               [24]  818 	ret
                                    819 ;------------------------------------------------------------
                                    820 ;Allocation info for local variables in function 'add_key_bit'
                                    821 ;------------------------------------------------------------
                                    822 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    823 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    824 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    825 ;------------------------------------------------------------
                                    826 ;	tmk_core/protocol/report.c:247: void add_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    827 ;	-----------------------------------------
                                    828 ;	 function add_key_bit
                                    829 ;	-----------------------------------------
      00777F                        830 _add_key_bit:
      00777F 12 38 75         [24]  831 	lcall	_ak820_outline_0108
      007782 90 08 AA         [24]  832 	mov	dptr,#_add_key_bit_report_arg_10000_162
      007785 12 38 7A         [24]  833 	lcall	_ak820_outline_0109
                                    834 ;	tmk_core/protocol/report.c:248: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007788 90 08 AA         [24]  835 	mov	dptr,#_add_key_bit_report_arg_10000_162
      00778B 12 38 34         [24]  836 	lcall	_ak820_outline_0054
                                    837 ;	tmk_core/protocol/report.c:249: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      00778E 90 08 A9         [24]  838 	mov	dptr,#_add_key_bit_PARM_2
      007791 E0               [24]  839 	movx	a,@dptr
      007792 FD               [12]  840 	mov	r5,a
      007793 12 60 7D         [24]  841 	lcall	_ak820_outline_0189
      007796 FC               [12]  842 	mov	r4,a
      007797 BC 1E 00         [24]  843 	cjne	r4,#0x1e,00112$
      00779A                        844 00112$:
      00779A 50 16            [24]  845 	jnc	00103$
                                    846 ;	tmk_core/protocol/report.c:250: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      00779C 12 78 9E         [24]  847 	lcall	_ak820_outline_0036
      00779F 80 02            [24]  848 	sjmp	00115$
      0077A1                        849 00114$:
      0077A1 25 E0            [12]  850 	add	a,acc
      0077A3                        851 00115$:
      0077A3 D5 F0 FB         [24]  852 	djnz	b,00114$
      0077A6 FF               [12]  853 	mov	r7,a
      0077A7 12 43 7B         [24]  854 	lcall	_ak820_outline_0184
      0077AA E0               [24]  855 	movx	a,@dptr
      0077AB 42 07            [12]  856 	orl	ar7,a
      0077AD 12 43 7B         [24]  857 	lcall	_ak820_outline_0184
      0077B0 EF               [12]  858 	mov	a,r7
      0077B1 F0               [24]  859 	movx	@dptr,a
      0077B2                        860 00103$:
                                    861 ;	tmk_core/protocol/report.c:254: }
      0077B2 22               [24]  862 	ret
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'del_key_bit'
                                    865 ;------------------------------------------------------------
                                    866 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    867 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    868 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    869 ;------------------------------------------------------------
                                    870 ;	tmk_core/protocol/report.c:260: void del_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function del_key_bit
                                    873 ;	-----------------------------------------
      0077B3                        874 _del_key_bit:
      0077B3 12 38 75         [24]  875 	lcall	_ak820_outline_0108
      0077B6 90 08 AD         [24]  876 	mov	dptr,#_del_key_bit_report_arg_10000_167
      0077B9 12 38 7A         [24]  877 	lcall	_ak820_outline_0109
                                    878 ;	tmk_core/protocol/report.c:261: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0077BC 90 08 AD         [24]  879 	mov	dptr,#_del_key_bit_report_arg_10000_167
      0077BF 12 38 34         [24]  880 	lcall	_ak820_outline_0054
                                    881 ;	tmk_core/protocol/report.c:262: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      0077C2 90 08 AC         [24]  882 	mov	dptr,#_del_key_bit_PARM_2
      0077C5 E0               [24]  883 	movx	a,@dptr
      0077C6 FD               [12]  884 	mov	r5,a
      0077C7 12 60 7D         [24]  885 	lcall	_ak820_outline_0189
      0077CA FC               [12]  886 	mov	r4,a
      0077CB BC 1E 00         [24]  887 	cjne	r4,#0x1e,00112$
      0077CE                        888 00112$:
      0077CE 50 17            [24]  889 	jnc	00103$
                                    890 ;	tmk_core/protocol/report.c:263: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      0077D0 12 78 9E         [24]  891 	lcall	_ak820_outline_0036
      0077D3 80 02            [24]  892 	sjmp	00115$
      0077D5                        893 00114$:
      0077D5 25 E0            [12]  894 	add	a,acc
      0077D7                        895 00115$:
      0077D7 D5 F0 FB         [24]  896 	djnz	b,00114$
      0077DA F4               [12]  897 	cpl	a
      0077DB FF               [12]  898 	mov	r7,a
      0077DC 12 43 7B         [24]  899 	lcall	_ak820_outline_0184
      0077DF E0               [24]  900 	movx	a,@dptr
      0077E0 52 07            [12]  901 	anl	ar7,a
      0077E2 12 43 7B         [24]  902 	lcall	_ak820_outline_0184
      0077E5 EF               [12]  903 	mov	a,r7
      0077E6 F0               [24]  904 	movx	@dptr,a
      0077E7                        905 00103$:
                                    906 ;	tmk_core/protocol/report.c:267: }
      0077E7 22               [24]  907 	ret
                                    908 ;------------------------------------------------------------
                                    909 ;Allocation info for local variables in function 'add_key_to_report'
                                    910 ;------------------------------------------------------------
                                    911 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    912 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    913 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/report.c:274: void add_key_to_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function add_key_to_report
                                    918 ;	-----------------------------------------
      0077E8                        919 _add_key_to_report:
      0077E8 12 38 75         [24]  920 	lcall	_ak820_outline_0108
      0077EB 90 08 B0         [24]  921 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      0077EE 12 38 7A         [24]  922 	lcall	_ak820_outline_0109
                                    923 ;	tmk_core/protocol/report.c:275: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0077F1 90 08 B0         [24]  924 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      0077F4 12 38 34         [24]  925 	lcall	_ak820_outline_0054
                                    926 ;	tmk_core/protocol/report.c:277: if (keyboard_protocol && keymap_config.nkro) {
      0077F7 90 0E 86         [24]  927 	mov	dptr,#_keyboard_protocol
      0077FA E0               [24]  928 	movx	a,@dptr
      0077FB 60 14            [24]  929 	jz	00102$
      0077FD 90 0B 6B         [24]  930 	mov	dptr,#_keymap_config
      007800 E0               [24]  931 	movx	a,@dptr
      007801 30 E7 0D         [24]  932 	jnb	acc.7,00102$
                                    933 ;	tmk_core/protocol/report.c:278: add_key_bit(keyboard_report, key);
      007804 90 08 AF         [24]  934 	mov	dptr,#_add_key_to_report_PARM_2
      007807 E0               [24]  935 	movx	a,@dptr
      007808 90 08 A9         [24]  936 	mov	dptr,#_add_key_bit_PARM_2
      00780B 12 43 31         [24]  937 	lcall	_ak820_outline_0068
                                    938 ;	tmk_core/protocol/report.c:279: return;
      00780E 02 77 7F         [24]  939 	ljmp	_add_key_bit
      007811                        940 00102$:
                                    941 ;	tmk_core/protocol/report.c:282: add_key_byte(keyboard_report, key);
      007811 90 08 AF         [24]  942 	mov	dptr,#_add_key_to_report_PARM_2
      007814 E0               [24]  943 	movx	a,@dptr
      007815 90 08 A2         [24]  944 	mov	dptr,#_add_key_byte_PARM_2
      007818 12 43 31         [24]  945 	lcall	_ak820_outline_0068
                                    946 ;	tmk_core/protocol/report.c:283: }
      00781B 02 76 E5         [24]  947 	ljmp	_add_key_byte
                                    948 ;------------------------------------------------------------
                                    949 ;Allocation info for local variables in function 'del_key_from_report'
                                    950 ;------------------------------------------------------------
                                    951 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    952 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    953 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    954 ;------------------------------------------------------------
                                    955 ;	tmk_core/protocol/report.c:289: void del_key_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    956 ;	-----------------------------------------
                                    957 ;	 function del_key_from_report
                                    958 ;	-----------------------------------------
      00781E                        959 _del_key_from_report:
      00781E 12 38 75         [24]  960 	lcall	_ak820_outline_0108
      007821 90 08 B3         [24]  961 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      007824 12 38 7A         [24]  962 	lcall	_ak820_outline_0109
                                    963 ;	tmk_core/protocol/report.c:290: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007827 90 08 B3         [24]  964 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      00782A 12 38 34         [24]  965 	lcall	_ak820_outline_0054
                                    966 ;	tmk_core/protocol/report.c:292: if (keyboard_protocol && keymap_config.nkro) {
      00782D 90 0E 86         [24]  967 	mov	dptr,#_keyboard_protocol
      007830 E0               [24]  968 	movx	a,@dptr
      007831 60 14            [24]  969 	jz	00102$
      007833 90 0B 6B         [24]  970 	mov	dptr,#_keymap_config
      007836 E0               [24]  971 	movx	a,@dptr
      007837 30 E7 0D         [24]  972 	jnb	acc.7,00102$
                                    973 ;	tmk_core/protocol/report.c:293: del_key_bit(keyboard_report, key);
      00783A 90 08 B2         [24]  974 	mov	dptr,#_del_key_from_report_PARM_2
      00783D E0               [24]  975 	movx	a,@dptr
      00783E 90 08 AC         [24]  976 	mov	dptr,#_del_key_bit_PARM_2
      007841 12 43 31         [24]  977 	lcall	_ak820_outline_0068
                                    978 ;	tmk_core/protocol/report.c:294: return;
      007844 02 77 B3         [24]  979 	ljmp	_del_key_bit
      007847                        980 00102$:
                                    981 ;	tmk_core/protocol/report.c:297: del_key_byte(keyboard_report, key);
      007847 90 08 B2         [24]  982 	mov	dptr,#_del_key_from_report_PARM_2
      00784A E0               [24]  983 	movx	a,@dptr
      00784B 90 08 A6         [24]  984 	mov	dptr,#_del_key_byte_PARM_2
      00784E 12 43 31         [24]  985 	lcall	_ak820_outline_0068
                                    986 ;	tmk_core/protocol/report.c:298: }
      007851 02 77 4E         [24]  987 	ljmp	_del_key_byte
                                    988 ;------------------------------------------------------------
                                    989 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    990 ;------------------------------------------------------------
                                    991 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                    992 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                    993 ;------------------------------------------------------------
                                    994 ;	tmk_core/protocol/report.c:304: void clear_keys_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function clear_keys_from_report
                                    997 ;	-----------------------------------------
      007854                        998 _clear_keys_from_report:
      007854 12 38 75         [24]  999 	lcall	_ak820_outline_0108
      007857 90 08 B5         [24] 1000 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      00785A 12 38 7A         [24] 1001 	lcall	_ak820_outline_0109
                                   1002 ;	tmk_core/protocol/report.c:305: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00785D 90 08 B5         [24] 1003 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      007860 12 38 34         [24] 1004 	lcall	_ak820_outline_0054
                                   1005 ;	tmk_core/protocol/report.c:308: if (keyboard_protocol && keymap_config.nkro) {
      007863 90 0E 86         [24] 1006 	mov	dptr,#_keyboard_protocol
      007866 E0               [24] 1007 	movx	a,@dptr
      007867 60 1E            [24] 1008 	jz	00102$
      007869 90 0B 6B         [24] 1009 	mov	dptr,#_keymap_config
      00786C E0               [24] 1010 	movx	a,@dptr
      00786D 30 E7 17         [24] 1011 	jnb	acc.7,00102$
                                   1012 ;	tmk_core/protocol/report.c:309: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      007870 74 02            [12] 1013 	mov	a,#0x02
      007872 12 43 6A         [24] 1014 	lcall	_ak820_outline_0162
      007875 7B 00            [12] 1015 	mov	r3,#0x00
      007877 12 78 CA         [24] 1016 	lcall	_ak820_outline_0182
      00787A 74 1E            [12] 1017 	mov	a,#0x1e
      00787C F0               [24] 1018 	movx	@dptr,a
      00787D E4               [12] 1019 	clr	a
      00787E A3               [24] 1020 	inc	dptr
      00787F 12 38 69         [24] 1021 	lcall	_ak820_outline_0102
      007882 8B F0            [24] 1022 	mov	b, r3
                                   1023 ;	tmk_core/protocol/report.c:310: return;
      007884 02 C3 20         [24] 1024 	ljmp	_memset
      007887                       1025 00102$:
                                   1026 ;	tmk_core/protocol/report.c:313: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      007887 74 02            [12] 1027 	mov	a,#0x02
      007889 12 43 54         [24] 1028 	lcall	_ak820_outline_0138
      00788C 7D 00            [12] 1029 	mov	r5,#0x00
      00788E 12 78 CA         [24] 1030 	lcall	_ak820_outline_0182
      007891 74 06            [12] 1031 	mov	a,#0x06
      007893 F0               [24] 1032 	movx	@dptr,a
      007894 E4               [12] 1033 	clr	a
      007895 A3               [24] 1034 	inc	dptr
      007896 12 43 31         [24] 1035 	lcall	_ak820_outline_0068
      007899 8D F0            [24] 1036 	mov	b, r5
                                   1037 ;	tmk_core/protocol/report.c:314: }
      00789B 02 C3 20         [24] 1038 	ljmp	_memset
                                   1039 	.area CSEG    (CODE)
                                   1040 	.area CONST   (CODE)
                                   1041 	.area CONST   (CODE)
      00C42F                       1042 _KEYCODE2CONSUMER_usages_10000_118:
      00C42F E2 00                 1043 	.byte #0xe2, #0x00	; 226
      00C431 E9 00                 1044 	.byte #0xe9, #0x00	; 233
      00C433 EA 00                 1045 	.byte #0xea, #0x00	; 234
      00C435 B5 00                 1046 	.byte #0xb5, #0x00	; 181
      00C437 B6 00                 1047 	.byte #0xb6, #0x00	; 182
      00C439 B7 00                 1048 	.byte #0xb7, #0x00	; 183
      00C43B CD 00                 1049 	.byte #0xcd, #0x00	; 205
      00C43D 83 01                 1050 	.byte #0x83, #0x01	; 387
      00C43F CC 00                 1051 	.byte #0xcc, #0x00	; 204
      00C441 8A 01                 1052 	.byte #0x8a, #0x01	; 394
      00C443 92 01                 1053 	.byte #0x92, #0x01	; 402
      00C445 94 01                 1054 	.byte #0x94, #0x01	; 404
      00C447 21 02                 1055 	.byte #0x21, #0x02	; 545
      00C449 23 02                 1056 	.byte #0x23, #0x02	; 547
      00C44B 24 02                 1057 	.byte #0x24, #0x02	; 548
      00C44D 25 02                 1058 	.byte #0x25, #0x02	; 549
      00C44F 26 02                 1059 	.byte #0x26, #0x02	; 550
      00C451 27 02                 1060 	.byte #0x27, #0x02	; 551
      00C453 2A 02                 1061 	.byte #0x2a, #0x02	; 554
      00C455 B3 00                 1062 	.byte #0xb3, #0x00	; 179
      00C457 B4 00                 1063 	.byte #0xb4, #0x00	; 180
      00C459 6F 00                 1064 	.byte #0x6f, #0x00	; 111
      00C45B 70 00                 1065 	.byte #0x70, #0x00	; 112
      00C45D 9F 01                 1066 	.byte #0x9f, #0x01	; 415
      00C45F CB 01                 1067 	.byte #0xcb, #0x01	; 459
      00C461 9F 02                 1068 	.byte #0x9f, #0x02	; 671
      00C463 A0 02                 1069 	.byte #0xa0, #0x02	; 672
                                   1070 	.area CSEG    (CODE)
                                   1071 	.area XINIT   (CODE)
                                   1072 	.area CABS    (ABS,CODE)
                                   1073 
                                   1074 ; Experimental exact instruction outlining.
                                   1075 	.globl _ak820_outline_0036
                                   1076 	.globl _ak820_outline_0054
                                   1077 	.globl _ak820_outline_0058
                                   1078 	.globl _ak820_outline_0068
                                   1079 	.globl _ak820_outline_0102
                                   1080 	.globl _ak820_outline_0108
                                   1081 	.globl _ak820_outline_0109
                                   1082 	.globl _ak820_outline_0110
                                   1083 	.globl _ak820_outline_0123
                                   1084 	.globl _ak820_outline_0132
                                   1085 	.globl _ak820_outline_0138
                                   1086 	.globl _ak820_outline_0146
                                   1087 	.globl _ak820_outline_0162
                                   1088 	.globl _ak820_outline_0182
                                   1089 	.globl _ak820_outline_0184
                                   1090 	.globl _ak820_outline_0189
                                   1091 
                                   1092 	.area CSEG (CODE)
                                   1093 ; function ak820_outline_0036
      00789E                       1094 _ak820_outline_0036:
      00789E 74 02            [12] 1095 	mov	a,#0x02
      0078A0 2E               [12] 1096 	add	a,r6
      0078A1 FE               [12] 1097 	mov	r6,a
      0078A2 E4               [12] 1098 	clr	a
      0078A3 3F               [12] 1099 	addc	a,r7
      0078A4 FF               [12] 1100 	mov	r7,a
      0078A5 EC               [12] 1101 	mov	a,r4
      0078A6 2E               [12] 1102 	add	a,r6
      0078A7 FC               [12] 1103 	mov	r4,a
      0078A8 E4               [12] 1104 	clr	a
      0078A9 3F               [12] 1105 	addc	a,r7
      0078AA FB               [12] 1106 	mov	r3,a
      0078AB 74 07            [12] 1107 	mov	a,#0x07
      0078AD 5D               [12] 1108 	anl	a,r5
      0078AE F5 F0            [12] 1109 	mov	b,a
      0078B0 05 F0            [12] 1110 	inc	b
      0078B2 74 01            [12] 1111 	mov	a,#0x01
      0078B4 22               [24] 1112 	ret
                                   1113 
                                   1114 	.area CSEG (CODE)
                                   1115 ; function ak820_outline_0132
      0078B5                       1116 _ak820_outline_0132:
      0078B5 F4               [12] 1117 	cpl	a
      0078B6 24 01            [12] 1118 	add	a,#0x01
      0078B8 C5 F0            [12] 1119 	xch	a,b
      0078BA F4               [12] 1120 	cpl	a
      0078BB 34 00            [12] 1121 	addc	a,#0x00
      0078BD C5 F0            [12] 1122 	xch	a,b
      0078BF 22               [24] 1123 	ret
                                   1124 
                                   1125 	.area CSEG (CODE)
                                   1126 ; function ak820_outline_0146
      0078C0                       1127 _ak820_outline_0146:
      0078C0 74 02            [12] 1128 	mov	a,#0x02
      0078C2 2E               [12] 1129 	add	a,r6
      0078C3 FB               [12] 1130 	mov	r3,a
      0078C4 E4               [12] 1131 	clr	a
      0078C5 3F               [12] 1132 	addc	a,r7
      0078C6 FC               [12] 1133 	mov	r4,a
      0078C7 ED               [12] 1134 	mov	a,r5
      0078C8 2B               [12] 1135 	add	a,r3
      0078C9 22               [24] 1136 	ret
                                   1137 
                                   1138 	.area CSEG (CODE)
                                   1139 ; function ak820_outline_0182
      0078CA                       1140 _ak820_outline_0182:
      0078CA 90 0E 7B         [24] 1141 	mov	dptr,#_memset_PARM_2
      0078CD E4               [12] 1142 	clr	a
      0078CE F0               [24] 1143 	movx	@dptr,a
      0078CF 90 0E 7C         [24] 1144 	mov	dptr,#_memset_PARM_3
      0078D2 22               [24] 1145 	ret
