                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      000011                        552 _ak820_tapping_before_sloc0_1_0:
      000011                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      00064E                        562 _source_state:
      00064E                        563 	.ds 130
      0006D0                        564 _pending_time:
      0006D0                        565 	.ds 2
      0006D2                        566 _pending_code:
      0006D2                        567 	.ds 2
      0006D4                        568 _ak820_tapping_source_PARM_1:
      0006D4                        569 	.ds 2
      0006D6                        570 _hold_PARM_2:
      0006D6                        571 	.ds 1
      0006D7                        572 _hold_code_10000_603:
      0006D7                        573 	.ds 2
      0006D9                        574 _hold_mods_30000_606:
      0006D9                        575 	.ds 1
      0006DA                        576 _commit_pending_id_10000_612:
      0006DA                        577 	.ds 1
      0006DB                        578 _ak820_tapping_before_event_10000_613:
      0006DB                        579 	.ds 2
      0006DD                        580 _ak820_tapping_process_record_10000_624:
      0006DD                        581 	.ds 2
      0006DF                        582 _ak820_tapping_process_code_10000_625:
      0006DF                        583 	.ds 2
      0006E1                        584 _ak820_tapping_process_sc_mods_10000_625:
      0006E1                        585 	.ds 1
      0006E2                        586 _ak820_oneshot_mods::
      0006E2                        587 	.ds 1
      0006E3                        588 _ak820_oneshot_consumed::
      0006E3                        589 	.ds 1
      0006E4                        590 _ak820_oneshot_process_PARM_2:
      0006E4                        591 	.ds 1
      0006E5                        592 _ak820_oneshot_process_PARM_3:
      0006E5                        593 	.ds 1
      0006E6                        594 _ak820_oneshot_process_code_10000_650:
      0006E6                        595 	.ds 2
      0006E8                        596 _ak820_oneshot_process_mods_10000_651:
      0006E8                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E84                        606 _pending:
      000E84                        607 	.ds 1
      000E85                        608 _ak820_oneshot_target::
      000E85                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004CFB                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004CFB 90 06 D5         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004CFE E0               [24]  656 	movx	a,@dptr
      004CFF FF               [12]  657 	mov	r7,a
      004D00 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004D03                        659 00147$:
      004D03 50 14            [24]  660 	jnc	00102$
      004D05 90 06 D4         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      004D08 E0               [24]  662 	movx	a,@dptr
      004D09 FE               [12]  663 	mov	r6,a
      004D0A BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      004D0D                        665 00149$:
      004D0D 50 0A            [24]  666 	jnc	00102$
      004D0F 8F 05            [24]  667 	mov	ar5,r7
      004D11 ED               [12]  668 	mov	a,r5
      004D12 12 38 B9         [24]  669 	lcall	_ak820_outline_0191
      004D15 2E               [12]  670 	add	a,r6
      004D16 F5 82            [12]  671 	mov	dpl,a
      004D18 22               [24]  672 	ret
      004D19                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004D19 90 06 D4         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      004D1C E0               [24]  676 	movx	a,@dptr
      004D1D FE               [12]  677 	mov	r6,a
      004D1E BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      004D21                        679 00151$:
      004D21 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004D23 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      004D26 75 82 80         [24]  683 	mov	dpl, #0x80
      004D29 22               [24]  684 	ret
      004D2A                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004D2A BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004D2D 75 82 81         [24]  688 	mov	dpl, #0x81
      004D30 22               [24]  689 	ret
      004D31                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004D31 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      004D34 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004D35                        707 _hold:
      004D35 12 38 75         [24]  708 	lcall	_ak820_outline_0108
      004D38 90 06 D7         [24]  709 	mov	dptr,#_hold_code_10000_603
      004D3B 12 38 7A         [24]  710 	lcall	_ak820_outline_0109
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004D3E 90 06 D7         [24]  712 	mov	dptr,#_hold_code_10000_603
      004D41 12 51 8C         [24]  713 	lcall	_ak820_outline_0009
      004D44 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004D46 2D               [12]  715 	add	a,r5
      004D47 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      004D49 8F 05            [24]  718 	mov	ar5,r7
      004D4B 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004D4E 90 06 D9         [24]  720 	mov	dptr,#_hold_mods_30000_606
      004D51 ED               [12]  721 	mov	a,r5
      004D52 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004D53 ED               [12]  724 	mov	a,r5
      004D54 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004D57 ED               [12]  726 	mov	a,r5
      004D58 C4               [12]  727 	swap	a
      004D59 54 F0            [12]  728 	anl	a,#0xf0
      004D5B 90 06 D9         [24]  729 	mov	dptr,#_hold_mods_30000_606
      004D5E F0               [24]  730 	movx	@dptr,a
      004D5F                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004D5F 90 06 D6         [24]  733 	mov	dptr,#_hold_PARM_2
      004D62 E0               [24]  734 	movx	a,@dptr
      004D63 60 09            [24]  735 	jz	00104$
      004D65 90 06 D9         [24]  736 	mov	dptr,#_hold_mods_30000_606
      004D68 E0               [24]  737 	movx	a,@dptr
      004D69 F5 82            [12]  738 	mov	dpl,a
      004D6B 02 7F 3D         [24]  739 	ljmp	_register_mods
      004D6E                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004D6E 90 06 D9         [24]  742 	mov	dptr,#_hold_mods_30000_606
      004D71 E0               [24]  743 	movx	a,@dptr
      004D72 F5 82            [12]  744 	mov	dpl,a
      004D74 02 7F 51         [24]  745 	ljmp	_unregister_mods
      004D77                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004D77 8F 06            [24]  748 	mov	ar6,r7
      004D79 74 0F            [12]  749 	mov	a,#0x0f
      004D7B 5E               [12]  750 	anl	a,r6
      004D7C FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004D7D 90 06 D6         [24]  753 	mov	dptr,#_hold_PARM_2
      004D80 E0               [24]  754 	movx	a,@dptr
      004D81 60 05            [24]  755 	jz	00107$
      004D83 8F 82            [24]  756 	mov	dpl, r7
      004D85 02 81 24         [24]  757 	ljmp	_layer_hold_on
      004D88                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004D88 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004D8A 02 81 5A         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004D8D                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004D8D 90 0E 84         [24]  774 	mov	dptr,#_pending
      004D90 E0               [24]  775 	movx	a,@dptr
      004D91 90 06 DA         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      004D94 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004D95 12 52 25         [24]  779 	lcall	_ak820_outline_0155
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004D98 90 06 DA         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      004D9B E0               [24]  782 	movx	a,@dptr
      004D9C 24 4E            [12]  783 	add	a,#_source_state
      004D9E FF               [12]  784 	mov	r7,a
      004D9F E4               [12]  785 	clr	a
      004DA0 34 06            [12]  786 	addc	a, #(_source_state >> 8)
      004DA2 FE               [12]  787 	mov	r6,a
      004DA3 12 43 65         [24]  788 	lcall	_ak820_outline_0159
      004DA6 E0               [24]  789 	movx	a,@dptr
      004DA7 FD               [12]  790 	mov	r5,a
      004DA8 43 05 04         [24]  791 	orl	ar5,#0x04
      004DAB 12 43 65         [24]  792 	lcall	_ak820_outline_0159
      004DAE ED               [12]  793 	mov	a,r5
      004DAF F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004DB0 90 06 D2         [24]  796 	mov	dptr,#_pending_code
      004DB3 12 38 34         [24]  797 	lcall	_ak820_outline_0054
      004DB6 90 06 D6         [24]  798 	mov	dptr,#_hold_PARM_2
      004DB9 74 01            [12]  799 	mov	a,#0x01
      004DBB 12 43 31         [24]  800 	lcall	_ak820_outline_0068
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004DBE A1 35            [12]  802 	ajmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      004DC0                        813 _ak820_tapping_before:
      004DC0 12 38 75         [24]  814 	lcall	_ak820_outline_0108
      004DC3 90 06 DB         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004DC6 12 38 7A         [24]  816 	lcall	_ak820_outline_0109
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004DC9 90 06 DB         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004DCC 12 51 8C         [24]  819 	lcall	_ak820_outline_0009
      004DCF 12 51 B1         [24]  820 	lcall	_ak820_outline_0025
      004DD2 C0 07            [24]  821 	push	ar7
      004DD4 C0 06            [24]  822 	push	ar6
      004DD6 12 C2 AA         [24]  823 	lcall	___memcpy
      004DD9 91 FB            [12]  824 	acall	_ak820_tapping_source
      004DDB AD 82            [24]  825 	mov	r5, dpl
      004DDD D0 06            [24]  826 	pop	ar6
      004DDF D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004DE1 90 0E F5         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      004DE4 E0               [24]  830 	movx	a,@dptr
      004DE5 60 26            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004DE7 12 52 0B         [24]  833 	lcall	_ak820_outline_0097
      004DEA 60 1D            [24]  834 	jz	00102$
      004DEC BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      004DEF 80 18            [24]  836 	sjmp	00102$
      004DF1                        837 00218$:
      004DF1 12 51 96         [24]  838 	lcall	_ak820_outline_0016
      004DF4 E0               [24]  839 	movx	a,@dptr
      004DF5 70 12            [24]  840 	jnz	00102$
      004DF7 ED               [12]  841 	mov	a,r5
      004DF8 24 4E            [12]  842 	add	a, #_source_state
      004DFA FB               [12]  843 	mov	r3,a
      004DFB E4               [12]  844 	clr	a
      004DFC 34 06            [12]  845 	addc	a, #(_source_state >> 8)
      004DFE 12 51 E1         [24]  846 	lcall	_ak820_outline_0058
      004E01 53 02 FD         [24]  847 	anl	ar2,#0xfd
      004E04 12 33 FC         [24]  848 	lcall	_ak820_outline_0123
      004E07 EA               [12]  849 	mov	a,r2
      004E08 F0               [24]  850 	movx	@dptr,a
      004E09                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004E09 75 82 00         [24]  853 	mov	dpl, #0x00
      004E0C 22               [24]  854 	ret
      004E0D                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004E0D 90 0E 84         [24]  857 	mov	dptr,#_pending
      004E10 E0               [24]  858 	movx	a,@dptr
      004E11 FC               [12]  859 	mov	r4,a
      004E12 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      004E15 80 3A            [24]  861 	sjmp	00108$
      004E17                        862 00220$:
      004E17 12 38 2C         [24]  863 	lcall	_ak820_outline_0037
      004E1A FA               [12]  864 	mov	r2,a
      004E1B A3               [24]  865 	inc	dptr
      004E1C E0               [24]  866 	movx	a,@dptr
      004E1D FB               [12]  867 	mov	r3,a
      004E1E 90 06 D0         [24]  868 	mov	dptr,#_pending_time
      004E21 12 38 6F         [24]  869 	lcall	_ak820_outline_0103
      004E24 EA               [12]  870 	mov	a,r2
      004E25 C3               [12]  871 	clr	c
      004E26 98               [12]  872 	subb	a,r0
      004E27 FA               [12]  873 	mov	r2,a
      004E28 EB               [12]  874 	mov	a,r3
      004E29 99               [12]  875 	subb	a,r1
      004E2A FB               [12]  876 	mov	r3,a
      004E2B C3               [12]  877 	clr	c
      004E2C EA               [12]  878 	mov	a,r2
      004E2D 94 C8            [12]  879 	subb	a,#0xc8
      004E2F EB               [12]  880 	mov	a,r3
      004E30 94 00            [12]  881 	subb	a,#0x00
      004E32 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004E34 74 04            [12]  884 	mov	a,#0x04
      004E36 12 51 CB         [24]  885 	lcall	_ak820_outline_0033
      004E39 60 16            [24]  886 	jz	00108$
      004E3B 12 38 05         [24]  887 	lcall	_ak820_outline_0010
      004E3E 60 11            [24]  888 	jz	00108$
      004E40 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004E43 80 06            [24]  890 	sjmp	00107$
      004E45                        891 00224$:
      004E45 ED               [12]  892 	mov	a,r5
      004E46 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      004E49 80 06            [24]  894 	sjmp	00108$
      004E4B                        895 00225$:
      004E4B                        896 00107$:
      004E4B C0 05            [24]  897 	push	ar5
      004E4D B1 8D            [12]  898 	acall	_commit_pending
      004E4F D0 05            [24]  899 	pop	ar5
      004E51                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004E51 90 06 DB         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004E54 12 38 34         [24]  903 	lcall	_ak820_outline_0054
      004E57 12 52 0B         [24]  904 	lcall	_ak820_outline_0097
      004E5A 60 03            [24]  905 	jz	00114$
      004E5C BD FF 04         [24]  906 	cjne	r5,#0xff,00115$
      004E5F                        907 00114$:
      004E5F 75 82 01         [24]  908 	mov	dpl, #0x01
      004E62 22               [24]  909 	ret
      004E63                        910 00115$:
                                    911 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004E63 ED               [12]  912 	mov	a,r5
      004E64 12 51 FD         [24]  913 	lcall	_ak820_outline_0081
      004E67 30 E1 13         [24]  914 	jnb	acc.1,00120$
                                    915 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004E6A 74 05            [12]  916 	mov	a,#0x05
      004E6C 2E               [12]  917 	add	a, r6
      004E6D 12 38 12         [24]  918 	lcall	_ak820_outline_0018
      004E70 70 07            [24]  919 	jnz	00118$
      004E72 74 FD            [12]  920 	mov	a,#0xfd
      004E74 5B               [12]  921 	anl	a,r3
      004E75 12 38 8A         [24]  922 	lcall	_ak820_outline_0126
      004E78 F0               [24]  923 	movx	@dptr,a
      004E79                        924 00118$:
                                    925 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004E79 75 82 00         [24]  926 	mov	dpl, #0x00
      004E7C 22               [24]  927 	ret
      004E7D                        928 00120$:
                                    929 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004E7D 12 42 F4         [24]  930 	lcall	_ak820_outline_0012
      004E80 E0               [24]  931 	movx	a,@dptr
      004E81 FF               [12]  932 	mov	r7,a
      004E82 8B 06            [24]  933 	mov	ar6,r3
      004E84 53 06 01         [24]  934 	anl	ar6,#0x01
      004E87 EE               [12]  935 	mov	a,r6
      004E88 B4 01 00         [24]  936 	cjne	a,#0x01,00231$
      004E8B                        937 00231$:
      004E8B B3               [12]  938 	cpl	c
      004E8C 92 11            [24]  939 	mov	_ak820_tapping_before_sloc0_1_0,c
      004E8E 8F F0            [24]  940 	mov	b,r7
      004E90 E4               [12]  941 	clr	a
      004E91 33               [12]  942 	rlc	a
      004E92 B5 F0 04         [24]  943 	cjne	a,b,00122$
      004E95 75 82 00         [24]  944 	mov	dpl, #0x00
      004E98 22               [24]  945 	ret
      004E99                        946 00122$:
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004E99 63 03 01         [24]  948 	xrl	ar3,#0x01
      004E9C 12 38 8A         [24]  949 	lcall	_ak820_outline_0126
      004E9F EB               [12]  950 	mov	a,r3
      004EA0 F0               [24]  951 	movx	@dptr,a
                                    952 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004EA1 75 82 01         [24]  953 	mov	dpl, #0x01
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004EA4 22               [24]  955 	ret
                                    956 ;------------------------------------------------------------
                                    957 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    958 ;------------------------------------------------------------
                                    959 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    960 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    961 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    962 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    963 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    964 ;------------------------------------------------------------
                                    965 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    966 ;	-----------------------------------------
                                    967 ;	 function ak820_tapping_process
                                    968 ;	-----------------------------------------
      004EA5                        969 _ak820_tapping_process:
      004EA5 12 38 75         [24]  970 	lcall	_ak820_outline_0108
      004EA8 90 06 DD         [24]  971 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004EAB 12 38 7A         [24]  972 	lcall	_ak820_outline_0109
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004EAE 90 06 E1         [24]  974 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004EB1 E4               [12]  975 	clr	a
      004EB2 F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004EB3 90 06 DD         [24]  978 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004EB6 12 38 34         [24]  979 	lcall	_ak820_outline_0054
      004EB9 74 04            [12]  980 	mov	a,#0x04
      004EBB 12 51 D6         [24]  981 	lcall	_ak820_outline_0034
      004EBE 70 04            [24]  982 	jnz	00102$
      004EC0 75 82 01         [24]  983 	mov	dpl, #0x01
      004EC3 22               [24]  984 	ret
      004EC4                        985 00102$:
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004EC4 8E 04            [24]  987 	mov	ar4,r6
      004EC6 8F 05            [24]  988 	mov	ar5,r7
      004EC8 12 51 B1         [24]  989 	lcall	_ak820_outline_0025
      004ECB C0 07            [24]  990 	push	ar7
      004ECD C0 06            [24]  991 	push	ar6
      004ECF 12 C2 AA         [24]  992 	lcall	___memcpy
      004ED2 91 FB            [12]  993 	acall	_ak820_tapping_source
      004ED4 AD 82            [24]  994 	mov	r5, dpl
      004ED6 D0 06            [24]  995 	pop	ar6
      004ED8 D0 07            [24]  996 	pop	ar7
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004EDA BD FF 04         [24]  998 	cjne	r5,#0xff,00104$
      004EDD 75 82 01         [24]  999 	mov	dpl, #0x01
      004EE0 22               [24] 1000 	ret
      004EE1                       1001 00104$:
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004EE1 74 07            [12] 1003 	mov	a,#0x07
      004EE3 12 38 24         [24] 1004 	lcall	_ak820_outline_0023
      004EE6 12 38 34         [24] 1005 	lcall	_ak820_outline_0054
      004EE9 90 06 DF         [24] 1006 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004EEC 12 51 E9         [24] 1007 	lcall	_ak820_outline_0061
                                   1008 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004EEF BE 1A 15         [24] 1009 	cjne	r6,#0x1a,00111$
      004EF2 BF 7C 12         [24] 1010 	cjne	r7,#0x7c,00111$
      004EF5 90 06 DF         [24] 1011 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004EF8 74 26            [12] 1012 	mov	a,#0x26
      004EFA F0               [24] 1013 	movx	@dptr,a
      004EFB 74 22            [12] 1014 	mov	a,#0x22
      004EFD A3               [24] 1015 	inc	dptr
      004EFE F0               [24] 1016 	movx	@dptr,a
      004EFF 90 06 E1         [24] 1017 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004F02 74 02            [12] 1018 	mov	a,#0x02
      004F04 F0               [24] 1019 	movx	@dptr,a
      004F05 80 28            [24] 1020 	sjmp	00112$
      004F07                       1021 00111$:
                                   1022 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004F07 BE 1B 15         [24] 1023 	cjne	r6,#0x1b,00108$
      004F0A BF 7C 12         [24] 1024 	cjne	r7,#0x7c,00108$
      004F0D 90 06 DF         [24] 1025 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004F10 74 27            [12] 1026 	mov	a,#0x27
      004F12 F0               [24] 1027 	movx	@dptr,a
      004F13 74 32            [12] 1028 	mov	a,#0x32
      004F15 A3               [24] 1029 	inc	dptr
      004F16 F0               [24] 1030 	movx	@dptr,a
      004F17 90 06 E1         [24] 1031 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004F1A 74 20            [12] 1032 	mov	a,#0x20
      004F1C F0               [24] 1033 	movx	@dptr,a
      004F1D 80 10            [24] 1034 	sjmp	00112$
      004F1F                       1035 00108$:
                                   1036 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004F1F BE 1E 0D         [24] 1037 	cjne	r6,#0x1e,00112$
      004F22 BF 7C 0A         [24] 1038 	cjne	r7,#0x7c,00112$
      004F25 90 06 DF         [24] 1039 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004F28 74 28            [12] 1040 	mov	a,#0x28
      004F2A F0               [24] 1041 	movx	@dptr,a
      004F2B 74 32            [12] 1042 	mov	a,#0x32
      004F2D A3               [24] 1043 	inc	dptr
      004F2E F0               [24] 1044 	movx	@dptr,a
      004F2F                       1045 00112$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004F2F 90 06 DF         [24] 1047 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004F32 E0               [24] 1048 	movx	a,@dptr
      004F33 A3               [24] 1049 	inc	dptr
      004F34 E0               [24] 1050 	movx	a,@dptr
      004F35 FF               [12] 1051 	mov	r7,a
                                   1052 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004F36 BF 20 00         [24] 1053 	cjne	r7,#0x20,00242$
      004F39                       1054 00242$:
      004F39 40 05            [24] 1055 	jc	00113$
      004F3B BF 50 00         [24] 1056 	cjne	r7,#0x50,00244$
      004F3E                       1057 00244$:
      004F3E 40 04            [24] 1058 	jc	00114$
      004F40                       1059 00113$:
      004F40 75 82 01         [24] 1060 	mov	dpl, #0x01
      004F43 22               [24] 1061 	ret
      004F44                       1062 00114$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004F44 BF 40 00         [24] 1064 	cjne	r7,#0x40,00246$
      004F47                       1065 00246$:
      004F47 40 0C            [24] 1066 	jc	00117$
      004F49 53 07 0F         [24] 1067 	anl	ar7,#0x0f
      004F4C BF 06 00         [24] 1068 	cjne	r7,#0x06,00248$
      004F4F                       1069 00248$:
      004F4F 40 04            [24] 1070 	jc	00117$
      004F51 75 82 00         [24] 1071 	mov	dpl, #0x00
      004F54 22               [24] 1072 	ret
      004F55                       1073 00117$:
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004F55 90 06 DD         [24] 1075 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004F58 12 38 34         [24] 1076 	lcall	_ak820_outline_0054
      004F5B 12 51 96         [24] 1077 	lcall	_ak820_outline_0016
      004F5E E0               [24] 1078 	movx	a,@dptr
      004F5F 60 1F            [24] 1079 	jz	00131$
                                   1080 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004F61 90 0E 84         [24] 1081 	mov	dptr,#_pending
      004F64 ED               [12] 1082 	mov	a,r5
      004F65 12 42 FE         [24] 1083 	lcall	_ak820_outline_0032
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004F68 12 38 34         [24] 1085 	lcall	_ak820_outline_0054
      004F6B 90 06 D0         [24] 1086 	mov	dptr,#_pending_time
      004F6E 12 51 E9         [24] 1087 	lcall	_ak820_outline_0061
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004F71 90 06 DF         [24] 1089 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004F74 12 38 34         [24] 1090 	lcall	_ak820_outline_0054
      004F77 90 06 D2         [24] 1091 	mov	dptr,#_pending_code
      004F7A 12 51 E9         [24] 1092 	lcall	_ak820_outline_0061
      004F7D 02 50 2F         [24] 1093 	ljmp	00132$
      004F80                       1094 00131$:
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004F80 90 0E 84         [24] 1096 	mov	dptr,#_pending
      004F83 E0               [24] 1097 	movx	a,@dptr
      004F84 FF               [12] 1098 	mov	r7,a
      004F85 ED               [12] 1099 	mov	a,r5
      004F86 B5 07 02         [24] 1100 	cjne	a,ar7,00251$
      004F89 80 03            [24] 1101 	sjmp	00252$
      004F8B                       1102 00251$:
      004F8B 02 50 07         [24] 1103 	ljmp	00128$
      004F8E                       1104 00252$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004F8E 12 52 25         [24] 1106 	lcall	_ak820_outline_0155
                                   1107 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004F91 90 06 E1         [24] 1108 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004F94 E0               [24] 1109 	movx	a,@dptr
      004F95 FF               [12] 1110 	mov	r7,a
      004F96 E0               [24] 1111 	movx	a,@dptr
      004F97 60 05            [24] 1112 	jz	00120$
      004F99 8F 82            [24] 1113 	mov	dpl, r7
      004F9B 12 85 95         [24] 1114 	lcall	_add_owned_mods
      004F9E                       1115 00120$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004F9E 90 06 DD         [24] 1117 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004FA1 12 38 34         [24] 1118 	lcall	_ak820_outline_0054
      004FA4 74 07            [12] 1119 	mov	a,#0x07
      004FA6 2E               [12] 1120 	add	a, r6
      004FA7 FB               [12] 1121 	mov	r3,a
      004FA8 E4               [12] 1122 	clr	a
      004FA9 3F               [12] 1123 	addc	a, r7
      004FAA FC               [12] 1124 	mov	r4,a
      004FAB 90 06 DF         [24] 1125 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004FAE E0               [24] 1126 	movx	a,@dptr
      004FAF F9               [12] 1127 	mov	r1,a
      004FB0 7A 00            [12] 1128 	mov	r2,#0x00
      004FB2 12 33 FC         [24] 1129 	lcall	_ak820_outline_0123
      004FB5 12 52 18         [24] 1130 	lcall	_ak820_outline_0100
                                   1131 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004FB8 C3               [12] 1132 	clr	c
      004FB9 04               [12] 1133 	inc	a
      004FBA 99               [12] 1134 	subb	a,r1
      004FBB 50 38            [24] 1135 	jnc	00122$
                                   1136 ;	free result
                                   1137 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004FBD 74 06            [12] 1138 	mov	a,#0x06
      004FBF 12 38 24         [24] 1139 	lcall	_ak820_outline_0023
      004FC2 E0               [24] 1140 	movx	a,@dptr
      004FC3 54 0F            [12] 1141 	anl	a,#0x0f
      004FC5 44 10            [12] 1142 	orl	a,#0x10
      004FC7 F0               [24] 1143 	movx	@dptr,a
                                   1144 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004FC8 12 51 96         [24] 1145 	lcall	_ak820_outline_0016
      004FCB 74 01            [12] 1146 	mov	a,#0x01
      004FCD F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004FCE 12 51 EF         [24] 1149 	lcall	_ak820_outline_0076
      004FD1 12 52 1E         [24] 1150 	lcall	_ak820_outline_0113
      004FD4 C0 07            [24] 1151 	push	ar7
      004FD6 C0 06            [24] 1152 	push	ar6
      004FD8 C0 04            [24] 1153 	push	ar4
      004FDA C0 03            [24] 1154 	push	ar3
      004FDC 12 79 E3         [24] 1155 	lcall	_process_record
      004FDF D0 03            [24] 1156 	pop	ar3
      004FE1 D0 04            [24] 1157 	pop	ar4
      004FE3 D0 06            [24] 1158 	pop	ar6
      004FE5 D0 07            [24] 1159 	pop	ar7
                                   1160 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004FE7 12 33 FC         [24] 1161 	lcall	_ak820_outline_0123
      004FEA E4               [12] 1162 	clr	a
      004FEB F0               [24] 1163 	movx	@dptr,a
                                   1164 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004FEC FC               [12] 1165 	mov	r4,a
      004FED 12 38 7F         [24] 1166 	lcall	_ak820_outline_0120
      004FF0 8C F0            [24] 1167 	mov	b, r4
      004FF2 12 79 E3         [24] 1168 	lcall	_process_record
      004FF5                       1169 00122$:
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004FF5 90 06 E1         [24] 1171 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004FF8 E0               [24] 1172 	movx	a,@dptr
      004FF9 FF               [12] 1173 	mov	r7,a
      004FFA E0               [24] 1174 	movx	a,@dptr
      004FFB 60 32            [24] 1175 	jz	00132$
                                   1176 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004FFD 8F 82            [24] 1177 	mov	dpl, r7
      004FFF 12 85 A4         [24] 1178 	lcall	_del_owned_mods
                                   1179 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      005002 12 88 C9         [24] 1180 	lcall	_send_keyboard_report
      005005 80 28            [24] 1181 	sjmp	00132$
      005007                       1182 00128$:
                                   1183 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      005007 ED               [12] 1184 	mov	a,r5
      005008 24 4E            [12] 1185 	add	a, #_source_state
      00500A FE               [12] 1186 	mov	r6,a
      00500B E4               [12] 1187 	clr	a
      00500C 34 06            [12] 1188 	addc	a, #(_source_state >> 8)
      00500E FF               [12] 1189 	mov	r7,a
      00500F 12 38 7F         [24] 1190 	lcall	_ak820_outline_0120
      005012 E0               [24] 1191 	movx	a,@dptr
      005013 FD               [12] 1192 	mov	r5,a
      005014 30 E2 18         [24] 1193 	jnb	acc.2,00132$
                                   1194 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      005017 53 05 FB         [24] 1195 	anl	ar5,#0xfb
      00501A 12 38 7F         [24] 1196 	lcall	_ak820_outline_0120
      00501D ED               [12] 1197 	mov	a,r5
      00501E F0               [24] 1198 	movx	@dptr,a
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      00501F 90 06 DF         [24] 1200 	mov	dptr,#_ak820_tapping_process_code_10000_625
      005022 12 38 34         [24] 1201 	lcall	_ak820_outline_0054
      005025 90 06 D6         [24] 1202 	mov	dptr,#_hold_PARM_2
      005028 E4               [12] 1203 	clr	a
      005029 12 43 31         [24] 1204 	lcall	_ak820_outline_0068
      00502C 12 4D 35         [24] 1205 	lcall	_hold
      00502F                       1206 00132$:
                                   1207 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      00502F 75 82 00         [24] 1208 	mov	dpl, #0x00
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      005032 22               [24] 1210 	ret
                                   1211 ;------------------------------------------------------------
                                   1212 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1213 ;------------------------------------------------------------
                                   1214 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1215 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1216 ;------------------------------------------------------------
                                   1217 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1218 ;	-----------------------------------------
                                   1219 ;	 function ak820_tapping_cancel
                                   1220 ;	-----------------------------------------
      005033                       1221 _ak820_tapping_cancel:
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      005033 12 52 25         [24] 1223 	lcall	_ak820_outline_0155
                                   1224 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      005036 7F 00            [12] 1225 	mov	r7,#0x00
      005038                       1226 00103$:
      005038 BF 82 00         [24] 1227 	cjne	r7,#0x82,00122$
      00503B                       1228 00122$:
      00503B 50 16            [24] 1229 	jnc	00105$
                                   1230 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      00503D 12 51 A2         [24] 1231 	lcall	_ak820_outline_0021
                                   1232 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      005040 74 02            [12] 1233 	mov	a,#0x02
      005042 5C               [12] 1234 	anl	a,r4
      005043 FB               [12] 1235 	mov	r3,a
      005044 53 04 01         [24] 1236 	anl	ar4,#0x01
      005047 EC               [12] 1237 	mov	a,r4
      005048 2C               [12] 1238 	add	a,r4
      005049 42 03            [12] 1239 	orl	ar3,a
      00504B 12 38 94         [24] 1240 	lcall	_ak820_outline_0136
      00504E EB               [12] 1241 	mov	a,r3
      00504F F0               [24] 1242 	movx	@dptr,a
                                   1243 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      005050 0F               [12] 1244 	inc	r7
      005051 80 E5            [24] 1245 	sjmp	00103$
      005053                       1246 00105$:
                                   1247 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      005053 22               [24] 1248 	ret
                                   1249 ;------------------------------------------------------------
                                   1250 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1251 ;------------------------------------------------------------
                                   1252 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1253 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1254 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1255 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1256 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1257 ;------------------------------------------------------------
                                   1258 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1259 ;	-----------------------------------------
                                   1260 ;	 function ak820_oneshot_process
                                   1261 ;	-----------------------------------------
      005054                       1262 _ak820_oneshot_process:
      005054 12 38 75         [24] 1263 	lcall	_ak820_outline_0108
      005057 90 06 E6         [24] 1264 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      00505A 12 38 7A         [24] 1265 	lcall	_ak820_outline_0109
                                   1266 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      00505D 90 06 E4         [24] 1267 	mov	dptr,#_ak820_oneshot_process_PARM_2
      005060 E0               [24] 1268 	movx	a,@dptr
      005061 FF               [12] 1269 	mov	r7,a
      005062 BF FF 02         [24] 1270 	cjne	r7,#0xff,00248$
      005065 80 0B            [24] 1271 	sjmp	00101$
      005067                       1272 00248$:
      005067 C0 07            [24] 1273 	push	ar7
      005069 12 AB D5         [24] 1274 	lcall	_get_repeat_key_count
      00506C E5 82            [12] 1275 	mov	a, dpl
      00506E D0 07            [24] 1276 	pop	ar7
      005070 60 04            [24] 1277 	jz	00102$
      005072                       1278 00101$:
      005072 75 82 01         [24] 1279 	mov	dpl, #0x01
      005075 22               [24] 1280 	ret
      005076                       1281 00102$:
                                   1282 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      005076 90 06 E6         [24] 1283 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      005079 E0               [24] 1284 	movx	a,@dptr
      00507A FD               [12] 1285 	mov	r5,a
      00507B A3               [24] 1286 	inc	dptr
      00507C E0               [24] 1287 	movx	a,@dptr
      00507D FB               [12] 1288 	mov	r3,a
      00507E BB 52 02         [24] 1289 	cjne	r3,#0x52,00250$
      005081 80 02            [24] 1290 	sjmp	00251$
      005083                       1291 00250$:
      005083 21 26            [12] 1292 	ajmp	00116$
      005085                       1293 00251$:
      005085 8D 04            [24] 1294 	mov	ar4,r5
      005087 53 04 E0         [24] 1295 	anl	ar4,#0xe0
      00508A BC A0 02         [24] 1296 	cjne	r4,#0xa0,00252$
      00508D 80 02            [24] 1297 	sjmp	00253$
      00508F                       1298 00252$:
      00508F 21 26            [12] 1299 	ajmp	00116$
      005091                       1300 00253$:
                                   1301 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      005091 8D 04            [24] 1302 	mov	ar4,r5
      005093 53 04 0F         [24] 1303 	anl	ar4,#0x0f
      005096 90 06 E8         [24] 1304 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      005099 EC               [12] 1305 	mov	a,r4
      00509A F0               [24] 1306 	movx	@dptr,a
                                   1307 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      00509B ED               [12] 1308 	mov	a,r5
      00509C 30 E4 08         [24] 1309 	jnb	acc.4,00105$
      00509F EC               [12] 1310 	mov	a,r4
      0050A0 C4               [12] 1311 	swap	a
      0050A1 54 F0            [12] 1312 	anl	a,#0xf0
      0050A3 90 06 E8         [24] 1313 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      0050A6 F0               [24] 1314 	movx	@dptr,a
      0050A7                       1315 00105$:
                                   1316 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      0050A7 90 06 E5         [24] 1317 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0050AA E0               [24] 1318 	movx	a,@dptr
      0050AB 60 2D            [24] 1319 	jz	00113$
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      0050AD 12 51 A2         [24] 1321 	lcall	_ak820_outline_0021
      0050B0 43 04 08         [24] 1322 	orl	ar4,#0x08
      0050B3 12 43 2A         [24] 1323 	lcall	_ak820_outline_0066
                                   1324 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      0050B6 53 04 EF         [24] 1325 	anl	ar4,#0xef
      0050B9 12 43 2A         [24] 1326 	lcall	_ak820_outline_0066
                                   1327 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      0050BC 90 0E 85         [24] 1328 	mov	dptr,#_ak820_oneshot_target
      0050BF E0               [24] 1329 	movx	a,@dptr
      0050C0 FC               [12] 1330 	mov	r4,a
      0050C1 BC FF 02         [24] 1331 	cjne	r4,#0xff,00256$
      0050C4 80 09            [24] 1332 	sjmp	00107$
      0050C6                       1333 00256$:
      0050C6 12 51 F6         [24] 1334 	lcall	_ak820_outline_0077
      0050C9 43 04 10         [24] 1335 	orl	ar4,#0x10
      0050CC 12 43 2A         [24] 1336 	lcall	_ak820_outline_0066
      0050CF                       1337 00107$:
                                   1338 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      0050CF 90 06 E8         [24] 1339 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      0050D2 E0               [24] 1340 	movx	a,@dptr
      0050D3 F5 82            [12] 1341 	mov	dpl,a
      0050D5 12 7F 3D         [24] 1342 	lcall	_register_mods
      0050D8 80 48            [24] 1343 	sjmp	00114$
      0050DA                       1344 00113$:
                                   1345 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      0050DA 12 51 A2         [24] 1346 	lcall	_ak820_outline_0021
      0050DD 30 E3 42         [24] 1347 	jnb	acc.3,00114$
                                   1348 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0050E0 EC               [12] 1349 	mov	a,r4
      0050E1 20 E4 24         [24] 1350 	jb	acc.4,00109$
                                   1351 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      0050E4 90 06 E2         [24] 1352 	mov	dptr,#_ak820_oneshot_mods
      0050E7 E0               [24] 1353 	movx	a,@dptr
      0050E8 F4               [12] 1354 	cpl	a
      0050E9 FC               [12] 1355 	mov	r4,a
      0050EA 90 06 E8         [24] 1356 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      0050ED E0               [24] 1357 	movx	a,@dptr
      0050EE FB               [12] 1358 	mov	r3,a
      0050EF 52 04            [12] 1359 	anl	ar4,a
      0050F1 8C 82            [24] 1360 	mov	dpl, r4
      0050F3 C0 06            [24] 1361 	push	ar6
      0050F5 C0 05            [24] 1362 	push	ar5
      0050F7 C0 03            [24] 1363 	push	ar3
      0050F9 12 85 95         [24] 1364 	lcall	_add_owned_mods
      0050FC D0 03            [24] 1365 	pop	ar3
      0050FE D0 05            [24] 1366 	pop	ar5
      005100 D0 06            [24] 1367 	pop	ar6
                                   1368 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      005102 90 06 E2         [24] 1369 	mov	dptr,#_ak820_oneshot_mods
      005105 E0               [24] 1370 	movx	a,@dptr
      005106 4B               [12] 1371 	orl	a,r3
      005107 F0               [24] 1372 	movx	@dptr,a
      005108                       1373 00109$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      005108 90 06 E8         [24] 1375 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      00510B E0               [24] 1376 	movx	a,@dptr
      00510C F5 82            [12] 1377 	mov	dpl,a
      00510E C0 06            [24] 1378 	push	ar6
      005110 C0 05            [24] 1379 	push	ar5
      005112 12 7F 51         [24] 1380 	lcall	_unregister_mods
      005115 D0 05            [24] 1381 	pop	ar5
      005117 D0 06            [24] 1382 	pop	ar6
                                   1383 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      005119 12 51 F6         [24] 1384 	lcall	_ak820_outline_0077
      00511C 53 04 E7         [24] 1385 	anl	ar4,#0xe7
      00511F 12 43 2A         [24] 1386 	lcall	_ak820_outline_0066
      005122                       1387 00114$:
                                   1388 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      005122 75 82 00         [24] 1389 	mov	dpl, #0x00
      005125 22               [24] 1390 	ret
      005126                       1391 00116$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      005126 90 06 E5         [24] 1393 	mov	dptr,#_ak820_oneshot_process_PARM_3
      005129 E0               [24] 1394 	movx	a,@dptr
      00512A 60 5C            [24] 1395 	jz	00124$
      00512C 90 06 E6         [24] 1396 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      00512F 12 38 5D         [24] 1397 	lcall	_ak820_outline_0080
      005132 C3               [12] 1398 	clr	c
      005133 74 01            [12] 1399 	mov	a,#0x01
      005135 9D               [12] 1400 	subb	a,r5
      005136 E4               [12] 1401 	clr	a
      005137 9E               [12] 1402 	subb	a,r6
      005138 50 4E            [24] 1403 	jnc	00124$
                                   1404 ;	free result
                                   1405 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      00513A C3               [12] 1406 	clr	c
      00513B ED               [12] 1407 	mov	a,r5
      00513C 94 E0            [12] 1408 	subb	a,#0xe0
      00513E EE               [12] 1409 	mov	a,r6
      00513F 94 00            [12] 1410 	subb	a,#0x00
      005141 40 07            [24] 1411 	jc	00129$
      005143 74 E7            [12] 1412 	mov	a,#0xe7
      005145 9D               [12] 1413 	subb	a,r5
      005146 E4               [12] 1414 	clr	a
      005147 9E               [12] 1415 	subb	a,r6
      005148 50 3E            [24] 1416 	jnc	00124$
                                   1417 ;	free result
      00514A                       1418 00129$:
                                   1419 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      00514A 74 AE            [12] 1420 	mov	a,#0x100 - 0x52
      00514C 2E               [12] 1421 	add	a,r6
      00514D 50 09            [24] 1422 	jnc	00165$
      00514F C3               [12] 1423 	clr	c
      005150 74 DF            [12] 1424 	mov	a,#0xdf
      005152 9D               [12] 1425 	subb	a,r5
      005153 74 52            [12] 1426 	mov	a,#0x52
      005155 9E               [12] 1427 	subb	a,r6
      005156 50 30            [24] 1428 	jnc	00124$
                                   1429 ;	free result
                                   1430 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      005158                       1431 00165$:
      005158 7E 00            [12] 1432 	mov	r6,#0x00
      00515A                       1433 00131$:
      00515A BE 82 00         [24] 1434 	cjne	r6,#0x82,00265$
      00515D                       1435 00265$:
      00515D 50 12            [24] 1436 	jnc	00120$
                                   1437 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      00515F EE               [12] 1438 	mov	a,r6
      005160 12 51 FD         [24] 1439 	lcall	_ak820_outline_0081
      005163 30 E3 08         [24] 1440 	jnb	acc.3,00132$
      005166 43 03 10         [24] 1441 	orl	ar3,#0x10
      005169 12 38 8A         [24] 1442 	lcall	_ak820_outline_0126
      00516C EB               [12] 1443 	mov	a,r3
      00516D F0               [24] 1444 	movx	@dptr,a
      00516E                       1445 00132$:
                                   1446 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      00516E 0E               [12] 1447 	inc	r6
      00516F 80 E9            [24] 1448 	sjmp	00131$
      005171                       1449 00120$:
                                   1450 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      005171 90 06 E2         [24] 1451 	mov	dptr,#_ak820_oneshot_mods
      005174 E0               [24] 1452 	movx	a,@dptr
      005175 FE               [12] 1453 	mov	r6,a
      005176 E0               [24] 1454 	movx	a,@dptr
      005177 60 0F            [24] 1455 	jz	00124$
                                   1456 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      005179 90 06 E3         [24] 1457 	mov	dptr,#_ak820_oneshot_consumed
      00517C EE               [12] 1458 	mov	a,r6
      00517D F0               [24] 1459 	movx	@dptr,a
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      00517E 90 0E 85         [24] 1461 	mov	dptr,#_ak820_oneshot_target
      005181 EF               [12] 1462 	mov	a,r7
      005182 F0               [24] 1463 	movx	@dptr,a
                                   1464 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      005183 90 06 E2         [24] 1465 	mov	dptr,#_ak820_oneshot_mods
      005186 E4               [12] 1466 	clr	a
      005187 F0               [24] 1467 	movx	@dptr,a
      005188                       1468 00124$:
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      005188 75 82 01         [24] 1470 	mov	dpl, #0x01
                                   1471 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      00518B 22               [24] 1472 	ret
                                   1473 	.area CSEG    (CODE)
                                   1474 	.area CONST   (CODE)
                                   1475 	.area XINIT   (CODE)
      00CB6B                       1476 __xinit__pending:
      00CB6B FF                    1477 	.db #0xff	; 255
      00CB6C                       1478 __xinit__ak820_oneshot_target:
      00CB6C FF                    1479 	.db #0xff	; 255
                                   1480 	.area CABS    (ABS,CODE)
                                   1481 
                                   1482 ; Experimental exact instruction outlining.
                                   1483 	.globl _ak820_outline_0009
                                   1484 	.globl _ak820_outline_0010
                                   1485 	.globl _ak820_outline_0012
                                   1486 	.globl _ak820_outline_0016
                                   1487 	.globl _ak820_outline_0018
                                   1488 	.globl _ak820_outline_0021
                                   1489 	.globl _ak820_outline_0023
                                   1490 	.globl _ak820_outline_0025
                                   1491 	.globl _ak820_outline_0032
                                   1492 	.globl _ak820_outline_0033
                                   1493 	.globl _ak820_outline_0034
                                   1494 	.globl _ak820_outline_0037
                                   1495 	.globl _ak820_outline_0054
                                   1496 	.globl _ak820_outline_0058
                                   1497 	.globl _ak820_outline_0061
                                   1498 	.globl _ak820_outline_0066
                                   1499 	.globl _ak820_outline_0068
                                   1500 	.globl _ak820_outline_0076
                                   1501 	.globl _ak820_outline_0077
                                   1502 	.globl _ak820_outline_0080
                                   1503 	.globl _ak820_outline_0081
                                   1504 	.globl _ak820_outline_0097
                                   1505 	.globl _ak820_outline_0100
                                   1506 	.globl _ak820_outline_0103
                                   1507 	.globl _ak820_outline_0108
                                   1508 	.globl _ak820_outline_0109
                                   1509 	.globl _ak820_outline_0113
                                   1510 	.globl _ak820_outline_0120
                                   1511 	.globl _ak820_outline_0123
                                   1512 	.globl _ak820_outline_0126
                                   1513 	.globl _ak820_outline_0136
                                   1514 	.globl _ak820_outline_0155
                                   1515 	.globl _ak820_outline_0159
                                   1516 	.globl _ak820_outline_0191
                                   1517 
                                   1518 	.area CSEG (CODE)
                                   1519 ; function ak820_outline_0009
      00518C                       1520 _ak820_outline_0009:
      00518C E0               [24] 1521 	movx	a,@dptr
      00518D FE               [12] 1522 	mov	r6,a
      00518E A3               [24] 1523 	inc	dptr
      00518F E0               [24] 1524 	movx	a,@dptr
      005190 FF               [12] 1525 	mov	r7,a
      005191 8E 04            [24] 1526 	mov	ar4,r6
      005193 8F 05            [24] 1527 	mov	ar5,r7
      005195 22               [24] 1528 	ret
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0016
      005196                       1532 _ak820_outline_0016:
      005196 74 05            [12] 1533 	mov	a,#0x05
      005198 2E               [12] 1534 	add	a,r6
      005199 FB               [12] 1535 	mov	r3,a
      00519A E4               [12] 1536 	clr	a
      00519B 3F               [12] 1537 	addc	a,r7
      00519C FC               [12] 1538 	mov	r4,a
      00519D 8B 82            [24] 1539 	mov	dpl,r3
      00519F 8C 83            [24] 1540 	mov	dph,r4
      0051A1 22               [24] 1541 	ret
                                   1542 
                                   1543 	.area CSEG (CODE)
                                   1544 ; function ak820_outline_0021
      0051A2                       1545 _ak820_outline_0021:
      0051A2 EF               [12] 1546 	mov	a,r7
      0051A3 24 4E            [12] 1547 	add	a,#_source_state
      0051A5 FD               [12] 1548 	mov	r5,a
      0051A6 E4               [12] 1549 	clr	a
      0051A7 34 06            [12] 1550 	addc	a,#(_source_state>>8)
      0051A9 FE               [12] 1551 	mov	r6,a
      0051AA 8D 82            [24] 1552 	mov	dpl,r5
      0051AC 8E 83            [24] 1553 	mov	dph,r6
      0051AE E0               [24] 1554 	movx	a,@dptr
      0051AF FC               [12] 1555 	mov	r4,a
      0051B0 22               [24] 1556 	ret
                                   1557 
                                   1558 	.area CSEG (CODE)
                                   1559 ; function ak820_outline_0025
      0051B1                       1560 _ak820_outline_0025:
      0051B1 90 0E 73         [24] 1561 	mov	dptr,#___memcpy_PARM_2
      0051B4 EC               [12] 1562 	mov	a,r4
      0051B5 F0               [24] 1563 	movx	@dptr,a
      0051B6 ED               [12] 1564 	mov	a,r5
      0051B7 A3               [24] 1565 	inc	dptr
      0051B8 F0               [24] 1566 	movx	@dptr,a
      0051B9 E4               [12] 1567 	clr	a
      0051BA A3               [24] 1568 	inc	dptr
      0051BB F0               [24] 1569 	movx	@dptr,a
      0051BC 90 0E 76         [24] 1570 	mov	dptr,#___memcpy_PARM_3
      0051BF 74 02            [12] 1571 	mov	a,#0x02
      0051C1 F0               [24] 1572 	movx	@dptr,a
      0051C2 E4               [12] 1573 	clr	a
      0051C3 A3               [24] 1574 	inc	dptr
      0051C4 F0               [24] 1575 	movx	@dptr,a
      0051C5 90 06 D4         [24] 1576 	mov	dptr,#_ak820_tapping_source_PARM_1
      0051C8 F5 F0            [12] 1577 	mov	b,a
      0051CA 22               [24] 1578 	ret
                                   1579 
                                   1580 	.area CSEG (CODE)
                                   1581 ; function ak820_outline_0033
      0051CB                       1582 _ak820_outline_0033:
      0051CB 2E               [12] 1583 	add	a,r6
      0051CC FA               [12] 1584 	mov	r2,a
      0051CD E4               [12] 1585 	clr	a
      0051CE 3F               [12] 1586 	addc	a,r7
      0051CF FB               [12] 1587 	mov	r3,a
      0051D0 8A 82            [24] 1588 	mov	dpl,r2
      0051D2 8B 83            [24] 1589 	mov	dph,r3
      0051D4 E0               [24] 1590 	movx	a,@dptr
      0051D5 22               [24] 1591 	ret
                                   1592 
                                   1593 	.area CSEG (CODE)
                                   1594 ; function ak820_outline_0034
      0051D6                       1595 _ak820_outline_0034:
      0051D6 2E               [12] 1596 	add	a,r6
      0051D7 FC               [12] 1597 	mov	r4,a
      0051D8 E4               [12] 1598 	clr	a
      0051D9 3F               [12] 1599 	addc	a,r7
      0051DA FD               [12] 1600 	mov	r5,a
      0051DB 8C 82            [24] 1601 	mov	dpl,r4
      0051DD 8D 83            [24] 1602 	mov	dph,r5
      0051DF E0               [24] 1603 	movx	a,@dptr
      0051E0 22               [24] 1604 	ret
                                   1605 
                                   1606 	.area CSEG (CODE)
                                   1607 ; function ak820_outline_0058
      0051E1                       1608 _ak820_outline_0058:
      0051E1 FC               [12] 1609 	mov	r4,a
      0051E2 8B 82            [24] 1610 	mov	dpl,r3
      0051E4 8C 83            [24] 1611 	mov	dph,r4
      0051E6 E0               [24] 1612 	movx	a,@dptr
      0051E7 FA               [12] 1613 	mov	r2,a
      0051E8 22               [24] 1614 	ret
                                   1615 
                                   1616 	.area CSEG (CODE)
                                   1617 ; function ak820_outline_0061
      0051E9                       1618 _ak820_outline_0061:
      0051E9 EE               [12] 1619 	mov	a,r6
      0051EA F0               [24] 1620 	movx	@dptr,a
      0051EB EF               [12] 1621 	mov	a,r7
      0051EC A3               [24] 1622 	inc	dptr
      0051ED F0               [24] 1623 	movx	@dptr,a
      0051EE 22               [24] 1624 	ret
                                   1625 
                                   1626 	.area CSEG (CODE)
                                   1627 ; function ak820_outline_0076
      0051EF                       1628 _ak820_outline_0076:
      0051EF 8E 00            [24] 1629 	mov	ar0,r6
      0051F1 8F 01            [24] 1630 	mov	ar1,r7
      0051F3 7A 00            [12] 1631 	mov	r2,#0x00
      0051F5 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0077
      0051F6                       1636 _ak820_outline_0077:
      0051F6 8D 82            [24] 1637 	mov	dpl,r5
      0051F8 8E 83            [24] 1638 	mov	dph,r6
      0051FA E0               [24] 1639 	movx	a,@dptr
      0051FB FC               [12] 1640 	mov	r4,a
      0051FC 22               [24] 1641 	ret
                                   1642 
                                   1643 	.area CSEG (CODE)
                                   1644 ; function ak820_outline_0081
      0051FD                       1645 _ak820_outline_0081:
      0051FD 24 4E            [12] 1646 	add	a,#_source_state
      0051FF FC               [12] 1647 	mov	r4,a
      005200 E4               [12] 1648 	clr	a
      005201 34 06            [12] 1649 	addc	a,#(_source_state>>8)
      005203 FD               [12] 1650 	mov	r5,a
      005204 8C 82            [24] 1651 	mov	dpl,r4
      005206 8D 83            [24] 1652 	mov	dph,r5
      005208 E0               [24] 1653 	movx	a,@dptr
      005209 FB               [12] 1654 	mov	r3,a
      00520A 22               [24] 1655 	ret
                                   1656 
                                   1657 	.area CSEG (CODE)
                                   1658 ; function ak820_outline_0097
      00520B                       1659 _ak820_outline_0097:
      00520B 74 04            [12] 1660 	mov	a,#0x04
      00520D 2E               [12] 1661 	add	a,r6
      00520E FB               [12] 1662 	mov	r3,a
      00520F E4               [12] 1663 	clr	a
      005210 3F               [12] 1664 	addc	a,r7
      005211 FC               [12] 1665 	mov	r4,a
      005212 8B 82            [24] 1666 	mov	dpl,r3
      005214 8C 83            [24] 1667 	mov	dph,r4
      005216 E0               [24] 1668 	movx	a,@dptr
      005217 22               [24] 1669 	ret
                                   1670 
                                   1671 	.area CSEG (CODE)
                                   1672 ; function ak820_outline_0100
      005218                       1673 _ak820_outline_0100:
      005218 E9               [12] 1674 	mov	a,r1
      005219 F0               [24] 1675 	movx	@dptr,a
      00521A EA               [12] 1676 	mov	a,r2
      00521B A3               [24] 1677 	inc	dptr
      00521C F0               [24] 1678 	movx	@dptr,a
      00521D 22               [24] 1679 	ret
                                   1680 
                                   1681 	.area CSEG (CODE)
                                   1682 ; function ak820_outline_0113
      00521E                       1683 _ak820_outline_0113:
      00521E 88 82            [24] 1684 	mov	dpl,r0
      005220 89 83            [24] 1685 	mov	dph,r1
      005222 8A F0            [24] 1686 	mov	b,r2
      005224 22               [24] 1687 	ret
                                   1688 
                                   1689 	.area CSEG (CODE)
                                   1690 ; function ak820_outline_0155
      005225                       1691 _ak820_outline_0155:
      005225 90 0E 84         [24] 1692 	mov	dptr,#_pending
      005228 74 FF            [12] 1693 	mov	a,#0xff
      00522A F0               [24] 1694 	movx	@dptr,a
      00522B 22               [24] 1695 	ret
