                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00072F                         85 _eeprom_read_word_addr_10000_91:
      00072F                         86 	.ds 3
      000732                         87 _eeprom_read_word_ret_10000_92:
      000732                         88 	.ds 2
      000734                         89 _eeprom_read_dword_addr_10000_93:
      000734                         90 	.ds 3
      000737                         91 _eeprom_read_dword_ret_10000_94:
      000737                         92 	.ds 4
      00073B                         93 _eeprom_write_byte_PARM_2:
      00073B                         94 	.ds 1
      00073C                         95 _eeprom_write_byte_addr_10000_95:
      00073C                         96 	.ds 3
      00073F                         97 _eeprom_write_word_PARM_2:
      00073F                         98 	.ds 2
      000741                         99 _eeprom_write_word_addr_10000_97:
      000741                        100 	.ds 3
      000744                        101 _eeprom_write_dword_PARM_2:
      000744                        102 	.ds 4
      000748                        103 _eeprom_write_dword_addr_10000_99:
      000748                        104 	.ds 3
      00074B                        105 _eeprom_update_byte_PARM_2:
      00074B                        106 	.ds 1
      00074C                        107 _eeprom_update_byte_addr_10000_107:
      00074C                        108 	.ds 3
      00074F                        109 _eeprom_update_word_PARM_2:
      00074F                        110 	.ds 2
      000751                        111 _eeprom_update_word_addr_10000_111:
      000751                        112 	.ds 3
      000754                        113 _eeprom_update_dword_PARM_2:
      000754                        114 	.ds 4
      000758                        115 _eeprom_update_dword_addr_10000_115:
      000758                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      00569D                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      00569D 12 43 06         [24]  170 	lcall	_ak820_outline_0038
      0056A0 90 07 2F         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0056A3 12 38 1C         [24]  172 	lcall	_ak820_outline_0019
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      0056A6 90 07 32         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0056A9 12 58 A4         [24]  175 	lcall	_ak820_outline_0156
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      0056AC 90 07 2F         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0056AF 12 58 58         [24]  178 	lcall	_ak820_outline_0013
      0056B2 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0056B5 ED               [12]  180 	mov	a,r5
      0056B6 12 38 1C         [24]  181 	lcall	_ak820_outline_0019
      0056B9 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0056BC 12 58 9D         [24]  183 	lcall	_ak820_outline_0111
      0056BF 90 07 32         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0056C2 12 40 A2         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      0056C5 90 07 32         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0056C8 12 58 94         [24]  188 	lcall	_ak820_outline_0093
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      0056CB 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      0056CC                        201 _eeprom_read_dword:
      0056CC 12 43 06         [24]  202 	lcall	_ak820_outline_0038
      0056CF 90 07 34         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0056D2 12 38 1C         [24]  204 	lcall	_ak820_outline_0019
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      0056D5 90 07 37         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0056D8 12 58 69         [24]  207 	lcall	_ak820_outline_0053
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      0056DB 90 07 34         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0056DE 12 58 58         [24]  210 	lcall	_ak820_outline_0013
      0056E1 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0056E4 ED               [12]  212 	mov	a,r5
      0056E5 12 38 1C         [24]  213 	lcall	_ak820_outline_0019
      0056E8 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0056EB 74 04            [12]  215 	mov	a,#0x04
      0056ED 12 38 8F         [24]  216 	lcall	_ak820_outline_0127
      0056F0 90 07 37         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0056F3 12 40 A2         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      0056F6 90 07 37         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0056F9 12 58 72         [24]  221 	lcall	_ak820_outline_0057
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      0056FC 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      0056FD                        234 _eeprom_write_byte:
      0056FD 12 43 06         [24]  235 	lcall	_ak820_outline_0038
      005700 90 07 3C         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005703 12 38 1C         [24]  237 	lcall	_ak820_outline_0019
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      005706 90 07 3C         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005709 12 58 41         [24]  240 	lcall	_ak820_outline_0004
      00570C 74 01            [12]  241 	mov	a,#0x01
      00570E 12 38 8F         [24]  242 	lcall	_ak820_outline_0127
      005711 90 07 3B         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005714 02 41 2E         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005717                        256 _eeprom_write_word:
      005717 12 43 06         [24]  257 	lcall	_ak820_outline_0038
      00571A 90 07 41         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00571D 12 38 1C         [24]  259 	lcall	_ak820_outline_0019
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      005720 90 07 41         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005723 12 58 41         [24]  262 	lcall	_ak820_outline_0004
      005726 12 58 9D         [24]  263 	lcall	_ak820_outline_0111
      005729 90 07 3F         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      00572C 02 41 2E         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      00572F                        277 _eeprom_write_dword:
      00572F 12 43 06         [24]  278 	lcall	_ak820_outline_0038
      005732 90 07 48         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005735 12 38 1C         [24]  280 	lcall	_ak820_outline_0019
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005738 90 07 48         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00573B 12 58 41         [24]  283 	lcall	_ak820_outline_0004
      00573E 74 04            [12]  284 	mov	a,#0x04
      005740 12 38 8F         [24]  285 	lcall	_ak820_outline_0127
      005743 90 07 44         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005746 02 41 2E         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      005749                        307 _eeprom_update_byte:
      005749 C0 07            [24]  308 	push	ar7
      00574B C0 06            [24]  309 	push	ar6
      00574D C0 05            [24]  310 	push	ar5
      00574F C0 04            [24]  311 	push	ar4
      005751 12 43 06         [24]  312 	lcall	_ak820_outline_0038
      005754 90 07 4C         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005757 12 38 1C         [24]  314 	lcall	_ak820_outline_0019
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      00575A 90 07 4C         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00575D 12 58 32         [24]  317 	lcall	_ak820_outline_0001
      005760 12 40 67         [24]  318 	lcall	_eeprom_read_byte
      005763 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005765 90 07 4B         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005768 E0               [24]  322 	movx	a,@dptr
      005769 FE               [12]  323 	mov	r6,a
      00576A EF               [12]  324 	mov	a,r7
      00576B B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00576E 80 35            [24]  326 	sjmp	00103$
      005770                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      005770 90 07 4C         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005773 12 38 4B         [24]  330 	lcall	_ak820_outline_0062
      005776 A3               [24]  331 	inc	dptr
      005777 E0               [24]  332 	movx	a,@dptr
      005778 FF               [12]  333 	mov	r7,a
      005779 90 07 3B         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      00577C EE               [12]  335 	mov	a,r6
      00577D 12 38 69         [24]  336 	lcall	_ak820_outline_0102
      005780 8F F0            [24]  337 	mov	b, r7
      005782 C0 07            [24]  338 	push	ar7
      005784 C0 06            [24]  339 	push	ar6
      005786 C0 05            [24]  340 	push	ar5
      005788 C0 04            [24]  341 	push	ar4
      00578A C0 03            [24]  342 	push	ar3
      00578C C0 02            [24]  343 	push	ar2
      00578E C0 01            [24]  344 	push	ar1
      005790 C0 00            [24]  345 	push	ar0
      005792 12 56 FD         [24]  346 	lcall	_eeprom_write_byte
      005795 D0 00            [24]  347 	pop	ar0
      005797 D0 01            [24]  348 	pop	ar1
      005799 D0 02            [24]  349 	pop	ar2
      00579B D0 03            [24]  350 	pop	ar3
      00579D D0 04            [24]  351 	pop	ar4
      00579F D0 05            [24]  352 	pop	ar5
      0057A1 D0 06            [24]  353 	pop	ar6
      0057A3 D0 07            [24]  354 	pop	ar7
      0057A5                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      0057A5 D0 04            [24]  357 	pop	ar4
      0057A7 D0 05            [24]  358 	pop	ar5
      0057A9 D0 06            [24]  359 	pop	ar6
      0057AB D0 07            [24]  360 	pop	ar7
      0057AD 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      0057AE                        373 _eeprom_update_word:
      0057AE 12 43 06         [24]  374 	lcall	_ak820_outline_0038
      0057B1 90 07 51         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0057B4 12 38 1C         [24]  376 	lcall	_ak820_outline_0019
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0057B7 90 07 51         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0057BA 12 58 32         [24]  379 	lcall	_ak820_outline_0001
      0057BD 12 56 9D         [24]  380 	lcall	_eeprom_read_word
      0057C0 12 43 4F         [24]  381 	lcall	_ak820_outline_0135
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0057C3 90 07 4F         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      0057C6 12 38 4B         [24]  384 	lcall	_ak820_outline_0062
      0057C9 EE               [12]  385 	mov	a,r6
      0057CA B5 04 05         [24]  386 	cjne	a,ar4,00112$
      0057CD EF               [12]  387 	mov	a,r7
      0057CE B5 05 01         [24]  388 	cjne	a,ar5,00112$
      0057D1 22               [24]  389 	ret
      0057D2                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      0057D2 90 07 51         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0057D5 E0               [24]  393 	movx	a,@dptr
      0057D6 FB               [12]  394 	mov	r3,a
      0057D7 A3               [24]  395 	inc	dptr
      0057D8 12 38 34         [24]  396 	lcall	_ak820_outline_0054
      0057DB 90 07 3F         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      0057DE 12 38 57         [24]  398 	lcall	_ak820_outline_0079
      0057E1 8B 82            [24]  399 	mov	dpl, r3
      0057E3 8E 83            [24]  400 	mov	dph, r6
      0057E5 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      0057E7 02 57 17         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      0057EA                        415 _eeprom_update_dword:
      0057EA 12 43 06         [24]  416 	lcall	_ak820_outline_0038
      0057ED 90 07 58         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0057F0 12 38 1C         [24]  418 	lcall	_ak820_outline_0019
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      0057F3 90 07 58         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0057F6 12 58 32         [24]  421 	lcall	_ak820_outline_0001
      0057F9 12 56 CC         [24]  422 	lcall	_eeprom_read_dword
      0057FC 12 58 83         [24]  423 	lcall	_ak820_outline_0059
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0057FF 90 07 54         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      005802 E0               [24]  426 	movx	a,@dptr
      005803 F8               [12]  427 	mov	r0,a
      005804 A3               [24]  428 	inc	dptr
      005805 12 58 8B         [24]  429 	lcall	_ak820_outline_0092
      005808 EC               [12]  430 	mov	a,r4
      005809 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      00580C ED               [12]  432 	mov	a,r5
      00580D B5 01 09         [24]  433 	cjne	a,ar1,00112$
      005810 EE               [12]  434 	mov	a,r6
      005811 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      005814 EF               [12]  436 	mov	a,r7
      005815 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      005818 22               [24]  438 	ret
      005819                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      005819 90 07 58         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00581C 12 58 58         [24]  442 	lcall	_ak820_outline_0013
      00581F 90 07 44         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005822 E8               [12]  444 	mov	a,r0
      005823 F0               [24]  445 	movx	@dptr,a
      005824 E9               [12]  446 	mov	a,r1
      005825 A3               [24]  447 	inc	dptr
      005826 F0               [24]  448 	movx	@dptr,a
      005827 EA               [12]  449 	mov	a,r2
      005828 A3               [24]  450 	inc	dptr
      005829 F0               [24]  451 	movx	@dptr,a
      00582A EB               [12]  452 	mov	a,r3
      00582B A3               [24]  453 	inc	dptr
      00582C 12 58 61         [24]  454 	lcall	_ak820_outline_0035
                                    455 ;	drivers/eeprom/eeprom_driver.c:101: }
      00582F 02 57 2F         [24]  456 	ljmp	_eeprom_write_dword
                                    457 	.area CSEG    (CODE)
                                    458 	.area CONST   (CODE)
                                    459 	.area XINIT   (CODE)
                                    460 	.area CABS    (ABS,CODE)
                                    461 
                                    462 ; Experimental exact instruction outlining.
                                    463 	.globl _ak820_outline_0001
                                    464 	.globl _ak820_outline_0004
                                    465 	.globl _ak820_outline_0013
                                    466 	.globl _ak820_outline_0019
                                    467 	.globl _ak820_outline_0035
                                    468 	.globl _ak820_outline_0038
                                    469 	.globl _ak820_outline_0053
                                    470 	.globl _ak820_outline_0054
                                    471 	.globl _ak820_outline_0057
                                    472 	.globl _ak820_outline_0059
                                    473 	.globl _ak820_outline_0062
                                    474 	.globl _ak820_outline_0079
                                    475 	.globl _ak820_outline_0092
                                    476 	.globl _ak820_outline_0093
                                    477 	.globl _ak820_outline_0102
                                    478 	.globl _ak820_outline_0111
                                    479 	.globl _ak820_outline_0127
                                    480 	.globl _ak820_outline_0135
                                    481 	.globl _ak820_outline_0156
                                    482 
                                    483 	.area CSEG (CODE)
                                    484 ; function ak820_outline_0001
      005832                        485 _ak820_outline_0001:
      005832 E0               [24]  486 	movx	a,@dptr
      005833 FD               [12]  487 	mov	r5,a
      005834 A3               [24]  488 	inc	dptr
      005835 E0               [24]  489 	movx	a,@dptr
      005836 FE               [12]  490 	mov	r6,a
      005837 A3               [24]  491 	inc	dptr
      005838 E0               [24]  492 	movx	a,@dptr
      005839 FF               [12]  493 	mov	r7,a
      00583A 8D 82            [24]  494 	mov	dpl,r5
      00583C 8E 83            [24]  495 	mov	dph,r6
      00583E 8F F0            [24]  496 	mov	b,r7
      005840 22               [24]  497 	ret
                                    498 
                                    499 	.area CSEG (CODE)
                                    500 ; function ak820_outline_0004
      005841                        501 _ak820_outline_0004:
      005841 E0               [24]  502 	movx	a,@dptr
      005842 FD               [12]  503 	mov	r5,a
      005843 A3               [24]  504 	inc	dptr
      005844 E0               [24]  505 	movx	a,@dptr
      005845 FE               [12]  506 	mov	r6,a
      005846 A3               [24]  507 	inc	dptr
      005847 E0               [24]  508 	movx	a,@dptr
      005848 FF               [12]  509 	mov	r7,a
      005849 90 05 8E         [24]  510 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00584C ED               [12]  511 	mov	a,r5
      00584D F0               [24]  512 	movx	@dptr,a
      00584E EE               [12]  513 	mov	a,r6
      00584F A3               [24]  514 	inc	dptr
      005850 F0               [24]  515 	movx	@dptr,a
      005851 EF               [12]  516 	mov	a,r7
      005852 A3               [24]  517 	inc	dptr
      005853 F0               [24]  518 	movx	@dptr,a
      005854 90 05 91         [24]  519 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005857 22               [24]  520 	ret
                                    521 
                                    522 	.area CSEG (CODE)
                                    523 ; function ak820_outline_0013
      005858                        524 _ak820_outline_0013:
      005858 E0               [24]  525 	movx	a,@dptr
      005859 FD               [12]  526 	mov	r5,a
      00585A A3               [24]  527 	inc	dptr
      00585B E0               [24]  528 	movx	a,@dptr
      00585C FE               [12]  529 	mov	r6,a
      00585D A3               [24]  530 	inc	dptr
      00585E E0               [24]  531 	movx	a,@dptr
      00585F FF               [12]  532 	mov	r7,a
      005860 22               [24]  533 	ret
                                    534 
                                    535 	.area CSEG (CODE)
                                    536 ; function ak820_outline_0035
      005861                        537 _ak820_outline_0035:
      005861 F0               [24]  538 	movx	@dptr,a
      005862 8D 82            [24]  539 	mov	dpl,r5
      005864 8E 83            [24]  540 	mov	dph,r6
      005866 8F F0            [24]  541 	mov	b,r7
      005868 22               [24]  542 	ret
                                    543 
                                    544 	.area CSEG (CODE)
                                    545 ; function ak820_outline_0053
      005869                        546 _ak820_outline_0053:
      005869 E4               [12]  547 	clr	a
      00586A F0               [24]  548 	movx	@dptr,a
      00586B A3               [24]  549 	inc	dptr
      00586C F0               [24]  550 	movx	@dptr,a
      00586D A3               [24]  551 	inc	dptr
      00586E F0               [24]  552 	movx	@dptr,a
      00586F A3               [24]  553 	inc	dptr
      005870 F0               [24]  554 	movx	@dptr,a
      005871 22               [24]  555 	ret
                                    556 
                                    557 	.area CSEG (CODE)
                                    558 ; function ak820_outline_0057
      005872                        559 _ak820_outline_0057:
      005872 E0               [24]  560 	movx	a,@dptr
      005873 FC               [12]  561 	mov	r4,a
      005874 A3               [24]  562 	inc	dptr
      005875 E0               [24]  563 	movx	a,@dptr
      005876 FD               [12]  564 	mov	r5,a
      005877 A3               [24]  565 	inc	dptr
      005878 E0               [24]  566 	movx	a,@dptr
      005879 FE               [12]  567 	mov	r6,a
      00587A A3               [24]  568 	inc	dptr
      00587B E0               [24]  569 	movx	a,@dptr
      00587C 8C 82            [24]  570 	mov	dpl,r4
      00587E 8D 83            [24]  571 	mov	dph,r5
      005880 8E F0            [24]  572 	mov	b,r6
      005882 22               [24]  573 	ret
                                    574 
                                    575 	.area CSEG (CODE)
                                    576 ; function ak820_outline_0059
      005883                        577 _ak820_outline_0059:
      005883 AC 82            [24]  578 	mov	r4,dpl
      005885 AD 83            [24]  579 	mov	r5,dph
      005887 AE F0            [24]  580 	mov	r6,b
      005889 FF               [12]  581 	mov	r7,a
      00588A 22               [24]  582 	ret
                                    583 
                                    584 	.area CSEG (CODE)
                                    585 ; function ak820_outline_0092
      00588B                        586 _ak820_outline_0092:
      00588B E0               [24]  587 	movx	a,@dptr
      00588C F9               [12]  588 	mov	r1,a
      00588D A3               [24]  589 	inc	dptr
      00588E E0               [24]  590 	movx	a,@dptr
      00588F FA               [12]  591 	mov	r2,a
      005890 A3               [24]  592 	inc	dptr
      005891 E0               [24]  593 	movx	a,@dptr
      005892 FB               [12]  594 	mov	r3,a
      005893 22               [24]  595 	ret
                                    596 
                                    597 	.area CSEG (CODE)
                                    598 ; function ak820_outline_0093
      005894                        599 _ak820_outline_0093:
      005894 E0               [24]  600 	movx	a,@dptr
      005895 FE               [12]  601 	mov	r6,a
      005896 A3               [24]  602 	inc	dptr
      005897 E0               [24]  603 	movx	a,@dptr
      005898 8E 82            [24]  604 	mov	dpl,r6
      00589A F5 83            [12]  605 	mov	dph,a
      00589C 22               [24]  606 	ret
                                    607 
                                    608 	.area CSEG (CODE)
                                    609 ; function ak820_outline_0111
      00589D                        610 _ak820_outline_0111:
      00589D 74 02            [12]  611 	mov	a,#0x02
      00589F F0               [24]  612 	movx	@dptr,a
      0058A0 E4               [12]  613 	clr	a
      0058A1 A3               [24]  614 	inc	dptr
      0058A2 F0               [24]  615 	movx	@dptr,a
      0058A3 22               [24]  616 	ret
                                    617 
                                    618 	.area CSEG (CODE)
                                    619 ; function ak820_outline_0156
      0058A4                        620 _ak820_outline_0156:
      0058A4 E4               [12]  621 	clr	a
      0058A5 F0               [24]  622 	movx	@dptr,a
      0058A6 A3               [24]  623 	inc	dptr
      0058A7 F0               [24]  624 	movx	@dptr,a
      0058A8 22               [24]  625 	ret
