;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_tap_dance
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _get_repeat_key_count
	.globl _dynamic_keymap_get_tap_dance
	.globl _process_record
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_tap_dance_valid
	.globl _ak820_tap_dance_task
	.globl _ak820_tap_dance_before
	.globl _ak820_tap_dance_process
	.globl _ak820_tap_dance_cancel
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_ak820_tap_dance_process_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_td_action_sloc0_1_0:
	.ds 1
_ak820_tap_dance_valid_sloc0_1_0:
	.ds 1
_ak820_tap_dance_before_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_td_entries:
	.ds 80
_td_time:
	.ds 16
_td_output:
	.ds 16
_td_source:
	.ds 8
_td_state:
	.ds 8
_td_suppressed:
	.ds 16
_td_record:
	.ds 9
_td_action_code_10000_594:
	.ds 2
_ak820_tap_dance_valid_entry_10000_596:
	.ds 2
_td_emit_PARM_2:
	.ds 2
_td_emit_PARM_3:
	.ds 1
_td_emit_slot_10000_598:
	.ds 1
_td_tap_PARM_2:
	.ds 2
_td_tap_slot_10000_601:
	.ds 1
_td_finish_interrupted_10000_604:
	.ds 1
_td_finish_slot_10000_605:
	.ds 1
_td_finish_code_10000_605:
	.ds 2
_ak820_tap_dance_task_now_10000_624:
	.ds 2
_ak820_tap_dance_task_term_30000_627:
	.ds 2
_ak820_tap_dance_before_event_10000_630:
	.ds 2
_ak820_tap_dance_process_record_10000_646:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_td_pending:
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function td_action
;	-----------------------------------------
_td_action:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_td_action_code_10000_594
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:22: uint8_t basic = code;
	mov	dptr,#_td_action_code_10000_594
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:23: return !code || (code < QK_MOD_TAP && ((basic >= KC_A && basic <= KC_EXSEL) ||
	mov	a,r6
	mov	r5,a
	orl	a,r7
	jz	00104$
	mov	a,#0x100 - 0x20
	add	a,r7
	jc	00103$
	cjne	r5,#0x04,00148$
00148$:
	jc	00114$
	mov	a,r5
	add	a,#0xff - 0xa4
	jnc	00104$
;	free result
00114$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:24: (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI)));
	cjne	r5,#0xe0,00151$
00151$:
	jc	00103$
	mov	a,r5
	add	a,#0xff - 0xe7
	jnc	00104$
;	free result
00103$:
;	assignBit
	clr	_td_action_sloc0_1_0
	sjmp	00105$
00104$:
;	assignBit
	setb	_td_action_sloc0_1_0
00105$:
	mov	c,_td_action_sloc0_1_0
	clr	a
	rlc	a
	mov	dpl, a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:25: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tap_dance_valid'
;------------------------------------------------------------
;entry         Allocated with name '_ak820_tap_dance_valid_entry_10000_596'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:26: bool ak820_tap_dance_valid(const vial_tap_dance_entry_t AK820_STATE_MEM *entry) {
;	-----------------------------------------
;	 function ak820_tap_dance_valid
;	-----------------------------------------
_ak820_tap_dance_valid:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tap_dance_valid_entry_10000_596
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:27: return entry->custom_tapping_term <= 32767 && td_action(entry->on_tap) &&
	mov	dptr,#_ak820_tap_dance_valid_entry_10000_596
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x08
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	clr	c
	mov	a,#0xff
	subb	a,r4
	mov	a,#0x7f
	subb	a,r5
	jc	00103$
;	free result
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	lcall	_td_action
	mov	a, dpl
	pop	ar6
	pop	ar7
	jz	00103$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: td_action(entry->on_hold) && td_action(entry->on_double_tap) && td_action(entry->on_tap_hold);
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	lcall	_td_action
	mov	a, dpl
	pop	ar6
	pop	ar7
	jz	00103$
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	lcall	_td_action
	mov	a, dpl
	pop	ar6
	pop	ar7
	jz	00103$
	mov	a,#0x06
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	lcall	_td_action
	mov	a, dpl
	jnz	00104$
00103$:
;	assignBit
	clr	_ak820_tap_dance_valid_sloc0_1_0
	sjmp	00105$
00104$:
;	assignBit
	setb	_ak820_tap_dance_valid_sloc0_1_0
00105$:
	mov	c,_ak820_tap_dance_valid_sloc0_1_0
	clr	a
	rlc	a
	mov	dpl, a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:29: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'td_emit'
;------------------------------------------------------------
;code          Allocated with name '_td_emit_PARM_2'
;pressed       Allocated with name '_td_emit_PARM_3'
;slot          Allocated with name '_td_emit_slot_10000_598'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:32: static void td_emit(uint8_t slot, uint16_t code, bool pressed) {
;	-----------------------------------------
;	 function td_emit
;	-----------------------------------------
_td_emit:
	mov	a,dpl
	mov	dptr,#_td_emit_slot_10000_598
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:33: if (!code) return;
	mov	dptr,#_td_emit_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_td_emit_PARM_2
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jnz	00102$
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:34: td_record.event.key.row = td_source[slot] / MATRIX_COLS;
	mov	dptr,#_td_emit_slot_10000_598
	movx	a,@dptr
	mov	r5,a
	add	a, #_td_source
	mov	r3,a
	clr	a
	addc	a, #(_td_source >> 8)
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	mov	b,#0x08
	div	ab
	mov	dptr,#(_td_record + 0x0001)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:35: td_record.event.key.col = td_source[slot] % MATRIX_COLS;
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	mov	r3,a
	anl	ar3,#0x07
	mov	dptr,#_td_record
	mov	a,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:36: td_record.event.type = KEY_EVENT;
	mov	dptr,#(_td_record + 0x0004)
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:37: td_record.event.time = td_time[slot];
	mov	a,r5
	mov	b,#0x02
	mul	ab
	add	a, #_td_time
	mov	dpl,a
	mov	a,#(_td_time >> 8)
	addc	a, b
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#(_td_record + 0x0002)
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:38: td_record.event.pressed = pressed;
	mov	dptr,#_td_emit_PARM_3
	movx	a,@dptr
	mov	dptr,#(_td_record + 0x0005)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:39: td_record.tap.count = 1;
	mov	dptr,#(_td_record + 0x0006)
	movx	a,@dptr
	anl	a,#0x0f
	orl	a,#0x10
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:40: td_record.keycode = code;
	mov	dptr,#(_td_record + 0x0007)
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:41: process_record(&td_record);
	mov	dptr,#_td_record
	mov	b, #0x00
;	keyboards/ajazz/ak820/ak820_tap_dance.c:42: }
	ljmp	_process_record
;------------------------------------------------------------
;Allocation info for local variables in function 'td_tap'
;------------------------------------------------------------
;code          Allocated with name '_td_tap_PARM_2'
;slot          Allocated with name '_td_tap_slot_10000_601'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:43: static void td_tap(uint8_t slot, uint16_t code) {
;	-----------------------------------------
;	 function td_tap
;	-----------------------------------------
_td_tap:
	mov	a,dpl
	mov	dptr,#_td_tap_slot_10000_601
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:44: td_emit(slot, code, true);
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_td_tap_PARM_2
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_td_emit_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_td_emit_PARM_3
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, r7
	push	ar7
	push	ar6
	push	ar5
	lcall	_td_emit
	pop	ar5
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_tap_dance.c:46: if (td_state[slot]) td_emit(slot, code, false);
	mov	a,r7
	add	a, #_td_state
	mov	r3,a
	clr	a
	addc	a, #(_td_state >> 8)
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	jz	00103$
	mov	dptr,#_td_emit_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_td_emit_PARM_3
	clr	a
	movx	@dptr,a
	mov	dpl, r7
;	keyboards/ajazz/ak820/ak820_tap_dance.c:47: }
	ljmp	_td_emit
00103$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'td_finish'
;------------------------------------------------------------
;interrupted   Allocated with name '_td_finish_interrupted_10000_604'
;slot          Allocated with name '_td_finish_slot_10000_605'
;code          Allocated with name '_td_finish_code_10000_605'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:48: static void td_finish(bool interrupted) {
;	-----------------------------------------
;	 function td_finish
;	-----------------------------------------
_td_finish:
	mov	a,dpl
	mov	dptr,#_td_finish_interrupted_10000_604
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:49: uint8_t slot = td_pending;
	mov	dptr,#_td_pending
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_td_finish_slot_10000_605
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:51: if (slot == TD_NONE) return;
	cjne	r7,#0xff,00102$
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:52: td_pending = TD_NONE;
	mov	dptr,#_td_pending
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:53: td_state[slot] |= TD_DONE;
	mov	dptr,#_td_finish_slot_10000_605
	movx	a,@dptr
	mov	r7,a
	add	a, #_td_state
	mov	r5,a
	clr	a
	addc	a, #(_td_state >> 8)
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	mov	r4,a
	orl	ar4,#0x08
	mov	dpl,r5
	mov	dph,r6
	mov	a,r4
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:54: if ((td_state[slot] & 3) == 1) {
	anl	ar4,#0x03
	cjne	r4,#0x01,00241$
	sjmp	00242$
00241$:
	ljmp	00120$
00242$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:55: code = (td_state[slot] & TD_DOWN) && !interrupted ? td_entries[slot].on_hold : td_entries[slot].on_tap;
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	rr	a
	rr	a
	anl	a,#0x01
	jz	00130$
	mov	dptr,#_td_finish_interrupted_10000_604
	movx	a,@dptr
	jnz	00130$
	mov	a,r7
	mov	b,#0x0a
	mul	ab
	add	a, #_td_entries
	mov	r3,a
	mov	a,#(_td_entries >> 8)
	addc	a, b
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	sjmp	00131$
00130$:
	mov	dptr,#_td_finish_slot_10000_605
	movx	a,@dptr
	mov	b,#0x0a
	mul	ab
	add	a, #_td_entries
	mov	dpl,a
	mov	a,#(_td_entries >> 8)
	addc	a, b
	mov	dph,a
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
00131$:
	mov	dptr,#_td_finish_code_10000_605
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:56: if (!code && (td_state[slot] & TD_DOWN) && !interrupted) code = td_entries[slot].on_tap;
	mov	a,r3
	orl	a,r4
	jz	00245$
	ljmp	00121$
00245$:
	mov	dptr,#_td_finish_slot_10000_605
	movx	a,@dptr
	mov	r4,a
	add	a, #_td_state
	mov	dpl,a
	clr	a
	addc	a, #(_td_state >> 8)
	mov	dph,a
	movx	a,@dptr
	jb	acc.2,00246$
	ljmp	00121$
00246$:
	mov	dptr,#_td_finish_interrupted_10000_604
	movx	a,@dptr
	jz	00247$
	ljmp	00121$
00247$:
	mov	a,r4
	mov	b,#0x0a
	mul	ab
	add	a, #_td_entries
	mov	dpl,a
	mov	a,#(_td_entries >> 8)
	addc	a, b
	mov	dph,a
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_td_finish_code_10000_605
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	ljmp	00121$
00120$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:57: } else if (interrupted) {
	mov	dptr,#_td_finish_interrupted_10000_604
	movx	a,@dptr
	jz	00117$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:58: td_tap(slot, td_entries[slot].on_tap);
	mov	a,r7
	mov	b,#0x0a
	mul	ab
	add	a, #_td_entries
	mov	r3,a
	mov	a,#(_td_entries >> 8)
	addc	a, b
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	mov	dptr,#_td_tap_PARM_2
	mov	a,r1
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
	mov	dpl, r7
	push	ar4
	push	ar3
	lcall	_td_tap
	pop	ar3
	pop	ar4
;	keyboards/ajazz/ak820/ak820_tap_dance.c:59: code = td_entries[slot].on_tap;
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_td_finish_code_10000_605
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	ljmp	00121$
00117$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:60: } else if (td_state[slot] & TD_DOWN) {
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	jb	acc.2,00249$
	ljmp	00114$
00249$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:61: code = td_entries[slot].on_tap_hold;
	mov	a,r7
	mov	b,#0x0a
	mul	ab
	add	a, #_td_entries
	mov	r5,a
	mov	a,#(_td_entries >> 8)
	addc	a, b
	mov	r6,a
	mov	a,#0x06
	add	a, r5
	mov	dpl,a
	clr	a
	addc	a, r6
	mov	dph,a
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_td_finish_code_10000_605
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:62: if (!code) {
	mov	a,r3
	orl	a,r4
	jz	00250$
	ljmp	00121$
00250$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:63: td_tap(slot, td_entries[slot].on_tap);
	mov	ar3,r5
	mov	ar4,r6
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	mov	dptr,#_td_tap_PARM_2
	mov	a,r1
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
	mov	dpl, r7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_td_tap
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
;	keyboards/ajazz/ak820/ak820_tap_dance.c:64: code = td_entries[slot].on_hold;
	mov	dpl,r5
	mov	dph,r6
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_td_finish_code_10000_605
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:65: if (!code) code = td_entries[slot].on_tap;
	mov	a,r5
	orl	a,r6
	jnz	00121$
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_td_finish_code_10000_605
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	sjmp	00121$
00114$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:68: code = td_entries[slot].on_double_tap;
	mov	a,r7
	mov	b,#0x0a
	mul	ab
	add	a, #_td_entries
	mov	r5,a
	mov	a,#(_td_entries >> 8)
	addc	a, b
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_td_finish_code_10000_605
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: if (!code) { td_tap(slot, td_entries[slot].on_tap); code = td_entries[slot].on_tap; }
	mov	a,r3
	orl	a,r4
	jnz	00121$
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_td_tap_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	dpl, r7
	push	ar6
	push	ar5
	lcall	_td_tap
	pop	ar5
	pop	ar6
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_td_finish_code_10000_605
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
00121$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:71: if (!td_state[slot]) return;
	mov	dptr,#_td_finish_slot_10000_605
	movx	a,@dptr
	mov	r7,a
	add	a, #_td_state
	mov	r5,a
	clr	a
	addc	a, #(_td_state >> 8)
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	jnz	00123$
	ret
00123$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:72: td_output[slot] = code;
	mov	a,r7
	mov	b,#0x02
	mul	ab
	add	a, #_td_output
	mov	r3,a
	mov	a,#(_td_output >> 8)
	addc	a, b
	mov	r4,a
	mov	dptr,#_td_finish_code_10000_605
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	mov	dpl,r3
	mov	dph,r4
	mov	a,r1
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:73: td_emit(slot, code, true);
	mov	dptr,#_td_emit_PARM_2
	mov	a,r1
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_td_emit_PARM_3
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, r7
	push	ar7
	push	ar6
	push	ar5
	push	ar2
	push	ar1
	lcall	_td_emit
	pop	ar1
	pop	ar2
	pop	ar5
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_tap_dance.c:74: if (!td_state[slot]) return;
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	mov	r4,a
	jnz	00125$
	ret
00125$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:75: if (!(td_state[slot] & TD_DOWN)) {
	mov	a,r4
	jb	acc.2,00128$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:76: td_emit(slot, code, false);
	mov	dptr,#_td_emit_PARM_2
	mov	a,r1
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_td_emit_PARM_3
	clr	a
	movx	@dptr,a
	mov	dpl, r7
	push	ar6
	push	ar5
	lcall	_td_emit
	pop	ar5
	pop	ar6
;	keyboards/ajazz/ak820/ak820_tap_dance.c:77: td_state[slot] = 0;
	mov	dpl,r5
	mov	dph,r6
	clr	a
	movx	@dptr,a
00128$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:79: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tap_dance_task'
;------------------------------------------------------------
;now           Allocated with name '_ak820_tap_dance_task_now_10000_624'
;term          Allocated with name '_ak820_tap_dance_task_term_30000_627'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:80: void ak820_tap_dance_task(uint16_t now) {
;	-----------------------------------------
;	 function ak820_tap_dance_task
;	-----------------------------------------
_ak820_tap_dance_task:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tap_dance_task_now_10000_624
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:81: if (td_pending != TD_NONE) {
	mov	dptr,#_td_pending
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00130$
	ret
00130$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:82: uint16_t term = td_entries[td_pending].custom_tapping_term;
	mov	a,r7
	mov	b,#0x0a
	mul	ab
	add	a, #_td_entries
	mov	r5,a
	mov	a,#(_td_entries >> 8)
	addc	a, b
	mov	r6,a
	mov	a,#0x08
	add	a, r5
	mov	dpl,a
	clr	a
	addc	a, r6
	mov	dph,a
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_ak820_tap_dance_task_term_30000_627
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:83: if (!term) term = 200;
	mov	a,r5
	orl	a,r6
	jnz	00102$
	mov	dptr,#_ak820_tap_dance_task_term_30000_627
	mov	a,#0xc8
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:84: if ((uint16_t)(now - td_time[td_pending]) >= term) td_finish(false);
	mov	a,r7
	mov	b,#0x02
	mul	ab
	add	a, #_td_time
	mov	dpl,a
	mov	a,#(_td_time >> 8)
	addc	a, b
	mov	dph,a
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_ak820_tap_dance_task_now_10000_624
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,r4
	clr	c
	subb	a,r6
	mov	r6,a
	mov	a,r5
	subb	a,r7
	mov	r7,a
	mov	dptr,#_ak820_tap_dance_task_term_30000_627
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	clr	c
	mov	a,r6
	subb	a,r4
	mov	a,r7
	subb	a,r5
	jc	00107$
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_tap_dance.c:86: }
	ljmp	_td_finish
00107$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tap_dance_before'
;------------------------------------------------------------
;event         Allocated with name '_ak820_tap_dance_before_event_10000_630'
;id            Allocated with name '_ak820_tap_dance_before_id_10000_631'
;i             Allocated with name '_ak820_tap_dance_before_i_20000_640'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:87: bool ak820_tap_dance_before(const keyevent_t AK820_STATE_MEM *event) {
;	-----------------------------------------
;	 function ak820_tap_dance_before
;	-----------------------------------------
_ak820_tap_dance_before:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tap_dance_before_event_10000_630
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:89: ak820_tap_dance_task(event->time);
	mov	dptr,#_ak820_tap_dance_before_event_10000_630
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	lcall	_ak820_tap_dance_task
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_tap_dance.c:90: if (IS_NOEVENT(*event)) return true;
	mov	a,#0x04
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	jnz	00102$
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:91: if (event->key.row >= MATRIX_ROWS || event->key.col >= MATRIX_COLS) {
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x10,00229$
00229$:
	jnc	00105$
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0x08,00231$
00231$:
	jc	00106$
00105$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:92: if (event->pressed) td_finish(true);
	mov	dptr,#_ak820_tap_dance_before_event_10000_630
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	a,#0x05
	add	a, r2
	mov	r2,a
	clr	a
	addc	a, r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	jz	00104$
	mov	dpl, #0x01
	lcall	_td_finish
00104$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:93: return true;
	mov	dpl, #0x01
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:95: id = event->key.row * MATRIX_COLS + event->key.col;
	mov	a,r5
	swap	a
	rr	a
	anl	a,#0xf8
;	keyboards/ajazz/ak820/ak820_tap_dance.c:96: if (td_suppressed[id >> 3] & (1u << (id & 7))) {
	add	a,r4
	mov	r5,a
	swap	a
	rl	a
	anl	a,#0x1f
	add	a, #_td_suppressed
	mov	dpl,a
	clr	a
	addc	a, #(_td_suppressed >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	mov	a,#0x07
	anl	a,r5
	mov	b, a
	inc	b
	mov	r3,#0x01
	mov	r2,#0x00
	sjmp	00235$
00234$:
	mov	a,r3
	add	a,r3
	mov	r3,a
	mov	a,r2
	rlc	a
	mov	r2,a
00235$:
	djnz	b,00234$
	mov	ar1,r4
	mov	r4,#0x00
	mov	a,r1
	anl	ar3,a
	mov	a,r4
	anl	ar2,a
	mov	a,r3
	orl	a,r2
	jz	00111$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:97: if (!event->pressed) td_suppressed[id >> 3] &= ~(1u << (id & 7));
	mov	a,#0x05
	add	a, r6
	mov	r3,a
	clr	a
	addc	a, r7
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	jnz	00109$
	mov	ar4,r5
	mov	a,r4
	swap	a
	rl	a
	anl	a,#0x1f
	add	a,#_td_suppressed
	mov	r4,a
	clr	a
	addc	a, #(_td_suppressed >> 8)
	mov	r3,a
	mov	ar2,r5
	mov	a,r2
	swap	a
	rl	a
	anl	a,#0x1f
	add	a, #_td_suppressed
	mov	dpl,a
	clr	a
	addc	a, #(_td_suppressed >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r2,a
	mov	a,#0x07
	anl	a,r5
	mov	b,a
	inc	b
	mov	a,#0x01
	sjmp	00239$
00238$:
	add	a,acc
00239$:
	djnz	b,00238$
	cpl	a
	anl	ar2,a
	mov	dpl,r4
	mov	dph,r3
	mov	a,r2
	movx	@dptr,a
00109$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:98: return false;
	mov	dpl, #0x00
	ret
00111$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:100: if (event->pressed && td_pending != TD_NONE &&
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00157$
	mov	dptr,#_td_pending
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00241$
	sjmp	00157$
00241$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:101: (td_source[td_pending] != id || (td_state[td_pending] & 3) == 2)) td_finish(true);
	mov	a,r7
	add	a, #_td_source
	mov	dpl,a
	clr	a
	addc	a, #(_td_source >> 8)
	mov	dph,a
	movx	a,@dptr
	cjne	a,ar5,00112$
	mov	a,r7
	add	a, #_td_state
	mov	dpl,a
	clr	a
	addc	a, #(_td_state >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r7,a
	anl	ar7,#0x03
	cjne	r7,#0x02,00157$
00112$:
	mov	dpl, #0x01
	push	ar5
	lcall	_td_finish
	pop	ar5
;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
00157$:
	mov	r7,#0x00
00127$:
	cjne	r7,#0x08,00246$
00246$:
	jc	00247$
	ljmp	00125$
00247$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:103: if (!td_state[i] || td_source[i] != id) continue;
	mov	a,r7
	add	a, #_td_state
	mov	r4,a
	clr	a
	addc	a, #(_td_state >> 8)
	mov	r6,a
	mov	dpl,r4
	mov	dph,r6
	movx	a,@dptr
	mov	r3,a
	jz	00124$
	mov	a,r7
	add	a, #_td_source
	mov	dpl,a
	clr	a
	addc	a, #(_td_source >> 8)
	mov	dph,a
	movx	a,@dptr
	cjne	a,ar5,00124$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:104: if (event->pressed) return !(td_state[i] & TD_DONE);
	mov	dptr,#_ak820_tap_dance_before_event_10000_630
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	mov	a,#0x05
	add	a, r1
	mov	r1,a
	clr	a
	addc	a, r2
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	movx	a,@dptr
	jz	00121$
	mov	a,r3
	mov	c,acc.3
	clr	a
	rlc	a
	cjne	a,#0x01,00252$
00252$:
	mov  _ak820_tap_dance_before_sloc0_1_0,c
	clr	a
	rlc	a
	mov	dpl, a
	ret
00121$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:105: td_state[i] &= ~TD_DOWN;
	anl	ar3,#0xfb
	mov	dpl,r4
	mov	dph,r6
	mov	a,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:106: if (td_state[i] & TD_DONE) {
	mov	a,r3
	jnb	acc.3,00123$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:107: td_emit(i, td_output[i], false);
	mov	a,r7
	mov	b,#0x02
	mul	ab
	add	a, #_td_output
	mov	dpl,a
	mov	a,#(_td_output >> 8)
	addc	a, b
	mov	dph,a
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_td_emit_PARM_2
	mov	a,r2
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_td_emit_PARM_3
	clr	a
	movx	@dptr,a
	mov	dpl, r7
	push	ar6
	push	ar4
	lcall	_td_emit
	pop	ar4
	pop	ar6
;	keyboards/ajazz/ak820/ak820_tap_dance.c:108: td_state[i] = 0;
	mov	dpl,r4
	mov	dph,r6
	clr	a
	movx	@dptr,a
00123$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:110: return false;
	mov	dpl, #0x00
	ret
00124$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
	inc	r7
	ljmp	00127$
00125$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:112: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_tap_dance.c:113: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tap_dance_process'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_tap_dance_process_sloc0_1_0'
;record        Allocated with name '_ak820_tap_dance_process_record_10000_646'
;slot          Allocated with name '_ak820_tap_dance_process_slot_10000_647'
;id            Allocated with name '_ak820_tap_dance_process_id_10000_647'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:114: bool ak820_tap_dance_process(keyrecord_t AK820_STATE_MEM *record) {
;	-----------------------------------------
;	 function ak820_tap_dance_process
;	-----------------------------------------
_ak820_tap_dance_process:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tap_dance_process_record_10000_646
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:118: if (record->event.type == KEY_EVENT && record->event.key.row < MATRIX_ROWS &&
	mov	dptr,#_ak820_tap_dance_process_record_10000_646
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x01,00258$
	sjmp	00259$
00258$:
	ljmp	00102$
00259$:
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x10,00260$
00260$:
	jc	00261$
	ljmp	00102$
00261$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:119: record->event.key.col < MATRIX_COLS && record->event.pressed && td_pending != TD_NONE &&
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0x08,00262$
00262$:
	jnc	00102$
	mov	a,#0x05
	add	a, r6
	mov	r2,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	jz	00102$
	mov	dptr,#_td_pending
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0xff,00265$
	sjmp	00102$
00265$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:120: !(td_state[td_pending] & TD_DOWN) &&
	mov	a,r3
	add	a, #_td_state
	mov	dpl,a
	clr	a
	addc	a, #(_td_state >> 8)
	mov	dph,a
	movx	a,@dptr
	jb	acc.2,00102$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:121: td_source[td_pending] == record->event.key.row * MATRIX_COLS + record->event.key.col &&
	mov	a,r3
	add	a, #_td_source
	mov	dpl,a
	clr	a
	addc	a, #(_td_source >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r2,a
	mov	ar1,r5
	clr	a
	rr	a
	anl	a,#0xf8
	xch	a,r1
	swap	a
	rr	a
	xch	a,r1
	xrl	a,r1
	xch	a,r1
	anl	a,#0xf8
	xch	a,r1
	xrl	a,r1
	mov	r5,a
	mov	ar0,r4
	mov	r4,#0x00
	mov	a,r0
	add	a, r1
	mov	r1,a
	mov	a,r4
	addc	a, r5
	mov	r5,a
	mov	a,r2
	cjne	a,ar1,00102$
	mov	a,r4
	cjne	a,ar5,00102$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:122: record->keycode != QK_TAP_DANCE + td_pending) td_finish(true);
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	r5,#0x00
	mov	a,#0x57
	add	a, r5
	mov	r5,a
	mov	a,r6
	cjne	a,ar3,00269$
	mov	a,r7
	cjne	a,ar5,00269$
	sjmp	00102$
00269$:
	mov	dpl, #0x01
	lcall	_td_finish
00102$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:123: if (record->keycode < QK_TAP_DANCE || record->keycode > QK_TAP_DANCE_MAX) return true;
	mov	dptr,#_ak820_tap_dance_process_record_10000_646
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x07
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	clr	c
	subb	a,#0x57
	jc	00110$
	mov	a,#0xff
	subb	a,r2
	mov	a,#0x57
	subb	a,r3
	jnc	00111$
;	free result
00110$:
	mov	dpl, #0x01
	ret
00111$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:125: if (record->event.type != KEY_EVENT || record->event.key.row >= MATRIX_ROWS ||
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x01,00113$
	mov	a,#0x01
	add	a, r6
	mov	r2,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	mov	r1,a
	cjne	r1,#0x10,00274$
00274$:
	jnc	00113$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:126: record->event.key.col >= MATRIX_COLS || get_repeat_key_count() || ak820_macro_primitive) return false;
	push	ar2
	push	ar3
	mov	ar0,r6
	mov	ar1,r7
	mov	dpl,r0
	mov	dph,r1
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x08,00276$
00276$:
	pop	ar3
	pop	ar2
	jnc	00113$
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_get_repeat_key_count
	mov	a, dpl
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00113$
	mov	dptr,#_ak820_macro_primitive
	movx	a,@dptr
	jz	00114$
00113$:
	mov	dpl, #0x00
	ret
00114$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:127: if (!record->event.pressed) return false;
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jnz	00120$
	mov	dpl,a
	ret
00120$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:128: slot = (uint8_t)record->keycode;
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:129: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	swap	a
	rr	a
	anl	a,#0xf8
	mov	r2,a
	mov	dpl,r0
	mov	dph,r1
	movx	a,@dptr
	add	a, r2
	mov	r6,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:130: if (slot >= VIAL_TAP_DANCE_ENTRIES || (td_state[slot] && td_source[slot] != id)) {
	cjne	r7,#0x08,00281$
00281$:
	jnc	00121$
	mov	a,r7
	add	a, #_td_state
	mov	r4,a
	clr	a
	addc	a, #(_td_state >> 8)
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r3,a
	jz	00122$
	mov	a,r7
	add	a, #_td_source
	mov	dpl,a
	clr	a
	addc	a, #(_td_source >> 8)
	mov	dph,a
	movx	a,@dptr
	cjne	a,ar6,00284$
	sjmp	00122$
00284$:
00121$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:131: td_suppressed[id >> 3] |= 1u << (id & 7);
	mov	ar2,r6
	mov	a,r2
	swap	a
	rl	a
	anl	a,#0x1f
	add	a, #_td_suppressed
	mov	r1,a
	clr	a
	addc	a, #(_td_suppressed >> 8)
	mov	r2,a
	mov	ar0,r6
	mov	a,r0
	swap	a
	rl	a
	anl	a,#0x1f
	add	a, #_td_suppressed
	mov	dpl,a
	clr	a
	addc	a, #(_td_suppressed >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	_ak820_tap_dance_process_sloc0_1_0,a
	mov	a,#0x07
	anl	a,r6
	mov	b,a
	inc	b
	mov	a,#0x01
	sjmp	00286$
00285$:
	add	a,acc
00286$:
	djnz	b,00285$
	mov	r0,a
	mov	a,_ak820_tap_dance_process_sloc0_1_0
	orl	ar0,a
	mov	dpl,r1
	mov	dph,r2
	mov	a,r0
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:132: return false;
	mov	dpl, #0x00
	ret
00122$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:134: if (!td_state[slot]) {
	mov	a,r3
	jz	00287$
	ljmp	00129$
00287$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:135: if (dynamic_keymap_get_tap_dance(slot, &td_entries[slot]) || !ak820_tap_dance_valid(&td_entries[slot])) {
	mov	a,r7
	mov	b,#0x0a
	mul	ab
	add	a, #_td_entries
	mov	r2,a
	mov	a,#(_td_entries >> 8)
	addc	a, b
	mov	r3,a
	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
	mov	a,r2
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r7
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_dynamic_keymap_get_tap_dance
	mov	a, dpl
	mov	b, dph
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	orl	a,b
	jnz	00125$
	mov	dpl, r2
	mov	dph, r3
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_ak820_tap_dance_valid
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00126$
00125$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:136: td_suppressed[id >> 3] |= 1u << (id & 7);
	mov	ar3,r6
	mov	a,r3
	swap	a
	rl	a
	anl	a,#0x1f
	add	a,#_td_suppressed
	mov	r3,a
	clr	a
	addc	a, #(_td_suppressed >> 8)
	mov	r2,a
	mov	ar1,r6
	mov	a,r1
	swap	a
	rl	a
	anl	a,#0x1f
	add	a, #_td_suppressed
	mov	dpl,a
	clr	a
	addc	a, #(_td_suppressed >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r1,a
	mov	a,#0x07
	anl	a,r6
	mov	b,a
	inc	b
	mov	a,#0x01
	sjmp	00291$
00290$:
	add	a,acc
00291$:
	djnz	b,00290$
	orl	ar1,a
	mov	dpl,r3
	mov	dph,r2
	mov	a,r1
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:137: return false;
	mov	dpl, #0x00
	ret
00126$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:139: td_source[slot] = id;
	mov	a,r7
	add	a, #_td_source
	mov	dpl,a
	clr	a
	addc	a, #(_td_source >> 8)
	mov	dph,a
	mov	a,r6
	movx	@dptr,a
00129$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:141: td_state[slot] = (td_state[slot] & 3) + 1 + TD_DOWN;
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r6,a
	mov	a,#0x03
	anl	a,r6
	add	a, #0x05
	mov	dpl,r4
	mov	dph,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:142: td_time[slot] = record->event.time;
	mov	a,r7
	mov	b,#0x02
	mul	ab
	add	a, #_td_time
	mov	r5,a
	mov	a,#(_td_time >> 8)
	addc	a, b
	mov	r6,a
	mov	dptr,#_ak820_tap_dance_process_record_10000_646
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dpl,r5
	mov	dph,r6
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:143: td_pending = slot;
	mov	dptr,#_td_pending
	mov	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:144: return false;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_tap_dance.c:145: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tap_dance_cancel'
;------------------------------------------------------------
;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_660'
;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_661'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:146: void ak820_tap_dance_cancel(void) {
;	-----------------------------------------
;	 function ak820_tap_dance_cancel
;	-----------------------------------------
_ak820_tap_dance_cancel:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:147: td_pending = TD_NONE;
	mov	dptr,#_td_pending
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:148: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) td_state[i] = 0;
	mov	r7,#0x00
00104$:
	cjne	r7,#0x08,00141$
00141$:
	jnc	00101$
	mov	a,r7
	add	a, #_td_state
	mov	dpl,a
	clr	a
	addc	a, #(_td_state >> 8)
	mov	dph,a
	clr	a
	movx	@dptr,a
	inc	r7
	sjmp	00104$
00101$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:149: for (uint8_t i = 0; i < sizeof(td_suppressed); ++i) td_suppressed[i] = 0;
	mov	r7,#0x00
00107$:
	cjne	r7,#0x10,00143$
00143$:
	jnc	00109$
	mov	a,r7
	add	a, #_td_suppressed
	mov	dpl,a
	clr	a
	addc	a, #(_td_suppressed >> 8)
	mov	dph,a
	clr	a
	movx	@dptr,a
	inc	r7
	sjmp	00107$
00109$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:150: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__td_pending:
	.db #0xff	; 255
	.area CABS    (ABS,CODE)
