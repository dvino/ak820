                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_macro
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_update_byte
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_nvm_end
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_begin
                                     17 	.globl _ak820_nvm_ok
                                     18 	.globl _ak820_macro_write_PARM_3
                                     19 	.globl _ak820_macro_write_PARM_2
                                     20 	.globl _ak820_macro_init
                                     21 	.globl _ak820_macro_ready
                                     22 	.globl _ak820_macro_length
                                     23 	.globl _ak820_macro_write
                                     24 	.globl _ak820_macro_reset
                                     25 ;--------------------------------------------------------
                                     26 ; special function registers
                                     27 ;--------------------------------------------------------
                                     28 	.area RSEG    (ABS,DATA)
      000000                         29 	.org 0x0000
                                     30 ;--------------------------------------------------------
                                     31 ; special function bits
                                     32 ;--------------------------------------------------------
                                     33 	.area RSEG    (ABS,DATA)
      000000                         34 	.org 0x0000
                                     35 ;--------------------------------------------------------
                                     36 ; overlayable register banks
                                     37 ;--------------------------------------------------------
                                     38 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         39 	.ds 8
                                     40 ;--------------------------------------------------------
                                     41 ; internal ram data
                                     42 ;--------------------------------------------------------
                                     43 	.area DSEG    (DATA)
      000018                         44 _ak820_macro_write_sloc0_1_0:
      000018                         45 	.ds 2
                                     46 ;--------------------------------------------------------
                                     47 ; overlayable items in internal ram
                                     48 ;--------------------------------------------------------
                                     49 	.area	OSEG    (OVR,DATA)
      000064                         50 _parse_byte_sloc1_1_0:
      000064                         51 	.ds 2
                                     52 ;--------------------------------------------------------
                                     53 ; indirectly addressable internal ram data
                                     54 ;--------------------------------------------------------
                                     55 	.area ISEG    (DATA)
                                     56 ;--------------------------------------------------------
                                     57 ; absolute internal ram data
                                     58 ;--------------------------------------------------------
                                     59 	.area IABS    (ABS,DATA)
                                     60 	.area IABS    (ABS,DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; bit data
                                     63 ;--------------------------------------------------------
                                     64 	.area BSEG    (BIT)
      000009                         65 _uploading:
      000009                         66 	.ds 1
      00000A                         67 _parse_byte_sloc0_1_0:
      00000A                         68 	.ds 1
      00000B                         69 _ak820_macro_ready_sloc0_1_0:
      00000B                         70 	.ds 1
                                     71 ;--------------------------------------------------------
                                     72 ; paged external ram data
                                     73 ;--------------------------------------------------------
                                     74 	.area PSEG    (PAG,XDATA)
                                     75 ;--------------------------------------------------------
                                     76 ; uninitialized external ram data
                                     77 ;--------------------------------------------------------
                                     78 	.area XSEG    (XDATA)
      00056B                         79 _parsed:
      00056B                         80 	.ds 2
      00056D                         81 _covered:
      00056D                         82 	.ds 2
      00056F                         83 _used_length:
      00056F                         84 	.ds 2
      000571                         85 _macro_byte_offset_10000_67:
      000571                         86 	.ds 2
      000573                         87 _busy_write_value_10000_69:
      000573                         88 	.ds 1
      000574                         89 _commit_length_length_10000_71:
      000574                         90 	.ds 2
      000576                         91 _commit_length_metadata_10000_72:
      000576                         92 	.ds 3
      000579                         93 _parse_byte_PARM_2:
      000579                         94 	.ds 1
      00057A                         95 _parse_byte_state_10000_74:
      00057A                         96 	.ds 2
      00057C                         97 _matches_PARM_2:
      00057C                         98 	.ds 2
      00057E                         99 _matches_PARM_3:
      00057E                        100 	.ds 2
      000580                        101 _matches_offset_10000_89:
      000580                        102 	.ds 2
      000582                        103 _ak820_macro_write_PARM_2:
      000582                        104 	.ds 2
      000584                        105 _ak820_macro_write_PARM_3:
      000584                        106 	.ds 3
      000587                        107 _ak820_macro_write_offset_10000_99:
      000587                        108 	.ds 2
      000589                        109 _ak820_macro_write_next_10000_100:
      000589                        110 	.ds 2
                                    111 ;--------------------------------------------------------
                                    112 ; absolute external ram data
                                    113 ;--------------------------------------------------------
                                    114 	.area XABS    (ABS,XDATA)
                                    115 ;--------------------------------------------------------
                                    116 ; initialized external ram data
                                    117 ;--------------------------------------------------------
                                    118 	.area XISEG   (XDATA)
                                    119 	.area HOME    (CODE)
                                    120 	.area GSINIT0 (CODE)
                                    121 	.area GSINIT1 (CODE)
                                    122 	.area GSINIT2 (CODE)
                                    123 	.area GSINIT3 (CODE)
                                    124 	.area GSINIT4 (CODE)
                                    125 	.area GSINIT5 (CODE)
                                    126 	.area GSINIT  (CODE)
                                    127 	.area GSFINAL (CODE)
                                    128 	.area CSEG    (CODE)
                                    129 ;--------------------------------------------------------
                                    130 ; global & static initialisations
                                    131 ;--------------------------------------------------------
                                    132 	.area HOME    (CODE)
                                    133 	.area GSINIT  (CODE)
                                    134 	.area GSFINAL (CODE)
                                    135 	.area GSINIT  (CODE)
                                    136 ;--------------------------------------------------------
                                    137 ; Home
                                    138 ;--------------------------------------------------------
                                    139 	.area HOME    (CODE)
                                    140 	.area HOME    (CODE)
                                    141 ;--------------------------------------------------------
                                    142 ; code
                                    143 ;--------------------------------------------------------
                                    144 	.area AK820LOW(CODE)
                                    145 ;------------------------------------------------------------
                                    146 ;Allocation info for local variables in function 'macro_byte'
                                    147 ;------------------------------------------------------------
                                    148 ;offset        Allocated with name '_macro_byte_offset_10000_67'
                                    149 ;------------------------------------------------------------
                                    150 ;	keyboards/ajazz/ak820/ak820_macro.c:40: static uint8_t macro_byte(uint16_t offset) {
                                    151 ;	-----------------------------------------
                                    152 ;	 function macro_byte
                                    153 ;	-----------------------------------------
      0028EC                        154 _macro_byte:
                           000007   155 	ar7 = 0x07
                           000006   156 	ar6 = 0x06
                           000005   157 	ar5 = 0x05
                           000004   158 	ar4 = 0x04
                           000003   159 	ar3 = 0x03
                           000002   160 	ar2 = 0x02
                           000001   161 	ar1 = 0x01
                           000000   162 	ar0 = 0x00
      0028EC AF 83            [24]  163 	mov	r7,dph
      0028EE E5 82            [12]  164 	mov	a,dpl
      0028F0 90 05 71         [24]  165 	mov	dptr,#_macro_byte_offset_10000_67
      0028F3 F0               [24]  166 	movx	@dptr,a
      0028F4 EF               [12]  167 	mov	a,r7
      0028F5 A3               [24]  168 	inc	dptr
      0028F6 F0               [24]  169 	movx	@dptr,a
                                    170 ;	keyboards/ajazz/ak820/ak820_macro.c:41: return eeprom_read_byte((const uint8_t *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + offset));
      0028F7 90 05 71         [24]  171 	mov	dptr,#_macro_byte_offset_10000_67
      0028FA E0               [24]  172 	movx	a,@dptr
      0028FB FE               [12]  173 	mov	r6,a
      0028FC A3               [24]  174 	inc	dptr
      0028FD E0               [24]  175 	movx	a,@dptr
      0028FE 24 08            [12]  176 	add	a,#0x08
      002900 FF               [12]  177 	mov	r7,a
      002901 7D 00            [12]  178 	mov	r5,#0x00
      002903 8E 82            [24]  179 	mov	dpl, r6
      002905 8F 83            [24]  180 	mov	dph, r7
      002907 8D F0            [24]  181 	mov	b, r5
                                    182 ;	keyboards/ajazz/ak820/ak820_macro.c:42: }
      002909 02 47 36         [24]  183 	ljmp	_eeprom_read_byte
                                    184 ;------------------------------------------------------------
                                    185 ;Allocation info for local variables in function 'busy_write'
                                    186 ;------------------------------------------------------------
                                    187 ;value         Allocated with name '_busy_write_value_10000_69'
                                    188 ;------------------------------------------------------------
                                    189 ;	keyboards/ajazz/ak820/ak820_macro.c:44: static void busy_write(uint8_t value) {
                                    190 ;	-----------------------------------------
                                    191 ;	 function busy_write
                                    192 ;	-----------------------------------------
      00290C                        193 _busy_write:
      00290C E5 82            [12]  194 	mov	a,dpl
      00290E 90 05 73         [24]  195 	mov	dptr,#_busy_write_value_10000_69
      002911 F0               [24]  196 	movx	@dptr,a
                                    197 ;	keyboards/ajazz/ak820/ak820_macro.c:45: eeprom_update_byte((uint8_t *)(uintptr_t)AK820_MACRO_BUSY_ADDR, value);
      002912 E0               [24]  198 	movx	a,@dptr
      002913 90 07 09         [24]  199 	mov	dptr,#_eeprom_update_byte_PARM_2
      002916 F0               [24]  200 	movx	@dptr,a
      002917 90 07 F0         [24]  201 	mov	dptr,#0x07f0
      00291A 75 F0 00         [24]  202 	mov	b, #0x00
      00291D 12 54 9B         [24]  203 	lcall	_eeprom_update_byte
                                    204 ;	keyboards/ajazz/ak820/ak820_macro.c:46: ak820_nvm_flush();
                                    205 ;	keyboards/ajazz/ak820/ak820_macro.c:47: }
      002920 02 44 EB         [24]  206 	ljmp	_ak820_nvm_flush
                                    207 ;------------------------------------------------------------
                                    208 ;Allocation info for local variables in function 'commit_length'
                                    209 ;------------------------------------------------------------
                                    210 ;length        Allocated with name '_commit_length_length_10000_71'
                                    211 ;metadata      Allocated with name '_commit_length_metadata_10000_72'
                                    212 ;------------------------------------------------------------
                                    213 ;	keyboards/ajazz/ak820/ak820_macro.c:49: static void commit_length(uint16_t length) {
                                    214 ;	-----------------------------------------
                                    215 ;	 function commit_length
                                    216 ;	-----------------------------------------
      002923                        217 _commit_length:
      002923 AF 83            [24]  218 	mov	r7,dph
      002925 E5 82            [12]  219 	mov	a,dpl
      002927 90 05 74         [24]  220 	mov	dptr,#_commit_length_length_10000_71
      00292A F0               [24]  221 	movx	@dptr,a
      00292B EF               [12]  222 	mov	a,r7
      00292C A3               [24]  223 	inc	dptr
      00292D F0               [24]  224 	movx	@dptr,a
                                    225 ;	keyboards/ajazz/ak820/ak820_macro.c:51: metadata[0] = 0;
      00292E 90 05 76         [24]  226 	mov	dptr,#_commit_length_metadata_10000_72
      002931 E4               [12]  227 	clr	a
      002932 F0               [24]  228 	movx	@dptr,a
                                    229 ;	keyboards/ajazz/ak820/ak820_macro.c:52: metadata[1] = (uint8_t)length;
      002933 90 05 74         [24]  230 	mov	dptr,#_commit_length_length_10000_71
      002936 E0               [24]  231 	movx	a,@dptr
      002937 FE               [12]  232 	mov	r6,a
      002938 A3               [24]  233 	inc	dptr
      002939 E0               [24]  234 	movx	a,@dptr
      00293A FF               [12]  235 	mov	r7,a
      00293B 8E 05            [24]  236 	mov	ar5,r6
      00293D 90 05 77         [24]  237 	mov	dptr,#(_commit_length_metadata_10000_72 + 0x0001)
      002940 ED               [12]  238 	mov	a,r5
      002941 F0               [24]  239 	movx	@dptr,a
                                    240 ;	keyboards/ajazz/ak820/ak820_macro.c:53: metadata[2] = (uint8_t)(length >> 8);
      002942 8F 05            [24]  241 	mov	ar5,r7
      002944 90 05 78         [24]  242 	mov	dptr,#(_commit_length_metadata_10000_72 + 0x0002)
      002947 ED               [12]  243 	mov	a,r5
      002948 F0               [24]  244 	movx	@dptr,a
                                    245 ;	keyboards/ajazz/ak820/ak820_macro.c:54: ak820_eeprom_write_block_xdata(metadata, (void *)(uintptr_t)AK820_MACRO_BUSY_ADDR, sizeof(metadata));
      002949 90 05 FC         [24]  246 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00294C 74 F0            [12]  247 	mov	a,#0xf0
      00294E F0               [24]  248 	movx	@dptr,a
      00294F 74 07            [12]  249 	mov	a,#0x07
      002951 A3               [24]  250 	inc	dptr
      002952 F0               [24]  251 	movx	@dptr,a
      002953 E4               [12]  252 	clr	a
      002954 A3               [24]  253 	inc	dptr
      002955 F0               [24]  254 	movx	@dptr,a
      002956 90 05 FF         [24]  255 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      002959 74 03            [12]  256 	mov	a,#0x03
      00295B F0               [24]  257 	movx	@dptr,a
      00295C E4               [12]  258 	clr	a
      00295D A3               [24]  259 	inc	dptr
      00295E F0               [24]  260 	movx	@dptr,a
      00295F 90 05 76         [24]  261 	mov	dptr,#_commit_length_metadata_10000_72
      002962 C0 07            [24]  262 	push	ar7
      002964 C0 06            [24]  263 	push	ar6
      002966 12 47 FD         [24]  264 	lcall	_ak820_eeprom_write_block_xdata
                                    265 ;	keyboards/ajazz/ak820/ak820_macro.c:55: ak820_nvm_flush();
      002969 12 44 EB         [24]  266 	lcall	_ak820_nvm_flush
      00296C D0 06            [24]  267 	pop	ar6
      00296E D0 07            [24]  268 	pop	ar7
                                    269 ;	keyboards/ajazz/ak820/ak820_macro.c:56: if (ak820_nvm_ok()) used_length = length;
      002970 12 44 DC         [24]  270 	lcall	_ak820_nvm_ok
      002973 E5 82            [12]  271 	mov	a, dpl
      002975 60 08            [24]  272 	jz	00103$
      002977 90 05 6F         [24]  273 	mov	dptr,#_used_length
      00297A EE               [12]  274 	mov	a,r6
      00297B F0               [24]  275 	movx	@dptr,a
      00297C EF               [12]  276 	mov	a,r7
      00297D A3               [24]  277 	inc	dptr
      00297E F0               [24]  278 	movx	@dptr,a
      00297F                        279 00103$:
                                    280 ;	keyboards/ajazz/ak820/ak820_macro.c:57: }
      00297F 22               [24]  281 	ret
                                    282 ;------------------------------------------------------------
                                    283 ;Allocation info for local variables in function 'parse_byte'
                                    284 ;------------------------------------------------------------
                                    285 ;value         Allocated with name '_parse_byte_PARM_2'
                                    286 ;state         Allocated with name '_parse_byte_state_10000_74'
                                    287 ;sloc1         Allocated with name '_parse_byte_sloc1_1_0'
                                    288 ;------------------------------------------------------------
                                    289 ;	keyboards/ajazz/ak820/ak820_macro.c:61: static bool parse_byte(macro_parse_t AK820_XDATA *state, uint8_t value) {
                                    290 ;	-----------------------------------------
                                    291 ;	 function parse_byte
                                    292 ;	-----------------------------------------
      002980                        293 _parse_byte:
      002980 AF 83            [24]  294 	mov	r7,dph
      002982 E5 82            [12]  295 	mov	a,dpl
      002984 90 05 7A         [24]  296 	mov	dptr,#_parse_byte_state_10000_74
      002987 F0               [24]  297 	movx	@dptr,a
      002988 EF               [12]  298 	mov	a,r7
      002989 A3               [24]  299 	inc	dptr
      00298A F0               [24]  300 	movx	@dptr,a
                                    301 ;	keyboards/ajazz/ak820/ak820_macro.c:62: if (state->terminated == DYNAMIC_KEYMAP_MACRO_COUNT) return value == 0;
      00298B 90 05 7A         [24]  302 	mov	dptr,#_parse_byte_state_10000_74
      00298E E0               [24]  303 	movx	a,@dptr
      00298F FE               [12]  304 	mov	r6,a
      002990 A3               [24]  305 	inc	dptr
      002991 E0               [24]  306 	movx	a,@dptr
      002992 FF               [12]  307 	mov	r7,a
      002993 8E 04            [24]  308 	mov	ar4,r6
      002995 8F 05            [24]  309 	mov	ar5,r7
      002997 8C 82            [24]  310 	mov	dpl,r4
      002999 8D 83            [24]  311 	mov	dph,r5
      00299B E0               [24]  312 	movx	a,@dptr
      00299C FB               [12]  313 	mov	r3,a
      00299D BB 10 0E         [24]  314 	cjne	r3,#0x10,00102$
      0029A0 90 05 79         [24]  315 	mov	dptr,#_parse_byte_PARM_2
      0029A3 E0               [24]  316 	movx	a,@dptr
      0029A4 B4 01 00         [24]  317 	cjne	a,#0x01,00191$
      0029A7                        318 00191$:
      0029A7 92 0A            [24]  319 	mov  _parse_byte_sloc0_1_0,c
      0029A9 E4               [12]  320 	clr	a
      0029AA 33               [12]  321 	rlc	a
      0029AB F5 82            [12]  322 	mov	dpl, a
      0029AD 22               [24]  323 	ret
      0029AE                        324 00102$:
                                    325 ;	keyboards/ajazz/ak820/ak820_macro.c:63: if (state->arguments == 3) {
      0029AE 0E               [12]  326 	inc	r6
      0029AF BE 00 01         [24]  327 	cjne	r6,#0x00,00192$
      0029B2 0F               [12]  328 	inc	r7
      0029B3                        329 00192$:
      0029B3 8E 82            [24]  330 	mov	dpl,r6
      0029B5 8F 83            [24]  331 	mov	dph,r7
      0029B7 E0               [24]  332 	movx	a,@dptr
      0029B8 FA               [12]  333 	mov	r2,a
      0029B9 BA 03 2C         [24]  334 	cjne	r2,#0x03,00120$
                                    335 ;	keyboards/ajazz/ak820/ak820_macro.c:64: if (value < 1 || value > 7) return false;
      0029BC 90 05 79         [24]  336 	mov	dptr,#_parse_byte_PARM_2
      0029BF E0               [24]  337 	movx	a,@dptr
      0029C0 F9               [12]  338 	mov	r1,a
      0029C1 B9 01 00         [24]  339 	cjne	r1,#0x01,00195$
      0029C4                        340 00195$:
      0029C4 40 05            [24]  341 	jc	00103$
      0029C6 E9               [12]  342 	mov	a,r1
      0029C7 24 F8            [12]  343 	add	a,#0xff - 0x07
      0029C9 50 04            [24]  344 	jnc	00104$
                                    345 ;	free result
      0029CB                        346 00103$:
      0029CB 75 82 00         [24]  347 	mov	dpl, #0x00
      0029CE 22               [24]  348 	ret
      0029CF                        349 00104$:
                                    350 ;	keyboards/ajazz/ak820/ak820_macro.c:65: state->arguments = value <= 3 ? 1 : 2;
      0029CF 8E 64            [24]  351 	mov	_parse_byte_sloc1_1_0,r6
      0029D1 8F 65            [24]  352 	mov	(_parse_byte_sloc1_1_0 + 1),r7
      0029D3 E9               [12]  353 	mov	a,r1
      0029D4 24 FC            [12]  354 	add	a,#0xff - 0x03
      0029D6 40 04            [24]  355 	jc	00124$
                                    356 ;	free result
      0029D8 79 01            [12]  357 	mov	r1,#0x01
      0029DA 80 02            [24]  358 	sjmp	00125$
      0029DC                        359 00124$:
      0029DC 79 02            [12]  360 	mov	r1,#0x02
      0029DE                        361 00125$:
      0029DE 85 64 82         [24]  362 	mov	dpl,_parse_byte_sloc1_1_0
      0029E1 85 65 83         [24]  363 	mov	dph,(_parse_byte_sloc1_1_0 + 1)
      0029E4 E9               [12]  364 	mov	a,r1
      0029E5 F0               [24]  365 	movx	@dptr,a
      0029E6 80 3A            [24]  366 	sjmp	00121$
      0029E8                        367 00120$:
                                    368 ;	keyboards/ajazz/ak820/ak820_macro.c:66: } else if (state->arguments) {
      0029E8 EA               [12]  369 	mov	a,r2
      0029E9 60 12            [24]  370 	jz	00117$
                                    371 ;	keyboards/ajazz/ak820/ak820_macro.c:67: if (!value) return false;
      0029EB 90 05 79         [24]  372 	mov	dptr,#_parse_byte_PARM_2
      0029EE E0               [24]  373 	movx	a,@dptr
      0029EF 70 03            [24]  374 	jnz	00107$
      0029F1 F5 82            [12]  375 	mov	dpl,a
      0029F3 22               [24]  376 	ret
      0029F4                        377 00107$:
                                    378 ;	keyboards/ajazz/ak820/ak820_macro.c:68: --state->arguments;
      0029F4 1A               [12]  379 	dec	r2
      0029F5 8E 82            [24]  380 	mov	dpl,r6
      0029F7 8F 83            [24]  381 	mov	dph,r7
      0029F9 EA               [12]  382 	mov	a,r2
      0029FA F0               [24]  383 	movx	@dptr,a
      0029FB 80 25            [24]  384 	sjmp	00121$
      0029FD                        385 00117$:
                                    386 ;	keyboards/ajazz/ak820/ak820_macro.c:69: } else if (!value) {
      0029FD 90 05 79         [24]  387 	mov	dptr,#_parse_byte_PARM_2
      002A00 E0               [24]  388 	movx	a,@dptr
      002A01 FA               [12]  389 	mov	r2,a
      002A02 70 09            [24]  390 	jnz	00114$
                                    391 ;	keyboards/ajazz/ak820/ak820_macro.c:70: ++state->terminated;
      002A04 0B               [12]  392 	inc	r3
      002A05 8C 82            [24]  393 	mov	dpl,r4
      002A07 8D 83            [24]  394 	mov	dph,r5
      002A09 EB               [12]  395 	mov	a,r3
      002A0A F0               [24]  396 	movx	@dptr,a
      002A0B 80 15            [24]  397 	sjmp	00121$
      002A0D                        398 00114$:
                                    399 ;	keyboards/ajazz/ak820/ak820_macro.c:71: } else if (value == 1) {
      002A0D BA 01 09         [24]  400 	cjne	r2,#0x01,00111$
                                    401 ;	keyboards/ajazz/ak820/ak820_macro.c:72: state->arguments = 3;
      002A10 8E 82            [24]  402 	mov	dpl,r6
      002A12 8F 83            [24]  403 	mov	dph,r7
      002A14 74 03            [12]  404 	mov	a,#0x03
      002A16 F0               [24]  405 	movx	@dptr,a
      002A17 80 09            [24]  406 	sjmp	00121$
      002A19                        407 00111$:
                                    408 ;	keyboards/ajazz/ak820/ak820_macro.c:73: } else if (value >= 128) {
      002A19 BA 80 00         [24]  409 	cjne	r2,#0x80,00204$
      002A1C                        410 00204$:
      002A1C 40 04            [24]  411 	jc	00121$
                                    412 ;	keyboards/ajazz/ak820/ak820_macro.c:76: return false;
      002A1E 75 82 00         [24]  413 	mov	dpl, #0x00
      002A21 22               [24]  414 	ret
      002A22                        415 00121$:
                                    416 ;	keyboards/ajazz/ak820/ak820_macro.c:78: return true;
      002A22 75 82 01         [24]  417 	mov	dpl, #0x01
                                    418 ;	keyboards/ajazz/ak820/ak820_macro.c:79: }
      002A25 22               [24]  419 	ret
                                    420 ;------------------------------------------------------------
                                    421 ;Allocation info for local variables in function 'matches'
                                    422 ;------------------------------------------------------------
                                    423 ;size          Allocated with name '_matches_PARM_2'
                                    424 ;data          Allocated with name '_matches_PARM_3'
                                    425 ;offset        Allocated with name '_matches_offset_10000_89'
                                    426 ;value         Allocated with name '_matches_value_20000_91'
                                    427 ;------------------------------------------------------------
                                    428 ;	keyboards/ajazz/ak820/ak820_macro.c:81: static bool matches(uint16_t offset, uint16_t size, const uint8_t AK820_XDATA *data) {
                                    429 ;	-----------------------------------------
                                    430 ;	 function matches
                                    431 ;	-----------------------------------------
      002A26                        432 _matches:
      002A26 AF 83            [24]  433 	mov	r7,dph
      002A28 E5 82            [12]  434 	mov	a,dpl
      002A2A 90 05 80         [24]  435 	mov	dptr,#_matches_offset_10000_89
      002A2D F0               [24]  436 	movx	@dptr,a
      002A2E EF               [12]  437 	mov	a,r7
      002A2F A3               [24]  438 	inc	dptr
      002A30 F0               [24]  439 	movx	@dptr,a
                                    440 ;	keyboards/ajazz/ak820/ak820_macro.c:82: while (size--) {
      002A31 90 05 7E         [24]  441 	mov	dptr,#_matches_PARM_3
      002A34 E0               [24]  442 	movx	a,@dptr
      002A35 FE               [12]  443 	mov	r6,a
      002A36 A3               [24]  444 	inc	dptr
      002A37 E0               [24]  445 	movx	a,@dptr
      002A38 FF               [12]  446 	mov	r7,a
      002A39 90 05 80         [24]  447 	mov	dptr,#_matches_offset_10000_89
      002A3C E0               [24]  448 	movx	a,@dptr
      002A3D FC               [12]  449 	mov	r4,a
      002A3E A3               [24]  450 	inc	dptr
      002A3F E0               [24]  451 	movx	a,@dptr
      002A40 FD               [12]  452 	mov	r5,a
      002A41 90 05 7C         [24]  453 	mov	dptr,#_matches_PARM_2
      002A44 E0               [24]  454 	movx	a,@dptr
      002A45 FA               [12]  455 	mov	r2,a
      002A46 A3               [24]  456 	inc	dptr
      002A47 E0               [24]  457 	movx	a,@dptr
      002A48 FB               [12]  458 	mov	r3,a
      002A49                        459 00103$:
      002A49 8A 00            [24]  460 	mov	ar0,r2
      002A4B 8B 01            [24]  461 	mov	ar1,r3
      002A4D 1A               [12]  462 	dec	r2
      002A4E BA FF 01         [24]  463 	cjne	r2,#0xff,00147$
      002A51 1B               [12]  464 	dec	r3
      002A52                        465 00147$:
      002A52 E8               [12]  466 	mov	a,r0
      002A53 49               [12]  467 	orl	a,r1
      002A54 60 5D            [24]  468 	jz	00105$
                                    469 ;	keyboards/ajazz/ak820/ak820_macro.c:83: uint8_t value = !uploading && offset >= used_length ? 0 : macro_byte(offset);
      002A56 20 09 13         [24]  470 	jb	_uploading,00108$
      002A59 90 05 6F         [24]  471 	mov	dptr,#_used_length
      002A5C E0               [24]  472 	movx	a,@dptr
      002A5D F8               [12]  473 	mov	r0,a
      002A5E A3               [24]  474 	inc	dptr
      002A5F E0               [24]  475 	movx	a,@dptr
      002A60 F9               [12]  476 	mov	r1,a
      002A61 C3               [12]  477 	clr	c
      002A62 EC               [12]  478 	mov	a,r4
      002A63 98               [12]  479 	subb	a,r0
      002A64 ED               [12]  480 	mov	a,r5
      002A65 99               [12]  481 	subb	a,r1
      002A66 40 04            [24]  482 	jc	00108$
      002A68 79 00            [12]  483 	mov	r1,#0x00
      002A6A 80 23            [24]  484 	sjmp	00109$
      002A6C                        485 00108$:
      002A6C 8C 82            [24]  486 	mov	dpl, r4
      002A6E 8D 83            [24]  487 	mov	dph, r5
      002A70 C0 07            [24]  488 	push	ar7
      002A72 C0 06            [24]  489 	push	ar6
      002A74 C0 05            [24]  490 	push	ar5
      002A76 C0 04            [24]  491 	push	ar4
      002A78 C0 03            [24]  492 	push	ar3
      002A7A C0 02            [24]  493 	push	ar2
      002A7C 12 28 EC         [24]  494 	lcall	_macro_byte
      002A7F A8 82            [24]  495 	mov	r0, dpl
      002A81 D0 02            [24]  496 	pop	ar2
      002A83 D0 03            [24]  497 	pop	ar3
      002A85 D0 04            [24]  498 	pop	ar4
      002A87 D0 05            [24]  499 	pop	ar5
      002A89 D0 06            [24]  500 	pop	ar6
      002A8B D0 07            [24]  501 	pop	ar7
      002A8D 88 01            [24]  502 	mov	ar1,r0
      002A8F                        503 00109$:
                                    504 ;	keyboards/ajazz/ak820/ak820_macro.c:84: if (value != *data++) return false;
      002A8F 8E 82            [24]  505 	mov	dpl,r6
      002A91 8F 83            [24]  506 	mov	dph,r7
      002A93 E0               [24]  507 	movx	a,@dptr
      002A94 F8               [12]  508 	mov	r0,a
      002A95 A3               [24]  509 	inc	dptr
      002A96 AE 82            [24]  510 	mov	r6,dpl
      002A98 AF 83            [24]  511 	mov	r7,dph
      002A9A E9               [12]  512 	mov	a,r1
      002A9B B5 00 02         [24]  513 	cjne	a,ar0,00151$
      002A9E 80 04            [24]  514 	sjmp	00102$
      002AA0                        515 00151$:
      002AA0 75 82 00         [24]  516 	mov	dpl, #0x00
      002AA3 22               [24]  517 	ret
      002AA4                        518 00102$:
                                    519 ;	keyboards/ajazz/ak820/ak820_macro.c:85: ++offset;
      002AA4 0C               [12]  520 	inc	r4
      002AA5 BC 00 01         [24]  521 	cjne	r4,#0x00,00152$
      002AA8 0D               [12]  522 	inc	r5
      002AA9                        523 00152$:
      002AA9 90 05 80         [24]  524 	mov	dptr,#_matches_offset_10000_89
      002AAC EC               [12]  525 	mov	a,r4
      002AAD F0               [24]  526 	movx	@dptr,a
      002AAE ED               [12]  527 	mov	a,r5
      002AAF A3               [24]  528 	inc	dptr
      002AB0 F0               [24]  529 	movx	@dptr,a
      002AB1 80 96            [24]  530 	sjmp	00103$
      002AB3                        531 00105$:
                                    532 ;	keyboards/ajazz/ak820/ak820_macro.c:87: return true;
      002AB3 75 82 01         [24]  533 	mov	dpl, #0x01
                                    534 ;	keyboards/ajazz/ak820/ak820_macro.c:88: }
      002AB6 22               [24]  535 	ret
                                    536 ;------------------------------------------------------------
                                    537 ;Allocation info for local variables in function 'ak820_macro_init'
                                    538 ;------------------------------------------------------------
                                    539 ;	keyboards/ajazz/ak820/ak820_macro.c:90: void ak820_macro_init(void) {
                                    540 ;	-----------------------------------------
                                    541 ;	 function ak820_macro_init
                                    542 ;	-----------------------------------------
      002AB7                        543 _ak820_macro_init:
                                    544 ;	keyboards/ajazz/ak820/ak820_macro.c:91: covered = 0;
      002AB7 90 05 6D         [24]  545 	mov	dptr,#_covered
      002ABA E4               [12]  546 	clr	a
      002ABB F0               [24]  547 	movx	@dptr,a
      002ABC A3               [24]  548 	inc	dptr
      002ABD F0               [24]  549 	movx	@dptr,a
                                    550 ;	keyboards/ajazz/ak820/ak820_macro.c:92: uploading = false;
                                    551 ;	assignBit
      002ABE C2 09            [12]  552 	clr	_uploading
                                    553 ;	keyboards/ajazz/ak820/ak820_macro.c:93: parsed.terminated = parsed.arguments = 0;
      002AC0 90 05 6C         [24]  554 	mov	dptr,#(_parsed + 0x0001)
      002AC3 E4               [12]  555 	clr	a
      002AC4 F0               [24]  556 	movx	@dptr,a
      002AC5 90 05 6B         [24]  557 	mov	dptr,#_parsed
      002AC8 F0               [24]  558 	movx	@dptr,a
                                    559 ;	keyboards/ajazz/ak820/ak820_macro.c:94: used_length = eeprom_read_byte((const uint8_t *)(uintptr_t)AK820_MACRO_LENGTH_ADDR);
      002AC9 90 07 F1         [24]  560 	mov	dptr,#0x07f1
      002ACC F5 F0            [12]  561 	mov	b,a
      002ACE 12 47 36         [24]  562 	lcall	_eeprom_read_byte
      002AD1 AF 82            [24]  563 	mov	r7, dpl
      002AD3 90 05 6F         [24]  564 	mov	dptr,#_used_length
      002AD6 EF               [12]  565 	mov	a,r7
      002AD7 F0               [24]  566 	movx	@dptr,a
      002AD8 E4               [12]  567 	clr	a
      002AD9 A3               [24]  568 	inc	dptr
      002ADA F0               [24]  569 	movx	@dptr,a
                                    570 ;	keyboards/ajazz/ak820/ak820_macro.c:95: used_length |= (uint16_t)eeprom_read_byte((const uint8_t *)(uintptr_t)(AK820_MACRO_LENGTH_ADDR + 1)) << 8;
      002ADB 90 07 F2         [24]  571 	mov	dptr,#0x07f2
      002ADE F5 F0            [12]  572 	mov	b,a
      002AE0 12 47 36         [24]  573 	lcall	_eeprom_read_byte
      002AE3 AE 82            [24]  574 	mov	r6,dpl
      002AE5 7F 00            [12]  575 	mov	r7,#0x00
      002AE7 90 05 6F         [24]  576 	mov	dptr,#_used_length
      002AEA E0               [24]  577 	movx	a,@dptr
      002AEB 4F               [12]  578 	orl	a,r7
      002AEC F0               [24]  579 	movx	@dptr,a
      002AED A3               [24]  580 	inc	dptr
      002AEE E0               [24]  581 	movx	a,@dptr
      002AEF 4E               [12]  582 	orl	a,r6
      002AF0 F0               [24]  583 	movx	@dptr,a
                                    584 ;	keyboards/ajazz/ak820/ak820_macro.c:96: }
      002AF1 22               [24]  585 	ret
                                    586 ;------------------------------------------------------------
                                    587 ;Allocation info for local variables in function 'ak820_macro_ready'
                                    588 ;------------------------------------------------------------
                                    589 ;	keyboards/ajazz/ak820/ak820_macro.c:98: bool ak820_macro_ready(void) {
                                    590 ;	-----------------------------------------
                                    591 ;	 function ak820_macro_ready
                                    592 ;	-----------------------------------------
      002AF2                        593 _ak820_macro_ready:
                                    594 ;	keyboards/ajazz/ak820/ak820_macro.c:99: return ak820_nvm_ok() && used_length >= DYNAMIC_KEYMAP_MACRO_COUNT &&
      002AF2 12 44 DC         [24]  595 	lcall	_ak820_nvm_ok
      002AF5 E5 82            [12]  596 	mov	a, dpl
      002AF7 60 25            [24]  597 	jz	00103$
      002AF9 90 05 6F         [24]  598 	mov	dptr,#_used_length
      002AFC E0               [24]  599 	movx	a,@dptr
      002AFD FE               [12]  600 	mov	r6,a
      002AFE A3               [24]  601 	inc	dptr
      002AFF E0               [24]  602 	movx	a,@dptr
      002B00 FF               [12]  603 	mov	r7,a
      002B01 C3               [12]  604 	clr	c
      002B02 EE               [12]  605 	mov	a,r6
      002B03 94 10            [12]  606 	subb	a,#0x10
      002B05 EF               [12]  607 	mov	a,r7
      002B06 94 00            [12]  608 	subb	a,#0x00
                                    609 ;	keyboards/ajazz/ak820/ak820_macro.c:100: used_length <= DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE &&
      002B08 40 14            [24]  610 	jc	00103$
      002B0A E4               [12]  611 	clr	a
      002B0B 9E               [12]  612 	subb	a,r6
      002B0C 74 20            [12]  613 	mov	a,#0x20
      002B0E 9F               [12]  614 	subb	a,r7
      002B0F 40 0D            [24]  615 	jc	00103$
                                    616 ;	free result
                                    617 ;	keyboards/ajazz/ak820/ak820_macro.c:101: eeprom_read_byte((const uint8_t *)(uintptr_t)AK820_MACRO_BUSY_ADDR) == 0;
      002B11 90 07 F0         [24]  618 	mov	dptr,#0x07f0
      002B14 75 F0 00         [24]  619 	mov	b, #0x00
      002B17 12 47 36         [24]  620 	lcall	_eeprom_read_byte
      002B1A E5 82            [12]  621 	mov	a, dpl
      002B1C 60 04            [24]  622 	jz	00104$
      002B1E                        623 00103$:
                                    624 ;	assignBit
      002B1E C2 0B            [12]  625 	clr	_ak820_macro_ready_sloc0_1_0
      002B20 80 02            [24]  626 	sjmp	00105$
      002B22                        627 00104$:
                                    628 ;	assignBit
      002B22 D2 0B            [12]  629 	setb	_ak820_macro_ready_sloc0_1_0
      002B24                        630 00105$:
      002B24 A2 0B            [12]  631 	mov	c,_ak820_macro_ready_sloc0_1_0
      002B26 E4               [12]  632 	clr	a
      002B27 33               [12]  633 	rlc	a
      002B28 F5 82            [12]  634 	mov	dpl, a
                                    635 ;	keyboards/ajazz/ak820/ak820_macro.c:102: }
      002B2A 22               [24]  636 	ret
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'ak820_macro_length'
                                    639 ;------------------------------------------------------------
                                    640 ;	keyboards/ajazz/ak820/ak820_macro.c:104: uint16_t ak820_macro_length(void) { return ak820_macro_ready() ? used_length : 0; }
                                    641 ;	-----------------------------------------
                                    642 ;	 function ak820_macro_length
                                    643 ;	-----------------------------------------
      002B2B                        644 _ak820_macro_length:
      002B2B 12 2A F2         [24]  645 	lcall	_ak820_macro_ready
      002B2E E5 82            [12]  646 	mov	a, dpl
      002B30 60 0A            [24]  647 	jz	00103$
      002B32 90 05 6F         [24]  648 	mov	dptr,#_used_length
      002B35 E0               [24]  649 	movx	a,@dptr
      002B36 FE               [12]  650 	mov	r6,a
      002B37 A3               [24]  651 	inc	dptr
      002B38 E0               [24]  652 	movx	a,@dptr
      002B39 FF               [12]  653 	mov	r7,a
      002B3A 80 04            [24]  654 	sjmp	00104$
      002B3C                        655 00103$:
      002B3C 7E 00            [12]  656 	mov	r6,#0x00
      002B3E 7F 00            [12]  657 	mov	r7,#0x00
      002B40                        658 00104$:
      002B40 8E 82            [24]  659 	mov	dpl, r6
      002B42 8F 83            [24]  660 	mov	dph, r7
      002B44 22               [24]  661 	ret
                                    662 ;------------------------------------------------------------
                                    663 ;Allocation info for local variables in function 'ak820_macro_write'
                                    664 ;------------------------------------------------------------
                                    665 ;sloc0         Allocated with name '_ak820_macro_write_sloc0_1_0'
                                    666 ;size          Allocated with name '_ak820_macro_write_PARM_2'
                                    667 ;packet        Allocated with name '_ak820_macro_write_PARM_3'
                                    668 ;offset        Allocated with name '_ak820_macro_write_offset_10000_99'
                                    669 ;data          Allocated with name '_ak820_macro_write_data_10000_100'
                                    670 ;next          Allocated with name '_ak820_macro_write_next_10000_100'
                                    671 ;i             Allocated with name '_ak820_macro_write_i_10000_100'
                                    672 ;end           Allocated with name '_ak820_macro_write_end_10000_100'
                                    673 ;complete      Allocated with name '_ak820_macro_write_complete_10000_100'
                                    674 ;------------------------------------------------------------
                                    675 ;	keyboards/ajazz/ak820/ak820_macro.c:106: bool ak820_macro_write(uint16_t offset, uint16_t size, const uint8_t *packet) {
                                    676 ;	-----------------------------------------
                                    677 ;	 function ak820_macro_write
                                    678 ;	-----------------------------------------
      002B45                        679 _ak820_macro_write:
      002B45 AF 83            [24]  680 	mov	r7,dph
      002B47 E5 82            [12]  681 	mov	a,dpl
      002B49 90 05 87         [24]  682 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002B4C F0               [24]  683 	movx	@dptr,a
      002B4D EF               [12]  684 	mov	a,r7
      002B4E A3               [24]  685 	inc	dptr
      002B4F F0               [24]  686 	movx	@dptr,a
                                    687 ;	keyboards/ajazz/ak820/ak820_macro.c:109: const uint8_t AK820_XDATA *data = (const uint8_t AK820_XDATA *)packet;
      002B50 90 05 84         [24]  688 	mov	dptr,#_ak820_macro_write_PARM_3
      002B53 E0               [24]  689 	movx	a,@dptr
      002B54 FE               [12]  690 	mov	r6,a
      002B55 A3               [24]  691 	inc	dptr
      002B56 E0               [24]  692 	movx	a,@dptr
      002B57 FF               [12]  693 	mov	r7,a
                                    694 ;	keyboards/ajazz/ak820/ak820_macro.c:115: if (!ak820_nvm_ok() || !size || offset >= DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE ||
      002B58 12 44 DC         [24]  695 	lcall	_ak820_nvm_ok
      002B5B E5 82            [12]  696 	mov	a, dpl
      002B5D 60 2B            [24]  697 	jz	00101$
      002B5F 90 05 82         [24]  698 	mov	dptr,#_ak820_macro_write_PARM_2
      002B62 E0               [24]  699 	movx	a,@dptr
      002B63 FC               [12]  700 	mov	r4,a
      002B64 A3               [24]  701 	inc	dptr
      002B65 E0               [24]  702 	movx	a,@dptr
      002B66 FD               [12]  703 	mov	r5,a
      002B67 4C               [12]  704 	orl	a,r4
      002B68 60 20            [24]  705 	jz	00101$
      002B6A 90 05 87         [24]  706 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002B6D E0               [24]  707 	movx	a,@dptr
      002B6E FA               [12]  708 	mov	r2,a
      002B6F A3               [24]  709 	inc	dptr
      002B70 E0               [24]  710 	movx	a,@dptr
      002B71 FB               [12]  711 	mov	r3,a
      002B72 8A 00            [24]  712 	mov	ar0,r2
      002B74 8B 01            [24]  713 	mov	ar1,r3
      002B76 74 E0            [12]  714 	mov	a,#0x100 - 0x20
      002B78 29               [12]  715 	add	a,r1
      002B79 40 0F            [24]  716 	jc	00101$
                                    717 ;	keyboards/ajazz/ak820/ak820_macro.c:116: size > DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE - offset) return false;
      002B7B E4               [12]  718 	clr	a
      002B7C C3               [12]  719 	clr	c
      002B7D 9A               [12]  720 	subb	a,r2
      002B7E F8               [12]  721 	mov	r0,a
      002B7F 74 20            [12]  722 	mov	a,#0x20
      002B81 9B               [12]  723 	subb	a,r3
      002B82 F9               [12]  724 	mov	r1,a
      002B83 C3               [12]  725 	clr	c
      002B84 E8               [12]  726 	mov	a,r0
      002B85 9C               [12]  727 	subb	a,r4
      002B86 E9               [12]  728 	mov	a,r1
      002B87 9D               [12]  729 	subb	a,r5
      002B88 50 04            [24]  730 	jnc	00102$
                                    731 ;	free result
      002B8A                        732 00101$:
      002B8A 75 82 00         [24]  733 	mov	dpl, #0x00
      002B8D 22               [24]  734 	ret
      002B8E                        735 00102$:
                                    736 ;	keyboards/ajazz/ak820/ak820_macro.c:117: end = offset + size;
      002B8E EC               [12]  737 	mov	a,r4
      002B8F 2A               [12]  738 	add	a, r2
      002B90 F8               [12]  739 	mov	r0,a
      002B91 ED               [12]  740 	mov	a,r5
      002B92 3B               [12]  741 	addc	a, r3
      002B93 F9               [12]  742 	mov	r1,a
                                    743 ;	keyboards/ajazz/ak820/ak820_macro.c:120: if (end <= covered && (uploading || offset || end == covered) && matches(offset, size, data)) return true;
      002B94 90 05 6D         [24]  744 	mov	dptr,#_covered
      002B97 E0               [24]  745 	movx	a,@dptr
      002B98 F5 18            [12]  746 	mov	_ak820_macro_write_sloc0_1_0,a
      002B9A A3               [24]  747 	inc	dptr
      002B9B E0               [24]  748 	movx	a,@dptr
      002B9C F5 19            [12]  749 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002B9E C3               [12]  750 	clr	c
      002B9F E5 18            [12]  751 	mov	a,_ak820_macro_write_sloc0_1_0
      002BA1 98               [12]  752 	subb	a,r0
      002BA2 E5 19            [12]  753 	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
      002BA4 99               [12]  754 	subb	a,r1
      002BA5 40 4E            [24]  755 	jc	00107$
                                    756 ;	free result
      002BA7 20 09 0C         [24]  757 	jb	_uploading,00111$
      002BAA EA               [12]  758 	mov	a,r2
      002BAB 4B               [12]  759 	orl	a,r3
      002BAC 70 08            [24]  760 	jnz	00111$
      002BAE E8               [12]  761 	mov	a,r0
      002BAF B5 18 43         [24]  762 	cjne	a,_ak820_macro_write_sloc0_1_0,00107$
      002BB2 E9               [12]  763 	mov	a,r1
      002BB3 B5 19 3F         [24]  764 	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00107$
      002BB6                        765 00111$:
      002BB6 90 05 87         [24]  766 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002BB9 E0               [24]  767 	movx	a,@dptr
      002BBA FA               [12]  768 	mov	r2,a
      002BBB A3               [24]  769 	inc	dptr
      002BBC E0               [24]  770 	movx	a,@dptr
      002BBD FB               [12]  771 	mov	r3,a
      002BBE 90 05 7C         [24]  772 	mov	dptr,#_matches_PARM_2
      002BC1 EC               [12]  773 	mov	a,r4
      002BC2 F0               [24]  774 	movx	@dptr,a
      002BC3 ED               [12]  775 	mov	a,r5
      002BC4 A3               [24]  776 	inc	dptr
      002BC5 F0               [24]  777 	movx	@dptr,a
      002BC6 90 05 7E         [24]  778 	mov	dptr,#_matches_PARM_3
      002BC9 EE               [12]  779 	mov	a,r6
      002BCA F0               [24]  780 	movx	@dptr,a
      002BCB EF               [12]  781 	mov	a,r7
      002BCC A3               [24]  782 	inc	dptr
      002BCD F0               [24]  783 	movx	@dptr,a
      002BCE 8A 82            [24]  784 	mov	dpl, r2
      002BD0 8B 83            [24]  785 	mov	dph, r3
      002BD2 C0 07            [24]  786 	push	ar7
      002BD4 C0 06            [24]  787 	push	ar6
      002BD6 C0 05            [24]  788 	push	ar5
      002BD8 C0 04            [24]  789 	push	ar4
      002BDA C0 01            [24]  790 	push	ar1
      002BDC C0 00            [24]  791 	push	ar0
      002BDE 12 2A 26         [24]  792 	lcall	_matches
      002BE1 E5 82            [12]  793 	mov	a, dpl
      002BE3 D0 00            [24]  794 	pop	ar0
      002BE5 D0 01            [24]  795 	pop	ar1
      002BE7 D0 04            [24]  796 	pop	ar4
      002BE9 D0 05            [24]  797 	pop	ar5
      002BEB D0 06            [24]  798 	pop	ar6
      002BED D0 07            [24]  799 	pop	ar7
      002BEF 60 04            [24]  800 	jz	00107$
      002BF1 75 82 01         [24]  801 	mov	dpl, #0x01
      002BF4 22               [24]  802 	ret
      002BF5                        803 00107$:
                                    804 ;	keyboards/ajazz/ak820/ak820_macro.c:122: if (!uploading) {
      002BF5 30 09 03         [24]  805 	jnb	_uploading,00371$
      002BF8 02 2C 93         [24]  806 	ljmp	00130$
      002BFB                        807 00371$:
                                    808 ;	keyboards/ajazz/ak820/ak820_macro.c:123: if (offset) {
      002BFB 90 05 87         [24]  809 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002BFE E0               [24]  810 	movx	a,@dptr
      002BFF FA               [12]  811 	mov	r2,a
      002C00 A3               [24]  812 	inc	dptr
      002C01 E0               [24]  813 	movx	a,@dptr
      002C02 FB               [12]  814 	mov	r3,a
      002C03 90 05 87         [24]  815 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002C06 E0               [24]  816 	movx	a,@dptr
      002C07 F5 F0            [12]  817 	mov	b,a
      002C09 A3               [24]  818 	inc	dptr
      002C0A E0               [24]  819 	movx	a,@dptr
      002C0B 45 F0            [12]  820 	orl	a,b
      002C0D 60 78            [24]  821 	jz	00120$
                                    822 ;	keyboards/ajazz/ak820/ak820_macro.c:127: if (!covered || offset != covered || !ak820_macro_ready()) return false;
      002C0F 90 05 6D         [24]  823 	mov	dptr,#_covered
      002C12 E0               [24]  824 	movx	a,@dptr
      002C13 F5 18            [12]  825 	mov	_ak820_macro_write_sloc0_1_0,a
      002C15 A3               [24]  826 	inc	dptr
      002C16 E0               [24]  827 	movx	a,@dptr
      002C17 F5 19            [12]  828 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002C19 90 05 6D         [24]  829 	mov	dptr,#_covered
      002C1C E0               [24]  830 	movx	a,@dptr
      002C1D F5 F0            [12]  831 	mov	b,a
      002C1F A3               [24]  832 	inc	dptr
      002C20 E0               [24]  833 	movx	a,@dptr
      002C21 45 F0            [12]  834 	orl	a,b
      002C23 60 27            [24]  835 	jz	00112$
      002C25 EA               [12]  836 	mov	a,r2
      002C26 B5 18 23         [24]  837 	cjne	a,_ak820_macro_write_sloc0_1_0,00112$
      002C29 EB               [12]  838 	mov	a,r3
      002C2A B5 19 1F         [24]  839 	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00112$
      002C2D C0 07            [24]  840 	push	ar7
      002C2F C0 06            [24]  841 	push	ar6
      002C31 C0 05            [24]  842 	push	ar5
      002C33 C0 04            [24]  843 	push	ar4
      002C35 C0 01            [24]  844 	push	ar1
      002C37 C0 00            [24]  845 	push	ar0
      002C39 12 2A F2         [24]  846 	lcall	_ak820_macro_ready
      002C3C E5 82            [12]  847 	mov	a, dpl
      002C3E D0 00            [24]  848 	pop	ar0
      002C40 D0 01            [24]  849 	pop	ar1
      002C42 D0 04            [24]  850 	pop	ar4
      002C44 D0 05            [24]  851 	pop	ar5
      002C46 D0 06            [24]  852 	pop	ar6
      002C48 D0 07            [24]  853 	pop	ar7
      002C4A 70 04            [24]  854 	jnz	00200$
      002C4C                        855 00112$:
      002C4C 75 82 00         [24]  856 	mov	dpl, #0x00
      002C4F 22               [24]  857 	ret
                                    858 ;	keyboards/ajazz/ak820/ak820_macro.c:128: for (i = 0; i < size; ++i) if (data[i]) return false;
      002C50                        859 00200$:
      002C50 7A 00            [12]  860 	mov	r2,#0x00
      002C52 7B 00            [12]  861 	mov	r3,#0x00
      002C54                        862 00148$:
      002C54 C3               [12]  863 	clr	c
      002C55 EA               [12]  864 	mov	a,r2
      002C56 9C               [12]  865 	subb	a,r4
      002C57 EB               [12]  866 	mov	a,r3
      002C58 9D               [12]  867 	subb	a,r5
      002C59 50 20            [24]  868 	jnc	00118$
      002C5B C0 00            [24]  869 	push	ar0
      002C5D C0 01            [24]  870 	push	ar1
      002C5F EA               [12]  871 	mov	a,r2
      002C60 2E               [12]  872 	add	a, r6
      002C61 F8               [12]  873 	mov	r0,a
      002C62 EB               [12]  874 	mov	a,r3
      002C63 3F               [12]  875 	addc	a, r7
      002C64 F9               [12]  876 	mov	r1,a
      002C65 88 82            [24]  877 	mov	dpl,r0
      002C67 89 83            [24]  878 	mov	dph,r1
      002C69 E0               [24]  879 	movx	a,@dptr
      002C6A D0 01            [24]  880 	pop	ar1
      002C6C D0 00            [24]  881 	pop	ar0
      002C6E 60 04            [24]  882 	jz	00149$
      002C70 75 82 00         [24]  883 	mov	dpl, #0x00
      002C73 22               [24]  884 	ret
      002C74                        885 00149$:
      002C74 0A               [12]  886 	inc	r2
      002C75 BA 00 DC         [24]  887 	cjne	r2,#0x00,00148$
      002C78 0B               [12]  888 	inc	r3
      002C79 80 D9            [24]  889 	sjmp	00148$
      002C7B                        890 00118$:
                                    891 ;	keyboards/ajazz/ak820/ak820_macro.c:129: covered = end;
      002C7B 90 05 6D         [24]  892 	mov	dptr,#_covered
      002C7E E8               [12]  893 	mov	a,r0
      002C7F F0               [24]  894 	movx	@dptr,a
      002C80 E9               [12]  895 	mov	a,r1
      002C81 A3               [24]  896 	inc	dptr
      002C82 F0               [24]  897 	movx	@dptr,a
                                    898 ;	keyboards/ajazz/ak820/ak820_macro.c:130: return true;
      002C83 75 82 01         [24]  899 	mov	dpl, #0x01
      002C86 22               [24]  900 	ret
      002C87                        901 00120$:
                                    902 ;	keyboards/ajazz/ak820/ak820_macro.c:132: next.terminated = next.arguments = 0;
      002C87 90 05 8A         [24]  903 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002C8A E4               [12]  904 	clr	a
      002C8B F0               [24]  905 	movx	@dptr,a
      002C8C 90 05 89         [24]  906 	mov	dptr,#_ak820_macro_write_next_10000_100
      002C8F F0               [24]  907 	movx	@dptr,a
      002C90 02 2D 28         [24]  908 	ljmp	00208$
      002C93                        909 00130$:
                                    910 ;	keyboards/ajazz/ak820/ak820_macro.c:134: if (offset > covered) return false; /* A hole is never old EEPROM data. */
      002C93 90 05 87         [24]  911 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002C96 E0               [24]  912 	movx	a,@dptr
      002C97 FA               [12]  913 	mov	r2,a
      002C98 A3               [24]  914 	inc	dptr
      002C99 E0               [24]  915 	movx	a,@dptr
      002C9A FB               [12]  916 	mov	r3,a
      002C9B 90 05 6D         [24]  917 	mov	dptr,#_covered
      002C9E E0               [24]  918 	movx	a,@dptr
      002C9F F5 18            [12]  919 	mov	_ak820_macro_write_sloc0_1_0,a
      002CA1 A3               [24]  920 	inc	dptr
      002CA2 E0               [24]  921 	movx	a,@dptr
      002CA3 F5 19            [12]  922 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002CA5 C3               [12]  923 	clr	c
      002CA6 E5 18            [12]  924 	mov	a,_ak820_macro_write_sloc0_1_0
      002CA8 9A               [12]  925 	subb	a,r2
      002CA9 E5 19            [12]  926 	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
      002CAB 9B               [12]  927 	subb	a,r3
      002CAC 50 04            [24]  928 	jnc	00122$
                                    929 ;	free result
      002CAE 75 82 00         [24]  930 	mov	dpl, #0x00
      002CB1 22               [24]  931 	ret
      002CB2                        932 00122$:
                                    933 ;	keyboards/ajazz/ak820/ak820_macro.c:135: if (offset == covered) {
      002CB2 EA               [12]  934 	mov	a,r2
      002CB3 B5 18 16         [24]  935 	cjne	a,_ak820_macro_write_sloc0_1_0,00127$
      002CB6 EB               [12]  936 	mov	a,r3
      002CB7 B5 19 12         [24]  937 	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00127$
                                    938 ;	keyboards/ajazz/ak820/ak820_macro.c:136: next.terminated = parsed.terminated;
      002CBA 90 05 6B         [24]  939 	mov	dptr,#_parsed
      002CBD E0               [24]  940 	movx	a,@dptr
      002CBE 90 05 89         [24]  941 	mov	dptr,#_ak820_macro_write_next_10000_100
      002CC1 F0               [24]  942 	movx	@dptr,a
                                    943 ;	keyboards/ajazz/ak820/ak820_macro.c:137: next.arguments = parsed.arguments;
      002CC2 90 05 6C         [24]  944 	mov	dptr,#(_parsed + 0x0001)
      002CC5 E0               [24]  945 	movx	a,@dptr
      002CC6 90 05 8A         [24]  946 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002CC9 F0               [24]  947 	movx	@dptr,a
      002CCA 80 5C            [24]  948 	sjmp	00208$
      002CCC                        949 00127$:
                                    950 ;	keyboards/ajazz/ak820/ak820_macro.c:142: next.terminated = next.arguments = 0;
      002CCC 90 05 8A         [24]  951 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002CCF E4               [12]  952 	clr	a
      002CD0 F0               [24]  953 	movx	@dptr,a
      002CD1 90 05 89         [24]  954 	mov	dptr,#_ak820_macro_write_next_10000_100
      002CD4 F0               [24]  955 	movx	@dptr,a
                                    956 ;	keyboards/ajazz/ak820/ak820_macro.c:143: for (i = 0; i < offset; ++i) if (!parse_byte(&next, macro_byte(i))) return false;
      002CD5 F5 18            [12]  957 	mov	_ak820_macro_write_sloc0_1_0,a
      002CD7 F5 19            [12]  958 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002CD9                        959 00151$:
      002CD9 C3               [12]  960 	clr	c
      002CDA E5 18            [12]  961 	mov	a,_ak820_macro_write_sloc0_1_0
      002CDC 9A               [12]  962 	subb	a,r2
      002CDD E5 19            [12]  963 	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
      002CDF 9B               [12]  964 	subb	a,r3
      002CE0 50 46            [24]  965 	jnc	00208$
      002CE2 85 18 82         [24]  966 	mov	dpl, _ak820_macro_write_sloc0_1_0
      002CE5 85 19 83         [24]  967 	mov	dph, (_ak820_macro_write_sloc0_1_0 + 1)
      002CE8 C0 07            [24]  968 	push	ar7
      002CEA C0 06            [24]  969 	push	ar6
      002CEC C0 05            [24]  970 	push	ar5
      002CEE C0 04            [24]  971 	push	ar4
      002CF0 C0 03            [24]  972 	push	ar3
      002CF2 C0 02            [24]  973 	push	ar2
      002CF4 C0 01            [24]  974 	push	ar1
      002CF6 C0 00            [24]  975 	push	ar0
      002CF8 12 28 EC         [24]  976 	lcall	_macro_byte
      002CFB E5 82            [12]  977 	mov	a, dpl
      002CFD 90 05 79         [24]  978 	mov	dptr,#_parse_byte_PARM_2
      002D00 F0               [24]  979 	movx	@dptr,a
      002D01 90 05 89         [24]  980 	mov	dptr,#_ak820_macro_write_next_10000_100
      002D04 12 29 80         [24]  981 	lcall	_parse_byte
      002D07 E5 82            [12]  982 	mov	a, dpl
      002D09 D0 00            [24]  983 	pop	ar0
      002D0B D0 01            [24]  984 	pop	ar1
      002D0D D0 02            [24]  985 	pop	ar2
      002D0F D0 03            [24]  986 	pop	ar3
      002D11 D0 04            [24]  987 	pop	ar4
      002D13 D0 05            [24]  988 	pop	ar5
      002D15 D0 06            [24]  989 	pop	ar6
      002D17 D0 07            [24]  990 	pop	ar7
      002D19 70 03            [24]  991 	jnz	00152$
      002D1B F5 82            [12]  992 	mov	dpl,a
      002D1D 22               [24]  993 	ret
      002D1E                        994 00152$:
      002D1E 05 18            [12]  995 	inc	_ak820_macro_write_sloc0_1_0
      002D20 E4               [12]  996 	clr	a
                                    997 ;	keyboards/ajazz/ak820/ak820_macro.c:146: for (i = 0; i < size; ++i) if (!parse_byte(&next, data[i])) return false;
      002D21 B5 18 B5         [24]  998 	cjne	a,_ak820_macro_write_sloc0_1_0,00151$
      002D24 05 19            [12]  999 	inc	(_ak820_macro_write_sloc0_1_0 + 1)
      002D26 80 B1            [24] 1000 	sjmp	00151$
      002D28                       1001 00208$:
      002D28 7A 00            [12] 1002 	mov	r2,#0x00
      002D2A 7B 00            [12] 1003 	mov	r3,#0x00
      002D2C                       1004 00154$:
      002D2C C3               [12] 1005 	clr	c
      002D2D EA               [12] 1006 	mov	a,r2
      002D2E 9C               [12] 1007 	subb	a,r4
      002D2F EB               [12] 1008 	mov	a,r3
      002D30 9D               [12] 1009 	subb	a,r5
      002D31 50 4A            [24] 1010 	jnc	00134$
      002D33 C0 00            [24] 1011 	push	ar0
      002D35 C0 01            [24] 1012 	push	ar1
      002D37 EA               [12] 1013 	mov	a,r2
      002D38 2E               [12] 1014 	add	a, r6
      002D39 F5 82            [12] 1015 	mov	dpl,a
      002D3B EB               [12] 1016 	mov	a,r3
      002D3C 3F               [12] 1017 	addc	a, r7
      002D3D F5 83            [12] 1018 	mov	dph,a
      002D3F E0               [24] 1019 	movx	a,@dptr
      002D40 F9               [12] 1020 	mov	r1,a
      002D41 90 05 79         [24] 1021 	mov	dptr,#_parse_byte_PARM_2
      002D44 F0               [24] 1022 	movx	@dptr,a
      002D45 90 05 89         [24] 1023 	mov	dptr,#_ak820_macro_write_next_10000_100
      002D48 C0 07            [24] 1024 	push	ar7
      002D4A C0 06            [24] 1025 	push	ar6
      002D4C C0 05            [24] 1026 	push	ar5
      002D4E C0 04            [24] 1027 	push	ar4
      002D50 C0 03            [24] 1028 	push	ar3
      002D52 C0 02            [24] 1029 	push	ar2
      002D54 C0 01            [24] 1030 	push	ar1
      002D56 C0 00            [24] 1031 	push	ar0
      002D58 12 29 80         [24] 1032 	lcall	_parse_byte
      002D5B E5 82            [12] 1033 	mov	a, dpl
      002D5D D0 00            [24] 1034 	pop	ar0
      002D5F D0 01            [24] 1035 	pop	ar1
      002D61 D0 02            [24] 1036 	pop	ar2
      002D63 D0 03            [24] 1037 	pop	ar3
      002D65 D0 04            [24] 1038 	pop	ar4
      002D67 D0 05            [24] 1039 	pop	ar5
      002D69 D0 06            [24] 1040 	pop	ar6
      002D6B D0 07            [24] 1041 	pop	ar7
      002D6D D0 01            [24] 1042 	pop	ar1
      002D6F D0 00            [24] 1043 	pop	ar0
      002D71 70 03            [24] 1044 	jnz	00155$
      002D73 F5 82            [12] 1045 	mov	dpl,a
      002D75 22               [24] 1046 	ret
      002D76                       1047 00155$:
      002D76 0A               [12] 1048 	inc	r2
      002D77 BA 00 B2         [24] 1049 	cjne	r2,#0x00,00154$
      002D7A 0B               [12] 1050 	inc	r3
      002D7B 80 AF            [24] 1051 	sjmp	00154$
      002D7D                       1052 00134$:
                                   1053 ;	keyboards/ajazz/ak820/ak820_macro.c:147: complete = next.terminated == DYNAMIC_KEYMAP_MACRO_COUNT;
      002D7D 90 05 89         [24] 1054 	mov	dptr,#_ak820_macro_write_next_10000_100
      002D80 E0               [24] 1055 	movx	a,@dptr
      002D81 FB               [12] 1056 	mov	r3,a
      002D82 E4               [12] 1057 	clr	a
      002D83 BB 10 01         [24] 1058 	cjne	r3,#0x10,00389$
      002D86 04               [12] 1059 	inc	a
      002D87                       1060 00389$:
                                   1061 ;	keyboards/ajazz/ak820/ak820_macro.c:148: if (!complete && end == DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE) return false;
      002D87 F5 18            [12] 1062 	mov	_ak820_macro_write_sloc0_1_0,a
      002D89 70 0E            [24] 1063 	jnz	00136$
      002D8B 88 02            [24] 1064 	mov	ar2,r0
      002D8D 89 03            [24] 1065 	mov	ar3,r1
      002D8F BA 00 07         [24] 1066 	cjne	r2,#0x00,00136$
      002D92 BB 20 04         [24] 1067 	cjne	r3,#0x20,00136$
      002D95 75 82 00         [24] 1068 	mov	dpl, #0x00
      002D98 22               [24] 1069 	ret
      002D99                       1070 00136$:
                                   1071 ;	keyboards/ajazz/ak820/ak820_macro.c:150: ak820_nvm_begin();
      002D99 C0 07            [24] 1072 	push	ar7
      002D9B C0 06            [24] 1073 	push	ar6
      002D9D C0 05            [24] 1074 	push	ar5
      002D9F C0 04            [24] 1075 	push	ar4
      002DA1 C0 01            [24] 1076 	push	ar1
      002DA3 C0 00            [24] 1077 	push	ar0
      002DA5 12 46 3E         [24] 1078 	lcall	_ak820_nvm_begin
      002DA8 D0 00            [24] 1079 	pop	ar0
      002DAA D0 01            [24] 1080 	pop	ar1
      002DAC D0 04            [24] 1081 	pop	ar4
      002DAE D0 05            [24] 1082 	pop	ar5
      002DB0 D0 06            [24] 1083 	pop	ar6
      002DB2 D0 07            [24] 1084 	pop	ar7
                                   1085 ;	keyboards/ajazz/ak820/ak820_macro.c:151: if (!uploading) {
      002DB4 20 09 2C         [24] 1086 	jb	_uploading,00141$
                                   1087 ;	keyboards/ajazz/ak820/ak820_macro.c:153: busy_write(1);
      002DB7 75 82 01         [24] 1088 	mov	dpl, #0x01
      002DBA C0 07            [24] 1089 	push	ar7
      002DBC C0 06            [24] 1090 	push	ar6
      002DBE C0 05            [24] 1091 	push	ar5
      002DC0 C0 04            [24] 1092 	push	ar4
      002DC2 C0 01            [24] 1093 	push	ar1
      002DC4 C0 00            [24] 1094 	push	ar0
      002DC6 12 29 0C         [24] 1095 	lcall	_busy_write
      002DC9 D0 00            [24] 1096 	pop	ar0
      002DCB D0 01            [24] 1097 	pop	ar1
      002DCD D0 04            [24] 1098 	pop	ar4
      002DCF D0 05            [24] 1099 	pop	ar5
      002DD1 D0 06            [24] 1100 	pop	ar6
      002DD3 D0 07            [24] 1101 	pop	ar7
                                   1102 ;	keyboards/ajazz/ak820/ak820_macro.c:154: if (!ak820_nvm_ok()) { ak820_nvm_end(); return false; }
      002DD5 12 44 DC         [24] 1103 	lcall	_ak820_nvm_ok
      002DD8 E5 82            [12] 1104 	mov	a, dpl
      002DDA 70 07            [24] 1105 	jnz	00141$
      002DDC 12 46 53         [24] 1106 	lcall	_ak820_nvm_end
      002DDF 75 82 00         [24] 1107 	mov	dpl, #0x00
      002DE2 22               [24] 1108 	ret
      002DE3                       1109 00141$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_macro.c:156: ak820_eeprom_write_block_xdata(data, (void *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + offset), size);
      002DE3 90 05 87         [24] 1111 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002DE6 E0               [24] 1112 	movx	a,@dptr
      002DE7 FA               [12] 1113 	mov	r2,a
      002DE8 A3               [24] 1114 	inc	dptr
      002DE9 E0               [24] 1115 	movx	a,@dptr
      002DEA 24 08            [12] 1116 	add	a,#0x08
      002DEC FB               [12] 1117 	mov	r3,a
      002DED 90 05 FC         [24] 1118 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      002DF0 EA               [12] 1119 	mov	a,r2
      002DF1 F0               [24] 1120 	movx	@dptr,a
      002DF2 EB               [12] 1121 	mov	a,r3
      002DF3 A3               [24] 1122 	inc	dptr
      002DF4 F0               [24] 1123 	movx	@dptr,a
      002DF5 E4               [12] 1124 	clr	a
      002DF6 A3               [24] 1125 	inc	dptr
      002DF7 F0               [24] 1126 	movx	@dptr,a
      002DF8 90 05 FF         [24] 1127 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      002DFB EC               [12] 1128 	mov	a,r4
      002DFC F0               [24] 1129 	movx	@dptr,a
      002DFD ED               [12] 1130 	mov	a,r5
      002DFE A3               [24] 1131 	inc	dptr
      002DFF F0               [24] 1132 	movx	@dptr,a
      002E00 8E 82            [24] 1133 	mov	dpl, r6
      002E02 8F 83            [24] 1134 	mov	dph, r7
      002E04 C0 01            [24] 1135 	push	ar1
      002E06 C0 00            [24] 1136 	push	ar0
      002E08 12 47 FD         [24] 1137 	lcall	_ak820_eeprom_write_block_xdata
                                   1138 ;	keyboards/ajazz/ak820/ak820_macro.c:157: ak820_nvm_flush();
      002E0B 12 44 EB         [24] 1139 	lcall	_ak820_nvm_flush
      002E0E D0 00            [24] 1140 	pop	ar0
      002E10 D0 01            [24] 1141 	pop	ar1
                                   1142 ;	keyboards/ajazz/ak820/ak820_macro.c:158: if (complete && ak820_nvm_ok()) commit_length(end);
      002E12 E5 18            [12] 1143 	mov	a,_ak820_macro_write_sloc0_1_0
      002E14 60 16            [24] 1144 	jz	00143$
      002E16 12 44 DC         [24] 1145 	lcall	_ak820_nvm_ok
      002E19 E5 82            [12] 1146 	mov	a, dpl
      002E1B 60 0F            [24] 1147 	jz	00143$
      002E1D 88 82            [24] 1148 	mov	dpl, r0
      002E1F 89 83            [24] 1149 	mov	dph, r1
      002E21 C0 01            [24] 1150 	push	ar1
      002E23 C0 00            [24] 1151 	push	ar0
      002E25 12 29 23         [24] 1152 	lcall	_commit_length
      002E28 D0 00            [24] 1153 	pop	ar0
      002E2A D0 01            [24] 1154 	pop	ar1
      002E2C                       1155 00143$:
                                   1156 ;	keyboards/ajazz/ak820/ak820_macro.c:159: ak820_nvm_end();
      002E2C C0 01            [24] 1157 	push	ar1
      002E2E C0 00            [24] 1158 	push	ar0
      002E30 12 46 53         [24] 1159 	lcall	_ak820_nvm_end
      002E33 D0 00            [24] 1160 	pop	ar0
      002E35 D0 01            [24] 1161 	pop	ar1
                                   1162 ;	keyboards/ajazz/ak820/ak820_macro.c:160: if (!ak820_nvm_ok()) return false;
      002E37 12 44 DC         [24] 1163 	lcall	_ak820_nvm_ok
      002E3A E5 82            [12] 1164 	mov	a, dpl
      002E3C 70 03            [24] 1165 	jnz	00146$
      002E3E F5 82            [12] 1166 	mov	dpl,a
      002E40 22               [24] 1167 	ret
      002E41                       1168 00146$:
                                   1169 ;	keyboards/ajazz/ak820/ak820_macro.c:161: covered = end;
      002E41 90 05 6D         [24] 1170 	mov	dptr,#_covered
      002E44 E8               [12] 1171 	mov	a,r0
      002E45 F0               [24] 1172 	movx	@dptr,a
      002E46 E9               [12] 1173 	mov	a,r1
      002E47 A3               [24] 1174 	inc	dptr
      002E48 F0               [24] 1175 	movx	@dptr,a
                                   1176 ;	keyboards/ajazz/ak820/ak820_macro.c:162: parsed.terminated = next.terminated;
      002E49 90 05 89         [24] 1177 	mov	dptr,#_ak820_macro_write_next_10000_100
      002E4C E0               [24] 1178 	movx	a,@dptr
      002E4D 90 05 6B         [24] 1179 	mov	dptr,#_parsed
      002E50 F0               [24] 1180 	movx	@dptr,a
                                   1181 ;	keyboards/ajazz/ak820/ak820_macro.c:163: parsed.arguments = next.arguments;
      002E51 90 05 8A         [24] 1182 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002E54 E0               [24] 1183 	movx	a,@dptr
      002E55 90 05 6C         [24] 1184 	mov	dptr,#(_parsed + 0x0001)
      002E58 F0               [24] 1185 	movx	@dptr,a
                                   1186 ;	keyboards/ajazz/ak820/ak820_macro.c:164: uploading = !complete;
      002E59 E5 18            [12] 1187 	mov	a,_ak820_macro_write_sloc0_1_0
      002E5B B4 01 00         [24] 1188 	cjne	a,#0x01,00399$
      002E5E                       1189 00399$:
      002E5E 92 09            [24] 1190 	mov	_uploading,c
                                   1191 ;	keyboards/ajazz/ak820/ak820_macro.c:165: return true;
      002E60 75 82 01         [24] 1192 	mov	dpl, #0x01
                                   1193 ;	keyboards/ajazz/ak820/ak820_macro.c:166: }
      002E63 22               [24] 1194 	ret
                                   1195 ;------------------------------------------------------------
                                   1196 ;Allocation info for local variables in function 'ak820_macro_reset'
                                   1197 ;------------------------------------------------------------
                                   1198 ;i             Allocated with name '_ak820_macro_reset_i_10000_127'
                                   1199 ;------------------------------------------------------------
                                   1200 ;	keyboards/ajazz/ak820/ak820_macro.c:168: bool ak820_macro_reset(void) {
                                   1201 ;	-----------------------------------------
                                   1202 ;	 function ak820_macro_reset
                                   1203 ;	-----------------------------------------
      002E64                       1204 _ak820_macro_reset:
                                   1205 ;	keyboards/ajazz/ak820/ak820_macro.c:170: ak820_nvm_begin();
      002E64 12 46 3E         [24] 1206 	lcall	_ak820_nvm_begin
                                   1207 ;	keyboards/ajazz/ak820/ak820_macro.c:171: busy_write(1);
      002E67 75 82 01         [24] 1208 	mov	dpl, #0x01
      002E6A 12 29 0C         [24] 1209 	lcall	_busy_write
                                   1210 ;	keyboards/ajazz/ak820/ak820_macro.c:172: if (ak820_nvm_ok()) {
      002E6D 12 44 DC         [24] 1211 	lcall	_ak820_nvm_ok
      002E70 E5 82            [12] 1212 	mov	a, dpl
      002E72 60 3E            [24] 1213 	jz	00105$
                                   1214 ;	keyboards/ajazz/ak820/ak820_macro.c:173: for (i = 0; i < DYNAMIC_KEYMAP_MACRO_COUNT; ++i)
      002E74 7E 00            [12] 1215 	mov	r6,#0x00
      002E76 7F 00            [12] 1216 	mov	r7,#0x00
      002E78                       1217 00106$:
                                   1218 ;	keyboards/ajazz/ak820/ak820_macro.c:174: eeprom_update_byte((uint8_t *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + i), 0);
      002E78 8E 04            [24] 1219 	mov	ar4,r6
      002E7A 8F 05            [24] 1220 	mov	ar5,r7
      002E7C 74 08            [12] 1221 	mov	a,#0x08
      002E7E 2D               [12] 1222 	add	a, r5
      002E7F FD               [12] 1223 	mov	r5,a
      002E80 7B 00            [12] 1224 	mov	r3,#0x00
      002E82 90 07 09         [24] 1225 	mov	dptr,#_eeprom_update_byte_PARM_2
      002E85 E4               [12] 1226 	clr	a
      002E86 F0               [24] 1227 	movx	@dptr,a
      002E87 8C 82            [24] 1228 	mov	dpl, r4
      002E89 8D 83            [24] 1229 	mov	dph, r5
      002E8B 8B F0            [24] 1230 	mov	b, r3
      002E8D 12 54 9B         [24] 1231 	lcall	_eeprom_update_byte
                                   1232 ;	keyboards/ajazz/ak820/ak820_macro.c:173: for (i = 0; i < DYNAMIC_KEYMAP_MACRO_COUNT; ++i)
      002E90 0E               [12] 1233 	inc	r6
      002E91 BE 00 01         [24] 1234 	cjne	r6,#0x00,00140$
      002E94 0F               [12] 1235 	inc	r7
      002E95                       1236 00140$:
      002E95 8E 04            [24] 1237 	mov	ar4,r6
      002E97 8F 05            [24] 1238 	mov	ar5,r7
      002E99 C3               [12] 1239 	clr	c
      002E9A EC               [12] 1240 	mov	a,r4
      002E9B 94 10            [12] 1241 	subb	a,#0x10
      002E9D ED               [12] 1242 	mov	a,r5
      002E9E 94 00            [12] 1243 	subb	a,#0x00
      002EA0 40 D6            [24] 1244 	jc	00106$
                                   1245 ;	keyboards/ajazz/ak820/ak820_macro.c:175: ak820_nvm_flush();
      002EA2 12 44 EB         [24] 1246 	lcall	_ak820_nvm_flush
                                   1247 ;	keyboards/ajazz/ak820/ak820_macro.c:176: if (ak820_nvm_ok()) commit_length(DYNAMIC_KEYMAP_MACRO_COUNT);
      002EA5 12 44 DC         [24] 1248 	lcall	_ak820_nvm_ok
      002EA8 E5 82            [12] 1249 	mov	a, dpl
      002EAA 60 06            [24] 1250 	jz	00105$
      002EAC 90 00 10         [24] 1251 	mov	dptr,#0x0010
      002EAF 12 29 23         [24] 1252 	lcall	_commit_length
      002EB2                       1253 00105$:
                                   1254 ;	keyboards/ajazz/ak820/ak820_macro.c:178: ak820_nvm_end();
      002EB2 12 46 53         [24] 1255 	lcall	_ak820_nvm_end
                                   1256 ;	keyboards/ajazz/ak820/ak820_macro.c:179: ak820_macro_init();
      002EB5 12 2A B7         [24] 1257 	lcall	_ak820_macro_init
                                   1258 ;	keyboards/ajazz/ak820/ak820_macro.c:180: return ak820_nvm_ok();
                                   1259 ;	keyboards/ajazz/ak820/ak820_macro.c:181: }
      002EB8 02 44 DC         [24] 1260 	ljmp	_ak820_nvm_ok
                                   1261 	.area AK820LOW(CODE)
                                   1262 	.area CONST   (CODE)
                                   1263 	.area XINIT   (CODE)
                                   1264 	.area CABS    (ABS,CODE)
