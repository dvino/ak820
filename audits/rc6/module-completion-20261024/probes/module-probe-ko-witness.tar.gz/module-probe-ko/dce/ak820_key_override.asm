;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_key_override
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dynamic_keymap_get_key_override
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_key_override_process_PARM_3
	.globl _ak820_key_override_process_PARM_2
	.globl _ak820_key_override_sync_PARM_2
	.globl _ak820_key_override_valid
	.globl _ak820_key_override_cancel
	.globl _ak820_key_override_reload
	.globl _ak820_key_override_sync
	.globl _ak820_key_override_process
	.globl _ak820_key_override_key
	.globl _ak820_key_override_mods
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_ak820_key_override_valid_sloc0_1_0:
	.ds 2
_ak820_key_override_valid_sloc1_1_0:
	.ds 2
_activate_sloc0_1_0:
	.ds 3
_activate_sloc1_1_0:
	.ds 1
_activate_sloc2_1_0:
	.ds 2
_ak820_key_override_process_sloc0_1_0:
	.ds 1
_ak820_key_override_process_sloc1_1_0:
	.ds 1
_ak820_key_override_process_sloc2_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_basic_sloc0_1_0:
	.ds 1
_matches_sloc0_1_0:
	.ds 1
_eligible_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_entries:
	.ds 80
_trigger:
	.ds 1
_previous_mods:
	.ds 1
_blocked:
	.ds 1
_hidden:
	.ds 1
_basic_key_10000_597:
	.ds 2
_ak820_key_override_valid_e_10000_599:
	.ds 2
_replacement_mods_key_10000_606:
	.ds 2
_matches_PARM_2:
	.ds 1
_matches_PARM_3:
	.ds 1
_matches_mods_10000_608:
	.ds 1
_eligible_PARM_2:
	.ds 1
_eligible_PARM_3:
	.ds 1
_eligible_index_10000_611:
	.ds 1
_activate_PARM_2:
	.ds 1
_activate_PARM_3:
	.ds 1
_activate_reason_10000_623:
	.ds 1
_activate_e_30000_627:
	.ds 3
_ak820_key_override_sync_PARM_2:
	.ds 1
_ak820_key_override_sync_mods_10000_630:
	.ds 1
_ak820_key_override_sync_reason_10000_631:
	.ds 1
_ak820_key_override_process_PARM_2:
	.ds 1
_ak820_key_override_process_PARM_3:
	.ds 1
_ak820_key_override_process_record_10000_635:
	.ds 2
_ak820_key_override_mods_mods_10000_660:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_source:
	.ds 1
_active:
	.ds 1
_enabled:
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function basic
;	-----------------------------------------
_basic:
	lcall	_ak820_outline_0114
	mov	dptr,#_basic_key_10000_597
	lcall	_ak820_outline_0115
	mov	dptr,#_basic_key_10000_597
	lcall	_ak820_outline_0057
	clr	c
	mov	a,r6
	subb	a,#0x04
	mov	a,r7
	subb	a,#0x00
	jc	00103$
	mov	a,#0xa4
	subb	a,r6
	clr	a
	subb	a,r7
	jnc	00104$
;	free result
00103$:
;	assignBit
	clr	_basic_sloc0_1_0
	sjmp	00105$
00104$:
;	assignBit
	setb	_basic_sloc0_1_0
00105$:
	mov	c,_basic_sloc0_1_0
	lcall	_ak820_outline_0154
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_valid'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_key_override_valid_sloc0_1_0'
;sloc1         Allocated with name '_ak820_key_override_valid_sloc1_1_0'
;e             Allocated with name '_ak820_key_override_valid_e_10000_599'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:14: bool ak820_key_override_valid(const vial_key_override_entry_t AK820_STATE_MEM *e) {
;	-----------------------------------------
;	 function ak820_key_override_valid
;	-----------------------------------------
_ak820_key_override_valid:
	lcall	_ak820_outline_0114
	mov	dptr,#_ak820_key_override_valid_e_10000_599
	lcall	_ak820_outline_0115
;	keyboards/ajazz/ak820/ak820_key_override.c:16: if (!(e->trigger | e->replacement | e->layers | e->trigger_mods |
	mov	dptr,#_ak820_key_override_valid_e_10000_599
	lcall	_ak820_outline_0006
	lcall	_ak820_outline_0065
	lcall	_ak820_outline_0037
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	a,r2
	orl	a,r4
	mov	r0,a
	mov	a,r3
	orl	a,r5
	mov	r1,a
	lcall	_ak820_outline_0020
	mov	_ak820_key_override_valid_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_key_override_valid_sloc0_1_0 + 1),a
	mov	a,_ak820_key_override_valid_sloc0_1_0
	orl	a,r0
	mov	_ak820_key_override_valid_sloc1_1_0,a
	mov	a,(_ak820_key_override_valid_sloc0_1_0 + 1)
	orl	a,r1
	mov	(_ak820_key_override_valid_sloc1_1_0 + 1),a
	mov	a,#0x06
	lcall	_ak820_outline_0016
	mov	r1,#0x00
	orl	_ak820_key_override_valid_sloc1_1_0,a
	mov	a,r1
	orl	(_ak820_key_override_valid_sloc1_1_0 + 1),a
;	keyboards/ajazz/ak820/ak820_key_override.c:17: e->negative_mod_mask | e->suppressed_mods | e->options)) return true;
	mov	a,#0x07
	lcall	_ak820_outline_0016
	mov	r1,#0x00
	orl	_ak820_key_override_valid_sloc1_1_0,a
	mov	a,r1
	orl	(_ak820_key_override_valid_sloc1_1_0 + 1),a
	mov	a,#0x08
	lcall	_ak820_outline_0016
	mov	r1,#0x00
	orl	_ak820_key_override_valid_sloc1_1_0,a
	mov	a,r1
	orl	(_ak820_key_override_valid_sloc1_1_0 + 1),a
	mov	a,#0x09
	lcall	_ak820_outline_0016
	mov	r7,a
	mov	r1,a
	mov	r6,#0x00
	mov	a,_ak820_key_override_valid_sloc1_1_0
	orl	ar1,a
	mov	a,(_ak820_key_override_valid_sloc1_1_0 + 1)
	orl	ar6,a
	mov	a,r1
	orl	a,r6
	jnz	00102$
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:18: if (!basic(e->trigger) || !e->layers || (e->layers & ~0x3fu)) return false;
	lcall	_ak820_outline_0134
	push	ar7
	push	ar3
	push	ar2
	lcall	_basic
	mov	a, dpl
	pop	ar2
	pop	ar3
	pop	ar7
	jz	00103$
	mov	a,_ak820_key_override_valid_sloc0_1_0
	orl	a,(_ak820_key_override_valid_sloc0_1_0 + 1)
	jz	00103$
	mov	a,_ak820_key_override_valid_sloc0_1_0
	anl	a,#0xc0
	jnz	00169$
	mov	a,(_ak820_key_override_valid_sloc0_1_0 + 1)
	jz	00104$
00169$:
00103$:
	mov	dpl, #0x00
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_key_override.c:19: if (e->options & 0x40) return false;
	mov	a,r7
	jnb	acc.6,00108$
	mov	dpl, #0x00
	ret
00108$:
;	keyboards/ajazz/ak820/ak820_key_override.c:20: if (!(e->options & ACTIVATIONS)) return false;
	mov	a,r7
	anl	a,#0x07
	jnz	00110$
	mov	dpl,a
	ret
00110$:
;	keyboards/ajazz/ak820/ak820_key_override.c:23: if (e->replacement && (e->replacement >= QK_MOD_TAP || !basic((uint8_t)e->replacement))) return false;
	mov	a,r2
	orl	a,r3
	jz	00112$
	mov	ar6,r2
	mov	ar7,r3
	mov	a,#0x100 - 0x20
	add	a,r7
	jc	00111$
	mov	r7,#0x00
	mov	dpl, r2
	mov	dph, r7
	lcall	_basic
	mov	a, dpl
	jnz	00112$
00111$:
	mov	dpl, #0x00
	ret
00112$:
;	keyboards/ajazz/ak820/ak820_key_override.c:24: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_key_override.c:25: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'replacement_mods'
;------------------------------------------------------------
;key           Allocated with name '_replacement_mods_key_10000_606'
;mods          Allocated with name '_replacement_mods_mods_10000_607'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:26: static uint8_t replacement_mods(uint16_t key) {
;	-----------------------------------------
;	 function replacement_mods
;	-----------------------------------------
_replacement_mods:
	lcall	_ak820_outline_0114
	mov	dptr,#_replacement_mods_key_10000_606
	lcall	_ak820_outline_0115
;	keyboards/ajazz/ak820/ak820_key_override.c:27: uint8_t mods = QK_MODS_GET_MODS(key);
	mov	dptr,#_replacement_mods_key_10000_606
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	a,#0x1f
	anl	a,r6
;	keyboards/ajazz/ak820/ak820_key_override.c:28: return (mods & 0x10) ? (mods & 15) << 4 : mods;
	mov	r7,a
	jnb	acc.4,00103$
	mov	ar6,r7
	anl	ar6,#0x0f
	mov	a,r6
	swap	a
	anl	a,#0xf0
	mov	r6,a
	sjmp	00104$
00103$:
	mov	ar6,r7
00104$:
	mov	dpl, r6
;	keyboards/ajazz/ak820/ak820_key_override.c:29: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'matches'
;------------------------------------------------------------
;required      Allocated with name '_matches_PARM_2'
;one           Allocated with name '_matches_PARM_3'
;mods          Allocated with name '_matches_mods_10000_608'
;low           Allocated with name '_matches_low_10000_609'
;high          Allocated with name '_matches_high_10000_609'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:31: static bool matches(uint8_t mods, uint8_t required, bool one) {
;	-----------------------------------------
;	 function matches
;	-----------------------------------------
_matches:
	mov	a,dpl
	mov	dptr,#_matches_mods_10000_608
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:32: uint8_t low = required & 15, high = required >> 4;
	mov	dptr,#_matches_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x0f
	anl	a,r7
	mov	r6,a
	mov	a,r7
	swap	a
	anl	a,#0x0f
	mov	r5,a
;	keyboards/ajazz/ak820/ak820_key_override.c:33: if (one) return !required || (mods & required);
	mov	dptr,#_matches_PARM_3
	movx	a,@dptr
	jz	00102$
	mov	a,r7
	jz	00106$
	mov	dptr,#_matches_mods_10000_608
	movx	a,@dptr
	anl	a,r7
	jnz	00106$
;	assignBit
	clr	_matches_sloc0_1_0
	sjmp	00107$
00106$:
;	assignBit
	setb	_matches_sloc0_1_0
00107$:
	mov	c,_matches_sloc0_1_0
	lcall	_ak820_outline_0154
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:34: return ((mods & low) | ((mods >> 4) & high)) == (low | high);
	mov	dptr,#_matches_mods_10000_608
	movx	a,@dptr
	mov	r7,a
	mov	a,r6
	anl	a,r7
	mov	r4,a
	mov	a,r7
	swap	a
	anl	a,#0x0f
	mov	r7,a
	mov	a,r5
	anl	a,r7
	orl	ar4,a
	mov	a,r5
	orl	ar6,a
	mov	a,r4
	cjne	a,ar6,00132$
	setb	c
	sjmp	00133$
00132$:
	clr	c
00133$:
	mov  _matches_sloc0_1_0,c
	lcall	_ak820_outline_0154
;	keyboards/ajazz/ak820/ak820_key_override.c:35: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eligible'
;------------------------------------------------------------
;mods          Allocated with name '_eligible_PARM_2'
;layer         Allocated with name '_eligible_PARM_3'
;index         Allocated with name '_eligible_index_10000_611'
;e             Allocated with name '_eligible_e_10000_612'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:36: static bool eligible(uint8_t index, uint8_t mods, uint8_t layer) {
;	-----------------------------------------
;	 function eligible
;	-----------------------------------------
_eligible:
	mov	a,dpl
	mov	dptr,#_eligible_index_10000_611
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:37: vial_key_override_entry_t *e = &entries[index];
	movx	a,@dptr
	lcall	_ak820_outline_0019
;	keyboards/ajazz/ak820/ak820_key_override.c:38: return layer < 6 && (e->layers & ((uint16_t)1 << layer)) &&
	mov	dptr,#_eligible_PARM_3
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x06,00131$
00131$:
	jnc	00103$
	lcall	_ak820_outline_0020
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	b,r5
	inc	b
	mov	r5,#0x01
	mov	r2,#0x00
	sjmp	00134$
00133$:
	mov	a,r5
	add	a,r5
	mov	r5,a
	mov	a,r2
	rlc	a
	mov	r2,a
00134$:
	djnz	b,00133$
	mov	a,r5
	anl	ar3,a
	mov	a,r2
	anl	ar4,a
	mov	a,r3
	orl	a,r4
	jz	00103$
;	keyboards/ajazz/ak820/ak820_key_override.c:39: !(mods & e->negative_mod_mask) && matches(mods, e->trigger_mods, e->options & 8);
	mov	a,#0x07
	lcall	_ak820_outline_0016
	mov	r5,a
	mov	dptr,#_eligible_PARM_2
	movx	a,@dptr
	mov	r4,a
	mov	a,r5
	anl	a,r4
	jnz	00103$
	mov	a,#0x06
	lcall	_ak820_outline_0016
	mov	r5,a
	mov	a,#0x09
	lcall	_ak820_outline_0016
	mov	dptr,#_matches_PARM_3
	mov	c,acc.3
	clr	a
	rlc	a
	movx	@dptr,a
	mov	dptr,#_matches_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	dpl, r4
	lcall	_matches
	mov	a, dpl
	jnz	00104$
00103$:
;	assignBit
	clr	_eligible_sloc0_1_0
	sjmp	00105$
00104$:
;	assignBit
	setb	_eligible_sloc0_1_0
00105$:
	mov	c,_eligible_sloc0_1_0
	lcall	_ak820_outline_0154
;	keyboards/ajazz/ak820/ak820_key_override.c:40: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'deactivate'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:41: static void deactivate(void) {
;	-----------------------------------------
;	 function deactivate
;	-----------------------------------------
_deactivate:
;	keyboards/ajazz/ak820/ak820_key_override.c:42: if (active != NONE && (entries[active].options & 16)) hidden = true;
	lcall	_ak820_outline_0131
	cjne	r7,#0xff,00120$
	sjmp	00102$
00120$:
	mov	a,r7
	lcall	_ak820_outline_0019
	mov	a,#0x09
	lcall	_ak820_outline_0016
	jnb	acc.4,00102$
	mov	dptr,#_hidden
	mov	a,#0x01
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:43: active = NONE;
	mov	dptr,#_active
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:44: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_cancel'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:45: void ak820_key_override_cancel(void) {
;	-----------------------------------------
;	 function ak820_key_override_cancel
;	-----------------------------------------
_ak820_key_override_cancel:
;	keyboards/ajazz/ak820/ak820_key_override.c:46: source = active = NONE;
	mov	dptr,#_active
	mov	a,#0xff
	movx	@dptr,a
	mov	dptr,#_source
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:47: previous_mods = 0;
	mov	dptr,#_previous_mods
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:48: blocked = hidden = false;
	mov	dptr,#_hidden
	movx	@dptr,a
	mov	dptr,#_blocked
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:49: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_reload'
;------------------------------------------------------------
;i             Allocated with name '_ak820_key_override_reload_i_20000_620'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:50: void ak820_key_override_reload(void) {
;	-----------------------------------------
;	 function ak820_key_override_reload
;	-----------------------------------------
_ak820_key_override_reload:
;	keyboards/ajazz/ak820/ak820_key_override.c:51: ak820_key_override_cancel();
	lcall	_ak820_key_override_cancel
;	keyboards/ajazz/ak820/ak820_key_override.c:52: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	mov	r7,#0x00
00106$:
	cjne	r7,#0x08,00132$
00132$:
	jnc	00108$
;	keyboards/ajazz/ak820/ak820_key_override.c:53: if (dynamic_keymap_get_key_override(i, &entries[i]) || !ak820_key_override_valid(&entries[i]))
	lcall	_ak820_outline_0040
	mov	r6,a
	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	lcall	_ak820_outline_0077
	mov	dpl, r7
	push	ar7
	push	ar6
	push	ar5
	lcall	_dynamic_keymap_get_key_override
	lcall	_ak820_outline_0130
	pop	ar5
	pop	ar6
	pop	ar7
	orl	a,b
	jnz	00101$
	lcall	_ak820_outline_0145
	push	ar7
	lcall	_ak820_key_override_valid
	mov	a, dpl
	pop	ar7
	jnz	00107$
00101$:
;	keyboards/ajazz/ak820/ak820_key_override.c:54: entries[i].options = 0;
	lcall	_ak820_outline_0040
	mov	r6,a
	mov	a,#0x09
	add	a, r5
	mov	dpl,a
	clr	a
	addc	a, r6
	mov	dph,a
	clr	a
	movx	@dptr,a
00107$:
;	keyboards/ajazz/ak820/ak820_key_override.c:52: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	inc	r7
	sjmp	00106$
00108$:
;	keyboards/ajazz/ak820/ak820_key_override.c:56: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'activate'
;------------------------------------------------------------
;sloc0         Allocated with name '_activate_sloc0_1_0'
;sloc1         Allocated with name '_activate_sloc1_1_0'
;sloc2         Allocated with name '_activate_sloc2_1_0'
;mods          Allocated with name '_activate_PARM_2'
;layer         Allocated with name '_activate_PARM_3'
;reason        Allocated with name '_activate_reason_10000_623'
;i             Allocated with name '_activate_i_20000_626'
;e             Allocated with name '_activate_e_30000_627'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:57: static void activate(uint8_t reason, uint8_t mods, uint8_t layer) {
;	-----------------------------------------
;	 function activate
;	-----------------------------------------
_activate:
	mov	a,dpl
	mov	dptr,#_activate_reason_10000_623
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:58: if (!enabled || source == NONE || blocked || hidden || active != NONE) return;
	mov	dptr,#_enabled
	movx	a,@dptr
	jz	00101$
	mov	dptr,#_source
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00215$
	ret
00215$:
	mov	dptr,#_blocked
	movx	a,@dptr
	jnz	00101$
	mov	dptr,#_hidden
	movx	a,@dptr
	jnz	00101$
	lcall	_ak820_outline_0131
	cjne	r7,#0xff,00218$
	sjmp	00148$
00218$:
00101$:
	ret
;	keyboards/ajazz/ak820/ak820_key_override.c:59: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
00148$:
	mov	dptr,#_activate_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	_activate_sloc1_1_0,r7
	mov	dptr,#_activate_PARM_3
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_activate_reason_10000_623
	movx	a,@dptr
	mov	r4,a
	mov	a,#0x04
	anl	a,r4
	mov	_activate_sloc2_1_0,a
	mov	(_activate_sloc2_1_0 + 1),#0x00
	mov	r1,#0x00
00119$:
	cjne	r1,#0x08,00219$
00219$:
	jc	00220$
	ret
00220$:
;	keyboards/ajazz/ak820/ak820_key_override.c:60: vial_key_override_entry_t *e = &entries[i];
	push	ar5
	mov	a,r1
	mov	b,#0x0a
	mul	ab
	add	a, #_entries
	mov	r0,a
	mov	a,#(_entries >> 8)
	addc	a, b
	mov	r5,a
	mov	_activate_sloc0_1_0,r0
	mov	(_activate_sloc0_1_0 + 1),r5
	mov	(_activate_sloc0_1_0 + 2),#0x00
	mov	dptr,#_activate_e_30000_627
	mov	a,_activate_sloc0_1_0
	movx	@dptr,a
	mov	a,(_activate_sloc0_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	a,(_activate_sloc0_1_0 + 2)
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:61: if (e->trigger == trigger && (e->options & ENABLED) && (e->options & reason) &&
	mov	dpl,_activate_sloc0_1_0
	mov	dph,(_activate_sloc0_1_0 + 1)
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_trigger
	movx	a,@dptr
	mov	r3,a
	mov	r6,#0x00
	mov	a,r0
	cjne	a,ar3,00221$
	mov	a,r5
	cjne	a,ar6,00221$
	sjmp	00222$
00221$:
	pop	ar5
	ljmp	00120$
00222$:
	pop	ar5
	mov	a,#0x09
	add	a, _activate_sloc0_1_0
	mov	r2,a
	clr	a
	addc	a, (_activate_sloc0_1_0 + 1)
	mov	r3,a
	mov	r6,(_activate_sloc0_1_0 + 2)
	lcall	_ak820_outline_0146
	mov	b,r6
	lcall	__gptrget
	mov	r6,a
	jb	acc.7,00223$
	ljmp	00120$
00223$:
	mov	a,r4
	anl	a,r6
	jnz	00224$
	ljmp	00120$
00224$:
;	keyboards/ajazz/ak820/ak820_key_override.c:62: ((reason & 1) || ((reason & 2) && (e->trigger_mods & mods & ~previous_mods)) ||
	mov	a,r4
	jb	acc.0,00116$
	mov	a,r4
	jnb	acc.1,00114$
	mov	a,#0x06
	add	a, _activate_sloc0_1_0
	mov	r2,a
	clr	a
	addc	a, (_activate_sloc0_1_0 + 1)
	mov	r3,a
	mov	r6,(_activate_sloc0_1_0 + 2)
	lcall	_ak820_outline_0146
	mov	b,r6
	lcall	__gptrget
	mov	r2,a
	mov	a,r7
	anl	ar2,a
	mov	dptr,#_previous_mods
	movx	a,@dptr
	mov	r3,a
	mov	r6,#0x00
	xrl	ar3,#0xff
	xrl	ar6,#0xff
	mov	ar0,r2
	mov	r2,#0x00
	mov	a,r0
	anl	ar3,a
	mov	a,r2
	anl	ar6,a
	mov	a,r3
	orl	a,r6
	jnz	00116$
00114$:
;	keyboards/ajazz/ak820/ak820_key_override.c:63: ((reason & 4) && (e->negative_mod_mask & previous_mods & ~mods))) && eligible(i, mods, layer)) {
	mov	a,_activate_sloc2_1_0
	orl	a,(_activate_sloc2_1_0 + 1)
	jz	00120$
	mov	dptr,#_activate_e_30000_627
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	a,#0x07
	add	a, r3
	lcall	_ak820_outline_0083
	mov	r6,a
	mov	dptr,#_previous_mods
	movx	a,@dptr
	anl	ar6,a
	mov	ar2,r7
	mov	r3,#0x00
	xrl	ar2,#0xff
	xrl	ar3,#0xff
	mov	ar0,r6
	mov	r6,#0x00
	mov	a,r0
	anl	ar2,a
	mov	a,r6
	anl	ar3,a
	mov	a,r2
	orl	a,r3
	jz	00120$
00116$:
	mov	dptr,#_eligible_PARM_2
	mov	a,_activate_sloc1_1_0
	movx	@dptr,a
	mov	dptr,#_eligible_PARM_3
	mov	a,r5
	movx	@dptr,a
	mov	dpl, r1
	push	ar7
	push	ar5
	push	ar4
	push	ar1
	lcall	_eligible
	mov	a, dpl
	pop	ar1
	pop	ar4
	pop	ar5
	pop	ar7
	jz	00120$
;	keyboards/ajazz/ak820/ak820_key_override.c:64: active = i;
	mov	dptr,#_active
	mov	a,r1
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:65: return;
	ret
00120$:
;	keyboards/ajazz/ak820/ak820_key_override.c:59: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	inc	r1
;	keyboards/ajazz/ak820/ak820_key_override.c:68: }
	ljmp	00119$
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_sync'
;------------------------------------------------------------
;layer         Allocated with name '_ak820_key_override_sync_PARM_2'
;mods          Allocated with name '_ak820_key_override_sync_mods_10000_630'
;reason        Allocated with name '_ak820_key_override_sync_reason_10000_631'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:69: void ak820_key_override_sync(uint8_t mods, uint8_t layer) {
;	-----------------------------------------
;	 function ak820_key_override_sync
;	-----------------------------------------
_ak820_key_override_sync:
	mov	a,dpl
	mov	dptr,#_ak820_key_override_sync_mods_10000_630
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:70: uint8_t reason = 0;
	mov	dptr,#_ak820_key_override_sync_reason_10000_631
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:71: if (active != NONE && !eligible(active, mods, layer)) deactivate();
	lcall	_ak820_outline_0131
	cjne	r7,#0xff,00138$
	sjmp	00102$
00138$:
	lcall	_ak820_outline_0141
	mov	dptr,#_eligible_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dptr,#_eligible_PARM_3
	lcall	_ak820_outline_0199
	lcall	_eligible
	mov	a, dpl
	jnz	00102$
	lcall	_deactivate
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:72: if (mods & ~previous_mods) reason |= 2;
	mov	dptr,#_previous_mods
	movx	a,@dptr
	mov	r6,a
	mov	r7,#0x00
	mov	a,#0xff
	xrl	a,r6
	mov	r4,a
	mov	a,#0xff
	xrl	a,r7
	mov	r5,a
	mov	dptr,#_ak820_key_override_sync_mods_10000_630
	movx	a,@dptr
	mov	r2,a
	mov	r3,#0x00
	anl	ar4,a
	mov	a,r3
	anl	ar5,a
	mov	a,r4
	orl	a,r5
	jz	00105$
	mov	dptr,#_ak820_key_override_sync_reason_10000_631
	mov	a,#0x02
	movx	@dptr,a
00105$:
;	keyboards/ajazz/ak820/ak820_key_override.c:73: if (previous_mods & ~mods) reason |= 4;
	xrl	ar2,#0xff
	xrl	ar3,#0xff
	mov	a,r2
	anl	ar6,a
	mov	a,r3
	anl	ar7,a
	mov	a,r6
	orl	a,r7
	jz	00107$
	mov	dptr,#_ak820_key_override_sync_reason_10000_631
	movx	a,@dptr
	orl	acc,#0x04
	movx	@dptr,a
00107$:
;	keyboards/ajazz/ak820/ak820_key_override.c:74: activate(reason, mods, layer);
	mov	dptr,#_ak820_key_override_sync_reason_10000_631
	movx	a,@dptr
	mov	r7,a
	lcall	_ak820_outline_0141
	mov	dptr,#_activate_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dptr,#_activate_PARM_3
	lcall	_ak820_outline_0199
	push	ar6
	lcall	_activate
	pop	ar6
;	keyboards/ajazz/ak820/ak820_key_override.c:75: previous_mods = mods;
	mov	dptr,#_previous_mods
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:76: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_process'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_key_override_process_sloc0_1_0'
;sloc1         Allocated with name '_ak820_key_override_process_sloc1_1_0'
;sloc2         Allocated with name '_ak820_key_override_process_sloc2_1_0'
;mods          Allocated with name '_ak820_key_override_process_PARM_2'
;layer         Allocated with name '_ak820_key_override_process_PARM_3'
;record        Allocated with name '_ak820_key_override_process_record_10000_635'
;key           Allocated with name '_ak820_key_override_process_key_10000_636'
;id            Allocated with name '_ak820_key_override_process_id_10000_636'
;i             Allocated with name '_ak820_key_override_process_i_20000_653'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:77: bool ak820_key_override_process(keyrecord_t AK820_STATE_MEM *record, uint8_t mods, uint8_t layer) {
;	-----------------------------------------
;	 function ak820_key_override_process
;	-----------------------------------------
_ak820_key_override_process:
	lcall	_ak820_outline_0114
	mov	dptr,#_ak820_key_override_process_record_10000_635
	lcall	_ak820_outline_0115
;	keyboards/ajazz/ak820/ak820_key_override.c:78: uint16_t key = record->keycode;
	mov	dptr,#_ak820_key_override_process_record_10000_635
	lcall	_ak820_outline_0002
;	keyboards/ajazz/ak820/ak820_key_override.c:80: ak820_key_override_sync(mods, layer);
	mov	dptr,#_ak820_key_override_process_PARM_2
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_ak820_key_override_process_PARM_3
	movx	a,@dptr
	mov	r2,a
	mov	dptr,#_ak820_key_override_sync_PARM_2
	movx	@dptr,a
	mov	dpl, r3
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_ak820_key_override_sync
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_key_override.c:81: if (key >= QK_KEY_OVERRIDE_TOGGLE && key <= QK_KEY_OVERRIDE_OFF) {
	mov	ar0,r4
	mov	ar1,r5
	clr	c
	mov	a,r0
	subb	a,#0x5d
	mov	a,r1
	subb	a,#0x7c
	jc	00112$
	mov	a,#0x5f
	subb	a,r0
	mov	a,#0x7c
	subb	a,r1
	jc	00112$
;	free result
;	keyboards/ajazz/ak820/ak820_key_override.c:82: if (record->event.pressed) {
	lcall	_ak820_outline_0007
	jz	00110$
;	keyboards/ajazz/ak820/ak820_key_override.c:83: if (key == QK_KEY_OVERRIDE_ON) enabled = true;
	cjne	r0,#0x5e,00105$
	cjne	r1,#0x7c,00105$
	mov	dptr,#_enabled
	mov	a,#0x01
	movx	@dptr,a
	sjmp	00106$
00105$:
;	keyboards/ajazz/ak820/ak820_key_override.c:84: else if (key == QK_KEY_OVERRIDE_OFF) enabled = false;
	cjne	r0,#0x5f,00102$
	cjne	r1,#0x7c,00102$
	mov	dptr,#_enabled
	clr	a
	movx	@dptr,a
	sjmp	00106$
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:85: else enabled = !enabled;
	mov	dptr,#_enabled
	movx	a,@dptr
	cjne	a,#0x01,00281$
00281$:
	clr	a
	rlc	a
	movx	@dptr,a
00106$:
;	keyboards/ajazz/ak820/ak820_key_override.c:86: if (!enabled) { deactivate(); blocked = true; }
	mov	dptr,#_enabled
	movx	a,@dptr
	jnz	00110$
	lcall	_deactivate
	mov	dptr,#_blocked
	mov	a,#0x01
	movx	@dptr,a
00110$:
;	keyboards/ajazz/ak820/ak820_key_override.c:88: return false;
	mov	dpl, #0x00
	ret
00112$:
;	keyboards/ajazz/ak820/ak820_key_override.c:90: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) return true;
	mov	dptr,#_ak820_key_override_process_record_10000_635
	movx	a,@dptr
	mov	_ak820_key_override_process_sloc2_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_key_override_process_sloc2_1_0 + 1),a
	mov	dpl,_ak820_key_override_process_sloc2_1_0
	mov	dph,(_ak820_key_override_process_sloc2_1_0 + 1)
	inc	dptr
	movx	a,@dptr
	mov	_ak820_key_override_process_sloc0_1_0,a
	clr	c
	subb	a,#0x10
	jnc	00114$
	mov	dpl,_ak820_key_override_process_sloc2_1_0
	mov	dph,(_ak820_key_override_process_sloc2_1_0 + 1)
	movx	a,@dptr
	mov	_ak820_key_override_process_sloc1_1_0,a
	clr	c
	subb	a,#0x08
	jc	00115$
00114$:
	mov	dpl, #0x01
	ret
00115$:
;	keyboards/ajazz/ak820/ak820_key_override.c:91: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
	push	ar2
	mov	a,_ak820_key_override_process_sloc0_1_0
	lcall	_ak820_outline_0198
	mov	_ak820_key_override_process_sloc0_1_0,a
	add	a,_ak820_key_override_process_sloc1_1_0
	mov	_ak820_key_override_process_sloc1_1_0,a
;	keyboards/ajazz/ak820/ak820_key_override.c:92: if (source == id) {
	mov	dptr,#_source
	movx	a,@dptr
	cjne	a,_ak820_key_override_process_sloc1_1_0,00285$
	sjmp	00286$
00285$:
	pop	ar2
	sjmp	00120$
00286$:
	pop	ar2
;	keyboards/ajazz/ak820/ak820_key_override.c:93: if (!record->event.pressed) ak820_key_override_cancel();
	mov	a,#0x05
	add	a, _ak820_key_override_process_sloc2_1_0
	mov	r6,a
	clr	a
	addc	a, (_ak820_key_override_process_sloc2_1_0 + 1)
	mov	r7,a
	lcall	_ak820_outline_0105
	jnz	00118$
	lcall	_ak820_key_override_cancel
00118$:
;	keyboards/ajazz/ak820/ak820_key_override.c:94: return false;
	mov	dpl, #0x00
	ret
00120$:
;	keyboards/ajazz/ak820/ak820_key_override.c:96: if (!record->event.pressed) return true;
	mov	a,#0x05
	add	a, _ak820_key_override_process_sloc2_1_0
	mov	r6,a
	clr	a
	addc	a, (_ak820_key_override_process_sloc2_1_0 + 1)
	mov	r7,a
	lcall	_ak820_outline_0105
	jnz	00122$
	mov	dpl, #0x01
	ret
00122$:
;	keyboards/ajazz/ak820/ak820_key_override.c:97: if (active != NONE && !(entries[active].options & 32) && !(key >= KC_LEFT_CTRL && key <= KC_RIGHT_GUI)) {
	lcall	_ak820_outline_0131
	cjne	r7,#0xff,00289$
	sjmp	00124$
00289$:
	mov	a,r7
	lcall	_ak820_outline_0019
	mov	a,#0x09
	lcall	_ak820_outline_0016
	jb	acc.5,00124$
	clr	c
	mov	a,r0
	subb	a,#0xe0
	mov	a,r1
	subb	a,#0x00
	jc	00123$
	mov	a,#0xe7
	subb	a,r0
	clr	a
	subb	a,r1
	jnc	00124$
;	free result
00123$:
;	keyboards/ajazz/ak820/ak820_key_override.c:98: deactivate(); blocked = true;
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_deactivate
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	mov	dptr,#_blocked
	mov	a,#0x01
	movx	@dptr,a
00124$:
;	keyboards/ajazz/ak820/ak820_key_override.c:100: if (source != NONE || !enabled || !basic(key)) return true;
	mov	dptr,#_source
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00128$
	mov	dptr,#_enabled
	movx	a,@dptr
	jz	00128$
	lcall	_ak820_outline_0134
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_basic
	mov	a, dpl
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	jnz	00178$
00128$:
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_key_override.c:101: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	ret
00178$:
	mov	r7,#0x00
00137$:
	cjne	r7,#0x08,00297$
00297$:
	jnc	00135$
;	keyboards/ajazz/ak820/ak820_key_override.c:102: if (entries[i].trigger == key && (entries[i].options & ENABLED)) {
	push	ar2
	mov	a,r7
	mov	b,#0x0a
	mul	ab
	add	a, #_entries
	mov	r1,a
	mov	a,#(_entries >> 8)
	addc	a, b
	mov	r6,a
	mov	dpl,r1
	mov	dph,r6
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	mov	a,r0
	cjne	a,ar4,00299$
	mov	a,r2
	cjne	a,ar5,00299$
	sjmp	00300$
00299$:
	pop	ar2
	sjmp	00138$
00300$:
	pop	ar2
	mov	a,#0x09
	add	a, r1
	lcall	_ak820_outline_0083
	jnb	acc.7,00138$
;	keyboards/ajazz/ak820/ak820_key_override.c:103: source = id; trigger = key; hidden = blocked = false;
	mov	dptr,#_source
	mov	a,_ak820_key_override_process_sloc1_1_0
	movx	@dptr,a
	mov	dptr,#_trigger
	mov	a,r4
	movx	@dptr,a
	mov	dptr,#_blocked
	clr	a
	movx	@dptr,a
	mov	dptr,#_hidden
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:104: activate(1, mods, layer);
	mov	dptr,#_activate_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	dptr,#_activate_PARM_3
	mov	a,r2
	movx	@dptr,a
	mov	dpl, #0x01
	lcall	_activate
;	keyboards/ajazz/ak820/ak820_key_override.c:105: return false;
	mov	dpl, #0x00
	ret
00138$:
;	keyboards/ajazz/ak820/ak820_key_override.c:101: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
	inc	r7
	sjmp	00137$
00135$:
;	keyboards/ajazz/ak820/ak820_key_override.c:108: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_key_override.c:109: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_key'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:110: uint8_t ak820_key_override_key(void) {
;	-----------------------------------------
;	 function ak820_key_override_key
;	-----------------------------------------
_ak820_key_override_key:
;	keyboards/ajazz/ak820/ak820_key_override.c:111: if (source == NONE || hidden) return 0;
	mov	dptr,#_source
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00122$
	sjmp	00101$
00122$:
	mov	dptr,#_hidden
	movx	a,@dptr
	jz	00102$
00101$:
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:112: return active == NONE ? trigger : (uint8_t)entries[active].replacement;
	lcall	_ak820_outline_0131
	cjne	r7,#0xff,00106$
	mov	dptr,#_trigger
	movx	a,@dptr
	mov	r6,a
	sjmp	00107$
00106$:
	lcall	_ak820_outline_0040
	mov	r7,a
	lcall	_ak820_outline_0194
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r6,a
00107$:
	mov	dpl, r6
;	keyboards/ajazz/ak820/ak820_key_override.c:113: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_mods'
;------------------------------------------------------------
;mods          Allocated with name '_ak820_key_override_mods_mods_10000_660'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:114: uint8_t ak820_key_override_mods(uint8_t mods) {
;	-----------------------------------------
;	 function ak820_key_override_mods
;	-----------------------------------------
_ak820_key_override_mods:
	mov	a,dpl
	mov	dptr,#_ak820_key_override_mods_mods_10000_660
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_key_override.c:115: if (active == NONE) return mods;
	lcall	_ak820_outline_0131
	cjne	r7,#0xff,00102$
	mov	dptr,#_ak820_key_override_mods_mods_10000_660
	movx	a,@dptr
	mov	dpl,a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_key_override.c:116: return (mods & ~entries[active].suppressed_mods) | replacement_mods(entries[active].replacement);
	mov	a,r7
	lcall	_ak820_outline_0019
	mov	a,#0x08
	lcall	_ak820_outline_0016
	mov	r5,a
	xrl	ar5,#0xff
	mov	dptr,#_ak820_key_override_mods_mods_10000_660
	movx	a,@dptr
	anl	ar5,a
	lcall	_ak820_outline_0107
	inc	dptr
	lcall	_ak820_outline_0006
	push	ar5
	lcall	_replacement_mods
	mov	r7, dpl
	pop	ar5
	mov	a,r7
	orl	ar5,a
	mov	dpl, r5
;	keyboards/ajazz/ak820/ak820_key_override.c:117: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_key_override_enabled'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_key_override.c:118: bool ak820_key_override_enabled(void) { return enabled; }
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__source:
	.db #0xff	; 255
__xinit__active:
	.db #0xff	; 255
__xinit__enabled:
	.db #0x01	;  1
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0002
	.globl _ak820_outline_0006
	.globl _ak820_outline_0007
	.globl _ak820_outline_0016
	.globl _ak820_outline_0019
	.globl _ak820_outline_0020
	.globl _ak820_outline_0037
	.globl _ak820_outline_0040
	.globl _ak820_outline_0057
	.globl _ak820_outline_0065
	.globl _ak820_outline_0077
	.globl _ak820_outline_0083
	.globl _ak820_outline_0105
	.globl _ak820_outline_0107
	.globl _ak820_outline_0114
	.globl _ak820_outline_0115
	.globl _ak820_outline_0130
	.globl _ak820_outline_0131
	.globl _ak820_outline_0134
	.globl _ak820_outline_0141
	.globl _ak820_outline_0145
	.globl _ak820_outline_0146
	.globl _ak820_outline_0154
	.globl _ak820_outline_0194
	.globl _ak820_outline_0198
	.globl _ak820_outline_0199

	.area CSEG (CODE)
; function ak820_outline_0019
_ak820_outline_0019:
	mov	b,#0x0a
	mul	ab
	add	a,#_entries
	mov	r6,a
	mov	a,#(_entries>>8)
	addc	a,b
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0020
_ak820_outline_0020:
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0040
_ak820_outline_0040:
	mov	a,r7
	mov	b,#0x0a
	mul	ab
	add	a,#_entries
	mov	r5,a
	mov	a,#(_entries>>8)
	addc	a,b
	ret

	.area CSEG (CODE)
; function ak820_outline_0083
_ak820_outline_0083:
	mov	dpl,a
	clr	a
	addc	a,r6
	mov	dph,a
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0131
_ak820_outline_0131:
	mov	dptr,#_active
	movx	a,@dptr
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0141
_ak820_outline_0141:
	mov	dptr,#_ak820_key_override_sync_mods_10000_630
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_ak820_key_override_sync_PARM_2
	movx	a,@dptr
	mov	r5,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0194
_ak820_outline_0194:
	mov	dpl,r5
	mov	dph,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0199
_ak820_outline_0199:
	mov	a,r5
	movx	@dptr,a
	mov	dpl,r7
	ret
