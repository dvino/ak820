                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006ED                         85 _eeprom_read_word_addr_10000_91:
      0006ED                         86 	.ds 3
      0006F0                         87 _eeprom_read_word_ret_10000_92:
      0006F0                         88 	.ds 2
      0006F2                         89 _eeprom_read_dword_addr_10000_93:
      0006F2                         90 	.ds 3
      0006F5                         91 _eeprom_read_dword_ret_10000_94:
      0006F5                         92 	.ds 4
      0006F9                         93 _eeprom_write_byte_PARM_2:
      0006F9                         94 	.ds 1
      0006FA                         95 _eeprom_write_byte_addr_10000_95:
      0006FA                         96 	.ds 3
      0006FD                         97 _eeprom_write_word_PARM_2:
      0006FD                         98 	.ds 2
      0006FF                         99 _eeprom_write_word_addr_10000_97:
      0006FF                        100 	.ds 3
      000702                        101 _eeprom_write_dword_PARM_2:
      000702                        102 	.ds 4
      000706                        103 _eeprom_write_dword_addr_10000_99:
      000706                        104 	.ds 3
      000709                        105 _eeprom_update_byte_PARM_2:
      000709                        106 	.ds 1
      00070A                        107 _eeprom_update_byte_addr_10000_107:
      00070A                        108 	.ds 3
      00070D                        109 _eeprom_update_word_PARM_2:
      00070D                        110 	.ds 2
      00070F                        111 _eeprom_update_word_addr_10000_111:
      00070F                        112 	.ds 3
      000712                        113 _eeprom_update_dword_PARM_2:
      000712                        114 	.ds 4
      000716                        115 _eeprom_update_dword_addr_10000_115:
      000716                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      0053EF                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      0053EF 12 49 D5         [24]  170 	lcall	_ak820_outline_0041
      0053F2 90 06 ED         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0053F5 12 38 21         [24]  172 	lcall	_ak820_outline_0022
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      0053F8 90 06 F0         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0053FB 12 55 F6         [24]  175 	lcall	_ak820_outline_0166
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      0053FE 90 06 ED         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005401 12 55 AA         [24]  178 	lcall	_ak820_outline_0013
      005404 90 05 F3         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005407 ED               [12]  180 	mov	a,r5
      005408 12 38 21         [24]  181 	lcall	_ak820_outline_0022
      00540B 90 05 F6         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00540E 12 55 EF         [24]  183 	lcall	_ak820_outline_0117
      005411 90 06 F0         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005414 12 47 71         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      005417 90 06 F0         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00541A 12 55 E6         [24]  188 	lcall	_ak820_outline_0099
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      00541D 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      00541E                        201 _eeprom_read_dword:
      00541E 12 49 D5         [24]  202 	lcall	_ak820_outline_0041
      005421 90 06 F2         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005424 12 38 21         [24]  204 	lcall	_ak820_outline_0022
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      005427 90 06 F5         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00542A 12 55 BB         [24]  207 	lcall	_ak820_outline_0056
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      00542D 90 06 F2         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005430 12 55 AA         [24]  210 	lcall	_ak820_outline_0013
      005433 90 05 F3         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005436 ED               [12]  212 	mov	a,r5
      005437 12 38 21         [24]  213 	lcall	_ak820_outline_0022
      00543A 90 05 F6         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00543D 74 04            [12]  215 	mov	a,#0x04
      00543F 12 38 A6         [24]  216 	lcall	_ak820_outline_0135
      005442 90 06 F5         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005445 12 47 71         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      005448 90 06 F5         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00544B 12 55 C4         [24]  221 	lcall	_ak820_outline_0060
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      00544E 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      00544F                        234 _eeprom_write_byte:
      00544F 12 49 D5         [24]  235 	lcall	_ak820_outline_0041
      005452 90 06 FA         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005455 12 38 21         [24]  237 	lcall	_ak820_outline_0022
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      005458 90 06 FA         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      00545B 12 55 93         [24]  240 	lcall	_ak820_outline_0005
      00545E 74 01            [12]  241 	mov	a,#0x01
      005460 12 38 A6         [24]  242 	lcall	_ak820_outline_0135
      005463 90 06 F9         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005466 02 47 FD         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005469                        256 _eeprom_write_word:
      005469 12 49 D5         [24]  257 	lcall	_ak820_outline_0041
      00546C 90 06 FF         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00546F 12 38 21         [24]  259 	lcall	_ak820_outline_0022
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      005472 90 06 FF         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005475 12 55 93         [24]  262 	lcall	_ak820_outline_0005
      005478 12 55 EF         [24]  263 	lcall	_ak820_outline_0117
      00547B 90 06 FD         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      00547E 02 47 FD         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      005481                        277 _eeprom_write_dword:
      005481 12 49 D5         [24]  278 	lcall	_ak820_outline_0041
      005484 90 07 06         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005487 12 38 21         [24]  280 	lcall	_ak820_outline_0022
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      00548A 90 07 06         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00548D 12 55 93         [24]  283 	lcall	_ak820_outline_0005
      005490 74 04            [12]  284 	mov	a,#0x04
      005492 12 38 A6         [24]  285 	lcall	_ak820_outline_0135
      005495 90 07 02         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005498 02 47 FD         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      00549B                        307 _eeprom_update_byte:
      00549B C0 07            [24]  308 	push	ar7
      00549D C0 06            [24]  309 	push	ar6
      00549F C0 05            [24]  310 	push	ar5
      0054A1 C0 04            [24]  311 	push	ar4
      0054A3 12 49 D5         [24]  312 	lcall	_ak820_outline_0041
      0054A6 90 07 0A         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0054A9 12 38 21         [24]  314 	lcall	_ak820_outline_0022
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      0054AC 90 07 0A         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0054AF 12 55 84         [24]  317 	lcall	_ak820_outline_0001
      0054B2 12 47 36         [24]  318 	lcall	_eeprom_read_byte
      0054B5 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      0054B7 90 07 09         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      0054BA E0               [24]  322 	movx	a,@dptr
      0054BB FE               [12]  323 	mov	r6,a
      0054BC EF               [12]  324 	mov	a,r7
      0054BD B5 06 02         [24]  325 	cjne	a,ar6,00112$
      0054C0 80 35            [24]  326 	sjmp	00103$
      0054C2                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      0054C2 90 07 0A         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0054C5 12 38 50         [24]  330 	lcall	_ak820_outline_0065
      0054C8 A3               [24]  331 	inc	dptr
      0054C9 E0               [24]  332 	movx	a,@dptr
      0054CA FF               [12]  333 	mov	r7,a
      0054CB 90 06 F9         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      0054CE EE               [12]  335 	mov	a,r6
      0054CF 12 38 7A         [24]  336 	lcall	_ak820_outline_0109
      0054D2 8F F0            [24]  337 	mov	b, r7
      0054D4 C0 07            [24]  338 	push	ar7
      0054D6 C0 06            [24]  339 	push	ar6
      0054D8 C0 05            [24]  340 	push	ar5
      0054DA C0 04            [24]  341 	push	ar4
      0054DC C0 03            [24]  342 	push	ar3
      0054DE C0 02            [24]  343 	push	ar2
      0054E0 C0 01            [24]  344 	push	ar1
      0054E2 C0 00            [24]  345 	push	ar0
      0054E4 12 54 4F         [24]  346 	lcall	_eeprom_write_byte
      0054E7 D0 00            [24]  347 	pop	ar0
      0054E9 D0 01            [24]  348 	pop	ar1
      0054EB D0 02            [24]  349 	pop	ar2
      0054ED D0 03            [24]  350 	pop	ar3
      0054EF D0 04            [24]  351 	pop	ar4
      0054F1 D0 05            [24]  352 	pop	ar5
      0054F3 D0 06            [24]  353 	pop	ar6
      0054F5 D0 07            [24]  354 	pop	ar7
      0054F7                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      0054F7 D0 04            [24]  357 	pop	ar4
      0054F9 D0 05            [24]  358 	pop	ar5
      0054FB D0 06            [24]  359 	pop	ar6
      0054FD D0 07            [24]  360 	pop	ar7
      0054FF 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      005500                        373 _eeprom_update_word:
      005500 12 49 D5         [24]  374 	lcall	_ak820_outline_0041
      005503 90 07 0F         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005506 12 38 21         [24]  376 	lcall	_ak820_outline_0022
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005509 90 07 0F         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00550C 12 55 84         [24]  379 	lcall	_ak820_outline_0001
      00550F 12 53 EF         [24]  380 	lcall	_eeprom_read_word
      005512 12 4A 1E         [24]  381 	lcall	_ak820_outline_0144
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      005515 90 07 0D         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      005518 12 38 50         [24]  384 	lcall	_ak820_outline_0065
      00551B EE               [12]  385 	mov	a,r6
      00551C B5 04 05         [24]  386 	cjne	a,ar4,00112$
      00551F EF               [12]  387 	mov	a,r7
      005520 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      005523 22               [24]  389 	ret
      005524                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      005524 90 07 0F         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005527 E0               [24]  393 	movx	a,@dptr
      005528 FB               [12]  394 	mov	r3,a
      005529 A3               [24]  395 	inc	dptr
      00552A 12 38 39         [24]  396 	lcall	_ak820_outline_0057
      00552D 90 06 FD         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      005530 12 38 5C         [24]  398 	lcall	_ak820_outline_0079
      005533 8B 82            [24]  399 	mov	dpl, r3
      005535 8E 83            [24]  400 	mov	dph, r6
      005537 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      005539 02 54 69         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      00553C                        415 _eeprom_update_dword:
      00553C 12 49 D5         [24]  416 	lcall	_ak820_outline_0041
      00553F 90 07 16         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005542 12 38 21         [24]  418 	lcall	_ak820_outline_0022
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      005545 90 07 16         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005548 12 55 84         [24]  421 	lcall	_ak820_outline_0001
      00554B 12 54 1E         [24]  422 	lcall	_eeprom_read_dword
      00554E 12 55 D5         [24]  423 	lcall	_ak820_outline_0062
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      005551 90 07 12         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      005554 E0               [24]  426 	movx	a,@dptr
      005555 F8               [12]  427 	mov	r0,a
      005556 A3               [24]  428 	inc	dptr
      005557 12 55 DD         [24]  429 	lcall	_ak820_outline_0098
      00555A EC               [12]  430 	mov	a,r4
      00555B B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      00555E ED               [12]  432 	mov	a,r5
      00555F B5 01 09         [24]  433 	cjne	a,ar1,00112$
      005562 EE               [12]  434 	mov	a,r6
      005563 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      005566 EF               [12]  436 	mov	a,r7
      005567 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      00556A 22               [24]  438 	ret
      00556B                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      00556B 90 07 16         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00556E 12 55 AA         [24]  442 	lcall	_ak820_outline_0013
      005571 90 07 02         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005574 E8               [12]  444 	mov	a,r0
      005575 F0               [24]  445 	movx	@dptr,a
      005576 E9               [12]  446 	mov	a,r1
      005577 A3               [24]  447 	inc	dptr
      005578 F0               [24]  448 	movx	@dptr,a
      005579 EA               [12]  449 	mov	a,r2
      00557A A3               [24]  450 	inc	dptr
      00557B F0               [24]  451 	movx	@dptr,a
      00557C EB               [12]  452 	mov	a,r3
      00557D A3               [24]  453 	inc	dptr
      00557E 12 55 B3         [24]  454 	lcall	_ak820_outline_0038
                                    455 ;	drivers/eeprom/eeprom_driver.c:101: }
      005581 02 54 81         [24]  456 	ljmp	_eeprom_write_dword
                                    457 	.area CSEG    (CODE)
                                    458 	.area CONST   (CODE)
                                    459 	.area XINIT   (CODE)
                                    460 	.area CABS    (ABS,CODE)
                                    461 
                                    462 ; Experimental exact instruction outlining.
                                    463 	.globl _ak820_outline_0001
                                    464 	.globl _ak820_outline_0005
                                    465 	.globl _ak820_outline_0013
                                    466 	.globl _ak820_outline_0022
                                    467 	.globl _ak820_outline_0038
                                    468 	.globl _ak820_outline_0041
                                    469 	.globl _ak820_outline_0056
                                    470 	.globl _ak820_outline_0057
                                    471 	.globl _ak820_outline_0060
                                    472 	.globl _ak820_outline_0062
                                    473 	.globl _ak820_outline_0065
                                    474 	.globl _ak820_outline_0079
                                    475 	.globl _ak820_outline_0098
                                    476 	.globl _ak820_outline_0099
                                    477 	.globl _ak820_outline_0109
                                    478 	.globl _ak820_outline_0117
                                    479 	.globl _ak820_outline_0135
                                    480 	.globl _ak820_outline_0144
                                    481 	.globl _ak820_outline_0166
                                    482 
                                    483 	.area CSEG (CODE)
                                    484 ; function ak820_outline_0001
      005584                        485 _ak820_outline_0001:
      005584 E0               [24]  486 	movx	a,@dptr
      005585 FD               [12]  487 	mov	r5,a
      005586 A3               [24]  488 	inc	dptr
      005587 E0               [24]  489 	movx	a,@dptr
      005588 FE               [12]  490 	mov	r6,a
      005589 A3               [24]  491 	inc	dptr
      00558A E0               [24]  492 	movx	a,@dptr
      00558B FF               [12]  493 	mov	r7,a
      00558C 8D 82            [24]  494 	mov	dpl,r5
      00558E 8E 83            [24]  495 	mov	dph,r6
      005590 8F F0            [24]  496 	mov	b,r7
      005592 22               [24]  497 	ret
                                    498 
                                    499 	.area CSEG (CODE)
                                    500 ; function ak820_outline_0005
      005593                        501 _ak820_outline_0005:
      005593 E0               [24]  502 	movx	a,@dptr
      005594 FD               [12]  503 	mov	r5,a
      005595 A3               [24]  504 	inc	dptr
      005596 E0               [24]  505 	movx	a,@dptr
      005597 FE               [12]  506 	mov	r6,a
      005598 A3               [24]  507 	inc	dptr
      005599 E0               [24]  508 	movx	a,@dptr
      00559A FF               [12]  509 	mov	r7,a
      00559B 90 05 FC         [24]  510 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00559E ED               [12]  511 	mov	a,r5
      00559F F0               [24]  512 	movx	@dptr,a
      0055A0 EE               [12]  513 	mov	a,r6
      0055A1 A3               [24]  514 	inc	dptr
      0055A2 F0               [24]  515 	movx	@dptr,a
      0055A3 EF               [12]  516 	mov	a,r7
      0055A4 A3               [24]  517 	inc	dptr
      0055A5 F0               [24]  518 	movx	@dptr,a
      0055A6 90 05 FF         [24]  519 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0055A9 22               [24]  520 	ret
                                    521 
                                    522 	.area CSEG (CODE)
                                    523 ; function ak820_outline_0013
      0055AA                        524 _ak820_outline_0013:
      0055AA E0               [24]  525 	movx	a,@dptr
      0055AB FD               [12]  526 	mov	r5,a
      0055AC A3               [24]  527 	inc	dptr
      0055AD E0               [24]  528 	movx	a,@dptr
      0055AE FE               [12]  529 	mov	r6,a
      0055AF A3               [24]  530 	inc	dptr
      0055B0 E0               [24]  531 	movx	a,@dptr
      0055B1 FF               [12]  532 	mov	r7,a
      0055B2 22               [24]  533 	ret
                                    534 
                                    535 	.area CSEG (CODE)
                                    536 ; function ak820_outline_0038
      0055B3                        537 _ak820_outline_0038:
      0055B3 F0               [24]  538 	movx	@dptr,a
      0055B4 8D 82            [24]  539 	mov	dpl,r5
      0055B6 8E 83            [24]  540 	mov	dph,r6
      0055B8 8F F0            [24]  541 	mov	b,r7
      0055BA 22               [24]  542 	ret
                                    543 
                                    544 	.area CSEG (CODE)
                                    545 ; function ak820_outline_0056
      0055BB                        546 _ak820_outline_0056:
      0055BB E4               [12]  547 	clr	a
      0055BC F0               [24]  548 	movx	@dptr,a
      0055BD A3               [24]  549 	inc	dptr
      0055BE F0               [24]  550 	movx	@dptr,a
      0055BF A3               [24]  551 	inc	dptr
      0055C0 F0               [24]  552 	movx	@dptr,a
      0055C1 A3               [24]  553 	inc	dptr
      0055C2 F0               [24]  554 	movx	@dptr,a
      0055C3 22               [24]  555 	ret
                                    556 
                                    557 	.area CSEG (CODE)
                                    558 ; function ak820_outline_0060
      0055C4                        559 _ak820_outline_0060:
      0055C4 E0               [24]  560 	movx	a,@dptr
      0055C5 FC               [12]  561 	mov	r4,a
      0055C6 A3               [24]  562 	inc	dptr
      0055C7 E0               [24]  563 	movx	a,@dptr
      0055C8 FD               [12]  564 	mov	r5,a
      0055C9 A3               [24]  565 	inc	dptr
      0055CA E0               [24]  566 	movx	a,@dptr
      0055CB FE               [12]  567 	mov	r6,a
      0055CC A3               [24]  568 	inc	dptr
      0055CD E0               [24]  569 	movx	a,@dptr
      0055CE 8C 82            [24]  570 	mov	dpl,r4
      0055D0 8D 83            [24]  571 	mov	dph,r5
      0055D2 8E F0            [24]  572 	mov	b,r6
      0055D4 22               [24]  573 	ret
                                    574 
                                    575 	.area CSEG (CODE)
                                    576 ; function ak820_outline_0062
      0055D5                        577 _ak820_outline_0062:
      0055D5 AC 82            [24]  578 	mov	r4,dpl
      0055D7 AD 83            [24]  579 	mov	r5,dph
      0055D9 AE F0            [24]  580 	mov	r6,b
      0055DB FF               [12]  581 	mov	r7,a
      0055DC 22               [24]  582 	ret
                                    583 
                                    584 	.area CSEG (CODE)
                                    585 ; function ak820_outline_0098
      0055DD                        586 _ak820_outline_0098:
      0055DD E0               [24]  587 	movx	a,@dptr
      0055DE F9               [12]  588 	mov	r1,a
      0055DF A3               [24]  589 	inc	dptr
      0055E0 E0               [24]  590 	movx	a,@dptr
      0055E1 FA               [12]  591 	mov	r2,a
      0055E2 A3               [24]  592 	inc	dptr
      0055E3 E0               [24]  593 	movx	a,@dptr
      0055E4 FB               [12]  594 	mov	r3,a
      0055E5 22               [24]  595 	ret
                                    596 
                                    597 	.area CSEG (CODE)
                                    598 ; function ak820_outline_0099
      0055E6                        599 _ak820_outline_0099:
      0055E6 E0               [24]  600 	movx	a,@dptr
      0055E7 FE               [12]  601 	mov	r6,a
      0055E8 A3               [24]  602 	inc	dptr
      0055E9 E0               [24]  603 	movx	a,@dptr
      0055EA 8E 82            [24]  604 	mov	dpl,r6
      0055EC F5 83            [12]  605 	mov	dph,a
      0055EE 22               [24]  606 	ret
                                    607 
                                    608 	.area CSEG (CODE)
                                    609 ; function ak820_outline_0117
      0055EF                        610 _ak820_outline_0117:
      0055EF 74 02            [12]  611 	mov	a,#0x02
      0055F1 F0               [24]  612 	movx	@dptr,a
      0055F2 E4               [12]  613 	clr	a
      0055F3 A3               [24]  614 	inc	dptr
      0055F4 F0               [24]  615 	movx	@dptr,a
      0055F5 22               [24]  616 	ret
                                    617 
                                    618 	.area CSEG (CODE)
                                    619 ; function ak820_outline_0166
      0055F6                        620 _ak820_outline_0166:
      0055F6 E4               [12]  621 	clr	a
      0055F7 F0               [24]  622 	movx	@dptr,a
      0055F8 A3               [24]  623 	inc	dptr
      0055F9 F0               [24]  624 	movx	@dptr,a
      0055FA 22               [24]  625 	ret
