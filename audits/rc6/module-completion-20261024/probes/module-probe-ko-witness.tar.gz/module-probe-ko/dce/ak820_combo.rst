                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _input_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _output_sloc0_1_0:
      000001                        542 	.ds 1
      000002                        543 _ak820_combo_valid_sloc0_1_0:
      000002                        544 	.ds 1
      000003                        545 _ak820_combo_process_sloc0_1_0:
      000003                        546 	.ds 1
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      000422                        555 _input_code_10000_594:
      000422                        556 	.ds 2
      000424                        557 _output_code_10000_596:
      000424                        558 	.ds 2
      000426                        559 _combos:
      000426                        560 	.ds 32
      000446                        561 _saved:
      000446                        562 	.ds 9
      00044F                        563 _active:
      00044F                        564 	.ds 1
      000450                        565 _ak820_combo_valid_entry_10000_598:
      000450                        566 	.ds 2
      000452                        567 _ak820_combo_reload_entry_30000_610:
      000452                        568 	.ds 10
      00045C                        569 _ak820_combo_tick_now_10000_615:
      00045C                        570 	.ds 2
      00045E                        571 _ak820_combo_process_record_10000_618:
      00045E                        572 	.ds 2
      000460                        573 _ak820_combo_process_eligible_10001_633:
      000460                        574 	.ds 1
      000461                        575 _ak820_combo_process_i_40001_636:
      000461                        576 	.ds 1
      000462                        577 _ak820_combo_process_a_50001_637:
      000462                        578 	.ds 1
      000463                        579 _ak820_combo_process_b_50001_637:
      000463                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; absolute external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XABS    (ABS,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; initialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XISEG   (XDATA)
      000E65                        589 _first:
      000E65                        590 	.ds 1
      000E66                        591 _second:
      000E66                        592 	.ds 1
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    621 ;------------------------------------------------------------
                                    622 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    623 ;------------------------------------------------------------
                                    624 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function input
                                    635 ;	-----------------------------------------
      003468                        636 _input:
      003468 12 38 86         [24]  637 	lcall	_ak820_outline_0114
      00346B 90 04 22         [24]  638 	mov	dptr,#_input_code_10000_594
      00346E 12 38 8B         [24]  639 	lcall	_ak820_outline_0115
      003471 90 04 22         [24]  640 	mov	dptr,#_input_code_10000_594
      003474 12 38 39         [24]  641 	lcall	_ak820_outline_0057
      003477 C3               [12]  642 	clr	c
      003478 EE               [12]  643 	mov	a,r6
      003479 94 04            [12]  644 	subb	a,#0x04
      00347B EF               [12]  645 	mov	a,r7
      00347C 94 00            [12]  646 	subb	a,#0x00
      00347E 40 07            [24]  647 	jc	00103$
      003480 74 A4            [12]  648 	mov	a,#0xa4
      003482 9E               [12]  649 	subb	a,r6
      003483 E4               [12]  650 	clr	a
      003484 9F               [12]  651 	subb	a,r7
      003485 50 04            [24]  652 	jnc	00104$
                                    653 ;	free result
      003487                        654 00103$:
                                    655 ;	assignBit
      003487 C2 00            [12]  656 	clr	_input_sloc0_1_0
      003489 80 02            [24]  657 	sjmp	00105$
      00348B                        658 00104$:
                                    659 ;	assignBit
      00348B D2 00            [12]  660 	setb	_input_sloc0_1_0
      00348D                        661 00105$:
      00348D A2 00            [12]  662 	mov	c,_input_sloc0_1_0
      00348F 12 38 B5         [24]  663 	lcall	_ak820_outline_0154
      003492 22               [24]  664 	ret
                                    665 ;------------------------------------------------------------
                                    666 ;Allocation info for local variables in function 'output'
                                    667 ;------------------------------------------------------------
                                    668 ;code          Allocated with name '_output_code_10000_596'
                                    669 ;basic         Allocated with name '_output_basic_10000_597'
                                    670 ;------------------------------------------------------------
                                    671 ;	keyboards/ajazz/ak820/ak820_combo.c:16: static bool output(uint16_t code) {
                                    672 ;	-----------------------------------------
                                    673 ;	 function output
                                    674 ;	-----------------------------------------
      003493                        675 _output:
      003493 12 38 86         [24]  676 	lcall	_ak820_outline_0114
      003496 90 04 24         [24]  677 	mov	dptr,#_output_code_10000_596
      003499 12 38 8B         [24]  678 	lcall	_ak820_outline_0115
                                    679 ;	keyboards/ajazz/ak820/ak820_combo.c:17: uint8_t basic = code;
      00349C 90 04 24         [24]  680 	mov	dptr,#_output_code_10000_596
      00349F 12 38 39         [24]  681 	lcall	_ak820_outline_0057
      0034A2 8E 05            [24]  682 	mov	ar5,r6
                                    683 ;	keyboards/ajazz/ak820/ak820_combo.c:18: return code < QK_MOD_TAP && (input(basic) || (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI));
      0034A4 74 E0            [12]  684 	mov	a,#0x100 - 0x20
      0034A6 2F               [12]  685 	add	a,r7
      0034A7 40 1B            [24]  686 	jc	00103$
      0034A9 8D 06            [24]  687 	mov	ar6,r5
      0034AB 7F 00            [12]  688 	mov	r7,#0x00
      0034AD 12 38 90         [24]  689 	lcall	_ak820_outline_0126
      0034B0 C0 05            [24]  690 	push	ar5
      0034B2 91 68            [12]  691 	acall	_input
      0034B4 E5 82            [12]  692 	mov	a, dpl
      0034B6 D0 05            [24]  693 	pop	ar5
      0034B8 70 0E            [24]  694 	jnz	00104$
      0034BA BD E0 00         [24]  695 	cjne	r5,#0xe0,00135$
      0034BD                        696 00135$:
      0034BD 40 05            [24]  697 	jc	00103$
      0034BF ED               [12]  698 	mov	a,r5
      0034C0 24 18            [12]  699 	add	a,#0xff - 0xe7
      0034C2 50 04            [24]  700 	jnc	00104$
                                    701 ;	free result
      0034C4                        702 00103$:
                                    703 ;	assignBit
      0034C4 C2 01            [12]  704 	clr	_output_sloc0_1_0
      0034C6 80 02            [24]  705 	sjmp	00105$
      0034C8                        706 00104$:
                                    707 ;	assignBit
      0034C8 D2 01            [12]  708 	setb	_output_sloc0_1_0
      0034CA                        709 00105$:
      0034CA A2 01            [12]  710 	mov	c,_output_sloc0_1_0
      0034CC 12 38 B5         [24]  711 	lcall	_ak820_outline_0154
                                    712 ;	keyboards/ajazz/ak820/ak820_combo.c:19: }
      0034CF 22               [24]  713 	ret
                                    714 ;------------------------------------------------------------
                                    715 ;Allocation info for local variables in function 'ak820_combo_valid'
                                    716 ;------------------------------------------------------------
                                    717 ;entry         Allocated with name '_ak820_combo_valid_entry_10000_598'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_combo.c:25: bool ak820_combo_valid(const vial_combo_entry_t AK820_STATE_MEM *entry) {
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_combo_valid
                                    722 ;	-----------------------------------------
      0034D0                        723 _ak820_combo_valid:
      0034D0 12 38 86         [24]  724 	lcall	_ak820_outline_0114
      0034D3 90 04 50         [24]  725 	mov	dptr,#_ak820_combo_valid_entry_10000_598
      0034D6 12 38 8B         [24]  726 	lcall	_ak820_outline_0115
                                    727 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[2] || entry->input[3]) return false;
      0034D9 90 04 50         [24]  728 	mov	dptr,#_ak820_combo_valid_entry_10000_598
      0034DC 12 37 F7         [24]  729 	lcall	_ak820_outline_0006
      0034DF A3               [24]  730 	inc	dptr
      0034E0 A3               [24]  731 	inc	dptr
      0034E1 A3               [24]  732 	inc	dptr
      0034E2 A3               [24]  733 	inc	dptr
      0034E3 E0               [24]  734 	movx	a,@dptr
      0034E4 FC               [12]  735 	mov	r4,a
      0034E5 A3               [24]  736 	inc	dptr
      0034E6 E0               [24]  737 	movx	a,@dptr
      0034E7 4C               [12]  738 	orl	a,r4
      0034E8 70 0B            [24]  739 	jnz	00101$
      0034EA 74 06            [12]  740 	mov	a,#0x06
      0034EC 12 38 0E         [24]  741 	lcall	_ak820_outline_0016
      0034EF FC               [12]  742 	mov	r4,a
      0034F0 A3               [24]  743 	inc	dptr
      0034F1 E0               [24]  744 	movx	a,@dptr
      0034F2 4C               [12]  745 	orl	a,r4
      0034F3 60 04            [24]  746 	jz	00102$
      0034F5                        747 00101$:
      0034F5 75 82 00         [24]  748 	mov	dpl, #0x00
      0034F8 22               [24]  749 	ret
      0034F9                        750 00102$:
                                    751 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      0034F9 8E 04            [24]  752 	mov	ar4,r6
      0034FB 8F 05            [24]  753 	mov	ar5,r7
      0034FD 12 38 31         [24]  754 	lcall	_ak820_outline_0037
      003500 FA               [12]  755 	mov	r2,a
      003501 A3               [24]  756 	inc	dptr
      003502 E0               [24]  757 	movx	a,@dptr
      003503 FB               [12]  758 	mov	r3,a
      003504 12 38 A1         [24]  759 	lcall	_ak820_outline_0134
      003507 12 38 50         [24]  760 	lcall	_ak820_outline_0065
      00350A EA               [12]  761 	mov	a,r2
      00350B 4C               [12]  762 	orl	a,r4
      00350C F8               [12]  763 	mov	r0,a
      00350D EB               [12]  764 	mov	a,r3
      00350E 4D               [12]  765 	orl	a,r5
      00350F 48               [12]  766 	orl	a,r0
      003510 70 12            [24]  767 	jnz	00105$
      003512 74 08            [12]  768 	mov	a,#0x08
      003514 12 38 0E         [24]  769 	lcall	_ak820_outline_0016
      003517 F8               [12]  770 	mov	r0,a
      003518 A3               [24]  771 	inc	dptr
      003519 E0               [24]  772 	movx	a,@dptr
      00351A 48               [12]  773 	orl	a,r0
      00351B B4 01 00         [24]  774 	cjne	a,#0x01,00152$
      00351E                        775 00152$:
      00351E 92 02            [24]  776 	mov  _ak820_combo_valid_sloc0_1_0,c
      003520 12 38 B5         [24]  777 	lcall	_ak820_outline_0154
      003523 22               [24]  778 	ret
      003524                        779 00105$:
                                    780 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (entry->input[0] == entry->input[1]) return false;
      003524 EC               [12]  781 	mov	a,r4
      003525 B5 02 08         [24]  782 	cjne	a,ar2,00107$
      003528 ED               [12]  783 	mov	a,r5
      003529 B5 03 04         [24]  784 	cjne	a,ar3,00107$
      00352C 75 82 00         [24]  785 	mov	dpl, #0x00
      00352F 22               [24]  786 	ret
      003530                        787 00107$:
                                    788 ;	keyboards/ajazz/ak820/ak820_combo.c:29: if (!input(entry->input[0])) return false;
      003530 12 38 A1         [24]  789 	lcall	_ak820_outline_0134
      003533 C0 07            [24]  790 	push	ar7
      003535 C0 06            [24]  791 	push	ar6
      003537 C0 03            [24]  792 	push	ar3
      003539 C0 02            [24]  793 	push	ar2
      00353B 91 68            [12]  794 	acall	_input
      00353D E5 82            [12]  795 	mov	a, dpl
      00353F D0 02            [24]  796 	pop	ar2
      003541 D0 03            [24]  797 	pop	ar3
      003543 D0 06            [24]  798 	pop	ar6
      003545 D0 07            [24]  799 	pop	ar7
      003547 70 03            [24]  800 	jnz	00109$
      003549 F5 82            [12]  801 	mov	dpl,a
      00354B 22               [24]  802 	ret
      00354C                        803 00109$:
                                    804 ;	keyboards/ajazz/ak820/ak820_combo.c:30: if (!input(entry->input[1])) return false;
      00354C 12 38 B0         [24]  805 	lcall	_ak820_outline_0146
      00354F C0 07            [24]  806 	push	ar7
      003551 C0 06            [24]  807 	push	ar6
      003553 91 68            [12]  808 	acall	_input
      003555 E5 82            [12]  809 	mov	a, dpl
      003557 D0 06            [24]  810 	pop	ar6
      003559 D0 07            [24]  811 	pop	ar7
      00355B 70 03            [24]  812 	jnz	00111$
      00355D F5 82            [12]  813 	mov	dpl,a
      00355F 22               [24]  814 	ret
      003560                        815 00111$:
                                    816 ;	keyboards/ajazz/ak820/ak820_combo.c:31: return output(entry->output);
      003560 74 08            [12]  817 	mov	a,#0x08
      003562 12 38 29         [24]  818 	lcall	_ak820_outline_0036
      003565 12 37 F7         [24]  819 	lcall	_ak820_outline_0006
                                    820 ;	keyboards/ajazz/ak820/ak820_combo.c:32: }
      003568 81 93            [12]  821 	ajmp	_output
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    824 ;------------------------------------------------------------
                                    825 ;	keyboards/ajazz/ak820/ak820_combo.c:35: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    826 ;	-----------------------------------------
                                    827 ;	 function ak820_combo_cancel
                                    828 ;	-----------------------------------------
      00356A                        829 _ak820_combo_cancel:
      00356A 90 0E 66         [24]  830 	mov	dptr,#_second
      00356D 74 FF            [12]  831 	mov	a,#0xff
      00356F F0               [24]  832 	movx	@dptr,a
      003570 90 0E 65         [24]  833 	mov	dptr,#_first
      003573 F0               [24]  834 	movx	@dptr,a
      003574 90 04 4F         [24]  835 	mov	dptr,#_active
      003577 E4               [12]  836 	clr	a
      003578 F0               [24]  837 	movx	@dptr,a
      003579 22               [24]  838 	ret
                                    839 ;------------------------------------------------------------
                                    840 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    841 ;------------------------------------------------------------
                                    842 ;i             Allocated with name '_ak820_combo_reload_i_20000_609'
                                    843 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_610'
                                    844 ;------------------------------------------------------------
                                    845 ;	keyboards/ajazz/ak820/ak820_combo.c:36: void ak820_combo_reload(void) {
                                    846 ;	-----------------------------------------
                                    847 ;	 function ak820_combo_reload
                                    848 ;	-----------------------------------------
      00357A                        849 _ak820_combo_reload:
                                    850 ;	keyboards/ajazz/ak820/ak820_combo.c:37: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00357A 7F 00            [12]  851 	mov	r7,#0x00
      00357C                        852 00105$:
      00357C BF 08 00         [24]  853 	cjne	r7,#0x08,00131$
      00357F                        854 00131$:
      00357F 40 01            [24]  855 	jc	00132$
      003581 22               [24]  856 	ret
      003582                        857 00132$:
                                    858 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = 0;
      003582 EF               [12]  859 	mov	a,r7
      003583 75 F0 04         [24]  860 	mov	b,#0x04
      003586 A4               [48]  861 	mul	ab
      003587 24 26            [12]  862 	add	a, #_combos
      003589 FD               [12]  863 	mov	r5,a
      00358A 74 04            [12]  864 	mov	a,#(_combos >> 8)
      00358C 35 F0            [12]  865 	addc	a, b
      00358E FE               [12]  866 	mov	r6,a
      00358F 8D 03            [24]  867 	mov	ar3,r5
      003591 8E 04            [24]  868 	mov	ar4,r6
      003593 12 33 FC         [24]  869 	lcall	_ak820_outline_0129
      003596 E4               [12]  870 	clr	a
      003597 F0               [24]  871 	movx	@dptr,a
                                    872 ;	keyboards/ajazz/ak820/ak820_combo.c:40: if (!dynamic_keymap_get_combo(i, &entry)) {
      003598 90 0B 7C         [24]  873 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00359B 74 52            [12]  874 	mov	a,#_ak820_combo_reload_entry_30000_610
      00359D F0               [24]  875 	movx	@dptr,a
      00359E 74 04            [12]  876 	mov	a,#(_ak820_combo_reload_entry_30000_610 >> 8)
      0035A0 12 38 56         [24]  877 	lcall	_ak820_outline_0077
      0035A3 8F 82            [24]  878 	mov	dpl, r7
      0035A5 C0 07            [24]  879 	push	ar7
      0035A7 C0 06            [24]  880 	push	ar6
      0035A9 C0 05            [24]  881 	push	ar5
      0035AB C0 04            [24]  882 	push	ar4
      0035AD C0 03            [24]  883 	push	ar3
      0035AF 12 8C BC         [24]  884 	lcall	_dynamic_keymap_get_combo
      0035B2 12 38 95         [24]  885 	lcall	_ak820_outline_0130
      0035B5 D0 03            [24]  886 	pop	ar3
      0035B7 D0 04            [24]  887 	pop	ar4
      0035B9 D0 05            [24]  888 	pop	ar5
      0035BB D0 06            [24]  889 	pop	ar6
      0035BD D0 07            [24]  890 	pop	ar7
      0035BF 45 F0            [12]  891 	orl	a,b
      0035C1 70 28            [24]  892 	jnz	00106$
                                    893 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].a = entry.input[0];
      0035C3 90 04 52         [24]  894 	mov	dptr,#_ak820_combo_reload_entry_30000_610
      0035C6 E0               [24]  895 	movx	a,@dptr
      0035C7 12 33 FC         [24]  896 	lcall	_ak820_outline_0129
      0035CA F0               [24]  897 	movx	@dptr,a
                                    898 ;	keyboards/ajazz/ak820/ak820_combo.c:42: combos[i].b = entry.input[1];
      0035CB 74 01            [12]  899 	mov	a,#0x01
      0035CD 2D               [12]  900 	add	a, r5
      0035CE FB               [12]  901 	mov	r3,a
      0035CF E4               [12]  902 	clr	a
      0035D0 3E               [12]  903 	addc	a, r6
      0035D1 FC               [12]  904 	mov	r4,a
      0035D2 90 04 54         [24]  905 	mov	dptr,#(_ak820_combo_reload_entry_30000_610 + 0x0002)
      0035D5 E0               [24]  906 	movx	a,@dptr
      0035D6 12 33 FC         [24]  907 	lcall	_ak820_outline_0129
      0035D9 F0               [24]  908 	movx	@dptr,a
                                    909 ;	keyboards/ajazz/ak820/ak820_combo.c:43: combos[i].output = entry.output;
      0035DA 74 02            [12]  910 	mov	a,#0x02
      0035DC 12 38 BF         [24]  911 	lcall	_ak820_outline_0171
      0035DF 90 04 5A         [24]  912 	mov	dptr,#(_ak820_combo_reload_entry_30000_610 + 0x0008)
      0035E2 12 38 9B         [24]  913 	lcall	_ak820_outline_0133
      0035E5 12 38 AB         [24]  914 	lcall	_ak820_outline_0145
      0035E8 12 38 68         [24]  915 	lcall	_ak820_outline_0090
      0035EB                        916 00106$:
                                    917 ;	keyboards/ajazz/ak820/ak820_combo.c:37: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035EB 0F               [12]  918 	inc	r7
                                    919 ;	keyboards/ajazz/ak820/ak820_combo.c:46: }
      0035EC A1 7C            [24]  920 	ajmp	00105$
                                    921 ;------------------------------------------------------------
                                    922 ;Allocation info for local variables in function 'flush'
                                    923 ;------------------------------------------------------------
                                    924 ;	keyboards/ajazz/ak820/ak820_combo.c:47: static void flush(void) {
                                    925 ;	-----------------------------------------
                                    926 ;	 function flush
                                    927 ;	-----------------------------------------
      0035EE                        928 _flush:
                                    929 ;	keyboards/ajazz/ak820/ak820_combo.c:48: first = NONE;
      0035EE 90 0E 65         [24]  930 	mov	dptr,#_first
      0035F1 74 FF            [12]  931 	mov	a,#0xff
      0035F3 F0               [24]  932 	movx	@dptr,a
                                    933 ;	keyboards/ajazz/ak820/ak820_combo.c:49: process_record(&saved);
      0035F4 90 04 46         [24]  934 	mov	dptr,#_saved
      0035F7 75 F0 00         [24]  935 	mov	b, #0x00
                                    936 ;	keyboards/ajazz/ak820/ak820_combo.c:50: }
      0035FA 02 77 2E         [24]  937 	ljmp	_process_record
                                    938 ;------------------------------------------------------------
                                    939 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    940 ;------------------------------------------------------------
                                    941 ;now           Allocated with name '_ak820_combo_tick_now_10000_615'
                                    942 ;------------------------------------------------------------
                                    943 ;	keyboards/ajazz/ak820/ak820_combo.c:51: void ak820_combo_tick(uint16_t now) {
                                    944 ;	-----------------------------------------
                                    945 ;	 function ak820_combo_tick
                                    946 ;	-----------------------------------------
      0035FD                        947 _ak820_combo_tick:
      0035FD 12 38 86         [24]  948 	lcall	_ak820_outline_0114
      003600 90 04 5C         [24]  949 	mov	dptr,#_ak820_combo_tick_now_10000_615
      003603 12 38 8B         [24]  950 	lcall	_ak820_outline_0115
                                    951 ;	keyboards/ajazz/ak820/ak820_combo.c:52: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      003606 12 38 C5         [24]  952 	lcall	_ak820_outline_0195
      003609 FF               [12]  953 	mov	r7,a
      00360A BF FF 01         [24]  954 	cjne	r7,#0xff,00128$
      00360D 22               [24]  955 	ret
      00360E                        956 00128$:
      00360E 90 04 4F         [24]  957 	mov	dptr,#_active
      003611 E0               [24]  958 	movx	a,@dptr
      003612 70 1E            [24]  959 	jnz	00105$
      003614 90 04 48         [24]  960 	mov	dptr,#(_saved + 0x0002)
      003617 12 38 39         [24]  961 	lcall	_ak820_outline_0057
      00361A 90 04 5C         [24]  962 	mov	dptr,#_ak820_combo_tick_now_10000_615
      00361D 12 38 50         [24]  963 	lcall	_ak820_outline_0065
      003620 EC               [12]  964 	mov	a,r4
      003621 C3               [12]  965 	clr	c
      003622 9E               [12]  966 	subb	a,r6
      003623 FE               [12]  967 	mov	r6,a
      003624 ED               [12]  968 	mov	a,r5
      003625 9F               [12]  969 	subb	a,r7
      003626 FF               [12]  970 	mov	r7,a
      003627 C3               [12]  971 	clr	c
      003628 EE               [12]  972 	mov	a,r6
      003629 94 28            [12]  973 	subb	a,#0x28
      00362B EF               [12]  974 	mov	a,r7
      00362C 94 00            [12]  975 	subb	a,#0x00
      00362E 40 02            [24]  976 	jc	00105$
                                    977 ;	keyboards/ajazz/ak820/ak820_combo.c:53: }
      003630 A1 EE            [24]  978 	ajmp	_flush
      003632                        979 00105$:
      003632 22               [24]  980 	ret
                                    981 ;------------------------------------------------------------
                                    982 ;Allocation info for local variables in function 'ak820_combo_process'
                                    983 ;------------------------------------------------------------
                                    984 ;record        Allocated with name '_ak820_combo_process_record_10000_618'
                                    985 ;id            Allocated with name '_ak820_combo_process_id_10000_619'
                                    986 ;code          Allocated with name '_ak820_combo_process_code_10000_619'
                                    987 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_633'
                                    988 ;previous      Allocated with name '_ak820_combo_process_previous_30001_635'
                                    989 ;i             Allocated with name '_ak820_combo_process_i_40001_636'
                                    990 ;a             Allocated with name '_ak820_combo_process_a_50001_637'
                                    991 ;b             Allocated with name '_ak820_combo_process_b_50001_637'
                                    992 ;------------------------------------------------------------
                                    993 ;	keyboards/ajazz/ak820/ak820_combo.c:54: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    994 ;	-----------------------------------------
                                    995 ;	 function ak820_combo_process
                                    996 ;	-----------------------------------------
      003633                        997 _ak820_combo_process:
      003633 12 38 86         [24]  998 	lcall	_ak820_outline_0114
      003636 90 04 5E         [24]  999 	mov	dptr,#_ak820_combo_process_record_10000_618
      003639 12 38 8B         [24] 1000 	lcall	_ak820_outline_0115
                                   1001 ;	keyboards/ajazz/ak820/ak820_combo.c:55: uint8_t id, code = record->keycode;
      00363C 90 04 5E         [24] 1002 	mov	dptr,#_ak820_combo_process_record_10000_618
      00363F 12 37 E3         [24] 1003 	lcall	_ak820_outline_0002
      003642 8C 03            [24] 1004 	mov	ar3,r4
                                   1005 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (IS_NOEVENT(record->event)) return true;
      003644 74 04            [12] 1006 	mov	a,#0x04
      003646 2E               [12] 1007 	add	a, r6
      003647 12 38 17         [24] 1008 	lcall	_ak820_outline_0021
      00364A 70 04            [24] 1009 	jnz	00102$
      00364C 75 82 01         [24] 1010 	mov	dpl, #0x01
      00364F 22               [24] 1011 	ret
      003650                       1012 00102$:
                                   1013 ;	keyboards/ajazz/ak820/ak820_combo.c:58: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      003650 12 38 74         [24] 1014 	lcall	_ak820_outline_0107
      003653 E0               [24] 1015 	movx	a,@dptr
      003654 FA               [12] 1016 	mov	r2,a
      003655 BA 10 00         [24] 1017 	cjne	r2,#0x10,00300$
      003658                       1018 00300$:
      003658 50 09            [24] 1019 	jnc	00106$
      00365A 12 38 6E         [24] 1020 	lcall	_ak820_outline_0105
      00365D F9               [12] 1021 	mov	r1,a
      00365E B9 08 00         [24] 1022 	cjne	r1,#0x08,00302$
      003661                       1023 00302$:
      003661 40 15            [24] 1024 	jc	00107$
      003663                       1025 00106$:
                                   1026 ;	keyboards/ajazz/ak820/ak820_combo.c:59: if (first != NONE && !active) flush();
      003663 12 38 C5         [24] 1027 	lcall	_ak820_outline_0195
      003666 F8               [12] 1028 	mov	r0,a
      003667 B8 FF 02         [24] 1029 	cjne	r0,#0xff,00304$
      00366A 80 08            [24] 1030 	sjmp	00104$
      00366C                       1031 00304$:
      00366C 90 04 4F         [24] 1032 	mov	dptr,#_active
      00366F E0               [24] 1033 	movx	a,@dptr
      003670 70 02            [24] 1034 	jnz	00104$
      003672 B1 EE            [24] 1035 	acall	_flush
      003674                       1036 00104$:
                                   1037 ;	keyboards/ajazz/ak820/ak820_combo.c:60: return true;
      003674 75 82 01         [24] 1038 	mov	dpl, #0x01
      003677 22               [24] 1039 	ret
      003678                       1040 00107$:
                                   1041 ;	keyboards/ajazz/ak820/ak820_combo.c:62: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003678 EA               [12] 1042 	mov	a,r2
      003679 12 38 CA         [24] 1043 	lcall	_ak820_outline_0198
      00367C 29               [12] 1044 	add	a,r1
      00367D FA               [12] 1045 	mov	r2,a
                                   1046 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (active) {
      00367E 90 04 4F         [24] 1047 	mov	dptr,#_active
      003681 E0               [24] 1048 	movx	a,@dptr
      003682 60 71            [24] 1049 	jz	00123$
                                   1050 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (id != first && id != second) return true;
      003684 12 38 C5         [24] 1051 	lcall	_ak820_outline_0195
      003687 F9               [12] 1052 	mov	r1,a
      003688 EA               [12] 1053 	mov	a,r2
      003689 B5 01 02         [24] 1054 	cjne	a,ar1,00307$
      00368C 80 0F            [24] 1055 	sjmp	00110$
      00368E                       1056 00307$:
      00368E 90 0E 66         [24] 1057 	mov	dptr,#_second
      003691 E0               [24] 1058 	movx	a,@dptr
      003692 F9               [12] 1059 	mov	r1,a
      003693 EA               [12] 1060 	mov	a,r2
      003694 B5 01 02         [24] 1061 	cjne	a,ar1,00308$
      003697 80 04            [24] 1062 	sjmp	00110$
      003699                       1063 00308$:
      003699 75 82 01         [24] 1064 	mov	dpl, #0x01
      00369C 22               [24] 1065 	ret
      00369D                       1066 00110$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_combo.c:65: if (!record->event.pressed) {
      00369D 90 04 5E         [24] 1068 	mov	dptr,#_ak820_combo_process_record_10000_618
      0036A0 12 38 80         [24] 1069 	lcall	_ak820_outline_0110
      0036A3 74 05            [12] 1070 	mov	a,#0x05
      0036A5 28               [12] 1071 	add	a, r0
      0036A6 F8               [12] 1072 	mov	r0,a
      0036A7 E4               [12] 1073 	clr	a
      0036A8 39               [12] 1074 	addc	a, r1
      0036A9 F9               [12] 1075 	mov	r1,a
      0036AA 12 38 BA         [24] 1076 	lcall	_ak820_outline_0167
      0036AD E0               [24] 1077 	movx	a,@dptr
      0036AE 70 41            [24] 1078 	jnz	00121$
                                   1079 ;	keyboards/ajazz/ak820/ak820_combo.c:66: if (saved.event.pressed) {
      0036B0 90 04 4B         [24] 1080 	mov	dptr,#(_saved + 0x0005)
      0036B3 E0               [24] 1081 	movx	a,@dptr
      0036B4 60 11            [24] 1082 	jz	00113$
                                   1083 ;	keyboards/ajazz/ak820/ak820_combo.c:67: saved.event.pressed = false;
      0036B6 90 04 4B         [24] 1084 	mov	dptr,#(_saved + 0x0005)
      0036B9 E4               [12] 1085 	clr	a
      0036BA F0               [24] 1086 	movx	@dptr,a
                                   1087 ;	keyboards/ajazz/ak820/ak820_combo.c:68: process_record(&saved);
      0036BB 90 04 46         [24] 1088 	mov	dptr,#_saved
      0036BE F5 F0            [12] 1089 	mov	b,a
      0036C0 C0 02            [24] 1090 	push	ar2
      0036C2 12 77 2E         [24] 1091 	lcall	_process_record
      0036C5 D0 02            [24] 1092 	pop	ar2
      0036C7                       1093 00113$:
                                   1094 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (id == first) first = NONE;
      0036C7 12 38 C5         [24] 1095 	lcall	_ak820_outline_0195
      0036CA F9               [12] 1096 	mov	r1,a
      0036CB EA               [12] 1097 	mov	a,r2
      0036CC B5 01 08         [24] 1098 	cjne	a,ar1,00115$
      0036CF 90 0E 65         [24] 1099 	mov	dptr,#_first
      0036D2 74 FF            [12] 1100 	mov	a,#0xff
      0036D4 F0               [24] 1101 	movx	@dptr,a
      0036D5 80 06            [24] 1102 	sjmp	00116$
      0036D7                       1103 00115$:
                                   1104 ;	keyboards/ajazz/ak820/ak820_combo.c:71: else second = NONE;
      0036D7 90 0E 66         [24] 1105 	mov	dptr,#_second
      0036DA 74 FF            [12] 1106 	mov	a,#0xff
      0036DC F0               [24] 1107 	movx	@dptr,a
      0036DD                       1108 00116$:
                                   1109 ;	keyboards/ajazz/ak820/ak820_combo.c:72: if (first == NONE && second == NONE) active = false;
      0036DD 12 38 C5         [24] 1110 	lcall	_ak820_outline_0195
      0036E0 F9               [12] 1111 	mov	r1,a
      0036E1 B9 FF 0D         [24] 1112 	cjne	r1,#0xff,00121$
      0036E4 90 0E 66         [24] 1113 	mov	dptr,#_second
      0036E7 E0               [24] 1114 	movx	a,@dptr
      0036E8 F9               [12] 1115 	mov	r1,a
      0036E9 B9 FF 05         [24] 1116 	cjne	r1,#0xff,00121$
      0036EC 90 04 4F         [24] 1117 	mov	dptr,#_active
      0036EF E4               [12] 1118 	clr	a
      0036F0 F0               [24] 1119 	movx	@dptr,a
      0036F1                       1120 00121$:
                                   1121 ;	keyboards/ajazz/ak820/ak820_combo.c:74: return false;
      0036F1 75 82 00         [24] 1122 	mov	dpl, #0x00
      0036F4 22               [24] 1123 	ret
      0036F5                       1124 00123$:
                                   1125 ;	keyboards/ajazz/ak820/ak820_combo.c:76: bool eligible = false;
      0036F5 90 04 60         [24] 1126 	mov	dptr,#_ak820_combo_process_eligible_10001_633
      0036F8 E4               [12] 1127 	clr	a
      0036F9 F0               [24] 1128 	movx	@dptr,a
                                   1129 ;	keyboards/ajazz/ak820/ak820_combo.c:77: if (record->event.pressed && input(record->keycode)) {
      0036FA 12 38 01         [24] 1130 	lcall	_ak820_outline_0007
      0036FD 70 02            [24] 1131 	jnz	00317$
      0036FF E1 A2            [12] 1132 	ajmp	00134$
      003701                       1133 00317$:
      003701 12 38 A1         [24] 1134 	lcall	_ak820_outline_0134
      003704 C0 03            [24] 1135 	push	ar3
      003706 C0 02            [24] 1136 	push	ar2
      003708 91 68            [12] 1137 	acall	_input
      00370A E5 82            [12] 1138 	mov	a, dpl
      00370C D0 02            [24] 1139 	pop	ar2
      00370E D0 03            [24] 1140 	pop	ar3
      003710 70 02            [24] 1141 	jnz	00318$
      003712 E1 A2            [12] 1142 	ajmp	00134$
      003714                       1143 00318$:
                                   1144 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t previous = saved.keycode;
      003714 90 04 4D         [24] 1145 	mov	dptr,#(_saved + 0x0007)
      003717 E0               [24] 1146 	movx	a,@dptr
      003718 FF               [12] 1147 	mov	r7,a
                                   1148 ;	keyboards/ajazz/ak820/ak820_combo.c:79: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003719 90 04 61         [24] 1149 	mov	dptr,#_ak820_combo_process_i_40001_636
      00371C E4               [12] 1150 	clr	a
      00371D F0               [24] 1151 	movx	@dptr,a
      00371E EB               [12] 1152 	mov	a,r3
      00371F B5 07 03         [24] 1153 	cjne	a,ar7,00319$
      003722 D3               [12] 1154 	setb	c
      003723 80 01            [24] 1155 	sjmp	00320$
      003725                       1156 00319$:
      003725 C3               [12] 1157 	clr	c
      003726                       1158 00320$:
      003726 92 03            [24] 1159 	mov	_ak820_combo_process_sloc0_1_0,c
      003728 7E 00            [12] 1160 	mov	r6,#0x00
      00372A                       1161 00141$:
      00372A BE 08 00         [24] 1162 	cjne	r6,#0x08,00321$
      00372D                       1163 00321$:
      00372D 40 02            [24] 1164 	jc	00322$
      00372F E1 A2            [12] 1165 	ajmp	00134$
      003731                       1166 00322$:
                                   1167 ;	keyboards/ajazz/ak820/ak820_combo.c:80: uint8_t a = combos[i].a, b = combos[i].b;
      003731 EE               [12] 1168 	mov	a,r6
      003732 12 38 3F         [24] 1169 	lcall	_ak820_outline_0059
      003735 E0               [24] 1170 	movx	a,@dptr
      003736 F9               [12] 1171 	mov	r1,a
      003737 90 04 62         [24] 1172 	mov	dptr,#_ak820_combo_process_a_50001_637
      00373A 12 38 7A         [24] 1173 	lcall	_ak820_outline_0109
      00373D A3               [24] 1174 	inc	dptr
      00373E E0               [24] 1175 	movx	a,@dptr
      00373F FD               [12] 1176 	mov	r5,a
      003740 90 04 63         [24] 1177 	mov	dptr,#_ak820_combo_process_b_50001_637
      003743 F0               [24] 1178 	movx	@dptr,a
                                   1179 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (a == code || b == code) {
      003744 E9               [12] 1180 	mov	a,r1
      003745 B5 03 02         [24] 1181 	cjne	a,ar3,00323$
      003748 80 04            [24] 1182 	sjmp	00129$
      00374A                       1183 00323$:
      00374A ED               [12] 1184 	mov	a,r5
      00374B B5 03 4C         [24] 1185 	cjne	a,ar3,00142$
      00374E                       1186 00129$:
                                   1187 ;	keyboards/ajazz/ak820/ak820_combo.c:82: eligible = true;
      00374E 90 04 60         [24] 1188 	mov	dptr,#_ak820_combo_process_eligible_10001_633
      003751 74 01            [12] 1189 	mov	a,#0x01
      003753 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	keyboards/ajazz/ak820/ak820_combo.c:83: if (first != NONE && code != previous && (a == previous || b == previous)) {
      003754 12 38 C5         [24] 1192 	lcall	_ak820_outline_0195
      003757 FD               [12] 1193 	mov	r5,a
      003758 BD FF 02         [24] 1194 	cjne	r5,#0xff,00326$
      00375B 80 3D            [24] 1195 	sjmp	00142$
      00375D                       1196 00326$:
      00375D 20 03 3A         [24] 1197 	jb	_ak820_combo_process_sloc0_1_0,00142$
      003760 90 04 62         [24] 1198 	mov	dptr,#_ak820_combo_process_a_50001_637
      003763 E0               [24] 1199 	movx	a,@dptr
      003764 B5 07 02         [24] 1200 	cjne	a,ar7,00328$
      003767 80 07            [24] 1201 	sjmp	00124$
      003769                       1202 00328$:
      003769 90 04 63         [24] 1203 	mov	dptr,#_ak820_combo_process_b_50001_637
      00376C E0               [24] 1204 	movx	a,@dptr
      00376D B5 07 2A         [24] 1205 	cjne	a,ar7,00142$
      003770                       1206 00124$:
                                   1207 ;	keyboards/ajazz/ak820/ak820_combo.c:84: second = id;
      003770 90 0E 66         [24] 1208 	mov	dptr,#_second
      003773 EA               [12] 1209 	mov	a,r2
      003774 F0               [24] 1210 	movx	@dptr,a
                                   1211 ;	keyboards/ajazz/ak820/ak820_combo.c:85: active = true;
      003775 90 04 4F         [24] 1212 	mov	dptr,#_active
      003778 74 01            [12] 1213 	mov	a,#0x01
      00377A F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_combo.c:86: saved.keycode = combos[i].output;
      00377B 90 04 61         [24] 1216 	mov	dptr,#_ak820_combo_process_i_40001_636
      00377E E0               [24] 1217 	movx	a,@dptr
      00377F 12 38 3F         [24] 1218 	lcall	_ak820_outline_0059
      003782 A3               [24] 1219 	inc	dptr
      003783 A3               [24] 1220 	inc	dptr
      003784 12 38 50         [24] 1221 	lcall	_ak820_outline_0065
      003787 90 04 4D         [24] 1222 	mov	dptr,#(_saved + 0x0007)
      00378A 12 38 5C         [24] 1223 	lcall	_ak820_outline_0079
                                   1224 ;	keyboards/ajazz/ak820/ak820_combo.c:87: process_record(&saved);
      00378D 90 04 46         [24] 1225 	mov	dptr,#_saved
      003790 75 F0 00         [24] 1226 	mov	b, #0x00
      003793 12 77 2E         [24] 1227 	lcall	_process_record
                                   1228 ;	keyboards/ajazz/ak820/ak820_combo.c:88: return false;
      003796 75 82 00         [24] 1229 	mov	dpl, #0x00
      003799 22               [24] 1230 	ret
      00379A                       1231 00142$:
                                   1232 ;	keyboards/ajazz/ak820/ak820_combo.c:79: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00379A 0E               [12] 1233 	inc	r6
      00379B 90 04 61         [24] 1234 	mov	dptr,#_ak820_combo_process_i_40001_636
      00379E EE               [12] 1235 	mov	a,r6
      00379F F0               [24] 1236 	movx	@dptr,a
      0037A0 E1 2A            [24] 1237 	ajmp	00141$
      0037A2                       1238 00134$:
                                   1239 ;	keyboards/ajazz/ak820/ak820_combo.c:93: if (first != NONE) flush();
      0037A2 12 38 C5         [24] 1240 	lcall	_ak820_outline_0195
      0037A5 FF               [12] 1241 	mov	r7,a
      0037A6 BF FF 02         [24] 1242 	cjne	r7,#0xff,00331$
      0037A9 80 06            [24] 1243 	sjmp	00137$
      0037AB                       1244 00331$:
      0037AB C0 02            [24] 1245 	push	ar2
      0037AD B1 EE            [24] 1246 	acall	_flush
      0037AF D0 02            [24] 1247 	pop	ar2
      0037B1                       1248 00137$:
                                   1249 ;	keyboards/ajazz/ak820/ak820_combo.c:94: if (eligible) {
      0037B1 90 04 60         [24] 1250 	mov	dptr,#_ak820_combo_process_eligible_10001_633
      0037B4 E0               [24] 1251 	movx	a,@dptr
      0037B5 60 28            [24] 1252 	jz	00139$
                                   1253 ;	keyboards/ajazz/ak820/ak820_combo.c:95: first = id;
      0037B7 90 0E 65         [24] 1254 	mov	dptr,#_first
      0037BA EA               [12] 1255 	mov	a,r2
      0037BB F0               [24] 1256 	movx	@dptr,a
                                   1257 ;	keyboards/ajazz/ak820/ak820_combo.c:96: saved = *record;
      0037BC 90 04 5E         [24] 1258 	mov	dptr,#_ak820_combo_process_record_10000_618
      0037BF 12 38 62         [24] 1259 	lcall	_ak820_outline_0085
      0037C2 7F 00            [12] 1260 	mov	r7,#0x00
      0037C4 90 0E 57         [24] 1261 	mov	dptr,#___memcpy_PARM_2
      0037C7 ED               [12] 1262 	mov	a,r5
      0037C8 12 38 21         [24] 1263 	lcall	_ak820_outline_0022
      0037CB 90 0E 5A         [24] 1264 	mov	dptr,#___memcpy_PARM_3
      0037CE 74 09            [12] 1265 	mov	a,#0x09
      0037D0 12 38 A6         [24] 1266 	lcall	_ak820_outline_0135
      0037D3 90 04 46         [24] 1267 	mov	dptr,#_saved
      0037D6 F5 F0            [12] 1268 	mov	b,a
      0037D8 12 C1 65         [24] 1269 	lcall	___memcpy
                                   1270 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return false;
      0037DB 75 82 00         [24] 1271 	mov	dpl, #0x00
      0037DE 22               [24] 1272 	ret
      0037DF                       1273 00139$:
                                   1274 ;	keyboards/ajazz/ak820/ak820_combo.c:99: return true;
      0037DF 75 82 01         [24] 1275 	mov	dpl, #0x01
                                   1276 ;	keyboards/ajazz/ak820/ak820_combo.c:100: }
      0037E2 22               [24] 1277 	ret
                                   1278 	.area CSEG    (CODE)
                                   1279 	.area CONST   (CODE)
                                   1280 	.area XINIT   (CODE)
      00CA23                       1281 __xinit__first:
      00CA23 FF                    1282 	.db #0xff	; 255
      00CA24                       1283 __xinit__second:
      00CA24 FF                    1284 	.db #0xff	; 255
                                   1285 	.area CABS    (ABS,CODE)
                                   1286 
                                   1287 ; Experimental exact instruction outlining.
                                   1288 	.globl _ak820_outline_0002
                                   1289 	.globl _ak820_outline_0006
                                   1290 	.globl _ak820_outline_0007
                                   1291 	.globl _ak820_outline_0016
                                   1292 	.globl _ak820_outline_0021
                                   1293 	.globl _ak820_outline_0022
                                   1294 	.globl _ak820_outline_0036
                                   1295 	.globl _ak820_outline_0037
                                   1296 	.globl _ak820_outline_0057
                                   1297 	.globl _ak820_outline_0059
                                   1298 	.globl _ak820_outline_0065
                                   1299 	.globl _ak820_outline_0077
                                   1300 	.globl _ak820_outline_0079
                                   1301 	.globl _ak820_outline_0085
                                   1302 	.globl _ak820_outline_0090
                                   1303 	.globl _ak820_outline_0105
                                   1304 	.globl _ak820_outline_0107
                                   1305 	.globl _ak820_outline_0109
                                   1306 	.globl _ak820_outline_0110
                                   1307 	.globl _ak820_outline_0114
                                   1308 	.globl _ak820_outline_0115
                                   1309 	.globl _ak820_outline_0126
                                   1310 	.globl _ak820_outline_0129
                                   1311 	.globl _ak820_outline_0130
                                   1312 	.globl _ak820_outline_0133
                                   1313 	.globl _ak820_outline_0134
                                   1314 	.globl _ak820_outline_0135
                                   1315 	.globl _ak820_outline_0145
                                   1316 	.globl _ak820_outline_0146
                                   1317 	.globl _ak820_outline_0154
                                   1318 	.globl _ak820_outline_0167
                                   1319 	.globl _ak820_outline_0171
                                   1320 	.globl _ak820_outline_0195
                                   1321 	.globl _ak820_outline_0198
                                   1322 
                                   1323 	.area CSEG (CODE)
                                   1324 ; function ak820_outline_0002
      0037E3                       1325 _ak820_outline_0002:
      0037E3 E0               [24] 1326 	movx	a,@dptr
      0037E4 FE               [12] 1327 	mov	r6,a
      0037E5 A3               [24] 1328 	inc	dptr
      0037E6 E0               [24] 1329 	movx	a,@dptr
      0037E7 FF               [12] 1330 	mov	r7,a
      0037E8 74 07            [12] 1331 	mov	a,#0x07
      0037EA 2E               [12] 1332 	add	a,r6
      0037EB F5 82            [12] 1333 	mov	dpl,a
      0037ED E4               [12] 1334 	clr	a
      0037EE 3F               [12] 1335 	addc	a,r7
      0037EF F5 83            [12] 1336 	mov	dph,a
      0037F1 E0               [24] 1337 	movx	a,@dptr
      0037F2 FC               [12] 1338 	mov	r4,a
      0037F3 A3               [24] 1339 	inc	dptr
      0037F4 E0               [24] 1340 	movx	a,@dptr
      0037F5 FD               [12] 1341 	mov	r5,a
      0037F6 22               [24] 1342 	ret
                                   1343 
                                   1344 	.area CSEG (CODE)
                                   1345 ; function ak820_outline_0006
      0037F7                       1346 _ak820_outline_0006:
      0037F7 E0               [24] 1347 	movx	a,@dptr
      0037F8 FE               [12] 1348 	mov	r6,a
      0037F9 A3               [24] 1349 	inc	dptr
      0037FA E0               [24] 1350 	movx	a,@dptr
      0037FB FF               [12] 1351 	mov	r7,a
      0037FC 8E 82            [24] 1352 	mov	dpl,r6
      0037FE 8F 83            [24] 1353 	mov	dph,r7
      003800 22               [24] 1354 	ret
                                   1355 
                                   1356 	.area CSEG (CODE)
                                   1357 ; function ak820_outline_0007
      003801                       1358 _ak820_outline_0007:
      003801 74 05            [12] 1359 	mov	a,#0x05
      003803 2E               [12] 1360 	add	a,r6
      003804 FE               [12] 1361 	mov	r6,a
      003805 E4               [12] 1362 	clr	a
      003806 3F               [12] 1363 	addc	a,r7
      003807 FF               [12] 1364 	mov	r7,a
      003808 8E 82            [24] 1365 	mov	dpl,r6
      00380A 8F 83            [24] 1366 	mov	dph,r7
      00380C E0               [24] 1367 	movx	a,@dptr
      00380D 22               [24] 1368 	ret
                                   1369 
                                   1370 	.area CSEG (CODE)
                                   1371 ; function ak820_outline_0016
      00380E                       1372 _ak820_outline_0016:
      00380E 2E               [12] 1373 	add	a,r6
      00380F F5 82            [12] 1374 	mov	dpl,a
      003811 E4               [12] 1375 	clr	a
      003812 3F               [12] 1376 	addc	a,r7
      003813 F5 83            [12] 1377 	mov	dph,a
      003815 E0               [24] 1378 	movx	a,@dptr
      003816 22               [24] 1379 	ret
                                   1380 
                                   1381 	.area CSEG (CODE)
                                   1382 ; function ak820_outline_0021
      003817                       1383 _ak820_outline_0021:
      003817 F9               [12] 1384 	mov	r1,a
      003818 E4               [12] 1385 	clr	a
      003819 3F               [12] 1386 	addc	a,r7
      00381A FA               [12] 1387 	mov	r2,a
      00381B 89 82            [24] 1388 	mov	dpl,r1
      00381D 8A 83            [24] 1389 	mov	dph,r2
      00381F E0               [24] 1390 	movx	a,@dptr
      003820 22               [24] 1391 	ret
                                   1392 
                                   1393 	.area CSEG (CODE)
                                   1394 ; function ak820_outline_0022
      003821                       1395 _ak820_outline_0022:
      003821 F0               [24] 1396 	movx	@dptr,a
      003822 EE               [12] 1397 	mov	a,r6
      003823 A3               [24] 1398 	inc	dptr
      003824 F0               [24] 1399 	movx	@dptr,a
      003825 EF               [12] 1400 	mov	a,r7
      003826 A3               [24] 1401 	inc	dptr
      003827 F0               [24] 1402 	movx	@dptr,a
      003828 22               [24] 1403 	ret
                                   1404 
                                   1405 	.area CSEG (CODE)
                                   1406 ; function ak820_outline_0036
      003829                       1407 _ak820_outline_0036:
      003829 2E               [12] 1408 	add	a,r6
      00382A F5 82            [12] 1409 	mov	dpl,a
      00382C E4               [12] 1410 	clr	a
      00382D 3F               [12] 1411 	addc	a,r7
      00382E F5 83            [12] 1412 	mov	dph,a
      003830 22               [24] 1413 	ret
                                   1414 
                                   1415 	.area CSEG (CODE)
                                   1416 ; function ak820_outline_0037
      003831                       1417 _ak820_outline_0037:
      003831 8E 82            [24] 1418 	mov	dpl,r6
      003833 8F 83            [24] 1419 	mov	dph,r7
      003835 A3               [24] 1420 	inc	dptr
      003836 A3               [24] 1421 	inc	dptr
      003837 E0               [24] 1422 	movx	a,@dptr
      003838 22               [24] 1423 	ret
                                   1424 
                                   1425 	.area CSEG (CODE)
                                   1426 ; function ak820_outline_0057
      003839                       1427 _ak820_outline_0057:
      003839 E0               [24] 1428 	movx	a,@dptr
      00383A FE               [12] 1429 	mov	r6,a
      00383B A3               [24] 1430 	inc	dptr
      00383C E0               [24] 1431 	movx	a,@dptr
      00383D FF               [12] 1432 	mov	r7,a
      00383E 22               [24] 1433 	ret
                                   1434 
                                   1435 	.area CSEG (CODE)
                                   1436 ; function ak820_outline_0059
      00383F                       1437 _ak820_outline_0059:
      00383F 75 F0 04         [24] 1438 	mov	b,#0x04
      003842 A4               [48] 1439 	mul	ab
      003843 24 26            [12] 1440 	add	a,#_combos
      003845 FC               [12] 1441 	mov	r4,a
      003846 74 04            [12] 1442 	mov	a,#(_combos>>8)
      003848 35 F0            [12] 1443 	addc	a,b
      00384A FD               [12] 1444 	mov	r5,a
      00384B 8C 82            [24] 1445 	mov	dpl,r4
      00384D 8D 83            [24] 1446 	mov	dph,r5
      00384F 22               [24] 1447 	ret
                                   1448 
                                   1449 	.area CSEG (CODE)
                                   1450 ; function ak820_outline_0065
      003850                       1451 _ak820_outline_0065:
      003850 E0               [24] 1452 	movx	a,@dptr
      003851 FC               [12] 1453 	mov	r4,a
      003852 A3               [24] 1454 	inc	dptr
      003853 E0               [24] 1455 	movx	a,@dptr
      003854 FD               [12] 1456 	mov	r5,a
      003855 22               [24] 1457 	ret
                                   1458 
                                   1459 	.area CSEG (CODE)
                                   1460 ; function ak820_outline_0077
      003856                       1461 _ak820_outline_0077:
      003856 A3               [24] 1462 	inc	dptr
      003857 F0               [24] 1463 	movx	@dptr,a
      003858 E4               [12] 1464 	clr	a
      003859 A3               [24] 1465 	inc	dptr
      00385A F0               [24] 1466 	movx	@dptr,a
      00385B 22               [24] 1467 	ret
                                   1468 
                                   1469 	.area CSEG (CODE)
                                   1470 ; function ak820_outline_0079
      00385C                       1471 _ak820_outline_0079:
      00385C EC               [12] 1472 	mov	a,r4
      00385D F0               [24] 1473 	movx	@dptr,a
      00385E ED               [12] 1474 	mov	a,r5
      00385F A3               [24] 1475 	inc	dptr
      003860 F0               [24] 1476 	movx	@dptr,a
      003861 22               [24] 1477 	ret
                                   1478 
                                   1479 	.area CSEG (CODE)
                                   1480 ; function ak820_outline_0085
      003862                       1481 _ak820_outline_0085:
      003862 E0               [24] 1482 	movx	a,@dptr
      003863 FD               [12] 1483 	mov	r5,a
      003864 A3               [24] 1484 	inc	dptr
      003865 E0               [24] 1485 	movx	a,@dptr
      003866 FE               [12] 1486 	mov	r6,a
      003867 22               [24] 1487 	ret
                                   1488 
                                   1489 	.area CSEG (CODE)
                                   1490 ; function ak820_outline_0090
      003868                       1491 _ak820_outline_0090:
      003868 EB               [12] 1492 	mov	a,r3
      003869 F0               [24] 1493 	movx	@dptr,a
      00386A EC               [12] 1494 	mov	a,r4
      00386B A3               [24] 1495 	inc	dptr
      00386C F0               [24] 1496 	movx	@dptr,a
      00386D 22               [24] 1497 	ret
                                   1498 
                                   1499 	.area CSEG (CODE)
                                   1500 ; function ak820_outline_0105
      00386E                       1501 _ak820_outline_0105:
      00386E 8E 82            [24] 1502 	mov	dpl,r6
      003870 8F 83            [24] 1503 	mov	dph,r7
      003872 E0               [24] 1504 	movx	a,@dptr
      003873 22               [24] 1505 	ret
                                   1506 
                                   1507 	.area CSEG (CODE)
                                   1508 ; function ak820_outline_0107
      003874                       1509 _ak820_outline_0107:
      003874 8E 82            [24] 1510 	mov	dpl,r6
      003876 8F 83            [24] 1511 	mov	dph,r7
      003878 A3               [24] 1512 	inc	dptr
      003879 22               [24] 1513 	ret
                                   1514 
                                   1515 	.area CSEG (CODE)
                                   1516 ; function ak820_outline_0109
      00387A                       1517 _ak820_outline_0109:
      00387A F0               [24] 1518 	movx	@dptr,a
      00387B 8C 82            [24] 1519 	mov	dpl,r4
      00387D 8D 83            [24] 1520 	mov	dph,r5
      00387F 22               [24] 1521 	ret
                                   1522 
                                   1523 	.area CSEG (CODE)
                                   1524 ; function ak820_outline_0110
      003880                       1525 _ak820_outline_0110:
      003880 E0               [24] 1526 	movx	a,@dptr
      003881 F8               [12] 1527 	mov	r0,a
      003882 A3               [24] 1528 	inc	dptr
      003883 E0               [24] 1529 	movx	a,@dptr
      003884 F9               [12] 1530 	mov	r1,a
      003885 22               [24] 1531 	ret
                                   1532 
                                   1533 	.area CSEG (CODE)
                                   1534 ; function ak820_outline_0114
      003886                       1535 _ak820_outline_0114:
      003886 AF 83            [24] 1536 	mov	r7,dph
      003888 E5 82            [12] 1537 	mov	a,dpl
      00388A 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0115
      00388B                       1542 _ak820_outline_0115:
      00388B F0               [24] 1543 	movx	@dptr,a
      00388C EF               [12] 1544 	mov	a,r7
      00388D A3               [24] 1545 	inc	dptr
      00388E F0               [24] 1546 	movx	@dptr,a
      00388F 22               [24] 1547 	ret
                                   1548 
                                   1549 	.area CSEG (CODE)
                                   1550 ; function ak820_outline_0126
      003890                       1551 _ak820_outline_0126:
      003890 8E 82            [24] 1552 	mov	dpl,r6
      003892 8F 83            [24] 1553 	mov	dph,r7
      003894 22               [24] 1554 	ret
                                   1555 
                                   1556 	.area CSEG (CODE)
                                   1557 ; function ak820_outline_0130
      003895                       1558 _ak820_outline_0130:
      003895 E5 82            [12] 1559 	mov	a,dpl
      003897 85 83 F0         [24] 1560 	mov	b,dph
      00389A 22               [24] 1561 	ret
                                   1562 
                                   1563 	.area CSEG (CODE)
                                   1564 ; function ak820_outline_0133
      00389B                       1565 _ak820_outline_0133:
      00389B E0               [24] 1566 	movx	a,@dptr
      00389C FB               [12] 1567 	mov	r3,a
      00389D A3               [24] 1568 	inc	dptr
      00389E E0               [24] 1569 	movx	a,@dptr
      00389F FC               [12] 1570 	mov	r4,a
      0038A0 22               [24] 1571 	ret
                                   1572 
                                   1573 	.area CSEG (CODE)
                                   1574 ; function ak820_outline_0134
      0038A1                       1575 _ak820_outline_0134:
      0038A1 8C 82            [24] 1576 	mov	dpl,r4
      0038A3 8D 83            [24] 1577 	mov	dph,r5
      0038A5 22               [24] 1578 	ret
                                   1579 
                                   1580 	.area CSEG (CODE)
                                   1581 ; function ak820_outline_0135
      0038A6                       1582 _ak820_outline_0135:
      0038A6 F0               [24] 1583 	movx	@dptr,a
      0038A7 E4               [12] 1584 	clr	a
      0038A8 A3               [24] 1585 	inc	dptr
      0038A9 F0               [24] 1586 	movx	@dptr,a
      0038AA 22               [24] 1587 	ret
                                   1588 
                                   1589 	.area CSEG (CODE)
                                   1590 ; function ak820_outline_0145
      0038AB                       1591 _ak820_outline_0145:
      0038AB 8D 82            [24] 1592 	mov	dpl,r5
      0038AD 8E 83            [24] 1593 	mov	dph,r6
      0038AF 22               [24] 1594 	ret
                                   1595 
                                   1596 	.area CSEG (CODE)
                                   1597 ; function ak820_outline_0146
      0038B0                       1598 _ak820_outline_0146:
      0038B0 8A 82            [24] 1599 	mov	dpl,r2
      0038B2 8B 83            [24] 1600 	mov	dph,r3
      0038B4 22               [24] 1601 	ret
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0154
      0038B5                       1605 _ak820_outline_0154:
      0038B5 E4               [12] 1606 	clr	a
      0038B6 33               [12] 1607 	rlc	a
      0038B7 F5 82            [12] 1608 	mov	dpl,a
      0038B9 22               [24] 1609 	ret
                                   1610 
                                   1611 	.area CSEG (CODE)
                                   1612 ; function ak820_outline_0167
      0038BA                       1613 _ak820_outline_0167:
      0038BA 88 82            [24] 1614 	mov	dpl,r0
      0038BC 89 83            [24] 1615 	mov	dph,r1
      0038BE 22               [24] 1616 	ret
                                   1617 
                                   1618 	.area CSEG (CODE)
                                   1619 ; function ak820_outline_0171
      0038BF                       1620 _ak820_outline_0171:
      0038BF 2D               [12] 1621 	add	a,r5
      0038C0 FD               [12] 1622 	mov	r5,a
      0038C1 E4               [12] 1623 	clr	a
      0038C2 3E               [12] 1624 	addc	a,r6
      0038C3 FE               [12] 1625 	mov	r6,a
      0038C4 22               [24] 1626 	ret
                                   1627 
                                   1628 	.area CSEG (CODE)
                                   1629 ; function ak820_outline_0195
      0038C5                       1630 _ak820_outline_0195:
      0038C5 90 0E 65         [24] 1631 	mov	dptr,#_first
      0038C8 E0               [24] 1632 	movx	a,@dptr
      0038C9 22               [24] 1633 	ret
                                   1634 
                                   1635 	.area CSEG (CODE)
                                   1636 ; function ak820_outline_0198
      0038CA                       1637 _ak820_outline_0198:
      0038CA C4               [12] 1638 	swap	a
      0038CB 03               [12] 1639 	rr	a
      0038CC 54 F8            [12] 1640 	anl	a,#0xf8
      0038CE 22               [24] 1641 	ret
