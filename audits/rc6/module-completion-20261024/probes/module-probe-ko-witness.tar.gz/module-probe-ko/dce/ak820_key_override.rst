                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_key_override
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_key_override
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _ak820_key_override_process_PARM_3
                                    256 	.globl _ak820_key_override_process_PARM_2
                                    257 	.globl _ak820_key_override_sync_PARM_2
                                    258 	.globl _ak820_key_override_valid
                                    259 	.globl _ak820_key_override_cancel
                                    260 	.globl _ak820_key_override_reload
                                    261 	.globl _ak820_key_override_sync
                                    262 	.globl _ak820_key_override_process
                                    263 	.globl _ak820_key_override_key
                                    264 	.globl _ak820_key_override_mods
                                    265 ;--------------------------------------------------------
                                    266 ; special function registers
                                    267 ;--------------------------------------------------------
                                    268 	.area RSEG    (ABS,DATA)
      000000                        269 	.org 0x0000
                           0000D0   270 _PSW	=	0x00d0
                           0000E0   271 _ACC	=	0x00e0
                           0000F0   272 _B	=	0x00f0
                           0000FD   273 _A_INV	=	0x00fd
                           000081   274 _SP	=	0x0081
                           000082   275 _DPL	=	0x0082
                           000083   276 _DPH	=	0x0083
                           0000A1   277 _SAFE_MOD	=	0x00a1
                           0000B1   278 _GLOBAL_CFG	=	0x00b1
                           000087   279 _PCON	=	0x0087
                           0000BA   280 _POWER_CFG	=	0x00ba
                           0000B9   281 _CLOCK_CFG	=	0x00b9
                           0000A9   282 _WAKE_CTRL	=	0x00a9
                           0000FE   283 _RESET_KEEP	=	0x00fe
                           0000FF   284 _WDOG_COUNT	=	0x00ff
                           0000A8   285 _IE	=	0x00a8
                           0000B8   286 _IP	=	0x00b8
                           0000E8   287 _IE_EX	=	0x00e8
                           0000E9   288 _IP_EX	=	0x00e9
                           0000B2   289 _GPIO_IE	=	0x00b2
                           008584   290 _ROM_ADDR	=	0x8584
                           000084   291 _ROM_ADDR_L	=	0x0084
                           000085   292 _ROM_ADDR_H	=	0x0085
                           008F8E   293 _ROM_DATA_HI	=	0x8f8e
                           00008E   294 _ROM_DATA_HL	=	0x008e
                           00008F   295 _ROM_DATA_HH	=	0x008f
                           000086   296 _ROM_CTRL	=	0x0086
                           000080   297 _P0	=	0x0080
                           0000C4   298 _P0_MOD_OC	=	0x00c4
                           0000C5   299 _P0_DIR_PU	=	0x00c5
                           000090   300 _P1	=	0x0090
                           000092   301 _P1_MOD_OC	=	0x0092
                           000093   302 _P1_DIR_PU	=	0x0093
                           0000A0   303 _P2	=	0x00a0
                           000094   304 _P2_MOD_OC	=	0x0094
                           000095   305 _P2_DIR_PU	=	0x0095
                           0000B0   306 _P3	=	0x00b0
                           000096   307 _P3_MOD_OC	=	0x0096
                           000097   308 _P3_DIR_PU	=	0x0097
                           0000C0   309 _P4	=	0x00c0
                           0000C2   310 _P4_MOD_OC	=	0x00c2
                           0000C3   311 _P4_DIR_PU	=	0x00c3
                           0000C1   312 _P4_LED_KEY	=	0x00c1
                           0000AA   313 _P5_IN	=	0x00aa
                           0000AB   314 _P5_OUT_PU	=	0x00ab
                           0000AC   315 _P5_DIR	=	0x00ac
                           0000AD   316 _P6_IN	=	0x00ad
                           0000AE   317 _P6_OUT_PU	=	0x00ae
                           0000AF   318 _P6_DIR	=	0x00af
                           0000F1   319 _P7	=	0x00f1
                           0000A2   320 _XBUS_AUX	=	0x00a2
                           000088   321 _TCON	=	0x0088
                           000089   322 _TMOD	=	0x0089
                           00008A   323 _TL0	=	0x008a
                           00008B   324 _TL1	=	0x008b
                           00008C   325 _TH0	=	0x008c
                           00008D   326 _TH1	=	0x008d
                           000098   327 _SCON	=	0x0098
                           000099   328 _SBUF	=	0x0099
                           0000C8   329 _T2CON	=	0x00c8
                           0000C9   330 _T2MOD	=	0x00c9
                           00CBCA   331 _RCAP2	=	0xcbca
                           0000CA   332 _RCAP2L	=	0x00ca
                           0000CB   333 _RCAP2H	=	0x00cb
                           00CDCC   334 _T2COUNT	=	0xcdcc
                           0000CC   335 _TL2	=	0x00cc
                           0000CD   336 _TH2	=	0x00cd
                           00CFCE   337 _T2CAP1	=	0xcfce
                           0000CE   338 _T2CAP1L	=	0x00ce
                           0000CF   339 _T2CAP1H	=	0x00cf
                           0000F8   340 _SPI0_STAT	=	0x00f8
                           0000F9   341 _SPI0_DATA	=	0x00f9
                           0000FA   342 _SPI0_CTRL	=	0x00fa
                           0000FB   343 _SPI0_CK_SE	=	0x00fb
                           0000FC   344 _SPI0_SETUP	=	0x00fc
                           0000BC   345 _SCON1	=	0x00bc
                           0000BD   346 _SBUF1	=	0x00bd
                           0000BE   347 _SBAUD1	=	0x00be
                           0000BF   348 _SIF1	=	0x00bf
                           0000B4   349 _SPI1_STAT	=	0x00b4
                           0000B5   350 _SPI1_DATA	=	0x00b5
                           0000B6   351 _SPI1_CTRL	=	0x00b6
                           0000B7   352 _SPI1_CK_SE	=	0x00b7
                           0000F3   353 _ADC_CTRL	=	0x00f3
                           00F5F4   354 _ADC_DAT	=	0xf5f4
                           0000F4   355 _ADC_DAT_L	=	0x00f4
                           0000F5   356 _ADC_DAT_H	=	0x00f5
                           0000F6   357 _ADC_CHAN	=	0x00f6
                           0000A6   358 _LED_COMMON	=	0x00a6
                           0000A7   359 _LED_PWM_OE	=	0x00a7
                           00C7C6   360 _LED_DMA	=	0xc7c6
                           0000C6   361 _LED_DMA_L	=	0x00c6
                           0000C7   362 _LED_DMA_H	=	0x00c7
                           0000F7   363 _LED_STATUS	=	0x00f7
                           0000B3   364 _I2CX_INT	=	0x00b3
                           0000BB   365 _I2CS_INT_ST	=	0x00bb
                                    366 ;--------------------------------------------------------
                                    367 ; special function bits
                                    368 ;--------------------------------------------------------
                                    369 	.area RSEG    (ABS,DATA)
      000000                        370 	.org 0x0000
                           0000D7   371 _CY	=	0x00d7
                           0000D6   372 _AC	=	0x00d6
                           0000D5   373 _F0	=	0x00d5
                           0000D4   374 _RS1	=	0x00d4
                           0000D3   375 _RS0	=	0x00d3
                           0000D2   376 _OV	=	0x00d2
                           0000D1   377 _F1	=	0x00d1
                           0000D0   378 _P	=	0x00d0
                           0000AF   379 _EA	=	0x00af
                           0000AE   380 _E_DIS	=	0x00ae
                           0000AD   381 _ET2	=	0x00ad
                           0000AC   382 _ES	=	0x00ac
                           0000AB   383 _ET1	=	0x00ab
                           0000AA   384 _EX1	=	0x00aa
                           0000A9   385 _ET0	=	0x00a9
                           0000A8   386 _EX0	=	0x00a8
                           0000BF   387 _PH_FLAG	=	0x00bf
                           0000BE   388 _PL_FLAG	=	0x00be
                           0000BD   389 _PT2	=	0x00bd
                           0000BC   390 _PS	=	0x00bc
                           0000BB   391 _PT1	=	0x00bb
                           0000BA   392 _PX1	=	0x00ba
                           0000B9   393 _PT0	=	0x00b9
                           0000B8   394 _PX0	=	0x00b8
                           0000EF   395 _IE_WDOG	=	0x00ef
                           0000EE   396 _IE_GPIO	=	0x00ee
                           0000ED   397 _IE_PWM_I2C	=	0x00ed
                           0000EC   398 _IE_UART1	=	0x00ec
                           0000EB   399 _IE_ADC	=	0x00eb
                           0000E9   400 _IE_USB	=	0x00e9
                           0000E8   401 _IE_SPI0	=	0x00e8
                           000087   402 _P0_7	=	0x0087
                           000086   403 _P0_6	=	0x0086
                           000085   404 _P0_5	=	0x0085
                           000084   405 _P0_4	=	0x0084
                           000083   406 _P0_3	=	0x0083
                           000082   407 _P0_2	=	0x0082
                           000081   408 _P0_1	=	0x0081
                           000080   409 _P0_0	=	0x0080
                           000081   410 _SDA0	=	0x0081
                           000080   411 _SCL0	=	0x0080
                           000083   412 _TXD_	=	0x0083
                           000082   413 _RXD_	=	0x0082
                           000085   414 _AIN13	=	0x0085
                           000084   415 _AIN12	=	0x0084
                           000083   416 _AIN11	=	0x0083
                           000082   417 _AIN10	=	0x0082
                           000081   418 _AIN9	=	0x0081
                           000080   419 _AIN8	=	0x0080
                           000097   420 _P1_7	=	0x0097
                           000096   421 _P1_6	=	0x0096
                           000095   422 _P1_5	=	0x0095
                           000094   423 _P1_4	=	0x0094
                           000093   424 _P1_3	=	0x0093
                           000092   425 _P1_2	=	0x0092
                           000091   426 _P1_1	=	0x0091
                           000090   427 _P1_0	=	0x0090
                           000097   428 _TXD1_	=	0x0097
                           000096   429 _RXD1_	=	0x0096
                           000097   430 _SCK	=	0x0097
                           000096   431 _MISO	=	0x0096
                           000095   432 _MOSI	=	0x0095
                           000094   433 _SCS	=	0x0094
                           000092   434 _INT0_	=	0x0092
                           000091   435 _T2EX	=	0x0091
                           000091   436 _CAP2	=	0x0091
                           000090   437 _T2	=	0x0090
                           000090   438 _CAP1	=	0x0090
                           000097   439 _AIN7	=	0x0097
                           000096   440 _AIN6	=	0x0096
                           000095   441 _AIN5	=	0x0095
                           000094   442 _AIN4	=	0x0094
                           000093   443 _AIN3	=	0x0093
                           000092   444 _AIN2	=	0x0092
                           000091   445 _AIN1	=	0x0091
                           000090   446 _AIN0	=	0x0090
                           0000A7   447 _P2_7	=	0x00a7
                           0000A6   448 _P2_6	=	0x00a6
                           0000A5   449 _P2_5	=	0x00a5
                           0000A4   450 _P2_4	=	0x00a4
                           0000A3   451 _P2_3	=	0x00a3
                           0000A2   452 _P2_2	=	0x00a2
                           0000A1   453 _P2_1	=	0x00a1
                           0000A0   454 _P2_0	=	0x00a0
                           0000A7   455 _TXD1	=	0x00a7
                           0000A6   456 _RXD1	=	0x00a6
                           0000A5   457 _T2EX_	=	0x00a5
                           0000A5   458 _CAP2_	=	0x00a5
                           0000A4   459 _T2_	=	0x00a4
                           0000A4   460 _CAP1_	=	0x00a4
                           0000B7   461 _P3_7	=	0x00b7
                           0000B6   462 _P3_6	=	0x00b6
                           0000B5   463 _P3_5	=	0x00b5
                           0000B4   464 _P3_4	=	0x00b4
                           0000B3   465 _P3_3	=	0x00b3
                           0000B2   466 _P3_2	=	0x00b2
                           0000B1   467 _P3_1	=	0x00b1
                           0000B0   468 _P3_0	=	0x00b0
                           0000B7   469 _SCK1	=	0x00b7
                           0000B6   470 _MISO1	=	0x00b6
                           0000B5   471 _MOSI1	=	0x00b5
                           0000B5   472 _T1	=	0x00b5
                           0000B4   473 _T0	=	0x00b4
                           0000B3   474 _INT1	=	0x00b3
                           0000B2   475 _INT0	=	0x00b2
                           0000B1   476 _TXD	=	0x00b1
                           0000B0   477 _RXD	=	0x00b0
                           0000C6   478 _P4_6	=	0x00c6
                           0000C5   479 _P4_5	=	0x00c5
                           0000C4   480 _P4_4	=	0x00c4
                           0000C3   481 _P4_3	=	0x00c3
                           0000C2   482 _P4_2	=	0x00c2
                           0000C1   483 _P4_1	=	0x00c1
                           0000C0   484 _P4_0	=	0x00c0
                           00008F   485 _TF1	=	0x008f
                           00008E   486 _TR1	=	0x008e
                           00008D   487 _TF0	=	0x008d
                           00008C   488 _TR0	=	0x008c
                           00008B   489 _IE1	=	0x008b
                           00008A   490 _IT1	=	0x008a
                           000089   491 _IE0	=	0x0089
                           000088   492 _IT0	=	0x0088
                           00009F   493 _SM0	=	0x009f
                           00009E   494 _SM1	=	0x009e
                           00009D   495 _SM2	=	0x009d
                           00009C   496 _REN	=	0x009c
                           00009B   497 _TB8	=	0x009b
                           00009A   498 _RB8	=	0x009a
                           000099   499 _TI	=	0x0099
                           000098   500 _RI	=	0x0098
                           0000CF   501 _TF2	=	0x00cf
                           0000CF   502 _CAP1F	=	0x00cf
                           0000CE   503 _EXF2	=	0x00ce
                           0000CD   504 _RCLK	=	0x00cd
                           0000CC   505 _TCLK	=	0x00cc
                           0000CB   506 _EXEN2	=	0x00cb
                           0000CA   507 _TR2	=	0x00ca
                           0000C9   508 _C_T2	=	0x00c9
                           0000C8   509 _CP_RL2	=	0x00c8
                           0000FF   510 _S0_FST_ACT	=	0x00ff
                           0000FE   511 _S0_IF_OV	=	0x00fe
                           0000FD   512 _S0_IF_FIRST	=	0x00fd
                           0000FC   513 _S0_IF_BYTE	=	0x00fc
                           0000FB   514 _S0_FREE	=	0x00fb
                           0000FA   515 _S0_T_FIFO	=	0x00fa
                           0000F8   516 _S0_R_FIFO	=	0x00f8
                           0000F7   517 _ADC_START	=	0x00f7
                                    518 ;--------------------------------------------------------
                                    519 ; overlayable register banks
                                    520 ;--------------------------------------------------------
                                    521 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        522 	.ds 8
                                    523 ;--------------------------------------------------------
                                    524 ; internal ram data
                                    525 ;--------------------------------------------------------
                                    526 	.area DSEG    (DATA)
      00000A                        527 _ak820_key_override_valid_sloc0_1_0:
      00000A                        528 	.ds 2
      00000C                        529 _ak820_key_override_valid_sloc1_1_0:
      00000C                        530 	.ds 2
      00000E                        531 _activate_sloc0_1_0:
      00000E                        532 	.ds 3
      000011                        533 _activate_sloc1_1_0:
      000011                        534 	.ds 1
      000012                        535 _activate_sloc2_1_0:
      000012                        536 	.ds 2
      000014                        537 _ak820_key_override_process_sloc0_1_0:
      000014                        538 	.ds 1
      000015                        539 _ak820_key_override_process_sloc1_1_0:
      000015                        540 	.ds 1
      000016                        541 _ak820_key_override_process_sloc2_1_0:
      000016                        542 	.ds 2
                                    543 ;--------------------------------------------------------
                                    544 ; overlayable items in internal ram
                                    545 ;--------------------------------------------------------
                                    546 ;--------------------------------------------------------
                                    547 ; indirectly addressable internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area ISEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; absolute internal ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area IABS    (ABS,DATA)
                                    554 	.area IABS    (ABS,DATA)
                                    555 ;--------------------------------------------------------
                                    556 ; bit data
                                    557 ;--------------------------------------------------------
                                    558 	.area BSEG    (BIT)
      000006                        559 _basic_sloc0_1_0:
      000006                        560 	.ds 1
      000007                        561 _matches_sloc0_1_0:
      000007                        562 	.ds 1
      000008                        563 _eligible_sloc0_1_0:
      000008                        564 	.ds 1
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      0004FD                        573 _entries:
      0004FD                        574 	.ds 80
      00054D                        575 _trigger:
      00054D                        576 	.ds 1
      00054E                        577 _previous_mods:
      00054E                        578 	.ds 1
      00054F                        579 _blocked:
      00054F                        580 	.ds 1
      000550                        581 _hidden:
      000550                        582 	.ds 1
      000551                        583 _basic_key_10000_597:
      000551                        584 	.ds 2
      000553                        585 _ak820_key_override_valid_e_10000_599:
      000553                        586 	.ds 2
      000555                        587 _replacement_mods_key_10000_606:
      000555                        588 	.ds 2
      000557                        589 _matches_PARM_2:
      000557                        590 	.ds 1
      000558                        591 _matches_PARM_3:
      000558                        592 	.ds 1
      000559                        593 _matches_mods_10000_608:
      000559                        594 	.ds 1
      00055A                        595 _eligible_PARM_2:
      00055A                        596 	.ds 1
      00055B                        597 _eligible_PARM_3:
      00055B                        598 	.ds 1
      00055C                        599 _eligible_index_10000_611:
      00055C                        600 	.ds 1
      00055D                        601 _activate_PARM_2:
      00055D                        602 	.ds 1
      00055E                        603 _activate_PARM_3:
      00055E                        604 	.ds 1
      00055F                        605 _activate_reason_10000_623:
      00055F                        606 	.ds 1
      000560                        607 _activate_e_30000_627:
      000560                        608 	.ds 3
      000563                        609 _ak820_key_override_sync_PARM_2:
      000563                        610 	.ds 1
      000564                        611 _ak820_key_override_sync_mods_10000_630:
      000564                        612 	.ds 1
      000565                        613 _ak820_key_override_sync_reason_10000_631:
      000565                        614 	.ds 1
      000566                        615 _ak820_key_override_process_PARM_2:
      000566                        616 	.ds 1
      000567                        617 _ak820_key_override_process_PARM_3:
      000567                        618 	.ds 1
      000568                        619 _ak820_key_override_process_record_10000_635:
      000568                        620 	.ds 2
      00056A                        621 _ak820_key_override_mods_mods_10000_660:
      00056A                        622 	.ds 1
                                    623 ;--------------------------------------------------------
                                    624 ; absolute external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XABS    (ABS,XDATA)
                                    627 ;--------------------------------------------------------
                                    628 ; initialized external ram data
                                    629 ;--------------------------------------------------------
                                    630 	.area XISEG   (XDATA)
      000E67                        631 _source:
      000E67                        632 	.ds 1
      000E68                        633 _active:
      000E68                        634 	.ds 1
      000E69                        635 _enabled:
      000E69                        636 	.ds 1
                                    637 	.area HOME    (CODE)
                                    638 	.area GSINIT0 (CODE)
                                    639 	.area GSINIT1 (CODE)
                                    640 	.area GSINIT2 (CODE)
                                    641 	.area GSINIT3 (CODE)
                                    642 	.area GSINIT4 (CODE)
                                    643 	.area GSINIT5 (CODE)
                                    644 	.area GSINIT  (CODE)
                                    645 	.area GSFINAL (CODE)
                                    646 	.area CSEG    (CODE)
                                    647 ;--------------------------------------------------------
                                    648 ; global & static initialisations
                                    649 ;--------------------------------------------------------
                                    650 	.area HOME    (CODE)
                                    651 	.area GSINIT  (CODE)
                                    652 	.area GSFINAL (CODE)
                                    653 	.area GSINIT  (CODE)
                                    654 ;--------------------------------------------------------
                                    655 ; Home
                                    656 ;--------------------------------------------------------
                                    657 	.area HOME    (CODE)
                                    658 	.area HOME    (CODE)
                                    659 ;--------------------------------------------------------
                                    660 ; code
                                    661 ;--------------------------------------------------------
                                    662 	.area CSEG    (CODE)
                                    663 ;------------------------------------------------------------
                                    664 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    665 ;------------------------------------------------------------
                                    666 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    667 ;------------------------------------------------------------
                                    668 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    669 ;	-----------------------------------------
                           000007   670 	ar7 = 0x07
                           000006   671 	ar6 = 0x06
                           000005   672 	ar5 = 0x05
                           000004   673 	ar4 = 0x04
                           000003   674 	ar3 = 0x03
                           000002   675 	ar2 = 0x02
                           000001   676 	ar1 = 0x01
                           000000   677 	ar0 = 0x00
                                    678 ;	 function basic
                                    679 ;	-----------------------------------------
      003B87                        680 _basic:
      003B87 12 38 86         [24]  681 	lcall	_ak820_outline_0114
      003B8A 90 05 51         [24]  682 	mov	dptr,#_basic_key_10000_597
      003B8D 12 38 8B         [24]  683 	lcall	_ak820_outline_0115
      003B90 90 05 51         [24]  684 	mov	dptr,#_basic_key_10000_597
      003B93 12 38 39         [24]  685 	lcall	_ak820_outline_0057
      003B96 C3               [12]  686 	clr	c
      003B97 EE               [12]  687 	mov	a,r6
      003B98 94 04            [12]  688 	subb	a,#0x04
      003B9A EF               [12]  689 	mov	a,r7
      003B9B 94 00            [12]  690 	subb	a,#0x00
      003B9D 40 07            [24]  691 	jc	00103$
      003B9F 74 A4            [12]  692 	mov	a,#0xa4
      003BA1 9E               [12]  693 	subb	a,r6
      003BA2 E4               [12]  694 	clr	a
      003BA3 9F               [12]  695 	subb	a,r7
      003BA4 50 04            [24]  696 	jnc	00104$
                                    697 ;	free result
      003BA6                        698 00103$:
                                    699 ;	assignBit
      003BA6 C2 06            [12]  700 	clr	_basic_sloc0_1_0
      003BA8 80 02            [24]  701 	sjmp	00105$
      003BAA                        702 00104$:
                                    703 ;	assignBit
      003BAA D2 06            [12]  704 	setb	_basic_sloc0_1_0
      003BAC                        705 00105$:
      003BAC A2 06            [12]  706 	mov	c,_basic_sloc0_1_0
      003BAE 12 38 B5         [24]  707 	lcall	_ak820_outline_0154
      003BB1 22               [24]  708 	ret
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'ak820_key_override_valid'
                                    711 ;------------------------------------------------------------
                                    712 ;sloc0         Allocated with name '_ak820_key_override_valid_sloc0_1_0'
                                    713 ;sloc1         Allocated with name '_ak820_key_override_valid_sloc1_1_0'
                                    714 ;e             Allocated with name '_ak820_key_override_valid_e_10000_599'
                                    715 ;------------------------------------------------------------
                                    716 ;	keyboards/ajazz/ak820/ak820_key_override.c:14: bool ak820_key_override_valid(const vial_key_override_entry_t AK820_STATE_MEM *e) {
                                    717 ;	-----------------------------------------
                                    718 ;	 function ak820_key_override_valid
                                    719 ;	-----------------------------------------
      003BB2                        720 _ak820_key_override_valid:
      003BB2 12 38 86         [24]  721 	lcall	_ak820_outline_0114
      003BB5 90 05 53         [24]  722 	mov	dptr,#_ak820_key_override_valid_e_10000_599
      003BB8 12 38 8B         [24]  723 	lcall	_ak820_outline_0115
                                    724 ;	keyboards/ajazz/ak820/ak820_key_override.c:16: if (!(e->trigger | e->replacement | e->layers | e->trigger_mods |
      003BBB 90 05 53         [24]  725 	mov	dptr,#_ak820_key_override_valid_e_10000_599
      003BBE 12 37 F7         [24]  726 	lcall	_ak820_outline_0006
      003BC1 12 38 50         [24]  727 	lcall	_ak820_outline_0065
      003BC4 12 38 31         [24]  728 	lcall	_ak820_outline_0037
      003BC7 FA               [12]  729 	mov	r2,a
      003BC8 A3               [24]  730 	inc	dptr
      003BC9 E0               [24]  731 	movx	a,@dptr
      003BCA FB               [12]  732 	mov	r3,a
      003BCB EA               [12]  733 	mov	a,r2
      003BCC 4C               [12]  734 	orl	a,r4
      003BCD F8               [12]  735 	mov	r0,a
      003BCE EB               [12]  736 	mov	a,r3
      003BCF 4D               [12]  737 	orl	a,r5
      003BD0 F9               [12]  738 	mov	r1,a
      003BD1 12 42 0C         [24]  739 	lcall	_ak820_outline_0020
      003BD4 F5 0A            [12]  740 	mov	_ak820_key_override_valid_sloc0_1_0,a
      003BD6 A3               [24]  741 	inc	dptr
      003BD7 E0               [24]  742 	movx	a,@dptr
      003BD8 F5 0B            [12]  743 	mov	(_ak820_key_override_valid_sloc0_1_0 + 1),a
      003BDA E5 0A            [12]  744 	mov	a,_ak820_key_override_valid_sloc0_1_0
      003BDC 48               [12]  745 	orl	a,r0
      003BDD F5 0C            [12]  746 	mov	_ak820_key_override_valid_sloc1_1_0,a
      003BDF E5 0B            [12]  747 	mov	a,(_ak820_key_override_valid_sloc0_1_0 + 1)
      003BE1 49               [12]  748 	orl	a,r1
      003BE2 F5 0D            [12]  749 	mov	(_ak820_key_override_valid_sloc1_1_0 + 1),a
      003BE4 74 06            [12]  750 	mov	a,#0x06
      003BE6 12 38 0E         [24]  751 	lcall	_ak820_outline_0016
      003BE9 79 00            [12]  752 	mov	r1,#0x00
      003BEB 42 0C            [12]  753 	orl	_ak820_key_override_valid_sloc1_1_0,a
      003BED E9               [12]  754 	mov	a,r1
      003BEE 42 0D            [12]  755 	orl	(_ak820_key_override_valid_sloc1_1_0 + 1),a
                                    756 ;	keyboards/ajazz/ak820/ak820_key_override.c:17: e->negative_mod_mask | e->suppressed_mods | e->options)) return true;
      003BF0 74 07            [12]  757 	mov	a,#0x07
      003BF2 12 38 0E         [24]  758 	lcall	_ak820_outline_0016
      003BF5 79 00            [12]  759 	mov	r1,#0x00
      003BF7 42 0C            [12]  760 	orl	_ak820_key_override_valid_sloc1_1_0,a
      003BF9 E9               [12]  761 	mov	a,r1
      003BFA 42 0D            [12]  762 	orl	(_ak820_key_override_valid_sloc1_1_0 + 1),a
      003BFC 74 08            [12]  763 	mov	a,#0x08
      003BFE 12 38 0E         [24]  764 	lcall	_ak820_outline_0016
      003C01 79 00            [12]  765 	mov	r1,#0x00
      003C03 42 0C            [12]  766 	orl	_ak820_key_override_valid_sloc1_1_0,a
      003C05 E9               [12]  767 	mov	a,r1
      003C06 42 0D            [12]  768 	orl	(_ak820_key_override_valid_sloc1_1_0 + 1),a
      003C08 74 09            [12]  769 	mov	a,#0x09
      003C0A 12 38 0E         [24]  770 	lcall	_ak820_outline_0016
      003C0D FF               [12]  771 	mov	r7,a
      003C0E F9               [12]  772 	mov	r1,a
      003C0F 7E 00            [12]  773 	mov	r6,#0x00
      003C11 E5 0C            [12]  774 	mov	a,_ak820_key_override_valid_sloc1_1_0
      003C13 42 01            [12]  775 	orl	ar1,a
      003C15 E5 0D            [12]  776 	mov	a,(_ak820_key_override_valid_sloc1_1_0 + 1)
      003C17 42 06            [12]  777 	orl	ar6,a
      003C19 E9               [12]  778 	mov	a,r1
      003C1A 4E               [12]  779 	orl	a,r6
      003C1B 70 04            [24]  780 	jnz	00102$
      003C1D 75 82 01         [24]  781 	mov	dpl, #0x01
      003C20 22               [24]  782 	ret
      003C21                        783 00102$:
                                    784 ;	keyboards/ajazz/ak820/ak820_key_override.c:18: if (!basic(e->trigger) || !e->layers || (e->layers & ~0x3fu)) return false;
      003C21 12 38 A1         [24]  785 	lcall	_ak820_outline_0134
      003C24 C0 07            [24]  786 	push	ar7
      003C26 C0 03            [24]  787 	push	ar3
      003C28 C0 02            [24]  788 	push	ar2
      003C2A 12 3B 87         [24]  789 	lcall	_basic
      003C2D E5 82            [12]  790 	mov	a, dpl
      003C2F D0 02            [24]  791 	pop	ar2
      003C31 D0 03            [24]  792 	pop	ar3
      003C33 D0 07            [24]  793 	pop	ar7
      003C35 60 10            [24]  794 	jz	00103$
      003C37 E5 0A            [12]  795 	mov	a,_ak820_key_override_valid_sloc0_1_0
      003C39 45 0B            [12]  796 	orl	a,(_ak820_key_override_valid_sloc0_1_0 + 1)
      003C3B 60 0A            [24]  797 	jz	00103$
      003C3D E5 0A            [12]  798 	mov	a,_ak820_key_override_valid_sloc0_1_0
      003C3F 54 C0            [12]  799 	anl	a,#0xc0
      003C41 70 04            [24]  800 	jnz	00169$
      003C43 E5 0B            [12]  801 	mov	a,(_ak820_key_override_valid_sloc0_1_0 + 1)
      003C45 60 04            [24]  802 	jz	00104$
      003C47                        803 00169$:
      003C47                        804 00103$:
      003C47 75 82 00         [24]  805 	mov	dpl, #0x00
      003C4A 22               [24]  806 	ret
      003C4B                        807 00104$:
                                    808 ;	keyboards/ajazz/ak820/ak820_key_override.c:19: if (e->options & 0x40) return false;
      003C4B EF               [12]  809 	mov	a,r7
      003C4C 30 E6 04         [24]  810 	jnb	acc.6,00108$
      003C4F 75 82 00         [24]  811 	mov	dpl, #0x00
      003C52 22               [24]  812 	ret
      003C53                        813 00108$:
                                    814 ;	keyboards/ajazz/ak820/ak820_key_override.c:20: if (!(e->options & ACTIVATIONS)) return false;
      003C53 EF               [12]  815 	mov	a,r7
      003C54 54 07            [12]  816 	anl	a,#0x07
      003C56 70 03            [24]  817 	jnz	00110$
      003C58 F5 82            [12]  818 	mov	dpl,a
      003C5A 22               [24]  819 	ret
      003C5B                        820 00110$:
                                    821 ;	keyboards/ajazz/ak820/ak820_key_override.c:23: if (e->replacement && (e->replacement >= QK_MOD_TAP || !basic((uint8_t)e->replacement))) return false;
      003C5B EA               [12]  822 	mov	a,r2
      003C5C 4B               [12]  823 	orl	a,r3
      003C5D 60 1A            [24]  824 	jz	00112$
      003C5F 8A 06            [24]  825 	mov	ar6,r2
      003C61 8B 07            [24]  826 	mov	ar7,r3
      003C63 74 E0            [12]  827 	mov	a,#0x100 - 0x20
      003C65 2F               [12]  828 	add	a,r7
      003C66 40 0D            [24]  829 	jc	00111$
      003C68 7F 00            [12]  830 	mov	r7,#0x00
      003C6A 8A 82            [24]  831 	mov	dpl, r2
      003C6C 8F 83            [24]  832 	mov	dph, r7
      003C6E 12 3B 87         [24]  833 	lcall	_basic
      003C71 E5 82            [12]  834 	mov	a, dpl
      003C73 70 04            [24]  835 	jnz	00112$
      003C75                        836 00111$:
      003C75 75 82 00         [24]  837 	mov	dpl, #0x00
      003C78 22               [24]  838 	ret
      003C79                        839 00112$:
                                    840 ;	keyboards/ajazz/ak820/ak820_key_override.c:24: return true;
      003C79 75 82 01         [24]  841 	mov	dpl, #0x01
                                    842 ;	keyboards/ajazz/ak820/ak820_key_override.c:25: }
      003C7C 22               [24]  843 	ret
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'replacement_mods'
                                    846 ;------------------------------------------------------------
                                    847 ;key           Allocated with name '_replacement_mods_key_10000_606'
                                    848 ;mods          Allocated with name '_replacement_mods_mods_10000_607'
                                    849 ;------------------------------------------------------------
                                    850 ;	keyboards/ajazz/ak820/ak820_key_override.c:26: static uint8_t replacement_mods(uint16_t key) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function replacement_mods
                                    853 ;	-----------------------------------------
      003C7D                        854 _replacement_mods:
      003C7D 12 38 86         [24]  855 	lcall	_ak820_outline_0114
      003C80 90 05 55         [24]  856 	mov	dptr,#_replacement_mods_key_10000_606
      003C83 12 38 8B         [24]  857 	lcall	_ak820_outline_0115
                                    858 ;	keyboards/ajazz/ak820/ak820_key_override.c:27: uint8_t mods = QK_MODS_GET_MODS(key);
      003C86 90 05 55         [24]  859 	mov	dptr,#_replacement_mods_key_10000_606
      003C89 E0               [24]  860 	movx	a,@dptr
      003C8A A3               [24]  861 	inc	dptr
      003C8B E0               [24]  862 	movx	a,@dptr
      003C8C FE               [12]  863 	mov	r6,a
      003C8D 74 1F            [12]  864 	mov	a,#0x1f
      003C8F 5E               [12]  865 	anl	a,r6
                                    866 ;	keyboards/ajazz/ak820/ak820_key_override.c:28: return (mods & 0x10) ? (mods & 15) << 4 : mods;
      003C90 FF               [12]  867 	mov	r7,a
      003C91 30 E4 0C         [24]  868 	jnb	acc.4,00103$
      003C94 8F 06            [24]  869 	mov	ar6,r7
      003C96 53 06 0F         [24]  870 	anl	ar6,#0x0f
      003C99 EE               [12]  871 	mov	a,r6
      003C9A C4               [12]  872 	swap	a
      003C9B 54 F0            [12]  873 	anl	a,#0xf0
      003C9D FE               [12]  874 	mov	r6,a
      003C9E 80 02            [24]  875 	sjmp	00104$
      003CA0                        876 00103$:
      003CA0 8F 06            [24]  877 	mov	ar6,r7
      003CA2                        878 00104$:
      003CA2 8E 82            [24]  879 	mov	dpl, r6
                                    880 ;	keyboards/ajazz/ak820/ak820_key_override.c:29: }
      003CA4 22               [24]  881 	ret
                                    882 ;------------------------------------------------------------
                                    883 ;Allocation info for local variables in function 'matches'
                                    884 ;------------------------------------------------------------
                                    885 ;required      Allocated with name '_matches_PARM_2'
                                    886 ;one           Allocated with name '_matches_PARM_3'
                                    887 ;mods          Allocated with name '_matches_mods_10000_608'
                                    888 ;low           Allocated with name '_matches_low_10000_609'
                                    889 ;high          Allocated with name '_matches_high_10000_609'
                                    890 ;------------------------------------------------------------
                                    891 ;	keyboards/ajazz/ak820/ak820_key_override.c:31: static bool matches(uint8_t mods, uint8_t required, bool one) {
                                    892 ;	-----------------------------------------
                                    893 ;	 function matches
                                    894 ;	-----------------------------------------
      003CA5                        895 _matches:
      003CA5 E5 82            [12]  896 	mov	a,dpl
      003CA7 90 05 59         [24]  897 	mov	dptr,#_matches_mods_10000_608
      003CAA F0               [24]  898 	movx	@dptr,a
                                    899 ;	keyboards/ajazz/ak820/ak820_key_override.c:32: uint8_t low = required & 15, high = required >> 4;
      003CAB 90 05 57         [24]  900 	mov	dptr,#_matches_PARM_2
      003CAE E0               [24]  901 	movx	a,@dptr
      003CAF FF               [12]  902 	mov	r7,a
      003CB0 74 0F            [12]  903 	mov	a,#0x0f
      003CB2 5F               [12]  904 	anl	a,r7
      003CB3 FE               [12]  905 	mov	r6,a
      003CB4 EF               [12]  906 	mov	a,r7
      003CB5 C4               [12]  907 	swap	a
      003CB6 54 0F            [12]  908 	anl	a,#0x0f
      003CB8 FD               [12]  909 	mov	r5,a
                                    910 ;	keyboards/ajazz/ak820/ak820_key_override.c:33: if (one) return !required || (mods & required);
      003CB9 90 05 58         [24]  911 	mov	dptr,#_matches_PARM_3
      003CBC E0               [24]  912 	movx	a,@dptr
      003CBD 60 16            [24]  913 	jz	00102$
      003CBF EF               [12]  914 	mov	a,r7
      003CC0 60 0B            [24]  915 	jz	00106$
      003CC2 90 05 59         [24]  916 	mov	dptr,#_matches_mods_10000_608
      003CC5 E0               [24]  917 	movx	a,@dptr
      003CC6 5F               [12]  918 	anl	a,r7
      003CC7 70 04            [24]  919 	jnz	00106$
                                    920 ;	assignBit
      003CC9 C2 07            [12]  921 	clr	_matches_sloc0_1_0
      003CCB 80 02            [24]  922 	sjmp	00107$
      003CCD                        923 00106$:
                                    924 ;	assignBit
      003CCD D2 07            [12]  925 	setb	_matches_sloc0_1_0
      003CCF                        926 00107$:
      003CCF A2 07            [12]  927 	mov	c,_matches_sloc0_1_0
      003CD1 12 38 B5         [24]  928 	lcall	_ak820_outline_0154
      003CD4 22               [24]  929 	ret
      003CD5                        930 00102$:
                                    931 ;	keyboards/ajazz/ak820/ak820_key_override.c:34: return ((mods & low) | ((mods >> 4) & high)) == (low | high);
      003CD5 90 05 59         [24]  932 	mov	dptr,#_matches_mods_10000_608
      003CD8 E0               [24]  933 	movx	a,@dptr
      003CD9 FF               [12]  934 	mov	r7,a
      003CDA EE               [12]  935 	mov	a,r6
      003CDB 5F               [12]  936 	anl	a,r7
      003CDC FC               [12]  937 	mov	r4,a
      003CDD EF               [12]  938 	mov	a,r7
      003CDE C4               [12]  939 	swap	a
      003CDF 54 0F            [12]  940 	anl	a,#0x0f
      003CE1 FF               [12]  941 	mov	r7,a
      003CE2 ED               [12]  942 	mov	a,r5
      003CE3 5F               [12]  943 	anl	a,r7
      003CE4 42 04            [12]  944 	orl	ar4,a
      003CE6 ED               [12]  945 	mov	a,r5
      003CE7 42 06            [12]  946 	orl	ar6,a
      003CE9 EC               [12]  947 	mov	a,r4
      003CEA B5 06 03         [24]  948 	cjne	a,ar6,00132$
      003CED D3               [12]  949 	setb	c
      003CEE 80 01            [24]  950 	sjmp	00133$
      003CF0                        951 00132$:
      003CF0 C3               [12]  952 	clr	c
      003CF1                        953 00133$:
      003CF1 92 07            [24]  954 	mov  _matches_sloc0_1_0,c
      003CF3 12 38 B5         [24]  955 	lcall	_ak820_outline_0154
                                    956 ;	keyboards/ajazz/ak820/ak820_key_override.c:35: }
      003CF6 22               [24]  957 	ret
                                    958 ;------------------------------------------------------------
                                    959 ;Allocation info for local variables in function 'eligible'
                                    960 ;------------------------------------------------------------
                                    961 ;mods          Allocated with name '_eligible_PARM_2'
                                    962 ;layer         Allocated with name '_eligible_PARM_3'
                                    963 ;index         Allocated with name '_eligible_index_10000_611'
                                    964 ;e             Allocated with name '_eligible_e_10000_612'
                                    965 ;------------------------------------------------------------
                                    966 ;	keyboards/ajazz/ak820/ak820_key_override.c:36: static bool eligible(uint8_t index, uint8_t mods, uint8_t layer) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function eligible
                                    969 ;	-----------------------------------------
      003CF7                        970 _eligible:
      003CF7 E5 82            [12]  971 	mov	a,dpl
      003CF9 90 05 5C         [24]  972 	mov	dptr,#_eligible_index_10000_611
      003CFC F0               [24]  973 	movx	@dptr,a
                                    974 ;	keyboards/ajazz/ak820/ak820_key_override.c:37: vial_key_override_entry_t *e = &entries[index];
      003CFD E0               [24]  975 	movx	a,@dptr
      003CFE 12 41 FF         [24]  976 	lcall	_ak820_outline_0019
                                    977 ;	keyboards/ajazz/ak820/ak820_key_override.c:38: return layer < 6 && (e->layers & ((uint16_t)1 << layer)) &&
      003D01 90 05 5B         [24]  978 	mov	dptr,#_eligible_PARM_3
      003D04 E0               [24]  979 	movx	a,@dptr
      003D05 FD               [12]  980 	mov	r5,a
      003D06 BD 06 00         [24]  981 	cjne	r5,#0x06,00131$
      003D09                        982 00131$:
      003D09 50 54            [24]  983 	jnc	00103$
      003D0B 12 42 0C         [24]  984 	lcall	_ak820_outline_0020
      003D0E FB               [12]  985 	mov	r3,a
      003D0F A3               [24]  986 	inc	dptr
      003D10 E0               [24]  987 	movx	a,@dptr
      003D11 FC               [12]  988 	mov	r4,a
      003D12 8D F0            [24]  989 	mov	b,r5
      003D14 05 F0            [12]  990 	inc	b
      003D16 7D 01            [12]  991 	mov	r5,#0x01
      003D18 7A 00            [12]  992 	mov	r2,#0x00
      003D1A 80 06            [24]  993 	sjmp	00134$
      003D1C                        994 00133$:
      003D1C ED               [12]  995 	mov	a,r5
      003D1D 2D               [12]  996 	add	a,r5
      003D1E FD               [12]  997 	mov	r5,a
      003D1F EA               [12]  998 	mov	a,r2
      003D20 33               [12]  999 	rlc	a
      003D21 FA               [12] 1000 	mov	r2,a
      003D22                       1001 00134$:
      003D22 D5 F0 F7         [24] 1002 	djnz	b,00133$
      003D25 ED               [12] 1003 	mov	a,r5
      003D26 52 03            [12] 1004 	anl	ar3,a
      003D28 EA               [12] 1005 	mov	a,r2
      003D29 52 04            [12] 1006 	anl	ar4,a
      003D2B EB               [12] 1007 	mov	a,r3
      003D2C 4C               [12] 1008 	orl	a,r4
      003D2D 60 30            [24] 1009 	jz	00103$
                                   1010 ;	keyboards/ajazz/ak820/ak820_key_override.c:39: !(mods & e->negative_mod_mask) && matches(mods, e->trigger_mods, e->options & 8);
      003D2F 74 07            [12] 1011 	mov	a,#0x07
      003D31 12 38 0E         [24] 1012 	lcall	_ak820_outline_0016
      003D34 FD               [12] 1013 	mov	r5,a
      003D35 90 05 5A         [24] 1014 	mov	dptr,#_eligible_PARM_2
      003D38 E0               [24] 1015 	movx	a,@dptr
      003D39 FC               [12] 1016 	mov	r4,a
      003D3A ED               [12] 1017 	mov	a,r5
      003D3B 5C               [12] 1018 	anl	a,r4
      003D3C 70 21            [24] 1019 	jnz	00103$
      003D3E 74 06            [12] 1020 	mov	a,#0x06
      003D40 12 38 0E         [24] 1021 	lcall	_ak820_outline_0016
      003D43 FD               [12] 1022 	mov	r5,a
      003D44 74 09            [12] 1023 	mov	a,#0x09
      003D46 12 38 0E         [24] 1024 	lcall	_ak820_outline_0016
      003D49 90 05 58         [24] 1025 	mov	dptr,#_matches_PARM_3
      003D4C A2 E3            [12] 1026 	mov	c,acc.3
      003D4E E4               [12] 1027 	clr	a
      003D4F 33               [12] 1028 	rlc	a
      003D50 F0               [24] 1029 	movx	@dptr,a
      003D51 90 05 57         [24] 1030 	mov	dptr,#_matches_PARM_2
      003D54 ED               [12] 1031 	mov	a,r5
      003D55 F0               [24] 1032 	movx	@dptr,a
      003D56 8C 82            [24] 1033 	mov	dpl, r4
      003D58 12 3C A5         [24] 1034 	lcall	_matches
      003D5B E5 82            [12] 1035 	mov	a, dpl
      003D5D 70 04            [24] 1036 	jnz	00104$
      003D5F                       1037 00103$:
                                   1038 ;	assignBit
      003D5F C2 08            [12] 1039 	clr	_eligible_sloc0_1_0
      003D61 80 02            [24] 1040 	sjmp	00105$
      003D63                       1041 00104$:
                                   1042 ;	assignBit
      003D63 D2 08            [12] 1043 	setb	_eligible_sloc0_1_0
      003D65                       1044 00105$:
      003D65 A2 08            [12] 1045 	mov	c,_eligible_sloc0_1_0
      003D67 12 38 B5         [24] 1046 	lcall	_ak820_outline_0154
                                   1047 ;	keyboards/ajazz/ak820/ak820_key_override.c:40: }
      003D6A 22               [24] 1048 	ret
                                   1049 ;------------------------------------------------------------
                                   1050 ;Allocation info for local variables in function 'deactivate'
                                   1051 ;------------------------------------------------------------
                                   1052 ;	keyboards/ajazz/ak820/ak820_key_override.c:41: static void deactivate(void) {
                                   1053 ;	-----------------------------------------
                                   1054 ;	 function deactivate
                                   1055 ;	-----------------------------------------
      003D6B                       1056 _deactivate:
                                   1057 ;	keyboards/ajazz/ak820/ak820_key_override.c:42: if (active != NONE && (entries[active].options & 16)) hidden = true;
      003D6B 12 42 2B         [24] 1058 	lcall	_ak820_outline_0131
      003D6E BF FF 02         [24] 1059 	cjne	r7,#0xff,00120$
      003D71 80 12            [24] 1060 	sjmp	00102$
      003D73                       1061 00120$:
      003D73 EF               [12] 1062 	mov	a,r7
      003D74 12 41 FF         [24] 1063 	lcall	_ak820_outline_0019
      003D77 74 09            [12] 1064 	mov	a,#0x09
      003D79 12 38 0E         [24] 1065 	lcall	_ak820_outline_0016
      003D7C 30 E4 06         [24] 1066 	jnb	acc.4,00102$
      003D7F 90 05 50         [24] 1067 	mov	dptr,#_hidden
      003D82 74 01            [12] 1068 	mov	a,#0x01
      003D84 F0               [24] 1069 	movx	@dptr,a
      003D85                       1070 00102$:
                                   1071 ;	keyboards/ajazz/ak820/ak820_key_override.c:43: active = NONE;
      003D85 90 0E 68         [24] 1072 	mov	dptr,#_active
      003D88 74 FF            [12] 1073 	mov	a,#0xff
      003D8A F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	keyboards/ajazz/ak820/ak820_key_override.c:44: }
      003D8B 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'ak820_key_override_cancel'
                                   1079 ;------------------------------------------------------------
                                   1080 ;	keyboards/ajazz/ak820/ak820_key_override.c:45: void ak820_key_override_cancel(void) {
                                   1081 ;	-----------------------------------------
                                   1082 ;	 function ak820_key_override_cancel
                                   1083 ;	-----------------------------------------
      003D8C                       1084 _ak820_key_override_cancel:
                                   1085 ;	keyboards/ajazz/ak820/ak820_key_override.c:46: source = active = NONE;
      003D8C 90 0E 68         [24] 1086 	mov	dptr,#_active
      003D8F 74 FF            [12] 1087 	mov	a,#0xff
      003D91 F0               [24] 1088 	movx	@dptr,a
      003D92 90 0E 67         [24] 1089 	mov	dptr,#_source
      003D95 F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	keyboards/ajazz/ak820/ak820_key_override.c:47: previous_mods = 0;
      003D96 90 05 4E         [24] 1092 	mov	dptr,#_previous_mods
      003D99 E4               [12] 1093 	clr	a
      003D9A F0               [24] 1094 	movx	@dptr,a
                                   1095 ;	keyboards/ajazz/ak820/ak820_key_override.c:48: blocked = hidden = false;
      003D9B 90 05 50         [24] 1096 	mov	dptr,#_hidden
      003D9E F0               [24] 1097 	movx	@dptr,a
      003D9F 90 05 4F         [24] 1098 	mov	dptr,#_blocked
      003DA2 F0               [24] 1099 	movx	@dptr,a
                                   1100 ;	keyboards/ajazz/ak820/ak820_key_override.c:49: }
      003DA3 22               [24] 1101 	ret
                                   1102 ;------------------------------------------------------------
                                   1103 ;Allocation info for local variables in function 'ak820_key_override_reload'
                                   1104 ;------------------------------------------------------------
                                   1105 ;i             Allocated with name '_ak820_key_override_reload_i_20000_620'
                                   1106 ;------------------------------------------------------------
                                   1107 ;	keyboards/ajazz/ak820/ak820_key_override.c:50: void ak820_key_override_reload(void) {
                                   1108 ;	-----------------------------------------
                                   1109 ;	 function ak820_key_override_reload
                                   1110 ;	-----------------------------------------
      003DA4                       1111 _ak820_key_override_reload:
                                   1112 ;	keyboards/ajazz/ak820/ak820_key_override.c:51: ak820_key_override_cancel();
      003DA4 12 3D 8C         [24] 1113 	lcall	_ak820_key_override_cancel
                                   1114 ;	keyboards/ajazz/ak820/ak820_key_override.c:52: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003DA7 7F 00            [12] 1115 	mov	r7,#0x00
      003DA9                       1116 00106$:
      003DA9 BF 08 00         [24] 1117 	cjne	r7,#0x08,00132$
      003DAC                       1118 00132$:
      003DAC 50 45            [24] 1119 	jnc	00108$
                                   1120 ;	keyboards/ajazz/ak820/ak820_key_override.c:53: if (dynamic_keymap_get_key_override(i, &entries[i]) || !ak820_key_override_valid(&entries[i]))
      003DAE 12 42 16         [24] 1121 	lcall	_ak820_outline_0040
      003DB1 FE               [12] 1122 	mov	r6,a
      003DB2 90 0B 8E         [24] 1123 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      003DB5 ED               [12] 1124 	mov	a,r5
      003DB6 F0               [24] 1125 	movx	@dptr,a
      003DB7 EE               [12] 1126 	mov	a,r6
      003DB8 12 38 56         [24] 1127 	lcall	_ak820_outline_0077
      003DBB 8F 82            [24] 1128 	mov	dpl, r7
      003DBD C0 07            [24] 1129 	push	ar7
      003DBF C0 06            [24] 1130 	push	ar6
      003DC1 C0 05            [24] 1131 	push	ar5
      003DC3 12 8D F4         [24] 1132 	lcall	_dynamic_keymap_get_key_override
      003DC6 12 38 95         [24] 1133 	lcall	_ak820_outline_0130
      003DC9 D0 05            [24] 1134 	pop	ar5
      003DCB D0 06            [24] 1135 	pop	ar6
      003DCD D0 07            [24] 1136 	pop	ar7
      003DCF 45 F0            [12] 1137 	orl	a,b
      003DD1 70 0E            [24] 1138 	jnz	00101$
      003DD3 12 38 AB         [24] 1139 	lcall	_ak820_outline_0145
      003DD6 C0 07            [24] 1140 	push	ar7
      003DD8 12 3B B2         [24] 1141 	lcall	_ak820_key_override_valid
      003DDB E5 82            [12] 1142 	mov	a, dpl
      003DDD D0 07            [24] 1143 	pop	ar7
      003DDF 70 0F            [24] 1144 	jnz	00107$
      003DE1                       1145 00101$:
                                   1146 ;	keyboards/ajazz/ak820/ak820_key_override.c:54: entries[i].options = 0;
      003DE1 12 42 16         [24] 1147 	lcall	_ak820_outline_0040
      003DE4 FE               [12] 1148 	mov	r6,a
      003DE5 74 09            [12] 1149 	mov	a,#0x09
      003DE7 2D               [12] 1150 	add	a, r5
      003DE8 F5 82            [12] 1151 	mov	dpl,a
      003DEA E4               [12] 1152 	clr	a
      003DEB 3E               [12] 1153 	addc	a, r6
      003DEC F5 83            [12] 1154 	mov	dph,a
      003DEE E4               [12] 1155 	clr	a
      003DEF F0               [24] 1156 	movx	@dptr,a
      003DF0                       1157 00107$:
                                   1158 ;	keyboards/ajazz/ak820/ak820_key_override.c:52: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003DF0 0F               [12] 1159 	inc	r7
      003DF1 80 B6            [24] 1160 	sjmp	00106$
      003DF3                       1161 00108$:
                                   1162 ;	keyboards/ajazz/ak820/ak820_key_override.c:56: }
      003DF3 22               [24] 1163 	ret
                                   1164 ;------------------------------------------------------------
                                   1165 ;Allocation info for local variables in function 'activate'
                                   1166 ;------------------------------------------------------------
                                   1167 ;sloc0         Allocated with name '_activate_sloc0_1_0'
                                   1168 ;sloc1         Allocated with name '_activate_sloc1_1_0'
                                   1169 ;sloc2         Allocated with name '_activate_sloc2_1_0'
                                   1170 ;mods          Allocated with name '_activate_PARM_2'
                                   1171 ;layer         Allocated with name '_activate_PARM_3'
                                   1172 ;reason        Allocated with name '_activate_reason_10000_623'
                                   1173 ;i             Allocated with name '_activate_i_20000_626'
                                   1174 ;e             Allocated with name '_activate_e_30000_627'
                                   1175 ;------------------------------------------------------------
                                   1176 ;	keyboards/ajazz/ak820/ak820_key_override.c:57: static void activate(uint8_t reason, uint8_t mods, uint8_t layer) {
                                   1177 ;	-----------------------------------------
                                   1178 ;	 function activate
                                   1179 ;	-----------------------------------------
      003DF4                       1180 _activate:
      003DF4 E5 82            [12] 1181 	mov	a,dpl
      003DF6 90 05 5F         [24] 1182 	mov	dptr,#_activate_reason_10000_623
      003DF9 F0               [24] 1183 	movx	@dptr,a
                                   1184 ;	keyboards/ajazz/ak820/ak820_key_override.c:58: if (!enabled || source == NONE || blocked || hidden || active != NONE) return;
      003DFA 90 0E 69         [24] 1185 	mov	dptr,#_enabled
      003DFD E0               [24] 1186 	movx	a,@dptr
      003DFE 60 1D            [24] 1187 	jz	00101$
      003E00 90 0E 67         [24] 1188 	mov	dptr,#_source
      003E03 E0               [24] 1189 	movx	a,@dptr
      003E04 FF               [12] 1190 	mov	r7,a
      003E05 BF FF 01         [24] 1191 	cjne	r7,#0xff,00215$
      003E08 22               [24] 1192 	ret
      003E09                       1193 00215$:
      003E09 90 05 4F         [24] 1194 	mov	dptr,#_blocked
      003E0C E0               [24] 1195 	movx	a,@dptr
      003E0D 70 0E            [24] 1196 	jnz	00101$
      003E0F 90 05 50         [24] 1197 	mov	dptr,#_hidden
      003E12 E0               [24] 1198 	movx	a,@dptr
      003E13 70 08            [24] 1199 	jnz	00101$
      003E15 12 42 2B         [24] 1200 	lcall	_ak820_outline_0131
      003E18 BF FF 02         [24] 1201 	cjne	r7,#0xff,00218$
      003E1B 80 01            [24] 1202 	sjmp	00148$
      003E1D                       1203 00218$:
      003E1D                       1204 00101$:
      003E1D 22               [24] 1205 	ret
                                   1206 ;	keyboards/ajazz/ak820/ak820_key_override.c:59: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003E1E                       1207 00148$:
      003E1E 90 05 5D         [24] 1208 	mov	dptr,#_activate_PARM_2
      003E21 E0               [24] 1209 	movx	a,@dptr
      003E22 FF               [12] 1210 	mov	r7,a
      003E23 8F 11            [24] 1211 	mov	_activate_sloc1_1_0,r7
      003E25 90 05 5E         [24] 1212 	mov	dptr,#_activate_PARM_3
      003E28 E0               [24] 1213 	movx	a,@dptr
      003E29 FD               [12] 1214 	mov	r5,a
      003E2A 90 05 5F         [24] 1215 	mov	dptr,#_activate_reason_10000_623
      003E2D E0               [24] 1216 	movx	a,@dptr
      003E2E FC               [12] 1217 	mov	r4,a
      003E2F 74 04            [12] 1218 	mov	a,#0x04
      003E31 5C               [12] 1219 	anl	a,r4
      003E32 F5 12            [12] 1220 	mov	_activate_sloc2_1_0,a
      003E34 75 13 00         [24] 1221 	mov	(_activate_sloc2_1_0 + 1),#0x00
      003E37 79 00            [12] 1222 	mov	r1,#0x00
      003E39                       1223 00119$:
      003E39 B9 08 00         [24] 1224 	cjne	r1,#0x08,00219$
      003E3C                       1225 00219$:
      003E3C 40 01            [24] 1226 	jc	00220$
      003E3E 22               [24] 1227 	ret
      003E3F                       1228 00220$:
                                   1229 ;	keyboards/ajazz/ak820/ak820_key_override.c:60: vial_key_override_entry_t *e = &entries[i];
      003E3F C0 05            [24] 1230 	push	ar5
      003E41 E9               [12] 1231 	mov	a,r1
      003E42 75 F0 0A         [24] 1232 	mov	b,#0x0a
      003E45 A4               [48] 1233 	mul	ab
      003E46 24 FD            [12] 1234 	add	a, #_entries
      003E48 F8               [12] 1235 	mov	r0,a
      003E49 74 04            [12] 1236 	mov	a,#(_entries >> 8)
      003E4B 35 F0            [12] 1237 	addc	a, b
      003E4D FD               [12] 1238 	mov	r5,a
      003E4E 88 0E            [24] 1239 	mov	_activate_sloc0_1_0,r0
      003E50 8D 0F            [24] 1240 	mov	(_activate_sloc0_1_0 + 1),r5
      003E52 75 10 00         [24] 1241 	mov	(_activate_sloc0_1_0 + 2),#0x00
      003E55 90 05 60         [24] 1242 	mov	dptr,#_activate_e_30000_627
      003E58 E5 0E            [12] 1243 	mov	a,_activate_sloc0_1_0
      003E5A F0               [24] 1244 	movx	@dptr,a
      003E5B E5 0F            [12] 1245 	mov	a,(_activate_sloc0_1_0 + 1)
      003E5D A3               [24] 1246 	inc	dptr
      003E5E F0               [24] 1247 	movx	@dptr,a
      003E5F E5 10            [12] 1248 	mov	a,(_activate_sloc0_1_0 + 2)
      003E61 A3               [24] 1249 	inc	dptr
      003E62 F0               [24] 1250 	movx	@dptr,a
                                   1251 ;	keyboards/ajazz/ak820/ak820_key_override.c:61: if (e->trigger == trigger && (e->options & ENABLED) && (e->options & reason) &&
      003E63 85 0E 82         [24] 1252 	mov	dpl,_activate_sloc0_1_0
      003E66 85 0F 83         [24] 1253 	mov	dph,(_activate_sloc0_1_0 + 1)
      003E69 E0               [24] 1254 	movx	a,@dptr
      003E6A F8               [12] 1255 	mov	r0,a
      003E6B A3               [24] 1256 	inc	dptr
      003E6C E0               [24] 1257 	movx	a,@dptr
      003E6D FD               [12] 1258 	mov	r5,a
      003E6E 90 05 4D         [24] 1259 	mov	dptr,#_trigger
      003E71 E0               [24] 1260 	movx	a,@dptr
      003E72 FB               [12] 1261 	mov	r3,a
      003E73 7E 00            [12] 1262 	mov	r6,#0x00
      003E75 E8               [12] 1263 	mov	a,r0
      003E76 B5 03 06         [24] 1264 	cjne	a,ar3,00221$
      003E79 ED               [12] 1265 	mov	a,r5
      003E7A B5 06 02         [24] 1266 	cjne	a,ar6,00221$
      003E7D 80 05            [24] 1267 	sjmp	00222$
      003E7F                       1268 00221$:
      003E7F D0 05            [24] 1269 	pop	ar5
      003E81 02 3F 3E         [24] 1270 	ljmp	00120$
      003E84                       1271 00222$:
      003E84 D0 05            [24] 1272 	pop	ar5
      003E86 74 09            [12] 1273 	mov	a,#0x09
      003E88 25 0E            [12] 1274 	add	a, _activate_sloc0_1_0
      003E8A FA               [12] 1275 	mov	r2,a
      003E8B E4               [12] 1276 	clr	a
      003E8C 35 0F            [12] 1277 	addc	a, (_activate_sloc0_1_0 + 1)
      003E8E FB               [12] 1278 	mov	r3,a
      003E8F AE 10            [24] 1279 	mov	r6,(_activate_sloc0_1_0 + 2)
      003E91 12 38 B0         [24] 1280 	lcall	_ak820_outline_0146
      003E94 8E F0            [24] 1281 	mov	b,r6
      003E96 12 C2 3E         [24] 1282 	lcall	__gptrget
      003E99 FE               [12] 1283 	mov	r6,a
      003E9A 20 E7 03         [24] 1284 	jb	acc.7,00223$
      003E9D 02 3F 3E         [24] 1285 	ljmp	00120$
      003EA0                       1286 00223$:
      003EA0 EC               [12] 1287 	mov	a,r4
      003EA1 5E               [12] 1288 	anl	a,r6
      003EA2 70 03            [24] 1289 	jnz	00224$
      003EA4 02 3F 3E         [24] 1290 	ljmp	00120$
      003EA7                       1291 00224$:
                                   1292 ;	keyboards/ajazz/ak820/ak820_key_override.c:62: ((reason & 1) || ((reason & 2) && (e->trigger_mods & mods & ~previous_mods)) ||
      003EA7 EC               [12] 1293 	mov	a,r4
      003EA8 20 E0 69         [24] 1294 	jb	acc.0,00116$
      003EAB EC               [12] 1295 	mov	a,r4
      003EAC 30 E1 32         [24] 1296 	jnb	acc.1,00114$
      003EAF 74 06            [12] 1297 	mov	a,#0x06
      003EB1 25 0E            [12] 1298 	add	a, _activate_sloc0_1_0
      003EB3 FA               [12] 1299 	mov	r2,a
      003EB4 E4               [12] 1300 	clr	a
      003EB5 35 0F            [12] 1301 	addc	a, (_activate_sloc0_1_0 + 1)
      003EB7 FB               [12] 1302 	mov	r3,a
      003EB8 AE 10            [24] 1303 	mov	r6,(_activate_sloc0_1_0 + 2)
      003EBA 12 38 B0         [24] 1304 	lcall	_ak820_outline_0146
      003EBD 8E F0            [24] 1305 	mov	b,r6
      003EBF 12 C2 3E         [24] 1306 	lcall	__gptrget
      003EC2 FA               [12] 1307 	mov	r2,a
      003EC3 EF               [12] 1308 	mov	a,r7
      003EC4 52 02            [12] 1309 	anl	ar2,a
      003EC6 90 05 4E         [24] 1310 	mov	dptr,#_previous_mods
      003EC9 E0               [24] 1311 	movx	a,@dptr
      003ECA FB               [12] 1312 	mov	r3,a
      003ECB 7E 00            [12] 1313 	mov	r6,#0x00
      003ECD 63 03 FF         [24] 1314 	xrl	ar3,#0xff
      003ED0 63 06 FF         [24] 1315 	xrl	ar6,#0xff
      003ED3 8A 00            [24] 1316 	mov	ar0,r2
      003ED5 7A 00            [12] 1317 	mov	r2,#0x00
      003ED7 E8               [12] 1318 	mov	a,r0
      003ED8 52 03            [12] 1319 	anl	ar3,a
      003EDA EA               [12] 1320 	mov	a,r2
      003EDB 52 06            [12] 1321 	anl	ar6,a
      003EDD EB               [12] 1322 	mov	a,r3
      003EDE 4E               [12] 1323 	orl	a,r6
      003EDF 70 33            [24] 1324 	jnz	00116$
      003EE1                       1325 00114$:
                                   1326 ;	keyboards/ajazz/ak820/ak820_key_override.c:63: ((reason & 4) && (e->negative_mod_mask & previous_mods & ~mods))) && eligible(i, mods, layer)) {
      003EE1 E5 12            [12] 1327 	mov	a,_activate_sloc2_1_0
      003EE3 45 13            [12] 1328 	orl	a,(_activate_sloc2_1_0 + 1)
      003EE5 60 57            [24] 1329 	jz	00120$
      003EE7 90 05 60         [24] 1330 	mov	dptr,#_activate_e_30000_627
      003EEA E0               [24] 1331 	movx	a,@dptr
      003EEB FB               [12] 1332 	mov	r3,a
      003EEC A3               [24] 1333 	inc	dptr
      003EED E0               [24] 1334 	movx	a,@dptr
      003EEE FE               [12] 1335 	mov	r6,a
      003EEF 74 07            [12] 1336 	mov	a,#0x07
      003EF1 2B               [12] 1337 	add	a, r3
      003EF2 12 42 23         [24] 1338 	lcall	_ak820_outline_0083
      003EF5 FE               [12] 1339 	mov	r6,a
      003EF6 90 05 4E         [24] 1340 	mov	dptr,#_previous_mods
      003EF9 E0               [24] 1341 	movx	a,@dptr
      003EFA 52 06            [12] 1342 	anl	ar6,a
      003EFC 8F 02            [24] 1343 	mov	ar2,r7
      003EFE 7B 00            [12] 1344 	mov	r3,#0x00
      003F00 63 02 FF         [24] 1345 	xrl	ar2,#0xff
      003F03 63 03 FF         [24] 1346 	xrl	ar3,#0xff
      003F06 8E 00            [24] 1347 	mov	ar0,r6
      003F08 7E 00            [12] 1348 	mov	r6,#0x00
      003F0A E8               [12] 1349 	mov	a,r0
      003F0B 52 02            [12] 1350 	anl	ar2,a
      003F0D EE               [12] 1351 	mov	a,r6
      003F0E 52 03            [12] 1352 	anl	ar3,a
      003F10 EA               [12] 1353 	mov	a,r2
      003F11 4B               [12] 1354 	orl	a,r3
      003F12 60 2A            [24] 1355 	jz	00120$
      003F14                       1356 00116$:
      003F14 90 05 5A         [24] 1357 	mov	dptr,#_eligible_PARM_2
      003F17 E5 11            [12] 1358 	mov	a,_activate_sloc1_1_0
      003F19 F0               [24] 1359 	movx	@dptr,a
      003F1A 90 05 5B         [24] 1360 	mov	dptr,#_eligible_PARM_3
      003F1D ED               [12] 1361 	mov	a,r5
      003F1E F0               [24] 1362 	movx	@dptr,a
      003F1F 89 82            [24] 1363 	mov	dpl, r1
      003F21 C0 07            [24] 1364 	push	ar7
      003F23 C0 05            [24] 1365 	push	ar5
      003F25 C0 04            [24] 1366 	push	ar4
      003F27 C0 01            [24] 1367 	push	ar1
      003F29 12 3C F7         [24] 1368 	lcall	_eligible
      003F2C E5 82            [12] 1369 	mov	a, dpl
      003F2E D0 01            [24] 1370 	pop	ar1
      003F30 D0 04            [24] 1371 	pop	ar4
      003F32 D0 05            [24] 1372 	pop	ar5
      003F34 D0 07            [24] 1373 	pop	ar7
      003F36 60 06            [24] 1374 	jz	00120$
                                   1375 ;	keyboards/ajazz/ak820/ak820_key_override.c:64: active = i;
      003F38 90 0E 68         [24] 1376 	mov	dptr,#_active
      003F3B E9               [12] 1377 	mov	a,r1
      003F3C F0               [24] 1378 	movx	@dptr,a
                                   1379 ;	keyboards/ajazz/ak820/ak820_key_override.c:65: return;
      003F3D 22               [24] 1380 	ret
      003F3E                       1381 00120$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_key_override.c:59: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      003F3E 09               [12] 1383 	inc	r1
                                   1384 ;	keyboards/ajazz/ak820/ak820_key_override.c:68: }
      003F3F 02 3E 39         [24] 1385 	ljmp	00119$
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'ak820_key_override_sync'
                                   1388 ;------------------------------------------------------------
                                   1389 ;layer         Allocated with name '_ak820_key_override_sync_PARM_2'
                                   1390 ;mods          Allocated with name '_ak820_key_override_sync_mods_10000_630'
                                   1391 ;reason        Allocated with name '_ak820_key_override_sync_reason_10000_631'
                                   1392 ;------------------------------------------------------------
                                   1393 ;	keyboards/ajazz/ak820/ak820_key_override.c:69: void ak820_key_override_sync(uint8_t mods, uint8_t layer) {
                                   1394 ;	-----------------------------------------
                                   1395 ;	 function ak820_key_override_sync
                                   1396 ;	-----------------------------------------
      003F42                       1397 _ak820_key_override_sync:
      003F42 E5 82            [12] 1398 	mov	a,dpl
      003F44 90 05 64         [24] 1399 	mov	dptr,#_ak820_key_override_sync_mods_10000_630
      003F47 F0               [24] 1400 	movx	@dptr,a
                                   1401 ;	keyboards/ajazz/ak820/ak820_key_override.c:70: uint8_t reason = 0;
      003F48 90 05 65         [24] 1402 	mov	dptr,#_ak820_key_override_sync_reason_10000_631
      003F4B E4               [12] 1403 	clr	a
      003F4C F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	keyboards/ajazz/ak820/ak820_key_override.c:71: if (active != NONE && !eligible(active, mods, layer)) deactivate();
      003F4D 12 42 2B         [24] 1406 	lcall	_ak820_outline_0131
      003F50 BF FF 02         [24] 1407 	cjne	r7,#0xff,00138$
      003F53 80 18            [24] 1408 	sjmp	00102$
      003F55                       1409 00138$:
      003F55 12 42 31         [24] 1410 	lcall	_ak820_outline_0141
      003F58 90 05 5A         [24] 1411 	mov	dptr,#_eligible_PARM_2
      003F5B EE               [12] 1412 	mov	a,r6
      003F5C F0               [24] 1413 	movx	@dptr,a
      003F5D 90 05 5B         [24] 1414 	mov	dptr,#_eligible_PARM_3
      003F60 12 42 41         [24] 1415 	lcall	_ak820_outline_0199
      003F63 12 3C F7         [24] 1416 	lcall	_eligible
      003F66 E5 82            [12] 1417 	mov	a, dpl
      003F68 70 03            [24] 1418 	jnz	00102$
      003F6A 12 3D 6B         [24] 1419 	lcall	_deactivate
      003F6D                       1420 00102$:
                                   1421 ;	keyboards/ajazz/ak820/ak820_key_override.c:72: if (mods & ~previous_mods) reason |= 2;
      003F6D 90 05 4E         [24] 1422 	mov	dptr,#_previous_mods
      003F70 E0               [24] 1423 	movx	a,@dptr
      003F71 FE               [12] 1424 	mov	r6,a
      003F72 7F 00            [12] 1425 	mov	r7,#0x00
      003F74 74 FF            [12] 1426 	mov	a,#0xff
      003F76 6E               [12] 1427 	xrl	a,r6
      003F77 FC               [12] 1428 	mov	r4,a
      003F78 74 FF            [12] 1429 	mov	a,#0xff
      003F7A 6F               [12] 1430 	xrl	a,r7
      003F7B FD               [12] 1431 	mov	r5,a
      003F7C 90 05 64         [24] 1432 	mov	dptr,#_ak820_key_override_sync_mods_10000_630
      003F7F E0               [24] 1433 	movx	a,@dptr
      003F80 FA               [12] 1434 	mov	r2,a
      003F81 7B 00            [12] 1435 	mov	r3,#0x00
      003F83 52 04            [12] 1436 	anl	ar4,a
      003F85 EB               [12] 1437 	mov	a,r3
      003F86 52 05            [12] 1438 	anl	ar5,a
      003F88 EC               [12] 1439 	mov	a,r4
      003F89 4D               [12] 1440 	orl	a,r5
      003F8A 60 06            [24] 1441 	jz	00105$
      003F8C 90 05 65         [24] 1442 	mov	dptr,#_ak820_key_override_sync_reason_10000_631
      003F8F 74 02            [12] 1443 	mov	a,#0x02
      003F91 F0               [24] 1444 	movx	@dptr,a
      003F92                       1445 00105$:
                                   1446 ;	keyboards/ajazz/ak820/ak820_key_override.c:73: if (previous_mods & ~mods) reason |= 4;
      003F92 63 02 FF         [24] 1447 	xrl	ar2,#0xff
      003F95 63 03 FF         [24] 1448 	xrl	ar3,#0xff
      003F98 EA               [12] 1449 	mov	a,r2
      003F99 52 06            [12] 1450 	anl	ar6,a
      003F9B EB               [12] 1451 	mov	a,r3
      003F9C 52 07            [12] 1452 	anl	ar7,a
      003F9E EE               [12] 1453 	mov	a,r6
      003F9F 4F               [12] 1454 	orl	a,r7
      003FA0 60 08            [24] 1455 	jz	00107$
      003FA2 90 05 65         [24] 1456 	mov	dptr,#_ak820_key_override_sync_reason_10000_631
      003FA5 E0               [24] 1457 	movx	a,@dptr
      003FA6 43 E0 04         [24] 1458 	orl	acc,#0x04
      003FA9 F0               [24] 1459 	movx	@dptr,a
      003FAA                       1460 00107$:
                                   1461 ;	keyboards/ajazz/ak820/ak820_key_override.c:74: activate(reason, mods, layer);
      003FAA 90 05 65         [24] 1462 	mov	dptr,#_ak820_key_override_sync_reason_10000_631
      003FAD E0               [24] 1463 	movx	a,@dptr
      003FAE FF               [12] 1464 	mov	r7,a
      003FAF 12 42 31         [24] 1465 	lcall	_ak820_outline_0141
      003FB2 90 05 5D         [24] 1466 	mov	dptr,#_activate_PARM_2
      003FB5 EE               [12] 1467 	mov	a,r6
      003FB6 F0               [24] 1468 	movx	@dptr,a
      003FB7 90 05 5E         [24] 1469 	mov	dptr,#_activate_PARM_3
      003FBA 12 42 41         [24] 1470 	lcall	_ak820_outline_0199
      003FBD C0 06            [24] 1471 	push	ar6
      003FBF 12 3D F4         [24] 1472 	lcall	_activate
      003FC2 D0 06            [24] 1473 	pop	ar6
                                   1474 ;	keyboards/ajazz/ak820/ak820_key_override.c:75: previous_mods = mods;
      003FC4 90 05 4E         [24] 1475 	mov	dptr,#_previous_mods
      003FC7 EE               [12] 1476 	mov	a,r6
      003FC8 F0               [24] 1477 	movx	@dptr,a
                                   1478 ;	keyboards/ajazz/ak820/ak820_key_override.c:76: }
      003FC9 22               [24] 1479 	ret
                                   1480 ;------------------------------------------------------------
                                   1481 ;Allocation info for local variables in function 'ak820_key_override_process'
                                   1482 ;------------------------------------------------------------
                                   1483 ;sloc0         Allocated with name '_ak820_key_override_process_sloc0_1_0'
                                   1484 ;sloc1         Allocated with name '_ak820_key_override_process_sloc1_1_0'
                                   1485 ;sloc2         Allocated with name '_ak820_key_override_process_sloc2_1_0'
                                   1486 ;mods          Allocated with name '_ak820_key_override_process_PARM_2'
                                   1487 ;layer         Allocated with name '_ak820_key_override_process_PARM_3'
                                   1488 ;record        Allocated with name '_ak820_key_override_process_record_10000_635'
                                   1489 ;key           Allocated with name '_ak820_key_override_process_key_10000_636'
                                   1490 ;id            Allocated with name '_ak820_key_override_process_id_10000_636'
                                   1491 ;i             Allocated with name '_ak820_key_override_process_i_20000_653'
                                   1492 ;------------------------------------------------------------
                                   1493 ;	keyboards/ajazz/ak820/ak820_key_override.c:77: bool ak820_key_override_process(keyrecord_t AK820_STATE_MEM *record, uint8_t mods, uint8_t layer) {
                                   1494 ;	-----------------------------------------
                                   1495 ;	 function ak820_key_override_process
                                   1496 ;	-----------------------------------------
      003FCA                       1497 _ak820_key_override_process:
      003FCA 12 38 86         [24] 1498 	lcall	_ak820_outline_0114
      003FCD 90 05 68         [24] 1499 	mov	dptr,#_ak820_key_override_process_record_10000_635
      003FD0 12 38 8B         [24] 1500 	lcall	_ak820_outline_0115
                                   1501 ;	keyboards/ajazz/ak820/ak820_key_override.c:78: uint16_t key = record->keycode;
      003FD3 90 05 68         [24] 1502 	mov	dptr,#_ak820_key_override_process_record_10000_635
      003FD6 12 37 E3         [24] 1503 	lcall	_ak820_outline_0002
                                   1504 ;	keyboards/ajazz/ak820/ak820_key_override.c:80: ak820_key_override_sync(mods, layer);
      003FD9 90 05 66         [24] 1505 	mov	dptr,#_ak820_key_override_process_PARM_2
      003FDC E0               [24] 1506 	movx	a,@dptr
      003FDD FB               [12] 1507 	mov	r3,a
      003FDE 90 05 67         [24] 1508 	mov	dptr,#_ak820_key_override_process_PARM_3
      003FE1 E0               [24] 1509 	movx	a,@dptr
      003FE2 FA               [12] 1510 	mov	r2,a
      003FE3 90 05 63         [24] 1511 	mov	dptr,#_ak820_key_override_sync_PARM_2
      003FE6 F0               [24] 1512 	movx	@dptr,a
      003FE7 8B 82            [24] 1513 	mov	dpl, r3
      003FE9 C0 07            [24] 1514 	push	ar7
      003FEB C0 06            [24] 1515 	push	ar6
      003FED C0 05            [24] 1516 	push	ar5
      003FEF C0 04            [24] 1517 	push	ar4
      003FF1 C0 03            [24] 1518 	push	ar3
      003FF3 C0 02            [24] 1519 	push	ar2
      003FF5 12 3F 42         [24] 1520 	lcall	_ak820_key_override_sync
      003FF8 D0 02            [24] 1521 	pop	ar2
      003FFA D0 03            [24] 1522 	pop	ar3
      003FFC D0 04            [24] 1523 	pop	ar4
      003FFE D0 05            [24] 1524 	pop	ar5
      004000 D0 06            [24] 1525 	pop	ar6
      004002 D0 07            [24] 1526 	pop	ar7
                                   1527 ;	keyboards/ajazz/ak820/ak820_key_override.c:81: if (key >= QK_KEY_OVERRIDE_TOGGLE && key <= QK_KEY_OVERRIDE_OFF) {
      004004 8C 00            [24] 1528 	mov	ar0,r4
      004006 8D 01            [24] 1529 	mov	ar1,r5
      004008 C3               [12] 1530 	clr	c
      004009 E8               [12] 1531 	mov	a,r0
      00400A 94 5D            [12] 1532 	subb	a,#0x5d
      00400C E9               [12] 1533 	mov	a,r1
      00400D 94 7C            [12] 1534 	subb	a,#0x7c
      00400F 40 45            [24] 1535 	jc	00112$
      004011 74 5F            [12] 1536 	mov	a,#0x5f
      004013 98               [12] 1537 	subb	a,r0
      004014 74 7C            [12] 1538 	mov	a,#0x7c
      004016 99               [12] 1539 	subb	a,r1
      004017 40 3D            [24] 1540 	jc	00112$
                                   1541 ;	free result
                                   1542 ;	keyboards/ajazz/ak820/ak820_key_override.c:82: if (record->event.pressed) {
      004019 12 38 01         [24] 1543 	lcall	_ak820_outline_0007
      00401C 60 34            [24] 1544 	jz	00110$
                                   1545 ;	keyboards/ajazz/ak820/ak820_key_override.c:83: if (key == QK_KEY_OVERRIDE_ON) enabled = true;
      00401E B8 5E 0B         [24] 1546 	cjne	r0,#0x5e,00105$
      004021 B9 7C 08         [24] 1547 	cjne	r1,#0x7c,00105$
      004024 90 0E 69         [24] 1548 	mov	dptr,#_enabled
      004027 74 01            [12] 1549 	mov	a,#0x01
      004029 F0               [24] 1550 	movx	@dptr,a
      00402A 80 17            [24] 1551 	sjmp	00106$
      00402C                       1552 00105$:
                                   1553 ;	keyboards/ajazz/ak820/ak820_key_override.c:84: else if (key == QK_KEY_OVERRIDE_OFF) enabled = false;
      00402C B8 5F 0A         [24] 1554 	cjne	r0,#0x5f,00102$
      00402F B9 7C 07         [24] 1555 	cjne	r1,#0x7c,00102$
      004032 90 0E 69         [24] 1556 	mov	dptr,#_enabled
      004035 E4               [12] 1557 	clr	a
      004036 F0               [24] 1558 	movx	@dptr,a
      004037 80 0A            [24] 1559 	sjmp	00106$
      004039                       1560 00102$:
                                   1561 ;	keyboards/ajazz/ak820/ak820_key_override.c:85: else enabled = !enabled;
      004039 90 0E 69         [24] 1562 	mov	dptr,#_enabled
      00403C E0               [24] 1563 	movx	a,@dptr
      00403D B4 01 00         [24] 1564 	cjne	a,#0x01,00281$
      004040                       1565 00281$:
      004040 E4               [12] 1566 	clr	a
      004041 33               [12] 1567 	rlc	a
      004042 F0               [24] 1568 	movx	@dptr,a
      004043                       1569 00106$:
                                   1570 ;	keyboards/ajazz/ak820/ak820_key_override.c:86: if (!enabled) { deactivate(); blocked = true; }
      004043 90 0E 69         [24] 1571 	mov	dptr,#_enabled
      004046 E0               [24] 1572 	movx	a,@dptr
      004047 70 09            [24] 1573 	jnz	00110$
      004049 12 3D 6B         [24] 1574 	lcall	_deactivate
      00404C 90 05 4F         [24] 1575 	mov	dptr,#_blocked
      00404F 74 01            [12] 1576 	mov	a,#0x01
      004051 F0               [24] 1577 	movx	@dptr,a
      004052                       1578 00110$:
                                   1579 ;	keyboards/ajazz/ak820/ak820_key_override.c:88: return false;
      004052 75 82 00         [24] 1580 	mov	dpl, #0x00
      004055 22               [24] 1581 	ret
      004056                       1582 00112$:
                                   1583 ;	keyboards/ajazz/ak820/ak820_key_override.c:90: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) return true;
      004056 90 05 68         [24] 1584 	mov	dptr,#_ak820_key_override_process_record_10000_635
      004059 E0               [24] 1585 	movx	a,@dptr
      00405A F5 16            [12] 1586 	mov	_ak820_key_override_process_sloc2_1_0,a
      00405C A3               [24] 1587 	inc	dptr
      00405D E0               [24] 1588 	movx	a,@dptr
      00405E F5 17            [12] 1589 	mov	(_ak820_key_override_process_sloc2_1_0 + 1),a
      004060 85 16 82         [24] 1590 	mov	dpl,_ak820_key_override_process_sloc2_1_0
      004063 85 17 83         [24] 1591 	mov	dph,(_ak820_key_override_process_sloc2_1_0 + 1)
      004066 A3               [24] 1592 	inc	dptr
      004067 E0               [24] 1593 	movx	a,@dptr
      004068 F5 14            [12] 1594 	mov	_ak820_key_override_process_sloc0_1_0,a
      00406A C3               [12] 1595 	clr	c
      00406B 94 10            [12] 1596 	subb	a,#0x10
      00406D 50 0E            [24] 1597 	jnc	00114$
      00406F 85 16 82         [24] 1598 	mov	dpl,_ak820_key_override_process_sloc2_1_0
      004072 85 17 83         [24] 1599 	mov	dph,(_ak820_key_override_process_sloc2_1_0 + 1)
      004075 E0               [24] 1600 	movx	a,@dptr
      004076 F5 15            [12] 1601 	mov	_ak820_key_override_process_sloc1_1_0,a
      004078 C3               [12] 1602 	clr	c
      004079 94 08            [12] 1603 	subb	a,#0x08
      00407B 40 04            [24] 1604 	jc	00115$
      00407D                       1605 00114$:
      00407D 75 82 01         [24] 1606 	mov	dpl, #0x01
      004080 22               [24] 1607 	ret
      004081                       1608 00115$:
                                   1609 ;	keyboards/ajazz/ak820/ak820_key_override.c:91: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      004081 C0 02            [24] 1610 	push	ar2
      004083 E5 14            [12] 1611 	mov	a,_ak820_key_override_process_sloc0_1_0
      004085 12 38 CA         [24] 1612 	lcall	_ak820_outline_0198
      004088 F5 14            [12] 1613 	mov	_ak820_key_override_process_sloc0_1_0,a
      00408A 25 15            [12] 1614 	add	a,_ak820_key_override_process_sloc1_1_0
      00408C F5 15            [12] 1615 	mov	_ak820_key_override_process_sloc1_1_0,a
                                   1616 ;	keyboards/ajazz/ak820/ak820_key_override.c:92: if (source == id) {
      00408E 90 0E 67         [24] 1617 	mov	dptr,#_source
      004091 E0               [24] 1618 	movx	a,@dptr
      004092 B5 15 02         [24] 1619 	cjne	a,_ak820_key_override_process_sloc1_1_0,00285$
      004095 80 04            [24] 1620 	sjmp	00286$
      004097                       1621 00285$:
      004097 D0 02            [24] 1622 	pop	ar2
      004099 80 17            [24] 1623 	sjmp	00120$
      00409B                       1624 00286$:
      00409B D0 02            [24] 1625 	pop	ar2
                                   1626 ;	keyboards/ajazz/ak820/ak820_key_override.c:93: if (!record->event.pressed) ak820_key_override_cancel();
      00409D 74 05            [12] 1627 	mov	a,#0x05
      00409F 25 16            [12] 1628 	add	a, _ak820_key_override_process_sloc2_1_0
      0040A1 FE               [12] 1629 	mov	r6,a
      0040A2 E4               [12] 1630 	clr	a
      0040A3 35 17            [12] 1631 	addc	a, (_ak820_key_override_process_sloc2_1_0 + 1)
      0040A5 FF               [12] 1632 	mov	r7,a
      0040A6 12 38 6E         [24] 1633 	lcall	_ak820_outline_0105
      0040A9 70 03            [24] 1634 	jnz	00118$
      0040AB 12 3D 8C         [24] 1635 	lcall	_ak820_key_override_cancel
      0040AE                       1636 00118$:
                                   1637 ;	keyboards/ajazz/ak820/ak820_key_override.c:94: return false;
      0040AE 75 82 00         [24] 1638 	mov	dpl, #0x00
      0040B1 22               [24] 1639 	ret
      0040B2                       1640 00120$:
                                   1641 ;	keyboards/ajazz/ak820/ak820_key_override.c:96: if (!record->event.pressed) return true;
      0040B2 74 05            [12] 1642 	mov	a,#0x05
      0040B4 25 16            [12] 1643 	add	a, _ak820_key_override_process_sloc2_1_0
      0040B6 FE               [12] 1644 	mov	r6,a
      0040B7 E4               [12] 1645 	clr	a
      0040B8 35 17            [12] 1646 	addc	a, (_ak820_key_override_process_sloc2_1_0 + 1)
      0040BA FF               [12] 1647 	mov	r7,a
      0040BB 12 38 6E         [24] 1648 	lcall	_ak820_outline_0105
      0040BE 70 04            [24] 1649 	jnz	00122$
      0040C0 75 82 01         [24] 1650 	mov	dpl, #0x01
      0040C3 22               [24] 1651 	ret
      0040C4                       1652 00122$:
                                   1653 ;	keyboards/ajazz/ak820/ak820_key_override.c:97: if (active != NONE && !(entries[active].options & 32) && !(key >= KC_LEFT_CTRL && key <= KC_RIGHT_GUI)) {
      0040C4 12 42 2B         [24] 1654 	lcall	_ak820_outline_0131
      0040C7 BF FF 02         [24] 1655 	cjne	r7,#0xff,00289$
      0040CA 80 35            [24] 1656 	sjmp	00124$
      0040CC                       1657 00289$:
      0040CC EF               [12] 1658 	mov	a,r7
      0040CD 12 41 FF         [24] 1659 	lcall	_ak820_outline_0019
      0040D0 74 09            [12] 1660 	mov	a,#0x09
      0040D2 12 38 0E         [24] 1661 	lcall	_ak820_outline_0016
      0040D5 20 E5 29         [24] 1662 	jb	acc.5,00124$
      0040D8 C3               [12] 1663 	clr	c
      0040D9 E8               [12] 1664 	mov	a,r0
      0040DA 94 E0            [12] 1665 	subb	a,#0xe0
      0040DC E9               [12] 1666 	mov	a,r1
      0040DD 94 00            [12] 1667 	subb	a,#0x00
      0040DF 40 07            [24] 1668 	jc	00123$
      0040E1 74 E7            [12] 1669 	mov	a,#0xe7
      0040E3 98               [12] 1670 	subb	a,r0
      0040E4 E4               [12] 1671 	clr	a
      0040E5 99               [12] 1672 	subb	a,r1
      0040E6 50 19            [24] 1673 	jnc	00124$
                                   1674 ;	free result
      0040E8                       1675 00123$:
                                   1676 ;	keyboards/ajazz/ak820/ak820_key_override.c:98: deactivate(); blocked = true;
      0040E8 C0 05            [24] 1677 	push	ar5
      0040EA C0 04            [24] 1678 	push	ar4
      0040EC C0 03            [24] 1679 	push	ar3
      0040EE C0 02            [24] 1680 	push	ar2
      0040F0 12 3D 6B         [24] 1681 	lcall	_deactivate
      0040F3 D0 02            [24] 1682 	pop	ar2
      0040F5 D0 03            [24] 1683 	pop	ar3
      0040F7 D0 04            [24] 1684 	pop	ar4
      0040F9 D0 05            [24] 1685 	pop	ar5
      0040FB 90 05 4F         [24] 1686 	mov	dptr,#_blocked
      0040FE 74 01            [12] 1687 	mov	a,#0x01
      004100 F0               [24] 1688 	movx	@dptr,a
      004101                       1689 00124$:
                                   1690 ;	keyboards/ajazz/ak820/ak820_key_override.c:100: if (source != NONE || !enabled || !basic(key)) return true;
      004101 90 0E 67         [24] 1691 	mov	dptr,#_source
      004104 E0               [24] 1692 	movx	a,@dptr
      004105 FF               [12] 1693 	mov	r7,a
      004106 BF FF 20         [24] 1694 	cjne	r7,#0xff,00128$
      004109 90 0E 69         [24] 1695 	mov	dptr,#_enabled
      00410C E0               [24] 1696 	movx	a,@dptr
      00410D 60 1A            [24] 1697 	jz	00128$
      00410F 12 38 A1         [24] 1698 	lcall	_ak820_outline_0134
      004112 C0 05            [24] 1699 	push	ar5
      004114 C0 04            [24] 1700 	push	ar4
      004116 C0 03            [24] 1701 	push	ar3
      004118 C0 02            [24] 1702 	push	ar2
      00411A 12 3B 87         [24] 1703 	lcall	_basic
      00411D E5 82            [12] 1704 	mov	a, dpl
      00411F D0 02            [24] 1705 	pop	ar2
      004121 D0 03            [24] 1706 	pop	ar3
      004123 D0 04            [24] 1707 	pop	ar4
      004125 D0 05            [24] 1708 	pop	ar5
      004127 70 04            [24] 1709 	jnz	00178$
      004129                       1710 00128$:
      004129 75 82 01         [24] 1711 	mov	dpl, #0x01
                                   1712 ;	keyboards/ajazz/ak820/ak820_key_override.c:101: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      00412C 22               [24] 1713 	ret
      00412D                       1714 00178$:
      00412D 7F 00            [12] 1715 	mov	r7,#0x00
      00412F                       1716 00137$:
      00412F BF 08 00         [24] 1717 	cjne	r7,#0x08,00297$
      004132                       1718 00297$:
      004132 50 5C            [24] 1719 	jnc	00135$
                                   1720 ;	keyboards/ajazz/ak820/ak820_key_override.c:102: if (entries[i].trigger == key && (entries[i].options & ENABLED)) {
      004134 C0 02            [24] 1721 	push	ar2
      004136 EF               [12] 1722 	mov	a,r7
      004137 75 F0 0A         [24] 1723 	mov	b,#0x0a
      00413A A4               [48] 1724 	mul	ab
      00413B 24 FD            [12] 1725 	add	a, #_entries
      00413D F9               [12] 1726 	mov	r1,a
      00413E 74 04            [12] 1727 	mov	a,#(_entries >> 8)
      004140 35 F0            [12] 1728 	addc	a, b
      004142 FE               [12] 1729 	mov	r6,a
      004143 89 82            [24] 1730 	mov	dpl,r1
      004145 8E 83            [24] 1731 	mov	dph,r6
      004147 E0               [24] 1732 	movx	a,@dptr
      004148 F8               [12] 1733 	mov	r0,a
      004149 A3               [24] 1734 	inc	dptr
      00414A E0               [24] 1735 	movx	a,@dptr
      00414B FA               [12] 1736 	mov	r2,a
      00414C E8               [12] 1737 	mov	a,r0
      00414D B5 04 06         [24] 1738 	cjne	a,ar4,00299$
      004150 EA               [12] 1739 	mov	a,r2
      004151 B5 05 02         [24] 1740 	cjne	a,ar5,00299$
      004154 80 04            [24] 1741 	sjmp	00300$
      004156                       1742 00299$:
      004156 D0 02            [24] 1743 	pop	ar2
      004158 80 33            [24] 1744 	sjmp	00138$
      00415A                       1745 00300$:
      00415A D0 02            [24] 1746 	pop	ar2
      00415C 74 09            [12] 1747 	mov	a,#0x09
      00415E 29               [12] 1748 	add	a, r1
      00415F 12 42 23         [24] 1749 	lcall	_ak820_outline_0083
      004162 30 E7 28         [24] 1750 	jnb	acc.7,00138$
                                   1751 ;	keyboards/ajazz/ak820/ak820_key_override.c:103: source = id; trigger = key; hidden = blocked = false;
      004165 90 0E 67         [24] 1752 	mov	dptr,#_source
      004168 E5 15            [12] 1753 	mov	a,_ak820_key_override_process_sloc1_1_0
      00416A F0               [24] 1754 	movx	@dptr,a
      00416B 90 05 4D         [24] 1755 	mov	dptr,#_trigger
      00416E EC               [12] 1756 	mov	a,r4
      00416F F0               [24] 1757 	movx	@dptr,a
      004170 90 05 4F         [24] 1758 	mov	dptr,#_blocked
      004173 E4               [12] 1759 	clr	a
      004174 F0               [24] 1760 	movx	@dptr,a
      004175 90 05 50         [24] 1761 	mov	dptr,#_hidden
      004178 F0               [24] 1762 	movx	@dptr,a
                                   1763 ;	keyboards/ajazz/ak820/ak820_key_override.c:104: activate(1, mods, layer);
      004179 90 05 5D         [24] 1764 	mov	dptr,#_activate_PARM_2
      00417C EB               [12] 1765 	mov	a,r3
      00417D F0               [24] 1766 	movx	@dptr,a
      00417E 90 05 5E         [24] 1767 	mov	dptr,#_activate_PARM_3
      004181 EA               [12] 1768 	mov	a,r2
      004182 F0               [24] 1769 	movx	@dptr,a
      004183 75 82 01         [24] 1770 	mov	dpl, #0x01
      004186 12 3D F4         [24] 1771 	lcall	_activate
                                   1772 ;	keyboards/ajazz/ak820/ak820_key_override.c:105: return false;
      004189 75 82 00         [24] 1773 	mov	dpl, #0x00
      00418C 22               [24] 1774 	ret
      00418D                       1775 00138$:
                                   1776 ;	keyboards/ajazz/ak820/ak820_key_override.c:101: for (uint8_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i) {
      00418D 0F               [12] 1777 	inc	r7
      00418E 80 9F            [24] 1778 	sjmp	00137$
      004190                       1779 00135$:
                                   1780 ;	keyboards/ajazz/ak820/ak820_key_override.c:108: return true;
      004190 75 82 01         [24] 1781 	mov	dpl, #0x01
                                   1782 ;	keyboards/ajazz/ak820/ak820_key_override.c:109: }
      004193 22               [24] 1783 	ret
                                   1784 ;------------------------------------------------------------
                                   1785 ;Allocation info for local variables in function 'ak820_key_override_key'
                                   1786 ;------------------------------------------------------------
                                   1787 ;	keyboards/ajazz/ak820/ak820_key_override.c:110: uint8_t ak820_key_override_key(void) {
                                   1788 ;	-----------------------------------------
                                   1789 ;	 function ak820_key_override_key
                                   1790 ;	-----------------------------------------
      004194                       1791 _ak820_key_override_key:
                                   1792 ;	keyboards/ajazz/ak820/ak820_key_override.c:111: if (source == NONE || hidden) return 0;
      004194 90 0E 67         [24] 1793 	mov	dptr,#_source
      004197 E0               [24] 1794 	movx	a,@dptr
      004198 FF               [12] 1795 	mov	r7,a
      004199 BF FF 02         [24] 1796 	cjne	r7,#0xff,00122$
      00419C 80 06            [24] 1797 	sjmp	00101$
      00419E                       1798 00122$:
      00419E 90 05 50         [24] 1799 	mov	dptr,#_hidden
      0041A1 E0               [24] 1800 	movx	a,@dptr
      0041A2 60 04            [24] 1801 	jz	00102$
      0041A4                       1802 00101$:
      0041A4 75 82 00         [24] 1803 	mov	dpl, #0x00
      0041A7 22               [24] 1804 	ret
      0041A8                       1805 00102$:
                                   1806 ;	keyboards/ajazz/ak820/ak820_key_override.c:112: return active == NONE ? trigger : (uint8_t)entries[active].replacement;
      0041A8 12 42 2B         [24] 1807 	lcall	_ak820_outline_0131
      0041AB BF FF 07         [24] 1808 	cjne	r7,#0xff,00106$
      0041AE 90 05 4D         [24] 1809 	mov	dptr,#_trigger
      0041B1 E0               [24] 1810 	movx	a,@dptr
      0041B2 FE               [12] 1811 	mov	r6,a
      0041B3 80 0B            [24] 1812 	sjmp	00107$
      0041B5                       1813 00106$:
      0041B5 12 42 16         [24] 1814 	lcall	_ak820_outline_0040
      0041B8 FF               [12] 1815 	mov	r7,a
      0041B9 12 42 3C         [24] 1816 	lcall	_ak820_outline_0194
      0041BC A3               [24] 1817 	inc	dptr
      0041BD A3               [24] 1818 	inc	dptr
      0041BE E0               [24] 1819 	movx	a,@dptr
      0041BF FE               [12] 1820 	mov	r6,a
      0041C0                       1821 00107$:
      0041C0 8E 82            [24] 1822 	mov	dpl, r6
                                   1823 ;	keyboards/ajazz/ak820/ak820_key_override.c:113: }
      0041C2 22               [24] 1824 	ret
                                   1825 ;------------------------------------------------------------
                                   1826 ;Allocation info for local variables in function 'ak820_key_override_mods'
                                   1827 ;------------------------------------------------------------
                                   1828 ;mods          Allocated with name '_ak820_key_override_mods_mods_10000_660'
                                   1829 ;------------------------------------------------------------
                                   1830 ;	keyboards/ajazz/ak820/ak820_key_override.c:114: uint8_t ak820_key_override_mods(uint8_t mods) {
                                   1831 ;	-----------------------------------------
                                   1832 ;	 function ak820_key_override_mods
                                   1833 ;	-----------------------------------------
      0041C3                       1834 _ak820_key_override_mods:
      0041C3 E5 82            [12] 1835 	mov	a,dpl
      0041C5 90 05 6A         [24] 1836 	mov	dptr,#_ak820_key_override_mods_mods_10000_660
      0041C8 F0               [24] 1837 	movx	@dptr,a
                                   1838 ;	keyboards/ajazz/ak820/ak820_key_override.c:115: if (active == NONE) return mods;
      0041C9 12 42 2B         [24] 1839 	lcall	_ak820_outline_0131
      0041CC BF FF 07         [24] 1840 	cjne	r7,#0xff,00102$
      0041CF 90 05 6A         [24] 1841 	mov	dptr,#_ak820_key_override_mods_mods_10000_660
      0041D2 E0               [24] 1842 	movx	a,@dptr
      0041D3 F5 82            [12] 1843 	mov	dpl,a
      0041D5 22               [24] 1844 	ret
      0041D6                       1845 00102$:
                                   1846 ;	keyboards/ajazz/ak820/ak820_key_override.c:116: return (mods & ~entries[active].suppressed_mods) | replacement_mods(entries[active].replacement);
      0041D6 EF               [12] 1847 	mov	a,r7
      0041D7 12 41 FF         [24] 1848 	lcall	_ak820_outline_0019
      0041DA 74 08            [12] 1849 	mov	a,#0x08
      0041DC 12 38 0E         [24] 1850 	lcall	_ak820_outline_0016
      0041DF FD               [12] 1851 	mov	r5,a
      0041E0 63 05 FF         [24] 1852 	xrl	ar5,#0xff
      0041E3 90 05 6A         [24] 1853 	mov	dptr,#_ak820_key_override_mods_mods_10000_660
      0041E6 E0               [24] 1854 	movx	a,@dptr
      0041E7 52 05            [12] 1855 	anl	ar5,a
      0041E9 12 38 74         [24] 1856 	lcall	_ak820_outline_0107
      0041EC A3               [24] 1857 	inc	dptr
      0041ED 12 37 F7         [24] 1858 	lcall	_ak820_outline_0006
      0041F0 C0 05            [24] 1859 	push	ar5
      0041F2 12 3C 7D         [24] 1860 	lcall	_replacement_mods
      0041F5 AF 82            [24] 1861 	mov	r7, dpl
      0041F7 D0 05            [24] 1862 	pop	ar5
      0041F9 EF               [12] 1863 	mov	a,r7
      0041FA 42 05            [12] 1864 	orl	ar5,a
      0041FC 8D 82            [24] 1865 	mov	dpl, r5
                                   1866 ;	keyboards/ajazz/ak820/ak820_key_override.c:117: }
      0041FE 22               [24] 1867 	ret
                                   1868 ;------------------------------------------------------------
                                   1869 ;Allocation info for local variables in function 'ak820_key_override_enabled'
                                   1870 ;------------------------------------------------------------
                                   1871 ;	keyboards/ajazz/ak820/ak820_key_override.c:118: bool ak820_key_override_enabled(void) { return enabled; }
                                   1872 ;	-----------------------------------------
                                   1873 	.area CSEG    (CODE)
                                   1874 	.area CONST   (CODE)
                                   1875 	.area XINIT   (CODE)
      00CA25                       1876 __xinit__source:
      00CA25 FF                    1877 	.db #0xff	; 255
      00CA26                       1878 __xinit__active:
      00CA26 FF                    1879 	.db #0xff	; 255
      00CA27                       1880 __xinit__enabled:
      00CA27 01                    1881 	.db #0x01	;  1
                                   1882 	.area CABS    (ABS,CODE)
                                   1883 
                                   1884 ; Experimental exact instruction outlining.
                                   1885 	.globl _ak820_outline_0002
                                   1886 	.globl _ak820_outline_0006
                                   1887 	.globl _ak820_outline_0007
                                   1888 	.globl _ak820_outline_0016
                                   1889 	.globl _ak820_outline_0019
                                   1890 	.globl _ak820_outline_0020
                                   1891 	.globl _ak820_outline_0037
                                   1892 	.globl _ak820_outline_0040
                                   1893 	.globl _ak820_outline_0057
                                   1894 	.globl _ak820_outline_0065
                                   1895 	.globl _ak820_outline_0077
                                   1896 	.globl _ak820_outline_0083
                                   1897 	.globl _ak820_outline_0105
                                   1898 	.globl _ak820_outline_0107
                                   1899 	.globl _ak820_outline_0114
                                   1900 	.globl _ak820_outline_0115
                                   1901 	.globl _ak820_outline_0130
                                   1902 	.globl _ak820_outline_0131
                                   1903 	.globl _ak820_outline_0134
                                   1904 	.globl _ak820_outline_0141
                                   1905 	.globl _ak820_outline_0145
                                   1906 	.globl _ak820_outline_0146
                                   1907 	.globl _ak820_outline_0154
                                   1908 	.globl _ak820_outline_0194
                                   1909 	.globl _ak820_outline_0198
                                   1910 	.globl _ak820_outline_0199
                                   1911 
                                   1912 	.area CSEG (CODE)
                                   1913 ; function ak820_outline_0019
      0041FF                       1914 _ak820_outline_0019:
      0041FF 75 F0 0A         [24] 1915 	mov	b,#0x0a
      004202 A4               [48] 1916 	mul	ab
      004203 24 FD            [12] 1917 	add	a,#_entries
      004205 FE               [12] 1918 	mov	r6,a
      004206 74 04            [12] 1919 	mov	a,#(_entries>>8)
      004208 35 F0            [12] 1920 	addc	a,b
      00420A FF               [12] 1921 	mov	r7,a
      00420B 22               [24] 1922 	ret
                                   1923 
                                   1924 	.area CSEG (CODE)
                                   1925 ; function ak820_outline_0020
      00420C                       1926 _ak820_outline_0020:
      00420C 8E 82            [24] 1927 	mov	dpl,r6
      00420E 8F 83            [24] 1928 	mov	dph,r7
      004210 A3               [24] 1929 	inc	dptr
      004211 A3               [24] 1930 	inc	dptr
      004212 A3               [24] 1931 	inc	dptr
      004213 A3               [24] 1932 	inc	dptr
      004214 E0               [24] 1933 	movx	a,@dptr
      004215 22               [24] 1934 	ret
                                   1935 
                                   1936 	.area CSEG (CODE)
                                   1937 ; function ak820_outline_0040
      004216                       1938 _ak820_outline_0040:
      004216 EF               [12] 1939 	mov	a,r7
      004217 75 F0 0A         [24] 1940 	mov	b,#0x0a
      00421A A4               [48] 1941 	mul	ab
      00421B 24 FD            [12] 1942 	add	a,#_entries
      00421D FD               [12] 1943 	mov	r5,a
      00421E 74 04            [12] 1944 	mov	a,#(_entries>>8)
      004220 35 F0            [12] 1945 	addc	a,b
      004222 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0083
      004223                       1950 _ak820_outline_0083:
      004223 F5 82            [12] 1951 	mov	dpl,a
      004225 E4               [12] 1952 	clr	a
      004226 3E               [12] 1953 	addc	a,r6
      004227 F5 83            [12] 1954 	mov	dph,a
      004229 E0               [24] 1955 	movx	a,@dptr
      00422A 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0131
      00422B                       1960 _ak820_outline_0131:
      00422B 90 0E 68         [24] 1961 	mov	dptr,#_active
      00422E E0               [24] 1962 	movx	a,@dptr
      00422F FF               [12] 1963 	mov	r7,a
      004230 22               [24] 1964 	ret
                                   1965 
                                   1966 	.area CSEG (CODE)
                                   1967 ; function ak820_outline_0141
      004231                       1968 _ak820_outline_0141:
      004231 90 05 64         [24] 1969 	mov	dptr,#_ak820_key_override_sync_mods_10000_630
      004234 E0               [24] 1970 	movx	a,@dptr
      004235 FE               [12] 1971 	mov	r6,a
      004236 90 05 63         [24] 1972 	mov	dptr,#_ak820_key_override_sync_PARM_2
      004239 E0               [24] 1973 	movx	a,@dptr
      00423A FD               [12] 1974 	mov	r5,a
      00423B 22               [24] 1975 	ret
                                   1976 
                                   1977 	.area CSEG (CODE)
                                   1978 ; function ak820_outline_0194
      00423C                       1979 _ak820_outline_0194:
      00423C 8D 82            [24] 1980 	mov	dpl,r5
      00423E 8F 83            [24] 1981 	mov	dph,r7
      004240 22               [24] 1982 	ret
                                   1983 
                                   1984 	.area CSEG (CODE)
                                   1985 ; function ak820_outline_0199
      004241                       1986 _ak820_outline_0199:
      004241 ED               [12] 1987 	mov	a,r5
      004242 F0               [24] 1988 	movx	@dptr,a
      004243 8F 82            [24] 1989 	mov	dpl,r7
      004245 22               [24] 1990 	ret
