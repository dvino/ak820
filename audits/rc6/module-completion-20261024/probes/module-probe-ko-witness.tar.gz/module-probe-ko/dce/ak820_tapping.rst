                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      000011                        552 _ak820_tapping_before_sloc0_1_0:
      000011                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      00060C                        562 _source_state:
      00060C                        563 	.ds 130
      00068E                        564 _pending_time:
      00068E                        565 	.ds 2
      000690                        566 _pending_code:
      000690                        567 	.ds 2
      000692                        568 _ak820_tapping_source_PARM_1:
      000692                        569 	.ds 2
      000694                        570 _hold_PARM_2:
      000694                        571 	.ds 1
      000695                        572 _hold_code_10000_603:
      000695                        573 	.ds 2
      000697                        574 _hold_mods_30000_606:
      000697                        575 	.ds 1
      000698                        576 _commit_pending_id_10000_612:
      000698                        577 	.ds 1
      000699                        578 _ak820_tapping_before_event_10000_613:
      000699                        579 	.ds 2
      00069B                        580 _ak820_tapping_process_record_10000_624:
      00069B                        581 	.ds 2
      00069D                        582 _ak820_tapping_process_code_10000_625:
      00069D                        583 	.ds 2
      00069F                        584 _ak820_tapping_process_sc_mods_10000_625:
      00069F                        585 	.ds 1
      0006A0                        586 _ak820_oneshot_mods::
      0006A0                        587 	.ds 1
      0006A1                        588 _ak820_oneshot_consumed::
      0006A1                        589 	.ds 1
      0006A2                        590 _ak820_oneshot_process_PARM_2:
      0006A2                        591 	.ds 1
      0006A3                        592 _ak820_oneshot_process_PARM_3:
      0006A3                        593 	.ds 1
      0006A4                        594 _ak820_oneshot_process_code_10000_650:
      0006A4                        595 	.ds 2
      0006A6                        596 _ak820_oneshot_process_mods_10000_651:
      0006A6                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E6A                        606 _pending:
      000E6A                        607 	.ds 1
      000E6B                        608 _ak820_oneshot_target::
      000E6B                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004A4F                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004A4F 90 06 93         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004A52 E0               [24]  656 	movx	a,@dptr
      004A53 FF               [12]  657 	mov	r7,a
      004A54 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004A57                        659 00147$:
      004A57 50 14            [24]  660 	jnc	00102$
      004A59 90 06 92         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      004A5C E0               [24]  662 	movx	a,@dptr
      004A5D FE               [12]  663 	mov	r6,a
      004A5E BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      004A61                        665 00149$:
      004A61 50 0A            [24]  666 	jnc	00102$
      004A63 8F 05            [24]  667 	mov	ar5,r7
      004A65 ED               [12]  668 	mov	a,r5
      004A66 12 38 CA         [24]  669 	lcall	_ak820_outline_0198
      004A69 2E               [12]  670 	add	a,r6
      004A6A F5 82            [12]  671 	mov	dpl,a
      004A6C 22               [24]  672 	ret
      004A6D                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004A6D 90 06 92         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      004A70 E0               [24]  676 	movx	a,@dptr
      004A71 FE               [12]  677 	mov	r6,a
      004A72 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      004A75                        679 00151$:
      004A75 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004A77 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      004A7A 75 82 80         [24]  683 	mov	dpl, #0x80
      004A7D 22               [24]  684 	ret
      004A7E                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004A7E BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004A81 75 82 81         [24]  688 	mov	dpl, #0x81
      004A84 22               [24]  689 	ret
      004A85                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004A85 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      004A88 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004A89                        707 _hold:
      004A89 12 38 86         [24]  708 	lcall	_ak820_outline_0114
      004A8C 90 06 95         [24]  709 	mov	dptr,#_hold_code_10000_603
      004A8F 12 38 8B         [24]  710 	lcall	_ak820_outline_0115
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004A92 90 06 95         [24]  712 	mov	dptr,#_hold_code_10000_603
      004A95 12 4E EC         [24]  713 	lcall	_ak820_outline_0010
      004A98 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004A9A 2D               [12]  715 	add	a,r5
      004A9B 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      004A9D 8F 05            [24]  718 	mov	ar5,r7
      004A9F 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004AA2 90 06 97         [24]  720 	mov	dptr,#_hold_mods_30000_606
      004AA5 ED               [12]  721 	mov	a,r5
      004AA6 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004AA7 ED               [12]  724 	mov	a,r5
      004AA8 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004AAB ED               [12]  726 	mov	a,r5
      004AAC C4               [12]  727 	swap	a
      004AAD 54 F0            [12]  728 	anl	a,#0xf0
      004AAF 90 06 97         [24]  729 	mov	dptr,#_hold_mods_30000_606
      004AB2 F0               [24]  730 	movx	@dptr,a
      004AB3                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004AB3 90 06 94         [24]  733 	mov	dptr,#_hold_PARM_2
      004AB6 E0               [24]  734 	movx	a,@dptr
      004AB7 60 09            [24]  735 	jz	00104$
      004AB9 90 06 97         [24]  736 	mov	dptr,#_hold_mods_30000_606
      004ABC E0               [24]  737 	movx	a,@dptr
      004ABD F5 82            [12]  738 	mov	dpl,a
      004ABF 02 7C 82         [24]  739 	ljmp	_register_mods
      004AC2                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004AC2 90 06 97         [24]  742 	mov	dptr,#_hold_mods_30000_606
      004AC5 E0               [24]  743 	movx	a,@dptr
      004AC6 F5 82            [12]  744 	mov	dpl,a
      004AC8 02 7C 96         [24]  745 	ljmp	_unregister_mods
      004ACB                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004ACB 8F 06            [24]  748 	mov	ar6,r7
      004ACD 74 0F            [12]  749 	mov	a,#0x0f
      004ACF 5E               [12]  750 	anl	a,r6
      004AD0 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004AD1 90 06 94         [24]  753 	mov	dptr,#_hold_PARM_2
      004AD4 E0               [24]  754 	movx	a,@dptr
      004AD5 60 05            [24]  755 	jz	00107$
      004AD7 8F 82            [24]  756 	mov	dpl, r7
      004AD9 02 7E 6D         [24]  757 	ljmp	_layer_hold_on
      004ADC                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004ADC 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004ADE 02 7E A4         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004AE1                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004AE1 90 0E 6A         [24]  774 	mov	dptr,#_pending
      004AE4 E0               [24]  775 	movx	a,@dptr
      004AE5 90 06 98         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      004AE8 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004AE9 12 4F 77         [24]  779 	lcall	_ak820_outline_0165
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004AEC 90 06 98         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      004AEF E0               [24]  782 	movx	a,@dptr
      004AF0 24 0C            [12]  783 	add	a,#_source_state
      004AF2 FF               [12]  784 	mov	r7,a
      004AF3 E4               [12]  785 	clr	a
      004AF4 34 06            [12]  786 	addc	a, #(_source_state >> 8)
      004AF6 FE               [12]  787 	mov	r6,a
      004AF7 12 4A 39         [24]  788 	lcall	_ak820_outline_0169
      004AFA E0               [24]  789 	movx	a,@dptr
      004AFB FD               [12]  790 	mov	r5,a
      004AFC 43 05 04         [24]  791 	orl	ar5,#0x04
      004AFF 12 4A 39         [24]  792 	lcall	_ak820_outline_0169
      004B02 ED               [12]  793 	mov	a,r5
      004B03 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004B04 90 06 90         [24]  796 	mov	dptr,#_pending_code
      004B07 12 38 39         [24]  797 	lcall	_ak820_outline_0057
      004B0A 90 06 94         [24]  798 	mov	dptr,#_hold_PARM_2
      004B0D 74 01            [12]  799 	mov	a,#0x01
      004B0F 12 4A 00         [24]  800 	lcall	_ak820_outline_0070
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004B12 41 89            [12]  802 	ajmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      004B14                        813 _ak820_tapping_before:
      004B14 12 38 86         [24]  814 	lcall	_ak820_outline_0114
      004B17 90 06 99         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004B1A 12 38 8B         [24]  816 	lcall	_ak820_outline_0115
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004B1D 90 06 99         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004B20 12 4E EC         [24]  819 	lcall	_ak820_outline_0010
      004B23 12 4F 11         [24]  820 	lcall	_ak820_outline_0026
      004B26 C0 07            [24]  821 	push	ar7
      004B28 C0 06            [24]  822 	push	ar6
      004B2A 12 C1 65         [24]  823 	lcall	___memcpy
      004B2D 51 4F            [12]  824 	acall	_ak820_tapping_source
      004B2F AD 82            [24]  825 	mov	r5, dpl
      004B31 D0 06            [24]  826 	pop	ar6
      004B33 D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004B35 90 0E DB         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      004B38 E0               [24]  830 	movx	a,@dptr
      004B39 60 26            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004B3B 12 4F 5D         [24]  833 	lcall	_ak820_outline_0102
      004B3E 60 1D            [24]  834 	jz	00102$
      004B40 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      004B43 80 18            [24]  836 	sjmp	00102$
      004B45                        837 00218$:
      004B45 12 4E F6         [24]  838 	lcall	_ak820_outline_0017
      004B48 E0               [24]  839 	movx	a,@dptr
      004B49 70 12            [24]  840 	jnz	00102$
      004B4B ED               [12]  841 	mov	a,r5
      004B4C 24 0C            [12]  842 	add	a, #_source_state
      004B4E FB               [12]  843 	mov	r3,a
      004B4F E4               [12]  844 	clr	a
      004B50 34 06            [12]  845 	addc	a, #(_source_state >> 8)
      004B52 12 4F 41         [24]  846 	lcall	_ak820_outline_0061
      004B55 53 02 FD         [24]  847 	anl	ar2,#0xfd
      004B58 12 33 FC         [24]  848 	lcall	_ak820_outline_0129
      004B5B EA               [12]  849 	mov	a,r2
      004B5C F0               [24]  850 	movx	@dptr,a
      004B5D                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004B5D 75 82 00         [24]  853 	mov	dpl, #0x00
      004B60 22               [24]  854 	ret
      004B61                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004B61 90 0E 6A         [24]  857 	mov	dptr,#_pending
      004B64 E0               [24]  858 	movx	a,@dptr
      004B65 FC               [12]  859 	mov	r4,a
      004B66 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      004B69 80 3A            [24]  861 	sjmp	00108$
      004B6B                        862 00220$:
      004B6B 12 38 31         [24]  863 	lcall	_ak820_outline_0037
      004B6E FA               [12]  864 	mov	r2,a
      004B6F A3               [24]  865 	inc	dptr
      004B70 E0               [24]  866 	movx	a,@dptr
      004B71 FB               [12]  867 	mov	r3,a
      004B72 90 06 8E         [24]  868 	mov	dptr,#_pending_time
      004B75 12 38 80         [24]  869 	lcall	_ak820_outline_0110
      004B78 EA               [12]  870 	mov	a,r2
      004B79 C3               [12]  871 	clr	c
      004B7A 98               [12]  872 	subb	a,r0
      004B7B FA               [12]  873 	mov	r2,a
      004B7C EB               [12]  874 	mov	a,r3
      004B7D 99               [12]  875 	subb	a,r1
      004B7E FB               [12]  876 	mov	r3,a
      004B7F C3               [12]  877 	clr	c
      004B80 EA               [12]  878 	mov	a,r2
      004B81 94 C8            [12]  879 	subb	a,#0xc8
      004B83 EB               [12]  880 	mov	a,r3
      004B84 94 00            [12]  881 	subb	a,#0x00
      004B86 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004B88 74 04            [12]  884 	mov	a,#0x04
      004B8A 12 4F 2B         [24]  885 	lcall	_ak820_outline_0034
      004B8D 60 16            [24]  886 	jz	00108$
      004B8F 12 38 01         [24]  887 	lcall	_ak820_outline_0007
      004B92 60 11            [24]  888 	jz	00108$
      004B94 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004B97 80 06            [24]  890 	sjmp	00107$
      004B99                        891 00224$:
      004B99 ED               [12]  892 	mov	a,r5
      004B9A B5 04 02         [24]  893 	cjne	a,ar4,00225$
      004B9D 80 06            [24]  894 	sjmp	00108$
      004B9F                        895 00225$:
      004B9F                        896 00107$:
      004B9F C0 05            [24]  897 	push	ar5
      004BA1 51 E1            [12]  898 	acall	_commit_pending
      004BA3 D0 05            [24]  899 	pop	ar5
      004BA5                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004BA5 90 06 99         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004BA8 12 38 39         [24]  903 	lcall	_ak820_outline_0057
      004BAB 12 4F 5D         [24]  904 	lcall	_ak820_outline_0102
      004BAE 60 03            [24]  905 	jz	00114$
      004BB0 BD FF 04         [24]  906 	cjne	r5,#0xff,00115$
      004BB3                        907 00114$:
      004BB3 75 82 01         [24]  908 	mov	dpl, #0x01
      004BB6 22               [24]  909 	ret
      004BB7                        910 00115$:
                                    911 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004BB7 ED               [12]  912 	mov	a,r5
      004BB8 24 0C            [12]  913 	add	a, #_source_state
      004BBA FC               [12]  914 	mov	r4,a
      004BBB E4               [12]  915 	clr	a
      004BBC 34 06            [12]  916 	addc	a, #(_source_state >> 8)
      004BBE FD               [12]  917 	mov	r5,a
      004BBF 12 4A 06         [24]  918 	lcall	_ak820_outline_0084
      004BC2 FB               [12]  919 	mov	r3,a
      004BC3 30 E1 13         [24]  920 	jnb	acc.1,00120$
                                    921 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004BC6 74 05            [12]  922 	mov	a,#0x05
      004BC8 2E               [12]  923 	add	a, r6
      004BC9 12 38 17         [24]  924 	lcall	_ak820_outline_0021
      004BCC 70 07            [24]  925 	jnz	00118$
      004BCE 74 FD            [12]  926 	mov	a,#0xfd
      004BD0 5B               [12]  927 	anl	a,r3
      004BD1 12 38 A1         [24]  928 	lcall	_ak820_outline_0134
      004BD4 F0               [24]  929 	movx	@dptr,a
      004BD5                        930 00118$:
                                    931 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004BD5 75 82 00         [24]  932 	mov	dpl, #0x00
      004BD8 22               [24]  933 	ret
      004BD9                        934 00120$:
                                    935 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004BD9 12 49 C3         [24]  936 	lcall	_ak820_outline_0012
      004BDC E0               [24]  937 	movx	a,@dptr
      004BDD FF               [12]  938 	mov	r7,a
      004BDE 8B 06            [24]  939 	mov	ar6,r3
      004BE0 53 06 01         [24]  940 	anl	ar6,#0x01
      004BE3 EE               [12]  941 	mov	a,r6
      004BE4 B4 01 00         [24]  942 	cjne	a,#0x01,00231$
      004BE7                        943 00231$:
      004BE7 B3               [12]  944 	cpl	c
      004BE8 92 11            [24]  945 	mov	_ak820_tapping_before_sloc0_1_0,c
      004BEA 8F F0            [24]  946 	mov	b,r7
      004BEC E4               [12]  947 	clr	a
      004BED 33               [12]  948 	rlc	a
      004BEE B5 F0 04         [24]  949 	cjne	a,b,00122$
      004BF1 75 82 00         [24]  950 	mov	dpl, #0x00
      004BF4 22               [24]  951 	ret
      004BF5                        952 00122$:
                                    953 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004BF5 63 03 01         [24]  954 	xrl	ar3,#0x01
      004BF8 12 38 A1         [24]  955 	lcall	_ak820_outline_0134
      004BFB EB               [12]  956 	mov	a,r3
      004BFC F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004BFD 75 82 01         [24]  959 	mov	dpl, #0x01
                                    960 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004C00 22               [24]  961 	ret
                                    962 ;------------------------------------------------------------
                                    963 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    964 ;------------------------------------------------------------
                                    965 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    966 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    967 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    968 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    969 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    970 ;------------------------------------------------------------
                                    971 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    972 ;	-----------------------------------------
                                    973 ;	 function ak820_tapping_process
                                    974 ;	-----------------------------------------
      004C01                        975 _ak820_tapping_process:
      004C01 12 38 86         [24]  976 	lcall	_ak820_outline_0114
      004C04 90 06 9B         [24]  977 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004C07 12 38 8B         [24]  978 	lcall	_ak820_outline_0115
                                    979 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004C0A 90 06 9F         [24]  980 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004C0D E4               [12]  981 	clr	a
      004C0E F0               [24]  982 	movx	@dptr,a
                                    983 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004C0F 90 06 9B         [24]  984 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004C12 12 38 39         [24]  985 	lcall	_ak820_outline_0057
      004C15 74 04            [12]  986 	mov	a,#0x04
      004C17 12 4F 36         [24]  987 	lcall	_ak820_outline_0035
      004C1A 70 04            [24]  988 	jnz	00102$
      004C1C 75 82 01         [24]  989 	mov	dpl, #0x01
      004C1F 22               [24]  990 	ret
      004C20                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004C20 8E 04            [24]  993 	mov	ar4,r6
      004C22 8F 05            [24]  994 	mov	ar5,r7
      004C24 12 4F 11         [24]  995 	lcall	_ak820_outline_0026
      004C27 C0 07            [24]  996 	push	ar7
      004C29 C0 06            [24]  997 	push	ar6
      004C2B 12 C1 65         [24]  998 	lcall	___memcpy
      004C2E 51 4F            [12]  999 	acall	_ak820_tapping_source
      004C30 AD 82            [24] 1000 	mov	r5, dpl
      004C32 D0 06            [24] 1001 	pop	ar6
      004C34 D0 07            [24] 1002 	pop	ar7
                                   1003 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004C36 BD FF 04         [24] 1004 	cjne	r5,#0xff,00104$
      004C39 75 82 01         [24] 1005 	mov	dpl, #0x01
      004C3C 22               [24] 1006 	ret
      004C3D                       1007 00104$:
                                   1008 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004C3D 74 07            [12] 1009 	mov	a,#0x07
      004C3F 12 38 0E         [24] 1010 	lcall	_ak820_outline_0016
      004C42 FE               [12] 1011 	mov	r6,a
      004C43 A3               [24] 1012 	inc	dptr
      004C44 E0               [24] 1013 	movx	a,@dptr
      004C45 FF               [12] 1014 	mov	r7,a
      004C46 90 06 9D         [24] 1015 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C49 12 4F 49         [24] 1016 	lcall	_ak820_outline_0064
                                   1017 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004C4C BE 1A 15         [24] 1018 	cjne	r6,#0x1a,00111$
      004C4F BF 7C 12         [24] 1019 	cjne	r7,#0x7c,00111$
      004C52 90 06 9D         [24] 1020 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C55 74 26            [12] 1021 	mov	a,#0x26
      004C57 F0               [24] 1022 	movx	@dptr,a
      004C58 74 22            [12] 1023 	mov	a,#0x22
      004C5A A3               [24] 1024 	inc	dptr
      004C5B F0               [24] 1025 	movx	@dptr,a
      004C5C 90 06 9F         [24] 1026 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004C5F 74 02            [12] 1027 	mov	a,#0x02
      004C61 F0               [24] 1028 	movx	@dptr,a
      004C62 80 28            [24] 1029 	sjmp	00112$
      004C64                       1030 00111$:
                                   1031 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004C64 BE 1B 15         [24] 1032 	cjne	r6,#0x1b,00108$
      004C67 BF 7C 12         [24] 1033 	cjne	r7,#0x7c,00108$
      004C6A 90 06 9D         [24] 1034 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C6D 74 27            [12] 1035 	mov	a,#0x27
      004C6F F0               [24] 1036 	movx	@dptr,a
      004C70 74 32            [12] 1037 	mov	a,#0x32
      004C72 A3               [24] 1038 	inc	dptr
      004C73 F0               [24] 1039 	movx	@dptr,a
      004C74 90 06 9F         [24] 1040 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004C77 74 20            [12] 1041 	mov	a,#0x20
      004C79 F0               [24] 1042 	movx	@dptr,a
      004C7A 80 10            [24] 1043 	sjmp	00112$
      004C7C                       1044 00108$:
                                   1045 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004C7C BE 1E 0D         [24] 1046 	cjne	r6,#0x1e,00112$
      004C7F BF 7C 0A         [24] 1047 	cjne	r7,#0x7c,00112$
      004C82 90 06 9D         [24] 1048 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C85 74 28            [12] 1049 	mov	a,#0x28
      004C87 F0               [24] 1050 	movx	@dptr,a
      004C88 74 32            [12] 1051 	mov	a,#0x32
      004C8A A3               [24] 1052 	inc	dptr
      004C8B F0               [24] 1053 	movx	@dptr,a
      004C8C                       1054 00112$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004C8C 90 06 9D         [24] 1056 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C8F E0               [24] 1057 	movx	a,@dptr
      004C90 A3               [24] 1058 	inc	dptr
      004C91 E0               [24] 1059 	movx	a,@dptr
      004C92 FF               [12] 1060 	mov	r7,a
                                   1061 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004C93 BF 20 00         [24] 1062 	cjne	r7,#0x20,00242$
      004C96                       1063 00242$:
      004C96 40 05            [24] 1064 	jc	00113$
      004C98 BF 50 00         [24] 1065 	cjne	r7,#0x50,00244$
      004C9B                       1066 00244$:
      004C9B 40 04            [24] 1067 	jc	00114$
      004C9D                       1068 00113$:
      004C9D 75 82 01         [24] 1069 	mov	dpl, #0x01
      004CA0 22               [24] 1070 	ret
      004CA1                       1071 00114$:
                                   1072 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004CA1 BF 40 00         [24] 1073 	cjne	r7,#0x40,00246$
      004CA4                       1074 00246$:
      004CA4 40 0C            [24] 1075 	jc	00117$
      004CA6 53 07 0F         [24] 1076 	anl	ar7,#0x0f
      004CA9 BF 06 00         [24] 1077 	cjne	r7,#0x06,00248$
      004CAC                       1078 00248$:
      004CAC 40 04            [24] 1079 	jc	00117$
      004CAE 75 82 00         [24] 1080 	mov	dpl, #0x00
      004CB1 22               [24] 1081 	ret
      004CB2                       1082 00117$:
                                   1083 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004CB2 90 06 9B         [24] 1084 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004CB5 12 38 39         [24] 1085 	lcall	_ak820_outline_0057
      004CB8 12 4E F6         [24] 1086 	lcall	_ak820_outline_0017
      004CBB E0               [24] 1087 	movx	a,@dptr
      004CBC 60 1E            [24] 1088 	jz	00131$
                                   1089 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004CBE 90 0E 6A         [24] 1090 	mov	dptr,#_pending
      004CC1 ED               [12] 1091 	mov	a,r5
      004CC2 12 49 CD         [24] 1092 	lcall	_ak820_outline_0027
                                   1093 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004CC5 12 38 39         [24] 1094 	lcall	_ak820_outline_0057
      004CC8 90 06 8E         [24] 1095 	mov	dptr,#_pending_time
      004CCB 12 4F 49         [24] 1096 	lcall	_ak820_outline_0064
                                   1097 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004CCE 90 06 9D         [24] 1098 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004CD1 12 38 39         [24] 1099 	lcall	_ak820_outline_0057
      004CD4 90 06 90         [24] 1100 	mov	dptr,#_pending_code
      004CD7 12 4F 49         [24] 1101 	lcall	_ak820_outline_0064
      004CDA A1 87            [12] 1102 	ajmp	00132$
      004CDC                       1103 00131$:
                                   1104 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004CDC 90 0E 6A         [24] 1105 	mov	dptr,#_pending
      004CDF E0               [24] 1106 	movx	a,@dptr
      004CE0 FF               [12] 1107 	mov	r7,a
      004CE1 ED               [12] 1108 	mov	a,r5
      004CE2 B5 07 02         [24] 1109 	cjne	a,ar7,00251$
      004CE5 80 02            [24] 1110 	sjmp	00252$
      004CE7                       1111 00251$:
      004CE7 A1 61            [12] 1112 	ajmp	00128$
      004CE9                       1113 00252$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004CE9 12 4F 77         [24] 1115 	lcall	_ak820_outline_0165
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004CEC 90 06 9F         [24] 1117 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004CEF E0               [24] 1118 	movx	a,@dptr
      004CF0 FF               [12] 1119 	mov	r7,a
      004CF1 E0               [24] 1120 	movx	a,@dptr
      004CF2 60 05            [24] 1121 	jz	00120$
      004CF4 8F 82            [24] 1122 	mov	dpl, r7
      004CF6 12 82 E1         [24] 1123 	lcall	_add_owned_mods
      004CF9                       1124 00120$:
                                   1125 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004CF9 90 06 9B         [24] 1126 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004CFC 12 38 39         [24] 1127 	lcall	_ak820_outline_0057
      004CFF 74 07            [12] 1128 	mov	a,#0x07
      004D01 2E               [12] 1129 	add	a, r6
      004D02 FB               [12] 1130 	mov	r3,a
      004D03 E4               [12] 1131 	clr	a
      004D04 3F               [12] 1132 	addc	a, r7
      004D05 FC               [12] 1133 	mov	r4,a
      004D06 90 06 9D         [24] 1134 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004D09 E0               [24] 1135 	movx	a,@dptr
      004D0A F9               [12] 1136 	mov	r1,a
      004D0B 7A 00            [12] 1137 	mov	r2,#0x00
      004D0D 12 33 FC         [24] 1138 	lcall	_ak820_outline_0129
      004D10 12 4F 71         [24] 1139 	lcall	_ak820_outline_0149
                                   1140 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004D13 C3               [12] 1141 	clr	c
      004D14 04               [12] 1142 	inc	a
      004D15 99               [12] 1143 	subb	a,r1
      004D16 50 37            [24] 1144 	jnc	00122$
                                   1145 ;	free result
                                   1146 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004D18 74 06            [12] 1147 	mov	a,#0x06
      004D1A 12 38 0E         [24] 1148 	lcall	_ak820_outline_0016
      004D1D 54 0F            [12] 1149 	anl	a,#0x0f
      004D1F 44 10            [12] 1150 	orl	a,#0x10
      004D21 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004D22 12 4E F6         [24] 1153 	lcall	_ak820_outline_0017
      004D25 74 01            [12] 1154 	mov	a,#0x01
      004D27 F0               [24] 1155 	movx	@dptr,a
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004D28 12 4F 4F         [24] 1157 	lcall	_ak820_outline_0080
      004D2B 12 4F 6A         [24] 1158 	lcall	_ak820_outline_0119
      004D2E C0 07            [24] 1159 	push	ar7
      004D30 C0 06            [24] 1160 	push	ar6
      004D32 C0 04            [24] 1161 	push	ar4
      004D34 C0 03            [24] 1162 	push	ar3
      004D36 12 77 2E         [24] 1163 	lcall	_process_record
      004D39 D0 03            [24] 1164 	pop	ar3
      004D3B D0 04            [24] 1165 	pop	ar4
      004D3D D0 06            [24] 1166 	pop	ar6
      004D3F D0 07            [24] 1167 	pop	ar7
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004D41 12 33 FC         [24] 1169 	lcall	_ak820_outline_0129
      004D44 E4               [12] 1170 	clr	a
      004D45 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004D46 FC               [12] 1173 	mov	r4,a
      004D47 12 38 90         [24] 1174 	lcall	_ak820_outline_0126
      004D4A 8C F0            [24] 1175 	mov	b, r4
      004D4C 12 77 2E         [24] 1176 	lcall	_process_record
      004D4F                       1177 00122$:
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004D4F 90 06 9F         [24] 1179 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004D52 E0               [24] 1180 	movx	a,@dptr
      004D53 FF               [12] 1181 	mov	r7,a
      004D54 E0               [24] 1182 	movx	a,@dptr
      004D55 60 30            [24] 1183 	jz	00132$
                                   1184 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004D57 8F 82            [24] 1185 	mov	dpl, r7
      004D59 12 82 F0         [24] 1186 	lcall	_del_owned_mods
                                   1187 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004D5C 12 86 13         [24] 1188 	lcall	_send_keyboard_report
      004D5F 80 26            [24] 1189 	sjmp	00132$
      004D61                       1190 00128$:
                                   1191 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004D61 ED               [12] 1192 	mov	a,r5
      004D62 24 0C            [12] 1193 	add	a, #_source_state
      004D64 FE               [12] 1194 	mov	r6,a
      004D65 E4               [12] 1195 	clr	a
      004D66 34 06            [12] 1196 	addc	a, #(_source_state >> 8)
      004D68 FF               [12] 1197 	mov	r7,a
      004D69 12 38 6E         [24] 1198 	lcall	_ak820_outline_0105
      004D6C FD               [12] 1199 	mov	r5,a
      004D6D 30 E2 17         [24] 1200 	jnb	acc.2,00132$
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004D70 53 05 FB         [24] 1202 	anl	ar5,#0xfb
      004D73 12 38 90         [24] 1203 	lcall	_ak820_outline_0126
      004D76 ED               [12] 1204 	mov	a,r5
      004D77 F0               [24] 1205 	movx	@dptr,a
                                   1206 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004D78 90 06 9D         [24] 1207 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004D7B 12 38 39         [24] 1208 	lcall	_ak820_outline_0057
      004D7E 90 06 94         [24] 1209 	mov	dptr,#_hold_PARM_2
      004D81 E4               [12] 1210 	clr	a
      004D82 12 4A 00         [24] 1211 	lcall	_ak820_outline_0070
      004D85 51 89            [12] 1212 	acall	_hold
      004D87                       1213 00132$:
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004D87 75 82 00         [24] 1215 	mov	dpl, #0x00
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004D8A 22               [24] 1217 	ret
                                   1218 ;------------------------------------------------------------
                                   1219 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1220 ;------------------------------------------------------------
                                   1221 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1222 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1223 ;------------------------------------------------------------
                                   1224 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1225 ;	-----------------------------------------
                                   1226 ;	 function ak820_tapping_cancel
                                   1227 ;	-----------------------------------------
      004D8B                       1228 _ak820_tapping_cancel:
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004D8B 12 4F 77         [24] 1230 	lcall	_ak820_outline_0165
                                   1231 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004D8E 7F 00            [12] 1232 	mov	r7,#0x00
      004D90                       1233 00103$:
      004D90 BF 82 00         [24] 1234 	cjne	r7,#0x82,00122$
      004D93                       1235 00122$:
      004D93 50 16            [24] 1236 	jnc	00105$
                                   1237 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004D95 12 4F 02         [24] 1238 	lcall	_ak820_outline_0024
                                   1239 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004D98 74 02            [12] 1240 	mov	a,#0x02
      004D9A 5C               [12] 1241 	anl	a,r4
      004D9B FB               [12] 1242 	mov	r3,a
      004D9C 53 04 01         [24] 1243 	anl	ar4,#0x01
      004D9F EC               [12] 1244 	mov	a,r4
      004DA0 2C               [12] 1245 	add	a,r4
      004DA1 42 03            [12] 1246 	orl	ar3,a
      004DA3 12 38 AB         [24] 1247 	lcall	_ak820_outline_0145
      004DA6 EB               [12] 1248 	mov	a,r3
      004DA7 F0               [24] 1249 	movx	@dptr,a
                                   1250 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004DA8 0F               [12] 1251 	inc	r7
      004DA9 80 E5            [24] 1252 	sjmp	00103$
      004DAB                       1253 00105$:
                                   1254 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004DAB 22               [24] 1255 	ret
                                   1256 ;------------------------------------------------------------
                                   1257 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1258 ;------------------------------------------------------------
                                   1259 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1260 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1261 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1262 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1263 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1264 ;------------------------------------------------------------
                                   1265 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1266 ;	-----------------------------------------
                                   1267 ;	 function ak820_oneshot_process
                                   1268 ;	-----------------------------------------
      004DAC                       1269 _ak820_oneshot_process:
      004DAC 12 38 86         [24] 1270 	lcall	_ak820_outline_0114
      004DAF 90 06 A4         [24] 1271 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004DB2 12 38 8B         [24] 1272 	lcall	_ak820_outline_0115
                                   1273 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004DB5 90 06 A2         [24] 1274 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004DB8 E0               [24] 1275 	movx	a,@dptr
      004DB9 FF               [12] 1276 	mov	r7,a
      004DBA BF FF 02         [24] 1277 	cjne	r7,#0xff,00248$
      004DBD 80 0B            [24] 1278 	sjmp	00101$
      004DBF                       1279 00248$:
      004DBF C0 07            [24] 1280 	push	ar7
      004DC1 12 AA C4         [24] 1281 	lcall	_get_repeat_key_count
      004DC4 E5 82            [12] 1282 	mov	a, dpl
      004DC6 D0 07            [24] 1283 	pop	ar7
      004DC8 60 04            [24] 1284 	jz	00102$
      004DCA                       1285 00101$:
      004DCA 75 82 01         [24] 1286 	mov	dpl, #0x01
      004DCD 22               [24] 1287 	ret
      004DCE                       1288 00102$:
                                   1289 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004DCE 90 06 A4         [24] 1290 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004DD1 E0               [24] 1291 	movx	a,@dptr
      004DD2 FD               [12] 1292 	mov	r5,a
      004DD3 A3               [24] 1293 	inc	dptr
      004DD4 E0               [24] 1294 	movx	a,@dptr
      004DD5 FB               [12] 1295 	mov	r3,a
      004DD6 BB 52 02         [24] 1296 	cjne	r3,#0x52,00250$
      004DD9 80 02            [24] 1297 	sjmp	00251$
      004DDB                       1298 00250$:
      004DDB C1 7E            [12] 1299 	ajmp	00116$
      004DDD                       1300 00251$:
      004DDD 8D 04            [24] 1301 	mov	ar4,r5
      004DDF 53 04 E0         [24] 1302 	anl	ar4,#0xe0
      004DE2 BC A0 02         [24] 1303 	cjne	r4,#0xa0,00252$
      004DE5 80 02            [24] 1304 	sjmp	00253$
      004DE7                       1305 00252$:
      004DE7 C1 7E            [12] 1306 	ajmp	00116$
      004DE9                       1307 00253$:
                                   1308 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004DE9 8D 04            [24] 1309 	mov	ar4,r5
      004DEB 53 04 0F         [24] 1310 	anl	ar4,#0x0f
      004DEE 90 06 A6         [24] 1311 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004DF1 EC               [12] 1312 	mov	a,r4
      004DF2 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004DF3 ED               [12] 1315 	mov	a,r5
      004DF4 30 E4 08         [24] 1316 	jnb	acc.4,00105$
      004DF7 EC               [12] 1317 	mov	a,r4
      004DF8 C4               [12] 1318 	swap	a
      004DF9 54 F0            [12] 1319 	anl	a,#0xf0
      004DFB 90 06 A6         [24] 1320 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004DFE F0               [24] 1321 	movx	@dptr,a
      004DFF                       1322 00105$:
                                   1323 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004DFF 90 06 A3         [24] 1324 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004E02 E0               [24] 1325 	movx	a,@dptr
      004E03 60 2D            [24] 1326 	jz	00113$
                                   1327 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004E05 12 4F 02         [24] 1328 	lcall	_ak820_outline_0024
      004E08 43 04 08         [24] 1329 	orl	ar4,#0x08
      004E0B 12 49 F9         [24] 1330 	lcall	_ak820_outline_0068
                                   1331 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004E0E 53 04 EF         [24] 1332 	anl	ar4,#0xef
      004E11 12 49 F9         [24] 1333 	lcall	_ak820_outline_0068
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004E14 90 0E 6B         [24] 1335 	mov	dptr,#_ak820_oneshot_target
      004E17 E0               [24] 1336 	movx	a,@dptr
      004E18 FC               [12] 1337 	mov	r4,a
      004E19 BC FF 02         [24] 1338 	cjne	r4,#0xff,00256$
      004E1C 80 09            [24] 1339 	sjmp	00107$
      004E1E                       1340 00256$:
      004E1E 12 4F 56         [24] 1341 	lcall	_ak820_outline_0081
      004E21 43 04 10         [24] 1342 	orl	ar4,#0x10
      004E24 12 49 F9         [24] 1343 	lcall	_ak820_outline_0068
      004E27                       1344 00107$:
                                   1345 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004E27 90 06 A6         [24] 1346 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004E2A E0               [24] 1347 	movx	a,@dptr
      004E2B F5 82            [12] 1348 	mov	dpl,a
      004E2D 12 7C 82         [24] 1349 	lcall	_register_mods
      004E30 80 48            [24] 1350 	sjmp	00114$
      004E32                       1351 00113$:
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004E32 12 4F 02         [24] 1353 	lcall	_ak820_outline_0024
      004E35 30 E3 42         [24] 1354 	jnb	acc.3,00114$
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004E38 EC               [12] 1356 	mov	a,r4
      004E39 20 E4 24         [24] 1357 	jb	acc.4,00109$
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004E3C 90 06 A0         [24] 1359 	mov	dptr,#_ak820_oneshot_mods
      004E3F E0               [24] 1360 	movx	a,@dptr
      004E40 F4               [12] 1361 	cpl	a
      004E41 FC               [12] 1362 	mov	r4,a
      004E42 90 06 A6         [24] 1363 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004E45 E0               [24] 1364 	movx	a,@dptr
      004E46 FB               [12] 1365 	mov	r3,a
      004E47 52 04            [12] 1366 	anl	ar4,a
      004E49 8C 82            [24] 1367 	mov	dpl, r4
      004E4B C0 06            [24] 1368 	push	ar6
      004E4D C0 05            [24] 1369 	push	ar5
      004E4F C0 03            [24] 1370 	push	ar3
      004E51 12 82 E1         [24] 1371 	lcall	_add_owned_mods
      004E54 D0 03            [24] 1372 	pop	ar3
      004E56 D0 05            [24] 1373 	pop	ar5
      004E58 D0 06            [24] 1374 	pop	ar6
                                   1375 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004E5A 90 06 A0         [24] 1376 	mov	dptr,#_ak820_oneshot_mods
      004E5D E0               [24] 1377 	movx	a,@dptr
      004E5E 4B               [12] 1378 	orl	a,r3
      004E5F F0               [24] 1379 	movx	@dptr,a
      004E60                       1380 00109$:
                                   1381 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004E60 90 06 A6         [24] 1382 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004E63 E0               [24] 1383 	movx	a,@dptr
      004E64 F5 82            [12] 1384 	mov	dpl,a
      004E66 C0 06            [24] 1385 	push	ar6
      004E68 C0 05            [24] 1386 	push	ar5
      004E6A 12 7C 96         [24] 1387 	lcall	_unregister_mods
      004E6D D0 05            [24] 1388 	pop	ar5
      004E6F D0 06            [24] 1389 	pop	ar6
                                   1390 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004E71 12 4F 56         [24] 1391 	lcall	_ak820_outline_0081
      004E74 53 04 E7         [24] 1392 	anl	ar4,#0xe7
      004E77 12 49 F9         [24] 1393 	lcall	_ak820_outline_0068
      004E7A                       1394 00114$:
                                   1395 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004E7A 75 82 00         [24] 1396 	mov	dpl, #0x00
      004E7D 22               [24] 1397 	ret
      004E7E                       1398 00116$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004E7E 90 06 A3         [24] 1400 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004E81 E0               [24] 1401 	movx	a,@dptr
      004E82 60 64            [24] 1402 	jz	00124$
      004E84 90 06 A4         [24] 1403 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004E87 12 38 62         [24] 1404 	lcall	_ak820_outline_0085
      004E8A C3               [12] 1405 	clr	c
      004E8B 74 01            [12] 1406 	mov	a,#0x01
      004E8D 9D               [12] 1407 	subb	a,r5
      004E8E E4               [12] 1408 	clr	a
      004E8F 9E               [12] 1409 	subb	a,r6
      004E90 50 56            [24] 1410 	jnc	00124$
                                   1411 ;	free result
                                   1412 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004E92 C3               [12] 1413 	clr	c
      004E93 ED               [12] 1414 	mov	a,r5
      004E94 94 E0            [12] 1415 	subb	a,#0xe0
      004E96 EE               [12] 1416 	mov	a,r6
      004E97 94 00            [12] 1417 	subb	a,#0x00
      004E99 40 07            [24] 1418 	jc	00129$
      004E9B 74 E7            [12] 1419 	mov	a,#0xe7
      004E9D 9D               [12] 1420 	subb	a,r5
      004E9E E4               [12] 1421 	clr	a
      004E9F 9E               [12] 1422 	subb	a,r6
      004EA0 50 46            [24] 1423 	jnc	00124$
                                   1424 ;	free result
      004EA2                       1425 00129$:
                                   1426 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004EA2 74 AE            [12] 1427 	mov	a,#0x100 - 0x52
      004EA4 2E               [12] 1428 	add	a,r6
      004EA5 50 09            [24] 1429 	jnc	00165$
      004EA7 C3               [12] 1430 	clr	c
      004EA8 74 DF            [12] 1431 	mov	a,#0xdf
      004EAA 9D               [12] 1432 	subb	a,r5
      004EAB 74 52            [12] 1433 	mov	a,#0x52
      004EAD 9E               [12] 1434 	subb	a,r6
      004EAE 50 38            [24] 1435 	jnc	00124$
                                   1436 ;	free result
                                   1437 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004EB0                       1438 00165$:
      004EB0 7E 00            [12] 1439 	mov	r6,#0x00
      004EB2                       1440 00131$:
      004EB2 BE 82 00         [24] 1441 	cjne	r6,#0x82,00265$
      004EB5                       1442 00265$:
      004EB5 50 1A            [24] 1443 	jnc	00120$
                                   1444 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004EB7 EE               [12] 1445 	mov	a,r6
      004EB8 24 0C            [12] 1446 	add	a, #_source_state
      004EBA FC               [12] 1447 	mov	r4,a
      004EBB E4               [12] 1448 	clr	a
      004EBC 34 06            [12] 1449 	addc	a, #(_source_state >> 8)
      004EBE FD               [12] 1450 	mov	r5,a
      004EBF 12 4A 06         [24] 1451 	lcall	_ak820_outline_0084
      004EC2 FB               [12] 1452 	mov	r3,a
      004EC3 30 E3 08         [24] 1453 	jnb	acc.3,00132$
      004EC6 43 03 10         [24] 1454 	orl	ar3,#0x10
      004EC9 12 38 A1         [24] 1455 	lcall	_ak820_outline_0134
      004ECC EB               [12] 1456 	mov	a,r3
      004ECD F0               [24] 1457 	movx	@dptr,a
      004ECE                       1458 00132$:
                                   1459 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004ECE 0E               [12] 1460 	inc	r6
      004ECF 80 E1            [24] 1461 	sjmp	00131$
      004ED1                       1462 00120$:
                                   1463 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004ED1 90 06 A0         [24] 1464 	mov	dptr,#_ak820_oneshot_mods
      004ED4 E0               [24] 1465 	movx	a,@dptr
      004ED5 FE               [12] 1466 	mov	r6,a
      004ED6 E0               [24] 1467 	movx	a,@dptr
      004ED7 60 0F            [24] 1468 	jz	00124$
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004ED9 90 06 A1         [24] 1470 	mov	dptr,#_ak820_oneshot_consumed
      004EDC EE               [12] 1471 	mov	a,r6
      004EDD F0               [24] 1472 	movx	@dptr,a
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004EDE 90 0E 6B         [24] 1474 	mov	dptr,#_ak820_oneshot_target
      004EE1 EF               [12] 1475 	mov	a,r7
      004EE2 F0               [24] 1476 	movx	@dptr,a
                                   1477 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004EE3 90 06 A0         [24] 1478 	mov	dptr,#_ak820_oneshot_mods
      004EE6 E4               [12] 1479 	clr	a
      004EE7 F0               [24] 1480 	movx	@dptr,a
      004EE8                       1481 00124$:
                                   1482 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004EE8 75 82 01         [24] 1483 	mov	dpl, #0x01
                                   1484 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004EEB 22               [24] 1485 	ret
                                   1486 	.area CSEG    (CODE)
                                   1487 	.area CONST   (CODE)
                                   1488 	.area XINIT   (CODE)
      00CA28                       1489 __xinit__pending:
      00CA28 FF                    1490 	.db #0xff	; 255
      00CA29                       1491 __xinit__ak820_oneshot_target:
      00CA29 FF                    1492 	.db #0xff	; 255
                                   1493 	.area CABS    (ABS,CODE)
                                   1494 
                                   1495 ; Experimental exact instruction outlining.
                                   1496 	.globl _ak820_outline_0007
                                   1497 	.globl _ak820_outline_0010
                                   1498 	.globl _ak820_outline_0012
                                   1499 	.globl _ak820_outline_0016
                                   1500 	.globl _ak820_outline_0017
                                   1501 	.globl _ak820_outline_0021
                                   1502 	.globl _ak820_outline_0024
                                   1503 	.globl _ak820_outline_0026
                                   1504 	.globl _ak820_outline_0027
                                   1505 	.globl _ak820_outline_0034
                                   1506 	.globl _ak820_outline_0035
                                   1507 	.globl _ak820_outline_0037
                                   1508 	.globl _ak820_outline_0057
                                   1509 	.globl _ak820_outline_0061
                                   1510 	.globl _ak820_outline_0064
                                   1511 	.globl _ak820_outline_0068
                                   1512 	.globl _ak820_outline_0070
                                   1513 	.globl _ak820_outline_0080
                                   1514 	.globl _ak820_outline_0081
                                   1515 	.globl _ak820_outline_0084
                                   1516 	.globl _ak820_outline_0085
                                   1517 	.globl _ak820_outline_0102
                                   1518 	.globl _ak820_outline_0105
                                   1519 	.globl _ak820_outline_0110
                                   1520 	.globl _ak820_outline_0114
                                   1521 	.globl _ak820_outline_0115
                                   1522 	.globl _ak820_outline_0119
                                   1523 	.globl _ak820_outline_0126
                                   1524 	.globl _ak820_outline_0129
                                   1525 	.globl _ak820_outline_0134
                                   1526 	.globl _ak820_outline_0145
                                   1527 	.globl _ak820_outline_0149
                                   1528 	.globl _ak820_outline_0165
                                   1529 	.globl _ak820_outline_0169
                                   1530 	.globl _ak820_outline_0198
                                   1531 
                                   1532 	.area CSEG (CODE)
                                   1533 ; function ak820_outline_0010
      004EEC                       1534 _ak820_outline_0010:
      004EEC E0               [24] 1535 	movx	a,@dptr
      004EED FE               [12] 1536 	mov	r6,a
      004EEE A3               [24] 1537 	inc	dptr
      004EEF E0               [24] 1538 	movx	a,@dptr
      004EF0 FF               [12] 1539 	mov	r7,a
      004EF1 8E 04            [24] 1540 	mov	ar4,r6
      004EF3 8F 05            [24] 1541 	mov	ar5,r7
      004EF5 22               [24] 1542 	ret
                                   1543 
                                   1544 	.area CSEG (CODE)
                                   1545 ; function ak820_outline_0017
      004EF6                       1546 _ak820_outline_0017:
      004EF6 74 05            [12] 1547 	mov	a,#0x05
      004EF8 2E               [12] 1548 	add	a,r6
      004EF9 FB               [12] 1549 	mov	r3,a
      004EFA E4               [12] 1550 	clr	a
      004EFB 3F               [12] 1551 	addc	a,r7
      004EFC FC               [12] 1552 	mov	r4,a
      004EFD 8B 82            [24] 1553 	mov	dpl,r3
      004EFF 8C 83            [24] 1554 	mov	dph,r4
      004F01 22               [24] 1555 	ret
                                   1556 
                                   1557 	.area CSEG (CODE)
                                   1558 ; function ak820_outline_0024
      004F02                       1559 _ak820_outline_0024:
      004F02 EF               [12] 1560 	mov	a,r7
      004F03 24 0C            [12] 1561 	add	a,#_source_state
      004F05 FD               [12] 1562 	mov	r5,a
      004F06 E4               [12] 1563 	clr	a
      004F07 34 06            [12] 1564 	addc	a,#(_source_state>>8)
      004F09 FE               [12] 1565 	mov	r6,a
      004F0A 8D 82            [24] 1566 	mov	dpl,r5
      004F0C 8E 83            [24] 1567 	mov	dph,r6
      004F0E E0               [24] 1568 	movx	a,@dptr
      004F0F FC               [12] 1569 	mov	r4,a
      004F10 22               [24] 1570 	ret
                                   1571 
                                   1572 	.area CSEG (CODE)
                                   1573 ; function ak820_outline_0026
      004F11                       1574 _ak820_outline_0026:
      004F11 90 0E 57         [24] 1575 	mov	dptr,#___memcpy_PARM_2
      004F14 EC               [12] 1576 	mov	a,r4
      004F15 F0               [24] 1577 	movx	@dptr,a
      004F16 ED               [12] 1578 	mov	a,r5
      004F17 A3               [24] 1579 	inc	dptr
      004F18 F0               [24] 1580 	movx	@dptr,a
      004F19 E4               [12] 1581 	clr	a
      004F1A A3               [24] 1582 	inc	dptr
      004F1B F0               [24] 1583 	movx	@dptr,a
      004F1C 90 0E 5A         [24] 1584 	mov	dptr,#___memcpy_PARM_3
      004F1F 74 02            [12] 1585 	mov	a,#0x02
      004F21 F0               [24] 1586 	movx	@dptr,a
      004F22 E4               [12] 1587 	clr	a
      004F23 A3               [24] 1588 	inc	dptr
      004F24 F0               [24] 1589 	movx	@dptr,a
      004F25 90 06 92         [24] 1590 	mov	dptr,#_ak820_tapping_source_PARM_1
      004F28 F5 F0            [12] 1591 	mov	b,a
      004F2A 22               [24] 1592 	ret
                                   1593 
                                   1594 	.area CSEG (CODE)
                                   1595 ; function ak820_outline_0034
      004F2B                       1596 _ak820_outline_0034:
      004F2B 2E               [12] 1597 	add	a,r6
      004F2C FA               [12] 1598 	mov	r2,a
      004F2D E4               [12] 1599 	clr	a
      004F2E 3F               [12] 1600 	addc	a,r7
      004F2F FB               [12] 1601 	mov	r3,a
      004F30 8A 82            [24] 1602 	mov	dpl,r2
      004F32 8B 83            [24] 1603 	mov	dph,r3
      004F34 E0               [24] 1604 	movx	a,@dptr
      004F35 22               [24] 1605 	ret
                                   1606 
                                   1607 	.area CSEG (CODE)
                                   1608 ; function ak820_outline_0035
      004F36                       1609 _ak820_outline_0035:
      004F36 2E               [12] 1610 	add	a,r6
      004F37 FC               [12] 1611 	mov	r4,a
      004F38 E4               [12] 1612 	clr	a
      004F39 3F               [12] 1613 	addc	a,r7
      004F3A FD               [12] 1614 	mov	r5,a
      004F3B 8C 82            [24] 1615 	mov	dpl,r4
      004F3D 8D 83            [24] 1616 	mov	dph,r5
      004F3F E0               [24] 1617 	movx	a,@dptr
      004F40 22               [24] 1618 	ret
                                   1619 
                                   1620 	.area CSEG (CODE)
                                   1621 ; function ak820_outline_0061
      004F41                       1622 _ak820_outline_0061:
      004F41 FC               [12] 1623 	mov	r4,a
      004F42 8B 82            [24] 1624 	mov	dpl,r3
      004F44 8C 83            [24] 1625 	mov	dph,r4
      004F46 E0               [24] 1626 	movx	a,@dptr
      004F47 FA               [12] 1627 	mov	r2,a
      004F48 22               [24] 1628 	ret
                                   1629 
                                   1630 	.area CSEG (CODE)
                                   1631 ; function ak820_outline_0064
      004F49                       1632 _ak820_outline_0064:
      004F49 EE               [12] 1633 	mov	a,r6
      004F4A F0               [24] 1634 	movx	@dptr,a
      004F4B EF               [12] 1635 	mov	a,r7
      004F4C A3               [24] 1636 	inc	dptr
      004F4D F0               [24] 1637 	movx	@dptr,a
      004F4E 22               [24] 1638 	ret
                                   1639 
                                   1640 	.area CSEG (CODE)
                                   1641 ; function ak820_outline_0080
      004F4F                       1642 _ak820_outline_0080:
      004F4F 8E 00            [24] 1643 	mov	ar0,r6
      004F51 8F 01            [24] 1644 	mov	ar1,r7
      004F53 7A 00            [12] 1645 	mov	r2,#0x00
      004F55 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0081
      004F56                       1650 _ak820_outline_0081:
      004F56 8D 82            [24] 1651 	mov	dpl,r5
      004F58 8E 83            [24] 1652 	mov	dph,r6
      004F5A E0               [24] 1653 	movx	a,@dptr
      004F5B FC               [12] 1654 	mov	r4,a
      004F5C 22               [24] 1655 	ret
                                   1656 
                                   1657 	.area CSEG (CODE)
                                   1658 ; function ak820_outline_0102
      004F5D                       1659 _ak820_outline_0102:
      004F5D 74 04            [12] 1660 	mov	a,#0x04
      004F5F 2E               [12] 1661 	add	a,r6
      004F60 FB               [12] 1662 	mov	r3,a
      004F61 E4               [12] 1663 	clr	a
      004F62 3F               [12] 1664 	addc	a,r7
      004F63 FC               [12] 1665 	mov	r4,a
      004F64 8B 82            [24] 1666 	mov	dpl,r3
      004F66 8C 83            [24] 1667 	mov	dph,r4
      004F68 E0               [24] 1668 	movx	a,@dptr
      004F69 22               [24] 1669 	ret
                                   1670 
                                   1671 	.area CSEG (CODE)
                                   1672 ; function ak820_outline_0119
      004F6A                       1673 _ak820_outline_0119:
      004F6A 88 82            [24] 1674 	mov	dpl,r0
      004F6C 89 83            [24] 1675 	mov	dph,r1
      004F6E 8A F0            [24] 1676 	mov	b,r2
      004F70 22               [24] 1677 	ret
                                   1678 
                                   1679 	.area CSEG (CODE)
                                   1680 ; function ak820_outline_0149
      004F71                       1681 _ak820_outline_0149:
      004F71 E9               [12] 1682 	mov	a,r1
      004F72 F0               [24] 1683 	movx	@dptr,a
      004F73 EA               [12] 1684 	mov	a,r2
      004F74 A3               [24] 1685 	inc	dptr
      004F75 F0               [24] 1686 	movx	@dptr,a
      004F76 22               [24] 1687 	ret
                                   1688 
                                   1689 	.area CSEG (CODE)
                                   1690 ; function ak820_outline_0165
      004F77                       1691 _ak820_outline_0165:
      004F77 90 0E 6A         [24] 1692 	mov	dptr,#_pending
      004F7A 74 FF            [12] 1693 	mov	a,#0xff
      004F7C F0               [24] 1694 	movx	@dptr,a
      004F7D 22               [24] 1695 	ret
