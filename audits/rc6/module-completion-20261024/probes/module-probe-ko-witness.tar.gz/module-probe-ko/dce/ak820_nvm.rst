                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      000027                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      000027                         68 	.ds 2
      000029                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      000029                         70 	.ds 2
      00002B                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      00002B                         72 	.ds 2
      00002D                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      00002D                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      00000C                         91 _page_valid:
      00000C                         92 	.ds 1
      00000D                         93 _page_dirty:
      00000D                         94 	.ds 1
      00000E                         95 _storage_failed:
      00000E                         96 	.ds 1
      00000F                         97 _ak820_nvm_ok_sloc0_1_0:
      00000F                         98 	.ds 1
      000010                         99 _load_page_sloc0_1_0:
      000010                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00058B                        109 _page_data:
      00058B                        110 	.ds 64
      0005CB                        111 _cached_page:
      0005CB                        112 	.ds 1
      0005CC                        113 _batch_depth:
      0005CC                        114 	.ds 1
      0005CD                        115 _first_failure_stage:
      0005CD                        116 	.ds 1
      0005CE                        117 _nvm_fail_stage_10000_20:
      0005CE                        118 	.ds 1
      0005CF                        119 _ak820_nvm_diagnostic_out_10000_23:
      0005CF                        120 	.ds 2
      0005D1                        121 _crc_byte_PARM_2:
      0005D1                        122 	.ds 1
      0005D2                        123 _crc_byte_crc_10000_25:
      0005D2                        124 	.ds 2
      0005D4                        125 _page_crc_crc_10000_30:
      0005D4                        126 	.ds 2
      0005D6                        127 _write_page_address_10000_32:
      0005D6                        128 	.ds 2
      0005D8                        129 _journal_header_valid_header_10000_39:
      0005D8                        130 	.ds 2
      0005DA                        131 _recover_journal_header_10000_46:
      0005DA                        132 	.ds 9
      0005E3                        133 _ak820_nvm_flush_header_10000_62:
      0005E3                        134 	.ds 9
      0005EC                        135 _ak820_nvm_flush_stage_10000_62:
      0005EC                        136 	.ds 1
      0005ED                        137 _load_page_page_10000_87:
      0005ED                        138 	.ds 1
      0005EE                        139 _read_offset_offset_10000_93:
      0005EE                        140 	.ds 2
      0005F0                        141 _eeprom_read_byte_addr_10000_97:
      0005F0                        142 	.ds 3
      0005F3                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      0005F3                        144 	.ds 3
      0005F6                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      0005F6                        146 	.ds 2
      0005F8                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005F8                        148 	.ds 2
      0005FA                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005FA                        150 	.ds 2
      0005FC                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005FC                        152 	.ds 3
      0005FF                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005FF                        154 	.ds 2
      000601                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000601                        156 	.ds 2
      000603                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000603                        158 	.ds 3
      000606                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000606                        160 	.ds 2
      000608                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000608                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      004246                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      004246 E5 82            [12]  215 	mov	a,dpl
      004248 90 05 CE         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      00424B F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      00424C 20 0E 08         [24]  219 	jb	_storage_failed,00102$
      00424F 90 05 CE         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      004252 E0               [24]  221 	movx	a,@dptr
      004253 90 05 CD         [24]  222 	mov	dptr,#_first_failure_stage
      004256 F0               [24]  223 	movx	@dptr,a
      004257                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      004257 D2 0E            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      004259 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      00425A                        239 _ak820_nvm_diagnostic:
      00425A 12 38 86         [24]  240 	lcall	_ak820_outline_0114
      00425D 90 05 CF         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      004260 12 38 8B         [24]  242 	lcall	_ak820_outline_0115
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      004263 90 05 CF         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      004266 12 38 39         [24]  245 	lcall	_ak820_outline_0057
      004269 A2 0E            [12]  246 	mov	c,_storage_failed
      00426B E4               [12]  247 	clr	a
      00426C 33               [12]  248 	rlc	a
      00426D 12 38 90         [24]  249 	lcall	_ak820_outline_0126
      004270 12 4A 00         [24]  250 	lcall	_ak820_outline_0070
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      004273 A3               [24]  252 	inc	dptr
      004274 A2 0C            [12]  253 	mov	c,_page_valid
      004276 E4               [12]  254 	clr	a
      004277 33               [12]  255 	rlc	a
      004278 12 49 CD         [24]  256 	lcall	_ak820_outline_0027
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      00427B A2 0D            [12]  258 	mov	c,_page_dirty
      00427D E4               [12]  259 	clr	a
      00427E 33               [12]  260 	rlc	a
      00427F F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      004280 74 03            [12]  263 	mov	a,#0x03
      004282 12 4A 3E         [24]  264 	lcall	_ak820_outline_0172
      004285 90 05 CC         [24]  265 	mov	dptr,#_batch_depth
      004288 E0               [24]  266 	movx	a,@dptr
      004289 12 38 A1         [24]  267 	lcall	_ak820_outline_0134
      00428C F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      00428D 74 04            [12]  270 	mov	a,#0x04
      00428F 12 4A 3E         [24]  271 	lcall	_ak820_outline_0172
      004292 90 05 CB         [24]  272 	mov	dptr,#_cached_page
      004295 E0               [24]  273 	movx	a,@dptr
      004296 12 38 A1         [24]  274 	lcall	_ak820_outline_0134
      004299 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      00429A 12 49 C3         [24]  277 	lcall	_ak820_outline_0012
      00429D E4               [12]  278 	clr	a
      00429E F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      00429F 74 06            [12]  281 	mov	a,#0x06
      0042A1 12 4A 23         [24]  282 	lcall	_ak820_outline_0148
      0042A4 90 05 CD         [24]  283 	mov	dptr,#_first_failure_stage
      0042A7 E0               [24]  284 	movx	a,@dptr
      0042A8 12 38 90         [24]  285 	lcall	_ak820_outline_0126
      0042AB F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      0042AC 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      0042AD                        300 _crc_byte:
      0042AD 12 38 86         [24]  301 	lcall	_ak820_outline_0114
      0042B0 90 05 D2         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      0042B3 12 38 8B         [24]  303 	lcall	_ak820_outline_0115
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      0042B6 90 05 D1         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      0042B9 E0               [24]  306 	movx	a,@dptr
      0042BA FF               [12]  307 	mov	r7,a
      0042BB 7E 00            [12]  308 	mov	r6,#0x00
      0042BD 90 05 D2         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      0042C0 E0               [24]  310 	movx	a,@dptr
      0042C1 6E               [12]  311 	xrl	a,r6
      0042C2 F0               [24]  312 	movx	@dptr,a
      0042C3 A3               [24]  313 	inc	dptr
      0042C4 E0               [24]  314 	movx	a,@dptr
      0042C5 6F               [12]  315 	xrl	a,r7
      0042C6 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      0042C7 7F 00            [12]  318 	mov	r7,#0x00
      0042C9                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      0042C9 90 05 D2         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      0042CC 12 38 62         [24]  322 	lcall	_ak820_outline_0085
      0042CF 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      0042D2 ED               [12]  324 	mov	a,r5
      0042D3 2D               [12]  325 	add	a,r5
      0042D4 FB               [12]  326 	mov	r3,a
      0042D5 EE               [12]  327 	mov	a,r6
      0042D6 33               [12]  328 	rlc	a
      0042D7 FC               [12]  329 	mov	r4,a
      0042D8 63 03 21         [24]  330 	xrl	ar3,#0x21
      0042DB 63 04 10         [24]  331 	xrl	ar4,#0x10
      0042DE 80 06            [24]  332 	sjmp	00107$
      0042E0                        333 00106$:
      0042E0 ED               [12]  334 	mov	a,r5
      0042E1 2D               [12]  335 	add	a,r5
      0042E2 FB               [12]  336 	mov	r3,a
      0042E3 EE               [12]  337 	mov	a,r6
      0042E4 33               [12]  338 	rlc	a
      0042E5 FC               [12]  339 	mov	r4,a
      0042E6                        340 00107$:
      0042E6 90 05 D2         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      0042E9 12 38 68         [24]  342 	lcall	_ak820_outline_0090
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      0042EC 0F               [12]  344 	inc	r7
      0042ED BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      0042F0 12 33 FC         [24]  347 	lcall	_ak820_outline_0129
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      0042F3 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      0042F4                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      0042F4 90 05 D4         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      0042F7 74 FF            [12]  363 	mov	a,#0xff
      0042F9 F0               [24]  364 	movx	@dptr,a
      0042FA A3               [24]  365 	inc	dptr
      0042FB F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      0042FC 7F 00            [12]  368 	mov	r7,#0x00
      0042FE                        369 00102$:
      0042FE 90 05 D4         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      004301 12 38 62         [24]  371 	lcall	_ak820_outline_0085
      004304 12 4A 0C         [24]  372 	lcall	_ak820_outline_0112
      004307 90 05 D1         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      00430A F0               [24]  374 	movx	@dptr,a
      00430B 12 38 AB         [24]  375 	lcall	_ak820_outline_0145
      00430E C0 07            [24]  376 	push	ar7
      004310 12 42 AD         [24]  377 	lcall	_crc_byte
      004313 AD 82            [24]  378 	mov	r5, dpl
      004315 AE 83            [24]  379 	mov	r6, dph
      004317 D0 07            [24]  380 	pop	ar7
      004319 90 05 D4         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      00431C 12 4A 44         [24]  382 	lcall	_ak820_outline_0173
      00431F 0F               [12]  383 	inc	r7
      004320 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      004323 12 38 AB         [24]  386 	lcall	_ak820_outline_0145
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      004326 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      004327                        399 _write_page:
      004327 12 38 86         [24]  400 	lcall	_ak820_outline_0114
      00432A 90 05 D6         [24]  401 	mov	dptr,#_write_page_address_10000_32
      00432D 12 38 8B         [24]  402 	lcall	_ak820_outline_0115
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      004330 90 05 D6         [24]  404 	mov	dptr,#_write_page_address_10000_32
      004333 12 37 F7         [24]  405 	lcall	_ak820_outline_0006
      004336 C0 07            [24]  406 	push	ar7
      004338 C0 06            [24]  407 	push	ar6
      00433A 12 3A 00         [24]  408 	lcall	_ak820_flash_erase
      00433D E5 82            [12]  409 	mov	a, dpl
      00433F D0 06            [24]  410 	pop	ar6
      004341 D0 07            [24]  411 	pop	ar7
      004343 70 03            [24]  412 	jnz	00102$
      004345 F5 82            [12]  413 	mov	dpl,a
      004347 22               [24]  414 	ret
      004348                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      004348 90 04 F9         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      00434B 74 8B            [12]  418 	mov	a,#_page_data
      00434D F0               [24]  419 	movx	@dptr,a
      00434E 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      004350 A3               [24]  421 	inc	dptr
      004351 12 4A 00         [24]  422 	lcall	_ak820_outline_0070
      004354 12 3B 14         [24]  423 	lcall	_ak820_flash_program_page
      004357 E5 82            [12]  424 	mov	a, dpl
      004359 70 03            [24]  425 	jnz	00120$
      00435B F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00435D 22               [24]  428 	ret
      00435E                        429 00120$:
      00435E 7F 00            [12]  430 	mov	r7,#0x00
      004360                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      004360 8F 05            [24]  433 	mov	ar5,r7
      004362 7E 00            [12]  434 	mov	r6,#0x00
      004364 90 05 D6         [24]  435 	mov	dptr,#_write_page_address_10000_32
      004367 12 38 9B         [24]  436 	lcall	_ak820_outline_0133
      00436A ED               [12]  437 	mov	a,r5
      00436B 2B               [12]  438 	add	a, r3
      00436C FB               [12]  439 	mov	r3,a
      00436D EE               [12]  440 	mov	a,r6
      00436E 3C               [12]  441 	addc	a, r4
      00436F FC               [12]  442 	mov	r4,a
      004370 12 33 FC         [24]  443 	lcall	_ak820_outline_0129
      004373 12 38 F3         [24]  444 	lcall	_ak820_flash_read
      004376 AE 82            [24]  445 	mov	r6, dpl
      004378 12 4A 0C         [24]  446 	lcall	_ak820_outline_0112
      00437B FD               [12]  447 	mov	r5,a
      00437C EE               [12]  448 	mov	a,r6
      00437D B5 05 02         [24]  449 	cjne	a,ar5,00149$
      004380 80 04            [24]  450 	sjmp	00109$
      004382                        451 00149$:
      004382 75 82 00         [24]  452 	mov	dpl, #0x00
      004385 22               [24]  453 	ret
      004386                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004386 0F               [12]  456 	inc	r7
      004387 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      00438A 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      00438D 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      00438E                        472 _journal_header_valid:
      00438E 12 38 86         [24]  473 	lcall	_ak820_outline_0114
      004391 90 05 D8         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      004394 12 38 8B         [24]  475 	lcall	_ak820_outline_0115
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      004397 90 05 D8         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      00439A 12 37 F7         [24]  478 	lcall	_ak820_outline_0006
      00439D E0               [24]  479 	movx	a,@dptr
      00439E FD               [12]  480 	mov	r5,a
      00439F BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      0043A2 80 04            [24]  482 	sjmp	00116$
      0043A4                        483 00138$:
      0043A4 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      0043A7 22               [24]  486 	ret
      0043A8                        487 00116$:
      0043A8 7D 01            [12]  488 	mov	r5,#0x01
      0043AA                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      0043AA ED               [12]  491 	mov	a,r5
      0043AB 12 38 0E         [24]  492 	lcall	_ak820_outline_0016
      0043AE FC               [12]  493 	mov	r4,a
      0043AF 8D 02            [24]  494 	mov	ar2,r5
      0043B1 7B 00            [12]  495 	mov	r3,#0x00
      0043B3 74 04            [12]  496 	mov	a,#0x04
      0043B5 2A               [12]  497 	add	a, r2
      0043B6 FA               [12]  498 	mov	r2,a
      0043B7 E4               [12]  499 	clr	a
      0043B8 3B               [12]  500 	addc	a, r3
      0043B9 FB               [12]  501 	mov	r3,a
      0043BA EA               [12]  502 	mov	a,r2
      0043BB 2E               [12]  503 	add	a, r6
      0043BC F5 82            [12]  504 	mov	dpl,a
      0043BE EB               [12]  505 	mov	a,r3
      0043BF 3F               [12]  506 	addc	a, r7
      0043C0 F5 83            [12]  507 	mov	dph,a
      0043C2 E0               [24]  508 	movx	a,@dptr
      0043C3 62 04            [12]  509 	xrl	ar4,a
      0043C5 BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      0043C8 80 04            [24]  511 	sjmp	00107$
      0043CA                        512 00139$:
      0043CA 75 82 00         [24]  513 	mov	dpl, #0x00
      0043CD 22               [24]  514 	ret
      0043CE                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      0043CE 0D               [12]  517 	inc	r5
      0043CF BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      0043D2 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      0043D5 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      0043D6                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      0043D6 7F 00            [12]  537 	mov	r7,#0x00
      0043D8                        538 00115$:
      0043D8 EF               [12]  539 	mov	a,r7
      0043D9 24 DA            [12]  540 	add	a, #_recover_journal_header_10000_46
      0043DB FD               [12]  541 	mov	r5,a
      0043DC E4               [12]  542 	clr	a
      0043DD 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      0043DF FE               [12]  544 	mov	r6,a
      0043E0 8F 04            [24]  545 	mov	ar4,r7
      0043E2 7B 00            [12]  546 	mov	r3,#0x00
      0043E4 74 40            [12]  547 	mov	a,#0x40
      0043E6 2C               [12]  548 	add	a, r4
      0043E7 FC               [12]  549 	mov	r4,a
      0043E8 74 EF            [12]  550 	mov	a,#0xef
      0043EA 3B               [12]  551 	addc	a, r3
      0043EB FB               [12]  552 	mov	r3,a
      0043EC 12 4A 4A         [24]  553 	lcall	_ak820_outline_0193
      0043EF 12 38 F3         [24]  554 	lcall	_ak820_flash_read
      0043F2 AC 82            [24]  555 	mov	r4, dpl
      0043F4 12 49 F9         [24]  556 	lcall	_ak820_outline_0068
      0043F7 0F               [12]  557 	inc	r7
      0043F8 BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      0043FB 90 05 DA         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      0043FE 12 43 8E         [24]  561 	lcall	_journal_header_valid
      004401 E5 82            [12]  562 	mov	a, dpl
      004403 70 01            [24]  563 	jnz	00103$
      004405 22               [24]  564 	ret
      004406                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      004406 90 05 DB         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      004409 E0               [24]  568 	movx	a,@dptr
      00440A FF               [12]  569 	mov	r7,a
      00440B 7E 00            [12]  570 	mov	r6,#0x00
      00440D 90 05 DC         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      004410 E0               [24]  572 	movx	a,@dptr
      004411 FC               [12]  573 	mov	r4,a
      004412 E4               [12]  574 	clr	a
      004413 42 07            [12]  575 	orl	ar7,a
      004415 EC               [12]  576 	mov	a,r4
      004416 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      004418 90 05 DD         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      00441B E0               [24]  580 	movx	a,@dptr
      00441C FD               [12]  581 	mov	r5,a
      00441D 7C 00            [12]  582 	mov	r4,#0x00
      00441F 90 05 DE         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      004422 E0               [24]  584 	movx	a,@dptr
      004423 FA               [12]  585 	mov	r2,a
      004424 E4               [12]  586 	clr	a
      004425 12 4A 29         [24]  587 	lcall	_ak820_outline_0153
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      004428 C3               [12]  589 	clr	c
      004429 EF               [12]  590 	mov	a,r7
      00442A 94 A0            [12]  591 	subb	a,#0xa0
      00442C EE               [12]  592 	mov	a,r6
      00442D 94 00            [12]  593 	subb	a,#0x00
      00442F 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      004431 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      004434 02 42 46         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      004437                        600 00134$:
      004437 7B 00            [12]  601 	mov	r3,#0x00
      004439                        602 00117$:
      004439 C0 05            [24]  603 	push	ar5
      00443B C0 04            [24]  604 	push	ar4
      00443D EB               [12]  605 	mov	a,r3
      00443E 24 8B            [12]  606 	add	a, #_page_data
      004440 F9               [12]  607 	mov	r1,a
      004441 E4               [12]  608 	clr	a
      004442 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      004444 FA               [12]  610 	mov	r2,a
      004445 8B 00            [24]  611 	mov	ar0,r3
      004447 7D 00            [12]  612 	mov	r5,#0x00
      004449 74 EF            [12]  613 	mov	a,#0xef
      00444B 2D               [12]  614 	add	a, r5
      00444C FD               [12]  615 	mov	r5,a
      00444D 88 82            [24]  616 	mov	dpl, r0
      00444F 8D 83            [24]  617 	mov	dph, r5
      004451 12 38 F3         [24]  618 	lcall	_ak820_flash_read
      004454 AD 82            [24]  619 	mov	r5, dpl
      004456 12 4A 34         [24]  620 	lcall	_ak820_outline_0168
      004459 ED               [12]  621 	mov	a,r5
      00445A F0               [24]  622 	movx	@dptr,a
      00445B 0B               [12]  623 	inc	r3
      00445C BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      00445F 80 06            [24]  625 	sjmp	00191$
      004461                        626 00190$:
      004461 D0 04            [24]  627 	pop	ar4
      004463 D0 05            [24]  628 	pop	ar5
      004465 80 D2            [24]  629 	sjmp	00117$
      004467                        630 00191$:
      004467 D0 04            [24]  631 	pop	ar4
      004469 D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      00446B C0 07            [24]  634 	push	ar7
      00446D C0 06            [24]  635 	push	ar6
      00446F C0 05            [24]  636 	push	ar5
      004471 C0 04            [24]  637 	push	ar4
      004473 12 42 F4         [24]  638 	lcall	_page_crc
      004476 AA 82            [24]  639 	mov	r2, dpl
      004478 AB 83            [24]  640 	mov	r3, dph
      00447A D0 04            [24]  641 	pop	ar4
      00447C D0 05            [24]  642 	pop	ar5
      00447E D0 06            [24]  643 	pop	ar6
      004480 D0 07            [24]  644 	pop	ar7
      004482 EA               [12]  645 	mov	a,r2
      004483 B5 05 06         [24]  646 	cjne	a,ar5,00192$
      004486 EB               [12]  647 	mov	a,r3
      004487 B5 04 02         [24]  648 	cjne	a,ar4,00192$
      00448A 80 06            [24]  649 	sjmp	00113$
      00448C                        650 00192$:
      00448C 75 82 02         [24]  651 	mov	dpl, #0x02
      00448F 02 42 46         [24]  652 	ljmp	_nvm_fail
      004492                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      004492 EE               [12]  655 	mov	a,r6
      004493 54 03            [12]  656 	anl	a,#0x03
      004495 A2 E0            [12]  657 	mov	c,acc.0
      004497 CF               [12]  658 	xch	a,r7
      004498 13               [12]  659 	rrc	a
      004499 CF               [12]  660 	xch	a,r7
      00449A 13               [12]  661 	rrc	a
      00449B A2 E0            [12]  662 	mov	c,acc.0
      00449D CF               [12]  663 	xch	a,r7
      00449E 13               [12]  664 	rrc	a
      00449F CF               [12]  665 	xch	a,r7
      0044A0 13               [12]  666 	rrc	a
      0044A1 CF               [12]  667 	xch	a,r7
      0044A2 24 C7            [12]  668 	add	a,#0xc7
      0044A4 FE               [12]  669 	mov	r6,a
      0044A5 12 4A 39         [24]  670 	lcall	_ak820_outline_0169
      0044A8 12 43 27         [24]  671 	lcall	_write_page
      0044AB E5 82            [12]  672 	mov	a, dpl
      0044AD 70 06            [24]  673 	jnz	00110$
      0044AF 75 82 03         [24]  674 	mov	dpl, #0x03
      0044B2 02 42 46         [24]  675 	ljmp	_nvm_fail
      0044B5                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      0044B5 90 EF 40         [24]  678 	mov	dptr,#0xef40
      0044B8 12 3A 00         [24]  679 	lcall	_ak820_flash_erase
      0044BB E5 82            [12]  680 	mov	a, dpl
      0044BD 70 06            [24]  681 	jnz	00119$
      0044BF 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      0044C2 02 42 46         [24]  684 	ljmp	_nvm_fail
      0044C5                        685 00119$:
      0044C5 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      0044C6                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      0044C6 C2 0E            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      0044C8 90 05 CD         [24]  699 	mov	dptr,#_first_failure_stage
      0044CB E4               [12]  700 	clr	a
      0044CC F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      0044CD C2 0D            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      0044CF C2 0C            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      0044D1 90 05 CC         [24]  708 	mov	dptr,#_batch_depth
      0044D4 E4               [12]  709 	clr	a
      0044D5 F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      0044D6 12 43 D6         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      0044D9 02 2A B7         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      0044DC                        723 _ak820_nvm_ok:
      0044DC A2 0E            [12]  724 	mov	c,_storage_failed
      0044DE B3               [12]  725 	cpl	c
      0044DF 92 0F            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      0044E1 12 38 B5         [24]  727 	lcall	_ak820_outline_0154
      0044E4 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      0044E5                        736 _ak820_nvm_schema_fault:
      0044E5 75 82 10         [24]  737 	mov	dpl, #0x10
      0044E8 02 42 46         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      0044EB                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      0044EB 30 0D 03         [24]  753 	jnb	_page_dirty,00101$
      0044EE 30 0E 01         [24]  754 	jnb	_storage_failed,00102$
      0044F1                        755 00101$:
      0044F1 22               [24]  756 	ret
      0044F2                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      0044F2 12 42 F4         [24]  759 	lcall	_page_crc
      0044F5 12 4A 1E         [24]  760 	lcall	_ak820_outline_0144
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      0044F8 90 05 E3         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0044FB 74 A5            [12]  763 	mov	a,#0xa5
      0044FD F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      0044FE 90 05 CB         [24]  766 	mov	dptr,#_cached_page
      004501 E0               [24]  767 	movx	a,@dptr
      004502 90 05 E4         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      004505 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      004506 90 05 E5         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      004509 E4               [12]  772 	clr	a
      00450A F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      00450B 8E 05            [24]  775 	mov	ar5,r6
      00450D 90 05 E6         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      004510 ED               [12]  777 	mov	a,r5
      004511 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      004512 8F 06            [24]  780 	mov	ar6,r7
      004514 90 05 E7         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      004517 EE               [12]  782 	mov	a,r6
      004518 F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      004519 7F 01            [12]  785 	mov	r7,#0x01
      00451B                        786 00128$:
      00451B 8F 06            [24]  787 	mov	ar6,r7
      00451D EE               [12]  788 	mov	a,r6
      00451E 24 04            [12]  789 	add	a,#0x04
      004520 FE               [12]  790 	mov	r6,a
      004521 33               [12]  791 	rlc	a
      004522 95 E0            [12]  792 	subb	a,acc
      004524 FD               [12]  793 	mov	r5,a
      004525 EE               [12]  794 	mov	a,r6
      004526 24 E3            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      004528 FE               [12]  796 	mov	r6,a
      004529 ED               [12]  797 	mov	a,r5
      00452A 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      00452C FD               [12]  799 	mov	r5,a
      00452D 12 49 DC         [24]  800 	lcall	_ak820_outline_0049
      004530 FC               [12]  801 	mov	r4,a
      004531 63 04 FF         [24]  802 	xrl	ar4,#0xff
      004534 8E 82            [24]  803 	mov	dpl,r6
      004536 8D 83            [24]  804 	mov	dph,r5
      004538 EC               [12]  805 	mov	a,r4
      004539 F0               [24]  806 	movx	@dptr,a
      00453A 0F               [12]  807 	inc	r7
      00453B BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      00453E 90 05 EC         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004541 74 05            [12]  811 	mov	a,#0x05
      004543 F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004544 90 EF 40         [24]  814 	mov	dptr,#0xef40
      004547 12 3A 00         [24]  815 	lcall	_ak820_flash_erase
      00454A E5 82            [12]  816 	mov	a, dpl
      00454C 70 03            [24]  817 	jnz	00269$
      00454E 02 46 35         [24]  818 	ljmp	00127$
      004551                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      004551 90 05 EC         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004554 74 06            [12]  822 	mov	a,#0x06
      004556 F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004557 7F 00            [12]  825 	mov	r7,#0x00
      004559                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      004559 12 49 E8         [24]  828 	lcall	_ak820_outline_0058
      00455C 12 38 F3         [24]  829 	lcall	_ak820_flash_read
      00455F E5 82            [12]  830 	mov	a, dpl
      004561 60 03            [24]  831 	jz	00270$
      004563 02 46 35         [24]  832 	ljmp	00127$
      004566                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004566 0F               [12]  835 	inc	r7
      004567 BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      00456A 90 05 EC         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00456D 74 07            [12]  839 	mov	a,#0x07
      00456F F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      004570 90 EF 00         [24]  842 	mov	dptr,#0xef00
      004573 12 43 27         [24]  843 	lcall	_write_page
      004576 E5 82            [12]  844 	mov	a, dpl
      004578 70 03            [24]  845 	jnz	00273$
      00457A 02 46 35         [24]  846 	ljmp	00127$
      00457D                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      00457D 90 05 EC         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004580 74 08            [12]  850 	mov	a,#0x08
      004582 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004583 7F 01            [12]  853 	mov	r7,#0x01
      004585                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      004585 12 49 DC         [24]  856 	lcall	_ak820_outline_0049
      004588 FE               [12]  857 	mov	r6,a
      004589 60 23            [24]  858 	jz	00133$
      00458B 8F 05            [24]  859 	mov	ar5,r7
      00458D 7C 00            [12]  860 	mov	r4,#0x00
      00458F 74 40            [12]  861 	mov	a,#0x40
      004591 2D               [12]  862 	add	a, r5
      004592 FD               [12]  863 	mov	r5,a
      004593 74 EF            [12]  864 	mov	a,#0xef
      004595 3C               [12]  865 	addc	a, r4
      004596 FC               [12]  866 	mov	r4,a
      004597 90 04 F6         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      00459A EE               [12]  868 	mov	a,r6
      00459B F0               [24]  869 	movx	@dptr,a
      00459C 8D 82            [24]  870 	mov	dpl, r5
      00459E 8C 83            [24]  871 	mov	dph, r4
      0045A0 C0 07            [24]  872 	push	ar7
      0045A2 12 3A 60         [24]  873 	lcall	_ak820_flash_program
      0045A5 E5 82            [12]  874 	mov	a, dpl
      0045A7 D0 07            [24]  875 	pop	ar7
      0045A9 70 03            [24]  876 	jnz	00275$
      0045AB 02 46 35         [24]  877 	ljmp	00127$
      0045AE                        878 00275$:
      0045AE                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0045AE 0F               [12]  881 	inc	r7
      0045AF BF 09 D3         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      0045B2 90 05 EC         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0045B5 74 09            [12]  885 	mov	a,#0x09
      0045B7 F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      0045B8 7F 01            [12]  888 	mov	r7,#0x01
      0045BA                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      0045BA 12 49 E8         [24]  891 	lcall	_ak820_outline_0058
      0045BD 12 38 F3         [24]  892 	lcall	_ak820_flash_read
      0045C0 AE 82            [24]  893 	mov	r6, dpl
      0045C2 12 49 DC         [24]  894 	lcall	_ak820_outline_0049
      0045C5 FD               [12]  895 	mov	r5,a
      0045C6 EE               [12]  896 	mov	a,r6
      0045C7 B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      0045CA 0F               [12]  899 	inc	r7
      0045CB BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      0045CE 90 05 EC         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0045D1 74 0A            [12]  903 	mov	a,#0x0a
      0045D3 F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      0045D4 90 05 E3         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0045D7 E0               [24]  907 	movx	a,@dptr
      0045D8 90 04 F6         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      0045DB F0               [24]  909 	movx	@dptr,a
      0045DC 90 EF 40         [24]  910 	mov	dptr,#0xef40
      0045DF 12 3A 60         [24]  911 	lcall	_ak820_flash_program
      0045E2 E5 82            [12]  912 	mov	a, dpl
      0045E4 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      0045E6 90 05 EC         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0045E9 74 0B            [12]  916 	mov	a,#0x0b
      0045EB F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      0045EC 90 EF 40         [24]  919 	mov	dptr,#0xef40
      0045EF 12 38 F3         [24]  920 	lcall	_ak820_flash_read
      0045F2 AF 82            [24]  921 	mov	r7, dpl
      0045F4 90 05 E3         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0045F7 E0               [24]  923 	movx	a,@dptr
      0045F8 FE               [12]  924 	mov	r6,a
      0045F9 EF               [12]  925 	mov	a,r7
      0045FA B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      0045FD 90 05 EC         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004600 74 0C            [12]  929 	mov	a,#0x0c
      004602 F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      004603 90 05 CB         [24]  932 	mov	dptr,#_cached_page
      004606 E0               [24]  933 	movx	a,@dptr
      004607 FE               [12]  934 	mov	r6,a
      004608 E4               [12]  935 	clr	a
      004609 C3               [12]  936 	clr	c
      00460A CE               [12]  937 	xch	a,r6
      00460B 13               [12]  938 	rrc	a
      00460C CE               [12]  939 	xch	a,r6
      00460D 13               [12]  940 	rrc	a
      00460E A2 E0            [12]  941 	mov	c,acc.0
      004610 CE               [12]  942 	xch	a,r6
      004611 13               [12]  943 	rrc	a
      004612 CE               [12]  944 	xch	a,r6
      004613 13               [12]  945 	rrc	a
      004614 CE               [12]  946 	xch	a,r6
      004615 24 C7            [12]  947 	add	a,#0xc7
      004617 FF               [12]  948 	mov	r7,a
      004618 12 38 90         [24]  949 	lcall	_ak820_outline_0126
      00461B 12 43 27         [24]  950 	lcall	_write_page
      00461E E5 82            [12]  951 	mov	a, dpl
      004620 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      004622 90 05 EC         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004625 74 0D            [12]  955 	mov	a,#0x0d
      004627 F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004628 90 EF 40         [24]  958 	mov	dptr,#0xef40
      00462B 12 3A 00         [24]  959 	lcall	_ak820_flash_erase
      00462E E5 82            [12]  960 	mov	a, dpl
      004630 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      004632 C2 0D            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      004634 22               [24]  967 	ret
      004635                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      004635 90 05 EC         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004638 E0               [24]  971 	movx	a,@dptr
      004639 F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      00463B 02 42 46         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      00463E                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      00463E 90 05 CC         [24]  984 	mov	dptr,#_batch_depth
      004641 E0               [24]  985 	movx	a,@dptr
      004642 FF               [12]  986 	mov	r7,a
      004643 BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      004646 75 82 0F         [24]  988 	mov	dpl, #0x0f
      004649 02 42 46         [24]  989 	ljmp	_nvm_fail
      00464C                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      00464C 90 05 CC         [24]  992 	mov	dptr,#_batch_depth
      00464F EF               [12]  993 	mov	a,r7
      004650 04               [12]  994 	inc	a
      004651 F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      004652 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      004653                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      004653 90 05 CC         [24] 1007 	mov	dptr,#_batch_depth
      004656 E0               [24] 1008 	movx	a,@dptr
      004657 FF               [12] 1009 	mov	r7,a
      004658 E0               [24] 1010 	movx	a,@dptr
      004659 60 06            [24] 1011 	jz	00102$
      00465B EF               [12] 1012 	mov	a,r7
      00465C 14               [12] 1013 	dec	a
      00465D 90 05 CC         [24] 1014 	mov	dptr,#_batch_depth
      004660 F0               [24] 1015 	movx	@dptr,a
      004661                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      004661 90 05 CC         [24] 1018 	mov	dptr,#_batch_depth
      004664 E0               [24] 1019 	movx	a,@dptr
      004665 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004667 02 44 EB         [24] 1022 	ljmp	_ak820_nvm_flush
      00466A                       1023 00105$:
      00466A 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      00466B                       1035 _load_page:
      00466B E5 82            [12] 1036 	mov	a,dpl
      00466D 90 05 ED         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      004670 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      004671 30 0C 17         [24] 1040 	jnb	_page_valid,00102$
      004674 90 05 CB         [24] 1041 	mov	dptr,#_cached_page
      004677 E0               [24] 1042 	movx	a,@dptr
      004678 FF               [12] 1043 	mov	r7,a
      004679 90 05 ED         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      00467C E0               [24] 1045 	movx	a,@dptr
      00467D FE               [12] 1046 	mov	r6,a
      00467E EF               [12] 1047 	mov	a,r7
      00467F B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      004682 A2 0E            [12] 1049 	mov	c,_storage_failed
      004684 B3               [12] 1050 	cpl	c
      004685 92 10            [24] 1051 	mov  _load_page_sloc0_1_0,c
      004687 12 38 B5         [24] 1052 	lcall	_ak820_outline_0154
      00468A 22               [24] 1053 	ret
      00468B                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      00468B 12 44 EB         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      00468E 30 0E 04         [24] 1058 	jnb	_storage_failed,00119$
      004691 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004694 22               [24] 1061 	ret
      004695                       1062 00119$:
      004695 7F 00            [12] 1063 	mov	r7,#0x00
      004697                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004697 EF               [12] 1066 	mov	a,r7
      004698 24 8B            [12] 1067 	add	a, #_page_data
      00469A FD               [12] 1068 	mov	r5,a
      00469B E4               [12] 1069 	clr	a
      00469C 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      00469E FE               [12] 1071 	mov	r6,a
      00469F 90 05 ED         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      0046A2 E0               [24] 1073 	movx	a,@dptr
      0046A3 FC               [12] 1074 	mov	r4,a
      0046A4 FA               [12] 1075 	mov	r2,a
      0046A5 E4               [12] 1076 	clr	a
      0046A6 C3               [12] 1077 	clr	c
      0046A7 CA               [12] 1078 	xch	a,r2
      0046A8 13               [12] 1079 	rrc	a
      0046A9 CA               [12] 1080 	xch	a,r2
      0046AA 13               [12] 1081 	rrc	a
      0046AB A2 E0            [12] 1082 	mov	c,acc.0
      0046AD CA               [12] 1083 	xch	a,r2
      0046AE 13               [12] 1084 	rrc	a
      0046AF CA               [12] 1085 	xch	a,r2
      0046B0 13               [12] 1086 	rrc	a
      0046B1 CA               [12] 1087 	xch	a,r2
      0046B2 24 C7            [12] 1088 	add	a,#0xc7
      0046B4 FB               [12] 1089 	mov	r3,a
      0046B5 8F 01            [24] 1090 	mov	ar1,r7
      0046B7 89 00            [24] 1091 	mov	ar0,r1
      0046B9 79 00            [12] 1092 	mov	r1,#0x00
      0046BB E8               [12] 1093 	mov	a,r0
      0046BC 2A               [12] 1094 	add	a, r2
      0046BD FA               [12] 1095 	mov	r2,a
      0046BE E9               [12] 1096 	mov	a,r1
      0046BF 3B               [12] 1097 	addc	a, r3
      0046C0 FB               [12] 1098 	mov	r3,a
      0046C1 12 38 B0         [24] 1099 	lcall	_ak820_outline_0146
      0046C4 12 38 F3         [24] 1100 	lcall	_ak820_flash_read
      0046C7 AB 82            [24] 1101 	mov	r3, dpl
      0046C9 12 38 AB         [24] 1102 	lcall	_ak820_outline_0145
      0046CC EB               [12] 1103 	mov	a,r3
      0046CD F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0046CE 0F               [12] 1106 	inc	r7
      0046CF BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      0046D2 90 05 CB         [24] 1109 	mov	dptr,#_cached_page
      0046D5 EC               [12] 1110 	mov	a,r4
      0046D6 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      0046D7 D2 0C            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      0046D9 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      0046DC 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      0046DD                       1128 _read_offset:
      0046DD 12 38 86         [24] 1129 	lcall	_ak820_outline_0114
      0046E0 90 05 EE         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      0046E3 12 38 8B         [24] 1131 	lcall	_ak820_outline_0115
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      0046E6 90 05 EE         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      0046E9 12 38 39         [24] 1134 	lcall	_ak820_outline_0057
      0046EC C3               [12] 1135 	clr	c
      0046ED 94 28            [12] 1136 	subb	a,#0x28
      0046EF 40 04            [24] 1137 	jc	00102$
      0046F1 75 82 00         [24] 1138 	mov	dpl, #0x00
      0046F4 22               [24] 1139 	ret
      0046F5                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0046F5 30 0C 34         [24] 1142 	jnb	_page_valid,00104$
      0046F8 8E 04            [24] 1143 	mov	ar4,r6
      0046FA EF               [12] 1144 	mov	a,r7
      0046FB A2 E7            [12] 1145 	mov	c,acc.7
      0046FD CC               [12] 1146 	xch	a,r4
      0046FE 33               [12] 1147 	rlc	a
      0046FF CC               [12] 1148 	xch	a,r4
      004700 33               [12] 1149 	rlc	a
      004701 A2 E7            [12] 1150 	mov	c,acc.7
      004703 CC               [12] 1151 	xch	a,r4
      004704 33               [12] 1152 	rlc	a
      004705 CC               [12] 1153 	xch	a,r4
      004706 33               [12] 1154 	rlc	a
      004707 CC               [12] 1155 	xch	a,r4
      004708 54 03            [12] 1156 	anl	a,#0x03
      00470A FD               [12] 1157 	mov	r5,a
      00470B 90 05 CB         [24] 1158 	mov	dptr,#_cached_page
      00470E E0               [24] 1159 	movx	a,@dptr
      00470F FA               [12] 1160 	mov	r2,a
      004710 7B 00            [12] 1161 	mov	r3,#0x00
      004712 EC               [12] 1162 	mov	a,r4
      004713 B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      004716 ED               [12] 1164 	mov	a,r5
      004717 B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      00471A 74 3F            [12] 1167 	mov	a,#0x3f
      00471C 5E               [12] 1168 	anl	a,r6
      00471D 7D 00            [12] 1169 	mov	r5,#0x00
      00471F 24 8B            [12] 1170 	add	a, #_page_data
      004721 F5 82            [12] 1171 	mov	dpl,a
      004723 ED               [12] 1172 	mov	a,r5
      004724 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      004726 F5 83            [12] 1174 	mov	dph,a
      004728 E0               [24] 1175 	movx	a,@dptr
      004729 F5 82            [12] 1176 	mov	dpl,a
      00472B 22               [24] 1177 	ret
      00472C                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      00472C 74 C7            [12] 1180 	mov	a,#0xc7
      00472E 2F               [12] 1181 	add	a, r7
      00472F FF               [12] 1182 	mov	r7,a
      004730 12 38 90         [24] 1183 	lcall	_ak820_outline_0126
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004733 02 38 F3         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      004736                       1195 _eeprom_read_byte:
      004736 C0 07            [24] 1196 	push	ar7
      004738 C0 06            [24] 1197 	push	ar6
      00473A 12 49 D5         [24] 1198 	lcall	_ak820_outline_0041
      00473D 90 05 F0         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004740 12 38 21         [24] 1200 	lcall	_ak820_outline_0022
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004743 90 05 F0         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004746 12 37 F7         [24] 1203 	lcall	_ak820_outline_0006
      004749 C0 06            [24] 1204 	push	ar6
      00474B C0 05            [24] 1205 	push	ar5
      00474D C0 04            [24] 1206 	push	ar4
      00474F C0 03            [24] 1207 	push	ar3
      004751 C0 02            [24] 1208 	push	ar2
      004753 C0 01            [24] 1209 	push	ar1
      004755 C0 00            [24] 1210 	push	ar0
      004757 12 46 DD         [24] 1211 	lcall	_read_offset
      00475A AF 82            [24] 1212 	mov	r7, dpl
      00475C D0 00            [24] 1213 	pop	ar0
      00475E D0 01            [24] 1214 	pop	ar1
      004760 D0 02            [24] 1215 	pop	ar2
      004762 D0 03            [24] 1216 	pop	ar3
      004764 D0 04            [24] 1217 	pop	ar4
      004766 D0 05            [24] 1218 	pop	ar5
      004768 D0 06            [24] 1219 	pop	ar6
      00476A 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      00476C D0 06            [24] 1222 	pop	ar6
      00476E D0 07            [24] 1223 	pop	ar7
      004770 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      004771                       1238 _ak820_eeprom_read_block_xdata:
      004771 12 38 86         [24] 1239 	lcall	_ak820_outline_0114
      004774 90 05 F8         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004777 12 38 8B         [24] 1241 	lcall	_ak820_outline_0115
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00477A 90 05 F3         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00477D 12 38 39         [24] 1244 	lcall	_ak820_outline_0057
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004780 90 05 F8         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004783 12 38 50         [24] 1247 	lcall	_ak820_outline_0065
      004786 90 05 FA         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004789 12 38 5C         [24] 1249 	lcall	_ak820_outline_0079
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      00478C 90 05 F6         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00478F 12 38 50         [24] 1252 	lcall	_ak820_outline_0065
      004792                       1253 00103$:
      004792 8C 02            [24] 1254 	mov	ar2,r4
      004794 8D 03            [24] 1255 	mov	ar3,r5
      004796 1C               [12] 1256 	dec	r4
      004797 BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      00479A 1D               [12] 1258 	dec	r5
      00479B                       1259 00130$:
      00479B EA               [12] 1260 	mov	a,r2
      00479C 4B               [12] 1261 	orl	a,r3
      00479D 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00479F 8E 02            [24] 1264 	mov	ar2,r6
      0047A1 8F 03            [24] 1265 	mov	ar3,r7
      0047A3 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      0047A5 2B               [12] 1267 	add	a,r3
      0047A6 50 17            [24] 1268 	jnc	00102$
      0047A8 90 05 FA         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0047AB 12 4A 18         [24] 1270 	lcall	_ak820_outline_0132
      0047AE 12 38 B0         [24] 1271 	lcall	_ak820_outline_0146
      0047B1 E4               [12] 1272 	clr	a
      0047B2 F0               [24] 1273 	movx	@dptr,a
      0047B3 90 05 FA         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0047B6 04               [12] 1275 	inc	a
      0047B7 2A               [12] 1276 	add	a, r2
      0047B8 F0               [24] 1277 	movx	@dptr,a
      0047B9 E4               [12] 1278 	clr	a
      0047BA 3B               [12] 1279 	addc	a, r3
      0047BB A3               [24] 1280 	inc	dptr
      0047BC F0               [24] 1281 	movx	@dptr,a
      0047BD 80 D3            [24] 1282 	sjmp	00103$
      0047BF                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0047BF 90 05 FA         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0047C2 12 4A 18         [24] 1286 	lcall	_ak820_outline_0132
      0047C5 12 38 90         [24] 1287 	lcall	_ak820_outline_0126
      0047C8 C0 07            [24] 1288 	push	ar7
      0047CA C0 06            [24] 1289 	push	ar6
      0047CC C0 05            [24] 1290 	push	ar5
      0047CE C0 04            [24] 1291 	push	ar4
      0047D0 C0 03            [24] 1292 	push	ar3
      0047D2 C0 02            [24] 1293 	push	ar2
      0047D4 12 46 DD         [24] 1294 	lcall	_read_offset
      0047D7 A9 82            [24] 1295 	mov	r1, dpl
      0047D9 D0 02            [24] 1296 	pop	ar2
      0047DB D0 03            [24] 1297 	pop	ar3
      0047DD D0 04            [24] 1298 	pop	ar4
      0047DF D0 05            [24] 1299 	pop	ar5
      0047E1 D0 06            [24] 1300 	pop	ar6
      0047E3 D0 07            [24] 1301 	pop	ar7
      0047E5 12 38 B0         [24] 1302 	lcall	_ak820_outline_0146
      0047E8 E9               [12] 1303 	mov	a,r1
      0047E9 F0               [24] 1304 	movx	@dptr,a
      0047EA 90 05 FA         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0047ED 74 01            [12] 1306 	mov	a,#0x01
      0047EF 2A               [12] 1307 	add	a, r2
      0047F0 F0               [24] 1308 	movx	@dptr,a
      0047F1 E4               [12] 1309 	clr	a
      0047F2 3B               [12] 1310 	addc	a, r3
      0047F3 A3               [24] 1311 	inc	dptr
      0047F4 F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0047F5 0E               [12] 1314 	inc	r6
      0047F6 BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      0047F9 0F               [12] 1316 	inc	r7
      0047FA 80 96            [24] 1317 	sjmp	00103$
      0047FC                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0047FC 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      0047FD                       1336 _ak820_eeprom_write_block_xdata:
      0047FD 12 38 86         [24] 1337 	lcall	_ak820_outline_0114
      004800 90 06 01         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004803 12 38 8B         [24] 1339 	lcall	_ak820_outline_0115
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004806 90 05 FC         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004809 12 38 39         [24] 1342 	lcall	_ak820_outline_0057
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      00480C 90 06 01         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00480F 12 38 50         [24] 1345 	lcall	_ak820_outline_0065
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004812 8E 02            [24] 1347 	mov	ar2,r6
      004814 8F 03            [24] 1348 	mov	ar3,r7
      004816 C3               [12] 1349 	clr	c
      004817 E4               [12] 1350 	clr	a
      004818 9A               [12] 1351 	subb	a,r2
      004819 74 28            [12] 1352 	mov	a,#0x28
      00481B 9B               [12] 1353 	subb	a,r3
      00481C 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      00481E E4               [12] 1356 	clr	a
      00481F C3               [12] 1357 	clr	c
      004820 9E               [12] 1358 	subb	a,r6
      004821 FA               [12] 1359 	mov	r2,a
      004822 74 28            [12] 1360 	mov	a,#0x28
      004824 9F               [12] 1361 	subb	a,r7
      004825 FB               [12] 1362 	mov	r3,a
      004826 90 05 FF         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004829 12 38 80         [24] 1364 	lcall	_ak820_outline_0110
      00482C C3               [12] 1365 	clr	c
      00482D EA               [12] 1366 	mov	a,r2
      00482E 98               [12] 1367 	subb	a,r0
      00482F EB               [12] 1368 	mov	a,r3
      004830 99               [12] 1369 	subb	a,r1
      004831 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      004833                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004833 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004836 02 42 46         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004839                       1378 00125$:
      004839 90 05 FF         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00483C 12 4A 18         [24] 1380 	lcall	_ak820_outline_0132
      00483F                       1381 00108$:
      00483F 8A 00            [24] 1382 	mov	ar0,r2
      004841 8B 01            [24] 1383 	mov	ar1,r3
      004843 1A               [12] 1384 	dec	r2
      004844 BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      004847 1B               [12] 1386 	dec	r3
      004848                       1387 00159$:
      004848 E8               [12] 1388 	mov	a,r0
      004849 49               [12] 1389 	orl	a,r1
      00484A 70 03            [24] 1390 	jnz	00160$
      00484C 02 48 D6         [24] 1391 	ljmp	00110$
      00484F                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00484F C0 02            [24] 1394 	push	ar2
      004851 C0 03            [24] 1395 	push	ar3
      004853 12 4A 06         [24] 1396 	lcall	_ak820_outline_0084
      004856 F9               [12] 1397 	mov	r1,a
      004857 A3               [24] 1398 	inc	dptr
      004858 12 4A 2F         [24] 1399 	lcall	_ak820_outline_0160
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00485B 8E 27            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00485D 8F 28            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00485F A8 27            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004861 E5 28            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004863 A2 E7            [12] 1405 	mov	c,acc.7
      004865 C8               [12] 1406 	xch	a,r0
      004866 33               [12] 1407 	rlc	a
      004867 C8               [12] 1408 	xch	a,r0
      004868 33               [12] 1409 	rlc	a
      004869 A2 E7            [12] 1410 	mov	c,acc.7
      00486B C8               [12] 1411 	xch	a,r0
      00486C 33               [12] 1412 	rlc	a
      00486D C8               [12] 1413 	xch	a,r0
      00486E 33               [12] 1414 	rlc	a
      00486F C8               [12] 1415 	xch	a,r0
      004870 54 03            [12] 1416 	anl	a,#0x03
      004872 FB               [12] 1417 	mov	r3,a
      004873 88 82            [24] 1418 	mov	dpl, r0
      004875 C0 07            [24] 1419 	push	ar7
      004877 C0 06            [24] 1420 	push	ar6
      004879 C0 05            [24] 1421 	push	ar5
      00487B C0 04            [24] 1422 	push	ar4
      00487D C0 03            [24] 1423 	push	ar3
      00487F C0 02            [24] 1424 	push	ar2
      004881 C0 01            [24] 1425 	push	ar1
      004883 12 46 6B         [24] 1426 	lcall	_load_page
      004886 E5 82            [12] 1427 	mov	a, dpl
      004888 D0 01            [24] 1428 	pop	ar1
      00488A D0 02            [24] 1429 	pop	ar2
      00488C D0 03            [24] 1430 	pop	ar3
      00488E D0 04            [24] 1431 	pop	ar4
      004890 D0 05            [24] 1432 	pop	ar5
      004892 D0 06            [24] 1433 	pop	ar6
      004894 D0 07            [24] 1434 	pop	ar7
      004896 D0 03            [24] 1435 	pop	ar3
      004898 D0 02            [24] 1436 	pop	ar2
      00489A 70 01            [24] 1437 	jnz	00105$
      00489C 22               [24] 1438 	ret
      00489D                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      00489D C0 06            [24] 1441 	push	ar6
      00489F C0 07            [24] 1442 	push	ar7
      0048A1 74 3F            [12] 1443 	mov	a,#0x3f
      0048A3 55 27            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0048A5 7F 00            [12] 1445 	mov	r7,#0x00
      0048A7 24 8B            [12] 1446 	add	a, #_page_data
      0048A9 F5 27            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0048AB EF               [12] 1448 	mov	a,r7
      0048AC 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      0048AE F5 28            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0048B0 85 27 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0048B3 85 28 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0048B6 E0               [24] 1453 	movx	a,@dptr
      0048B7 B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      0048BA D0 07            [24] 1455 	pop	ar7
      0048BC D0 06            [24] 1456 	pop	ar6
      0048BE 80 0E            [24] 1457 	sjmp	00107$
      0048C0                       1458 00162$:
      0048C0 D0 07            [24] 1459 	pop	ar7
      0048C2 D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0048C4 85 27 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0048C7 85 28 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0048CA E9               [12] 1464 	mov	a,r1
      0048CB F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      0048CC D2 0D            [12] 1468 	setb	_page_dirty
      0048CE                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0048CE 0E               [12] 1471 	inc	r6
      0048CF BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      0048D2 0F               [12] 1473 	inc	r7
      0048D3                       1474 00163$:
      0048D3 02 48 3F         [24] 1475 	ljmp	00108$
      0048D6                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0048D6 90 05 CC         [24] 1478 	mov	dptr,#_batch_depth
      0048D9 E0               [24] 1479 	movx	a,@dptr
      0048DA 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0048DC 02 44 EB         [24] 1482 	ljmp	_ak820_nvm_flush
      0048DF                       1483 00113$:
      0048DF 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      0048E0                       1502 _ak820_eeprom_update_block_xdata:
      0048E0 12 38 86         [24] 1503 	lcall	_ak820_outline_0114
      0048E3 90 06 08         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0048E6 12 38 8B         [24] 1505 	lcall	_ak820_outline_0115
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0048E9 90 06 08         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0048EC 12 38 39         [24] 1508 	lcall	_ak820_outline_0057
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0048EF 90 06 03         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0048F2 E0               [24] 1511 	movx	a,@dptr
      0048F3 F5 2D            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0048F5 A3               [24] 1513 	inc	dptr
      0048F6 E0               [24] 1514 	movx	a,@dptr
      0048F7 F5 2E            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0048F9 A3               [24] 1516 	inc	dptr
      0048FA E0               [24] 1517 	movx	a,@dptr
      0048FB F5 2F            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0048FD A9 2D            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0048FF AA 2E            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004901 E4               [12] 1522 	clr	a
      004902 F5 29            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004904 F5 2A            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004906                       1525 00105$:
      004906 90 06 06         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004909 E0               [24] 1527 	movx	a,@dptr
      00490A F5 2B            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      00490C A3               [24] 1529 	inc	dptr
      00490D E0               [24] 1530 	movx	a,@dptr
      00490E F5 2C            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004910 C3               [12] 1532 	clr	c
      004911 E5 29            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004913 95 2B            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004915 E5 2A            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004917 95 2C            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004919 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      00491B 89 00            [24] 1539 	mov	ar0,r1
      00491D 8A 05            [24] 1540 	mov	ar5,r2
      00491F E5 29            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004921 28               [12] 1542 	add	a, r0
      004922 F8               [12] 1543 	mov	r0,a
      004923 E5 2A            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004925 3D               [12] 1545 	addc	a, r5
      004926 FD               [12] 1546 	mov	r5,a
      004927 88 82            [24] 1547 	mov	dpl, r0
      004929 8D 83            [24] 1548 	mov	dph, r5
      00492B C0 07            [24] 1549 	push	ar7
      00492D C0 06            [24] 1550 	push	ar6
      00492F C0 02            [24] 1551 	push	ar2
      004931 C0 01            [24] 1552 	push	ar1
      004933 12 46 DD         [24] 1553 	lcall	_read_offset
      004936 AD 82            [24] 1554 	mov	r5, dpl
      004938 D0 01            [24] 1555 	pop	ar1
      00493A D0 02            [24] 1556 	pop	ar2
      00493C D0 06            [24] 1557 	pop	ar6
      00493E D0 07            [24] 1558 	pop	ar7
      004940 E5 29            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004942 2E               [12] 1560 	add	a, r6
      004943 F5 82            [12] 1561 	mov	dpl,a
      004945 E5 2A            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004947 3F               [12] 1563 	addc	a, r7
      004948 F5 83            [12] 1564 	mov	dph,a
      00494A E0               [24] 1565 	movx	a,@dptr
      00494B FC               [12] 1566 	mov	r4,a
      00494C ED               [12] 1567 	mov	a,r5
      00494D B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      004950 80 27            [24] 1569 	sjmp	00106$
      004952                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004952 90 06 08         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004955 E0               [24] 1573 	movx	a,@dptr
      004956 F8               [12] 1574 	mov	r0,a
      004957 A3               [24] 1575 	inc	dptr
      004958 E0               [24] 1576 	movx	a,@dptr
      004959 FD               [12] 1577 	mov	r5,a
      00495A 90 05 FC         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00495D E5 2D            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00495F F0               [24] 1580 	movx	@dptr,a
      004960 E5 2E            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004962 A3               [24] 1582 	inc	dptr
      004963 F0               [24] 1583 	movx	@dptr,a
      004964 E5 2F            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004966 A3               [24] 1585 	inc	dptr
      004967 F0               [24] 1586 	movx	@dptr,a
      004968 90 05 FF         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00496B E5 2B            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00496D F0               [24] 1589 	movx	@dptr,a
      00496E E5 2C            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004970 A3               [24] 1591 	inc	dptr
      004971 F0               [24] 1592 	movx	@dptr,a
      004972 88 82            [24] 1593 	mov	dpl, r0
      004974 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004976 02 47 FD         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      004979                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004979 05 29            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      00497B E4               [12] 1600 	clr	a
      00497C B5 29 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00497F 05 2A            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004981 80 83            [24] 1603 	sjmp	00105$
      004983                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004983 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      004984                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      004984 12 44 EB         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004987 7F 00            [12] 1621 	mov	r7,#0x00
      004989                       1622 00111$:
      004989 BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      00498C 22               [24] 1624 	ret
      00498D                       1625 00165$:
      00498D 20 0E 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004990 8F 82            [24] 1628 	mov	dpl, r7
      004992 C0 07            [24] 1629 	push	ar7
      004994 12 46 6B         [24] 1630 	lcall	_load_page
      004997 E5 82            [12] 1631 	mov	a, dpl
      004999 D0 07            [24] 1632 	pop	ar7
      00499B 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00499D 22               [24] 1635 	ret
      00499E                       1636 00126$:
      00499E 7E 00            [12] 1637 	mov	r6,#0x00
      0049A0                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0049A0 EE               [12] 1640 	mov	a,r6
      0049A1 24 8B            [12] 1641 	add	a, #_page_data
      0049A3 FC               [12] 1642 	mov	r4,a
      0049A4 E4               [12] 1643 	clr	a
      0049A5 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      0049A7 FD               [12] 1645 	mov	r5,a
      0049A8 12 4A 06         [24] 1646 	lcall	_ak820_outline_0084
      0049AB 60 07            [24] 1647 	jz	00108$
      0049AD 12 38 A1         [24] 1648 	lcall	_ak820_outline_0134
      0049B0 E4               [12] 1649 	clr	a
      0049B1 F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      0049B2 D2 0D            [12] 1652 	setb	_page_dirty
      0049B4                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0049B4 0E               [12] 1655 	inc	r6
      0049B5 BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0049B8 C0 07            [24] 1658 	push	ar7
      0049BA 12 44 EB         [24] 1659 	lcall	_ak820_nvm_flush
      0049BD D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0049BF 0F               [12] 1662 	inc	r7
      0049C0 80 C7            [24] 1663 	sjmp	00111$
      0049C2                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0049C2 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0006
                                   1674 	.globl _ak820_outline_0012
                                   1675 	.globl _ak820_outline_0016
                                   1676 	.globl _ak820_outline_0022
                                   1677 	.globl _ak820_outline_0027
                                   1678 	.globl _ak820_outline_0041
                                   1679 	.globl _ak820_outline_0049
                                   1680 	.globl _ak820_outline_0057
                                   1681 	.globl _ak820_outline_0058
                                   1682 	.globl _ak820_outline_0065
                                   1683 	.globl _ak820_outline_0068
                                   1684 	.globl _ak820_outline_0070
                                   1685 	.globl _ak820_outline_0079
                                   1686 	.globl _ak820_outline_0084
                                   1687 	.globl _ak820_outline_0085
                                   1688 	.globl _ak820_outline_0090
                                   1689 	.globl _ak820_outline_0110
                                   1690 	.globl _ak820_outline_0112
                                   1691 	.globl _ak820_outline_0114
                                   1692 	.globl _ak820_outline_0115
                                   1693 	.globl _ak820_outline_0126
                                   1694 	.globl _ak820_outline_0129
                                   1695 	.globl _ak820_outline_0132
                                   1696 	.globl _ak820_outline_0133
                                   1697 	.globl _ak820_outline_0134
                                   1698 	.globl _ak820_outline_0144
                                   1699 	.globl _ak820_outline_0145
                                   1700 	.globl _ak820_outline_0146
                                   1701 	.globl _ak820_outline_0148
                                   1702 	.globl _ak820_outline_0153
                                   1703 	.globl _ak820_outline_0154
                                   1704 	.globl _ak820_outline_0160
                                   1705 	.globl _ak820_outline_0168
                                   1706 	.globl _ak820_outline_0169
                                   1707 	.globl _ak820_outline_0172
                                   1708 	.globl _ak820_outline_0173
                                   1709 	.globl _ak820_outline_0193
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0012
      0049C3                       1713 _ak820_outline_0012:
      0049C3 8E 82            [24] 1714 	mov	dpl,r6
      0049C5 8F 83            [24] 1715 	mov	dph,r7
      0049C7 A3               [24] 1716 	inc	dptr
      0049C8 A3               [24] 1717 	inc	dptr
      0049C9 A3               [24] 1718 	inc	dptr
      0049CA A3               [24] 1719 	inc	dptr
      0049CB A3               [24] 1720 	inc	dptr
      0049CC 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0027
      0049CD                       1725 _ak820_outline_0027:
      0049CD F0               [24] 1726 	movx	@dptr,a
      0049CE 8E 82            [24] 1727 	mov	dpl,r6
      0049D0 8F 83            [24] 1728 	mov	dph,r7
      0049D2 A3               [24] 1729 	inc	dptr
      0049D3 A3               [24] 1730 	inc	dptr
      0049D4 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0041
      0049D5                       1735 _ak820_outline_0041:
      0049D5 AF F0            [24] 1736 	mov	r7,b
      0049D7 AE 83            [24] 1737 	mov	r6,dph
      0049D9 E5 82            [12] 1738 	mov	a,dpl
      0049DB 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0049
      0049DC                       1743 _ak820_outline_0049:
      0049DC EF               [12] 1744 	mov	a,r7
      0049DD 24 E3            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      0049DF F5 82            [12] 1746 	mov	dpl,a
      0049E1 E4               [12] 1747 	clr	a
      0049E2 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0049E4 F5 83            [12] 1749 	mov	dph,a
      0049E6 E0               [24] 1750 	movx	a,@dptr
      0049E7 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0058
      0049E8                       1755 _ak820_outline_0058:
      0049E8 8F 06            [24] 1756 	mov	ar6,r7
      0049EA 7D 00            [12] 1757 	mov	r5,#0x00
      0049EC 74 40            [12] 1758 	mov	a,#0x40
      0049EE 2E               [12] 1759 	add	a,r6
      0049EF FE               [12] 1760 	mov	r6,a
      0049F0 74 EF            [12] 1761 	mov	a,#0xef
      0049F2 3D               [12] 1762 	addc	a,r5
      0049F3 FD               [12] 1763 	mov	r5,a
      0049F4 8E 82            [24] 1764 	mov	dpl,r6
      0049F6 8D 83            [24] 1765 	mov	dph,r5
      0049F8 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0068
      0049F9                       1770 _ak820_outline_0068:
      0049F9 8D 82            [24] 1771 	mov	dpl,r5
      0049FB 8E 83            [24] 1772 	mov	dph,r6
      0049FD EC               [12] 1773 	mov	a,r4
      0049FE F0               [24] 1774 	movx	@dptr,a
      0049FF 22               [24] 1775 	ret
                                   1776 
                                   1777 	.area CSEG (CODE)
                                   1778 ; function ak820_outline_0070
      004A00                       1779 _ak820_outline_0070:
      004A00 F0               [24] 1780 	movx	@dptr,a
      004A01 8E 82            [24] 1781 	mov	dpl,r6
      004A03 8F 83            [24] 1782 	mov	dph,r7
      004A05 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0084
      004A06                       1787 _ak820_outline_0084:
      004A06 8C 82            [24] 1788 	mov	dpl,r4
      004A08 8D 83            [24] 1789 	mov	dph,r5
      004A0A E0               [24] 1790 	movx	a,@dptr
      004A0B 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0112
      004A0C                       1795 _ak820_outline_0112:
      004A0C EF               [12] 1796 	mov	a,r7
      004A0D 24 8B            [12] 1797 	add	a,#_page_data
      004A0F F5 82            [12] 1798 	mov	dpl,a
      004A11 E4               [12] 1799 	clr	a
      004A12 34 05            [12] 1800 	addc	a,#(_page_data>>8)
      004A14 F5 83            [12] 1801 	mov	dph,a
      004A16 E0               [24] 1802 	movx	a,@dptr
      004A17 22               [24] 1803 	ret
                                   1804 
                                   1805 	.area CSEG (CODE)
                                   1806 ; function ak820_outline_0132
      004A18                       1807 _ak820_outline_0132:
      004A18 E0               [24] 1808 	movx	a,@dptr
      004A19 FA               [12] 1809 	mov	r2,a
      004A1A A3               [24] 1810 	inc	dptr
      004A1B E0               [24] 1811 	movx	a,@dptr
      004A1C FB               [12] 1812 	mov	r3,a
      004A1D 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0144
      004A1E                       1817 _ak820_outline_0144:
      004A1E AE 82            [24] 1818 	mov	r6,dpl
      004A20 AF 83            [24] 1819 	mov	r7,dph
      004A22 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0148
      004A23                       1824 _ak820_outline_0148:
      004A23 2E               [12] 1825 	add	a,r6
      004A24 FE               [12] 1826 	mov	r6,a
      004A25 E4               [12] 1827 	clr	a
      004A26 3F               [12] 1828 	addc	a,r7
      004A27 FF               [12] 1829 	mov	r7,a
      004A28 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0153
      004A29                       1834 _ak820_outline_0153:
      004A29 42 05            [12] 1835 	orl	ar5,a
      004A2B EA               [12] 1836 	mov	a,r2
      004A2C 42 04            [12] 1837 	orl	ar4,a
      004A2E 22               [24] 1838 	ret
                                   1839 
                                   1840 	.area CSEG (CODE)
                                   1841 ; function ak820_outline_0160
      004A2F                       1842 _ak820_outline_0160:
      004A2F AC 82            [24] 1843 	mov	r4,dpl
      004A31 AD 83            [24] 1844 	mov	r5,dph
      004A33 22               [24] 1845 	ret
                                   1846 
                                   1847 	.area CSEG (CODE)
                                   1848 ; function ak820_outline_0168
      004A34                       1849 _ak820_outline_0168:
      004A34 89 82            [24] 1850 	mov	dpl,r1
      004A36 8A 83            [24] 1851 	mov	dph,r2
      004A38 22               [24] 1852 	ret
                                   1853 
                                   1854 	.area CSEG (CODE)
                                   1855 ; function ak820_outline_0169
      004A39                       1856 _ak820_outline_0169:
      004A39 8F 82            [24] 1857 	mov	dpl,r7
      004A3B 8E 83            [24] 1858 	mov	dph,r6
      004A3D 22               [24] 1859 	ret
                                   1860 
                                   1861 	.area CSEG (CODE)
                                   1862 ; function ak820_outline_0172
      004A3E                       1863 _ak820_outline_0172:
      004A3E 2E               [12] 1864 	add	a,r6
      004A3F FC               [12] 1865 	mov	r4,a
      004A40 E4               [12] 1866 	clr	a
      004A41 3F               [12] 1867 	addc	a,r7
      004A42 FD               [12] 1868 	mov	r5,a
      004A43 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0173
      004A44                       1873 _ak820_outline_0173:
      004A44 ED               [12] 1874 	mov	a,r5
      004A45 F0               [24] 1875 	movx	@dptr,a
      004A46 EE               [12] 1876 	mov	a,r6
      004A47 A3               [24] 1877 	inc	dptr
      004A48 F0               [24] 1878 	movx	@dptr,a
      004A49 22               [24] 1879 	ret
                                   1880 
                                   1881 	.area CSEG (CODE)
                                   1882 ; function ak820_outline_0193
      004A4A                       1883 _ak820_outline_0193:
      004A4A 8C 82            [24] 1884 	mov	dpl,r4
      004A4C 8B 83            [24] 1885 	mov	dph,r3
      004A4E 22               [24] 1886 	ret
