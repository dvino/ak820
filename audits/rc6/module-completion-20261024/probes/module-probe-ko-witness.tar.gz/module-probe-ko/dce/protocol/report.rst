                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _biton
                                     12 	.globl _memset
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _del_key_from_report_PARM_2
                                    257 	.globl _add_key_to_report_PARM_2
                                    258 	.globl _del_key_bit_PARM_2
                                    259 	.globl _add_key_bit_PARM_2
                                    260 	.globl _del_key_byte_PARM_2
                                    261 	.globl _add_key_byte_PARM_2
                                    262 	.globl _KEYCODE2CONSUMER
                                    263 	.globl _add_key_byte
                                    264 	.globl _del_key_byte
                                    265 	.globl _add_key_bit
                                    266 	.globl _del_key_bit
                                    267 	.globl _add_key_to_report
                                    268 	.globl _del_key_from_report
                                    269 	.globl _clear_keys_from_report
                                    270 ;--------------------------------------------------------
                                    271 ; special function registers
                                    272 ;--------------------------------------------------------
                                    273 	.area RSEG    (ABS,DATA)
      000000                        274 	.org 0x0000
                           0000D0   275 _PSW	=	0x00d0
                           0000E0   276 _ACC	=	0x00e0
                           0000F0   277 _B	=	0x00f0
                           0000FD   278 _A_INV	=	0x00fd
                           000081   279 _SP	=	0x0081
                           000082   280 _DPL	=	0x0082
                           000083   281 _DPH	=	0x0083
                           0000A1   282 _SAFE_MOD	=	0x00a1
                           0000B1   283 _GLOBAL_CFG	=	0x00b1
                           000087   284 _PCON	=	0x0087
                           0000BA   285 _POWER_CFG	=	0x00ba
                           0000B9   286 _CLOCK_CFG	=	0x00b9
                           0000A9   287 _WAKE_CTRL	=	0x00a9
                           0000FE   288 _RESET_KEEP	=	0x00fe
                           0000FF   289 _WDOG_COUNT	=	0x00ff
                           0000A8   290 _IE	=	0x00a8
                           0000B8   291 _IP	=	0x00b8
                           0000E8   292 _IE_EX	=	0x00e8
                           0000E9   293 _IP_EX	=	0x00e9
                           0000B2   294 _GPIO_IE	=	0x00b2
                           008584   295 _ROM_ADDR	=	0x8584
                           000084   296 _ROM_ADDR_L	=	0x0084
                           000085   297 _ROM_ADDR_H	=	0x0085
                           008F8E   298 _ROM_DATA_HI	=	0x8f8e
                           00008E   299 _ROM_DATA_HL	=	0x008e
                           00008F   300 _ROM_DATA_HH	=	0x008f
                           000086   301 _ROM_CTRL	=	0x0086
                           000080   302 _P0	=	0x0080
                           0000C4   303 _P0_MOD_OC	=	0x00c4
                           0000C5   304 _P0_DIR_PU	=	0x00c5
                           000090   305 _P1	=	0x0090
                           000092   306 _P1_MOD_OC	=	0x0092
                           000093   307 _P1_DIR_PU	=	0x0093
                           0000A0   308 _P2	=	0x00a0
                           000094   309 _P2_MOD_OC	=	0x0094
                           000095   310 _P2_DIR_PU	=	0x0095
                           0000B0   311 _P3	=	0x00b0
                           000096   312 _P3_MOD_OC	=	0x0096
                           000097   313 _P3_DIR_PU	=	0x0097
                           0000C0   314 _P4	=	0x00c0
                           0000C2   315 _P4_MOD_OC	=	0x00c2
                           0000C3   316 _P4_DIR_PU	=	0x00c3
                           0000C1   317 _P4_LED_KEY	=	0x00c1
                           0000AA   318 _P5_IN	=	0x00aa
                           0000AB   319 _P5_OUT_PU	=	0x00ab
                           0000AC   320 _P5_DIR	=	0x00ac
                           0000AD   321 _P6_IN	=	0x00ad
                           0000AE   322 _P6_OUT_PU	=	0x00ae
                           0000AF   323 _P6_DIR	=	0x00af
                           0000F1   324 _P7	=	0x00f1
                           0000A2   325 _XBUS_AUX	=	0x00a2
                           000088   326 _TCON	=	0x0088
                           000089   327 _TMOD	=	0x0089
                           00008A   328 _TL0	=	0x008a
                           00008B   329 _TL1	=	0x008b
                           00008C   330 _TH0	=	0x008c
                           00008D   331 _TH1	=	0x008d
                           000098   332 _SCON	=	0x0098
                           000099   333 _SBUF	=	0x0099
                           0000C8   334 _T2CON	=	0x00c8
                           0000C9   335 _T2MOD	=	0x00c9
                           00CBCA   336 _RCAP2	=	0xcbca
                           0000CA   337 _RCAP2L	=	0x00ca
                           0000CB   338 _RCAP2H	=	0x00cb
                           00CDCC   339 _T2COUNT	=	0xcdcc
                           0000CC   340 _TL2	=	0x00cc
                           0000CD   341 _TH2	=	0x00cd
                           00CFCE   342 _T2CAP1	=	0xcfce
                           0000CE   343 _T2CAP1L	=	0x00ce
                           0000CF   344 _T2CAP1H	=	0x00cf
                           0000F8   345 _SPI0_STAT	=	0x00f8
                           0000F9   346 _SPI0_DATA	=	0x00f9
                           0000FA   347 _SPI0_CTRL	=	0x00fa
                           0000FB   348 _SPI0_CK_SE	=	0x00fb
                           0000FC   349 _SPI0_SETUP	=	0x00fc
                           0000BC   350 _SCON1	=	0x00bc
                           0000BD   351 _SBUF1	=	0x00bd
                           0000BE   352 _SBAUD1	=	0x00be
                           0000BF   353 _SIF1	=	0x00bf
                           0000B4   354 _SPI1_STAT	=	0x00b4
                           0000B5   355 _SPI1_DATA	=	0x00b5
                           0000B6   356 _SPI1_CTRL	=	0x00b6
                           0000B7   357 _SPI1_CK_SE	=	0x00b7
                           0000F3   358 _ADC_CTRL	=	0x00f3
                           00F5F4   359 _ADC_DAT	=	0xf5f4
                           0000F4   360 _ADC_DAT_L	=	0x00f4
                           0000F5   361 _ADC_DAT_H	=	0x00f5
                           0000F6   362 _ADC_CHAN	=	0x00f6
                           0000A6   363 _LED_COMMON	=	0x00a6
                           0000A7   364 _LED_PWM_OE	=	0x00a7
                           00C7C6   365 _LED_DMA	=	0xc7c6
                           0000C6   366 _LED_DMA_L	=	0x00c6
                           0000C7   367 _LED_DMA_H	=	0x00c7
                           0000F7   368 _LED_STATUS	=	0x00f7
                           0000B3   369 _I2CX_INT	=	0x00b3
                           0000BB   370 _I2CS_INT_ST	=	0x00bb
                                    371 ;--------------------------------------------------------
                                    372 ; special function bits
                                    373 ;--------------------------------------------------------
                                    374 	.area RSEG    (ABS,DATA)
      000000                        375 	.org 0x0000
                           0000D7   376 _CY	=	0x00d7
                           0000D6   377 _AC	=	0x00d6
                           0000D5   378 _F0	=	0x00d5
                           0000D4   379 _RS1	=	0x00d4
                           0000D3   380 _RS0	=	0x00d3
                           0000D2   381 _OV	=	0x00d2
                           0000D1   382 _F1	=	0x00d1
                           0000D0   383 _P	=	0x00d0
                           0000AF   384 _EA	=	0x00af
                           0000AE   385 _E_DIS	=	0x00ae
                           0000AD   386 _ET2	=	0x00ad
                           0000AC   387 _ES	=	0x00ac
                           0000AB   388 _ET1	=	0x00ab
                           0000AA   389 _EX1	=	0x00aa
                           0000A9   390 _ET0	=	0x00a9
                           0000A8   391 _EX0	=	0x00a8
                           0000BF   392 _PH_FLAG	=	0x00bf
                           0000BE   393 _PL_FLAG	=	0x00be
                           0000BD   394 _PT2	=	0x00bd
                           0000BC   395 _PS	=	0x00bc
                           0000BB   396 _PT1	=	0x00bb
                           0000BA   397 _PX1	=	0x00ba
                           0000B9   398 _PT0	=	0x00b9
                           0000B8   399 _PX0	=	0x00b8
                           0000EF   400 _IE_WDOG	=	0x00ef
                           0000EE   401 _IE_GPIO	=	0x00ee
                           0000ED   402 _IE_PWM_I2C	=	0x00ed
                           0000EC   403 _IE_UART1	=	0x00ec
                           0000EB   404 _IE_ADC	=	0x00eb
                           0000E9   405 _IE_USB	=	0x00e9
                           0000E8   406 _IE_SPI0	=	0x00e8
                           000087   407 _P0_7	=	0x0087
                           000086   408 _P0_6	=	0x0086
                           000085   409 _P0_5	=	0x0085
                           000084   410 _P0_4	=	0x0084
                           000083   411 _P0_3	=	0x0083
                           000082   412 _P0_2	=	0x0082
                           000081   413 _P0_1	=	0x0081
                           000080   414 _P0_0	=	0x0080
                           000081   415 _SDA0	=	0x0081
                           000080   416 _SCL0	=	0x0080
                           000083   417 _TXD_	=	0x0083
                           000082   418 _RXD_	=	0x0082
                           000085   419 _AIN13	=	0x0085
                           000084   420 _AIN12	=	0x0084
                           000083   421 _AIN11	=	0x0083
                           000082   422 _AIN10	=	0x0082
                           000081   423 _AIN9	=	0x0081
                           000080   424 _AIN8	=	0x0080
                           000097   425 _P1_7	=	0x0097
                           000096   426 _P1_6	=	0x0096
                           000095   427 _P1_5	=	0x0095
                           000094   428 _P1_4	=	0x0094
                           000093   429 _P1_3	=	0x0093
                           000092   430 _P1_2	=	0x0092
                           000091   431 _P1_1	=	0x0091
                           000090   432 _P1_0	=	0x0090
                           000097   433 _TXD1_	=	0x0097
                           000096   434 _RXD1_	=	0x0096
                           000097   435 _SCK	=	0x0097
                           000096   436 _MISO	=	0x0096
                           000095   437 _MOSI	=	0x0095
                           000094   438 _SCS	=	0x0094
                           000092   439 _INT0_	=	0x0092
                           000091   440 _T2EX	=	0x0091
                           000091   441 _CAP2	=	0x0091
                           000090   442 _T2	=	0x0090
                           000090   443 _CAP1	=	0x0090
                           000097   444 _AIN7	=	0x0097
                           000096   445 _AIN6	=	0x0096
                           000095   446 _AIN5	=	0x0095
                           000094   447 _AIN4	=	0x0094
                           000093   448 _AIN3	=	0x0093
                           000092   449 _AIN2	=	0x0092
                           000091   450 _AIN1	=	0x0091
                           000090   451 _AIN0	=	0x0090
                           0000A7   452 _P2_7	=	0x00a7
                           0000A6   453 _P2_6	=	0x00a6
                           0000A5   454 _P2_5	=	0x00a5
                           0000A4   455 _P2_4	=	0x00a4
                           0000A3   456 _P2_3	=	0x00a3
                           0000A2   457 _P2_2	=	0x00a2
                           0000A1   458 _P2_1	=	0x00a1
                           0000A0   459 _P2_0	=	0x00a0
                           0000A7   460 _TXD1	=	0x00a7
                           0000A6   461 _RXD1	=	0x00a6
                           0000A5   462 _T2EX_	=	0x00a5
                           0000A5   463 _CAP2_	=	0x00a5
                           0000A4   464 _T2_	=	0x00a4
                           0000A4   465 _CAP1_	=	0x00a4
                           0000B7   466 _P3_7	=	0x00b7
                           0000B6   467 _P3_6	=	0x00b6
                           0000B5   468 _P3_5	=	0x00b5
                           0000B4   469 _P3_4	=	0x00b4
                           0000B3   470 _P3_3	=	0x00b3
                           0000B2   471 _P3_2	=	0x00b2
                           0000B1   472 _P3_1	=	0x00b1
                           0000B0   473 _P3_0	=	0x00b0
                           0000B7   474 _SCK1	=	0x00b7
                           0000B6   475 _MISO1	=	0x00b6
                           0000B5   476 _MOSI1	=	0x00b5
                           0000B5   477 _T1	=	0x00b5
                           0000B4   478 _T0	=	0x00b4
                           0000B3   479 _INT1	=	0x00b3
                           0000B2   480 _INT0	=	0x00b2
                           0000B1   481 _TXD	=	0x00b1
                           0000B0   482 _RXD	=	0x00b0
                           0000C6   483 _P4_6	=	0x00c6
                           0000C5   484 _P4_5	=	0x00c5
                           0000C4   485 _P4_4	=	0x00c4
                           0000C3   486 _P4_3	=	0x00c3
                           0000C2   487 _P4_2	=	0x00c2
                           0000C1   488 _P4_1	=	0x00c1
                           0000C0   489 _P4_0	=	0x00c0
                           00008F   490 _TF1	=	0x008f
                           00008E   491 _TR1	=	0x008e
                           00008D   492 _TF0	=	0x008d
                           00008C   493 _TR0	=	0x008c
                           00008B   494 _IE1	=	0x008b
                           00008A   495 _IT1	=	0x008a
                           000089   496 _IE0	=	0x0089
                           000088   497 _IT0	=	0x0088
                           00009F   498 _SM0	=	0x009f
                           00009E   499 _SM1	=	0x009e
                           00009D   500 _SM2	=	0x009d
                           00009C   501 _REN	=	0x009c
                           00009B   502 _TB8	=	0x009b
                           00009A   503 _RB8	=	0x009a
                           000099   504 _TI	=	0x0099
                           000098   505 _RI	=	0x0098
                           0000CF   506 _TF2	=	0x00cf
                           0000CF   507 _CAP1F	=	0x00cf
                           0000CE   508 _EXF2	=	0x00ce
                           0000CD   509 _RCLK	=	0x00cd
                           0000CC   510 _TCLK	=	0x00cc
                           0000CB   511 _EXEN2	=	0x00cb
                           0000CA   512 _TR2	=	0x00ca
                           0000C9   513 _C_T2	=	0x00c9
                           0000C8   514 _CP_RL2	=	0x00c8
                           0000FF   515 _S0_FST_ACT	=	0x00ff
                           0000FE   516 _S0_IF_OV	=	0x00fe
                           0000FD   517 _S0_IF_FIRST	=	0x00fd
                           0000FC   518 _S0_IF_BYTE	=	0x00fc
                           0000FB   519 _S0_FREE	=	0x00fb
                           0000FA   520 _S0_T_FIFO	=	0x00fa
                           0000F8   521 _S0_R_FIFO	=	0x00f8
                           0000F7   522 _ADC_START	=	0x00f7
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable register banks
                                    525 ;--------------------------------------------------------
                                    526 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        527 	.ds 8
                                    528 ;--------------------------------------------------------
                                    529 ; internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area DSEG    (DATA)
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable items in internal ram
                                    534 ;--------------------------------------------------------
                                    535 ;--------------------------------------------------------
                                    536 ; indirectly addressable internal ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area ISEG    (DATA)
                                    539 ;--------------------------------------------------------
                                    540 ; absolute internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area IABS    (ABS,DATA)
                                    543 	.area IABS    (ABS,DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; bit data
                                    546 ;--------------------------------------------------------
                                    547 	.area BSEG    (BIT)
                                    548 ;--------------------------------------------------------
                                    549 ; paged external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area PSEG    (PAG,XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; uninitialized external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XSEG    (XDATA)
      00085F                        556 _KEYCODE2CONSUMER_key_10000_117:
      00085F                        557 	.ds 1
      000860                        558 _add_key_byte_PARM_2:
      000860                        559 	.ds 1
      000861                        560 _add_key_byte_report_arg_10000_144:
      000861                        561 	.ds 2
      000863                        562 _add_key_byte_empty_10000_145:
      000863                        563 	.ds 1
      000864                        564 _del_key_byte_PARM_2:
      000864                        565 	.ds 1
      000865                        566 _del_key_byte_report_arg_10000_156:
      000865                        567 	.ds 2
      000867                        568 _add_key_bit_PARM_2:
      000867                        569 	.ds 1
      000868                        570 _add_key_bit_report_arg_10000_162:
      000868                        571 	.ds 2
      00086A                        572 _del_key_bit_PARM_2:
      00086A                        573 	.ds 1
      00086B                        574 _del_key_bit_report_arg_10000_167:
      00086B                        575 	.ds 2
      00086D                        576 _add_key_to_report_PARM_2:
      00086D                        577 	.ds 1
      00086E                        578 _add_key_to_report_report_arg_10000_172:
      00086E                        579 	.ds 2
      000870                        580 _del_key_from_report_PARM_2:
      000870                        581 	.ds 1
      000871                        582 _del_key_from_report_report_arg_10000_176:
      000871                        583 	.ds 2
      000873                        584 _clear_keys_from_report_report_arg_10000_180:
      000873                        585 	.ds 2
                                    586 ;--------------------------------------------------------
                                    587 ; absolute external ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area XABS    (ABS,XDATA)
                                    590 ;--------------------------------------------------------
                                    591 ; initialized external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XISEG   (XDATA)
                                    594 	.area HOME    (CODE)
                                    595 	.area GSINIT0 (CODE)
                                    596 	.area GSINIT1 (CODE)
                                    597 	.area GSINIT2 (CODE)
                                    598 	.area GSINIT3 (CODE)
                                    599 	.area GSINIT4 (CODE)
                                    600 	.area GSINIT5 (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.area GSFINAL (CODE)
                                    603 	.area CSEG    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; global & static initialisations
                                    606 ;--------------------------------------------------------
                                    607 	.area HOME    (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 	.area GSFINAL (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 ;--------------------------------------------------------
                                    612 ; Home
                                    613 ;--------------------------------------------------------
                                    614 	.area HOME    (CODE)
                                    615 	.area HOME    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; code
                                    618 ;--------------------------------------------------------
                                    619 	.area CSEG    (CODE)
                                    620 ;------------------------------------------------------------
                                    621 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    622 ;------------------------------------------------------------
                                    623 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    624 ;------------------------------------------------------------
                                    625 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    626 ;	-----------------------------------------
                           000007   627 	ar7 = 0x07
                           000006   628 	ar6 = 0x06
                           000005   629 	ar5 = 0x05
                           000004   630 	ar4 = 0x04
                           000003   631 	ar3 = 0x03
                           000002   632 	ar2 = 0x02
                           000001   633 	ar1 = 0x01
                           000000   634 	ar0 = 0x00
                                    635 ;	 function KEYCODE2CONSUMER
                                    636 ;	-----------------------------------------
      0073FD                        637 _KEYCODE2CONSUMER:
      0073FD E5 82            [12]  638 	mov	a,dpl
      0073FF 90 08 5F         [24]  639 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      007402 F0               [24]  640 	movx	@dptr,a
                                    641 ;	tmk_core/protocol/report.c:43: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      007403 E0               [24]  642 	movx	a,@dptr
      007404 FF               [12]  643 	mov	r7,a
      007405 BF A8 00         [24]  644 	cjne	r7,#0xa8,00113$
      007408                        645 00113$:
      007408 40 05            [24]  646 	jc	00101$
      00740A EF               [12]  647 	mov	a,r7
      00740B 24 3D            [12]  648 	add	a,#0xff - 0xc2
      00740D 50 04            [24]  649 	jnc	00102$
                                    650 ;	free result
      00740F                        651 00101$:
      00740F 90 00 00         [24]  652 	mov	dptr,#0x0000
      007412 22               [24]  653 	ret
      007413                        654 00102$:
                                    655 ;	tmk_core/protocol/report.c:44: return usages[key - KC_AUDIO_MUTE];
      007413 EF               [12]  656 	mov	a,r7
      007414 24 58            [12]  657 	add	a,#0x58
      007416 FF               [12]  658 	mov	r7,a
      007417 C2 D5            [12]  659 	clr	F0
      007419 75 F0 02         [24]  660 	mov	b,#0x02
      00741C EF               [12]  661 	mov	a,r7
      00741D 30 E7 04         [24]  662 	jnb	acc.7,00116$
      007420 B2 D5            [12]  663 	cpl	F0
      007422 F4               [12]  664 	cpl	a
      007423 04               [12]  665 	inc	a
      007424                        666 00116$:
      007424 A4               [48]  667 	mul	ab
      007425 30 D5 03         [24]  668 	jnb	F0,00117$
      007428 12 76 0B         [24]  669 	lcall	_ak820_outline_0140
      00742B                        670 00117$:
      00742B 24 EA            [12]  671 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      00742D F5 82            [12]  672 	mov	dpl,a
      00742F 74 C2            [12]  673 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      007431 12 5D A4         [24]  674 	lcall	_ak820_outline_0116
      007434 FE               [12]  675 	mov	r6,a
      007435 A3               [24]  676 	inc	dptr
      007436 E4               [12]  677 	clr	a
      007437 93               [24]  678 	movc	a,@a+dptr
                                    679 ;	tmk_core/protocol/report.c:45: }
      007438 8E 82            [24]  680 	mov	dpl,r6
      00743A F5 83            [12]  681 	mov	dph,a
      00743C 22               [24]  682 	ret
                                    683 ;------------------------------------------------------------
                                    684 ;Allocation info for local variables in function 'has_anykey'
                                    685 ;------------------------------------------------------------
                                    686 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    687 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    688 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    689 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    690 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.c:62: uint8_t has_anykey(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function add_key_byte
                                    695 ;	-----------------------------------------
      00743D                        696 _add_key_byte:
      00743D 12 38 86         [24]  697 	lcall	_ak820_outline_0114
      007440 90 08 61         [24]  698 	mov	dptr,#_add_key_byte_report_arg_10000_144
      007443 12 38 8B         [24]  699 	lcall	_ak820_outline_0115
                                    700 ;	tmk_core/protocol/report.c:139: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007446 90 08 61         [24]  701 	mov	dptr,#_add_key_byte_report_arg_10000_144
      007449 12 38 39         [24]  702 	lcall	_ak820_outline_0057
                                    703 ;	tmk_core/protocol/report.c:185: int8_t empty = -1;
      00744C 90 08 63         [24]  704 	mov	dptr,#_add_key_byte_empty_10000_145
      00744F 74 FF            [12]  705 	mov	a,#0xff
      007451 F0               [24]  706 	movx	@dptr,a
                                    707 ;	tmk_core/protocol/report.c:200: }
      007452 7D 00            [12]  708 	mov	r5,#0x00
      007454                        709 00112$:
                                    710 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      007454 C3               [12]  711 	clr	c
      007455 ED               [12]  712 	mov	a,r5
      007456 64 80            [12]  713 	xrl	a,#0x80
      007458 94 86            [12]  714 	subb	a,#0x86
      00745A 50 29            [24]  715 	jnc	00106$
                                    716 ;	tmk_core/protocol/report.c:187: if (keyboard_report->keys[i] == code) {
      00745C 12 76 16         [24]  717 	lcall	_ak820_outline_0156
      00745F F5 82            [12]  718 	mov	dpl,a
      007461 E4               [12]  719 	clr	a
      007462 3C               [12]  720 	addc	a, r4
      007463 F5 83            [12]  721 	mov	dph,a
      007465 E0               [24]  722 	movx	a,@dptr
      007466 FC               [12]  723 	mov	r4,a
      007467 90 08 60         [24]  724 	mov	dptr,#_add_key_byte_PARM_2
      00746A E0               [24]  725 	movx	a,@dptr
      00746B FB               [12]  726 	mov	r3,a
      00746C EC               [12]  727 	mov	a,r4
      00746D B5 03 02         [24]  728 	cjne	a,ar3,00167$
      007470 80 13            [24]  729 	sjmp	00106$
      007472                        730 00167$:
                                    731 ;	tmk_core/protocol/report.c:190: if (empty == -1 && keyboard_report->keys[i] == 0) {
      007472 90 08 63         [24]  732 	mov	dptr,#_add_key_byte_empty_10000_145
      007475 E0               [24]  733 	movx	a,@dptr
      007476 FB               [12]  734 	mov	r3,a
      007477 BB FF 08         [24]  735 	cjne	r3,#0xff,00113$
      00747A EC               [12]  736 	mov	a,r4
      00747B 70 05            [24]  737 	jnz	00113$
                                    738 ;	tmk_core/protocol/report.c:191: empty = i;
      00747D 90 08 63         [24]  739 	mov	dptr,#_add_key_byte_empty_10000_145
      007480 ED               [12]  740 	mov	a,r5
      007481 F0               [24]  741 	movx	@dptr,a
      007482                        742 00113$:
                                    743 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      007482 0D               [12]  744 	inc	r5
      007483 80 CF            [24]  745 	sjmp	00112$
      007485                        746 00106$:
                                    747 ;	tmk_core/protocol/report.c:194: if (i == KEYBOARD_REPORT_KEYS) {
      007485 BD 06 1D         [24]  748 	cjne	r5,#0x06,00114$
                                    749 ;	tmk_core/protocol/report.c:195: if (empty != -1) {
      007488 90 08 63         [24]  750 	mov	dptr,#_add_key_byte_empty_10000_145
      00748B E0               [24]  751 	movx	a,@dptr
      00748C FD               [12]  752 	mov	r5,a
      00748D BD FF 01         [24]  753 	cjne	r5,#0xff,00173$
      007490 22               [24]  754 	ret
      007491                        755 00173$:
                                    756 ;	tmk_core/protocol/report.c:196: keyboard_report->keys[empty] = code;
      007491 74 02            [12]  757 	mov	a,#0x02
      007493 12 4A 23         [24]  758 	lcall	_ak820_outline_0148
      007496 ED               [12]  759 	mov	a,r5
      007497 2E               [12]  760 	add	a, r6
      007498 FD               [12]  761 	mov	r5,a
      007499 E4               [12]  762 	clr	a
      00749A 3F               [12]  763 	addc	a, r7
      00749B FC               [12]  764 	mov	r4,a
      00749C 90 08 60         [24]  765 	mov	dptr,#_add_key_byte_PARM_2
      00749F E0               [24]  766 	movx	a,@dptr
      0074A0 8D 82            [24]  767 	mov	dpl,r5
      0074A2 8C 83            [24]  768 	mov	dph,r4
      0074A4 F0               [24]  769 	movx	@dptr,a
      0074A5                        770 00114$:
                                    771 ;	tmk_core/protocol/report.c:200: }
      0074A5 22               [24]  772 	ret
                                    773 ;------------------------------------------------------------
                                    774 ;Allocation info for local variables in function 'del_key_byte'
                                    775 ;------------------------------------------------------------
                                    776 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    777 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    778 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    779 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    780 ;------------------------------------------------------------
                                    781 ;	tmk_core/protocol/report.c:206: void del_key_byte(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function del_key_byte
                                    784 ;	-----------------------------------------
      0074A6                        785 _del_key_byte:
      0074A6 12 38 86         [24]  786 	lcall	_ak820_outline_0114
      0074A9 90 08 65         [24]  787 	mov	dptr,#_del_key_byte_report_arg_10000_156
      0074AC 12 38 8B         [24]  788 	lcall	_ak820_outline_0115
                                    789 ;	tmk_core/protocol/report.c:207: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0074AF 90 08 65         [24]  790 	mov	dptr,#_del_key_byte_report_arg_10000_156
      0074B2 12 38 39         [24]  791 	lcall	_ak820_outline_0057
                                    792 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0074B5 7D 00            [12]  793 	mov	r5,#0x00
      0074B7                        794 00105$:
      0074B7 BD 06 00         [24]  795 	cjne	r5,#0x06,00131$
      0074BA                        796 00131$:
      0074BA 50 1A            [24]  797 	jnc	00107$
                                    798 ;	tmk_core/protocol/report.c:235: if (keyboard_report->keys[i] == code) {
      0074BC 12 76 16         [24]  799 	lcall	_ak820_outline_0156
      0074BF FB               [12]  800 	mov	r3,a
      0074C0 E4               [12]  801 	clr	a
      0074C1 3C               [12]  802 	addc	a, r4
      0074C2 12 4F 41         [24]  803 	lcall	_ak820_outline_0061
      0074C5 90 08 64         [24]  804 	mov	dptr,#_del_key_byte_PARM_2
      0074C8 E0               [24]  805 	movx	a,@dptr
      0074C9 F9               [12]  806 	mov	r1,a
      0074CA EA               [12]  807 	mov	a,r2
      0074CB B5 01 05         [24]  808 	cjne	a,ar1,00106$
                                    809 ;	tmk_core/protocol/report.c:236: keyboard_report->keys[i] = 0;
      0074CE 12 33 FC         [24]  810 	lcall	_ak820_outline_0129
      0074D1 E4               [12]  811 	clr	a
      0074D2 F0               [24]  812 	movx	@dptr,a
      0074D3                        813 00106$:
                                    814 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0074D3 0D               [12]  815 	inc	r5
      0074D4 80 E1            [24]  816 	sjmp	00105$
      0074D6                        817 00107$:
                                    818 ;	tmk_core/protocol/report.c:240: }
      0074D6 22               [24]  819 	ret
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'add_key_bit'
                                    822 ;------------------------------------------------------------
                                    823 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    824 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    825 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    826 ;------------------------------------------------------------
                                    827 ;	tmk_core/protocol/report.c:247: void add_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function add_key_bit
                                    830 ;	-----------------------------------------
      0074D7                        831 _add_key_bit:
      0074D7 12 38 86         [24]  832 	lcall	_ak820_outline_0114
      0074DA 90 08 68         [24]  833 	mov	dptr,#_add_key_bit_report_arg_10000_162
      0074DD 12 38 8B         [24]  834 	lcall	_ak820_outline_0115
                                    835 ;	tmk_core/protocol/report.c:248: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0074E0 90 08 68         [24]  836 	mov	dptr,#_add_key_bit_report_arg_10000_162
      0074E3 12 38 39         [24]  837 	lcall	_ak820_outline_0057
                                    838 ;	tmk_core/protocol/report.c:249: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      0074E6 90 08 67         [24]  839 	mov	dptr,#_add_key_bit_PARM_2
      0074E9 E0               [24]  840 	movx	a,@dptr
      0074EA FD               [12]  841 	mov	r5,a
      0074EB C4               [12]  842 	swap	a
      0074EC 23               [12]  843 	rl	a
      0074ED 54 1F            [12]  844 	anl	a,#0x1f
      0074EF FC               [12]  845 	mov	r4,a
      0074F0 BC 1E 00         [24]  846 	cjne	r4,#0x1e,00112$
      0074F3                        847 00112$:
      0074F3 50 16            [24]  848 	jnc	00103$
                                    849 ;	tmk_core/protocol/report.c:250: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      0074F5 12 75 F4         [24]  850 	lcall	_ak820_outline_0039
      0074F8 80 02            [24]  851 	sjmp	00115$
      0074FA                        852 00114$:
      0074FA 25 E0            [12]  853 	add	a,acc
      0074FC                        854 00115$:
      0074FC D5 F0 FB         [24]  855 	djnz	b,00114$
      0074FF FF               [12]  856 	mov	r7,a
      007500 12 4A 4A         [24]  857 	lcall	_ak820_outline_0193
      007503 E0               [24]  858 	movx	a,@dptr
      007504 42 07            [12]  859 	orl	ar7,a
      007506 12 4A 4A         [24]  860 	lcall	_ak820_outline_0193
      007509 EF               [12]  861 	mov	a,r7
      00750A F0               [24]  862 	movx	@dptr,a
      00750B                        863 00103$:
                                    864 ;	tmk_core/protocol/report.c:254: }
      00750B 22               [24]  865 	ret
                                    866 ;------------------------------------------------------------
                                    867 ;Allocation info for local variables in function 'del_key_bit'
                                    868 ;------------------------------------------------------------
                                    869 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    870 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    871 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    872 ;------------------------------------------------------------
                                    873 ;	tmk_core/protocol/report.c:260: void del_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function del_key_bit
                                    876 ;	-----------------------------------------
      00750C                        877 _del_key_bit:
      00750C 12 38 86         [24]  878 	lcall	_ak820_outline_0114
      00750F 90 08 6B         [24]  879 	mov	dptr,#_del_key_bit_report_arg_10000_167
      007512 12 38 8B         [24]  880 	lcall	_ak820_outline_0115
                                    881 ;	tmk_core/protocol/report.c:261: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007515 90 08 6B         [24]  882 	mov	dptr,#_del_key_bit_report_arg_10000_167
      007518 12 38 39         [24]  883 	lcall	_ak820_outline_0057
                                    884 ;	tmk_core/protocol/report.c:262: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      00751B 90 08 6A         [24]  885 	mov	dptr,#_del_key_bit_PARM_2
      00751E E0               [24]  886 	movx	a,@dptr
      00751F FD               [12]  887 	mov	r5,a
      007520 C4               [12]  888 	swap	a
      007521 23               [12]  889 	rl	a
      007522 54 1F            [12]  890 	anl	a,#0x1f
      007524 FC               [12]  891 	mov	r4,a
      007525 BC 1E 00         [24]  892 	cjne	r4,#0x1e,00112$
      007528                        893 00112$:
      007528 50 17            [24]  894 	jnc	00103$
                                    895 ;	tmk_core/protocol/report.c:263: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      00752A 12 75 F4         [24]  896 	lcall	_ak820_outline_0039
      00752D 80 02            [24]  897 	sjmp	00115$
      00752F                        898 00114$:
      00752F 25 E0            [12]  899 	add	a,acc
      007531                        900 00115$:
      007531 D5 F0 FB         [24]  901 	djnz	b,00114$
      007534 F4               [12]  902 	cpl	a
      007535 FF               [12]  903 	mov	r7,a
      007536 12 4A 4A         [24]  904 	lcall	_ak820_outline_0193
      007539 E0               [24]  905 	movx	a,@dptr
      00753A 52 07            [12]  906 	anl	ar7,a
      00753C 12 4A 4A         [24]  907 	lcall	_ak820_outline_0193
      00753F EF               [12]  908 	mov	a,r7
      007540 F0               [24]  909 	movx	@dptr,a
      007541                        910 00103$:
                                    911 ;	tmk_core/protocol/report.c:267: }
      007541 22               [24]  912 	ret
                                    913 ;------------------------------------------------------------
                                    914 ;Allocation info for local variables in function 'add_key_to_report'
                                    915 ;------------------------------------------------------------
                                    916 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    917 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    918 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    919 ;------------------------------------------------------------
                                    920 ;	tmk_core/protocol/report.c:274: void add_key_to_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function add_key_to_report
                                    923 ;	-----------------------------------------
      007542                        924 _add_key_to_report:
      007542 12 38 86         [24]  925 	lcall	_ak820_outline_0114
      007545 90 08 6E         [24]  926 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      007548 12 38 8B         [24]  927 	lcall	_ak820_outline_0115
                                    928 ;	tmk_core/protocol/report.c:275: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00754B 90 08 6E         [24]  929 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      00754E 12 38 39         [24]  930 	lcall	_ak820_outline_0057
                                    931 ;	tmk_core/protocol/report.c:277: if (keyboard_protocol && keymap_config.nkro) {
      007551 90 0E 6C         [24]  932 	mov	dptr,#_keyboard_protocol
      007554 E0               [24]  933 	movx	a,@dptr
      007555 60 13            [24]  934 	jz	00102$
      007557 90 0B 4D         [24]  935 	mov	dptr,#_keymap_config
      00755A E0               [24]  936 	movx	a,@dptr
      00755B 30 E7 0C         [24]  937 	jnb	acc.7,00102$
                                    938 ;	tmk_core/protocol/report.c:278: add_key_bit(keyboard_report, key);
      00755E 90 08 6D         [24]  939 	mov	dptr,#_add_key_to_report_PARM_2
      007561 E0               [24]  940 	movx	a,@dptr
      007562 90 08 67         [24]  941 	mov	dptr,#_add_key_bit_PARM_2
      007565 12 4A 00         [24]  942 	lcall	_ak820_outline_0070
                                    943 ;	tmk_core/protocol/report.c:279: return;
      007568 81 D7            [12]  944 	ajmp	_add_key_bit
      00756A                        945 00102$:
                                    946 ;	tmk_core/protocol/report.c:282: add_key_byte(keyboard_report, key);
      00756A 90 08 6D         [24]  947 	mov	dptr,#_add_key_to_report_PARM_2
      00756D E0               [24]  948 	movx	a,@dptr
      00756E 90 08 60         [24]  949 	mov	dptr,#_add_key_byte_PARM_2
      007571 12 4A 00         [24]  950 	lcall	_ak820_outline_0070
                                    951 ;	tmk_core/protocol/report.c:283: }
      007574 81 3D            [12]  952 	ajmp	_add_key_byte
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'del_key_from_report'
                                    955 ;------------------------------------------------------------
                                    956 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    957 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    958 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    959 ;------------------------------------------------------------
                                    960 ;	tmk_core/protocol/report.c:289: void del_key_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function del_key_from_report
                                    963 ;	-----------------------------------------
      007576                        964 _del_key_from_report:
      007576 12 38 86         [24]  965 	lcall	_ak820_outline_0114
      007579 90 08 71         [24]  966 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      00757C 12 38 8B         [24]  967 	lcall	_ak820_outline_0115
                                    968 ;	tmk_core/protocol/report.c:290: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00757F 90 08 71         [24]  969 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      007582 12 38 39         [24]  970 	lcall	_ak820_outline_0057
                                    971 ;	tmk_core/protocol/report.c:292: if (keyboard_protocol && keymap_config.nkro) {
      007585 90 0E 6C         [24]  972 	mov	dptr,#_keyboard_protocol
      007588 E0               [24]  973 	movx	a,@dptr
      007589 60 13            [24]  974 	jz	00102$
      00758B 90 0B 4D         [24]  975 	mov	dptr,#_keymap_config
      00758E E0               [24]  976 	movx	a,@dptr
      00758F 30 E7 0C         [24]  977 	jnb	acc.7,00102$
                                    978 ;	tmk_core/protocol/report.c:293: del_key_bit(keyboard_report, key);
      007592 90 08 70         [24]  979 	mov	dptr,#_del_key_from_report_PARM_2
      007595 E0               [24]  980 	movx	a,@dptr
      007596 90 08 6A         [24]  981 	mov	dptr,#_del_key_bit_PARM_2
      007599 12 4A 00         [24]  982 	lcall	_ak820_outline_0070
                                    983 ;	tmk_core/protocol/report.c:294: return;
      00759C A1 0C            [24]  984 	ajmp	_del_key_bit
      00759E                        985 00102$:
                                    986 ;	tmk_core/protocol/report.c:297: del_key_byte(keyboard_report, key);
      00759E 90 08 70         [24]  987 	mov	dptr,#_del_key_from_report_PARM_2
      0075A1 E0               [24]  988 	movx	a,@dptr
      0075A2 90 08 64         [24]  989 	mov	dptr,#_del_key_byte_PARM_2
      0075A5 12 4A 00         [24]  990 	lcall	_ak820_outline_0070
                                    991 ;	tmk_core/protocol/report.c:298: }
      0075A8 81 A6            [12]  992 	ajmp	_del_key_byte
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    995 ;------------------------------------------------------------
                                    996 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                    997 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                    998 ;------------------------------------------------------------
                                    999 ;	tmk_core/protocol/report.c:304: void clear_keys_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                   1000 ;	-----------------------------------------
                                   1001 ;	 function clear_keys_from_report
                                   1002 ;	-----------------------------------------
      0075AA                       1003 _clear_keys_from_report:
      0075AA 12 38 86         [24] 1004 	lcall	_ak820_outline_0114
      0075AD 90 08 73         [24] 1005 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      0075B0 12 38 8B         [24] 1006 	lcall	_ak820_outline_0115
                                   1007 ;	tmk_core/protocol/report.c:305: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0075B3 90 08 73         [24] 1008 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      0075B6 12 38 39         [24] 1009 	lcall	_ak820_outline_0057
                                   1010 ;	tmk_core/protocol/report.c:308: if (keyboard_protocol && keymap_config.nkro) {
      0075B9 90 0E 6C         [24] 1011 	mov	dptr,#_keyboard_protocol
      0075BC E0               [24] 1012 	movx	a,@dptr
      0075BD 60 1E            [24] 1013 	jz	00102$
      0075BF 90 0B 4D         [24] 1014 	mov	dptr,#_keymap_config
      0075C2 E0               [24] 1015 	movx	a,@dptr
      0075C3 30 E7 17         [24] 1016 	jnb	acc.7,00102$
                                   1017 ;	tmk_core/protocol/report.c:309: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      0075C6 74 02            [12] 1018 	mov	a,#0x02
      0075C8 12 4A 3E         [24] 1019 	lcall	_ak820_outline_0172
      0075CB 7B 00            [12] 1020 	mov	r3,#0x00
      0075CD 12 76 20         [24] 1021 	lcall	_ak820_outline_0191
      0075D0 74 1E            [12] 1022 	mov	a,#0x1e
      0075D2 F0               [24] 1023 	movx	@dptr,a
      0075D3 E4               [12] 1024 	clr	a
      0075D4 A3               [24] 1025 	inc	dptr
      0075D5 12 38 7A         [24] 1026 	lcall	_ak820_outline_0109
      0075D8 8B F0            [24] 1027 	mov	b, r3
                                   1028 ;	tmk_core/protocol/report.c:310: return;
      0075DA 02 C1 DB         [24] 1029 	ljmp	_memset
      0075DD                       1030 00102$:
                                   1031 ;	tmk_core/protocol/report.c:313: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      0075DD 74 02            [12] 1032 	mov	a,#0x02
      0075DF 12 4A 23         [24] 1033 	lcall	_ak820_outline_0148
      0075E2 7D 00            [12] 1034 	mov	r5,#0x00
      0075E4 12 76 20         [24] 1035 	lcall	_ak820_outline_0191
      0075E7 74 06            [12] 1036 	mov	a,#0x06
      0075E9 F0               [24] 1037 	movx	@dptr,a
      0075EA E4               [12] 1038 	clr	a
      0075EB A3               [24] 1039 	inc	dptr
      0075EC 12 4A 00         [24] 1040 	lcall	_ak820_outline_0070
      0075EF 8D F0            [24] 1041 	mov	b, r5
                                   1042 ;	tmk_core/protocol/report.c:314: }
      0075F1 02 C1 DB         [24] 1043 	ljmp	_memset
                                   1044 	.area CSEG    (CODE)
                                   1045 	.area CONST   (CODE)
                                   1046 	.area CONST   (CODE)
      00C2EA                       1047 _KEYCODE2CONSUMER_usages_10000_118:
      00C2EA E2 00                 1048 	.byte #0xe2, #0x00	; 226
      00C2EC E9 00                 1049 	.byte #0xe9, #0x00	; 233
      00C2EE EA 00                 1050 	.byte #0xea, #0x00	; 234
      00C2F0 B5 00                 1051 	.byte #0xb5, #0x00	; 181
      00C2F2 B6 00                 1052 	.byte #0xb6, #0x00	; 182
      00C2F4 B7 00                 1053 	.byte #0xb7, #0x00	; 183
      00C2F6 CD 00                 1054 	.byte #0xcd, #0x00	; 205
      00C2F8 83 01                 1055 	.byte #0x83, #0x01	; 387
      00C2FA CC 00                 1056 	.byte #0xcc, #0x00	; 204
      00C2FC 8A 01                 1057 	.byte #0x8a, #0x01	; 394
      00C2FE 92 01                 1058 	.byte #0x92, #0x01	; 402
      00C300 94 01                 1059 	.byte #0x94, #0x01	; 404
      00C302 21 02                 1060 	.byte #0x21, #0x02	; 545
      00C304 23 02                 1061 	.byte #0x23, #0x02	; 547
      00C306 24 02                 1062 	.byte #0x24, #0x02	; 548
      00C308 25 02                 1063 	.byte #0x25, #0x02	; 549
      00C30A 26 02                 1064 	.byte #0x26, #0x02	; 550
      00C30C 27 02                 1065 	.byte #0x27, #0x02	; 551
      00C30E 2A 02                 1066 	.byte #0x2a, #0x02	; 554
      00C310 B3 00                 1067 	.byte #0xb3, #0x00	; 179
      00C312 B4 00                 1068 	.byte #0xb4, #0x00	; 180
      00C314 6F 00                 1069 	.byte #0x6f, #0x00	; 111
      00C316 70 00                 1070 	.byte #0x70, #0x00	; 112
      00C318 9F 01                 1071 	.byte #0x9f, #0x01	; 415
      00C31A CB 01                 1072 	.byte #0xcb, #0x01	; 459
      00C31C 9F 02                 1073 	.byte #0x9f, #0x02	; 671
      00C31E A0 02                 1074 	.byte #0xa0, #0x02	; 672
                                   1075 	.area CSEG    (CODE)
                                   1076 	.area XINIT   (CODE)
                                   1077 	.area CABS    (ABS,CODE)
                                   1078 
                                   1079 ; Experimental exact instruction outlining.
                                   1080 	.globl _ak820_outline_0039
                                   1081 	.globl _ak820_outline_0057
                                   1082 	.globl _ak820_outline_0061
                                   1083 	.globl _ak820_outline_0070
                                   1084 	.globl _ak820_outline_0109
                                   1085 	.globl _ak820_outline_0114
                                   1086 	.globl _ak820_outline_0115
                                   1087 	.globl _ak820_outline_0116
                                   1088 	.globl _ak820_outline_0129
                                   1089 	.globl _ak820_outline_0140
                                   1090 	.globl _ak820_outline_0148
                                   1091 	.globl _ak820_outline_0156
                                   1092 	.globl _ak820_outline_0172
                                   1093 	.globl _ak820_outline_0191
                                   1094 	.globl _ak820_outline_0193
                                   1095 
                                   1096 	.area CSEG (CODE)
                                   1097 ; function ak820_outline_0039
      0075F4                       1098 _ak820_outline_0039:
      0075F4 74 02            [12] 1099 	mov	a,#0x02
      0075F6 2E               [12] 1100 	add	a,r6
      0075F7 FE               [12] 1101 	mov	r6,a
      0075F8 E4               [12] 1102 	clr	a
      0075F9 3F               [12] 1103 	addc	a,r7
      0075FA FF               [12] 1104 	mov	r7,a
      0075FB EC               [12] 1105 	mov	a,r4
      0075FC 2E               [12] 1106 	add	a,r6
      0075FD FC               [12] 1107 	mov	r4,a
      0075FE E4               [12] 1108 	clr	a
      0075FF 3F               [12] 1109 	addc	a,r7
      007600 FB               [12] 1110 	mov	r3,a
      007601 74 07            [12] 1111 	mov	a,#0x07
      007603 5D               [12] 1112 	anl	a,r5
      007604 F5 F0            [12] 1113 	mov	b,a
      007606 05 F0            [12] 1114 	inc	b
      007608 74 01            [12] 1115 	mov	a,#0x01
      00760A 22               [24] 1116 	ret
                                   1117 
                                   1118 	.area CSEG (CODE)
                                   1119 ; function ak820_outline_0140
      00760B                       1120 _ak820_outline_0140:
      00760B F4               [12] 1121 	cpl	a
      00760C 24 01            [12] 1122 	add	a,#0x01
      00760E C5 F0            [12] 1123 	xch	a,b
      007610 F4               [12] 1124 	cpl	a
      007611 34 00            [12] 1125 	addc	a,#0x00
      007613 C5 F0            [12] 1126 	xch	a,b
      007615 22               [24] 1127 	ret
                                   1128 
                                   1129 	.area CSEG (CODE)
                                   1130 ; function ak820_outline_0156
      007616                       1131 _ak820_outline_0156:
      007616 74 02            [12] 1132 	mov	a,#0x02
      007618 2E               [12] 1133 	add	a,r6
      007619 FB               [12] 1134 	mov	r3,a
      00761A E4               [12] 1135 	clr	a
      00761B 3F               [12] 1136 	addc	a,r7
      00761C FC               [12] 1137 	mov	r4,a
      00761D ED               [12] 1138 	mov	a,r5
      00761E 2B               [12] 1139 	add	a,r3
      00761F 22               [24] 1140 	ret
                                   1141 
                                   1142 	.area CSEG (CODE)
                                   1143 ; function ak820_outline_0191
      007620                       1144 _ak820_outline_0191:
      007620 90 0E 5F         [24] 1145 	mov	dptr,#_memset_PARM_2
      007623 E4               [12] 1146 	clr	a
      007624 F0               [24] 1147 	movx	@dptr,a
      007625 90 0E 60         [24] 1148 	mov	dptr,#_memset_PARM_3
      007628 22               [24] 1149 	ret
