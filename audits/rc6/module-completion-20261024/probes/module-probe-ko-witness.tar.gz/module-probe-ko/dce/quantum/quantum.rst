                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_key_override_process
                                     18 	.globl _process_repeat_key
                                     19 	.globl _process_last_key
                                     20 	.globl _get_repeat_key_count
                                     21 	.globl _process_caps_word
                                     22 	.globl _process_record_via
                                     23 	.globl _get_weak_mods
                                     24 	.globl _get_mods
                                     25 	.globl _send_keyboard_report
                                     26 	.globl _mcu_reset
                                     27 	.globl _bootloader_jump
                                     28 	.globl _ak820_resolve_key
                                     29 	.globl _default_layer_set
                                     30 	.globl _biton
                                     31 	.globl _clear_keyboard
                                     32 	.globl _unregister_weak_mods
                                     33 	.globl _register_weak_mods
                                     34 	.globl _unregister_mods
                                     35 	.globl _register_mods
                                     36 	.globl _unregister_code
                                     37 	.globl _register_code
                                     38 	.globl _eeconfig_disable
                                     39 	.globl _rgb_matrix_set_suspend_state
                                     40 	.globl _rgb_matrix_task
                                     41 	.globl _mDelaymS
                                     42 	.globl _ADC_START
                                     43 	.globl _S0_R_FIFO
                                     44 	.globl _S0_T_FIFO
                                     45 	.globl _S0_FREE
                                     46 	.globl _S0_IF_BYTE
                                     47 	.globl _S0_IF_FIRST
                                     48 	.globl _S0_IF_OV
                                     49 	.globl _S0_FST_ACT
                                     50 	.globl _CP_RL2
                                     51 	.globl _C_T2
                                     52 	.globl _TR2
                                     53 	.globl _EXEN2
                                     54 	.globl _TCLK
                                     55 	.globl _RCLK
                                     56 	.globl _EXF2
                                     57 	.globl _CAP1F
                                     58 	.globl _TF2
                                     59 	.globl _RI
                                     60 	.globl _TI
                                     61 	.globl _RB8
                                     62 	.globl _TB8
                                     63 	.globl _REN
                                     64 	.globl _SM2
                                     65 	.globl _SM1
                                     66 	.globl _SM0
                                     67 	.globl _IT0
                                     68 	.globl _IE0
                                     69 	.globl _IT1
                                     70 	.globl _IE1
                                     71 	.globl _TR0
                                     72 	.globl _TF0
                                     73 	.globl _TR1
                                     74 	.globl _TF1
                                     75 	.globl _P4_0
                                     76 	.globl _P4_1
                                     77 	.globl _P4_2
                                     78 	.globl _P4_3
                                     79 	.globl _P4_4
                                     80 	.globl _P4_5
                                     81 	.globl _P4_6
                                     82 	.globl _RXD
                                     83 	.globl _TXD
                                     84 	.globl _INT0
                                     85 	.globl _INT1
                                     86 	.globl _T0
                                     87 	.globl _T1
                                     88 	.globl _MOSI1
                                     89 	.globl _MISO1
                                     90 	.globl _SCK1
                                     91 	.globl _P3_0
                                     92 	.globl _P3_1
                                     93 	.globl _P3_2
                                     94 	.globl _P3_3
                                     95 	.globl _P3_4
                                     96 	.globl _P3_5
                                     97 	.globl _P3_6
                                     98 	.globl _P3_7
                                     99 	.globl _CAP1_
                                    100 	.globl _T2_
                                    101 	.globl _CAP2_
                                    102 	.globl _T2EX_
                                    103 	.globl _RXD1
                                    104 	.globl _TXD1
                                    105 	.globl _P2_0
                                    106 	.globl _P2_1
                                    107 	.globl _P2_2
                                    108 	.globl _P2_3
                                    109 	.globl _P2_4
                                    110 	.globl _P2_5
                                    111 	.globl _P2_6
                                    112 	.globl _P2_7
                                    113 	.globl _AIN0
                                    114 	.globl _AIN1
                                    115 	.globl _AIN2
                                    116 	.globl _AIN3
                                    117 	.globl _AIN4
                                    118 	.globl _AIN5
                                    119 	.globl _AIN6
                                    120 	.globl _AIN7
                                    121 	.globl _CAP1
                                    122 	.globl _T2
                                    123 	.globl _CAP2
                                    124 	.globl _T2EX
                                    125 	.globl _INT0_
                                    126 	.globl _SCS
                                    127 	.globl _MOSI
                                    128 	.globl _MISO
                                    129 	.globl _SCK
                                    130 	.globl _RXD1_
                                    131 	.globl _TXD1_
                                    132 	.globl _P1_0
                                    133 	.globl _P1_1
                                    134 	.globl _P1_2
                                    135 	.globl _P1_3
                                    136 	.globl _P1_4
                                    137 	.globl _P1_5
                                    138 	.globl _P1_6
                                    139 	.globl _P1_7
                                    140 	.globl _AIN8
                                    141 	.globl _AIN9
                                    142 	.globl _AIN10
                                    143 	.globl _AIN11
                                    144 	.globl _AIN12
                                    145 	.globl _AIN13
                                    146 	.globl _RXD_
                                    147 	.globl _TXD_
                                    148 	.globl _SCL0
                                    149 	.globl _SDA0
                                    150 	.globl _P0_0
                                    151 	.globl _P0_1
                                    152 	.globl _P0_2
                                    153 	.globl _P0_3
                                    154 	.globl _P0_4
                                    155 	.globl _P0_5
                                    156 	.globl _P0_6
                                    157 	.globl _P0_7
                                    158 	.globl _IE_SPI0
                                    159 	.globl _IE_USB
                                    160 	.globl _IE_ADC
                                    161 	.globl _IE_UART1
                                    162 	.globl _IE_PWM_I2C
                                    163 	.globl _IE_GPIO
                                    164 	.globl _IE_WDOG
                                    165 	.globl _PX0
                                    166 	.globl _PT0
                                    167 	.globl _PX1
                                    168 	.globl _PT1
                                    169 	.globl _PS
                                    170 	.globl _PT2
                                    171 	.globl _PL_FLAG
                                    172 	.globl _PH_FLAG
                                    173 	.globl _EX0
                                    174 	.globl _ET0
                                    175 	.globl _EX1
                                    176 	.globl _ET1
                                    177 	.globl _ES
                                    178 	.globl _ET2
                                    179 	.globl _E_DIS
                                    180 	.globl _EA
                                    181 	.globl _P
                                    182 	.globl _F1
                                    183 	.globl _OV
                                    184 	.globl _RS0
                                    185 	.globl _RS1
                                    186 	.globl _F0
                                    187 	.globl _AC
                                    188 	.globl _CY
                                    189 	.globl _I2CS_INT_ST
                                    190 	.globl _I2CX_INT
                                    191 	.globl _LED_STATUS
                                    192 	.globl _LED_DMA_H
                                    193 	.globl _LED_DMA_L
                                    194 	.globl _LED_DMA
                                    195 	.globl _LED_PWM_OE
                                    196 	.globl _LED_COMMON
                                    197 	.globl _ADC_CHAN
                                    198 	.globl _ADC_DAT_H
                                    199 	.globl _ADC_DAT_L
                                    200 	.globl _ADC_DAT
                                    201 	.globl _ADC_CTRL
                                    202 	.globl _SPI1_CK_SE
                                    203 	.globl _SPI1_CTRL
                                    204 	.globl _SPI1_DATA
                                    205 	.globl _SPI1_STAT
                                    206 	.globl _SIF1
                                    207 	.globl _SBAUD1
                                    208 	.globl _SBUF1
                                    209 	.globl _SCON1
                                    210 	.globl _SPI0_SETUP
                                    211 	.globl _SPI0_CK_SE
                                    212 	.globl _SPI0_CTRL
                                    213 	.globl _SPI0_DATA
                                    214 	.globl _SPI0_STAT
                                    215 	.globl _T2CAP1H
                                    216 	.globl _T2CAP1L
                                    217 	.globl _T2CAP1
                                    218 	.globl _TH2
                                    219 	.globl _TL2
                                    220 	.globl _T2COUNT
                                    221 	.globl _RCAP2H
                                    222 	.globl _RCAP2L
                                    223 	.globl _RCAP2
                                    224 	.globl _T2MOD
                                    225 	.globl _T2CON
                                    226 	.globl _SBUF
                                    227 	.globl _SCON
                                    228 	.globl _TH1
                                    229 	.globl _TH0
                                    230 	.globl _TL1
                                    231 	.globl _TL0
                                    232 	.globl _TMOD
                                    233 	.globl _TCON
                                    234 	.globl _XBUS_AUX
                                    235 	.globl _P7
                                    236 	.globl _P6_DIR
                                    237 	.globl _P6_OUT_PU
                                    238 	.globl _P6_IN
                                    239 	.globl _P5_DIR
                                    240 	.globl _P5_OUT_PU
                                    241 	.globl _P5_IN
                                    242 	.globl _P4_LED_KEY
                                    243 	.globl _P4_DIR_PU
                                    244 	.globl _P4_MOD_OC
                                    245 	.globl _P4
                                    246 	.globl _P3_DIR_PU
                                    247 	.globl _P3_MOD_OC
                                    248 	.globl _P3
                                    249 	.globl _P2_DIR_PU
                                    250 	.globl _P2_MOD_OC
                                    251 	.globl _P2
                                    252 	.globl _P1_DIR_PU
                                    253 	.globl _P1_MOD_OC
                                    254 	.globl _P1
                                    255 	.globl _P0_DIR_PU
                                    256 	.globl _P0_MOD_OC
                                    257 	.globl _P0
                                    258 	.globl _ROM_CTRL
                                    259 	.globl _ROM_DATA_HH
                                    260 	.globl _ROM_DATA_HL
                                    261 	.globl _ROM_DATA_HI
                                    262 	.globl _ROM_ADDR_H
                                    263 	.globl _ROM_ADDR_L
                                    264 	.globl _ROM_ADDR
                                    265 	.globl _GPIO_IE
                                    266 	.globl _IP_EX
                                    267 	.globl _IE_EX
                                    268 	.globl _IP
                                    269 	.globl _IE
                                    270 	.globl _WDOG_COUNT
                                    271 	.globl _RESET_KEEP
                                    272 	.globl _WAKE_CTRL
                                    273 	.globl _CLOCK_CFG
                                    274 	.globl _POWER_CFG
                                    275 	.globl _PCON
                                    276 	.globl _GLOBAL_CFG
                                    277 	.globl _SAFE_MOD
                                    278 	.globl _DPH
                                    279 	.globl _DPL
                                    280 	.globl _SP
                                    281 	.globl _A_INV
                                    282 	.globl _B
                                    283 	.globl _ACC
                                    284 	.globl _PSW
                                    285 	.globl _process_record_quantum_helper_PARM_2
                                    286 	.globl _get_record_keycode_PARM_2
                                    287 	.globl _post_process_record_user_PARM_2
                                    288 	.globl _post_process_record_kb_PARM_2
                                    289 	.globl _process_record_user_PARM_2
                                    290 	.globl _process_record_kb_PARM_2
                                    291 	.globl _pre_process_record_user_PARM_2
                                    292 	.globl _pre_process_record_kb_PARM_2
                                    293 	.globl _register_code16
                                    294 	.globl _unregister_code16
                                    295 	.globl _pre_process_record_kb
                                    296 	.globl _pre_process_record_user
                                    297 	.globl _process_action_kb
                                    298 	.globl _process_record_kb
                                    299 	.globl _process_record_user
                                    300 	.globl _post_process_record_kb
                                    301 	.globl _post_process_record_user
                                    302 	.globl _reset_keyboard
                                    303 	.globl _soft_reset_keyboard
                                    304 	.globl _get_record_keycode
                                    305 	.globl _pre_process_record_quantum
                                    306 	.globl _post_process_record_quantum
                                    307 	.globl _process_record_quantum
                                    308 	.globl _process_record_quantum_helper
                                    309 	.globl _shutdown_user
                                    310 ;--------------------------------------------------------
                                    311 ; special function registers
                                    312 ;--------------------------------------------------------
                                    313 	.area RSEG    (ABS,DATA)
      000000                        314 	.org 0x0000
                           0000D0   315 _PSW	=	0x00d0
                           0000E0   316 _ACC	=	0x00e0
                           0000F0   317 _B	=	0x00f0
                           0000FD   318 _A_INV	=	0x00fd
                           000081   319 _SP	=	0x0081
                           000082   320 _DPL	=	0x0082
                           000083   321 _DPH	=	0x0083
                           0000A1   322 _SAFE_MOD	=	0x00a1
                           0000B1   323 _GLOBAL_CFG	=	0x00b1
                           000087   324 _PCON	=	0x0087
                           0000BA   325 _POWER_CFG	=	0x00ba
                           0000B9   326 _CLOCK_CFG	=	0x00b9
                           0000A9   327 _WAKE_CTRL	=	0x00a9
                           0000FE   328 _RESET_KEEP	=	0x00fe
                           0000FF   329 _WDOG_COUNT	=	0x00ff
                           0000A8   330 _IE	=	0x00a8
                           0000B8   331 _IP	=	0x00b8
                           0000E8   332 _IE_EX	=	0x00e8
                           0000E9   333 _IP_EX	=	0x00e9
                           0000B2   334 _GPIO_IE	=	0x00b2
                           008584   335 _ROM_ADDR	=	0x8584
                           000084   336 _ROM_ADDR_L	=	0x0084
                           000085   337 _ROM_ADDR_H	=	0x0085
                           008F8E   338 _ROM_DATA_HI	=	0x8f8e
                           00008E   339 _ROM_DATA_HL	=	0x008e
                           00008F   340 _ROM_DATA_HH	=	0x008f
                           000086   341 _ROM_CTRL	=	0x0086
                           000080   342 _P0	=	0x0080
                           0000C4   343 _P0_MOD_OC	=	0x00c4
                           0000C5   344 _P0_DIR_PU	=	0x00c5
                           000090   345 _P1	=	0x0090
                           000092   346 _P1_MOD_OC	=	0x0092
                           000093   347 _P1_DIR_PU	=	0x0093
                           0000A0   348 _P2	=	0x00a0
                           000094   349 _P2_MOD_OC	=	0x0094
                           000095   350 _P2_DIR_PU	=	0x0095
                           0000B0   351 _P3	=	0x00b0
                           000096   352 _P3_MOD_OC	=	0x0096
                           000097   353 _P3_DIR_PU	=	0x0097
                           0000C0   354 _P4	=	0x00c0
                           0000C2   355 _P4_MOD_OC	=	0x00c2
                           0000C3   356 _P4_DIR_PU	=	0x00c3
                           0000C1   357 _P4_LED_KEY	=	0x00c1
                           0000AA   358 _P5_IN	=	0x00aa
                           0000AB   359 _P5_OUT_PU	=	0x00ab
                           0000AC   360 _P5_DIR	=	0x00ac
                           0000AD   361 _P6_IN	=	0x00ad
                           0000AE   362 _P6_OUT_PU	=	0x00ae
                           0000AF   363 _P6_DIR	=	0x00af
                           0000F1   364 _P7	=	0x00f1
                           0000A2   365 _XBUS_AUX	=	0x00a2
                           000088   366 _TCON	=	0x0088
                           000089   367 _TMOD	=	0x0089
                           00008A   368 _TL0	=	0x008a
                           00008B   369 _TL1	=	0x008b
                           00008C   370 _TH0	=	0x008c
                           00008D   371 _TH1	=	0x008d
                           000098   372 _SCON	=	0x0098
                           000099   373 _SBUF	=	0x0099
                           0000C8   374 _T2CON	=	0x00c8
                           0000C9   375 _T2MOD	=	0x00c9
                           00CBCA   376 _RCAP2	=	0xcbca
                           0000CA   377 _RCAP2L	=	0x00ca
                           0000CB   378 _RCAP2H	=	0x00cb
                           00CDCC   379 _T2COUNT	=	0xcdcc
                           0000CC   380 _TL2	=	0x00cc
                           0000CD   381 _TH2	=	0x00cd
                           00CFCE   382 _T2CAP1	=	0xcfce
                           0000CE   383 _T2CAP1L	=	0x00ce
                           0000CF   384 _T2CAP1H	=	0x00cf
                           0000F8   385 _SPI0_STAT	=	0x00f8
                           0000F9   386 _SPI0_DATA	=	0x00f9
                           0000FA   387 _SPI0_CTRL	=	0x00fa
                           0000FB   388 _SPI0_CK_SE	=	0x00fb
                           0000FC   389 _SPI0_SETUP	=	0x00fc
                           0000BC   390 _SCON1	=	0x00bc
                           0000BD   391 _SBUF1	=	0x00bd
                           0000BE   392 _SBAUD1	=	0x00be
                           0000BF   393 _SIF1	=	0x00bf
                           0000B4   394 _SPI1_STAT	=	0x00b4
                           0000B5   395 _SPI1_DATA	=	0x00b5
                           0000B6   396 _SPI1_CTRL	=	0x00b6
                           0000B7   397 _SPI1_CK_SE	=	0x00b7
                           0000F3   398 _ADC_CTRL	=	0x00f3
                           00F5F4   399 _ADC_DAT	=	0xf5f4
                           0000F4   400 _ADC_DAT_L	=	0x00f4
                           0000F5   401 _ADC_DAT_H	=	0x00f5
                           0000F6   402 _ADC_CHAN	=	0x00f6
                           0000A6   403 _LED_COMMON	=	0x00a6
                           0000A7   404 _LED_PWM_OE	=	0x00a7
                           00C7C6   405 _LED_DMA	=	0xc7c6
                           0000C6   406 _LED_DMA_L	=	0x00c6
                           0000C7   407 _LED_DMA_H	=	0x00c7
                           0000F7   408 _LED_STATUS	=	0x00f7
                           0000B3   409 _I2CX_INT	=	0x00b3
                           0000BB   410 _I2CS_INT_ST	=	0x00bb
                                    411 ;--------------------------------------------------------
                                    412 ; special function bits
                                    413 ;--------------------------------------------------------
                                    414 	.area RSEG    (ABS,DATA)
      000000                        415 	.org 0x0000
                           0000D7   416 _CY	=	0x00d7
                           0000D6   417 _AC	=	0x00d6
                           0000D5   418 _F0	=	0x00d5
                           0000D4   419 _RS1	=	0x00d4
                           0000D3   420 _RS0	=	0x00d3
                           0000D2   421 _OV	=	0x00d2
                           0000D1   422 _F1	=	0x00d1
                           0000D0   423 _P	=	0x00d0
                           0000AF   424 _EA	=	0x00af
                           0000AE   425 _E_DIS	=	0x00ae
                           0000AD   426 _ET2	=	0x00ad
                           0000AC   427 _ES	=	0x00ac
                           0000AB   428 _ET1	=	0x00ab
                           0000AA   429 _EX1	=	0x00aa
                           0000A9   430 _ET0	=	0x00a9
                           0000A8   431 _EX0	=	0x00a8
                           0000BF   432 _PH_FLAG	=	0x00bf
                           0000BE   433 _PL_FLAG	=	0x00be
                           0000BD   434 _PT2	=	0x00bd
                           0000BC   435 _PS	=	0x00bc
                           0000BB   436 _PT1	=	0x00bb
                           0000BA   437 _PX1	=	0x00ba
                           0000B9   438 _PT0	=	0x00b9
                           0000B8   439 _PX0	=	0x00b8
                           0000EF   440 _IE_WDOG	=	0x00ef
                           0000EE   441 _IE_GPIO	=	0x00ee
                           0000ED   442 _IE_PWM_I2C	=	0x00ed
                           0000EC   443 _IE_UART1	=	0x00ec
                           0000EB   444 _IE_ADC	=	0x00eb
                           0000E9   445 _IE_USB	=	0x00e9
                           0000E8   446 _IE_SPI0	=	0x00e8
                           000087   447 _P0_7	=	0x0087
                           000086   448 _P0_6	=	0x0086
                           000085   449 _P0_5	=	0x0085
                           000084   450 _P0_4	=	0x0084
                           000083   451 _P0_3	=	0x0083
                           000082   452 _P0_2	=	0x0082
                           000081   453 _P0_1	=	0x0081
                           000080   454 _P0_0	=	0x0080
                           000081   455 _SDA0	=	0x0081
                           000080   456 _SCL0	=	0x0080
                           000083   457 _TXD_	=	0x0083
                           000082   458 _RXD_	=	0x0082
                           000085   459 _AIN13	=	0x0085
                           000084   460 _AIN12	=	0x0084
                           000083   461 _AIN11	=	0x0083
                           000082   462 _AIN10	=	0x0082
                           000081   463 _AIN9	=	0x0081
                           000080   464 _AIN8	=	0x0080
                           000097   465 _P1_7	=	0x0097
                           000096   466 _P1_6	=	0x0096
                           000095   467 _P1_5	=	0x0095
                           000094   468 _P1_4	=	0x0094
                           000093   469 _P1_3	=	0x0093
                           000092   470 _P1_2	=	0x0092
                           000091   471 _P1_1	=	0x0091
                           000090   472 _P1_0	=	0x0090
                           000097   473 _TXD1_	=	0x0097
                           000096   474 _RXD1_	=	0x0096
                           000097   475 _SCK	=	0x0097
                           000096   476 _MISO	=	0x0096
                           000095   477 _MOSI	=	0x0095
                           000094   478 _SCS	=	0x0094
                           000092   479 _INT0_	=	0x0092
                           000091   480 _T2EX	=	0x0091
                           000091   481 _CAP2	=	0x0091
                           000090   482 _T2	=	0x0090
                           000090   483 _CAP1	=	0x0090
                           000097   484 _AIN7	=	0x0097
                           000096   485 _AIN6	=	0x0096
                           000095   486 _AIN5	=	0x0095
                           000094   487 _AIN4	=	0x0094
                           000093   488 _AIN3	=	0x0093
                           000092   489 _AIN2	=	0x0092
                           000091   490 _AIN1	=	0x0091
                           000090   491 _AIN0	=	0x0090
                           0000A7   492 _P2_7	=	0x00a7
                           0000A6   493 _P2_6	=	0x00a6
                           0000A5   494 _P2_5	=	0x00a5
                           0000A4   495 _P2_4	=	0x00a4
                           0000A3   496 _P2_3	=	0x00a3
                           0000A2   497 _P2_2	=	0x00a2
                           0000A1   498 _P2_1	=	0x00a1
                           0000A0   499 _P2_0	=	0x00a0
                           0000A7   500 _TXD1	=	0x00a7
                           0000A6   501 _RXD1	=	0x00a6
                           0000A5   502 _T2EX_	=	0x00a5
                           0000A5   503 _CAP2_	=	0x00a5
                           0000A4   504 _T2_	=	0x00a4
                           0000A4   505 _CAP1_	=	0x00a4
                           0000B7   506 _P3_7	=	0x00b7
                           0000B6   507 _P3_6	=	0x00b6
                           0000B5   508 _P3_5	=	0x00b5
                           0000B4   509 _P3_4	=	0x00b4
                           0000B3   510 _P3_3	=	0x00b3
                           0000B2   511 _P3_2	=	0x00b2
                           0000B1   512 _P3_1	=	0x00b1
                           0000B0   513 _P3_0	=	0x00b0
                           0000B7   514 _SCK1	=	0x00b7
                           0000B6   515 _MISO1	=	0x00b6
                           0000B5   516 _MOSI1	=	0x00b5
                           0000B5   517 _T1	=	0x00b5
                           0000B4   518 _T0	=	0x00b4
                           0000B3   519 _INT1	=	0x00b3
                           0000B2   520 _INT0	=	0x00b2
                           0000B1   521 _TXD	=	0x00b1
                           0000B0   522 _RXD	=	0x00b0
                           0000C6   523 _P4_6	=	0x00c6
                           0000C5   524 _P4_5	=	0x00c5
                           0000C4   525 _P4_4	=	0x00c4
                           0000C3   526 _P4_3	=	0x00c3
                           0000C2   527 _P4_2	=	0x00c2
                           0000C1   528 _P4_1	=	0x00c1
                           0000C0   529 _P4_0	=	0x00c0
                           00008F   530 _TF1	=	0x008f
                           00008E   531 _TR1	=	0x008e
                           00008D   532 _TF0	=	0x008d
                           00008C   533 _TR0	=	0x008c
                           00008B   534 _IE1	=	0x008b
                           00008A   535 _IT1	=	0x008a
                           000089   536 _IE0	=	0x0089
                           000088   537 _IT0	=	0x0088
                           00009F   538 _SM0	=	0x009f
                           00009E   539 _SM1	=	0x009e
                           00009D   540 _SM2	=	0x009d
                           00009C   541 _REN	=	0x009c
                           00009B   542 _TB8	=	0x009b
                           00009A   543 _RB8	=	0x009a
                           000099   544 _TI	=	0x0099
                           000098   545 _RI	=	0x0098
                           0000CF   546 _TF2	=	0x00cf
                           0000CF   547 _CAP1F	=	0x00cf
                           0000CE   548 _EXF2	=	0x00ce
                           0000CD   549 _RCLK	=	0x00cd
                           0000CC   550 _TCLK	=	0x00cc
                           0000CB   551 _EXEN2	=	0x00cb
                           0000CA   552 _TR2	=	0x00ca
                           0000C9   553 _C_T2	=	0x00c9
                           0000C8   554 _CP_RL2	=	0x00c8
                           0000FF   555 _S0_FST_ACT	=	0x00ff
                           0000FE   556 _S0_IF_OV	=	0x00fe
                           0000FD   557 _S0_IF_FIRST	=	0x00fd
                           0000FC   558 _S0_IF_BYTE	=	0x00fc
                           0000FB   559 _S0_FREE	=	0x00fb
                           0000FA   560 _S0_T_FIFO	=	0x00fa
                           0000F8   561 _S0_R_FIFO	=	0x00f8
                           0000F7   562 _ADC_START	=	0x00f7
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable register banks
                                    565 ;--------------------------------------------------------
                                    566 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        567 	.ds 8
                                    568 ;--------------------------------------------------------
                                    569 ; internal ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area DSEG    (DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; overlayable items in internal ram
                                    574 ;--------------------------------------------------------
                                    575 ;--------------------------------------------------------
                                    576 ; indirectly addressable internal ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area ISEG    (DATA)
                                    579 ;--------------------------------------------------------
                                    580 ; absolute internal ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area IABS    (ABS,DATA)
                                    583 	.area IABS    (ABS,DATA)
                                    584 ;--------------------------------------------------------
                                    585 ; bit data
                                    586 ;--------------------------------------------------------
                                    587 	.area BSEG    (BIT)
      000028                        588 _get_record_keycode_sloc0_1_0:
      000028                        589 	.ds 1
      000029                        590 _pre_process_record_quantum_sloc0_1_0:
      000029                        591 	.ds 1
      00002A                        592 _process_ak820_nkro_sloc0_1_0:
      00002A                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      000C7A                        602 _extract_mod_bits_code_10000_609:
      000C7A                        603 	.ds 2
      000C7C                        604 _register_code16_code_10000_615:
      000C7C                        605 	.ds 2
      000C7E                        606 _unregister_code16_code_10000_620:
      000C7E                        607 	.ds 2
      000C80                        608 _pre_process_record_kb_PARM_2:
      000C80                        609 	.ds 3
      000C83                        610 _pre_process_record_kb_keycode_10000_634:
      000C83                        611 	.ds 2
      000C85                        612 _pre_process_record_user_PARM_2:
      000C85                        613 	.ds 3
      000C88                        614 _process_record_kb_PARM_2:
      000C88                        615 	.ds 3
      000C8B                        616 _process_record_kb_keycode_10000_640:
      000C8B                        617 	.ds 2
      000C8D                        618 _process_record_user_PARM_2:
      000C8D                        619 	.ds 3
      000C90                        620 _post_process_record_kb_PARM_2:
      000C90                        621 	.ds 3
      000C93                        622 _post_process_record_kb_keycode_10000_644:
      000C93                        623 	.ds 2
      000C95                        624 _post_process_record_user_PARM_2:
      000C95                        625 	.ds 3
      000C98                        626 _get_record_keycode_PARM_2:
      000C98                        627 	.ds 1
      000C99                        628 _get_record_keycode_record_argument_10000_658:
      000C99                        629 	.ds 3
      000C9C                        630 _pre_process_record_quantum_record_argument_10000_664:
      000C9C                        631 	.ds 3
      000C9F                        632 _post_process_record_quantum_record_10000_666:
      000C9F                        633 	.ds 3
      000CA2                        634 _process_record_quantum_record_10000_668:
      000CA2                        635 	.ds 3
      000CA5                        636 _process_ak820_override_record_10000_670:
      000CA5                        637 	.ds 2
      000CA7                        638 _process_ak820_nkro_PARM_2:
      000CA7                        639 	.ds 3
      000CAA                        640 _process_ak820_nkro_keycode_10000_674:
      000CAA                        641 	.ds 2
      000CAC                        642 _process_record_quantum_helper_PARM_2:
      000CAC                        643 	.ds 3
      000CAF                        644 _process_record_quantum_helper_keycode_10000_679:
      000CAF                        645 	.ds 2
      000CB1                        646 _get_u8_str_last_num_10000_705:
      000CB1                        647 	.ds 1
      000CB2                        648 _get_u16_str_last_num_10000_709:
      000CB2                        649 	.ds 2
                                    650 ;--------------------------------------------------------
                                    651 ; absolute external ram data
                                    652 ;--------------------------------------------------------
                                    653 	.area XABS    (ABS,XDATA)
                                    654 ;--------------------------------------------------------
                                    655 ; initialized external ram data
                                    656 ;--------------------------------------------------------
                                    657 	.area XISEG   (XDATA)
                                    658 	.area HOME    (CODE)
                                    659 	.area GSINIT0 (CODE)
                                    660 	.area GSINIT1 (CODE)
                                    661 	.area GSINIT2 (CODE)
                                    662 	.area GSINIT3 (CODE)
                                    663 	.area GSINIT4 (CODE)
                                    664 	.area GSINIT5 (CODE)
                                    665 	.area GSINIT  (CODE)
                                    666 	.area GSFINAL (CODE)
                                    667 	.area CSEG    (CODE)
                                    668 ;--------------------------------------------------------
                                    669 ; global & static initialisations
                                    670 ;--------------------------------------------------------
                                    671 	.area HOME    (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 	.area GSFINAL (CODE)
                                    674 	.area GSINIT  (CODE)
                                    675 ;------------------------------------------------------------
                                    676 ;Allocation info for local variables in function 'get_u8_str'
                                    677 ;------------------------------------------------------------
                                    678 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    679 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_704'
                                    680 ;buf           Allocated with name '_get_u8_str_buf_10000_705'
                                    681 ;last_num      Allocated with name '_get_u8_str_last_num_10000_705'
                                    682 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_705'
                                    683 ;------------------------------------------------------------
                                    684 ;	quantum/quantum.c:778: static uint8_t last_num = 0xFF;
      0030F3 90 0C B1         [24]  685 	mov	dptr,#_get_u8_str_last_num_10000_705
      0030F6 74 FF            [12]  686 	mov	a,#0xff
      0030F8 F0               [24]  687 	movx	@dptr,a
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'get_u16_str'
                                    690 ;------------------------------------------------------------
                                    691 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    692 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_708'
                                    693 ;buf           Allocated with name '_get_u16_str_buf_10000_709'
                                    694 ;last_num      Allocated with name '_get_u16_str_last_num_10000_709'
                                    695 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_709'
                                    696 ;------------------------------------------------------------
                                    697 ;	quantum/quantum.c:798: static uint16_t last_num = 0xFF;
      0030F9 90 0C B2         [24]  698 	mov	dptr,#_get_u16_str_last_num_10000_709
      0030FC 74 FF            [12]  699 	mov	a,#0xff
      0030FE F0               [24]  700 	movx	@dptr,a
      0030FF E4               [12]  701 	clr	a
      003100 A3               [24]  702 	inc	dptr
      003101 F0               [24]  703 	movx	@dptr,a
                                    704 ;--------------------------------------------------------
                                    705 ; Home
                                    706 ;--------------------------------------------------------
                                    707 	.area HOME    (CODE)
                                    708 	.area HOME    (CODE)
                                    709 ;--------------------------------------------------------
                                    710 ; code
                                    711 ;--------------------------------------------------------
                                    712 	.area CSEG    (CODE)
                                    713 ;------------------------------------------------------------
                                    714 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    715 ;------------------------------------------------------------
                                    716 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    717 ;------------------------------------------------------------
                                    718 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    719 ;	-----------------------------------------
                           000007   720 	ar7 = 0x07
                           000006   721 	ar6 = 0x06
                           000005   722 	ar5 = 0x05
                           000004   723 	ar4 = 0x04
                           000003   724 	ar3 = 0x03
                           000002   725 	ar2 = 0x02
                           000001   726 	ar1 = 0x01
                           000000   727 	ar0 = 0x00
                                    728 ;	 function extract_mod_bits
                                    729 ;	-----------------------------------------
      00A594                        730 _extract_mod_bits:
      00A594 12 38 86         [24]  731 	lcall	_ak820_outline_0114
      00A597 90 0C 7A         [24]  732 	mov	dptr,#_extract_mod_bits_code_10000_609
      00A59A 12 38 8B         [24]  733 	lcall	_ak820_outline_0115
                                    734 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A59D 90 0C 7A         [24]  735 	mov	dptr,#_extract_mod_bits_code_10000_609
      00A5A0 E0               [24]  736 	movx	a,@dptr
      00A5A1 A3               [24]  737 	inc	dptr
      00A5A2 E0               [24]  738 	movx	a,@dptr
                                    739 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A5A3 FF               [12]  740 	mov	r7,a
      00A5A4 60 05            [24]  741 	jz	00101$
      00A5A6 EF               [12]  742 	mov	a,r7
      00A5A7 24 E0            [12]  743 	add	a,#0xff - 0x1f
      00A5A9 50 04            [24]  744 	jnc	00102$
                                    745 ;	free result
      00A5AB                        746 00101$:
      00A5AB 75 82 00         [24]  747 	mov	dpl, #0x00
      00A5AE 22               [24]  748 	ret
      00A5AF                        749 00102$:
                                    750 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A5AF EF               [12]  751 	mov	a,r7
      00A5B0 30 E4 07         [24]  752 	jnb	acc.4,00106$
      00A5B3 EF               [12]  753 	mov	a,r7
      00A5B4 C4               [12]  754 	swap	a
      00A5B5 54 F0            [12]  755 	anl	a,#0xf0
      00A5B7 FE               [12]  756 	mov	r6,a
      00A5B8 80 02            [24]  757 	sjmp	00107$
      00A5BA                        758 00106$:
      00A5BA 8F 06            [24]  759 	mov	ar6,r7
      00A5BC                        760 00107$:
      00A5BC 8E 82            [24]  761 	mov	dpl, r6
                                    762 ;	quantum/quantum.c:143: }
      00A5BE 22               [24]  763 	ret
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'do_code16'
                                    766 ;------------------------------------------------------------
                                    767 ;f             Allocated with name '_do_code16_PARM_2'
                                    768 ;code          Allocated with name '_do_code16_code_10000_612'
                                    769 ;------------------------------------------------------------
                                    770 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    771 ;	-----------------------------------------
                                    772 ;	 function register_code16
                                    773 ;	-----------------------------------------
      00A5BF                        774 _register_code16:
      00A5BF 12 38 86         [24]  775 	lcall	_ak820_outline_0114
      00A5C2 90 0C 7C         [24]  776 	mov	dptr,#_register_code16_code_10000_615
      00A5C5 12 38 8B         [24]  777 	lcall	_ak820_outline_0115
                                    778 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A5C8 90 0C 7C         [24]  779 	mov	dptr,#_register_code16_code_10000_615
      00A5CB 12 37 F7         [24]  780 	lcall	_ak820_outline_0006
      00A5CE C0 07            [24]  781 	push	ar7
      00A5D0 C0 06            [24]  782 	push	ar6
      00A5D2 B1 94            [12]  783 	acall	_extract_mod_bits
      00A5D4 AD 82            [24]  784 	mov	r5, dpl
      00A5D6 D0 06            [24]  785 	pop	ar6
      00A5D8 D0 07            [24]  786 	pop	ar7
                                    787 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A5DA 12 A3 CD         [24]  788 	lcall	_ak820_outline_0127
      00A5DD 40 07            [24]  789 	jc	00105$
      00A5DF 74 E7            [12]  790 	mov	a,#0xe7
      00A5E1 9E               [12]  791 	subb	a,r6
      00A5E2 E4               [12]  792 	clr	a
      00A5E3 9F               [12]  793 	subb	a,r7
      00A5E4 50 08            [24]  794 	jnc	00101$
                                    795 ;	free result
      00A5E6                        796 00105$:
      00A5E6 90 0C 7C         [24]  797 	mov	dptr,#_register_code16_code_10000_615
      00A5E9 12 73 EE         [24]  798 	lcall	_ak820_outline_0044
      00A5EC 70 07            [24]  799 	jnz	00102$
      00A5EE                        800 00101$:
                                    801 ;	quantum/quantum.c:153: register_mods(mods);
      00A5EE 8D 82            [24]  802 	mov	dpl, r5
      00A5F0 12 7C 82         [24]  803 	lcall	_register_mods
      00A5F3 80 05            [24]  804 	sjmp	00103$
      00A5F5                        805 00102$:
                                    806 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A5F5 8D 82            [24]  807 	mov	dpl, r5
      00A5F7 12 7C AA         [24]  808 	lcall	_register_weak_mods
      00A5FA                        809 00103$:
                                    810 ;	quantum/quantum.c:157: register_code(code);
      00A5FA 90 0C 7C         [24]  811 	mov	dptr,#_register_code16_code_10000_615
      00A5FD E0               [24]  812 	movx	a,@dptr
      00A5FE F5 82            [12]  813 	mov	dpl,a
                                    814 ;	quantum/quantum.c:167: }
      00A600 02 7B 68         [24]  815 	ljmp	_register_code
                                    816 ;------------------------------------------------------------
                                    817 ;Allocation info for local variables in function 'unregister_code16'
                                    818 ;------------------------------------------------------------
                                    819 ;code          Allocated with name '_unregister_code16_code_10000_620'
                                    820 ;mods          Allocated with name '_unregister_code16_mods_10000_621'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function unregister_code16
                                    825 ;	-----------------------------------------
      00A603                        826 _unregister_code16:
      00A603 12 38 86         [24]  827 	lcall	_ak820_outline_0114
      00A606 90 0C 7E         [24]  828 	mov	dptr,#_unregister_code16_code_10000_620
      00A609 12 38 8B         [24]  829 	lcall	_ak820_outline_0115
                                    830 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A60C 90 0C 7E         [24]  831 	mov	dptr,#_unregister_code16_code_10000_620
      00A60F 12 37 F7         [24]  832 	lcall	_ak820_outline_0006
      00A612 C0 07            [24]  833 	push	ar7
      00A614 C0 06            [24]  834 	push	ar6
      00A616 B1 94            [12]  835 	acall	_extract_mod_bits
      00A618 AD 82            [24]  836 	mov	r5, dpl
      00A61A D0 06            [24]  837 	pop	ar6
                                    838 ;	quantum/quantum.c:172: unregister_code(code);
      00A61C 8E 04            [24]  839 	mov	ar4,r6
      00A61E 8C 82            [24]  840 	mov	dpl, r4
      00A620 C0 06            [24]  841 	push	ar6
      00A622 C0 05            [24]  842 	push	ar5
      00A624 12 7B D2         [24]  843 	lcall	_unregister_code
      00A627 D0 05            [24]  844 	pop	ar5
      00A629 D0 06            [24]  845 	pop	ar6
      00A62B D0 07            [24]  846 	pop	ar7
                                    847 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A62D 12 A3 CD         [24]  848 	lcall	_ak820_outline_0127
      00A630 40 07            [24]  849 	jc	00105$
      00A632 74 E7            [12]  850 	mov	a,#0xe7
      00A634 9E               [12]  851 	subb	a,r6
      00A635 E4               [12]  852 	clr	a
      00A636 9F               [12]  853 	subb	a,r7
      00A637 50 08            [24]  854 	jnc	00101$
                                    855 ;	free result
      00A639                        856 00105$:
      00A639 90 0C 7E         [24]  857 	mov	dptr,#_unregister_code16_code_10000_620
      00A63C 12 73 EE         [24]  858 	lcall	_ak820_outline_0044
      00A63F 70 05            [24]  859 	jnz	00102$
      00A641                        860 00101$:
                                    861 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A641 8D 82            [24]  862 	mov	dpl, r5
      00A643 02 7C 96         [24]  863 	ljmp	_unregister_mods
      00A646                        864 00102$:
                                    865 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A646 8D 82            [24]  866 	mov	dpl, r5
                                    867 ;	quantum/quantum.c:187: }
      00A648 02 7C BE         [24]  868 	ljmp	_unregister_weak_mods
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'tap_code16_delay'
                                    871 ;------------------------------------------------------------
                                    872 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    873 ;code          Allocated with name '_tap_code16_delay_code_10000_625'
                                    874 ;i             Allocated with name '_tap_code16_delay_i_20000_627'
                                    875 ;i             Allocated with name '_tap_code16_delay_i_50000_630'
                                    876 ;------------------------------------------------------------
                                    877 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function pre_process_record_kb
                                    880 ;	-----------------------------------------
      00A64B                        881 _pre_process_record_kb:
      00A64B 12 38 86         [24]  882 	lcall	_ak820_outline_0114
      00A64E 90 0C 83         [24]  883 	mov	dptr,#_pre_process_record_kb_keycode_10000_634
      00A651 12 38 8B         [24]  884 	lcall	_ak820_outline_0115
                                    885 ;	quantum/quantum.c:211: return pre_process_record_user(keycode, record);
      00A654 90 0C 83         [24]  886 	mov	dptr,#_pre_process_record_kb_keycode_10000_634
      00A657 12 38 39         [24]  887 	lcall	_ak820_outline_0057
      00A65A 90 0C 80         [24]  888 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A65D 12 A3 C4         [24]  889 	lcall	_ak820_outline_0029
      00A660 90 0C 85         [24]  890 	mov	dptr,#_pre_process_record_user_PARM_2
      00A663 12 AA 23         [24]  891 	lcall	_ak820_outline_0011
                                    892 ;	quantum/quantum.c:212: }
      00A666 C1 68            [12]  893 	ajmp	_pre_process_record_user
                                    894 ;------------------------------------------------------------
                                    895 ;Allocation info for local variables in function 'pre_process_record_user'
                                    896 ;------------------------------------------------------------
                                    897 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    898 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_636'
                                    899 ;------------------------------------------------------------
                                    900 ;	quantum/quantum.c:214: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    901 ;	-----------------------------------------
                                    902 ;	 function pre_process_record_user
                                    903 ;	-----------------------------------------
      00A668                        904 _pre_process_record_user:
                                    905 ;	quantum/quantum.c:215: return true;
      00A668 75 82 01         [24]  906 	mov	dpl, #0x01
                                    907 ;	quantum/quantum.c:216: }
      00A66B 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'process_action_kb'
                                    911 ;------------------------------------------------------------
                                    912 ;record        Allocated with name '_process_action_kb_record_10000_638'
                                    913 ;------------------------------------------------------------
                                    914 ;	quantum/quantum.c:218: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    915 ;	-----------------------------------------
                                    916 ;	 function process_action_kb
                                    917 ;	-----------------------------------------
      00A66C                        918 _process_action_kb:
                                    919 ;	quantum/quantum.c:219: return true;
      00A66C 75 82 01         [24]  920 	mov	dpl, #0x01
                                    921 ;	quantum/quantum.c:220: }
      00A66F 22               [24]  922 	ret
                                    923 ;------------------------------------------------------------
                                    924 ;Allocation info for local variables in function 'process_record_kb'
                                    925 ;------------------------------------------------------------
                                    926 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    927 ;keycode       Allocated with name '_process_record_kb_keycode_10000_640'
                                    928 ;------------------------------------------------------------
                                    929 ;	quantum/quantum.c:222: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    930 ;	-----------------------------------------
                                    931 ;	 function process_record_kb
                                    932 ;	-----------------------------------------
      00A670                        933 _process_record_kb:
      00A670 12 38 86         [24]  934 	lcall	_ak820_outline_0114
      00A673 90 0C 8B         [24]  935 	mov	dptr,#_process_record_kb_keycode_10000_640
      00A676 12 38 8B         [24]  936 	lcall	_ak820_outline_0115
                                    937 ;	quantum/quantum.c:223: return process_record_user(keycode, record);
      00A679 90 0C 8B         [24]  938 	mov	dptr,#_process_record_kb_keycode_10000_640
      00A67C 12 38 39         [24]  939 	lcall	_ak820_outline_0057
      00A67F 90 0C 88         [24]  940 	mov	dptr,#_process_record_kb_PARM_2
      00A682 12 A3 C4         [24]  941 	lcall	_ak820_outline_0029
      00A685 90 0C 8D         [24]  942 	mov	dptr,#_process_record_user_PARM_2
      00A688 12 AA 23         [24]  943 	lcall	_ak820_outline_0011
                                    944 ;	quantum/quantum.c:224: }
      00A68B C1 8D            [12]  945 	ajmp	_process_record_user
                                    946 ;------------------------------------------------------------
                                    947 ;Allocation info for local variables in function 'process_record_user'
                                    948 ;------------------------------------------------------------
                                    949 ;record        Allocated with name '_process_record_user_PARM_2'
                                    950 ;keycode       Allocated with name '_process_record_user_keycode_10000_642'
                                    951 ;------------------------------------------------------------
                                    952 ;	quantum/quantum.c:226: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    953 ;	-----------------------------------------
                                    954 ;	 function process_record_user
                                    955 ;	-----------------------------------------
      00A68D                        956 _process_record_user:
                                    957 ;	quantum/quantum.c:227: return true;
      00A68D 75 82 01         [24]  958 	mov	dpl, #0x01
                                    959 ;	quantum/quantum.c:228: }
      00A690 22               [24]  960 	ret
                                    961 ;------------------------------------------------------------
                                    962 ;Allocation info for local variables in function 'post_process_record_kb'
                                    963 ;------------------------------------------------------------
                                    964 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    965 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_644'
                                    966 ;------------------------------------------------------------
                                    967 ;	quantum/quantum.c:230: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    968 ;	-----------------------------------------
                                    969 ;	 function post_process_record_kb
                                    970 ;	-----------------------------------------
      00A691                        971 _post_process_record_kb:
      00A691 12 38 86         [24]  972 	lcall	_ak820_outline_0114
      00A694 90 0C 93         [24]  973 	mov	dptr,#_post_process_record_kb_keycode_10000_644
      00A697 12 38 8B         [24]  974 	lcall	_ak820_outline_0115
                                    975 ;	quantum/quantum.c:231: post_process_record_user(keycode, record);
      00A69A 90 0C 93         [24]  976 	mov	dptr,#_post_process_record_kb_keycode_10000_644
      00A69D 12 38 39         [24]  977 	lcall	_ak820_outline_0057
      00A6A0 90 0C 90         [24]  978 	mov	dptr,#_post_process_record_kb_PARM_2
      00A6A3 12 A3 C4         [24]  979 	lcall	_ak820_outline_0029
      00A6A6 90 0C 95         [24]  980 	mov	dptr,#_post_process_record_user_PARM_2
      00A6A9 12 AA 23         [24]  981 	lcall	_ak820_outline_0011
                                    982 ;	quantum/quantum.c:232: }
      00A6AC C1 AE            [24]  983 	ajmp	_post_process_record_user
                                    984 ;------------------------------------------------------------
                                    985 ;Allocation info for local variables in function 'post_process_record_user'
                                    986 ;------------------------------------------------------------
                                    987 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    988 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_646'
                                    989 ;------------------------------------------------------------
                                    990 ;	quantum/quantum.c:234: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    991 ;	-----------------------------------------
                                    992 ;	 function post_process_record_user
                                    993 ;	-----------------------------------------
      00A6AE                        994 _post_process_record_user:
      00A6AE 22               [24]  995 	ret
                                    996 ;------------------------------------------------------------
                                    997 ;Allocation info for local variables in function 'shutdown_quantum'
                                    998 ;------------------------------------------------------------
                                    999 ;i             Allocated with name '_shutdown_quantum_i_30000_652'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	quantum/quantum.c:236: void shutdown_quantum(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function shutdown_quantum
                                   1004 ;	-----------------------------------------
      00A6AF                       1005 _shutdown_quantum:
                                   1006 ;	quantum/quantum.c:237: clear_keyboard();
      00A6AF 12 7C D2         [24] 1007 	lcall	_clear_keyboard
                                   1008 ;	quantum/quantum.c:252: shutdown_user();
      00A6B2 12 AA 15         [24] 1009 	lcall	_shutdown_user
                                   1010 ;	quantum/quantum.c:253: wait_ms(250);
      00A6B5 7F FA            [12] 1011 	mov	r7,#0xfa
      00A6B7                       1012 00106$:
      00A6B7 EF               [12] 1013 	mov	a,r7
      00A6B8 60 09            [24] 1014 	jz	00108$
      00A6BA 90 00 01         [24] 1015 	mov	dptr,#0x0001
      00A6BD 12 5F 5C         [24] 1016 	lcall	_mDelaymS
      00A6C0 1F               [12] 1017 	dec	r7
      00A6C1 80 F4            [24] 1018 	sjmp	00106$
      00A6C3                       1019 00108$:
                                   1020 ;	quantum/quantum.c:258: }
      00A6C3 22               [24] 1021 	ret
                                   1022 ;------------------------------------------------------------
                                   1023 ;Allocation info for local variables in function 'reset_keyboard'
                                   1024 ;------------------------------------------------------------
                                   1025 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                   1026 ;	-----------------------------------------
                                   1027 ;	 function reset_keyboard
                                   1028 ;	-----------------------------------------
      00A6C4                       1029 _reset_keyboard:
                                   1030 ;	quantum/quantum.c:261: shutdown_quantum();
      00A6C4 D1 AF            [24] 1031 	acall	_shutdown_quantum
                                   1032 ;	quantum/quantum.c:262: bootloader_jump();
                                   1033 ;	quantum/quantum.c:263: }
      00A6C6 02 34 0E         [24] 1034 	ljmp	_bootloader_jump
                                   1035 ;------------------------------------------------------------
                                   1036 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1037 ;------------------------------------------------------------
                                   1038 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                   1039 ;	-----------------------------------------
                                   1040 ;	 function soft_reset_keyboard
                                   1041 ;	-----------------------------------------
      00A6C9                       1042 _soft_reset_keyboard:
                                   1043 ;	quantum/quantum.c:266: shutdown_quantum();
      00A6C9 D1 AF            [24] 1044 	acall	_shutdown_quantum
                                   1045 ;	quantum/quantum.c:267: mcu_reset();
                                   1046 ;	quantum/quantum.c:268: }
      00A6CB 02 34 01         [24] 1047 	ljmp	_mcu_reset
                                   1048 ;------------------------------------------------------------
                                   1049 ;Allocation info for local variables in function 'get_record_keycode'
                                   1050 ;------------------------------------------------------------
                                   1051 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1052 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_658'
                                   1053 ;record        Allocated with name '_get_record_keycode_record_10000_659'
                                   1054 ;------------------------------------------------------------
                                   1055 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1056 ;	-----------------------------------------
                                   1057 ;	 function get_record_keycode
                                   1058 ;	-----------------------------------------
      00A6CE                       1059 _get_record_keycode:
      00A6CE 12 49 D5         [24] 1060 	lcall	_ak820_outline_0041
      00A6D1 90 0C 99         [24] 1061 	mov	dptr,#_get_record_keycode_record_argument_10000_658
      00A6D4 12 38 21         [24] 1062 	lcall	_ak820_outline_0022
                                   1063 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A6D7 90 0C 99         [24] 1064 	mov	dptr,#_get_record_keycode_record_argument_10000_658
      00A6DA 12 37 E3         [24] 1065 	lcall	_ak820_outline_0002
                                   1066 ;	quantum/quantum.c:278: if (record->keycode) {
      00A6DD 4C               [12] 1067 	orl	a,r4
      00A6DE 60 04            [24] 1068 	jz	00102$
                                   1069 ;	quantum/quantum.c:279: return record->keycode;
      00A6E0 12 38 A1         [24] 1070 	lcall	_ak820_outline_0134
      00A6E3 22               [24] 1071 	ret
      00A6E4                       1072 00102$:
                                   1073 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A6E4 12 7D 30         [24] 1074 	lcall	_ak820_outline_0025
      00A6E7 7A 00            [12] 1075 	mov	r2,#0x00
      00A6E9 12 4A 29         [24] 1076 	lcall	_ak820_outline_0153
      00A6EC 12 38 01         [24] 1077 	lcall	_ak820_outline_0007
      00A6EF 60 06            [24] 1078 	jz	00105$
      00A6F1 90 0C 98         [24] 1079 	mov	dptr,#_get_record_keycode_PARM_2
      00A6F4 E0               [24] 1080 	movx	a,@dptr
      00A6F5 70 04            [24] 1081 	jnz	00106$
      00A6F7                       1082 00105$:
                                   1083 ;	assignBit
      00A6F7 C2 28            [12] 1084 	clr	_get_record_keycode_sloc0_1_0
      00A6F9 80 02            [24] 1085 	sjmp	00107$
      00A6FB                       1086 00106$:
                                   1087 ;	assignBit
      00A6FB D2 28            [12] 1088 	setb	_get_record_keycode_sloc0_1_0
      00A6FD                       1089 00107$:
      00A6FD 90 09 D7         [24] 1090 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A700 A2 28            [12] 1091 	mov	c,_get_record_keycode_sloc0_1_0
      00A702 E4               [12] 1092 	clr	a
      00A703 33               [12] 1093 	rlc	a
      00A704 F0               [24] 1094 	movx	@dptr,a
      00A705 8D 82            [24] 1095 	mov	dpl, r5
      00A707 8C 83            [24] 1096 	mov	dph, r4
                                   1097 ;	quantum/quantum.c:287: }
      00A709 02 80 C6         [24] 1098 	ljmp	_ak820_resolve_key
                                   1099 ;------------------------------------------------------------
                                   1100 ;Allocation info for local variables in function 'get_event_keycode'
                                   1101 ;------------------------------------------------------------
                                   1102 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1103 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_662'
                                   1104 ;------------------------------------------------------------
                                   1105 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1106 ;	-----------------------------------------
                                   1107 ;	 function pre_process_record_quantum
                                   1108 ;	-----------------------------------------
      00A70C                       1109 _pre_process_record_quantum:
      00A70C 12 49 D5         [24] 1110 	lcall	_ak820_outline_0041
      00A70F 90 0C 9C         [24] 1111 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_664
      00A712 12 38 21         [24] 1112 	lcall	_ak820_outline_0022
                                   1113 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A715 90 0C 9C         [24] 1114 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_664
      00A718 12 38 39         [24] 1115 	lcall	_ak820_outline_0057
                                   1116 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A71B 8E 03            [24] 1117 	mov	ar3,r6
      00A71D 8F 04            [24] 1118 	mov	ar4,r7
      00A71F 7D 00            [12] 1119 	mov	r5,#0x00
      00A721 90 0C 98         [24] 1120 	mov	dptr,#_get_record_keycode_PARM_2
      00A724 74 01            [12] 1121 	mov	a,#0x01
      00A726 F0               [24] 1122 	movx	@dptr,a
      00A727 12 33 FC         [24] 1123 	lcall	_ak820_outline_0129
      00A72A 8D F0            [24] 1124 	mov	b, r5
      00A72C C0 07            [24] 1125 	push	ar7
      00A72E C0 06            [24] 1126 	push	ar6
      00A730 D1 CE            [24] 1127 	acall	_get_record_keycode
      00A732 12 4A 2F         [24] 1128 	lcall	_ak820_outline_0160
      00A735 D0 06            [24] 1129 	pop	ar6
      00A737 D0 07            [24] 1130 	pop	ar7
                                   1131 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A739 74 07            [12] 1132 	mov	a,#0x07
      00A73B 12 38 29         [24] 1133 	lcall	_ak820_outline_0036
      00A73E 12 38 5C         [24] 1134 	lcall	_ak820_outline_0079
                                   1135 ;	quantum/quantum.c:353: return pre_process_record_kb(keycode, record) &&
      00A741 90 0C 80         [24] 1136 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A744 12 AA 16         [24] 1137 	lcall	_ak820_outline_0003
      00A747 C0 07            [24] 1138 	push	ar7
      00A749 C0 06            [24] 1139 	push	ar6
      00A74B D1 4B            [12] 1140 	acall	_pre_process_record_kb
      00A74D E5 82            [12] 1141 	mov	a, dpl
      00A74F D0 06            [24] 1142 	pop	ar6
      00A751 D0 07            [24] 1143 	pop	ar7
      00A753 60 0A            [24] 1144 	jz	00103$
                                   1145 ;	quantum/quantum.c:356: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A755 12 38 90         [24] 1146 	lcall	_ak820_outline_0126
      00A758 12 36 33         [24] 1147 	lcall	_ak820_combo_process
      00A75B E5 82            [12] 1148 	mov	a, dpl
      00A75D 70 04            [24] 1149 	jnz	00104$
                                   1150 ;	quantum/quantum.c:361: true;
      00A75F                       1151 00103$:
                                   1152 ;	assignBit
      00A75F C2 29            [12] 1153 	clr	_pre_process_record_quantum_sloc0_1_0
      00A761 80 02            [24] 1154 	sjmp	00105$
      00A763                       1155 00104$:
                                   1156 ;	assignBit
      00A763 D2 29            [12] 1157 	setb	_pre_process_record_quantum_sloc0_1_0
      00A765                       1158 00105$:
      00A765 A2 29            [12] 1159 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A767 12 38 B5         [24] 1160 	lcall	_ak820_outline_0154
                                   1161 ;	quantum/quantum.c:362: }
      00A76A 22               [24] 1162 	ret
                                   1163 ;------------------------------------------------------------
                                   1164 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1165 ;------------------------------------------------------------
                                   1166 ;record        Allocated with name '_post_process_record_quantum_record_10000_666'
                                   1167 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_667'
                                   1168 ;------------------------------------------------------------
                                   1169 ;	quantum/quantum.c:365: void post_process_record_quantum(keyrecord_t *record) {
                                   1170 ;	-----------------------------------------
                                   1171 ;	 function post_process_record_quantum
                                   1172 ;	-----------------------------------------
      00A76B                       1173 _post_process_record_quantum:
      00A76B 12 49 D5         [24] 1174 	lcall	_ak820_outline_0041
      00A76E 90 0C 9F         [24] 1175 	mov	dptr,#_post_process_record_quantum_record_10000_666
      00A771 12 38 21         [24] 1176 	lcall	_ak820_outline_0022
                                   1177 ;	quantum/quantum.c:366: uint16_t keycode = get_record_keycode(record, false);
      00A774 90 0C 9F         [24] 1178 	mov	dptr,#_post_process_record_quantum_record_10000_666
      00A777 12 55 AA         [24] 1179 	lcall	_ak820_outline_0013
      00A77A 90 0C 98         [24] 1180 	mov	dptr,#_get_record_keycode_PARM_2
      00A77D E4               [12] 1181 	clr	a
      00A77E 12 55 B3         [24] 1182 	lcall	_ak820_outline_0038
      00A781 12 A6 CE         [24] 1183 	lcall	_get_record_keycode
      00A784 12 4A 1E         [24] 1184 	lcall	_ak820_outline_0144
                                   1185 ;	quantum/quantum.c:367: post_process_record_kb(keycode, record);
      00A787 90 0C 9F         [24] 1186 	mov	dptr,#_post_process_record_quantum_record_10000_666
      00A78A 12 A3 C4         [24] 1187 	lcall	_ak820_outline_0029
      00A78D 90 0C 90         [24] 1188 	mov	dptr,#_post_process_record_kb_PARM_2
      00A790 12 AA 23         [24] 1189 	lcall	_ak820_outline_0011
                                   1190 ;	quantum/quantum.c:368: }
      00A793 02 A6 91         [24] 1191 	ljmp	_post_process_record_kb
                                   1192 ;------------------------------------------------------------
                                   1193 ;Allocation info for local variables in function 'process_record_quantum'
                                   1194 ;------------------------------------------------------------
                                   1195 ;record        Allocated with name '_process_record_quantum_record_10000_668'
                                   1196 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_669'
                                   1197 ;------------------------------------------------------------
                                   1198 ;	quantum/quantum.c:370: bool process_record_quantum(keyrecord_t *record) {
                                   1199 ;	-----------------------------------------
                                   1200 ;	 function process_record_quantum
                                   1201 ;	-----------------------------------------
      00A796                       1202 _process_record_quantum:
      00A796 12 49 D5         [24] 1203 	lcall	_ak820_outline_0041
      00A799 90 0C A2         [24] 1204 	mov	dptr,#_process_record_quantum_record_10000_668
      00A79C 12 38 21         [24] 1205 	lcall	_ak820_outline_0022
                                   1206 ;	quantum/quantum.c:372: uint16_t keycode = get_record_keycode(record, false);
      00A79F 90 0C A2         [24] 1207 	mov	dptr,#_process_record_quantum_record_10000_668
      00A7A2 12 55 AA         [24] 1208 	lcall	_ak820_outline_0013
      00A7A5 90 0C 98         [24] 1209 	mov	dptr,#_get_record_keycode_PARM_2
      00A7A8 E4               [12] 1210 	clr	a
      00A7A9 12 55 B3         [24] 1211 	lcall	_ak820_outline_0038
      00A7AC 12 A6 CE         [24] 1212 	lcall	_get_record_keycode
      00A7AF 12 4A 1E         [24] 1213 	lcall	_ak820_outline_0144
                                   1214 ;	quantum/quantum.c:376: return process_record_quantum_helper(keycode, record);
      00A7B2 90 0C A2         [24] 1215 	mov	dptr,#_process_record_quantum_record_10000_668
      00A7B5 12 A3 C4         [24] 1216 	lcall	_ak820_outline_0029
      00A7B8 90 0C AC         [24] 1217 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A7BB 12 AA 23         [24] 1218 	lcall	_ak820_outline_0011
                                   1219 ;	quantum/quantum.c:377: }
      00A7BE 02 A8 94         [24] 1220 	ljmp	_process_record_quantum_helper
                                   1221 ;------------------------------------------------------------
                                   1222 ;Allocation info for local variables in function 'process_ak820_override'
                                   1223 ;------------------------------------------------------------
                                   1224 ;record        Allocated with name '_process_ak820_override_record_10000_670'
                                   1225 ;------------------------------------------------------------
                                   1226 ;	quantum/quantum.c:379: static bool process_ak820_override(keyrecord_t AK820_STATE_MEM *record) {
                                   1227 ;	-----------------------------------------
                                   1228 ;	 function process_ak820_override
                                   1229 ;	-----------------------------------------
      00A7C1                       1230 _process_ak820_override:
      00A7C1 12 38 86         [24] 1231 	lcall	_ak820_outline_0114
      00A7C4 90 0C A5         [24] 1232 	mov	dptr,#_process_ak820_override_record_10000_670
      00A7C7 12 38 8B         [24] 1233 	lcall	_ak820_outline_0115
                                   1234 ;	quantum/quantum.c:381: if (get_repeat_key_count() || ak820_macro_primitive) return true;
      00A7CA 12 AA C4         [24] 1235 	lcall	_get_repeat_key_count
      00A7CD E5 82            [12] 1236 	mov	a, dpl
      00A7CF 70 06            [24] 1237 	jnz	00101$
      00A7D1 90 09 F1         [24] 1238 	mov	dptr,#_ak820_macro_primitive
      00A7D4 E0               [24] 1239 	movx	a,@dptr
      00A7D5 60 04            [24] 1240 	jz	00102$
      00A7D7                       1241 00101$:
      00A7D7 75 82 01         [24] 1242 	mov	dpl, #0x01
      00A7DA 22               [24] 1243 	ret
      00A7DB                       1244 00102$:
                                   1245 ;	quantum/quantum.c:382: if (ak820_key_override_process(record, get_mods() | get_weak_mods(),
      00A7DB 90 0C A5         [24] 1246 	mov	dptr,#_process_ak820_override_record_10000_670
      00A7DE 12 38 39         [24] 1247 	lcall	_ak820_outline_0057
      00A7E1 12 87 65         [24] 1248 	lcall	_get_mods
      00A7E4 AD 82            [24] 1249 	mov	r5, dpl
      00A7E6 12 87 7B         [24] 1250 	lcall	_get_weak_mods
      00A7E9 E5 82            [12] 1251 	mov	a,dpl
      00A7EB 42 05            [12] 1252 	orl	ar5,a
                                   1253 ;	quantum/quantum.c:383: get_highest_layer(layer_state | default_layer_state))) return true;
      00A7ED 90 0E 7B         [24] 1254 	mov	dptr,#_default_layer_state
      00A7F0 E0               [24] 1255 	movx	a,@dptr
      00A7F1 FC               [12] 1256 	mov	r4,a
      00A7F2 90 0E 7C         [24] 1257 	mov	dptr,#_layer_state
      00A7F5 E0               [24] 1258 	movx	a,@dptr
      00A7F6 42 04            [12] 1259 	orl	ar4,a
      00A7F8 8C 82            [24] 1260 	mov	dpl, r4
      00A7FA C0 07            [24] 1261 	push	ar7
      00A7FC C0 06            [24] 1262 	push	ar6
      00A7FE C0 05            [24] 1263 	push	ar5
      00A800 12 88 1A         [24] 1264 	lcall	_biton
      00A803 AC 82            [24] 1265 	mov	r4, dpl
      00A805 D0 05            [24] 1266 	pop	ar5
      00A807 D0 06            [24] 1267 	pop	ar6
      00A809 D0 07            [24] 1268 	pop	ar7
      00A80B 90 05 66         [24] 1269 	mov	dptr,#_ak820_key_override_process_PARM_2
      00A80E ED               [12] 1270 	mov	a,r5
      00A80F F0               [24] 1271 	movx	@dptr,a
      00A810 90 05 67         [24] 1272 	mov	dptr,#_ak820_key_override_process_PARM_3
      00A813 EC               [12] 1273 	mov	a,r4
      00A814 12 4A 00         [24] 1274 	lcall	_ak820_outline_0070
      00A817 12 3F CA         [24] 1275 	lcall	_ak820_key_override_process
      00A81A E5 82            [12] 1276 	mov	a, dpl
      00A81C 60 04            [24] 1277 	jz	00105$
      00A81E 75 82 01         [24] 1278 	mov	dpl, #0x01
      00A821 22               [24] 1279 	ret
      00A822                       1280 00105$:
                                   1281 ;	quantum/quantum.c:384: send_keyboard_report();
      00A822 12 86 13         [24] 1282 	lcall	_send_keyboard_report
                                   1283 ;	quantum/quantum.c:385: return false;
      00A825 75 82 00         [24] 1284 	mov	dpl, #0x00
                                   1285 ;	quantum/quantum.c:386: }
      00A828 22               [24] 1286 	ret
                                   1287 ;------------------------------------------------------------
                                   1288 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1289 ;------------------------------------------------------------
                                   1290 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1291 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_674'
                                   1292 ;record        Allocated with name '_process_ak820_nkro_record_10000_675'
                                   1293 ;------------------------------------------------------------
                                   1294 ;	quantum/quantum.c:394: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1295 ;	-----------------------------------------
                                   1296 ;	 function process_ak820_nkro
                                   1297 ;	-----------------------------------------
      00A829                       1298 _process_ak820_nkro:
      00A829 12 38 86         [24] 1299 	lcall	_ak820_outline_0114
      00A82C 90 0C AA         [24] 1300 	mov	dptr,#_process_ak820_nkro_keycode_10000_674
      00A82F 12 38 8B         [24] 1301 	lcall	_ak820_outline_0115
                                   1302 ;	quantum/quantum.c:396: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A832 90 0C A7         [24] 1303 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A835 12 38 39         [24] 1304 	lcall	_ak820_outline_0057
                                   1305 ;	quantum/quantum.c:400: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A838 90 0C AA         [24] 1306 	mov	dptr,#_process_ak820_nkro_keycode_10000_674
      00A83B 12 38 50         [24] 1307 	lcall	_ak820_outline_0065
      00A83E C3               [12] 1308 	clr	c
      00A83F EC               [12] 1309 	mov	a,r4
      00A840 94 11            [12] 1310 	subb	a,#0x11
      00A842 ED               [12] 1311 	mov	a,r5
      00A843 94 70            [12] 1312 	subb	a,#0x70
      00A845 40 08            [24] 1313 	jc	00101$
      00A847 74 13            [12] 1314 	mov	a,#0x13
      00A849 9C               [12] 1315 	subb	a,r4
      00A84A 74 70            [12] 1316 	mov	a,#0x70
      00A84C 9D               [12] 1317 	subb	a,r5
      00A84D 50 04            [24] 1318 	jnc	00102$
                                   1319 ;	free result
      00A84F                       1320 00101$:
      00A84F 75 82 01         [24] 1321 	mov	dpl, #0x01
      00A852 22               [24] 1322 	ret
      00A853                       1323 00102$:
                                   1324 ;	quantum/quantum.c:401: if (record->event.pressed) {
      00A853 12 38 01         [24] 1325 	lcall	_ak820_outline_0007
      00A856 60 38            [24] 1326 	jz	00105$
                                   1327 ;	quantum/quantum.c:402: clear_keyboard();
      00A858 C0 05            [24] 1328 	push	ar5
      00A85A C0 04            [24] 1329 	push	ar4
      00A85C 12 7C D2         [24] 1330 	lcall	_clear_keyboard
      00A85F D0 04            [24] 1331 	pop	ar4
      00A861 D0 05            [24] 1332 	pop	ar5
                                   1333 ;	quantum/quantum.c:403: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A863 BC 13 14         [24] 1334 	cjne	r4,#0x13,00108$
      00A866 BD 70 11         [24] 1335 	cjne	r5,#0x70,00108$
      00A869 90 0B 4D         [24] 1336 	mov	dptr,#_keymap_config
      00A86C E0               [24] 1337 	movx	a,@dptr
      00A86D 23               [12] 1338 	rl	a
      00A86E 54 01            [12] 1339 	anl	a,#0x01
      00A870 B4 01 00         [24] 1340 	cjne	a,#0x01,00136$
      00A873                       1341 00136$:
      00A873 92 2A            [24] 1342 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A875 E4               [12] 1343 	clr	a
      00A876 33               [12] 1344 	rlc	a
      00A877 FF               [12] 1345 	mov	r7,a
      00A878 80 09            [24] 1346 	sjmp	00109$
      00A87A                       1347 00108$:
      00A87A E4               [12] 1348 	clr	a
      00A87B BC 11 04         [24] 1349 	cjne	r4,#0x11,00137$
      00A87E BD 70 01         [24] 1350 	cjne	r5,#0x70,00137$
      00A881 04               [12] 1351 	inc	a
      00A882                       1352 00137$:
      00A882 FF               [12] 1353 	mov	r7,a
      00A883                       1354 00109$:
                                   1355 ;	assignBit
      00A883 EF               [12] 1356 	mov	a,r7
      00A884 24 FF            [12] 1357 	add	a,#0xff
      00A886 E4               [12] 1358 	clr	a
      00A887 33               [12] 1359 	rlc	a
      00A888 90 0B 4D         [24] 1360 	mov	dptr,#_keymap_config
      00A88B 13               [12] 1361 	rrc	a
      00A88C E0               [24] 1362 	movx	a,@dptr
      00A88D 92 E7            [24] 1363 	mov	acc.7,c
      00A88F F0               [24] 1364 	movx	@dptr,a
      00A890                       1365 00105$:
                                   1366 ;	quantum/quantum.c:405: return false;
      00A890 75 82 00         [24] 1367 	mov	dpl, #0x00
                                   1368 ;	quantum/quantum.c:406: }
      00A893 22               [24] 1369 	ret
                                   1370 ;------------------------------------------------------------
                                   1371 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1372 ;------------------------------------------------------------
                                   1373 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1374 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_679'
                                   1375 ;record        Allocated with name '_process_record_quantum_helper_record_10000_680'
                                   1376 ;------------------------------------------------------------
                                   1377 ;	quantum/quantum.c:409: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1378 ;	-----------------------------------------
                                   1379 ;	 function process_record_quantum_helper
                                   1380 ;	-----------------------------------------
      00A894                       1381 _process_record_quantum_helper:
      00A894 12 38 86         [24] 1382 	lcall	_ak820_outline_0114
      00A897 90 0C AF         [24] 1383 	mov	dptr,#_process_record_quantum_helper_keycode_10000_679
      00A89A 12 38 8B         [24] 1384 	lcall	_ak820_outline_0115
                                   1385 ;	quantum/quantum.c:411: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A89D 90 0C AC         [24] 1386 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A8A0 12 38 39         [24] 1387 	lcall	_ak820_outline_0057
                                   1388 ;	quantum/quantum.c:454: process_ak820_nkro(keycode, record) &&
      00A8A3 90 0C AF         [24] 1389 	mov	dptr,#_process_record_quantum_helper_keycode_10000_679
      00A8A6 12 38 50         [24] 1390 	lcall	_ak820_outline_0065
      00A8A9 90 0C A7         [24] 1391 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A8AC 12 AA 16         [24] 1392 	lcall	_ak820_outline_0003
      00A8AF C0 07            [24] 1393 	push	ar7
      00A8B1 C0 06            [24] 1394 	push	ar6
      00A8B3 C0 05            [24] 1395 	push	ar5
      00A8B5 C0 04            [24] 1396 	push	ar4
      00A8B7 11 29            [24] 1397 	acall	_process_ak820_nkro
      00A8B9 E5 82            [12] 1398 	mov	a, dpl
      00A8BB D0 04            [24] 1399 	pop	ar4
      00A8BD D0 05            [24] 1400 	pop	ar5
      00A8BF D0 06            [24] 1401 	pop	ar6
      00A8C1 D0 07            [24] 1402 	pop	ar7
      00A8C3 70 02            [24] 1403 	jnz	00212$
      00A8C5 21 D2            [12] 1404 	ajmp	00101$
      00A8C7                       1405 00212$:
                                   1406 ;	quantum/quantum.c:465: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A8C7 90 0C 63         [24] 1407 	mov	dptr,#_process_last_key_PARM_2
      00A8CA 12 AA 16         [24] 1408 	lcall	_ak820_outline_0003
      00A8CD C0 07            [24] 1409 	push	ar7
      00A8CF C0 06            [24] 1410 	push	ar6
      00A8D1 C0 05            [24] 1411 	push	ar5
      00A8D3 C0 04            [24] 1412 	push	ar4
      00A8D5 12 A2 FE         [24] 1413 	lcall	_process_last_key
      00A8D8 E5 82            [12] 1414 	mov	a, dpl
      00A8DA D0 04            [24] 1415 	pop	ar4
      00A8DC D0 05            [24] 1416 	pop	ar5
      00A8DE D0 06            [24] 1417 	pop	ar6
      00A8E0 D0 07            [24] 1418 	pop	ar7
      00A8E2 70 02            [24] 1419 	jnz	00213$
      00A8E4 21 D2            [12] 1420 	ajmp	00101$
      00A8E6                       1421 00213$:
      00A8E6 90 0C 69         [24] 1422 	mov	dptr,#_process_repeat_key_PARM_2
      00A8E9 12 AA 16         [24] 1423 	lcall	_ak820_outline_0003
      00A8EC C0 07            [24] 1424 	push	ar7
      00A8EE C0 06            [24] 1425 	push	ar6
      00A8F0 C0 05            [24] 1426 	push	ar5
      00A8F2 C0 04            [24] 1427 	push	ar4
      00A8F4 12 A3 7B         [24] 1428 	lcall	_process_repeat_key
      00A8F7 E5 82            [12] 1429 	mov	a, dpl
      00A8F9 D0 04            [24] 1430 	pop	ar4
      00A8FB D0 05            [24] 1431 	pop	ar5
      00A8FD D0 06            [24] 1432 	pop	ar6
      00A8FF D0 07            [24] 1433 	pop	ar7
      00A901 70 02            [24] 1434 	jnz	00214$
      00A903 21 D2            [12] 1435 	ajmp	00101$
      00A905                       1436 00214$:
                                   1437 ;	quantum/quantum.c:474: process_record_via(keycode, record) &&
      00A905 90 0C EC         [24] 1438 	mov	dptr,#_process_record_via_PARM_2
      00A908 12 AA 16         [24] 1439 	lcall	_ak820_outline_0003
      00A90B C0 07            [24] 1440 	push	ar7
      00A90D C0 06            [24] 1441 	push	ar6
      00A90F C0 05            [24] 1442 	push	ar5
      00A911 C0 04            [24] 1443 	push	ar4
      00A913 F1 17            [12] 1444 	acall	_process_record_via
      00A915 E5 82            [12] 1445 	mov	a, dpl
      00A917 D0 04            [24] 1446 	pop	ar4
      00A919 D0 05            [24] 1447 	pop	ar5
      00A91B D0 06            [24] 1448 	pop	ar6
      00A91D D0 07            [24] 1449 	pop	ar7
      00A91F 70 02            [24] 1450 	jnz	00215$
      00A921 21 D2            [12] 1451 	ajmp	00101$
      00A923                       1452 00215$:
                                   1453 ;	quantum/quantum.c:484: process_record_kb(keycode, record) &&
      00A923 90 0C 88         [24] 1454 	mov	dptr,#_process_record_kb_PARM_2
      00A926 12 AA 16         [24] 1455 	lcall	_ak820_outline_0003
      00A929 C0 07            [24] 1456 	push	ar7
      00A92B C0 06            [24] 1457 	push	ar6
      00A92D C0 05            [24] 1458 	push	ar5
      00A92F C0 04            [24] 1459 	push	ar4
      00A931 12 A6 70         [24] 1460 	lcall	_process_record_kb
      00A934 E5 82            [12] 1461 	mov	a, dpl
      00A936 D0 04            [24] 1462 	pop	ar4
      00A938 D0 05            [24] 1463 	pop	ar5
      00A93A D0 06            [24] 1464 	pop	ar6
      00A93C D0 07            [24] 1465 	pop	ar7
      00A93E 70 02            [24] 1466 	jnz	00216$
      00A940 21 D2            [12] 1467 	ajmp	00101$
      00A942                       1468 00216$:
                                   1469 ;	quantum/quantum.c:507: process_caps_word(keycode, record) &&
      00A942 90 0C 4B         [24] 1470 	mov	dptr,#_process_caps_word_PARM_2
      00A945 12 AA 16         [24] 1471 	lcall	_ak820_outline_0003
      00A948 C0 07            [24] 1472 	push	ar7
      00A94A C0 06            [24] 1473 	push	ar6
      00A94C C0 05            [24] 1474 	push	ar5
      00A94E C0 04            [24] 1475 	push	ar4
      00A950 12 A0 8C         [24] 1476 	lcall	_process_caps_word
      00A953 E5 82            [12] 1477 	mov	a, dpl
      00A955 D0 04            [24] 1478 	pop	ar4
      00A957 D0 05            [24] 1479 	pop	ar5
      00A959 D0 06            [24] 1480 	pop	ar6
      00A95B D0 07            [24] 1481 	pop	ar7
      00A95D 70 02            [24] 1482 	jnz	00217$
      00A95F 21 D2            [12] 1483 	ajmp	00101$
      00A961                       1484 00217$:
                                   1485 ;	quantum/quantum.c:510: process_ak820_override((keyrecord_t AK820_STATE_MEM *)record) &&
      00A961 12 38 90         [24] 1486 	lcall	_ak820_outline_0126
      00A964 C0 07            [24] 1487 	push	ar7
      00A966 C0 06            [24] 1488 	push	ar6
      00A968 C0 05            [24] 1489 	push	ar5
      00A96A C0 04            [24] 1490 	push	ar4
      00A96C 12 A7 C1         [24] 1491 	lcall	_process_ak820_override
      00A96F E5 82            [12] 1492 	mov	a, dpl
      00A971 D0 04            [24] 1493 	pop	ar4
      00A973 D0 05            [24] 1494 	pop	ar5
      00A975 D0 06            [24] 1495 	pop	ar6
      00A977 D0 07            [24] 1496 	pop	ar7
      00A979 60 57            [24] 1497 	jz	00101$
                                   1498 ;	quantum/quantum.c:537: process_grave_esc(keycode, record) &&
      00A97B 90 0C 50         [24] 1499 	mov	dptr,#_process_grave_esc_PARM_2
      00A97E 12 AA 16         [24] 1500 	lcall	_ak820_outline_0003
      00A981 C0 07            [24] 1501 	push	ar7
      00A983 C0 06            [24] 1502 	push	ar6
      00A985 C0 05            [24] 1503 	push	ar5
      00A987 C0 04            [24] 1504 	push	ar4
      00A989 12 A1 9E         [24] 1505 	lcall	_process_grave_esc
      00A98C E5 82            [12] 1506 	mov	a, dpl
      00A98E D0 04            [24] 1507 	pop	ar4
      00A990 D0 05            [24] 1508 	pop	ar5
      00A992 D0 06            [24] 1509 	pop	ar6
      00A994 D0 07            [24] 1510 	pop	ar7
      00A996 60 3A            [24] 1511 	jz	00101$
                                   1512 ;	quantum/quantum.c:540: process_rgb(keycode, record) &&
      00A998 90 0C 6E         [24] 1513 	mov	dptr,#_process_rgb_PARM_2
      00A99B 12 AA 16         [24] 1514 	lcall	_ak820_outline_0003
      00A99E C0 07            [24] 1515 	push	ar7
      00A9A0 C0 06            [24] 1516 	push	ar6
      00A9A2 C0 05            [24] 1517 	push	ar5
      00A9A4 C0 04            [24] 1518 	push	ar4
      00A9A6 12 A3 D5         [24] 1519 	lcall	_process_rgb
      00A9A9 E5 82            [12] 1520 	mov	a, dpl
      00A9AB D0 04            [24] 1521 	pop	ar4
      00A9AD D0 05            [24] 1522 	pop	ar5
      00A9AF D0 06            [24] 1523 	pop	ar6
      00A9B1 D0 07            [24] 1524 	pop	ar7
      00A9B3 60 1D            [24] 1525 	jz	00101$
                                   1526 ;	quantum/quantum.c:552: process_tri_layer(keycode, record) &&
      00A9B5 90 0C 74         [24] 1527 	mov	dptr,#_process_tri_layer_PARM_2
      00A9B8 12 AA 16         [24] 1528 	lcall	_ak820_outline_0003
      00A9BB C0 07            [24] 1529 	push	ar7
      00A9BD C0 06            [24] 1530 	push	ar6
      00A9BF C0 05            [24] 1531 	push	ar5
      00A9C1 C0 04            [24] 1532 	push	ar4
      00A9C3 12 A4 86         [24] 1533 	lcall	_process_tri_layer
      00A9C6 E5 82            [12] 1534 	mov	a, dpl
      00A9C8 D0 04            [24] 1535 	pop	ar4
      00A9CA D0 05            [24] 1536 	pop	ar5
      00A9CC D0 06            [24] 1537 	pop	ar6
      00A9CE D0 07            [24] 1538 	pop	ar7
      00A9D0 70 04            [24] 1539 	jnz	00102$
                                   1540 ;	quantum/quantum.c:554: true)) {
      00A9D2                       1541 00101$:
                                   1542 ;	quantum/quantum.c:555: return false;
      00A9D2 75 82 00         [24] 1543 	mov	dpl, #0x00
      00A9D5 22               [24] 1544 	ret
      00A9D6                       1545 00102$:
                                   1546 ;	quantum/quantum.c:558: if (record->event.pressed) {
      00A9D6 74 05            [12] 1547 	mov	a,#0x05
      00A9D8 12 4F 2B         [24] 1548 	lcall	_ak820_outline_0034
      00A9DB 60 30            [24] 1549 	jz	00118$
                                   1550 ;	quantum/quantum.c:559: switch (keycode) {
      00A9DD BC 00 05         [24] 1551 	cjne	r4,#0x00,00223$
      00A9E0 BD 7C 02         [24] 1552 	cjne	r5,#0x7c,00223$
      00A9E3 80 10            [24] 1553 	sjmp	00113$
      00A9E5                       1554 00223$:
      00A9E5 BC 01 05         [24] 1555 	cjne	r4,#0x01,00224$
      00A9E8 BD 7C 02         [24] 1556 	cjne	r5,#0x7c,00224$
      00A9EB 80 0F            [24] 1557 	sjmp	00114$
      00A9ED                       1558 00224$:
                                   1559 ;	quantum/quantum.c:561: case QK_BOOTLOADER:
      00A9ED BC 03 1D         [24] 1560 	cjne	r4,#0x03,00118$
      00A9F0 BD 7C 1A         [24] 1561 	cjne	r5,#0x7c,00118$
      00A9F3 80 0E            [24] 1562 	sjmp	00115$
      00A9F5                       1563 00113$:
                                   1564 ;	quantum/quantum.c:562: reset_keyboard();
      00A9F5 12 A6 C4         [24] 1565 	lcall	_reset_keyboard
                                   1566 ;	quantum/quantum.c:563: return false;
      00A9F8 75 82 00         [24] 1567 	mov	dpl, #0x00
                                   1568 ;	quantum/quantum.c:564: case QK_REBOOT:
      00A9FB 22               [24] 1569 	ret
      00A9FC                       1570 00114$:
                                   1571 ;	quantum/quantum.c:565: soft_reset_keyboard();
      00A9FC 12 A6 C9         [24] 1572 	lcall	_soft_reset_keyboard
                                   1573 ;	quantum/quantum.c:566: return false;
      00A9FF 75 82 00         [24] 1574 	mov	dpl, #0x00
                                   1575 ;	quantum/quantum.c:578: case QK_CLEAR_EEPROM:
      00AA02 22               [24] 1576 	ret
      00AA03                       1577 00115$:
                                   1578 ;	quantum/quantum.c:585: eeconfig_disable();
      00AA03 12 98 11         [24] 1579 	lcall	_eeconfig_disable
                                   1580 ;	quantum/quantum.c:586: soft_reset_keyboard();
      00AA06 12 A6 C9         [24] 1581 	lcall	_soft_reset_keyboard
                                   1582 ;	quantum/quantum.c:588: return false;
      00AA09 75 82 00         [24] 1583 	mov	dpl, #0x00
                                   1584 ;	quantum/quantum.c:643: }
      00AA0C 22               [24] 1585 	ret
      00AA0D                       1586 00118$:
                                   1587 ;	quantum/quantum.c:646: return process_action_kb(record);
      00AA0D 7D 00            [12] 1588 	mov	r5,#0x00
      00AA0F 12 7D 6C         [24] 1589 	lcall	_ak820_outline_0120
                                   1590 ;	quantum/quantum.c:647: }
      00AA12 02 A6 6C         [24] 1591 	ljmp	_process_action_kb
                                   1592 ;------------------------------------------------------------
                                   1593 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1594 ;------------------------------------------------------------
                                   1595 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_687'
                                   1596 ;------------------------------------------------------------
                                   1597 ;	quantum/quantum.c:649: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1598 ;	-----------------------------------------
                                   1599 ;	 function shutdown_user
                                   1600 ;	-----------------------------------------
      00AA15                       1601 _shutdown_user:
      00AA15 22               [24] 1602 	ret
                                   1603 ;------------------------------------------------------------
                                   1604 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1605 ;------------------------------------------------------------
                                   1606 ;	quantum/quantum.c:665: void suspend_power_down_quantum(void) {
                                   1607 ;	-----------------------------------------
                                   1608 	.area CSEG    (CODE)
                                   1609 	.area CONST   (CODE)
                                   1610 	.area XINIT   (CODE)
                                   1611 	.area CABS    (ABS,CODE)
                                   1612 
                                   1613 ; Experimental exact instruction outlining.
                                   1614 	.globl _ak820_outline_0002
                                   1615 	.globl _ak820_outline_0003
                                   1616 	.globl _ak820_outline_0006
                                   1617 	.globl _ak820_outline_0007
                                   1618 	.globl _ak820_outline_0011
                                   1619 	.globl _ak820_outline_0013
                                   1620 	.globl _ak820_outline_0022
                                   1621 	.globl _ak820_outline_0025
                                   1622 	.globl _ak820_outline_0029
                                   1623 	.globl _ak820_outline_0034
                                   1624 	.globl _ak820_outline_0036
                                   1625 	.globl _ak820_outline_0038
                                   1626 	.globl _ak820_outline_0041
                                   1627 	.globl _ak820_outline_0044
                                   1628 	.globl _ak820_outline_0057
                                   1629 	.globl _ak820_outline_0065
                                   1630 	.globl _ak820_outline_0070
                                   1631 	.globl _ak820_outline_0079
                                   1632 	.globl _ak820_outline_0114
                                   1633 	.globl _ak820_outline_0115
                                   1634 	.globl _ak820_outline_0120
                                   1635 	.globl _ak820_outline_0126
                                   1636 	.globl _ak820_outline_0127
                                   1637 	.globl _ak820_outline_0129
                                   1638 	.globl _ak820_outline_0134
                                   1639 	.globl _ak820_outline_0144
                                   1640 	.globl _ak820_outline_0153
                                   1641 	.globl _ak820_outline_0154
                                   1642 	.globl _ak820_outline_0160
                                   1643 
                                   1644 	.area CSEG (CODE)
                                   1645 ; function ak820_outline_0003
      00AA16                       1646 _ak820_outline_0003:
      00AA16 EE               [12] 1647 	mov	a,r6
      00AA17 F0               [24] 1648 	movx	@dptr,a
      00AA18 EF               [12] 1649 	mov	a,r7
      00AA19 A3               [24] 1650 	inc	dptr
      00AA1A F0               [24] 1651 	movx	@dptr,a
      00AA1B E4               [12] 1652 	clr	a
      00AA1C A3               [24] 1653 	inc	dptr
      00AA1D F0               [24] 1654 	movx	@dptr,a
      00AA1E 8C 82            [24] 1655 	mov	dpl,r4
      00AA20 8D 83            [24] 1656 	mov	dph,r5
      00AA22 22               [24] 1657 	ret
                                   1658 
                                   1659 	.area CSEG (CODE)
                                   1660 ; function ak820_outline_0011
      00AA23                       1661 _ak820_outline_0011:
      00AA23 EB               [12] 1662 	mov	a,r3
      00AA24 F0               [24] 1663 	movx	@dptr,a
      00AA25 EC               [12] 1664 	mov	a,r4
      00AA26 A3               [24] 1665 	inc	dptr
      00AA27 F0               [24] 1666 	movx	@dptr,a
      00AA28 ED               [12] 1667 	mov	a,r5
      00AA29 A3               [24] 1668 	inc	dptr
      00AA2A F0               [24] 1669 	movx	@dptr,a
      00AA2B 8E 82            [24] 1670 	mov	dpl,r6
      00AA2D 8F 83            [24] 1671 	mov	dph,r7
      00AA2F 22               [24] 1672 	ret
