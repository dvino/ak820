                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_key_override_reload
                                     12 	.globl _unregister_code16
                                     13 	.globl _register_code16
                                     14 	.globl _matrix_is_on
                                     15 	.globl _dynamic_keymap_set_key_override
                                     16 	.globl _dynamic_keymap_get_key_override
                                     17 	.globl _dynamic_keymap_set_combo
                                     18 	.globl _dynamic_keymap_get_combo
                                     19 	.globl _dynamic_keymap_set_encoder
                                     20 	.globl _dynamic_keymap_get_encoder
                                     21 	.globl _repeat_key_cancel
                                     22 	.globl _ak820_combo_reload
                                     23 	.globl _clear_keyboard
                                     24 	.globl _ak820_action_exec
                                     25 	.globl _timer_elapsed32
                                     26 	.globl _timer_read32
                                     27 	.globl _timer_read
                                     28 	.globl ___memcpy
                                     29 	.globl _ADC_START
                                     30 	.globl _S0_R_FIFO
                                     31 	.globl _S0_T_FIFO
                                     32 	.globl _S0_FREE
                                     33 	.globl _S0_IF_BYTE
                                     34 	.globl _S0_IF_FIRST
                                     35 	.globl _S0_IF_OV
                                     36 	.globl _S0_FST_ACT
                                     37 	.globl _CP_RL2
                                     38 	.globl _C_T2
                                     39 	.globl _TR2
                                     40 	.globl _EXEN2
                                     41 	.globl _TCLK
                                     42 	.globl _RCLK
                                     43 	.globl _EXF2
                                     44 	.globl _CAP1F
                                     45 	.globl _TF2
                                     46 	.globl _RI
                                     47 	.globl _TI
                                     48 	.globl _RB8
                                     49 	.globl _TB8
                                     50 	.globl _REN
                                     51 	.globl _SM2
                                     52 	.globl _SM1
                                     53 	.globl _SM0
                                     54 	.globl _IT0
                                     55 	.globl _IE0
                                     56 	.globl _IT1
                                     57 	.globl _IE1
                                     58 	.globl _TR0
                                     59 	.globl _TF0
                                     60 	.globl _TR1
                                     61 	.globl _TF1
                                     62 	.globl _P4_0
                                     63 	.globl _P4_1
                                     64 	.globl _P4_2
                                     65 	.globl _P4_3
                                     66 	.globl _P4_4
                                     67 	.globl _P4_5
                                     68 	.globl _P4_6
                                     69 	.globl _RXD
                                     70 	.globl _TXD
                                     71 	.globl _INT0
                                     72 	.globl _INT1
                                     73 	.globl _T0
                                     74 	.globl _T1
                                     75 	.globl _MOSI1
                                     76 	.globl _MISO1
                                     77 	.globl _SCK1
                                     78 	.globl _P3_0
                                     79 	.globl _P3_1
                                     80 	.globl _P3_2
                                     81 	.globl _P3_3
                                     82 	.globl _P3_4
                                     83 	.globl _P3_5
                                     84 	.globl _P3_6
                                     85 	.globl _P3_7
                                     86 	.globl _CAP1_
                                     87 	.globl _T2_
                                     88 	.globl _CAP2_
                                     89 	.globl _T2EX_
                                     90 	.globl _RXD1
                                     91 	.globl _TXD1
                                     92 	.globl _P2_0
                                     93 	.globl _P2_1
                                     94 	.globl _P2_2
                                     95 	.globl _P2_3
                                     96 	.globl _P2_4
                                     97 	.globl _P2_5
                                     98 	.globl _P2_6
                                     99 	.globl _P2_7
                                    100 	.globl _AIN0
                                    101 	.globl _AIN1
                                    102 	.globl _AIN2
                                    103 	.globl _AIN3
                                    104 	.globl _AIN4
                                    105 	.globl _AIN5
                                    106 	.globl _AIN6
                                    107 	.globl _AIN7
                                    108 	.globl _CAP1
                                    109 	.globl _T2
                                    110 	.globl _CAP2
                                    111 	.globl _T2EX
                                    112 	.globl _INT0_
                                    113 	.globl _SCS
                                    114 	.globl _MOSI
                                    115 	.globl _MISO
                                    116 	.globl _SCK
                                    117 	.globl _RXD1_
                                    118 	.globl _TXD1_
                                    119 	.globl _P1_0
                                    120 	.globl _P1_1
                                    121 	.globl _P1_2
                                    122 	.globl _P1_3
                                    123 	.globl _P1_4
                                    124 	.globl _P1_5
                                    125 	.globl _P1_6
                                    126 	.globl _P1_7
                                    127 	.globl _AIN8
                                    128 	.globl _AIN9
                                    129 	.globl _AIN10
                                    130 	.globl _AIN11
                                    131 	.globl _AIN12
                                    132 	.globl _AIN13
                                    133 	.globl _RXD_
                                    134 	.globl _TXD_
                                    135 	.globl _SCL0
                                    136 	.globl _SDA0
                                    137 	.globl _P0_0
                                    138 	.globl _P0_1
                                    139 	.globl _P0_2
                                    140 	.globl _P0_3
                                    141 	.globl _P0_4
                                    142 	.globl _P0_5
                                    143 	.globl _P0_6
                                    144 	.globl _P0_7
                                    145 	.globl _IE_SPI0
                                    146 	.globl _IE_USB
                                    147 	.globl _IE_ADC
                                    148 	.globl _IE_UART1
                                    149 	.globl _IE_PWM_I2C
                                    150 	.globl _IE_GPIO
                                    151 	.globl _IE_WDOG
                                    152 	.globl _PX0
                                    153 	.globl _PT0
                                    154 	.globl _PX1
                                    155 	.globl _PT1
                                    156 	.globl _PS
                                    157 	.globl _PT2
                                    158 	.globl _PL_FLAG
                                    159 	.globl _PH_FLAG
                                    160 	.globl _EX0
                                    161 	.globl _ET0
                                    162 	.globl _EX1
                                    163 	.globl _ET1
                                    164 	.globl _ES
                                    165 	.globl _ET2
                                    166 	.globl _E_DIS
                                    167 	.globl _EA
                                    168 	.globl _P
                                    169 	.globl _F1
                                    170 	.globl _OV
                                    171 	.globl _RS0
                                    172 	.globl _RS1
                                    173 	.globl _F0
                                    174 	.globl _AC
                                    175 	.globl _CY
                                    176 	.globl _I2CS_INT_ST
                                    177 	.globl _I2CX_INT
                                    178 	.globl _LED_STATUS
                                    179 	.globl _LED_DMA_H
                                    180 	.globl _LED_DMA_L
                                    181 	.globl _LED_DMA
                                    182 	.globl _LED_PWM_OE
                                    183 	.globl _LED_COMMON
                                    184 	.globl _ADC_CHAN
                                    185 	.globl _ADC_DAT_H
                                    186 	.globl _ADC_DAT_L
                                    187 	.globl _ADC_DAT
                                    188 	.globl _ADC_CTRL
                                    189 	.globl _SPI1_CK_SE
                                    190 	.globl _SPI1_CTRL
                                    191 	.globl _SPI1_DATA
                                    192 	.globl _SPI1_STAT
                                    193 	.globl _SIF1
                                    194 	.globl _SBAUD1
                                    195 	.globl _SBUF1
                                    196 	.globl _SCON1
                                    197 	.globl _SPI0_SETUP
                                    198 	.globl _SPI0_CK_SE
                                    199 	.globl _SPI0_CTRL
                                    200 	.globl _SPI0_DATA
                                    201 	.globl _SPI0_STAT
                                    202 	.globl _T2CAP1H
                                    203 	.globl _T2CAP1L
                                    204 	.globl _T2CAP1
                                    205 	.globl _TH2
                                    206 	.globl _TL2
                                    207 	.globl _T2COUNT
                                    208 	.globl _RCAP2H
                                    209 	.globl _RCAP2L
                                    210 	.globl _RCAP2
                                    211 	.globl _T2MOD
                                    212 	.globl _T2CON
                                    213 	.globl _SBUF
                                    214 	.globl _SCON
                                    215 	.globl _TH1
                                    216 	.globl _TH0
                                    217 	.globl _TL1
                                    218 	.globl _TL0
                                    219 	.globl _TMOD
                                    220 	.globl _TCON
                                    221 	.globl _XBUS_AUX
                                    222 	.globl _P7
                                    223 	.globl _P6_DIR
                                    224 	.globl _P6_OUT_PU
                                    225 	.globl _P6_IN
                                    226 	.globl _P5_DIR
                                    227 	.globl _P5_OUT_PU
                                    228 	.globl _P5_IN
                                    229 	.globl _P4_LED_KEY
                                    230 	.globl _P4_DIR_PU
                                    231 	.globl _P4_MOD_OC
                                    232 	.globl _P4
                                    233 	.globl _P3_DIR_PU
                                    234 	.globl _P3_MOD_OC
                                    235 	.globl _P3
                                    236 	.globl _P2_DIR_PU
                                    237 	.globl _P2_MOD_OC
                                    238 	.globl _P2
                                    239 	.globl _P1_DIR_PU
                                    240 	.globl _P1_MOD_OC
                                    241 	.globl _P1
                                    242 	.globl _P0_DIR_PU
                                    243 	.globl _P0_MOD_OC
                                    244 	.globl _P0
                                    245 	.globl _ROM_CTRL
                                    246 	.globl _ROM_DATA_HH
                                    247 	.globl _ROM_DATA_HL
                                    248 	.globl _ROM_DATA_HI
                                    249 	.globl _ROM_ADDR_H
                                    250 	.globl _ROM_ADDR_L
                                    251 	.globl _ROM_ADDR
                                    252 	.globl _GPIO_IE
                                    253 	.globl _IP_EX
                                    254 	.globl _IE_EX
                                    255 	.globl _IP
                                    256 	.globl _IE
                                    257 	.globl _WDOG_COUNT
                                    258 	.globl _RESET_KEEP
                                    259 	.globl _WAKE_CTRL
                                    260 	.globl _CLOCK_CFG
                                    261 	.globl _POWER_CFG
                                    262 	.globl _PCON
                                    263 	.globl _GLOBAL_CFG
                                    264 	.globl _SAFE_MOD
                                    265 	.globl _DPH
                                    266 	.globl _DPL
                                    267 	.globl _SP
                                    268 	.globl _A_INV
                                    269 	.globl _B
                                    270 	.globl _ACC
                                    271 	.globl _PSW
                                    272 	.globl _vial_unlock_in_progress
                                    273 	.globl _vial_unlocked
                                    274 	.globl _g_vial_magic_keycode_override
                                    275 	.globl _vial_handle_cmd_PARM_2
                                    276 	.globl _vial_unlock_task
                                    277 	.globl _vial_init
                                    278 	.globl _vial_handle_cmd
                                    279 	.globl _vial_keycode_down
                                    280 	.globl _vial_keycode_up
                                    281 	.globl _vial_keycode_tap
                                    282 ;--------------------------------------------------------
                                    283 ; special function registers
                                    284 ;--------------------------------------------------------
                                    285 	.area RSEG    (ABS,DATA)
      000000                        286 	.org 0x0000
                           0000D0   287 _PSW	=	0x00d0
                           0000E0   288 _ACC	=	0x00e0
                           0000F0   289 _B	=	0x00f0
                           0000FD   290 _A_INV	=	0x00fd
                           000081   291 _SP	=	0x0081
                           000082   292 _DPL	=	0x0082
                           000083   293 _DPH	=	0x0083
                           0000A1   294 _SAFE_MOD	=	0x00a1
                           0000B1   295 _GLOBAL_CFG	=	0x00b1
                           000087   296 _PCON	=	0x0087
                           0000BA   297 _POWER_CFG	=	0x00ba
                           0000B9   298 _CLOCK_CFG	=	0x00b9
                           0000A9   299 _WAKE_CTRL	=	0x00a9
                           0000FE   300 _RESET_KEEP	=	0x00fe
                           0000FF   301 _WDOG_COUNT	=	0x00ff
                           0000A8   302 _IE	=	0x00a8
                           0000B8   303 _IP	=	0x00b8
                           0000E8   304 _IE_EX	=	0x00e8
                           0000E9   305 _IP_EX	=	0x00e9
                           0000B2   306 _GPIO_IE	=	0x00b2
                           008584   307 _ROM_ADDR	=	0x8584
                           000084   308 _ROM_ADDR_L	=	0x0084
                           000085   309 _ROM_ADDR_H	=	0x0085
                           008F8E   310 _ROM_DATA_HI	=	0x8f8e
                           00008E   311 _ROM_DATA_HL	=	0x008e
                           00008F   312 _ROM_DATA_HH	=	0x008f
                           000086   313 _ROM_CTRL	=	0x0086
                           000080   314 _P0	=	0x0080
                           0000C4   315 _P0_MOD_OC	=	0x00c4
                           0000C5   316 _P0_DIR_PU	=	0x00c5
                           000090   317 _P1	=	0x0090
                           000092   318 _P1_MOD_OC	=	0x0092
                           000093   319 _P1_DIR_PU	=	0x0093
                           0000A0   320 _P2	=	0x00a0
                           000094   321 _P2_MOD_OC	=	0x0094
                           000095   322 _P2_DIR_PU	=	0x0095
                           0000B0   323 _P3	=	0x00b0
                           000096   324 _P3_MOD_OC	=	0x0096
                           000097   325 _P3_DIR_PU	=	0x0097
                           0000C0   326 _P4	=	0x00c0
                           0000C2   327 _P4_MOD_OC	=	0x00c2
                           0000C3   328 _P4_DIR_PU	=	0x00c3
                           0000C1   329 _P4_LED_KEY	=	0x00c1
                           0000AA   330 _P5_IN	=	0x00aa
                           0000AB   331 _P5_OUT_PU	=	0x00ab
                           0000AC   332 _P5_DIR	=	0x00ac
                           0000AD   333 _P6_IN	=	0x00ad
                           0000AE   334 _P6_OUT_PU	=	0x00ae
                           0000AF   335 _P6_DIR	=	0x00af
                           0000F1   336 _P7	=	0x00f1
                           0000A2   337 _XBUS_AUX	=	0x00a2
                           000088   338 _TCON	=	0x0088
                           000089   339 _TMOD	=	0x0089
                           00008A   340 _TL0	=	0x008a
                           00008B   341 _TL1	=	0x008b
                           00008C   342 _TH0	=	0x008c
                           00008D   343 _TH1	=	0x008d
                           000098   344 _SCON	=	0x0098
                           000099   345 _SBUF	=	0x0099
                           0000C8   346 _T2CON	=	0x00c8
                           0000C9   347 _T2MOD	=	0x00c9
                           00CBCA   348 _RCAP2	=	0xcbca
                           0000CA   349 _RCAP2L	=	0x00ca
                           0000CB   350 _RCAP2H	=	0x00cb
                           00CDCC   351 _T2COUNT	=	0xcdcc
                           0000CC   352 _TL2	=	0x00cc
                           0000CD   353 _TH2	=	0x00cd
                           00CFCE   354 _T2CAP1	=	0xcfce
                           0000CE   355 _T2CAP1L	=	0x00ce
                           0000CF   356 _T2CAP1H	=	0x00cf
                           0000F8   357 _SPI0_STAT	=	0x00f8
                           0000F9   358 _SPI0_DATA	=	0x00f9
                           0000FA   359 _SPI0_CTRL	=	0x00fa
                           0000FB   360 _SPI0_CK_SE	=	0x00fb
                           0000FC   361 _SPI0_SETUP	=	0x00fc
                           0000BC   362 _SCON1	=	0x00bc
                           0000BD   363 _SBUF1	=	0x00bd
                           0000BE   364 _SBAUD1	=	0x00be
                           0000BF   365 _SIF1	=	0x00bf
                           0000B4   366 _SPI1_STAT	=	0x00b4
                           0000B5   367 _SPI1_DATA	=	0x00b5
                           0000B6   368 _SPI1_CTRL	=	0x00b6
                           0000B7   369 _SPI1_CK_SE	=	0x00b7
                           0000F3   370 _ADC_CTRL	=	0x00f3
                           00F5F4   371 _ADC_DAT	=	0xf5f4
                           0000F4   372 _ADC_DAT_L	=	0x00f4
                           0000F5   373 _ADC_DAT_H	=	0x00f5
                           0000F6   374 _ADC_CHAN	=	0x00f6
                           0000A6   375 _LED_COMMON	=	0x00a6
                           0000A7   376 _LED_PWM_OE	=	0x00a7
                           00C7C6   377 _LED_DMA	=	0xc7c6
                           0000C6   378 _LED_DMA_L	=	0x00c6
                           0000C7   379 _LED_DMA_H	=	0x00c7
                           0000F7   380 _LED_STATUS	=	0x00f7
                           0000B3   381 _I2CX_INT	=	0x00b3
                           0000BB   382 _I2CS_INT_ST	=	0x00bb
                                    383 ;--------------------------------------------------------
                                    384 ; special function bits
                                    385 ;--------------------------------------------------------
                                    386 	.area RSEG    (ABS,DATA)
      000000                        387 	.org 0x0000
                           0000D7   388 _CY	=	0x00d7
                           0000D6   389 _AC	=	0x00d6
                           0000D5   390 _F0	=	0x00d5
                           0000D4   391 _RS1	=	0x00d4
                           0000D3   392 _RS0	=	0x00d3
                           0000D2   393 _OV	=	0x00d2
                           0000D1   394 _F1	=	0x00d1
                           0000D0   395 _P	=	0x00d0
                           0000AF   396 _EA	=	0x00af
                           0000AE   397 _E_DIS	=	0x00ae
                           0000AD   398 _ET2	=	0x00ad
                           0000AC   399 _ES	=	0x00ac
                           0000AB   400 _ET1	=	0x00ab
                           0000AA   401 _EX1	=	0x00aa
                           0000A9   402 _ET0	=	0x00a9
                           0000A8   403 _EX0	=	0x00a8
                           0000BF   404 _PH_FLAG	=	0x00bf
                           0000BE   405 _PL_FLAG	=	0x00be
                           0000BD   406 _PT2	=	0x00bd
                           0000BC   407 _PS	=	0x00bc
                           0000BB   408 _PT1	=	0x00bb
                           0000BA   409 _PX1	=	0x00ba
                           0000B9   410 _PT0	=	0x00b9
                           0000B8   411 _PX0	=	0x00b8
                           0000EF   412 _IE_WDOG	=	0x00ef
                           0000EE   413 _IE_GPIO	=	0x00ee
                           0000ED   414 _IE_PWM_I2C	=	0x00ed
                           0000EC   415 _IE_UART1	=	0x00ec
                           0000EB   416 _IE_ADC	=	0x00eb
                           0000E9   417 _IE_USB	=	0x00e9
                           0000E8   418 _IE_SPI0	=	0x00e8
                           000087   419 _P0_7	=	0x0087
                           000086   420 _P0_6	=	0x0086
                           000085   421 _P0_5	=	0x0085
                           000084   422 _P0_4	=	0x0084
                           000083   423 _P0_3	=	0x0083
                           000082   424 _P0_2	=	0x0082
                           000081   425 _P0_1	=	0x0081
                           000080   426 _P0_0	=	0x0080
                           000081   427 _SDA0	=	0x0081
                           000080   428 _SCL0	=	0x0080
                           000083   429 _TXD_	=	0x0083
                           000082   430 _RXD_	=	0x0082
                           000085   431 _AIN13	=	0x0085
                           000084   432 _AIN12	=	0x0084
                           000083   433 _AIN11	=	0x0083
                           000082   434 _AIN10	=	0x0082
                           000081   435 _AIN9	=	0x0081
                           000080   436 _AIN8	=	0x0080
                           000097   437 _P1_7	=	0x0097
                           000096   438 _P1_6	=	0x0096
                           000095   439 _P1_5	=	0x0095
                           000094   440 _P1_4	=	0x0094
                           000093   441 _P1_3	=	0x0093
                           000092   442 _P1_2	=	0x0092
                           000091   443 _P1_1	=	0x0091
                           000090   444 _P1_0	=	0x0090
                           000097   445 _TXD1_	=	0x0097
                           000096   446 _RXD1_	=	0x0096
                           000097   447 _SCK	=	0x0097
                           000096   448 _MISO	=	0x0096
                           000095   449 _MOSI	=	0x0095
                           000094   450 _SCS	=	0x0094
                           000092   451 _INT0_	=	0x0092
                           000091   452 _T2EX	=	0x0091
                           000091   453 _CAP2	=	0x0091
                           000090   454 _T2	=	0x0090
                           000090   455 _CAP1	=	0x0090
                           000097   456 _AIN7	=	0x0097
                           000096   457 _AIN6	=	0x0096
                           000095   458 _AIN5	=	0x0095
                           000094   459 _AIN4	=	0x0094
                           000093   460 _AIN3	=	0x0093
                           000092   461 _AIN2	=	0x0092
                           000091   462 _AIN1	=	0x0091
                           000090   463 _AIN0	=	0x0090
                           0000A7   464 _P2_7	=	0x00a7
                           0000A6   465 _P2_6	=	0x00a6
                           0000A5   466 _P2_5	=	0x00a5
                           0000A4   467 _P2_4	=	0x00a4
                           0000A3   468 _P2_3	=	0x00a3
                           0000A2   469 _P2_2	=	0x00a2
                           0000A1   470 _P2_1	=	0x00a1
                           0000A0   471 _P2_0	=	0x00a0
                           0000A7   472 _TXD1	=	0x00a7
                           0000A6   473 _RXD1	=	0x00a6
                           0000A5   474 _T2EX_	=	0x00a5
                           0000A5   475 _CAP2_	=	0x00a5
                           0000A4   476 _T2_	=	0x00a4
                           0000A4   477 _CAP1_	=	0x00a4
                           0000B7   478 _P3_7	=	0x00b7
                           0000B6   479 _P3_6	=	0x00b6
                           0000B5   480 _P3_5	=	0x00b5
                           0000B4   481 _P3_4	=	0x00b4
                           0000B3   482 _P3_3	=	0x00b3
                           0000B2   483 _P3_2	=	0x00b2
                           0000B1   484 _P3_1	=	0x00b1
                           0000B0   485 _P3_0	=	0x00b0
                           0000B7   486 _SCK1	=	0x00b7
                           0000B6   487 _MISO1	=	0x00b6
                           0000B5   488 _MOSI1	=	0x00b5
                           0000B5   489 _T1	=	0x00b5
                           0000B4   490 _T0	=	0x00b4
                           0000B3   491 _INT1	=	0x00b3
                           0000B2   492 _INT0	=	0x00b2
                           0000B1   493 _TXD	=	0x00b1
                           0000B0   494 _RXD	=	0x00b0
                           0000C6   495 _P4_6	=	0x00c6
                           0000C5   496 _P4_5	=	0x00c5
                           0000C4   497 _P4_4	=	0x00c4
                           0000C3   498 _P4_3	=	0x00c3
                           0000C2   499 _P4_2	=	0x00c2
                           0000C1   500 _P4_1	=	0x00c1
                           0000C0   501 _P4_0	=	0x00c0
                           00008F   502 _TF1	=	0x008f
                           00008E   503 _TR1	=	0x008e
                           00008D   504 _TF0	=	0x008d
                           00008C   505 _TR0	=	0x008c
                           00008B   506 _IE1	=	0x008b
                           00008A   507 _IT1	=	0x008a
                           000089   508 _IE0	=	0x0089
                           000088   509 _IT0	=	0x0088
                           00009F   510 _SM0	=	0x009f
                           00009E   511 _SM1	=	0x009e
                           00009D   512 _SM2	=	0x009d
                           00009C   513 _REN	=	0x009c
                           00009B   514 _TB8	=	0x009b
                           00009A   515 _RB8	=	0x009a
                           000099   516 _TI	=	0x0099
                           000098   517 _RI	=	0x0098
                           0000CF   518 _TF2	=	0x00cf
                           0000CF   519 _CAP1F	=	0x00cf
                           0000CE   520 _EXF2	=	0x00ce
                           0000CD   521 _RCLK	=	0x00cd
                           0000CC   522 _TCLK	=	0x00cc
                           0000CB   523 _EXEN2	=	0x00cb
                           0000CA   524 _TR2	=	0x00ca
                           0000C9   525 _C_T2	=	0x00c9
                           0000C8   526 _CP_RL2	=	0x00c8
                           0000FF   527 _S0_FST_ACT	=	0x00ff
                           0000FE   528 _S0_IF_OV	=	0x00fe
                           0000FD   529 _S0_IF_FIRST	=	0x00fd
                           0000FC   530 _S0_IF_BYTE	=	0x00fc
                           0000FB   531 _S0_FREE	=	0x00fb
                           0000FA   532 _S0_T_FIFO	=	0x00fa
                           0000F8   533 _S0_R_FIFO	=	0x00f8
                           0000F7   534 _ADC_START	=	0x00f7
                                    535 ;--------------------------------------------------------
                                    536 ; overlayable register banks
                                    537 ;--------------------------------------------------------
                                    538 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        539 	.ds 8
                                    540 ;--------------------------------------------------------
                                    541 ; internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area DSEG    (DATA)
      000052                        544 _vial_handle_cmd_sloc0_1_0:
      000052                        545 	.ds 2
      000054                        546 _vial_handle_cmd_sloc1_1_0:
      000054                        547 	.ds 2
      000056                        548 _vial_handle_cmd_sloc2_1_0:
      000056                        549 	.ds 2
      000058                        550 _vial_handle_cmd_sloc3_1_0:
      000058                        551 	.ds 2
                                    552 ;--------------------------------------------------------
                                    553 ; overlayable items in internal ram
                                    554 ;--------------------------------------------------------
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
                                    568 ;--------------------------------------------------------
                                    569 ; paged external ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area PSEG    (PAG,XDATA)
                                    572 ;--------------------------------------------------------
                                    573 ; uninitialized external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XSEG    (XDATA)
      000CF9                        576 _vial_unlock_timer:
      000CF9                        577 	.ds 4
      000CFD                        578 _vial_unlock_holding:
      000CFD                        579 	.ds 1
      000CFE                        580 _vial_keycode_firewall_in_10000_619:
      000CFE                        581 	.ds 2
      000D00                        582 _vial_fill_packet_PARM_2:
      000D00                        583 	.ds 1
      000D01                        584 _vial_fill_packet_msg_10000_622:
      000D01                        585 	.ds 2
      000D03                        586 _vial_handle_cmd_PARM_2:
      000D03                        587 	.ds 1
      000D04                        588 _vial_handle_cmd_data_10000_627:
      000D04                        589 	.ds 3
      000D07                        590 _vial_handle_cmd_entry_70000_655:
      000D07                        591 	.ds 10
      000D11                        592 _vial_handle_cmd_entry_70000_656:
      000D11                        593 	.ds 10
      000D1B                        594 _vial_handle_cmd_entry_70000_658:
      000D1B                        595 	.ds 10
      000D25                        596 _vial_handle_cmd_entry_70000_659:
      000D25                        597 	.ds 10
      000D2F                        598 _g_vial_magic_keycode_override::
      000D2F                        599 	.ds 2
      000D31                        600 _vial_keycode_down_keycode_10000_661:
      000D31                        601 	.ds 2
      000D33                        602 _vial_keycode_down_dummy_event_30000_668:
      000D33                        603 	.ds 6
      000D39                        604 _vial_keycode_up_keycode_10000_669:
      000D39                        605 	.ds 2
      000D3B                        606 _vial_keycode_up_dummy_event_30000_676:
      000D3B                        607 	.ds 6
      000D41                        608 _vial_keycode_tap_keycode_10000_677:
      000D41                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
      000EDA                        618 _vial_unlocked::
      000EDA                        619 	.ds 1
      000EDB                        620 _vial_unlock_in_progress::
      000EDB                        621 	.ds 1
      000EDC                        622 _vial_unlock_counter:
      000EDC                        623 	.ds 1
      000EDD                        624 _vial_unlock_combo_rows:
      000EDD                        625 	.ds 2
      000EDF                        626 _vial_unlock_combo_cols:
      000EDF                        627 	.ds 2
                                    628 	.area HOME    (CODE)
                                    629 	.area GSINIT0 (CODE)
                                    630 	.area GSINIT1 (CODE)
                                    631 	.area GSINIT2 (CODE)
                                    632 	.area GSINIT3 (CODE)
                                    633 	.area GSINIT4 (CODE)
                                    634 	.area GSINIT5 (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area CSEG    (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; global & static initialisations
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area GSINIT  (CODE)
                                    643 	.area GSFINAL (CODE)
                                    644 	.area GSINIT  (CODE)
                                    645 ;--------------------------------------------------------
                                    646 ; Home
                                    647 ;--------------------------------------------------------
                                    648 	.area HOME    (CODE)
                                    649 	.area HOME    (CODE)
                                    650 ;--------------------------------------------------------
                                    651 ; code
                                    652 ;--------------------------------------------------------
                                    653 	.area CSEG    (CODE)
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    656 ;------------------------------------------------------------
                                    657 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    658 ;------------------------------------------------------------
                                    659 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    660 ;	-----------------------------------------
                           000007   661 	ar7 = 0x07
                           000006   662 	ar6 = 0x06
                           000005   663 	ar5 = 0x05
                           000004   664 	ar4 = 0x04
                           000003   665 	ar3 = 0x03
                           000002   666 	ar2 = 0x02
                           000001   667 	ar1 = 0x01
                           000000   668 	ar0 = 0x00
                                    669 ;	 function vial_unlock_task
                                    670 ;	-----------------------------------------
      00B525                        671 _vial_unlock_task:
                                    672 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B525 90 0E DB         [24]  673 	mov	dptr,#_vial_unlock_in_progress
      00B528 E0               [24]  674 	movx	a,@dptr
      00B529 70 01            [24]  675 	jnz	00131$
      00B52B 22               [24]  676 	ret
                                    677 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B52C                        678 00131$:
      00B52C 7F 00            [12]  679 	mov	r7,#0x00
      00B52E                        680 00115$:
      00B52E BF 02 00         [24]  681 	cjne	r7,#0x02,00184$
      00B531                        682 00184$:
      00B531 50 29            [24]  683 	jnc	00105$
                                    684 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B533 EF               [12]  685 	mov	a,r7
      00B534 12 BB BE         [24]  686 	lcall	_ak820_outline_0138
      00B537 FE               [12]  687 	mov	r6,a
      00B538 EF               [12]  688 	mov	a,r7
      00B539 12 BB B3         [24]  689 	lcall	_ak820_outline_0137
      00B53C 90 07 CD         [24]  690 	mov	dptr,#_matrix_is_on_PARM_2
      00B53F F0               [24]  691 	movx	@dptr,a
      00B540 8E 82            [24]  692 	mov	dpl, r6
      00B542 C0 07            [24]  693 	push	ar7
      00B544 12 5F CE         [24]  694 	lcall	_matrix_is_on
      00B547 E5 82            [12]  695 	mov	a, dpl
      00B549 D0 07            [24]  696 	pop	ar7
      00B54B 70 0C            [24]  697 	jnz	00116$
                                    698 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B54D 90 0C FD         [24]  699 	mov	dptr,#_vial_unlock_holding
      00B550 E4               [12]  700 	clr	a
      00B551 F0               [24]  701 	movx	@dptr,a
                                    702 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B552 90 0E DC         [24]  703 	mov	dptr,#_vial_unlock_counter
      00B555 74 1E            [12]  704 	mov	a,#0x1e
      00B557 F0               [24]  705 	movx	@dptr,a
                                    706 ;	quantum/vial.c:69: return;
      00B558 22               [24]  707 	ret
      00B559                        708 00116$:
                                    709 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B559 0F               [12]  710 	inc	r7
      00B55A 80 D2            [24]  711 	sjmp	00115$
      00B55C                        712 00105$:
                                    713 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B55C 90 0C FD         [24]  714 	mov	dptr,#_vial_unlock_holding
      00B55F E0               [24]  715 	movx	a,@dptr
      00B560 70 12            [24]  716 	jnz	00107$
                                    717 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B562 90 0C FD         [24]  718 	mov	dptr,#_vial_unlock_holding
      00B565 74 01            [12]  719 	mov	a,#0x01
      00B567 F0               [24]  720 	movx	@dptr,a
                                    721 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B568 12 4F C3         [24]  722 	lcall	_timer_read32
      00B56B 12 55 D5         [24]  723 	lcall	_ak820_outline_0062
      00B56E 90 0C F9         [24]  724 	mov	dptr,#_vial_unlock_timer
      00B571 12 98 AA         [24]  725 	lcall	_ak820_outline_0008
      00B574                        726 00107$:
                                    727 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B574 90 0C F9         [24]  728 	mov	dptr,#_vial_unlock_timer
      00B577 12 55 C4         [24]  729 	lcall	_ak820_outline_0060
      00B57A 12 50 1C         [24]  730 	lcall	_timer_elapsed32
      00B57D 12 55 D5         [24]  731 	lcall	_ak820_outline_0062
                                    732 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B580 7B 1E            [12]  733 	mov	r3,#0x1e
      00B582                        734 00109$:
      00B582 EB               [12]  735 	mov	a,r3
      00B583 60 22            [24]  736 	jz	00111$
      00B585 C3               [12]  737 	clr	c
      00B586 EC               [12]  738 	mov	a,r4
      00B587 94 64            [12]  739 	subb	a,#0x64
      00B589 ED               [12]  740 	mov	a,r5
      00B58A 94 00            [12]  741 	subb	a,#0x00
      00B58C EE               [12]  742 	mov	a,r6
      00B58D 94 00            [12]  743 	subb	a,#0x00
      00B58F EF               [12]  744 	mov	a,r7
      00B590 94 00            [12]  745 	subb	a,#0x00
      00B592 40 13            [24]  746 	jc	00111$
                                    747 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B594 EC               [12]  748 	mov	a,r4
      00B595 24 9C            [12]  749 	add	a,#0x9c
      00B597 FC               [12]  750 	mov	r4,a
      00B598 ED               [12]  751 	mov	a,r5
      00B599 34 FF            [12]  752 	addc	a,#0xff
      00B59B FD               [12]  753 	mov	r5,a
      00B59C EE               [12]  754 	mov	a,r6
      00B59D 34 FF            [12]  755 	addc	a,#0xff
      00B59F FE               [12]  756 	mov	r6,a
      00B5A0 EF               [12]  757 	mov	a,r7
      00B5A1 34 FF            [12]  758 	addc	a,#0xff
      00B5A3 FF               [12]  759 	mov	r7,a
                                    760 ;	quantum/vial.c:82: --counter;
      00B5A4 1B               [12]  761 	dec	r3
      00B5A5 80 DB            [24]  762 	sjmp	00109$
      00B5A7                        763 00111$:
                                    764 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B5A7 90 0E DC         [24]  765 	mov	dptr,#_vial_unlock_counter
      00B5AA EB               [12]  766 	mov	a,r3
      00B5AB F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:85: if (!counter) {
      00B5AC EB               [12]  769 	mov	a,r3
      00B5AD 70 0A            [24]  770 	jnz	00117$
                                    771 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B5AF 90 0E DB         [24]  772 	mov	dptr,#_vial_unlock_in_progress
      00B5B2 E4               [12]  773 	clr	a
      00B5B3 F0               [24]  774 	movx	@dptr,a
                                    775 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B5B4 90 0E DA         [24]  776 	mov	dptr,#_vial_unlocked
      00B5B7 04               [12]  777 	inc	a
      00B5B8 F0               [24]  778 	movx	@dptr,a
      00B5B9                        779 00117$:
                                    780 ;	quantum/vial.c:90: }
      00B5B9 22               [24]  781 	ret
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'vial_init'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/vial.c:117: void vial_init(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function vial_init
                                    788 ;	-----------------------------------------
      00B5BA                        789 _vial_init:
                                    790 ;	quantum/vial.c:125: reload_combo();
      00B5BA 12 35 7A         [24]  791 	lcall	_ak820_combo_reload
                                    792 ;	quantum/vial.c:128: reload_key_override();
                                    793 ;	quantum/vial.c:130: }
      00B5BD 02 3D A4         [24]  794 	ljmp	_ak820_key_override_reload
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    797 ;------------------------------------------------------------
                                    798 ;in            Allocated with name '_vial_keycode_firewall_in_10000_619'
                                    799 ;------------------------------------------------------------
                                    800 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    801 ;	-----------------------------------------
                                    802 ;	 function vial_keycode_firewall
                                    803 ;	-----------------------------------------
      00B5C0                        804 _vial_keycode_firewall:
      00B5C0 12 38 86         [24]  805 	lcall	_ak820_outline_0114
      00B5C3 90 0C FE         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_619
      00B5C6 12 38 8B         [24]  807 	lcall	_ak820_outline_0115
                                    808 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B5C9 90 0C FE         [24]  809 	mov	dptr,#_vial_keycode_firewall_in_10000_619
      00B5CC 12 4E EC         [24]  810 	lcall	_ak820_outline_0010
      00B5CF BC 00 0D         [24]  811 	cjne	r4,#0x00,00102$
      00B5D2 BD 7C 0A         [24]  812 	cjne	r5,#0x7c,00102$
      00B5D5 90 0E DA         [24]  813 	mov	dptr,#_vial_unlocked
      00B5D8 E0               [24]  814 	movx	a,@dptr
      00B5D9 70 04            [24]  815 	jnz	00102$
                                    816 ;	quantum/vial.c:134: return 0;
      00B5DB 90 00 00         [24]  817 	mov	dptr,#0x0000
      00B5DE 22               [24]  818 	ret
      00B5DF                        819 00102$:
                                    820 ;	quantum/vial.c:135: return in;
      00B5DF 12 38 90         [24]  821 	lcall	_ak820_outline_0126
                                    822 ;	quantum/vial.c:136: }
      00B5E2 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'vial_fill_packet'
                                    826 ;------------------------------------------------------------
                                    827 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    828 ;msg           Allocated with name '_vial_fill_packet_msg_10000_622'
                                    829 ;i             Allocated with name '_vial_fill_packet_i_20000_624'
                                    830 ;------------------------------------------------------------
                                    831 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    832 ;	-----------------------------------------
                                    833 ;	 function vial_fill_packet
                                    834 ;	-----------------------------------------
      00B5E3                        835 _vial_fill_packet:
      00B5E3 12 38 86         [24]  836 	lcall	_ak820_outline_0114
      00B5E6 90 0D 01         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_622
      00B5E9 12 38 8B         [24]  838 	lcall	_ak820_outline_0115
                                    839 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B5EC 90 0D 01         [24]  840 	mov	dptr,#_vial_fill_packet_msg_10000_622
      00B5EF 12 38 39         [24]  841 	lcall	_ak820_outline_0057
      00B5F2 90 0D 00         [24]  842 	mov	dptr,#_vial_fill_packet_PARM_2
      00B5F5 E0               [24]  843 	movx	a,@dptr
      00B5F6 FD               [12]  844 	mov	r5,a
      00B5F7 7C 00            [12]  845 	mov	r4,#0x00
      00B5F9                        846 00103$:
      00B5F9 BC 20 00         [24]  847 	cjne	r4,#0x20,00122$
      00B5FC                        848 00122$:
      00B5FC 50 09            [24]  849 	jnc	00105$
      00B5FE EC               [12]  850 	mov	a,r4
      00B5FF 12 38 29         [24]  851 	lcall	_ak820_outline_0036
      00B602 ED               [12]  852 	mov	a,r5
      00B603 F0               [24]  853 	movx	@dptr,a
      00B604 0C               [12]  854 	inc	r4
      00B605 80 F2            [24]  855 	sjmp	00103$
      00B607                        856 00105$:
                                    857 ;	quantum/vial.c:141: }
      00B607 22               [24]  858 	ret
                                    859 ;------------------------------------------------------------
                                    860 ;Allocation info for local variables in function 'vial_release_held_state'
                                    861 ;------------------------------------------------------------
                                    862 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    863 ;	-----------------------------------------
                                    864 ;	 function vial_release_held_state
                                    865 ;	-----------------------------------------
      00B608                        866 _vial_release_held_state:
                                    867 ;	quantum/vial.c:174: repeat_key_cancel();
      00B608 12 AA 30         [24]  868 	lcall	_repeat_key_cancel
                                    869 ;	quantum/vial.c:176: clear_keyboard();
                                    870 ;	quantum/vial.c:177: }
      00B60B 02 7C D2         [24]  871 	ljmp	_clear_keyboard
                                    872 ;------------------------------------------------------------
                                    873 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    874 ;------------------------------------------------------------
                                    875 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    876 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    877 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    878 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    879 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    880 ;data          Allocated with name '_vial_handle_cmd_data_10000_627'
                                    881 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_628'
                                    882 ;i             Allocated with name '_vial_handle_cmd_i_50000_633'
                                    883 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_634'
                                    884 ;page          Allocated with name '_vial_handle_cmd_page_40001_637'
                                    885 ;start         Allocated with name '_vial_handle_cmd_start_40002_639'
                                    886 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_639'
                                    887 ;count         Allocated with name '_vial_handle_cmd_count_40002_639'
                                    888 ;i             Allocated with name '_vial_handle_cmd_i_50002_640'
                                    889 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_641'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_641'
                                    891 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_641'
                                    892 ;i             Allocated with name '_vial_handle_cmd_i_50000_644'
                                    893 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_655'
                                    894 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_655'
                                    895 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_656'
                                    896 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_656'
                                    897 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_658'
                                    898 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_658'
                                    899 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_659'
                                    900 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_659'
                                    901 ;------------------------------------------------------------
                                    902 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    903 ;	-----------------------------------------
                                    904 ;	 function vial_handle_cmd
                                    905 ;	-----------------------------------------
      00B60E                        906 _vial_handle_cmd:
      00B60E 12 49 D5         [24]  907 	lcall	_ak820_outline_0041
      00B611 90 0D 04         [24]  908 	mov	dptr,#_vial_handle_cmd_data_10000_627
      00B614 12 38 21         [24]  909 	lcall	_ak820_outline_0022
                                    910 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B617 90 0D 04         [24]  911 	mov	dptr,#_vial_handle_cmd_data_10000_627
      00B61A 12 38 39         [24]  912 	lcall	_ak820_outline_0057
                                    913 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B61D 90 0D 03         [24]  914 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B620 E0               [24]  915 	movx	a,@dptr
      00B621 FD               [12]  916 	mov	r5,a
      00B622 BD 20 02         [24]  917 	cjne	r5,#0x20,00255$
      00B625 80 01            [24]  918 	sjmp	00102$
      00B627                        919 00255$:
                                    920 ;	quantum/vial.c:190: return;
      00B627 22               [24]  921 	ret
      00B628                        922 00102$:
                                    923 ;	quantum/vial.c:193: switch (msg[1]) {
      00B628 74 01            [12]  924 	mov	a,#0x01
      00B62A 12 4F 36         [24]  925 	lcall	_ak820_outline_0035
      00B62D FB               [12]  926 	mov  r3,a
      00B62E 24 F2            [12]  927 	add	a,#0xff - 0x0d
      00B630 50 01            [24]  928 	jnc	00256$
      00B632 22               [24]  929 	ret
      00B633                        930 00256$:
                                    931 ;	free result
      00B633 EB               [12]  932 	mov	a,r3
      00B634 24 0A            [12]  933 	add	a,#(00257$-3-.)
      00B636 83               [24]  934 	movc	a,@a+pc
      00B637 F5 82            [12]  935 	mov	dpl,a
      00B639 EB               [12]  936 	mov	a,r3
      00B63A 24 12            [12]  937 	add	a,#(00258$-3-.)
      00B63C 83               [24]  938 	movc	a,@a+pc
      00B63D F5 83            [12]  939 	mov	dph,a
      00B63F E4               [12]  940 	clr	a
      00B640 73               [24]  941 	jmp	@a+dptr
      00B641                        942 00257$:
      00B641 5D                     943 	.db	00103$
      00B642 A5                     944 	.db	00105$
      00B643 B9                     945 	.db	00106$
      00B644 44                     946 	.db	00112$
      00B645 CA                     947 	.db	00113$
      00B646 13                     948 	.db	00114$
      00B647 82                     949 	.db	00116$
      00B648 9D                     950 	.db	00119$
      00B649 BD                     951 	.db	00120$
      00B64A CB                     952 	.db	00121$
      00B64B A1                     953 	.db	00143$
      00B64C A1                     954 	.db	00143$
      00B64D A1                     955 	.db	00143$
      00B64E D6                     956 	.db	00122$
      00B64F                        957 00258$:
      00B64F B6                     958 	.db	00103$>>8
      00B650 B6                     959 	.db	00105$>>8
      00B651 B6                     960 	.db	00106$>>8
      00B652 B7                     961 	.db	00112$>>8
      00B653 B7                     962 	.db	00113$>>8
      00B654 B8                     963 	.db	00114$>>8
      00B655 B8                     964 	.db	00116$>>8
      00B656 B8                     965 	.db	00119$>>8
      00B657 B8                     966 	.db	00120$>>8
      00B658 B8                     967 	.db	00121$>>8
      00B659 BA                     968 	.db	00143$>>8
      00B65A BA                     969 	.db	00143$>>8
      00B65B BA                     970 	.db	00143$>>8
      00B65C B8                     971 	.db	00122$>>8
                                    972 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B65D                        973 00103$:
                                    974 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B65D 90 0D 00         [24]  975 	mov	dptr,#_vial_fill_packet_PARM_2
      00B660 E4               [12]  976 	clr	a
      00B661 12 4A 00         [24]  977 	lcall	_ak820_outline_0070
      00B664 C0 07            [24]  978 	push	ar7
      00B666 C0 06            [24]  979 	push	ar6
      00B668 12 B5 E3         [24]  980 	lcall	_vial_fill_packet
      00B66B D0 06            [24]  981 	pop	ar6
      00B66D D0 07            [24]  982 	pop	ar7
                                    983 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B66F 12 38 90         [24]  984 	lcall	_ak820_outline_0126
      00B672 74 06            [12]  985 	mov	a,#0x06
      00B674 12 4A 00         [24]  986 	lcall	_ak820_outline_0070
                                    987 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B677 A3               [24]  988 	inc	dptr
      00B678 E4               [12]  989 	clr	a
      00B679 12 49 CD         [24]  990 	lcall	_ak820_outline_0027
                                    991 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B67C 12 49 CD         [24]  992 	lcall	_ak820_outline_0027
                                    993 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B67F A3               [24]  994 	inc	dptr
      00B680 F0               [24]  995 	movx	@dptr,a
                                    996 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B681 FB               [12]  997 	mov	r3,a
      00B682                        998 00135$:
      00B682 BB 08 00         [24]  999 	cjne	r3,#0x08,00259$
      00B685                       1000 00259$:
      00B685 50 15            [24] 1001 	jnc	00104$
      00B687 8B 02            [24] 1002 	mov	ar2,r3
      00B689 74 04            [12] 1003 	mov	a,#0x04
      00B68B 2A               [12] 1004 	add	a, r2
      00B68C 2E               [12] 1005 	add	a, r6
      00B68D F9               [12] 1006 	mov	r1,a
      00B68E E4               [12] 1007 	clr	a
      00B68F 3F               [12] 1008 	addc	a,r7
      00B690 FA               [12] 1009 	mov	r2,a
      00B691 EB               [12] 1010 	mov	a,r3
      00B692 90 C8 5F         [24] 1011 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_632
      00B695 93               [24] 1012 	movc	a,@a+dptr
      00B696 12 72 BF         [24] 1013 	lcall	_ak820_outline_0150
      00B699 0B               [12] 1014 	inc	r3
      00B69A 80 E6            [24] 1015 	sjmp	00135$
      00B69C                       1016 00104$:
                                   1017 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B69C 74 0C            [12] 1018 	mov	a,#0x0c
      00B69E 12 38 29         [24] 1019 	lcall	_ak820_outline_0036
      00B6A1 74 01            [12] 1020 	mov	a,#0x01
      00B6A3 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	quantum/vial.c:207: break;
      00B6A4 22               [24] 1023 	ret
                                   1024 ;	quantum/vial.c:210: case vial_get_size: {
      00B6A5                       1025 00105$:
                                   1026 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B6A5 12 38 90         [24] 1027 	lcall	_ak820_outline_0126
      00B6A8 74 7C            [12] 1028 	mov	a,#0x7c
      00B6AA 12 38 7A         [24] 1029 	lcall	_ak820_outline_0109
                                   1030 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B6AD 74 01            [12] 1031 	mov	a,#0x01
      00B6AF 12 49 CD         [24] 1032 	lcall	_ak820_outline_0027
                                   1033 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B6B2 E4               [12] 1034 	clr	a
      00B6B3 12 49 CD         [24] 1035 	lcall	_ak820_outline_0027
                                   1036 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B6B6 A3               [24] 1037 	inc	dptr
      00B6B7 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	quantum/vial.c:216: break;
      00B6B8 22               [24] 1040 	ret
                                   1041 ;	quantum/vial.c:219: case vial_get_def: {
      00B6B9                       1042 00106$:
                                   1043 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B6B9 12 42 0C         [24] 1044 	lcall	_ak820_outline_0020
      00B6BC FB               [12] 1045 	mov	r3,a
      00B6BD 12 49 C3         [24] 1046 	lcall	_ak820_outline_0012
      00B6C0 E0               [24] 1047 	movx	a,@dptr
      00B6C1 4B               [12] 1048 	orl	a,r3
      00B6C2 60 01            [24] 1049 	jz	00108$
      00B6C4 22               [24] 1050 	ret
      00B6C5                       1051 00108$:
                                   1052 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B6C5 12 38 31         [24] 1053 	lcall	_ak820_outline_0037
      00B6C8 FB               [12] 1054 	mov	r3,a
      00B6C9 7A 00            [12] 1055 	mov	r2,#0x00
      00B6CB 12 B4 F0         [24] 1056 	lcall	_ak820_outline_0018
      00B6CE F9               [12] 1057 	mov	r1,a
      00B6CF E4               [12] 1058 	clr	a
      00B6D0 42 03            [12] 1059 	orl	ar3,a
      00B6D2 E9               [12] 1060 	mov	a,r1
      00B6D3 42 02            [12] 1061 	orl	ar2,a
                                   1062 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B6D5 C3               [12] 1063 	clr	c
      00B6D6 EB               [12] 1064 	mov	a,r3
      00B6D7 94 0C            [12] 1065 	subb	a,#0x0c
      00B6D9 EA               [12] 1066 	mov	a,r2
      00B6DA 94 00            [12] 1067 	subb	a,#0x00
      00B6DC 40 01            [24] 1068 	jc	00110$
      00B6DE 22               [24] 1069 	ret
      00B6DF                       1070 00110$:
                                   1071 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B6DF EA               [12] 1072 	mov	a,r2
      00B6E0 C4               [12] 1073 	swap	a
      00B6E1 23               [12] 1074 	rl	a
      00B6E2 54 E0            [12] 1075 	anl	a,#0xe0
      00B6E4 CB               [12] 1076 	xch	a,r3
      00B6E5 C4               [12] 1077 	swap	a
      00B6E6 23               [12] 1078 	rl	a
      00B6E7 CB               [12] 1079 	xch	a,r3
      00B6E8 6B               [12] 1080 	xrl	a,r3
      00B6E9 CB               [12] 1081 	xch	a,r3
      00B6EA 54 E0            [12] 1082 	anl	a,#0xe0
      00B6EC CB               [12] 1083 	xch	a,r3
      00B6ED 6B               [12] 1084 	xrl	a,r3
      00B6EE FA               [12] 1085 	mov	r2,a
      00B6EF 8B 52            [24] 1086 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B6F1 8A 53            [24] 1087 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1088 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B6F3 74 7C            [12] 1089 	mov	a,#0x7c
      00B6F5 C3               [12] 1090 	clr	c
      00B6F6 95 52            [12] 1091 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B6F8 F8               [12] 1092 	mov	r0,a
      00B6F9 74 01            [12] 1093 	mov	a,#0x01
      00B6FB 95 53            [12] 1094 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B6FD F9               [12] 1095 	mov	r1,a
                                   1096 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B6FE C3               [12] 1097 	clr	c
      00B6FF E8               [12] 1098 	mov	a,r0
      00B700 94 20            [12] 1099 	subb	a,#0x20
      00B702 E9               [12] 1100 	mov	a,r1
      00B703 94 00            [12] 1101 	subb	a,#0x00
      00B705 40 02            [24] 1102 	jc	00146$
      00B707 78 20            [12] 1103 	mov	r0,#0x20
      00B709                       1104 00146$:
                                   1105 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B709 79 00            [12] 1106 	mov	r1,#0x00
      00B70B                       1107 00138$:
      00B70B C3               [12] 1108 	clr	c
      00B70C E9               [12] 1109 	mov	a,r1
      00B70D 98               [12] 1110 	subb	a,r0
      00B70E 40 01            [24] 1111 	jc	00264$
      00B710 22               [24] 1112 	ret
      00B711                       1113 00264$:
      00B711 C0 00            [24] 1114 	push	ar0
      00B713 E9               [12] 1115 	mov	a,r1
      00B714 2E               [12] 1116 	add	a, r6
      00B715 F5 54            [12] 1117 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B717 E4               [12] 1118 	clr	a
      00B718 3F               [12] 1119 	addc	a, r7
      00B719 F5 55            [12] 1120 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B71B 89 56            [24] 1121 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B71D 75 57 00         [24] 1122 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B720 A8 52            [24] 1123 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B722 AB 53            [24] 1124 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B724 E5 56            [12] 1125 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B726 28               [12] 1126 	add	a, r0
      00B727 F8               [12] 1127 	mov	r0,a
      00B728 E5 57            [12] 1128 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B72A 3B               [12] 1129 	addc	a, r3
      00B72B FB               [12] 1130 	mov	r3,a
      00B72C E8               [12] 1131 	mov	a,r0
      00B72D 24 E3            [12] 1132 	add	a, #_keyboard_definition
      00B72F F5 82            [12] 1133 	mov	dpl,a
      00B731 EB               [12] 1134 	mov	a,r3
      00B732 34 C6            [12] 1135 	addc	a, #(_keyboard_definition >> 8)
      00B734 F5 83            [12] 1136 	mov	dph,a
      00B736 E4               [12] 1137 	clr	a
      00B737 93               [24] 1138 	movc	a,@a+dptr
      00B738 85 54 82         [24] 1139 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B73B 85 55 83         [24] 1140 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B73E F0               [24] 1141 	movx	@dptr,a
      00B73F 09               [12] 1142 	inc	r1
      00B740 D0 00            [24] 1143 	pop	ar0
                                   1144 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B742 80 C7            [24] 1145 	sjmp	00138$
      00B744                       1146 00112$:
                                   1147 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B744 74 02            [12] 1148 	mov	a,#0x02
      00B746 12 4F 2B         [24] 1149 	lcall	_ak820_outline_0034
      00B749 F5 56            [12] 1150 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1151 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B74B 74 03            [12] 1152 	mov	a,#0x03
      00B74D 2E               [12] 1153 	add	a, r6
      00B74E F5 54            [12] 1154 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B750 E4               [12] 1155 	clr	a
      00B751 3F               [12] 1156 	addc	a, r7
      00B752 F5 55            [12] 1157 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B754 85 54 82         [24] 1158 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B757 85 55 83         [24] 1159 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B75A E0               [24] 1160 	movx	a,@dptr
                                   1161 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B75B F5 52            [12] 1162 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B75D 90 0B 74         [24] 1163 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B760 F0               [24] 1164 	movx	@dptr,a
      00B761 90 0B 75         [24] 1165 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B764 E4               [12] 1166 	clr	a
      00B765 F0               [24] 1167 	movx	@dptr,a
      00B766 85 56 82         [24] 1168 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B769 C0 07            [24] 1169 	push	ar7
      00B76B C0 06            [24] 1170 	push	ar6
      00B76D C0 05            [24] 1171 	push	ar5
      00B76F C0 04            [24] 1172 	push	ar4
      00B771 C0 03            [24] 1173 	push	ar3
      00B773 C0 02            [24] 1174 	push	ar2
      00B775 12 8B EA         [24] 1175 	lcall	_dynamic_keymap_get_encoder
      00B778 85 82 58         [24] 1176 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B77B 85 83 59         [24] 1177 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B77E D0 02            [24] 1178 	pop	ar2
      00B780 D0 03            [24] 1179 	pop	ar3
      00B782 D0 04            [24] 1180 	pop	ar4
      00B784 D0 05            [24] 1181 	pop	ar5
      00B786 D0 06            [24] 1182 	pop	ar6
      00B788 D0 07            [24] 1183 	pop	ar7
                                   1184 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B78A A9 59            [24] 1185 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B78C 12 38 90         [24] 1186 	lcall	_ak820_outline_0126
      00B78F E9               [12] 1187 	mov	a,r1
      00B790 F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B791 A8 58            [24] 1190 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B793 12 38 A1         [24] 1191 	lcall	_ak820_outline_0134
      00B796 E8               [12] 1192 	mov	a,r0
      00B797 F0               [24] 1193 	movx	@dptr,a
                                   1194 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B798 90 0B 74         [24] 1195 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B79B E5 52            [12] 1196 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B79D F0               [24] 1197 	movx	@dptr,a
      00B79E 90 0B 75         [24] 1198 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B7A1 74 01            [12] 1199 	mov	a,#0x01
      00B7A3 F0               [24] 1200 	movx	@dptr,a
      00B7A4 85 56 82         [24] 1201 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B7A7 C0 03            [24] 1202 	push	ar3
      00B7A9 C0 02            [24] 1203 	push	ar2
      00B7AB 12 8B EA         [24] 1204 	lcall	_dynamic_keymap_get_encoder
      00B7AE 85 82 58         [24] 1205 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B7B1 85 83 59         [24] 1206 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B7B4 D0 02            [24] 1207 	pop	ar2
      00B7B6 D0 03            [24] 1208 	pop	ar3
                                   1209 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B7B8 A9 59            [24] 1210 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B7BA 12 38 B0         [24] 1211 	lcall	_ak820_outline_0146
      00B7BD E9               [12] 1212 	mov	a,r1
      00B7BE F0               [24] 1213 	movx	@dptr,a
                                   1214 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B7BF A8 58            [24] 1215 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B7C1 85 54 82         [24] 1216 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B7C4 85 55 83         [24] 1217 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B7C7 E8               [12] 1218 	mov	a,r0
      00B7C8 F0               [24] 1219 	movx	@dptr,a
                                   1220 ;	quantum/vial.c:255: break;
      00B7C9 22               [24] 1221 	ret
                                   1222 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B7CA                       1223 00113$:
                                   1224 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B7CA 12 38 31         [24] 1225 	lcall	_ak820_outline_0037
      00B7CD F5 54            [12] 1226 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B7CF 12 B4 F0         [24] 1227 	lcall	_ak820_outline_0018
      00B7D2 F5 56            [12] 1228 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B7D4 12 42 0C         [24] 1229 	lcall	_ak820_outline_0020
                                   1230 ;	assignBit
      00B7D7 24 FF            [12] 1231 	add	a,#0xff
      00B7D9 E4               [12] 1232 	clr	a
      00B7DA 33               [12] 1233 	rlc	a
      00B7DB F5 58            [12] 1234 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B7DD 12 49 C3         [24] 1235 	lcall	_ak820_outline_0012
      00B7E0 E0               [24] 1236 	movx	a,@dptr
      00B7E1 F9               [12] 1237 	mov	r1,a
      00B7E2 78 00            [12] 1238 	mov	r0,#0x00
      00B7E4 74 06            [12] 1239 	mov	a,#0x06
      00B7E6 12 38 0E         [24] 1240 	lcall	_ak820_outline_0016
      00B7E9 7B 00            [12] 1241 	mov	r3,#0x00
      00B7EB 42 00            [12] 1242 	orl	ar0,a
      00B7ED EB               [12] 1243 	mov	a,r3
      00B7EE 42 01            [12] 1244 	orl	ar1,a
      00B7F0 12 38 BA         [24] 1245 	lcall	_ak820_outline_0167
      00B7F3 12 B5 C0         [24] 1246 	lcall	_vial_keycode_firewall
      00B7F6 AA 82            [24] 1247 	mov	r2, dpl
      00B7F8 AB 83            [24] 1248 	mov	r3, dph
      00B7FA 90 0B 77         [24] 1249 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B7FD E5 56            [12] 1250 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B7FF F0               [24] 1251 	movx	@dptr,a
      00B800 90 0B 78         [24] 1252 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B803 E5 58            [12] 1253 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B805 F0               [24] 1254 	movx	@dptr,a
      00B806 90 0B 79         [24] 1255 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B809 EA               [12] 1256 	mov	a,r2
      00B80A 12 7D A0         [24] 1257 	lcall	_ak820_outline_0197
      00B80D 85 54 82         [24] 1258 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1259 ;	quantum/vial.c:259: break;
      00B810 02 8C 51         [24] 1260 	ljmp	_dynamic_keymap_set_encoder
                                   1261 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B813                       1262 00114$:
                                   1263 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B813 90 0D 00         [24] 1264 	mov	dptr,#_vial_fill_packet_PARM_2
      00B816 74 FF            [12] 1265 	mov	a,#0xff
      00B818 12 4A 00         [24] 1266 	lcall	_ak820_outline_0070
      00B81B C0 07            [24] 1267 	push	ar7
      00B81D C0 06            [24] 1268 	push	ar6
      00B81F 12 B5 E3         [24] 1269 	lcall	_vial_fill_packet
      00B822 D0 06            [24] 1270 	pop	ar6
      00B824 D0 07            [24] 1271 	pop	ar7
                                   1272 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B826 90 0E DA         [24] 1273 	mov	dptr,#_vial_unlocked
      00B829 E0               [24] 1274 	movx	a,@dptr
      00B82A 12 38 90         [24] 1275 	lcall	_ak820_outline_0126
      00B82D F0               [24] 1276 	movx	@dptr,a
                                   1277 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B82E 74 01            [12] 1278 	mov	a,#0x01
      00B830 2E               [12] 1279 	add	a, r6
      00B831 FA               [12] 1280 	mov	r2,a
      00B832 E4               [12] 1281 	clr	a
      00B833 3F               [12] 1282 	addc	a, r7
      00B834 FB               [12] 1283 	mov	r3,a
      00B835 90 0E DB         [24] 1284 	mov	dptr,#_vial_unlock_in_progress
      00B838 E0               [24] 1285 	movx	a,@dptr
      00B839 12 38 B0         [24] 1286 	lcall	_ak820_outline_0146
      00B83C F0               [24] 1287 	movx	@dptr,a
                                   1288 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B83D 7B 00            [12] 1289 	mov	r3,#0x00
      00B83F                       1290 00141$:
      00B83F BB 02 00         [24] 1291 	cjne	r3,#0x02,00265$
      00B842                       1292 00265$:
      00B842 40 01            [24] 1293 	jc	00266$
      00B844 22               [24] 1294 	ret
      00B845                       1295 00266$:
                                   1296 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B845 8B 01            [24] 1297 	mov	ar1,r3
      00B847 7A 00            [12] 1298 	mov	r2,#0x00
      00B849 E9               [12] 1299 	mov	a,r1
      00B84A 29               [12] 1300 	add	a,r1
      00B84B F5 58            [12] 1301 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B84D EA               [12] 1302 	mov	a,r2
      00B84E 33               [12] 1303 	rlc	a
      00B84F F5 59            [12] 1304 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B851 74 02            [12] 1305 	mov	a,#0x02
      00B853 25 58            [12] 1306 	add	a, _vial_handle_cmd_sloc3_1_0
      00B855 F8               [12] 1307 	mov	r0,a
      00B856 E4               [12] 1308 	clr	a
      00B857 35 59            [12] 1309 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B859 FA               [12] 1310 	mov	r2,a
      00B85A E8               [12] 1311 	mov	a,r0
      00B85B 2E               [12] 1312 	add	a, r6
      00B85C F8               [12] 1313 	mov	r0,a
      00B85D EA               [12] 1314 	mov	a,r2
      00B85E 3F               [12] 1315 	addc	a, r7
      00B85F FA               [12] 1316 	mov	r2,a
      00B860 EB               [12] 1317 	mov	a,r3
      00B861 12 BB BE         [24] 1318 	lcall	_ak820_outline_0138
      00B864 88 82            [24] 1319 	mov	dpl,r0
      00B866 8A 83            [24] 1320 	mov	dph,r2
      00B868 F0               [24] 1321 	movx	@dptr,a
                                   1322 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B869 74 03            [12] 1323 	mov	a,#0x03
      00B86B 25 58            [12] 1324 	add	a, _vial_handle_cmd_sloc3_1_0
      00B86D F9               [12] 1325 	mov	r1,a
      00B86E E4               [12] 1326 	clr	a
      00B86F 35 59            [12] 1327 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B871 FA               [12] 1328 	mov	r2,a
      00B872 E9               [12] 1329 	mov	a,r1
      00B873 2E               [12] 1330 	add	a, r6
      00B874 F9               [12] 1331 	mov	r1,a
      00B875 EA               [12] 1332 	mov	a,r2
      00B876 3F               [12] 1333 	addc	a, r7
      00B877 FA               [12] 1334 	mov	r2,a
      00B878 EB               [12] 1335 	mov	a,r3
      00B879 12 BB B3         [24] 1336 	lcall	_ak820_outline_0137
      00B87C 12 72 BF         [24] 1337 	lcall	_ak820_outline_0150
                                   1338 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B87F 0B               [12] 1339 	inc	r3
                                   1340 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B880 80 BD            [24] 1341 	sjmp	00141$
      00B882                       1342 00116$:
                                   1343 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B882 90 0E DB         [24] 1344 	mov	dptr,#_vial_unlock_in_progress
      00B885 E0               [24] 1345 	movx	a,@dptr
      00B886 70 03            [24] 1346 	jnz	00118$
      00B888 12 B6 08         [24] 1347 	lcall	_vial_release_held_state
      00B88B                       1348 00118$:
                                   1349 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B88B 90 0E DB         [24] 1350 	mov	dptr,#_vial_unlock_in_progress
      00B88E 74 01            [12] 1351 	mov	a,#0x01
      00B890 F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B891 90 0E DC         [24] 1354 	mov	dptr,#_vial_unlock_counter
      00B894 74 1E            [12] 1355 	mov	a,#0x1e
      00B896 F0               [24] 1356 	movx	@dptr,a
                                   1357 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B897 90 0C FD         [24] 1358 	mov	dptr,#_vial_unlock_holding
      00B89A E4               [12] 1359 	clr	a
      00B89B F0               [24] 1360 	movx	@dptr,a
                                   1361 ;	quantum/vial.c:287: break;
      00B89C 22               [24] 1362 	ret
                                   1363 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B89D                       1364 00119$:
                                   1365 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B89D 90 0E DA         [24] 1366 	mov	dptr,#_vial_unlocked
      00B8A0 E0               [24] 1367 	movx	a,@dptr
      00B8A1 12 38 90         [24] 1368 	lcall	_ak820_outline_0126
      00B8A4 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B8A5 90 0E DB         [24] 1371 	mov	dptr,#_vial_unlock_in_progress
      00B8A8 E0               [24] 1372 	movx	a,@dptr
      00B8A9 12 38 A1         [24] 1373 	lcall	_ak820_outline_0134
      00B8AC F0               [24] 1374 	movx	@dptr,a
                                   1375 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B8AD 74 02            [12] 1376 	mov	a,#0x02
      00B8AF 2E               [12] 1377 	add	a, r6
      00B8B0 FA               [12] 1378 	mov	r2,a
      00B8B1 E4               [12] 1379 	clr	a
      00B8B2 3F               [12] 1380 	addc	a, r7
      00B8B3 FB               [12] 1381 	mov	r3,a
      00B8B4 90 0E DC         [24] 1382 	mov	dptr,#_vial_unlock_counter
      00B8B7 E0               [24] 1383 	movx	a,@dptr
      00B8B8 12 38 B0         [24] 1384 	lcall	_ak820_outline_0146
      00B8BB F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/vial.c:293: break;
      00B8BC 22               [24] 1387 	ret
                                   1388 ;	quantum/vial.c:295: case vial_lock: {
      00B8BD                       1389 00120$:
                                   1390 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B8BD 90 0E DA         [24] 1391 	mov	dptr,#_vial_unlocked
      00B8C0 E4               [12] 1392 	clr	a
      00B8C1 F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B8C2 90 0E DB         [24] 1395 	mov	dptr,#_vial_unlock_in_progress
      00B8C5 F0               [24] 1396 	movx	@dptr,a
                                   1397 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B8C6 90 0C FD         [24] 1398 	mov	dptr,#_vial_unlock_holding
      00B8C9 F0               [24] 1399 	movx	@dptr,a
                                   1400 ;	quantum/vial.c:301: break;
      00B8CA 22               [24] 1401 	ret
                                   1402 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B8CB                       1403 00121$:
                                   1404 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B8CB 90 0D 00         [24] 1405 	mov	dptr,#_vial_fill_packet_PARM_2
      00B8CE 74 FF            [12] 1406 	mov	a,#0xff
      00B8D0 12 4A 00         [24] 1407 	lcall	_ak820_outline_0070
                                   1408 ;	quantum/vial.c:314: break;
      00B8D3 02 B5 E3         [24] 1409 	ljmp	_vial_fill_packet
                                   1410 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B8D6                       1411 00122$:
                                   1412 ;	quantum/vial.c:347: switch (msg[2]) {
      00B8D6 12 38 31         [24] 1413 	lcall	_ak820_outline_0037
      00B8D9 FB               [12] 1414 	mov  r3,a
      00B8DA 24 F9            [12] 1415 	add	a,#0xff - 0x06
      00B8DC 50 01            [24] 1416 	jnc	00268$
      00B8DE 22               [24] 1417 	ret
      00B8DF                       1418 00268$:
                                   1419 ;	free result
      00B8DF EB               [12] 1420 	mov	a,r3
      00B8E0 2B               [12] 1421 	add	a,r3
      00B8E1 2B               [12] 1422 	add	a,r3
      00B8E2 90 B8 E6         [24] 1423 	mov	dptr,#00269$
      00B8E5 73               [24] 1424 	jmp	@a+dptr
      00B8E6                       1425 00269$:
      00B8E6 02 B8 FB         [24] 1426 	ljmp	00123$
      00B8E9 02 BA A1         [24] 1427 	ljmp	00143$
      00B8EC 02 BA A1         [24] 1428 	ljmp	00143$
      00B8EF 02 B9 24         [24] 1429 	ljmp	00124$
      00B8F2 02 B9 86         [24] 1430 	ljmp	00125$
      00B8F5 02 B9 E4         [24] 1431 	ljmp	00128$
      00B8F8 02 BA 46         [24] 1432 	ljmp	00129$
                                   1433 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B8FB                       1434 00123$:
                                   1435 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B8FB 90 0D 00         [24] 1436 	mov	dptr,#_vial_fill_packet_PARM_2
      00B8FE E4               [12] 1437 	clr	a
      00B8FF 12 4A 00         [24] 1438 	lcall	_ak820_outline_0070
      00B902 C0 07            [24] 1439 	push	ar7
      00B904 C0 06            [24] 1440 	push	ar6
      00B906 12 B5 E3         [24] 1441 	lcall	_vial_fill_packet
      00B909 D0 06            [24] 1442 	pop	ar6
      00B90B D0 07            [24] 1443 	pop	ar7
                                   1444 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B90D 12 38 90         [24] 1445 	lcall	_ak820_outline_0126
      00B910 E4               [12] 1446 	clr	a
      00B911 12 4A 00         [24] 1447 	lcall	_ak820_outline_0070
                                   1448 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B914 A3               [24] 1449 	inc	dptr
      00B915 74 08            [12] 1450 	mov	a,#0x08
      00B917 12 49 CD         [24] 1451 	lcall	_ak820_outline_0027
                                   1452 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B91A F0               [24] 1453 	movx	@dptr,a
                                   1454 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B91B 74 1F            [12] 1455 	mov	a,#0x1f
      00B91D 12 38 29         [24] 1456 	lcall	_ak820_outline_0036
      00B920 74 01            [12] 1457 	mov	a,#0x01
      00B922 F0               [24] 1458 	movx	@dptr,a
                                   1459 ;	quantum/vial.c:356: break;
      00B923 22               [24] 1460 	ret
                                   1461 ;	quantum/vial.c:380: case dynamic_vial_combo_get: {
      00B924                       1462 00124$:
                                   1463 ;	quantum/vial.c:381: uint8_t idx = msg[3];
      00B924 12 B4 F0         [24] 1464 	lcall	_ak820_outline_0018
      00B927 FB               [12] 1465 	mov	r3,a
                                   1466 ;	quantum/vial.c:382: vial_combo_entry_t entry = { { 0 }, 0 };
      00B928 90 0D 07         [24] 1467 	mov	dptr,#_vial_handle_cmd_entry_70000_655
      00B92B 12 55 F6         [24] 1468 	lcall	_ak820_outline_0166
      00B92E 90 0D 09         [24] 1469 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0002)
      00B931 F0               [24] 1470 	movx	@dptr,a
      00B932 A3               [24] 1471 	inc	dptr
      00B933 F0               [24] 1472 	movx	@dptr,a
      00B934 90 0D 0B         [24] 1473 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0004)
      00B937 F0               [24] 1474 	movx	@dptr,a
      00B938 A3               [24] 1475 	inc	dptr
      00B939 F0               [24] 1476 	movx	@dptr,a
      00B93A 90 0D 0D         [24] 1477 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0006)
      00B93D F0               [24] 1478 	movx	@dptr,a
      00B93E A3               [24] 1479 	inc	dptr
      00B93F F0               [24] 1480 	movx	@dptr,a
      00B940 90 0D 0F         [24] 1481 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0008)
      00B943 F0               [24] 1482 	movx	@dptr,a
      00B944 A3               [24] 1483 	inc	dptr
      00B945 F0               [24] 1484 	movx	@dptr,a
                                   1485 ;	quantum/vial.c:383: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B946 90 0B 7C         [24] 1486 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B949 74 07            [12] 1487 	mov	a,#_vial_handle_cmd_entry_70000_655
      00B94B F0               [24] 1488 	movx	@dptr,a
      00B94C 74 0D            [12] 1489 	mov	a,#(_vial_handle_cmd_entry_70000_655 >> 8)
      00B94E 12 38 56         [24] 1490 	lcall	_ak820_outline_0077
      00B951 8B 82            [24] 1491 	mov	dpl, r3
      00B953 C0 07            [24] 1492 	push	ar7
      00B955 C0 06            [24] 1493 	push	ar6
      00B957 C0 05            [24] 1494 	push	ar5
      00B959 C0 04            [24] 1495 	push	ar4
      00B95B 12 8C BC         [24] 1496 	lcall	_dynamic_keymap_get_combo
      00B95E AA 82            [24] 1497 	mov	r2, dpl
      00B960 D0 04            [24] 1498 	pop	ar4
      00B962 D0 05            [24] 1499 	pop	ar5
      00B964 D0 06            [24] 1500 	pop	ar6
      00B966 D0 07            [24] 1501 	pop	ar7
      00B968 12 38 90         [24] 1502 	lcall	_ak820_outline_0126
      00B96B EA               [12] 1503 	mov	a,r2
      00B96C F0               [24] 1504 	movx	@dptr,a
                                   1505 ;	quantum/vial.c:384: memcpy(&msg[1], &entry, sizeof(entry));
      00B96D 8C 01            [24] 1506 	mov	ar1,r4
      00B96F 8D 02            [24] 1507 	mov	ar2,r5
      00B971 7B 00            [12] 1508 	mov	r3,#0x00
      00B973 90 0E 57         [24] 1509 	mov	dptr,#___memcpy_PARM_2
      00B976 74 07            [12] 1510 	mov	a,#_vial_handle_cmd_entry_70000_655
      00B978 F0               [24] 1511 	movx	@dptr,a
      00B979 74 0D            [12] 1512 	mov	a,#(_vial_handle_cmd_entry_70000_655 >> 8)
      00B97B 12 BB 8B         [24] 1513 	lcall	_ak820_outline_0009
      00B97E 12 4A 34         [24] 1514 	lcall	_ak820_outline_0168
      00B981 8B F0            [24] 1515 	mov	b, r3
                                   1516 ;	quantum/vial.c:385: break;
      00B983 02 C1 65         [24] 1517 	ljmp	___memcpy
                                   1518 ;	quantum/vial.c:387: case dynamic_vial_combo_set: {
      00B986                       1519 00125$:
                                   1520 ;	quantum/vial.c:388: uint8_t idx = msg[3];
      00B986 12 B4 F0         [24] 1521 	lcall	_ak820_outline_0018
      00B989 FB               [12] 1522 	mov	r3,a
                                   1523 ;	quantum/vial.c:390: memcpy(&entry, &msg[4], sizeof(entry));
      00B98A 74 04            [12] 1524 	mov	a,#0x04
      00B98C 2E               [12] 1525 	add	a, r6
      00B98D F9               [12] 1526 	mov	r1,a
      00B98E E4               [12] 1527 	clr	a
      00B98F 3F               [12] 1528 	addc	a, r7
      00B990 FA               [12] 1529 	mov	r2,a
      00B991 90 0E 57         [24] 1530 	mov	dptr,#___memcpy_PARM_2
      00B994 E9               [12] 1531 	mov	a,r1
      00B995 F0               [24] 1532 	movx	@dptr,a
      00B996 EA               [12] 1533 	mov	a,r2
      00B997 12 BB 8B         [24] 1534 	lcall	_ak820_outline_0009
      00B99A 90 0D 11         [24] 1535 	mov	dptr,#_vial_handle_cmd_entry_70000_656
      00B99D F5 F0            [12] 1536 	mov	b,a
      00B99F C0 07            [24] 1537 	push	ar7
      00B9A1 C0 06            [24] 1538 	push	ar6
      00B9A3 C0 03            [24] 1539 	push	ar3
      00B9A5 12 C1 65         [24] 1540 	lcall	___memcpy
                                   1541 ;	quantum/vial.c:391: entry.output = vial_keycode_firewall(entry.output);
      00B9A8 90 0D 19         [24] 1542 	mov	dptr,#(_vial_handle_cmd_entry_70000_656 + 0x0008)
      00B9AB E0               [24] 1543 	movx	a,@dptr
      00B9AC F9               [12] 1544 	mov	r1,a
      00B9AD A3               [24] 1545 	inc	dptr
      00B9AE E0               [24] 1546 	movx	a,@dptr
      00B9AF FA               [12] 1547 	mov	r2,a
      00B9B0 12 4A 34         [24] 1548 	lcall	_ak820_outline_0168
      00B9B3 12 B5 C0         [24] 1549 	lcall	_vial_keycode_firewall
      00B9B6 A9 82            [24] 1550 	mov	r1, dpl
      00B9B8 AA 83            [24] 1551 	mov	r2, dph
      00B9BA D0 03            [24] 1552 	pop	ar3
      00B9BC 90 0D 19         [24] 1553 	mov	dptr,#(_vial_handle_cmd_entry_70000_656 + 0x0008)
      00B9BF 12 4F 71         [24] 1554 	lcall	_ak820_outline_0149
                                   1555 ;	quantum/vial.c:392: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B9C2 90 0B 80         [24] 1556 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B9C5 74 11            [12] 1557 	mov	a,#_vial_handle_cmd_entry_70000_656
      00B9C7 F0               [24] 1558 	movx	@dptr,a
      00B9C8 74 0D            [12] 1559 	mov	a,#(_vial_handle_cmd_entry_70000_656 >> 8)
      00B9CA 12 38 56         [24] 1560 	lcall	_ak820_outline_0077
      00B9CD 8B 82            [24] 1561 	mov	dpl, r3
      00B9CF 12 8D 52         [24] 1562 	lcall	_dynamic_keymap_set_combo
      00B9D2 AA 82            [24] 1563 	mov	r2, dpl
      00B9D4 D0 06            [24] 1564 	pop	ar6
      00B9D6 D0 07            [24] 1565 	pop	ar7
      00B9D8 12 38 90         [24] 1566 	lcall	_ak820_outline_0126
      00B9DB EA               [12] 1567 	mov	a,r2
      00B9DC F0               [24] 1568 	movx	@dptr,a
                                   1569 ;	quantum/vial.c:393: if (!msg[0]) reload_combo();
      00B9DD EA               [12] 1570 	mov	a,r2
      00B9DE 60 01            [24] 1571 	jz	00270$
      00B9E0 22               [24] 1572 	ret
      00B9E1                       1573 00270$:
                                   1574 ;	quantum/vial.c:394: break;
      00B9E1 02 35 7A         [24] 1575 	ljmp	_ak820_combo_reload
                                   1576 ;	quantum/vial.c:398: case dynamic_vial_key_override_get: {
      00B9E4                       1577 00128$:
                                   1578 ;	quantum/vial.c:399: uint8_t idx = msg[3];
      00B9E4 12 B4 F0         [24] 1579 	lcall	_ak820_outline_0018
      00B9E7 FB               [12] 1580 	mov	r3,a
                                   1581 ;	quantum/vial.c:400: vial_key_override_entry_t entry = { 0 };
      00B9E8 90 0D 1B         [24] 1582 	mov	dptr,#_vial_handle_cmd_entry_70000_658
      00B9EB 12 55 F6         [24] 1583 	lcall	_ak820_outline_0166
      00B9EE 90 0D 1D         [24] 1584 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0002)
      00B9F1 F0               [24] 1585 	movx	@dptr,a
      00B9F2 A3               [24] 1586 	inc	dptr
      00B9F3 F0               [24] 1587 	movx	@dptr,a
      00B9F4 90 0D 1F         [24] 1588 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0004)
      00B9F7 F0               [24] 1589 	movx	@dptr,a
      00B9F8 A3               [24] 1590 	inc	dptr
      00B9F9 F0               [24] 1591 	movx	@dptr,a
      00B9FA 90 0D 21         [24] 1592 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0006)
      00B9FD F0               [24] 1593 	movx	@dptr,a
      00B9FE 90 0D 22         [24] 1594 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0007)
      00BA01 F0               [24] 1595 	movx	@dptr,a
      00BA02 90 0D 23         [24] 1596 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0008)
      00BA05 F0               [24] 1597 	movx	@dptr,a
      00BA06 90 0D 24         [24] 1598 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0009)
      00BA09 F0               [24] 1599 	movx	@dptr,a
                                   1600 ;	quantum/vial.c:401: msg[0] = dynamic_keymap_get_key_override(idx, &entry);
      00BA0A 90 0B 8E         [24] 1601 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      00BA0D 74 1B            [12] 1602 	mov	a,#_vial_handle_cmd_entry_70000_658
      00BA0F F0               [24] 1603 	movx	@dptr,a
      00BA10 74 0D            [12] 1604 	mov	a,#(_vial_handle_cmd_entry_70000_658 >> 8)
      00BA12 12 38 56         [24] 1605 	lcall	_ak820_outline_0077
      00BA15 8B 82            [24] 1606 	mov	dpl, r3
      00BA17 C0 07            [24] 1607 	push	ar7
      00BA19 C0 06            [24] 1608 	push	ar6
      00BA1B C0 05            [24] 1609 	push	ar5
      00BA1D C0 04            [24] 1610 	push	ar4
      00BA1F 12 8D F4         [24] 1611 	lcall	_dynamic_keymap_get_key_override
      00BA22 AA 82            [24] 1612 	mov	r2, dpl
      00BA24 D0 04            [24] 1613 	pop	ar4
      00BA26 D0 05            [24] 1614 	pop	ar5
      00BA28 D0 06            [24] 1615 	pop	ar6
      00BA2A D0 07            [24] 1616 	pop	ar7
      00BA2C 12 38 90         [24] 1617 	lcall	_ak820_outline_0126
      00BA2F EA               [12] 1618 	mov	a,r2
      00BA30 F0               [24] 1619 	movx	@dptr,a
                                   1620 ;	quantum/vial.c:402: memcpy(&msg[1], &entry, sizeof(entry));
      00BA31 7B 00            [12] 1621 	mov	r3,#0x00
      00BA33 90 0E 57         [24] 1622 	mov	dptr,#___memcpy_PARM_2
      00BA36 74 1B            [12] 1623 	mov	a,#_vial_handle_cmd_entry_70000_658
      00BA38 F0               [24] 1624 	movx	@dptr,a
      00BA39 74 0D            [12] 1625 	mov	a,#(_vial_handle_cmd_entry_70000_658 >> 8)
      00BA3B 12 BB 8B         [24] 1626 	lcall	_ak820_outline_0009
      00BA3E 12 38 A1         [24] 1627 	lcall	_ak820_outline_0134
      00BA41 8B F0            [24] 1628 	mov	b, r3
                                   1629 ;	quantum/vial.c:403: break;
      00BA43 02 C1 65         [24] 1630 	ljmp	___memcpy
                                   1631 ;	quantum/vial.c:405: case dynamic_vial_key_override_set: {
      00BA46                       1632 00129$:
                                   1633 ;	quantum/vial.c:406: uint8_t idx = msg[3];
      00BA46 12 B4 F0         [24] 1634 	lcall	_ak820_outline_0018
      00BA49 FD               [12] 1635 	mov	r5,a
                                   1636 ;	quantum/vial.c:408: memcpy(&entry, &msg[4], sizeof(entry));
      00BA4A 74 04            [12] 1637 	mov	a,#0x04
      00BA4C 2E               [12] 1638 	add	a, r6
      00BA4D FB               [12] 1639 	mov	r3,a
      00BA4E E4               [12] 1640 	clr	a
      00BA4F 3F               [12] 1641 	addc	a, r7
      00BA50 FC               [12] 1642 	mov	r4,a
      00BA51 90 0E 57         [24] 1643 	mov	dptr,#___memcpy_PARM_2
      00BA54 EB               [12] 1644 	mov	a,r3
      00BA55 F0               [24] 1645 	movx	@dptr,a
      00BA56 EC               [12] 1646 	mov	a,r4
      00BA57 12 BB 8B         [24] 1647 	lcall	_ak820_outline_0009
      00BA5A 90 0D 25         [24] 1648 	mov	dptr,#_vial_handle_cmd_entry_70000_659
      00BA5D F5 F0            [12] 1649 	mov	b,a
      00BA5F C0 07            [24] 1650 	push	ar7
      00BA61 C0 06            [24] 1651 	push	ar6
      00BA63 C0 05            [24] 1652 	push	ar5
      00BA65 12 C1 65         [24] 1653 	lcall	___memcpy
                                   1654 ;	quantum/vial.c:409: entry.replacement = vial_keycode_firewall(entry.replacement);
      00BA68 90 0D 27         [24] 1655 	mov	dptr,#(_vial_handle_cmd_entry_70000_659 + 0x0002)
      00BA6B 12 38 9B         [24] 1656 	lcall	_ak820_outline_0133
      00BA6E 12 33 FC         [24] 1657 	lcall	_ak820_outline_0129
      00BA71 12 B5 C0         [24] 1658 	lcall	_vial_keycode_firewall
      00BA74 AB 82            [24] 1659 	mov	r3, dpl
      00BA76 AC 83            [24] 1660 	mov	r4, dph
      00BA78 D0 05            [24] 1661 	pop	ar5
      00BA7A 90 0D 27         [24] 1662 	mov	dptr,#(_vial_handle_cmd_entry_70000_659 + 0x0002)
      00BA7D 12 38 68         [24] 1663 	lcall	_ak820_outline_0090
                                   1664 ;	quantum/vial.c:410: msg[0] = dynamic_keymap_set_key_override(idx, &entry);
      00BA80 90 0B 92         [24] 1665 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      00BA83 74 25            [12] 1666 	mov	a,#_vial_handle_cmd_entry_70000_659
      00BA85 F0               [24] 1667 	movx	@dptr,a
      00BA86 74 0D            [12] 1668 	mov	a,#(_vial_handle_cmd_entry_70000_659 >> 8)
      00BA88 12 38 56         [24] 1669 	lcall	_ak820_outline_0077
      00BA8B 8D 82            [24] 1670 	mov	dpl, r5
      00BA8D 12 8E 76         [24] 1671 	lcall	_dynamic_keymap_set_key_override
      00BA90 AC 82            [24] 1672 	mov	r4, dpl
      00BA92 D0 06            [24] 1673 	pop	ar6
      00BA94 D0 07            [24] 1674 	pop	ar7
      00BA96 12 38 90         [24] 1675 	lcall	_ak820_outline_0126
      00BA99 EC               [12] 1676 	mov	a,r4
      00BA9A F0               [24] 1677 	movx	@dptr,a
                                   1678 ;	quantum/vial.c:411: if (!msg[0]) reload_key_override();
      00BA9B EC               [12] 1679 	mov	a,r4
      00BA9C 70 03            [24] 1680 	jnz	00143$
                                   1681 ;	quantum/vial.c:419: }
                                   1682 ;	quantum/vial.c:420: }
      00BA9E 02 3D A4         [24] 1683 	ljmp	_ak820_key_override_reload
      00BAA1                       1684 00143$:
      00BAA1 22               [24] 1685 	ret
                                   1686 ;------------------------------------------------------------
                                   1687 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1688 ;------------------------------------------------------------
                                   1689 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_661'
                                   1690 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_668'
                                   1691 ;------------------------------------------------------------
                                   1692 ;	quantum/vial.c:424: void vial_keycode_down(uint16_t keycode) {
                                   1693 ;	-----------------------------------------
                                   1694 ;	 function vial_keycode_down
                                   1695 ;	-----------------------------------------
      00BAA2                       1696 _vial_keycode_down:
      00BAA2 12 38 86         [24] 1697 	lcall	_ak820_outline_0114
      00BAA5 90 0D 31         [24] 1698 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00BAA8 12 38 8B         [24] 1699 	lcall	_ak820_outline_0115
                                   1700 ;	quantum/vial.c:428: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00BAAB 90 0D 31         [24] 1701 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00BAAE 12 4E EC         [24] 1702 	lcall	_ak820_outline_0010
      00BAB1 74 E0            [12] 1703 	mov	a,#0x100 - 0x20
      00BAB3 2D               [12] 1704 	add	a,r5
      00BAB4 50 19            [24] 1705 	jnc	00104$
      00BAB6 C3               [12] 1706 	clr	c
      00BAB7 74 FF            [12] 1707 	mov	a,#0xff
      00BAB9 9C               [12] 1708 	subb	a,r4
      00BABA 74 4F            [12] 1709 	mov	a,#0x4f
      00BABC 9D               [12] 1710 	subb	a,r5
      00BABD 40 10            [24] 1711 	jc	00104$
                                   1712 ;	free result
                                   1713 ;	quantum/vial.c:429: keycode = (uint8_t)keycode;
      00BABF 90 0D 31         [24] 1714 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00BAC2 EE               [12] 1715 	mov	a,r6
      00BAC3 12 38 A6         [24] 1716 	lcall	_ak820_outline_0135
                                   1717 ;	quantum/vial.c:430: if (keycode <= KC_TRANSPARENT) return;
      00BAC6 90 0D 31         [24] 1718 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00BAC9 E0               [24] 1719 	movx	a,@dptr
      00BACA 24 FE            [12] 1720 	add	a,#0xff - 0x01
      00BACC 40 01            [24] 1721 	jc	00104$
                                   1722 ;	free result
      00BACE 22               [24] 1723 	ret
      00BACF                       1724 00104$:
                                   1725 ;	quantum/vial.c:433: g_vial_magic_keycode_override = keycode;
      00BACF 90 0D 31         [24] 1726 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00BAD2 12 BB 9A         [24] 1727 	lcall	_ak820_outline_0028
                                   1728 ;	quantum/vial.c:435: if (keycode <= QK_MODS_MAX) {
      00BAD5 40 06            [24] 1729 	jc	00107$
                                   1730 ;	free result
                                   1731 ;	quantum/vial.c:436: register_code16(keycode);
      00BAD7 12 38 90         [24] 1732 	lcall	_ak820_outline_0126
      00BADA 02 A5 BF         [24] 1733 	ljmp	_register_code16
      00BADD                       1734 00107$:
                                   1735 ;	quantum/vial.c:438: keyevent_t dummy_event = {
      00BADD 90 0D 37         [24] 1736 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0004)
      00BAE0 74 01            [12] 1737 	mov	a,#0x01
      00BAE2 F0               [24] 1738 	movx	@dptr,a
      00BAE3 90 0D 34         [24] 1739 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0001)
      00BAE6 74 F0            [12] 1740 	mov	a,#0xf0
      00BAE8 F0               [24] 1741 	movx	@dptr,a
      00BAE9 90 0D 33         [24] 1742 	mov	dptr,#_vial_keycode_down_dummy_event_30000_668
      00BAEC F0               [24] 1743 	movx	@dptr,a
      00BAED 90 0D 38         [24] 1744 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0005)
      00BAF0 74 01            [12] 1745 	mov	a,#0x01
      00BAF2 F0               [24] 1746 	movx	@dptr,a
      00BAF3 12 4F F4         [24] 1747 	lcall	_timer_read
      00BAF6 12 4A 1E         [24] 1748 	lcall	_ak820_outline_0144
      00BAF9 43 06 01         [24] 1749 	orl	ar6,#0x01
      00BAFC 90 0D 35         [24] 1750 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0002)
      00BAFF 12 4F 49         [24] 1751 	lcall	_ak820_outline_0064
                                   1752 ;	quantum/vial.c:442: AK820_ACTION_EXEC(dummy_event);
      00BB02 90 0D 33         [24] 1753 	mov	dptr,#_vial_keycode_down_dummy_event_30000_668
                                   1754 ;	quantum/vial.c:444: }
      00BB05 02 76 F3         [24] 1755 	ljmp	_ak820_action_exec
                                   1756 ;------------------------------------------------------------
                                   1757 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1758 ;------------------------------------------------------------
                                   1759 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_669'
                                   1760 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_676'
                                   1761 ;------------------------------------------------------------
                                   1762 ;	quantum/vial.c:446: void vial_keycode_up(uint16_t keycode) {
                                   1763 ;	-----------------------------------------
                                   1764 ;	 function vial_keycode_up
                                   1765 ;	-----------------------------------------
      00BB08                       1766 _vial_keycode_up:
      00BB08 12 38 86         [24] 1767 	lcall	_ak820_outline_0114
      00BB0B 90 0D 39         [24] 1768 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00BB0E 12 38 8B         [24] 1769 	lcall	_ak820_outline_0115
                                   1770 ;	quantum/vial.c:450: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00BB11 90 0D 39         [24] 1771 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00BB14 12 4E EC         [24] 1772 	lcall	_ak820_outline_0010
      00BB17 74 E0            [12] 1773 	mov	a,#0x100 - 0x20
      00BB19 2D               [12] 1774 	add	a,r5
      00BB1A 50 19            [24] 1775 	jnc	00104$
      00BB1C C3               [12] 1776 	clr	c
      00BB1D 74 FF            [12] 1777 	mov	a,#0xff
      00BB1F 9C               [12] 1778 	subb	a,r4
      00BB20 74 4F            [12] 1779 	mov	a,#0x4f
      00BB22 9D               [12] 1780 	subb	a,r5
      00BB23 40 10            [24] 1781 	jc	00104$
                                   1782 ;	free result
                                   1783 ;	quantum/vial.c:451: keycode = (uint8_t)keycode;
      00BB25 90 0D 39         [24] 1784 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00BB28 EE               [12] 1785 	mov	a,r6
      00BB29 12 38 A6         [24] 1786 	lcall	_ak820_outline_0135
                                   1787 ;	quantum/vial.c:452: if (keycode <= KC_TRANSPARENT) return;
      00BB2C 90 0D 39         [24] 1788 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00BB2F E0               [24] 1789 	movx	a,@dptr
      00BB30 24 FE            [12] 1790 	add	a,#0xff - 0x01
      00BB32 40 01            [24] 1791 	jc	00104$
                                   1792 ;	free result
      00BB34 22               [24] 1793 	ret
      00BB35                       1794 00104$:
                                   1795 ;	quantum/vial.c:455: g_vial_magic_keycode_override = keycode;
      00BB35 90 0D 39         [24] 1796 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00BB38 12 BB 9A         [24] 1797 	lcall	_ak820_outline_0028
                                   1798 ;	quantum/vial.c:457: if (keycode <= QK_MODS_MAX) {
      00BB3B 40 06            [24] 1799 	jc	00107$
                                   1800 ;	free result
                                   1801 ;	quantum/vial.c:458: unregister_code16(keycode);
      00BB3D 12 38 90         [24] 1802 	lcall	_ak820_outline_0126
      00BB40 02 A6 03         [24] 1803 	ljmp	_unregister_code16
      00BB43                       1804 00107$:
                                   1805 ;	quantum/vial.c:460: keyevent_t dummy_event = {
      00BB43 90 0D 3F         [24] 1806 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0004)
      00BB46 74 01            [12] 1807 	mov	a,#0x01
      00BB48 F0               [24] 1808 	movx	@dptr,a
      00BB49 90 0D 3C         [24] 1809 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0001)
      00BB4C 74 F0            [12] 1810 	mov	a,#0xf0
      00BB4E F0               [24] 1811 	movx	@dptr,a
      00BB4F 90 0D 3B         [24] 1812 	mov	dptr,#_vial_keycode_up_dummy_event_30000_676
      00BB52 F0               [24] 1813 	movx	@dptr,a
      00BB53 90 0D 40         [24] 1814 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0005)
      00BB56 E4               [12] 1815 	clr	a
      00BB57 F0               [24] 1816 	movx	@dptr,a
      00BB58 12 4F F4         [24] 1817 	lcall	_timer_read
      00BB5B 12 4A 1E         [24] 1818 	lcall	_ak820_outline_0144
      00BB5E 43 06 01         [24] 1819 	orl	ar6,#0x01
      00BB61 90 0D 3D         [24] 1820 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0002)
      00BB64 12 4F 49         [24] 1821 	lcall	_ak820_outline_0064
                                   1822 ;	quantum/vial.c:464: AK820_ACTION_EXEC(dummy_event);
      00BB67 90 0D 3B         [24] 1823 	mov	dptr,#_vial_keycode_up_dummy_event_30000_676
                                   1824 ;	quantum/vial.c:466: }
      00BB6A 02 76 F3         [24] 1825 	ljmp	_ak820_action_exec
                                   1826 ;------------------------------------------------------------
                                   1827 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1828 ;------------------------------------------------------------
                                   1829 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_677'
                                   1830 ;i             Allocated with name '_vial_keycode_tap_i_30000_680'
                                   1831 ;------------------------------------------------------------
                                   1832 ;	quantum/vial.c:468: void vial_keycode_tap(uint16_t keycode) {
                                   1833 ;	-----------------------------------------
                                   1834 ;	 function vial_keycode_tap
                                   1835 ;	-----------------------------------------
      00BB6D                       1836 _vial_keycode_tap:
      00BB6D 12 38 86         [24] 1837 	lcall	_ak820_outline_0114
      00BB70 90 0D 41         [24] 1838 	mov	dptr,#_vial_keycode_tap_keycode_10000_677
      00BB73 12 38 8B         [24] 1839 	lcall	_ak820_outline_0115
                                   1840 ;	quantum/vial.c:469: vial_keycode_down(keycode);
      00BB76 90 0D 41         [24] 1841 	mov	dptr,#_vial_keycode_tap_keycode_10000_677
      00BB79 12 37 F7         [24] 1842 	lcall	_ak820_outline_0006
      00BB7C C0 07            [24] 1843 	push	ar7
      00BB7E C0 06            [24] 1844 	push	ar6
      00BB80 51 A2            [12] 1845 	acall	_vial_keycode_down
      00BB82 D0 06            [24] 1846 	pop	ar6
      00BB84 D0 07            [24] 1847 	pop	ar7
                                   1848 ;	quantum/vial.c:471: vial_keycode_up(keycode);
      00BB86 12 38 90         [24] 1849 	lcall	_ak820_outline_0126
                                   1850 ;	quantum/vial.c:472: }
      00BB89 61 08            [12] 1851 	ajmp	_vial_keycode_up
                                   1852 ;------------------------------------------------------------
                                   1853 ;Allocation info for local variables in function 'process_record_vial'
                                   1854 ;------------------------------------------------------------
                                   1855 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1856 ;keycode       Allocated with name '_process_record_vial_keycode_10000_682'
                                   1857 ;------------------------------------------------------------
                                   1858 ;	quantum/vial.c:682: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1859 ;	-----------------------------------------
                                   1860 	.area CSEG    (CODE)
                                   1861 	.area CONST   (CODE)
                                   1862 	.area CONST   (CODE)
      00C6E3                       1863 _keyboard_definition:
      00C6E3 FD                    1864 	.db #0xfd	; 253
      00C6E4 37                    1865 	.db #0x37	; 55	'7'
      00C6E5 7A                    1866 	.db #0x7a	; 122	'z'
      00C6E6 58                    1867 	.db #0x58	; 88	'X'
      00C6E7 5A                    1868 	.db #0x5a	; 90	'Z'
      00C6E8 00                    1869 	.db #0x00	; 0
      00C6E9 00                    1870 	.db #0x00	; 0
      00C6EA 04                    1871 	.db #0x04	; 4
      00C6EB E6                    1872 	.db #0xe6	; 230
      00C6EC D6                    1873 	.db #0xd6	; 214
      00C6ED B4                    1874 	.db #0xb4	; 180
      00C6EE 46                    1875 	.db #0x46	; 70	'F'
      00C6EF 02                    1876 	.db #0x02	; 2
      00C6F0 00                    1877 	.db #0x00	; 0
      00C6F1 21                    1878 	.db #0x21	; 33
      00C6F2 01                    1879 	.db #0x01	; 1
      00C6F3 00                    1880 	.db #0x00	; 0
      00C6F4 00                    1881 	.db #0x00	; 0
      00C6F5 00                    1882 	.db #0x00	; 0
      00C6F6 00                    1883 	.db #0x00	; 0
      00C6F7 37                    1884 	.db #0x37	; 55	'7'
      00C6F8 27                    1885 	.db #0x27	; 39
      00C6F9 97                    1886 	.db #0x97	; 151
      00C6FA D6                    1887 	.db #0xd6	; 214
      00C6FB E0                    1888 	.db #0xe0	; 224
      00C6FC 03                    1889 	.db #0x03	; 3
      00C6FD CB                    1890 	.db #0xcb	; 203
      00C6FE 01                    1891 	.db #0x01	; 1
      00C6FF 3C                    1892 	.db #0x3c	; 60
      00C700 00                    1893 	.db #0x00	; 0
      00C701 00                    1894 	.db #0x00	; 0
      00C702 3D                    1895 	.db #0x3d	; 61
      00C703 88                    1896 	.db #0x88	; 136
      00C704 CD                    1897 	.db #0xcd	; 205
      00C705 A5                    1898 	.db #0xa5	; 165
      00C706 AA                    1899 	.db #0xaa	; 170
      00C707 E5                    1900 	.db #0xe5	; 229
      00C708 A8                    1901 	.db #0xa8	; 168
      00C709 76                    1902 	.db #0x76	; 118	'v'
      00C70A F6                    1903 	.db #0xf6	; 246
      00C70B 43                    1904 	.db #0x43	; 67	'C'
      00C70C 0E                    1905 	.db #0x0e	; 14
      00C70D D2                    1906 	.db #0xd2	; 210
      00C70E 90                    1907 	.db #0x90	; 144
      00C70F 7D                    1908 	.db #0x7d	; 125
      00C710 94                    1909 	.db #0x94	; 148
      00C711 79                    1910 	.db #0x79	; 121	'y'
      00C712 78                    1911 	.db #0x78	; 120	'x'
      00C713 EF                    1912 	.db #0xef	; 239
      00C714 49                    1913 	.db #0x49	; 73	'I'
      00C715 3E                    1914 	.db #0x3e	; 62
      00C716 EF                    1915 	.db #0xef	; 239
      00C717 FD                    1916 	.db #0xfd	; 253
      00C718 8F                    1917 	.db #0x8f	; 143
      00C719 EF                    1918 	.db #0xef	; 239
      00C71A 00                    1919 	.db #0x00	; 0
      00C71B C6                    1920 	.db #0xc6	; 198
      00C71C D1                    1921 	.db #0xd1	; 209
      00C71D DB                    1922 	.db #0xdb	; 219
      00C71E FB                    1923 	.db #0xfb	; 251
      00C71F EB                    1924 	.db #0xeb	; 235
      00C720 DE                    1925 	.db #0xde	; 222
      00C721 66                    1926 	.db #0x66	; 102	'f'
      00C722 63                    1927 	.db #0x63	; 99	'c'
      00C723 0C                    1928 	.db #0x0c	; 12
      00C724 92                    1929 	.db #0x92	; 146
      00C725 7B                    1930 	.db #0x7b	; 123
      00C726 F9                    1931 	.db #0xf9	; 249
      00C727 D4                    1932 	.db #0xd4	; 212
      00C728 7A                    1933 	.db #0x7a	; 122	'z'
      00C729 4F                    1934 	.db #0x4f	; 79	'O'
      00C72A 83                    1935 	.db #0x83	; 131
      00C72B 4B                    1936 	.db #0x4b	; 75	'K'
      00C72C 86                    1937 	.db #0x86	; 134
      00C72D 0E                    1938 	.db #0x0e	; 14
      00C72E 6A                    1939 	.db #0x6a	; 106	'j'
      00C72F F2                    1940 	.db #0xf2	; 242
      00C730 22                    1941 	.db #0x22	; 34
      00C731 22                    1942 	.db #0x22	; 34
      00C732 0B                    1943 	.db #0x0b	; 11
      00C733 03                    1944 	.db #0x03	; 3
      00C734 BA                    1945 	.db #0xba	; 186
      00C735 67                    1946 	.db #0x67	; 103	'g'
      00C736 9B                    1947 	.db #0x9b	; 155
      00C737 7A                    1948 	.db #0x7a	; 122	'z'
      00C738 E1                    1949 	.db #0xe1	; 225
      00C739 BC                    1950 	.db #0xbc	; 188
      00C73A 37                    1951 	.db #0x37	; 55	'7'
      00C73B 26                    1952 	.db #0x26	; 38
      00C73C 46                    1953 	.db #0x46	; 70	'F'
      00C73D 78                    1954 	.db #0x78	; 120	'x'
      00C73E 05                    1955 	.db #0x05	; 5
      00C73F 0D                    1956 	.db #0x0d	; 13
      00C740 95                    1957 	.db #0x95	; 149
      00C741 02                    1958 	.db #0x02	; 2
      00C742 E4                    1959 	.db #0xe4	; 228
      00C743 18                    1960 	.db #0x18	; 24
      00C744 CA                    1961 	.db #0xca	; 202
      00C745 33                    1962 	.db #0x33	; 51	'3'
      00C746 EA                    1963 	.db #0xea	; 234
      00C747 24                    1964 	.db #0x24	; 36
      00C748 C8                    1965 	.db #0xc8	; 200
      00C749 81                    1966 	.db #0x81	; 129
      00C74A 4E                    1967 	.db #0x4e	; 78	'N'
      00C74B 47                    1968 	.db #0x47	; 71	'G'
      00C74C A8                    1969 	.db #0xa8	; 168
      00C74D 44                    1970 	.db #0x44	; 68	'D'
      00C74E DD                    1971 	.db #0xdd	; 221
      00C74F 91                    1972 	.db #0x91	; 145
      00C750 6D                    1973 	.db #0x6d	; 109	'm'
      00C751 69                    1974 	.db #0x69	; 105	'i'
      00C752 DB                    1975 	.db #0xdb	; 219
      00C753 4F                    1976 	.db #0x4f	; 79	'O'
      00C754 3A                    1977 	.db #0x3a	; 58
      00C755 43                    1978 	.db #0x43	; 67	'C'
      00C756 9D                    1979 	.db #0x9d	; 157
      00C757 26                    1980 	.db #0x26	; 38
      00C758 49                    1981 	.db #0x49	; 73	'I'
      00C759 4C                    1982 	.db #0x4c	; 76	'L'
      00C75A EF                    1983 	.db #0xef	; 239
      00C75B 2B                    1984 	.db #0x2b	; 43
      00C75C D8                    1985 	.db #0xd8	; 216
      00C75D 55                    1986 	.db #0x55	; 85	'U'
      00C75E 95                    1987 	.db #0x95	; 149
      00C75F 70                    1988 	.db #0x70	; 112	'p'
      00C760 B1                    1989 	.db #0xb1	; 177
      00C761 CC                    1990 	.db #0xcc	; 204
      00C762 CF                    1991 	.db #0xcf	; 207
      00C763 13                    1992 	.db #0x13	; 19
      00C764 32                    1993 	.db #0x32	; 50	'2'
      00C765 6A                    1994 	.db #0x6a	; 106	'j'
      00C766 A1                    1995 	.db #0xa1	; 161
      00C767 FF                    1996 	.db #0xff	; 255
      00C768 99                    1997 	.db #0x99	; 153
      00C769 61                    1998 	.db #0x61	; 97	'a'
      00C76A 95                    1999 	.db #0x95	; 149
      00C76B B1                    2000 	.db #0xb1	; 177
      00C76C 89                    2001 	.db #0x89	; 137
      00C76D 9B                    2002 	.db #0x9b	; 155
      00C76E 11                    2003 	.db #0x11	; 17
      00C76F D9                    2004 	.db #0xd9	; 217
      00C770 35                    2005 	.db #0x35	; 53	'5'
      00C771 78                    2006 	.db #0x78	; 120	'x'
      00C772 ED                    2007 	.db #0xed	; 237
      00C773 CD                    2008 	.db #0xcd	; 205
      00C774 94                    2009 	.db #0x94	; 148
      00C775 6E                    2010 	.db #0x6e	; 110	'n'
      00C776 60                    2011 	.db #0x60	; 96
      00C777 8E                    2012 	.db #0x8e	; 142
      00C778 63                    2013 	.db #0x63	; 99	'c'
      00C779 8B                    2014 	.db #0x8b	; 139
      00C77A FF                    2015 	.db #0xff	; 255
      00C77B 4E                    2016 	.db #0x4e	; 78	'N'
      00C77C 20                    2017 	.db #0x20	; 32
      00C77D 7A                    2018 	.db #0x7a	; 122	'z'
      00C77E B5                    2019 	.db #0xb5	; 181
      00C77F 87                    2020 	.db #0x87	; 135
      00C780 C2                    2021 	.db #0xc2	; 194
      00C781 35                    2022 	.db #0x35	; 53	'5'
      00C782 A4                    2023 	.db #0xa4	; 164
      00C783 6D                    2024 	.db #0x6d	; 109	'm'
      00C784 18                    2025 	.db #0x18	; 24
      00C785 C1                    2026 	.db #0xc1	; 193
      00C786 A3                    2027 	.db #0xa3	; 163
      00C787 DB                    2028 	.db #0xdb	; 219
      00C788 53                    2029 	.db #0x53	; 83	'S'
      00C789 1D                    2030 	.db #0x1d	; 29
      00C78A EC                    2031 	.db #0xec	; 236
      00C78B F0                    2032 	.db #0xf0	; 240
      00C78C BF                    2033 	.db #0xbf	; 191
      00C78D 4A                    2034 	.db #0x4a	; 74	'J'
      00C78E 4C                    2035 	.db #0x4c	; 76	'L'
      00C78F 4A                    2036 	.db #0x4a	; 74	'J'
      00C790 C4                    2037 	.db #0xc4	; 196
      00C791 AA                    2038 	.db #0xaa	; 170
      00C792 37                    2039 	.db #0x37	; 55	'7'
      00C793 19                    2040 	.db #0x19	; 25
      00C794 34                    2041 	.db #0x34	; 52	'4'
      00C795 3F                    2042 	.db #0x3f	; 63
      00C796 A1                    2043 	.db #0xa1	; 161
      00C797 D3                    2044 	.db #0xd3	; 211
      00C798 1A                    2045 	.db #0x1a	; 26
      00C799 5C                    2046 	.db #0x5c	; 92
      00C79A 03                    2047 	.db #0x03	; 3
      00C79B 4D                    2048 	.db #0x4d	; 77	'M'
      00C79C BC                    2049 	.db #0xbc	; 188
      00C79D 10                    2050 	.db #0x10	; 16
      00C79E 2E                    2051 	.db #0x2e	; 46
      00C79F 80                    2052 	.db #0x80	; 128
      00C7A0 F7                    2053 	.db #0xf7	; 247
      00C7A1 D6                    2054 	.db #0xd6	; 214
      00C7A2 82                    2055 	.db #0x82	; 130
      00C7A3 24                    2056 	.db #0x24	; 36
      00C7A4 4C                    2057 	.db #0x4c	; 76	'L'
      00C7A5 87                    2058 	.db #0x87	; 135
      00C7A6 B9                    2059 	.db #0xb9	; 185
      00C7A7 F8                    2060 	.db #0xf8	; 248
      00C7A8 BE                    2061 	.db #0xbe	; 190
      00C7A9 67                    2062 	.db #0x67	; 103	'g'
      00C7AA 96                    2063 	.db #0x96	; 150
      00C7AB 89                    2064 	.db #0x89	; 137
      00C7AC 30                    2065 	.db #0x30	; 48	'0'
      00C7AD C8                    2066 	.db #0xc8	; 200
      00C7AE 8D                    2067 	.db #0x8d	; 141
      00C7AF 2C                    2068 	.db #0x2c	; 44
      00C7B0 F5                    2069 	.db #0xf5	; 245
      00C7B1 06                    2070 	.db #0x06	; 6
      00C7B2 05                    2071 	.db #0x05	; 5
      00C7B3 7C                    2072 	.db #0x7c	; 124
      00C7B4 48                    2073 	.db #0x48	; 72	'H'
      00C7B5 1B                    2074 	.db #0x1b	; 27
      00C7B6 76                    2075 	.db #0x76	; 118	'v'
      00C7B7 AA                    2076 	.db #0xaa	; 170
      00C7B8 3D                    2077 	.db #0x3d	; 61
      00C7B9 28                    2078 	.db #0x28	; 40
      00C7BA FC                    2079 	.db #0xfc	; 252
      00C7BB 80                    2080 	.db #0x80	; 128
      00C7BC 75                    2081 	.db #0x75	; 117	'u'
      00C7BD EB                    2082 	.db #0xeb	; 235
      00C7BE 78                    2083 	.db #0x78	; 120	'x'
      00C7BF D0                    2084 	.db #0xd0	; 208
      00C7C0 8A                    2085 	.db #0x8a	; 138
      00C7C1 8F                    2086 	.db #0x8f	; 143
      00C7C2 27                    2087 	.db #0x27	; 39
      00C7C3 F7                    2088 	.db #0xf7	; 247
      00C7C4 F2                    2089 	.db #0xf2	; 242
      00C7C5 EB                    2090 	.db #0xeb	; 235
      00C7C6 58                    2091 	.db #0x58	; 88	'X'
      00C7C7 37                    2092 	.db #0x37	; 55	'7'
      00C7C8 3C                    2093 	.db #0x3c	; 60
      00C7C9 2B                    2094 	.db #0x2b	; 43
      00C7CA 6F                    2095 	.db #0x6f	; 111	'o'
      00C7CB 0E                    2096 	.db #0x0e	; 14
      00C7CC C7                    2097 	.db #0xc7	; 199
      00C7CD E2                    2098 	.db #0xe2	; 226
      00C7CE A0                    2099 	.db #0xa0	; 160
      00C7CF 97                    2100 	.db #0x97	; 151
      00C7D0 EE                    2101 	.db #0xee	; 238
      00C7D1 FD                    2102 	.db #0xfd	; 253
      00C7D2 9F                    2103 	.db #0x9f	; 159
      00C7D3 45                    2104 	.db #0x45	; 69	'E'
      00C7D4 17                    2105 	.db #0x17	; 23
      00C7D5 94                    2106 	.db #0x94	; 148
      00C7D6 E6                    2107 	.db #0xe6	; 230
      00C7D7 E7                    2108 	.db #0xe7	; 231
      00C7D8 FA                    2109 	.db #0xfa	; 250
      00C7D9 4C                    2110 	.db #0x4c	; 76	'L'
      00C7DA 7A                    2111 	.db #0x7a	; 122	'z'
      00C7DB D6                    2112 	.db #0xd6	; 214
      00C7DC 7A                    2113 	.db #0x7a	; 122	'z'
      00C7DD 7B                    2114 	.db #0x7b	; 123
      00C7DE ED                    2115 	.db #0xed	; 237
      00C7DF 10                    2116 	.db #0x10	; 16
      00C7E0 C5                    2117 	.db #0xc5	; 197
      00C7E1 BC                    2118 	.db #0xbc	; 188
      00C7E2 E3                    2119 	.db #0xe3	; 227
      00C7E3 A9                    2120 	.db #0xa9	; 169
      00C7E4 1F                    2121 	.db #0x1f	; 31
      00C7E5 CF                    2122 	.db #0xcf	; 207
      00C7E6 C4                    2123 	.db #0xc4	; 196
      00C7E7 9D                    2124 	.db #0x9d	; 157
      00C7E8 DC                    2125 	.db #0xdc	; 220
      00C7E9 45                    2126 	.db #0x45	; 69	'E'
      00C7EA 2A                    2127 	.db #0x2a	; 42
      00C7EB 69                    2128 	.db #0x69	; 105	'i'
      00C7EC 57                    2129 	.db #0x57	; 87	'W'
      00C7ED 8F                    2130 	.db #0x8f	; 143
      00C7EE EC                    2131 	.db #0xec	; 236
      00C7EF 85                    2132 	.db #0x85	; 133
      00C7F0 6C                    2133 	.db #0x6c	; 108	'l'
      00C7F1 43                    2134 	.db #0x43	; 67	'C'
      00C7F2 1C                    2135 	.db #0x1c	; 28
      00C7F3 BA                    2136 	.db #0xba	; 186
      00C7F4 89                    2137 	.db #0x89	; 137
      00C7F5 68                    2138 	.db #0x68	; 104	'h'
      00C7F6 4A                    2139 	.db #0x4a	; 74	'J'
      00C7F7 1C                    2140 	.db #0x1c	; 28
      00C7F8 91                    2141 	.db #0x91	; 145
      00C7F9 3F                    2142 	.db #0x3f	; 63
      00C7FA D1                    2143 	.db #0xd1	; 209
      00C7FB B3                    2144 	.db #0xb3	; 179
      00C7FC 96                    2145 	.db #0x96	; 150
      00C7FD 1D                    2146 	.db #0x1d	; 29
      00C7FE 7C                    2147 	.db #0x7c	; 124
      00C7FF 14                    2148 	.db #0x14	; 20
      00C800 77                    2149 	.db #0x77	; 119	'w'
      00C801 9C                    2150 	.db #0x9c	; 156
      00C802 74                    2151 	.db #0x74	; 116	't'
      00C803 36                    2152 	.db #0x36	; 54	'6'
      00C804 FF                    2153 	.db #0xff	; 255
      00C805 2C                    2154 	.db #0x2c	; 44
      00C806 66                    2155 	.db #0x66	; 102	'f'
      00C807 AF                    2156 	.db #0xaf	; 175
      00C808 0F                    2157 	.db #0x0f	; 15
      00C809 3C                    2158 	.db #0x3c	; 60
      00C80A A2                    2159 	.db #0xa2	; 162
      00C80B 23                    2160 	.db #0x23	; 35
      00C80C 85                    2161 	.db #0x85	; 133
      00C80D 05                    2162 	.db #0x05	; 5
      00C80E 87                    2163 	.db #0x87	; 135
      00C80F DA                    2164 	.db #0xda	; 218
      00C810 61                    2165 	.db #0x61	; 97	'a'
      00C811 5E                    2166 	.db #0x5e	; 94
      00C812 42                    2167 	.db #0x42	; 66	'B'
      00C813 54                    2168 	.db #0x54	; 84	'T'
      00C814 60                    2169 	.db #0x60	; 96
      00C815 23                    2170 	.db #0x23	; 35
      00C816 CA                    2171 	.db #0xca	; 202
      00C817 BC                    2172 	.db #0xbc	; 188
      00C818 B3                    2173 	.db #0xb3	; 179
      00C819 18                    2174 	.db #0x18	; 24
      00C81A 1D                    2175 	.db #0x1d	; 29
      00C81B F8                    2176 	.db #0xf8	; 248
      00C81C 0A                    2177 	.db #0x0a	; 10
      00C81D 55                    2178 	.db #0x55	; 85	'U'
      00C81E CD                    2179 	.db #0xcd	; 205
      00C81F A3                    2180 	.db #0xa3	; 163
      00C820 DE                    2181 	.db #0xde	; 222
      00C821 FF                    2182 	.db #0xff	; 255
      00C822 B2                    2183 	.db #0xb2	; 178
      00C823 2A                    2184 	.db #0x2a	; 42
      00C824 35                    2185 	.db #0x35	; 53	'5'
      00C825 00                    2186 	.db #0x00	; 0
      00C826 D6                    2187 	.db #0xd6	; 214
      00C827 7B                    2188 	.db #0x7b	; 123
      00C828 E8                    2189 	.db #0xe8	; 232
      00C829 F2                    2190 	.db #0xf2	; 242
      00C82A 1A                    2191 	.db #0x1a	; 26
      00C82B BC                    2192 	.db #0xbc	; 188
      00C82C F5                    2193 	.db #0xf5	; 245
      00C82D 7E                    2194 	.db #0x7e	; 126
      00C82E 48                    2195 	.db #0x48	; 72	'H'
      00C82F 72                    2196 	.db #0x72	; 114	'r'
      00C830 E0                    2197 	.db #0xe0	; 224
      00C831 E4                    2198 	.db #0xe4	; 228
      00C832 E0                    2199 	.db #0xe0	; 224
      00C833 27                    2200 	.db #0x27	; 39
      00C834 87                    2201 	.db #0x87	; 135
      00C835 9A                    2202 	.db #0x9a	; 154
      00C836 51                    2203 	.db #0x51	; 81	'Q'
      00C837 D4                    2204 	.db #0xd4	; 212
      00C838 DD                    2205 	.db #0xdd	; 221
      00C839 C3                    2206 	.db #0xc3	; 195
      00C83A AA                    2207 	.db #0xaa	; 170
      00C83B 49                    2208 	.db #0x49	; 73	'I'
      00C83C 5A                    2209 	.db #0x5a	; 90	'Z'
      00C83D 2A                    2210 	.db #0x2a	; 42
      00C83E 00                    2211 	.db #0x00	; 0
      00C83F A0                    2212 	.db #0xa0	; 160
      00C840 8C                    2213 	.db #0x8c	; 140
      00C841 FF                    2214 	.db #0xff	; 255
      00C842 74                    2215 	.db #0x74	; 116	't'
      00C843 BF                    2216 	.db #0xbf	; 191
      00C844 EC                    2217 	.db #0xec	; 236
      00C845 1D                    2218 	.db #0x1d	; 29
      00C846 F1                    2219 	.db #0xf1	; 241
      00C847 00                    2220 	.db #0x00	; 0
      00C848 01                    2221 	.db #0x01	; 1
      00C849 D8                    2222 	.db #0xd8	; 216
      00C84A 02                    2223 	.db #0x02	; 2
      00C84B CC                    2224 	.db #0xcc	; 204
      00C84C 07                    2225 	.db #0x07	; 7
      00C84D 00                    2226 	.db #0x00	; 0
      00C84E 00                    2227 	.db #0x00	; 0
      00C84F C4                    2228 	.db #0xc4	; 196
      00C850 5E                    2229 	.db #0x5e	; 94
      00C851 2C                    2230 	.db #0x2c	; 44
      00C852 7E                    2231 	.db #0x7e	; 126
      00C853 B1                    2232 	.db #0xb1	; 177
      00C854 C4                    2233 	.db #0xc4	; 196
      00C855 67                    2234 	.db #0x67	; 103	'g'
      00C856 FB                    2235 	.db #0xfb	; 251
      00C857 02                    2236 	.db #0x02	; 2
      00C858 00                    2237 	.db #0x00	; 0
      00C859 00                    2238 	.db #0x00	; 0
      00C85A 00                    2239 	.db #0x00	; 0
      00C85B 00                    2240 	.db #0x00	; 0
      00C85C 04                    2241 	.db #0x04	; 4
      00C85D 59                    2242 	.db #0x59	; 89	'Y'
      00C85E 5A                    2243 	.db #0x5a	; 90	'Z'
                                   2244 	.area CSEG    (CODE)
                                   2245 	.area CONST   (CODE)
      00C85F                       2246 _vial_handle_cmd_keyboard_uid_40000_632:
      00C85F 04                    2247 	.db #0x04	; 4
      00C860 70                    2248 	.db #0x70	; 112	'p'
      00C861 FF                    2249 	.db #0xff	; 255
      00C862 90                    2250 	.db #0x90	; 144
      00C863 01                    2251 	.db #0x01	; 1
      00C864 B9                    2252 	.db #0xb9	; 185
      00C865 15                    2253 	.db #0x15	; 21
      00C866 D3                    2254 	.db #0xd3	; 211
                                   2255 	.area CSEG    (CODE)
                                   2256 	.area XINIT   (CODE)
      00CA98                       2257 __xinit__vial_unlocked:
      00CA98 00                    2258 	.db #0x00	;  0
      00CA99                       2259 __xinit__vial_unlock_in_progress:
      00CA99 00                    2260 	.db #0x00	;  0
      00CA9A                       2261 __xinit__vial_unlock_counter:
      00CA9A 00                    2262 	.db #0x00	; 0
      00CA9B                       2263 __xinit__vial_unlock_combo_rows:
      00CA9B 00                    2264 	.db #0x00	; 0
      00CA9C 00                    2265 	.db #0x00	; 0
      00CA9D                       2266 __xinit__vial_unlock_combo_cols:
      00CA9D 00                    2267 	.db #0x00	; 0
      00CA9E 05                    2268 	.db #0x05	; 5
                                   2269 	.area CABS    (ABS,CODE)
                                   2270 
                                   2271 ; Experimental exact instruction outlining.
                                   2272 	.globl _ak820_outline_0006
                                   2273 	.globl _ak820_outline_0008
                                   2274 	.globl _ak820_outline_0009
                                   2275 	.globl _ak820_outline_0010
                                   2276 	.globl _ak820_outline_0012
                                   2277 	.globl _ak820_outline_0016
                                   2278 	.globl _ak820_outline_0018
                                   2279 	.globl _ak820_outline_0020
                                   2280 	.globl _ak820_outline_0022
                                   2281 	.globl _ak820_outline_0027
                                   2282 	.globl _ak820_outline_0028
                                   2283 	.globl _ak820_outline_0034
                                   2284 	.globl _ak820_outline_0035
                                   2285 	.globl _ak820_outline_0036
                                   2286 	.globl _ak820_outline_0037
                                   2287 	.globl _ak820_outline_0041
                                   2288 	.globl _ak820_outline_0057
                                   2289 	.globl _ak820_outline_0060
                                   2290 	.globl _ak820_outline_0062
                                   2291 	.globl _ak820_outline_0064
                                   2292 	.globl _ak820_outline_0070
                                   2293 	.globl _ak820_outline_0077
                                   2294 	.globl _ak820_outline_0090
                                   2295 	.globl _ak820_outline_0109
                                   2296 	.globl _ak820_outline_0114
                                   2297 	.globl _ak820_outline_0115
                                   2298 	.globl _ak820_outline_0126
                                   2299 	.globl _ak820_outline_0129
                                   2300 	.globl _ak820_outline_0133
                                   2301 	.globl _ak820_outline_0134
                                   2302 	.globl _ak820_outline_0135
                                   2303 	.globl _ak820_outline_0137
                                   2304 	.globl _ak820_outline_0138
                                   2305 	.globl _ak820_outline_0144
                                   2306 	.globl _ak820_outline_0146
                                   2307 	.globl _ak820_outline_0149
                                   2308 	.globl _ak820_outline_0150
                                   2309 	.globl _ak820_outline_0166
                                   2310 	.globl _ak820_outline_0167
                                   2311 	.globl _ak820_outline_0168
                                   2312 	.globl _ak820_outline_0197
                                   2313 
                                   2314 	.area CSEG (CODE)
                                   2315 ; function ak820_outline_0009
      00BB8B                       2316 _ak820_outline_0009:
      00BB8B A3               [24] 2317 	inc	dptr
      00BB8C F0               [24] 2318 	movx	@dptr,a
      00BB8D E4               [12] 2319 	clr	a
      00BB8E A3               [24] 2320 	inc	dptr
      00BB8F F0               [24] 2321 	movx	@dptr,a
      00BB90 90 0E 5A         [24] 2322 	mov	dptr,#___memcpy_PARM_3
      00BB93 74 0A            [12] 2323 	mov	a,#0x0a
      00BB95 F0               [24] 2324 	movx	@dptr,a
      00BB96 E4               [12] 2325 	clr	a
      00BB97 A3               [24] 2326 	inc	dptr
      00BB98 F0               [24] 2327 	movx	@dptr,a
      00BB99 22               [24] 2328 	ret
                                   2329 
                                   2330 	.area CSEG (CODE)
                                   2331 ; function ak820_outline_0028
      00BB9A                       2332 _ak820_outline_0028:
      00BB9A E0               [24] 2333 	movx	a,@dptr
      00BB9B FE               [12] 2334 	mov	r6,a
      00BB9C A3               [24] 2335 	inc	dptr
      00BB9D E0               [24] 2336 	movx	a,@dptr
      00BB9E FF               [12] 2337 	mov	r7,a
      00BB9F 90 0D 2F         [24] 2338 	mov	dptr,#_g_vial_magic_keycode_override
      00BBA2 EE               [12] 2339 	mov	a,r6
      00BBA3 F0               [24] 2340 	movx	@dptr,a
      00BBA4 EF               [12] 2341 	mov	a,r7
      00BBA5 A3               [24] 2342 	inc	dptr
      00BBA6 F0               [24] 2343 	movx	@dptr,a
      00BBA7 8E 04            [24] 2344 	mov	ar4,r6
      00BBA9 8F 05            [24] 2345 	mov	ar5,r7
      00BBAB C3               [12] 2346 	clr	c
      00BBAC 74 FF            [12] 2347 	mov	a,#0xff
      00BBAE 9C               [12] 2348 	subb	a,r4
      00BBAF 74 1F            [12] 2349 	mov	a,#0x1f
      00BBB1 9D               [12] 2350 	subb	a,r5
      00BBB2 22               [24] 2351 	ret
                                   2352 
                                   2353 	.area CSEG (CODE)
                                   2354 ; function ak820_outline_0137
      00BBB3                       2355 _ak820_outline_0137:
      00BBB3 24 DF            [12] 2356 	add	a,#_vial_unlock_combo_cols
      00BBB5 F5 82            [12] 2357 	mov	dpl,a
      00BBB7 E4               [12] 2358 	clr	a
      00BBB8 34 0E            [12] 2359 	addc	a,#(_vial_unlock_combo_cols>>8)
      00BBBA F5 83            [12] 2360 	mov	dph,a
      00BBBC E0               [24] 2361 	movx	a,@dptr
      00BBBD 22               [24] 2362 	ret
                                   2363 
                                   2364 	.area CSEG (CODE)
                                   2365 ; function ak820_outline_0138
      00BBBE                       2366 _ak820_outline_0138:
      00BBBE 24 DD            [12] 2367 	add	a,#_vial_unlock_combo_rows
      00BBC0 F5 82            [12] 2368 	mov	dpl,a
      00BBC2 E4               [12] 2369 	clr	a
      00BBC3 34 0E            [12] 2370 	addc	a,#(_vial_unlock_combo_rows>>8)
      00BBC5 F5 83            [12] 2371 	mov	dph,a
      00BBC7 E0               [24] 2372 	movx	a,@dptr
      00BBC8 22               [24] 2373 	ret
