                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_key_override_cancel
                                     21 	.globl _pre_process_record_quantum
                                     22 	.globl _get_record_keycode
                                     23 	.globl _repeat_key_cancel
                                     24 	.globl _clear_owned_usages
                                     25 	.globl _owned_usage_key
                                     26 	.globl _clear_owned_keys
                                     27 	.globl _del_owned_key
                                     28 	.globl _add_owned_key
                                     29 	.globl _clear_owned_mods
                                     30 	.globl _del_owned_weak_mods
                                     31 	.globl _add_owned_weak_mods
                                     32 	.globl _del_owned_mods
                                     33 	.globl _add_owned_mods
                                     34 	.globl _clear_weak_mods
                                     35 	.globl _clear_mods
                                     36 	.globl _send_keyboard_report
                                     37 	.globl _layer_hold_clear
                                     38 	.globl _layer_hold_off
                                     39 	.globl _layer_hold_on
                                     40 	.globl _ak820_resolve_key
                                     41 	.globl _layer_xor
                                     42 	.globl _layer_and
                                     43 	.globl _layer_or
                                     44 	.globl _layer_off
                                     45 	.globl _layer_on
                                     46 	.globl _layer_move
                                     47 	.globl _layer_clear
                                     48 	.globl _layer_state_set
                                     49 	.globl _default_layer_xor
                                     50 	.globl _default_layer_and
                                     51 	.globl _default_layer_or
                                     52 	.globl _default_layer_set
                                     53 	.globl _post_process_record_quantum
                                     54 	.globl _process_record_quantum
                                     55 	.globl _action_for_keycode
                                     56 	.globl _mDelaymS
                                     57 	.globl _host_consumer_send
                                     58 	.globl _host_system_send
                                     59 	.globl _host_keyboard_leds
                                     60 	.globl _led_set
                                     61 	.globl _clear_keys_from_report
                                     62 	.globl ___memcpy
                                     63 	.globl _ADC_START
                                     64 	.globl _S0_R_FIFO
                                     65 	.globl _S0_T_FIFO
                                     66 	.globl _S0_FREE
                                     67 	.globl _S0_IF_BYTE
                                     68 	.globl _S0_IF_FIRST
                                     69 	.globl _S0_IF_OV
                                     70 	.globl _S0_FST_ACT
                                     71 	.globl _CP_RL2
                                     72 	.globl _C_T2
                                     73 	.globl _TR2
                                     74 	.globl _EXEN2
                                     75 	.globl _TCLK
                                     76 	.globl _RCLK
                                     77 	.globl _EXF2
                                     78 	.globl _CAP1F
                                     79 	.globl _TF2
                                     80 	.globl _RI
                                     81 	.globl _TI
                                     82 	.globl _RB8
                                     83 	.globl _TB8
                                     84 	.globl _REN
                                     85 	.globl _SM2
                                     86 	.globl _SM1
                                     87 	.globl _SM0
                                     88 	.globl _IT0
                                     89 	.globl _IE0
                                     90 	.globl _IT1
                                     91 	.globl _IE1
                                     92 	.globl _TR0
                                     93 	.globl _TF0
                                     94 	.globl _TR1
                                     95 	.globl _TF1
                                     96 	.globl _P4_0
                                     97 	.globl _P4_1
                                     98 	.globl _P4_2
                                     99 	.globl _P4_3
                                    100 	.globl _P4_4
                                    101 	.globl _P4_5
                                    102 	.globl _P4_6
                                    103 	.globl _RXD
                                    104 	.globl _TXD
                                    105 	.globl _INT0
                                    106 	.globl _INT1
                                    107 	.globl _T0
                                    108 	.globl _T1
                                    109 	.globl _MOSI1
                                    110 	.globl _MISO1
                                    111 	.globl _SCK1
                                    112 	.globl _P3_0
                                    113 	.globl _P3_1
                                    114 	.globl _P3_2
                                    115 	.globl _P3_3
                                    116 	.globl _P3_4
                                    117 	.globl _P3_5
                                    118 	.globl _P3_6
                                    119 	.globl _P3_7
                                    120 	.globl _CAP1_
                                    121 	.globl _T2_
                                    122 	.globl _CAP2_
                                    123 	.globl _T2EX_
                                    124 	.globl _RXD1
                                    125 	.globl _TXD1
                                    126 	.globl _P2_0
                                    127 	.globl _P2_1
                                    128 	.globl _P2_2
                                    129 	.globl _P2_3
                                    130 	.globl _P2_4
                                    131 	.globl _P2_5
                                    132 	.globl _P2_6
                                    133 	.globl _P2_7
                                    134 	.globl _AIN0
                                    135 	.globl _AIN1
                                    136 	.globl _AIN2
                                    137 	.globl _AIN3
                                    138 	.globl _AIN4
                                    139 	.globl _AIN5
                                    140 	.globl _AIN6
                                    141 	.globl _AIN7
                                    142 	.globl _CAP1
                                    143 	.globl _T2
                                    144 	.globl _CAP2
                                    145 	.globl _T2EX
                                    146 	.globl _INT0_
                                    147 	.globl _SCS
                                    148 	.globl _MOSI
                                    149 	.globl _MISO
                                    150 	.globl _SCK
                                    151 	.globl _RXD1_
                                    152 	.globl _TXD1_
                                    153 	.globl _P1_0
                                    154 	.globl _P1_1
                                    155 	.globl _P1_2
                                    156 	.globl _P1_3
                                    157 	.globl _P1_4
                                    158 	.globl _P1_5
                                    159 	.globl _P1_6
                                    160 	.globl _P1_7
                                    161 	.globl _AIN8
                                    162 	.globl _AIN9
                                    163 	.globl _AIN10
                                    164 	.globl _AIN11
                                    165 	.globl _AIN12
                                    166 	.globl _AIN13
                                    167 	.globl _RXD_
                                    168 	.globl _TXD_
                                    169 	.globl _SCL0
                                    170 	.globl _SDA0
                                    171 	.globl _P0_0
                                    172 	.globl _P0_1
                                    173 	.globl _P0_2
                                    174 	.globl _P0_3
                                    175 	.globl _P0_4
                                    176 	.globl _P0_5
                                    177 	.globl _P0_6
                                    178 	.globl _P0_7
                                    179 	.globl _IE_SPI0
                                    180 	.globl _IE_USB
                                    181 	.globl _IE_ADC
                                    182 	.globl _IE_UART1
                                    183 	.globl _IE_PWM_I2C
                                    184 	.globl _IE_GPIO
                                    185 	.globl _IE_WDOG
                                    186 	.globl _PX0
                                    187 	.globl _PT0
                                    188 	.globl _PX1
                                    189 	.globl _PT1
                                    190 	.globl _PS
                                    191 	.globl _PT2
                                    192 	.globl _PL_FLAG
                                    193 	.globl _PH_FLAG
                                    194 	.globl _EX0
                                    195 	.globl _ET0
                                    196 	.globl _EX1
                                    197 	.globl _ET1
                                    198 	.globl _ES
                                    199 	.globl _ET2
                                    200 	.globl _E_DIS
                                    201 	.globl _EA
                                    202 	.globl _P
                                    203 	.globl _F1
                                    204 	.globl _OV
                                    205 	.globl _RS0
                                    206 	.globl _RS1
                                    207 	.globl _F0
                                    208 	.globl _AC
                                    209 	.globl _CY
                                    210 	.globl _I2CS_INT_ST
                                    211 	.globl _I2CX_INT
                                    212 	.globl _LED_STATUS
                                    213 	.globl _LED_DMA_H
                                    214 	.globl _LED_DMA_L
                                    215 	.globl _LED_DMA
                                    216 	.globl _LED_PWM_OE
                                    217 	.globl _LED_COMMON
                                    218 	.globl _ADC_CHAN
                                    219 	.globl _ADC_DAT_H
                                    220 	.globl _ADC_DAT_L
                                    221 	.globl _ADC_DAT
                                    222 	.globl _ADC_CTRL
                                    223 	.globl _SPI1_CK_SE
                                    224 	.globl _SPI1_CTRL
                                    225 	.globl _SPI1_DATA
                                    226 	.globl _SPI1_STAT
                                    227 	.globl _SIF1
                                    228 	.globl _SBAUD1
                                    229 	.globl _SBUF1
                                    230 	.globl _SCON1
                                    231 	.globl _SPI0_SETUP
                                    232 	.globl _SPI0_CK_SE
                                    233 	.globl _SPI0_CTRL
                                    234 	.globl _SPI0_DATA
                                    235 	.globl _SPI0_STAT
                                    236 	.globl _T2CAP1H
                                    237 	.globl _T2CAP1L
                                    238 	.globl _T2CAP1
                                    239 	.globl _TH2
                                    240 	.globl _TL2
                                    241 	.globl _T2COUNT
                                    242 	.globl _RCAP2H
                                    243 	.globl _RCAP2L
                                    244 	.globl _RCAP2
                                    245 	.globl _T2MOD
                                    246 	.globl _T2CON
                                    247 	.globl _SBUF
                                    248 	.globl _SCON
                                    249 	.globl _TH1
                                    250 	.globl _TH0
                                    251 	.globl _TL1
                                    252 	.globl _TL0
                                    253 	.globl _TMOD
                                    254 	.globl _TCON
                                    255 	.globl _XBUS_AUX
                                    256 	.globl _P7
                                    257 	.globl _P6_DIR
                                    258 	.globl _P6_OUT_PU
                                    259 	.globl _P6_IN
                                    260 	.globl _P5_DIR
                                    261 	.globl _P5_OUT_PU
                                    262 	.globl _P5_IN
                                    263 	.globl _P4_LED_KEY
                                    264 	.globl _P4_DIR_PU
                                    265 	.globl _P4_MOD_OC
                                    266 	.globl _P4
                                    267 	.globl _P3_DIR_PU
                                    268 	.globl _P3_MOD_OC
                                    269 	.globl _P3
                                    270 	.globl _P2_DIR_PU
                                    271 	.globl _P2_MOD_OC
                                    272 	.globl _P2
                                    273 	.globl _P1_DIR_PU
                                    274 	.globl _P1_MOD_OC
                                    275 	.globl _P1
                                    276 	.globl _P0_DIR_PU
                                    277 	.globl _P0_MOD_OC
                                    278 	.globl _P0
                                    279 	.globl _ROM_CTRL
                                    280 	.globl _ROM_DATA_HH
                                    281 	.globl _ROM_DATA_HL
                                    282 	.globl _ROM_DATA_HI
                                    283 	.globl _ROM_ADDR_H
                                    284 	.globl _ROM_ADDR_L
                                    285 	.globl _ROM_ADDR
                                    286 	.globl _GPIO_IE
                                    287 	.globl _IP_EX
                                    288 	.globl _IE_EX
                                    289 	.globl _IP
                                    290 	.globl _IE
                                    291 	.globl _WDOG_COUNT
                                    292 	.globl _RESET_KEEP
                                    293 	.globl _WAKE_CTRL
                                    294 	.globl _CLOCK_CFG
                                    295 	.globl _POWER_CFG
                                    296 	.globl _PCON
                                    297 	.globl _GLOBAL_CFG
                                    298 	.globl _SAFE_MOD
                                    299 	.globl _DPH
                                    300 	.globl _DPL
                                    301 	.globl _SP
                                    302 	.globl _A_INV
                                    303 	.globl _B
                                    304 	.globl _ACC
                                    305 	.globl _PSW
                                    306 	.globl _disable_action_cache
                                    307 	.globl _tap_code_delay_PARM_2
                                    308 	.globl _process_action_PARM_2
                                    309 	.globl _action_exec_PARM_1
                                    310 	.globl _tp_buttons
                                    311 	.globl _action_exec
                                    312 	.globl _ak820_action_exec
                                    313 	.globl _process_record
                                    314 	.globl _process_record_handler
                                    315 	.globl _process_action
                                    316 	.globl _register_code
                                    317 	.globl _unregister_code
                                    318 	.globl _tap_code_delay
                                    319 	.globl _tap_code
                                    320 	.globl _register_mods
                                    321 	.globl _unregister_mods
                                    322 	.globl _register_weak_mods
                                    323 	.globl _unregister_weak_mods
                                    324 	.globl _clear_keyboard
                                    325 	.globl _clear_keyboard_but_mods
                                    326 	.globl _clear_keyboard_but_mods_and_keys
                                    327 ;--------------------------------------------------------
                                    328 ; special function registers
                                    329 ;--------------------------------------------------------
                                    330 	.area RSEG    (ABS,DATA)
      000000                        331 	.org 0x0000
                           0000D0   332 _PSW	=	0x00d0
                           0000E0   333 _ACC	=	0x00e0
                           0000F0   334 _B	=	0x00f0
                           0000FD   335 _A_INV	=	0x00fd
                           000081   336 _SP	=	0x0081
                           000082   337 _DPL	=	0x0082
                           000083   338 _DPH	=	0x0083
                           0000A1   339 _SAFE_MOD	=	0x00a1
                           0000B1   340 _GLOBAL_CFG	=	0x00b1
                           000087   341 _PCON	=	0x0087
                           0000BA   342 _POWER_CFG	=	0x00ba
                           0000B9   343 _CLOCK_CFG	=	0x00b9
                           0000A9   344 _WAKE_CTRL	=	0x00a9
                           0000FE   345 _RESET_KEEP	=	0x00fe
                           0000FF   346 _WDOG_COUNT	=	0x00ff
                           0000A8   347 _IE	=	0x00a8
                           0000B8   348 _IP	=	0x00b8
                           0000E8   349 _IE_EX	=	0x00e8
                           0000E9   350 _IP_EX	=	0x00e9
                           0000B2   351 _GPIO_IE	=	0x00b2
                           008584   352 _ROM_ADDR	=	0x8584
                           000084   353 _ROM_ADDR_L	=	0x0084
                           000085   354 _ROM_ADDR_H	=	0x0085
                           008F8E   355 _ROM_DATA_HI	=	0x8f8e
                           00008E   356 _ROM_DATA_HL	=	0x008e
                           00008F   357 _ROM_DATA_HH	=	0x008f
                           000086   358 _ROM_CTRL	=	0x0086
                           000080   359 _P0	=	0x0080
                           0000C4   360 _P0_MOD_OC	=	0x00c4
                           0000C5   361 _P0_DIR_PU	=	0x00c5
                           000090   362 _P1	=	0x0090
                           000092   363 _P1_MOD_OC	=	0x0092
                           000093   364 _P1_DIR_PU	=	0x0093
                           0000A0   365 _P2	=	0x00a0
                           000094   366 _P2_MOD_OC	=	0x0094
                           000095   367 _P2_DIR_PU	=	0x0095
                           0000B0   368 _P3	=	0x00b0
                           000096   369 _P3_MOD_OC	=	0x0096
                           000097   370 _P3_DIR_PU	=	0x0097
                           0000C0   371 _P4	=	0x00c0
                           0000C2   372 _P4_MOD_OC	=	0x00c2
                           0000C3   373 _P4_DIR_PU	=	0x00c3
                           0000C1   374 _P4_LED_KEY	=	0x00c1
                           0000AA   375 _P5_IN	=	0x00aa
                           0000AB   376 _P5_OUT_PU	=	0x00ab
                           0000AC   377 _P5_DIR	=	0x00ac
                           0000AD   378 _P6_IN	=	0x00ad
                           0000AE   379 _P6_OUT_PU	=	0x00ae
                           0000AF   380 _P6_DIR	=	0x00af
                           0000F1   381 _P7	=	0x00f1
                           0000A2   382 _XBUS_AUX	=	0x00a2
                           000088   383 _TCON	=	0x0088
                           000089   384 _TMOD	=	0x0089
                           00008A   385 _TL0	=	0x008a
                           00008B   386 _TL1	=	0x008b
                           00008C   387 _TH0	=	0x008c
                           00008D   388 _TH1	=	0x008d
                           000098   389 _SCON	=	0x0098
                           000099   390 _SBUF	=	0x0099
                           0000C8   391 _T2CON	=	0x00c8
                           0000C9   392 _T2MOD	=	0x00c9
                           00CBCA   393 _RCAP2	=	0xcbca
                           0000CA   394 _RCAP2L	=	0x00ca
                           0000CB   395 _RCAP2H	=	0x00cb
                           00CDCC   396 _T2COUNT	=	0xcdcc
                           0000CC   397 _TL2	=	0x00cc
                           0000CD   398 _TH2	=	0x00cd
                           00CFCE   399 _T2CAP1	=	0xcfce
                           0000CE   400 _T2CAP1L	=	0x00ce
                           0000CF   401 _T2CAP1H	=	0x00cf
                           0000F8   402 _SPI0_STAT	=	0x00f8
                           0000F9   403 _SPI0_DATA	=	0x00f9
                           0000FA   404 _SPI0_CTRL	=	0x00fa
                           0000FB   405 _SPI0_CK_SE	=	0x00fb
                           0000FC   406 _SPI0_SETUP	=	0x00fc
                           0000BC   407 _SCON1	=	0x00bc
                           0000BD   408 _SBUF1	=	0x00bd
                           0000BE   409 _SBAUD1	=	0x00be
                           0000BF   410 _SIF1	=	0x00bf
                           0000B4   411 _SPI1_STAT	=	0x00b4
                           0000B5   412 _SPI1_DATA	=	0x00b5
                           0000B6   413 _SPI1_CTRL	=	0x00b6
                           0000B7   414 _SPI1_CK_SE	=	0x00b7
                           0000F3   415 _ADC_CTRL	=	0x00f3
                           00F5F4   416 _ADC_DAT	=	0xf5f4
                           0000F4   417 _ADC_DAT_L	=	0x00f4
                           0000F5   418 _ADC_DAT_H	=	0x00f5
                           0000F6   419 _ADC_CHAN	=	0x00f6
                           0000A6   420 _LED_COMMON	=	0x00a6
                           0000A7   421 _LED_PWM_OE	=	0x00a7
                           00C7C6   422 _LED_DMA	=	0xc7c6
                           0000C6   423 _LED_DMA_L	=	0x00c6
                           0000C7   424 _LED_DMA_H	=	0x00c7
                           0000F7   425 _LED_STATUS	=	0x00f7
                           0000B3   426 _I2CX_INT	=	0x00b3
                           0000BB   427 _I2CS_INT_ST	=	0x00bb
                                    428 ;--------------------------------------------------------
                                    429 ; special function bits
                                    430 ;--------------------------------------------------------
                                    431 	.area RSEG    (ABS,DATA)
      000000                        432 	.org 0x0000
                           0000D7   433 _CY	=	0x00d7
                           0000D6   434 _AC	=	0x00d6
                           0000D5   435 _F0	=	0x00d5
                           0000D4   436 _RS1	=	0x00d4
                           0000D3   437 _RS0	=	0x00d3
                           0000D2   438 _OV	=	0x00d2
                           0000D1   439 _F1	=	0x00d1
                           0000D0   440 _P	=	0x00d0
                           0000AF   441 _EA	=	0x00af
                           0000AE   442 _E_DIS	=	0x00ae
                           0000AD   443 _ET2	=	0x00ad
                           0000AC   444 _ES	=	0x00ac
                           0000AB   445 _ET1	=	0x00ab
                           0000AA   446 _EX1	=	0x00aa
                           0000A9   447 _ET0	=	0x00a9
                           0000A8   448 _EX0	=	0x00a8
                           0000BF   449 _PH_FLAG	=	0x00bf
                           0000BE   450 _PL_FLAG	=	0x00be
                           0000BD   451 _PT2	=	0x00bd
                           0000BC   452 _PS	=	0x00bc
                           0000BB   453 _PT1	=	0x00bb
                           0000BA   454 _PX1	=	0x00ba
                           0000B9   455 _PT0	=	0x00b9
                           0000B8   456 _PX0	=	0x00b8
                           0000EF   457 _IE_WDOG	=	0x00ef
                           0000EE   458 _IE_GPIO	=	0x00ee
                           0000ED   459 _IE_PWM_I2C	=	0x00ed
                           0000EC   460 _IE_UART1	=	0x00ec
                           0000EB   461 _IE_ADC	=	0x00eb
                           0000E9   462 _IE_USB	=	0x00e9
                           0000E8   463 _IE_SPI0	=	0x00e8
                           000087   464 _P0_7	=	0x0087
                           000086   465 _P0_6	=	0x0086
                           000085   466 _P0_5	=	0x0085
                           000084   467 _P0_4	=	0x0084
                           000083   468 _P0_3	=	0x0083
                           000082   469 _P0_2	=	0x0082
                           000081   470 _P0_1	=	0x0081
                           000080   471 _P0_0	=	0x0080
                           000081   472 _SDA0	=	0x0081
                           000080   473 _SCL0	=	0x0080
                           000083   474 _TXD_	=	0x0083
                           000082   475 _RXD_	=	0x0082
                           000085   476 _AIN13	=	0x0085
                           000084   477 _AIN12	=	0x0084
                           000083   478 _AIN11	=	0x0083
                           000082   479 _AIN10	=	0x0082
                           000081   480 _AIN9	=	0x0081
                           000080   481 _AIN8	=	0x0080
                           000097   482 _P1_7	=	0x0097
                           000096   483 _P1_6	=	0x0096
                           000095   484 _P1_5	=	0x0095
                           000094   485 _P1_4	=	0x0094
                           000093   486 _P1_3	=	0x0093
                           000092   487 _P1_2	=	0x0092
                           000091   488 _P1_1	=	0x0091
                           000090   489 _P1_0	=	0x0090
                           000097   490 _TXD1_	=	0x0097
                           000096   491 _RXD1_	=	0x0096
                           000097   492 _SCK	=	0x0097
                           000096   493 _MISO	=	0x0096
                           000095   494 _MOSI	=	0x0095
                           000094   495 _SCS	=	0x0094
                           000092   496 _INT0_	=	0x0092
                           000091   497 _T2EX	=	0x0091
                           000091   498 _CAP2	=	0x0091
                           000090   499 _T2	=	0x0090
                           000090   500 _CAP1	=	0x0090
                           000097   501 _AIN7	=	0x0097
                           000096   502 _AIN6	=	0x0096
                           000095   503 _AIN5	=	0x0095
                           000094   504 _AIN4	=	0x0094
                           000093   505 _AIN3	=	0x0093
                           000092   506 _AIN2	=	0x0092
                           000091   507 _AIN1	=	0x0091
                           000090   508 _AIN0	=	0x0090
                           0000A7   509 _P2_7	=	0x00a7
                           0000A6   510 _P2_6	=	0x00a6
                           0000A5   511 _P2_5	=	0x00a5
                           0000A4   512 _P2_4	=	0x00a4
                           0000A3   513 _P2_3	=	0x00a3
                           0000A2   514 _P2_2	=	0x00a2
                           0000A1   515 _P2_1	=	0x00a1
                           0000A0   516 _P2_0	=	0x00a0
                           0000A7   517 _TXD1	=	0x00a7
                           0000A6   518 _RXD1	=	0x00a6
                           0000A5   519 _T2EX_	=	0x00a5
                           0000A5   520 _CAP2_	=	0x00a5
                           0000A4   521 _T2_	=	0x00a4
                           0000A4   522 _CAP1_	=	0x00a4
                           0000B7   523 _P3_7	=	0x00b7
                           0000B6   524 _P3_6	=	0x00b6
                           0000B5   525 _P3_5	=	0x00b5
                           0000B4   526 _P3_4	=	0x00b4
                           0000B3   527 _P3_3	=	0x00b3
                           0000B2   528 _P3_2	=	0x00b2
                           0000B1   529 _P3_1	=	0x00b1
                           0000B0   530 _P3_0	=	0x00b0
                           0000B7   531 _SCK1	=	0x00b7
                           0000B6   532 _MISO1	=	0x00b6
                           0000B5   533 _MOSI1	=	0x00b5
                           0000B5   534 _T1	=	0x00b5
                           0000B4   535 _T0	=	0x00b4
                           0000B3   536 _INT1	=	0x00b3
                           0000B2   537 _INT0	=	0x00b2
                           0000B1   538 _TXD	=	0x00b1
                           0000B0   539 _RXD	=	0x00b0
                           0000C6   540 _P4_6	=	0x00c6
                           0000C5   541 _P4_5	=	0x00c5
                           0000C4   542 _P4_4	=	0x00c4
                           0000C3   543 _P4_3	=	0x00c3
                           0000C2   544 _P4_2	=	0x00c2
                           0000C1   545 _P4_1	=	0x00c1
                           0000C0   546 _P4_0	=	0x00c0
                           00008F   547 _TF1	=	0x008f
                           00008E   548 _TR1	=	0x008e
                           00008D   549 _TF0	=	0x008d
                           00008C   550 _TR0	=	0x008c
                           00008B   551 _IE1	=	0x008b
                           00008A   552 _IT1	=	0x008a
                           000089   553 _IE0	=	0x0089
                           000088   554 _IT0	=	0x0088
                           00009F   555 _SM0	=	0x009f
                           00009E   556 _SM1	=	0x009e
                           00009D   557 _SM2	=	0x009d
                           00009C   558 _REN	=	0x009c
                           00009B   559 _TB8	=	0x009b
                           00009A   560 _RB8	=	0x009a
                           000099   561 _TI	=	0x0099
                           000098   562 _RI	=	0x0098
                           0000CF   563 _TF2	=	0x00cf
                           0000CF   564 _CAP1F	=	0x00cf
                           0000CE   565 _EXF2	=	0x00ce
                           0000CD   566 _RCLK	=	0x00cd
                           0000CC   567 _TCLK	=	0x00cc
                           0000CB   568 _EXEN2	=	0x00cb
                           0000CA   569 _TR2	=	0x00ca
                           0000C9   570 _C_T2	=	0x00c9
                           0000C8   571 _CP_RL2	=	0x00c8
                           0000FF   572 _S0_FST_ACT	=	0x00ff
                           0000FE   573 _S0_IF_OV	=	0x00fe
                           0000FD   574 _S0_IF_FIRST	=	0x00fd
                           0000FC   575 _S0_IF_BYTE	=	0x00fc
                           0000FB   576 _S0_FREE	=	0x00fb
                           0000FA   577 _S0_T_FIFO	=	0x00fa
                           0000F8   578 _S0_R_FIFO	=	0x00f8
                           0000F7   579 _ADC_START	=	0x00f7
                                    580 ;--------------------------------------------------------
                                    581 ; overlayable register banks
                                    582 ;--------------------------------------------------------
                                    583 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        584 	.ds 8
                                    585 ;--------------------------------------------------------
                                    586 ; internal ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area DSEG    (DATA)
      00001B                        589 _process_action_sloc0_1_0:
      00001B                        590 	.ds 1
                                    591 ;--------------------------------------------------------
                                    592 ; overlayable items in internal ram
                                    593 ;--------------------------------------------------------
                                    594 ;--------------------------------------------------------
                                    595 ; indirectly addressable internal ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area ISEG    (DATA)
                                    598 ;--------------------------------------------------------
                                    599 ; absolute internal ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area IABS    (ABS,DATA)
                                    602 	.area IABS    (ABS,DATA)
                                    603 ;--------------------------------------------------------
                                    604 ; bit data
                                    605 ;--------------------------------------------------------
                                    606 	.area BSEG    (BIT)
      000022                        607 _process_action_sloc1_1_0:
      000022                        608 	.ds 1
                                    609 ;--------------------------------------------------------
                                    610 ; paged external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area PSEG    (PAG,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; uninitialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XSEG    (XDATA)
      00087C                        617 _tp_buttons::
      00087C                        618 	.ds 2
      00087E                        619 _action_exec_PARM_1:
      00087E                        620 	.ds 6
      000884                        621 _action_exec_record_10001_634:
      000884                        622 	.ds 9
      00088D                        623 _ak820_action_exec_event_10000_638:
      00088D                        624 	.ds 2
      00088F                        625 _ak820_action_exec_snapshot_10000_639:
      00088F                        626 	.ds 6
      000895                        627 _process_record_record_10000_642:
      000895                        628 	.ds 3
      000898                        629 _process_record_handler_record_argument_10000_650:
      000898                        630 	.ds 3
      00089B                        631 _process_record_handler_action_10000_651:
      00089B                        632 	.ds 2
      00089D                        633 _process_action_PARM_2:
      00089D                        634 	.ds 2
      00089F                        635 _process_action_record_argument_10000_662:
      00089F                        636 	.ds 3
      0008A2                        637 _process_action_on_40000_685:
      0008A2                        638 	.ds 1
      0008A3                        639 _register_code_code_10000_719:
      0008A3                        640 	.ds 1
      0008A4                        641 _unregister_code_code_10000_733:
      0008A4                        642 	.ds 1
      0008A5                        643 _tap_code_delay_PARM_2:
      0008A5                        644 	.ds 2
      0008A7                        645 _tap_code_delay_code_10000_746:
      0008A7                        646 	.ds 1
      0008A8                        647 _tap_code_code_10000_753:
      0008A8                        648 	.ds 1
      0008A9                        649 _register_mods_mods_10000_755:
      0008A9                        650 	.ds 1
      0008AA                        651 _unregister_mods_mods_10000_759:
      0008AA                        652 	.ds 1
      0008AB                        653 _register_weak_mods_mods_10000_763:
      0008AB                        654 	.ds 1
      0008AC                        655 _unregister_weak_mods_mods_10000_767:
      0008AC                        656 	.ds 1
                                    657 ;--------------------------------------------------------
                                    658 ; absolute external ram data
                                    659 ;--------------------------------------------------------
                                    660 	.area XABS    (ABS,XDATA)
                                    661 ;--------------------------------------------------------
                                    662 ; initialized external ram data
                                    663 ;--------------------------------------------------------
                                    664 	.area XISEG   (XDATA)
      000E7A                        665 _disable_action_cache::
      000E7A                        666 	.ds 1
                                    667 	.area HOME    (CODE)
                                    668 	.area GSINIT0 (CODE)
                                    669 	.area GSINIT1 (CODE)
                                    670 	.area GSINIT2 (CODE)
                                    671 	.area GSINIT3 (CODE)
                                    672 	.area GSINIT4 (CODE)
                                    673 	.area GSINIT5 (CODE)
                                    674 	.area GSINIT  (CODE)
                                    675 	.area GSFINAL (CODE)
                                    676 	.area CSEG    (CODE)
                                    677 ;--------------------------------------------------------
                                    678 ; global & static initialisations
                                    679 ;--------------------------------------------------------
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 	.area GSFINAL (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 ;--------------------------------------------------------
                                    685 ; Home
                                    686 ;--------------------------------------------------------
                                    687 	.area HOME    (CODE)
                                    688 	.area HOME    (CODE)
                                    689 ;--------------------------------------------------------
                                    690 ; code
                                    691 ;--------------------------------------------------------
                                    692 	.area CSEG    (CODE)
                                    693 ;------------------------------------------------------------
                                    694 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    695 ;------------------------------------------------------------
                                    696 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    697 ;------------------------------------------------------------
                                    698 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    699 ;	-----------------------------------------
                           000007   700 	ar7 = 0x07
                           000006   701 	ar6 = 0x06
                           000005   702 	ar5 = 0x05
                           000004   703 	ar4 = 0x04
                           000003   704 	ar3 = 0x03
                           000002   705 	ar2 = 0x02
                           000001   706 	ar1 = 0x01
                           000000   707 	ar0 = 0x00
                                    708 ;	 function action_exec
                                    709 ;	-----------------------------------------
      00768C                        710 _action_exec:
                                    711 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      00768C 90 08 80         [24]  712 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00768F 12 37 F7         [24]  713 	lcall	_ak820_outline_0006
      007692 12 35 FD         [24]  714 	lcall	_ak820_combo_tick
                                    715 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007695 90 08 7E         [24]  716 	mov	dptr,#_action_exec_PARM_1
      007698 12 4B 14         [24]  717 	lcall	_ak820_tapping_before
      00769B E5 82            [12]  718 	mov	a, dpl
      00769D 70 01            [24]  719 	jnz	00102$
      00769F 22               [24]  720 	ret
      0076A0                        721 00102$:
                                    722 ;	quantum/action.c:125: if (event.pressed) {
      0076A0 90 08 83         [24]  723 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0076A3 E0               [24]  724 	movx	a,@dptr
      0076A4 60 03            [24]  725 	jz	00104$
                                    726 ;	quantum/action.c:127: clear_weak_mods();
      0076A6 12 87 AA         [24]  727 	lcall	_clear_weak_mods
      0076A9                        728 00104$:
                                    729 ;	quantum/action.c:139: record.event = event;
      0076A9 90 0E 57         [24]  730 	mov	dptr,#___memcpy_PARM_2
      0076AC 74 7E            [12]  731 	mov	a,#_action_exec_PARM_1
      0076AE F0               [24]  732 	movx	@dptr,a
      0076AF 74 08            [12]  733 	mov	a,#(_action_exec_PARM_1 >> 8)
      0076B1 12 38 56         [24]  734 	lcall	_ak820_outline_0077
      0076B4 12 7D 52         [24]  735 	lcall	_ak820_outline_0076
      0076B7 90 08 84         [24]  736 	mov	dptr,#_action_exec_record_10001_634
      0076BA F5 F0            [12]  737 	mov	b,a
      0076BC 12 C1 65         [24]  738 	lcall	___memcpy
                                    739 ;	quantum/action.c:141: record.tap.count = 0;
      0076BF 90 08 8A         [24]  740 	mov	dptr,#(_action_exec_record_10001_634 + 0x0006)
      0076C2 E0               [24]  741 	movx	a,@dptr
      0076C3 54 0F            [12]  742 	anl	a,#0x0f
      0076C5 F0               [24]  743 	movx	@dptr,a
                                    744 ;	quantum/action.c:146: record.keycode = 0;
      0076C6 90 08 8B         [24]  745 	mov	dptr,#(_action_exec_record_10001_634 + 0x0007)
      0076C9 12 55 F6         [24]  746 	lcall	_ak820_outline_0166
                                    747 ;	quantum/action.c:177: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0076CC 90 08 88         [24]  748 	mov	dptr,#(_action_exec_record_10001_634 + 0x0004)
      0076CF E0               [24]  749 	movx	a,@dptr
      0076D0 60 0D            [24]  750 	jz	00107$
      0076D2 90 08 84         [24]  751 	mov	dptr,#_action_exec_record_10001_634
      0076D5 75 F0 00         [24]  752 	mov	b, #0x00
      0076D8 12 A7 0C         [24]  753 	lcall	_pre_process_record_quantum
      0076DB E5 82            [12]  754 	mov	a, dpl
      0076DD 60 13            [24]  755 	jz	00110$
      0076DF                        756 00107$:
                                    757 ;	quantum/action.c:179: if (!ak820_tapping_process(&record)) return;
      0076DF 90 08 84         [24]  758 	mov	dptr,#_action_exec_record_10001_634
      0076E2 12 4C 01         [24]  759 	lcall	_ak820_tapping_process
      0076E5 E5 82            [12]  760 	mov	a, dpl
      0076E7 70 01            [24]  761 	jnz	00106$
      0076E9 22               [24]  762 	ret
      0076EA                        763 00106$:
                                    764 ;	quantum/action.c:184: process_record(&record);
      0076EA 90 08 84         [24]  765 	mov	dptr,#_action_exec_record_10001_634
      0076ED 75 F0 00         [24]  766 	mov	b, #0x00
                                    767 ;	quantum/action.c:199: }
      0076F0 E1 2E            [12]  768 	ajmp	_process_record
      0076F2                        769 00110$:
      0076F2 22               [24]  770 	ret
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'ak820_action_exec'
                                    773 ;------------------------------------------------------------
                                    774 ;event         Allocated with name '_ak820_action_exec_event_10000_638'
                                    775 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_639'
                                    776 ;------------------------------------------------------------
                                    777 ;	quantum/action.c:202: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    778 ;	-----------------------------------------
                                    779 ;	 function ak820_action_exec
                                    780 ;	-----------------------------------------
      0076F3                        781 _ak820_action_exec:
      0076F3 12 38 86         [24]  782 	lcall	_ak820_outline_0114
      0076F6 90 08 8D         [24]  783 	mov	dptr,#_ak820_action_exec_event_10000_638
      0076F9 12 38 8B         [24]  784 	lcall	_ak820_outline_0115
                                    785 ;	quantum/action.c:205: keyevent_t snapshot = *event;
      0076FC 90 08 8D         [24]  786 	mov	dptr,#_ak820_action_exec_event_10000_638
      0076FF 12 38 62         [24]  787 	lcall	_ak820_outline_0085
      007702 7F 00            [12]  788 	mov	r7,#0x00
      007704 90 0E 57         [24]  789 	mov	dptr,#___memcpy_PARM_2
      007707 ED               [12]  790 	mov	a,r5
      007708 12 38 21         [24]  791 	lcall	_ak820_outline_0022
      00770B 12 7D 52         [24]  792 	lcall	_ak820_outline_0076
      00770E 90 08 8F         [24]  793 	mov	dptr,#_ak820_action_exec_snapshot_10000_639
      007711 F5 F0            [12]  794 	mov	b,a
      007713 12 C1 65         [24]  795 	lcall	___memcpy
                                    796 ;	quantum/action.c:206: action_exec(snapshot);
      007716 90 0E 57         [24]  797 	mov	dptr,#___memcpy_PARM_2
      007719 74 8F            [12]  798 	mov	a,#_ak820_action_exec_snapshot_10000_639
      00771B F0               [24]  799 	movx	@dptr,a
      00771C 74 08            [12]  800 	mov	a,#(_ak820_action_exec_snapshot_10000_639 >> 8)
      00771E 12 38 56         [24]  801 	lcall	_ak820_outline_0077
      007721 12 7D 52         [24]  802 	lcall	_ak820_outline_0076
      007724 90 08 7E         [24]  803 	mov	dptr,#_action_exec_PARM_1
      007727 F5 F0            [12]  804 	mov	b,a
      007729 12 C1 65         [24]  805 	lcall	___memcpy
                                    806 ;	quantum/action.c:207: }
      00772C C1 8C            [12]  807 	ajmp	_action_exec
                                    808 ;------------------------------------------------------------
                                    809 ;Allocation info for local variables in function 'process_record_nocache'
                                    810 ;------------------------------------------------------------
                                    811 ;record        Allocated with name '_process_record_nocache_record_10000_640'
                                    812 ;------------------------------------------------------------
                                    813 ;	quantum/action.c:292: void process_record_nocache(keyrecord_t *record) {
                                    814 ;	-----------------------------------------
                                    815 ;	 function process_record
                                    816 ;	-----------------------------------------
      00772E                        817 _process_record:
      00772E 12 49 D5         [24]  818 	lcall	_ak820_outline_0041
      007731 90 08 95         [24]  819 	mov	dptr,#_process_record_record_10000_642
      007734 12 38 21         [24]  820 	lcall	_ak820_outline_0022
                                    821 ;	quantum/action.c:346: if (IS_NOEVENT(record->event)) {
      007737 90 08 95         [24]  822 	mov	dptr,#_process_record_record_10000_642
      00773A 12 55 AA         [24]  823 	lcall	_ak820_outline_0013
      00773D 74 04            [12]  824 	mov	a,#0x04
      00773F 12 7D 22         [24]  825 	lcall	_ak820_outline_0015
      007742 12 C2 3E         [24]  826 	lcall	__gptrget
      007745 70 01            [24]  827 	jnz	00102$
                                    828 ;	quantum/action.c:347: return;
      007747 22               [24]  829 	ret
      007748                        830 00102$:
                                    831 ;	quantum/action.c:355: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007748 8D 02            [24]  832 	mov	ar2,r5
      00774A 8E 03            [24]  833 	mov	ar3,r6
      00774C 8F 04            [24]  834 	mov	ar4,r7
      00774E 90 0E 57         [24]  835 	mov	dptr,#___memcpy_PARM_2
      007751 EA               [12]  836 	mov	a,r2
      007752 12 7D A0         [24]  837 	lcall	_ak820_outline_0197
      007755 EC               [12]  838 	mov	a,r4
      007756 A3               [24]  839 	inc	dptr
      007757 F0               [24]  840 	movx	@dptr,a
      007758 90 0E 5A         [24]  841 	mov	dptr,#___memcpy_PARM_3
      00775B 12 55 EF         [24]  842 	lcall	_ak820_outline_0117
      00775E 90 06 92         [24]  843 	mov	dptr,#_ak820_tapping_source_PARM_1
      007761 F5 F0            [12]  844 	mov	b,a
      007763 C0 07            [24]  845 	push	ar7
      007765 C0 06            [24]  846 	push	ar6
      007767 C0 05            [24]  847 	push	ar5
      007769 12 C1 65         [24]  848 	lcall	___memcpy
      00776C 12 4A 4F         [24]  849 	lcall	_ak820_tapping_source
      00776F AC 82            [24]  850 	mov	r4, dpl
      007771 D0 05            [24]  851 	pop	ar5
      007773 D0 06            [24]  852 	pop	ar6
      007775 D0 07            [24]  853 	pop	ar7
                                    854 ;	quantum/action.c:356: bool oneshot_pressed = record->event.pressed;
      007777 74 05            [12]  855 	mov	a,#0x05
      007779 12 7D 14         [24]  856 	lcall	_ak820_outline_0014
      00777C 12 C2 3E         [24]  857 	lcall	__gptrget
      00777F FB               [12]  858 	mov	r3,a
                                    859 ;	quantum/action.c:357: record->keycode = get_record_keycode(record, true);
      007780 12 7D 85         [24]  860 	lcall	_ak820_outline_0157
      007783 90 0C 98         [24]  861 	mov	dptr,#_get_record_keycode_PARM_2
      007786 74 01            [12]  862 	mov	a,#0x01
      007788 12 55 B3         [24]  863 	lcall	_ak820_outline_0038
      00778B C0 04            [24]  864 	push	ar4
      00778D C0 03            [24]  865 	push	ar3
      00778F C0 02            [24]  866 	push	ar2
      007791 C0 01            [24]  867 	push	ar1
      007793 C0 00            [24]  868 	push	ar0
      007795 12 A6 CE         [24]  869 	lcall	_get_record_keycode
      007798 12 4A 1E         [24]  870 	lcall	_ak820_outline_0144
      00779B D0 00            [24]  871 	pop	ar0
      00779D D0 01            [24]  872 	pop	ar1
      00779F D0 02            [24]  873 	pop	ar2
      0077A1 D0 03            [24]  874 	pop	ar3
      0077A3 D0 04            [24]  875 	pop	ar4
      0077A5 12 4F 6A         [24]  876 	lcall	_ak820_outline_0119
      0077A8 EE               [12]  877 	mov	a,r6
      0077A9 12 C2 03         [24]  878 	lcall	__gptrput
      0077AC A3               [24]  879 	inc	dptr
      0077AD EF               [12]  880 	mov	a,r7
      0077AE 12 C2 03         [24]  881 	lcall	__gptrput
                                    882 ;	quantum/action.c:358: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0077B1 90 08 95         [24]  883 	mov	dptr,#_process_record_record_10000_642
      0077B4 12 55 AA         [24]  884 	lcall	_ak820_outline_0013
      0077B7 12 7D 85         [24]  885 	lcall	_ak820_outline_0157
      0077BA 12 4F 6A         [24]  886 	lcall	_ak820_outline_0119
      0077BD 12 C2 3E         [24]  887 	lcall	__gptrget
      0077C0 F8               [12]  888 	mov	r0,a
      0077C1 A3               [24]  889 	inc	dptr
      0077C2 12 C2 3E         [24]  890 	lcall	__gptrget
      0077C5 F9               [12]  891 	mov	r1,a
      0077C6 90 06 A2         [24]  892 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0077C9 EC               [12]  893 	mov	a,r4
      0077CA F0               [24]  894 	movx	@dptr,a
      0077CB 90 06 A3         [24]  895 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0077CE EB               [12]  896 	mov	a,r3
      0077CF F0               [24]  897 	movx	@dptr,a
      0077D0 12 38 BA         [24]  898 	lcall	_ak820_outline_0167
      0077D3 C0 07            [24]  899 	push	ar7
      0077D5 C0 06            [24]  900 	push	ar6
      0077D7 C0 05            [24]  901 	push	ar5
      0077D9 C0 04            [24]  902 	push	ar4
      0077DB C0 03            [24]  903 	push	ar3
      0077DD 12 4D AC         [24]  904 	lcall	_ak820_oneshot_process
      0077E0 E5 82            [12]  905 	mov	a, dpl
      0077E2 D0 03            [24]  906 	pop	ar3
      0077E4 D0 04            [24]  907 	pop	ar4
      0077E6 D0 05            [24]  908 	pop	ar5
      0077E8 D0 06            [24]  909 	pop	ar6
      0077EA D0 07            [24]  910 	pop	ar7
      0077EC 70 01            [24]  911 	jnz	00104$
      0077EE 22               [24]  912 	ret
      0077EF                        913 00104$:
                                    914 ;	quantum/action.c:360: if (!process_record_quantum(record)) {
      0077EF 12 73 F6         [24]  915 	lcall	_ak820_outline_0063
      0077F2 C0 04            [24]  916 	push	ar4
      0077F4 C0 03            [24]  917 	push	ar3
      0077F6 12 A7 96         [24]  918 	lcall	_process_record_quantum
      0077F9 E5 82            [12]  919 	mov	a, dpl
      0077FB D0 03            [24]  920 	pop	ar3
      0077FD D0 04            [24]  921 	pop	ar4
      0077FF 70 0A            [24]  922 	jnz	00106$
                                    923 ;	quantum/action.c:362: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007801 90 06 0A         [24]  924 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007804 EB               [12]  925 	mov	a,r3
      007805 F0               [24]  926 	movx	@dptr,a
      007806 8C 82            [24]  927 	mov	dpl, r4
                                    928 ;	quantum/action.c:369: return;
      007808 02 2E BB         [24]  929 	ljmp	_ak820_oneshot_post
      00780B                        930 00106$:
                                    931 ;	quantum/action.c:375: process_record_handler(record);
      00780B 90 08 95         [24]  932 	mov	dptr,#_process_record_record_10000_642
      00780E 12 55 84         [24]  933 	lcall	_ak820_outline_0001
      007811 C0 04            [24]  934 	push	ar4
      007813 C0 03            [24]  935 	push	ar3
      007815 11 2E            [24]  936 	acall	_process_record_handler
                                    937 ;	quantum/action.c:379: post_process_record_quantum(record);
      007817 90 08 95         [24]  938 	mov	dptr,#_process_record_record_10000_642
      00781A 12 55 84         [24]  939 	lcall	_ak820_outline_0001
      00781D 12 A7 6B         [24]  940 	lcall	_post_process_record_quantum
      007820 D0 03            [24]  941 	pop	ar3
      007822 D0 04            [24]  942 	pop	ar4
                                    943 ;	quantum/action.c:381: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007824 90 06 0A         [24]  944 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007827 EB               [12]  945 	mov	a,r3
      007828 F0               [24]  946 	movx	@dptr,a
      007829 8C 82            [24]  947 	mov	dpl, r4
                                    948 ;	quantum/action.c:383: }
      00782B 02 2E BB         [24]  949 	ljmp	_ak820_oneshot_post
                                    950 ;------------------------------------------------------------
                                    951 ;Allocation info for local variables in function 'process_record_handler'
                                    952 ;------------------------------------------------------------
                                    953 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_650'
                                    954 ;record        Allocated with name '_process_record_handler_record_10000_651'
                                    955 ;action        Allocated with name '_process_record_handler_action_10000_651'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/action.c:385: void process_record_handler(keyrecord_t *record_argument) {
                                    958 ;	-----------------------------------------
                                    959 ;	 function process_record_handler
                                    960 ;	-----------------------------------------
      00782E                        961 _process_record_handler:
      00782E 12 49 D5         [24]  962 	lcall	_ak820_outline_0041
      007831 90 08 98         [24]  963 	mov	dptr,#_process_record_handler_record_argument_10000_650
      007834 12 38 21         [24]  964 	lcall	_ak820_outline_0022
                                    965 ;	quantum/action.c:389: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007837 90 08 98         [24]  966 	mov	dptr,#_process_record_handler_record_argument_10000_650
      00783A 12 37 E3         [24]  967 	lcall	_ak820_outline_0002
                                    968 ;	quantum/action.c:396: if (record->keycode) {
      00783D 4C               [12]  969 	orl	a,r4
      00783E 60 19            [24]  970 	jz	00102$
                                    971 ;	quantum/action.c:397: action.code = action_for_keycode(record->keycode);
      007840 12 38 A1         [24]  972 	lcall	_ak820_outline_0134
      007843 C0 07            [24]  973 	push	ar7
      007845 C0 06            [24]  974 	push	ar6
      007847 12 9D 1A         [24]  975 	lcall	_action_for_keycode
      00784A 12 4A 2F         [24]  976 	lcall	_ak820_outline_0160
      00784D D0 06            [24]  977 	pop	ar6
      00784F D0 07            [24]  978 	pop	ar7
      007851 90 08 9B         [24]  979 	mov	dptr,#_process_record_handler_action_10000_651
      007854 12 38 5C         [24]  980 	lcall	_ak820_outline_0079
      007857 80 2B            [24]  981 	sjmp	00104$
      007859                        982 00102$:
                                    983 ;	quantum/action.c:400: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007859 12 7D 30         [24]  984 	lcall	_ak820_outline_0025
      00785C 7A 00            [12]  985 	mov	r2,#0x00
      00785E 12 4A 29         [24]  986 	lcall	_ak820_outline_0153
      007861 12 49 C3         [24]  987 	lcall	_ak820_outline_0012
      007864 E0               [24]  988 	movx	a,@dptr
      007865 90 09 D7         [24]  989 	mov	dptr,#_ak820_resolve_key_PARM_2
      007868 F0               [24]  990 	movx	@dptr,a
      007869 8D 82            [24]  991 	mov	dpl, r5
      00786B 8C 83            [24]  992 	mov	dph, r4
      00786D C0 07            [24]  993 	push	ar7
      00786F C0 06            [24]  994 	push	ar6
      007871 12 80 C6         [24]  995 	lcall	_ak820_resolve_key
      007874 12 9D 1A         [24]  996 	lcall	_action_for_keycode
      007877 12 4A 2F         [24]  997 	lcall	_ak820_outline_0160
      00787A D0 06            [24]  998 	pop	ar6
      00787C D0 07            [24]  999 	pop	ar7
      00787E 90 08 9B         [24] 1000 	mov	dptr,#_process_record_handler_action_10000_651
      007881 12 38 5C         [24] 1001 	lcall	_ak820_outline_0079
                                   1002 ;	quantum/action.c:409: ac_dprintf("ACTION: ");
      007884                       1003 00104$:
                                   1004 ;	quantum/action.c:420: process_action(record, action);
      007884 7D 00            [12] 1005 	mov	r5,#0x00
      007886 90 0E 57         [24] 1006 	mov	dptr,#___memcpy_PARM_2
      007889 74 9B            [12] 1007 	mov	a,#_process_record_handler_action_10000_651
      00788B F0               [24] 1008 	movx	@dptr,a
      00788C 74 08            [12] 1009 	mov	a,#(_process_record_handler_action_10000_651 >> 8)
      00788E 12 38 56         [24] 1010 	lcall	_ak820_outline_0077
      007891 90 0E 5A         [24] 1011 	mov	dptr,#___memcpy_PARM_3
      007894 12 55 EF         [24] 1012 	lcall	_ak820_outline_0117
      007897 90 08 9D         [24] 1013 	mov	dptr,#_process_action_PARM_2
      00789A F5 F0            [12] 1014 	mov	b,a
      00789C C0 07            [24] 1015 	push	ar7
      00789E C0 06            [24] 1016 	push	ar6
      0078A0 C0 05            [24] 1017 	push	ar5
      0078A2 12 C1 65         [24] 1018 	lcall	___memcpy
      0078A5 D0 05            [24] 1019 	pop	ar5
      0078A7 D0 06            [24] 1020 	pop	ar6
      0078A9 D0 07            [24] 1021 	pop	ar7
      0078AB 12 7D 6C         [24] 1022 	lcall	_ak820_outline_0120
                                   1023 ;	quantum/action.c:421: }
      0078AE 01 B0            [24] 1024 	ajmp	_process_action
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'register_mouse'
                                   1027 ;------------------------------------------------------------
                                   1028 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1029 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_659'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	quantum/action.c:433: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function process_action
                                   1034 ;	-----------------------------------------
      0078B0                       1035 _process_action:
      0078B0 12 49 D5         [24] 1036 	lcall	_ak820_outline_0041
      0078B3 90 08 9F         [24] 1037 	mov	dptr,#_process_action_record_argument_10000_662
      0078B6 12 38 21         [24] 1038 	lcall	_ak820_outline_0022
                                   1039 ;	quantum/action.c:486: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0078B9 90 08 9F         [24] 1040 	mov	dptr,#_process_action_record_argument_10000_662
      0078BC 12 37 F7         [24] 1041 	lcall	_ak820_outline_0006
                                   1042 ;	quantum/action.c:492: pressed = record->event.pressed;
      0078BF A3               [24] 1043 	inc	dptr
      0078C0 A3               [24] 1044 	inc	dptr
      0078C1 A3               [24] 1045 	inc	dptr
      0078C2 A3               [24] 1046 	inc	dptr
      0078C3 A3               [24] 1047 	inc	dptr
      0078C4 E0               [24] 1048 	movx	a,@dptr
      0078C5 F5 1B            [12] 1049 	mov	_process_action_sloc0_1_0,a
                                   1050 ;	quantum/action.c:516: switch (action.kind.id) {
      0078C7 90 08 9E         [24] 1051 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078CA E0               [24] 1052 	movx	a,@dptr
      0078CB C4               [12] 1053 	swap	a
      0078CC 54 0F            [12] 1054 	anl	a,#0x0f
      0078CE FD               [12] 1055 	mov  r5,a
      0078CF 24 F4            [12] 1056 	add	a,#0xff - 0x0b
      0078D1 50 03            [24] 1057 	jnc	00434$
      0078D3 02 7B 51         [24] 1058 	ljmp	00181$
      0078D6                       1059 00434$:
                                   1060 ;	free result
      0078D6 ED               [12] 1061 	mov	a,r5
      0078D7 24 0A            [12] 1062 	add	a,#(00435$-3-.)
      0078D9 83               [24] 1063 	movc	a,@a+pc
      0078DA F5 82            [12] 1064 	mov	dpl,a
      0078DC ED               [12] 1065 	mov	a,r5
      0078DD 24 10            [12] 1066 	add	a,#(00436$-3-.)
      0078DF 83               [24] 1067 	movc	a,@a+pc
      0078E0 F5 83            [12] 1068 	mov	dph,a
      0078E2 E4               [12] 1069 	clr	a
      0078E3 73               [24] 1070 	jmp	@a+dptr
      0078E4                       1071 00435$:
      0078E4 FC                    1072 	.db	00102$
      0078E5 FC                    1073 	.db	00102$
      0078E6 51                    1074 	.db	00181$
      0078E7 51                    1075 	.db	00181$
      0078E8 86                    1076 	.db	00123$
      0078E9 51                    1077 	.db	00181$
      0078EA 51                    1078 	.db	00181$
      0078EB 51                    1079 	.db	00181$
      0078EC E6                    1080 	.db	00131$
      0078ED B8                    1081 	.db	00147$
      0078EE DE                    1082 	.db	00152$
      0078EF DE                    1083 	.db	00152$
      0078F0                       1084 00436$:
      0078F0 78                    1085 	.db	00102$>>8
      0078F1 78                    1086 	.db	00102$>>8
      0078F2 7B                    1087 	.db	00181$>>8
      0078F3 7B                    1088 	.db	00181$>>8
      0078F4 79                    1089 	.db	00123$>>8
      0078F5 7B                    1090 	.db	00181$>>8
      0078F6 7B                    1091 	.db	00181$>>8
      0078F7 7B                    1092 	.db	00181$>>8
      0078F8 79                    1093 	.db	00131$>>8
      0078F9 7A                    1094 	.db	00147$>>8
      0078FA 7A                    1095 	.db	00152$>>8
      0078FB 7A                    1096 	.db	00152$>>8
                                   1097 ;	quantum/action.c:519: case ACT_RMODS: {
      0078FC                       1098 00102$:
                                   1099 ;	quantum/action.c:520: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0078FC 90 08 9E         [24] 1100 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078FF E0               [24] 1101 	movx	a,@dptr
      007900 54 F0            [12] 1102 	anl	a,#0xf0
      007902 70 06            [24] 1103 	jnz	00194$
      007904 12 7D 73         [24] 1104 	lcall	_ak820_outline_0121
      007907 FD               [12] 1105 	mov	r5,a
      007908 80 07            [24] 1106 	sjmp	00195$
      00790A                       1107 00194$:
      00790A 12 7D 73         [24] 1108 	lcall	_ak820_outline_0121
      00790D C4               [12] 1109 	swap	a
      00790E 54 F0            [12] 1110 	anl	a,#0xf0
      007910 FD               [12] 1111 	mov	r5,a
      007911                       1112 00195$:
                                   1113 ;	quantum/action.c:522: if (pressed) {
      007911 E5 1B            [12] 1114 	mov	a,_process_action_sloc0_1_0
      007913 60 35            [24] 1115 	jz	00119$
                                   1116 ;	quantum/action.c:523: if (mods) {
      007915 ED               [12] 1117 	mov	a,r5
      007916 60 29            [24] 1118 	jz	00110$
                                   1119 ;	quantum/action.c:524: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007918 12 7D 8F         [24] 1120 	lcall	_ak820_outline_0170
      00791B FC               [12] 1121 	mov	r4,a
      00791C BC E0 00         [24] 1122 	cjne	r4,#0xe0,00440$
      00791F                       1123 00440$:
      00791F 40 07            [24] 1124 	jc	00108$
      007921 12 7D 8F         [24] 1125 	lcall	_ak820_outline_0170
      007924 24 18            [12] 1126 	add	a,#0xff - 0xe7
      007926 50 0A            [24] 1127 	jnc	00104$
                                   1128 ;	free result
      007928                       1129 00108$:
      007928 7B 9D            [12] 1130 	mov	r3,#_process_action_PARM_2
      00792A 7C 08            [12] 1131 	mov	r4,#(_process_action_PARM_2 >> 8)
      00792C 12 33 FC         [24] 1132 	lcall	_ak820_outline_0129
      00792F E0               [24] 1133 	movx	a,@dptr
      007930 70 07            [24] 1134 	jnz	00105$
      007932                       1135 00104$:
                                   1136 ;	quantum/action.c:528: add_owned_mods(mods);
      007932 8D 82            [24] 1137 	mov	dpl, r5
      007934 12 82 E1         [24] 1138 	lcall	_add_owned_mods
      007937 80 05            [24] 1139 	sjmp	00106$
      007939                       1140 00105$:
                                   1141 ;	quantum/action.c:530: add_owned_weak_mods(mods);
      007939 8D 82            [24] 1142 	mov	dpl, r5
      00793B 12 82 FE         [24] 1143 	lcall	_add_owned_weak_mods
      00793E                       1144 00106$:
                                   1145 ;	quantum/action.c:532: send_keyboard_report();
      00793E 12 86 13         [24] 1146 	lcall	_send_keyboard_report
      007941                       1147 00110$:
                                   1148 ;	quantum/action.c:534: register_code(action.key.code);
      007941 12 7D 5C         [24] 1149 	lcall	_ak820_outline_0082
      007944 12 7B 68         [24] 1150 	lcall	_register_code
      007947 02 7B 51         [24] 1151 	ljmp	00181$
      00794A                       1152 00119$:
                                   1153 ;	quantum/action.c:536: unregister_code(action.key.code);
      00794A 12 7D 5C         [24] 1154 	lcall	_ak820_outline_0082
      00794D C0 05            [24] 1155 	push	ar5
      00794F 12 7B D2         [24] 1156 	lcall	_unregister_code
      007952 D0 05            [24] 1157 	pop	ar5
                                   1158 ;	quantum/action.c:537: if (mods) {
      007954 ED               [12] 1159 	mov	a,r5
      007955 70 03            [24] 1160 	jnz	00444$
      007957 02 7B 51         [24] 1161 	ljmp	00181$
      00795A                       1162 00444$:
                                   1163 ;	quantum/action.c:538: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00795A 12 7D 8F         [24] 1164 	lcall	_ak820_outline_0170
      00795D FC               [12] 1165 	mov	r4,a
      00795E BC E0 00         [24] 1166 	cjne	r4,#0xe0,00445$
      007961                       1167 00445$:
      007961 40 07            [24] 1168 	jc	00115$
      007963 12 7D 8F         [24] 1169 	lcall	_ak820_outline_0170
      007966 24 18            [12] 1170 	add	a,#0xff - 0xe7
      007968 50 0A            [24] 1171 	jnc	00111$
                                   1172 ;	free result
      00796A                       1173 00115$:
      00796A 7B 9D            [12] 1174 	mov	r3,#_process_action_PARM_2
      00796C 7C 08            [12] 1175 	mov	r4,#(_process_action_PARM_2 >> 8)
      00796E 12 33 FC         [24] 1176 	lcall	_ak820_outline_0129
      007971 E0               [24] 1177 	movx	a,@dptr
      007972 70 07            [24] 1178 	jnz	00112$
      007974                       1179 00111$:
                                   1180 ;	quantum/action.c:539: del_owned_mods(mods);
      007974 8D 82            [24] 1181 	mov	dpl, r5
      007976 12 82 F0         [24] 1182 	lcall	_del_owned_mods
      007979 80 05            [24] 1183 	sjmp	00113$
      00797B                       1184 00112$:
                                   1185 ;	quantum/action.c:541: del_owned_weak_mods(mods);
      00797B 8D 82            [24] 1186 	mov	dpl, r5
      00797D 12 83 0D         [24] 1187 	lcall	_del_owned_weak_mods
      007980                       1188 00113$:
                                   1189 ;	quantum/action.c:543: send_keyboard_report();
      007980 12 86 13         [24] 1190 	lcall	_send_keyboard_report
                                   1191 ;	quantum/action.c:546: } break;
      007983 02 7B 51         [24] 1192 	ljmp	00181$
                                   1193 ;	quantum/action.c:623: case ACT_USAGE:
      007986                       1194 00123$:
                                   1195 ;	quantum/action.c:629: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007986 74 07            [12] 1196 	mov	a,#0x07
      007988 12 38 29         [24] 1197 	lcall	_ak820_outline_0036
      00798B 12 4E EC         [24] 1198 	lcall	_ak820_outline_0010
      00798E C3               [12] 1199 	clr	c
      00798F EC               [12] 1200 	mov	a,r4
      007990 94 A5            [12] 1201 	subb	a,#0xa5
      007992 ED               [12] 1202 	mov	a,r5
      007993 94 00            [12] 1203 	subb	a,#0x00
      007995 40 15            [24] 1204 	jc	00125$
      007997 74 C2            [12] 1205 	mov	a,#0xc2
      007999 9C               [12] 1206 	subb	a,r4
      00799A E4               [12] 1207 	clr	a
      00799B 9D               [12] 1208 	subb	a,r5
      00799C 40 0E            [24] 1209 	jc	00125$
                                   1210 ;	free result
                                   1211 ;	quantum/action.c:630: owned_usage_key((uint8_t)record->keycode, pressed);
      00799E 90 0A FE         [24] 1212 	mov	dptr,#_owned_usage_key_PARM_2
      0079A1 E5 1B            [12] 1213 	mov	a,_process_action_sloc0_1_0
      0079A3 F0               [24] 1214 	movx	@dptr,a
      0079A4 8E 82            [24] 1215 	mov	dpl, r6
      0079A6 12 84 C0         [24] 1216 	lcall	_owned_usage_key
                                   1217 ;	quantum/action.c:631: break;
      0079A9 02 7B 51         [24] 1218 	ljmp	00181$
      0079AC                       1219 00125$:
                                   1220 ;	quantum/action.c:634: switch (action.usage.page) {
      0079AC 12 7D 63         [24] 1221 	lcall	_ak820_outline_0094
      0079AF FF               [12] 1222 	mov	r7,a
      0079B0 60 08            [24] 1223 	jz	00127$
      0079B2 BF 01 02         [24] 1224 	cjne	r7,#0x01,00452$
      0079B5 80 19            [24] 1225 	sjmp	00128$
      0079B7                       1226 00452$:
      0079B7 02 7B 51         [24] 1227 	ljmp	00181$
                                   1228 ;	quantum/action.c:635: case PAGE_SYSTEM:
      0079BA                       1229 00127$:
                                   1230 ;	quantum/action.c:636: host_system_send(pressed ? action.usage.code : 0);
      0079BA E5 1B            [12] 1231 	mov	a,_process_action_sloc0_1_0
      0079BC 60 05            [24] 1232 	jz	00196$
      0079BE 12 7D 7A         [24] 1233 	lcall	_ak820_outline_0142
      0079C1 80 04            [24] 1234 	sjmp	00197$
      0079C3                       1235 00196$:
      0079C3 7E 00            [12] 1236 	mov	r6,#0x00
      0079C5 7F 00            [12] 1237 	mov	r7,#0x00
      0079C7                       1238 00197$:
      0079C7 12 38 90         [24] 1239 	lcall	_ak820_outline_0126
      0079CA 12 73 82         [24] 1240 	lcall	_host_system_send
                                   1241 ;	quantum/action.c:637: break;
      0079CD 02 7B 51         [24] 1242 	ljmp	00181$
                                   1243 ;	quantum/action.c:638: case PAGE_CONSUMER:
      0079D0                       1244 00128$:
                                   1245 ;	quantum/action.c:639: host_consumer_send(pressed ? action.usage.code : 0);
      0079D0 E5 1B            [12] 1246 	mov	a,_process_action_sloc0_1_0
      0079D2 60 05            [24] 1247 	jz	00198$
      0079D4 12 7D 7A         [24] 1248 	lcall	_ak820_outline_0142
      0079D7 80 04            [24] 1249 	sjmp	00199$
      0079D9                       1250 00198$:
      0079D9 7E 00            [12] 1251 	mov	r6,#0x00
      0079DB 7F 00            [12] 1252 	mov	r7,#0x00
      0079DD                       1253 00199$:
      0079DD 12 38 90         [24] 1254 	lcall	_ak820_outline_0126
      0079E0 12 73 B1         [24] 1255 	lcall	_host_consumer_send
                                   1256 ;	quantum/action.c:642: break;
      0079E3 02 7B 51         [24] 1257 	ljmp	00181$
                                   1258 ;	quantum/action.c:649: case ACT_LAYER: {
      0079E6                       1259 00131$:
                                   1260 ;	quantum/action.c:650: uint8_t on = action.layer_bitop.on;
      0079E6 90 08 9E         [24] 1261 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0079E9 E0               [24] 1262 	movx	a,@dptr
      0079EA 54 03            [12] 1263 	anl	a,#0x03
      0079EC 90 08 A2         [24] 1264 	mov	dptr,#_process_action_on_40000_685
      0079EF F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/action.c:653: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0079F0 E0               [24] 1267 	movx	a,@dptr
      0079F1 FF               [12] 1268 	mov	r7,a
      0079F2 60 11            [24] 1269 	jz	00200$
      0079F4 E5 1B            [12] 1270 	mov	a,_process_action_sloc0_1_0
      0079F6 60 07            [24] 1271 	jz	00202$
      0079F8 8F 06            [24] 1272 	mov	ar6,r7
      0079FA 53 06 01         [24] 1273 	anl	ar6,#0x01
      0079FD 80 10            [24] 1274 	sjmp	00201$
      0079FF                       1275 00202$:
      0079FF 74 02            [12] 1276 	mov	a,#0x02
      007A01 5F               [12] 1277 	anl	a,r7
      007A02 FE               [12] 1278 	mov	r6,a
      007A03 80 0A            [24] 1279 	sjmp	00201$
      007A05                       1280 00200$:
      007A05 E5 1B            [12] 1281 	mov	a,_process_action_sloc0_1_0
      007A07 B4 01 00         [24] 1282 	cjne	a,#0x01,00457$
      007A0A                       1283 00457$:
      007A0A 92 22            [24] 1284 	mov  _process_action_sloc1_1_0,c
      007A0C E4               [12] 1285 	clr	a
      007A0D 33               [12] 1286 	rlc	a
      007A0E FE               [12] 1287 	mov	r6,a
      007A0F                       1288 00201$:
      007A0F EE               [12] 1289 	mov	a,r6
      007A10 70 03            [24] 1290 	jnz	00458$
      007A12 02 7B 51         [24] 1291 	ljmp	00181$
      007A15                       1292 00458$:
                                   1293 ;	quantum/action.c:654: uint8_t shift = action.layer_bitop.part * 4;
      007A15 12 7D 8F         [24] 1294 	lcall	_ak820_outline_0170
      007A18 C4               [12] 1295 	swap	a
      007A19 03               [12] 1296 	rr	a
      007A1A 54 07            [12] 1297 	anl	a,#0x07
      007A1C 25 E0            [12] 1298 	add	a,acc
      007A1E 25 E0            [12] 1299 	add	a,acc
      007A20 FF               [12] 1300 	mov	r7,a
                                   1301 ;	quantum/action.c:655: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007A21 12 7D 8F         [24] 1302 	lcall	_ak820_outline_0170
      007A24 54 0F            [12] 1303 	anl	a,#0x0f
      007A26 FE               [12] 1304 	mov	r6,a
      007A27 8F F0            [24] 1305 	mov	b,r7
      007A29 05 F0            [12] 1306 	inc	b
      007A2B EE               [12] 1307 	mov	a,r6
      007A2C 80 02            [24] 1308 	sjmp	00460$
      007A2E                       1309 00459$:
      007A2E 25 E0            [12] 1310 	add	a,acc
      007A30                       1311 00460$:
      007A30 D5 F0 FB         [24] 1312 	djnz	b,00459$
      007A33 FE               [12] 1313 	mov	r6,a
                                   1314 ;	quantum/action.c:656: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007A34 12 7D 8F         [24] 1315 	lcall	_ak820_outline_0170
      007A37 30 E4 11         [24] 1316 	jnb	acc.4,00204$
      007A3A 8F F0            [24] 1317 	mov	b,r7
      007A3C 05 F0            [12] 1318 	inc	b
      007A3E 74 0F            [12] 1319 	mov	a,#0x0f
      007A40 80 02            [24] 1320 	sjmp	00463$
      007A42                       1321 00462$:
      007A42 25 E0            [12] 1322 	add	a,acc
      007A44                       1323 00463$:
      007A44 D5 F0 FB         [24] 1324 	djnz	b,00462$
      007A47 F4               [12] 1325 	cpl	a
      007A48 FF               [12] 1326 	mov	r7,a
      007A49 80 02            [24] 1327 	sjmp	00205$
      007A4B                       1328 00204$:
      007A4B 7F 00            [12] 1329 	mov	r7,#0x00
      007A4D                       1330 00205$:
                                   1331 ;	quantum/action.c:657: bits |= mask;
      007A4D EE               [12] 1332 	mov	a,r6
      007A4E 42 07            [12] 1333 	orl	ar7,a
                                   1334 ;	quantum/action.c:658: if (!on) {
      007A50 90 08 A2         [24] 1335 	mov	dptr,#_process_action_on_40000_685
      007A53 E0               [24] 1336 	movx	a,@dptr
      007A54 70 31            [24] 1337 	jnz	00143$
                                   1338 ;	quantum/action.c:659: switch (action.layer_bitop.op) {
      007A56 12 7D 63         [24] 1339 	lcall	_ak820_outline_0094
      007A59 FE               [12] 1340 	mov	r6,a
      007A5A 2E               [12] 1341 	add	a,r6
                                   1342 ;	quantum/action.c:660: case OP_BIT_AND: default_layer_and(bits); break;
      007A5B 90 7A 5F         [24] 1343 	mov	dptr,#00465$
      007A5E 73               [24] 1344 	jmp	@a+dptr
      007A5F                       1345 00465$:
      007A5F 80 06            [24] 1346 	sjmp	00132$
      007A61 80 0C            [24] 1347 	sjmp	00133$
      007A63 80 12            [24] 1348 	sjmp	00134$
      007A65 80 18            [24] 1349 	sjmp	00135$
      007A67                       1350 00132$:
      007A67 8F 82            [24] 1351 	mov	dpl, r7
      007A69 12 7D EA         [24] 1352 	lcall	_default_layer_and
      007A6C 02 7B 51         [24] 1353 	ljmp	00181$
                                   1354 ;	quantum/action.c:661: case OP_BIT_OR: default_layer_or(bits); break;
      007A6F                       1355 00133$:
      007A6F 8F 82            [24] 1356 	mov	dpl, r7
      007A71 12 7D DA         [24] 1357 	lcall	_default_layer_or
      007A74 02 7B 51         [24] 1358 	ljmp	00181$
                                   1359 ;	quantum/action.c:662: case OP_BIT_XOR: default_layer_xor(bits); break;
      007A77                       1360 00134$:
      007A77 8F 82            [24] 1361 	mov	dpl, r7
      007A79 12 7D FF         [24] 1362 	lcall	_default_layer_xor
      007A7C 02 7B 51         [24] 1363 	ljmp	00181$
                                   1364 ;	quantum/action.c:663: case OP_BIT_SET: default_layer_set(bits); break;
      007A7F                       1365 00135$:
      007A7F 8F 82            [24] 1366 	mov	dpl, r7
      007A81 12 7D D0         [24] 1367 	lcall	_default_layer_set
                                   1368 ;	quantum/action.c:664: }
      007A84 02 7B 51         [24] 1369 	ljmp	00181$
      007A87                       1370 00143$:
                                   1371 ;	quantum/action.c:666: switch (action.layer_bitop.op) {
      007A87 12 7D 63         [24] 1372 	lcall	_ak820_outline_0094
      007A8A FE               [12] 1373 	mov	r6,a
      007A8B 2E               [12] 1374 	add	a,r6
                                   1375 ;	quantum/action.c:667: case OP_BIT_AND: layer_and(bits); break;
      007A8C 90 7A 90         [24] 1376 	mov	dptr,#00466$
      007A8F 73               [24] 1377 	jmp	@a+dptr
      007A90                       1378 00466$:
      007A90 80 06            [24] 1379 	sjmp	00137$
      007A92 80 0C            [24] 1380 	sjmp	00138$
      007A94 80 12            [24] 1381 	sjmp	00139$
      007A96 80 18            [24] 1382 	sjmp	00140$
      007A98                       1383 00137$:
      007A98 8F 82            [24] 1384 	mov	dpl, r7
      007A9A 12 7F 70         [24] 1385 	lcall	_layer_and
      007A9D 02 7B 51         [24] 1386 	ljmp	00181$
                                   1387 ;	quantum/action.c:668: case OP_BIT_OR: layer_or(bits); break;
      007AA0                       1388 00138$:
      007AA0 8F 82            [24] 1389 	mov	dpl, r7
      007AA2 12 7F 60         [24] 1390 	lcall	_layer_or
      007AA5 02 7B 51         [24] 1391 	ljmp	00181$
                                   1392 ;	quantum/action.c:669: case OP_BIT_XOR: layer_xor(bits); break;
      007AA8                       1393 00139$:
      007AA8 8F 82            [24] 1394 	mov	dpl, r7
      007AAA 12 7F 85         [24] 1395 	lcall	_layer_xor
      007AAD 02 7B 51         [24] 1396 	ljmp	00181$
                                   1397 ;	quantum/action.c:670: case OP_BIT_SET: layer_state_set(bits); break;
      007AB0                       1398 00140$:
      007AB0 8F 82            [24] 1399 	mov	dpl, r7
      007AB2 12 7F 08         [24] 1400 	lcall	_layer_state_set
                                   1401 ;	quantum/action.c:674: break;
      007AB5 02 7B 51         [24] 1402 	ljmp	00181$
                                   1403 ;	quantum/action.c:676: case ACT_LAYER_MODS:
      007AB8                       1404 00147$:
                                   1405 ;	quantum/action.c:677: if (pressed) {
      007AB8 E5 1B            [12] 1406 	mov	a,_process_action_sloc0_1_0
      007ABA 60 11            [24] 1407 	jz	00149$
                                   1408 ;	quantum/action.c:678: layer_hold_on(action.layer_mods.layer);
      007ABC 12 7D 73         [24] 1409 	lcall	_ak820_outline_0121
      007ABF F5 82            [12] 1410 	mov	dpl,a
      007AC1 12 7E 6D         [24] 1411 	lcall	_layer_hold_on
                                   1412 ;	quantum/action.c:679: register_mods(action.layer_mods.mods);
      007AC4 12 7D 5C         [24] 1413 	lcall	_ak820_outline_0082
      007AC7 12 7C 82         [24] 1414 	lcall	_register_mods
      007ACA 02 7B 51         [24] 1415 	ljmp	00181$
      007ACD                       1416 00149$:
                                   1417 ;	quantum/action.c:681: unregister_mods(action.layer_mods.mods);
      007ACD 12 7D 5C         [24] 1418 	lcall	_ak820_outline_0082
      007AD0 12 7C 96         [24] 1419 	lcall	_unregister_mods
                                   1420 ;	quantum/action.c:682: layer_hold_off(action.layer_mods.layer);
      007AD3 12 7D 73         [24] 1421 	lcall	_ak820_outline_0121
      007AD6 F5 82            [12] 1422 	mov	dpl,a
      007AD8 12 7E A4         [24] 1423 	lcall	_layer_hold_off
                                   1424 ;	quantum/action.c:684: break;
      007ADB 02 7B 51         [24] 1425 	ljmp	00181$
                                   1426 ;	quantum/action.c:686: case ACT_LAYER_TAP_EXT:
      007ADE                       1427 00152$:
                                   1428 ;	quantum/action.c:687: switch (action.layer_tap.code) {
      007ADE 12 7D 8F         [24] 1429 	lcall	_ak820_outline_0170
      007AE1 FF               [12] 1430 	mov	r7,a
      007AE2 BF F1 02         [24] 1431 	cjne	r7,#0xf1,00468$
      007AE5 80 0A            [24] 1432 	sjmp	00154$
      007AE7                       1433 00468$:
      007AE7 BF F2 02         [24] 1434 	cjne	r7,#0xf2,00469$
      007AEA 80 19            [24] 1435 	sjmp	00155$
      007AEC                       1436 00469$:
                                   1437 ;	quantum/action.c:703: momentary_layer_action:
      007AEC BF F3 3B         [24] 1438 	cjne	r7,#0xf3,00160$
      007AEF 80 28            [24] 1439 	sjmp	00156$
      007AF1                       1440 00154$:
                                   1441 ;	quantum/action.c:704: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007AF1 E5 1B            [12] 1442 	mov	a,_process_action_sloc0_1_0
      007AF3 60 08            [24] 1443 	jz	00206$
      007AF5 12 7D 49         [24] 1444 	lcall	_ak820_outline_0048
      007AF8 12 7E 6D         [24] 1445 	lcall	_layer_hold_on
      007AFB 80 54            [24] 1446 	sjmp	00181$
      007AFD                       1447 00206$:
      007AFD 12 7D 49         [24] 1448 	lcall	_ak820_outline_0048
      007B00 12 7E A4         [24] 1449 	lcall	_layer_hold_off
                                   1450 ;	quantum/action.c:705: break;
                                   1451 ;	quantum/action.c:706: case OP_OFF_ON:
      007B03 80 4C            [24] 1452 	sjmp	00181$
      007B05                       1453 00155$:
                                   1454 ;	quantum/action.c:707: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007B05 E5 1B            [12] 1455 	mov	a,_process_action_sloc0_1_0
      007B07 60 08            [24] 1456 	jz	00208$
      007B09 12 7D 49         [24] 1457 	lcall	_ak820_outline_0048
      007B0C 12 7F 45         [24] 1458 	lcall	_layer_off
      007B0F 80 40            [24] 1459 	sjmp	00181$
      007B11                       1460 00208$:
      007B11 12 7D 49         [24] 1461 	lcall	_ak820_outline_0048
      007B14 12 7F 2D         [24] 1462 	lcall	_layer_on
                                   1463 ;	quantum/action.c:708: break;
                                   1464 ;	quantum/action.c:709: case OP_SET_CLEAR:
      007B17 80 38            [24] 1465 	sjmp	00181$
      007B19                       1466 00156$:
                                   1467 ;	quantum/action.c:710: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007B19 E5 1B            [12] 1468 	mov	a,_process_action_sloc0_1_0
      007B1B 60 08            [24] 1469 	jz	00210$
      007B1D 12 7D 49         [24] 1470 	lcall	_ak820_outline_0048
      007B20 12 7F 1A         [24] 1471 	lcall	_layer_move
      007B23 80 2C            [24] 1472 	sjmp	00181$
      007B25                       1473 00210$:
      007B25 12 7F 15         [24] 1474 	lcall	_layer_clear
                                   1475 ;	quantum/action.c:711: break;
                                   1476 ;	quantum/action.c:757: default:
      007B28 80 27            [24] 1477 	sjmp	00181$
      007B2A                       1478 00160$:
                                   1479 ;	quantum/action.c:764: if (pressed) {
      007B2A E5 1B            [12] 1480 	mov	a,_process_action_sloc0_1_0
      007B2C 60 08            [24] 1481 	jz	00163$
                                   1482 ;	quantum/action.c:766: register_code(action.layer_tap.code);
      007B2E 12 7D 5C         [24] 1483 	lcall	_ak820_outline_0082
      007B31 12 7B 68         [24] 1484 	lcall	_register_code
                                   1485 ;	quantum/action.c:768: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007B34 80 1B            [24] 1486 	sjmp	00181$
      007B36                       1487 00163$:
                                   1488 ;	quantum/action.c:769: if (action.layer_tap.code == KC_CAPS) {
      007B36 12 7D 8F         [24] 1489 	lcall	_ak820_outline_0170
      007B39 FF               [12] 1490 	mov	r7,a
      007B3A BF 39 0E         [24] 1491 	cjne	r7,#0x39,00175$
                                   1492 ;	quantum/action.c:770: wait_ms(TAP_HOLD_CAPS_DELAY);
      007B3D 7F 50            [12] 1493 	mov	r7,#0x50
      007B3F                       1494 00187$:
      007B3F EF               [12] 1495 	mov	a,r7
      007B40 60 09            [24] 1496 	jz	00175$
      007B42 90 00 01         [24] 1497 	mov	dptr,#0x0001
      007B45 12 5F 5C         [24] 1498 	lcall	_mDelaymS
      007B48 1F               [12] 1499 	dec	r7
                                   1500 ;	quantum/action.c:772: wait_ms(TAP_CODE_DELAY);
      007B49 80 F4            [24] 1501 	sjmp	00187$
      007B4B                       1502 00175$:
                                   1503 ;	quantum/action.c:774: unregister_code(action.layer_tap.code);
      007B4B 12 7D 5C         [24] 1504 	lcall	_ak820_outline_0082
      007B4E 12 7B D2         [24] 1505 	lcall	_unregister_code
                                   1506 ;	quantum/action.c:857: }
      007B51                       1507 00181$:
                                   1508 ;	quantum/action.c:878: switch (action.kind.id) {
      007B51 90 08 9E         [24] 1509 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007B54 E0               [24] 1510 	movx	a,@dptr
      007B55 C4               [12] 1511 	swap	a
      007B56 54 0F            [12] 1512 	anl	a,#0x0f
      007B58 FF               [12] 1513 	mov	r7,a
      007B59 BF 08 02         [24] 1514 	cjne	r7,#0x08,00478$
      007B5C 80 03            [24] 1515 	sjmp	00183$
      007B5E                       1516 00478$:
      007B5E BF 09 06         [24] 1517 	cjne	r7,#0x09,00192$
                                   1518 ;	quantum/action.c:880: case ACT_LAYER_MODS:
      007B61                       1519 00183$:
                                   1520 ;	quantum/action.c:885: led_set(host_keyboard_leds());
      007B61 12 72 E7         [24] 1521 	lcall	_host_keyboard_leds
                                   1522 ;	quantum/action.c:889: }
                                   1523 ;	quantum/action.c:942: }
      007B64 02 9F D0         [24] 1524 	ljmp	_led_set
      007B67                       1525 00192$:
      007B67 22               [24] 1526 	ret
                                   1527 ;------------------------------------------------------------
                                   1528 ;Allocation info for local variables in function 'register_code'
                                   1529 ;------------------------------------------------------------
                                   1530 ;code          Allocated with name '_register_code_code_10000_719'
                                   1531 ;------------------------------------------------------------
                                   1532 ;	quantum/action.c:948: __attribute__((weak)) void register_code(uint8_t code) {
                                   1533 ;	-----------------------------------------
                                   1534 ;	 function register_code
                                   1535 ;	-----------------------------------------
      007B68                       1536 _register_code:
      007B68 E5 82            [12] 1537 	mov	a,dpl
      007B6A 90 08 A3         [24] 1538 	mov	dptr,#_register_code_code_10000_719
      007B6D F0               [24] 1539 	movx	@dptr,a
                                   1540 ;	quantum/action.c:949: if (code == KC_NO) {
      007B6E E0               [24] 1541 	movx	a,@dptr
      007B6F FF               [12] 1542 	mov	r7,a
      007B70 70 01            [24] 1543 	jnz	00123$
                                   1544 ;	quantum/action.c:950: return;
      007B72 22               [24] 1545 	ret
      007B73                       1546 00123$:
                                   1547 ;	quantum/action.c:985: } else if (IS_BASIC_KEYCODE(code)) {
      007B73 BF 04 00         [24] 1548 	cjne	r7,#0x04,00186$
      007B76                       1549 00186$:
      007B76 40 12            [24] 1550 	jc	00119$
      007B78 EF               [12] 1551 	mov	a,r7
      007B79 24 5B            [12] 1552 	add	a,#0xff - 0xa4
      007B7B 40 0D            [24] 1553 	jc	00119$
                                   1554 ;	free result
                                   1555 ;	quantum/action.c:990: if (!add_owned_key(code)) return;
      007B7D 8F 82            [24] 1556 	mov	dpl, r7
      007B7F 12 83 81         [24] 1557 	lcall	_add_owned_key
      007B82 E5 82            [12] 1558 	mov	a, dpl
      007B84 70 01            [24] 1559 	jnz	00104$
      007B86 22               [24] 1560 	ret
      007B87                       1561 00104$:
                                   1562 ;	quantum/action.c:1004: send_keyboard_report();
      007B87 02 86 13         [24] 1563 	ljmp	_send_keyboard_report
      007B8A                       1564 00119$:
                                   1565 ;	quantum/action.c:1005: } else if (IS_MODIFIER_KEYCODE(code)) {
      007B8A 12 7D 94         [24] 1566 	lcall	_ak820_outline_0179
      007B8D BF E0 00         [24] 1567 	cjne	r7,#0xe0,00190$
      007B90                       1568 00190$:
      007B90 40 17            [24] 1569 	jc	00115$
      007B92 EF               [12] 1570 	mov	a,r7
      007B93 24 18            [12] 1571 	add	a,#0xff - 0xe7
      007B95 40 12            [24] 1572 	jc	00115$
                                   1573 ;	free result
                                   1574 ;	quantum/action.c:1006: add_owned_mods(MOD_BIT(code));
      007B97 12 7D 3F         [24] 1575 	lcall	_ak820_outline_0046
      007B9A 80 02            [24] 1576 	sjmp	00194$
      007B9C                       1577 00193$:
      007B9C 25 E0            [12] 1578 	add	a,acc
      007B9E                       1579 00194$:
      007B9E D5 F0 FB         [24] 1580 	djnz	b,00193$
      007BA1 F5 82            [12] 1581 	mov	dpl,a
      007BA3 12 82 E1         [24] 1582 	lcall	_add_owned_mods
                                   1583 ;	quantum/action.c:1007: send_keyboard_report();
      007BA6 02 86 13         [24] 1584 	ljmp	_send_keyboard_report
      007BA9                       1585 00115$:
                                   1586 ;	quantum/action.c:1010: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007BA9 12 7D 94         [24] 1587 	lcall	_ak820_outline_0179
      007BAC BF A5 00         [24] 1588 	cjne	r7,#0xa5,00195$
      007BAF                       1589 00195$:
      007BAF 40 05            [24] 1590 	jc	00113$
      007BB1 EF               [12] 1591 	mov	a,r7
      007BB2 24 58            [12] 1592 	add	a,#0xff - 0xa7
      007BB4 50 0D            [24] 1593 	jnc	00108$
                                   1594 ;	free result
      007BB6                       1595 00113$:
      007BB6 12 7D 94         [24] 1596 	lcall	_ak820_outline_0179
      007BB9 BF A8 00         [24] 1597 	cjne	r7,#0xa8,00198$
      007BBC                       1598 00198$:
      007BBC 40 13            [24] 1599 	jc	00125$
      007BBE EF               [12] 1600 	mov	a,r7
      007BBF 24 3D            [12] 1601 	add	a,#0xff - 0xc2
      007BC1 40 0E            [24] 1602 	jc	00125$
                                   1603 ;	free result
      007BC3                       1604 00108$:
                                   1605 ;	quantum/action.c:1012: owned_usage_key(code, true);
      007BC3 12 7D 94         [24] 1606 	lcall	_ak820_outline_0179
      007BC6 90 0A FE         [24] 1607 	mov	dptr,#_owned_usage_key_PARM_2
      007BC9 74 01            [12] 1608 	mov	a,#0x01
      007BCB F0               [24] 1609 	movx	@dptr,a
      007BCC 8F 82            [24] 1610 	mov	dpl, r7
                                   1611 ;	quantum/action.c:1020: register_mouse(code, true);
                                   1612 ;	quantum/action.c:1022: }
      007BCE 02 84 C0         [24] 1613 	ljmp	_owned_usage_key
      007BD1                       1614 00125$:
      007BD1 22               [24] 1615 	ret
                                   1616 ;------------------------------------------------------------
                                   1617 ;Allocation info for local variables in function 'unregister_code'
                                   1618 ;------------------------------------------------------------
                                   1619 ;code          Allocated with name '_unregister_code_code_10000_733'
                                   1620 ;------------------------------------------------------------
                                   1621 ;	quantum/action.c:1028: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1622 ;	-----------------------------------------
                                   1623 ;	 function unregister_code
                                   1624 ;	-----------------------------------------
      007BD2                       1625 _unregister_code:
      007BD2 E5 82            [12] 1626 	mov	a,dpl
      007BD4 90 08 A4         [24] 1627 	mov	dptr,#_unregister_code_code_10000_733
      007BD7 F0               [24] 1628 	movx	@dptr,a
                                   1629 ;	quantum/action.c:1029: if (code == KC_NO) {
      007BD8 E0               [24] 1630 	movx	a,@dptr
      007BD9 FF               [12] 1631 	mov	r7,a
      007BDA 70 01            [24] 1632 	jnz	00121$
                                   1633 ;	quantum/action.c:1030: return;
      007BDC 22               [24] 1634 	ret
      007BDD                       1635 00121$:
                                   1636 ;	quantum/action.c:1062: } else if (IS_BASIC_KEYCODE(code)) {
      007BDD BF 04 00         [24] 1637 	cjne	r7,#0x04,00184$
      007BE0                       1638 00184$:
      007BE0 40 12            [24] 1639 	jc	00117$
      007BE2 EF               [12] 1640 	mov	a,r7
      007BE3 24 5B            [12] 1641 	add	a,#0xff - 0xa4
      007BE5 40 0D            [24] 1642 	jc	00117$
                                   1643 ;	free result
                                   1644 ;	quantum/action.c:1064: if (!del_owned_key(code)) return;
      007BE7 8F 82            [24] 1645 	mov	dpl, r7
      007BE9 12 83 FA         [24] 1646 	lcall	_del_owned_key
      007BEC E5 82            [12] 1647 	mov	a, dpl
      007BEE 70 01            [24] 1648 	jnz	00102$
      007BF0 22               [24] 1649 	ret
      007BF1                       1650 00102$:
                                   1651 ;	quantum/action.c:1071: send_keyboard_report();
      007BF1 02 86 13         [24] 1652 	ljmp	_send_keyboard_report
      007BF4                       1653 00117$:
                                   1654 ;	quantum/action.c:1072: } else if (IS_MODIFIER_KEYCODE(code)) {
      007BF4 12 7D 9A         [24] 1655 	lcall	_ak820_outline_0180
      007BF7 BF E0 00         [24] 1656 	cjne	r7,#0xe0,00188$
      007BFA                       1657 00188$:
      007BFA 40 17            [24] 1658 	jc	00113$
      007BFC EF               [12] 1659 	mov	a,r7
      007BFD 24 18            [12] 1660 	add	a,#0xff - 0xe7
      007BFF 40 12            [24] 1661 	jc	00113$
                                   1662 ;	free result
                                   1663 ;	quantum/action.c:1073: del_owned_mods(MOD_BIT(code));
      007C01 12 7D 3F         [24] 1664 	lcall	_ak820_outline_0046
      007C04 80 02            [24] 1665 	sjmp	00192$
      007C06                       1666 00191$:
      007C06 25 E0            [12] 1667 	add	a,acc
      007C08                       1668 00192$:
      007C08 D5 F0 FB         [24] 1669 	djnz	b,00191$
      007C0B F5 82            [12] 1670 	mov	dpl,a
      007C0D 12 82 F0         [24] 1671 	lcall	_del_owned_mods
                                   1672 ;	quantum/action.c:1074: send_keyboard_report();
      007C10 02 86 13         [24] 1673 	ljmp	_send_keyboard_report
      007C13                       1674 00113$:
                                   1675 ;	quantum/action.c:1077: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007C13 12 7D 9A         [24] 1676 	lcall	_ak820_outline_0180
      007C16 BF A5 00         [24] 1677 	cjne	r7,#0xa5,00193$
      007C19                       1678 00193$:
      007C19 40 05            [24] 1679 	jc	00111$
      007C1B EF               [12] 1680 	mov	a,r7
      007C1C 24 58            [12] 1681 	add	a,#0xff - 0xa7
      007C1E 50 0D            [24] 1682 	jnc	00106$
                                   1683 ;	free result
      007C20                       1684 00111$:
      007C20 12 7D 9A         [24] 1685 	lcall	_ak820_outline_0180
      007C23 BF A8 00         [24] 1686 	cjne	r7,#0xa8,00196$
      007C26                       1687 00196$:
      007C26 40 12            [24] 1688 	jc	00123$
      007C28 EF               [12] 1689 	mov	a,r7
      007C29 24 3D            [12] 1690 	add	a,#0xff - 0xc2
      007C2B 40 0D            [24] 1691 	jc	00123$
                                   1692 ;	free result
      007C2D                       1693 00106$:
                                   1694 ;	quantum/action.c:1079: owned_usage_key(code, false);
      007C2D 12 7D 9A         [24] 1695 	lcall	_ak820_outline_0180
      007C30 90 0A FE         [24] 1696 	mov	dptr,#_owned_usage_key_PARM_2
      007C33 E4               [12] 1697 	clr	a
      007C34 F0               [24] 1698 	movx	@dptr,a
      007C35 8F 82            [24] 1699 	mov	dpl, r7
                                   1700 ;	quantum/action.c:1087: register_mouse(code, false);
                                   1701 ;	quantum/action.c:1089: }
      007C37 02 84 C0         [24] 1702 	ljmp	_owned_usage_key
      007C3A                       1703 00123$:
      007C3A 22               [24] 1704 	ret
                                   1705 ;------------------------------------------------------------
                                   1706 ;Allocation info for local variables in function 'tap_code_delay'
                                   1707 ;------------------------------------------------------------
                                   1708 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1709 ;code          Allocated with name '_tap_code_delay_code_10000_746'
                                   1710 ;i             Allocated with name '_tap_code_delay_i_20000_748'
                                   1711 ;i             Allocated with name '_tap_code_delay_i_50000_751'
                                   1712 ;------------------------------------------------------------
                                   1713 ;	quantum/action.c:1096: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1714 ;	-----------------------------------------
                                   1715 ;	 function tap_code_delay
                                   1716 ;	-----------------------------------------
      007C3B                       1717 _tap_code_delay:
      007C3B E5 82            [12] 1718 	mov	a,dpl
      007C3D 90 08 A7         [24] 1719 	mov	dptr,#_tap_code_delay_code_10000_746
      007C40 F0               [24] 1720 	movx	@dptr,a
                                   1721 ;	quantum/action.c:1097: register_code(code);
      007C41 E0               [24] 1722 	movx	a,@dptr
      007C42 FF               [12] 1723 	mov	r7,a
      007C43 F5 82            [12] 1724 	mov	dpl,a
      007C45 C0 07            [24] 1725 	push	ar7
      007C47 71 68            [12] 1726 	acall	_register_code
      007C49 D0 07            [24] 1727 	pop	ar7
                                   1728 ;	quantum/action.c:1098: for (uint16_t i = delay; i > 0; i--) {
      007C4B 90 08 A5         [24] 1729 	mov	dptr,#_tap_code_delay_PARM_2
      007C4E 12 38 62         [24] 1730 	lcall	_ak820_outline_0085
      007C51                       1731 00110$:
      007C51 ED               [12] 1732 	mov	a,r5
      007C52 4E               [12] 1733 	orl	a,r6
      007C53 60 0D            [24] 1734 	jz	00105$
                                   1735 ;	quantum/action.c:1099: wait_ms(1);
      007C55 90 00 01         [24] 1736 	mov	dptr,#0x0001
      007C58 12 5F 5C         [24] 1737 	lcall	_mDelaymS
                                   1738 ;	quantum/action.c:1098: for (uint16_t i = delay; i > 0; i--) {
      007C5B 1D               [12] 1739 	dec	r5
      007C5C BD FF 01         [24] 1740 	cjne	r5,#0xff,00141$
      007C5F 1E               [12] 1741 	dec	r6
      007C60                       1742 00141$:
      007C60 80 EF            [24] 1743 	sjmp	00110$
      007C62                       1744 00105$:
                                   1745 ;	quantum/action.c:1101: unregister_code(code);
      007C62 8F 82            [24] 1746 	mov	dpl, r7
                                   1747 ;	quantum/action.c:1102: }
      007C64 61 D2            [12] 1748 	ajmp	_unregister_code
                                   1749 ;------------------------------------------------------------
                                   1750 ;Allocation info for local variables in function 'tap_code'
                                   1751 ;------------------------------------------------------------
                                   1752 ;code          Allocated with name '_tap_code_code_10000_753'
                                   1753 ;------------------------------------------------------------
                                   1754 ;	quantum/action.c:1108: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1755 ;	-----------------------------------------
                                   1756 ;	 function tap_code
                                   1757 ;	-----------------------------------------
      007C66                       1758 _tap_code:
      007C66 E5 82            [12] 1759 	mov	a,dpl
      007C68 90 08 A8         [24] 1760 	mov	dptr,#_tap_code_code_10000_753
      007C6B F0               [24] 1761 	movx	@dptr,a
                                   1762 ;	quantum/action.c:1109: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007C6C E0               [24] 1763 	movx	a,@dptr
      007C6D FF               [12] 1764 	mov	r7,a
      007C6E BF 39 04         [24] 1765 	cjne	r7,#0x39,00103$
      007C71 7E 50            [12] 1766 	mov	r6,#0x50
      007C73 80 02            [24] 1767 	sjmp	00104$
      007C75                       1768 00103$:
      007C75 7E 00            [12] 1769 	mov	r6,#0x00
      007C77                       1770 00104$:
      007C77 90 08 A5         [24] 1771 	mov	dptr,#_tap_code_delay_PARM_2
      007C7A EE               [12] 1772 	mov	a,r6
      007C7B 12 38 A6         [24] 1773 	lcall	_ak820_outline_0135
      007C7E 8F 82            [24] 1774 	mov	dpl, r7
                                   1775 ;	quantum/action.c:1110: }
      007C80 81 3B            [12] 1776 	ajmp	_tap_code_delay
                                   1777 ;------------------------------------------------------------
                                   1778 ;Allocation info for local variables in function 'register_mods'
                                   1779 ;------------------------------------------------------------
                                   1780 ;mods          Allocated with name '_register_mods_mods_10000_755'
                                   1781 ;------------------------------------------------------------
                                   1782 ;	quantum/action.c:1116: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1783 ;	-----------------------------------------
                                   1784 ;	 function register_mods
                                   1785 ;	-----------------------------------------
      007C82                       1786 _register_mods:
      007C82 E5 82            [12] 1787 	mov	a,dpl
      007C84 90 08 A9         [24] 1788 	mov	dptr,#_register_mods_mods_10000_755
      007C87 F0               [24] 1789 	movx	@dptr,a
                                   1790 ;	quantum/action.c:1117: if (mods) {
      007C88 E0               [24] 1791 	movx	a,@dptr
      007C89 FF               [12] 1792 	mov	r7,a
      007C8A E0               [24] 1793 	movx	a,@dptr
      007C8B 60 08            [24] 1794 	jz	00103$
                                   1795 ;	quantum/action.c:1118: add_owned_mods(mods);
      007C8D 8F 82            [24] 1796 	mov	dpl, r7
      007C8F 12 82 E1         [24] 1797 	lcall	_add_owned_mods
                                   1798 ;	quantum/action.c:1119: send_keyboard_report();
                                   1799 ;	quantum/action.c:1121: }
      007C92 02 86 13         [24] 1800 	ljmp	_send_keyboard_report
      007C95                       1801 00103$:
      007C95 22               [24] 1802 	ret
                                   1803 ;------------------------------------------------------------
                                   1804 ;Allocation info for local variables in function 'unregister_mods'
                                   1805 ;------------------------------------------------------------
                                   1806 ;mods          Allocated with name '_unregister_mods_mods_10000_759'
                                   1807 ;------------------------------------------------------------
                                   1808 ;	quantum/action.c:1127: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1809 ;	-----------------------------------------
                                   1810 ;	 function unregister_mods
                                   1811 ;	-----------------------------------------
      007C96                       1812 _unregister_mods:
      007C96 E5 82            [12] 1813 	mov	a,dpl
      007C98 90 08 AA         [24] 1814 	mov	dptr,#_unregister_mods_mods_10000_759
      007C9B F0               [24] 1815 	movx	@dptr,a
                                   1816 ;	quantum/action.c:1128: if (mods) {
      007C9C E0               [24] 1817 	movx	a,@dptr
      007C9D FF               [12] 1818 	mov	r7,a
      007C9E E0               [24] 1819 	movx	a,@dptr
      007C9F 60 08            [24] 1820 	jz	00103$
                                   1821 ;	quantum/action.c:1129: del_owned_mods(mods);
      007CA1 8F 82            [24] 1822 	mov	dpl, r7
      007CA3 12 82 F0         [24] 1823 	lcall	_del_owned_mods
                                   1824 ;	quantum/action.c:1130: send_keyboard_report();
                                   1825 ;	quantum/action.c:1132: }
      007CA6 02 86 13         [24] 1826 	ljmp	_send_keyboard_report
      007CA9                       1827 00103$:
      007CA9 22               [24] 1828 	ret
                                   1829 ;------------------------------------------------------------
                                   1830 ;Allocation info for local variables in function 'register_weak_mods'
                                   1831 ;------------------------------------------------------------
                                   1832 ;mods          Allocated with name '_register_weak_mods_mods_10000_763'
                                   1833 ;------------------------------------------------------------
                                   1834 ;	quantum/action.c:1138: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1835 ;	-----------------------------------------
                                   1836 ;	 function register_weak_mods
                                   1837 ;	-----------------------------------------
      007CAA                       1838 _register_weak_mods:
      007CAA E5 82            [12] 1839 	mov	a,dpl
      007CAC 90 08 AB         [24] 1840 	mov	dptr,#_register_weak_mods_mods_10000_763
      007CAF F0               [24] 1841 	movx	@dptr,a
                                   1842 ;	quantum/action.c:1139: if (mods) {
      007CB0 E0               [24] 1843 	movx	a,@dptr
      007CB1 FF               [12] 1844 	mov	r7,a
      007CB2 E0               [24] 1845 	movx	a,@dptr
      007CB3 60 08            [24] 1846 	jz	00103$
                                   1847 ;	quantum/action.c:1140: add_owned_weak_mods(mods);
      007CB5 8F 82            [24] 1848 	mov	dpl, r7
      007CB7 12 82 FE         [24] 1849 	lcall	_add_owned_weak_mods
                                   1850 ;	quantum/action.c:1141: send_keyboard_report();
                                   1851 ;	quantum/action.c:1143: }
      007CBA 02 86 13         [24] 1852 	ljmp	_send_keyboard_report
      007CBD                       1853 00103$:
      007CBD 22               [24] 1854 	ret
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1857 ;------------------------------------------------------------
                                   1858 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_767'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	quantum/action.c:1149: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1861 ;	-----------------------------------------
                                   1862 ;	 function unregister_weak_mods
                                   1863 ;	-----------------------------------------
      007CBE                       1864 _unregister_weak_mods:
      007CBE E5 82            [12] 1865 	mov	a,dpl
      007CC0 90 08 AC         [24] 1866 	mov	dptr,#_unregister_weak_mods_mods_10000_767
      007CC3 F0               [24] 1867 	movx	@dptr,a
                                   1868 ;	quantum/action.c:1150: if (mods) {
      007CC4 E0               [24] 1869 	movx	a,@dptr
      007CC5 FF               [12] 1870 	mov	r7,a
      007CC6 E0               [24] 1871 	movx	a,@dptr
      007CC7 60 08            [24] 1872 	jz	00103$
                                   1873 ;	quantum/action.c:1151: del_owned_weak_mods(mods);
      007CC9 8F 82            [24] 1874 	mov	dpl, r7
      007CCB 12 83 0D         [24] 1875 	lcall	_del_owned_weak_mods
                                   1876 ;	quantum/action.c:1152: send_keyboard_report();
                                   1877 ;	quantum/action.c:1154: }
      007CCE 02 86 13         [24] 1878 	ljmp	_send_keyboard_report
      007CD1                       1879 00103$:
      007CD1 22               [24] 1880 	ret
                                   1881 ;------------------------------------------------------------
                                   1882 ;Allocation info for local variables in function 'clear_keyboard'
                                   1883 ;------------------------------------------------------------
                                   1884 ;	quantum/action.c:1160: void clear_keyboard(void) {
                                   1885 ;	-----------------------------------------
                                   1886 ;	 function clear_keyboard
                                   1887 ;	-----------------------------------------
      007CD2                       1888 _clear_keyboard:
                                   1889 ;	quantum/action.c:1161: clear_mods();
      007CD2 12 87 75         [24] 1890 	lcall	_clear_mods
                                   1891 ;	quantum/action.c:1162: clear_keyboard_but_mods();
                                   1892 ;	quantum/action.c:1163: }
      007CD5 81 D7            [12] 1893 	ajmp	_clear_keyboard_but_mods
                                   1894 ;------------------------------------------------------------
                                   1895 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1896 ;------------------------------------------------------------
                                   1897 ;	quantum/action.c:1169: void clear_keyboard_but_mods(void) {
                                   1898 ;	-----------------------------------------
                                   1899 ;	 function clear_keyboard_but_mods
                                   1900 ;	-----------------------------------------
      007CD7                       1901 _clear_keyboard_but_mods:
                                   1902 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007CD7 90 0E 7F         [24] 1903 	mov	dptr,#_actual_keyboard_report
      007CDA 12 75 AA         [24] 1904 	lcall	_clear_keys_from_report
                                   1905 ;	quantum/action.c:1171: clear_keyboard_but_mods_and_keys();
                                   1906 ;	quantum/action.c:1172: }
      007CDD 81 DF            [12] 1907 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1910 ;------------------------------------------------------------
                                   1911 ;	quantum/action.c:1178: void clear_keyboard_but_mods_and_keys(void) {
                                   1912 ;	-----------------------------------------
                                   1913 ;	 function clear_keyboard_but_mods_and_keys
                                   1914 ;	-----------------------------------------
      007CDF                       1915 _clear_keyboard_but_mods_and_keys:
                                   1916 ;	quantum/action.c:1180: ak820_tapping_cancel();
      007CDF 12 4D 8B         [24] 1917 	lcall	_ak820_tapping_cancel
                                   1918 ;	quantum/action.c:1185: ak820_key_override_cancel();
      007CE2 12 3D 8C         [24] 1919 	lcall	_ak820_key_override_cancel
                                   1920 ;	quantum/action.c:1197: ak820_oneshot_cancel();
      007CE5 12 2E F0         [24] 1921 	lcall	_ak820_oneshot_cancel
                                   1922 ;	quantum/action.c:1200: ak820_combo_cancel();
      007CE8 12 35 6A         [24] 1923 	lcall	_ak820_combo_cancel
                                   1924 ;	quantum/action.c:1203: repeat_key_cancel();
      007CEB 12 AA 30         [24] 1925 	lcall	_repeat_key_cancel
                                   1926 ;	quantum/action.c:1205: clear_owned_mods();
      007CEE 12 83 1C         [24] 1927 	lcall	_clear_owned_mods
                                   1928 ;	quantum/action.c:1206: clear_owned_keys();
      007CF1 12 83 54         [24] 1929 	lcall	_clear_owned_keys
                                   1930 ;	quantum/action.c:1207: clear_owned_usages();
      007CF4 12 84 88         [24] 1931 	lcall	_clear_owned_usages
                                   1932 ;	quantum/action.c:1208: layer_hold_clear();
      007CF7 D1 DB            [12] 1933 	acall	_layer_hold_clear
                                   1934 ;	quantum/action.c:1210: clear_macro_tri_layer();
      007CF9 12 A4 7B         [24] 1935 	lcall	_clear_macro_tri_layer
                                   1936 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007CFC 90 0E 7F         [24] 1937 	mov	dptr,#_actual_keyboard_report
      007CFF 12 75 AA         [24] 1938 	lcall	_clear_keys_from_report
                                   1939 ;	quantum/action.c:1215: host_system_send(0);
      007D02 90 00 00         [24] 1940 	mov	dptr,#0x0000
      007D05 12 73 82         [24] 1941 	lcall	_host_system_send
                                   1942 ;	quantum/action.c:1216: host_consumer_send(0);
      007D08 90 00 00         [24] 1943 	mov	dptr,#0x0000
      007D0B 12 73 B1         [24] 1944 	lcall	_host_consumer_send
                                   1945 ;	quantum/action.c:1218: clear_weak_mods();
      007D0E 12 87 AA         [24] 1946 	lcall	_clear_weak_mods
                                   1947 ;	quantum/action.c:1219: send_keyboard_report();
                                   1948 ;	quantum/action.c:1227: }
      007D11 02 86 13         [24] 1949 	ljmp	_send_keyboard_report
                                   1950 ;------------------------------------------------------------
                                   1951 ;Allocation info for local variables in function 'is_tap_record'
                                   1952 ;------------------------------------------------------------
                                   1953 ;record        Allocated with name '_is_tap_record_record_10000_783'
                                   1954 ;action        Allocated with name '_is_tap_record_action_10001_787'
                                   1955 ;------------------------------------------------------------
                                   1956 ;	quantum/action.c:1233: bool is_tap_record(keyrecord_t *record) {
                                   1957 ;	-----------------------------------------
                                   1958 	.area CSEG    (CODE)
                                   1959 	.area CONST   (CODE)
                                   1960 	.area XINIT   (CODE)
      00CA38                       1961 __xinit__disable_action_cache:
      00CA38 00                    1962 	.db #0x00	;  0
                                   1963 	.area CABS    (ABS,CODE)
                                   1964 
                                   1965 ; Experimental exact instruction outlining.
                                   1966 	.globl _ak820_outline_0001
                                   1967 	.globl _ak820_outline_0002
                                   1968 	.globl _ak820_outline_0006
                                   1969 	.globl _ak820_outline_0010
                                   1970 	.globl _ak820_outline_0012
                                   1971 	.globl _ak820_outline_0013
                                   1972 	.globl _ak820_outline_0014
                                   1973 	.globl _ak820_outline_0015
                                   1974 	.globl _ak820_outline_0022
                                   1975 	.globl _ak820_outline_0025
                                   1976 	.globl _ak820_outline_0036
                                   1977 	.globl _ak820_outline_0038
                                   1978 	.globl _ak820_outline_0041
                                   1979 	.globl _ak820_outline_0046
                                   1980 	.globl _ak820_outline_0048
                                   1981 	.globl _ak820_outline_0063
                                   1982 	.globl _ak820_outline_0076
                                   1983 	.globl _ak820_outline_0077
                                   1984 	.globl _ak820_outline_0079
                                   1985 	.globl _ak820_outline_0082
                                   1986 	.globl _ak820_outline_0085
                                   1987 	.globl _ak820_outline_0094
                                   1988 	.globl _ak820_outline_0114
                                   1989 	.globl _ak820_outline_0115
                                   1990 	.globl _ak820_outline_0117
                                   1991 	.globl _ak820_outline_0119
                                   1992 	.globl _ak820_outline_0120
                                   1993 	.globl _ak820_outline_0121
                                   1994 	.globl _ak820_outline_0126
                                   1995 	.globl _ak820_outline_0129
                                   1996 	.globl _ak820_outline_0134
                                   1997 	.globl _ak820_outline_0135
                                   1998 	.globl _ak820_outline_0142
                                   1999 	.globl _ak820_outline_0144
                                   2000 	.globl _ak820_outline_0153
                                   2001 	.globl _ak820_outline_0157
                                   2002 	.globl _ak820_outline_0160
                                   2003 	.globl _ak820_outline_0166
                                   2004 	.globl _ak820_outline_0167
                                   2005 	.globl _ak820_outline_0170
                                   2006 	.globl _ak820_outline_0179
                                   2007 	.globl _ak820_outline_0180
                                   2008 	.globl _ak820_outline_0197
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0014
      007D14                       2012 _ak820_outline_0014:
      007D14 2D               [12] 2013 	add	a,r5
      007D15 F9               [12] 2014 	mov	r1,a
      007D16 E4               [12] 2015 	clr	a
      007D17 3E               [12] 2016 	addc	a,r6
      007D18 FA               [12] 2017 	mov	r2,a
      007D19 8F 03            [24] 2018 	mov	ar3,r7
      007D1B 89 82            [24] 2019 	mov	dpl,r1
      007D1D 8A 83            [24] 2020 	mov	dph,r2
      007D1F 8B F0            [24] 2021 	mov	b,r3
      007D21 22               [24] 2022 	ret
                                   2023 
                                   2024 	.area CSEG (CODE)
                                   2025 ; function ak820_outline_0015
      007D22                       2026 _ak820_outline_0015:
      007D22 2D               [12] 2027 	add	a,r5
      007D23 FA               [12] 2028 	mov	r2,a
      007D24 E4               [12] 2029 	clr	a
      007D25 3E               [12] 2030 	addc	a,r6
      007D26 FB               [12] 2031 	mov	r3,a
      007D27 8F 04            [24] 2032 	mov	ar4,r7
      007D29 8A 82            [24] 2033 	mov	dpl,r2
      007D2B 8B 83            [24] 2034 	mov	dph,r3
      007D2D 8C F0            [24] 2035 	mov	b,r4
      007D2F 22               [24] 2036 	ret
                                   2037 
                                   2038 	.area CSEG (CODE)
                                   2039 ; function ak820_outline_0025
      007D30                       2040 _ak820_outline_0025:
      007D30 8E 82            [24] 2041 	mov	dpl,r6
      007D32 8F 83            [24] 2042 	mov	dph,r7
      007D34 A3               [24] 2043 	inc	dptr
      007D35 E0               [24] 2044 	movx	a,@dptr
      007D36 FC               [12] 2045 	mov	r4,a
      007D37 7D 00            [12] 2046 	mov	r5,#0x00
      007D39 8E 82            [24] 2047 	mov	dpl,r6
      007D3B 8F 83            [24] 2048 	mov	dph,r7
      007D3D E0               [24] 2049 	movx	a,@dptr
      007D3E 22               [24] 2050 	ret
                                   2051 
                                   2052 	.area CSEG (CODE)
                                   2053 ; function ak820_outline_0046
      007D3F                       2054 _ak820_outline_0046:
      007D3F 74 07            [12] 2055 	mov	a,#0x07
      007D41 5F               [12] 2056 	anl	a,r7
      007D42 F5 F0            [12] 2057 	mov	b,a
      007D44 05 F0            [12] 2058 	inc	b
      007D46 74 01            [12] 2059 	mov	a,#0x01
      007D48 22               [24] 2060 	ret
                                   2061 
                                   2062 	.area CSEG (CODE)
                                   2063 ; function ak820_outline_0048
      007D49                       2064 _ak820_outline_0048:
      007D49 90 08 9E         [24] 2065 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007D4C E0               [24] 2066 	movx	a,@dptr
      007D4D 54 1F            [12] 2067 	anl	a,#0x1f
      007D4F F5 82            [12] 2068 	mov	dpl,a
      007D51 22               [24] 2069 	ret
                                   2070 
                                   2071 	.area CSEG (CODE)
                                   2072 ; function ak820_outline_0076
      007D52                       2073 _ak820_outline_0076:
      007D52 90 0E 5A         [24] 2074 	mov	dptr,#___memcpy_PARM_3
      007D55 74 06            [12] 2075 	mov	a,#0x06
      007D57 F0               [24] 2076 	movx	@dptr,a
      007D58 E4               [12] 2077 	clr	a
      007D59 A3               [24] 2078 	inc	dptr
      007D5A F0               [24] 2079 	movx	@dptr,a
      007D5B 22               [24] 2080 	ret
                                   2081 
                                   2082 	.area CSEG (CODE)
                                   2083 ; function ak820_outline_0082
      007D5C                       2084 _ak820_outline_0082:
      007D5C 90 08 9D         [24] 2085 	mov	dptr,#_process_action_PARM_2
      007D5F E0               [24] 2086 	movx	a,@dptr
      007D60 F5 82            [12] 2087 	mov	dpl,a
      007D62 22               [24] 2088 	ret
                                   2089 
                                   2090 	.area CSEG (CODE)
                                   2091 ; function ak820_outline_0094
      007D63                       2092 _ak820_outline_0094:
      007D63 90 08 9E         [24] 2093 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007D66 E0               [24] 2094 	movx	a,@dptr
      007D67 03               [12] 2095 	rr	a
      007D68 03               [12] 2096 	rr	a
      007D69 54 03            [12] 2097 	anl	a,#0x03
      007D6B 22               [24] 2098 	ret
                                   2099 
                                   2100 	.area CSEG (CODE)
                                   2101 ; function ak820_outline_0120
      007D6C                       2102 _ak820_outline_0120:
      007D6C 8E 82            [24] 2103 	mov	dpl,r6
      007D6E 8F 83            [24] 2104 	mov	dph,r7
      007D70 8D F0            [24] 2105 	mov	b,r5
      007D72 22               [24] 2106 	ret
                                   2107 
                                   2108 	.area CSEG (CODE)
                                   2109 ; function ak820_outline_0121
      007D73                       2110 _ak820_outline_0121:
      007D73 90 08 9E         [24] 2111 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007D76 E0               [24] 2112 	movx	a,@dptr
      007D77 54 0F            [12] 2113 	anl	a,#0x0f
      007D79 22               [24] 2114 	ret
                                   2115 
                                   2116 	.area CSEG (CODE)
                                   2117 ; function ak820_outline_0142
      007D7A                       2118 _ak820_outline_0142:
      007D7A 90 08 9D         [24] 2119 	mov	dptr,#_process_action_PARM_2
      007D7D E0               [24] 2120 	movx	a,@dptr
      007D7E FE               [12] 2121 	mov	r6,a
      007D7F A3               [24] 2122 	inc	dptr
      007D80 E0               [24] 2123 	movx	a,@dptr
      007D81 54 03            [12] 2124 	anl	a,#0x03
      007D83 FF               [12] 2125 	mov	r7,a
      007D84 22               [24] 2126 	ret
                                   2127 
                                   2128 	.area CSEG (CODE)
                                   2129 ; function ak820_outline_0157
      007D85                       2130 _ak820_outline_0157:
      007D85 74 07            [12] 2131 	mov	a,#0x07
      007D87 2D               [12] 2132 	add	a,r5
      007D88 F8               [12] 2133 	mov	r0,a
      007D89 E4               [12] 2134 	clr	a
      007D8A 3E               [12] 2135 	addc	a,r6
      007D8B F9               [12] 2136 	mov	r1,a
      007D8C 8F 02            [24] 2137 	mov	ar2,r7
      007D8E 22               [24] 2138 	ret
                                   2139 
                                   2140 	.area CSEG (CODE)
                                   2141 ; function ak820_outline_0170
      007D8F                       2142 _ak820_outline_0170:
      007D8F 90 08 9D         [24] 2143 	mov	dptr,#_process_action_PARM_2
      007D92 E0               [24] 2144 	movx	a,@dptr
      007D93 22               [24] 2145 	ret
                                   2146 
                                   2147 	.area CSEG (CODE)
                                   2148 ; function ak820_outline_0179
      007D94                       2149 _ak820_outline_0179:
      007D94 90 08 A3         [24] 2150 	mov	dptr,#_register_code_code_10000_719
      007D97 E0               [24] 2151 	movx	a,@dptr
      007D98 FF               [12] 2152 	mov	r7,a
      007D99 22               [24] 2153 	ret
                                   2154 
                                   2155 	.area CSEG (CODE)
                                   2156 ; function ak820_outline_0180
      007D9A                       2157 _ak820_outline_0180:
      007D9A 90 08 A4         [24] 2158 	mov	dptr,#_unregister_code_code_10000_733
      007D9D E0               [24] 2159 	movx	a,@dptr
      007D9E FF               [12] 2160 	mov	r7,a
      007D9F 22               [24] 2161 	ret
                                   2162 
                                   2163 	.area CSEG (CODE)
                                   2164 ; function ak820_outline_0197
      007DA0                       2165 _ak820_outline_0197:
      007DA0 F0               [24] 2166 	movx	@dptr,a
      007DA1 EB               [12] 2167 	mov	a,r3
      007DA2 A3               [24] 2168 	inc	dptr
      007DA3 F0               [24] 2169 	movx	@dptr,a
      007DA4 22               [24] 2170 	ret
