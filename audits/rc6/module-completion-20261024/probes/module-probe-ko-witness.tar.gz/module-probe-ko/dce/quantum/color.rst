                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module color
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ADC_START
                                     12 	.globl _S0_R_FIFO
                                     13 	.globl _S0_T_FIFO
                                     14 	.globl _S0_FREE
                                     15 	.globl _S0_IF_BYTE
                                     16 	.globl _S0_IF_FIRST
                                     17 	.globl _S0_IF_OV
                                     18 	.globl _S0_FST_ACT
                                     19 	.globl _CP_RL2
                                     20 	.globl _C_T2
                                     21 	.globl _TR2
                                     22 	.globl _EXEN2
                                     23 	.globl _TCLK
                                     24 	.globl _RCLK
                                     25 	.globl _EXF2
                                     26 	.globl _CAP1F
                                     27 	.globl _TF2
                                     28 	.globl _RI
                                     29 	.globl _TI
                                     30 	.globl _RB8
                                     31 	.globl _TB8
                                     32 	.globl _REN
                                     33 	.globl _SM2
                                     34 	.globl _SM1
                                     35 	.globl _SM0
                                     36 	.globl _IT0
                                     37 	.globl _IE0
                                     38 	.globl _IT1
                                     39 	.globl _IE1
                                     40 	.globl _TR0
                                     41 	.globl _TF0
                                     42 	.globl _TR1
                                     43 	.globl _TF1
                                     44 	.globl _P4_0
                                     45 	.globl _P4_1
                                     46 	.globl _P4_2
                                     47 	.globl _P4_3
                                     48 	.globl _P4_4
                                     49 	.globl _P4_5
                                     50 	.globl _P4_6
                                     51 	.globl _RXD
                                     52 	.globl _TXD
                                     53 	.globl _INT0
                                     54 	.globl _INT1
                                     55 	.globl _T0
                                     56 	.globl _T1
                                     57 	.globl _MOSI1
                                     58 	.globl _MISO1
                                     59 	.globl _SCK1
                                     60 	.globl _P3_0
                                     61 	.globl _P3_1
                                     62 	.globl _P3_2
                                     63 	.globl _P3_3
                                     64 	.globl _P3_4
                                     65 	.globl _P3_5
                                     66 	.globl _P3_6
                                     67 	.globl _P3_7
                                     68 	.globl _CAP1_
                                     69 	.globl _T2_
                                     70 	.globl _CAP2_
                                     71 	.globl _T2EX_
                                     72 	.globl _RXD1
                                     73 	.globl _TXD1
                                     74 	.globl _P2_0
                                     75 	.globl _P2_1
                                     76 	.globl _P2_2
                                     77 	.globl _P2_3
                                     78 	.globl _P2_4
                                     79 	.globl _P2_5
                                     80 	.globl _P2_6
                                     81 	.globl _P2_7
                                     82 	.globl _AIN0
                                     83 	.globl _AIN1
                                     84 	.globl _AIN2
                                     85 	.globl _AIN3
                                     86 	.globl _AIN4
                                     87 	.globl _AIN5
                                     88 	.globl _AIN6
                                     89 	.globl _AIN7
                                     90 	.globl _CAP1
                                     91 	.globl _T2
                                     92 	.globl _CAP2
                                     93 	.globl _T2EX
                                     94 	.globl _INT0_
                                     95 	.globl _SCS
                                     96 	.globl _MOSI
                                     97 	.globl _MISO
                                     98 	.globl _SCK
                                     99 	.globl _RXD1_
                                    100 	.globl _TXD1_
                                    101 	.globl _P1_0
                                    102 	.globl _P1_1
                                    103 	.globl _P1_2
                                    104 	.globl _P1_3
                                    105 	.globl _P1_4
                                    106 	.globl _P1_5
                                    107 	.globl _P1_6
                                    108 	.globl _P1_7
                                    109 	.globl _AIN8
                                    110 	.globl _AIN9
                                    111 	.globl _AIN10
                                    112 	.globl _AIN11
                                    113 	.globl _AIN12
                                    114 	.globl _AIN13
                                    115 	.globl _RXD_
                                    116 	.globl _TXD_
                                    117 	.globl _SCL0
                                    118 	.globl _SDA0
                                    119 	.globl _P0_0
                                    120 	.globl _P0_1
                                    121 	.globl _P0_2
                                    122 	.globl _P0_3
                                    123 	.globl _P0_4
                                    124 	.globl _P0_5
                                    125 	.globl _P0_6
                                    126 	.globl _P0_7
                                    127 	.globl _IE_SPI0
                                    128 	.globl _IE_USB
                                    129 	.globl _IE_ADC
                                    130 	.globl _IE_UART1
                                    131 	.globl _IE_PWM_I2C
                                    132 	.globl _IE_GPIO
                                    133 	.globl _IE_WDOG
                                    134 	.globl _PX0
                                    135 	.globl _PT0
                                    136 	.globl _PX1
                                    137 	.globl _PT1
                                    138 	.globl _PS
                                    139 	.globl _PT2
                                    140 	.globl _PL_FLAG
                                    141 	.globl _PH_FLAG
                                    142 	.globl _EX0
                                    143 	.globl _ET0
                                    144 	.globl _EX1
                                    145 	.globl _ET1
                                    146 	.globl _ES
                                    147 	.globl _ET2
                                    148 	.globl _E_DIS
                                    149 	.globl _EA
                                    150 	.globl _P
                                    151 	.globl _F1
                                    152 	.globl _OV
                                    153 	.globl _RS0
                                    154 	.globl _RS1
                                    155 	.globl _F0
                                    156 	.globl _AC
                                    157 	.globl _CY
                                    158 	.globl _I2CS_INT_ST
                                    159 	.globl _I2CX_INT
                                    160 	.globl _LED_STATUS
                                    161 	.globl _LED_DMA_H
                                    162 	.globl _LED_DMA_L
                                    163 	.globl _LED_DMA
                                    164 	.globl _LED_PWM_OE
                                    165 	.globl _LED_COMMON
                                    166 	.globl _ADC_CHAN
                                    167 	.globl _ADC_DAT_H
                                    168 	.globl _ADC_DAT_L
                                    169 	.globl _ADC_DAT
                                    170 	.globl _ADC_CTRL
                                    171 	.globl _SPI1_CK_SE
                                    172 	.globl _SPI1_CTRL
                                    173 	.globl _SPI1_DATA
                                    174 	.globl _SPI1_STAT
                                    175 	.globl _SIF1
                                    176 	.globl _SBAUD1
                                    177 	.globl _SBUF1
                                    178 	.globl _SCON1
                                    179 	.globl _SPI0_SETUP
                                    180 	.globl _SPI0_CK_SE
                                    181 	.globl _SPI0_CTRL
                                    182 	.globl _SPI0_DATA
                                    183 	.globl _SPI0_STAT
                                    184 	.globl _T2CAP1H
                                    185 	.globl _T2CAP1L
                                    186 	.globl _T2CAP1
                                    187 	.globl _TH2
                                    188 	.globl _TL2
                                    189 	.globl _T2COUNT
                                    190 	.globl _RCAP2H
                                    191 	.globl _RCAP2L
                                    192 	.globl _RCAP2
                                    193 	.globl _T2MOD
                                    194 	.globl _T2CON
                                    195 	.globl _SBUF
                                    196 	.globl _SCON
                                    197 	.globl _TH1
                                    198 	.globl _TH0
                                    199 	.globl _TL1
                                    200 	.globl _TL0
                                    201 	.globl _TMOD
                                    202 	.globl _TCON
                                    203 	.globl _XBUS_AUX
                                    204 	.globl _P7
                                    205 	.globl _P6_DIR
                                    206 	.globl _P6_OUT_PU
                                    207 	.globl _P6_IN
                                    208 	.globl _P5_DIR
                                    209 	.globl _P5_OUT_PU
                                    210 	.globl _P5_IN
                                    211 	.globl _P4_LED_KEY
                                    212 	.globl _P4_DIR_PU
                                    213 	.globl _P4_MOD_OC
                                    214 	.globl _P4
                                    215 	.globl _P3_DIR_PU
                                    216 	.globl _P3_MOD_OC
                                    217 	.globl _P3
                                    218 	.globl _P2_DIR_PU
                                    219 	.globl _P2_MOD_OC
                                    220 	.globl _P2
                                    221 	.globl _P1_DIR_PU
                                    222 	.globl _P1_MOD_OC
                                    223 	.globl _P1
                                    224 	.globl _P0_DIR_PU
                                    225 	.globl _P0_MOD_OC
                                    226 	.globl _P0
                                    227 	.globl _ROM_CTRL
                                    228 	.globl _ROM_DATA_HH
                                    229 	.globl _ROM_DATA_HL
                                    230 	.globl _ROM_DATA_HI
                                    231 	.globl _ROM_ADDR_H
                                    232 	.globl _ROM_ADDR_L
                                    233 	.globl _ROM_ADDR
                                    234 	.globl _GPIO_IE
                                    235 	.globl _IP_EX
                                    236 	.globl _IE_EX
                                    237 	.globl _IP
                                    238 	.globl _IE
                                    239 	.globl _WDOG_COUNT
                                    240 	.globl _RESET_KEEP
                                    241 	.globl _WAKE_CTRL
                                    242 	.globl _CLOCK_CFG
                                    243 	.globl _POWER_CFG
                                    244 	.globl _PCON
                                    245 	.globl _GLOBAL_CFG
                                    246 	.globl _SAFE_MOD
                                    247 	.globl _DPH
                                    248 	.globl _DPL
                                    249 	.globl _SP
                                    250 	.globl _A_INV
                                    251 	.globl _B
                                    252 	.globl _ACC
                                    253 	.globl _PSW
                                    254 	.globl _hsv_to_rgb_into_PARM_3
                                    255 	.globl _hsv_to_rgb_into_PARM_1
                                    256 	.globl _hsv_to_rgb_into
                                    257 ;--------------------------------------------------------
                                    258 ; special function registers
                                    259 ;--------------------------------------------------------
                                    260 	.area RSEG    (ABS,DATA)
      000000                        261 	.org 0x0000
                           0000D0   262 _PSW	=	0x00d0
                           0000E0   263 _ACC	=	0x00e0
                           0000F0   264 _B	=	0x00f0
                           0000FD   265 _A_INV	=	0x00fd
                           000081   266 _SP	=	0x0081
                           000082   267 _DPL	=	0x0082
                           000083   268 _DPH	=	0x0083
                           0000A1   269 _SAFE_MOD	=	0x00a1
                           0000B1   270 _GLOBAL_CFG	=	0x00b1
                           000087   271 _PCON	=	0x0087
                           0000BA   272 _POWER_CFG	=	0x00ba
                           0000B9   273 _CLOCK_CFG	=	0x00b9
                           0000A9   274 _WAKE_CTRL	=	0x00a9
                           0000FE   275 _RESET_KEEP	=	0x00fe
                           0000FF   276 _WDOG_COUNT	=	0x00ff
                           0000A8   277 _IE	=	0x00a8
                           0000B8   278 _IP	=	0x00b8
                           0000E8   279 _IE_EX	=	0x00e8
                           0000E9   280 _IP_EX	=	0x00e9
                           0000B2   281 _GPIO_IE	=	0x00b2
                           008584   282 _ROM_ADDR	=	0x8584
                           000084   283 _ROM_ADDR_L	=	0x0084
                           000085   284 _ROM_ADDR_H	=	0x0085
                           008F8E   285 _ROM_DATA_HI	=	0x8f8e
                           00008E   286 _ROM_DATA_HL	=	0x008e
                           00008F   287 _ROM_DATA_HH	=	0x008f
                           000086   288 _ROM_CTRL	=	0x0086
                           000080   289 _P0	=	0x0080
                           0000C4   290 _P0_MOD_OC	=	0x00c4
                           0000C5   291 _P0_DIR_PU	=	0x00c5
                           000090   292 _P1	=	0x0090
                           000092   293 _P1_MOD_OC	=	0x0092
                           000093   294 _P1_DIR_PU	=	0x0093
                           0000A0   295 _P2	=	0x00a0
                           000094   296 _P2_MOD_OC	=	0x0094
                           000095   297 _P2_DIR_PU	=	0x0095
                           0000B0   298 _P3	=	0x00b0
                           000096   299 _P3_MOD_OC	=	0x0096
                           000097   300 _P3_DIR_PU	=	0x0097
                           0000C0   301 _P4	=	0x00c0
                           0000C2   302 _P4_MOD_OC	=	0x00c2
                           0000C3   303 _P4_DIR_PU	=	0x00c3
                           0000C1   304 _P4_LED_KEY	=	0x00c1
                           0000AA   305 _P5_IN	=	0x00aa
                           0000AB   306 _P5_OUT_PU	=	0x00ab
                           0000AC   307 _P5_DIR	=	0x00ac
                           0000AD   308 _P6_IN	=	0x00ad
                           0000AE   309 _P6_OUT_PU	=	0x00ae
                           0000AF   310 _P6_DIR	=	0x00af
                           0000F1   311 _P7	=	0x00f1
                           0000A2   312 _XBUS_AUX	=	0x00a2
                           000088   313 _TCON	=	0x0088
                           000089   314 _TMOD	=	0x0089
                           00008A   315 _TL0	=	0x008a
                           00008B   316 _TL1	=	0x008b
                           00008C   317 _TH0	=	0x008c
                           00008D   318 _TH1	=	0x008d
                           000098   319 _SCON	=	0x0098
                           000099   320 _SBUF	=	0x0099
                           0000C8   321 _T2CON	=	0x00c8
                           0000C9   322 _T2MOD	=	0x00c9
                           00CBCA   323 _RCAP2	=	0xcbca
                           0000CA   324 _RCAP2L	=	0x00ca
                           0000CB   325 _RCAP2H	=	0x00cb
                           00CDCC   326 _T2COUNT	=	0xcdcc
                           0000CC   327 _TL2	=	0x00cc
                           0000CD   328 _TH2	=	0x00cd
                           00CFCE   329 _T2CAP1	=	0xcfce
                           0000CE   330 _T2CAP1L	=	0x00ce
                           0000CF   331 _T2CAP1H	=	0x00cf
                           0000F8   332 _SPI0_STAT	=	0x00f8
                           0000F9   333 _SPI0_DATA	=	0x00f9
                           0000FA   334 _SPI0_CTRL	=	0x00fa
                           0000FB   335 _SPI0_CK_SE	=	0x00fb
                           0000FC   336 _SPI0_SETUP	=	0x00fc
                           0000BC   337 _SCON1	=	0x00bc
                           0000BD   338 _SBUF1	=	0x00bd
                           0000BE   339 _SBAUD1	=	0x00be
                           0000BF   340 _SIF1	=	0x00bf
                           0000B4   341 _SPI1_STAT	=	0x00b4
                           0000B5   342 _SPI1_DATA	=	0x00b5
                           0000B6   343 _SPI1_CTRL	=	0x00b6
                           0000B7   344 _SPI1_CK_SE	=	0x00b7
                           0000F3   345 _ADC_CTRL	=	0x00f3
                           00F5F4   346 _ADC_DAT	=	0xf5f4
                           0000F4   347 _ADC_DAT_L	=	0x00f4
                           0000F5   348 _ADC_DAT_H	=	0x00f5
                           0000F6   349 _ADC_CHAN	=	0x00f6
                           0000A6   350 _LED_COMMON	=	0x00a6
                           0000A7   351 _LED_PWM_OE	=	0x00a7
                           00C7C6   352 _LED_DMA	=	0xc7c6
                           0000C6   353 _LED_DMA_L	=	0x00c6
                           0000C7   354 _LED_DMA_H	=	0x00c7
                           0000F7   355 _LED_STATUS	=	0x00f7
                           0000B3   356 _I2CX_INT	=	0x00b3
                           0000BB   357 _I2CS_INT_ST	=	0x00bb
                                    358 ;--------------------------------------------------------
                                    359 ; special function bits
                                    360 ;--------------------------------------------------------
                                    361 	.area RSEG    (ABS,DATA)
      000000                        362 	.org 0x0000
                           0000D7   363 _CY	=	0x00d7
                           0000D6   364 _AC	=	0x00d6
                           0000D5   365 _F0	=	0x00d5
                           0000D4   366 _RS1	=	0x00d4
                           0000D3   367 _RS0	=	0x00d3
                           0000D2   368 _OV	=	0x00d2
                           0000D1   369 _F1	=	0x00d1
                           0000D0   370 _P	=	0x00d0
                           0000AF   371 _EA	=	0x00af
                           0000AE   372 _E_DIS	=	0x00ae
                           0000AD   373 _ET2	=	0x00ad
                           0000AC   374 _ES	=	0x00ac
                           0000AB   375 _ET1	=	0x00ab
                           0000AA   376 _EX1	=	0x00aa
                           0000A9   377 _ET0	=	0x00a9
                           0000A8   378 _EX0	=	0x00a8
                           0000BF   379 _PH_FLAG	=	0x00bf
                           0000BE   380 _PL_FLAG	=	0x00be
                           0000BD   381 _PT2	=	0x00bd
                           0000BC   382 _PS	=	0x00bc
                           0000BB   383 _PT1	=	0x00bb
                           0000BA   384 _PX1	=	0x00ba
                           0000B9   385 _PT0	=	0x00b9
                           0000B8   386 _PX0	=	0x00b8
                           0000EF   387 _IE_WDOG	=	0x00ef
                           0000EE   388 _IE_GPIO	=	0x00ee
                           0000ED   389 _IE_PWM_I2C	=	0x00ed
                           0000EC   390 _IE_UART1	=	0x00ec
                           0000EB   391 _IE_ADC	=	0x00eb
                           0000E9   392 _IE_USB	=	0x00e9
                           0000E8   393 _IE_SPI0	=	0x00e8
                           000087   394 _P0_7	=	0x0087
                           000086   395 _P0_6	=	0x0086
                           000085   396 _P0_5	=	0x0085
                           000084   397 _P0_4	=	0x0084
                           000083   398 _P0_3	=	0x0083
                           000082   399 _P0_2	=	0x0082
                           000081   400 _P0_1	=	0x0081
                           000080   401 _P0_0	=	0x0080
                           000081   402 _SDA0	=	0x0081
                           000080   403 _SCL0	=	0x0080
                           000083   404 _TXD_	=	0x0083
                           000082   405 _RXD_	=	0x0082
                           000085   406 _AIN13	=	0x0085
                           000084   407 _AIN12	=	0x0084
                           000083   408 _AIN11	=	0x0083
                           000082   409 _AIN10	=	0x0082
                           000081   410 _AIN9	=	0x0081
                           000080   411 _AIN8	=	0x0080
                           000097   412 _P1_7	=	0x0097
                           000096   413 _P1_6	=	0x0096
                           000095   414 _P1_5	=	0x0095
                           000094   415 _P1_4	=	0x0094
                           000093   416 _P1_3	=	0x0093
                           000092   417 _P1_2	=	0x0092
                           000091   418 _P1_1	=	0x0091
                           000090   419 _P1_0	=	0x0090
                           000097   420 _TXD1_	=	0x0097
                           000096   421 _RXD1_	=	0x0096
                           000097   422 _SCK	=	0x0097
                           000096   423 _MISO	=	0x0096
                           000095   424 _MOSI	=	0x0095
                           000094   425 _SCS	=	0x0094
                           000092   426 _INT0_	=	0x0092
                           000091   427 _T2EX	=	0x0091
                           000091   428 _CAP2	=	0x0091
                           000090   429 _T2	=	0x0090
                           000090   430 _CAP1	=	0x0090
                           000097   431 _AIN7	=	0x0097
                           000096   432 _AIN6	=	0x0096
                           000095   433 _AIN5	=	0x0095
                           000094   434 _AIN4	=	0x0094
                           000093   435 _AIN3	=	0x0093
                           000092   436 _AIN2	=	0x0092
                           000091   437 _AIN1	=	0x0091
                           000090   438 _AIN0	=	0x0090
                           0000A7   439 _P2_7	=	0x00a7
                           0000A6   440 _P2_6	=	0x00a6
                           0000A5   441 _P2_5	=	0x00a5
                           0000A4   442 _P2_4	=	0x00a4
                           0000A3   443 _P2_3	=	0x00a3
                           0000A2   444 _P2_2	=	0x00a2
                           0000A1   445 _P2_1	=	0x00a1
                           0000A0   446 _P2_0	=	0x00a0
                           0000A7   447 _TXD1	=	0x00a7
                           0000A6   448 _RXD1	=	0x00a6
                           0000A5   449 _T2EX_	=	0x00a5
                           0000A5   450 _CAP2_	=	0x00a5
                           0000A4   451 _T2_	=	0x00a4
                           0000A4   452 _CAP1_	=	0x00a4
                           0000B7   453 _P3_7	=	0x00b7
                           0000B6   454 _P3_6	=	0x00b6
                           0000B5   455 _P3_5	=	0x00b5
                           0000B4   456 _P3_4	=	0x00b4
                           0000B3   457 _P3_3	=	0x00b3
                           0000B2   458 _P3_2	=	0x00b2
                           0000B1   459 _P3_1	=	0x00b1
                           0000B0   460 _P3_0	=	0x00b0
                           0000B7   461 _SCK1	=	0x00b7
                           0000B6   462 _MISO1	=	0x00b6
                           0000B5   463 _MOSI1	=	0x00b5
                           0000B5   464 _T1	=	0x00b5
                           0000B4   465 _T0	=	0x00b4
                           0000B3   466 _INT1	=	0x00b3
                           0000B2   467 _INT0	=	0x00b2
                           0000B1   468 _TXD	=	0x00b1
                           0000B0   469 _RXD	=	0x00b0
                           0000C6   470 _P4_6	=	0x00c6
                           0000C5   471 _P4_5	=	0x00c5
                           0000C4   472 _P4_4	=	0x00c4
                           0000C3   473 _P4_3	=	0x00c3
                           0000C2   474 _P4_2	=	0x00c2
                           0000C1   475 _P4_1	=	0x00c1
                           0000C0   476 _P4_0	=	0x00c0
                           00008F   477 _TF1	=	0x008f
                           00008E   478 _TR1	=	0x008e
                           00008D   479 _TF0	=	0x008d
                           00008C   480 _TR0	=	0x008c
                           00008B   481 _IE1	=	0x008b
                           00008A   482 _IT1	=	0x008a
                           000089   483 _IE0	=	0x0089
                           000088   484 _IT0	=	0x0088
                           00009F   485 _SM0	=	0x009f
                           00009E   486 _SM1	=	0x009e
                           00009D   487 _SM2	=	0x009d
                           00009C   488 _REN	=	0x009c
                           00009B   489 _TB8	=	0x009b
                           00009A   490 _RB8	=	0x009a
                           000099   491 _TI	=	0x0099
                           000098   492 _RI	=	0x0098
                           0000CF   493 _TF2	=	0x00cf
                           0000CF   494 _CAP1F	=	0x00cf
                           0000CE   495 _EXF2	=	0x00ce
                           0000CD   496 _RCLK	=	0x00cd
                           0000CC   497 _TCLK	=	0x00cc
                           0000CB   498 _EXEN2	=	0x00cb
                           0000CA   499 _TR2	=	0x00ca
                           0000C9   500 _C_T2	=	0x00c9
                           0000C8   501 _CP_RL2	=	0x00c8
                           0000FF   502 _S0_FST_ACT	=	0x00ff
                           0000FE   503 _S0_IF_OV	=	0x00fe
                           0000FD   504 _S0_IF_FIRST	=	0x00fd
                           0000FC   505 _S0_IF_BYTE	=	0x00fc
                           0000FB   506 _S0_FREE	=	0x00fb
                           0000FA   507 _S0_T_FIFO	=	0x00fa
                           0000F8   508 _S0_R_FIFO	=	0x00f8
                           0000F7   509 _ADC_START	=	0x00f7
                                    510 ;--------------------------------------------------------
                                    511 ; overlayable register banks
                                    512 ;--------------------------------------------------------
                                    513 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        514 	.ds 8
                                    515 ;--------------------------------------------------------
                                    516 ; internal ram data
                                    517 ;--------------------------------------------------------
                                    518 	.area DSEG    (DATA)
                                    519 ;--------------------------------------------------------
                                    520 ; overlayable items in internal ram
                                    521 ;--------------------------------------------------------
                                    522 ;--------------------------------------------------------
                                    523 ; indirectly addressable internal ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area ISEG    (DATA)
                                    526 ;--------------------------------------------------------
                                    527 ; absolute internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area IABS    (ABS,DATA)
                                    530 	.area IABS    (ABS,DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; bit data
                                    533 ;--------------------------------------------------------
                                    534 	.area BSEG    (BIT)
                                    535 ;--------------------------------------------------------
                                    536 ; paged external ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area PSEG    (PAG,XDATA)
                                    539 ;--------------------------------------------------------
                                    540 ; uninitialized external ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area XSEG    (XDATA)
      000B51                        543 _mulhi8_PARM_2:
      000B51                        544 	.ds 1
      000B52                        545 _hsv_to_rgb_into_PARM_1:
      000B52                        546 	.ds 3
      000B55                        547 _hsv_to_rgb_into_PARM_3:
      000B55                        548 	.ds 2
      000B57                        549 _hsv_to_rgb_into_use_cie_10000_55:
      000B57                        550 	.ds 1
      000B58                        551 _hsv_to_rgb_into_rgb_10000_56:
      000B58                        552 	.ds 3
      000B5B                        553 _hsv_to_rgb_into_v_10000_56:
      000B5B                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; absolute external ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area XABS    (ABS,XDATA)
                                    559 ;--------------------------------------------------------
                                    560 ; initialized external ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area XISEG   (XDATA)
                                    563 	.area HOME    (CODE)
                                    564 	.area GSINIT0 (CODE)
                                    565 	.area GSINIT1 (CODE)
                                    566 	.area GSINIT2 (CODE)
                                    567 	.area GSINIT3 (CODE)
                                    568 	.area GSINIT4 (CODE)
                                    569 	.area GSINIT5 (CODE)
                                    570 	.area GSINIT  (CODE)
                                    571 	.area GSFINAL (CODE)
                                    572 	.area CSEG    (CODE)
                                    573 ;--------------------------------------------------------
                                    574 ; global & static initialisations
                                    575 ;--------------------------------------------------------
                                    576 	.area HOME    (CODE)
                                    577 	.area GSINIT  (CODE)
                                    578 	.area GSFINAL (CODE)
                                    579 	.area GSINIT  (CODE)
                                    580 ;--------------------------------------------------------
                                    581 ; Home
                                    582 ;--------------------------------------------------------
                                    583 	.area HOME    (CODE)
                                    584 	.area HOME    (CODE)
                                    585 ;--------------------------------------------------------
                                    586 ; code
                                    587 ;--------------------------------------------------------
                                    588 	.area CSEG    (CODE)
                                    589 ;------------------------------------------------------------
                                    590 ;Allocation info for local variables in function 'mulhi8'
                                    591 ;------------------------------------------------------------
                                    592 ;y             Allocated with name '_mulhi8_PARM_2'
                                    593 ;x             Allocated with name '_mulhi8_x_10000_53'
                                    594 ;------------------------------------------------------------
                                    595 ;	quantum/color.c:31: static uint8_t mulhi8(uint8_t x, uint8_t y) __naked {
                                    596 ;	-----------------------------------------
                                    597 ;	 function mulhi8
                                    598 ;	-----------------------------------------
      0088C1                        599 _mulhi8:
                                    600 ;	naked function: no prologue.
                                    601 ;	quantum/color.c:40: __endasm;
      0088C1 85 82 F0         [24]  602 	mov b,dpl
      0088C4 90 0B 51         [24]  603 	mov dptr,#_mulhi8_PARM_2
      0088C7 E0               [24]  604 	movx a,@dptr
      0088C8 A4               [48]  605 	mul ab
      0088C9 85 F0 82         [24]  606 	mov dpl,b
      0088CC 22               [24]  607 	ret
                                    608 ;	quantum/color.c:41: }
                                    609 ;	naked function: no epilogue.
                                    610 ;------------------------------------------------------------
                                    611 ;Allocation info for local variables in function 'hsv_to_rgb_into'
                                    612 ;------------------------------------------------------------
                                    613 ;hsv           Allocated with name '_hsv_to_rgb_into_PARM_1'
                                    614 ;output        Allocated with name '_hsv_to_rgb_into_PARM_3'
                                    615 ;use_cie       Allocated with name '_hsv_to_rgb_into_use_cie_10000_55'
                                    616 ;rgb           Allocated with name '_hsv_to_rgb_into_rgb_10000_56'
                                    617 ;region        Allocated with name '_hsv_to_rgb_into_region_10000_56'
                                    618 ;remainder     Allocated with name '_hsv_to_rgb_into_remainder_10000_56'
                                    619 ;p             Allocated with name '_hsv_to_rgb_into_p_10000_56'
                                    620 ;q             Allocated with name '_hsv_to_rgb_into_q_10000_56'
                                    621 ;t             Allocated with name '_hsv_to_rgb_into_t_10000_56'
                                    622 ;h             Allocated with name '_hsv_to_rgb_into_h_10000_56'
                                    623 ;s             Allocated with name '_hsv_to_rgb_into_s_10000_56'
                                    624 ;v             Allocated with name '_hsv_to_rgb_into_v_10000_56'
                                    625 ;scaled        Allocated with name '_hsv_to_rgb_into_scaled_10001_65'
                                    626 ;------------------------------------------------------------
                                    627 ;	quantum/color.c:49: void hsv_to_rgb_into(HSV hsv, bool use_cie, RGB __xdata *output) {
                                    628 ;	-----------------------------------------
                                    629 ;	 function hsv_to_rgb_into
                                    630 ;	-----------------------------------------
      0088CD                        631 _hsv_to_rgb_into:
                           000007   632 	ar7 = 0x07
                           000006   633 	ar6 = 0x06
                           000005   634 	ar5 = 0x05
                           000004   635 	ar4 = 0x04
                           000003   636 	ar3 = 0x03
                           000002   637 	ar2 = 0x02
                           000001   638 	ar1 = 0x01
                           000000   639 	ar0 = 0x00
      0088CD E5 82            [12]  640 	mov	a,dpl
      0088CF 90 0B 57         [24]  641 	mov	dptr,#_hsv_to_rgb_into_use_cie_10000_55
      0088D2 F0               [24]  642 	movx	@dptr,a
                                    643 ;	quantum/color.c:57: if (hsv.s == 0) {
      0088D3 90 0B 53         [24]  644 	mov	dptr,#(_hsv_to_rgb_into_PARM_1 + 0x0001)
      0088D6 E0               [24]  645 	movx	a,@dptr
      0088D7 FF               [12]  646 	mov	r7,a
      0088D8 70 45            [24]  647 	jnz	00105$
                                    648 ;	quantum/color.c:59: if (use_cie) {
      0088DA 90 0B 57         [24]  649 	mov	dptr,#_hsv_to_rgb_into_use_cie_10000_55
      0088DD E0               [24]  650 	movx	a,@dptr
      0088DE 60 14            [24]  651 	jz	00102$
                                    652 ;	quantum/color.c:60: rgb.r = rgb.g = rgb.b = pgm_read_byte(&CIE1931_CURVE[CIE_INDEX(hsv.v)]);
      0088E0 12 8A 40         [24]  653 	lcall	_ak820_outline_0103
      0088E3 FE               [12]  654 	mov	r6,a
      0088E4 90 0B 5A         [24]  655 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0002)
      0088E7 F0               [24]  656 	movx	@dptr,a
      0088E8 90 0B 58         [24]  657 	mov	dptr,#_hsv_to_rgb_into_rgb_10000_56
      0088EB EE               [12]  658 	mov	a,r6
      0088EC F0               [24]  659 	movx	@dptr,a
      0088ED 90 0B 59         [24]  660 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0001)
      0088F0 EE               [12]  661 	mov	a,r6
      0088F1 F0               [24]  662 	movx	@dptr,a
      0088F2 80 18            [24]  663 	sjmp	00103$
      0088F4                        664 00102$:
                                    665 ;	quantum/color.c:62: rgb.r = hsv.v;
      0088F4 90 0B 54         [24]  666 	mov	dptr,#(_hsv_to_rgb_into_PARM_1 + 0x0002)
      0088F7 E0               [24]  667 	movx	a,@dptr
      0088F8 90 0B 59         [24]  668 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0001)
      0088FB F0               [24]  669 	movx	@dptr,a
                                    670 ;	quantum/color.c:63: rgb.g = hsv.v;
      0088FC 90 0B 54         [24]  671 	mov	dptr,#(_hsv_to_rgb_into_PARM_1 + 0x0002)
      0088FF E0               [24]  672 	movx	a,@dptr
      008900 90 0B 58         [24]  673 	mov	dptr,#_hsv_to_rgb_into_rgb_10000_56
      008903 F0               [24]  674 	movx	@dptr,a
                                    675 ;	quantum/color.c:64: rgb.b = hsv.v;
      008904 90 0B 54         [24]  676 	mov	dptr,#(_hsv_to_rgb_into_PARM_1 + 0x0002)
      008907 E0               [24]  677 	movx	a,@dptr
      008908 90 0B 5A         [24]  678 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0002)
      00890B F0               [24]  679 	movx	@dptr,a
      00890C                        680 00103$:
                                    681 ;	quantum/color.c:72: *output = rgb;
      00890C 90 0B 55         [24]  682 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      00890F 12 38 50         [24]  683 	lcall	_ak820_outline_0065
      008912 7E 00            [12]  684 	mov	r6,#0x00
      008914 12 8A 2A         [24]  685 	lcall	_ak820_outline_0042
      008917 12 38 7A         [24]  686 	lcall	_ak820_outline_0109
      00891A 8E F0            [24]  687 	mov	b, r6
                                    688 ;	quantum/color.c:73: return;
      00891C 02 C1 65         [24]  689 	ljmp	___memcpy
      00891F                        690 00105$:
                                    691 ;	quantum/color.c:79: h = hsv.h;
      00891F 90 0B 52         [24]  692 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      008922 E0               [24]  693 	movx	a,@dptr
      008923 FE               [12]  694 	mov	r6,a
                                    695 ;	quantum/color.c:82: if (use_cie) {
      008924 90 0B 57         [24]  696 	mov	dptr,#_hsv_to_rgb_into_use_cie_10000_55
      008927 E0               [24]  697 	movx	a,@dptr
      008928 60 09            [24]  698 	jz	00107$
                                    699 ;	quantum/color.c:83: v = pgm_read_byte(&CIE1931_CURVE[CIE_INDEX(hsv.v)]);
      00892A 12 8A 40         [24]  700 	lcall	_ak820_outline_0103
      00892D 90 0B 5B         [24]  701 	mov	dptr,#_hsv_to_rgb_into_v_10000_56
      008930 F0               [24]  702 	movx	@dptr,a
      008931 80 08            [24]  703 	sjmp	00108$
      008933                        704 00107$:
                                    705 ;	quantum/color.c:85: v = hsv.v;
      008933 90 0B 54         [24]  706 	mov	dptr,#(_hsv_to_rgb_into_PARM_1 + 0x0002)
      008936 E0               [24]  707 	movx	a,@dptr
      008937 90 0B 5B         [24]  708 	mov	dptr,#_hsv_to_rgb_into_v_10000_56
      00893A F0               [24]  709 	movx	@dptr,a
      00893B                        710 00108$:
                                    711 ;	quantum/color.c:91: uint16_t scaled = (uint16_t)h * 6;
      00893B 8E 05            [24]  712 	mov	ar5,r6
      00893D ED               [12]  713 	mov	a,r5
      00893E 75 F0 06         [24]  714 	mov	b,#0x06
      008941 A4               [48]  715 	mul	ab
      008942 FD               [12]  716 	mov	r5,a
      008943 AC F0            [24]  717 	mov	r4,b
                                    718 ;	quantum/color.c:92: region = (scaled + 1 + (scaled >> 8)) >> 8;
      008945 8D 02            [24]  719 	mov	ar2,r5
      008947 8C 03            [24]  720 	mov	ar3,r4
      008949 0A               [12]  721 	inc	r2
      00894A BA 00 01         [24]  722 	cjne	r2,#0x00,00150$
      00894D 0B               [12]  723 	inc	r3
      00894E                        724 00150$:
      00894E 8C 05            [24]  725 	mov	ar5,r4
      008950 7C 00            [12]  726 	mov	r4,#0x00
      008952 ED               [12]  727 	mov	a,r5
      008953 2A               [12]  728 	add	a, r2
      008954 EC               [12]  729 	mov	a,r4
      008955 3B               [12]  730 	addc	a, r3
      008956 FD               [12]  731 	mov	r5,a
                                    732 ;	quantum/color.c:93: remainder = (h * 2 - region * 85) * 3;
      008957 EE               [12]  733 	mov	a,r6
      008958 2E               [12]  734 	add	a,r6
      008959 FE               [12]  735 	mov	r6,a
      00895A 8D 04            [24]  736 	mov	ar4,r5
      00895C EC               [12]  737 	mov	a,r4
      00895D 75 F0 55         [24]  738 	mov	b,#0x55
      008960 A4               [48]  739 	mul	ab
      008961 D3               [12]  740 	setb	c
      008962 9E               [12]  741 	subb	a,r6
      008963 F4               [12]  742 	cpl	a
      008964 75 F0 03         [24]  743 	mov	b,#0x03
      008967 A4               [48]  744 	mul	ab
      008968 FE               [12]  745 	mov	r6,a
                                    746 ;	quantum/color.c:95: p = mulhi8(v, 255 - s);
      008969 90 0B 5B         [24]  747 	mov	dptr,#_hsv_to_rgb_into_v_10000_56
      00896C E0               [24]  748 	movx	a,@dptr
      00896D FC               [12]  749 	mov	r4,a
      00896E 8F 03            [24]  750 	mov	ar3,r7
      008970 12 8A 4D         [24]  751 	lcall	_ak820_outline_0122
      008973 9B               [12]  752 	subb	a,r3
      008974 F0               [24]  753 	movx	@dptr,a
      008975 8C 82            [24]  754 	mov	dpl, r4
      008977 12 88 C1         [24]  755 	lcall	_mulhi8
      00897A AB 82            [24]  756 	mov	r3, dpl
                                    757 ;	quantum/color.c:96: q = mulhi8(v, 255 - mulhi8(s, remainder));
      00897C 90 0B 51         [24]  758 	mov	dptr,#_mulhi8_PARM_2
      00897F EE               [12]  759 	mov	a,r6
      008980 F0               [24]  760 	movx	@dptr,a
      008981 8F 82            [24]  761 	mov	dpl, r7
      008983 12 88 C1         [24]  762 	lcall	_mulhi8
      008986 AA 82            [24]  763 	mov	r2, dpl
      008988 12 8A 4D         [24]  764 	lcall	_ak820_outline_0122
      00898B 9A               [12]  765 	subb	a,r2
      00898C F0               [24]  766 	movx	@dptr,a
      00898D 8C 82            [24]  767 	mov	dpl, r4
      00898F 12 88 C1         [24]  768 	lcall	_mulhi8
      008992 AA 82            [24]  769 	mov	r2, dpl
                                    770 ;	quantum/color.c:97: t = mulhi8(v, 255 - mulhi8(s, 255 - remainder));
      008994 12 8A 4D         [24]  771 	lcall	_ak820_outline_0122
      008997 9E               [12]  772 	subb	a,r6
      008998 F0               [24]  773 	movx	@dptr,a
      008999 8F 82            [24]  774 	mov	dpl, r7
      00899B 12 88 C1         [24]  775 	lcall	_mulhi8
      00899E AF 82            [24]  776 	mov	r7, dpl
      0089A0 12 8A 4D         [24]  777 	lcall	_ak820_outline_0122
      0089A3 9F               [12]  778 	subb	a,r7
      0089A4 F0               [24]  779 	movx	@dptr,a
      0089A5 8C 82            [24]  780 	mov	dpl, r4
      0089A7 12 88 C1         [24]  781 	lcall	_mulhi8
      0089AA AF 82            [24]  782 	mov	r7, dpl
                                    783 ;	quantum/color.c:99: switch (region) {
      0089AC ED               [12]  784 	mov	a,r5
      0089AD 24 F9            [12]  785 	add	a,#0xff - 0x06
      0089AF 40 5C            [24]  786 	jc	00115$
                                    787 ;	free result
      0089B1 ED               [12]  788 	mov	a,r5
      0089B2 2D               [12]  789 	add	a,r5
      0089B3 2D               [12]  790 	add	a,r5
      0089B4 90 89 B8         [24]  791 	mov	dptr,#00152$
      0089B7 73               [24]  792 	jmp	@a+dptr
      0089B8                        793 00152$:
      0089B8 02 89 CA         [24]  794 	ljmp	00110$
      0089BB 02 89 DB         [24]  795 	ljmp	00111$
      0089BE 02 89 E6         [24]  796 	ljmp	00112$
      0089C1 02 89 F1         [24]  797 	ljmp	00113$
      0089C4 02 8A 02         [24]  798 	ljmp	00114$
      0089C7 02 8A 0D         [24]  799 	ljmp	00115$
                                    800 ;	quantum/color.c:101: case 0:
      0089CA                        801 00110$:
                                    802 ;	quantum/color.c:102: rgb.r = v;
      0089CA 90 0B 59         [24]  803 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0001)
      0089CD EC               [12]  804 	mov	a,r4
      0089CE F0               [24]  805 	movx	@dptr,a
                                    806 ;	quantum/color.c:103: rgb.g = t;
      0089CF 90 0B 58         [24]  807 	mov	dptr,#_hsv_to_rgb_into_rgb_10000_56
      0089D2 EF               [12]  808 	mov	a,r7
      0089D3 F0               [24]  809 	movx	@dptr,a
                                    810 ;	quantum/color.c:104: rgb.b = p;
      0089D4 90 0B 5A         [24]  811 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0002)
      0089D7 EB               [12]  812 	mov	a,r3
      0089D8 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/color.c:105: break;
                                    815 ;	quantum/color.c:106: case 1:
      0089D9 80 3E            [24]  816 	sjmp	00116$
      0089DB                        817 00111$:
                                    818 ;	quantum/color.c:107: rgb.r = q;
      0089DB 90 0B 59         [24]  819 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0001)
      0089DE EA               [12]  820 	mov	a,r2
      0089DF 12 8A 5E         [24]  821 	lcall	_ak820_outline_0159
                                    822 ;	quantum/color.c:108: rgb.g = v;
                                    823 ;	quantum/color.c:109: rgb.b = p;
      0089E2 EB               [12]  824 	mov	a,r3
      0089E3 F0               [24]  825 	movx	@dptr,a
                                    826 ;	quantum/color.c:110: break;
                                    827 ;	quantum/color.c:111: case 2:
      0089E4 80 33            [24]  828 	sjmp	00116$
      0089E6                        829 00112$:
                                    830 ;	quantum/color.c:112: rgb.r = p;
      0089E6 90 0B 59         [24]  831 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0001)
      0089E9 EB               [12]  832 	mov	a,r3
      0089EA 12 8A 5E         [24]  833 	lcall	_ak820_outline_0159
                                    834 ;	quantum/color.c:113: rgb.g = v;
                                    835 ;	quantum/color.c:114: rgb.b = t;
      0089ED EF               [12]  836 	mov	a,r7
      0089EE F0               [24]  837 	movx	@dptr,a
                                    838 ;	quantum/color.c:115: break;
                                    839 ;	quantum/color.c:116: case 3:
      0089EF 80 28            [24]  840 	sjmp	00116$
      0089F1                        841 00113$:
                                    842 ;	quantum/color.c:117: rgb.r = p;
      0089F1 90 0B 59         [24]  843 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0001)
      0089F4 EB               [12]  844 	mov	a,r3
      0089F5 F0               [24]  845 	movx	@dptr,a
                                    846 ;	quantum/color.c:118: rgb.g = q;
      0089F6 90 0B 58         [24]  847 	mov	dptr,#_hsv_to_rgb_into_rgb_10000_56
      0089F9 EA               [12]  848 	mov	a,r2
      0089FA F0               [24]  849 	movx	@dptr,a
                                    850 ;	quantum/color.c:119: rgb.b = v;
      0089FB 90 0B 5A         [24]  851 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0002)
      0089FE EC               [12]  852 	mov	a,r4
      0089FF F0               [24]  853 	movx	@dptr,a
                                    854 ;	quantum/color.c:120: break;
                                    855 ;	quantum/color.c:121: case 4:
      008A00 80 17            [24]  856 	sjmp	00116$
      008A02                        857 00114$:
                                    858 ;	quantum/color.c:122: rgb.r = t;
      008A02 90 0B 59         [24]  859 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0001)
      008A05 EF               [12]  860 	mov	a,r7
      008A06 12 8A 54         [24]  861 	lcall	_ak820_outline_0158
                                    862 ;	quantum/color.c:123: rgb.g = p;
                                    863 ;	quantum/color.c:124: rgb.b = v;
      008A09 EC               [12]  864 	mov	a,r4
      008A0A F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/color.c:125: break;
                                    867 ;	quantum/color.c:126: default:
      008A0B 80 0C            [24]  868 	sjmp	00116$
      008A0D                        869 00115$:
                                    870 ;	quantum/color.c:127: rgb.r = v;
      008A0D 90 0B 5B         [24]  871 	mov	dptr,#_hsv_to_rgb_into_v_10000_56
      008A10 E0               [24]  872 	movx	a,@dptr
      008A11 90 0B 59         [24]  873 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56 + 0x0001)
      008A14 12 8A 54         [24]  874 	lcall	_ak820_outline_0158
                                    875 ;	quantum/color.c:128: rgb.g = p;
                                    876 ;	quantum/color.c:129: rgb.b = q;
      008A17 EA               [12]  877 	mov	a,r2
      008A18 F0               [24]  878 	movx	@dptr,a
                                    879 ;	quantum/color.c:131: }
      008A19                        880 00116$:
                                    881 ;	quantum/color.c:134: *output = rgb;
      008A19 90 0B 55         [24]  882 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      008A1C 12 38 62         [24]  883 	lcall	_ak820_outline_0085
      008A1F 7F 00            [12]  884 	mov	r7,#0x00
      008A21 12 8A 2A         [24]  885 	lcall	_ak820_outline_0042
      008A24 12 55 B3         [24]  886 	lcall	_ak820_outline_0038
                                    887 ;	quantum/color.c:138: }
      008A27 02 C1 65         [24]  888 	ljmp	___memcpy
                                    889 ;------------------------------------------------------------
                                    890 ;Allocation info for local variables in function 'hsv_to_rgb_impl'
                                    891 ;------------------------------------------------------------
                                    892 ;hsv           Allocated with name '_hsv_to_rgb_impl_PARM_1'
                                    893 ;use_cie       Allocated with name '_hsv_to_rgb_impl_PARM_2'
                                    894 ;rgb           Allocated with name '_hsv_to_rgb_impl_rgb_10000_69'
                                    895 ;------------------------------------------------------------
                                    896 ;	quantum/color.c:143: RGB hsv_to_rgb_impl(HSV hsv, bool use_cie) {
                                    897 ;	-----------------------------------------
                                    898 	.area CSEG    (CODE)
                                    899 	.area CONST   (CODE)
                                    900 	.area XINIT   (CODE)
                                    901 	.area CABS    (ABS,CODE)
                                    902 
                                    903 ; Experimental exact instruction outlining.
                                    904 	.globl _ak820_outline_0038
                                    905 	.globl _ak820_outline_0042
                                    906 	.globl _ak820_outline_0065
                                    907 	.globl _ak820_outline_0085
                                    908 	.globl _ak820_outline_0103
                                    909 	.globl _ak820_outline_0109
                                    910 	.globl _ak820_outline_0122
                                    911 	.globl _ak820_outline_0158
                                    912 	.globl _ak820_outline_0159
                                    913 
                                    914 	.area CSEG (CODE)
                                    915 ; function ak820_outline_0042
      008A2A                        916 _ak820_outline_0042:
      008A2A 90 0E 57         [24]  917 	mov	dptr,#___memcpy_PARM_2
      008A2D 74 58            [12]  918 	mov	a,#_hsv_to_rgb_into_rgb_10000_56
      008A2F F0               [24]  919 	movx	@dptr,a
      008A30 74 0B            [12]  920 	mov	a,#(_hsv_to_rgb_into_rgb_10000_56>>8)
      008A32 A3               [24]  921 	inc	dptr
      008A33 F0               [24]  922 	movx	@dptr,a
      008A34 E4               [12]  923 	clr	a
      008A35 A3               [24]  924 	inc	dptr
      008A36 F0               [24]  925 	movx	@dptr,a
      008A37 90 0E 5A         [24]  926 	mov	dptr,#___memcpy_PARM_3
      008A3A 74 03            [12]  927 	mov	a,#0x03
      008A3C F0               [24]  928 	movx	@dptr,a
      008A3D E4               [12]  929 	clr	a
      008A3E A3               [24]  930 	inc	dptr
      008A3F 22               [24]  931 	ret
                                    932 
                                    933 	.area CSEG (CODE)
                                    934 ; function ak820_outline_0103
      008A40                        935 _ak820_outline_0103:
      008A40 90 0B 54         [24]  936 	mov	dptr,#(_hsv_to_rgb_into_PARM_1+0x0002)
      008A43 E0               [24]  937 	movx	a,@dptr
      008A44 C4               [12]  938 	swap	a
      008A45 23               [12]  939 	rl	a
      008A46 54 1F            [12]  940 	anl	a,#0x1f
      008A48 90 C5 CC         [24]  941 	mov	dptr,#_CIE1931_CURVE
      008A4B 93               [24]  942 	movc	a,@a+dptr
      008A4C 22               [24]  943 	ret
                                    944 
                                    945 	.area CSEG (CODE)
                                    946 ; function ak820_outline_0122
      008A4D                        947 _ak820_outline_0122:
      008A4D 90 0B 51         [24]  948 	mov	dptr,#_mulhi8_PARM_2
      008A50 74 FF            [12]  949 	mov	a,#0xff
      008A52 C3               [12]  950 	clr	c
      008A53 22               [24]  951 	ret
                                    952 
                                    953 	.area CSEG (CODE)
                                    954 ; function ak820_outline_0158
      008A54                        955 _ak820_outline_0158:
      008A54 F0               [24]  956 	movx	@dptr,a
      008A55 90 0B 58         [24]  957 	mov	dptr,#_hsv_to_rgb_into_rgb_10000_56
      008A58 EB               [12]  958 	mov	a,r3
      008A59 F0               [24]  959 	movx	@dptr,a
      008A5A 90 0B 5A         [24]  960 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56+0x0002)
      008A5D 22               [24]  961 	ret
                                    962 
                                    963 	.area CSEG (CODE)
                                    964 ; function ak820_outline_0159
      008A5E                        965 _ak820_outline_0159:
      008A5E F0               [24]  966 	movx	@dptr,a
      008A5F 90 0B 58         [24]  967 	mov	dptr,#_hsv_to_rgb_into_rgb_10000_56
      008A62 EC               [12]  968 	mov	a,r4
      008A63 F0               [24]  969 	movx	@dptr,a
      008A64 90 0B 5A         [24]  970 	mov	dptr,#(_hsv_to_rgb_into_rgb_10000_56+0x0002)
      008A67 22               [24]  971 	ret
