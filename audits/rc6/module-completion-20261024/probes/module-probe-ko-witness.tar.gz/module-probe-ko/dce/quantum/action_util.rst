                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_key_override_mods
                                     12 	.globl _ak820_key_override_key
                                     13 	.globl _ak820_key_override_sync
                                     14 	.globl _biton
                                     15 	.globl _host_consumer_send
                                     16 	.globl _host_system_send
                                     17 	.globl _host_keyboard_send
                                     18 	.globl _clear_keys_from_report
                                     19 	.globl _del_key_from_report
                                     20 	.globl _add_key_to_report
                                     21 	.globl _KEYCODE2CONSUMER
                                     22 	.globl _ADC_START
                                     23 	.globl _S0_R_FIFO
                                     24 	.globl _S0_T_FIFO
                                     25 	.globl _S0_FREE
                                     26 	.globl _S0_IF_BYTE
                                     27 	.globl _S0_IF_FIRST
                                     28 	.globl _S0_IF_OV
                                     29 	.globl _S0_FST_ACT
                                     30 	.globl _CP_RL2
                                     31 	.globl _C_T2
                                     32 	.globl _TR2
                                     33 	.globl _EXEN2
                                     34 	.globl _TCLK
                                     35 	.globl _RCLK
                                     36 	.globl _EXF2
                                     37 	.globl _CAP1F
                                     38 	.globl _TF2
                                     39 	.globl _RI
                                     40 	.globl _TI
                                     41 	.globl _RB8
                                     42 	.globl _TB8
                                     43 	.globl _REN
                                     44 	.globl _SM2
                                     45 	.globl _SM1
                                     46 	.globl _SM0
                                     47 	.globl _IT0
                                     48 	.globl _IE0
                                     49 	.globl _IT1
                                     50 	.globl _IE1
                                     51 	.globl _TR0
                                     52 	.globl _TF0
                                     53 	.globl _TR1
                                     54 	.globl _TF1
                                     55 	.globl _P4_0
                                     56 	.globl _P4_1
                                     57 	.globl _P4_2
                                     58 	.globl _P4_3
                                     59 	.globl _P4_4
                                     60 	.globl _P4_5
                                     61 	.globl _P4_6
                                     62 	.globl _RXD
                                     63 	.globl _TXD
                                     64 	.globl _INT0
                                     65 	.globl _INT1
                                     66 	.globl _T0
                                     67 	.globl _T1
                                     68 	.globl _MOSI1
                                     69 	.globl _MISO1
                                     70 	.globl _SCK1
                                     71 	.globl _P3_0
                                     72 	.globl _P3_1
                                     73 	.globl _P3_2
                                     74 	.globl _P3_3
                                     75 	.globl _P3_4
                                     76 	.globl _P3_5
                                     77 	.globl _P3_6
                                     78 	.globl _P3_7
                                     79 	.globl _CAP1_
                                     80 	.globl _T2_
                                     81 	.globl _CAP2_
                                     82 	.globl _T2EX_
                                     83 	.globl _RXD1
                                     84 	.globl _TXD1
                                     85 	.globl _P2_0
                                     86 	.globl _P2_1
                                     87 	.globl _P2_2
                                     88 	.globl _P2_3
                                     89 	.globl _P2_4
                                     90 	.globl _P2_5
                                     91 	.globl _P2_6
                                     92 	.globl _P2_7
                                     93 	.globl _AIN0
                                     94 	.globl _AIN1
                                     95 	.globl _AIN2
                                     96 	.globl _AIN3
                                     97 	.globl _AIN4
                                     98 	.globl _AIN5
                                     99 	.globl _AIN6
                                    100 	.globl _AIN7
                                    101 	.globl _CAP1
                                    102 	.globl _T2
                                    103 	.globl _CAP2
                                    104 	.globl _T2EX
                                    105 	.globl _INT0_
                                    106 	.globl _SCS
                                    107 	.globl _MOSI
                                    108 	.globl _MISO
                                    109 	.globl _SCK
                                    110 	.globl _RXD1_
                                    111 	.globl _TXD1_
                                    112 	.globl _P1_0
                                    113 	.globl _P1_1
                                    114 	.globl _P1_2
                                    115 	.globl _P1_3
                                    116 	.globl _P1_4
                                    117 	.globl _P1_5
                                    118 	.globl _P1_6
                                    119 	.globl _P1_7
                                    120 	.globl _AIN8
                                    121 	.globl _AIN9
                                    122 	.globl _AIN10
                                    123 	.globl _AIN11
                                    124 	.globl _AIN12
                                    125 	.globl _AIN13
                                    126 	.globl _RXD_
                                    127 	.globl _TXD_
                                    128 	.globl _SCL0
                                    129 	.globl _SDA0
                                    130 	.globl _P0_0
                                    131 	.globl _P0_1
                                    132 	.globl _P0_2
                                    133 	.globl _P0_3
                                    134 	.globl _P0_4
                                    135 	.globl _P0_5
                                    136 	.globl _P0_6
                                    137 	.globl _P0_7
                                    138 	.globl _IE_SPI0
                                    139 	.globl _IE_USB
                                    140 	.globl _IE_ADC
                                    141 	.globl _IE_UART1
                                    142 	.globl _IE_PWM_I2C
                                    143 	.globl _IE_GPIO
                                    144 	.globl _IE_WDOG
                                    145 	.globl _PX0
                                    146 	.globl _PT0
                                    147 	.globl _PX1
                                    148 	.globl _PT1
                                    149 	.globl _PS
                                    150 	.globl _PT2
                                    151 	.globl _PL_FLAG
                                    152 	.globl _PH_FLAG
                                    153 	.globl _EX0
                                    154 	.globl _ET0
                                    155 	.globl _EX1
                                    156 	.globl _ET1
                                    157 	.globl _ES
                                    158 	.globl _ET2
                                    159 	.globl _E_DIS
                                    160 	.globl _EA
                                    161 	.globl _P
                                    162 	.globl _F1
                                    163 	.globl _OV
                                    164 	.globl _RS0
                                    165 	.globl _RS1
                                    166 	.globl _F0
                                    167 	.globl _AC
                                    168 	.globl _CY
                                    169 	.globl _I2CS_INT_ST
                                    170 	.globl _I2CX_INT
                                    171 	.globl _LED_STATUS
                                    172 	.globl _LED_DMA_H
                                    173 	.globl _LED_DMA_L
                                    174 	.globl _LED_DMA
                                    175 	.globl _LED_PWM_OE
                                    176 	.globl _LED_COMMON
                                    177 	.globl _ADC_CHAN
                                    178 	.globl _ADC_DAT_H
                                    179 	.globl _ADC_DAT_L
                                    180 	.globl _ADC_DAT
                                    181 	.globl _ADC_CTRL
                                    182 	.globl _SPI1_CK_SE
                                    183 	.globl _SPI1_CTRL
                                    184 	.globl _SPI1_DATA
                                    185 	.globl _SPI1_STAT
                                    186 	.globl _SIF1
                                    187 	.globl _SBAUD1
                                    188 	.globl _SBUF1
                                    189 	.globl _SCON1
                                    190 	.globl _SPI0_SETUP
                                    191 	.globl _SPI0_CK_SE
                                    192 	.globl _SPI0_CTRL
                                    193 	.globl _SPI0_DATA
                                    194 	.globl _SPI0_STAT
                                    195 	.globl _T2CAP1H
                                    196 	.globl _T2CAP1L
                                    197 	.globl _T2CAP1
                                    198 	.globl _TH2
                                    199 	.globl _TL2
                                    200 	.globl _T2COUNT
                                    201 	.globl _RCAP2H
                                    202 	.globl _RCAP2L
                                    203 	.globl _RCAP2
                                    204 	.globl _T2MOD
                                    205 	.globl _T2CON
                                    206 	.globl _SBUF
                                    207 	.globl _SCON
                                    208 	.globl _TH1
                                    209 	.globl _TH0
                                    210 	.globl _TL1
                                    211 	.globl _TL0
                                    212 	.globl _TMOD
                                    213 	.globl _TCON
                                    214 	.globl _XBUS_AUX
                                    215 	.globl _P7
                                    216 	.globl _P6_DIR
                                    217 	.globl _P6_OUT_PU
                                    218 	.globl _P6_IN
                                    219 	.globl _P5_DIR
                                    220 	.globl _P5_OUT_PU
                                    221 	.globl _P5_IN
                                    222 	.globl _P4_LED_KEY
                                    223 	.globl _P4_DIR_PU
                                    224 	.globl _P4_MOD_OC
                                    225 	.globl _P4
                                    226 	.globl _P3_DIR_PU
                                    227 	.globl _P3_MOD_OC
                                    228 	.globl _P3
                                    229 	.globl _P2_DIR_PU
                                    230 	.globl _P2_MOD_OC
                                    231 	.globl _P2
                                    232 	.globl _P1_DIR_PU
                                    233 	.globl _P1_MOD_OC
                                    234 	.globl _P1
                                    235 	.globl _P0_DIR_PU
                                    236 	.globl _P0_MOD_OC
                                    237 	.globl _P0
                                    238 	.globl _ROM_CTRL
                                    239 	.globl _ROM_DATA_HH
                                    240 	.globl _ROM_DATA_HL
                                    241 	.globl _ROM_DATA_HI
                                    242 	.globl _ROM_ADDR_H
                                    243 	.globl _ROM_ADDR_L
                                    244 	.globl _ROM_ADDR
                                    245 	.globl _GPIO_IE
                                    246 	.globl _IP_EX
                                    247 	.globl _IE_EX
                                    248 	.globl _IP
                                    249 	.globl _IE
                                    250 	.globl _WDOG_COUNT
                                    251 	.globl _RESET_KEEP
                                    252 	.globl _WAKE_CTRL
                                    253 	.globl _CLOCK_CFG
                                    254 	.globl _POWER_CFG
                                    255 	.globl _PCON
                                    256 	.globl _GLOBAL_CFG
                                    257 	.globl _SAFE_MOD
                                    258 	.globl _DPH
                                    259 	.globl _DPL
                                    260 	.globl _SP
                                    261 	.globl _A_INV
                                    262 	.globl _B
                                    263 	.globl _ACC
                                    264 	.globl _PSW
                                    265 	.globl _actual_keyboard_report
                                    266 	.globl _owned_usage_key_PARM_2
                                    267 	.globl _ak820_macro_change_PARM_3
                                    268 	.globl _ak820_macro_change_PARM_2
                                    269 	.globl _ak820_macro_cancelled
                                    270 	.globl _ak820_macro_primitive
                                    271 	.globl _ak820_macro_change
                                    272 	.globl _add_owned_mods
                                    273 	.globl _del_owned_mods
                                    274 	.globl _add_owned_weak_mods
                                    275 	.globl _del_owned_weak_mods
                                    276 	.globl _clear_owned_mods
                                    277 	.globl _clear_owned_keys
                                    278 	.globl _add_owned_key
                                    279 	.globl _del_owned_key
                                    280 	.globl _clear_owned_usages
                                    281 	.globl _owned_usage_key
                                    282 	.globl _send_keyboard_report
                                    283 	.globl _get_mods
                                    284 	.globl _clear_mods
                                    285 	.globl _get_weak_mods
                                    286 	.globl _add_weak_mods
                                    287 	.globl _del_weak_mods
                                    288 	.globl _clear_weak_mods
                                    289 ;--------------------------------------------------------
                                    290 ; special function registers
                                    291 ;--------------------------------------------------------
                                    292 	.area RSEG    (ABS,DATA)
      000000                        293 	.org 0x0000
                           0000D0   294 _PSW	=	0x00d0
                           0000E0   295 _ACC	=	0x00e0
                           0000F0   296 _B	=	0x00f0
                           0000FD   297 _A_INV	=	0x00fd
                           000081   298 _SP	=	0x0081
                           000082   299 _DPL	=	0x0082
                           000083   300 _DPH	=	0x0083
                           0000A1   301 _SAFE_MOD	=	0x00a1
                           0000B1   302 _GLOBAL_CFG	=	0x00b1
                           000087   303 _PCON	=	0x0087
                           0000BA   304 _POWER_CFG	=	0x00ba
                           0000B9   305 _CLOCK_CFG	=	0x00b9
                           0000A9   306 _WAKE_CTRL	=	0x00a9
                           0000FE   307 _RESET_KEEP	=	0x00fe
                           0000FF   308 _WDOG_COUNT	=	0x00ff
                           0000A8   309 _IE	=	0x00a8
                           0000B8   310 _IP	=	0x00b8
                           0000E8   311 _IE_EX	=	0x00e8
                           0000E9   312 _IP_EX	=	0x00e9
                           0000B2   313 _GPIO_IE	=	0x00b2
                           008584   314 _ROM_ADDR	=	0x8584
                           000084   315 _ROM_ADDR_L	=	0x0084
                           000085   316 _ROM_ADDR_H	=	0x0085
                           008F8E   317 _ROM_DATA_HI	=	0x8f8e
                           00008E   318 _ROM_DATA_HL	=	0x008e
                           00008F   319 _ROM_DATA_HH	=	0x008f
                           000086   320 _ROM_CTRL	=	0x0086
                           000080   321 _P0	=	0x0080
                           0000C4   322 _P0_MOD_OC	=	0x00c4
                           0000C5   323 _P0_DIR_PU	=	0x00c5
                           000090   324 _P1	=	0x0090
                           000092   325 _P1_MOD_OC	=	0x0092
                           000093   326 _P1_DIR_PU	=	0x0093
                           0000A0   327 _P2	=	0x00a0
                           000094   328 _P2_MOD_OC	=	0x0094
                           000095   329 _P2_DIR_PU	=	0x0095
                           0000B0   330 _P3	=	0x00b0
                           000096   331 _P3_MOD_OC	=	0x0096
                           000097   332 _P3_DIR_PU	=	0x0097
                           0000C0   333 _P4	=	0x00c0
                           0000C2   334 _P4_MOD_OC	=	0x00c2
                           0000C3   335 _P4_DIR_PU	=	0x00c3
                           0000C1   336 _P4_LED_KEY	=	0x00c1
                           0000AA   337 _P5_IN	=	0x00aa
                           0000AB   338 _P5_OUT_PU	=	0x00ab
                           0000AC   339 _P5_DIR	=	0x00ac
                           0000AD   340 _P6_IN	=	0x00ad
                           0000AE   341 _P6_OUT_PU	=	0x00ae
                           0000AF   342 _P6_DIR	=	0x00af
                           0000F1   343 _P7	=	0x00f1
                           0000A2   344 _XBUS_AUX	=	0x00a2
                           000088   345 _TCON	=	0x0088
                           000089   346 _TMOD	=	0x0089
                           00008A   347 _TL0	=	0x008a
                           00008B   348 _TL1	=	0x008b
                           00008C   349 _TH0	=	0x008c
                           00008D   350 _TH1	=	0x008d
                           000098   351 _SCON	=	0x0098
                           000099   352 _SBUF	=	0x0099
                           0000C8   353 _T2CON	=	0x00c8
                           0000C9   354 _T2MOD	=	0x00c9
                           00CBCA   355 _RCAP2	=	0xcbca
                           0000CA   356 _RCAP2L	=	0x00ca
                           0000CB   357 _RCAP2H	=	0x00cb
                           00CDCC   358 _T2COUNT	=	0xcdcc
                           0000CC   359 _TL2	=	0x00cc
                           0000CD   360 _TH2	=	0x00cd
                           00CFCE   361 _T2CAP1	=	0xcfce
                           0000CE   362 _T2CAP1L	=	0x00ce
                           0000CF   363 _T2CAP1H	=	0x00cf
                           0000F8   364 _SPI0_STAT	=	0x00f8
                           0000F9   365 _SPI0_DATA	=	0x00f9
                           0000FA   366 _SPI0_CTRL	=	0x00fa
                           0000FB   367 _SPI0_CK_SE	=	0x00fb
                           0000FC   368 _SPI0_SETUP	=	0x00fc
                           0000BC   369 _SCON1	=	0x00bc
                           0000BD   370 _SBUF1	=	0x00bd
                           0000BE   371 _SBAUD1	=	0x00be
                           0000BF   372 _SIF1	=	0x00bf
                           0000B4   373 _SPI1_STAT	=	0x00b4
                           0000B5   374 _SPI1_DATA	=	0x00b5
                           0000B6   375 _SPI1_CTRL	=	0x00b6
                           0000B7   376 _SPI1_CK_SE	=	0x00b7
                           0000F3   377 _ADC_CTRL	=	0x00f3
                           00F5F4   378 _ADC_DAT	=	0xf5f4
                           0000F4   379 _ADC_DAT_L	=	0x00f4
                           0000F5   380 _ADC_DAT_H	=	0x00f5
                           0000F6   381 _ADC_CHAN	=	0x00f6
                           0000A6   382 _LED_COMMON	=	0x00a6
                           0000A7   383 _LED_PWM_OE	=	0x00a7
                           00C7C6   384 _LED_DMA	=	0xc7c6
                           0000C6   385 _LED_DMA_L	=	0x00c6
                           0000C7   386 _LED_DMA_H	=	0x00c7
                           0000F7   387 _LED_STATUS	=	0x00f7
                           0000B3   388 _I2CX_INT	=	0x00b3
                           0000BB   389 _I2CS_INT_ST	=	0x00bb
                                    390 ;--------------------------------------------------------
                                    391 ; special function bits
                                    392 ;--------------------------------------------------------
                                    393 	.area RSEG    (ABS,DATA)
      000000                        394 	.org 0x0000
                           0000D7   395 _CY	=	0x00d7
                           0000D6   396 _AC	=	0x00d6
                           0000D5   397 _F0	=	0x00d5
                           0000D4   398 _RS1	=	0x00d4
                           0000D3   399 _RS0	=	0x00d3
                           0000D2   400 _OV	=	0x00d2
                           0000D1   401 _F1	=	0x00d1
                           0000D0   402 _P	=	0x00d0
                           0000AF   403 _EA	=	0x00af
                           0000AE   404 _E_DIS	=	0x00ae
                           0000AD   405 _ET2	=	0x00ad
                           0000AC   406 _ES	=	0x00ac
                           0000AB   407 _ET1	=	0x00ab
                           0000AA   408 _EX1	=	0x00aa
                           0000A9   409 _ET0	=	0x00a9
                           0000A8   410 _EX0	=	0x00a8
                           0000BF   411 _PH_FLAG	=	0x00bf
                           0000BE   412 _PL_FLAG	=	0x00be
                           0000BD   413 _PT2	=	0x00bd
                           0000BC   414 _PS	=	0x00bc
                           0000BB   415 _PT1	=	0x00bb
                           0000BA   416 _PX1	=	0x00ba
                           0000B9   417 _PT0	=	0x00b9
                           0000B8   418 _PX0	=	0x00b8
                           0000EF   419 _IE_WDOG	=	0x00ef
                           0000EE   420 _IE_GPIO	=	0x00ee
                           0000ED   421 _IE_PWM_I2C	=	0x00ed
                           0000EC   422 _IE_UART1	=	0x00ec
                           0000EB   423 _IE_ADC	=	0x00eb
                           0000E9   424 _IE_USB	=	0x00e9
                           0000E8   425 _IE_SPI0	=	0x00e8
                           000087   426 _P0_7	=	0x0087
                           000086   427 _P0_6	=	0x0086
                           000085   428 _P0_5	=	0x0085
                           000084   429 _P0_4	=	0x0084
                           000083   430 _P0_3	=	0x0083
                           000082   431 _P0_2	=	0x0082
                           000081   432 _P0_1	=	0x0081
                           000080   433 _P0_0	=	0x0080
                           000081   434 _SDA0	=	0x0081
                           000080   435 _SCL0	=	0x0080
                           000083   436 _TXD_	=	0x0083
                           000082   437 _RXD_	=	0x0082
                           000085   438 _AIN13	=	0x0085
                           000084   439 _AIN12	=	0x0084
                           000083   440 _AIN11	=	0x0083
                           000082   441 _AIN10	=	0x0082
                           000081   442 _AIN9	=	0x0081
                           000080   443 _AIN8	=	0x0080
                           000097   444 _P1_7	=	0x0097
                           000096   445 _P1_6	=	0x0096
                           000095   446 _P1_5	=	0x0095
                           000094   447 _P1_4	=	0x0094
                           000093   448 _P1_3	=	0x0093
                           000092   449 _P1_2	=	0x0092
                           000091   450 _P1_1	=	0x0091
                           000090   451 _P1_0	=	0x0090
                           000097   452 _TXD1_	=	0x0097
                           000096   453 _RXD1_	=	0x0096
                           000097   454 _SCK	=	0x0097
                           000096   455 _MISO	=	0x0096
                           000095   456 _MOSI	=	0x0095
                           000094   457 _SCS	=	0x0094
                           000092   458 _INT0_	=	0x0092
                           000091   459 _T2EX	=	0x0091
                           000091   460 _CAP2	=	0x0091
                           000090   461 _T2	=	0x0090
                           000090   462 _CAP1	=	0x0090
                           000097   463 _AIN7	=	0x0097
                           000096   464 _AIN6	=	0x0096
                           000095   465 _AIN5	=	0x0095
                           000094   466 _AIN4	=	0x0094
                           000093   467 _AIN3	=	0x0093
                           000092   468 _AIN2	=	0x0092
                           000091   469 _AIN1	=	0x0091
                           000090   470 _AIN0	=	0x0090
                           0000A7   471 _P2_7	=	0x00a7
                           0000A6   472 _P2_6	=	0x00a6
                           0000A5   473 _P2_5	=	0x00a5
                           0000A4   474 _P2_4	=	0x00a4
                           0000A3   475 _P2_3	=	0x00a3
                           0000A2   476 _P2_2	=	0x00a2
                           0000A1   477 _P2_1	=	0x00a1
                           0000A0   478 _P2_0	=	0x00a0
                           0000A7   479 _TXD1	=	0x00a7
                           0000A6   480 _RXD1	=	0x00a6
                           0000A5   481 _T2EX_	=	0x00a5
                           0000A5   482 _CAP2_	=	0x00a5
                           0000A4   483 _T2_	=	0x00a4
                           0000A4   484 _CAP1_	=	0x00a4
                           0000B7   485 _P3_7	=	0x00b7
                           0000B6   486 _P3_6	=	0x00b6
                           0000B5   487 _P3_5	=	0x00b5
                           0000B4   488 _P3_4	=	0x00b4
                           0000B3   489 _P3_3	=	0x00b3
                           0000B2   490 _P3_2	=	0x00b2
                           0000B1   491 _P3_1	=	0x00b1
                           0000B0   492 _P3_0	=	0x00b0
                           0000B7   493 _SCK1	=	0x00b7
                           0000B6   494 _MISO1	=	0x00b6
                           0000B5   495 _MOSI1	=	0x00b5
                           0000B5   496 _T1	=	0x00b5
                           0000B4   497 _T0	=	0x00b4
                           0000B3   498 _INT1	=	0x00b3
                           0000B2   499 _INT0	=	0x00b2
                           0000B1   500 _TXD	=	0x00b1
                           0000B0   501 _RXD	=	0x00b0
                           0000C6   502 _P4_6	=	0x00c6
                           0000C5   503 _P4_5	=	0x00c5
                           0000C4   504 _P4_4	=	0x00c4
                           0000C3   505 _P4_3	=	0x00c3
                           0000C2   506 _P4_2	=	0x00c2
                           0000C1   507 _P4_1	=	0x00c1
                           0000C0   508 _P4_0	=	0x00c0
                           00008F   509 _TF1	=	0x008f
                           00008E   510 _TR1	=	0x008e
                           00008D   511 _TF0	=	0x008d
                           00008C   512 _TR0	=	0x008c
                           00008B   513 _IE1	=	0x008b
                           00008A   514 _IT1	=	0x008a
                           000089   515 _IE0	=	0x0089
                           000088   516 _IT0	=	0x0088
                           00009F   517 _SM0	=	0x009f
                           00009E   518 _SM1	=	0x009e
                           00009D   519 _SM2	=	0x009d
                           00009C   520 _REN	=	0x009c
                           00009B   521 _TB8	=	0x009b
                           00009A   522 _RB8	=	0x009a
                           000099   523 _TI	=	0x0099
                           000098   524 _RI	=	0x0098
                           0000CF   525 _TF2	=	0x00cf
                           0000CF   526 _CAP1F	=	0x00cf
                           0000CE   527 _EXF2	=	0x00ce
                           0000CD   528 _RCLK	=	0x00cd
                           0000CC   529 _TCLK	=	0x00cc
                           0000CB   530 _EXEN2	=	0x00cb
                           0000CA   531 _TR2	=	0x00ca
                           0000C9   532 _C_T2	=	0x00c9
                           0000C8   533 _CP_RL2	=	0x00c8
                           0000FF   534 _S0_FST_ACT	=	0x00ff
                           0000FE   535 _S0_IF_OV	=	0x00fe
                           0000FD   536 _S0_IF_FIRST	=	0x00fd
                           0000FC   537 _S0_IF_BYTE	=	0x00fc
                           0000FB   538 _S0_FREE	=	0x00fb
                           0000FA   539 _S0_T_FIFO	=	0x00fa
                           0000F8   540 _S0_R_FIFO	=	0x00f8
                           0000F7   541 _ADC_START	=	0x00f7
                                    542 ;--------------------------------------------------------
                                    543 ; overlayable register banks
                                    544 ;--------------------------------------------------------
                                    545 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        546 	.ds 8
                                    547 ;--------------------------------------------------------
                                    548 ; internal ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area DSEG    (DATA)
                                    551 ;--------------------------------------------------------
                                    552 ; overlayable items in internal ram
                                    553 ;--------------------------------------------------------
                                    554 	.area	OSEG    (OVR,DATA)
      000064                        555 _change_owned_sloc1_1_0:
      000064                        556 	.ds 1
                                    557 ;--------------------------------------------------------
                                    558 ; indirectly addressable internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area ISEG    (DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; absolute internal ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area IABS    (ABS,DATA)
                                    565 	.area IABS    (ABS,DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; bit data
                                    568 ;--------------------------------------------------------
                                    569 	.area BSEG    (BIT)
      000023                        570 _ak820_macro_change_sloc0_1_0:
      000023                        571 	.ds 1
      000024                        572 _change_owned_sloc0_1_0:
      000024                        573 	.ds 1
      000025                        574 _owned_usage_key_sloc0_1_0:
      000025                        575 	.ds 1
                                    576 ;--------------------------------------------------------
                                    577 ; paged external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area PSEG    (PAG,XDATA)
                                    580 ;--------------------------------------------------------
                                    581 ; uninitialized external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area XSEG    (XDATA)
      0009DD                        584 _owned_mod_refs:
      0009DD                        585 	.ds 8
      0009E5                        586 _owned_weak_refs:
      0009E5                        587 	.ds 8
      0009ED                        588 _owned_mods:
      0009ED                        589 	.ds 1
      0009EE                        590 _owned_weak_mods:
      0009EE                        591 	.ds 1
      0009EF                        592 _macro_mods:
      0009EF                        593 	.ds 2
      0009F1                        594 _ak820_macro_primitive::
      0009F1                        595 	.ds 1
      0009F2                        596 _ak820_macro_cancelled::
      0009F2                        597 	.ds 1
      0009F3                        598 _ak820_macro_change_PARM_2:
      0009F3                        599 	.ds 1
      0009F4                        600 _ak820_macro_change_PARM_3:
      0009F4                        601 	.ds 1
      0009F5                        602 _ak820_macro_change_bits_10000_355:
      0009F5                        603 	.ds 2
      0009F7                        604 _change_owned_PARM_2:
      0009F7                        605 	.ds 1
      0009F8                        606 _change_owned_mods_10000_360:
      0009F8                        607 	.ds 1
      0009F9                        608 _change_owned_result_10001_364:
      0009F9                        609 	.ds 1
      0009FA                        610 _change_owned_bit_20001_365:
      0009FA                        611 	.ds 1
      0009FB                        612 _add_owned_mods_mods_10000_373:
      0009FB                        613 	.ds 1
      0009FC                        614 _del_owned_mods_mods_10000_375:
      0009FC                        615 	.ds 1
      0009FD                        616 _add_owned_weak_mods_mods_10000_377:
      0009FD                        617 	.ds 1
      0009FE                        618 _del_owned_weak_mods_mods_10000_379:
      0009FE                        619 	.ds 1
      0009FF                        620 _key_refs:
      0009FF                        621 	.ds 165
      000AA4                        622 _distinct_keys:
      000AA4                        623 	.ds 1
      000AA5                        624 _macro_keys:
      000AA5                        625 	.ds 21
      000ABA                        626 _add_owned_key_code_10000_388:
      000ABA                        627 	.ds 1
      000ABB                        628 _del_owned_key_code_10000_403:
      000ABB                        629 	.ds 1
      000ABC                        630 _usage_refs:
      000ABC                        631 	.ds 30
      000ADA                        632 _usage_order:
      000ADA                        633 	.ds 30
      000AF8                        634 _usage_lengths:
      000AF8                        635 	.ds 2
      000AFA                        636 _macro_usages:
      000AFA                        637 	.ds 4
      000AFE                        638 _owned_usage_key_PARM_2:
      000AFE                        639 	.ds 1
      000AFF                        640 _owned_usage_key_code_10000_430:
      000AFF                        641 	.ds 1
      000B00                        642 _owned_usage_key___200000090_20000_431:
      000B00                        643 	.ds 2
      000B02                        644 _owned_usage_key_which_10000_431:
      000B02                        645 	.ds 1
      000B03                        646 _owned_usage_key_count_10000_431:
      000B03                        647 	.ds 1
      000B04                        648 _owned_usage_key_pos_30001_438:
      000B04                        649 	.ds 1
      000B05                        650 _owned_usage_key_key_40000_443:
      000B05                        651 	.ds 1
      000B06                        652 _send_keyboard_report_projected_10001_450:
      000B06                        653 	.ds 32
      000B26                        654 _send_keyboard_report_empty_50002_457:
      000B26                        655 	.ds 1
      000B27                        656 _send_keyboard_report_present_50002_457:
      000B27                        657 	.ds 1
      000B28                        658 _send_keyboard_report_last_report_10003_466:
      000B28                        659 	.ds 32
      000B48                        660 _send_keyboard_report_changed_10003_466:
      000B48                        661 	.ds 1
      000B49                        662 _add_weak_mods_mods_10000_484:
      000B49                        663 	.ds 1
      000B4A                        664 _del_weak_mods_mods_10000_486:
      000B4A                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000E7D                        674 _real_mods:
      000E7D                        675 	.ds 1
      000E7E                        676 _weak_mods:
      000E7E                        677 	.ds 1
      000E7F                        678 _actual_keyboard_report::
      000E7F                        679 	.ds 32
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT0 (CODE)
                                    682 	.area GSINIT1 (CODE)
                                    683 	.area GSINIT2 (CODE)
                                    684 	.area GSINIT3 (CODE)
                                    685 	.area GSINIT4 (CODE)
                                    686 	.area GSINIT5 (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area CSEG    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; global & static initialisations
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 	.area GSFINAL (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    708 ;------------------------------------------------------------
                                    709 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    710 ;------------------------------------------------------------
                                    711 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function ak820_macro_change
                                    722 ;	-----------------------------------------
      0081AA                        723 _ak820_macro_change:
      0081AA 12 38 86         [24]  724 	lcall	_ak820_outline_0114
      0081AD 90 09 F5         [24]  725 	mov	dptr,#_ak820_macro_change_bits_10000_355
      0081B0 12 38 8B         [24]  726 	lcall	_ak820_outline_0115
                                    727 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      0081B3 90 09 F1         [24]  728 	mov	dptr,#_ak820_macro_primitive
      0081B6 E0               [24]  729 	movx	a,@dptr
      0081B7 70 04            [24]  730 	jnz	00102$
      0081B9 75 82 01         [24]  731 	mov	dpl, #0x01
      0081BC 22               [24]  732 	ret
      0081BD                        733 00102$:
                                    734 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      0081BD 90 09 F3         [24]  735 	mov	dptr,#_ak820_macro_change_PARM_2
      0081C0 E0               [24]  736 	movx	a,@dptr
      0081C1 FF               [12]  737 	mov	r7,a
      0081C2 12 7D 3F         [24]  738 	lcall	_ak820_outline_0046
      0081C5 80 02            [24]  739 	sjmp	00123$
      0081C7                        740 00122$:
      0081C7 25 E0            [12]  741 	add	a,acc
      0081C9                        742 00123$:
      0081C9 D5 F0 FB         [24]  743 	djnz	b,00122$
      0081CC FE               [12]  744 	mov	r6,a
                                    745 ;	quantum/action_util.c:101: bits += index >> 3;
      0081CD 12 88 0B         [24]  746 	lcall	_ak820_outline_0174
      0081D0 FF               [12]  747 	mov	r7,a
      0081D1 90 09 F5         [24]  748 	mov	dptr,#_ak820_macro_change_bits_10000_355
      0081D4 12 38 50         [24]  749 	lcall	_ak820_outline_0065
      0081D7 90 09 F5         [24]  750 	mov	dptr,#_ak820_macro_change_bits_10000_355
      0081DA EF               [12]  751 	mov	a,r7
      0081DB 2C               [12]  752 	add	a, r4
      0081DC F0               [24]  753 	movx	@dptr,a
      0081DD E4               [12]  754 	clr	a
      0081DE 3D               [12]  755 	addc	a, r5
      0081DF A3               [24]  756 	inc	dptr
      0081E0 F0               [24]  757 	movx	@dptr,a
                                    758 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      0081E1 90 09 F5         [24]  759 	mov	dptr,#_ak820_macro_change_bits_10000_355
      0081E4 E0               [24]  760 	movx	a,@dptr
      0081E5 FD               [12]  761 	mov	r5,a
      0081E6 A3               [24]  762 	inc	dptr
      0081E7 E0               [24]  763 	movx	a,@dptr
      0081E8 FF               [12]  764 	mov	r7,a
      0081E9 12 42 3C         [24]  765 	lcall	_ak820_outline_0194
      0081EC E0               [24]  766 	movx	a,@dptr
      0081ED FC               [12]  767 	mov	r4,a
      0081EE EE               [12]  768 	mov	a,r6
      0081EF 5C               [12]  769 	anl	a,r4
      0081F0 B4 01 00         [24]  770 	cjne	a,#0x01,00124$
      0081F3                        771 00124$:
      0081F3 B3               [12]  772 	cpl	c
      0081F4 92 23            [24]  773 	mov	_ak820_macro_change_sloc0_1_0,c
      0081F6 90 09 F4         [24]  774 	mov	dptr,#_ak820_macro_change_PARM_3
      0081F9 E0               [24]  775 	movx	a,@dptr
      0081FA FB               [12]  776 	mov	r3,a
      0081FB A2 23            [12]  777 	mov	c,_ak820_macro_change_sloc0_1_0
      0081FD E4               [12]  778 	clr	a
      0081FE 33               [12]  779 	rlc	a
      0081FF B5 03 04         [24]  780 	cjne	a,ar3,00104$
      008202 75 82 00         [24]  781 	mov	dpl, #0x00
      008205 22               [24]  782 	ret
      008206                        783 00104$:
                                    784 ;	quantum/action_util.c:103: *bits ^= mask;
      008206 EC               [12]  785 	mov	a,r4
      008207 62 06            [12]  786 	xrl	ar6,a
      008209 12 42 3C         [24]  787 	lcall	_ak820_outline_0194
      00820C EE               [12]  788 	mov	a,r6
      00820D F0               [24]  789 	movx	@dptr,a
                                    790 ;	quantum/action_util.c:104: return true;
      00820E 75 82 01         [24]  791 	mov	dpl, #0x01
                                    792 ;	quantum/action_util.c:105: }
      008211 22               [24]  793 	ret
                                    794 ;------------------------------------------------------------
                                    795 ;Allocation info for local variables in function 'change_owned'
                                    796 ;------------------------------------------------------------
                                    797 ;mode          Allocated with name '_change_owned_PARM_2'
                                    798 ;mods          Allocated with name '_change_owned_mods_10000_360'
                                    799 ;kind          Allocated with name '_change_owned_kind_10000_361'
                                    800 ;pressed       Allocated with name '_change_owned_pressed_10000_361'
                                    801 ;refs          Allocated with name '_change_owned_refs_10000_361'
                                    802 ;old           Allocated with name '_change_owned_old_30000_363'
                                    803 ;result        Allocated with name '_change_owned_result_10001_364'
                                    804 ;i             Allocated with name '_change_owned_i_20001_365'
                                    805 ;bit           Allocated with name '_change_owned_bit_20001_365'
                                    806 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function change_owned
                                    811 ;	-----------------------------------------
      008212                        812 _change_owned:
      008212 E5 82            [12]  813 	mov	a,dpl
      008214 90 09 F8         [24]  814 	mov	dptr,#_change_owned_mods_10000_360
      008217 F0               [24]  815 	movx	@dptr,a
                                    816 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      008218 90 09 F7         [24]  817 	mov	dptr,#_change_owned_PARM_2
      00821B E0               [24]  818 	movx	a,@dptr
      00821C FF               [12]  819 	mov	r7,a
      00821D C3               [12]  820 	clr	c
      00821E 13               [12]  821 	rrc	a
      00821F FE               [12]  822 	mov	r6,a
                                    823 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      008220 53 07 01         [24]  824 	anl	ar7,#0x01
      008223 EF               [12]  825 	mov	a,r7
      008224 B4 01 00         [24]  826 	cjne	a,#0x01,00205$
      008227                        827 00205$:
      008227 92 24            [24]  828 	mov  _change_owned_sloc0_1_0,c
      008229 B3               [12]  829 	cpl	c
      00822A E4               [12]  830 	clr	a
      00822B 33               [12]  831 	rlc	a
      00822C F5 64            [12]  832 	mov	_change_owned_sloc1_1_0,a
                                    833 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      00822E EE               [12]  834 	mov	a,r6
      00822F 60 06            [24]  835 	jz	00121$
      008231 7D E5            [12]  836 	mov	r5,#_owned_weak_refs
      008233 7F 09            [12]  837 	mov	r7,#(_owned_weak_refs >> 8)
      008235 80 04            [24]  838 	sjmp	00122$
      008237                        839 00121$:
      008237 7D DD            [12]  840 	mov	r5,#_owned_mod_refs
      008239 7F 09            [12]  841 	mov	r7,#(_owned_mod_refs >> 8)
      00823B                        842 00122$:
                                    843 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      00823B 90 09 F1         [24]  844 	mov	dptr,#_ak820_macro_primitive
      00823E E0               [24]  845 	movx	a,@dptr
      00823F 60 36            [24]  846 	jz	00102$
                                    847 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      008241 EE               [12]  848 	mov	a,r6
      008242 24 EF            [12]  849 	add	a, #_macro_mods
      008244 FB               [12]  850 	mov	r3,a
      008245 E4               [12]  851 	clr	a
      008246 34 09            [12]  852 	addc	a, #(_macro_mods >> 8)
      008248 12 4F 41         [24]  853 	lcall	_ak820_outline_0061
                                    854 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      00824B E5 64            [12]  855 	mov	a,_change_owned_sloc1_1_0
      00824D 60 0A            [24]  856 	jz	00123$
      00824F 90 09 F8         [24]  857 	mov	dptr,#_change_owned_mods_10000_360
      008252 E0               [24]  858 	movx	a,@dptr
      008253 F9               [12]  859 	mov	r1,a
      008254 EA               [12]  860 	mov	a,r2
      008255 42 01            [12]  861 	orl	ar1,a
      008257 80 07            [24]  862 	sjmp	00124$
      008259                        863 00123$:
      008259 90 09 F8         [24]  864 	mov	dptr,#_change_owned_mods_10000_360
      00825C E0               [24]  865 	movx	a,@dptr
      00825D F4               [12]  866 	cpl	a
      00825E 5A               [12]  867 	anl	a,r2
      00825F F9               [12]  868 	mov	r1,a
      008260                        869 00124$:
      008260 12 33 FC         [24]  870 	lcall	_ak820_outline_0129
      008263 E9               [12]  871 	mov	a,r1
      008264 F0               [24]  872 	movx	@dptr,a
                                    873 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      008265 E5 64            [12]  874 	mov	a,_change_owned_sloc1_1_0
      008267 60 06            [24]  875 	jz	00125$
      008269 74 FF            [12]  876 	mov	a,#0xff
      00826B 6A               [12]  877 	xrl	a,r2
      00826C FC               [12]  878 	mov	r4,a
      00826D 80 02            [24]  879 	sjmp	00126$
      00826F                        880 00125$:
      00826F 8A 04            [24]  881 	mov	ar4,r2
      008271                        882 00126$:
      008271 90 09 F8         [24]  883 	mov	dptr,#_change_owned_mods_10000_360
      008274 E0               [24]  884 	movx	a,@dptr
      008275 5C               [12]  885 	anl	a,r4
      008276 F0               [24]  886 	movx	@dptr,a
      008277                        887 00102$:
                                    888 ;	quantum/action_util.c:115: uint8_t result = 0;
      008277 90 09 F9         [24]  889 	mov	dptr,#_change_owned_result_10001_364
      00827A E4               [12]  890 	clr	a
      00827B F0               [24]  891 	movx	@dptr,a
                                    892 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00827C 90 09 FA         [24]  893 	mov	dptr,#_change_owned_bit_20001_365
      00827F 04               [12]  894 	inc	a
      008280 F0               [24]  895 	movx	@dptr,a
      008281 90 09 F8         [24]  896 	mov	dptr,#_change_owned_mods_10000_360
      008284 E0               [24]  897 	movx	a,@dptr
      008285 FC               [12]  898 	mov	r4,a
      008286 7B 00            [12]  899 	mov	r3,#0x00
      008288                        900 00117$:
      008288 BB 08 00         [24]  901 	cjne	r3,#0x08,00210$
      00828B                        902 00210$:
      00828B 50 3F            [24]  903 	jnc	00112$
                                    904 ;	quantum/action_util.c:117: if (mods & bit) {
      00828D 90 09 FA         [24]  905 	mov	dptr,#_change_owned_bit_20001_365
      008290 E0               [24]  906 	movx	a,@dptr
      008291 5C               [12]  907 	anl	a,r4
      008292 60 1C            [24]  908 	jz	00109$
                                    909 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      008294 E5 64            [12]  910 	mov	a,_change_owned_sloc1_1_0
      008296 60 0C            [24]  911 	jz	00106$
      008298 EB               [12]  912 	mov	a,r3
      008299 2D               [12]  913 	add	a, r5
      00829A 12 38 17         [24]  914 	lcall	_ak820_outline_0021
      00829D F8               [12]  915 	mov	r0,a
      00829E 08               [12]  916 	inc	r0
      00829F 12 87 BE         [24]  917 	lcall	_ak820_outline_0067
      0082A2 80 0C            [24]  918 	sjmp	00109$
      0082A4                        919 00106$:
                                    920 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      0082A4 EB               [12]  921 	mov	a,r3
      0082A5 2D               [12]  922 	add	a, r5
      0082A6 12 38 17         [24]  923 	lcall	_ak820_outline_0021
      0082A9 F8               [12]  924 	mov	r0,a
      0082AA 60 04            [24]  925 	jz	00109$
      0082AC 18               [12]  926 	dec	r0
      0082AD 12 87 BE         [24]  927 	lcall	_ak820_outline_0067
      0082B0                        928 00109$:
                                    929 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      0082B0 EB               [12]  930 	mov	a,r3
      0082B1 2D               [12]  931 	add	a, r5
      0082B2 12 38 17         [24]  932 	lcall	_ak820_outline_0021
      0082B5 60 0B            [24]  933 	jz	00118$
      0082B7 90 09 FA         [24]  934 	mov	dptr,#_change_owned_bit_20001_365
      0082BA E0               [24]  935 	movx	a,@dptr
      0082BB FA               [12]  936 	mov	r2,a
      0082BC 90 09 F9         [24]  937 	mov	dptr,#_change_owned_result_10001_364
      0082BF E0               [24]  938 	movx	a,@dptr
      0082C0 4A               [12]  939 	orl	a,r2
      0082C1 F0               [24]  940 	movx	@dptr,a
      0082C2                        941 00118$:
                                    942 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0082C2 0B               [12]  943 	inc	r3
      0082C3 90 09 FA         [24]  944 	mov	dptr,#_change_owned_bit_20001_365
      0082C6 E0               [24]  945 	movx	a,@dptr
      0082C7 25 E0            [12]  946 	add	a,acc
      0082C9 F0               [24]  947 	movx	@dptr,a
      0082CA 80 BC            [24]  948 	sjmp	00117$
      0082CC                        949 00112$:
                                    950 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      0082CC EE               [12]  951 	mov	a,r6
      0082CD 60 09            [24]  952 	jz	00114$
      0082CF 90 09 F9         [24]  953 	mov	dptr,#_change_owned_result_10001_364
      0082D2 E0               [24]  954 	movx	a,@dptr
      0082D3 90 09 EE         [24]  955 	mov	dptr,#_owned_weak_mods
      0082D6 F0               [24]  956 	movx	@dptr,a
      0082D7 22               [24]  957 	ret
      0082D8                        958 00114$:
                                    959 ;	quantum/action_util.c:124: else owned_mods = result;
      0082D8 90 09 F9         [24]  960 	mov	dptr,#_change_owned_result_10001_364
      0082DB E0               [24]  961 	movx	a,@dptr
      0082DC 90 09 ED         [24]  962 	mov	dptr,#_owned_mods
      0082DF F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:125: }
      0082E0 22               [24]  965 	ret
                                    966 ;------------------------------------------------------------
                                    967 ;Allocation info for local variables in function 'add_owned_mods'
                                    968 ;------------------------------------------------------------
                                    969 ;mods          Allocated with name '_add_owned_mods_mods_10000_373'
                                    970 ;------------------------------------------------------------
                                    971 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    972 ;	-----------------------------------------
                                    973 ;	 function add_owned_mods
                                    974 ;	-----------------------------------------
      0082E1                        975 _add_owned_mods:
      0082E1 E5 82            [12]  976 	mov	a,dpl
      0082E3 90 09 FB         [24]  977 	mov	dptr,#_add_owned_mods_mods_10000_373
      0082E6 12 87 EE         [24]  978 	lcall	_ak820_outline_0125
      0082E9 74 01            [12]  979 	mov	a,#0x01
      0082EB F0               [24]  980 	movx	@dptr,a
      0082EC 8F 82            [24]  981 	mov	dpl, r7
      0082EE 41 12            [12]  982 	ajmp	_change_owned
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'del_owned_mods'
                                    985 ;------------------------------------------------------------
                                    986 ;mods          Allocated with name '_del_owned_mods_mods_10000_375'
                                    987 ;------------------------------------------------------------
                                    988 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    989 ;	-----------------------------------------
                                    990 ;	 function del_owned_mods
                                    991 ;	-----------------------------------------
      0082F0                        992 _del_owned_mods:
      0082F0 E5 82            [12]  993 	mov	a,dpl
      0082F2 90 09 FC         [24]  994 	mov	dptr,#_del_owned_mods_mods_10000_375
      0082F5 12 87 EE         [24]  995 	lcall	_ak820_outline_0125
      0082F8 E4               [12]  996 	clr	a
      0082F9 F0               [24]  997 	movx	@dptr,a
      0082FA 8F 82            [24]  998 	mov	dpl, r7
      0082FC 41 12            [12]  999 	ajmp	_change_owned
                                   1000 ;------------------------------------------------------------
                                   1001 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1002 ;------------------------------------------------------------
                                   1003 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_377'
                                   1004 ;------------------------------------------------------------
                                   1005 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1006 ;	-----------------------------------------
                                   1007 ;	 function add_owned_weak_mods
                                   1008 ;	-----------------------------------------
      0082FE                       1009 _add_owned_weak_mods:
      0082FE E5 82            [12] 1010 	mov	a,dpl
      008300 90 09 FD         [24] 1011 	mov	dptr,#_add_owned_weak_mods_mods_10000_377
      008303 12 87 EE         [24] 1012 	lcall	_ak820_outline_0125
      008306 74 03            [12] 1013 	mov	a,#0x03
      008308 F0               [24] 1014 	movx	@dptr,a
      008309 8F 82            [24] 1015 	mov	dpl, r7
      00830B 41 12            [12] 1016 	ajmp	_change_owned
                                   1017 ;------------------------------------------------------------
                                   1018 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1019 ;------------------------------------------------------------
                                   1020 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_379'
                                   1021 ;------------------------------------------------------------
                                   1022 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1023 ;	-----------------------------------------
                                   1024 ;	 function del_owned_weak_mods
                                   1025 ;	-----------------------------------------
      00830D                       1026 _del_owned_weak_mods:
      00830D E5 82            [12] 1027 	mov	a,dpl
      00830F 90 09 FE         [24] 1028 	mov	dptr,#_del_owned_weak_mods_mods_10000_379
      008312 12 87 EE         [24] 1029 	lcall	_ak820_outline_0125
      008315 74 02            [12] 1030 	mov	a,#0x02
      008317 F0               [24] 1031 	movx	@dptr,a
      008318 8F 82            [24] 1032 	mov	dpl, r7
      00831A 41 12            [12] 1033 	ajmp	_change_owned
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1036 ;------------------------------------------------------------
                                   1037 ;i             Allocated with name '_clear_owned_mods_i_20000_383'
                                   1038 ;------------------------------------------------------------
                                   1039 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1040 ;	-----------------------------------------
                                   1041 ;	 function clear_owned_mods
                                   1042 ;	-----------------------------------------
      00831C                       1043 _clear_owned_mods:
                                   1044 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      00831C 7F 00            [12] 1045 	mov	r7,#0x00
      00831E                       1046 00103$:
      00831E BF 08 00         [24] 1047 	cjne	r7,#0x08,00122$
      008321                       1048 00122$:
      008321 50 1A            [24] 1049 	jnc	00101$
      008323 EF               [12] 1050 	mov	a,r7
      008324 24 DD            [12] 1051 	add	a, #_owned_mod_refs
      008326 FD               [12] 1052 	mov	r5,a
      008327 E4               [12] 1053 	clr	a
      008328 34 09            [12] 1054 	addc	a, #(_owned_mod_refs >> 8)
      00832A FE               [12] 1055 	mov	r6,a
      00832B EF               [12] 1056 	mov	a,r7
      00832C 24 E5            [12] 1057 	add	a, #_owned_weak_refs
      00832E F5 82            [12] 1058 	mov	dpl,a
      008330 E4               [12] 1059 	clr	a
      008331 34 09            [12] 1060 	addc	a, #(_owned_weak_refs >> 8)
      008333 F5 83            [12] 1061 	mov	dph,a
      008335 E4               [12] 1062 	clr	a
      008336 F0               [24] 1063 	movx	@dptr,a
      008337 12 87 E8         [24] 1064 	lcall	_ak820_outline_0106
      00833A 0F               [12] 1065 	inc	r7
      00833B 80 E1            [24] 1066 	sjmp	00103$
      00833D                       1067 00101$:
                                   1068 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      00833D 90 09 F0         [24] 1069 	mov	dptr,#(_macro_mods + 0x0001)
      008340 E4               [12] 1070 	clr	a
      008341 F0               [24] 1071 	movx	@dptr,a
      008342 90 09 EF         [24] 1072 	mov	dptr,#_macro_mods
      008345 F0               [24] 1073 	movx	@dptr,a
      008346 90 09 EE         [24] 1074 	mov	dptr,#_owned_weak_mods
      008349 F0               [24] 1075 	movx	@dptr,a
      00834A 90 09 ED         [24] 1076 	mov	dptr,#_owned_mods
      00834D F0               [24] 1077 	movx	@dptr,a
                                   1078 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      00834E 90 09 F2         [24] 1079 	mov	dptr,#_ak820_macro_cancelled
      008351 04               [12] 1080 	inc	a
      008352 F0               [24] 1081 	movx	@dptr,a
                                   1082 ;	quantum/action_util.c:134: }
      008353 22               [24] 1083 	ret
                                   1084 ;------------------------------------------------------------
                                   1085 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1086 ;------------------------------------------------------------
                                   1087 ;i             Allocated with name '_clear_owned_keys_i_20000_386'
                                   1088 ;i             Allocated with name '_clear_owned_keys_i_20000_387'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function clear_owned_keys
                                   1093 ;	-----------------------------------------
      008354                       1094 _clear_owned_keys:
                                   1095 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      008354 7F 00            [12] 1096 	mov	r7,#0x00
      008356                       1097 00104$:
      008356 EF               [12] 1098 	mov	a,r7
      008357 24 5B            [12] 1099 	add	a,#0xff - 0xa4
      008359 40 0D            [24] 1100 	jc	00101$
                                   1101 ;	free result
      00835B EF               [12] 1102 	mov	a,r7
      00835C 24 FF            [12] 1103 	add	a, #_key_refs
      00835E F5 82            [12] 1104 	mov	dpl,a
      008360 E4               [12] 1105 	clr	a
      008361 34 09            [12] 1106 	addc	a, #(_key_refs >> 8)
      008363 12 81 9B         [24] 1107 	lcall	_ak820_outline_0175
      008366 80 EE            [24] 1108 	sjmp	00104$
      008368                       1109 00101$:
                                   1110 ;	quantum/action_util.c:142: distinct_keys = 0;
      008368 90 0A A4         [24] 1111 	mov	dptr,#_distinct_keys
      00836B E4               [12] 1112 	clr	a
      00836C F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      00836D FF               [12] 1115 	mov	r7,a
      00836E                       1116 00107$:
      00836E BF 15 00         [24] 1117 	cjne	r7,#0x15,00142$
      008371                       1118 00142$:
      008371 50 0D            [24] 1119 	jnc	00109$
      008373 EF               [12] 1120 	mov	a,r7
      008374 24 A5            [12] 1121 	add	a, #_macro_keys
      008376 F5 82            [12] 1122 	mov	dpl,a
      008378 E4               [12] 1123 	clr	a
      008379 34 0A            [12] 1124 	addc	a, #(_macro_keys >> 8)
      00837B 12 81 9B         [24] 1125 	lcall	_ak820_outline_0175
      00837E 80 EE            [24] 1126 	sjmp	00107$
      008380                       1127 00109$:
                                   1128 ;	quantum/action_util.c:144: }
      008380 22               [24] 1129 	ret
                                   1130 ;------------------------------------------------------------
                                   1131 ;Allocation info for local variables in function 'add_owned_key'
                                   1132 ;------------------------------------------------------------
                                   1133 ;code          Allocated with name '_add_owned_key_code_10000_388'
                                   1134 ;__400000079   Allocated with name '_add_owned_key___400000079_40000_397'
                                   1135 ;key           Allocated with name '_add_owned_key_key_50000_398'
                                   1136 ;i             Allocated with name '_add_owned_key_i_40000_396'
                                   1137 ;__300000081   Allocated with name '_add_owned_key___300000081_30000_400'
                                   1138 ;key           Allocated with name '_add_owned_key_key_40000_401'
                                   1139 ;------------------------------------------------------------
                                   1140 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1141 ;	-----------------------------------------
                                   1142 ;	 function add_owned_key
                                   1143 ;	-----------------------------------------
      008381                       1144 _add_owned_key:
      008381 E5 82            [12] 1145 	mov	a,dpl
      008383 90 0A BA         [24] 1146 	mov	dptr,#_add_owned_key_code_10000_388
      008386 12 88 00         [24] 1147 	lcall	_ak820_outline_0143
                                   1148 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      008389 74 01            [12] 1149 	mov	a,#0x01
      00838B F0               [24] 1150 	movx	@dptr,a
      00838C 90 0A A5         [24] 1151 	mov	dptr,#_macro_keys
      00838F C0 07            [24] 1152 	push	ar7
      008391 31 AA            [12] 1153 	acall	_ak820_macro_change
      008393 E5 82            [12] 1154 	mov	a, dpl
      008395 D0 07            [24] 1155 	pop	ar7
      008397 70 03            [24] 1156 	jnz	00102$
      008399 F5 82            [12] 1157 	mov	dpl,a
      00839B 22               [24] 1158 	ret
      00839C                       1159 00102$:
                                   1160 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      00839C 12 87 B0         [24] 1161 	lcall	_ak820_outline_0033
      00839F FC               [12] 1162 	mov	r4,a
      0083A0 04               [12] 1163 	inc	a
      0083A1 12 87 E8         [24] 1164 	lcall	_ak820_outline_0106
      0083A4 EC               [12] 1165 	mov	a,r4
      0083A5 60 04            [24] 1166 	jz	00104$
      0083A7 75 82 00         [24] 1167 	mov	dpl, #0x00
      0083AA 22               [24] 1168 	ret
      0083AB                       1169 00104$:
                                   1170 ;	quantum/action_util.c:148: ++distinct_keys;
      0083AB 90 0A A4         [24] 1171 	mov	dptr,#_distinct_keys
      0083AE E0               [24] 1172 	movx	a,@dptr
      0083AF 24 01            [12] 1173 	add	a, #0x01
      0083B1 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0083B2 90 0E 6C         [24] 1176 	mov	dptr,#_keyboard_protocol
      0083B5 E0               [24] 1177 	movx	a,@dptr
      0083B6 60 11            [24] 1178 	jz	00106$
      0083B8 90 0B 4D         [24] 1179 	mov	dptr,#_keymap_config
      0083BB E0               [24] 1180 	movx	a,@dptr
      0083BC 30 E7 0A         [24] 1181 	jnb	acc.7,00106$
                                   1182 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0083BF 12 88 11         [24] 1183 	lcall	_ak820_outline_0186
      0083C2 12 75 42         [24] 1184 	lcall	_add_key_to_report
                                   1185 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0083C5 75 82 01         [24] 1186 	mov	dpl, #0x01
      0083C8 22               [24] 1187 	ret
      0083C9                       1188 00106$:
                                   1189 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      0083C9 90 0A A4         [24] 1190 	mov	dptr,#_distinct_keys
      0083CC E0               [24] 1191 	movx	a,@dptr
      0083CD 24 F9            [12] 1192 	add	a,#0xff - 0x06
      0083CF 50 17            [24] 1193 	jnc	00110$
                                   1194 ;	free result
                                   1195 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      0083D1 7F 00            [12] 1196 	mov	r7,#0x00
      0083D3                       1197 00115$:
      0083D3 BF 06 00         [24] 1198 	cjne	r7,#0x06,00174$
      0083D6                       1199 00174$:
      0083D6 50 1E            [24] 1200 	jnc	00111$
      0083D8 EF               [12] 1201 	mov	a,r7
      0083D9 24 81            [12] 1202 	add	a, #(_actual_keyboard_report + 0x0002)
      0083DB F5 82            [12] 1203 	mov	dpl,a
      0083DD E4               [12] 1204 	clr	a
      0083DE 34 0E            [12] 1205 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      0083E0 F5 83            [12] 1206 	mov	dph,a
      0083E2 74 01            [12] 1207 	mov	a,#0x01
      0083E4 F0               [24] 1208 	movx	@dptr,a
      0083E5 0F               [12] 1209 	inc	r7
      0083E6 80 EB            [24] 1210 	sjmp	00115$
      0083E8                       1211 00110$:
                                   1212 ;	quantum/action_util.c:154: } else add_key(code);
      0083E8 90 0A BA         [24] 1213 	mov	dptr,#_add_owned_key_code_10000_388
      0083EB E0               [24] 1214 	movx	a,@dptr
                                   1215 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0083EC 90 08 6D         [24] 1216 	mov	dptr,#_add_key_to_report_PARM_2
      0083EF F0               [24] 1217 	movx	@dptr,a
      0083F0 90 0E 7F         [24] 1218 	mov	dptr,#_actual_keyboard_report
      0083F3 12 75 42         [24] 1219 	lcall	_add_key_to_report
                                   1220 ;	quantum/action_util.c:154: } else add_key(code);
      0083F6                       1221 00111$:
                                   1222 ;	quantum/action_util.c:155: return true;
      0083F6 75 82 01         [24] 1223 	mov	dpl, #0x01
                                   1224 ;	quantum/action_util.c:156: }
      0083F9 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'del_owned_key'
                                   1228 ;------------------------------------------------------------
                                   1229 ;code          Allocated with name '_del_owned_key_code_10000_403'
                                   1230 ;__400000083   Allocated with name '_del_owned_key___400000083_40000_414'
                                   1231 ;key           Allocated with name '_del_owned_key_key_50000_415'
                                   1232 ;key           Allocated with name '_del_owned_key_key_40000_412'
                                   1233 ;__600000086   Allocated with name '_del_owned_key___600000086_60000_420'
                                   1234 ;key           Allocated with name '_del_owned_key_key_70000_421'
                                   1235 ;__300000088   Allocated with name '_del_owned_key___300000088_30000_423'
                                   1236 ;key           Allocated with name '_del_owned_key_key_40000_424'
                                   1237 ;------------------------------------------------------------
                                   1238 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1239 ;	-----------------------------------------
                                   1240 ;	 function del_owned_key
                                   1241 ;	-----------------------------------------
      0083FA                       1242 _del_owned_key:
      0083FA E5 82            [12] 1243 	mov	a,dpl
      0083FC 90 0A BB         [24] 1244 	mov	dptr,#_del_owned_key_code_10000_403
      0083FF 12 88 00         [24] 1245 	lcall	_ak820_outline_0143
                                   1246 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      008402 E4               [12] 1247 	clr	a
      008403 F0               [24] 1248 	movx	@dptr,a
      008404 90 0A A5         [24] 1249 	mov	dptr,#_macro_keys
      008407 C0 07            [24] 1250 	push	ar7
      008409 31 AA            [12] 1251 	acall	_ak820_macro_change
      00840B E5 82            [12] 1252 	mov	a, dpl
      00840D D0 07            [24] 1253 	pop	ar7
      00840F 70 03            [24] 1254 	jnz	00102$
      008411 F5 82            [12] 1255 	mov	dpl,a
      008413 22               [24] 1256 	ret
      008414                       1257 00102$:
                                   1258 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      008414 12 87 B0         [24] 1259 	lcall	_ak820_outline_0033
      008417 FC               [12] 1260 	mov	r4,a
      008418 60 07            [24] 1261 	jz	00103$
      00841A 1C               [12] 1262 	dec	r4
      00841B 12 49 F9         [24] 1263 	lcall	_ak820_outline_0068
      00841E EC               [12] 1264 	mov	a,r4
      00841F 60 04            [24] 1265 	jz	00104$
      008421                       1266 00103$:
      008421 75 82 00         [24] 1267 	mov	dpl, #0x00
      008424 22               [24] 1268 	ret
      008425                       1269 00104$:
                                   1270 ;	quantum/action_util.c:160: --distinct_keys;
      008425 90 0A A4         [24] 1271 	mov	dptr,#_distinct_keys
      008428 E0               [24] 1272 	movx	a,@dptr
      008429 14               [12] 1273 	dec	a
      00842A F0               [24] 1274 	movx	@dptr,a
                                   1275 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      00842B 90 0E 6C         [24] 1276 	mov	dptr,#_keyboard_protocol
      00842E E0               [24] 1277 	movx	a,@dptr
      00842F 60 16            [24] 1278 	jz	00107$
      008431 90 0B 4D         [24] 1279 	mov	dptr,#_keymap_config
      008434 E0               [24] 1280 	movx	a,@dptr
      008435 30 E7 0F         [24] 1281 	jnb	acc.7,00107$
                                   1282 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008438 90 08 70         [24] 1283 	mov	dptr,#_del_key_from_report_PARM_2
      00843B EF               [12] 1284 	mov	a,r7
      00843C F0               [24] 1285 	movx	@dptr,a
      00843D 90 0E 7F         [24] 1286 	mov	dptr,#_actual_keyboard_report
      008440 12 75 76         [24] 1287 	lcall	_del_key_from_report
                                   1288 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008443 75 82 01         [24] 1289 	mov	dpl, #0x01
      008446 22               [24] 1290 	ret
      008447                       1291 00107$:
                                   1292 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      008447 90 0A A4         [24] 1293 	mov	dptr,#_distinct_keys
      00844A E0               [24] 1294 	movx	a,@dptr
      00844B FF               [12] 1295 	mov  r7,a
      00844C 24 F9            [12] 1296 	add	a,#0xff - 0x06
      00844E 50 04            [24] 1297 	jnc	00110$
                                   1298 ;	free result
      008450 75 82 01         [24] 1299 	mov	dpl, #0x01
      008453 22               [24] 1300 	ret
      008454                       1301 00110$:
                                   1302 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008454 BF 06 1F         [24] 1303 	cjne	r7,#0x06,00115$
                                   1304 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      008457 90 0E 7F         [24] 1305 	mov	dptr,#_actual_keyboard_report
      00845A 12 75 AA         [24] 1306 	lcall	_clear_keys_from_report
                                   1307 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      00845D 7F 04            [12] 1308 	mov	r7,#0x04
      00845F                       1309 00122$:
      00845F EF               [12] 1310 	mov	a,r7
      008460 24 5B            [12] 1311 	add	a,#0xff - 0xa4
      008462 40 20            [24] 1312 	jc	00116$
                                   1313 ;	free result
      008464 12 87 B0         [24] 1314 	lcall	_ak820_outline_0033
      008467 60 0A            [24] 1315 	jz	00123$
                                   1316 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008469 12 88 11         [24] 1317 	lcall	_ak820_outline_0186
      00846C C0 07            [24] 1318 	push	ar7
      00846E 12 75 42         [24] 1319 	lcall	_add_key_to_report
      008471 D0 07            [24] 1320 	pop	ar7
                                   1321 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008473                       1322 00123$:
      008473 0F               [12] 1323 	inc	r7
      008474 80 E9            [24] 1324 	sjmp	00122$
      008476                       1325 00115$:
                                   1326 ;	quantum/action_util.c:169: } else del_key(code);
      008476 90 0A BB         [24] 1327 	mov	dptr,#_del_owned_key_code_10000_403
      008479 E0               [24] 1328 	movx	a,@dptr
                                   1329 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00847A 90 08 70         [24] 1330 	mov	dptr,#_del_key_from_report_PARM_2
      00847D F0               [24] 1331 	movx	@dptr,a
      00847E 90 0E 7F         [24] 1332 	mov	dptr,#_actual_keyboard_report
      008481 12 75 76         [24] 1333 	lcall	_del_key_from_report
                                   1334 ;	quantum/action_util.c:169: } else del_key(code);
      008484                       1335 00116$:
                                   1336 ;	quantum/action_util.c:170: return true;
      008484 75 82 01         [24] 1337 	mov	dpl, #0x01
                                   1338 ;	quantum/action_util.c:171: }
      008487 22               [24] 1339 	ret
                                   1340 ;------------------------------------------------------------
                                   1341 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1342 ;------------------------------------------------------------
                                   1343 ;i             Allocated with name '_clear_owned_usages_i_20000_428'
                                   1344 ;i             Allocated with name '_clear_owned_usages_i_20000_429'
                                   1345 ;------------------------------------------------------------
                                   1346 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1347 ;	-----------------------------------------
                                   1348 ;	 function clear_owned_usages
                                   1349 ;	-----------------------------------------
      008488                       1350 _clear_owned_usages:
                                   1351 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      008488 7F 00            [12] 1352 	mov	r7,#0x00
      00848A                       1353 00104$:
      00848A BF 1E 00         [24] 1354 	cjne	r7,#0x1e,00141$
      00848D                       1355 00141$:
      00848D 50 14            [24] 1356 	jnc	00101$
      00848F EF               [12] 1357 	mov	a,r7
      008490 24 BC            [12] 1358 	add	a, #_usage_refs
      008492 FD               [12] 1359 	mov	r5,a
      008493 E4               [12] 1360 	clr	a
      008494 34 0A            [12] 1361 	addc	a, #(_usage_refs >> 8)
      008496 FE               [12] 1362 	mov	r6,a
      008497 EF               [12] 1363 	mov	a,r7
      008498 12 87 CF         [24] 1364 	lcall	_ak820_outline_0073
      00849B E4               [12] 1365 	clr	a
      00849C F0               [24] 1366 	movx	@dptr,a
      00849D 12 87 E8         [24] 1367 	lcall	_ak820_outline_0106
      0084A0 0F               [12] 1368 	inc	r7
      0084A1 80 E7            [24] 1369 	sjmp	00104$
      0084A3                       1370 00101$:
                                   1371 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      0084A3 90 0A F9         [24] 1372 	mov	dptr,#(_usage_lengths + 0x0001)
      0084A6 E4               [12] 1373 	clr	a
      0084A7 F0               [24] 1374 	movx	@dptr,a
      0084A8 90 0A F8         [24] 1375 	mov	dptr,#_usage_lengths
      0084AB F0               [24] 1376 	movx	@dptr,a
                                   1377 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      0084AC FF               [12] 1378 	mov	r7,a
      0084AD                       1379 00107$:
      0084AD BF 04 00         [24] 1380 	cjne	r7,#0x04,00143$
      0084B0                       1381 00143$:
      0084B0 50 0D            [24] 1382 	jnc	00109$
      0084B2 EF               [12] 1383 	mov	a,r7
      0084B3 24 FA            [12] 1384 	add	a, #_macro_usages
      0084B5 F5 82            [12] 1385 	mov	dpl,a
      0084B7 E4               [12] 1386 	clr	a
      0084B8 34 0A            [12] 1387 	addc	a, #(_macro_usages >> 8)
      0084BA 12 81 9B         [24] 1388 	lcall	_ak820_outline_0175
      0084BD 80 EE            [24] 1389 	sjmp	00107$
      0084BF                       1390 00109$:
                                   1391 ;	quantum/action_util.c:185: }
      0084BF 22               [24] 1392 	ret
                                   1393 ;------------------------------------------------------------
                                   1394 ;Allocation info for local variables in function 'owned_usage_key'
                                   1395 ;------------------------------------------------------------
                                   1396 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1397 ;code          Allocated with name '_owned_usage_key_code_10000_430'
                                   1398 ;__200000090   Allocated with name '_owned_usage_key___200000090_20000_431'
                                   1399 ;which         Allocated with name '_owned_usage_key_which_10000_431'
                                   1400 ;base          Allocated with name '_owned_usage_key_base_10000_431'
                                   1401 ;count         Allocated with name '_owned_usage_key_count_10000_431'
                                   1402 ;index         Allocated with name '_owned_usage_key_index_10000_431'
                                   1403 ;pos           Allocated with name '_owned_usage_key_pos_30001_438'
                                   1404 ;i             Allocated with name '_owned_usage_key_i_40001_439'
                                   1405 ;__300000091   Allocated with name '_owned_usage_key___300000091_30000_442'
                                   1406 ;key           Allocated with name '_owned_usage_key_key_40000_443'
                                   1407 ;------------------------------------------------------------
                                   1408 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1409 ;	-----------------------------------------
                                   1410 ;	 function owned_usage_key
                                   1411 ;	-----------------------------------------
      0084C0                       1412 _owned_usage_key:
      0084C0 E5 82            [12] 1413 	mov	a,dpl
      0084C2 90 0A FF         [24] 1414 	mov	dptr,#_owned_usage_key_code_10000_430
      0084C5 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      0084C6 E0               [24] 1417 	movx	a,@dptr
      0084C7 FF               [12] 1418 	mov	r7,a
      0084C8 BF A8 00         [24] 1419 	cjne	r7,#0xa8,00244$
      0084CB                       1420 00244$:
      0084CB B3               [12] 1421 	cpl	c
      0084CC 92 25            [24] 1422 	mov	_owned_usage_key_sloc0_1_0,c
      0084CE E4               [12] 1423 	clr	a
      0084CF 33               [12] 1424 	rlc	a
      0084D0 FF               [12] 1425 	mov	r7,a
      0084D1 90 0B 02         [24] 1426 	mov	dptr,#_owned_usage_key_which_10000_431
      0084D4 F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      0084D5 EF               [12] 1429 	mov	a,r7
      0084D6 60 02            [24] 1430 	jz	00129$
      0084D8 74 03            [12] 1431 	mov	a,#0x03
      0084DA                       1432 00129$:
      0084DA FE               [12] 1433 	mov	r6,a
                                   1434 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      0084DB EF               [12] 1435 	mov	a,r7
      0084DC 24 F8            [12] 1436 	add	a, #_usage_lengths
      0084DE FD               [12] 1437 	mov	r5,a
      0084DF E4               [12] 1438 	clr	a
      0084E0 34 0A            [12] 1439 	addc	a, #(_usage_lengths >> 8)
      0084E2 FF               [12] 1440 	mov	r7,a
      0084E3 12 42 3C         [24] 1441 	lcall	_ak820_outline_0194
      0084E6 E0               [24] 1442 	movx	a,@dptr
      0084E7 FC               [12] 1443 	mov	r4,a
                                   1444 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      0084E8 90 0A FF         [24] 1445 	mov	dptr,#_owned_usage_key_code_10000_430
      0084EB E0               [24] 1446 	movx	a,@dptr
      0084EC 24 5B            [12] 1447 	add	a,#0x5b
      0084EE FB               [12] 1448 	mov	r3,a
                                   1449 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      0084EF 90 0A FE         [24] 1450 	mov	dptr,#_owned_usage_key_PARM_2
      0084F2 E0               [24] 1451 	movx	a,@dptr
      0084F3 FA               [12] 1452 	mov	r2,a
      0084F4 90 09 F3         [24] 1453 	mov	dptr,#_ak820_macro_change_PARM_2
      0084F7 EB               [12] 1454 	mov	a,r3
      0084F8 F0               [24] 1455 	movx	@dptr,a
      0084F9 90 09 F4         [24] 1456 	mov	dptr,#_ak820_macro_change_PARM_3
      0084FC EA               [12] 1457 	mov	a,r2
      0084FD F0               [24] 1458 	movx	@dptr,a
      0084FE 90 0A FA         [24] 1459 	mov	dptr,#_macro_usages
      008501 C0 07            [24] 1460 	push	ar7
      008503 C0 06            [24] 1461 	push	ar6
      008505 C0 05            [24] 1462 	push	ar5
      008507 C0 04            [24] 1463 	push	ar4
      008509 C0 03            [24] 1464 	push	ar3
      00850B C0 02            [24] 1465 	push	ar2
      00850D 31 AA            [12] 1466 	acall	_ak820_macro_change
      00850F E5 82            [12] 1467 	mov	a, dpl
      008511 D0 02            [24] 1468 	pop	ar2
      008513 D0 03            [24] 1469 	pop	ar3
      008515 D0 04            [24] 1470 	pop	ar4
      008517 D0 05            [24] 1471 	pop	ar5
      008519 D0 06            [24] 1472 	pop	ar6
      00851B D0 07            [24] 1473 	pop	ar7
      00851D 70 01            [24] 1474 	jnz	00102$
      00851F 22               [24] 1475 	ret
      008520                       1476 00102$:
                                   1477 ;	quantum/action_util.c:192: if (pressed) {
      008520 EA               [12] 1478 	mov	a,r2
      008521 60 1A            [24] 1479 	jz	00115$
                                   1480 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      008523 12 87 D9         [24] 1481 	lcall	_ak820_outline_0078
      008526 04               [12] 1482 	inc	a
      008527 12 72 BF         [24] 1483 	lcall	_ak820_outline_0150
      00852A E8               [12] 1484 	mov	a,r0
      00852B 60 01            [24] 1485 	jz	00104$
      00852D 22               [24] 1486 	ret
      00852E                       1487 00104$:
                                   1488 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      00852E 90 0B 03         [24] 1489 	mov	dptr,#_owned_usage_key_count_10000_431
      008531 EC               [12] 1490 	mov	a,r4
      008532 04               [12] 1491 	inc	a
      008533 F0               [24] 1492 	movx	@dptr,a
      008534 EC               [12] 1493 	mov	a,r4
      008535 2E               [12] 1494 	add	a, r6
      008536 12 87 CF         [24] 1495 	lcall	_ak820_outline_0073
      008539 EB               [12] 1496 	mov	a,r3
      00853A F0               [24] 1497 	movx	@dptr,a
      00853B A1 9E            [12] 1498 	ajmp	00116$
      00853D                       1499 00115$:
                                   1500 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      00853D 12 87 D9         [24] 1501 	lcall	_ak820_outline_0078
      008540 60 07            [24] 1502 	jz	00105$
      008542 18               [12] 1503 	dec	r0
      008543 12 87 BE         [24] 1504 	lcall	_ak820_outline_0067
      008546 E8               [12] 1505 	mov	a,r0
      008547 60 01            [24] 1506 	jz	00106$
      008549                       1507 00105$:
      008549 22               [24] 1508 	ret
      00854A                       1509 00106$:
                                   1510 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      00854A 7A 00            [12] 1511 	mov	r2,#0x00
      00854C                       1512 00108$:
      00854C EA               [12] 1513 	mov	a,r2
      00854D 2E               [12] 1514 	add	a, r6
      00854E 12 87 CF         [24] 1515 	lcall	_ak820_outline_0073
      008551 E0               [24] 1516 	movx	a,@dptr
      008552 B5 03 02         [24] 1517 	cjne	a,ar3,00251$
      008555 80 03            [24] 1518 	sjmp	00167$
      008557                       1519 00251$:
      008557 0A               [12] 1520 	inc	r2
      008558 80 F2            [24] 1521 	sjmp	00108$
      00855A                       1522 00167$:
      00855A 90 0B 04         [24] 1523 	mov	dptr,#_owned_usage_key_pos_30001_438
      00855D EA               [12] 1524 	mov	a,r2
      00855E F0               [24] 1525 	movx	@dptr,a
                                   1526 ;	quantum/action_util.c:199: --count;
      00855F 1C               [12] 1527 	dec	r4
      008560 90 0B 03         [24] 1528 	mov	dptr,#_owned_usage_key_count_10000_431
      008563 EC               [12] 1529 	mov	a,r4
      008564 F0               [24] 1530 	movx	@dptr,a
                                   1531 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      008565 8A 03            [24] 1532 	mov	ar3,r2
      008567                       1533 00125$:
      008567 C3               [12] 1534 	clr	c
      008568 EB               [12] 1535 	mov	a,r3
      008569 9C               [12] 1536 	subb	a,r4
      00856A 50 23            [24] 1537 	jnc	00111$
      00856C C0 05            [24] 1538 	push	ar5
      00856E C0 07            [24] 1539 	push	ar7
      008570 EB               [12] 1540 	mov	a,r3
      008571 2E               [12] 1541 	add	a, r6
      008572 FA               [12] 1542 	mov	r2,a
      008573 24 DA            [12] 1543 	add	a, #_usage_order
      008575 F8               [12] 1544 	mov	r0,a
      008576 E4               [12] 1545 	clr	a
      008577 34 0A            [12] 1546 	addc	a, #(_usage_order >> 8)
      008579 F9               [12] 1547 	mov	r1,a
      00857A 0A               [12] 1548 	inc	r2
      00857B EA               [12] 1549 	mov	a,r2
      00857C 33               [12] 1550 	rlc	a
      00857D 95 E0            [12] 1551 	subb	a,acc
      00857F FF               [12] 1552 	mov	r7,a
      008580 EA               [12] 1553 	mov	a,r2
      008581 12 87 F5         [24] 1554 	lcall	_ak820_outline_0136
      008584 12 38 BA         [24] 1555 	lcall	_ak820_outline_0167
      008587 F0               [24] 1556 	movx	@dptr,a
      008588 0B               [12] 1557 	inc	r3
      008589 D0 07            [24] 1558 	pop	ar7
      00858B D0 05            [24] 1559 	pop	ar5
      00858D 80 D8            [24] 1560 	sjmp	00125$
      00858F                       1561 00111$:
                                   1562 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      00858F 12 42 3C         [24] 1563 	lcall	_ak820_outline_0194
      008592 EC               [12] 1564 	mov	a,r4
      008593 F0               [24] 1565 	movx	@dptr,a
                                   1566 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      008594 90 0B 04         [24] 1567 	mov	dptr,#_owned_usage_key_pos_30001_438
      008597 E0               [24] 1568 	movx	a,@dptr
      008598 B5 04 02         [24] 1569 	cjne	a,ar4,00253$
      00859B 80 01            [24] 1570 	sjmp	00116$
      00859D                       1571 00253$:
      00859D 22               [24] 1572 	ret
      00859E                       1573 00116$:
                                   1574 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      00859E 90 0B 03         [24] 1575 	mov	dptr,#_owned_usage_key_count_10000_431
      0085A1 E0               [24] 1576 	movx	a,@dptr
      0085A2 FC               [12] 1577 	mov	r4,a
      0085A3 12 42 3C         [24] 1578 	lcall	_ak820_outline_0194
      0085A6 F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0085A7 EC               [12] 1581 	mov	a,r4
      0085A8 60 15            [24] 1582 	jz	00131$
      0085AA EC               [12] 1583 	mov	a,r4
      0085AB 2E               [12] 1584 	add	a, r6
      0085AC FE               [12] 1585 	mov	r6,a
      0085AD 1E               [12] 1586 	dec	r6
      0085AE EE               [12] 1587 	mov	a,r6
      0085AF 33               [12] 1588 	rlc	a
      0085B0 95 E0            [12] 1589 	subb	a,acc
      0085B2 FF               [12] 1590 	mov	r7,a
      0085B3 EE               [12] 1591 	mov	a,r6
      0085B4 12 87 F5         [24] 1592 	lcall	_ak820_outline_0136
      0085B7 24 A5            [12] 1593 	add	a,#0xa5
      0085B9 FE               [12] 1594 	mov	r6,a
      0085BA 33               [12] 1595 	rlc	a
      0085BB 95 E0            [12] 1596 	subb	a,acc
      0085BD 80 02            [24] 1597 	sjmp	00132$
      0085BF                       1598 00131$:
      0085BF 7E 00            [12] 1599 	mov	r6,#0x00
      0085C1                       1600 00132$:
      0085C1 90 0A FF         [24] 1601 	mov	dptr,#_owned_usage_key_code_10000_430
      0085C4 EE               [12] 1602 	mov	a,r6
      0085C5 F0               [24] 1603 	movx	@dptr,a
                                   1604 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0085C6 90 0B 02         [24] 1605 	mov	dptr,#_owned_usage_key_which_10000_431
      0085C9 E0               [24] 1606 	movx	a,@dptr
      0085CA 60 18            [24] 1607 	jz	00118$
      0085CC EE               [12] 1608 	mov	a,r6
      0085CD 60 0B            [24] 1609 	jz	00133$
      0085CF 8E 82            [24] 1610 	mov	dpl, r6
      0085D1 12 73 FD         [24] 1611 	lcall	_KEYCODE2CONSUMER
      0085D4 AD 82            [24] 1612 	mov	r5, dpl
      0085D6 AF 83            [24] 1613 	mov	r7, dph
      0085D8 80 04            [24] 1614 	sjmp	00134$
      0085DA                       1615 00133$:
      0085DA 7D 00            [12] 1616 	mov	r5,#0x00
      0085DC 7F 00            [12] 1617 	mov	r7,#0x00
      0085DE                       1618 00134$:
      0085DE 12 42 3C         [24] 1619 	lcall	_ak820_outline_0194
      0085E1 02 73 B1         [24] 1620 	ljmp	_host_consumer_send
      0085E4                       1621 00118$:
                                   1622 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0085E4 EE               [12] 1623 	mov	a,r6
      0085E5 60 22            [24] 1624 	jz	00135$
                                   1625 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      0085E7 BE A5 00         [24] 1626 	cjne	r6,#0xa5,00258$
      0085EA                       1627 00258$:
      0085EA 40 05            [24] 1628 	jc	00121$
      0085EC EE               [12] 1629 	mov	a,r6
      0085ED 24 58            [12] 1630 	add	a,#0xff - 0xa7
      0085EF 50 08            [24] 1631 	jnc	00122$
                                   1632 ;	free result
      0085F1                       1633 00121$:
      0085F1 90 0B 00         [24] 1634 	mov	dptr,#_owned_usage_key___200000090_20000_431
      0085F4 12 55 F6         [24] 1635 	lcall	_ak820_outline_0166
      0085F7 80 09            [24] 1636 	sjmp	00123$
      0085F9                       1637 00122$:
                                   1638 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      0085F9 74 DC            [12] 1639 	mov	a,#0xdc
      0085FB 2E               [12] 1640 	add	a, r6
      0085FC 90 0B 00         [24] 1641 	mov	dptr,#_owned_usage_key___200000090_20000_431
      0085FF 12 38 A6         [24] 1642 	lcall	_ak820_outline_0135
                                   1643 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008602                       1644 00123$:
      008602 90 0B 00         [24] 1645 	mov	dptr,#_owned_usage_key___200000090_20000_431
      008605 E0               [24] 1646 	movx	a,@dptr
      008606 FF               [12] 1647 	mov	r7,a
      008607 80 02            [24] 1648 	sjmp	00136$
      008609                       1649 00135$:
      008609 7F 00            [12] 1650 	mov	r7,#0x00
      00860B                       1651 00136$:
      00860B 7E 00            [12] 1652 	mov	r6,#0x00
      00860D 12 4A 39         [24] 1653 	lcall	_ak820_outline_0169
                                   1654 ;	quantum/action_util.c:208: }
      008610 02 73 82         [24] 1655 	ljmp	_host_system_send
                                   1656 ;------------------------------------------------------------
                                   1657 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1658 ;------------------------------------------------------------
                                   1659 ;projected     Allocated with name '_send_keyboard_report_projected_10001_450'
                                   1660 ;out           Allocated with name '_send_keyboard_report_out_10001_450'
                                   1661 ;base          Allocated with name '_send_keyboard_report_base_10001_450'
                                   1662 ;i             Allocated with name '_send_keyboard_report_i_20001_451'
                                   1663 ;overlay_key   Allocated with name '_send_keyboard_report_overlay_key_10002_452'
                                   1664 ;empty         Allocated with name '_send_keyboard_report_empty_50002_457'
                                   1665 ;present       Allocated with name '_send_keyboard_report_present_50002_457'
                                   1666 ;i             Allocated with name '_send_keyboard_report_i_60002_458'
                                   1667 ;i             Allocated with name '_send_keyboard_report_i_90002_465'
                                   1668 ;last_report   Allocated with name '_send_keyboard_report_last_report_10003_466'
                                   1669 ;changed       Allocated with name '_send_keyboard_report_changed_10003_466'
                                   1670 ;dest          Allocated with name '_send_keyboard_report_dest_10003_466'
                                   1671 ;src           Allocated with name '_send_keyboard_report_src_10003_466'
                                   1672 ;i             Allocated with name '_send_keyboard_report_i_20003_467'
                                   1673 ;------------------------------------------------------------
                                   1674 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1675 ;	-----------------------------------------
                                   1676 ;	 function send_keyboard_report
                                   1677 ;	-----------------------------------------
      008613                       1678 _send_keyboard_report:
                                   1679 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      008613 90 0E 7D         [24] 1680 	mov	dptr,#_real_mods
      008616 E0               [24] 1681 	movx	a,@dptr
      008617 FF               [12] 1682 	mov	r7,a
      008618 90 0E 7F         [24] 1683 	mov	dptr,#_actual_keyboard_report
      00861B F0               [24] 1684 	movx	@dptr,a
                                   1685 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      00861C 90 0E 7E         [24] 1686 	mov	dptr,#_weak_mods
      00861F E0               [24] 1687 	movx	a,@dptr
      008620 42 07            [12] 1688 	orl	ar7,a
      008622 90 0E 7F         [24] 1689 	mov	dptr,#_actual_keyboard_report
      008625 EF               [12] 1690 	mov	a,r7
      008626 F0               [24] 1691 	movx	@dptr,a
                                   1692 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008627 90 09 EE         [24] 1693 	mov	dptr,#_owned_weak_mods
      00862A E0               [24] 1694 	movx	a,@dptr
      00862B FE               [12] 1695 	mov	r6,a
      00862C 90 09 ED         [24] 1696 	mov	dptr,#_owned_mods
      00862F E0               [24] 1697 	movx	a,@dptr
      008630 4E               [12] 1698 	orl	a,r6
      008631 42 07            [12] 1699 	orl	ar7,a
      008633 90 0E 7F         [24] 1700 	mov	dptr,#_actual_keyboard_report
      008636 EF               [12] 1701 	mov	a,r7
      008637 F0               [24] 1702 	movx	@dptr,a
                                   1703 ;	quantum/action_util.c:458: ak820_key_override_sync(keyboard_report->mods, get_highest_layer(layer_state | default_layer_state));
      008638 90 0E 7B         [24] 1704 	mov	dptr,#_default_layer_state
      00863B E0               [24] 1705 	movx	a,@dptr
      00863C FE               [12] 1706 	mov	r6,a
      00863D 90 0E 7C         [24] 1707 	mov	dptr,#_layer_state
      008640 E0               [24] 1708 	movx	a,@dptr
      008641 42 06            [12] 1709 	orl	ar6,a
      008643 8E 82            [24] 1710 	mov	dpl, r6
      008645 C0 07            [24] 1711 	push	ar7
      008647 12 88 1A         [24] 1712 	lcall	_biton
      00864A E5 82            [12] 1713 	mov	a, dpl
      00864C D0 07            [24] 1714 	pop	ar7
      00864E 90 05 63         [24] 1715 	mov	dptr,#_ak820_key_override_sync_PARM_2
      008651 F0               [24] 1716 	movx	@dptr,a
      008652 8F 82            [24] 1717 	mov	dpl, r7
      008654 12 3F 42         [24] 1718 	lcall	_ak820_key_override_sync
                                   1719 ;	quantum/action_util.c:459: keyboard_report->mods = ak820_key_override_mods(keyboard_report->mods);
      008657 90 0E 7F         [24] 1720 	mov	dptr,#_actual_keyboard_report
      00865A E0               [24] 1721 	movx	a,@dptr
      00865B F5 82            [12] 1722 	mov	dpl,a
      00865D 12 41 C3         [24] 1723 	lcall	_ak820_key_override_mods
      008660 AF 82            [24] 1724 	mov	r7, dpl
      008662 90 0E 7F         [24] 1725 	mov	dptr,#_actual_keyboard_report
      008665 EF               [12] 1726 	mov	a,r7
      008666 F0               [24] 1727 	movx	@dptr,a
                                   1728 ;	quantum/action_util.c:482: uint8_t AK820_STATE_MEM *out = (uint8_t AK820_STATE_MEM *)&projected;
                                   1729 ;	quantum/action_util.c:483: const uint8_t AK820_STATE_MEM *base = (const uint8_t AK820_STATE_MEM *)keyboard_report;
                                   1730 ;	quantum/action_util.c:484: for (uint8_t i = 0; i < sizeof(projected); ++i) out[i] = base[i];
      008667 7F 00            [12] 1731 	mov	r7,#0x00
      008669                       1732 00125$:
      008669 BF 20 00         [24] 1733 	cjne	r7,#0x20,00261$
      00866C                       1734 00261$:
      00866C 50 19            [24] 1735 	jnc	00101$
      00866E EF               [12] 1736 	mov	a,r7
      00866F 24 06            [12] 1737 	add	a, #_send_keyboard_report_projected_10001_450
      008671 FD               [12] 1738 	mov	r5,a
      008672 E4               [12] 1739 	clr	a
      008673 34 0B            [12] 1740 	addc	a, #(_send_keyboard_report_projected_10001_450 >> 8)
      008675 FE               [12] 1741 	mov	r6,a
      008676 EF               [12] 1742 	mov	a,r7
      008677 24 7F            [12] 1743 	add	a, #_actual_keyboard_report
      008679 F5 82            [12] 1744 	mov	dpl,a
      00867B E4               [12] 1745 	clr	a
      00867C 34 0E            [12] 1746 	addc	a, #(_actual_keyboard_report >> 8)
      00867E F5 83            [12] 1747 	mov	dph,a
      008680 E0               [24] 1748 	movx	a,@dptr
      008681 12 87 E8         [24] 1749 	lcall	_ak820_outline_0106
      008684 0F               [12] 1750 	inc	r7
      008685 80 E2            [24] 1751 	sjmp	00125$
      008687                       1752 00101$:
                                   1753 ;	quantum/action_util.c:485: uint8_t overlay_key = ak820_key_override_key();
      008687 12 41 94         [24] 1754 	lcall	_ak820_key_override_key
                                   1755 ;	quantum/action_util.c:486: if (overlay_key) {
      00868A E5 82            [12] 1756 	mov	a,dpl
      00868C FF               [12] 1757 	mov	r7,a
      00868D 70 02            [24] 1758 	jnz	00263$
      00868F E1 1F            [12] 1759 	ajmp	00118$
      008691                       1760 00263$:
                                   1761 ;	quantum/action_util.c:488: if (keyboard_protocol && keymap_config.nkro) {
      008691 90 0E 6C         [24] 1762 	mov	dptr,#_keyboard_protocol
      008694 E0               [24] 1763 	movx	a,@dptr
      008695 60 2B            [24] 1764 	jz	00114$
      008697 90 0B 4D         [24] 1765 	mov	dptr,#_keymap_config
      00869A E0               [24] 1766 	movx	a,@dptr
      00869B 30 E7 24         [24] 1767 	jnb	acc.7,00114$
                                   1768 ;	quantum/action_util.c:489: projected.nkro.bits[overlay_key >> 3] |= 1u << (overlay_key & 7);
      00869E 12 88 0B         [24] 1769 	lcall	_ak820_outline_0174
      0086A1 24 08            [12] 1770 	add	a,#(_send_keyboard_report_projected_10001_450 + 0x0002)
      0086A3 FE               [12] 1771 	mov	r6,a
      0086A4 E4               [12] 1772 	clr	a
      0086A5 34 0B            [12] 1773 	addc	a, #((_send_keyboard_report_projected_10001_450 + 0x0002) >> 8)
      0086A7 FD               [12] 1774 	mov	r5,a
      0086A8 12 7D 3F         [24] 1775 	lcall	_ak820_outline_0046
      0086AB 80 02            [24] 1776 	sjmp	00267$
      0086AD                       1777 00266$:
      0086AD 25 E0            [12] 1778 	add	a,acc
      0086AF                       1779 00267$:
      0086AF D5 F0 FB         [24] 1780 	djnz	b,00266$
      0086B2 FC               [12] 1781 	mov	r4,a
      0086B3 8E 82            [24] 1782 	mov	dpl,r6
      0086B5 8D 83            [24] 1783 	mov	dph,r5
      0086B7 E0               [24] 1784 	movx	a,@dptr
      0086B8 42 04            [12] 1785 	orl	ar4,a
      0086BA 8E 82            [24] 1786 	mov	dpl,r6
      0086BC 8D 83            [24] 1787 	mov	dph,r5
      0086BE EC               [12] 1788 	mov	a,r4
      0086BF F0               [24] 1789 	movx	@dptr,a
      0086C0 80 5D            [24] 1790 	sjmp	00118$
      0086C2                       1791 00114$:
                                   1792 ;	quantum/action_util.c:493: uint8_t empty = 255;
      0086C2 90 0B 26         [24] 1793 	mov	dptr,#_send_keyboard_report_empty_50002_457
      0086C5 74 FF            [12] 1794 	mov	a,#0xff
      0086C7 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	quantum/action_util.c:494: bool present = false;
      0086C8 90 0B 27         [24] 1797 	mov	dptr,#_send_keyboard_report_present_50002_457
      0086CB E4               [12] 1798 	clr	a
      0086CC F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	quantum/action_util.c:495: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) {
      0086CD FE               [12] 1801 	mov	r6,a
      0086CE                       1802 00128$:
      0086CE BE 06 00         [24] 1803 	cjne	r6,#0x06,00268$
      0086D1                       1804 00268$:
      0086D1 50 23            [24] 1805 	jnc	00106$
                                   1806 ;	quantum/action_util.c:496: if (projected.keys[i] == overlay_key) present = true;
      0086D3 EE               [12] 1807 	mov	a,r6
      0086D4 12 87 C5         [24] 1808 	lcall	_ak820_outline_0071
      0086D7 E0               [24] 1809 	movx	a,@dptr
      0086D8 B5 07 06         [24] 1810 	cjne	a,ar7,00103$
      0086DB 90 0B 27         [24] 1811 	mov	dptr,#_send_keyboard_report_present_50002_457
      0086DE 74 01            [12] 1812 	mov	a,#0x01
      0086E0 F0               [24] 1813 	movx	@dptr,a
      0086E1                       1814 00103$:
                                   1815 ;	quantum/action_util.c:497: if (!projected.keys[i]) empty = i;
      0086E1 EE               [12] 1816 	mov	a,r6
      0086E2 24 08            [12] 1817 	add	a, #(_send_keyboard_report_projected_10001_450 + 0x0002)
      0086E4 FC               [12] 1818 	mov	r4,a
      0086E5 E4               [12] 1819 	clr	a
      0086E6 34 0B            [12] 1820 	addc	a, #((_send_keyboard_report_projected_10001_450 + 0x0002) >> 8)
      0086E8 FD               [12] 1821 	mov	r5,a
      0086E9 12 4A 06         [24] 1822 	lcall	_ak820_outline_0084
      0086EC 70 05            [24] 1823 	jnz	00129$
      0086EE 90 0B 26         [24] 1824 	mov	dptr,#_send_keyboard_report_empty_50002_457
      0086F1 EE               [12] 1825 	mov	a,r6
      0086F2 F0               [24] 1826 	movx	@dptr,a
      0086F3                       1827 00129$:
                                   1828 ;	quantum/action_util.c:495: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) {
      0086F3 0E               [12] 1829 	inc	r6
      0086F4 80 D8            [24] 1830 	sjmp	00128$
      0086F6                       1831 00106$:
                                   1832 ;	quantum/action_util.c:499: if (!present) {
      0086F6 90 0B 27         [24] 1833 	mov	dptr,#_send_keyboard_report_present_50002_457
      0086F9 E0               [24] 1834 	movx	a,@dptr
      0086FA 70 23            [24] 1835 	jnz	00118$
                                   1836 ;	quantum/action_util.c:500: if (empty != 255) projected.keys[empty] = overlay_key;
      0086FC 90 0B 26         [24] 1837 	mov	dptr,#_send_keyboard_report_empty_50002_457
      0086FF E0               [24] 1838 	movx	a,@dptr
      008700 FE               [12] 1839 	mov	r6,a
      008701 BE FF 02         [24] 1840 	cjne	r6,#0xff,00274$
      008704 80 08            [24] 1841 	sjmp	00167$
      008706                       1842 00274$:
      008706 EE               [12] 1843 	mov	a,r6
      008707 12 87 C5         [24] 1844 	lcall	_ak820_outline_0071
      00870A EF               [12] 1845 	mov	a,r7
      00870B F0               [24] 1846 	movx	@dptr,a
                                   1847 ;	quantum/action_util.c:501: else for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) projected.keys[i] = 1;
      00870C 80 11            [24] 1848 	sjmp	00118$
      00870E                       1849 00167$:
      00870E 7F 00            [12] 1850 	mov	r7,#0x00
      008710                       1851 00131$:
      008710 BF 06 00         [24] 1852 	cjne	r7,#0x06,00275$
      008713                       1853 00275$:
      008713 50 0A            [24] 1854 	jnc	00118$
      008715 EF               [12] 1855 	mov	a,r7
      008716 12 87 C5         [24] 1856 	lcall	_ak820_outline_0071
      008719 74 01            [12] 1857 	mov	a,#0x01
      00871B F0               [24] 1858 	movx	@dptr,a
      00871C 0F               [12] 1859 	inc	r7
      00871D 80 F1            [24] 1860 	sjmp	00131$
      00871F                       1861 00118$:
                                   1862 ;	quantum/action_util.c:517: bool changed = false;
      00871F 90 0B 48         [24] 1863 	mov	dptr,#_send_keyboard_report_changed_10003_466
      008722 E4               [12] 1864 	clr	a
      008723 F0               [24] 1865 	movx	@dptr,a
                                   1866 ;	quantum/action_util.c:519: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1867 ;	quantum/action_util.c:525: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008724 FF               [12] 1868 	mov	r7,a
      008725                       1869 00134$:
      008725 BF 20 00         [24] 1870 	cjne	r7,#0x20,00277$
      008728                       1871 00277$:
      008728 50 2B            [24] 1872 	jnc	00121$
                                   1873 ;	quantum/action_util.c:526: if (dest[i] != src[i]) {
      00872A EF               [12] 1874 	mov	a,r7
      00872B 24 28            [12] 1875 	add	a, #_send_keyboard_report_last_report_10003_466
      00872D FD               [12] 1876 	mov	r5,a
      00872E E4               [12] 1877 	clr	a
      00872F 34 0B            [12] 1878 	addc	a, #(_send_keyboard_report_last_report_10003_466 >> 8)
      008731 FE               [12] 1879 	mov	r6,a
      008732 12 4F 56         [24] 1880 	lcall	_ak820_outline_0081
      008735 EF               [12] 1881 	mov	a,r7
      008736 24 06            [12] 1882 	add	a, #_send_keyboard_report_projected_10001_450
      008738 F5 82            [12] 1883 	mov	dpl,a
      00873A E4               [12] 1884 	clr	a
      00873B 34 0B            [12] 1885 	addc	a, #(_send_keyboard_report_projected_10001_450 >> 8)
      00873D F5 83            [12] 1886 	mov	dph,a
      00873F E0               [24] 1887 	movx	a,@dptr
      008740 FB               [12] 1888 	mov	r3,a
      008741 EC               [12] 1889 	mov	a,r4
      008742 B5 03 02         [24] 1890 	cjne	a,ar3,00279$
      008745 80 0B            [24] 1891 	sjmp	00135$
      008747                       1892 00279$:
                                   1893 ;	quantum/action_util.c:527: dest[i] = src[i];
      008747 12 38 AB         [24] 1894 	lcall	_ak820_outline_0145
      00874A EB               [12] 1895 	mov	a,r3
      00874B F0               [24] 1896 	movx	@dptr,a
                                   1897 ;	quantum/action_util.c:528: changed = true;
      00874C 90 0B 48         [24] 1898 	mov	dptr,#_send_keyboard_report_changed_10003_466
      00874F 74 01            [12] 1899 	mov	a,#0x01
      008751 F0               [24] 1900 	movx	@dptr,a
      008752                       1901 00135$:
                                   1902 ;	quantum/action_util.c:525: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008752 0F               [12] 1903 	inc	r7
      008753 80 D0            [24] 1904 	sjmp	00134$
      008755                       1905 00121$:
                                   1906 ;	quantum/action_util.c:531: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      008755 90 0B 48         [24] 1907 	mov	dptr,#_send_keyboard_report_changed_10003_466
      008758 E0               [24] 1908 	movx	a,@dptr
      008759 60 09            [24] 1909 	jz	00136$
      00875B 90 0B 06         [24] 1910 	mov	dptr,#_send_keyboard_report_projected_10001_450
      00875E 75 F0 00         [24] 1911 	mov	b, #0x00
                                   1912 ;	quantum/action_util.c:540: }
      008761 02 72 F7         [24] 1913 	ljmp	_host_keyboard_send
      008764                       1914 00136$:
      008764 22               [24] 1915 	ret
                                   1916 ;------------------------------------------------------------
                                   1917 ;Allocation info for local variables in function 'get_mods'
                                   1918 ;------------------------------------------------------------
                                   1919 ;	quantum/action_util.c:546: uint8_t get_mods(void) {
                                   1920 ;	-----------------------------------------
                                   1921 ;	 function get_mods
                                   1922 ;	-----------------------------------------
      008765                       1923 _get_mods:
      008765 C0 07            [24] 1924 	push	ar7
                                   1925 ;	quantum/action_util.c:551: ;
      008767 90 09 ED         [24] 1926 	mov	dptr,#_owned_mods
      00876A E0               [24] 1927 	movx	a,@dptr
      00876B FF               [12] 1928 	mov	r7,a
      00876C 90 0E 7D         [24] 1929 	mov	dptr,#_real_mods
      00876F 12 81 95         [24] 1930 	lcall	_ak820_outline_0152
                                   1931 ;	quantum/action_util.c:552: }
      008772 D0 07            [24] 1932 	pop	ar7
      008774 22               [24] 1933 	ret
                                   1934 ;------------------------------------------------------------
                                   1935 ;Allocation info for local variables in function 'add_mods'
                                   1936 ;------------------------------------------------------------
                                   1937 ;mods          Allocated with name '_add_mods_mods_10000_474'
                                   1938 ;------------------------------------------------------------
                                   1939 ;	quantum/action_util.c:557: void add_mods(uint8_t mods) {
                                   1940 ;	-----------------------------------------
                                   1941 ;	 function clear_mods
                                   1942 ;	-----------------------------------------
      008775                       1943 _clear_mods:
                                   1944 ;	quantum/action_util.c:579: real_mods = 0;
      008775 90 0E 7D         [24] 1945 	mov	dptr,#_real_mods
      008778 E4               [12] 1946 	clr	a
      008779 F0               [24] 1947 	movx	@dptr,a
                                   1948 ;	quantum/action_util.c:580: }
      00877A 22               [24] 1949 	ret
                                   1950 ;------------------------------------------------------------
                                   1951 ;Allocation info for local variables in function 'get_weak_mods'
                                   1952 ;------------------------------------------------------------
                                   1953 ;	quantum/action_util.c:586: uint8_t get_weak_mods(void) {
                                   1954 ;	-----------------------------------------
                                   1955 ;	 function get_weak_mods
                                   1956 ;	-----------------------------------------
      00877B                       1957 _get_weak_mods:
      00877B C0 07            [24] 1958 	push	ar7
                                   1959 ;	quantum/action_util.c:591: ;
      00877D 90 09 EE         [24] 1960 	mov	dptr,#_owned_weak_mods
      008780 E0               [24] 1961 	movx	a,@dptr
      008781 FF               [12] 1962 	mov	r7,a
      008782 90 0E 7E         [24] 1963 	mov	dptr,#_weak_mods
      008785 12 81 95         [24] 1964 	lcall	_ak820_outline_0152
                                   1965 ;	quantum/action_util.c:592: }
      008788 D0 07            [24] 1966 	pop	ar7
      00878A 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'add_weak_mods'
                                   1970 ;------------------------------------------------------------
                                   1971 ;mods          Allocated with name '_add_weak_mods_mods_10000_484'
                                   1972 ;------------------------------------------------------------
                                   1973 ;	quantum/action_util.c:597: void add_weak_mods(uint8_t mods) {
                                   1974 ;	-----------------------------------------
                                   1975 ;	 function add_weak_mods
                                   1976 ;	-----------------------------------------
      00878B                       1977 _add_weak_mods:
      00878B E5 82            [12] 1978 	mov	a,dpl
      00878D 90 0B 49         [24] 1979 	mov	dptr,#_add_weak_mods_mods_10000_484
      008790 F0               [24] 1980 	movx	@dptr,a
                                   1981 ;	quantum/action_util.c:598: weak_mods |= mods;
      008791 E0               [24] 1982 	movx	a,@dptr
      008792 FF               [12] 1983 	mov	r7,a
      008793 90 0E 7E         [24] 1984 	mov	dptr,#_weak_mods
      008796 E0               [24] 1985 	movx	a,@dptr
      008797 4F               [12] 1986 	orl	a,r7
      008798 F0               [24] 1987 	movx	@dptr,a
                                   1988 ;	quantum/action_util.c:599: }
      008799 22               [24] 1989 	ret
                                   1990 ;------------------------------------------------------------
                                   1991 ;Allocation info for local variables in function 'del_weak_mods'
                                   1992 ;------------------------------------------------------------
                                   1993 ;mods          Allocated with name '_del_weak_mods_mods_10000_486'
                                   1994 ;------------------------------------------------------------
                                   1995 ;	quantum/action_util.c:604: void del_weak_mods(uint8_t mods) {
                                   1996 ;	-----------------------------------------
                                   1997 ;	 function del_weak_mods
                                   1998 ;	-----------------------------------------
      00879A                       1999 _del_weak_mods:
      00879A E5 82            [12] 2000 	mov	a,dpl
      00879C 90 0B 4A         [24] 2001 	mov	dptr,#_del_weak_mods_mods_10000_486
      00879F F0               [24] 2002 	movx	@dptr,a
                                   2003 ;	quantum/action_util.c:605: weak_mods &= ~mods;
      0087A0 E0               [24] 2004 	movx	a,@dptr
      0087A1 F4               [12] 2005 	cpl	a
      0087A2 FF               [12] 2006 	mov	r7,a
      0087A3 90 0E 7E         [24] 2007 	mov	dptr,#_weak_mods
      0087A6 E0               [24] 2008 	movx	a,@dptr
      0087A7 5F               [12] 2009 	anl	a,r7
      0087A8 F0               [24] 2010 	movx	@dptr,a
                                   2011 ;	quantum/action_util.c:606: }
      0087A9 22               [24] 2012 	ret
                                   2013 ;------------------------------------------------------------
                                   2014 ;Allocation info for local variables in function 'set_weak_mods'
                                   2015 ;------------------------------------------------------------
                                   2016 ;mods          Allocated with name '_set_weak_mods_mods_10000_488'
                                   2017 ;------------------------------------------------------------
                                   2018 ;	quantum/action_util.c:611: void set_weak_mods(uint8_t mods) {
                                   2019 ;	-----------------------------------------
                                   2020 ;	 function clear_weak_mods
                                   2021 ;	-----------------------------------------
      0087AA                       2022 _clear_weak_mods:
                                   2023 ;	quantum/action_util.c:619: weak_mods = 0;
      0087AA 90 0E 7E         [24] 2024 	mov	dptr,#_weak_mods
      0087AD E4               [12] 2025 	clr	a
      0087AE F0               [24] 2026 	movx	@dptr,a
                                   2027 ;	quantum/action_util.c:620: }
      0087AF 22               [24] 2028 	ret
                                   2029 ;------------------------------------------------------------
                                   2030 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   2031 ;------------------------------------------------------------
                                   2032 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_492'
                                   2033 ;------------------------------------------------------------
                                   2034 ;	quantum/action_util.c:702: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   2035 ;	-----------------------------------------
                                   2036 	.area CSEG    (CODE)
                                   2037 	.area CONST   (CODE)
                                   2038 	.area XINIT   (CODE)
      00CA3B                       2039 __xinit__real_mods:
      00CA3B 00                    2040 	.db #0x00	; 0
      00CA3C                       2041 __xinit__weak_mods:
      00CA3C 00                    2042 	.db #0x00	; 0
      00CA3D                       2043 __xinit__actual_keyboard_report:
      00CA3D 00                    2044 	.db #0x00	; 0
      00CA3E 00                    2045 	.db #0x00	; 0
      00CA3F 00                    2046 	.db #0x00	; 0
      00CA40 00                    2047 	.db #0x00	; 0
      00CA41 00                    2048 	.db #0x00	; 0
      00CA42 00                    2049 	.db #0x00	; 0
      00CA43 00                    2050 	.db #0x00	; 0
      00CA44 00                    2051 	.db #0x00	; 0
      00CA45 00                    2052 	.db 0x00
      00CA46 00                    2053 	.db 0x00
      00CA47 00                    2054 	.db 0x00
      00CA48 00                    2055 	.db 0x00
      00CA49 00                    2056 	.db 0x00
      00CA4A 00                    2057 	.db 0x00
      00CA4B 00                    2058 	.db 0x00
      00CA4C 00                    2059 	.db 0x00
      00CA4D 00                    2060 	.db 0x00
      00CA4E 00                    2061 	.db 0x00
      00CA4F 00                    2062 	.db 0x00
      00CA50 00                    2063 	.db 0x00
      00CA51 00                    2064 	.db 0x00
      00CA52 00                    2065 	.db 0x00
      00CA53 00                    2066 	.db 0x00
      00CA54 00                    2067 	.db 0x00
      00CA55 00                    2068 	.db 0x00
      00CA56 00                    2069 	.db 0x00
      00CA57 00                    2070 	.db 0x00
      00CA58 00                    2071 	.db 0x00
      00CA59 00                    2072 	.db 0x00
      00CA5A 00                    2073 	.db 0x00
      00CA5B 00                    2074 	.db 0x00
      00CA5C 00                    2075 	.db 0x00
                                   2076 	.area CABS    (ABS,CODE)
                                   2077 
                                   2078 ; Experimental exact instruction outlining.
                                   2079 	.globl _ak820_outline_0021
                                   2080 	.globl _ak820_outline_0033
                                   2081 	.globl _ak820_outline_0046
                                   2082 	.globl _ak820_outline_0061
                                   2083 	.globl _ak820_outline_0065
                                   2084 	.globl _ak820_outline_0067
                                   2085 	.globl _ak820_outline_0068
                                   2086 	.globl _ak820_outline_0071
                                   2087 	.globl _ak820_outline_0073
                                   2088 	.globl _ak820_outline_0078
                                   2089 	.globl _ak820_outline_0081
                                   2090 	.globl _ak820_outline_0084
                                   2091 	.globl _ak820_outline_0106
                                   2092 	.globl _ak820_outline_0114
                                   2093 	.globl _ak820_outline_0115
                                   2094 	.globl _ak820_outline_0125
                                   2095 	.globl _ak820_outline_0129
                                   2096 	.globl _ak820_outline_0135
                                   2097 	.globl _ak820_outline_0136
                                   2098 	.globl _ak820_outline_0143
                                   2099 	.globl _ak820_outline_0145
                                   2100 	.globl _ak820_outline_0150
                                   2101 	.globl _ak820_outline_0152
                                   2102 	.globl _ak820_outline_0166
                                   2103 	.globl _ak820_outline_0167
                                   2104 	.globl _ak820_outline_0169
                                   2105 	.globl _ak820_outline_0174
                                   2106 	.globl _ak820_outline_0175
                                   2107 	.globl _ak820_outline_0186
                                   2108 	.globl _ak820_outline_0194
                                   2109 
                                   2110 	.area CSEG (CODE)
                                   2111 ; function ak820_outline_0033
      0087B0                       2112 _ak820_outline_0033:
      0087B0 EF               [12] 2113 	mov	a,r7
      0087B1 24 FF            [12] 2114 	add	a,#_key_refs
      0087B3 FD               [12] 2115 	mov	r5,a
      0087B4 E4               [12] 2116 	clr	a
      0087B5 34 09            [12] 2117 	addc	a,#(_key_refs>>8)
      0087B7 FE               [12] 2118 	mov	r6,a
      0087B8 8D 82            [24] 2119 	mov	dpl,r5
      0087BA 8E 83            [24] 2120 	mov	dph,r6
      0087BC E0               [24] 2121 	movx	a,@dptr
      0087BD 22               [24] 2122 	ret
                                   2123 
                                   2124 	.area CSEG (CODE)
                                   2125 ; function ak820_outline_0067
      0087BE                       2126 _ak820_outline_0067:
      0087BE 89 82            [24] 2127 	mov	dpl,r1
      0087C0 8A 83            [24] 2128 	mov	dph,r2
      0087C2 E8               [12] 2129 	mov	a,r0
      0087C3 F0               [24] 2130 	movx	@dptr,a
      0087C4 22               [24] 2131 	ret
                                   2132 
                                   2133 	.area CSEG (CODE)
                                   2134 ; function ak820_outline_0071
      0087C5                       2135 _ak820_outline_0071:
      0087C5 24 08            [12] 2136 	add	a,#(_send_keyboard_report_projected_10001_450+0x0002)
      0087C7 F5 82            [12] 2137 	mov	dpl,a
      0087C9 E4               [12] 2138 	clr	a
      0087CA 34 0B            [12] 2139 	addc	a,#((_send_keyboard_report_projected_10001_450+0x0002)>>8)
      0087CC F5 83            [12] 2140 	mov	dph,a
      0087CE 22               [24] 2141 	ret
                                   2142 
                                   2143 	.area CSEG (CODE)
                                   2144 ; function ak820_outline_0073
      0087CF                       2145 _ak820_outline_0073:
      0087CF 24 DA            [12] 2146 	add	a,#_usage_order
      0087D1 F5 82            [12] 2147 	mov	dpl,a
      0087D3 E4               [12] 2148 	clr	a
      0087D4 34 0A            [12] 2149 	addc	a,#(_usage_order>>8)
      0087D6 F5 83            [12] 2150 	mov	dph,a
      0087D8 22               [24] 2151 	ret
                                   2152 
                                   2153 	.area CSEG (CODE)
                                   2154 ; function ak820_outline_0078
      0087D9                       2155 _ak820_outline_0078:
      0087D9 EB               [12] 2156 	mov	a,r3
      0087DA 24 BC            [12] 2157 	add	a,#_usage_refs
      0087DC F9               [12] 2158 	mov	r1,a
      0087DD E4               [12] 2159 	clr	a
      0087DE 34 0A            [12] 2160 	addc	a,#(_usage_refs>>8)
      0087E0 FA               [12] 2161 	mov	r2,a
      0087E1 89 82            [24] 2162 	mov	dpl,r1
      0087E3 8A 83            [24] 2163 	mov	dph,r2
      0087E5 E0               [24] 2164 	movx	a,@dptr
      0087E6 F8               [12] 2165 	mov	r0,a
      0087E7 22               [24] 2166 	ret
                                   2167 
                                   2168 	.area CSEG (CODE)
                                   2169 ; function ak820_outline_0106
      0087E8                       2170 _ak820_outline_0106:
      0087E8 8D 82            [24] 2171 	mov	dpl,r5
      0087EA 8E 83            [24] 2172 	mov	dph,r6
      0087EC F0               [24] 2173 	movx	@dptr,a
      0087ED 22               [24] 2174 	ret
                                   2175 
                                   2176 	.area CSEG (CODE)
                                   2177 ; function ak820_outline_0125
      0087EE                       2178 _ak820_outline_0125:
      0087EE F0               [24] 2179 	movx	@dptr,a
      0087EF E0               [24] 2180 	movx	a,@dptr
      0087F0 FF               [12] 2181 	mov	r7,a
      0087F1 90 09 F7         [24] 2182 	mov	dptr,#_change_owned_PARM_2
      0087F4 22               [24] 2183 	ret
                                   2184 
                                   2185 	.area CSEG (CODE)
                                   2186 ; function ak820_outline_0136
      0087F5                       2187 _ak820_outline_0136:
      0087F5 24 DA            [12] 2188 	add	a,#_usage_order
      0087F7 F5 82            [12] 2189 	mov	dpl,a
      0087F9 EF               [12] 2190 	mov	a,r7
      0087FA 34 0A            [12] 2191 	addc	a,#(_usage_order>>8)
      0087FC F5 83            [12] 2192 	mov	dph,a
      0087FE E0               [24] 2193 	movx	a,@dptr
      0087FF 22               [24] 2194 	ret
                                   2195 
                                   2196 	.area CSEG (CODE)
                                   2197 ; function ak820_outline_0143
      008800                       2198 _ak820_outline_0143:
      008800 F0               [24] 2199 	movx	@dptr,a
      008801 E0               [24] 2200 	movx	a,@dptr
      008802 FF               [12] 2201 	mov	r7,a
      008803 90 09 F3         [24] 2202 	mov	dptr,#_ak820_macro_change_PARM_2
      008806 F0               [24] 2203 	movx	@dptr,a
      008807 90 09 F4         [24] 2204 	mov	dptr,#_ak820_macro_change_PARM_3
      00880A 22               [24] 2205 	ret
                                   2206 
                                   2207 	.area CSEG (CODE)
                                   2208 ; function ak820_outline_0174
      00880B                       2209 _ak820_outline_0174:
      00880B EF               [12] 2210 	mov	a,r7
      00880C C4               [12] 2211 	swap	a
      00880D 23               [12] 2212 	rl	a
      00880E 54 1F            [12] 2213 	anl	a,#0x1f
      008810 22               [24] 2214 	ret
                                   2215 
                                   2216 	.area CSEG (CODE)
                                   2217 ; function ak820_outline_0186
      008811                       2218 _ak820_outline_0186:
      008811 90 08 6D         [24] 2219 	mov	dptr,#_add_key_to_report_PARM_2
      008814 EF               [12] 2220 	mov	a,r7
      008815 F0               [24] 2221 	movx	@dptr,a
      008816 90 0E 7F         [24] 2222 	mov	dptr,#_actual_keyboard_report
      008819 22               [24] 2223 	ret
