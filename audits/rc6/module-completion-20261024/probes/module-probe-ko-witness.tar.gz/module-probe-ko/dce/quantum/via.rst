                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000048                        553 _raw_hid_receive_sloc0_1_0:
      000048                        554 	.ds 4
      00004C                        555 _raw_hid_receive_sloc1_1_0:
      00004C                        556 	.ds 1
      00004D                        557 _raw_hid_receive_sloc2_1_0:
      00004D                        558 	.ds 1
      00004E                        559 _raw_hid_receive_sloc3_1_0:
      00004E                        560 	.ds 2
      000050                        561 _raw_hid_receive_sloc4_1_0:
      000050                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002C                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002C                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000CE7                        589 _via_eeprom_set_valid_valid_10000_611:
      000CE7                        590 	.ds 1
      000CE8                        591 _via_set_layout_options_value_10000_627:
      000CE8                        592 	.ds 4
      000CEC                        593 _process_record_via_PARM_2:
      000CEC                        594 	.ds 3
      000CEF                        595 _process_record_via_keycode_10000_629:
      000CEF                        596 	.ds 2
      000CF1                        597 _raw_hid_receive_kb_PARM_2:
      000CF1                        598 	.ds 1
      000CF2                        599 _raw_hid_receive_kb_data_10000_635:
      000CF2                        600 	.ds 3
      000CF5                        601 _raw_hid_receive_PARM_2:
      000CF5                        602 	.ds 1
      000CF6                        603 _raw_hid_receive_packet_10000_637:
      000CF6                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00AE38                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00AE38 90 00 25         [24]  658 	mov	dptr,#0x0025
      00AE3B 75 F0 00         [24]  659 	mov	b, #0x00
      00AE3E 12 47 36         [24]  660 	lcall	_eeprom_read_byte
      00AE41 AF 82            [24]  661 	mov	r7, dpl
      00AE43 BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00AE46 90 00 26         [24]  663 	mov	dptr,#0x0026
      00AE49 75 F0 00         [24]  664 	mov	b, #0x00
      00AE4C 12 47 36         [24]  665 	lcall	_eeprom_read_byte
      00AE4F AF 82            [24]  666 	mov	r7, dpl
      00AE51 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00AE54 90 00 27         [24]  668 	mov	dptr,#0x0027
      00AE57 75 F0 00         [24]  669 	mov	b, #0x00
      00AE5A 12 47 36         [24]  670 	lcall	_eeprom_read_byte
      00AE5D AF 82            [24]  671 	mov	r7, dpl
      00AE5F BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00AE62 80 04            [24]  673 	sjmp	00104$
      00AE64                        674 00126$:
      00AE64                        675 00103$:
                                    676 ;	assignBit
      00AE64 C2 2C            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00AE66 80 02            [24]  678 	sjmp	00105$
      00AE68                        679 00104$:
                                    680 ;	assignBit
      00AE68 D2 2C            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00AE6A                        682 00105$:
      00AE6A A2 2C            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00AE6C 12 38 B5         [24]  684 	lcall	_ak820_outline_0154
                                    685 ;	quantum/via.c:104: }
      00AE6F 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_611'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_612'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_612'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_612'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00AE70                        699 _via_eeprom_set_valid:
      00AE70 E5 82            [12]  700 	mov	a,dpl
      00AE72 90 0C E7         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AE75 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00AE76 E0               [24]  704 	movx	a,@dptr
      00AE77 60 04            [24]  705 	jz	00103$
      00AE79 7F 03            [12]  706 	mov	r7,#0x03
      00AE7B 80 02            [24]  707 	sjmp	00104$
      00AE7D                        708 00103$:
      00AE7D 7F FF            [12]  709 	mov	r7,#0xff
      00AE7F                        710 00104$:
      00AE7F 90 07 09         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AE82 EF               [12]  712 	mov	a,r7
      00AE83 F0               [24]  713 	movx	@dptr,a
      00AE84 90 00 25         [24]  714 	mov	dptr,#0x0025
      00AE87 75 F0 00         [24]  715 	mov	b, #0x00
      00AE8A 12 54 9B         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00AE8D 90 0C E7         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AE90 E0               [24]  719 	movx	a,@dptr
      00AE91 60 04            [24]  720 	jz	00105$
      00AE93 7F 20            [12]  721 	mov	r7,#0x20
      00AE95 80 02            [24]  722 	sjmp	00106$
      00AE97                        723 00105$:
      00AE97 7F FF            [12]  724 	mov	r7,#0xff
      00AE99                        725 00106$:
      00AE99 90 07 09         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AE9C EF               [12]  727 	mov	a,r7
      00AE9D F0               [24]  728 	movx	@dptr,a
      00AE9E 90 00 26         [24]  729 	mov	dptr,#0x0026
      00AEA1 75 F0 00         [24]  730 	mov	b, #0x00
      00AEA4 12 54 9B         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00AEA7 90 0C E7         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AEAA E0               [24]  734 	movx	a,@dptr
      00AEAB 60 04            [24]  735 	jz	00107$
      00AEAD 7F 08            [12]  736 	mov	r7,#0x08
      00AEAF 80 02            [24]  737 	sjmp	00108$
      00AEB1                        738 00107$:
      00AEB1 7F FF            [12]  739 	mov	r7,#0xff
      00AEB3                        740 00108$:
      00AEB3 90 07 09         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AEB6 EF               [12]  742 	mov	a,r7
      00AEB7 F0               [24]  743 	movx	@dptr,a
      00AEB8 90 00 27         [24]  744 	mov	dptr,#0x0027
      00AEBB 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00AEBE 02 54 9B         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00AEC1                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00AEC1 D1 E4            [12]  757 	acall	_via_get_layout_options
      00AEC3 D1 FC            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00AEC5 D1 38            [12]  760 	acall	_via_eeprom_is_valid
      00AEC7 E5 82            [12]  761 	mov	a, dpl
      00AEC9 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00AECB 02 44 E5         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00AECE                        766 00103$:
      00AECE 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00AECF                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00AECF 75 82 00         [24]  777 	mov	dpl, #0x00
      00AED2 D1 70            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00AED4 12 98 D0         [24]  780 	lcall	_ak820_outline_0163
      00AED7 D1 FD            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00AED9 12 8F 15         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00AEDC 12 93 C5         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00AEDF 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00AEE2 C1 70            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00AEE4                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00AEE4 90 00 28         [24]  799 	mov	dptr,#0x0028
      00AEE7 75 F0 00         [24]  800 	mov	b, #0x00
      00AEEA 12 47 36         [24]  801 	lcall	_eeprom_read_byte
      00AEED AF 82            [24]  802 	mov	r7, dpl
      00AEEF 7E 00            [12]  803 	mov	r6,#0x00
      00AEF1 7D 00            [12]  804 	mov	r5,#0x00
      00AEF3 7C 00            [12]  805 	mov	r4,#0x00
      00AEF5 12 4A 39         [24]  806 	lcall	_ak820_outline_0169
      00AEF8 8D F0            [24]  807 	mov	b, r5
      00AEFA EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00AEFB 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_624'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00AEFC                        820 _via_set_layout_options_kb:
      00AEFC 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_627'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00AEFD                        831 _via_set_layout_options:
      00AEFD 12 98 C8         [24]  832 	lcall	_ak820_outline_0128
      00AF00 90 0C E8         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_627
      00AF03 12 98 B6         [24]  834 	lcall	_ak820_outline_0050
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00AF06 90 0C E8         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_627
      00AF09 E0               [24]  837 	movx	a,@dptr
      00AF0A 90 07 09         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AF0D F0               [24]  839 	movx	@dptr,a
      00AF0E 90 00 28         [24]  840 	mov	dptr,#0x0028
      00AF11 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00AF14 02 54 9B         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_629'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_634'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00AF17                        855 _process_record_via:
      00AF17 12 38 86         [24]  856 	lcall	_ak820_outline_0114
      00AF1A 90 0C EF         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_629
      00AF1D 12 38 8B         [24]  858 	lcall	_ak820_outline_0115
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00AF20 90 0C EC         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00AF23 12 55 AA         [24]  861 	lcall	_ak820_outline_0013
      00AF26 74 05            [12]  862 	mov	a,#0x05
      00AF28 12 38 BF         [24]  863 	lcall	_ak820_outline_0171
      00AF2B 12 73 F6         [24]  864 	lcall	_ak820_outline_0063
      00AF2E 12 C2 3E         [24]  865 	lcall	__gptrget
      00AF31 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00AF33 90 0C EF         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_629
      00AF36 12 4E EC         [24]  869 	lcall	_ak820_outline_0010
      00AF39 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00AF3B 2D               [12]  871 	add	a,r5
      00AF3C 50 12            [24]  872 	jnc	00105$
      00AF3E C3               [12]  873 	clr	c
      00AF3F 74 7F            [12]  874 	mov	a,#0x7f
      00AF41 9C               [12]  875 	subb	a,r4
      00AF42 74 77            [12]  876 	mov	a,#0x77
      00AF44 9D               [12]  877 	subb	a,r5
      00AF45 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00AF47 8E 82            [24]  882 	mov	dpl, r6
      00AF49 12 93 EB         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00AF4C 75 82 00         [24]  885 	mov	dpl, #0x00
      00AF4F 22               [24]  886 	ret
      00AF50                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00AF50 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00AF53 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_635'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_636'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00AF54                        903 _raw_hid_receive_kb:
      00AF54 12 49 D5         [24]  904 	lcall	_ak820_outline_0041
      00AF57 90 0C F2         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AF5A 12 38 21         [24]  906 	lcall	_ak820_outline_0022
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00AF5D 90 0C F2         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AF60 12 55 84         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00AF63 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00AF65 02 C2 03         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_637'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_638'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_638'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_638'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_644'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_652'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_653'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_656'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_657'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_658'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_663'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_665'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_674'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_675'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_675'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_680'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_680'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_687'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_687'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_692'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00AF68                        950 _raw_hid_receive:
      00AF68 12 49 D5         [24]  951 	lcall	_ak820_outline_0041
      00AF6B 90 0C F6         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AF6E 12 38 21         [24]  953 	lcall	_ak820_outline_0022
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00AF71 90 0C F6         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AF74 12 38 39         [24]  956 	lcall	_ak820_outline_0057
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00AF77 74 01            [12]  958 	mov	a,#0x01
      00AF79 12 4A 3E         [24]  959 	lcall	_ak820_outline_0172
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00AF7C 90 0C F5         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00AF7F E0               [24]  962 	movx	a,@dptr
      00AF80 FB               [12]  963 	mov	r3,a
      00AF81 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00AF84 80 01            [24]  965 	sjmp	00102$
      00AF86                        966 00520$:
      00AF86 22               [24]  967 	ret
      00AF87                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AF87 90 0E DB         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00AF8A E0               [24]  971 	movx	a,@dptr
      00AF8B 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AF8D 12 38 6E         [24]  974 	lcall	_ak820_outline_0105
      00AF90 FA               [12]  975 	mov	r2,a
      00AF91 BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00AF94 80 01            [24]  977 	sjmp	00104$
      00AF96                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00AF96 22               [24]  980 	ret
      00AF97                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AF97 12 4A 06         [24]  983 	lcall	_ak820_outline_0084
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AF9A FA               [12]  985 	mov	r2,a
      00AF9B 60 21            [24]  986 	jz	00114$
      00AF9D BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00AFA0 80 1C            [24]  988 	sjmp	00114$
      00AFA2                        989 00524$:
      00AFA2 BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00AFA5 80 17            [24]  991 	sjmp	00114$
      00AFA7                        992 00525$:
      00AFA7 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00AFAA 80 12            [24]  994 	sjmp	00114$
      00AFAC                        995 00526$:
      00AFAC BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00AFAF 80 0D            [24]  997 	sjmp	00114$
      00AFB1                        998 00527$:
      00AFB1 BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00AFB4 80 08            [24] 1000 	sjmp	00114$
      00AFB6                       1001 00528$:
      00AFB6 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00AFB9 80 03            [24] 1003 	sjmp	00530$
      00AFBB                       1004 00529$:
      00AFBB 02 B4 CB         [24] 1005 	ljmp	00171$
      00AFBE                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00AFBE                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00AFBE 12 38 6E         [24] 1010 	lcall	_ak820_outline_0105
      00AFC1 FA               [12] 1011 	mov	r2,a
      00AFC2 BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00AFC5 80 68            [24] 1013 	sjmp	00115$
      00AFC7                       1014 00531$:
      00AFC7 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00AFCA 80 6F            [24] 1016 	sjmp	00116$
      00AFCC                       1017 00532$:
      00AFCC BA 03 03         [24] 1018 	cjne	r2,#0x03,00533$
      00AFCF 02 B0 F6         [24] 1019 	ljmp	00125$
      00AFD2                       1020 00533$:
      00AFD2 BA 04 03         [24] 1021 	cjne	r2,#0x04,00534$
      00AFD5 02 B1 87         [24] 1022 	ljmp	00129$
      00AFD8                       1023 00534$:
      00AFD8 BA 05 03         [24] 1024 	cjne	r2,#0x05,00535$
      00AFDB 02 B1 C3         [24] 1025 	ljmp	00130$
      00AFDE                       1026 00535$:
      00AFDE BA 06 03         [24] 1027 	cjne	r2,#0x06,00536$
      00AFE1 02 B2 2B         [24] 1028 	ljmp	00135$
      00AFE4                       1029 00536$:
      00AFE4 BA 07 03         [24] 1030 	cjne	r2,#0x07,00537$
      00AFE7 02 B2 3C         [24] 1031 	ljmp	00136$
      00AFEA                       1032 00537$:
      00AFEA BA 08 03         [24] 1033 	cjne	r2,#0x08,00538$
      00AFED 02 B2 56         [24] 1034 	ljmp	00137$
      00AFF0                       1035 00538$:
      00AFF0 BA 09 03         [24] 1036 	cjne	r2,#0x09,00539$
      00AFF3 02 B2 70         [24] 1037 	ljmp	00138$
      00AFF6                       1038 00539$:
      00AFF6 BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00AFF9 02 B4 5B         [24] 1040 	ljmp	00161$
      00AFFC                       1041 00540$:
      00AFFC BA 0C 03         [24] 1042 	cjne	r2,#0x0c,00541$
      00AFFF 02 B2 8A         [24] 1043 	ljmp	00139$
      00B002                       1044 00541$:
      00B002 BA 0D 03         [24] 1045 	cjne	r2,#0x0d,00542$
      00B005 02 B2 AA         [24] 1046 	ljmp	00140$
      00B008                       1047 00542$:
      00B008 BA 0E 03         [24] 1048 	cjne	r2,#0x0e,00543$
      00B00B 02 B2 D2         [24] 1049 	ljmp	00141$
      00B00E                       1050 00543$:
      00B00E BA 0F 03         [24] 1051 	cjne	r2,#0x0f,00544$
      00B011 02 B3 18         [24] 1052 	ljmp	00144$
      00B014                       1053 00544$:
      00B014 BA 10 02         [24] 1054 	cjne	r2,#0x10,00545$
      00B017 61 86            [12] 1055 	ajmp	00151$
      00B019                       1056 00545$:
      00B019 BA 11 02         [24] 1057 	cjne	r2,#0x11,00546$
      00B01C 61 9E            [12] 1058 	ajmp	00154$
      00B01E                       1059 00546$:
      00B01E BA 12 02         [24] 1060 	cjne	r2,#0x12,00547$
      00B021 61 BE            [12] 1061 	ajmp	00155$
      00B023                       1062 00547$:
      00B023 BA 13 02         [24] 1063 	cjne	r2,#0x13,00548$
      00B026 81 04            [12] 1064 	ajmp	00158$
      00B028                       1065 00548$:
      00B028 BA FE 02         [24] 1066 	cjne	r2,#0xfe,00549$
      00B02B 81 9A            [12] 1067 	ajmp	00168$
      00B02D                       1068 00549$:
      00B02D 81 B3            [12] 1069 	ajmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00B02F                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00B02F 12 38 A1         [24] 1073 	lcall	_ak820_outline_0134
      00B032 E4               [12] 1074 	clr	a
      00B033 12 49 CD         [24] 1075 	lcall	_ak820_outline_0027
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00B036 74 09            [12] 1077 	mov	a,#0x09
      00B038 F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00B039 81 CB            [12] 1080 	ajmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00B03B                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00B03B 12 4A 06         [24] 1084 	lcall	_ak820_outline_0084
      00B03E FA               [12] 1085 	mov	r2,a
      00B03F BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00B042 80 0C            [24] 1087 	sjmp	00117$
      00B044                       1088 00550$:
      00B044 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00B047 80 31            [24] 1090 	sjmp	00118$
      00B049                       1091 00551$:
      00B049 BA 03 02         [24] 1092 	cjne	r2,#0x03,00552$
      00B04C 01 B4            [24] 1093 	ajmp	00119$
      00B04E                       1094 00552$:
      00B04E 01 DC            [24] 1095 	ajmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00B050                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00B050 12 4F C3         [24] 1099 	lcall	_timer_read32
      00B053 85 82 48         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00B056 85 83 49         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00B059 85 F0 4A         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00B05C F5 4B            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00B05E 12 38 74         [24] 1105 	lcall	_ak820_outline_0107
      00B061 A3               [24] 1106 	inc	dptr
      00B062 E5 4B            [12] 1107 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00B064 12 49 CD         [24] 1108 	lcall	_ak820_outline_0027
                                   1109 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00B067 A3               [24] 1110 	inc	dptr
      00B068 E5 4A            [12] 1111 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00B06A 12 49 CD         [24] 1112 	lcall	_ak820_outline_0027
                                   1113 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00B06D A3               [24] 1114 	inc	dptr
      00B06E A3               [24] 1115 	inc	dptr
      00B06F E5 49            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B071 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00B072 12 49 C3         [24] 1119 	lcall	_ak820_outline_0012
      00B075 E5 48            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00B077 F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00B078 81 CB            [12] 1123 	ajmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00B07A                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00B07A C0 03            [24] 1127 	push	ar3
      00B07C C0 07            [24] 1128 	push	ar7
      00B07E C0 06            [24] 1129 	push	ar6
      00B080 C0 03            [24] 1130 	push	ar3
      00B082 12 AE E4         [24] 1131 	lcall	_via_get_layout_options
      00B085 85 82 48         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00B088 85 83 49         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00B08B 85 F0 4A         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00B08E F5 4B            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00B090 D0 03            [24] 1136 	pop	ar3
      00B092 D0 06            [24] 1137 	pop	ar6
      00B094 D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00B096 12 38 74         [24] 1140 	lcall	_ak820_outline_0107
      00B099 A3               [24] 1141 	inc	dptr
      00B09A E5 4B            [12] 1142 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00B09C 12 49 CD         [24] 1143 	lcall	_ak820_outline_0027
                                   1144 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00B09F A3               [24] 1145 	inc	dptr
      00B0A0 E5 4A            [12] 1146 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00B0A2 12 49 CD         [24] 1147 	lcall	_ak820_outline_0027
                                   1148 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00B0A5 A3               [24] 1149 	inc	dptr
      00B0A6 A3               [24] 1150 	inc	dptr
      00B0A7 E5 49            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B0A9 F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00B0AA 12 49 C3         [24] 1154 	lcall	_ak820_outline_0012
      00B0AD E5 48            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00B0AF F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00B0B0 D0 03            [24] 1158 	pop	ar3
      00B0B2 81 CB            [12] 1159 	ajmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00B0B4                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00B0B4 90 0E DA         [24] 1163 	mov	dptr,#_vial_unlocked
      00B0B7 E0               [24] 1164 	movx	a,@dptr
      00B0B8 70 02            [24] 1165 	jnz	00553$
      00B0BA 81 CB            [12] 1166 	ajmp	00171$
      00B0BC                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00B0BC 7A 01            [12] 1169 	mov	r2,#0x01
      00B0BE 79 00            [12] 1170 	mov	r1,#0x00
      00B0C0                       1171 00173$:
      00B0C0 B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00B0C3                       1173 00554$:
      00B0C3 40 02            [24] 1174 	jc	00555$
      00B0C5 81 CB            [12] 1175 	ajmp	00171$
      00B0C7                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00B0C7 89 82            [24] 1178 	mov	dpl, r1
      00B0C9 12 60 1D         [24] 1179 	lcall	_matrix_get_row
      00B0CC A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00B0CE EA               [12] 1182 	mov	a,r2
      00B0CF 2C               [12] 1183 	add	a, r4
      00B0D0 F5 82            [12] 1184 	mov	dpl,a
      00B0D2 E4               [12] 1185 	clr	a
      00B0D3 3D               [12] 1186 	addc	a, r5
      00B0D4 F5 83            [12] 1187 	mov	dph,a
      00B0D6 0A               [12] 1188 	inc	r2
      00B0D7 E8               [12] 1189 	mov	a,r0
      00B0D8 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00B0D9 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00B0DA 80 E4            [24] 1194 	sjmp	00173$
      00B0DC                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00B0DC 12 4F 4F         [24] 1197 	lcall	_ak820_outline_0080
      00B0DF 90 0C F1         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B0E2 12 B4 F9         [24] 1199 	lcall	_ak820_outline_0047
      00B0E5 C0 07            [24] 1200 	push	ar7
      00B0E7 C0 06            [24] 1201 	push	ar6
      00B0E9 C0 03            [24] 1202 	push	ar3
      00B0EB 12 AF 54         [24] 1203 	lcall	_raw_hid_receive_kb
      00B0EE D0 03            [24] 1204 	pop	ar3
      00B0F0 D0 06            [24] 1205 	pop	ar6
      00B0F2 D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00B0F4 81 CB            [12] 1208 	ajmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00B0F6                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00B0F6 12 4A 06         [24] 1212 	lcall	_ak820_outline_0084
      00B0F9 FA               [12] 1213 	mov	r2,a
      00B0FA BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00B0FD 80 02            [24] 1215 	sjmp	00557$
      00B0FF                       1216 00556$:
      00B0FF 21 6D            [12] 1217 	ajmp	00127$
      00B101                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00B101 C0 03            [24] 1220 	push	ar3
      00B103 12 38 31         [24] 1221 	lcall	_ak820_outline_0037
      00B106 F8               [12] 1222 	mov	r0,a
      00B107 79 00            [12] 1223 	mov	r1,#0x00
      00B109 7B 00            [12] 1224 	mov	r3,#0x00
      00B10B 88 4B            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00B10D 8B 48            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00B10F 8B 49            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00B111 8B 4A            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00B113 12 B4 F0         [24] 1229 	lcall	_ak820_outline_0018
      00B116 F8               [12] 1230 	mov	r0,a
      00B117 89 03            [24] 1231 	mov	ar3,r1
      00B119 88 02            [24] 1232 	mov	ar2,r0
      00B11B E4               [12] 1233 	clr	a
      00B11C 42 48            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00B11E E9               [12] 1235 	mov	a,r1
      00B11F 42 49            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00B121 EA               [12] 1237 	mov	a,r2
      00B122 42 4A            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00B124 EB               [12] 1239 	mov	a,r3
      00B125 42 4B            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00B127 12 42 0C         [24] 1241 	lcall	_ak820_outline_0020
      00B12A F8               [12] 1242 	mov	r0,a
      00B12B 79 00            [12] 1243 	mov	r1,#0x00
      00B12D 7A 00            [12] 1244 	mov	r2,#0x00
      00B12F 8A 03            [24] 1245 	mov	ar3,r2
      00B131 89 02            [24] 1246 	mov	ar2,r1
      00B133 88 01            [24] 1247 	mov	ar1,r0
      00B135 E4               [12] 1248 	clr	a
      00B136 42 48            [12] 1249 	orl	_raw_hid_receive_sloc0_1_0,a
      00B138 E9               [12] 1250 	mov	a,r1
      00B139 42 49            [12] 1251 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00B13B EA               [12] 1252 	mov	a,r2
      00B13C 42 4A            [12] 1253 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00B13E EB               [12] 1254 	mov	a,r3
      00B13F 42 4B            [12] 1255 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00B141 12 49 C3         [24] 1256 	lcall	_ak820_outline_0012
      00B144 E0               [24] 1257 	movx	a,@dptr
      00B145 F8               [12] 1258 	mov	r0,a
      00B146 E4               [12] 1259 	clr	a
      00B147 F9               [12] 1260 	mov	r1,a
      00B148 FA               [12] 1261 	mov	r2,a
      00B149 FB               [12] 1262 	mov	r3,a
      00B14A E5 49            [12] 1263 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B14C 42 01            [12] 1264 	orl	ar1,a
      00B14E E5 4A            [12] 1265 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00B150 42 02            [12] 1266 	orl	ar2,a
      00B152 E5 4B            [12] 1267 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00B154 42 03            [12] 1268 	orl	ar3,a
                                   1269 ;	quantum/via.c:323: via_set_layout_options(value);
      00B156 12 4F 6A         [24] 1270 	lcall	_ak820_outline_0119
      00B159 EB               [12] 1271 	mov	a, r3
      00B15A C0 07            [24] 1272 	push	ar7
      00B15C C0 06            [24] 1273 	push	ar6
      00B15E C0 03            [24] 1274 	push	ar3
      00B160 12 AE FD         [24] 1275 	lcall	_via_set_layout_options
      00B163 D0 03            [24] 1276 	pop	ar3
      00B165 D0 06            [24] 1277 	pop	ar6
      00B167 D0 07            [24] 1278 	pop	ar7
                                   1279 ;	quantum/via.c:324: break;
      00B169 D0 03            [24] 1280 	pop	ar3
      00B16B 81 CB            [12] 1281 	ajmp	00171$
                                   1282 ;	quantum/via.c:326: default: {
      00B16D                       1283 00127$:
                                   1284 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00B16D 12 4F 4F         [24] 1285 	lcall	_ak820_outline_0080
      00B170 90 0C F1         [24] 1286 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B173 12 B4 F9         [24] 1287 	lcall	_ak820_outline_0047
      00B176 C0 07            [24] 1288 	push	ar7
      00B178 C0 06            [24] 1289 	push	ar6
      00B17A C0 03            [24] 1290 	push	ar3
      00B17C 12 AF 54         [24] 1291 	lcall	_raw_hid_receive_kb
      00B17F D0 03            [24] 1292 	pop	ar3
      00B181 D0 06            [24] 1293 	pop	ar6
      00B183 D0 07            [24] 1294 	pop	ar7
                                   1295 ;	quantum/via.c:331: break;
      00B185 81 CB            [12] 1296 	ajmp	00171$
                                   1297 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00B187                       1298 00129$:
                                   1299 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00B187 12 4A 06         [24] 1300 	lcall	_ak820_outline_0084
      00B18A FA               [12] 1301 	mov	r2,a
      00B18B 12 38 31         [24] 1302 	lcall	_ak820_outline_0037
      00B18E F9               [12] 1303 	mov	r1,a
      00B18F 12 B4 F0         [24] 1304 	lcall	_ak820_outline_0018
      00B192 F8               [12] 1305 	mov	r0,a
      00B193 90 0B 6A         [24] 1306 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00B196 E9               [12] 1307 	mov	a,r1
      00B197 F0               [24] 1308 	movx	@dptr,a
      00B198 90 0B 6B         [24] 1309 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00B19B E8               [12] 1310 	mov	a,r0
      00B19C F0               [24] 1311 	movx	@dptr,a
      00B19D 8A 82            [24] 1312 	mov	dpl, r2
      00B19F C0 07            [24] 1313 	push	ar7
      00B1A1 C0 06            [24] 1314 	push	ar6
      00B1A3 C0 03            [24] 1315 	push	ar3
      00B1A5 12 8B 2D         [24] 1316 	lcall	_dynamic_keymap_get_keycode
      00B1A8 A9 82            [24] 1317 	mov	r1, dpl
      00B1AA AA 83            [24] 1318 	mov	r2, dph
      00B1AC D0 03            [24] 1319 	pop	ar3
      00B1AE D0 06            [24] 1320 	pop	ar6
      00B1B0 D0 07            [24] 1321 	pop	ar7
                                   1322 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00B1B2 12 38 74         [24] 1323 	lcall	_ak820_outline_0107
      00B1B5 A3               [24] 1324 	inc	dptr
      00B1B6 A3               [24] 1325 	inc	dptr
      00B1B7 A3               [24] 1326 	inc	dptr
      00B1B8 8A 00            [24] 1327 	mov	ar0,r2
      00B1BA E8               [12] 1328 	mov	a,r0
      00B1BB F0               [24] 1329 	movx	@dptr,a
                                   1330 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00B1BC 12 49 C3         [24] 1331 	lcall	_ak820_outline_0012
      00B1BF E9               [12] 1332 	mov	a,r1
      00B1C0 F0               [24] 1333 	movx	@dptr,a
                                   1334 ;	quantum/via.c:337: break;
      00B1C1 81 CB            [12] 1335 	ajmp	00171$
                                   1336 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00B1C3                       1337 00130$:
                                   1338 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00B1C3 90 0E DA         [24] 1339 	mov	dptr,#_vial_unlocked
      00B1C6 E0               [24] 1340 	movx	a,@dptr
      00B1C7 70 17            [24] 1341 	jnz	00132$
      00B1C9 12 42 0C         [24] 1342 	lcall	_ak820_outline_0020
      00B1CC FA               [12] 1343 	mov	r2,a
      00B1CD BA 7C 10         [24] 1344 	cjne	r2,#0x7c,00132$
      00B1D0 74 05            [12] 1345 	mov	a,#0x05
      00B1D2 2E               [12] 1346 	add	a, r6
      00B1D3 12 38 17         [24] 1347 	lcall	_ak820_outline_0021
      00B1D6 70 08            [24] 1348 	jnz	00132$
                                   1349 ;	quantum/via.c:344: *command_id = id_unhandled;
      00B1D8 12 38 90         [24] 1350 	lcall	_ak820_outline_0126
      00B1DB 74 FF            [12] 1351 	mov	a,#0xff
      00B1DD F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/via.c:345: break;
      00B1DE 81 CB            [12] 1354 	ajmp	00171$
      00B1E0                       1355 00132$:
                                   1356 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00B1E0 C0 03            [24] 1357 	push	ar3
      00B1E2 12 4A 06         [24] 1358 	lcall	_ak820_outline_0084
      00B1E5 F5 4D            [12] 1359 	mov	_raw_hid_receive_sloc2_1_0,a
      00B1E7 12 38 31         [24] 1360 	lcall	_ak820_outline_0037
      00B1EA F5 4C            [12] 1361 	mov	_raw_hid_receive_sloc1_1_0,a
      00B1EC 12 B4 F0         [24] 1362 	lcall	_ak820_outline_0018
      00B1EF F5 48            [12] 1363 	mov	_raw_hid_receive_sloc0_1_0,a
      00B1F1 12 42 0C         [24] 1364 	lcall	_ak820_outline_0020
      00B1F4 FB               [12] 1365 	mov	r3,a
      00B1F5 78 00            [12] 1366 	mov	r0,#0x00
      00B1F7 12 49 C3         [24] 1367 	lcall	_ak820_outline_0012
      00B1FA E0               [24] 1368 	movx	a,@dptr
      00B1FB 7A 00            [12] 1369 	mov	r2,#0x00
      00B1FD 42 00            [12] 1370 	orl	ar0,a
      00B1FF EA               [12] 1371 	mov	a,r2
      00B200 42 03            [12] 1372 	orl	ar3,a
      00B202 90 0B 6D         [24] 1373 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00B205 E5 4C            [12] 1374 	mov	a,_raw_hid_receive_sloc1_1_0
      00B207 F0               [24] 1375 	movx	@dptr,a
      00B208 90 0B 6E         [24] 1376 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00B20B E5 48            [12] 1377 	mov	a,_raw_hid_receive_sloc0_1_0
      00B20D F0               [24] 1378 	movx	@dptr,a
      00B20E 90 0B 6F         [24] 1379 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00B211 E8               [12] 1380 	mov	a,r0
      00B212 12 7D A0         [24] 1381 	lcall	_ak820_outline_0197
      00B215 85 4D 82         [24] 1382 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00B218 C0 07            [24] 1383 	push	ar7
      00B21A C0 06            [24] 1384 	push	ar6
      00B21C C0 03            [24] 1385 	push	ar3
      00B21E 12 8B 7A         [24] 1386 	lcall	_dynamic_keymap_set_keycode
      00B221 D0 03            [24] 1387 	pop	ar3
      00B223 D0 06            [24] 1388 	pop	ar6
      00B225 D0 07            [24] 1389 	pop	ar7
                                   1390 ;	quantum/via.c:349: break;
      00B227 D0 03            [24] 1391 	pop	ar3
      00B229 81 CB            [12] 1392 	ajmp	00171$
                                   1393 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00B22B                       1394 00135$:
                                   1395 ;	quantum/via.c:352: dynamic_keymap_reset();
      00B22B C0 07            [24] 1396 	push	ar7
      00B22D C0 06            [24] 1397 	push	ar6
      00B22F C0 03            [24] 1398 	push	ar3
      00B231 12 8F 15         [24] 1399 	lcall	_dynamic_keymap_reset
      00B234 D0 03            [24] 1400 	pop	ar3
      00B236 D0 06            [24] 1401 	pop	ar6
      00B238 D0 07            [24] 1402 	pop	ar7
                                   1403 ;	quantum/via.c:353: break;
      00B23A 81 CB            [12] 1404 	ajmp	00171$
                                   1405 ;	quantum/via.c:355: case id_lighting_set_value: {
      00B23C                       1406 00136$:
                                   1407 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00B23C 12 4F 4F         [24] 1408 	lcall	_ak820_outline_0080
      00B23F 90 0E 50         [24] 1409 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B242 12 B4 F9         [24] 1410 	lcall	_ak820_outline_0047
      00B245 C0 07            [24] 1411 	push	ar7
      00B247 C0 06            [24] 1412 	push	ar6
      00B249 C0 03            [24] 1413 	push	ar3
      00B24B 12 BF DF         [24] 1414 	lcall	_vialrgb_set_value
      00B24E D0 03            [24] 1415 	pop	ar3
      00B250 D0 06            [24] 1416 	pop	ar6
      00B252 D0 07            [24] 1417 	pop	ar7
                                   1418 ;	quantum/via.c:375: break;
      00B254 81 CB            [12] 1419 	ajmp	00171$
                                   1420 ;	quantum/via.c:377: case id_lighting_get_value: {
      00B256                       1421 00137$:
                                   1422 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00B256 12 4F 4F         [24] 1423 	lcall	_ak820_outline_0080
      00B259 90 0E 4C         [24] 1424 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B25C 12 B4 F9         [24] 1425 	lcall	_ak820_outline_0047
      00B25F C0 07            [24] 1426 	push	ar7
      00B261 C0 06            [24] 1427 	push	ar6
      00B263 C0 03            [24] 1428 	push	ar3
      00B265 12 BE 74         [24] 1429 	lcall	_vialrgb_get_value
      00B268 D0 03            [24] 1430 	pop	ar3
      00B26A D0 06            [24] 1431 	pop	ar6
      00B26C D0 07            [24] 1432 	pop	ar7
                                   1433 ;	quantum/via.c:397: break;
      00B26E 81 CB            [12] 1434 	ajmp	00171$
                                   1435 ;	quantum/via.c:399: case id_lighting_save: {
      00B270                       1436 00138$:
                                   1437 ;	quantum/via.c:407: vialrgb_save(data, length);
      00B270 12 4F 4F         [24] 1438 	lcall	_ak820_outline_0080
      00B273 90 0E 54         [24] 1439 	mov	dptr,#_vialrgb_save_PARM_2
      00B276 12 B4 F9         [24] 1440 	lcall	_ak820_outline_0047
      00B279 C0 07            [24] 1441 	push	ar7
      00B27B C0 06            [24] 1442 	push	ar6
      00B27D C0 03            [24] 1443 	push	ar3
      00B27F 12 C0 70         [24] 1444 	lcall	_vialrgb_save
      00B282 D0 03            [24] 1445 	pop	ar3
      00B284 D0 06            [24] 1446 	pop	ar6
      00B286 D0 07            [24] 1447 	pop	ar7
                                   1448 ;	quantum/via.c:419: break;
      00B288 81 CB            [12] 1449 	ajmp	00171$
                                   1450 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00B28A                       1451 00139$:
                                   1452 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00B28A C0 07            [24] 1453 	push	ar7
      00B28C C0 06            [24] 1454 	push	ar6
      00B28E C0 05            [24] 1455 	push	ar5
      00B290 C0 04            [24] 1456 	push	ar4
      00B292 C0 03            [24] 1457 	push	ar3
      00B294 12 93 41         [24] 1458 	lcall	_dynamic_keymap_macro_get_count
      00B297 AA 82            [24] 1459 	mov	r2, dpl
      00B299 D0 03            [24] 1460 	pop	ar3
      00B29B D0 04            [24] 1461 	pop	ar4
      00B29D D0 05            [24] 1462 	pop	ar5
      00B29F D0 06            [24] 1463 	pop	ar6
      00B2A1 D0 07            [24] 1464 	pop	ar7
      00B2A3 12 38 A1         [24] 1465 	lcall	_ak820_outline_0134
      00B2A6 EA               [12] 1466 	mov	a,r2
      00B2A7 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	quantum/via.c:430: break;
      00B2A8 81 CB            [12] 1469 	ajmp	00171$
                                   1470 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00B2AA                       1471 00140$:
                                   1472 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00B2AA C0 07            [24] 1473 	push	ar7
      00B2AC C0 06            [24] 1474 	push	ar6
      00B2AE C0 05            [24] 1475 	push	ar5
      00B2B0 C0 04            [24] 1476 	push	ar4
      00B2B2 C0 03            [24] 1477 	push	ar3
      00B2B4 12 93 45         [24] 1478 	lcall	_dynamic_keymap_macro_get_buffer_size
      00B2B7 A9 82            [24] 1479 	mov	r1, dpl
      00B2B9 AA 83            [24] 1480 	mov	r2, dph
      00B2BB D0 03            [24] 1481 	pop	ar3
      00B2BD D0 04            [24] 1482 	pop	ar4
      00B2BF D0 05            [24] 1483 	pop	ar5
      00B2C1 D0 06            [24] 1484 	pop	ar6
      00B2C3 D0 07            [24] 1485 	pop	ar7
                                   1486 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00B2C5 8A 00            [24] 1487 	mov	ar0,r2
      00B2C7 12 38 A1         [24] 1488 	lcall	_ak820_outline_0134
      00B2CA E8               [12] 1489 	mov	a,r0
      00B2CB 12 49 CD         [24] 1490 	lcall	_ak820_outline_0027
                                   1491 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00B2CE E9               [12] 1492 	mov	a,r1
      00B2CF F0               [24] 1493 	movx	@dptr,a
                                   1494 ;	quantum/via.c:436: break;
      00B2D0 81 CB            [12] 1495 	ajmp	00171$
                                   1496 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00B2D2                       1497 00141$:
                                   1498 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B2D2 C0 03            [24] 1499 	push	ar3
      00B2D4 12 B4 D9         [24] 1500 	lcall	_ak820_outline_0004
      00B2D7 89 48            [24] 1501 	mov	_raw_hid_receive_sloc0_1_0,r1
      00B2D9 8A 49            [24] 1502 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1503 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00B2DB 12 B4 F0         [24] 1504 	lcall	_ak820_outline_0018
      00B2DE FB               [12] 1505 	mov	r3,a
                                   1506 ;	quantum/via.c:441: if (size <= 28)
      00B2DF 8B 4E            [24] 1507 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B2E1 75 4F 00         [24] 1508 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B2E4 C3               [12] 1509 	clr	c
      00B2E5 74 1C            [12] 1510 	mov	a,#0x1c
      00B2E7 9B               [12] 1511 	subb	a,r3
      00B2E8 D0 03            [24] 1512 	pop	ar3
      00B2EA 50 02            [24] 1513 	jnc	00562$
      00B2EC 81 CB            [12] 1514 	ajmp	00171$
      00B2EE                       1515 00562$:
                                   1516 ;	free result
                                   1517 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00B2EE 12 B5 02         [24] 1518 	lcall	_ak820_outline_0074
      00B2F1 90 0B CE         [24] 1519 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00B2F4 E5 4E            [12] 1520 	mov	a,_raw_hid_receive_sloc3_1_0
      00B2F6 F0               [24] 1521 	movx	@dptr,a
      00B2F7 E5 4F            [12] 1522 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B2F9 A3               [24] 1523 	inc	dptr
      00B2FA F0               [24] 1524 	movx	@dptr,a
      00B2FB 90 0B D0         [24] 1525 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00B2FE 12 B5 0C         [24] 1526 	lcall	_ak820_outline_0092
      00B301 85 48 82         [24] 1527 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00B304 85 49 83         [24] 1528 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00B307 C0 07            [24] 1529 	push	ar7
      00B309 C0 06            [24] 1530 	push	ar6
      00B30B C0 03            [24] 1531 	push	ar3
      00B30D 12 93 49         [24] 1532 	lcall	_dynamic_keymap_macro_get_buffer
      00B310 D0 03            [24] 1533 	pop	ar3
      00B312 D0 06            [24] 1534 	pop	ar6
      00B314 D0 07            [24] 1535 	pop	ar7
                                   1536 ;	quantum/via.c:443: break;
      00B316 81 CB            [12] 1537 	ajmp	00171$
                                   1538 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00B318                       1539 00144$:
                                   1540 ;	quantum/via.c:448: if (!vial_unlocked) {
      00B318 90 0E DA         [24] 1541 	mov	dptr,#_vial_unlocked
      00B31B E0               [24] 1542 	movx	a,@dptr
      00B31C 70 01            [24] 1543 	jnz	00146$
                                   1544 ;	quantum/via.c:450: return;
      00B31E 22               [24] 1545 	ret
      00B31F                       1546 00146$:
                                   1547 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B31F C0 03            [24] 1548 	push	ar3
      00B321 12 B4 D9         [24] 1549 	lcall	_ak820_outline_0004
      00B324 89 4E            [24] 1550 	mov	_raw_hid_receive_sloc3_1_0,r1
      00B326 8A 4F            [24] 1551 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1552 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00B328 12 B4 F0         [24] 1553 	lcall	_ak820_outline_0018
      00B32B F5 48            [12] 1554 	mov	_raw_hid_receive_sloc0_1_0, a
      00B32D 75 49 00         [24] 1555 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1556 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00B330 85 48 50         [24] 1557 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00B333 85 49 51         [24] 1558 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00B336 C3               [12] 1559 	clr	c
      00B337 74 1C            [12] 1560 	mov	a,#0x1c
      00B339 95 50            [12] 1561 	subb	a,_raw_hid_receive_sloc4_1_0
      00B33B E4               [12] 1562 	clr	a
      00B33C 95 51            [12] 1563 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B33E D0 03            [24] 1564 	pop	ar3
      00B340 40 43            [24] 1565 	jc	00147$
                                   1566 ;	free result
      00B342 8B 01            [24] 1567 	mov	ar1,r3
      00B344 7A 00            [12] 1568 	mov	r2,#0x00
      00B346 E9               [12] 1569 	mov	a,r1
      00B347 24 FC            [12] 1570 	add	a,#0xfc
      00B349 F9               [12] 1571 	mov	r1,a
      00B34A EA               [12] 1572 	mov	a,r2
      00B34B 34 FF            [12] 1573 	addc	a,#0xff
      00B34D FA               [12] 1574 	mov	r2,a
      00B34E C3               [12] 1575 	clr	c
      00B34F E9               [12] 1576 	mov	a,r1
      00B350 95 50            [12] 1577 	subb	a,_raw_hid_receive_sloc4_1_0
      00B352 EA               [12] 1578 	mov	a,r2
      00B353 95 51            [12] 1579 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B355 40 2E            [24] 1580 	jc	00147$
                                   1581 ;	free result
      00B357 12 B5 02         [24] 1582 	lcall	_ak820_outline_0074
      00B35A 90 0B D5         [24] 1583 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00B35D E5 48            [12] 1584 	mov	a,_raw_hid_receive_sloc0_1_0
      00B35F F0               [24] 1585 	movx	@dptr,a
      00B360 E5 49            [12] 1586 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B362 A3               [24] 1587 	inc	dptr
      00B363 F0               [24] 1588 	movx	@dptr,a
      00B364 90 0B D7         [24] 1589 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00B367 12 B5 0C         [24] 1590 	lcall	_ak820_outline_0092
      00B36A 85 4E 82         [24] 1591 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00B36D 85 4F 83         [24] 1592 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00B370 C0 07            [24] 1593 	push	ar7
      00B372 C0 06            [24] 1594 	push	ar6
      00B374 C0 03            [24] 1595 	push	ar3
      00B376 12 93 96         [24] 1596 	lcall	_dynamic_keymap_macro_set_buffer
      00B379 E5 82            [12] 1597 	mov	a, dpl
      00B37B D0 03            [24] 1598 	pop	ar3
      00B37D D0 06            [24] 1599 	pop	ar6
      00B37F D0 07            [24] 1600 	pop	ar7
      00B381 60 02            [24] 1601 	jz	00566$
      00B383 81 CB            [12] 1602 	ajmp	00171$
      00B385                       1603 00566$:
      00B385                       1604 00147$:
      00B385 22               [24] 1605 	ret
                                   1606 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00B386                       1607 00151$:
                                   1608 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00B386 90 0E DA         [24] 1609 	mov	dptr,#_vial_unlocked
      00B389 E0               [24] 1610 	movx	a,@dptr
      00B38A 70 01            [24] 1611 	jnz	00153$
      00B38C 22               [24] 1612 	ret
      00B38D                       1613 00153$:
                                   1614 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00B38D C0 07            [24] 1615 	push	ar7
      00B38F C0 06            [24] 1616 	push	ar6
      00B391 C0 03            [24] 1617 	push	ar3
      00B393 12 93 C5         [24] 1618 	lcall	_dynamic_keymap_macro_reset
      00B396 D0 03            [24] 1619 	pop	ar3
      00B398 D0 06            [24] 1620 	pop	ar6
      00B39A D0 07            [24] 1621 	pop	ar7
                                   1622 ;	quantum/via.c:473: break;
      00B39C 81 CB            [12] 1623 	ajmp	00171$
                                   1624 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00B39E                       1625 00154$:
                                   1626 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00B39E C0 07            [24] 1627 	push	ar7
      00B3A0 C0 06            [24] 1628 	push	ar6
      00B3A2 C0 05            [24] 1629 	push	ar5
      00B3A4 C0 04            [24] 1630 	push	ar4
      00B3A6 C0 03            [24] 1631 	push	ar3
      00B3A8 12 8A F4         [24] 1632 	lcall	_dynamic_keymap_get_layer_count
      00B3AB AA 82            [24] 1633 	mov	r2, dpl
      00B3AD D0 03            [24] 1634 	pop	ar3
      00B3AF D0 04            [24] 1635 	pop	ar4
      00B3B1 D0 05            [24] 1636 	pop	ar5
      00B3B3 D0 06            [24] 1637 	pop	ar6
      00B3B5 D0 07            [24] 1638 	pop	ar7
      00B3B7 12 38 A1         [24] 1639 	lcall	_ak820_outline_0134
      00B3BA EA               [12] 1640 	mov	a,r2
      00B3BB F0               [24] 1641 	movx	@dptr,a
                                   1642 ;	quantum/via.c:477: break;
      00B3BC 81 CB            [12] 1643 	ajmp	00171$
                                   1644 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00B3BE                       1645 00155$:
                                   1646 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B3BE C0 03            [24] 1647 	push	ar3
      00B3C0 12 B4 D9         [24] 1648 	lcall	_ak820_outline_0004
      00B3C3 89 50            [24] 1649 	mov	_raw_hid_receive_sloc4_1_0,r1
      00B3C5 8A 51            [24] 1650 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1651 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00B3C7 12 B4 F0         [24] 1652 	lcall	_ak820_outline_0018
      00B3CA FB               [12] 1653 	mov	r3,a
                                   1654 ;	quantum/via.c:482: if (size <= 28)
      00B3CB 8B 4E            [24] 1655 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B3CD 75 4F 00         [24] 1656 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B3D0 C3               [12] 1657 	clr	c
      00B3D1 74 1C            [12] 1658 	mov	a,#0x1c
      00B3D3 9B               [12] 1659 	subb	a,r3
      00B3D4 D0 03            [24] 1660 	pop	ar3
      00B3D6 50 02            [24] 1661 	jnc	00568$
      00B3D8 81 CB            [12] 1662 	ajmp	00171$
      00B3DA                       1663 00568$:
                                   1664 ;	free result
                                   1665 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00B3DA 12 B5 02         [24] 1666 	lcall	_ak820_outline_0074
      00B3DD 90 0B B7         [24] 1667 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00B3E0 E5 4E            [12] 1668 	mov	a,_raw_hid_receive_sloc3_1_0
      00B3E2 F0               [24] 1669 	movx	@dptr,a
      00B3E3 E5 4F            [12] 1670 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B3E5 A3               [24] 1671 	inc	dptr
      00B3E6 F0               [24] 1672 	movx	@dptr,a
      00B3E7 90 0B B9         [24] 1673 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00B3EA 12 B5 0C         [24] 1674 	lcall	_ak820_outline_0092
      00B3ED 85 50 82         [24] 1675 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B3F0 85 51 83         [24] 1676 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B3F3 C0 07            [24] 1677 	push	ar7
      00B3F5 C0 06            [24] 1678 	push	ar6
      00B3F7 C0 03            [24] 1679 	push	ar3
      00B3F9 12 91 13         [24] 1680 	lcall	_dynamic_keymap_get_buffer
      00B3FC D0 03            [24] 1681 	pop	ar3
      00B3FE D0 06            [24] 1682 	pop	ar6
      00B400 D0 07            [24] 1683 	pop	ar7
                                   1684 ;	quantum/via.c:484: break;
      00B402 81 CB            [12] 1685 	ajmp	00171$
                                   1686 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00B404                       1687 00158$:
                                   1688 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B404 12 4A 06         [24] 1689 	lcall	_ak820_outline_0084
      00B407 FD               [12] 1690 	mov	r5,a
      00B408 7C 00            [12] 1691 	mov	r4,#0x00
      00B40A 12 38 31         [24] 1692 	lcall	_ak820_outline_0037
      00B40D 7A 00            [12] 1693 	mov	r2,#0x00
      00B40F 42 04            [12] 1694 	orl	ar4,a
      00B411 EA               [12] 1695 	mov	a,r2
      00B412 42 05            [12] 1696 	orl	ar5,a
      00B414 8C 50            [24] 1697 	mov	_raw_hid_receive_sloc4_1_0,r4
      00B416 8D 51            [24] 1698 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1699 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00B418 12 B4 F0         [24] 1700 	lcall	_ak820_outline_0018
      00B41B F9               [12] 1701 	mov	r1,a
      00B41C 7A 00            [12] 1702 	mov	r2,#0x00
                                   1703 ;	quantum/via.c:489: if (size <= 28)
      00B41E 89 00            [24] 1704 	mov	ar0,r1
      00B420 E8               [12] 1705 	mov	a,r0
      00B421 24 E3            [12] 1706 	add	a,#0xff - 0x1c
      00B423 50 02            [24] 1707 	jnc	00569$
      00B425 81 CB            [12] 1708 	ajmp	00171$
      00B427                       1709 00569$:
                                   1710 ;	free result
                                   1711 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00B427 C0 03            [24] 1712 	push	ar3
      00B429 74 04            [12] 1713 	mov	a,#0x04
      00B42B 2E               [12] 1714 	add	a, r6
      00B42C F8               [12] 1715 	mov	r0,a
      00B42D E4               [12] 1716 	clr	a
      00B42E 3F               [12] 1717 	addc	a, r7
      00B42F FB               [12] 1718 	mov	r3,a
      00B430 7D 00            [12] 1719 	mov	r5,#0x00
      00B432 90 0B BE         [24] 1720 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00B435 12 4F 71         [24] 1721 	lcall	_ak820_outline_0149
      00B438 90 0B C0         [24] 1722 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00B43B E8               [12] 1723 	mov	a,r0
      00B43C 12 7D A0         [24] 1724 	lcall	_ak820_outline_0197
      00B43F ED               [12] 1725 	mov	a,r5
      00B440 A3               [24] 1726 	inc	dptr
      00B441 F0               [24] 1727 	movx	@dptr,a
      00B442 85 50 82         [24] 1728 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B445 85 51 83         [24] 1729 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B448 C0 07            [24] 1730 	push	ar7
      00B44A C0 06            [24] 1731 	push	ar6
      00B44C C0 03            [24] 1732 	push	ar3
      00B44E 12 91 51         [24] 1733 	lcall	_dynamic_keymap_set_buffer
      00B451 D0 03            [24] 1734 	pop	ar3
      00B453 D0 06            [24] 1735 	pop	ar6
      00B455 D0 07            [24] 1736 	pop	ar7
                                   1737 ;	quantum/via.c:491: break;
      00B457 D0 03            [24] 1738 	pop	ar3
      00B459 81 CB            [12] 1739 	ajmp	00171$
                                   1740 ;	quantum/via.c:495: case id_bootloader_jump: {
      00B45B                       1741 00161$:
                                   1742 ;	quantum/via.c:497: if (!vial_unlocked)
      00B45B 90 0E DA         [24] 1743 	mov	dptr,#_vial_unlocked
      00B45E E0               [24] 1744 	movx	a,@dptr
      00B45F 70 02            [24] 1745 	jnz	00570$
      00B461 81 CB            [12] 1746 	ajmp	00171$
      00B463                       1747 00570$:
                                   1748 ;	quantum/via.c:501: raw_hid_send(data, length);
      00B463 12 B5 1E         [24] 1749 	lcall	_ak820_outline_0161
      00B466 90 06 E3         [24] 1750 	mov	dptr,#_raw_hid_send_PARM_2
      00B469 12 B5 15         [24] 1751 	lcall	_ak820_outline_0093
      00B46C C0 07            [24] 1752 	push	ar7
      00B46E C0 06            [24] 1753 	push	ar6
      00B470 C0 03            [24] 1754 	push	ar3
      00B472 12 51 AF         [24] 1755 	lcall	_raw_hid_send
      00B475 D0 03            [24] 1756 	pop	ar3
      00B477 D0 06            [24] 1757 	pop	ar6
      00B479 D0 07            [24] 1758 	pop	ar7
                                   1759 ;	quantum/via.c:503: wait_ms(100);
      00B47B 7D 64            [12] 1760 	mov	r5,#0x64
      00B47D                       1761 00176$:
      00B47D ED               [12] 1762 	mov	a,r5
      00B47E 60 09            [24] 1763 	jz	00166$
      00B480 90 00 01         [24] 1764 	mov	dptr,#0x0001
      00B483 12 5F 5C         [24] 1765 	lcall	_mDelaymS
      00B486 1D               [12] 1766 	dec	r5
      00B487 80 F4            [24] 1767 	sjmp	00176$
      00B489                       1768 00166$:
                                   1769 ;	quantum/via.c:504: bootloader_jump();
      00B489 C0 07            [24] 1770 	push	ar7
      00B48B C0 06            [24] 1771 	push	ar6
      00B48D C0 03            [24] 1772 	push	ar3
      00B48F 12 34 0E         [24] 1773 	lcall	_bootloader_jump
      00B492 D0 03            [24] 1774 	pop	ar3
      00B494 D0 06            [24] 1775 	pop	ar6
      00B496 D0 07            [24] 1776 	pop	ar7
                                   1777 ;	quantum/via.c:505: break;
                                   1778 ;	quantum/via.c:509: case id_vial_prefix: {
      00B498 80 31            [24] 1779 	sjmp	00171$
      00B49A                       1780 00168$:
                                   1781 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B49A 12 B5 1E         [24] 1782 	lcall	_ak820_outline_0161
      00B49D 90 0D 03         [24] 1783 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B4A0 12 B5 15         [24] 1784 	lcall	_ak820_outline_0093
      00B4A3 C0 07            [24] 1785 	push	ar7
      00B4A5 C0 06            [24] 1786 	push	ar6
      00B4A7 C0 03            [24] 1787 	push	ar3
      00B4A9 D1 0E            [12] 1788 	acall	_vial_handle_cmd
      00B4AB D0 03            [24] 1789 	pop	ar3
      00B4AD D0 06            [24] 1790 	pop	ar6
      00B4AF D0 07            [24] 1791 	pop	ar7
                                   1792 ;	quantum/via.c:511: break;
                                   1793 ;	quantum/via.c:514: default: {
      00B4B1 80 18            [24] 1794 	sjmp	00171$
      00B4B3                       1795 00169$:
                                   1796 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B4B3 12 B5 1E         [24] 1797 	lcall	_ak820_outline_0161
      00B4B6 90 0C F1         [24] 1798 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B4B9 12 B5 15         [24] 1799 	lcall	_ak820_outline_0093
      00B4BC C0 07            [24] 1800 	push	ar7
      00B4BE C0 06            [24] 1801 	push	ar6
      00B4C0 C0 03            [24] 1802 	push	ar3
      00B4C2 12 AF 54         [24] 1803 	lcall	_raw_hid_receive_kb
      00B4C5 D0 03            [24] 1804 	pop	ar3
      00B4C7 D0 06            [24] 1805 	pop	ar6
      00B4C9 D0 07            [24] 1806 	pop	ar7
                                   1807 ;	quantum/via.c:521: skip:
      00B4CB                       1808 00171$:
                                   1809 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B4CB 7D 00            [12] 1810 	mov	r5,#0x00
      00B4CD 90 06 E3         [24] 1811 	mov	dptr,#_raw_hid_send_PARM_2
      00B4D0 EB               [12] 1812 	mov	a,r3
      00B4D1 12 4A 00         [24] 1813 	lcall	_ak820_outline_0070
      00B4D4 8D F0            [24] 1814 	mov	b, r5
                                   1815 ;	quantum/via.c:526: }
      00B4D6 02 51 AF         [24] 1816 	ljmp	_raw_hid_send
                                   1817 	.area CSEG    (CODE)
                                   1818 	.area CONST   (CODE)
                                   1819 	.area XINIT   (CODE)
                                   1820 	.area CABS    (ABS,CODE)
                                   1821 
                                   1822 ; Experimental exact instruction outlining.
                                   1823 	.globl _ak820_outline_0001
                                   1824 	.globl _ak820_outline_0004
                                   1825 	.globl _ak820_outline_0010
                                   1826 	.globl _ak820_outline_0012
                                   1827 	.globl _ak820_outline_0013
                                   1828 	.globl _ak820_outline_0018
                                   1829 	.globl _ak820_outline_0020
                                   1830 	.globl _ak820_outline_0021
                                   1831 	.globl _ak820_outline_0022
                                   1832 	.globl _ak820_outline_0027
                                   1833 	.globl _ak820_outline_0037
                                   1834 	.globl _ak820_outline_0041
                                   1835 	.globl _ak820_outline_0047
                                   1836 	.globl _ak820_outline_0050
                                   1837 	.globl _ak820_outline_0057
                                   1838 	.globl _ak820_outline_0063
                                   1839 	.globl _ak820_outline_0070
                                   1840 	.globl _ak820_outline_0074
                                   1841 	.globl _ak820_outline_0080
                                   1842 	.globl _ak820_outline_0084
                                   1843 	.globl _ak820_outline_0092
                                   1844 	.globl _ak820_outline_0093
                                   1845 	.globl _ak820_outline_0105
                                   1846 	.globl _ak820_outline_0107
                                   1847 	.globl _ak820_outline_0114
                                   1848 	.globl _ak820_outline_0115
                                   1849 	.globl _ak820_outline_0119
                                   1850 	.globl _ak820_outline_0126
                                   1851 	.globl _ak820_outline_0128
                                   1852 	.globl _ak820_outline_0134
                                   1853 	.globl _ak820_outline_0149
                                   1854 	.globl _ak820_outline_0154
                                   1855 	.globl _ak820_outline_0161
                                   1856 	.globl _ak820_outline_0163
                                   1857 	.globl _ak820_outline_0169
                                   1858 	.globl _ak820_outline_0171
                                   1859 	.globl _ak820_outline_0172
                                   1860 	.globl _ak820_outline_0197
                                   1861 
                                   1862 	.area CSEG (CODE)
                                   1863 ; function ak820_outline_0004
      00B4D9                       1864 _ak820_outline_0004:
      00B4D9 8C 82            [24] 1865 	mov	dpl,r4
      00B4DB 8D 83            [24] 1866 	mov	dph,r5
      00B4DD E0               [24] 1867 	movx	a,@dptr
      00B4DE FA               [12] 1868 	mov	r2,a
      00B4DF 79 00            [12] 1869 	mov	r1,#0x00
      00B4E1 8E 82            [24] 1870 	mov	dpl,r6
      00B4E3 8F 83            [24] 1871 	mov	dph,r7
      00B4E5 A3               [24] 1872 	inc	dptr
      00B4E6 A3               [24] 1873 	inc	dptr
      00B4E7 E0               [24] 1874 	movx	a,@dptr
      00B4E8 7B 00            [12] 1875 	mov	r3,#0x00
      00B4EA 42 01            [12] 1876 	orl	ar1,a
      00B4EC EB               [12] 1877 	mov	a,r3
      00B4ED 42 02            [12] 1878 	orl	ar2,a
      00B4EF 22               [24] 1879 	ret
                                   1880 
                                   1881 	.area CSEG (CODE)
                                   1882 ; function ak820_outline_0018
      00B4F0                       1883 _ak820_outline_0018:
      00B4F0 8E 82            [24] 1884 	mov	dpl,r6
      00B4F2 8F 83            [24] 1885 	mov	dph,r7
      00B4F4 A3               [24] 1886 	inc	dptr
      00B4F5 A3               [24] 1887 	inc	dptr
      00B4F6 A3               [24] 1888 	inc	dptr
      00B4F7 E0               [24] 1889 	movx	a,@dptr
      00B4F8 22               [24] 1890 	ret
                                   1891 
                                   1892 	.area CSEG (CODE)
                                   1893 ; function ak820_outline_0047
      00B4F9                       1894 _ak820_outline_0047:
      00B4F9 EB               [12] 1895 	mov	a,r3
      00B4FA F0               [24] 1896 	movx	@dptr,a
      00B4FB 88 82            [24] 1897 	mov	dpl,r0
      00B4FD 89 83            [24] 1898 	mov	dph,r1
      00B4FF 8A F0            [24] 1899 	mov	b,r2
      00B501 22               [24] 1900 	ret
                                   1901 
                                   1902 	.area CSEG (CODE)
                                   1903 ; function ak820_outline_0074
      00B502                       1904 _ak820_outline_0074:
      00B502 74 04            [12] 1905 	mov	a,#0x04
      00B504 2E               [12] 1906 	add	a,r6
      00B505 F9               [12] 1907 	mov	r1,a
      00B506 E4               [12] 1908 	clr	a
      00B507 3F               [12] 1909 	addc	a,r7
      00B508 F8               [12] 1910 	mov	r0,a
      00B509 7A 00            [12] 1911 	mov	r2,#0x00
      00B50B 22               [24] 1912 	ret
                                   1913 
                                   1914 	.area CSEG (CODE)
                                   1915 ; function ak820_outline_0092
      00B50C                       1916 _ak820_outline_0092:
      00B50C E9               [12] 1917 	mov	a,r1
      00B50D F0               [24] 1918 	movx	@dptr,a
      00B50E E8               [12] 1919 	mov	a,r0
      00B50F A3               [24] 1920 	inc	dptr
      00B510 F0               [24] 1921 	movx	@dptr,a
      00B511 EA               [12] 1922 	mov	a,r2
      00B512 A3               [24] 1923 	inc	dptr
      00B513 F0               [24] 1924 	movx	@dptr,a
      00B514 22               [24] 1925 	ret
                                   1926 
                                   1927 	.area CSEG (CODE)
                                   1928 ; function ak820_outline_0093
      00B515                       1929 _ak820_outline_0093:
      00B515 EB               [12] 1930 	mov	a,r3
      00B516 F0               [24] 1931 	movx	@dptr,a
      00B517 8A 82            [24] 1932 	mov	dpl,r2
      00B519 8C 83            [24] 1933 	mov	dph,r4
      00B51B 8D F0            [24] 1934 	mov	b,r5
      00B51D 22               [24] 1935 	ret
                                   1936 
                                   1937 	.area CSEG (CODE)
                                   1938 ; function ak820_outline_0161
      00B51E                       1939 _ak820_outline_0161:
      00B51E 8E 02            [24] 1940 	mov	ar2,r6
      00B520 8F 04            [24] 1941 	mov	ar4,r7
      00B522 7D 00            [12] 1942 	mov	r5,#0x00
      00B524 22               [24] 1943 	ret
