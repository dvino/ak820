                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module keyboard
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _quantum_task
                                     12 	.globl _switch_events
                                     13 	.globl _quantum_init
                                     14 	.globl _should_process_keypress
                                     15 	.globl _last_encoder_activity_trigger
                                     16 	.globl _last_matrix_activity_trigger
                                     17 	.globl _caps_word_task
                                     18 	.globl _vial_unlock_task
                                     19 	.globl _vial_init
                                     20 	.globl _eeprom_driver_init
                                     21 	.globl _via_init
                                     22 	.globl _encoder_read
                                     23 	.globl _encoder_init
                                     24 	.globl _rgb_matrix_init
                                     25 	.globl _rgb_matrix_task
                                     26 	.globl _process_rgb_matrix
                                     27 	.globl _ak820_action_exec
                                     28 	.globl _print_set_sendchar
                                     29 	.globl _sendchar
                                     30 	.globl _led_task
                                     31 	.globl _led_init_ports
                                     32 	.globl _magic
                                     33 	.globl _matrix_print
                                     34 	.globl _matrix_get_row
                                     35 	.globl _matrix_scan
                                     36 	.globl _matrix_init
                                     37 	.globl _keyboard_post_init_user
                                     38 	.globl _timer_elapsed32
                                     39 	.globl _timer_read32
                                     40 	.globl _timer_read
                                     41 	.globl _timer_init
                                     42 	.globl _ADC_START
                                     43 	.globl _S0_R_FIFO
                                     44 	.globl _S0_T_FIFO
                                     45 	.globl _S0_FREE
                                     46 	.globl _S0_IF_BYTE
                                     47 	.globl _S0_IF_FIRST
                                     48 	.globl _S0_IF_OV
                                     49 	.globl _S0_FST_ACT
                                     50 	.globl _CP_RL2
                                     51 	.globl _C_T2
                                     52 	.globl _TR2
                                     53 	.globl _EXEN2
                                     54 	.globl _TCLK
                                     55 	.globl _RCLK
                                     56 	.globl _EXF2
                                     57 	.globl _CAP1F
                                     58 	.globl _TF2
                                     59 	.globl _RI
                                     60 	.globl _TI
                                     61 	.globl _RB8
                                     62 	.globl _TB8
                                     63 	.globl _REN
                                     64 	.globl _SM2
                                     65 	.globl _SM1
                                     66 	.globl _SM0
                                     67 	.globl _IT0
                                     68 	.globl _IE0
                                     69 	.globl _IT1
                                     70 	.globl _IE1
                                     71 	.globl _TR0
                                     72 	.globl _TF0
                                     73 	.globl _TR1
                                     74 	.globl _TF1
                                     75 	.globl _P4_0
                                     76 	.globl _P4_1
                                     77 	.globl _P4_2
                                     78 	.globl _P4_3
                                     79 	.globl _P4_4
                                     80 	.globl _P4_5
                                     81 	.globl _P4_6
                                     82 	.globl _RXD
                                     83 	.globl _TXD
                                     84 	.globl _INT0
                                     85 	.globl _INT1
                                     86 	.globl _T0
                                     87 	.globl _T1
                                     88 	.globl _MOSI1
                                     89 	.globl _MISO1
                                     90 	.globl _SCK1
                                     91 	.globl _P3_0
                                     92 	.globl _P3_1
                                     93 	.globl _P3_2
                                     94 	.globl _P3_3
                                     95 	.globl _P3_4
                                     96 	.globl _P3_5
                                     97 	.globl _P3_6
                                     98 	.globl _P3_7
                                     99 	.globl _CAP1_
                                    100 	.globl _T2_
                                    101 	.globl _CAP2_
                                    102 	.globl _T2EX_
                                    103 	.globl _RXD1
                                    104 	.globl _TXD1
                                    105 	.globl _P2_0
                                    106 	.globl _P2_1
                                    107 	.globl _P2_2
                                    108 	.globl _P2_3
                                    109 	.globl _P2_4
                                    110 	.globl _P2_5
                                    111 	.globl _P2_6
                                    112 	.globl _P2_7
                                    113 	.globl _AIN0
                                    114 	.globl _AIN1
                                    115 	.globl _AIN2
                                    116 	.globl _AIN3
                                    117 	.globl _AIN4
                                    118 	.globl _AIN5
                                    119 	.globl _AIN6
                                    120 	.globl _AIN7
                                    121 	.globl _CAP1
                                    122 	.globl _T2
                                    123 	.globl _CAP2
                                    124 	.globl _T2EX
                                    125 	.globl _INT0_
                                    126 	.globl _SCS
                                    127 	.globl _MOSI
                                    128 	.globl _MISO
                                    129 	.globl _SCK
                                    130 	.globl _RXD1_
                                    131 	.globl _TXD1_
                                    132 	.globl _P1_0
                                    133 	.globl _P1_1
                                    134 	.globl _P1_2
                                    135 	.globl _P1_3
                                    136 	.globl _P1_4
                                    137 	.globl _P1_5
                                    138 	.globl _P1_6
                                    139 	.globl _P1_7
                                    140 	.globl _AIN8
                                    141 	.globl _AIN9
                                    142 	.globl _AIN10
                                    143 	.globl _AIN11
                                    144 	.globl _AIN12
                                    145 	.globl _AIN13
                                    146 	.globl _RXD_
                                    147 	.globl _TXD_
                                    148 	.globl _SCL0
                                    149 	.globl _SDA0
                                    150 	.globl _P0_0
                                    151 	.globl _P0_1
                                    152 	.globl _P0_2
                                    153 	.globl _P0_3
                                    154 	.globl _P0_4
                                    155 	.globl _P0_5
                                    156 	.globl _P0_6
                                    157 	.globl _P0_7
                                    158 	.globl _IE_SPI0
                                    159 	.globl _IE_USB
                                    160 	.globl _IE_ADC
                                    161 	.globl _IE_UART1
                                    162 	.globl _IE_PWM_I2C
                                    163 	.globl _IE_GPIO
                                    164 	.globl _IE_WDOG
                                    165 	.globl _PX0
                                    166 	.globl _PT0
                                    167 	.globl _PX1
                                    168 	.globl _PT1
                                    169 	.globl _PS
                                    170 	.globl _PT2
                                    171 	.globl _PL_FLAG
                                    172 	.globl _PH_FLAG
                                    173 	.globl _EX0
                                    174 	.globl _ET0
                                    175 	.globl _EX1
                                    176 	.globl _ET1
                                    177 	.globl _ES
                                    178 	.globl _ET2
                                    179 	.globl _E_DIS
                                    180 	.globl _EA
                                    181 	.globl _P
                                    182 	.globl _F1
                                    183 	.globl _OV
                                    184 	.globl _RS0
                                    185 	.globl _RS1
                                    186 	.globl _F0
                                    187 	.globl _AC
                                    188 	.globl _CY
                                    189 	.globl _I2CS_INT_ST
                                    190 	.globl _I2CX_INT
                                    191 	.globl _LED_STATUS
                                    192 	.globl _LED_DMA_H
                                    193 	.globl _LED_DMA_L
                                    194 	.globl _LED_DMA
                                    195 	.globl _LED_PWM_OE
                                    196 	.globl _LED_COMMON
                                    197 	.globl _ADC_CHAN
                                    198 	.globl _ADC_DAT_H
                                    199 	.globl _ADC_DAT_L
                                    200 	.globl _ADC_DAT
                                    201 	.globl _ADC_CTRL
                                    202 	.globl _SPI1_CK_SE
                                    203 	.globl _SPI1_CTRL
                                    204 	.globl _SPI1_DATA
                                    205 	.globl _SPI1_STAT
                                    206 	.globl _SIF1
                                    207 	.globl _SBAUD1
                                    208 	.globl _SBUF1
                                    209 	.globl _SCON1
                                    210 	.globl _SPI0_SETUP
                                    211 	.globl _SPI0_CK_SE
                                    212 	.globl _SPI0_CTRL
                                    213 	.globl _SPI0_DATA
                                    214 	.globl _SPI0_STAT
                                    215 	.globl _T2CAP1H
                                    216 	.globl _T2CAP1L
                                    217 	.globl _T2CAP1
                                    218 	.globl _TH2
                                    219 	.globl _TL2
                                    220 	.globl _T2COUNT
                                    221 	.globl _RCAP2H
                                    222 	.globl _RCAP2L
                                    223 	.globl _RCAP2
                                    224 	.globl _T2MOD
                                    225 	.globl _T2CON
                                    226 	.globl _SBUF
                                    227 	.globl _SCON
                                    228 	.globl _TH1
                                    229 	.globl _TH0
                                    230 	.globl _TL1
                                    231 	.globl _TL0
                                    232 	.globl _TMOD
                                    233 	.globl _TCON
                                    234 	.globl _XBUS_AUX
                                    235 	.globl _P7
                                    236 	.globl _P6_DIR
                                    237 	.globl _P6_OUT_PU
                                    238 	.globl _P6_IN
                                    239 	.globl _P5_DIR
                                    240 	.globl _P5_OUT_PU
                                    241 	.globl _P5_IN
                                    242 	.globl _P4_LED_KEY
                                    243 	.globl _P4_DIR_PU
                                    244 	.globl _P4_MOD_OC
                                    245 	.globl _P4
                                    246 	.globl _P3_DIR_PU
                                    247 	.globl _P3_MOD_OC
                                    248 	.globl _P3
                                    249 	.globl _P2_DIR_PU
                                    250 	.globl _P2_MOD_OC
                                    251 	.globl _P2
                                    252 	.globl _P1_DIR_PU
                                    253 	.globl _P1_MOD_OC
                                    254 	.globl _P1
                                    255 	.globl _P0_DIR_PU
                                    256 	.globl _P0_MOD_OC
                                    257 	.globl _P0
                                    258 	.globl _ROM_CTRL
                                    259 	.globl _ROM_DATA_HH
                                    260 	.globl _ROM_DATA_HL
                                    261 	.globl _ROM_DATA_HI
                                    262 	.globl _ROM_ADDR_H
                                    263 	.globl _ROM_ADDR_L
                                    264 	.globl _ROM_ADDR
                                    265 	.globl _GPIO_IE
                                    266 	.globl _IP_EX
                                    267 	.globl _IE_EX
                                    268 	.globl _IP
                                    269 	.globl _IE
                                    270 	.globl _WDOG_COUNT
                                    271 	.globl _RESET_KEEP
                                    272 	.globl _WAKE_CTRL
                                    273 	.globl _CLOCK_CFG
                                    274 	.globl _POWER_CFG
                                    275 	.globl _PCON
                                    276 	.globl _GLOBAL_CFG
                                    277 	.globl _SAFE_MOD
                                    278 	.globl _DPH
                                    279 	.globl _DPL
                                    280 	.globl _SP
                                    281 	.globl _A_INV
                                    282 	.globl _B
                                    283 	.globl _ACC
                                    284 	.globl _PSW
                                    285 	.globl _switch_events_PARM_3
                                    286 	.globl _switch_events_PARM_2
                                    287 	.globl _keyboard_post_init_kb
                                    288 	.globl _matrix_can_read
                                    289 	.globl _keyboard_setup
                                    290 	.globl _is_keyboard_master
                                    291 	.globl _housekeeping_task
                                    292 	.globl _keyboard_init
                                    293 	.globl _keyboard_task
                                    294 ;--------------------------------------------------------
                                    295 ; special function registers
                                    296 ;--------------------------------------------------------
                                    297 	.area RSEG    (ABS,DATA)
      000000                        298 	.org 0x0000
                           0000D0   299 _PSW	=	0x00d0
                           0000E0   300 _ACC	=	0x00e0
                           0000F0   301 _B	=	0x00f0
                           0000FD   302 _A_INV	=	0x00fd
                           000081   303 _SP	=	0x0081
                           000082   304 _DPL	=	0x0082
                           000083   305 _DPH	=	0x0083
                           0000A1   306 _SAFE_MOD	=	0x00a1
                           0000B1   307 _GLOBAL_CFG	=	0x00b1
                           000087   308 _PCON	=	0x0087
                           0000BA   309 _POWER_CFG	=	0x00ba
                           0000B9   310 _CLOCK_CFG	=	0x00b9
                           0000A9   311 _WAKE_CTRL	=	0x00a9
                           0000FE   312 _RESET_KEEP	=	0x00fe
                           0000FF   313 _WDOG_COUNT	=	0x00ff
                           0000A8   314 _IE	=	0x00a8
                           0000B8   315 _IP	=	0x00b8
                           0000E8   316 _IE_EX	=	0x00e8
                           0000E9   317 _IP_EX	=	0x00e9
                           0000B2   318 _GPIO_IE	=	0x00b2
                           008584   319 _ROM_ADDR	=	0x8584
                           000084   320 _ROM_ADDR_L	=	0x0084
                           000085   321 _ROM_ADDR_H	=	0x0085
                           008F8E   322 _ROM_DATA_HI	=	0x8f8e
                           00008E   323 _ROM_DATA_HL	=	0x008e
                           00008F   324 _ROM_DATA_HH	=	0x008f
                           000086   325 _ROM_CTRL	=	0x0086
                           000080   326 _P0	=	0x0080
                           0000C4   327 _P0_MOD_OC	=	0x00c4
                           0000C5   328 _P0_DIR_PU	=	0x00c5
                           000090   329 _P1	=	0x0090
                           000092   330 _P1_MOD_OC	=	0x0092
                           000093   331 _P1_DIR_PU	=	0x0093
                           0000A0   332 _P2	=	0x00a0
                           000094   333 _P2_MOD_OC	=	0x0094
                           000095   334 _P2_DIR_PU	=	0x0095
                           0000B0   335 _P3	=	0x00b0
                           000096   336 _P3_MOD_OC	=	0x0096
                           000097   337 _P3_DIR_PU	=	0x0097
                           0000C0   338 _P4	=	0x00c0
                           0000C2   339 _P4_MOD_OC	=	0x00c2
                           0000C3   340 _P4_DIR_PU	=	0x00c3
                           0000C1   341 _P4_LED_KEY	=	0x00c1
                           0000AA   342 _P5_IN	=	0x00aa
                           0000AB   343 _P5_OUT_PU	=	0x00ab
                           0000AC   344 _P5_DIR	=	0x00ac
                           0000AD   345 _P6_IN	=	0x00ad
                           0000AE   346 _P6_OUT_PU	=	0x00ae
                           0000AF   347 _P6_DIR	=	0x00af
                           0000F1   348 _P7	=	0x00f1
                           0000A2   349 _XBUS_AUX	=	0x00a2
                           000088   350 _TCON	=	0x0088
                           000089   351 _TMOD	=	0x0089
                           00008A   352 _TL0	=	0x008a
                           00008B   353 _TL1	=	0x008b
                           00008C   354 _TH0	=	0x008c
                           00008D   355 _TH1	=	0x008d
                           000098   356 _SCON	=	0x0098
                           000099   357 _SBUF	=	0x0099
                           0000C8   358 _T2CON	=	0x00c8
                           0000C9   359 _T2MOD	=	0x00c9
                           00CBCA   360 _RCAP2	=	0xcbca
                           0000CA   361 _RCAP2L	=	0x00ca
                           0000CB   362 _RCAP2H	=	0x00cb
                           00CDCC   363 _T2COUNT	=	0xcdcc
                           0000CC   364 _TL2	=	0x00cc
                           0000CD   365 _TH2	=	0x00cd
                           00CFCE   366 _T2CAP1	=	0xcfce
                           0000CE   367 _T2CAP1L	=	0x00ce
                           0000CF   368 _T2CAP1H	=	0x00cf
                           0000F8   369 _SPI0_STAT	=	0x00f8
                           0000F9   370 _SPI0_DATA	=	0x00f9
                           0000FA   371 _SPI0_CTRL	=	0x00fa
                           0000FB   372 _SPI0_CK_SE	=	0x00fb
                           0000FC   373 _SPI0_SETUP	=	0x00fc
                           0000BC   374 _SCON1	=	0x00bc
                           0000BD   375 _SBUF1	=	0x00bd
                           0000BE   376 _SBAUD1	=	0x00be
                           0000BF   377 _SIF1	=	0x00bf
                           0000B4   378 _SPI1_STAT	=	0x00b4
                           0000B5   379 _SPI1_DATA	=	0x00b5
                           0000B6   380 _SPI1_CTRL	=	0x00b6
                           0000B7   381 _SPI1_CK_SE	=	0x00b7
                           0000F3   382 _ADC_CTRL	=	0x00f3
                           00F5F4   383 _ADC_DAT	=	0xf5f4
                           0000F4   384 _ADC_DAT_L	=	0x00f4
                           0000F5   385 _ADC_DAT_H	=	0x00f5
                           0000F6   386 _ADC_CHAN	=	0x00f6
                           0000A6   387 _LED_COMMON	=	0x00a6
                           0000A7   388 _LED_PWM_OE	=	0x00a7
                           00C7C6   389 _LED_DMA	=	0xc7c6
                           0000C6   390 _LED_DMA_L	=	0x00c6
                           0000C7   391 _LED_DMA_H	=	0x00c7
                           0000F7   392 _LED_STATUS	=	0x00f7
                           0000B3   393 _I2CX_INT	=	0x00b3
                           0000BB   394 _I2CS_INT_ST	=	0x00bb
                                    395 ;--------------------------------------------------------
                                    396 ; special function bits
                                    397 ;--------------------------------------------------------
                                    398 	.area RSEG    (ABS,DATA)
      000000                        399 	.org 0x0000
                           0000D7   400 _CY	=	0x00d7
                           0000D6   401 _AC	=	0x00d6
                           0000D5   402 _F0	=	0x00d5
                           0000D4   403 _RS1	=	0x00d4
                           0000D3   404 _RS0	=	0x00d3
                           0000D2   405 _OV	=	0x00d2
                           0000D1   406 _F1	=	0x00d1
                           0000D0   407 _P	=	0x00d0
                           0000AF   408 _EA	=	0x00af
                           0000AE   409 _E_DIS	=	0x00ae
                           0000AD   410 _ET2	=	0x00ad
                           0000AC   411 _ES	=	0x00ac
                           0000AB   412 _ET1	=	0x00ab
                           0000AA   413 _EX1	=	0x00aa
                           0000A9   414 _ET0	=	0x00a9
                           0000A8   415 _EX0	=	0x00a8
                           0000BF   416 _PH_FLAG	=	0x00bf
                           0000BE   417 _PL_FLAG	=	0x00be
                           0000BD   418 _PT2	=	0x00bd
                           0000BC   419 _PS	=	0x00bc
                           0000BB   420 _PT1	=	0x00bb
                           0000BA   421 _PX1	=	0x00ba
                           0000B9   422 _PT0	=	0x00b9
                           0000B8   423 _PX0	=	0x00b8
                           0000EF   424 _IE_WDOG	=	0x00ef
                           0000EE   425 _IE_GPIO	=	0x00ee
                           0000ED   426 _IE_PWM_I2C	=	0x00ed
                           0000EC   427 _IE_UART1	=	0x00ec
                           0000EB   428 _IE_ADC	=	0x00eb
                           0000E9   429 _IE_USB	=	0x00e9
                           0000E8   430 _IE_SPI0	=	0x00e8
                           000087   431 _P0_7	=	0x0087
                           000086   432 _P0_6	=	0x0086
                           000085   433 _P0_5	=	0x0085
                           000084   434 _P0_4	=	0x0084
                           000083   435 _P0_3	=	0x0083
                           000082   436 _P0_2	=	0x0082
                           000081   437 _P0_1	=	0x0081
                           000080   438 _P0_0	=	0x0080
                           000081   439 _SDA0	=	0x0081
                           000080   440 _SCL0	=	0x0080
                           000083   441 _TXD_	=	0x0083
                           000082   442 _RXD_	=	0x0082
                           000085   443 _AIN13	=	0x0085
                           000084   444 _AIN12	=	0x0084
                           000083   445 _AIN11	=	0x0083
                           000082   446 _AIN10	=	0x0082
                           000081   447 _AIN9	=	0x0081
                           000080   448 _AIN8	=	0x0080
                           000097   449 _P1_7	=	0x0097
                           000096   450 _P1_6	=	0x0096
                           000095   451 _P1_5	=	0x0095
                           000094   452 _P1_4	=	0x0094
                           000093   453 _P1_3	=	0x0093
                           000092   454 _P1_2	=	0x0092
                           000091   455 _P1_1	=	0x0091
                           000090   456 _P1_0	=	0x0090
                           000097   457 _TXD1_	=	0x0097
                           000096   458 _RXD1_	=	0x0096
                           000097   459 _SCK	=	0x0097
                           000096   460 _MISO	=	0x0096
                           000095   461 _MOSI	=	0x0095
                           000094   462 _SCS	=	0x0094
                           000092   463 _INT0_	=	0x0092
                           000091   464 _T2EX	=	0x0091
                           000091   465 _CAP2	=	0x0091
                           000090   466 _T2	=	0x0090
                           000090   467 _CAP1	=	0x0090
                           000097   468 _AIN7	=	0x0097
                           000096   469 _AIN6	=	0x0096
                           000095   470 _AIN5	=	0x0095
                           000094   471 _AIN4	=	0x0094
                           000093   472 _AIN3	=	0x0093
                           000092   473 _AIN2	=	0x0092
                           000091   474 _AIN1	=	0x0091
                           000090   475 _AIN0	=	0x0090
                           0000A7   476 _P2_7	=	0x00a7
                           0000A6   477 _P2_6	=	0x00a6
                           0000A5   478 _P2_5	=	0x00a5
                           0000A4   479 _P2_4	=	0x00a4
                           0000A3   480 _P2_3	=	0x00a3
                           0000A2   481 _P2_2	=	0x00a2
                           0000A1   482 _P2_1	=	0x00a1
                           0000A0   483 _P2_0	=	0x00a0
                           0000A7   484 _TXD1	=	0x00a7
                           0000A6   485 _RXD1	=	0x00a6
                           0000A5   486 _T2EX_	=	0x00a5
                           0000A5   487 _CAP2_	=	0x00a5
                           0000A4   488 _T2_	=	0x00a4
                           0000A4   489 _CAP1_	=	0x00a4
                           0000B7   490 _P3_7	=	0x00b7
                           0000B6   491 _P3_6	=	0x00b6
                           0000B5   492 _P3_5	=	0x00b5
                           0000B4   493 _P3_4	=	0x00b4
                           0000B3   494 _P3_3	=	0x00b3
                           0000B2   495 _P3_2	=	0x00b2
                           0000B1   496 _P3_1	=	0x00b1
                           0000B0   497 _P3_0	=	0x00b0
                           0000B7   498 _SCK1	=	0x00b7
                           0000B6   499 _MISO1	=	0x00b6
                           0000B5   500 _MOSI1	=	0x00b5
                           0000B5   501 _T1	=	0x00b5
                           0000B4   502 _T0	=	0x00b4
                           0000B3   503 _INT1	=	0x00b3
                           0000B2   504 _INT0	=	0x00b2
                           0000B1   505 _TXD	=	0x00b1
                           0000B0   506 _RXD	=	0x00b0
                           0000C6   507 _P4_6	=	0x00c6
                           0000C5   508 _P4_5	=	0x00c5
                           0000C4   509 _P4_4	=	0x00c4
                           0000C3   510 _P4_3	=	0x00c3
                           0000C2   511 _P4_2	=	0x00c2
                           0000C1   512 _P4_1	=	0x00c1
                           0000C0   513 _P4_0	=	0x00c0
                           00008F   514 _TF1	=	0x008f
                           00008E   515 _TR1	=	0x008e
                           00008D   516 _TF0	=	0x008d
                           00008C   517 _TR0	=	0x008c
                           00008B   518 _IE1	=	0x008b
                           00008A   519 _IT1	=	0x008a
                           000089   520 _IE0	=	0x0089
                           000088   521 _IT0	=	0x0088
                           00009F   522 _SM0	=	0x009f
                           00009E   523 _SM1	=	0x009e
                           00009D   524 _SM2	=	0x009d
                           00009C   525 _REN	=	0x009c
                           00009B   526 _TB8	=	0x009b
                           00009A   527 _RB8	=	0x009a
                           000099   528 _TI	=	0x0099
                           000098   529 _RI	=	0x0098
                           0000CF   530 _TF2	=	0x00cf
                           0000CF   531 _CAP1F	=	0x00cf
                           0000CE   532 _EXF2	=	0x00ce
                           0000CD   533 _RCLK	=	0x00cd
                           0000CC   534 _TCLK	=	0x00cc
                           0000CB   535 _EXEN2	=	0x00cb
                           0000CA   536 _TR2	=	0x00ca
                           0000C9   537 _C_T2	=	0x00c9
                           0000C8   538 _CP_RL2	=	0x00c8
                           0000FF   539 _S0_FST_ACT	=	0x00ff
                           0000FE   540 _S0_IF_OV	=	0x00fe
                           0000FD   541 _S0_IF_FIRST	=	0x00fd
                           0000FC   542 _S0_IF_BYTE	=	0x00fc
                           0000FB   543 _S0_FREE	=	0x00fb
                           0000FA   544 _S0_T_FIFO	=	0x00fa
                           0000F8   545 _S0_R_FIFO	=	0x00f8
                           0000F7   546 _ADC_START	=	0x00f7
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable register banks
                                    549 ;--------------------------------------------------------
                                    550 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        551 	.ds 8
                                    552 ;--------------------------------------------------------
                                    553 ; internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area DSEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; overlayable items in internal ram
                                    558 ;--------------------------------------------------------
                                    559 	.area	OSEG    (OVR,DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; indirectly addressable internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area ISEG    (DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; absolute internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area IABS    (ABS,DATA)
                                    568 	.area IABS    (ABS,DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; bit data
                                    571 ;--------------------------------------------------------
                                    572 	.area BSEG    (BIT)
                                    573 ;--------------------------------------------------------
                                    574 ; paged external ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area PSEG    (PAG,XDATA)
                                    577 ;--------------------------------------------------------
                                    578 ; uninitialized external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XSEG    (XDATA)
      000C04                        581 _switch_events_PARM_2:
      000C04                        582 	.ds 1
      000C05                        583 _switch_events_PARM_3:
      000C05                        584 	.ds 1
      000C06                        585 _switch_events_row_10000_492:
      000C06                        586 	.ds 1
      000C07                        587 _generate_tick_event_last_tick_10000_495:
      000C07                        588 	.ds 2
      000C09                        589 _matrix_task_last_tick_60000_524:
      000C09                        590 	.ds 2
      000C0B                        591 _matrix_task_dummy_event_70000_525:
      000C0B                        592 	.ds 6
      000C11                        593 _matrix_task_matrix_previous_10001_502:
      000C11                        594 	.ds 16
      000C21                        595 _matrix_task_matrix_changed_10002_503:
      000C21                        596 	.ds 1
      000C22                        597 _matrix_task_last_tick_60002_528:
      000C22                        598 	.ds 2
      000C24                        599 _matrix_task_dummy_event_70002_529:
      000C24                        600 	.ds 6
      000C2A                        601 _matrix_task_row_changes_30003_512:
      000C2A                        602 	.ds 1
      000C2B                        603 _matrix_task_col_mask_30004_515:
      000C2B                        604 	.ds 1
      000C2C                        605 _matrix_task_dummy_event_90004_521:
      000C2C                        606 	.ds 6
                                    607 ;--------------------------------------------------------
                                    608 ; absolute external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XABS    (ABS,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; initialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XISEG   (XDATA)
      000EB8                        615 _last_input_modification_time:
      000EB8                        616 	.ds 4
      000EBC                        617 _last_matrix_modification_time:
      000EBC                        618 	.ds 4
      000EC0                        619 _last_encoder_modification_time:
      000EC0                        620 	.ds 4
      000EC4                        621 _last_pointing_device_modification_time:
      000EC4                        622 	.ds 4
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT0 (CODE)
                                    625 	.area GSINIT1 (CODE)
                                    626 	.area GSINIT2 (CODE)
                                    627 	.area GSINIT3 (CODE)
                                    628 	.area GSINIT4 (CODE)
                                    629 	.area GSINIT5 (CODE)
                                    630 	.area GSINIT  (CODE)
                                    631 	.area GSFINAL (CODE)
                                    632 	.area CSEG    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; global & static initialisations
                                    635 ;--------------------------------------------------------
                                    636 	.area HOME    (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 	.area GSFINAL (CODE)
                                    639 	.area GSINIT  (CODE)
                                    640 ;------------------------------------------------------------
                                    641 ;Allocation info for local variables in function 'generate_tick_event'
                                    642 ;------------------------------------------------------------
                                    643 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_495'
                                    644 ;now           Allocated with name '_generate_tick_event_now_10000_495'
                                    645 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_497'
                                    646 ;------------------------------------------------------------
                                    647 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      0030DA 90 0C 07         [24]  648 	mov	dptr,#_generate_tick_event_last_tick_10000_495
      0030DD E4               [12]  649 	clr	a
      0030DE F0               [24]  650 	movx	@dptr,a
      0030DF A3               [24]  651 	inc	dptr
      0030E0 F0               [24]  652 	movx	@dptr,a
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'matrix_task'
                                    655 ;------------------------------------------------------------
                                    656 ;last_tick     Allocated with name '_matrix_task_last_tick_60000_524'
                                    657 ;now           Allocated with name '_matrix_task_now_60000_524'
                                    658 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70000_525'
                                    659 ;matrix_previous Allocated with name '_matrix_task_matrix_previous_10001_502'
                                    660 ;matrix_changed Allocated with name '_matrix_task_matrix_changed_10002_503'
                                    661 ;row           Allocated with name '_matrix_task_row_20002_504'
                                    662 ;last_tick     Allocated with name '_matrix_task_last_tick_60002_528'
                                    663 ;now           Allocated with name '_matrix_task_now_60002_528'
                                    664 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70002_529'
                                    665 ;process_keypress Allocated with name '_matrix_task_process_keypress_10003_510'
                                    666 ;row           Allocated with name '_matrix_task_row_20003_511'
                                    667 ;__400030090   Allocated with name '_matrix_task___400030090_40003_512'
                                    668 ;current_row   Allocated with name '_matrix_task_current_row_30003_512'
                                    669 ;row_changes   Allocated with name '_matrix_task_row_changes_30003_512'
                                    670 ;__500030091   Allocated with name '_matrix_task___500030091_50003_530'
                                    671 ;__500030092   Allocated with name '_matrix_task___500030092_50003_530'
                                    672 ;row           Allocated with name '_matrix_task_row_60003_531'
                                    673 ;rowdata       Allocated with name '_matrix_task_rowdata_60003_531'
                                    674 ;col_mask      Allocated with name '_matrix_task_col_mask_30004_515'
                                    675 ;col           Allocated with name '_matrix_task_col_40004_516'
                                    676 ;key_pressed   Allocated with name '_matrix_task_key_pressed_70004_519'
                                    677 ;dummy_event   Allocated with name '_matrix_task_dummy_event_90004_521'
                                    678 ;------------------------------------------------------------
                                    679 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      0030E1 90 0C 09         [24]  680 	mov	dptr,#_matrix_task_last_tick_60000_524
      0030E4 E4               [12]  681 	clr	a
      0030E5 F0               [24]  682 	movx	@dptr,a
      0030E6 A3               [24]  683 	inc	dptr
      0030E7 F0               [24]  684 	movx	@dptr,a
      0030E8 90 0C 22         [24]  685 	mov	dptr,#_matrix_task_last_tick_60002_528
      0030EB F0               [24]  686 	movx	@dptr,a
      0030EC A3               [24]  687 	inc	dptr
      0030ED F0               [24]  688 	movx	@dptr,a
                                    689 ;--------------------------------------------------------
                                    690 ; Home
                                    691 ;--------------------------------------------------------
                                    692 	.area HOME    (CODE)
                                    693 	.area HOME    (CODE)
                                    694 ;--------------------------------------------------------
                                    695 ; code
                                    696 ;--------------------------------------------------------
                                    697 	.area CSEG    (CODE)
                                    698 ;------------------------------------------------------------
                                    699 ;Allocation info for local variables in function 'IS_KEYEVENT'
                                    700 ;------------------------------------------------------------
                                    701 ;event         Allocated with name '_IS_KEYEVENT_PARM_1'
                                    702 ;------------------------------------------------------------
                                    703 ;	quantum/keyboard.c:36: bool IS_KEYEVENT(const keyevent_t event) {
                                    704 ;	-----------------------------------------
                           000007   705 	ar7 = 0x07
                           000006   706 	ar6 = 0x06
                           000005   707 	ar5 = 0x05
                           000004   708 	ar4 = 0x04
                           000003   709 	ar3 = 0x03
                           000002   710 	ar2 = 0x02
                           000001   711 	ar1 = 0x01
                           000000   712 	ar0 = 0x00
                                    713 ;	 function last_matrix_activity_trigger
                                    714 ;	-----------------------------------------
      009AE1                        715 _last_matrix_activity_trigger:
                                    716 ;	quantum/keyboard.c:190: last_matrix_modification_time = last_input_modification_time = sync_timer_read32();
      009AE1 12 4F C3         [24]  717 	lcall	_timer_read32
      009AE4 12 55 D5         [24]  718 	lcall	_ak820_outline_0062
      009AE7 90 0E B8         [24]  719 	mov	dptr,#_last_input_modification_time
      009AEA 12 98 AA         [24]  720 	lcall	_ak820_outline_0008
      009AED 90 0E BC         [24]  721 	mov	dptr,#_last_matrix_modification_time
      009AF0 12 98 AA         [24]  722 	lcall	_ak820_outline_0008
                                    723 ;	quantum/keyboard.c:191: }
      009AF3 22               [24]  724 	ret
                                    725 ;------------------------------------------------------------
                                    726 ;Allocation info for local variables in function 'last_encoder_activity_time'
                                    727 ;------------------------------------------------------------
                                    728 ;	quantum/keyboard.c:194: uint32_t        last_encoder_activity_time(void) {
                                    729 ;	-----------------------------------------
                                    730 ;	 function last_encoder_activity_trigger
                                    731 ;	-----------------------------------------
      009AF4                        732 _last_encoder_activity_trigger:
                                    733 ;	quantum/keyboard.c:201: last_encoder_modification_time = last_input_modification_time = sync_timer_read32();
      009AF4 12 4F C3         [24]  734 	lcall	_timer_read32
      009AF7 12 55 D5         [24]  735 	lcall	_ak820_outline_0062
      009AFA 90 0E B8         [24]  736 	mov	dptr,#_last_input_modification_time
      009AFD 12 98 AA         [24]  737 	lcall	_ak820_outline_0008
      009B00 90 0E C0         [24]  738 	mov	dptr,#_last_encoder_modification_time
      009B03 12 98 AA         [24]  739 	lcall	_ak820_outline_0008
                                    740 ;	quantum/keyboard.c:202: }
      009B06 22               [24]  741 	ret
                                    742 ;------------------------------------------------------------
                                    743 ;Allocation info for local variables in function 'last_pointing_device_activity_time'
                                    744 ;------------------------------------------------------------
                                    745 ;	quantum/keyboard.c:205: uint32_t        last_pointing_device_activity_time(void) {
                                    746 ;	-----------------------------------------
                                    747 ;	 function keyboard_post_init_kb
                                    748 ;	-----------------------------------------
      009B07                        749 _keyboard_post_init_kb:
                                    750 ;	quantum/keyboard.c:345: keyboard_post_init_user();
                                    751 ;	quantum/keyboard.c:346: }
      009B07 C1 FF            [12]  752 	ajmp	_keyboard_post_init_user
                                    753 ;------------------------------------------------------------
                                    754 ;Allocation info for local variables in function 'matrix_can_read'
                                    755 ;------------------------------------------------------------
                                    756 ;	quantum/keyboard.c:352: __attribute__((weak)) bool matrix_can_read(void) {
                                    757 ;	-----------------------------------------
                                    758 ;	 function matrix_can_read
                                    759 ;	-----------------------------------------
      009B09                        760 _matrix_can_read:
                                    761 ;	quantum/keyboard.c:353: return true;
      009B09 75 82 01         [24]  762 	mov	dpl, #0x01
                                    763 ;	quantum/keyboard.c:354: }
      009B0C 22               [24]  764 	ret
                                    765 ;------------------------------------------------------------
                                    766 ;Allocation info for local variables in function 'keyboard_setup'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/keyboard.c:360: void keyboard_setup(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function keyboard_setup
                                    771 ;	-----------------------------------------
      009B0D                        772 _keyboard_setup:
                                    773 ;	quantum/keyboard.c:361: print_set_sendchar(sendchar);
      009B0D 90 A0 64         [24]  774 	mov	dptr,#_sendchar
      009B10 12 A0 38         [24]  775 	lcall	_print_set_sendchar
                                    776 ;	quantum/keyboard.c:363: eeprom_driver_init();
      009B13 12 44 C6         [24]  777 	lcall	_eeprom_driver_init
                                    778 ;	quantum/keyboard.c:366: vial_init();
                                    779 ;	quantum/keyboard.c:372: keyboard_pre_init_kb();
                                    780 ;	quantum/keyboard.c:373: }
      009B16 02 B5 BA         [24]  781 	ljmp	_vial_init
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'is_keyboard_master'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/keyboard.c:381: __attribute__((weak)) bool is_keyboard_master(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function is_keyboard_master
                                    788 ;	-----------------------------------------
      009B19                        789 _is_keyboard_master:
                                    790 ;	quantum/keyboard.c:382: return true;
      009B19 75 82 01         [24]  791 	mov	dpl, #0x01
                                    792 ;	quantum/keyboard.c:383: }
      009B1C 22               [24]  793 	ret
                                    794 ;------------------------------------------------------------
                                    795 ;Allocation info for local variables in function 'is_keyboard_left'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/keyboard.c:389: __attribute__((weak)) bool is_keyboard_left(void) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function should_process_keypress
                                    800 ;	-----------------------------------------
      009B1D                        801 _should_process_keypress:
                                    802 ;	quantum/keyboard.c:401: return is_keyboard_master();
                                    803 ;	quantum/keyboard.c:402: }
      009B1D 61 19            [12]  804 	ajmp	_is_keyboard_master
                                    805 ;------------------------------------------------------------
                                    806 ;Allocation info for local variables in function 'housekeeping_task_kb'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/keyboard.c:409: __attribute__((weak)) void housekeeping_task_kb(void) {}
                                    809 ;	-----------------------------------------
                                    810 ;	 function housekeeping_task
                                    811 ;	-----------------------------------------
      009B1F                        812 _housekeeping_task:
                                    813 ;	quantum/keyboard.c:424: housekeeping_task_user();
                                    814 ;	quantum/keyboard.c:425: }
      009B1F 22               [24]  815 	ret
                                    816 ;------------------------------------------------------------
                                    817 ;Allocation info for local variables in function 'quantum_init'
                                    818 ;------------------------------------------------------------
                                    819 ;	quantum/keyboard.c:431: void quantum_init(void) {
                                    820 ;	-----------------------------------------
                                    821 ;	 function quantum_init
                                    822 ;	-----------------------------------------
      009B20                        823 _quantum_init:
                                    824 ;	quantum/keyboard.c:432: magic();
      009B20 12 88 90         [24]  825 	lcall	_magic
                                    826 ;	quantum/keyboard.c:433: led_init_ports();
      009B23 12 9F CF         [24]  827 	lcall	_led_init_ports
                                    828 ;	quantum/keyboard.c:444: rgb_matrix_init();
                                    829 ;	quantum/keyboard.c:452: }
      009B26 02 57 72         [24]  830 	ljmp	_rgb_matrix_init
                                    831 ;------------------------------------------------------------
                                    832 ;Allocation info for local variables in function 'keyboard_init'
                                    833 ;------------------------------------------------------------
                                    834 ;	quantum/keyboard.c:458: void keyboard_init(void) {
                                    835 ;	-----------------------------------------
                                    836 ;	 function keyboard_init
                                    837 ;	-----------------------------------------
      009B29                        838 _keyboard_init:
                                    839 ;	quantum/keyboard.c:459: timer_init();
      009B29 12 4F 85         [24]  840 	lcall	_timer_init
                                    841 ;	quantum/keyboard.c:462: via_init();
      009B2C 12 AE C1         [24]  842 	lcall	_via_init
                                    843 ;	quantum/keyboard.c:468: encoder_init();
      009B2F 11 ED            [12]  844 	acall	_encoder_init
                                    845 ;	quantum/keyboard.c:470: matrix_init();
      009B31 12 60 68         [24]  846 	lcall	_matrix_init
                                    847 ;	quantum/keyboard.c:471: quantum_init();
      009B34 71 20            [12]  848 	acall	_quantum_init
                                    849 ;	quantum/keyboard.c:521: keyboard_post_init_kb(); /* Always keep this last */
                                    850 ;	quantum/keyboard.c:522: }
      009B36 61 07            [12]  851 	ajmp	_keyboard_post_init_kb
                                    852 ;------------------------------------------------------------
                                    853 ;Allocation info for local variables in function 'switch_events'
                                    854 ;------------------------------------------------------------
                                    855 ;col           Allocated with name '_switch_events_PARM_2'
                                    856 ;pressed       Allocated with name '_switch_events_PARM_3'
                                    857 ;row           Allocated with name '_switch_events_row_10000_492'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/keyboard.c:529: void switch_events(uint8_t row, uint8_t col, bool pressed) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function switch_events
                                    862 ;	-----------------------------------------
      009B38                        863 _switch_events:
      009B38 E5 82            [12]  864 	mov	a,dpl
      009B3A 90 0C 06         [24]  865 	mov	dptr,#_switch_events_row_10000_492
      009B3D F0               [24]  866 	movx	@dptr,a
                                    867 ;	quantum/keyboard.c:534: process_rgb_matrix(row, col, pressed);
      009B3E E0               [24]  868 	movx	a,@dptr
      009B3F FF               [12]  869 	mov	r7,a
      009B40 90 0C 04         [24]  870 	mov	dptr,#_switch_events_PARM_2
      009B43 E0               [24]  871 	movx	a,@dptr
      009B44 FE               [12]  872 	mov	r6,a
      009B45 90 0C 05         [24]  873 	mov	dptr,#_switch_events_PARM_3
      009B48 E0               [24]  874 	movx	a,@dptr
      009B49 FD               [12]  875 	mov	r5,a
      009B4A 90 07 99         [24]  876 	mov	dptr,#_process_rgb_matrix_PARM_2
      009B4D EE               [12]  877 	mov	a,r6
      009B4E F0               [24]  878 	movx	@dptr,a
      009B4F 90 07 9A         [24]  879 	mov	dptr,#_process_rgb_matrix_PARM_3
      009B52 12 42 41         [24]  880 	lcall	_ak820_outline_0199
                                    881 ;	quantum/keyboard.c:536: }
      009B55 02 5B 07         [24]  882 	ljmp	_process_rgb_matrix
                                    883 ;------------------------------------------------------------
                                    884 ;Allocation info for local variables in function 'generate_tick_event'
                                    885 ;------------------------------------------------------------
                                    886 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_495'
                                    887 ;now           Allocated with name '_generate_tick_event_now_10000_495'
                                    888 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_497'
                                    889 ;------------------------------------------------------------
                                    890 ;	quantum/keyboard.c:542: static inline void generate_tick_event(void) {
                                    891 ;	-----------------------------------------
                                    892 ;	 function matrix_task
                                    893 ;	-----------------------------------------
      009B58                        894 _matrix_task:
                                    895 ;	quantum/keyboard.c:562: if (!matrix_can_read()) {
      009B58 71 09            [12]  896 	acall	_matrix_can_read
      009B5A E5 82            [12]  897 	mov	a, dpl
      009B5C 70 4B            [24]  898 	jnz	00102$
                                    899 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      009B5E 12 4F F4         [24]  900 	lcall	_timer_read
      009B61 12 4A 1E         [24]  901 	lcall	_ak820_outline_0144
                                    902 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      009B64 90 0C 09         [24]  903 	mov	dptr,#_matrix_task_last_tick_60000_524
      009B67 12 38 50         [24]  904 	lcall	_ak820_outline_0065
      009B6A EE               [12]  905 	mov	a,r6
      009B6B C3               [12]  906 	clr	c
      009B6C 9C               [12]  907 	subb	a,r4
      009B6D FC               [12]  908 	mov	r4,a
      009B6E EF               [12]  909 	mov	a,r7
      009B6F 9D               [12]  910 	subb	a,r5
      009B70 4C               [12]  911 	orl	a,r4
      009B71 60 32            [24]  912 	jz	00120$
                                    913 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      009B73 90 0C 0B         [24]  914 	mov	dptr,#_matrix_task_dummy_event_70000_525
      009B76 E4               [12]  915 	clr	a
      009B77 F0               [24]  916 	movx	@dptr,a
      009B78 90 0C 0C         [24]  917 	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0001)
      009B7B F0               [24]  918 	movx	@dptr,a
      009B7C 12 4F F4         [24]  919 	lcall	_timer_read
      009B7F 12 4A 2F         [24]  920 	lcall	_ak820_outline_0160
      009B82 90 0C 0D         [24]  921 	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0002)
      009B85 12 38 5C         [24]  922 	lcall	_ak820_outline_0079
      009B88 90 0C 0F         [24]  923 	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0004)
      009B8B E4               [12]  924 	clr	a
      009B8C F0               [24]  925 	movx	@dptr,a
      009B8D 90 0C 10         [24]  926 	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0005)
      009B90 F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
      009B91 90 0C 0B         [24]  929 	mov	dptr,#_matrix_task_dummy_event_70000_525
      009B94 C0 07            [24]  930 	push	ar7
      009B96 C0 06            [24]  931 	push	ar6
      009B98 12 76 F3         [24]  932 	lcall	_ak820_action_exec
      009B9B D0 06            [24]  933 	pop	ar6
      009B9D D0 07            [24]  934 	pop	ar7
                                    935 ;	quantum/keyboard.c:550: last_tick = now;
      009B9F 90 0C 09         [24]  936 	mov	dptr,#_matrix_task_last_tick_60000_524
      009BA2 12 4F 49         [24]  937 	lcall	_ak820_outline_0064
                                    938 ;	quantum/keyboard.c:563: generate_tick_event();
      009BA5                        939 00120$:
                                    940 ;	quantum/keyboard.c:564: return false;
      009BA5 75 82 00         [24]  941 	mov	dpl, #0x00
      009BA8 22               [24]  942 	ret
      009BA9                        943 00102$:
                                    944 ;	quantum/keyboard.c:569: matrix_scan();
      009BA9 12 60 91         [24]  945 	lcall	_matrix_scan
                                    946 ;	quantum/keyboard.c:573: vial_unlock_task();
      009BAC 12 B5 25         [24]  947 	lcall	_vial_unlock_task
                                    948 ;	quantum/keyboard.c:575: bool matrix_changed = false;
      009BAF 90 0C 21         [24]  949 	mov	dptr,#_matrix_task_matrix_changed_10002_503
      009BB2 E4               [12]  950 	clr	a
      009BB3 F0               [24]  951 	movx	@dptr,a
                                    952 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009BB4 FF               [12]  953 	mov	r7,a
      009BB5                        954 00127$:
      009BB5 BF 10 00         [24]  955 	cjne	r7,#0x10,00247$
      009BB8                        956 00247$:
      009BB8 50 1F            [24]  957 	jnc	00103$
      009BBA 90 0C 21         [24]  958 	mov	dptr,#_matrix_task_matrix_changed_10002_503
      009BBD E0               [24]  959 	movx	a,@dptr
      009BBE 70 19            [24]  960 	jnz	00103$
                                    961 ;	quantum/keyboard.c:577: matrix_changed |= matrix_previous[row] ^ matrix_get_row(row);
      009BC0 EF               [12]  962 	mov	a,r7
      009BC1 12 9D 10         [24]  963 	lcall	_ak820_outline_0072
      009BC4 E0               [24]  964 	movx	a,@dptr
      009BC5 FE               [12]  965 	mov	r6,a
      009BC6 8F 82            [24]  966 	mov	dpl, r7
      009BC8 12 60 1D         [24]  967 	lcall	_matrix_get_row
      009BCB E5 82            [12]  968 	mov	a,dpl
      009BCD 6E               [12]  969 	xrl	a,r6
                                    970 ;	assignBit
      009BCE 90 0C 21         [24]  971 	mov	dptr,#_matrix_task_matrix_changed_10002_503
      009BD1 24 FF            [12]  972 	add	a,#0xff
      009BD3 E4               [12]  973 	clr	a
      009BD4 33               [12]  974 	rlc	a
      009BD5 F0               [24]  975 	movx	@dptr,a
                                    976 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009BD6 0F               [12]  977 	inc	r7
      009BD7 80 DC            [24]  978 	sjmp	00127$
      009BD9                        979 00103$:
                                    980 ;	quantum/keyboard.c:583: if (!matrix_changed) {
      009BD9 90 0C 21         [24]  981 	mov	dptr,#_matrix_task_matrix_changed_10002_503
      009BDC E0               [24]  982 	movx	a,@dptr
      009BDD 70 4B            [24]  983 	jnz	00105$
                                    984 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      009BDF 12 4F F4         [24]  985 	lcall	_timer_read
      009BE2 12 4A 1E         [24]  986 	lcall	_ak820_outline_0144
                                    987 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      009BE5 90 0C 22         [24]  988 	mov	dptr,#_matrix_task_last_tick_60002_528
      009BE8 12 38 50         [24]  989 	lcall	_ak820_outline_0065
      009BEB EE               [12]  990 	mov	a,r6
      009BEC C3               [12]  991 	clr	c
      009BED 9C               [12]  992 	subb	a,r4
      009BEE FC               [12]  993 	mov	r4,a
      009BEF EF               [12]  994 	mov	a,r7
      009BF0 9D               [12]  995 	subb	a,r5
      009BF1 4C               [12]  996 	orl	a,r4
      009BF2 60 32            [24]  997 	jz	00123$
                                    998 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      009BF4 90 0C 24         [24]  999 	mov	dptr,#_matrix_task_dummy_event_70002_529
      009BF7 E4               [12] 1000 	clr	a
      009BF8 F0               [24] 1001 	movx	@dptr,a
      009BF9 90 0C 25         [24] 1002 	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0001)
      009BFC F0               [24] 1003 	movx	@dptr,a
      009BFD 12 4F F4         [24] 1004 	lcall	_timer_read
      009C00 12 4A 2F         [24] 1005 	lcall	_ak820_outline_0160
      009C03 90 0C 26         [24] 1006 	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0002)
      009C06 12 38 5C         [24] 1007 	lcall	_ak820_outline_0079
      009C09 90 0C 28         [24] 1008 	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0004)
      009C0C E4               [12] 1009 	clr	a
      009C0D F0               [24] 1010 	movx	@dptr,a
      009C0E 90 0C 29         [24] 1011 	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0005)
      009C11 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
      009C12 90 0C 24         [24] 1014 	mov	dptr,#_matrix_task_dummy_event_70002_529
      009C15 C0 07            [24] 1015 	push	ar7
      009C17 C0 06            [24] 1016 	push	ar6
      009C19 12 76 F3         [24] 1017 	lcall	_ak820_action_exec
      009C1C D0 06            [24] 1018 	pop	ar6
      009C1E D0 07            [24] 1019 	pop	ar7
                                   1020 ;	quantum/keyboard.c:550: last_tick = now;
      009C20 90 0C 22         [24] 1021 	mov	dptr,#_matrix_task_last_tick_60002_528
      009C23 12 4F 49         [24] 1022 	lcall	_ak820_outline_0064
                                   1023 ;	quantum/keyboard.c:584: generate_tick_event();
      009C26                       1024 00123$:
                                   1025 ;	quantum/keyboard.c:585: return matrix_changed;
      009C26 75 82 00         [24] 1026 	mov	dpl, #0x00
      009C29 22               [24] 1027 	ret
      009C2A                       1028 00105$:
                                   1029 ;	quantum/keyboard.c:588: if (debug_config.matrix) {
      009C2A 90 0E CC         [24] 1030 	mov	dptr,#_debug_config
      009C2D E0               [24] 1031 	movx	a,@dptr
      009C2E 30 E1 03         [24] 1032 	jnb	acc.1,00107$
                                   1033 ;	quantum/keyboard.c:589: matrix_print();
      009C31 12 60 BD         [24] 1034 	lcall	_matrix_print
      009C34                       1035 00107$:
                                   1036 ;	quantum/keyboard.c:592: const bool process_keypress = should_process_keypress();
      009C34 71 1D            [12] 1037 	acall	_should_process_keypress
      009C36 AF 82            [24] 1038 	mov	r7, dpl
                                   1039 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      009C38 7E 00            [12] 1040 	mov	r6,#0x00
      009C3A                       1041 00133$:
      009C3A BE 10 00         [24] 1042 	cjne	r6,#0x10,00253$
      009C3D                       1043 00253$:
      009C3D 40 02            [24] 1044 	jc	00254$
      009C3F 81 F1            [24] 1045 	ajmp	00117$
      009C41                       1046 00254$:
                                   1047 ;	quantum/keyboard.c:595: const matrix_row_t current_row = matrix_get_row(row);
      009C41 8E 82            [24] 1048 	mov	dpl, r6
      009C43 12 60 1D         [24] 1049 	lcall	_matrix_get_row
      009C46 AD 82            [24] 1050 	mov	r5, dpl
                                   1051 ;	quantum/keyboard.c:596: const matrix_row_t row_changes = current_row ^ matrix_previous[row];
      009C48 EE               [12] 1052 	mov	a,r6
      009C49 12 9D 10         [24] 1053 	lcall	_ak820_outline_0072
      009C4C E0               [24] 1054 	movx	a,@dptr
      009C4D FC               [12] 1055 	mov	r4,a
      009C4E ED               [12] 1056 	mov	a,r5
      009C4F 62 04            [12] 1057 	xrl	ar4,a
      009C51 90 0C 2A         [24] 1058 	mov	dptr,#_matrix_task_row_changes_30003_512
      009C54 EC               [12] 1059 	mov	a,r4
      009C55 F0               [24] 1060 	movx	@dptr,a
                                   1061 ;	quantum/keyboard.c:598: if (!row_changes || has_ghost_in_row(row, current_row)) {
      009C56 EC               [12] 1062 	mov	a,r4
      009C57 70 02            [24] 1063 	jnz	00255$
      009C59 81 EE            [24] 1064 	ajmp	00116$
      009C5B                       1065 00255$:
                                   1066 ;	quantum/keyboard.c:602: matrix_row_t col_mask = 1;
      009C5B 90 0C 2B         [24] 1067 	mov	dptr,#_matrix_task_col_mask_30004_515
      009C5E 74 01            [12] 1068 	mov	a,#0x01
      009C60 F0               [24] 1069 	movx	@dptr,a
                                   1070 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      009C61 7C 00            [12] 1071 	mov	r4,#0x00
      009C63                       1072 00130$:
      009C63 BC 08 00         [24] 1073 	cjne	r4,#0x08,00256$
      009C66                       1074 00256$:
      009C66 40 02            [24] 1075 	jc	00257$
      009C68 81 E8            [24] 1076 	ajmp	00115$
      009C6A                       1077 00257$:
                                   1078 ;	quantum/keyboard.c:604: if (row_changes & col_mask) {
      009C6A 90 0C 2A         [24] 1079 	mov	dptr,#_matrix_task_row_changes_30003_512
      009C6D E0               [24] 1080 	movx	a,@dptr
      009C6E FB               [12] 1081 	mov	r3,a
      009C6F 90 0C 2B         [24] 1082 	mov	dptr,#_matrix_task_col_mask_30004_515
      009C72 E0               [24] 1083 	movx	a,@dptr
      009C73 FA               [12] 1084 	mov	r2,a
      009C74 5B               [12] 1085 	anl	a,r3
      009C75 60 67            [24] 1086 	jz	00131$
                                   1087 ;	quantum/keyboard.c:605: const bool key_pressed = current_row & col_mask;
      009C77 ED               [12] 1088 	mov	a,r5
      009C78 52 02            [12] 1089 	anl	ar2,a
                                   1090 ;	assignBit
      009C7A EA               [12] 1091 	mov	a,r2
      009C7B 24 FF            [12] 1092 	add	a,#0xff
      009C7D E4               [12] 1093 	clr	a
      009C7E 33               [12] 1094 	rlc	a
      009C7F FA               [12] 1095 	mov	r2,a
                                   1096 ;	quantum/keyboard.c:607: if (process_keypress) {
      009C80 EF               [12] 1097 	mov	a,r7
      009C81 60 3D            [24] 1098 	jz	00112$
                                   1099 ;	quantum/keyboard.c:609: MAKE_KEYEVENT(row, col, key_pressed);
      009C83 90 0C 2C         [24] 1100 	mov	dptr,#_matrix_task_dummy_event_90004_521
      009C86 EC               [12] 1101 	mov	a,r4
      009C87 F0               [24] 1102 	movx	@dptr,a
      009C88 90 0C 2D         [24] 1103 	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0001)
      009C8B EE               [12] 1104 	mov	a,r6
      009C8C F0               [24] 1105 	movx	@dptr,a
      009C8D 12 4F F4         [24] 1106 	lcall	_timer_read
      009C90 A9 82            [24] 1107 	mov	r1, dpl
      009C92 AB 83            [24] 1108 	mov	r3, dph
      009C94 90 0C 2E         [24] 1109 	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0002)
      009C97 E9               [12] 1110 	mov	a,r1
      009C98 12 7D A0         [24] 1111 	lcall	_ak820_outline_0197
      009C9B 90 0C 30         [24] 1112 	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0004)
      009C9E 74 01            [12] 1113 	mov	a,#0x01
      009CA0 F0               [24] 1114 	movx	@dptr,a
      009CA1 90 0C 31         [24] 1115 	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0005)
      009CA4 EA               [12] 1116 	mov	a,r2
      009CA5 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/keyboard.c:610: AK820_ACTION_EXEC(dummy_event);
      009CA6 90 0C 2C         [24] 1119 	mov	dptr,#_matrix_task_dummy_event_90004_521
      009CA9 C0 07            [24] 1120 	push	ar7
      009CAB C0 06            [24] 1121 	push	ar6
      009CAD C0 05            [24] 1122 	push	ar5
      009CAF C0 04            [24] 1123 	push	ar4
      009CB1 C0 02            [24] 1124 	push	ar2
      009CB3 12 76 F3         [24] 1125 	lcall	_ak820_action_exec
      009CB6 D0 02            [24] 1126 	pop	ar2
      009CB8 D0 04            [24] 1127 	pop	ar4
      009CBA D0 05            [24] 1128 	pop	ar5
      009CBC D0 06            [24] 1129 	pop	ar6
      009CBE D0 07            [24] 1130 	pop	ar7
      009CC0                       1131 00112$:
                                   1132 ;	quantum/keyboard.c:613: switch_events(row, col, key_pressed);
      009CC0 90 0C 04         [24] 1133 	mov	dptr,#_switch_events_PARM_2
      009CC3 EC               [12] 1134 	mov	a,r4
      009CC4 F0               [24] 1135 	movx	@dptr,a
      009CC5 90 0C 05         [24] 1136 	mov	dptr,#_switch_events_PARM_3
      009CC8 EA               [12] 1137 	mov	a,r2
      009CC9 F0               [24] 1138 	movx	@dptr,a
      009CCA 8E 82            [24] 1139 	mov	dpl, r6
      009CCC C0 07            [24] 1140 	push	ar7
      009CCE C0 06            [24] 1141 	push	ar6
      009CD0 C0 05            [24] 1142 	push	ar5
      009CD2 C0 04            [24] 1143 	push	ar4
      009CD4 71 38            [12] 1144 	acall	_switch_events
      009CD6 D0 04            [24] 1145 	pop	ar4
      009CD8 D0 05            [24] 1146 	pop	ar5
      009CDA D0 06            [24] 1147 	pop	ar6
      009CDC D0 07            [24] 1148 	pop	ar7
      009CDE                       1149 00131$:
                                   1150 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      009CDE 0C               [12] 1151 	inc	r4
      009CDF 90 0C 2B         [24] 1152 	mov	dptr,#_matrix_task_col_mask_30004_515
      009CE2 E0               [24] 1153 	movx	a,@dptr
      009CE3 25 E0            [12] 1154 	add	a,acc
      009CE5 F0               [24] 1155 	movx	@dptr,a
      009CE6 81 63            [24] 1156 	ajmp	00130$
      009CE8                       1157 00115$:
                                   1158 ;	quantum/keyboard.c:617: matrix_previous[row] = current_row;
      009CE8 EE               [12] 1159 	mov	a,r6
      009CE9 12 9D 10         [24] 1160 	lcall	_ak820_outline_0072
      009CEC ED               [12] 1161 	mov	a,r5
      009CED F0               [24] 1162 	movx	@dptr,a
      009CEE                       1163 00116$:
                                   1164 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      009CEE 0E               [12] 1165 	inc	r6
      009CEF 81 3A            [24] 1166 	ajmp	00133$
      009CF1                       1167 00117$:
                                   1168 ;	quantum/keyboard.c:620: return matrix_changed;
      009CF1 75 82 01         [24] 1169 	mov	dpl, #0x01
                                   1170 ;	quantum/keyboard.c:621: }
      009CF4 22               [24] 1171 	ret
                                   1172 ;------------------------------------------------------------
                                   1173 ;Allocation info for local variables in function 'quantum_task'
                                   1174 ;------------------------------------------------------------
                                   1175 ;	quantum/keyboard.c:627: void quantum_task(void) {
                                   1176 ;	-----------------------------------------
                                   1177 ;	 function quantum_task
                                   1178 ;	-----------------------------------------
      009CF5                       1179 _quantum_task:
                                   1180 ;	quantum/keyboard.c:694: caps_word_task();
                                   1181 ;	quantum/keyboard.c:700: }
      009CF5 02 2E FF         [24] 1182 	ljmp	_caps_word_task
                                   1183 ;------------------------------------------------------------
                                   1184 ;Allocation info for local variables in function 'keyboard_task'
                                   1185 ;------------------------------------------------------------
                                   1186 ;activity_has_occurred Allocated with name '_keyboard_task_activity_has_occurred_10000_536'
                                   1187 ;------------------------------------------------------------
                                   1188 ;	quantum/keyboard.c:703: void keyboard_task(void) {
                                   1189 ;	-----------------------------------------
                                   1190 ;	 function keyboard_task
                                   1191 ;	-----------------------------------------
      009CF8                       1192 _keyboard_task:
                                   1193 ;	quantum/keyboard.c:705: if (matrix_task()) {
      009CF8 71 58            [12] 1194 	acall	_matrix_task
      009CFA E5 82            [12] 1195 	mov	a, dpl
      009CFC 60 02            [24] 1196 	jz	00102$
                                   1197 ;	quantum/keyboard.c:706: last_matrix_activity_trigger();
      009CFE 51 E1            [12] 1198 	acall	_last_matrix_activity_trigger
                                   1199 ;	quantum/keyboard.c:707: activity_has_occurred = true;
      009D00                       1200 00102$:
                                   1201 ;	quantum/keyboard.c:710: quantum_task();
      009D00 91 F5            [24] 1202 	acall	_quantum_task
                                   1203 ;	quantum/keyboard.c:724: rgb_matrix_task();
      009D02 12 58 98         [24] 1204 	lcall	_rgb_matrix_task
                                   1205 ;	quantum/keyboard.c:734: if (encoder_read()) {
      009D05 51 45            [12] 1206 	acall	_encoder_read
      009D07 E5 82            [12] 1207 	mov	a, dpl
      009D09 60 02            [24] 1208 	jz	00104$
                                   1209 ;	quantum/keyboard.c:735: last_encoder_activity_trigger();
      009D0B 51 F4            [12] 1210 	acall	_last_encoder_activity_trigger
                                   1211 ;	quantum/keyboard.c:736: activity_has_occurred = true;
      009D0D                       1212 00104$:
                                   1213 ;	quantum/keyboard.c:790: led_task();
                                   1214 ;	quantum/keyboard.c:791: }
      009D0D 02 9F F0         [24] 1215 	ljmp	_led_task
                                   1216 	.area CSEG    (CODE)
                                   1217 	.area CONST   (CODE)
                                   1218 	.area XINIT   (CODE)
      00CA76                       1219 __xinit__last_input_modification_time:
      00CA76 00 00 00 00           1220 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00CA7A                       1221 __xinit__last_matrix_modification_time:
      00CA7A 00 00 00 00           1222 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00CA7E                       1223 __xinit__last_encoder_modification_time:
      00CA7E 00 00 00 00           1224 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00CA82                       1225 __xinit__last_pointing_device_modification_time:
      00CA82 00 00 00 00           1226 	.byte #0x00, #0x00, #0x00, #0x00	; 0
                                   1227 	.area CABS    (ABS,CODE)
                                   1228 
                                   1229 ; Experimental exact instruction outlining.
                                   1230 	.globl _ak820_outline_0008
                                   1231 	.globl _ak820_outline_0062
                                   1232 	.globl _ak820_outline_0064
                                   1233 	.globl _ak820_outline_0065
                                   1234 	.globl _ak820_outline_0072
                                   1235 	.globl _ak820_outline_0079
                                   1236 	.globl _ak820_outline_0144
                                   1237 	.globl _ak820_outline_0160
                                   1238 	.globl _ak820_outline_0197
                                   1239 	.globl _ak820_outline_0199
                                   1240 
                                   1241 	.area CSEG (CODE)
                                   1242 ; function ak820_outline_0072
      009D10                       1243 _ak820_outline_0072:
      009D10 24 11            [12] 1244 	add	a,#_matrix_task_matrix_previous_10001_502
      009D12 F5 82            [12] 1245 	mov	dpl,a
      009D14 E4               [12] 1246 	clr	a
      009D15 34 0C            [12] 1247 	addc	a,#(_matrix_task_matrix_previous_10001_502>>8)
      009D17 F5 83            [12] 1248 	mov	dph,a
      009D19 22               [24] 1249 	ret
