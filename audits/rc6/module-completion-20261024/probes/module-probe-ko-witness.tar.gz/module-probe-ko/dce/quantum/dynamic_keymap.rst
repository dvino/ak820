                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_key_override_valid
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_write_block_xdata
                                     16 	.globl _ak820_eeprom_read_block_xdata
                                     17 	.globl _ak820_nvm_flush
                                     18 	.globl _ak820_nvm_ok
                                     19 	.globl _ak820_macro_reset
                                     20 	.globl _ak820_macro_write
                                     21 	.globl _ak820_macro_length
                                     22 	.globl _ak820_macro_ready
                                     23 	.globl _send_char
                                     24 	.globl _keycode_at_encodermap_location_raw
                                     25 	.globl _keycode_at_keymap_location_raw
                                     26 	.globl _vial_keycode_tap
                                     27 	.globl _vial_keycode_up
                                     28 	.globl _vial_keycode_down
                                     29 	.globl _clear_keyboard
                                     30 	.globl _tap_code
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _mDelaymS
                                     34 	.globl ___memcpy
                                     35 	.globl _memset
                                     36 	.globl _eeprom_update_byte
                                     37 	.globl _eeprom_read_byte
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    284 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    285 	.globl _keycode_at_encodermap_location_PARM_3
                                    286 	.globl _keycode_at_encodermap_location_PARM_2
                                    287 	.globl _keycode_at_keymap_location_PARM_3
                                    288 	.globl _keycode_at_keymap_location_PARM_2
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    292 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    293 	.globl _dynamic_keymap_set_key_override_PARM_2
                                    294 	.globl _dynamic_keymap_get_key_override_PARM_2
                                    295 	.globl _dynamic_keymap_set_combo_PARM_2
                                    296 	.globl _dynamic_keymap_get_combo_PARM_2
                                    297 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    298 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    299 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    300 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    301 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    302 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    303 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    304 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    305 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    306 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    307 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    309 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    310 	.globl _dynamic_keymap_get_layer_count
                                    311 	.globl _dynamic_keymap_key_to_eeprom_address
                                    312 	.globl _dynamic_keymap_get_keycode
                                    313 	.globl _dynamic_keymap_set_keycode
                                    314 	.globl _dynamic_keymap_get_encoder
                                    315 	.globl _dynamic_keymap_set_encoder
                                    316 	.globl _dynamic_keymap_get_combo
                                    317 	.globl _dynamic_keymap_set_combo
                                    318 	.globl _dynamic_keymap_get_key_override
                                    319 	.globl _dynamic_keymap_set_key_override
                                    320 	.globl _dynamic_keymap_reset
                                    321 	.globl _dynamic_keymap_get_buffer
                                    322 	.globl _dynamic_keymap_set_buffer
                                    323 	.globl _keycode_at_keymap_location
                                    324 	.globl _keycode_at_encodermap_location
                                    325 	.globl _dynamic_keymap_macro_get_count
                                    326 	.globl _dynamic_keymap_macro_get_buffer_size
                                    327 	.globl _dynamic_keymap_macro_get_buffer
                                    328 	.globl _dynamic_keymap_macro_set_buffer
                                    329 	.globl _dynamic_keymap_macro_reset
                                    330 	.globl _dynamic_keymap_macro_send
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      00003A                        593 _dynamic_keymap_set_encoder_sloc0_1_0:
      00003A                        594 	.ds 2
      00003C                        595 _dynamic_keymap_get_combo_sloc0_1_0:
      00003C                        596 	.ds 1
      00003D                        597 _ak820_dynamic_read_buffer_sloc0_1_0:
      00003D                        598 	.ds 1
      00003E                        599 _dynamic_keymap_set_buffer_sloc0_1_0:
      00003E                        600 	.ds 2
      000040                        601 _dynamic_keymap_set_buffer_sloc1_1_0:
      000040                        602 	.ds 2
      000042                        603 _dynamic_keymap_set_buffer_sloc2_1_0:
      000042                        604 	.ds 1
      000043                        605 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000043                        606 	.ds 2
                                    607 ;--------------------------------------------------------
                                    608 ; overlayable items in internal ram
                                    609 ;--------------------------------------------------------
                                    610 ;--------------------------------------------------------
                                    611 ; indirectly addressable internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area ISEG    (DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; absolute internal ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area IABS    (ABS,DATA)
                                    618 	.area IABS    (ABS,DATA)
                                    619 ;--------------------------------------------------------
                                    620 ; bit data
                                    621 ;--------------------------------------------------------
                                    622 	.area BSEG    (BIT)
      000027                        623 _dynamic_keymap_macro_send_sloc0_1_0:
      000027                        624 	.ds 1
                                    625 ;--------------------------------------------------------
                                    626 ; paged external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area PSEG    (PAG,XDATA)
                                    629 ;--------------------------------------------------------
                                    630 ; uninitialized external ram data
                                    631 ;--------------------------------------------------------
                                    632 	.area XSEG    (XDATA)
      000B67                        633 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B67                        634 	.ds 1
      000B68                        635 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B68                        636 	.ds 1
      000B69                        637 _dynamic_keymap_key_to_eeprom_address_layer_10000_374:
      000B69                        638 	.ds 1
      000B6A                        639 _dynamic_keymap_get_keycode_PARM_2:
      000B6A                        640 	.ds 1
      000B6B                        641 _dynamic_keymap_get_keycode_PARM_3:
      000B6B                        642 	.ds 1
      000B6C                        643 _dynamic_keymap_get_keycode_layer_10000_376:
      000B6C                        644 	.ds 1
      000B6D                        645 _dynamic_keymap_set_keycode_PARM_2:
      000B6D                        646 	.ds 1
      000B6E                        647 _dynamic_keymap_set_keycode_PARM_3:
      000B6E                        648 	.ds 1
      000B6F                        649 _dynamic_keymap_set_keycode_PARM_4:
      000B6F                        650 	.ds 2
      000B71                        651 _dynamic_keymap_set_keycode_layer_10000_380:
      000B71                        652 	.ds 1
      000B72                        653 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B72                        654 	.ds 1
      000B73                        655 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_384:
      000B73                        656 	.ds 1
      000B74                        657 _dynamic_keymap_get_encoder_PARM_2:
      000B74                        658 	.ds 1
      000B75                        659 _dynamic_keymap_get_encoder_PARM_3:
      000B75                        660 	.ds 1
      000B76                        661 _dynamic_keymap_get_encoder_layer_10000_386:
      000B76                        662 	.ds 1
      000B77                        663 _dynamic_keymap_set_encoder_PARM_2:
      000B77                        664 	.ds 1
      000B78                        665 _dynamic_keymap_set_encoder_PARM_3:
      000B78                        666 	.ds 1
      000B79                        667 _dynamic_keymap_set_encoder_PARM_4:
      000B79                        668 	.ds 2
      000B7B                        669 _dynamic_keymap_set_encoder_layer_10000_390:
      000B7B                        670 	.ds 1
      000B7C                        671 _dynamic_keymap_get_combo_PARM_2:
      000B7C                        672 	.ds 3
      000B7F                        673 _dynamic_keymap_get_combo_index_10000_394:
      000B7F                        674 	.ds 1
      000B80                        675 _dynamic_keymap_set_combo_PARM_2:
      000B80                        676 	.ds 3
      000B83                        677 _dynamic_keymap_set_combo_index_10000_400:
      000B83                        678 	.ds 1
      000B84                        679 _dynamic_keymap_set_combo_stored_10002_405:
      000B84                        680 	.ds 10
      000B8E                        681 _dynamic_keymap_get_key_override_PARM_2:
      000B8E                        682 	.ds 3
      000B91                        683 _dynamic_keymap_get_key_override_index_10000_407:
      000B91                        684 	.ds 1
      000B92                        685 _dynamic_keymap_set_key_override_PARM_2:
      000B92                        686 	.ds 3
      000B95                        687 _dynamic_keymap_set_key_override_index_10000_411:
      000B95                        688 	.ds 1
      000B96                        689 _dynamic_keymap_reset_vial_unlocked_prev_10000_415:
      000B96                        690 	.ds 1
      000B97                        691 _dynamic_keymap_reset_combo_10001_424:
      000B97                        692 	.ds 10
      000BA1                        693 _dynamic_keymap_reset_ko_10002_426:
      000BA1                        694 	.ds 10
      000BAB                        695 _ak820_dynamic_read_buffer_PARM_2:
      000BAB                        696 	.ds 2
      000BAD                        697 _ak820_dynamic_read_buffer_PARM_3:
      000BAD                        698 	.ds 2
      000BAF                        699 _ak820_dynamic_read_buffer_PARM_4:
      000BAF                        700 	.ds 2
      000BB1                        701 _ak820_dynamic_read_buffer_PARM_5:
      000BB1                        702 	.ds 3
      000BB4                        703 _ak820_dynamic_read_buffer_base_10000_428:
      000BB4                        704 	.ds 2
      000BB6                        705 _ak820_dynamic_read_buffer_available_10000_429:
      000BB6                        706 	.ds 1
      000BB7                        707 _dynamic_keymap_get_buffer_PARM_2:
      000BB7                        708 	.ds 2
      000BB9                        709 _dynamic_keymap_get_buffer_PARM_3:
      000BB9                        710 	.ds 3
      000BBC                        711 _dynamic_keymap_get_buffer_offset_10000_435:
      000BBC                        712 	.ds 2
      000BBE                        713 _dynamic_keymap_set_buffer_PARM_2:
      000BBE                        714 	.ds 2
      000BC0                        715 _dynamic_keymap_set_buffer_PARM_3:
      000BC0                        716 	.ds 3
      000BC3                        717 _dynamic_keymap_set_buffer_offset_10000_437:
      000BC3                        718 	.ds 2
      000BC5                        719 _dynamic_keymap_set_buffer_chk_offset_30001_444:
      000BC5                        720 	.ds 1
      000BC6                        721 _dynamic_keymap_set_buffer_chk_sz_30001_444:
      000BC6                        722 	.ds 1
      000BC7                        723 _dynamic_keymap_set_buffer_i_40001_451:
      000BC7                        724 	.ds 1
      000BC8                        725 _keycode_at_keymap_location_PARM_2:
      000BC8                        726 	.ds 1
      000BC9                        727 _keycode_at_keymap_location_PARM_3:
      000BC9                        728 	.ds 1
      000BCA                        729 _keycode_at_keymap_location_layer_num_10000_455:
      000BCA                        730 	.ds 1
      000BCB                        731 _keycode_at_encodermap_location_PARM_2:
      000BCB                        732 	.ds 1
      000BCC                        733 _keycode_at_encodermap_location_PARM_3:
      000BCC                        734 	.ds 1
      000BCD                        735 _keycode_at_encodermap_location_layer_num_10000_459:
      000BCD                        736 	.ds 1
      000BCE                        737 _dynamic_keymap_macro_get_buffer_PARM_2:
      000BCE                        738 	.ds 2
      000BD0                        739 _dynamic_keymap_macro_get_buffer_PARM_3:
      000BD0                        740 	.ds 3
      000BD3                        741 _dynamic_keymap_macro_get_buffer_offset_10000_467:
      000BD3                        742 	.ds 2
      000BD5                        743 _dynamic_keymap_macro_set_buffer_PARM_2:
      000BD5                        744 	.ds 2
      000BD7                        745 _dynamic_keymap_macro_set_buffer_PARM_3:
      000BD7                        746 	.ds 3
      000BDA                        747 _dynamic_keymap_macro_set_buffer_offset_10000_469:
      000BDA                        748 	.ds 2
      000BDC                        749 _decode_keycode_kc_10000_473:
      000BDC                        750 	.ds 2
      000BDE                        751 _dynamic_keymap_macro_send_id_10000_476:
      000BDE                        752 	.ds 1
      000BDF                        753 _dynamic_keymap_macro_send_sending_10000_477:
      000BDF                        754 	.ds 1
      000BE0                        755 _dynamic_keymap_macro_send_p_10001_482:
      000BE0                        756 	.ds 2
      000BE2                        757 _dynamic_keymap_macro_send_data_10003_489:
      000BE2                        758 	.ds 4
                                    759 ;--------------------------------------------------------
                                    760 ; absolute external ram data
                                    761 ;--------------------------------------------------------
                                    762 	.area XABS    (ABS,XDATA)
                                    763 ;--------------------------------------------------------
                                    764 ; initialized external ram data
                                    765 ;--------------------------------------------------------
                                    766 	.area XISEG   (XDATA)
                                    767 	.area HOME    (CODE)
                                    768 	.area GSINIT0 (CODE)
                                    769 	.area GSINIT1 (CODE)
                                    770 	.area GSINIT2 (CODE)
                                    771 	.area GSINIT3 (CODE)
                                    772 	.area GSINIT4 (CODE)
                                    773 	.area GSINIT5 (CODE)
                                    774 	.area GSINIT  (CODE)
                                    775 	.area GSFINAL (CODE)
                                    776 	.area CSEG    (CODE)
                                    777 ;--------------------------------------------------------
                                    778 ; global & static initialisations
                                    779 ;--------------------------------------------------------
                                    780 	.area HOME    (CODE)
                                    781 	.area GSINIT  (CODE)
                                    782 	.area GSFINAL (CODE)
                                    783 	.area GSINIT  (CODE)
                                    784 ;--------------------------------------------------------
                                    785 ; Home
                                    786 ;--------------------------------------------------------
                                    787 	.area HOME    (CODE)
                                    788 	.area HOME    (CODE)
                                    789 ;--------------------------------------------------------
                                    790 ; code
                                    791 ;--------------------------------------------------------
                                    792 	.area CSEG    (CODE)
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    795 ;------------------------------------------------------------
                                    796 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_232'
                                    797 ;------------------------------------------------------------
                                    798 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    799 ;	-----------------------------------------
                           000007   800 	ar7 = 0x07
                           000006   801 	ar6 = 0x06
                           000005   802 	ar5 = 0x05
                           000004   803 	ar4 = 0x04
                           000003   804 	ar3 = 0x03
                           000002   805 	ar2 = 0x02
                           000001   806 	ar1 = 0x01
                           000000   807 	ar0 = 0x00
                                    808 ;	 function dynamic_keymap_get_layer_count
                                    809 ;	-----------------------------------------
      008AF4                        810 _dynamic_keymap_get_layer_count:
                                    811 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008AF4 75 82 06         [24]  812 	mov	dpl, #0x06
                                    813 ;	quantum/dynamic_keymap.c:201: }
      008AF7 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    817 ;------------------------------------------------------------
                                    818 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    819 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    820 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_374'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function dynamic_keymap_key_to_eeprom_address
                                    825 ;	-----------------------------------------
      008AF8                        826 _dynamic_keymap_key_to_eeprom_address:
      008AF8 E5 82            [12]  827 	mov	a,dpl
      008AFA 90 0B 69         [24]  828 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_374
      008AFD F0               [24]  829 	movx	@dptr,a
                                    830 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008AFE E0               [24]  831 	movx	a,@dptr
      008AFF FF               [12]  832 	mov	r7,a
      008B00 7E 00            [12]  833 	mov	r6,#0x00
      008B02 74 40            [12]  834 	mov	a,#0x40
      008B04 12 4A 23         [24]  835 	lcall	_ak820_outline_0148
      008B07 7D 00            [12]  836 	mov	r5,#0x00
      008B09 90 0B 67         [24]  837 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008B0C E0               [24]  838 	movx	a,@dptr
      008B0D 75 F0 10         [24]  839 	mov	b,#0x10
      008B10 A4               [48]  840 	mul	ab
      008B11 2E               [12]  841 	add	a, r6
      008B12 FE               [12]  842 	mov	r6,a
      008B13 EF               [12]  843 	mov	a,r7
      008B14 35 F0            [12]  844 	addc	a, b
      008B16 FF               [12]  845 	mov	r7,a
      008B17 90 0B 68         [24]  846 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008B1A E0               [24]  847 	movx	a,@dptr
      008B1B 7C 00            [12]  848 	mov	r4,#0x00
      008B1D 25 E0            [12]  849 	add	a,acc
      008B1F FB               [12]  850 	mov	r3,a
      008B20 EC               [12]  851 	mov	a,r4
      008B21 33               [12]  852 	rlc	a
      008B22 FC               [12]  853 	mov	r4,a
      008B23 EB               [12]  854 	mov	a,r3
      008B24 2E               [12]  855 	add	a, r6
      008B25 FE               [12]  856 	mov	r6,a
      008B26 EC               [12]  857 	mov	a,r4
      008B27 3F               [12]  858 	addc	a, r7
      008B28 FF               [12]  859 	mov	r7,a
      008B29 12 7D 6C         [24]  860 	lcall	_ak820_outline_0120
                                    861 ;	quantum/dynamic_keymap.c:206: }
      008B2C 22               [24]  862 	ret
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    865 ;------------------------------------------------------------
                                    866 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    867 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    868 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_376'
                                    869 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_379'
                                    870 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_379'
                                    871 ;------------------------------------------------------------
                                    872 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    873 ;	-----------------------------------------
                                    874 ;	 function dynamic_keymap_get_keycode
                                    875 ;	-----------------------------------------
      008B2D                        876 _dynamic_keymap_get_keycode:
      008B2D E5 82            [12]  877 	mov	a,dpl
      008B2F 90 0B 6C         [24]  878 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_376
      008B32 F0               [24]  879 	movx	@dptr,a
                                    880 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008B33 E0               [24]  881 	movx	a,@dptr
      008B34 FF               [12]  882 	mov	r7,a
      008B35 BF 06 00         [24]  883 	cjne	r7,#0x06,00121$
      008B38                        884 00121$:
      008B38 50 14            [24]  885 	jnc	00101$
      008B3A 90 0B 6A         [24]  886 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008B3D E0               [24]  887 	movx	a,@dptr
      008B3E FE               [12]  888 	mov	r6,a
      008B3F BE 10 00         [24]  889 	cjne	r6,#0x10,00123$
      008B42                        890 00123$:
      008B42 50 0A            [24]  891 	jnc	00101$
      008B44 90 0B 6B         [24]  892 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008B47 E0               [24]  893 	movx	a,@dptr
      008B48 FD               [12]  894 	mov	r5,a
      008B49 BD 08 00         [24]  895 	cjne	r5,#0x08,00125$
      008B4C                        896 00125$:
      008B4C 40 04            [24]  897 	jc	00102$
      008B4E                        898 00101$:
      008B4E 90 00 00         [24]  899 	mov	dptr,#0x0000
      008B51 22               [24]  900 	ret
      008B52                        901 00102$:
                                    902 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008B52 12 96 DD         [24]  903 	lcall	_ak820_outline_0104
      008B55 51 F8            [12]  904 	acall	_dynamic_keymap_key_to_eeprom_address
                                    905 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008B57 12 96 F1         [24]  906 	lcall	_ak820_outline_0124
      008B5A 12 47 36         [24]  907 	lcall	_eeprom_read_byte
      008B5D AB 82            [24]  908 	mov	r3,dpl
      008B5F 7C 00            [12]  909 	mov	r4,#0x00
                                    910 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008B61 0D               [12]  911 	inc	r5
      008B62 BD 00 01         [24]  912 	cjne	r5,#0x00,00127$
      008B65 0E               [12]  913 	inc	r6
      008B66                        914 00127$:
      008B66 12 73 F6         [24]  915 	lcall	_ak820_outline_0063
      008B69 12 47 36         [24]  916 	lcall	_eeprom_read_byte
      008B6C AF 82            [24]  917 	mov	r7, dpl
      008B6E 7E 00            [12]  918 	mov	r6,#0x00
      008B70 EF               [12]  919 	mov	a,r7
      008B71 42 04            [12]  920 	orl	ar4,a
      008B73 EE               [12]  921 	mov	a,r6
      008B74 42 03            [12]  922 	orl	ar3,a
                                    923 ;	quantum/dynamic_keymap.c:214: return keycode;
      008B76 12 4A 4A         [24]  924 	lcall	_ak820_outline_0193
                                    925 ;	quantum/dynamic_keymap.c:215: }
      008B79 22               [24]  926 	ret
                                    927 ;------------------------------------------------------------
                                    928 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    929 ;------------------------------------------------------------
                                    930 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    931 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    932 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    933 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_380'
                                    934 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_383'
                                    935 ;------------------------------------------------------------
                                    936 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    937 ;	-----------------------------------------
                                    938 ;	 function dynamic_keymap_set_keycode
                                    939 ;	-----------------------------------------
      008B7A                        940 _dynamic_keymap_set_keycode:
      008B7A E5 82            [12]  941 	mov	a,dpl
      008B7C 90 0B 71         [24]  942 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_380
      008B7F F0               [24]  943 	movx	@dptr,a
                                    944 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008B80 E0               [24]  945 	movx	a,@dptr
      008B81 FF               [12]  946 	mov	r7,a
      008B82 BF 06 00         [24]  947 	cjne	r7,#0x06,00121$
      008B85                        948 00121$:
      008B85 50 14            [24]  949 	jnc	00101$
      008B87 90 0B 6D         [24]  950 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008B8A E0               [24]  951 	movx	a,@dptr
      008B8B FE               [12]  952 	mov	r6,a
      008B8C BE 10 00         [24]  953 	cjne	r6,#0x10,00123$
      008B8F                        954 00123$:
      008B8F 50 0A            [24]  955 	jnc	00101$
      008B91 90 0B 6E         [24]  956 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008B94 E0               [24]  957 	movx	a,@dptr
      008B95 FD               [12]  958 	mov	r5,a
      008B96 BD 08 00         [24]  959 	cjne	r5,#0x08,00125$
      008B99                        960 00125$:
      008B99 40 01            [24]  961 	jc	00102$
      008B9B                        962 00101$:
      008B9B 22               [24]  963 	ret
      008B9C                        964 00102$:
                                    965 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008B9C 12 96 DD         [24]  966 	lcall	_ak820_outline_0104
      008B9F 51 F8            [12]  967 	acall	_dynamic_keymap_key_to_eeprom_address
      008BA1 12 96 F1         [24]  968 	lcall	_ak820_outline_0124
                                    969 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008BA4 90 0B 6F         [24]  970 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008BA7 E0               [24]  971 	movx	a,@dptr
      008BA8 FB               [12]  972 	mov	r3,a
      008BA9 A3               [24]  973 	inc	dptr
      008BAA E0               [24]  974 	movx	a,@dptr
      008BAB 90 07 09         [24]  975 	mov	dptr,#_eeprom_update_byte_PARM_2
      008BAE 12 55 B3         [24]  976 	lcall	_ak820_outline_0038
      008BB1 12 54 9B         [24]  977 	lcall	_eeprom_update_byte
                                    978 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008BB4 0D               [12]  979 	inc	r5
      008BB5 BD 00 01         [24]  980 	cjne	r5,#0x00,00127$
      008BB8 0E               [12]  981 	inc	r6
      008BB9                        982 00127$:
      008BB9 90 07 09         [24]  983 	mov	dptr,#_eeprom_update_byte_PARM_2
      008BBC EB               [12]  984 	mov	a,r3
      008BBD 12 55 B3         [24]  985 	lcall	_ak820_outline_0038
                                    986 ;	quantum/dynamic_keymap.c:223: }
      008BC0 02 54 9B         [24]  987 	ljmp	_eeprom_update_byte
                                    988 ;------------------------------------------------------------
                                    989 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    990 ;------------------------------------------------------------
                                    991 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    992 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_384'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    997 ;	-----------------------------------------
      008BC3                        998 _dynamic_keymap_encoder_to_eeprom_address:
      008BC3 E5 82            [12]  999 	mov	a,dpl
      008BC5 90 0B 73         [24] 1000 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_384
      008BC8 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008BC9 E0               [24] 1003 	movx	a,@dptr
      008BCA 75 F0 04         [24] 1004 	mov	b,#0x04
      008BCD A4               [48] 1005 	mul	ab
      008BCE 24 40            [12] 1006 	add	a, #0x40
      008BD0 FD               [12] 1007 	mov	r5,a
      008BD1 74 06            [12] 1008 	mov	a,#0x06
      008BD3 35 F0            [12] 1009 	addc	a, b
      008BD5 FE               [12] 1010 	mov	r6,a
      008BD6 7F 00            [12] 1011 	mov	r7,#0x00
      008BD8 90 0B 72         [24] 1012 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008BDB E0               [24] 1013 	movx	a,@dptr
      008BDC 75 F0 04         [24] 1014 	mov	b,#0x04
      008BDF A4               [48] 1015 	mul	ab
      008BE0 2D               [12] 1016 	add	a, r5
      008BE1 FD               [12] 1017 	mov	r5,a
      008BE2 EE               [12] 1018 	mov	a,r6
      008BE3 35 F0            [12] 1019 	addc	a, b
      008BE5 FE               [12] 1020 	mov	r6,a
      008BE6 12 73 F6         [24] 1021 	lcall	_ak820_outline_0063
                                   1022 ;	quantum/dynamic_keymap.c:228: }
      008BE9 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1026 ;------------------------------------------------------------
                                   1027 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1028 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1029 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_386'
                                   1030 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_389'
                                   1031 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_389'
                                   1032 ;------------------------------------------------------------
                                   1033 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1034 ;	-----------------------------------------
                                   1035 ;	 function dynamic_keymap_get_encoder
                                   1036 ;	-----------------------------------------
      008BEA                       1037 _dynamic_keymap_get_encoder:
      008BEA E5 82            [12] 1038 	mov	a,dpl
      008BEC 90 0B 76         [24] 1039 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_386
      008BEF F0               [24] 1040 	movx	@dptr,a
                                   1041 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008BF0 E0               [24] 1042 	movx	a,@dptr
      008BF1 FF               [12] 1043 	mov	r7,a
      008BF2 BF 06 00         [24] 1044 	cjne	r7,#0x06,00131$
      008BF5                       1045 00131$:
      008BF5 50 0A            [24] 1046 	jnc	00101$
      008BF7 90 0B 74         [24] 1047 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008BFA E0               [24] 1048 	movx	a,@dptr
      008BFB FE               [12] 1049 	mov	r6,a
      008BFC BE 01 00         [24] 1050 	cjne	r6,#0x01,00133$
      008BFF                       1051 00133$:
      008BFF 40 04            [24] 1052 	jc	00102$
      008C01                       1053 00101$:
      008C01 90 00 00         [24] 1054 	mov	dptr,#0x0000
      008C04 22               [24] 1055 	ret
      008C05                       1056 00102$:
                                   1057 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008C05 90 0B 72         [24] 1058 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008C08 E4               [12] 1059 	clr	a
      008C09 F0               [24] 1060 	movx	@dptr,a
      008C0A 8F 82            [24] 1061 	mov	dpl, r7
      008C0C 71 C3            [12] 1062 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008C0E 12 96 F1         [24] 1063 	lcall	_ak820_outline_0124
                                   1064 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008C11 90 0B 75         [24] 1065 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008C14 E0               [24] 1066 	movx	a,@dptr
      008C15 FC               [12] 1067 	mov	r4,a
      008C16 E0               [24] 1068 	movx	a,@dptr
      008C17 60 04            [24] 1069 	jz	00106$
      008C19 7B 00            [12] 1070 	mov	r3,#0x00
      008C1B 80 02            [24] 1071 	sjmp	00107$
      008C1D                       1072 00106$:
      008C1D 7B 02            [12] 1073 	mov	r3,#0x02
      008C1F                       1074 00107$:
      008C1F EB               [12] 1075 	mov	a,r3
      008C20 12 7D 14         [24] 1076 	lcall	_ak820_outline_0014
      008C23 12 47 36         [24] 1077 	lcall	_eeprom_read_byte
      008C26 AA 82            [24] 1078 	mov	r2,dpl
      008C28 7B 00            [12] 1079 	mov	r3,#0x00
                                   1080 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008C2A EC               [12] 1081 	mov	a,r4
      008C2B 60 04            [24] 1082 	jz	00108$
      008C2D 7C 00            [12] 1083 	mov	r4,#0x00
      008C2F 80 02            [24] 1084 	sjmp	00109$
      008C31                       1085 00108$:
      008C31 7C 02            [12] 1086 	mov	r4,#0x02
      008C33                       1087 00109$:
      008C33 EC               [12] 1088 	mov	a,r4
      008C34 12 38 BF         [24] 1089 	lcall	_ak820_outline_0171
      008C37 0D               [12] 1090 	inc	r5
      008C38 BD 00 01         [24] 1091 	cjne	r5,#0x00,00137$
      008C3B 0E               [12] 1092 	inc	r6
      008C3C                       1093 00137$:
      008C3C 12 73 F6         [24] 1094 	lcall	_ak820_outline_0063
      008C3F 12 47 36         [24] 1095 	lcall	_eeprom_read_byte
      008C42 AF 82            [24] 1096 	mov	r7, dpl
      008C44 7E 00            [12] 1097 	mov	r6,#0x00
      008C46 EF               [12] 1098 	mov	a,r7
      008C47 42 03            [12] 1099 	orl	ar3,a
      008C49 EE               [12] 1100 	mov	a,r6
      008C4A 42 02            [12] 1101 	orl	ar2,a
                                   1102 ;	quantum/dynamic_keymap.c:236: return keycode;
      008C4C 8B 82            [24] 1103 	mov	dpl, r3
      008C4E 8A 83            [24] 1104 	mov	dph, r2
                                   1105 ;	quantum/dynamic_keymap.c:237: }
      008C50 22               [24] 1106 	ret
                                   1107 ;------------------------------------------------------------
                                   1108 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1109 ;------------------------------------------------------------
                                   1110 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1111 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1112 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1113 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1114 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_390'
                                   1115 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_393'
                                   1116 ;------------------------------------------------------------
                                   1117 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1118 ;	-----------------------------------------
                                   1119 ;	 function dynamic_keymap_set_encoder
                                   1120 ;	-----------------------------------------
      008C51                       1121 _dynamic_keymap_set_encoder:
      008C51 E5 82            [12] 1122 	mov	a,dpl
      008C53 90 0B 7B         [24] 1123 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_390
      008C56 F0               [24] 1124 	movx	@dptr,a
                                   1125 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008C57 E0               [24] 1126 	movx	a,@dptr
      008C58 FF               [12] 1127 	mov	r7,a
      008C59 BF 06 00         [24] 1128 	cjne	r7,#0x06,00131$
      008C5C                       1129 00131$:
      008C5C 50 0A            [24] 1130 	jnc	00101$
      008C5E 90 0B 77         [24] 1131 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008C61 E0               [24] 1132 	movx	a,@dptr
      008C62 FE               [12] 1133 	mov	r6,a
      008C63 BE 01 00         [24] 1134 	cjne	r6,#0x01,00133$
      008C66                       1135 00133$:
      008C66 40 01            [24] 1136 	jc	00102$
      008C68                       1137 00101$:
      008C68 22               [24] 1138 	ret
      008C69                       1139 00102$:
                                   1140 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008C69 90 0B 72         [24] 1141 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008C6C E4               [12] 1142 	clr	a
      008C6D F0               [24] 1143 	movx	@dptr,a
      008C6E 8F 82            [24] 1144 	mov	dpl, r7
      008C70 71 C3            [12] 1145 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008C72 12 96 F1         [24] 1146 	lcall	_ak820_outline_0124
                                   1147 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008C75 90 0B 78         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008C78 E0               [24] 1149 	movx	a,@dptr
      008C79 FC               [12] 1150 	mov	r4,a
      008C7A E0               [24] 1151 	movx	a,@dptr
      008C7B 60 04            [24] 1152 	jz	00106$
      008C7D 7B 00            [12] 1153 	mov	r3,#0x00
      008C7F 80 02            [24] 1154 	sjmp	00107$
      008C81                       1155 00106$:
      008C81 7B 02            [12] 1156 	mov	r3,#0x02
      008C83                       1157 00107$:
      008C83 EB               [12] 1158 	mov	a,r3
      008C84 12 97 03         [24] 1159 	lcall	_ak820_outline_0147
      008C87 8F 03            [24] 1160 	mov	ar3,r7
      008C89 90 0B 79         [24] 1161 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C8C E0               [24] 1162 	movx	a,@dptr
      008C8D F5 3A            [12] 1163 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008C8F A3               [24] 1164 	inc	dptr
      008C90 E0               [24] 1165 	movx	a,@dptr
      008C91 F5 3B            [12] 1166 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008C93 90 07 09         [24] 1167 	mov	dptr,#_eeprom_update_byte_PARM_2
      008C96 F0               [24] 1168 	movx	@dptr,a
      008C97 12 4A 34         [24] 1169 	lcall	_ak820_outline_0168
      008C9A 8B F0            [24] 1170 	mov	b, r3
      008C9C 12 54 9B         [24] 1171 	lcall	_eeprom_update_byte
                                   1172 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008C9F EC               [12] 1173 	mov	a,r4
      008CA0 60 04            [24] 1174 	jz	00108$
      008CA2 7C 00            [12] 1175 	mov	r4,#0x00
      008CA4 80 02            [24] 1176 	sjmp	00109$
      008CA6                       1177 00108$:
      008CA6 7C 02            [12] 1178 	mov	r4,#0x02
      008CA8                       1179 00109$:
      008CA8 EC               [12] 1180 	mov	a,r4
      008CA9 12 38 BF         [24] 1181 	lcall	_ak820_outline_0171
      008CAC 0D               [12] 1182 	inc	r5
      008CAD BD 00 01         [24] 1183 	cjne	r5,#0x00,00137$
      008CB0 0E               [12] 1184 	inc	r6
      008CB1                       1185 00137$:
      008CB1 90 07 09         [24] 1186 	mov	dptr,#_eeprom_update_byte_PARM_2
      008CB4 E5 3A            [12] 1187 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008CB6 12 55 B3         [24] 1188 	lcall	_ak820_outline_0038
                                   1189 ;	quantum/dynamic_keymap.c:245: }
      008CB9 02 54 9B         [24] 1190 	ljmp	_eeprom_update_byte
                                   1191 ;------------------------------------------------------------
                                   1192 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1193 ;------------------------------------------------------------
                                   1194 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1195 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1196 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_394'
                                   1197 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_395'
                                   1198 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_397'
                                   1199 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_398'
                                   1200 ;------------------------------------------------------------
                                   1201 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1202 ;	-----------------------------------------
                                   1203 ;	 function dynamic_keymap_get_combo
                                   1204 ;	-----------------------------------------
      008CBC                       1205 _dynamic_keymap_get_combo:
      008CBC E5 82            [12] 1206 	mov	a,dpl
      008CBE 90 0B 7F         [24] 1207 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_394
      008CC1 F0               [24] 1208 	movx	@dptr,a
                                   1209 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008CC2 90 0B 7C         [24] 1210 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008CC5 12 38 39         [24] 1211 	lcall	_ak820_outline_0057
                                   1212 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008CC8 90 0B 7F         [24] 1213 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_394
      008CCB E0               [24] 1214 	movx	a,@dptr
      008CCC FD               [12] 1215 	mov	r5,a
      008CCD BD 08 00         [24] 1216 	cjne	r5,#0x08,00132$
      008CD0                       1217 00132$:
      008CD0 40 04            [24] 1218 	jc	00102$
                                   1219 ;	quantum/dynamic_keymap.c:315: return -1;
      008CD2 90 FF FF         [24] 1220 	mov	dptr,#0xffff
      008CD5 22               [24] 1221 	ret
      008CD6                       1222 00102$:
                                   1223 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008CD6 12 96 C9         [24] 1224 	lcall	_ak820_outline_0086
                                   1225 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008CD9 8E 02            [24] 1226 	mov	ar2,r6
      008CDB 8F 03            [24] 1227 	mov	ar3,r7
      008CDD 90 05 F3         [24] 1228 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008CE0 EC               [12] 1229 	mov	a,r4
      008CE1 F0               [24] 1230 	movx	@dptr,a
      008CE2 ED               [12] 1231 	mov	a,r5
      008CE3 12 38 56         [24] 1232 	lcall	_ak820_outline_0077
      008CE6 90 05 F6         [24] 1233 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008CE9 12 96 EA         [24] 1234 	lcall	_ak820_outline_0118
      008CEC 12 38 B0         [24] 1235 	lcall	_ak820_outline_0146
      008CEF C0 07            [24] 1236 	push	ar7
      008CF1 C0 06            [24] 1237 	push	ar6
      008CF3 12 47 71         [24] 1238 	lcall	_ak820_eeprom_read_block_xdata
      008CF6 D0 06            [24] 1239 	pop	ar6
      008CF8 D0 07            [24] 1240 	pop	ar7
                                   1241 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008CFA 74 04            [12] 1242 	mov	a,#0x04
      008CFC 12 4F 36         [24] 1243 	lcall	_ak820_outline_0035
      008CFF FA               [12] 1244 	mov	r2,a
      008D00 A3               [24] 1245 	inc	dptr
      008D01 E0               [24] 1246 	movx	a,@dptr
      008D02 FB               [12] 1247 	mov	r3,a
      008D03 BA 20 14         [24] 1248 	cjne	r2,#0x20,00108$
      008D06 BB 08 11         [24] 1249 	cjne	r3,#0x08,00108$
      008D09 74 06            [12] 1250 	mov	a,#0x06
      008D0B 12 38 0E         [24] 1251 	lcall	_ak820_outline_0016
      008D0E FA               [12] 1252 	mov	r2,a
      008D0F A3               [24] 1253 	inc	dptr
      008D10 E0               [24] 1254 	movx	a,@dptr
      008D11 FB               [12] 1255 	mov	r3,a
      008D12 BA 01 05         [24] 1256 	cjne	r2,#0x01,00136$
      008D15 BB 00 02         [24] 1257 	cjne	r3,#0x00,00136$
      008D18 80 05            [24] 1258 	sjmp	00109$
      008D1A                       1259 00136$:
      008D1A                       1260 00108$:
      008D1A 75 3C 00         [24] 1261 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008D1D 80 03            [24] 1262 	sjmp	00110$
      008D1F                       1263 00109$:
      008D1F 75 3C 01         [24] 1264 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008D22                       1265 00110$:
                                   1266 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008D22 74 06            [12] 1267 	mov	a,#0x06
      008D24 12 38 29         [24] 1268 	lcall	_ak820_outline_0036
      008D27 E4               [12] 1269 	clr	a
      008D28 F0               [24] 1270 	movx	@dptr,a
      008D29 A3               [24] 1271 	inc	dptr
      008D2A 12 38 7A         [24] 1272 	lcall	_ak820_outline_0109
      008D2D F0               [24] 1273 	movx	@dptr,a
      008D2E A3               [24] 1274 	inc	dptr
      008D2F F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008D30 E5 3C            [12] 1277 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008D32 60 12            [24] 1278 	jz	00103$
      008D34 12 38 90         [24] 1279 	lcall	_ak820_outline_0126
      008D37 C0 07            [24] 1280 	push	ar7
      008D39 C0 06            [24] 1281 	push	ar6
      008D3B 12 34 D0         [24] 1282 	lcall	_ak820_combo_valid
      008D3E E5 82            [12] 1283 	mov	a, dpl
      008D40 D0 06            [24] 1284 	pop	ar6
      008D42 D0 07            [24] 1285 	pop	ar7
      008D44 70 08            [24] 1286 	jnz	00104$
      008D46                       1287 00103$:
      008D46 7D 00            [12] 1288 	mov	r5,#0x00
      008D48 12 96 B4         [24] 1289 	lcall	_ak820_outline_0045
      008D4B 12 C1 DB         [24] 1290 	lcall	_memset
      008D4E                       1291 00104$:
                                   1292 ;	quantum/dynamic_keymap.c:329: return 0;
      008D4E 90 00 00         [24] 1293 	mov	dptr,#0x0000
                                   1294 ;	quantum/dynamic_keymap.c:330: }
      008D51 22               [24] 1295 	ret
                                   1296 ;------------------------------------------------------------
                                   1297 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1298 ;------------------------------------------------------------
                                   1299 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1300 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_400'
                                   1301 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_401'
                                   1302 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_404'
                                   1303 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_405'
                                   1304 ;------------------------------------------------------------
                                   1305 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1306 ;	-----------------------------------------
                                   1307 ;	 function dynamic_keymap_set_combo
                                   1308 ;	-----------------------------------------
      008D52                       1309 _dynamic_keymap_set_combo:
      008D52 E5 82            [12] 1310 	mov	a,dpl
      008D54 90 0B 83         [24] 1311 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_400
      008D57 F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008D58 90 0B 80         [24] 1314 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008D5B 12 37 F7         [24] 1315 	lcall	_ak820_outline_0006
                                   1316 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008D5E C0 07            [24] 1317 	push	ar7
      008D60 C0 06            [24] 1318 	push	ar6
      008D62 12 34 D0         [24] 1319 	lcall	_ak820_combo_valid
      008D65 E5 82            [12] 1320 	mov	a, dpl
      008D67 D0 06            [24] 1321 	pop	ar6
      008D69 D0 07            [24] 1322 	pop	ar7
      008D6B 60 07            [24] 1323 	jz	00101$
      008D6D 12 44 DC         [24] 1324 	lcall	_ak820_nvm_ok
      008D70 E5 82            [12] 1325 	mov	a, dpl
      008D72 70 04            [24] 1326 	jnz	00102$
      008D74                       1327 00101$:
      008D74 90 FF FF         [24] 1328 	mov	dptr,#0xffff
      008D77 22               [24] 1329 	ret
      008D78                       1330 00102$:
                                   1331 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008D78 90 0B 83         [24] 1332 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_400
      008D7B E0               [24] 1333 	movx	a,@dptr
      008D7C FD               [12] 1334 	mov	r5,a
      008D7D BD 08 00         [24] 1335 	cjne	r5,#0x08,00133$
      008D80                       1336 00133$:
      008D80 40 04            [24] 1337 	jc	00105$
                                   1338 ;	quantum/dynamic_keymap.c:342: return -1;
      008D82 90 FF FF         [24] 1339 	mov	dptr,#0xffff
      008D85 22               [24] 1340 	ret
      008D86                       1341 00105$:
                                   1342 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008D86 12 96 C9         [24] 1343 	lcall	_ak820_outline_0086
                                   1344 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008D89 C0 07            [24] 1345 	push	ar7
      008D8B C0 06            [24] 1346 	push	ar6
      008D8D C0 05            [24] 1347 	push	ar5
      008D8F C0 04            [24] 1348 	push	ar4
      008D91 12 7C D2         [24] 1349 	lcall	_clear_keyboard
      008D94 D0 04            [24] 1350 	pop	ar4
      008D96 D0 05            [24] 1351 	pop	ar5
      008D98 D0 06            [24] 1352 	pop	ar6
      008D9A D0 07            [24] 1353 	pop	ar7
                                   1354 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008D9C 90 0E 57         [24] 1355 	mov	dptr,#___memcpy_PARM_2
      008D9F 12 4F 49         [24] 1356 	lcall	_ak820_outline_0064
      008DA2 E4               [12] 1357 	clr	a
      008DA3 A3               [24] 1358 	inc	dptr
      008DA4 F0               [24] 1359 	movx	@dptr,a
      008DA5 90 0E 5A         [24] 1360 	mov	dptr,#___memcpy_PARM_3
      008DA8 12 96 EA         [24] 1361 	lcall	_ak820_outline_0118
      008DAB 90 0B 84         [24] 1362 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_405
      008DAE F5 F0            [12] 1363 	mov	b,a
      008DB0 C0 05            [24] 1364 	push	ar5
      008DB2 C0 04            [24] 1365 	push	ar4
      008DB4 12 C1 65         [24] 1366 	lcall	___memcpy
      008DB7 D0 04            [24] 1367 	pop	ar4
      008DB9 D0 05            [24] 1368 	pop	ar5
                                   1369 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008DBB 90 0B 88         [24] 1370 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_405 + 0x0004)
      008DBE 74 20            [12] 1371 	mov	a,#0x20
      008DC0 F0               [24] 1372 	movx	@dptr,a
      008DC1 74 08            [12] 1373 	mov	a,#0x08
      008DC3 A3               [24] 1374 	inc	dptr
      008DC4 F0               [24] 1375 	movx	@dptr,a
                                   1376 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008DC5 90 0B 8A         [24] 1377 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_405 + 0x0006)
      008DC8 74 01            [12] 1378 	mov	a,#0x01
      008DCA 12 38 A6         [24] 1379 	lcall	_ak820_outline_0135
                                   1380 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008DCD 90 05 FC         [24] 1381 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008DD0 EC               [12] 1382 	mov	a,r4
      008DD1 F0               [24] 1383 	movx	@dptr,a
      008DD2 ED               [12] 1384 	mov	a,r5
      008DD3 12 38 56         [24] 1385 	lcall	_ak820_outline_0077
      008DD6 90 05 FF         [24] 1386 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008DD9 12 96 EA         [24] 1387 	lcall	_ak820_outline_0118
      008DDC 90 0B 84         [24] 1388 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_405
      008DDF 12 47 FD         [24] 1389 	lcall	_ak820_eeprom_write_block_xdata
                                   1390 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008DE2 12 44 EB         [24] 1391 	lcall	_ak820_nvm_flush
                                   1392 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008DE5 12 44 DC         [24] 1393 	lcall	_ak820_nvm_ok
      008DE8 E5 82            [12] 1394 	mov	a, dpl
      008DEA 70 04            [24] 1395 	jnz	00107$
      008DEC 90 FF FF         [24] 1396 	mov	dptr,#0xffff
      008DEF 22               [24] 1397 	ret
      008DF0                       1398 00107$:
                                   1399 ;	quantum/dynamic_keymap.c:360: return 0;
      008DF0 90 00 00         [24] 1400 	mov	dptr,#0x0000
                                   1401 ;	quantum/dynamic_keymap.c:361: }
      008DF3 22               [24] 1402 	ret
                                   1403 ;------------------------------------------------------------
                                   1404 ;Allocation info for local variables in function 'dynamic_keymap_get_key_override'
                                   1405 ;------------------------------------------------------------
                                   1406 ;buffer        Allocated with name '_dynamic_keymap_get_key_override_PARM_2'
                                   1407 ;index         Allocated with name '_dynamic_keymap_get_key_override_index_10000_407'
                                   1408 ;entry         Allocated with name '_dynamic_keymap_get_key_override_entry_10000_408'
                                   1409 ;------------------------------------------------------------
                                   1410 ;	quantum/dynamic_keymap.c:366: int dynamic_keymap_get_key_override(uint8_t index, vial_key_override_entry_t *buffer) {
                                   1411 ;	-----------------------------------------
                                   1412 ;	 function dynamic_keymap_get_key_override
                                   1413 ;	-----------------------------------------
      008DF4                       1414 _dynamic_keymap_get_key_override:
      008DF4 E5 82            [12] 1415 	mov	a,dpl
      008DF6 90 0B 91         [24] 1416 	mov	dptr,#_dynamic_keymap_get_key_override_index_10000_407
      008DF9 F0               [24] 1417 	movx	@dptr,a
                                   1418 ;	quantum/dynamic_keymap.c:367: vial_key_override_entry_t AK820_STATE_MEM *entry = (vial_key_override_entry_t AK820_STATE_MEM *)buffer;
      008DFA 90 0B 8E         [24] 1419 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      008DFD 12 38 39         [24] 1420 	lcall	_ak820_outline_0057
                                   1421 ;	quantum/dynamic_keymap.c:368: if (index >= AK820_EXTENSION_ENTRIES) return -1;
      008E00 90 0B 91         [24] 1422 	mov	dptr,#_dynamic_keymap_get_key_override_index_10000_407
      008E03 E0               [24] 1423 	movx	a,@dptr
      008E04 FD               [12] 1424 	mov	r5,a
      008E05 BD 08 00         [24] 1425 	cjne	r5,#0x08,00130$
      008E08                       1426 00130$:
      008E08 40 04            [24] 1427 	jc	00102$
      008E0A 90 FF FF         [24] 1428 	mov	dptr,#0xffff
      008E0D 22               [24] 1429 	ret
      008E0E                       1430 00102$:
                                   1431 ;	quantum/dynamic_keymap.c:369: ak820_eeprom_read_block_xdata(entry, (const void *)(VIAL_KEY_OVERRIDE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008E0E 8E 03            [24] 1432 	mov	ar3,r6
      008E10 8F 04            [24] 1433 	mov	ar4,r7
      008E12 BD 06 00         [24] 1434 	cjne	r5,#0x06,00132$
      008E15                       1435 00132$:
      008E15 50 0C            [24] 1436 	jnc	00107$
      008E17 8D 02            [24] 1437 	mov	ar2,r5
      008E19 EA               [12] 1438 	mov	a,r2
      008E1A 75 F0 0A         [24] 1439 	mov	b,#0x0a
      008E1D A4               [48] 1440 	mul	ab
      008E1E F9               [12] 1441 	mov	r1,a
      008E1F 7A 00            [12] 1442 	mov	r2,#0x00
      008E21 80 11            [24] 1443 	sjmp	00108$
      008E23                       1444 00107$:
      008E23 ED               [12] 1445 	mov	a,r5
      008E24 24 FA            [12] 1446 	add	a,#0xfa
      008E26 75 F0 0A         [24] 1447 	mov	b,#0x0a
      008E29 A4               [48] 1448 	mul	ab
      008E2A F8               [12] 1449 	mov	r0,a
      008E2B 7D 00            [12] 1450 	mov	r5,#0x00
      008E2D 74 40            [12] 1451 	mov	a,#0x40
      008E2F 28               [12] 1452 	add	a, r0
      008E30 F9               [12] 1453 	mov	r1,a
      008E31 E4               [12] 1454 	clr	a
      008E32 3D               [12] 1455 	addc	a, r5
      008E33 FA               [12] 1456 	mov	r2,a
      008E34                       1457 00108$:
      008E34 74 40            [12] 1458 	mov	a,#0x40
      008E36 29               [12] 1459 	add	a, r1
      008E37 F9               [12] 1460 	mov	r1,a
      008E38 74 07            [12] 1461 	mov	a,#0x07
      008E3A 3A               [12] 1462 	addc	a, r2
      008E3B FA               [12] 1463 	mov	r2,a
      008E3C 90 05 F3         [24] 1464 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008E3F E9               [12] 1465 	mov	a,r1
      008E40 F0               [24] 1466 	movx	@dptr,a
      008E41 EA               [12] 1467 	mov	a,r2
      008E42 12 38 56         [24] 1468 	lcall	_ak820_outline_0077
      008E45 90 05 F6         [24] 1469 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008E48 12 96 EA         [24] 1470 	lcall	_ak820_outline_0118
      008E4B 12 33 FC         [24] 1471 	lcall	_ak820_outline_0129
      008E4E C0 07            [24] 1472 	push	ar7
      008E50 C0 06            [24] 1473 	push	ar6
      008E52 12 47 71         [24] 1474 	lcall	_ak820_eeprom_read_block_xdata
      008E55 D0 06            [24] 1475 	pop	ar6
      008E57 D0 07            [24] 1476 	pop	ar7
                                   1477 ;	quantum/dynamic_keymap.c:370: if (!ak820_key_override_valid(entry)) memset(entry, 0, sizeof(*entry));
      008E59 12 38 90         [24] 1478 	lcall	_ak820_outline_0126
      008E5C C0 07            [24] 1479 	push	ar7
      008E5E C0 06            [24] 1480 	push	ar6
      008E60 12 3B B2         [24] 1481 	lcall	_ak820_key_override_valid
      008E63 E5 82            [12] 1482 	mov	a, dpl
      008E65 D0 06            [24] 1483 	pop	ar6
      008E67 D0 07            [24] 1484 	pop	ar7
      008E69 70 07            [24] 1485 	jnz	00104$
      008E6B FD               [12] 1486 	mov	r5,a
      008E6C 12 96 B4         [24] 1487 	lcall	_ak820_outline_0045
      008E6F 12 C1 DB         [24] 1488 	lcall	_memset
      008E72                       1489 00104$:
                                   1490 ;	quantum/dynamic_keymap.c:371: return 0;
      008E72 90 00 00         [24] 1491 	mov	dptr,#0x0000
                                   1492 ;	quantum/dynamic_keymap.c:372: }
      008E75 22               [24] 1493 	ret
                                   1494 ;------------------------------------------------------------
                                   1495 ;Allocation info for local variables in function 'dynamic_keymap_set_key_override'
                                   1496 ;------------------------------------------------------------
                                   1497 ;buffer        Allocated with name '_dynamic_keymap_set_key_override_PARM_2'
                                   1498 ;index         Allocated with name '_dynamic_keymap_set_key_override_index_10000_411'
                                   1499 ;entry         Allocated with name '_dynamic_keymap_set_key_override_entry_10000_412'
                                   1500 ;------------------------------------------------------------
                                   1501 ;	quantum/dynamic_keymap.c:373: int dynamic_keymap_set_key_override(uint8_t index, const vial_key_override_entry_t *buffer) {
                                   1502 ;	-----------------------------------------
                                   1503 ;	 function dynamic_keymap_set_key_override
                                   1504 ;	-----------------------------------------
      008E76                       1505 _dynamic_keymap_set_key_override:
      008E76 E5 82            [12] 1506 	mov	a,dpl
      008E78 90 0B 95         [24] 1507 	mov	dptr,#_dynamic_keymap_set_key_override_index_10000_411
      008E7B F0               [24] 1508 	movx	@dptr,a
                                   1509 ;	quantum/dynamic_keymap.c:374: const vial_key_override_entry_t AK820_STATE_MEM *entry = (const vial_key_override_entry_t AK820_STATE_MEM *)buffer;
      008E7C 90 0B 92         [24] 1510 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      008E7F 12 38 39         [24] 1511 	lcall	_ak820_outline_0057
                                   1512 ;	quantum/dynamic_keymap.c:375: if (index >= AK820_EXTENSION_ENTRIES || !ak820_key_override_valid(entry) || !ak820_nvm_ok()) return -1;
      008E82 90 0B 95         [24] 1513 	mov	dptr,#_dynamic_keymap_set_key_override_index_10000_411
      008E85 E0               [24] 1514 	movx	a,@dptr
      008E86 FD               [12] 1515 	mov	r5,a
      008E87 BD 08 00         [24] 1516 	cjne	r5,#0x08,00139$
      008E8A                       1517 00139$:
      008E8A 50 1D            [24] 1518 	jnc	00101$
      008E8C 12 38 90         [24] 1519 	lcall	_ak820_outline_0126
      008E8F C0 07            [24] 1520 	push	ar7
      008E91 C0 06            [24] 1521 	push	ar6
      008E93 C0 05            [24] 1522 	push	ar5
      008E95 12 3B B2         [24] 1523 	lcall	_ak820_key_override_valid
      008E98 E5 82            [12] 1524 	mov	a, dpl
      008E9A D0 05            [24] 1525 	pop	ar5
      008E9C D0 06            [24] 1526 	pop	ar6
      008E9E D0 07            [24] 1527 	pop	ar7
      008EA0 60 07            [24] 1528 	jz	00101$
      008EA2 12 44 DC         [24] 1529 	lcall	_ak820_nvm_ok
      008EA5 E5 82            [12] 1530 	mov	a, dpl
      008EA7 70 04            [24] 1531 	jnz	00102$
      008EA9                       1532 00101$:
      008EA9 90 FF FF         [24] 1533 	mov	dptr,#0xffff
      008EAC 22               [24] 1534 	ret
      008EAD                       1535 00102$:
                                   1536 ;	quantum/dynamic_keymap.c:376: clear_keyboard();
      008EAD C0 07            [24] 1537 	push	ar7
      008EAF C0 06            [24] 1538 	push	ar6
      008EB1 C0 05            [24] 1539 	push	ar5
      008EB3 12 7C D2         [24] 1540 	lcall	_clear_keyboard
      008EB6 D0 05            [24] 1541 	pop	ar5
      008EB8 D0 06            [24] 1542 	pop	ar6
      008EBA D0 07            [24] 1543 	pop	ar7
                                   1544 ;	quantum/dynamic_keymap.c:377: ak820_eeprom_update_block_xdata(entry, (void *)(VIAL_KEY_OVERRIDE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008EBC BD 06 00         [24] 1545 	cjne	r5,#0x06,00143$
      008EBF                       1546 00143$:
      008EBF 50 0C            [24] 1547 	jnc	00107$
      008EC1 8D 04            [24] 1548 	mov	ar4,r5
      008EC3 EC               [12] 1549 	mov	a,r4
      008EC4 75 F0 0A         [24] 1550 	mov	b,#0x0a
      008EC7 A4               [48] 1551 	mul	ab
      008EC8 FB               [12] 1552 	mov	r3,a
      008EC9 7C 00            [12] 1553 	mov	r4,#0x00
      008ECB 80 11            [24] 1554 	sjmp	00108$
      008ECD                       1555 00107$:
      008ECD ED               [12] 1556 	mov	a,r5
      008ECE 24 FA            [12] 1557 	add	a,#0xfa
      008ED0 75 F0 0A         [24] 1558 	mov	b,#0x0a
      008ED3 A4               [48] 1559 	mul	ab
      008ED4 FD               [12] 1560 	mov	r5,a
      008ED5 7A 00            [12] 1561 	mov	r2,#0x00
      008ED7 74 40            [12] 1562 	mov	a,#0x40
      008ED9 2D               [12] 1563 	add	a, r5
      008EDA FB               [12] 1564 	mov	r3,a
      008EDB E4               [12] 1565 	clr	a
      008EDC 3A               [12] 1566 	addc	a, r2
      008EDD FC               [12] 1567 	mov	r4,a
      008EDE                       1568 00108$:
      008EDE 74 40            [12] 1569 	mov	a,#0x40
      008EE0 2B               [12] 1570 	add	a, r3
      008EE1 FB               [12] 1571 	mov	r3,a
      008EE2 74 07            [12] 1572 	mov	a,#0x07
      008EE4 3C               [12] 1573 	addc	a, r4
      008EE5 FC               [12] 1574 	mov	r4,a
      008EE6 90 06 03         [24] 1575 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      008EE9 EB               [12] 1576 	mov	a,r3
      008EEA F0               [24] 1577 	movx	@dptr,a
      008EEB EC               [12] 1578 	mov	a,r4
      008EEC 12 38 56         [24] 1579 	lcall	_ak820_outline_0077
      008EEF 90 06 06         [24] 1580 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      008EF2 74 0A            [12] 1581 	mov	a,#0x0a
      008EF4 F0               [24] 1582 	movx	@dptr,a
      008EF5 E4               [12] 1583 	clr	a
      008EF6 A3               [24] 1584 	inc	dptr
      008EF7 12 4A 00         [24] 1585 	lcall	_ak820_outline_0070
      008EFA 12 48 E0         [24] 1586 	lcall	_ak820_eeprom_update_block_xdata
                                   1587 ;	quantum/dynamic_keymap.c:378: ak820_nvm_flush();
      008EFD 12 44 EB         [24] 1588 	lcall	_ak820_nvm_flush
                                   1589 ;	quantum/dynamic_keymap.c:379: return ak820_nvm_ok() ? 0 : -1;
      008F00 12 44 DC         [24] 1590 	lcall	_ak820_nvm_ok
      008F03 E5 82            [12] 1591 	mov	a, dpl
      008F05 60 06            [24] 1592 	jz	00109$
      008F07 7E 00            [12] 1593 	mov	r6,#0x00
      008F09 7F 00            [12] 1594 	mov	r7,#0x00
      008F0B 80 04            [24] 1595 	sjmp	00110$
      008F0D                       1596 00109$:
      008F0D 7E FF            [12] 1597 	mov	r6,#0xff
      008F0F 7F FF            [12] 1598 	mov	r7,#0xff
      008F11                       1599 00110$:
      008F11 12 38 90         [24] 1600 	lcall	_ak820_outline_0126
                                   1601 ;	quantum/dynamic_keymap.c:380: }
      008F14 22               [24] 1602 	ret
                                   1603 ;------------------------------------------------------------
                                   1604 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1605 ;------------------------------------------------------------
                                   1606 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_415'
                                   1607 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_416'
                                   1608 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_418'
                                   1609 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_420'
                                   1610 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_422'
                                   1611 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_424'
                                   1612 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_425'
                                   1613 ;ko            Allocated with name '_dynamic_keymap_reset_ko_10002_426'
                                   1614 ;i             Allocated with name '_dynamic_keymap_reset_i_20002_427'
                                   1615 ;------------------------------------------------------------
                                   1616 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1617 ;	-----------------------------------------
                                   1618 ;	 function dynamic_keymap_reset
                                   1619 ;	-----------------------------------------
      008F15                       1620 _dynamic_keymap_reset:
                                   1621 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008F15 90 0E DA         [24] 1622 	mov	dptr,#_vial_unlocked
      008F18 E0               [24] 1623 	movx	a,@dptr
      008F19 90 0B 96         [24] 1624 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_415
      008F1C F0               [24] 1625 	movx	@dptr,a
                                   1626 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008F1D 90 0E DA         [24] 1627 	mov	dptr,#_vial_unlocked
      008F20 74 01            [12] 1628 	mov	a,#0x01
      008F22 F0               [24] 1629 	movx	@dptr,a
                                   1630 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008F23 7F 00            [12] 1631 	mov	r7,#0x00
      008F25                       1632 00117$:
      008F25 BF 06 00         [24] 1633 	cjne	r7,#0x06,00217$
      008F28                       1634 00217$:
      008F28 40 03            [24] 1635 	jc	00218$
      008F2A 02 8F D6         [24] 1636 	ljmp	00104$
      008F2D                       1637 00218$:
                                   1638 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008F2D 7E 00            [12] 1639 	mov	r6,#0x00
      008F2F                       1640 00111$:
      008F2F BE 10 00         [24] 1641 	cjne	r6,#0x10,00219$
      008F32                       1642 00219$:
      008F32 50 4B            [24] 1643 	jnc	00102$
                                   1644 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008F34 7D 00            [12] 1645 	mov	r5,#0x00
      008F36                       1646 00108$:
      008F36 BD 08 00         [24] 1647 	cjne	r5,#0x08,00221$
      008F39                       1648 00221$:
      008F39 50 41            [24] 1649 	jnc	00112$
                                   1650 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008F3B 90 0C 3C         [24] 1651 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008F3E EE               [12] 1652 	mov	a,r6
      008F3F F0               [24] 1653 	movx	@dptr,a
      008F40 90 0C 3D         [24] 1654 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008F43 12 42 41         [24] 1655 	lcall	_ak820_outline_0199
      008F46 C0 07            [24] 1656 	push	ar7
      008F48 C0 06            [24] 1657 	push	ar6
      008F4A C0 05            [24] 1658 	push	ar5
      008F4C 12 9F 00         [24] 1659 	lcall	_keycode_at_keymap_location_raw
      008F4F AB 82            [24] 1660 	mov	r3, dpl
      008F51 AC 83            [24] 1661 	mov	r4, dph
      008F53 D0 05            [24] 1662 	pop	ar5
      008F55 D0 06            [24] 1663 	pop	ar6
      008F57 D0 07            [24] 1664 	pop	ar7
      008F59 90 0B 6D         [24] 1665 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008F5C EE               [12] 1666 	mov	a,r6
      008F5D F0               [24] 1667 	movx	@dptr,a
      008F5E 90 0B 6E         [24] 1668 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008F61 ED               [12] 1669 	mov	a,r5
      008F62 F0               [24] 1670 	movx	@dptr,a
      008F63 90 0B 6F         [24] 1671 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008F66 12 38 68         [24] 1672 	lcall	_ak820_outline_0090
      008F69 8F 82            [24] 1673 	mov	dpl, r7
      008F6B C0 07            [24] 1674 	push	ar7
      008F6D C0 06            [24] 1675 	push	ar6
      008F6F C0 05            [24] 1676 	push	ar5
      008F71 71 7A            [12] 1677 	acall	_dynamic_keymap_set_keycode
      008F73 D0 05            [24] 1678 	pop	ar5
      008F75 D0 06            [24] 1679 	pop	ar6
      008F77 D0 07            [24] 1680 	pop	ar7
                                   1681 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008F79 0D               [12] 1682 	inc	r5
      008F7A 80 BA            [24] 1683 	sjmp	00108$
      008F7C                       1684 00112$:
                                   1685 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008F7C 0E               [12] 1686 	inc	r6
      008F7D 80 B0            [24] 1687 	sjmp	00111$
      008F7F                       1688 00102$:
                                   1689 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008F7F 7E 00            [12] 1690 	mov	r6,#0x00
      008F81                       1691 00114$:
      008F81 BE 01 00         [24] 1692 	cjne	r6,#0x01,00223$
      008F84                       1693 00223$:
      008F84 50 4C            [24] 1694 	jnc	00118$
                                   1695 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008F86 12 97 1F         [24] 1696 	lcall	_ak820_outline_0189
      008F89 04               [12] 1697 	inc	a
      008F8A F0               [24] 1698 	movx	@dptr,a
      008F8B 8F 82            [24] 1699 	mov	dpl, r7
      008F8D C0 07            [24] 1700 	push	ar7
      008F8F 12 9F 45         [24] 1701 	lcall	_keycode_at_encodermap_location_raw
      008F92 12 4A 2F         [24] 1702 	lcall	_ak820_outline_0160
      008F95 D0 07            [24] 1703 	pop	ar7
      008F97 12 97 16         [24] 1704 	lcall	_ak820_outline_0188
      008F9A 04               [12] 1705 	inc	a
      008F9B F0               [24] 1706 	movx	@dptr,a
      008F9C 90 0B 79         [24] 1707 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008F9F 12 38 5C         [24] 1708 	lcall	_ak820_outline_0079
      008FA2 8F 82            [24] 1709 	mov	dpl, r7
      008FA4 C0 07            [24] 1710 	push	ar7
      008FA6 12 8C 51         [24] 1711 	lcall	_dynamic_keymap_set_encoder
      008FA9 D0 07            [24] 1712 	pop	ar7
                                   1713 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008FAB 12 97 1F         [24] 1714 	lcall	_ak820_outline_0189
      008FAE F0               [24] 1715 	movx	@dptr,a
      008FAF 8F 82            [24] 1716 	mov	dpl, r7
      008FB1 C0 07            [24] 1717 	push	ar7
      008FB3 12 9F 45         [24] 1718 	lcall	_keycode_at_encodermap_location_raw
      008FB6 12 4A 2F         [24] 1719 	lcall	_ak820_outline_0160
      008FB9 D0 07            [24] 1720 	pop	ar7
      008FBB 12 97 16         [24] 1721 	lcall	_ak820_outline_0188
      008FBE F0               [24] 1722 	movx	@dptr,a
      008FBF 90 0B 79         [24] 1723 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008FC2 12 38 5C         [24] 1724 	lcall	_ak820_outline_0079
      008FC5 8F 82            [24] 1725 	mov	dpl, r7
      008FC7 C0 07            [24] 1726 	push	ar7
      008FC9 12 8C 51         [24] 1727 	lcall	_dynamic_keymap_set_encoder
      008FCC D0 07            [24] 1728 	pop	ar7
                                   1729 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008FCE 7E 01            [12] 1730 	mov	r6,#0x01
      008FD0 80 AF            [24] 1731 	sjmp	00114$
      008FD2                       1732 00118$:
                                   1733 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008FD2 0F               [12] 1734 	inc	r7
      008FD3 02 8F 25         [24] 1735 	ljmp	00117$
      008FD6                       1736 00104$:
                                   1737 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008FD6 90 0B 97         [24] 1738 	mov	dptr,#_dynamic_keymap_reset_combo_10001_424
      008FD9 12 55 F6         [24] 1739 	lcall	_ak820_outline_0166
      008FDC 90 0B 99         [24] 1740 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0002)
      008FDF F0               [24] 1741 	movx	@dptr,a
      008FE0 A3               [24] 1742 	inc	dptr
      008FE1 F0               [24] 1743 	movx	@dptr,a
      008FE2 90 0B 9B         [24] 1744 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0004)
      008FE5 F0               [24] 1745 	movx	@dptr,a
      008FE6 A3               [24] 1746 	inc	dptr
      008FE7 F0               [24] 1747 	movx	@dptr,a
      008FE8 90 0B 9D         [24] 1748 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0006)
      008FEB F0               [24] 1749 	movx	@dptr,a
      008FEC A3               [24] 1750 	inc	dptr
      008FED F0               [24] 1751 	movx	@dptr,a
      008FEE 90 0B 9F         [24] 1752 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_424 + 0x0008)
      008FF1 F0               [24] 1753 	movx	@dptr,a
      008FF2 A3               [24] 1754 	inc	dptr
      008FF3 F0               [24] 1755 	movx	@dptr,a
                                   1756 ;	quantum/dynamic_keymap.c:450: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008FF4 FF               [12] 1757 	mov	r7,a
      008FF5                       1758 00120$:
      008FF5 BF 08 00         [24] 1759 	cjne	r7,#0x08,00225$
      008FF8                       1760 00225$:
      008FF8 50 19            [24] 1761 	jnc	00105$
                                   1762 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008FFA 8F 06            [24] 1763 	mov	ar6,r7
      008FFC 90 0B 80         [24] 1764 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008FFF 74 97            [12] 1765 	mov	a,#_dynamic_keymap_reset_combo_10001_424
      009001 F0               [24] 1766 	movx	@dptr,a
      009002 74 0B            [12] 1767 	mov	a,#(_dynamic_keymap_reset_combo_10001_424 >> 8)
      009004 12 38 56         [24] 1768 	lcall	_ak820_outline_0077
      009007 8E 82            [24] 1769 	mov	dpl, r6
      009009 C0 07            [24] 1770 	push	ar7
      00900B 12 8D 52         [24] 1771 	lcall	_dynamic_keymap_set_combo
      00900E D0 07            [24] 1772 	pop	ar7
                                   1773 ;	quantum/dynamic_keymap.c:450: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      009010 0F               [12] 1774 	inc	r7
      009011 80 E2            [24] 1775 	sjmp	00120$
      009013                       1776 00105$:
                                   1777 ;	quantum/dynamic_keymap.c:455: vial_key_override_entry_t ko = { 0 };
      009013 90 0B A1         [24] 1778 	mov	dptr,#_dynamic_keymap_reset_ko_10002_426
      009016 12 55 F6         [24] 1779 	lcall	_ak820_outline_0166
      009019 90 0B A3         [24] 1780 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0002)
      00901C F0               [24] 1781 	movx	@dptr,a
      00901D A3               [24] 1782 	inc	dptr
      00901E F0               [24] 1783 	movx	@dptr,a
      00901F 90 0B A5         [24] 1784 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0004)
      009022 F0               [24] 1785 	movx	@dptr,a
      009023 A3               [24] 1786 	inc	dptr
      009024 F0               [24] 1787 	movx	@dptr,a
      009025 90 0B A7         [24] 1788 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0006)
      009028 F0               [24] 1789 	movx	@dptr,a
      009029 90 0B A8         [24] 1790 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0007)
      00902C F0               [24] 1791 	movx	@dptr,a
      00902D 90 0B A9         [24] 1792 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0008)
      009030 F0               [24] 1793 	movx	@dptr,a
      009031 90 0B AA         [24] 1794 	mov	dptr,#(_dynamic_keymap_reset_ko_10002_426 + 0x0009)
      009034 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	quantum/dynamic_keymap.c:460: for (size_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i)
      009035 FF               [12] 1797 	mov	r7,a
      009036                       1798 00123$:
      009036 BF 08 00         [24] 1799 	cjne	r7,#0x08,00227$
      009039                       1800 00227$:
      009039 50 19            [24] 1801 	jnc	00106$
                                   1802 ;	quantum/dynamic_keymap.c:461: dynamic_keymap_set_key_override(i, &ko);
      00903B 8F 06            [24] 1803 	mov	ar6,r7
      00903D 90 0B 92         [24] 1804 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      009040 74 A1            [12] 1805 	mov	a,#_dynamic_keymap_reset_ko_10002_426
      009042 F0               [24] 1806 	movx	@dptr,a
      009043 74 0B            [12] 1807 	mov	a,#(_dynamic_keymap_reset_ko_10002_426 >> 8)
      009045 12 38 56         [24] 1808 	lcall	_ak820_outline_0077
      009048 8E 82            [24] 1809 	mov	dpl, r6
      00904A C0 07            [24] 1810 	push	ar7
      00904C 12 8E 76         [24] 1811 	lcall	_dynamic_keymap_set_key_override
      00904F D0 07            [24] 1812 	pop	ar7
                                   1813 ;	quantum/dynamic_keymap.c:460: for (size_t i = 0; i < VIAL_KEY_OVERRIDE_ENTRIES; ++i)
      009051 0F               [12] 1814 	inc	r7
      009052 80 E2            [24] 1815 	sjmp	00123$
      009054                       1816 00106$:
                                   1817 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      009054 90 0B 96         [24] 1818 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_415
      009057 E0               [24] 1819 	movx	a,@dptr
      009058 90 0E DA         [24] 1820 	mov	dptr,#_vial_unlocked
      00905B F0               [24] 1821 	movx	@dptr,a
                                   1822 ;	quantum/dynamic_keymap.c:468: }
      00905C 22               [24] 1823 	ret
                                   1824 ;------------------------------------------------------------
                                   1825 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1826 ;------------------------------------------------------------
                                   1827 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1828 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1829 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1830 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1831 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1832 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_428'
                                   1833 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_429'
                                   1834 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_429'
                                   1835 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_432'
                                   1836 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_434'
                                   1837 ;------------------------------------------------------------
                                   1838 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1839 ;	-----------------------------------------
                                   1840 ;	 function ak820_dynamic_read_buffer
                                   1841 ;	-----------------------------------------
      00905D                       1842 _ak820_dynamic_read_buffer:
      00905D 12 38 86         [24] 1843 	lcall	_ak820_outline_0114
      009060 90 0B B4         [24] 1844 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_428
      009063 12 38 8B         [24] 1845 	lcall	_ak820_outline_0115
                                   1846 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      009066 90 0B B1         [24] 1847 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009069 12 38 39         [24] 1848 	lcall	_ak820_outline_0057
                                   1849 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      00906C 90 0B B6         [24] 1850 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      00906F E4               [12] 1851 	clr	a
      009070 F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      009071 90 0B AF         [24] 1854 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009074 12 38 50         [24] 1855 	lcall	_ak820_outline_0065
      009077 8C 02            [24] 1856 	mov	ar2,r4
      009079 8D 03            [24] 1857 	mov	ar3,r5
      00907B C3               [12] 1858 	clr	c
      00907C 74 1C            [12] 1859 	mov	a,#0x1c
      00907E 9A               [12] 1860 	subb	a,r2
      00907F E4               [12] 1861 	clr	a
      009080 9B               [12] 1862 	subb	a,r3
      009081 50 01            [24] 1863 	jnc	00102$
                                   1864 ;	free result
      009083 22               [24] 1865 	ret
      009084                       1866 00102$:
                                   1867 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      009084 90 0B AD         [24] 1868 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      009087 12 4A 18         [24] 1869 	lcall	_ak820_outline_0132
      00908A 90 0B AB         [24] 1870 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00908D 12 38 80         [24] 1871 	lcall	_ak820_outline_0110
      009090 C3               [12] 1872 	clr	c
      009091 EA               [12] 1873 	mov	a,r2
      009092 98               [12] 1874 	subb	a,r0
      009093 EB               [12] 1875 	mov	a,r3
      009094 99               [12] 1876 	subb	a,r1
      009095 50 17            [24] 1877 	jnc	00104$
                                   1878 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      009097 E8               [12] 1879 	mov	a,r0
      009098 C3               [12] 1880 	clr	c
      009099 9A               [12] 1881 	subb	a,r2
      00909A F8               [12] 1882 	mov	r0,a
      00909B E9               [12] 1883 	mov	a,r1
      00909C 9B               [12] 1884 	subb	a,r3
      00909D F9               [12] 1885 	mov	r1,a
                                   1886 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      00909E C3               [12] 1887 	clr	c
      00909F E8               [12] 1888 	mov	a,r0
      0090A0 9C               [12] 1889 	subb	a,r4
      0090A1 E9               [12] 1890 	mov	a,r1
      0090A2 9D               [12] 1891 	subb	a,r5
      0090A3 40 04            [24] 1892 	jc	00114$
      0090A5 8C 00            [24] 1893 	mov	ar0,r4
      0090A7 8D 01            [24] 1894 	mov	ar1,r5
      0090A9                       1895 00114$:
      0090A9 90 0B B6         [24] 1896 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      0090AC E8               [12] 1897 	mov	a,r0
      0090AD F0               [24] 1898 	movx	@dptr,a
      0090AE                       1899 00104$:
                                   1900 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0090AE 90 0B B6         [24] 1901 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      0090B1 E0               [24] 1902 	movx	a,@dptr
      0090B2 F5 3D            [12] 1903 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      0090B4 E0               [24] 1904 	movx	a,@dptr
      0090B5 60 42            [24] 1905 	jz	00106$
      0090B7 C0 04            [24] 1906 	push	ar4
      0090B9 C0 05            [24] 1907 	push	ar5
      0090BB 8E 00            [24] 1908 	mov	ar0,r6
      0090BD 8F 05            [24] 1909 	mov	ar5,r7
      0090BF 90 0B B4         [24] 1910 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_428
      0090C2 E0               [24] 1911 	movx	a,@dptr
      0090C3 F9               [12] 1912 	mov	r1,a
      0090C4 A3               [24] 1913 	inc	dptr
      0090C5 E0               [24] 1914 	movx	a,@dptr
      0090C6 FC               [12] 1915 	mov	r4,a
      0090C7 EA               [12] 1916 	mov	a,r2
      0090C8 29               [12] 1917 	add	a, r1
      0090C9 FA               [12] 1918 	mov	r2,a
      0090CA EB               [12] 1919 	mov	a,r3
      0090CB 3C               [12] 1920 	addc	a, r4
      0090CC FB               [12] 1921 	mov	r3,a
      0090CD 90 05 F3         [24] 1922 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0090D0 EA               [12] 1923 	mov	a,r2
      0090D1 F0               [24] 1924 	movx	@dptr,a
      0090D2 EB               [12] 1925 	mov	a,r3
      0090D3 12 38 56         [24] 1926 	lcall	_ak820_outline_0077
      0090D6 90 05 F6         [24] 1927 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0090D9 E5 3D            [12] 1928 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      0090DB 12 38 A6         [24] 1929 	lcall	_ak820_outline_0135
      0090DE 88 82            [24] 1930 	mov	dpl, r0
      0090E0 8D 83            [24] 1931 	mov	dph, r5
      0090E2 C0 07            [24] 1932 	push	ar7
      0090E4 C0 06            [24] 1933 	push	ar6
      0090E6 C0 05            [24] 1934 	push	ar5
      0090E8 C0 04            [24] 1935 	push	ar4
      0090EA 12 47 71         [24] 1936 	lcall	_ak820_eeprom_read_block_xdata
      0090ED D0 04            [24] 1937 	pop	ar4
      0090EF D0 05            [24] 1938 	pop	ar5
      0090F1 D0 06            [24] 1939 	pop	ar6
      0090F3 D0 07            [24] 1940 	pop	ar7
                                   1941 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0090F5 D0 05            [24] 1942 	pop	ar5
      0090F7 D0 04            [24] 1943 	pop	ar4
                                   1944 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0090F9                       1945 00106$:
                                   1946 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0090F9 90 0B B6         [24] 1947 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_429
      0090FC E0               [24] 1948 	movx	a,@dptr
      0090FD FB               [12] 1949 	mov	r3,a
      0090FE                       1950 00109$:
      0090FE 8B 01            [24] 1951 	mov	ar1,r3
      009100 7A 00            [12] 1952 	mov	r2,#0x00
      009102 C3               [12] 1953 	clr	c
      009103 E9               [12] 1954 	mov	a,r1
      009104 9C               [12] 1955 	subb	a,r4
      009105 EA               [12] 1956 	mov	a,r2
      009106 9D               [12] 1957 	subb	a,r5
      009107 50 09            [24] 1958 	jnc	00111$
      009109 EB               [12] 1959 	mov	a,r3
      00910A 12 38 29         [24] 1960 	lcall	_ak820_outline_0036
      00910D E4               [12] 1961 	clr	a
      00910E F0               [24] 1962 	movx	@dptr,a
      00910F 0B               [12] 1963 	inc	r3
      009110 80 EC            [24] 1964 	sjmp	00109$
      009112                       1965 00111$:
                                   1966 ;	quantum/dynamic_keymap.c:483: }
      009112 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1970 ;------------------------------------------------------------
                                   1971 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1972 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1973 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_435'
                                   1974 ;------------------------------------------------------------
                                   1975 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1976 ;	-----------------------------------------
                                   1977 ;	 function dynamic_keymap_get_buffer
                                   1978 ;	-----------------------------------------
      009113                       1979 _dynamic_keymap_get_buffer:
      009113 12 38 86         [24] 1980 	lcall	_ak820_outline_0114
      009116 90 0B BC         [24] 1981 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_435
      009119 12 38 8B         [24] 1982 	lcall	_ak820_outline_0115
                                   1983 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      00911C 90 0B BC         [24] 1984 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_435
      00911F 12 38 39         [24] 1985 	lcall	_ak820_outline_0057
      009122 90 0B B7         [24] 1986 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      009125 12 38 50         [24] 1987 	lcall	_ak820_outline_0065
      009128 90 0B B9         [24] 1988 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00912B 12 55 DD         [24] 1989 	lcall	_ak820_outline_0098
      00912E 90 0B AB         [24] 1990 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      009131 E4               [12] 1991 	clr	a
      009132 F0               [24] 1992 	movx	@dptr,a
      009133 74 06            [12] 1993 	mov	a,#0x06
      009135 A3               [24] 1994 	inc	dptr
      009136 F0               [24] 1995 	movx	@dptr,a
      009137 90 0B AD         [24] 1996 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00913A 12 4F 49         [24] 1997 	lcall	_ak820_outline_0064
      00913D 90 0B AF         [24] 1998 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009140 12 38 5C         [24] 1999 	lcall	_ak820_outline_0079
      009143 90 0B B1         [24] 2000 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009146 12 4F 71         [24] 2001 	lcall	_ak820_outline_0149
      009149 EB               [12] 2002 	mov	a,r3
      00914A A3               [24] 2003 	inc	dptr
      00914B F0               [24] 2004 	movx	@dptr,a
      00914C 90 00 40         [24] 2005 	mov	dptr,#0x0040
                                   2006 ;	quantum/dynamic_keymap.c:511: }
      00914F 01 5D            [12] 2007 	ajmp	_ak820_dynamic_read_buffer
                                   2008 ;------------------------------------------------------------
                                   2009 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   2010 ;------------------------------------------------------------
                                   2011 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   2012 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   2013 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   2014 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   2015 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   2016 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_437'
                                   2017 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_438'
                                   2018 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_438'
                                   2019 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_438'
                                   2020 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_441'
                                   2021 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_444'
                                   2022 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_444'
                                   2023 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_446'
                                   2024 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_449'
                                   2025 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_451'
                                   2026 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_452'
                                   2027 ;------------------------------------------------------------
                                   2028 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2029 ;	-----------------------------------------
                                   2030 ;	 function dynamic_keymap_set_buffer
                                   2031 ;	-----------------------------------------
      009151                       2032 _dynamic_keymap_set_buffer:
      009151 12 38 86         [24] 2033 	lcall	_ak820_outline_0114
      009154 90 0B C3         [24] 2034 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      009157 12 38 8B         [24] 2035 	lcall	_ak820_outline_0115
                                   2036 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      00915A 90 0B C3         [24] 2037 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      00915D 12 4E EC         [24] 2038 	lcall	_ak820_outline_0010
      009160 74 40            [12] 2039 	mov	a,#0x40
      009162 2C               [12] 2040 	add	a, r4
      009163 FA               [12] 2041 	mov	r2,a
      009164 E4               [12] 2042 	clr	a
      009165 3D               [12] 2043 	addc	a, r5
      009166 FB               [12] 2044 	mov	r3,a
                                   2045 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      009167 90 0B C0         [24] 2046 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00916A 12 38 80         [24] 2047 	lcall	_ak820_outline_0110
                                   2048 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      00916D 90 0B BE         [24] 2049 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      009170 E0               [24] 2050 	movx	a,@dptr
      009171 F5 3E            [12] 2051 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      009173 A3               [24] 2052 	inc	dptr
      009174 E0               [24] 2053 	movx	a,@dptr
      009175 F5 3F            [12] 2054 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      009177 E5 3E            [12] 2055 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      009179 45 3F            [12] 2056 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00917B 70 01            [24] 2057 	jnz	00102$
      00917D 22               [24] 2058 	ret
      00917E                       2059 00102$:
                                   2060 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      00917E 85 3E 40         [24] 2061 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      009181 85 3F 41         [24] 2062 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009184 C3               [12] 2063 	clr	c
      009185 74 1C            [12] 2064 	mov	a,#0x1c
      009187 95 40            [12] 2065 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      009189 E4               [12] 2066 	clr	a
      00918A 95 41            [12] 2067 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      00918C 50 01            [24] 2068 	jnc	00104$
                                   2069 ;	free result
      00918E 22               [24] 2070 	ret
      00918F                       2071 00104$:
                                   2072 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      00918F 85 3E 42         [24] 2073 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   2074 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      009192 74 FA            [12] 2075 	mov	a,#0x100 - 0x06
      009194 2F               [12] 2076 	add	a,r7
      009195 40 11            [24] 2077 	jc	00105$
      009197 E4               [12] 2078 	clr	a
      009198 C3               [12] 2079 	clr	c
      009199 9E               [12] 2080 	subb	a,r6
      00919A FE               [12] 2081 	mov	r6,a
      00919B 74 06            [12] 2082 	mov	a,#0x06
      00919D 9F               [12] 2083 	subb	a,r7
      00919E FF               [12] 2084 	mov	r7,a
      00919F C3               [12] 2085 	clr	c
      0091A0 EE               [12] 2086 	mov	a,r6
      0091A1 95 3E            [12] 2087 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0091A3 EF               [12] 2088 	mov	a,r7
      0091A4 95 3F            [12] 2089 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0091A6 50 01            [24] 2090 	jnc	00106$
      0091A8                       2091 00105$:
                                   2092 ;	quantum/dynamic_keymap.c:529: return;
      0091A8 22               [24] 2093 	ret
      0091A9                       2094 00106$:
                                   2095 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      0091A9 90 0E DA         [24] 2096 	mov	dptr,#_vial_unlocked
      0091AC E0               [24] 2097 	movx	a,@dptr
      0091AD 60 02            [24] 2098 	jz	00207$
      0091AF 41 BB            [12] 2099 	ajmp	00120$
      0091B1                       2100 00207$:
                                   2101 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      0091B1 90 0B C5         [24] 2102 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_444
      0091B4 E4               [12] 2103 	clr	a
      0091B5 F0               [24] 2104 	movx	@dptr,a
                                   2105 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      0091B6 90 0B C6         [24] 2106 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_444
      0091B9 E5 42            [12] 2107 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0091BB F0               [24] 2108 	movx	@dptr,a
                                   2109 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      0091BC EC               [12] 2110 	mov	a,r4
      0091BD 30 E0 31         [24] 2111 	jnb	acc.0,00111$
                                   2112 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      0091C0 EA               [12] 2113 	mov	a,r2
      0091C1 24 FF            [12] 2114 	add	a,#0xff
      0091C3 FE               [12] 2115 	mov	r6,a
      0091C4 EB               [12] 2116 	mov	a,r3
      0091C5 34 FF            [12] 2117 	addc	a,#0xff
      0091C7 FF               [12] 2118 	mov	r7,a
      0091C8 7D 00            [12] 2119 	mov	r5,#0x00
      0091CA 12 7D 6C         [24] 2120 	lcall	_ak820_outline_0120
      0091CD 12 47 36         [24] 2121 	lcall	_eeprom_read_byte
      0091D0 AE 82            [24] 2122 	mov	r6,dpl
      0091D2 7F 00            [12] 2123 	mov	r7,#0x00
      0091D4 12 38 BA         [24] 2124 	lcall	_ak820_outline_0167
      0091D7 E0               [24] 2125 	movx	a,@dptr
      0091D8 7C 00            [12] 2126 	mov	r4,#0x00
      0091DA 42 07            [12] 2127 	orl	ar7,a
      0091DC EC               [12] 2128 	mov	a,r4
      0091DD 42 06            [12] 2129 	orl	ar6,a
                                   2130 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      0091DF BF 00 09         [24] 2131 	cjne	r7,#0x00,00109$
      0091E2 BE 7C 06         [24] 2132 	cjne	r6,#0x7c,00109$
                                   2133 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      0091E5 12 38 BA         [24] 2134 	lcall	_ak820_outline_0167
      0091E8 74 FF            [12] 2135 	mov	a,#0xff
      0091EA F0               [24] 2136 	movx	@dptr,a
      0091EB                       2137 00109$:
                                   2138 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      0091EB 90 0B C5         [24] 2139 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_444
      0091EE 74 01            [12] 2140 	mov	a,#0x01
      0091F0 F0               [24] 2141 	movx	@dptr,a
      0091F1                       2142 00111$:
                                   2143 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      0091F1 90 0B C3         [24] 2144 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      0091F4 12 38 39         [24] 2145 	lcall	_ak820_outline_0057
      0091F7 E5 3E            [12] 2146 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0091F9 2E               [12] 2147 	add	a, r6
      0091FA FE               [12] 2148 	mov	r6,a
      0091FB E5 3F            [12] 2149 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0091FD 3F               [12] 2150 	addc	a, r7
      0091FE EE               [12] 2151 	mov	a,r6
      0091FF 30 E0 5A         [24] 2152 	jnb	acc.0,00115$
                                   2153 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      009202 AE 42            [24] 2154 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      009204 7F 00            [12] 2155 	mov	r7,#0x00
      009206 EE               [12] 2156 	mov	a,r6
      009207 24 FF            [12] 2157 	add	a,#0xff
      009209 FC               [12] 2158 	mov	r4,a
      00920A EF               [12] 2159 	mov	a,r7
      00920B 34 FF            [12] 2160 	addc	a,#0xff
      00920D FD               [12] 2161 	mov	r5,a
      00920E EC               [12] 2162 	mov	a,r4
      00920F 28               [12] 2163 	add	a, r0
      009210 F5 82            [12] 2164 	mov	dpl,a
      009212 ED               [12] 2165 	mov	a,r5
      009213 39               [12] 2166 	addc	a, r1
      009214 F5 83            [12] 2167 	mov	dph,a
      009216 E0               [24] 2168 	movx	a,@dptr
      009217 FC               [12] 2169 	mov	r4,a
      009218 7D 00            [12] 2170 	mov	r5,#0x00
      00921A E5 42            [12] 2171 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00921C 2A               [12] 2172 	add	a, r2
      00921D FA               [12] 2173 	mov	r2,a
      00921E E4               [12] 2174 	clr	a
      00921F 3B               [12] 2175 	addc	a, r3
      009220 FB               [12] 2176 	mov	r3,a
      009221 C0 00            [24] 2177 	push	ar0
      009223 C0 01            [24] 2178 	push	ar1
      009225 8B 01            [24] 2179 	mov	ar1,r3
      009227 7B 00            [12] 2180 	mov	r3,#0x00
      009229 8A 82            [24] 2181 	mov	dpl, r2
      00922B 89 83            [24] 2182 	mov	dph, r1
      00922D 8B F0            [24] 2183 	mov	b, r3
      00922F 12 47 36         [24] 2184 	lcall	_eeprom_read_byte
      009232 AB 82            [24] 2185 	mov	r3, dpl
      009234 7A 00            [12] 2186 	mov	r2,#0x00
      009236 EB               [12] 2187 	mov	a,r3
      009237 12 4A 29         [24] 2188 	lcall	_ak820_outline_0153
                                   2189 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      00923A BD 00 05         [24] 2190 	cjne	r5,#0x00,00212$
      00923D BC 7C 02         [24] 2191 	cjne	r4,#0x7c,00212$
      009240 80 06            [24] 2192 	sjmp	00213$
      009242                       2193 00212$:
      009242 D0 01            [24] 2194 	pop	ar1
      009244 D0 00            [24] 2195 	pop	ar0
      009246 80 0D            [24] 2196 	sjmp	00113$
      009248                       2197 00213$:
      009248 D0 01            [24] 2198 	pop	ar1
      00924A D0 00            [24] 2199 	pop	ar0
                                   2200 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      00924C 1E               [12] 2201 	dec	r6
      00924D BE FF 01         [24] 2202 	cjne	r6,#0xff,00214$
      009250 1F               [12] 2203 	dec	r7
      009251                       2204 00214$:
      009251 EE               [12] 2205 	mov	a,r6
      009252 12 96 F8         [24] 2206 	lcall	_ak820_outline_0139
      009255                       2207 00113$:
                                   2208 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      009255 E5 42            [12] 2209 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      009257 14               [12] 2210 	dec	a
      009258 90 0B C6         [24] 2211 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_444
      00925B F0               [24] 2212 	movx	@dptr,a
      00925C                       2213 00115$:
                                   2214 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      00925C 90 0B C5         [24] 2215 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_444
      00925F E0               [24] 2216 	movx	a,@dptr
      009260 90 0B C7         [24] 2217 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_451
      009263 F0               [24] 2218 	movx	@dptr,a
      009264                       2219 00122$:
      009264 90 0B C7         [24] 2220 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_451
      009267 E0               [24] 2221 	movx	a,@dptr
      009268 FF               [12] 2222 	mov	r7,a
      009269 90 0B C6         [24] 2223 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_444
      00926C E0               [24] 2224 	movx	a,@dptr
      00926D FE               [12] 2225 	mov	r6,a
      00926E C3               [12] 2226 	clr	c
      00926F EF               [12] 2227 	mov	a,r7
      009270 9E               [12] 2228 	subb	a,r6
      009271 50 48            [24] 2229 	jnc	00120$
                                   2230 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      009273 EF               [12] 2231 	mov	a,r7
      009274 28               [12] 2232 	add	a, r0
      009275 FD               [12] 2233 	mov	r5,a
      009276 E4               [12] 2234 	clr	a
      009277 39               [12] 2235 	addc	a, r1
      009278 FE               [12] 2236 	mov	r6,a
      009279 12 4F 56         [24] 2237 	lcall	_ak820_outline_0081
      00927C 7B 00            [12] 2238 	mov	r3,#0x00
      00927E 8C 3F            [24] 2239 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      009280 8B 3E            [24] 2240 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      009282 8F 02            [24] 2241 	mov	ar2,r7
      009284 7F 00            [12] 2242 	mov	r7,#0x00
      009286 74 01            [12] 2243 	mov	a,#0x01
      009288 2A               [12] 2244 	add	a, r2
      009289 FB               [12] 2245 	mov	r3,a
      00928A E4               [12] 2246 	clr	a
      00928B 3F               [12] 2247 	addc	a, r7
      00928C FC               [12] 2248 	mov	r4,a
      00928D EB               [12] 2249 	mov	a,r3
      00928E 28               [12] 2250 	add	a, r0
      00928F F5 82            [12] 2251 	mov	dpl,a
      009291 EC               [12] 2252 	mov	a,r4
      009292 39               [12] 2253 	addc	a, r1
      009293 F5 83            [12] 2254 	mov	dph,a
      009295 E0               [24] 2255 	movx	a,@dptr
      009296 FC               [12] 2256 	mov	r4,a
      009297 7B 00            [12] 2257 	mov	r3,#0x00
      009299 E5 3F            [12] 2258 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00929B 42 03            [12] 2259 	orl	ar3,a
                                   2260 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      00929D BC 00 12         [24] 2261 	cjne	r4,#0x00,00123$
      0092A0 BB 7C 0F         [24] 2262 	cjne	r3,#0x7c,00123$
                                   2263 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      0092A3 12 38 AB         [24] 2264 	lcall	_ak820_outline_0145
      0092A6 74 FF            [12] 2265 	mov	a,#0xff
      0092A8 F0               [24] 2266 	movx	@dptr,a
                                   2267 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      0092A9 0A               [12] 2268 	inc	r2
      0092AA BA 00 01         [24] 2269 	cjne	r2,#0x00,00218$
      0092AD 0F               [12] 2270 	inc	r7
      0092AE                       2271 00218$:
      0092AE EA               [12] 2272 	mov	a,r2
      0092AF 12 96 F8         [24] 2273 	lcall	_ak820_outline_0139
      0092B2                       2274 00123$:
                                   2275 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0092B2 90 0B C7         [24] 2276 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_451
      0092B5 E0               [24] 2277 	movx	a,@dptr
      0092B6 24 02            [12] 2278 	add	a,#0x02
      0092B8 F0               [24] 2279 	movx	@dptr,a
      0092B9 80 A9            [24] 2280 	sjmp	00122$
      0092BB                       2281 00120$:
                                   2282 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      0092BB 90 0B C3         [24] 2283 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_437
      0092BE 12 38 39         [24] 2284 	lcall	_ak820_outline_0057
      0092C1 74 40            [12] 2285 	mov	a,#0x40
      0092C3 12 4A 23         [24] 2286 	lcall	_ak820_outline_0148
      0092C6 90 05 FC         [24] 2287 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0092C9 12 4F 49         [24] 2288 	lcall	_ak820_outline_0064
      0092CC E4               [12] 2289 	clr	a
      0092CD A3               [24] 2290 	inc	dptr
      0092CE F0               [24] 2291 	movx	@dptr,a
      0092CF 90 05 FF         [24] 2292 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0092D2 E5 40            [12] 2293 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0092D4 F0               [24] 2294 	movx	@dptr,a
      0092D5 E5 41            [12] 2295 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0092D7 A3               [24] 2296 	inc	dptr
      0092D8 F0               [24] 2297 	movx	@dptr,a
      0092D9 12 38 BA         [24] 2298 	lcall	_ak820_outline_0167
                                   2299 ;	quantum/dynamic_keymap.c:584: }
      0092DC 02 47 FD         [24] 2300 	ljmp	_ak820_eeprom_write_block_xdata
                                   2301 ;------------------------------------------------------------
                                   2302 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2303 ;------------------------------------------------------------
                                   2304 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2305 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2306 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_455'
                                   2307 ;------------------------------------------------------------
                                   2308 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2309 ;	-----------------------------------------
                                   2310 ;	 function keycode_at_keymap_location
                                   2311 ;	-----------------------------------------
      0092DF                       2312 _keycode_at_keymap_location:
      0092DF E5 82            [12] 2313 	mov	a,dpl
      0092E1 90 0B CA         [24] 2314 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_455
      0092E4 F0               [24] 2315 	movx	@dptr,a
                                   2316 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      0092E5 E0               [24] 2317 	movx	a,@dptr
      0092E6 FF               [12] 2318 	mov	r7,a
      0092E7 BF 06 00         [24] 2319 	cjne	r7,#0x06,00128$
      0092EA                       2320 00128$:
      0092EA 50 22            [24] 2321 	jnc	00102$
      0092EC 90 0B C8         [24] 2322 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      0092EF E0               [24] 2323 	movx	a,@dptr
      0092F0 FE               [12] 2324 	mov	r6,a
      0092F1 BE 10 00         [24] 2325 	cjne	r6,#0x10,00130$
      0092F4                       2326 00130$:
      0092F4 50 18            [24] 2327 	jnc	00102$
      0092F6 90 0B C9         [24] 2328 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      0092F9 E0               [24] 2329 	movx	a,@dptr
      0092FA FD               [12] 2330 	mov	r5,a
      0092FB BD 08 00         [24] 2331 	cjne	r5,#0x08,00132$
      0092FE                       2332 00132$:
      0092FE 50 0E            [24] 2333 	jnc	00102$
                                   2334 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      009300 90 0B 6A         [24] 2335 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      009303 EE               [12] 2336 	mov	a,r6
      009304 F0               [24] 2337 	movx	@dptr,a
      009305 90 0B 6B         [24] 2338 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      009308 12 42 41         [24] 2339 	lcall	_ak820_outline_0199
      00930B 02 8B 2D         [24] 2340 	ljmp	_dynamic_keymap_get_keycode
      00930E                       2341 00102$:
                                   2342 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      00930E 90 00 00         [24] 2343 	mov	dptr,#0x0000
                                   2344 ;	quantum/dynamic_keymap.c:591: }
      009311 22               [24] 2345 	ret
                                   2346 ;------------------------------------------------------------
                                   2347 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2348 ;------------------------------------------------------------
                                   2349 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2350 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2351 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_459'
                                   2352 ;------------------------------------------------------------
                                   2353 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2354 ;	-----------------------------------------
                                   2355 ;	 function keycode_at_encodermap_location
                                   2356 ;	-----------------------------------------
      009312                       2357 _keycode_at_encodermap_location:
      009312 E5 82            [12] 2358 	mov	a,dpl
      009314 90 0B CD         [24] 2359 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_459
      009317 F0               [24] 2360 	movx	@dptr,a
                                   2361 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      009318 E0               [24] 2362 	movx	a,@dptr
      009319 FF               [12] 2363 	mov	r7,a
      00931A BF 06 00         [24] 2364 	cjne	r7,#0x06,00120$
      00931D                       2365 00120$:
      00931D 50 1E            [24] 2366 	jnc	00102$
      00931F 90 0B CB         [24] 2367 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      009322 E0               [24] 2368 	movx	a,@dptr
      009323 FE               [12] 2369 	mov	r6,a
      009324 BE 01 00         [24] 2370 	cjne	r6,#0x01,00122$
      009327                       2371 00122$:
      009327 50 14            [24] 2372 	jnc	00102$
                                   2373 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      009329 90 0B CC         [24] 2374 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      00932C E0               [24] 2375 	movx	a,@dptr
      00932D FE               [12] 2376 	mov	r6,a
      00932E 90 0B 74         [24] 2377 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      009331 E4               [12] 2378 	clr	a
      009332 F0               [24] 2379 	movx	@dptr,a
      009333 90 0B 75         [24] 2380 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      009336 EE               [12] 2381 	mov	a,r6
      009337 F0               [24] 2382 	movx	@dptr,a
      009338 8F 82            [24] 2383 	mov	dpl, r7
      00933A 02 8B EA         [24] 2384 	ljmp	_dynamic_keymap_get_encoder
      00933D                       2385 00102$:
                                   2386 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      00933D 90 00 00         [24] 2387 	mov	dptr,#0x0000
                                   2388 ;	quantum/dynamic_keymap.c:599: }
      009340 22               [24] 2389 	ret
                                   2390 ;------------------------------------------------------------
                                   2391 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2392 ;------------------------------------------------------------
                                   2393 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2394 ;	-----------------------------------------
                                   2395 ;	 function dynamic_keymap_macro_get_count
                                   2396 ;	-----------------------------------------
      009341                       2397 _dynamic_keymap_macro_get_count:
                                   2398 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      009341 75 82 10         [24] 2399 	mov	dpl, #0x10
                                   2400 ;	quantum/dynamic_keymap.c:604: }
      009344 22               [24] 2401 	ret
                                   2402 ;------------------------------------------------------------
                                   2403 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2404 ;------------------------------------------------------------
                                   2405 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2406 ;	-----------------------------------------
                                   2407 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2408 ;	-----------------------------------------
      009345                       2409 _dynamic_keymap_macro_get_buffer_size:
                                   2410 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      009345 90 20 00         [24] 2411 	mov	dptr,#0x2000
                                   2412 ;	quantum/dynamic_keymap.c:608: }
      009348 22               [24] 2413 	ret
                                   2414 ;------------------------------------------------------------
                                   2415 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2416 ;------------------------------------------------------------
                                   2417 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2418 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2419 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2420 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_467'
                                   2421 ;------------------------------------------------------------
                                   2422 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2423 ;	-----------------------------------------
                                   2424 ;	 function dynamic_keymap_macro_get_buffer
                                   2425 ;	-----------------------------------------
      009349                       2426 _dynamic_keymap_macro_get_buffer:
      009349 12 38 86         [24] 2427 	lcall	_ak820_outline_0114
      00934C 90 0B D3         [24] 2428 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_467
      00934F 12 38 8B         [24] 2429 	lcall	_ak820_outline_0115
                                   2430 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      009352 12 2B 2B         [24] 2431 	lcall	_ak820_macro_length
      009355 12 4A 1E         [24] 2432 	lcall	_ak820_outline_0144
      009358 90 0B D3         [24] 2433 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_467
      00935B 12 38 50         [24] 2434 	lcall	_ak820_outline_0065
      00935E 90 0B CE         [24] 2435 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      009361 E0               [24] 2436 	movx	a,@dptr
      009362 F5 43            [12] 2437 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      009364 A3               [24] 2438 	inc	dptr
      009365 E0               [24] 2439 	movx	a,@dptr
      009366 F5 44            [12] 2440 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      009368 90 0B D0         [24] 2441 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00936B 12 38 80         [24] 2442 	lcall	_ak820_outline_0110
      00936E A3               [24] 2443 	inc	dptr
      00936F E0               [24] 2444 	movx	a,@dptr
      009370 FB               [12] 2445 	mov	r3,a
      009371 90 0B AB         [24] 2446 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      009374 12 4F 49         [24] 2447 	lcall	_ak820_outline_0064
      009377 90 0B AD         [24] 2448 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00937A 12 38 5C         [24] 2449 	lcall	_ak820_outline_0079
      00937D 90 0B AF         [24] 2450 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009380 E5 43            [12] 2451 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      009382 F0               [24] 2452 	movx	@dptr,a
      009383 E5 44            [12] 2453 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      009385 A3               [24] 2454 	inc	dptr
      009386 F0               [24] 2455 	movx	@dptr,a
      009387 90 0B B1         [24] 2456 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00938A E8               [12] 2457 	mov	a,r0
      00938B F0               [24] 2458 	movx	@dptr,a
      00938C E9               [12] 2459 	mov	a,r1
      00938D A3               [24] 2460 	inc	dptr
      00938E 12 7D A0         [24] 2461 	lcall	_ak820_outline_0197
      009391 90 08 00         [24] 2462 	mov	dptr,#0x0800
                                   2463 ;	quantum/dynamic_keymap.c:635: }
      009394 01 5D            [12] 2464 	ajmp	_ak820_dynamic_read_buffer
                                   2465 ;------------------------------------------------------------
                                   2466 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2467 ;------------------------------------------------------------
                                   2468 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2469 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2470 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_469'
                                   2471 ;------------------------------------------------------------
                                   2472 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2473 ;	-----------------------------------------
                                   2474 ;	 function dynamic_keymap_macro_set_buffer
                                   2475 ;	-----------------------------------------
      009396                       2476 _dynamic_keymap_macro_set_buffer:
      009396 12 38 86         [24] 2477 	lcall	_ak820_outline_0114
      009399 90 0B DA         [24] 2478 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_469
      00939C 12 38 8B         [24] 2479 	lcall	_ak820_outline_0115
                                   2480 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      00939F 90 0B DA         [24] 2481 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_469
      0093A2 12 38 39         [24] 2482 	lcall	_ak820_outline_0057
      0093A5 90 0B D5         [24] 2483 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      0093A8 12 38 50         [24] 2484 	lcall	_ak820_outline_0065
      0093AB 90 0B D7         [24] 2485 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      0093AE 12 55 DD         [24] 2486 	lcall	_ak820_outline_0098
      0093B1 90 05 82         [24] 2487 	mov	dptr,#_ak820_macro_write_PARM_2
      0093B4 12 38 5C         [24] 2488 	lcall	_ak820_outline_0079
      0093B7 90 05 84         [24] 2489 	mov	dptr,#_ak820_macro_write_PARM_3
      0093BA 12 4F 71         [24] 2490 	lcall	_ak820_outline_0149
      0093BD EB               [12] 2491 	mov	a,r3
      0093BE A3               [24] 2492 	inc	dptr
      0093BF 12 4A 00         [24] 2493 	lcall	_ak820_outline_0070
                                   2494 ;	quantum/dynamic_keymap.c:640: }
      0093C2 02 2B 45         [24] 2495 	ljmp	_ak820_macro_write
                                   2496 ;------------------------------------------------------------
                                   2497 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2498 ;------------------------------------------------------------
                                   2499 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2500 ;	-----------------------------------------
                                   2501 ;	 function dynamic_keymap_macro_reset
                                   2502 ;	-----------------------------------------
      0093C5                       2503 _dynamic_keymap_macro_reset:
                                   2504 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2505 ;	quantum/dynamic_keymap.c:666: }
      0093C5 02 2E 64         [24] 2506 	ljmp	_ak820_macro_reset
                                   2507 ;------------------------------------------------------------
                                   2508 ;Allocation info for local variables in function 'decode_keycode'
                                   2509 ;------------------------------------------------------------
                                   2510 ;kc            Allocated with name '_decode_keycode_kc_10000_473'
                                   2511 ;------------------------------------------------------------
                                   2512 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2513 ;	-----------------------------------------
                                   2514 ;	 function decode_keycode
                                   2515 ;	-----------------------------------------
      0093C8                       2516 _decode_keycode:
      0093C8 12 38 86         [24] 2517 	lcall	_ak820_outline_0114
      0093CB 90 0B DC         [24] 2518 	mov	dptr,#_decode_keycode_kc_10000_473
      0093CE 12 38 8B         [24] 2519 	lcall	_ak820_outline_0115
                                   2520 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      0093D1 90 0B DC         [24] 2521 	mov	dptr,#_decode_keycode_kc_10000_473
      0093D4 12 4E EC         [24] 2522 	lcall	_ak820_outline_0010
      0093D7 C3               [12] 2523 	clr	c
      0093D8 E4               [12] 2524 	clr	a
      0093D9 9C               [12] 2525 	subb	a,r4
      0093DA 74 FF            [12] 2526 	mov	a,#0xff
      0093DC 9D               [12] 2527 	subb	a,r5
      0093DD 50 08            [24] 2528 	jnc	00102$
                                   2529 ;	free result
                                   2530 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      0093DF 8C 05            [24] 2531 	mov	ar5,r4
      0093E1 7C 00            [12] 2532 	mov	r4,#0x00
      0093E3 12 38 A1         [24] 2533 	lcall	_ak820_outline_0134
      0093E6 22               [24] 2534 	ret
      0093E7                       2535 00102$:
                                   2536 ;	quantum/dynamic_keymap.c:672: return kc;
      0093E7 12 38 90         [24] 2537 	lcall	_ak820_outline_0126
                                   2538 ;	quantum/dynamic_keymap.c:673: }
      0093EA 22               [24] 2539 	ret
                                   2540 ;------------------------------------------------------------
                                   2541 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2542 ;------------------------------------------------------------
                                   2543 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_476'
                                   2544 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_477'
                                   2545 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_482'
                                   2546 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_483'
                                   2547 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_489'
                                   2548 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_507'
                                   2549 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_511'
                                   2550 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_511'
                                   2551 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_513'
                                   2552 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_515'
                                   2553 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_519'
                                   2554 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_521'
                                   2555 ;------------------------------------------------------------
                                   2556 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2557 ;	-----------------------------------------
                                   2558 ;	 function dynamic_keymap_macro_send
                                   2559 ;	-----------------------------------------
      0093EB                       2560 _dynamic_keymap_macro_send:
      0093EB E5 82            [12] 2561 	mov	a,dpl
      0093ED 90 0B DE         [24] 2562 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_476
      0093F0 F0               [24] 2563 	movx	@dptr,a
                                   2564 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      0093F1 90 0B DF         [24] 2565 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_477
      0093F4 E0               [24] 2566 	movx	a,@dptr
      0093F5 60 01            [24] 2567 	jz	00102$
      0093F7 22               [24] 2568 	ret
      0093F8                       2569 00102$:
                                   2570 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      0093F8 90 0B DE         [24] 2571 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_476
      0093FB E0               [24] 2572 	movx	a,@dptr
      0093FC FF               [12] 2573 	mov	r7,a
      0093FD BF 10 00         [24] 2574 	cjne	r7,#0x10,00422$
      009400                       2575 00422$:
      009400 40 01            [24] 2576 	jc	00104$
                                   2577 ;	quantum/dynamic_keymap.c:683: return;
      009402 22               [24] 2578 	ret
      009403                       2579 00104$:
                                   2580 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      009403 C0 07            [24] 2581 	push	ar7
      009405 12 2A F2         [24] 2582 	lcall	_ak820_macro_ready
      009408 E5 82            [12] 2583 	mov	a, dpl
      00940A D0 07            [24] 2584 	pop	ar7
      00940C 70 01            [24] 2585 	jnz	00106$
      00940E 22               [24] 2586 	ret
      00940F                       2587 00106$:
                                   2588 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      00940F 90 0B E0         [24] 2589 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      009412 E4               [12] 2590 	clr	a
      009413 F0               [24] 2591 	movx	@dptr,a
      009414 74 08            [12] 2592 	mov	a,#0x08
      009416 A3               [24] 2593 	inc	dptr
      009417 F0               [24] 2594 	movx	@dptr,a
                                   2595 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      009418 C0 07            [24] 2596 	push	ar7
      00941A 12 2B 2B         [24] 2597 	lcall	_ak820_macro_length
      00941D AD 82            [24] 2598 	mov	r5, dpl
      00941F AE 83            [24] 2599 	mov	r6, dph
      009421 D0 07            [24] 2600 	pop	ar7
      009423 74 08            [12] 2601 	mov	a,#0x08
      009425 2E               [12] 2602 	add	a, r6
      009426 FE               [12] 2603 	mov	r6,a
                                   2604 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      009427 7B 00            [12] 2605 	mov	r3,#0x00
      009429 7C 08            [12] 2606 	mov	r4,#0x08
      00942B                       2607 00111$:
      00942B EF               [12] 2608 	mov	a,r7
      00942C 60 31            [24] 2609 	jz	00113$
                                   2610 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      00942E EB               [12] 2611 	mov	a,r3
      00942F B5 05 05         [24] 2612 	cjne	a,ar5,00108$
      009432 EC               [12] 2613 	mov	a,r4
      009433 B5 06 01         [24] 2614 	cjne	a,ar6,00108$
                                   2615 ;	quantum/dynamic_keymap.c:717: return;
      009436 22               [24] 2616 	ret
      009437                       2617 00108$:
                                   2618 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      009437 8B 01            [24] 2619 	mov	ar1,r3
      009439 8C 02            [24] 2620 	mov	ar2,r4
      00943B 8A 00            [24] 2621 	mov	ar0,r2
      00943D 7A 00            [12] 2622 	mov	r2,#0x00
      00943F 89 82            [24] 2623 	mov	dpl, r1
      009441 88 83            [24] 2624 	mov	dph, r0
      009443 8A F0            [24] 2625 	mov	b, r2
      009445 12 47 36         [24] 2626 	lcall	_eeprom_read_byte
      009448 E5 82            [12] 2627 	mov	a, dpl
      00944A 70 06            [24] 2628 	jnz	00110$
                                   2629 ;	quantum/dynamic_keymap.c:720: --id;
      00944C 1F               [12] 2630 	dec	r7
      00944D 90 0B DE         [24] 2631 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_476
      009450 EF               [12] 2632 	mov	a,r7
      009451 F0               [24] 2633 	movx	@dptr,a
      009452                       2634 00110$:
                                   2635 ;	quantum/dynamic_keymap.c:722: ++p;
      009452 0B               [12] 2636 	inc	r3
      009453 BB 00 01         [24] 2637 	cjne	r3,#0x00,00429$
      009456 0C               [12] 2638 	inc	r4
      009457                       2639 00429$:
      009457 90 0B E0         [24] 2640 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      00945A 12 38 68         [24] 2641 	lcall	_ak820_outline_0090
      00945D 80 CC            [24] 2642 	sjmp	00111$
      00945F                       2643 00113$:
                                   2644 ;	quantum/dynamic_keymap.c:728: sending = true;
      00945F 90 0B DF         [24] 2645 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_477
      009462 74 01            [12] 2646 	mov	a,#0x01
      009464 F0               [24] 2647 	movx	@dptr,a
                                   2648 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      009465 12 97 10         [24] 2649 	lcall	_ak820_outline_0177
      009468 90 09 F2         [24] 2650 	mov	dptr,#_ak820_macro_cancelled
      00946B F0               [24] 2651 	movx	@dptr,a
                                   2652 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      00946C 90 0B E2         [24] 2653 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      00946F F0               [24] 2654 	movx	@dptr,a
      009470 90 0B E3         [24] 2655 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      009473 F0               [24] 2656 	movx	@dptr,a
      009474 90 0B E4         [24] 2657 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0002)
      009477 F0               [24] 2658 	movx	@dptr,a
      009478 90 0B E5         [24] 2659 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0003)
      00947B F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	quantum/dynamic_keymap.c:738: while (p < end
      00947C                       2662 00167$:
                                   2663 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      00947C 90 0B E0         [24] 2664 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      00947F E0               [24] 2665 	movx	a,@dptr
      009480 FC               [12] 2666 	mov	r4,a
      009481 A3               [24] 2667 	inc	dptr
      009482 E0               [24] 2668 	movx	a,@dptr
      009483 FF               [12] 2669 	mov	r7,a
      009484 C3               [12] 2670 	clr	c
      009485 EC               [12] 2671 	mov	a,r4
      009486 9D               [12] 2672 	subb	a,r5
      009487 EF               [12] 2673 	mov	a,r7
      009488 9E               [12] 2674 	subb	a,r6
      009489 40 02            [24] 2675 	jc	00430$
      00948B C1 90            [12] 2676 	ajmp	00169$
      00948D                       2677 00430$:
      00948D 90 09 F2         [24] 2678 	mov	dptr,#_ak820_macro_cancelled
      009490 E0               [24] 2679 	movx	a,@dptr
      009491 60 02            [24] 2680 	jz	00431$
      009493 C1 90            [12] 2681 	ajmp	00169$
      009495                       2682 00431$:
                                   2683 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009495 8C 02            [24] 2684 	mov	ar2,r4
      009497 8F 03            [24] 2685 	mov	ar3,r7
      009499 90 0B E0         [24] 2686 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      00949C 74 01            [12] 2687 	mov	a,#0x01
      00949E 2C               [12] 2688 	add	a, r4
      00949F F0               [24] 2689 	movx	@dptr,a
      0094A0 E4               [12] 2690 	clr	a
      0094A1 3F               [12] 2691 	addc	a, r7
      0094A2 A3               [24] 2692 	inc	dptr
      0094A3 F0               [24] 2693 	movx	@dptr,a
      0094A4 7F 00            [12] 2694 	mov	r7,#0x00
      0094A6 12 38 B0         [24] 2695 	lcall	_ak820_outline_0146
      0094A9 8F F0            [24] 2696 	mov	b, r7
      0094AB 12 47 36         [24] 2697 	lcall	_eeprom_read_byte
      0094AE AF 82            [24] 2698 	mov	r7, dpl
      0094B0 90 0B E2         [24] 2699 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      0094B3 EF               [12] 2700 	mov	a,r7
      0094B4 F0               [24] 2701 	movx	@dptr,a
                                   2702 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      0094B5 90 0B E3         [24] 2703 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      0094B8 E4               [12] 2704 	clr	a
      0094B9 F0               [24] 2705 	movx	@dptr,a
                                   2706 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      0094BA 90 0B E2         [24] 2707 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      0094BD E0               [24] 2708 	movx	a,@dptr
      0094BE 70 02            [24] 2709 	jnz	00432$
      0094C0 C1 90            [12] 2710 	ajmp	00169$
      0094C2                       2711 00432$:
                                   2712 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      0094C2 90 0B E2         [24] 2713 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      0094C5 E0               [24] 2714 	movx	a,@dptr
      0094C6 FF               [12] 2715 	mov	r7,a
      0094C7 BF 01 02         [24] 2716 	cjne	r7,#0x01,00433$
      0094CA 80 02            [24] 2717 	sjmp	00434$
      0094CC                       2718 00433$:
      0094CC C1 73            [12] 2719 	ajmp	00164$
      0094CE                       2720 00434$:
                                   2721 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0094CE 12 96 98         [24] 2722 	lcall	_ak820_outline_0000
      0094D1 12 47 36         [24] 2723 	lcall	_eeprom_read_byte
      0094D4 AF 82            [24] 2724 	mov	r7, dpl
      0094D6 90 0B E3         [24] 2725 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      0094D9 EF               [12] 2726 	mov	a,r7
      0094DA F0               [24] 2727 	movx	@dptr,a
                                   2728 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      0094DB EF               [12] 2729 	mov	a,r7
      0094DC 70 02            [24] 2730 	jnz	00435$
      0094DE C1 90            [12] 2731 	ajmp	00169$
      0094E0                       2732 00435$:
                                   2733 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      0094E0 12 96 D7         [24] 2734 	lcall	_ak820_outline_0100
      0094E3 BF 01 02         [24] 2735 	cjne	r7,#0x01,00436$
      0094E6 80 12            [24] 2736 	sjmp	00151$
      0094E8                       2737 00436$:
      0094E8 12 96 D7         [24] 2738 	lcall	_ak820_outline_0100
      0094EB BF 02 02         [24] 2739 	cjne	r7,#0x02,00437$
      0094EE 80 0A            [24] 2740 	sjmp	00151$
      0094F0                       2741 00437$:
      0094F0 12 96 D7         [24] 2742 	lcall	_ak820_outline_0100
      0094F3 BF 03 02         [24] 2743 	cjne	r7,#0x03,00438$
      0094F6 80 02            [24] 2744 	sjmp	00439$
      0094F8                       2745 00438$:
      0094F8 A1 59            [12] 2746 	ajmp	00152$
      0094FA                       2747 00439$:
      0094FA                       2748 00151$:
                                   2749 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0094FA 12 96 98         [24] 2750 	lcall	_ak820_outline_0000
      0094FD 12 47 36         [24] 2751 	lcall	_eeprom_read_byte
      009500 12 97 28         [24] 2752 	lcall	_ak820_outline_0192
                                   2753 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      009503 70 02            [24] 2754 	jnz	00440$
      009505 81 7C            [12] 2755 	ajmp	00167$
      009507                       2756 00440$:
                                   2757 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      009507 12 96 D7         [24] 2758 	lcall	_ak820_outline_0100
      00950A BF 01 03         [24] 2759 	cjne	r7,#0x01,00441$
      00950D D3               [12] 2760 	setb	c
      00950E 80 01            [24] 2761 	sjmp	00442$
      009510                       2762 00441$:
      009510 C3               [12] 2763 	clr	c
      009511                       2764 00442$:
      009511 92 27            [24] 2765 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009513 90 09 F1         [24] 2766 	mov	dptr,#_ak820_macro_primitive
      009516 B3               [12] 2767 	cpl	c
      009517 E4               [12] 2768 	clr	a
      009518 33               [12] 2769 	rlc	a
      009519 F0               [24] 2770 	movx	@dptr,a
                                   2771 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      00951A 12 96 D7         [24] 2772 	lcall	_ak820_outline_0100
      00951D BF 01 10         [24] 2773 	cjne	r7,#0x01,00122$
      009520 12 97 09         [24] 2774 	lcall	_ak820_outline_0162
      009523 C0 06            [24] 2775 	push	ar6
      009525 C0 05            [24] 2776 	push	ar5
      009527 12 7C 66         [24] 2777 	lcall	_tap_code
      00952A D0 05            [24] 2778 	pop	ar5
      00952C D0 06            [24] 2779 	pop	ar6
      00952E 80 24            [24] 2780 	sjmp	00123$
      009530                       2781 00122$:
                                   2782 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      009530 12 96 D7         [24] 2783 	lcall	_ak820_outline_0100
      009533 BF 02 10         [24] 2784 	cjne	r7,#0x02,00119$
      009536 12 97 09         [24] 2785 	lcall	_ak820_outline_0162
      009539 C0 06            [24] 2786 	push	ar6
      00953B C0 05            [24] 2787 	push	ar5
      00953D 12 7B 68         [24] 2788 	lcall	_register_code
      009540 D0 05            [24] 2789 	pop	ar5
      009542 D0 06            [24] 2790 	pop	ar6
      009544 80 0E            [24] 2791 	sjmp	00123$
      009546                       2792 00119$:
                                   2793 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      009546 12 97 09         [24] 2794 	lcall	_ak820_outline_0162
      009549 C0 06            [24] 2795 	push	ar6
      00954B C0 05            [24] 2796 	push	ar5
      00954D 12 7B D2         [24] 2797 	lcall	_unregister_code
      009550 D0 05            [24] 2798 	pop	ar5
      009552 D0 06            [24] 2799 	pop	ar6
      009554                       2800 00123$:
                                   2801 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      009554 12 97 10         [24] 2802 	lcall	_ak820_outline_0177
      009557 81 7C            [12] 2803 	ajmp	00167$
      009559                       2804 00152$:
                                   2805 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      009559 12 96 D7         [24] 2806 	lcall	_ak820_outline_0100
      00955C BF 05 02         [24] 2807 	cjne	r7,#0x05,00447$
      00955F 80 12            [24] 2808 	sjmp	00146$
      009561                       2809 00447$:
      009561 12 96 D7         [24] 2810 	lcall	_ak820_outline_0100
      009564 BF 06 02         [24] 2811 	cjne	r7,#0x06,00448$
      009567 80 0A            [24] 2812 	sjmp	00146$
      009569                       2813 00448$:
      009569 12 96 D7         [24] 2814 	lcall	_ak820_outline_0100
      00956C BF 07 02         [24] 2815 	cjne	r7,#0x07,00449$
      00956F 80 02            [24] 2816 	sjmp	00450$
      009571                       2817 00449$:
      009571 C1 15            [12] 2818 	ajmp	00147$
      009573                       2819 00450$:
      009573                       2820 00146$:
                                   2821 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009573 12 96 98         [24] 2822 	lcall	_ak820_outline_0000
      009576 12 47 36         [24] 2823 	lcall	_eeprom_read_byte
      009579 12 97 28         [24] 2824 	lcall	_ak820_outline_0192
                                   2825 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      00957C 70 02            [24] 2826 	jnz	00451$
      00957E 81 7C            [12] 2827 	ajmp	00167$
      009580                       2828 00451$:
                                   2829 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009580 12 96 98         [24] 2830 	lcall	_ak820_outline_0000
      009583 12 47 36         [24] 2831 	lcall	_eeprom_read_byte
      009586 AF 82            [24] 2832 	mov	r7, dpl
      009588 90 0B E5         [24] 2833 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0003)
      00958B EF               [12] 2834 	mov	a,r7
      00958C F0               [24] 2835 	movx	@dptr,a
                                   2836 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      00958D EF               [12] 2837 	mov	a,r7
      00958E 70 02            [24] 2838 	jnz	00452$
      009590 81 7C            [12] 2839 	ajmp	00167$
      009592                       2840 00452$:
                                   2841 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009592 90 0B E4         [24] 2842 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0002)
      009595 E0               [24] 2843 	movx	a,@dptr
      009596 FF               [12] 2844 	mov	r7,a
      009597 90 0B E5         [24] 2845 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0003)
      00959A E0               [24] 2846 	movx	a,@dptr
      00959B FB               [12] 2847 	mov	r3,a
      00959C E4               [12] 2848 	clr	a
      00959D FC               [12] 2849 	mov	r4,a
      00959E FA               [12] 2850 	mov	r2,a
      00959F EF               [12] 2851 	mov	a,r7
      0095A0 42 04            [12] 2852 	orl	ar4,a
      0095A2 EA               [12] 2853 	mov	a,r2
      0095A3 42 03            [12] 2854 	orl	ar3,a
                                   2855 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      0095A5 12 4A 4A         [24] 2856 	lcall	_ak820_outline_0193
      0095A8 C0 06            [24] 2857 	push	ar6
      0095AA C0 05            [24] 2858 	push	ar5
      0095AC 71 C8            [12] 2859 	acall	_decode_keycode
      0095AE AC 82            [24] 2860 	mov	r4, dpl
      0095B0 AF 83            [24] 2861 	mov	r7, dph
      0095B2 D0 05            [24] 2862 	pop	ar5
      0095B4 D0 06            [24] 2863 	pop	ar6
                                   2864 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      0095B6 90 0B E3         [24] 2865 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      0095B9 E0               [24] 2866 	movx	a,@dptr
      0095BA FB               [12] 2867 	mov	r3,a
      0095BB BB 05 03         [24] 2868 	cjne	r3,#0x05,00453$
      0095BE D3               [12] 2869 	setb	c
      0095BF 80 01            [24] 2870 	sjmp	00454$
      0095C1                       2871 00453$:
      0095C1 C3               [12] 2872 	clr	c
      0095C2                       2873 00454$:
      0095C2 92 27            [24] 2874 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0095C4 90 09 F1         [24] 2875 	mov	dptr,#_ak820_macro_primitive
      0095C7 B3               [12] 2876 	cpl	c
      0095C8 E4               [12] 2877 	clr	a
      0095C9 33               [12] 2878 	rlc	a
      0095CA F0               [24] 2879 	movx	@dptr,a
                                   2880 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      0095CB 90 0B E3         [24] 2881 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489 + 0x0001)
      0095CE E0               [24] 2882 	movx	a,@dptr
      0095CF FB               [12] 2883 	mov	r3,a
      0095D0 BB 05 02         [24] 2884 	cjne	r3,#0x05,00455$
      0095D3 80 0A            [24] 2885 	sjmp	00126$
      0095D5                       2886 00455$:
      0095D5 BB 06 02         [24] 2887 	cjne	r3,#0x06,00456$
      0095D8 80 16            [24] 2888 	sjmp	00127$
      0095DA                       2889 00456$:
                                   2890 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      0095DA BB 07 33         [24] 2891 	cjne	r3,#0x07,00129$
      0095DD 80 22            [24] 2892 	sjmp	00128$
      0095DF                       2893 00126$:
                                   2894 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      0095DF 8C 82            [24] 2895 	mov	dpl, r4
      0095E1 8F 83            [24] 2896 	mov	dph, r7
      0095E3 C0 06            [24] 2897 	push	ar6
      0095E5 C0 05            [24] 2898 	push	ar5
      0095E7 12 BB 6D         [24] 2899 	lcall	_vial_keycode_tap
      0095EA D0 05            [24] 2900 	pop	ar5
      0095EC D0 06            [24] 2901 	pop	ar6
                                   2902 ;	quantum/dynamic_keymap.c:795: break;
                                   2903 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      0095EE 80 20            [24] 2904 	sjmp	00129$
      0095F0                       2905 00127$:
                                   2906 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      0095F0 8C 82            [24] 2907 	mov	dpl, r4
      0095F2 8F 83            [24] 2908 	mov	dph, r7
      0095F4 C0 06            [24] 2909 	push	ar6
      0095F6 C0 05            [24] 2910 	push	ar5
      0095F8 12 BA A2         [24] 2911 	lcall	_vial_keycode_down
      0095FB D0 05            [24] 2912 	pop	ar5
      0095FD D0 06            [24] 2913 	pop	ar6
                                   2914 ;	quantum/dynamic_keymap.c:798: break;
                                   2915 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      0095FF 80 0F            [24] 2916 	sjmp	00129$
      009601                       2917 00128$:
                                   2918 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      009601 8C 82            [24] 2919 	mov	dpl, r4
      009603 8F 83            [24] 2920 	mov	dph, r7
      009605 C0 06            [24] 2921 	push	ar6
      009607 C0 05            [24] 2922 	push	ar5
      009609 12 BB 08         [24] 2923 	lcall	_vial_keycode_up
      00960C D0 05            [24] 2924 	pop	ar5
      00960E D0 06            [24] 2925 	pop	ar6
                                   2926 ;	quantum/dynamic_keymap.c:802: }
      009610                       2927 00129$:
                                   2928 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      009610 12 97 10         [24] 2929 	lcall	_ak820_outline_0177
      009613 81 7C            [12] 2930 	ajmp	00167$
      009615                       2931 00147$:
                                   2932 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      009615 12 96 D7         [24] 2933 	lcall	_ak820_outline_0100
      009618 BF 04 02         [24] 2934 	cjne	r7,#0x04,00458$
      00961B 80 02            [24] 2935 	sjmp	00459$
      00961D                       2936 00458$:
      00961D 81 7C            [12] 2937 	ajmp	00167$
      00961F                       2938 00459$:
                                   2939 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00961F 12 96 98         [24] 2940 	lcall	_ak820_outline_0000
      009622 12 47 36         [24] 2941 	lcall	_eeprom_read_byte
      009625 AF 82            [24] 2942 	mov	r7, dpl
                                   2943 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009627 90 0B E0         [24] 2944 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      00962A 12 38 9B         [24] 2945 	lcall	_ak820_outline_0133
      00962D 90 0B E0         [24] 2946 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      009630 74 01            [12] 2947 	mov	a,#0x01
      009632 2B               [12] 2948 	add	a, r3
      009633 F0               [24] 2949 	movx	@dptr,a
      009634 E4               [12] 2950 	clr	a
      009635 3C               [12] 2951 	addc	a, r4
      009636 A3               [24] 2952 	inc	dptr
      009637 F0               [24] 2953 	movx	@dptr,a
      009638 7A 00            [12] 2954 	mov	r2,#0x00
      00963A 12 33 FC         [24] 2955 	lcall	_ak820_outline_0129
      00963D 8A F0            [24] 2956 	mov	b, r2
      00963F 12 47 36         [24] 2957 	lcall	_eeprom_read_byte
      009642 AC 82            [24] 2958 	mov	r4, dpl
                                   2959 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      009644 EF               [12] 2960 	mov	a,r7
      009645 60 49            [24] 2961 	jz	00169$
      009647 EC               [12] 2962 	mov	a,r4
      009648 60 46            [24] 2963 	jz	00169$
                                   2964 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      00964A 1F               [12] 2965 	dec	r7
      00964B 1C               [12] 2966 	dec	r4
      00964C EC               [12] 2967 	mov	a,r4
      00964D 75 F0 FF         [24] 2968 	mov	b,#0xff
      009650 A4               [48] 2969 	mul	ab
      009651 FC               [12] 2970 	mov	r4,a
      009652 AB F0            [24] 2971 	mov	r3,b
      009654 7A 00            [12] 2972 	mov	r2,#0x00
      009656 EC               [12] 2973 	mov	a,r4
      009657 2F               [12] 2974 	add	a, r7
      009658 FC               [12] 2975 	mov	r4,a
      009659 EB               [12] 2976 	mov	a,r3
      00965A 3A               [12] 2977 	addc	a, r2
      00965B FB               [12] 2978 	mov	r3,a
                                   2979 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      00965C                       2980 00141$:
      00965C 8C 02            [24] 2981 	mov	ar2,r4
      00965E 8B 07            [24] 2982 	mov	ar7,r3
      009660 1C               [12] 2983 	dec	r4
      009661 BC FF 01         [24] 2984 	cjne	r4,#0xff,00462$
      009664 1B               [12] 2985 	dec	r3
      009665                       2986 00462$:
      009665 EA               [12] 2987 	mov	a,r2
      009666 4F               [12] 2988 	orl	a,r7
      009667 70 02            [24] 2989 	jnz	00463$
      009669 81 7C            [12] 2990 	ajmp	00167$
      00966B                       2991 00463$:
      00966B 90 00 01         [24] 2992 	mov	dptr,#0x0001
      00966E 12 5F 5C         [24] 2993 	lcall	_mDelaymS
      009671 80 E9            [24] 2994 	sjmp	00141$
      009673                       2995 00164$:
                                   2996 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      009673 90 0B E2         [24] 2997 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009676 E0               [24] 2998 	movx	a,@dptr
      009677 FF               [12] 2999 	mov	r7,a
      009678 BF 80 00         [24] 3000 	cjne	r7,#0x80,00464$
      00967B                       3001 00464$:
      00967B 50 13            [24] 3002 	jnc	00169$
                                   3003 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      00967D 90 0B E2         [24] 3004 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_489
      009680 E0               [24] 3005 	movx	a,@dptr
      009681 F5 82            [12] 3006 	mov	dpl,a
      009683 C0 06            [24] 3007 	push	ar6
      009685 C0 05            [24] 3008 	push	ar5
      009687 12 AD 76         [24] 3009 	lcall	_send_char
      00968A D0 05            [24] 3010 	pop	ar5
      00968C D0 06            [24] 3011 	pop	ar6
                                   3012 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      00968E 81 7C            [12] 3013 	ajmp	00167$
      009690                       3014 00169$:
                                   3015 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      009690 12 97 10         [24] 3016 	lcall	_ak820_outline_0177
                                   3017 ;	quantum/dynamic_keymap.c:837: sending = false;
      009693 90 0B DF         [24] 3018 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_477
      009696 F0               [24] 3019 	movx	@dptr,a
                                   3020 ;	quantum/dynamic_keymap.c:839: }
      009697 22               [24] 3021 	ret
                                   3022 	.area CSEG    (CODE)
                                   3023 	.area CONST   (CODE)
                                   3024 	.area XINIT   (CODE)
                                   3025 	.area CABS    (ABS,CODE)
                                   3026 
                                   3027 ; Experimental exact instruction outlining.
                                   3028 	.globl _ak820_outline_0000
                                   3029 	.globl _ak820_outline_0006
                                   3030 	.globl _ak820_outline_0010
                                   3031 	.globl _ak820_outline_0014
                                   3032 	.globl _ak820_outline_0016
                                   3033 	.globl _ak820_outline_0035
                                   3034 	.globl _ak820_outline_0036
                                   3035 	.globl _ak820_outline_0038
                                   3036 	.globl _ak820_outline_0045
                                   3037 	.globl _ak820_outline_0057
                                   3038 	.globl _ak820_outline_0063
                                   3039 	.globl _ak820_outline_0064
                                   3040 	.globl _ak820_outline_0065
                                   3041 	.globl _ak820_outline_0070
                                   3042 	.globl _ak820_outline_0077
                                   3043 	.globl _ak820_outline_0079
                                   3044 	.globl _ak820_outline_0081
                                   3045 	.globl _ak820_outline_0086
                                   3046 	.globl _ak820_outline_0090
                                   3047 	.globl _ak820_outline_0098
                                   3048 	.globl _ak820_outline_0100
                                   3049 	.globl _ak820_outline_0104
                                   3050 	.globl _ak820_outline_0109
                                   3051 	.globl _ak820_outline_0110
                                   3052 	.globl _ak820_outline_0114
                                   3053 	.globl _ak820_outline_0115
                                   3054 	.globl _ak820_outline_0118
                                   3055 	.globl _ak820_outline_0120
                                   3056 	.globl _ak820_outline_0124
                                   3057 	.globl _ak820_outline_0126
                                   3058 	.globl _ak820_outline_0129
                                   3059 	.globl _ak820_outline_0132
                                   3060 	.globl _ak820_outline_0133
                                   3061 	.globl _ak820_outline_0134
                                   3062 	.globl _ak820_outline_0135
                                   3063 	.globl _ak820_outline_0139
                                   3064 	.globl _ak820_outline_0144
                                   3065 	.globl _ak820_outline_0145
                                   3066 	.globl _ak820_outline_0146
                                   3067 	.globl _ak820_outline_0147
                                   3068 	.globl _ak820_outline_0148
                                   3069 	.globl _ak820_outline_0149
                                   3070 	.globl _ak820_outline_0153
                                   3071 	.globl _ak820_outline_0160
                                   3072 	.globl _ak820_outline_0162
                                   3073 	.globl _ak820_outline_0166
                                   3074 	.globl _ak820_outline_0167
                                   3075 	.globl _ak820_outline_0168
                                   3076 	.globl _ak820_outline_0171
                                   3077 	.globl _ak820_outline_0177
                                   3078 	.globl _ak820_outline_0188
                                   3079 	.globl _ak820_outline_0189
                                   3080 	.globl _ak820_outline_0192
                                   3081 	.globl _ak820_outline_0193
                                   3082 	.globl _ak820_outline_0197
                                   3083 	.globl _ak820_outline_0199
                                   3084 
                                   3085 	.area CSEG (CODE)
                                   3086 ; function ak820_outline_0000
      009698                       3087 _ak820_outline_0000:
      009698 90 0B E0         [24] 3088 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      00969B E0               [24] 3089 	movx	a,@dptr
      00969C FC               [12] 3090 	mov	r4,a
      00969D A3               [24] 3091 	inc	dptr
      00969E E0               [24] 3092 	movx	a,@dptr
      00969F FF               [12] 3093 	mov	r7,a
      0096A0 90 0B E0         [24] 3094 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_482
      0096A3 74 01            [12] 3095 	mov	a,#0x01
      0096A5 2C               [12] 3096 	add	a,r4
      0096A6 F0               [24] 3097 	movx	@dptr,a
      0096A7 E4               [12] 3098 	clr	a
      0096A8 3F               [12] 3099 	addc	a,r7
      0096A9 A3               [24] 3100 	inc	dptr
      0096AA F0               [24] 3101 	movx	@dptr,a
      0096AB 7B 00            [12] 3102 	mov	r3,#0x00
      0096AD 8C 82            [24] 3103 	mov	dpl,r4
      0096AF 8F 83            [24] 3104 	mov	dph,r7
      0096B1 8B F0            [24] 3105 	mov	b,r3
      0096B3 22               [24] 3106 	ret
                                   3107 
                                   3108 	.area CSEG (CODE)
                                   3109 ; function ak820_outline_0045
      0096B4                       3110 _ak820_outline_0045:
      0096B4 90 0E 5F         [24] 3111 	mov	dptr,#_memset_PARM_2
      0096B7 E4               [12] 3112 	clr	a
      0096B8 F0               [24] 3113 	movx	@dptr,a
      0096B9 90 0E 60         [24] 3114 	mov	dptr,#_memset_PARM_3
      0096BC 74 0A            [12] 3115 	mov	a,#0x0a
      0096BE F0               [24] 3116 	movx	@dptr,a
      0096BF E4               [12] 3117 	clr	a
      0096C0 A3               [24] 3118 	inc	dptr
      0096C1 F0               [24] 3119 	movx	@dptr,a
      0096C2 8E 82            [24] 3120 	mov	dpl,r6
      0096C4 8F 83            [24] 3121 	mov	dph,r7
      0096C6 8D F0            [24] 3122 	mov	b,r5
      0096C8 22               [24] 3123 	ret
                                   3124 
                                   3125 	.area CSEG (CODE)
                                   3126 ; function ak820_outline_0086
      0096C9                       3127 _ak820_outline_0086:
      0096C9 ED               [12] 3128 	mov	a,r5
      0096CA 75 F0 0A         [24] 3129 	mov	b,#0x0a
      0096CD A4               [48] 3130 	mul	ab
      0096CE 24 58            [12] 3131 	add	a,#0x58
      0096D0 FC               [12] 3132 	mov	r4,a
      0096D1 74 06            [12] 3133 	mov	a,#0x06
      0096D3 35 F0            [12] 3134 	addc	a,b
      0096D5 FD               [12] 3135 	mov	r5,a
      0096D6 22               [24] 3136 	ret
                                   3137 
                                   3138 	.area CSEG (CODE)
                                   3139 ; function ak820_outline_0100
      0096D7                       3140 _ak820_outline_0100:
      0096D7 90 0B E3         [24] 3141 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489+0x0001)
      0096DA E0               [24] 3142 	movx	a,@dptr
      0096DB FF               [12] 3143 	mov	r7,a
      0096DC 22               [24] 3144 	ret
                                   3145 
                                   3146 	.area CSEG (CODE)
                                   3147 ; function ak820_outline_0104
      0096DD                       3148 _ak820_outline_0104:
      0096DD 90 0B 67         [24] 3149 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0096E0 EE               [12] 3150 	mov	a,r6
      0096E1 F0               [24] 3151 	movx	@dptr,a
      0096E2 90 0B 68         [24] 3152 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0096E5 ED               [12] 3153 	mov	a,r5
      0096E6 F0               [24] 3154 	movx	@dptr,a
      0096E7 8F 82            [24] 3155 	mov	dpl,r7
      0096E9 22               [24] 3156 	ret
                                   3157 
                                   3158 	.area CSEG (CODE)
                                   3159 ; function ak820_outline_0118
      0096EA                       3160 _ak820_outline_0118:
      0096EA 74 0A            [12] 3161 	mov	a,#0x0a
      0096EC F0               [24] 3162 	movx	@dptr,a
      0096ED E4               [12] 3163 	clr	a
      0096EE A3               [24] 3164 	inc	dptr
      0096EF F0               [24] 3165 	movx	@dptr,a
      0096F0 22               [24] 3166 	ret
                                   3167 
                                   3168 	.area CSEG (CODE)
                                   3169 ; function ak820_outline_0124
      0096F1                       3170 _ak820_outline_0124:
      0096F1 AD 82            [24] 3171 	mov	r5,dpl
      0096F3 AE 83            [24] 3172 	mov	r6,dph
      0096F5 AF F0            [24] 3173 	mov	r7,b
      0096F7 22               [24] 3174 	ret
                                   3175 
                                   3176 	.area CSEG (CODE)
                                   3177 ; function ak820_outline_0139
      0096F8                       3178 _ak820_outline_0139:
      0096F8 28               [12] 3179 	add	a,r0
      0096F9 F5 82            [12] 3180 	mov	dpl,a
      0096FB EF               [12] 3181 	mov	a,r7
      0096FC 39               [12] 3182 	addc	a,r1
      0096FD F5 83            [12] 3183 	mov	dph,a
      0096FF 74 FF            [12] 3184 	mov	a,#0xff
      009701 F0               [24] 3185 	movx	@dptr,a
      009702 22               [24] 3186 	ret
                                   3187 
                                   3188 	.area CSEG (CODE)
                                   3189 ; function ak820_outline_0147
      009703                       3190 _ak820_outline_0147:
      009703 2D               [12] 3191 	add	a,r5
      009704 F9               [12] 3192 	mov	r1,a
      009705 E4               [12] 3193 	clr	a
      009706 3E               [12] 3194 	addc	a,r6
      009707 FA               [12] 3195 	mov	r2,a
      009708 22               [24] 3196 	ret
                                   3197 
                                   3198 	.area CSEG (CODE)
                                   3199 ; function ak820_outline_0162
      009709                       3200 _ak820_outline_0162:
      009709 90 0B E4         [24] 3201 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489+0x0002)
      00970C E0               [24] 3202 	movx	a,@dptr
      00970D F5 82            [12] 3203 	mov	dpl,a
      00970F 22               [24] 3204 	ret
                                   3205 
                                   3206 	.area CSEG (CODE)
                                   3207 ; function ak820_outline_0177
      009710                       3208 _ak820_outline_0177:
      009710 90 09 F1         [24] 3209 	mov	dptr,#_ak820_macro_primitive
      009713 E4               [12] 3210 	clr	a
      009714 F0               [24] 3211 	movx	@dptr,a
      009715 22               [24] 3212 	ret
                                   3213 
                                   3214 	.area CSEG (CODE)
                                   3215 ; function ak820_outline_0188
      009716                       3216 _ak820_outline_0188:
      009716 90 0B 77         [24] 3217 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009719 E4               [12] 3218 	clr	a
      00971A F0               [24] 3219 	movx	@dptr,a
      00971B 90 0B 78         [24] 3220 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00971E 22               [24] 3221 	ret
                                   3222 
                                   3223 	.area CSEG (CODE)
                                   3224 ; function ak820_outline_0189
      00971F                       3225 _ak820_outline_0189:
      00971F 90 0C 3F         [24] 3226 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      009722 E4               [12] 3227 	clr	a
      009723 F0               [24] 3228 	movx	@dptr,a
      009724 90 0C 40         [24] 3229 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      009727 22               [24] 3230 	ret
                                   3231 
                                   3232 	.area CSEG (CODE)
                                   3233 ; function ak820_outline_0192
      009728                       3234 _ak820_outline_0192:
      009728 AF 82            [24] 3235 	mov	r7,dpl
      00972A 90 0B E4         [24] 3236 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_489+0x0002)
      00972D EF               [12] 3237 	mov	a,r7
      00972E F0               [24] 3238 	movx	@dptr,a
      00972F EF               [12] 3239 	mov	a,r7
      009730 22               [24] 3240 	ret
