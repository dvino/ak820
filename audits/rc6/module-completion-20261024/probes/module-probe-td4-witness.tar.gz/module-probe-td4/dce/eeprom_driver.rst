                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000748                         85 _eeprom_read_word_addr_10000_91:
      000748                         86 	.ds 3
      00074B                         87 _eeprom_read_word_ret_10000_92:
      00074B                         88 	.ds 2
      00074D                         89 _eeprom_read_dword_addr_10000_93:
      00074D                         90 	.ds 3
      000750                         91 _eeprom_read_dword_ret_10000_94:
      000750                         92 	.ds 4
      000754                         93 _eeprom_write_byte_PARM_2:
      000754                         94 	.ds 1
      000755                         95 _eeprom_write_byte_addr_10000_95:
      000755                         96 	.ds 3
      000758                         97 _eeprom_write_word_PARM_2:
      000758                         98 	.ds 2
      00075A                         99 _eeprom_write_word_addr_10000_97:
      00075A                        100 	.ds 3
      00075D                        101 _eeprom_write_dword_PARM_2:
      00075D                        102 	.ds 4
      000761                        103 _eeprom_write_dword_addr_10000_99:
      000761                        104 	.ds 3
      000764                        105 _eeprom_update_byte_PARM_2:
      000764                        106 	.ds 1
      000765                        107 _eeprom_update_byte_addr_10000_107:
      000765                        108 	.ds 3
      000768                        109 _eeprom_update_word_PARM_2:
      000768                        110 	.ds 2
      00076A                        111 _eeprom_update_word_addr_10000_111:
      00076A                        112 	.ds 3
      00076D                        113 _eeprom_update_dword_PARM_2:
      00076D                        114 	.ds 4
      000771                        115 _eeprom_update_dword_addr_10000_115:
      000771                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      00528E                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      00528E 12 43 11         [24]  170 	lcall	_ak820_outline_0042
      005291 90 07 48         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005294 12 38 0D         [24]  172 	lcall	_ak820_outline_0019
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      005297 90 07 4B         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00529A 12 49 26         [24]  175 	lcall	_ak820_outline_0146
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      00529D 90 07 48         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0052A0 12 54 4B         [24]  178 	lcall	_ak820_outline_0015
      0052A3 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0052A6 ED               [12]  180 	mov	a,r5
      0052A7 12 38 0D         [24]  181 	lcall	_ak820_outline_0019
      0052AA 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0052AD 12 54 86         [24]  183 	lcall	_ak820_outline_0111
      0052B0 90 07 4B         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0052B3 12 40 AD         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      0052B6 90 07 4B         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0052B9 12 54 7D         [24]  188 	lcall	_ak820_outline_0095
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      0052BC 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      0052BD                        201 _eeprom_read_dword:
      0052BD 12 43 11         [24]  202 	lcall	_ak820_outline_0042
      0052C0 90 07 4D         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0052C3 12 38 0D         [24]  204 	lcall	_ak820_outline_0019
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      0052C6 90 07 50         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0052C9 12 54 5B         [24]  207 	lcall	_ak820_outline_0057
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      0052CC 90 07 4D         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0052CF 12 54 4B         [24]  210 	lcall	_ak820_outline_0015
      0052D2 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0052D5 ED               [12]  212 	mov	a,r5
      0052D6 12 38 0D         [24]  213 	lcall	_ak820_outline_0019
      0052D9 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0052DC 74 04            [12]  215 	mov	a,#0x04
      0052DE 12 38 9D         [24]  216 	lcall	_ak820_outline_0130
      0052E1 90 07 50         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0052E4 12 40 AD         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      0052E7 90 07 50         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0052EA 12 54 64         [24]  221 	lcall	_ak820_outline_0062
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      0052ED 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      0052EE                        234 _eeprom_write_byte:
      0052EE 12 43 11         [24]  235 	lcall	_ak820_outline_0042
      0052F1 90 07 55         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0052F4 12 38 0D         [24]  237 	lcall	_ak820_outline_0019
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      0052F7 90 07 55         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0052FA 12 54 34         [24]  240 	lcall	_ak820_outline_0004
      0052FD 74 01            [12]  241 	mov	a,#0x01
      0052FF 12 38 9D         [24]  242 	lcall	_ak820_outline_0130
      005302 90 07 54         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005305 02 41 39         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005308                        256 _eeprom_write_word:
      005308 12 43 11         [24]  257 	lcall	_ak820_outline_0042
      00530B 90 07 5A         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00530E 12 38 0D         [24]  259 	lcall	_ak820_outline_0019
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      005311 90 07 5A         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005314 12 54 34         [24]  262 	lcall	_ak820_outline_0004
      005317 12 54 86         [24]  263 	lcall	_ak820_outline_0111
      00531A 90 07 58         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      00531D 02 41 39         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      005320                        277 _eeprom_write_dword:
      005320 12 43 11         [24]  278 	lcall	_ak820_outline_0042
      005323 90 07 61         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005326 12 38 0D         [24]  280 	lcall	_ak820_outline_0019
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005329 90 07 61         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00532C 12 54 34         [24]  283 	lcall	_ak820_outline_0004
      00532F 74 04            [12]  284 	mov	a,#0x04
      005331 12 38 9D         [24]  285 	lcall	_ak820_outline_0130
      005334 90 07 5D         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005337 02 41 39         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      00533A                        307 _eeprom_update_byte:
      00533A C0 07            [24]  308 	push	ar7
      00533C C0 06            [24]  309 	push	ar6
      00533E C0 05            [24]  310 	push	ar5
      005340 C0 04            [24]  311 	push	ar4
      005342 12 43 11         [24]  312 	lcall	_ak820_outline_0042
      005345 90 07 65         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005348 12 38 0D         [24]  314 	lcall	_ak820_outline_0019
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      00534B 90 07 65         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00534E 12 54 25         [24]  317 	lcall	_ak820_outline_0002
      005351 12 40 72         [24]  318 	lcall	_eeprom_read_byte
      005354 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005356 90 07 64         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005359 E0               [24]  322 	movx	a,@dptr
      00535A FE               [12]  323 	mov	r6,a
      00535B EF               [12]  324 	mov	a,r7
      00535C B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00535F 80 36            [24]  326 	sjmp	00103$
      005361                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      005361 90 07 65         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005364 12 38 45         [24]  330 	lcall	_ak820_outline_0065
      005367 A3               [24]  331 	inc	dptr
      005368 E0               [24]  332 	movx	a,@dptr
      005369 FF               [12]  333 	mov	r7,a
      00536A 90 07 54         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      00536D EE               [12]  335 	mov	a,r6
      00536E F0               [24]  336 	movx	@dptr,a
      00536F 12 38 98         [24]  337 	lcall	_ak820_outline_0129
      005372 8F F0            [24]  338 	mov	b, r7
      005374 C0 07            [24]  339 	push	ar7
      005376 C0 06            [24]  340 	push	ar6
      005378 C0 05            [24]  341 	push	ar5
      00537A C0 04            [24]  342 	push	ar4
      00537C C0 03            [24]  343 	push	ar3
      00537E C0 02            [24]  344 	push	ar2
      005380 C0 01            [24]  345 	push	ar1
      005382 C0 00            [24]  346 	push	ar0
      005384 12 52 EE         [24]  347 	lcall	_eeprom_write_byte
      005387 D0 00            [24]  348 	pop	ar0
      005389 D0 01            [24]  349 	pop	ar1
      00538B D0 02            [24]  350 	pop	ar2
      00538D D0 03            [24]  351 	pop	ar3
      00538F D0 04            [24]  352 	pop	ar4
      005391 D0 05            [24]  353 	pop	ar5
      005393 D0 06            [24]  354 	pop	ar6
      005395 D0 07            [24]  355 	pop	ar7
      005397                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      005397 D0 04            [24]  358 	pop	ar4
      005399 D0 05            [24]  359 	pop	ar5
      00539B D0 06            [24]  360 	pop	ar6
      00539D D0 07            [24]  361 	pop	ar7
      00539F 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      0053A0                        374 _eeprom_update_word:
      0053A0 12 43 11         [24]  375 	lcall	_ak820_outline_0042
      0053A3 90 07 6A         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0053A6 12 38 0D         [24]  377 	lcall	_ak820_outline_0019
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0053A9 90 07 6A         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0053AC 12 54 25         [24]  380 	lcall	_ak820_outline_0002
      0053AF 12 52 8E         [24]  381 	lcall	_eeprom_read_word
      0053B2 12 43 67         [24]  382 	lcall	_ak820_outline_0139
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0053B5 90 07 68         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      0053B8 12 38 45         [24]  385 	lcall	_ak820_outline_0065
      0053BB EE               [12]  386 	mov	a,r6
      0053BC B5 04 05         [24]  387 	cjne	a,ar4,00112$
      0053BF EF               [12]  388 	mov	a,r7
      0053C0 B5 05 01         [24]  389 	cjne	a,ar5,00112$
      0053C3 22               [24]  390 	ret
      0053C4                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      0053C4 90 07 6A         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0053C7 E0               [24]  394 	movx	a,@dptr
      0053C8 FB               [12]  395 	mov	r3,a
      0053C9 A3               [24]  396 	inc	dptr
      0053CA 12 38 2E         [24]  397 	lcall	_ak820_outline_0059
      0053CD 90 07 58         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      0053D0 12 38 51         [24]  399 	lcall	_ak820_outline_0079
      0053D3 8B 82            [24]  400 	mov	dpl, r3
      0053D5 8E 83            [24]  401 	mov	dph, r6
      0053D7 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      0053D9 02 53 08         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      0053DC                        416 _eeprom_update_dword:
      0053DC 12 43 11         [24]  417 	lcall	_ak820_outline_0042
      0053DF 90 07 71         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0053E2 12 38 0D         [24]  419 	lcall	_ak820_outline_0019
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      0053E5 90 07 71         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0053E8 12 54 25         [24]  422 	lcall	_ak820_outline_0002
      0053EB 12 52 BD         [24]  423 	lcall	_eeprom_read_dword
      0053EE 12 54 75         [24]  424 	lcall	_ak820_outline_0063
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0053F1 90 07 6D         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      0053F4 12 38 63         [24]  427 	lcall	_ak820_outline_0098
      0053F7 A3               [24]  428 	inc	dptr
      0053F8 12 43 4F         [24]  429 	lcall	_ak820_outline_0084
      0053FB EC               [12]  430 	mov	a,r4
      0053FC B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      0053FF ED               [12]  432 	mov	a,r5
      005400 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      005403 EE               [12]  434 	mov	a,r6
      005404 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      005407 EF               [12]  436 	mov	a,r7
      005408 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      00540B 22               [24]  438 	ret
      00540C                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      00540C 90 07 71         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00540F 12 54 4B         [24]  442 	lcall	_ak820_outline_0015
      005412 90 07 5D         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005415 E8               [12]  444 	mov	a,r0
      005416 F0               [24]  445 	movx	@dptr,a
      005417 E9               [12]  446 	mov	a,r1
      005418 A3               [24]  447 	inc	dptr
      005419 F0               [24]  448 	movx	@dptr,a
      00541A EA               [12]  449 	mov	a,r2
      00541B A3               [24]  450 	inc	dptr
      00541C 12 49 35         [24]  451 	lcall	_ak820_outline_0162
      00541F 12 54 54         [24]  452 	lcall	_ak820_outline_0052
                                    453 ;	drivers/eeprom/eeprom_driver.c:101: }
      005422 02 53 20         [24]  454 	ljmp	_eeprom_write_dword
                                    455 	.area CSEG    (CODE)
                                    456 	.area CONST   (CODE)
                                    457 	.area XINIT   (CODE)
                                    458 	.area CABS    (ABS,CODE)
                                    459 
                                    460 ; Experimental exact instruction outlining.
                                    461 	.globl _ak820_outline_0002
                                    462 	.globl _ak820_outline_0004
                                    463 	.globl _ak820_outline_0015
                                    464 	.globl _ak820_outline_0019
                                    465 	.globl _ak820_outline_0042
                                    466 	.globl _ak820_outline_0052
                                    467 	.globl _ak820_outline_0057
                                    468 	.globl _ak820_outline_0059
                                    469 	.globl _ak820_outline_0062
                                    470 	.globl _ak820_outline_0063
                                    471 	.globl _ak820_outline_0065
                                    472 	.globl _ak820_outline_0079
                                    473 	.globl _ak820_outline_0084
                                    474 	.globl _ak820_outline_0095
                                    475 	.globl _ak820_outline_0098
                                    476 	.globl _ak820_outline_0111
                                    477 	.globl _ak820_outline_0129
                                    478 	.globl _ak820_outline_0130
                                    479 	.globl _ak820_outline_0139
                                    480 	.globl _ak820_outline_0146
                                    481 	.globl _ak820_outline_0162
                                    482 
                                    483 	.area CSEG (CODE)
                                    484 ; function ak820_outline_0002
      005425                        485 _ak820_outline_0002:
      005425 E0               [24]  486 	movx	a,@dptr
      005426 FD               [12]  487 	mov	r5,a
      005427 A3               [24]  488 	inc	dptr
      005428 E0               [24]  489 	movx	a,@dptr
      005429 FE               [12]  490 	mov	r6,a
      00542A A3               [24]  491 	inc	dptr
      00542B E0               [24]  492 	movx	a,@dptr
      00542C FF               [12]  493 	mov	r7,a
      00542D 8D 82            [24]  494 	mov	dpl,r5
      00542F 8E 83            [24]  495 	mov	dph,r6
      005431 8F F0            [24]  496 	mov	b,r7
      005433 22               [24]  497 	ret
                                    498 
                                    499 	.area CSEG (CODE)
                                    500 ; function ak820_outline_0004
      005434                        501 _ak820_outline_0004:
      005434 E0               [24]  502 	movx	a,@dptr
      005435 FD               [12]  503 	mov	r5,a
      005436 A3               [24]  504 	inc	dptr
      005437 E0               [24]  505 	movx	a,@dptr
      005438 FE               [12]  506 	mov	r6,a
      005439 A3               [24]  507 	inc	dptr
      00543A E0               [24]  508 	movx	a,@dptr
      00543B FF               [12]  509 	mov	r7,a
      00543C 90 05 8E         [24]  510 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00543F ED               [12]  511 	mov	a,r5
      005440 F0               [24]  512 	movx	@dptr,a
      005441 EE               [12]  513 	mov	a,r6
      005442 A3               [24]  514 	inc	dptr
      005443 F0               [24]  515 	movx	@dptr,a
      005444 EF               [12]  516 	mov	a,r7
      005445 A3               [24]  517 	inc	dptr
      005446 F0               [24]  518 	movx	@dptr,a
      005447 90 05 91         [24]  519 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00544A 22               [24]  520 	ret
                                    521 
                                    522 	.area CSEG (CODE)
                                    523 ; function ak820_outline_0015
      00544B                        524 _ak820_outline_0015:
      00544B E0               [24]  525 	movx	a,@dptr
      00544C FD               [12]  526 	mov	r5,a
      00544D A3               [24]  527 	inc	dptr
      00544E E0               [24]  528 	movx	a,@dptr
      00544F FE               [12]  529 	mov	r6,a
      005450 A3               [24]  530 	inc	dptr
      005451 E0               [24]  531 	movx	a,@dptr
      005452 FF               [12]  532 	mov	r7,a
      005453 22               [24]  533 	ret
                                    534 
                                    535 	.area CSEG (CODE)
                                    536 ; function ak820_outline_0052
      005454                        537 _ak820_outline_0052:
      005454 8D 82            [24]  538 	mov	dpl,r5
      005456 8E 83            [24]  539 	mov	dph,r6
      005458 8F F0            [24]  540 	mov	b,r7
      00545A 22               [24]  541 	ret
                                    542 
                                    543 	.area CSEG (CODE)
                                    544 ; function ak820_outline_0057
      00545B                        545 _ak820_outline_0057:
      00545B E4               [12]  546 	clr	a
      00545C F0               [24]  547 	movx	@dptr,a
      00545D A3               [24]  548 	inc	dptr
      00545E F0               [24]  549 	movx	@dptr,a
      00545F A3               [24]  550 	inc	dptr
      005460 F0               [24]  551 	movx	@dptr,a
      005461 A3               [24]  552 	inc	dptr
      005462 F0               [24]  553 	movx	@dptr,a
      005463 22               [24]  554 	ret
                                    555 
                                    556 	.area CSEG (CODE)
                                    557 ; function ak820_outline_0062
      005464                        558 _ak820_outline_0062:
      005464 E0               [24]  559 	movx	a,@dptr
      005465 FC               [12]  560 	mov	r4,a
      005466 A3               [24]  561 	inc	dptr
      005467 E0               [24]  562 	movx	a,@dptr
      005468 FD               [12]  563 	mov	r5,a
      005469 A3               [24]  564 	inc	dptr
      00546A E0               [24]  565 	movx	a,@dptr
      00546B FE               [12]  566 	mov	r6,a
      00546C A3               [24]  567 	inc	dptr
      00546D E0               [24]  568 	movx	a,@dptr
      00546E 8C 82            [24]  569 	mov	dpl,r4
      005470 8D 83            [24]  570 	mov	dph,r5
      005472 8E F0            [24]  571 	mov	b,r6
      005474 22               [24]  572 	ret
                                    573 
                                    574 	.area CSEG (CODE)
                                    575 ; function ak820_outline_0063
      005475                        576 _ak820_outline_0063:
      005475 AC 82            [24]  577 	mov	r4,dpl
      005477 AD 83            [24]  578 	mov	r5,dph
      005479 AE F0            [24]  579 	mov	r6,b
      00547B FF               [12]  580 	mov	r7,a
      00547C 22               [24]  581 	ret
                                    582 
                                    583 	.area CSEG (CODE)
                                    584 ; function ak820_outline_0095
      00547D                        585 _ak820_outline_0095:
      00547D E0               [24]  586 	movx	a,@dptr
      00547E FE               [12]  587 	mov	r6,a
      00547F A3               [24]  588 	inc	dptr
      005480 E0               [24]  589 	movx	a,@dptr
      005481 8E 82            [24]  590 	mov	dpl,r6
      005483 F5 83            [12]  591 	mov	dph,a
      005485 22               [24]  592 	ret
                                    593 
                                    594 	.area CSEG (CODE)
                                    595 ; function ak820_outline_0111
      005486                        596 _ak820_outline_0111:
      005486 74 02            [12]  597 	mov	a,#0x02
      005488 F0               [24]  598 	movx	@dptr,a
      005489 E4               [12]  599 	clr	a
      00548A A3               [24]  600 	inc	dptr
      00548B F0               [24]  601 	movx	@dptr,a
      00548C 22               [24]  602 	ret
