                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tap_dance
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _dynamic_keymap_get_tap_dance
                                     13 	.globl _process_record
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_tap_dance_valid
                                    258 	.globl _ak820_tap_dance_task
                                    259 	.globl _ak820_tap_dance_before
                                    260 	.globl _ak820_tap_dance_process
                                    261 	.globl _ak820_tap_dance_cancel
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable items in internal ram
                                    526 ;--------------------------------------------------------
                                    527 ;--------------------------------------------------------
                                    528 ; indirectly addressable internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area ISEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; absolute internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area IABS    (ABS,DATA)
                                    535 	.area IABS    (ABS,DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; bit data
                                    538 ;--------------------------------------------------------
                                    539 	.area BSEG    (BIT)
      00000E                        540 _td_finish_sloc0_1_0:
      00000E                        541 	.ds 1
      00000F                        542 _ak820_tap_dance_before_sloc0_1_0:
      00000F                        543 	.ds 1
      000010                        544 _ak820_tap_dance_process_sloc0_1_0:
      000010                        545 	.ds 1
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      00059E                        554 _td_slots:
      00059E                        555 	.ds 32
      0005BE                        556 _td_wait:
      0005BE                        557 	.ds 2
      0005C0                        558 _td_work:
      0005C0                        559 	.ds 2
      0005C2                        560 _td_entry:
      0005C2                        561 	.ds 10
      0005CC                        562 _td_time:
      0005CC                        563 	.ds 2
      0005CE                        564 _td_map:
      0005CE                        565 	.ds 128
      00064E                        566 _td_record:
      00064E                        567 	.ds 9
      000657                        568 _td_step:
      000657                        569 	.ds 1
      000658                        570 _ak820_tap_dance_valid_entry_10000_594:
      000658                        571 	.ds 2
      00065A                        572 _ak820_tap_dance_valid_basic_30000_598:
      00065A                        573 	.ds 1
      00065B                        574 _td_finish_interrupted_10000_603:
      00065B                        575 	.ds 1
      00065C                        576 _td_finish_choice_10000_604:
      00065C                        577 	.ds 1
      00065D                        578 _td_finish_state_10000_604:
      00065D                        579 	.ds 1
      00065E                        580 _td_finish_extra_10000_604:
      00065E                        581 	.ds 1
      00065F                        582 _ak820_tap_dance_task_now_10000_620:
      00065F                        583 	.ds 2
      000661                        584 _ak820_tap_dance_task_term_10000_621:
      000661                        585 	.ds 2
      000663                        586 _ak820_tap_dance_before_event_10000_624:
      000663                        587 	.ds 2
      000665                        588 _ak820_tap_dance_process_record_10000_640:
      000665                        589 	.ds 2
                                    590 ;--------------------------------------------------------
                                    591 ; absolute external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XABS    (ABS,XDATA)
                                    594 ;--------------------------------------------------------
                                    595 ; initialized external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XISEG   (XDATA)
                                    598 	.area HOME    (CODE)
                                    599 	.area GSINIT0 (CODE)
                                    600 	.area GSINIT1 (CODE)
                                    601 	.area GSINIT2 (CODE)
                                    602 	.area GSINIT3 (CODE)
                                    603 	.area GSINIT4 (CODE)
                                    604 	.area GSINIT5 (CODE)
                                    605 	.area GSINIT  (CODE)
                                    606 	.area GSFINAL (CODE)
                                    607 	.area CSEG    (CODE)
                                    608 ;--------------------------------------------------------
                                    609 ; global & static initialisations
                                    610 ;--------------------------------------------------------
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT  (CODE)
                                    613 	.area GSFINAL (CODE)
                                    614 	.area GSINIT  (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; Home
                                    617 ;--------------------------------------------------------
                                    618 	.area HOME    (CODE)
                                    619 	.area HOME    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; code
                                    622 ;--------------------------------------------------------
                                    623 	.area CSEG    (CODE)
                                    624 ;------------------------------------------------------------
                                    625 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    626 ;------------------------------------------------------------
                                    627 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    628 ;------------------------------------------------------------
                                    629 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    630 ;	-----------------------------------------
                           000007   631 	ar7 = 0x07
                           000006   632 	ar6 = 0x06
                           000005   633 	ar5 = 0x05
                           000004   634 	ar4 = 0x04
                           000003   635 	ar3 = 0x03
                           000002   636 	ar2 = 0x02
                           000001   637 	ar1 = 0x01
                           000000   638 	ar0 = 0x00
                                    639 ;	 function ak820_tap_dance_valid
                                    640 ;	-----------------------------------------
      004392                        641 _ak820_tap_dance_valid:
      004392 12 38 7A         [24]  642 	lcall	_ak820_outline_0106
      004395 90 06 58         [24]  643 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
      004398 12 38 75         [24]  644 	lcall	_ak820_outline_0105
                                    645 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:25: const uint8_t AK820_STATE_MEM *bytes = (const uint8_t AK820_STATE_MEM *)entry;
      00439B 90 06 58         [24]  646 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
      00439E 12 38 2E         [24]  647 	lcall	_ak820_outline_0059
                                    648 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:26: if (bytes[9] & 128) return false;
      0043A1 74 09            [12]  649 	mov	a,#0x09
      0043A3 12 38 15         [24]  650 	lcall	_ak820_outline_0020
      0043A6 30 E7 04         [24]  651 	jnb	acc.7,00130$
      0043A9 75 82 00         [24]  652 	mov	dpl, #0x00
                                    653 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:27: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      0043AC 22               [24]  654 	ret
      0043AD                        655 00130$:
      0043AD 7D 00            [12]  656 	mov	r5,#0x00
      0043AF                        657 00114$:
      0043AF BD 04 00         [24]  658 	cjne	r5,#0x04,00167$
      0043B2                        659 00167$:
      0043B2 50 38            [24]  660 	jnc	00112$
                                    661 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: uint8_t basic = bytes[0], mods = bytes[1];
      0043B4 12 38 6F         [24]  662 	lcall	_ak820_outline_0103
      0043B7 FC               [12]  663 	mov	r4,a
      0043B8 90 06 5A         [24]  664 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
      0043BB 12 43 43         [24]  665 	lcall	_ak820_outline_0072
      0043BE A3               [24]  666 	inc	dptr
      0043BF E0               [24]  667 	movx	a,@dptr
                                    668 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:29: if (!(basic | mods)) continue;
      0043C0 FB               [12]  669 	mov	r3,a
      0043C1 4C               [12]  670 	orl	a,r4
      0043C2 60 22            [24]  671 	jz	00111$
                                    672 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:30: if (mods >= 32 || !((basic >= KC_A && basic <= KC_EXSEL) ||
      0043C4 BB 20 00         [24]  673 	cjne	r3,#0x20,00170$
      0043C7                        674 00170$:
      0043C7 50 19            [24]  675 	jnc	00105$
      0043C9 BC 04 00         [24]  676 	cjne	r4,#0x04,00172$
      0043CC                        677 00172$:
      0043CC 40 05            [24]  678 	jc	00109$
      0043CE EC               [12]  679 	mov	a,r4
      0043CF 24 5B            [12]  680 	add	a,#0xff - 0xa4
      0043D1 50 13            [24]  681 	jnc	00111$
                                    682 ;	free result
      0043D3                        683 00109$:
                                    684 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:31: (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI))) return false;
      0043D3 90 06 5A         [24]  685 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
      0043D6 E0               [24]  686 	movx	a,@dptr
      0043D7 FC               [12]  687 	mov	r4,a
      0043D8 BC E0 00         [24]  688 	cjne	r4,#0xe0,00175$
      0043DB                        689 00175$:
      0043DB 40 05            [24]  690 	jc	00105$
      0043DD EC               [12]  691 	mov	a,r4
      0043DE 24 18            [12]  692 	add	a,#0xff - 0xe7
      0043E0 50 04            [24]  693 	jnc	00111$
                                    694 ;	free result
      0043E2                        695 00105$:
      0043E2 75 82 00         [24]  696 	mov	dpl, #0x00
      0043E5 22               [24]  697 	ret
      0043E6                        698 00111$:
                                    699 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:27: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      0043E6 0D               [12]  700 	inc	r5
      0043E7 12 49 1E         [24]  701 	lcall	_ak820_outline_0123
      0043EA 80 C3            [24]  702 	sjmp	00114$
      0043EC                        703 00112$:
                                    704 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:33: return true;
      0043EC 75 82 01         [24]  705 	mov	dpl, #0x01
                                    706 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:34: }
      0043EF 22               [24]  707 	ret
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'td_prepare'
                                    710 ;------------------------------------------------------------
                                    711 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:37: static void td_prepare(void) {
                                    712 ;	-----------------------------------------
                                    713 ;	 function td_prepare
                                    714 ;	-----------------------------------------
      0043F0                        715 _td_prepare:
                                    716 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:38: td_record.event.key.row = td_work->source / MATRIX_COLS;
      0043F0 90 05 C0         [24]  717 	mov	dptr,#_td_work
      0043F3 12 37 DC         [24]  718 	lcall	_ak820_outline_0005
      0043F6 A3               [24]  719 	inc	dptr
      0043F7 A3               [24]  720 	inc	dptr
      0043F8 E0               [24]  721 	movx	a,@dptr
      0043F9 75 F0 08         [24]  722 	mov	b,#0x08
      0043FC 84               [48]  723 	div	ab
      0043FD 90 06 4F         [24]  724 	mov	dptr,#(_td_record + 0x0001)
      004400 F0               [24]  725 	movx	@dptr,a
                                    726 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:39: td_record.event.key.col = td_work->source % MATRIX_COLS;
      004401 90 05 C0         [24]  727 	mov	dptr,#_td_work
      004404 12 37 DC         [24]  728 	lcall	_ak820_outline_0005
      004407 A3               [24]  729 	inc	dptr
      004408 A3               [24]  730 	inc	dptr
      004409 E0               [24]  731 	movx	a,@dptr
      00440A FF               [12]  732 	mov	r7,a
      00440B 53 07 07         [24]  733 	anl	ar7,#0x07
      00440E 90 06 4E         [24]  734 	mov	dptr,#_td_record
      004411 EF               [12]  735 	mov	a,r7
      004412 F0               [24]  736 	movx	@dptr,a
                                    737 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:40: td_record.event.type = KEY_EVENT;
      004413 90 06 52         [24]  738 	mov	dptr,#(_td_record + 0x0004)
      004416 74 01            [12]  739 	mov	a,#0x01
      004418 F0               [24]  740 	movx	@dptr,a
                                    741 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:41: td_record.event.time = td_time;
      004419 90 05 CC         [24]  742 	mov	dptr,#_td_time
      00441C 12 38 2E         [24]  743 	lcall	_ak820_outline_0059
      00441F 90 06 50         [24]  744 	mov	dptr,#(_td_record + 0x0002)
      004422 12 49 18         [24]  745 	lcall	_ak820_outline_0066
                                    746 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:42: td_record.tap.count = 1;
      004425 90 06 54         [24]  747 	mov	dptr,#(_td_record + 0x0006)
      004428 E0               [24]  748 	movx	a,@dptr
      004429 54 0F            [12]  749 	anl	a,#0x0f
      00442B 44 10            [12]  750 	orl	a,#0x10
      00442D F0               [24]  751 	movx	@dptr,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:43: }
      00442E 22               [24]  753 	ret
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'td_finish'
                                    756 ;------------------------------------------------------------
                                    757 ;interrupted   Allocated with name '_td_finish_interrupted_10000_603'
                                    758 ;choice        Allocated with name '_td_finish_choice_10000_604'
                                    759 ;state         Allocated with name '_td_finish_state_10000_604'
                                    760 ;extra         Allocated with name '_td_finish_extra_10000_604'
                                    761 ;------------------------------------------------------------
                                    762 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:44: static void td_finish(bool interrupted) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function td_finish
                                    765 ;	-----------------------------------------
      00442F                        766 _td_finish:
      00442F E5 82            [12]  767 	mov	a,dpl
      004431 90 06 5B         [24]  768 	mov	dptr,#_td_finish_interrupted_10000_603
      004434 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:45: uint8_t choice = 0, state;
      004435 90 06 5C         [24]  771 	mov	dptr,#_td_finish_choice_10000_604
      004438 E4               [12]  772 	clr	a
      004439 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:46: bool extra = false;
      00443A 90 06 5E         [24]  775 	mov	dptr,#_td_finish_extra_10000_604
      00443D F0               [24]  776 	movx	@dptr,a
                                    777 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:47: if (!td_wait) return;
      00443E 90 05 BE         [24]  778 	mov	dptr,#_td_wait
      004441 12 38 2E         [24]  779 	lcall	_ak820_outline_0059
      004444 90 05 BE         [24]  780 	mov	dptr,#_td_wait
      004447 12 48 F6         [24]  781 	lcall	_ak820_outline_0038
      00444A 70 01            [24]  782 	jnz	00102$
      00444C 22               [24]  783 	ret
      00444D                        784 00102$:
                                    785 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:48: td_work = td_wait;
      00444D 90 05 C0         [24]  786 	mov	dptr,#_td_work
      004450 12 49 18         [24]  787 	lcall	_ak820_outline_0066
                                    788 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:49: td_wait = 0;
      004453 90 05 BE         [24]  789 	mov	dptr,#_td_wait
      004456 12 49 26         [24]  790 	lcall	_ak820_outline_0146
                                    791 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:50: state = td_work->state;
      004459 12 48 AA         [24]  792 	lcall	_ak820_outline_0007
      00445C FD               [12]  793 	mov	r5,a
      00445D 90 06 5D         [24]  794 	mov	dptr,#_td_finish_state_10000_604
      004460 F0               [24]  795 	movx	@dptr,a
                                    796 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:51: td_work->state = state | TD_DONE;
      004461 43 05 08         [24]  797 	orl	ar5,#0x08
      004464 12 38 8D         [24]  798 	lcall	_ak820_outline_0121
      004467 ED               [12]  799 	mov	a,r5
      004468 F0               [24]  800 	movx	@dptr,a
                                    801 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:52: if ((state & 3) == 1) {
      004469 90 06 5D         [24]  802 	mov	dptr,#_td_finish_state_10000_604
      00446C E0               [24]  803 	movx	a,@dptr
      00446D FF               [12]  804 	mov	r7,a
      00446E FE               [12]  805 	mov	r6,a
      00446F 53 06 03         [24]  806 	anl	ar6,#0x03
      004472 BE 01 12         [24]  807 	cjne	r6,#0x01,00110$
                                    808 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:53: if ((state & TD_DOWN) && !interrupted) choice = 1;
      004475 EF               [12]  809 	mov	a,r7
      004476 30 E2 2B         [24]  810 	jnb	acc.2,00111$
      004479 90 06 5B         [24]  811 	mov	dptr,#_td_finish_interrupted_10000_603
      00447C E0               [24]  812 	movx	a,@dptr
      00447D 70 25            [24]  813 	jnz	00111$
      00447F 90 06 5C         [24]  814 	mov	dptr,#_td_finish_choice_10000_604
      004482 74 01            [12]  815 	mov	a,#0x01
      004484 F0               [24]  816 	movx	@dptr,a
      004485 80 1D            [24]  817 	sjmp	00111$
      004487                        818 00110$:
                                    819 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:54: } else if (interrupted) extra = true;
      004487 90 06 5B         [24]  820 	mov	dptr,#_td_finish_interrupted_10000_603
      00448A E0               [24]  821 	movx	a,@dptr
      00448B 60 08            [24]  822 	jz	00107$
      00448D 90 06 5E         [24]  823 	mov	dptr,#_td_finish_extra_10000_604
      004490 74 01            [12]  824 	mov	a,#0x01
      004492 F0               [24]  825 	movx	@dptr,a
      004493 80 0F            [24]  826 	sjmp	00111$
      004495                        827 00107$:
                                    828 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:55: else choice = (state & TD_DOWN) ? 3 : 2;
      004495 EF               [12]  829 	mov	a,r7
      004496 30 E2 04         [24]  830 	jnb	acc.2,00133$
      004499 7F 03            [12]  831 	mov	r7,#0x03
      00449B 80 02            [24]  832 	sjmp	00134$
      00449D                        833 00133$:
      00449D 7F 02            [12]  834 	mov	r7,#0x02
      00449F                        835 00134$:
      00449F 90 06 5C         [24]  836 	mov	dptr,#_td_finish_choice_10000_604
      0044A2 EF               [12]  837 	mov	a,r7
      0044A3 F0               [24]  838 	movx	@dptr,a
      0044A4                        839 00111$:
                                    840 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:56: td_work->output = ((uint16_t AK820_STATE_MEM *)&td_entry)[choice];
      0044A4 90 05 C0         [24]  841 	mov	dptr,#_td_work
      0044A7 12 38 2E         [24]  842 	lcall	_ak820_outline_0059
      0044AA 90 06 5C         [24]  843 	mov	dptr,#_td_finish_choice_10000_604
      0044AD E0               [24]  844 	movx	a,@dptr
      0044AE FD               [12]  845 	mov	r5,a
      0044AF 75 F0 02         [24]  846 	mov	b,#0x02
      0044B2 A4               [48]  847 	mul	ab
      0044B3 24 C2            [12]  848 	add	a, #_td_entry
      0044B5 F5 82            [12]  849 	mov	dpl,a
      0044B7 74 05            [12]  850 	mov	a,#(_td_entry >> 8)
      0044B9 35 F0            [12]  851 	addc	a, b
      0044BB F5 83            [12]  852 	mov	dph,a
      0044BD 12 38 69         [24]  853 	lcall	_ak820_outline_0099
      0044C0 12 38 8D         [24]  854 	lcall	_ak820_outline_0121
      0044C3 12 38 57         [24]  855 	lcall	_ak820_outline_0082
                                    856 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:57: if (!td_work->output) {
      0044C6 90 05 C0         [24]  857 	mov	dptr,#_td_work
      0044C9 12 37 DC         [24]  858 	lcall	_ak820_outline_0005
      0044CC 12 49 3A         [24]  859 	lcall	_ak820_outline_0173
      0044CF 70 28            [24]  860 	jnz	00115$
                                    861 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:58: if (choice >= 2) extra = true;
      0044D1 BD 02 00         [24]  862 	cjne	r5,#0x02,00275$
      0044D4                        863 00275$:
      0044D4 40 06            [24]  864 	jc	00113$
      0044D6 90 06 5E         [24]  865 	mov	dptr,#_td_finish_extra_10000_604
      0044D9 74 01            [12]  866 	mov	a,#0x01
      0044DB F0               [24]  867 	movx	@dptr,a
      0044DC                        868 00113$:
                                    869 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:59: td_work->output = choice == 3 && td_entry.on_hold ? td_entry.on_hold : td_entry.on_tap;
      0044DC 90 06 5C         [24]  870 	mov	dptr,#_td_finish_choice_10000_604
      0044DF E0               [24]  871 	movx	a,@dptr
      0044E0 FD               [12]  872 	mov	r5,a
      0044E1 BD 03 09         [24]  873 	cjne	r5,#0x03,00135$
      0044E4 90 05 C4         [24]  874 	mov	dptr,#(_td_entry + 0x0002)
      0044E7 12 38 45         [24]  875 	lcall	_ak820_outline_0065
      0044EA 4C               [12]  876 	orl	a,r4
      0044EB 70 06            [24]  877 	jnz	00136$
      0044ED                        878 00135$:
      0044ED 90 05 C2         [24]  879 	mov	dptr,#_td_entry
      0044F0 12 38 45         [24]  880 	lcall	_ak820_outline_0065
      0044F3                        881 00136$:
      0044F3 12 38 8D         [24]  882 	lcall	_ak820_outline_0121
      0044F6 12 38 51         [24]  883 	lcall	_ak820_outline_0079
      0044F9                        884 00115$:
                                    885 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:61: td_step = extra ? 0 : 2;
      0044F9 90 06 5E         [24]  886 	mov	dptr,#_td_finish_extra_10000_604
      0044FC E0               [24]  887 	movx	a,@dptr
      0044FD 60 04            [24]  888 	jz	00140$
      0044FF 7F 00            [12]  889 	mov	r7,#0x00
      004501 80 02            [24]  890 	sjmp	00141$
      004503                        891 00140$:
      004503 7F 02            [12]  892 	mov	r7,#0x02
      004505                        893 00141$:
      004505 90 06 57         [24]  894 	mov	dptr,#_td_step
      004508 EF               [12]  895 	mov	a,r7
      004509 F0               [24]  896 	movx	@dptr,a
                                    897 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:62: td_record.keycode = td_entry.on_tap;
      00450A 90 05 C2         [24]  898 	mov	dptr,#_td_entry
      00450D 12 48 DE         [24]  899 	lcall	_ak820_outline_0033
                                    900 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:63: td_prepare();
      004510 12 43 F0         [24]  901 	lcall	_td_prepare
      004513                        902 00129$:
                                    903 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:66: for (; td_step < 4; ++td_step) {
      004513 90 06 57         [24]  904 	mov	dptr,#_td_step
      004516 E0               [24]  905 	movx	a,@dptr
      004517 FF               [12]  906 	mov	r7,a
      004518 BF 04 00         [24]  907 	cjne	r7,#0x04,00281$
      00451B                        908 00281$:
      00451B 50 4C            [24]  909 	jnc	00125$
                                    910 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:67: if (td_step == 2) td_record.keycode = td_work->output;
      00451D BF 02 09         [24]  911 	cjne	r7,#0x02,00117$
      004520 90 05 C0         [24]  912 	mov	dptr,#_td_work
      004523 12 37 DC         [24]  913 	lcall	_ak820_outline_0005
      004526 12 48 DE         [24]  914 	lcall	_ak820_outline_0033
      004529                        915 00117$:
                                    916 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:68: if (td_step == 3 && (td_work->state & TD_DOWN)) break;
      004529 90 06 57         [24]  917 	mov	dptr,#_td_step
      00452C E0               [24]  918 	movx	a,@dptr
      00452D FF               [12]  919 	mov	r7,a
      00452E BF 03 0D         [24]  920 	cjne	r7,#0x03,00119$
      004531 90 05 C0         [24]  921 	mov	dptr,#_td_work
      004534 12 37 DC         [24]  922 	lcall	_ak820_outline_0005
      004537 A3               [24]  923 	inc	dptr
      004538 A3               [24]  924 	inc	dptr
      004539 A3               [24]  925 	inc	dptr
      00453A E0               [24]  926 	movx	a,@dptr
      00453B 20 E2 2B         [24]  927 	jb	acc.2,00125$
      00453E                        928 00119$:
                                    929 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: td_record.event.pressed = !(td_step & 1);
      00453E 90 06 57         [24]  930 	mov	dptr,#_td_step
      004541 E0               [24]  931 	movx	a,@dptr
      004542 54 01            [12]  932 	anl	a,#0x01
      004544 B4 01 00         [24]  933 	cjne	a,#0x01,00288$
      004547                        934 00288$:
      004547 92 0E            [24]  935 	mov	_td_finish_sloc0_1_0,c
      004549 90 06 53         [24]  936 	mov	dptr,#(_td_record + 0x0005)
      00454C E4               [12]  937 	clr	a
      00454D 33               [12]  938 	rlc	a
      00454E 12 49 2B         [24]  939 	lcall	_ak820_outline_0150
                                    940 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:70: if (td_record.keycode) process_record(&td_record);
      004551 60 06            [24]  941 	jz	00122$
      004553 90 06 4E         [24]  942 	mov	dptr,#_td_record
      004556 12 75 BD         [24]  943 	lcall	_process_record
      004559                        944 00122$:
                                    945 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:71: if (!td_work->state) return;
      004559 12 48 AA         [24]  946 	lcall	_ak820_outline_0007
      00455C 70 01            [24]  947 	jnz	00130$
      00455E 22               [24]  948 	ret
      00455F                        949 00130$:
                                    950 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:66: for (; td_step < 4; ++td_step) {
      00455F 90 06 57         [24]  951 	mov	dptr,#_td_step
      004562 E0               [24]  952 	movx	a,@dptr
      004563 24 01            [12]  953 	add	a, #0x01
      004565 F0               [24]  954 	movx	@dptr,a
      004566 02 45 13         [24]  955 	ljmp	00129$
      004569                        956 00125$:
                                    957 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:73: if (!(td_work->state & TD_DOWN)) td_work->state = 0;
      004569 12 48 AA         [24]  958 	lcall	_ak820_outline_0007
      00456C 20 E2 05         [24]  959 	jb	acc.2,00131$
      00456F 12 38 8D         [24]  960 	lcall	_ak820_outline_0121
      004572 E4               [12]  961 	clr	a
      004573 F0               [24]  962 	movx	@dptr,a
      004574                        963 00131$:
                                    964 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:74: }
      004574 22               [24]  965 	ret
                                    966 ;------------------------------------------------------------
                                    967 ;Allocation info for local variables in function 'ak820_tap_dance_task'
                                    968 ;------------------------------------------------------------
                                    969 ;now           Allocated with name '_ak820_tap_dance_task_now_10000_620'
                                    970 ;term          Allocated with name '_ak820_tap_dance_task_term_10000_621'
                                    971 ;------------------------------------------------------------
                                    972 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:75: void ak820_tap_dance_task(uint16_t now) {
                                    973 ;	-----------------------------------------
                                    974 ;	 function ak820_tap_dance_task
                                    975 ;	-----------------------------------------
      004575                        976 _ak820_tap_dance_task:
      004575 12 38 7A         [24]  977 	lcall	_ak820_outline_0106
      004578 90 06 5F         [24]  978 	mov	dptr,#_ak820_tap_dance_task_now_10000_620
      00457B 12 38 75         [24]  979 	lcall	_ak820_outline_0105
                                    980 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:76: uint16_t term = td_entry.custom_tapping_term;
      00457E 90 05 CA         [24]  981 	mov	dptr,#(_td_entry + 0x0008)
      004581 12 38 2E         [24]  982 	lcall	_ak820_outline_0059
      004584 90 06 61         [24]  983 	mov	dptr,#_ak820_tap_dance_task_term_10000_621
      004587 12 49 18         [24]  984 	lcall	_ak820_outline_0066
                                    985 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:77: if (!term) term = 200;
      00458A EE               [12]  986 	mov	a,r6
      00458B 4F               [12]  987 	orl	a,r7
      00458C 70 08            [24]  988 	jnz	00102$
      00458E 90 06 61         [24]  989 	mov	dptr,#_ak820_tap_dance_task_term_10000_621
      004591 74 C8            [12]  990 	mov	a,#0xc8
      004593 12 38 9D         [24]  991 	lcall	_ak820_outline_0130
      004596                        992 00102$:
                                    993 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:78: if (td_wait && (uint16_t)(now - td_time) >= term) td_finish(false);
      004596 90 05 BE         [24]  994 	mov	dptr,#_td_wait
      004599 12 48 F6         [24]  995 	lcall	_ak820_outline_0038
      00459C 60 26            [24]  996 	jz	00106$
      00459E 90 05 CC         [24]  997 	mov	dptr,#_td_time
      0045A1 12 38 2E         [24]  998 	lcall	_ak820_outline_0059
      0045A4 90 06 5F         [24]  999 	mov	dptr,#_ak820_tap_dance_task_now_10000_620
      0045A7 12 38 45         [24] 1000 	lcall	_ak820_outline_0065
      0045AA EC               [12] 1001 	mov	a,r4
      0045AB C3               [12] 1002 	clr	c
      0045AC 9E               [12] 1003 	subb	a,r6
      0045AD FE               [12] 1004 	mov	r6,a
      0045AE ED               [12] 1005 	mov	a,r5
      0045AF 9F               [12] 1006 	subb	a,r7
      0045B0 FF               [12] 1007 	mov	r7,a
      0045B1 90 06 61         [24] 1008 	mov	dptr,#_ak820_tap_dance_task_term_10000_621
      0045B4 12 38 45         [24] 1009 	lcall	_ak820_outline_0065
      0045B7 C3               [12] 1010 	clr	c
      0045B8 EE               [12] 1011 	mov	a,r6
      0045B9 9C               [12] 1012 	subb	a,r4
      0045BA EF               [12] 1013 	mov	a,r7
      0045BB 9D               [12] 1014 	subb	a,r5
      0045BC 40 06            [24] 1015 	jc	00106$
      0045BE 75 82 00         [24] 1016 	mov	dpl, #0x00
                                   1017 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:79: }
      0045C1 02 44 2F         [24] 1018 	ljmp	_td_finish
      0045C4                       1019 00106$:
      0045C4 22               [24] 1020 	ret
                                   1021 ;------------------------------------------------------------
                                   1022 ;Allocation info for local variables in function 'ak820_tap_dance_before'
                                   1023 ;------------------------------------------------------------
                                   1024 ;event         Allocated with name '_ak820_tap_dance_before_event_10000_624'
                                   1025 ;id            Allocated with name '_ak820_tap_dance_before_id_10000_625'
                                   1026 ;slot          Allocated with name '_ak820_tap_dance_before_slot_10000_625'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:80: bool ak820_tap_dance_before(const keyevent_t AK820_STATE_MEM *event) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function ak820_tap_dance_before
                                   1031 ;	-----------------------------------------
      0045C5                       1032 _ak820_tap_dance_before:
      0045C5 12 38 7A         [24] 1033 	lcall	_ak820_outline_0106
      0045C8 90 06 63         [24] 1034 	mov	dptr,#_ak820_tap_dance_before_event_10000_624
      0045CB 12 38 75         [24] 1035 	lcall	_ak820_outline_0105
                                   1036 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:83: if (IS_NOEVENT(*event)) return true;
      0045CE 90 06 63         [24] 1037 	mov	dptr,#_ak820_tap_dance_before_event_10000_624
      0045D1 12 38 2E         [24] 1038 	lcall	_ak820_outline_0059
      0045D4 74 04            [12] 1039 	mov	a,#0x04
      0045D6 12 48 CA         [24] 1040 	lcall	_ak820_outline_0014
      0045D9 70 04            [24] 1041 	jnz	00102$
      0045DB 75 82 01         [24] 1042 	mov	dpl, #0x01
      0045DE 22               [24] 1043 	ret
      0045DF                       1044 00102$:
                                   1045 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:84: if (event->key.row >= MATRIX_ROWS || event->key.col >= MATRIX_COLS) {
      0045DF 12 38 86         [24] 1046 	lcall	_ak820_outline_0115
      0045E2 FD               [12] 1047 	mov	r5,a
      0045E3 BD 10 00         [24] 1048 	cjne	r5,#0x10,00220$
      0045E6                       1049 00220$:
      0045E6 50 09            [24] 1050 	jnc	00105$
      0045E8 12 38 6F         [24] 1051 	lcall	_ak820_outline_0103
      0045EB FC               [12] 1052 	mov	r4,a
      0045EC BC 08 00         [24] 1053 	cjne	r4,#0x08,00222$
      0045EF                       1054 00222$:
      0045EF 40 1D            [24] 1055 	jc	00106$
      0045F1                       1056 00105$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:85: if (event->pressed) td_finish(true);
      0045F1 90 06 63         [24] 1058 	mov	dptr,#_ak820_tap_dance_before_event_10000_624
      0045F4 12 43 4F         [24] 1059 	lcall	_ak820_outline_0084
      0045F7 74 05            [12] 1060 	mov	a,#0x05
      0045F9 2A               [12] 1061 	add	a, r2
      0045FA FA               [12] 1062 	mov	r2,a
      0045FB E4               [12] 1063 	clr	a
      0045FC 3B               [12] 1064 	addc	a, r3
      0045FD FB               [12] 1065 	mov	r3,a
      0045FE 12 38 A2         [24] 1066 	lcall	_ak820_outline_0131
      004601 E0               [24] 1067 	movx	a,@dptr
      004602 60 06            [24] 1068 	jz	00104$
      004604 75 82 01         [24] 1069 	mov	dpl, #0x01
      004607 12 44 2F         [24] 1070 	lcall	_td_finish
      00460A                       1071 00104$:
                                   1072 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:86: return true;
      00460A 75 82 01         [24] 1073 	mov	dpl, #0x01
      00460D 22               [24] 1074 	ret
      00460E                       1075 00106$:
                                   1076 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:88: id = event->key.row * MATRIX_COLS + event->key.col;
      00460E ED               [12] 1077 	mov	a,r5
      00460F 12 38 BC         [24] 1078 	lcall	_ak820_outline_0176
                                   1079 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:89: if (td_map[id] == TD_NONE) {
      004612 2C               [12] 1080 	add	a,r4
      004613 FD               [12] 1081 	mov	r5,a
      004614 24 CE            [12] 1082 	add	a, #_td_map
      004616 FB               [12] 1083 	mov	r3,a
      004617 E4               [12] 1084 	clr	a
      004618 34 05            [12] 1085 	addc	a, #(_td_map >> 8)
      00461A 12 49 10         [24] 1086 	lcall	_ak820_outline_0053
      00461D BA FF 0F         [24] 1087 	cjne	r2,#0xff,00111$
                                   1088 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:90: if (!event->pressed) td_map[id] = 0;
      004620 74 05            [12] 1089 	mov	a,#0x05
      004622 2E               [12] 1090 	add	a, r6
      004623 12 38 03         [24] 1091 	lcall	_ak820_outline_0017
      004626 70 03            [24] 1092 	jnz	00109$
      004628 12 38 7F         [24] 1093 	lcall	_ak820_outline_0114
      00462B                       1094 00109$:
                                   1095 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:91: return false;
      00462B 75 82 00         [24] 1096 	mov	dpl, #0x00
      00462E 22               [24] 1097 	ret
      00462F                       1098 00111$:
                                   1099 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:93: if (event->pressed && td_wait && (td_wait->source != id || (td_wait->state & 3) == 2)) td_finish(true);
      00462F 12 37 E6         [24] 1100 	lcall	_ak820_outline_0006
      004632 60 2B            [24] 1101 	jz	00113$
      004634 90 05 BE         [24] 1102 	mov	dptr,#_td_wait
      004637 12 38 2E         [24] 1103 	lcall	_ak820_outline_0059
      00463A 4E               [12] 1104 	orl	a,r6
      00463B 60 22            [24] 1105 	jz	00113$
      00463D 12 38 1E         [24] 1106 	lcall	_ak820_outline_0034
      004640 B5 05 0A         [24] 1107 	cjne	a,ar5,00112$
      004643 12 48 D5         [24] 1108 	lcall	_ak820_outline_0016
      004646 FF               [12] 1109 	mov	r7,a
      004647 53 07 03         [24] 1110 	anl	ar7,#0x03
      00464A BF 02 12         [24] 1111 	cjne	r7,#0x02,00113$
      00464D                       1112 00112$:
      00464D 75 82 01         [24] 1113 	mov	dpl, #0x01
      004650 C0 05            [24] 1114 	push	ar5
      004652 C0 04            [24] 1115 	push	ar4
      004654 C0 03            [24] 1116 	push	ar3
      004656 12 44 2F         [24] 1117 	lcall	_td_finish
      004659 D0 03            [24] 1118 	pop	ar3
      00465B D0 04            [24] 1119 	pop	ar4
      00465D D0 05            [24] 1120 	pop	ar5
      00465F                       1121 00113$:
                                   1122 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:94: slot = td_slots + td_map[id];
      00465F 12 33 FC         [24] 1123 	lcall	_ak820_outline_0125
      004662 E0               [24] 1124 	movx	a,@dptr
      004663 12 38 C6         [24] 1125 	lcall	_ak820_outline_0192
      004666 24 9E            [12] 1126 	add	a, #_td_slots
      004668 FE               [12] 1127 	mov	r6,a
      004669 74 05            [12] 1128 	mov	a,#(_td_slots >> 8)
      00466B 35 F0            [12] 1129 	addc	a, b
      00466D FF               [12] 1130 	mov	r7,a
                                   1131 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:95: if (slot->state && slot->source == id) {
      00466E 74 03            [12] 1132 	mov	a,#0x03
      004670 12 48 BF         [24] 1133 	lcall	_ak820_outline_0013
      004673 FA               [12] 1134 	mov	r2,a
      004674 60 5B            [24] 1135 	jz	00124$
      004676 12 38 1E         [24] 1136 	lcall	_ak820_outline_0034
      004679 B5 05 55         [24] 1137 	cjne	a,ar5,00124$
                                   1138 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:96: if (event->pressed) return !(slot->state & TD_DONE);
      00467C 90 06 63         [24] 1139 	mov	dptr,#_ak820_tap_dance_before_event_10000_624
      00467F E0               [24] 1140 	movx	a,@dptr
      004680 F9               [12] 1141 	mov	r1,a
      004681 A3               [24] 1142 	inc	dptr
      004682 E0               [24] 1143 	movx	a,@dptr
      004683 FD               [12] 1144 	mov	r5,a
      004684 74 05            [12] 1145 	mov	a,#0x05
      004686 29               [12] 1146 	add	a, r1
      004687 F9               [12] 1147 	mov	r1,a
      004688 E4               [12] 1148 	clr	a
      004689 3D               [12] 1149 	addc	a, r5
      00468A FD               [12] 1150 	mov	r5,a
      00468B 89 82            [24] 1151 	mov	dpl,r1
      00468D 8D 83            [24] 1152 	mov	dph,r5
      00468F E0               [24] 1153 	movx	a,@dptr
      004690 60 0E            [24] 1154 	jz	00118$
      004692 EA               [12] 1155 	mov	a,r2
      004693 A2 E3            [12] 1156 	mov	c,acc.3
      004695 E4               [12] 1157 	clr	a
      004696 33               [12] 1158 	rlc	a
      004697 B4 01 00         [24] 1159 	cjne	a,#0x01,00238$
      00469A                       1160 00238$:
      00469A 92 0F            [24] 1161 	mov  _ak820_tap_dance_before_sloc0_1_0,c
      00469C 12 38 AC         [24] 1162 	lcall	_ak820_outline_0147
      00469F 22               [24] 1163 	ret
      0046A0                       1164 00118$:
                                   1165 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:97: slot->state &= ~TD_DOWN;
      0046A0 53 02 FB         [24] 1166 	anl	ar2,#0xfb
      0046A3 12 33 FC         [24] 1167 	lcall	_ak820_outline_0125
      0046A6 EA               [12] 1168 	mov	a,r2
      0046A7 F0               [24] 1169 	movx	@dptr,a
                                   1170 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:98: if (slot->state & TD_DONE) {
      0046A8 EA               [12] 1171 	mov	a,r2
      0046A9 30 E3 21         [24] 1172 	jnb	acc.3,00122$
                                   1173 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:99: td_work = slot;
      0046AC 90 05 C0         [24] 1174 	mov	dptr,#_td_work
      0046AF EE               [12] 1175 	mov	a,r6
      0046B0 F0               [24] 1176 	movx	@dptr,a
      0046B1 EF               [12] 1177 	mov	a,r7
      0046B2 12 43 35         [24] 1178 	lcall	_ak820_outline_0064
                                   1179 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:100: td_record.keycode = slot->output;
      0046B5 12 48 DE         [24] 1180 	lcall	_ak820_outline_0033
                                   1181 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:101: slot->state = 0;
      0046B8 12 38 7F         [24] 1182 	lcall	_ak820_outline_0114
                                   1183 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: td_prepare();
      0046BB 12 43 F0         [24] 1184 	lcall	_td_prepare
                                   1185 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:103: td_record.event.pressed = false;
      0046BE 90 06 53         [24] 1186 	mov	dptr,#(_td_record + 0x0005)
      0046C1 E4               [12] 1187 	clr	a
      0046C2 12 49 2B         [24] 1188 	lcall	_ak820_outline_0150
                                   1189 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:104: if (td_record.keycode) process_record(&td_record);
      0046C5 60 06            [24] 1190 	jz	00122$
      0046C7 90 06 4E         [24] 1191 	mov	dptr,#_td_record
      0046CA 12 75 BD         [24] 1192 	lcall	_process_record
      0046CD                       1193 00122$:
                                   1194 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:106: return false;
      0046CD 75 82 00         [24] 1195 	mov	dpl, #0x00
      0046D0 22               [24] 1196 	ret
      0046D1                       1197 00124$:
                                   1198 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:108: return true;
      0046D1 75 82 01         [24] 1199 	mov	dpl, #0x01
                                   1200 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:109: }
      0046D4 22               [24] 1201 	ret
                                   1202 ;------------------------------------------------------------
                                   1203 ;Allocation info for local variables in function 'ak820_tap_dance_process'
                                   1204 ;------------------------------------------------------------
                                   1205 ;record        Allocated with name '_ak820_tap_dance_process_record_10000_640'
                                   1206 ;index         Allocated with name '_ak820_tap_dance_process_index_10000_641'
                                   1207 ;id            Allocated with name '_ak820_tap_dance_process_id_10000_641'
                                   1208 ;slot          Allocated with name '_ak820_tap_dance_process_slot_10000_641'
                                   1209 ;------------------------------------------------------------
                                   1210 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:110: bool ak820_tap_dance_process(keyrecord_t AK820_STATE_MEM *record) {
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function ak820_tap_dance_process
                                   1213 ;	-----------------------------------------
      0046D5                       1214 _ak820_tap_dance_process:
      0046D5 12 38 7A         [24] 1215 	lcall	_ak820_outline_0106
      0046D8 90 06 65         [24] 1216 	mov	dptr,#_ak820_tap_dance_process_record_10000_640
      0046DB 12 38 75         [24] 1217 	lcall	_ak820_outline_0105
                                   1218 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:113: if (record->event.type != KEY_EVENT || record->event.key.row >= MATRIX_ROWS ||
      0046DE 90 06 65         [24] 1219 	mov	dptr,#_ak820_tap_dance_process_record_10000_640
      0046E1 12 37 DC         [24] 1220 	lcall	_ak820_outline_0005
      0046E4 A3               [24] 1221 	inc	dptr
      0046E5 A3               [24] 1222 	inc	dptr
      0046E6 A3               [24] 1223 	inc	dptr
      0046E7 A3               [24] 1224 	inc	dptr
      0046E8 E0               [24] 1225 	movx	a,@dptr
      0046E9 FD               [12] 1226 	mov	r5,a
      0046EA BD 01 4B         [24] 1227 	cjne	r5,#0x01,00101$
      0046ED 74 01            [12] 1228 	mov	a,#0x01
      0046EF 12 48 CA         [24] 1229 	lcall	_ak820_outline_0014
      0046F2 FB               [12] 1230 	mov	r3,a
      0046F3 BB 10 00         [24] 1231 	cjne	r3,#0x10,00226$
      0046F6                       1232 00226$:
      0046F6 50 40            [24] 1233 	jnc	00101$
                                   1234 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:114: record->event.key.col >= MATRIX_COLS || get_repeat_key_count() || ak820_macro_primitive ||
      0046F8 8E 02            [24] 1235 	mov	ar2,r6
      0046FA 8F 03            [24] 1236 	mov	ar3,r7
      0046FC 12 38 A2         [24] 1237 	lcall	_ak820_outline_0131
      0046FF E0               [24] 1238 	movx	a,@dptr
      004700 F9               [12] 1239 	mov	r1,a
      004701 B9 08 00         [24] 1240 	cjne	r1,#0x08,00228$
      004704                       1241 00228$:
      004704 50 32            [24] 1242 	jnc	00101$
      004706 C0 07            [24] 1243 	push	ar7
      004708 C0 06            [24] 1244 	push	ar6
      00470A C0 05            [24] 1245 	push	ar5
      00470C C0 04            [24] 1246 	push	ar4
      00470E C0 03            [24] 1247 	push	ar3
      004710 C0 02            [24] 1248 	push	ar2
      004712 12 A7 82         [24] 1249 	lcall	_get_repeat_key_count
      004715 E5 82            [12] 1250 	mov	a, dpl
      004717 D0 02            [24] 1251 	pop	ar2
      004719 D0 03            [24] 1252 	pop	ar3
      00471B D0 04            [24] 1253 	pop	ar4
      00471D D0 05            [24] 1254 	pop	ar5
      00471F D0 06            [24] 1255 	pop	ar6
      004721 D0 07            [24] 1256 	pop	ar7
      004723 70 13            [24] 1257 	jnz	00101$
      004725 90 0A 49         [24] 1258 	mov	dptr,#_ak820_macro_primitive
      004728 E0               [24] 1259 	movx	a,@dptr
      004729 70 0D            [24] 1260 	jnz	00101$
                                   1261 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:115: !record->event.pressed) return (record->keycode >> 8) != (QK_TAP_DANCE >> 8);
      00472B 74 05            [12] 1262 	mov	a,#0x05
      00472D 2E               [12] 1263 	add	a, r6
      00472E F8               [12] 1264 	mov	r0,a
      00472F E4               [12] 1265 	clr	a
      004730 3F               [12] 1266 	addc	a, r7
      004731 F9               [12] 1267 	mov	r1,a
      004732 12 38 B1         [24] 1268 	lcall	_ak820_outline_0153
      004735 E0               [24] 1269 	movx	a,@dptr
      004736 70 26            [24] 1270 	jnz	00102$
      004738                       1271 00101$:
      004738 90 06 65         [24] 1272 	mov	dptr,#_ak820_tap_dance_process_record_10000_640
      00473B 12 38 63         [24] 1273 	lcall	_ak820_outline_0098
      00473E 74 07            [12] 1274 	mov	a,#0x07
      004740 28               [12] 1275 	add	a, r0
      004741 F5 82            [12] 1276 	mov	dpl,a
      004743 E4               [12] 1277 	clr	a
      004744 39               [12] 1278 	addc	a, r1
      004745 F5 83            [12] 1279 	mov	dph,a
      004747 E0               [24] 1280 	movx	a,@dptr
      004748 A3               [24] 1281 	inc	dptr
      004749 E0               [24] 1282 	movx	a,@dptr
      00474A F8               [12] 1283 	mov	r0,a
      00474B 79 00            [12] 1284 	mov	r1,#0x00
      00474D B8 57 06         [24] 1285 	cjne	r0,#0x57,00233$
      004750 B9 00 03         [24] 1286 	cjne	r1,#0x00,00233$
      004753 D3               [12] 1287 	setb	c
      004754 80 01            [24] 1288 	sjmp	00234$
      004756                       1289 00233$:
      004756 C3               [12] 1290 	clr	c
      004757                       1291 00234$:
      004757 B3               [12] 1292 	cpl	c
      004758 92 10            [24] 1293 	mov	_ak820_tap_dance_process_sloc0_1_0,c
      00475A 12 38 AC         [24] 1294 	lcall	_ak820_outline_0147
      00475D 22               [24] 1295 	ret
      00475E                       1296 00102$:
                                   1297 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:116: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      00475E 12 43 49         [24] 1298 	lcall	_ak820_outline_0083
      004761 12 38 BC         [24] 1299 	lcall	_ak820_outline_0176
      004764 FC               [12] 1300 	mov	r4,a
      004765 12 38 A2         [24] 1301 	lcall	_ak820_outline_0131
      004768 E0               [24] 1302 	movx	a,@dptr
      004769 2C               [12] 1303 	add	a, r4
      00476A FD               [12] 1304 	mov	r5,a
                                   1305 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:118: if (td_wait && !(td_wait->state & TD_DOWN) && td_wait->source == id &&
      00476B 90 05 BE         [24] 1306 	mov	dptr,#_td_wait
      00476E 12 38 69         [24] 1307 	lcall	_ak820_outline_0099
      004771 4B               [12] 1308 	orl	a,r3
      004772 60 3B            [24] 1309 	jz	00109$
      004774 12 33 FC         [24] 1310 	lcall	_ak820_outline_0125
      004777 A3               [24] 1311 	inc	dptr
      004778 A3               [24] 1312 	inc	dptr
      004779 A3               [24] 1313 	inc	dptr
      00477A E0               [24] 1314 	movx	a,@dptr
      00477B 20 E2 31         [24] 1315 	jb	acc.2,00109$
      00477E 12 33 FC         [24] 1316 	lcall	_ak820_outline_0125
      004781 A3               [24] 1317 	inc	dptr
      004782 A3               [24] 1318 	inc	dptr
      004783 E0               [24] 1319 	movx	a,@dptr
      004784 B5 05 28         [24] 1320 	cjne	a,ar5,00109$
                                   1321 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:119: record->keycode != (QK_TAP_DANCE | td_map[id])) td_finish(true);
      004787 74 07            [12] 1322 	mov	a,#0x07
      004789 12 38 15         [24] 1323 	lcall	_ak820_outline_0020
      00478C FE               [12] 1324 	mov	r6,a
      00478D A3               [24] 1325 	inc	dptr
      00478E E0               [24] 1326 	movx	a,@dptr
      00478F FF               [12] 1327 	mov	r7,a
      004790 ED               [12] 1328 	mov	a,r5
      004791 12 49 06         [24] 1329 	lcall	_ak820_outline_0044
      004794 E0               [24] 1330 	movx	a,@dptr
      004795 FC               [12] 1331 	mov	r4,a
      004796 7B 00            [12] 1332 	mov	r3,#0x00
      004798 43 03 57         [24] 1333 	orl	ar3,#0x57
      00479B EE               [12] 1334 	mov	a,r6
      00479C B5 04 06         [24] 1335 	cjne	a,ar4,00239$
      00479F EF               [12] 1336 	mov	a,r7
      0047A0 B5 03 02         [24] 1337 	cjne	a,ar3,00239$
      0047A3 80 0A            [24] 1338 	sjmp	00109$
      0047A5                       1339 00239$:
      0047A5 75 82 01         [24] 1340 	mov	dpl, #0x01
      0047A8 C0 05            [24] 1341 	push	ar5
      0047AA 12 44 2F         [24] 1342 	lcall	_td_finish
      0047AD D0 05            [24] 1343 	pop	ar5
      0047AF                       1344 00109$:
                                   1345 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:120: if ((record->keycode >> 8) != (QK_TAP_DANCE >> 8)) return true;
      0047AF 90 06 65         [24] 1346 	mov	dptr,#_ak820_tap_dance_process_record_10000_640
      0047B2 12 37 F3         [24] 1347 	lcall	_ak820_outline_0008
      0047B5 FE               [12] 1348 	mov	r6,a
      0047B6 A3               [24] 1349 	inc	dptr
      0047B7 E0               [24] 1350 	movx	a,@dptr
      0047B8 FB               [12] 1351 	mov	r3,a
      0047B9 7C 00            [12] 1352 	mov	r4,#0x00
      0047BB BB 57 05         [24] 1353 	cjne	r3,#0x57,00240$
      0047BE BC 00 02         [24] 1354 	cjne	r4,#0x00,00240$
      0047C1 80 04            [24] 1355 	sjmp	00114$
      0047C3                       1356 00240$:
      0047C3 75 82 01         [24] 1357 	mov	dpl, #0x01
      0047C6 22               [24] 1358 	ret
      0047C7                       1359 00114$:
                                   1360 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:121: index = (uint8_t)record->keycode;
                                   1361 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:122: slot = td_slots + (index & 7);
      0047C7 8E 04            [24] 1362 	mov	ar4,r6
      0047C9 53 04 07         [24] 1363 	anl	ar4,#0x07
      0047CC 7F 00            [12] 1364 	mov	r7,#0x00
      0047CE EC               [12] 1365 	mov	a,r4
      0047CF 2C               [12] 1366 	add	a,r4
      0047D0 FC               [12] 1367 	mov	r4,a
      0047D1 EF               [12] 1368 	mov	a,r7
      0047D2 33               [12] 1369 	rlc	a
      0047D3 FF               [12] 1370 	mov	r7,a
      0047D4 EC               [12] 1371 	mov	a,r4
      0047D5 2C               [12] 1372 	add	a,r4
      0047D6 FC               [12] 1373 	mov	r4,a
      0047D7 EF               [12] 1374 	mov	a,r7
      0047D8 33               [12] 1375 	rlc	a
      0047D9 FF               [12] 1376 	mov	r7,a
      0047DA EC               [12] 1377 	mov	a,r4
      0047DB 24 9E            [12] 1378 	add	a, #_td_slots
      0047DD FC               [12] 1379 	mov	r4,a
      0047DE EF               [12] 1380 	mov	a,r7
      0047DF 34 05            [12] 1381 	addc	a, #(_td_slots >> 8)
      0047E1 FF               [12] 1382 	mov	r7,a
                                   1383 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:123: if (index >= VIAL_TAP_DANCE_ENTRIES || (slot->state && slot->source != id)) goto suppress;
      0047E2 BE 08 00         [24] 1384 	cjne	r6,#0x08,00241$
      0047E5                       1385 00241$:
      0047E5 40 03            [24] 1386 	jc	00242$
      0047E7 02 48 6E         [24] 1387 	ljmp	00123$
      0047EA                       1388 00242$:
      0047EA 74 03            [12] 1389 	mov	a,#0x03
      0047EC 2C               [12] 1390 	add	a, r4
      0047ED 12 48 EC         [24] 1391 	lcall	_ak820_outline_0035
      0047F0 F9               [12] 1392 	mov	r1,a
      0047F1 60 0E            [24] 1393 	jz	00116$
      0047F3 12 49 40         [24] 1394 	lcall	_ak820_outline_0188
      0047F6 A3               [24] 1395 	inc	dptr
      0047F7 A3               [24] 1396 	inc	dptr
      0047F8 E0               [24] 1397 	movx	a,@dptr
      0047F9 B5 05 02         [24] 1398 	cjne	a,ar5,00244$
      0047FC 80 03            [24] 1399 	sjmp	00245$
      0047FE                       1400 00244$:
      0047FE 02 48 6E         [24] 1401 	ljmp	00123$
      004801                       1402 00245$:
      004801                       1403 00116$:
                                   1404 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:124: if (!slot->state) {
      004801 E9               [12] 1405 	mov	a,r1
      004802 70 36            [24] 1406 	jnz	00122$
                                   1407 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:125: if (dynamic_keymap_get_tap_dance(index, &td_entry)) goto suppress;
      004804 90 0B B0         [24] 1408 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      004807 74 C2            [12] 1409 	mov	a,#_td_entry
      004809 F0               [24] 1410 	movx	@dptr,a
      00480A 74 05            [12] 1411 	mov	a,#(_td_entry >> 8)
      00480C 12 38 4B         [24] 1412 	lcall	_ak820_outline_0077
      00480F 8E 82            [24] 1413 	mov	dpl, r6
      004811 C0 07            [24] 1414 	push	ar7
      004813 C0 06            [24] 1415 	push	ar6
      004815 C0 05            [24] 1416 	push	ar5
      004817 C0 04            [24] 1417 	push	ar4
      004819 C0 03            [24] 1418 	push	ar3
      00481B C0 02            [24] 1419 	push	ar2
      00481D 12 89 DB         [24] 1420 	lcall	_dynamic_keymap_get_tap_dance
      004820 12 38 92         [24] 1421 	lcall	_ak820_outline_0126
      004823 D0 02            [24] 1422 	pop	ar2
      004825 D0 03            [24] 1423 	pop	ar3
      004827 D0 04            [24] 1424 	pop	ar4
      004829 D0 05            [24] 1425 	pop	ar5
      00482B D0 06            [24] 1426 	pop	ar6
      00482D D0 07            [24] 1427 	pop	ar7
      00482F 45 F0            [12] 1428 	orl	a,b
      004831 70 3B            [24] 1429 	jnz	00123$
                                   1430 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:126: slot->source = id;
      004833 12 49 40         [24] 1431 	lcall	_ak820_outline_0188
      004836 A3               [24] 1432 	inc	dptr
      004837 A3               [24] 1433 	inc	dptr
      004838 ED               [12] 1434 	mov	a,r5
      004839 F0               [24] 1435 	movx	@dptr,a
      00483A                       1436 00122$:
                                   1437 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:128: slot->state = (slot->state & 3) + 1 + TD_DOWN;
      00483A 12 38 A2         [24] 1438 	lcall	_ak820_outline_0131
      00483D E0               [24] 1439 	movx	a,@dptr
      00483E F9               [12] 1440 	mov	r1,a
      00483F 74 03            [12] 1441 	mov	a,#0x03
      004841 59               [12] 1442 	anl	a,r1
      004842 24 05            [12] 1443 	add	a, #0x05
      004844 12 38 A2         [24] 1444 	lcall	_ak820_outline_0131
      004847 F0               [24] 1445 	movx	@dptr,a
                                   1446 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:129: td_time = record->event.time;
      004848 90 06 65         [24] 1447 	mov	dptr,#_ak820_tap_dance_process_record_10000_640
      00484B 12 43 4F         [24] 1448 	lcall	_ak820_outline_0084
      00484E 12 38 A2         [24] 1449 	lcall	_ak820_outline_0131
      004851 A3               [24] 1450 	inc	dptr
      004852 A3               [24] 1451 	inc	dptr
      004853 12 43 4F         [24] 1452 	lcall	_ak820_outline_0084
      004856 90 05 CC         [24] 1453 	mov	dptr,#_td_time
      004859 EA               [12] 1454 	mov	a,r2
      00485A 12 49 35         [24] 1455 	lcall	_ak820_outline_0162
                                   1456 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:130: td_wait = slot;
      00485D 90 05 BE         [24] 1457 	mov	dptr,#_td_wait
      004860 EC               [12] 1458 	mov	a,r4
      004861 12 38 75         [24] 1459 	lcall	_ak820_outline_0105
                                   1460 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:131: td_map[id] = index;
      004864 ED               [12] 1461 	mov	a,r5
      004865 12 49 06         [24] 1462 	lcall	_ak820_outline_0044
      004868 EE               [12] 1463 	mov	a,r6
      004869 F0               [24] 1464 	movx	@dptr,a
                                   1465 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:132: return false;
      00486A 75 82 00         [24] 1466 	mov	dpl, #0x00
                                   1467 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:133: suppress:
      00486D 22               [24] 1468 	ret
      00486E                       1469 00123$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:134: td_map[id] = TD_NONE;
      00486E ED               [12] 1471 	mov	a,r5
      00486F 12 49 06         [24] 1472 	lcall	_ak820_outline_0044
      004872 74 FF            [12] 1473 	mov	a,#0xff
      004874 F0               [24] 1474 	movx	@dptr,a
                                   1475 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:135: return false;
      004875 75 82 00         [24] 1476 	mov	dpl, #0x00
                                   1477 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:136: }
      004878 22               [24] 1478 	ret
                                   1479 ;------------------------------------------------------------
                                   1480 ;Allocation info for local variables in function 'ak820_tap_dance_cancel'
                                   1481 ;------------------------------------------------------------
                                   1482 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_651'
                                   1483 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_652'
                                   1484 ;------------------------------------------------------------
                                   1485 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:137: void ak820_tap_dance_cancel(void) {
                                   1486 ;	-----------------------------------------
                                   1487 ;	 function ak820_tap_dance_cancel
                                   1488 ;	-----------------------------------------
      004879                       1489 _ak820_tap_dance_cancel:
                                   1490 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:138: td_wait = 0;
      004879 90 05 BE         [24] 1491 	mov	dptr,#_td_wait
      00487C 12 49 26         [24] 1492 	lcall	_ak820_outline_0146
                                   1493 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:139: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) td_slots[i].state = 0;
      00487F FF               [12] 1494 	mov	r7,a
      004880                       1495 00104$:
      004880 BF 08 00         [24] 1496 	cjne	r7,#0x08,00141$
      004883                       1497 00141$:
      004883 50 14            [24] 1498 	jnc	00101$
      004885 EF               [12] 1499 	mov	a,r7
      004886 12 38 C6         [24] 1500 	lcall	_ak820_outline_0192
      004889 24 9E            [12] 1501 	add	a, #_td_slots
      00488B FD               [12] 1502 	mov	r5,a
      00488C 74 05            [12] 1503 	mov	a,#(_td_slots >> 8)
      00488E 35 F0            [12] 1504 	addc	a, b
      004890 FE               [12] 1505 	mov	r6,a
      004891 12 48 FE         [24] 1506 	lcall	_ak820_outline_0041
      004894 E4               [12] 1507 	clr	a
      004895 F0               [24] 1508 	movx	@dptr,a
      004896 0F               [12] 1509 	inc	r7
      004897 80 E7            [24] 1510 	sjmp	00104$
      004899                       1511 00101$:
                                   1512 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:140: for (uint8_t i = 0; i < sizeof(td_map); ++i) td_map[i] = 0;
      004899 7F 00            [12] 1513 	mov	r7,#0x00
      00489B                       1514 00107$:
      00489B BF 80 00         [24] 1515 	cjne	r7,#0x80,00143$
      00489E                       1516 00143$:
      00489E 50 09            [24] 1517 	jnc	00109$
      0048A0 EF               [12] 1518 	mov	a,r7
      0048A1 12 49 06         [24] 1519 	lcall	_ak820_outline_0044
      0048A4 E4               [12] 1520 	clr	a
      0048A5 F0               [24] 1521 	movx	@dptr,a
      0048A6 0F               [12] 1522 	inc	r7
      0048A7 80 F2            [24] 1523 	sjmp	00107$
      0048A9                       1524 00109$:
                                   1525 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:141: }
      0048A9 22               [24] 1526 	ret
                                   1527 	.area CSEG    (CODE)
                                   1528 	.area CONST   (CODE)
                                   1529 	.area XINIT   (CODE)
                                   1530 	.area CABS    (ABS,CODE)
                                   1531 
                                   1532 ; Experimental exact instruction outlining.
                                   1533 	.globl _ak820_outline_0005
                                   1534 	.globl _ak820_outline_0006
                                   1535 	.globl _ak820_outline_0007
                                   1536 	.globl _ak820_outline_0008
                                   1537 	.globl _ak820_outline_0013
                                   1538 	.globl _ak820_outline_0014
                                   1539 	.globl _ak820_outline_0016
                                   1540 	.globl _ak820_outline_0017
                                   1541 	.globl _ak820_outline_0020
                                   1542 	.globl _ak820_outline_0033
                                   1543 	.globl _ak820_outline_0034
                                   1544 	.globl _ak820_outline_0035
                                   1545 	.globl _ak820_outline_0038
                                   1546 	.globl _ak820_outline_0041
                                   1547 	.globl _ak820_outline_0044
                                   1548 	.globl _ak820_outline_0053
                                   1549 	.globl _ak820_outline_0059
                                   1550 	.globl _ak820_outline_0064
                                   1551 	.globl _ak820_outline_0065
                                   1552 	.globl _ak820_outline_0066
                                   1553 	.globl _ak820_outline_0072
                                   1554 	.globl _ak820_outline_0077
                                   1555 	.globl _ak820_outline_0079
                                   1556 	.globl _ak820_outline_0082
                                   1557 	.globl _ak820_outline_0083
                                   1558 	.globl _ak820_outline_0084
                                   1559 	.globl _ak820_outline_0098
                                   1560 	.globl _ak820_outline_0099
                                   1561 	.globl _ak820_outline_0103
                                   1562 	.globl _ak820_outline_0105
                                   1563 	.globl _ak820_outline_0106
                                   1564 	.globl _ak820_outline_0114
                                   1565 	.globl _ak820_outline_0115
                                   1566 	.globl _ak820_outline_0121
                                   1567 	.globl _ak820_outline_0123
                                   1568 	.globl _ak820_outline_0125
                                   1569 	.globl _ak820_outline_0126
                                   1570 	.globl _ak820_outline_0130
                                   1571 	.globl _ak820_outline_0131
                                   1572 	.globl _ak820_outline_0146
                                   1573 	.globl _ak820_outline_0147
                                   1574 	.globl _ak820_outline_0150
                                   1575 	.globl _ak820_outline_0153
                                   1576 	.globl _ak820_outline_0162
                                   1577 	.globl _ak820_outline_0173
                                   1578 	.globl _ak820_outline_0176
                                   1579 	.globl _ak820_outline_0188
                                   1580 	.globl _ak820_outline_0192
                                   1581 
                                   1582 	.area CSEG (CODE)
                                   1583 ; function ak820_outline_0007
      0048AA                       1584 _ak820_outline_0007:
      0048AA 90 05 C0         [24] 1585 	mov	dptr,#_td_work
      0048AD E0               [24] 1586 	movx	a,@dptr
      0048AE FE               [12] 1587 	mov	r6,a
      0048AF A3               [24] 1588 	inc	dptr
      0048B0 E0               [24] 1589 	movx	a,@dptr
      0048B1 FF               [12] 1590 	mov	r7,a
      0048B2 74 03            [12] 1591 	mov	a,#0x03
      0048B4 2E               [12] 1592 	add	a,r6
      0048B5 FE               [12] 1593 	mov	r6,a
      0048B6 E4               [12] 1594 	clr	a
      0048B7 3F               [12] 1595 	addc	a,r7
      0048B8 FF               [12] 1596 	mov	r7,a
      0048B9 8E 82            [24] 1597 	mov	dpl,r6
      0048BB 8F 83            [24] 1598 	mov	dph,r7
      0048BD E0               [24] 1599 	movx	a,@dptr
      0048BE 22               [24] 1600 	ret
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0013
      0048BF                       1604 _ak820_outline_0013:
      0048BF 2E               [12] 1605 	add	a,r6
      0048C0 FB               [12] 1606 	mov	r3,a
      0048C1 E4               [12] 1607 	clr	a
      0048C2 3F               [12] 1608 	addc	a,r7
      0048C3 FC               [12] 1609 	mov	r4,a
      0048C4 8B 82            [24] 1610 	mov	dpl,r3
      0048C6 8C 83            [24] 1611 	mov	dph,r4
      0048C8 E0               [24] 1612 	movx	a,@dptr
      0048C9 22               [24] 1613 	ret
                                   1614 
                                   1615 	.area CSEG (CODE)
                                   1616 ; function ak820_outline_0014
      0048CA                       1617 _ak820_outline_0014:
      0048CA 2E               [12] 1618 	add	a,r6
      0048CB FC               [12] 1619 	mov	r4,a
      0048CC E4               [12] 1620 	clr	a
      0048CD 3F               [12] 1621 	addc	a,r7
      0048CE FD               [12] 1622 	mov	r5,a
      0048CF 8C 82            [24] 1623 	mov	dpl,r4
      0048D1 8D 83            [24] 1624 	mov	dph,r5
      0048D3 E0               [24] 1625 	movx	a,@dptr
      0048D4 22               [24] 1626 	ret
                                   1627 
                                   1628 	.area CSEG (CODE)
                                   1629 ; function ak820_outline_0016
      0048D5                       1630 _ak820_outline_0016:
      0048D5 8E 82            [24] 1631 	mov	dpl,r6
      0048D7 8F 83            [24] 1632 	mov	dph,r7
      0048D9 A3               [24] 1633 	inc	dptr
      0048DA A3               [24] 1634 	inc	dptr
      0048DB A3               [24] 1635 	inc	dptr
      0048DC E0               [24] 1636 	movx	a,@dptr
      0048DD 22               [24] 1637 	ret
                                   1638 
                                   1639 	.area CSEG (CODE)
                                   1640 ; function ak820_outline_0033
      0048DE                       1641 _ak820_outline_0033:
      0048DE E0               [24] 1642 	movx	a,@dptr
      0048DF FE               [12] 1643 	mov	r6,a
      0048E0 A3               [24] 1644 	inc	dptr
      0048E1 E0               [24] 1645 	movx	a,@dptr
      0048E2 FF               [12] 1646 	mov	r7,a
      0048E3 90 06 55         [24] 1647 	mov	dptr,#(_td_record+0x0007)
      0048E6 EE               [12] 1648 	mov	a,r6
      0048E7 F0               [24] 1649 	movx	@dptr,a
      0048E8 EF               [12] 1650 	mov	a,r7
      0048E9 A3               [24] 1651 	inc	dptr
      0048EA F0               [24] 1652 	movx	@dptr,a
      0048EB 22               [24] 1653 	ret
                                   1654 
                                   1655 	.area CSEG (CODE)
                                   1656 ; function ak820_outline_0035
      0048EC                       1657 _ak820_outline_0035:
      0048EC FA               [12] 1658 	mov	r2,a
      0048ED E4               [12] 1659 	clr	a
      0048EE 3F               [12] 1660 	addc	a,r7
      0048EF FB               [12] 1661 	mov	r3,a
      0048F0 8A 82            [24] 1662 	mov	dpl,r2
      0048F2 8B 83            [24] 1663 	mov	dph,r3
      0048F4 E0               [24] 1664 	movx	a,@dptr
      0048F5 22               [24] 1665 	ret
                                   1666 
                                   1667 	.area CSEG (CODE)
                                   1668 ; function ak820_outline_0038
      0048F6                       1669 _ak820_outline_0038:
      0048F6 E0               [24] 1670 	movx	a,@dptr
      0048F7 F5 F0            [12] 1671 	mov	b,a
      0048F9 A3               [24] 1672 	inc	dptr
      0048FA E0               [24] 1673 	movx	a,@dptr
      0048FB 45 F0            [12] 1674 	orl	a,b
      0048FD 22               [24] 1675 	ret
                                   1676 
                                   1677 	.area CSEG (CODE)
                                   1678 ; function ak820_outline_0041
      0048FE                       1679 _ak820_outline_0041:
      0048FE 8D 82            [24] 1680 	mov	dpl,r5
      004900 8E 83            [24] 1681 	mov	dph,r6
      004902 A3               [24] 1682 	inc	dptr
      004903 A3               [24] 1683 	inc	dptr
      004904 A3               [24] 1684 	inc	dptr
      004905 22               [24] 1685 	ret
                                   1686 
                                   1687 	.area CSEG (CODE)
                                   1688 ; function ak820_outline_0044
      004906                       1689 _ak820_outline_0044:
      004906 24 CE            [12] 1690 	add	a,#_td_map
      004908 F5 82            [12] 1691 	mov	dpl,a
      00490A E4               [12] 1692 	clr	a
      00490B 34 05            [12] 1693 	addc	a,#(_td_map>>8)
      00490D F5 83            [12] 1694 	mov	dph,a
      00490F 22               [24] 1695 	ret
                                   1696 
                                   1697 	.area CSEG (CODE)
                                   1698 ; function ak820_outline_0053
      004910                       1699 _ak820_outline_0053:
      004910 FC               [12] 1700 	mov	r4,a
      004911 8B 82            [24] 1701 	mov	dpl,r3
      004913 8C 83            [24] 1702 	mov	dph,r4
      004915 E0               [24] 1703 	movx	a,@dptr
      004916 FA               [12] 1704 	mov	r2,a
      004917 22               [24] 1705 	ret
                                   1706 
                                   1707 	.area CSEG (CODE)
                                   1708 ; function ak820_outline_0066
      004918                       1709 _ak820_outline_0066:
      004918 EE               [12] 1710 	mov	a,r6
      004919 F0               [24] 1711 	movx	@dptr,a
      00491A EF               [12] 1712 	mov	a,r7
      00491B A3               [24] 1713 	inc	dptr
      00491C F0               [24] 1714 	movx	@dptr,a
      00491D 22               [24] 1715 	ret
                                   1716 
                                   1717 	.area CSEG (CODE)
                                   1718 ; function ak820_outline_0123
      00491E                       1719 _ak820_outline_0123:
      00491E 74 02            [12] 1720 	mov	a,#0x02
      004920 2E               [12] 1721 	add	a,r6
      004921 FE               [12] 1722 	mov	r6,a
      004922 E4               [12] 1723 	clr	a
      004923 3F               [12] 1724 	addc	a,r7
      004924 FF               [12] 1725 	mov	r7,a
      004925 22               [24] 1726 	ret
                                   1727 
                                   1728 	.area CSEG (CODE)
                                   1729 ; function ak820_outline_0146
      004926                       1730 _ak820_outline_0146:
      004926 E4               [12] 1731 	clr	a
      004927 F0               [24] 1732 	movx	@dptr,a
      004928 A3               [24] 1733 	inc	dptr
      004929 F0               [24] 1734 	movx	@dptr,a
      00492A 22               [24] 1735 	ret
                                   1736 
                                   1737 	.area CSEG (CODE)
                                   1738 ; function ak820_outline_0150
      00492B                       1739 _ak820_outline_0150:
      00492B F0               [24] 1740 	movx	@dptr,a
      00492C 90 06 55         [24] 1741 	mov	dptr,#(_td_record+0x0007)
      00492F E0               [24] 1742 	movx	a,@dptr
      004930 FE               [12] 1743 	mov	r6,a
      004931 A3               [24] 1744 	inc	dptr
      004932 E0               [24] 1745 	movx	a,@dptr
      004933 4E               [12] 1746 	orl	a,r6
      004934 22               [24] 1747 	ret
                                   1748 
                                   1749 	.area CSEG (CODE)
                                   1750 ; function ak820_outline_0162
      004935                       1751 _ak820_outline_0162:
      004935 F0               [24] 1752 	movx	@dptr,a
      004936 EB               [12] 1753 	mov	a,r3
      004937 A3               [24] 1754 	inc	dptr
      004938 F0               [24] 1755 	movx	@dptr,a
      004939 22               [24] 1756 	ret
                                   1757 
                                   1758 	.area CSEG (CODE)
                                   1759 ; function ak820_outline_0173
      00493A                       1760 _ak820_outline_0173:
      00493A E0               [24] 1761 	movx	a,@dptr
      00493B FB               [12] 1762 	mov	r3,a
      00493C A3               [24] 1763 	inc	dptr
      00493D E0               [24] 1764 	movx	a,@dptr
      00493E 4B               [12] 1765 	orl	a,r3
      00493F 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0188
      004940                       1770 _ak820_outline_0188:
      004940 8C 82            [24] 1771 	mov	dpl,r4
      004942 8F 83            [24] 1772 	mov	dph,r7
      004944 22               [24] 1773 	ret
