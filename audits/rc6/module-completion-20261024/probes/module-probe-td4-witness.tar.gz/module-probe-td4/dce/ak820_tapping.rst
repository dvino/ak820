                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      000011                        552 _ak820_tapping_before_sloc0_1_0:
      000011                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      000667                        562 _source_state:
      000667                        563 	.ds 130
      0006E9                        564 _pending_time:
      0006E9                        565 	.ds 2
      0006EB                        566 _pending_code:
      0006EB                        567 	.ds 2
      0006ED                        568 _ak820_tapping_source_PARM_1:
      0006ED                        569 	.ds 2
      0006EF                        570 _hold_PARM_2:
      0006EF                        571 	.ds 1
      0006F0                        572 _hold_code_10000_603:
      0006F0                        573 	.ds 2
      0006F2                        574 _hold_mods_30000_606:
      0006F2                        575 	.ds 1
      0006F3                        576 _commit_pending_id_10000_612:
      0006F3                        577 	.ds 1
      0006F4                        578 _ak820_tapping_before_event_10000_613:
      0006F4                        579 	.ds 2
      0006F6                        580 _ak820_tapping_process_record_10000_624:
      0006F6                        581 	.ds 2
      0006F8                        582 _ak820_tapping_process_code_10000_625:
      0006F8                        583 	.ds 2
      0006FA                        584 _ak820_tapping_process_sc_mods_10000_625:
      0006FA                        585 	.ds 1
      0006FB                        586 _ak820_oneshot_mods::
      0006FB                        587 	.ds 1
      0006FC                        588 _ak820_oneshot_consumed::
      0006FC                        589 	.ds 1
      0006FD                        590 _ak820_oneshot_process_PARM_2:
      0006FD                        591 	.ds 1
      0006FE                        592 _ak820_oneshot_process_PARM_3:
      0006FE                        593 	.ds 1
      0006FF                        594 _ak820_oneshot_process_code_10000_650:
      0006FF                        595 	.ds 2
      000701                        596 _ak820_oneshot_process_mods_10000_651:
      000701                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E94                        606 _pending:
      000E94                        607 	.ds 1
      000E95                        608 _ak820_oneshot_target::
      000E95                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004945                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004945 90 06 EE         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004948 E0               [24]  656 	movx	a,@dptr
      004949 FF               [12]  657 	mov	r7,a
      00494A BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      00494D                        659 00147$:
      00494D 50 14            [24]  660 	jnc	00102$
      00494F 90 06 ED         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      004952 E0               [24]  662 	movx	a,@dptr
      004953 FE               [12]  663 	mov	r6,a
      004954 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      004957                        665 00149$:
      004957 50 0A            [24]  666 	jnc	00102$
      004959 8F 05            [24]  667 	mov	ar5,r7
      00495B ED               [12]  668 	mov	a,r5
      00495C 12 38 BC         [24]  669 	lcall	_ak820_outline_0176
      00495F 2E               [12]  670 	add	a,r6
      004960 F5 82            [12]  671 	mov	dpl,a
      004962 22               [24]  672 	ret
      004963                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004963 90 06 ED         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      004966 E0               [24]  676 	movx	a,@dptr
      004967 FE               [12]  677 	mov	r6,a
      004968 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      00496B                        679 00151$:
      00496B 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      00496D BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      004970 75 82 80         [24]  683 	mov	dpl, #0x80
      004973 22               [24]  684 	ret
      004974                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004974 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004977 75 82 81         [24]  688 	mov	dpl, #0x81
      00497A 22               [24]  689 	ret
      00497B                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      00497B 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      00497E 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      00497F                        707 _hold:
      00497F 12 38 7A         [24]  708 	lcall	_ak820_outline_0106
      004982 90 06 F0         [24]  709 	mov	dptr,#_hold_code_10000_603
      004985 12 38 75         [24]  710 	lcall	_ak820_outline_0105
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004988 90 06 F0         [24]  712 	mov	dptr,#_hold_code_10000_603
      00498B 12 4D DC         [24]  713 	lcall	_ak820_outline_0012
      00498E 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004990 2D               [12]  715 	add	a,r5
      004991 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      004993 8F 05            [24]  718 	mov	ar5,r7
      004995 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004998 90 06 F2         [24]  720 	mov	dptr,#_hold_mods_30000_606
      00499B ED               [12]  721 	mov	a,r5
      00499C F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      00499D ED               [12]  724 	mov	a,r5
      00499E 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0049A1 ED               [12]  726 	mov	a,r5
      0049A2 C4               [12]  727 	swap	a
      0049A3 54 F0            [12]  728 	anl	a,#0xf0
      0049A5 90 06 F2         [24]  729 	mov	dptr,#_hold_mods_30000_606
      0049A8 F0               [24]  730 	movx	@dptr,a
      0049A9                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0049A9 90 06 EF         [24]  733 	mov	dptr,#_hold_PARM_2
      0049AC E0               [24]  734 	movx	a,@dptr
      0049AD 60 09            [24]  735 	jz	00104$
      0049AF 90 06 F2         [24]  736 	mov	dptr,#_hold_mods_30000_606
      0049B2 E0               [24]  737 	movx	a,@dptr
      0049B3 F5 82            [12]  738 	mov	dpl,a
      0049B5 02 7B 08         [24]  739 	ljmp	_register_mods
      0049B8                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      0049B8 90 06 F2         [24]  742 	mov	dptr,#_hold_mods_30000_606
      0049BB E0               [24]  743 	movx	a,@dptr
      0049BC F5 82            [12]  744 	mov	dpl,a
      0049BE 02 7B 1C         [24]  745 	ljmp	_unregister_mods
      0049C1                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      0049C1 8F 06            [24]  748 	mov	ar6,r7
      0049C3 74 0F            [12]  749 	mov	a,#0x0f
      0049C5 5E               [12]  750 	anl	a,r6
      0049C6 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      0049C7 90 06 EF         [24]  753 	mov	dptr,#_hold_PARM_2
      0049CA E0               [24]  754 	movx	a,@dptr
      0049CB 60 05            [24]  755 	jz	00107$
      0049CD 8F 82            [24]  756 	mov	dpl, r7
      0049CF 02 7C C4         [24]  757 	ljmp	_layer_hold_on
      0049D2                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      0049D2 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0049D4 02 7C FB         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      0049D7                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      0049D7 90 0E 94         [24]  774 	mov	dptr,#_pending
      0049DA E0               [24]  775 	movx	a,@dptr
      0049DB 90 06 F3         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      0049DE F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      0049DF 12 4E 16         [24]  779 	lcall	_ak820_outline_0159
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      0049E2 90 06 F3         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      0049E5 E0               [24]  782 	movx	a,@dptr
      0049E6 24 67            [12]  783 	add	a,#_source_state
      0049E8 FF               [12]  784 	mov	r7,a
      0049E9 E4               [12]  785 	clr	a
      0049EA 34 06            [12]  786 	addc	a, #(_source_state >> 8)
      0049EC FE               [12]  787 	mov	r6,a
      0049ED 12 43 77         [24]  788 	lcall	_ak820_outline_0160
      0049F0 E0               [24]  789 	movx	a,@dptr
      0049F1 FD               [12]  790 	mov	r5,a
      0049F2 43 05 04         [24]  791 	orl	ar5,#0x04
      0049F5 12 43 77         [24]  792 	lcall	_ak820_outline_0160
      0049F8 ED               [12]  793 	mov	a,r5
      0049F9 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      0049FA 90 06 EB         [24]  796 	mov	dptr,#_pending_code
      0049FD 12 38 2E         [24]  797 	lcall	_ak820_outline_0059
      004A00 90 06 EF         [24]  798 	mov	dptr,#_hold_PARM_2
      004A03 74 01            [12]  799 	mov	a,#0x01
      004A05 12 43 43         [24]  800 	lcall	_ak820_outline_0072
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004A08 21 7F            [12]  802 	ajmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      004A0A                        813 _ak820_tapping_before:
      004A0A 12 38 7A         [24]  814 	lcall	_ak820_outline_0106
      004A0D 90 06 F4         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004A10 12 38 75         [24]  816 	lcall	_ak820_outline_0105
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004A13 90 06 F4         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004A16 12 4D DC         [24]  819 	lcall	_ak820_outline_0012
      004A19 12 4D F5         [24]  820 	lcall	_ak820_outline_0025
      004A1C C0 07            [24]  821 	push	ar7
      004A1E C0 06            [24]  822 	push	ar6
      004A20 12 BE 0C         [24]  823 	lcall	___memcpy
      004A23 31 45            [12]  824 	acall	_ak820_tapping_source
      004A25 AD 82            [24]  825 	mov	r5, dpl
      004A27 D0 06            [24]  826 	pop	ar6
      004A29 D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004A2B 90 0F 05         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      004A2E E0               [24]  830 	movx	a,@dptr
      004A2F 60 29            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004A31 74 04            [12]  833 	mov	a,#0x04
      004A33 12 48 BF         [24]  834 	lcall	_ak820_outline_0013
      004A36 60 1E            [24]  835 	jz	00102$
      004A38 BD FF 02         [24]  836 	cjne	r5,#0xff,00218$
      004A3B 80 19            [24]  837 	sjmp	00102$
      004A3D                        838 00218$:
      004A3D 74 05            [12]  839 	mov	a,#0x05
      004A3F 12 48 BF         [24]  840 	lcall	_ak820_outline_0013
      004A42 70 12            [24]  841 	jnz	00102$
      004A44 ED               [12]  842 	mov	a,r5
      004A45 24 67            [12]  843 	add	a, #_source_state
      004A47 FB               [12]  844 	mov	r3,a
      004A48 E4               [12]  845 	clr	a
      004A49 34 06            [12]  846 	addc	a, #(_source_state >> 8)
      004A4B 12 49 10         [24]  847 	lcall	_ak820_outline_0053
      004A4E 53 02 FD         [24]  848 	anl	ar2,#0xfd
      004A51 12 33 FC         [24]  849 	lcall	_ak820_outline_0125
      004A54 EA               [12]  850 	mov	a,r2
      004A55 F0               [24]  851 	movx	@dptr,a
      004A56                        852 00102$:
                                    853 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004A56 75 82 00         [24]  854 	mov	dpl, #0x00
      004A59 22               [24]  855 	ret
      004A5A                        856 00106$:
                                    857 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004A5A 90 0E 94         [24]  858 	mov	dptr,#_pending
      004A5D E0               [24]  859 	movx	a,@dptr
      004A5E FC               [12]  860 	mov	r4,a
      004A5F BC FF 02         [24]  861 	cjne	r4,#0xff,00220$
      004A62 80 3B            [24]  862 	sjmp	00108$
      004A64                        863 00220$:
      004A64 12 38 1E         [24]  864 	lcall	_ak820_outline_0034
      004A67 FA               [12]  865 	mov	r2,a
      004A68 A3               [24]  866 	inc	dptr
      004A69 E0               [24]  867 	movx	a,@dptr
      004A6A FB               [12]  868 	mov	r3,a
      004A6B 90 06 E9         [24]  869 	mov	dptr,#_pending_time
      004A6E 12 38 63         [24]  870 	lcall	_ak820_outline_0098
      004A71 EA               [12]  871 	mov	a,r2
      004A72 C3               [12]  872 	clr	c
      004A73 98               [12]  873 	subb	a,r0
      004A74 FA               [12]  874 	mov	r2,a
      004A75 EB               [12]  875 	mov	a,r3
      004A76 99               [12]  876 	subb	a,r1
      004A77 FB               [12]  877 	mov	r3,a
      004A78 C3               [12]  878 	clr	c
      004A79 EA               [12]  879 	mov	a,r2
      004A7A 94 C8            [12]  880 	subb	a,#0xc8
      004A7C EB               [12]  881 	mov	a,r3
      004A7D 94 00            [12]  882 	subb	a,#0x00
      004A7F 50 18            [24]  883 	jnc	00107$
                                    884 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004A81 74 04            [12]  885 	mov	a,#0x04
      004A83 2E               [12]  886 	add	a, r6
      004A84 12 48 EC         [24]  887 	lcall	_ak820_outline_0035
      004A87 60 16            [24]  888 	jz	00108$
      004A89 12 37 E6         [24]  889 	lcall	_ak820_outline_0006
      004A8C 60 11            [24]  890 	jz	00108$
      004A8E BD FF 02         [24]  891 	cjne	r5,#0xff,00224$
      004A91 80 06            [24]  892 	sjmp	00107$
      004A93                        893 00224$:
      004A93 ED               [12]  894 	mov	a,r5
      004A94 B5 04 02         [24]  895 	cjne	a,ar4,00225$
      004A97 80 06            [24]  896 	sjmp	00108$
      004A99                        897 00225$:
      004A99                        898 00107$:
      004A99 C0 05            [24]  899 	push	ar5
      004A9B 31 D7            [12]  900 	acall	_commit_pending
      004A9D D0 05            [24]  901 	pop	ar5
      004A9F                        902 00108$:
                                    903 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004A9F 90 06 F4         [24]  904 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004AA2 12 38 2E         [24]  905 	lcall	_ak820_outline_0059
      004AA5 74 04            [12]  906 	mov	a,#0x04
      004AA7 12 48 BF         [24]  907 	lcall	_ak820_outline_0013
      004AAA 60 03            [24]  908 	jz	00114$
      004AAC BD FF 04         [24]  909 	cjne	r5,#0xff,00115$
      004AAF                        910 00114$:
      004AAF 75 82 01         [24]  911 	mov	dpl, #0x01
      004AB2 22               [24]  912 	ret
      004AB3                        913 00115$:
                                    914 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004AB3 ED               [12]  915 	mov	a,r5
      004AB4 24 67            [12]  916 	add	a, #_source_state
      004AB6 FC               [12]  917 	mov	r4,a
      004AB7 E4               [12]  918 	clr	a
      004AB8 34 06            [12]  919 	addc	a, #(_source_state >> 8)
      004ABA FD               [12]  920 	mov	r5,a
      004ABB 12 43 49         [24]  921 	lcall	_ak820_outline_0083
      004ABE FB               [12]  922 	mov	r3,a
      004ABF 30 E1 12         [24]  923 	jnb	acc.1,00120$
                                    924 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004AC2 74 05            [12]  925 	mov	a,#0x05
      004AC4 2E               [12]  926 	add	a, r6
      004AC5 12 38 03         [24]  927 	lcall	_ak820_outline_0017
      004AC8 70 06            [24]  928 	jnz	00118$
      004ACA 74 FD            [12]  929 	mov	a,#0xfd
      004ACC 5B               [12]  930 	anl	a,r3
      004ACD 12 43 61         [24]  931 	lcall	_ak820_outline_0127
      004AD0                        932 00118$:
                                    933 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004AD0 75 82 00         [24]  934 	mov	dpl, #0x00
      004AD3 22               [24]  935 	ret
      004AD4                        936 00120$:
                                    937 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004AD4 12 42 FF         [24]  938 	lcall	_ak820_outline_0011
      004AD7 E0               [24]  939 	movx	a,@dptr
      004AD8 FF               [12]  940 	mov	r7,a
      004AD9 8B 06            [24]  941 	mov	ar6,r3
      004ADB 53 06 01         [24]  942 	anl	ar6,#0x01
      004ADE EE               [12]  943 	mov	a,r6
      004ADF B4 01 00         [24]  944 	cjne	a,#0x01,00231$
      004AE2                        945 00231$:
      004AE2 B3               [12]  946 	cpl	c
      004AE3 92 11            [24]  947 	mov	_ak820_tapping_before_sloc0_1_0,c
      004AE5 8F F0            [24]  948 	mov	b,r7
      004AE7 E4               [12]  949 	clr	a
      004AE8 33               [12]  950 	rlc	a
      004AE9 B5 F0 04         [24]  951 	cjne	a,b,00122$
      004AEC 75 82 00         [24]  952 	mov	dpl, #0x00
      004AEF 22               [24]  953 	ret
      004AF0                        954 00122$:
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004AF0 63 03 01         [24]  956 	xrl	ar3,#0x01
      004AF3 12 38 98         [24]  957 	lcall	_ak820_outline_0129
      004AF6 EB               [12]  958 	mov	a,r3
      004AF7 F0               [24]  959 	movx	@dptr,a
                                    960 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004AF8 75 82 01         [24]  961 	mov	dpl, #0x01
                                    962 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004AFB 22               [24]  963 	ret
                                    964 ;------------------------------------------------------------
                                    965 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    966 ;------------------------------------------------------------
                                    967 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    968 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    969 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    970 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    971 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    972 ;------------------------------------------------------------
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    974 ;	-----------------------------------------
                                    975 ;	 function ak820_tapping_process
                                    976 ;	-----------------------------------------
      004AFC                        977 _ak820_tapping_process:
      004AFC 12 38 7A         [24]  978 	lcall	_ak820_outline_0106
      004AFF 90 06 F6         [24]  979 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B02 12 38 75         [24]  980 	lcall	_ak820_outline_0105
                                    981 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004B05 90 06 FA         [24]  982 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B08 E4               [12]  983 	clr	a
      004B09 F0               [24]  984 	movx	@dptr,a
                                    985 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004B0A 90 06 F6         [24]  986 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B0D 12 38 2E         [24]  987 	lcall	_ak820_outline_0059
      004B10 74 04            [12]  988 	mov	a,#0x04
      004B12 12 48 CA         [24]  989 	lcall	_ak820_outline_0014
      004B15 70 04            [24]  990 	jnz	00102$
      004B17 75 82 01         [24]  991 	mov	dpl, #0x01
      004B1A 22               [24]  992 	ret
      004B1B                        993 00102$:
                                    994 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004B1B 8E 04            [24]  995 	mov	ar4,r6
      004B1D 8F 05            [24]  996 	mov	ar5,r7
      004B1F 12 4D F5         [24]  997 	lcall	_ak820_outline_0025
      004B22 C0 07            [24]  998 	push	ar7
      004B24 C0 06            [24]  999 	push	ar6
      004B26 12 BE 0C         [24] 1000 	lcall	___memcpy
      004B29 31 45            [12] 1001 	acall	_ak820_tapping_source
      004B2B AD 82            [24] 1002 	mov	r5, dpl
      004B2D D0 06            [24] 1003 	pop	ar6
      004B2F D0 07            [24] 1004 	pop	ar7
                                   1005 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004B31 BD FF 04         [24] 1006 	cjne	r5,#0xff,00104$
      004B34 75 82 01         [24] 1007 	mov	dpl, #0x01
      004B37 22               [24] 1008 	ret
      004B38                       1009 00104$:
                                   1010 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004B38 74 07            [12] 1011 	mov	a,#0x07
      004B3A 12 38 15         [24] 1012 	lcall	_ak820_outline_0020
      004B3D FE               [12] 1013 	mov	r6,a
      004B3E A3               [24] 1014 	inc	dptr
      004B3F E0               [24] 1015 	movx	a,@dptr
      004B40 FF               [12] 1016 	mov	r7,a
      004B41 90 06 F8         [24] 1017 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B44 12 49 18         [24] 1018 	lcall	_ak820_outline_0066
                                   1019 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004B47 BE 1A 15         [24] 1020 	cjne	r6,#0x1a,00111$
      004B4A BF 7C 12         [24] 1021 	cjne	r7,#0x7c,00111$
      004B4D 90 06 F8         [24] 1022 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B50 74 26            [12] 1023 	mov	a,#0x26
      004B52 F0               [24] 1024 	movx	@dptr,a
      004B53 74 22            [12] 1025 	mov	a,#0x22
      004B55 A3               [24] 1026 	inc	dptr
      004B56 F0               [24] 1027 	movx	@dptr,a
      004B57 90 06 FA         [24] 1028 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B5A 74 02            [12] 1029 	mov	a,#0x02
      004B5C F0               [24] 1030 	movx	@dptr,a
      004B5D 80 28            [24] 1031 	sjmp	00112$
      004B5F                       1032 00111$:
                                   1033 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004B5F BE 1B 15         [24] 1034 	cjne	r6,#0x1b,00108$
      004B62 BF 7C 12         [24] 1035 	cjne	r7,#0x7c,00108$
      004B65 90 06 F8         [24] 1036 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B68 74 27            [12] 1037 	mov	a,#0x27
      004B6A F0               [24] 1038 	movx	@dptr,a
      004B6B 74 32            [12] 1039 	mov	a,#0x32
      004B6D A3               [24] 1040 	inc	dptr
      004B6E F0               [24] 1041 	movx	@dptr,a
      004B6F 90 06 FA         [24] 1042 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B72 74 20            [12] 1043 	mov	a,#0x20
      004B74 F0               [24] 1044 	movx	@dptr,a
      004B75 80 10            [24] 1045 	sjmp	00112$
      004B77                       1046 00108$:
                                   1047 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004B77 BE 1E 0D         [24] 1048 	cjne	r6,#0x1e,00112$
      004B7A BF 7C 0A         [24] 1049 	cjne	r7,#0x7c,00112$
      004B7D 90 06 F8         [24] 1050 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B80 74 28            [12] 1051 	mov	a,#0x28
      004B82 F0               [24] 1052 	movx	@dptr,a
      004B83 74 32            [12] 1053 	mov	a,#0x32
      004B85 A3               [24] 1054 	inc	dptr
      004B86 F0               [24] 1055 	movx	@dptr,a
      004B87                       1056 00112$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004B87 90 06 F8         [24] 1058 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B8A E0               [24] 1059 	movx	a,@dptr
      004B8B A3               [24] 1060 	inc	dptr
      004B8C E0               [24] 1061 	movx	a,@dptr
      004B8D FF               [12] 1062 	mov	r7,a
                                   1063 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004B8E BF 20 00         [24] 1064 	cjne	r7,#0x20,00242$
      004B91                       1065 00242$:
      004B91 40 05            [24] 1066 	jc	00113$
      004B93 BF 50 00         [24] 1067 	cjne	r7,#0x50,00244$
      004B96                       1068 00244$:
      004B96 40 04            [24] 1069 	jc	00114$
      004B98                       1070 00113$:
      004B98 75 82 01         [24] 1071 	mov	dpl, #0x01
      004B9B 22               [24] 1072 	ret
      004B9C                       1073 00114$:
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004B9C BF 40 00         [24] 1075 	cjne	r7,#0x40,00246$
      004B9F                       1076 00246$:
      004B9F 40 0C            [24] 1077 	jc	00117$
      004BA1 53 07 0F         [24] 1078 	anl	ar7,#0x0f
      004BA4 BF 06 00         [24] 1079 	cjne	r7,#0x06,00248$
      004BA7                       1080 00248$:
      004BA7 40 04            [24] 1081 	jc	00117$
      004BA9 75 82 00         [24] 1082 	mov	dpl, #0x00
      004BAC 22               [24] 1083 	ret
      004BAD                       1084 00117$:
                                   1085 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004BAD 90 06 F6         [24] 1086 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004BB0 12 38 2E         [24] 1087 	lcall	_ak820_outline_0059
      004BB3 74 05            [12] 1088 	mov	a,#0x05
      004BB5 12 48 BF         [24] 1089 	lcall	_ak820_outline_0013
      004BB8 60 20            [24] 1090 	jz	00131$
                                   1091 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004BBA 90 0E 94         [24] 1092 	mov	dptr,#_pending
      004BBD ED               [12] 1093 	mov	a,r5
      004BBE F0               [24] 1094 	movx	@dptr,a
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004BBF 12 38 1E         [24] 1096 	lcall	_ak820_outline_0034
      004BC2 FE               [12] 1097 	mov	r6,a
      004BC3 A3               [24] 1098 	inc	dptr
      004BC4 E0               [24] 1099 	movx	a,@dptr
      004BC5 FF               [12] 1100 	mov	r7,a
      004BC6 90 06 E9         [24] 1101 	mov	dptr,#_pending_time
      004BC9 12 49 18         [24] 1102 	lcall	_ak820_outline_0066
                                   1103 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004BCC 90 06 F8         [24] 1104 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BCF 12 38 2E         [24] 1105 	lcall	_ak820_outline_0059
      004BD2 90 06 EB         [24] 1106 	mov	dptr,#_pending_code
      004BD5 12 49 18         [24] 1107 	lcall	_ak820_outline_0066
      004BD8 81 77            [12] 1108 	ajmp	00132$
      004BDA                       1109 00131$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004BDA 90 0E 94         [24] 1111 	mov	dptr,#_pending
      004BDD E0               [24] 1112 	movx	a,@dptr
      004BDE FF               [12] 1113 	mov	r7,a
      004BDF ED               [12] 1114 	mov	a,r5
      004BE0 B5 07 02         [24] 1115 	cjne	a,ar7,00251$
      004BE3 80 02            [24] 1116 	sjmp	00252$
      004BE5                       1117 00251$:
      004BE5 81 51            [12] 1118 	ajmp	00128$
      004BE7                       1119 00252$:
                                   1120 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004BE7 12 4E 16         [24] 1121 	lcall	_ak820_outline_0159
                                   1122 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004BEA 90 06 FA         [24] 1123 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004BED E0               [24] 1124 	movx	a,@dptr
      004BEE FF               [12] 1125 	mov	r7,a
      004BEF E0               [24] 1126 	movx	a,@dptr
      004BF0 60 05            [24] 1127 	jz	00120$
      004BF2 8F 82            [24] 1128 	mov	dpl, r7
      004BF4 12 81 35         [24] 1129 	lcall	_add_owned_mods
      004BF7                       1130 00120$:
                                   1131 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004BF7 90 06 F6         [24] 1132 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004BFA 12 38 2E         [24] 1133 	lcall	_ak820_outline_0059
      004BFD 74 07            [12] 1134 	mov	a,#0x07
      004BFF 2E               [12] 1135 	add	a, r6
      004C00 FB               [12] 1136 	mov	r3,a
      004C01 E4               [12] 1137 	clr	a
      004C02 3F               [12] 1138 	addc	a, r7
      004C03 FC               [12] 1139 	mov	r4,a
      004C04 90 06 F8         [24] 1140 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C07 E0               [24] 1141 	movx	a,@dptr
      004C08 F9               [12] 1142 	mov	r1,a
      004C09 7A 00            [12] 1143 	mov	r2,#0x00
      004C0B 12 33 FC         [24] 1144 	lcall	_ak820_outline_0125
      004C0E E9               [12] 1145 	mov	a,r1
      004C0F F0               [24] 1146 	movx	@dptr,a
      004C10 EA               [12] 1147 	mov	a,r2
      004C11 A3               [24] 1148 	inc	dptr
      004C12 F0               [24] 1149 	movx	@dptr,a
                                   1150 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004C13 C3               [12] 1151 	clr	c
      004C14 04               [12] 1152 	inc	a
      004C15 99               [12] 1153 	subb	a,r1
      004C16 50 27            [24] 1154 	jnc	00122$
                                   1155 ;	free result
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004C18 74 06            [12] 1157 	mov	a,#0x06
      004C1A 12 38 15         [24] 1158 	lcall	_ak820_outline_0020
      004C1D 54 0F            [12] 1159 	anl	a,#0x0f
      004C1F 44 10            [12] 1160 	orl	a,#0x10
      004C21 F0               [24] 1161 	movx	@dptr,a
                                   1162 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004C22 12 42 FF         [24] 1163 	lcall	_ak820_outline_0011
      004C25 74 01            [12] 1164 	mov	a,#0x01
      004C27 12 43 43         [24] 1165 	lcall	_ak820_outline_0072
                                   1166 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004C2A 12 75 BD         [24] 1167 	lcall	_process_record
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004C2D 90 06 F6         [24] 1169 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004C30 12 37 DC         [24] 1170 	lcall	_ak820_outline_0005
      004C33 A3               [24] 1171 	inc	dptr
      004C34 A3               [24] 1172 	inc	dptr
      004C35 A3               [24] 1173 	inc	dptr
      004C36 A3               [24] 1174 	inc	dptr
      004C37 A3               [24] 1175 	inc	dptr
      004C38 E4               [12] 1176 	clr	a
      004C39 12 43 43         [24] 1177 	lcall	_ak820_outline_0072
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004C3C 12 75 BD         [24] 1179 	lcall	_process_record
      004C3F                       1180 00122$:
                                   1181 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004C3F 90 06 FA         [24] 1182 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004C42 E0               [24] 1183 	movx	a,@dptr
      004C43 FF               [12] 1184 	mov	r7,a
      004C44 E0               [24] 1185 	movx	a,@dptr
      004C45 60 30            [24] 1186 	jz	00132$
                                   1187 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004C47 8F 82            [24] 1188 	mov	dpl, r7
      004C49 12 81 44         [24] 1189 	lcall	_del_owned_mods
                                   1190 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004C4C 12 84 6A         [24] 1191 	lcall	_send_keyboard_report
      004C4F 80 26            [24] 1192 	sjmp	00132$
      004C51                       1193 00128$:
                                   1194 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004C51 ED               [12] 1195 	mov	a,r5
      004C52 24 67            [12] 1196 	add	a, #_source_state
      004C54 FE               [12] 1197 	mov	r6,a
      004C55 E4               [12] 1198 	clr	a
      004C56 34 06            [12] 1199 	addc	a, #(_source_state >> 8)
      004C58 FF               [12] 1200 	mov	r7,a
      004C59 12 38 6F         [24] 1201 	lcall	_ak820_outline_0103
      004C5C FD               [12] 1202 	mov	r5,a
      004C5D 30 E2 17         [24] 1203 	jnb	acc.2,00132$
                                   1204 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004C60 53 05 FB         [24] 1205 	anl	ar5,#0xfb
      004C63 12 38 8D         [24] 1206 	lcall	_ak820_outline_0121
      004C66 ED               [12] 1207 	mov	a,r5
      004C67 F0               [24] 1208 	movx	@dptr,a
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004C68 90 06 F8         [24] 1210 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C6B 12 38 2E         [24] 1211 	lcall	_ak820_outline_0059
      004C6E 90 06 EF         [24] 1212 	mov	dptr,#_hold_PARM_2
      004C71 E4               [12] 1213 	clr	a
      004C72 12 43 43         [24] 1214 	lcall	_ak820_outline_0072
      004C75 31 7F            [12] 1215 	acall	_hold
      004C77                       1216 00132$:
                                   1217 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004C77 75 82 00         [24] 1218 	mov	dpl, #0x00
                                   1219 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004C7A 22               [24] 1220 	ret
                                   1221 ;------------------------------------------------------------
                                   1222 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1223 ;------------------------------------------------------------
                                   1224 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1225 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1226 ;------------------------------------------------------------
                                   1227 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1228 ;	-----------------------------------------
                                   1229 ;	 function ak820_tapping_cancel
                                   1230 ;	-----------------------------------------
      004C7B                       1231 _ak820_tapping_cancel:
                                   1232 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004C7B 12 4E 16         [24] 1233 	lcall	_ak820_outline_0159
                                   1234 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004C7E 7F 00            [12] 1235 	mov	r7,#0x00
      004C80                       1236 00103$:
      004C80 BF 82 00         [24] 1237 	cjne	r7,#0x82,00122$
      004C83                       1238 00122$:
      004C83 50 16            [24] 1239 	jnc	00105$
                                   1240 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004C85 12 4D E6         [24] 1241 	lcall	_ak820_outline_0022
                                   1242 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004C88 74 02            [12] 1243 	mov	a,#0x02
      004C8A 5C               [12] 1244 	anl	a,r4
      004C8B FB               [12] 1245 	mov	r3,a
      004C8C 53 04 01         [24] 1246 	anl	ar4,#0x01
      004C8F EC               [12] 1247 	mov	a,r4
      004C90 2C               [12] 1248 	add	a,r4
      004C91 42 03            [12] 1249 	orl	ar3,a
      004C93 12 38 A7         [24] 1250 	lcall	_ak820_outline_0140
      004C96 EB               [12] 1251 	mov	a,r3
      004C97 F0               [24] 1252 	movx	@dptr,a
                                   1253 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004C98 0F               [12] 1254 	inc	r7
      004C99 80 E5            [24] 1255 	sjmp	00103$
      004C9B                       1256 00105$:
                                   1257 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004C9B 22               [24] 1258 	ret
                                   1259 ;------------------------------------------------------------
                                   1260 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1261 ;------------------------------------------------------------
                                   1262 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1263 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1264 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1265 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1266 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1267 ;------------------------------------------------------------
                                   1268 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1269 ;	-----------------------------------------
                                   1270 ;	 function ak820_oneshot_process
                                   1271 ;	-----------------------------------------
      004C9C                       1272 _ak820_oneshot_process:
      004C9C 12 38 7A         [24] 1273 	lcall	_ak820_outline_0106
      004C9F 90 06 FF         [24] 1274 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004CA2 12 38 75         [24] 1275 	lcall	_ak820_outline_0105
                                   1276 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004CA5 90 06 FD         [24] 1277 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004CA8 E0               [24] 1278 	movx	a,@dptr
      004CA9 FF               [12] 1279 	mov	r7,a
      004CAA BF FF 02         [24] 1280 	cjne	r7,#0xff,00248$
      004CAD 80 0B            [24] 1281 	sjmp	00101$
      004CAF                       1282 00248$:
      004CAF C0 07            [24] 1283 	push	ar7
      004CB1 12 A7 82         [24] 1284 	lcall	_get_repeat_key_count
      004CB4 E5 82            [12] 1285 	mov	a, dpl
      004CB6 D0 07            [24] 1286 	pop	ar7
      004CB8 60 04            [24] 1287 	jz	00102$
      004CBA                       1288 00101$:
      004CBA 75 82 01         [24] 1289 	mov	dpl, #0x01
      004CBD 22               [24] 1290 	ret
      004CBE                       1291 00102$:
                                   1292 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004CBE 90 06 FF         [24] 1293 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004CC1 E0               [24] 1294 	movx	a,@dptr
      004CC2 FD               [12] 1295 	mov	r5,a
      004CC3 A3               [24] 1296 	inc	dptr
      004CC4 E0               [24] 1297 	movx	a,@dptr
      004CC5 FB               [12] 1298 	mov	r3,a
      004CC6 BB 52 02         [24] 1299 	cjne	r3,#0x52,00250$
      004CC9 80 02            [24] 1300 	sjmp	00251$
      004CCB                       1301 00250$:
      004CCB A1 6E            [12] 1302 	ajmp	00116$
      004CCD                       1303 00251$:
      004CCD 8D 04            [24] 1304 	mov	ar4,r5
      004CCF 53 04 E0         [24] 1305 	anl	ar4,#0xe0
      004CD2 BC A0 02         [24] 1306 	cjne	r4,#0xa0,00252$
      004CD5 80 02            [24] 1307 	sjmp	00253$
      004CD7                       1308 00252$:
      004CD7 A1 6E            [12] 1309 	ajmp	00116$
      004CD9                       1310 00253$:
                                   1311 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004CD9 8D 04            [24] 1312 	mov	ar4,r5
      004CDB 53 04 0F         [24] 1313 	anl	ar4,#0x0f
      004CDE 90 07 01         [24] 1314 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CE1 EC               [12] 1315 	mov	a,r4
      004CE2 F0               [24] 1316 	movx	@dptr,a
                                   1317 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004CE3 ED               [12] 1318 	mov	a,r5
      004CE4 30 E4 08         [24] 1319 	jnb	acc.4,00105$
      004CE7 EC               [12] 1320 	mov	a,r4
      004CE8 C4               [12] 1321 	swap	a
      004CE9 54 F0            [12] 1322 	anl	a,#0xf0
      004CEB 90 07 01         [24] 1323 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CEE F0               [24] 1324 	movx	@dptr,a
      004CEF                       1325 00105$:
                                   1326 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004CEF 90 06 FE         [24] 1327 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004CF2 E0               [24] 1328 	movx	a,@dptr
      004CF3 60 2D            [24] 1329 	jz	00113$
                                   1330 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004CF5 12 4D E6         [24] 1331 	lcall	_ak820_outline_0022
      004CF8 43 04 08         [24] 1332 	orl	ar4,#0x08
      004CFB 12 43 3C         [24] 1333 	lcall	_ak820_outline_0070
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004CFE 53 04 EF         [24] 1335 	anl	ar4,#0xef
      004D01 12 43 3C         [24] 1336 	lcall	_ak820_outline_0070
                                   1337 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004D04 90 0E 95         [24] 1338 	mov	dptr,#_ak820_oneshot_target
      004D07 E0               [24] 1339 	movx	a,@dptr
      004D08 FC               [12] 1340 	mov	r4,a
      004D09 BC FF 02         [24] 1341 	cjne	r4,#0xff,00256$
      004D0C 80 09            [24] 1342 	sjmp	00107$
      004D0E                       1343 00256$:
      004D0E 12 4E 0F         [24] 1344 	lcall	_ak820_outline_0080
      004D11 43 04 10         [24] 1345 	orl	ar4,#0x10
      004D14 12 43 3C         [24] 1346 	lcall	_ak820_outline_0070
      004D17                       1347 00107$:
                                   1348 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004D17 90 07 01         [24] 1349 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D1A E0               [24] 1350 	movx	a,@dptr
      004D1B F5 82            [12] 1351 	mov	dpl,a
      004D1D 12 7B 08         [24] 1352 	lcall	_register_mods
      004D20 80 48            [24] 1353 	sjmp	00114$
      004D22                       1354 00113$:
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004D22 12 4D E6         [24] 1356 	lcall	_ak820_outline_0022
      004D25 30 E3 42         [24] 1357 	jnb	acc.3,00114$
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004D28 EC               [12] 1359 	mov	a,r4
      004D29 20 E4 24         [24] 1360 	jb	acc.4,00109$
                                   1361 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004D2C 90 06 FB         [24] 1362 	mov	dptr,#_ak820_oneshot_mods
      004D2F E0               [24] 1363 	movx	a,@dptr
      004D30 F4               [12] 1364 	cpl	a
      004D31 FC               [12] 1365 	mov	r4,a
      004D32 90 07 01         [24] 1366 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D35 E0               [24] 1367 	movx	a,@dptr
      004D36 FB               [12] 1368 	mov	r3,a
      004D37 52 04            [12] 1369 	anl	ar4,a
      004D39 8C 82            [24] 1370 	mov	dpl, r4
      004D3B C0 06            [24] 1371 	push	ar6
      004D3D C0 05            [24] 1372 	push	ar5
      004D3F C0 03            [24] 1373 	push	ar3
      004D41 12 81 35         [24] 1374 	lcall	_add_owned_mods
      004D44 D0 03            [24] 1375 	pop	ar3
      004D46 D0 05            [24] 1376 	pop	ar5
      004D48 D0 06            [24] 1377 	pop	ar6
                                   1378 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004D4A 90 06 FB         [24] 1379 	mov	dptr,#_ak820_oneshot_mods
      004D4D E0               [24] 1380 	movx	a,@dptr
      004D4E 4B               [12] 1381 	orl	a,r3
      004D4F F0               [24] 1382 	movx	@dptr,a
      004D50                       1383 00109$:
                                   1384 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004D50 90 07 01         [24] 1385 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D53 E0               [24] 1386 	movx	a,@dptr
      004D54 F5 82            [12] 1387 	mov	dpl,a
      004D56 C0 06            [24] 1388 	push	ar6
      004D58 C0 05            [24] 1389 	push	ar5
      004D5A 12 7B 1C         [24] 1390 	lcall	_unregister_mods
      004D5D D0 05            [24] 1391 	pop	ar5
      004D5F D0 06            [24] 1392 	pop	ar6
                                   1393 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004D61 12 4E 0F         [24] 1394 	lcall	_ak820_outline_0080
      004D64 53 04 E7         [24] 1395 	anl	ar4,#0xe7
      004D67 12 43 3C         [24] 1396 	lcall	_ak820_outline_0070
      004D6A                       1397 00114$:
                                   1398 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004D6A 75 82 00         [24] 1399 	mov	dpl, #0x00
      004D6D 22               [24] 1400 	ret
      004D6E                       1401 00116$:
                                   1402 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004D6E 90 06 FE         [24] 1403 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004D71 E0               [24] 1404 	movx	a,@dptr
      004D72 60 64            [24] 1405 	jz	00124$
      004D74 90 06 FF         [24] 1406 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004D77 12 38 5D         [24] 1407 	lcall	_ak820_outline_0085
      004D7A C3               [12] 1408 	clr	c
      004D7B 74 01            [12] 1409 	mov	a,#0x01
      004D7D 9D               [12] 1410 	subb	a,r5
      004D7E E4               [12] 1411 	clr	a
      004D7F 9E               [12] 1412 	subb	a,r6
      004D80 50 56            [24] 1413 	jnc	00124$
                                   1414 ;	free result
                                   1415 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004D82 C3               [12] 1416 	clr	c
      004D83 ED               [12] 1417 	mov	a,r5
      004D84 94 E0            [12] 1418 	subb	a,#0xe0
      004D86 EE               [12] 1419 	mov	a,r6
      004D87 94 00            [12] 1420 	subb	a,#0x00
      004D89 40 07            [24] 1421 	jc	00129$
      004D8B 74 E7            [12] 1422 	mov	a,#0xe7
      004D8D 9D               [12] 1423 	subb	a,r5
      004D8E E4               [12] 1424 	clr	a
      004D8F 9E               [12] 1425 	subb	a,r6
      004D90 50 46            [24] 1426 	jnc	00124$
                                   1427 ;	free result
      004D92                       1428 00129$:
                                   1429 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004D92 74 AE            [12] 1430 	mov	a,#0x100 - 0x52
      004D94 2E               [12] 1431 	add	a,r6
      004D95 50 09            [24] 1432 	jnc	00165$
      004D97 C3               [12] 1433 	clr	c
      004D98 74 DF            [12] 1434 	mov	a,#0xdf
      004D9A 9D               [12] 1435 	subb	a,r5
      004D9B 74 52            [12] 1436 	mov	a,#0x52
      004D9D 9E               [12] 1437 	subb	a,r6
      004D9E 50 38            [24] 1438 	jnc	00124$
                                   1439 ;	free result
                                   1440 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004DA0                       1441 00165$:
      004DA0 7E 00            [12] 1442 	mov	r6,#0x00
      004DA2                       1443 00131$:
      004DA2 BE 82 00         [24] 1444 	cjne	r6,#0x82,00265$
      004DA5                       1445 00265$:
      004DA5 50 1A            [24] 1446 	jnc	00120$
                                   1447 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004DA7 EE               [12] 1448 	mov	a,r6
      004DA8 24 67            [12] 1449 	add	a, #_source_state
      004DAA FC               [12] 1450 	mov	r4,a
      004DAB E4               [12] 1451 	clr	a
      004DAC 34 06            [12] 1452 	addc	a, #(_source_state >> 8)
      004DAE FD               [12] 1453 	mov	r5,a
      004DAF 12 43 49         [24] 1454 	lcall	_ak820_outline_0083
      004DB2 FB               [12] 1455 	mov	r3,a
      004DB3 30 E3 08         [24] 1456 	jnb	acc.3,00132$
      004DB6 43 03 10         [24] 1457 	orl	ar3,#0x10
      004DB9 12 38 98         [24] 1458 	lcall	_ak820_outline_0129
      004DBC EB               [12] 1459 	mov	a,r3
      004DBD F0               [24] 1460 	movx	@dptr,a
      004DBE                       1461 00132$:
                                   1462 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004DBE 0E               [12] 1463 	inc	r6
      004DBF 80 E1            [24] 1464 	sjmp	00131$
      004DC1                       1465 00120$:
                                   1466 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004DC1 90 06 FB         [24] 1467 	mov	dptr,#_ak820_oneshot_mods
      004DC4 E0               [24] 1468 	movx	a,@dptr
      004DC5 FE               [12] 1469 	mov	r6,a
      004DC6 E0               [24] 1470 	movx	a,@dptr
      004DC7 60 0F            [24] 1471 	jz	00124$
                                   1472 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004DC9 90 06 FC         [24] 1473 	mov	dptr,#_ak820_oneshot_consumed
      004DCC EE               [12] 1474 	mov	a,r6
      004DCD F0               [24] 1475 	movx	@dptr,a
                                   1476 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004DCE 90 0E 95         [24] 1477 	mov	dptr,#_ak820_oneshot_target
      004DD1 EF               [12] 1478 	mov	a,r7
      004DD2 F0               [24] 1479 	movx	@dptr,a
                                   1480 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004DD3 90 06 FB         [24] 1481 	mov	dptr,#_ak820_oneshot_mods
      004DD6 E4               [12] 1482 	clr	a
      004DD7 F0               [24] 1483 	movx	@dptr,a
      004DD8                       1484 00124$:
                                   1485 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004DD8 75 82 01         [24] 1486 	mov	dpl, #0x01
                                   1487 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004DDB 22               [24] 1488 	ret
                                   1489 	.area CSEG    (CODE)
                                   1490 	.area CONST   (CODE)
                                   1491 	.area XINIT   (CODE)
      00C6CC                       1492 __xinit__pending:
      00C6CC FF                    1493 	.db #0xff	; 255
      00C6CD                       1494 __xinit__ak820_oneshot_target:
      00C6CD FF                    1495 	.db #0xff	; 255
                                   1496 	.area CABS    (ABS,CODE)
                                   1497 
                                   1498 ; Experimental exact instruction outlining.
                                   1499 	.globl _ak820_outline_0005
                                   1500 	.globl _ak820_outline_0006
                                   1501 	.globl _ak820_outline_0011
                                   1502 	.globl _ak820_outline_0012
                                   1503 	.globl _ak820_outline_0013
                                   1504 	.globl _ak820_outline_0014
                                   1505 	.globl _ak820_outline_0017
                                   1506 	.globl _ak820_outline_0020
                                   1507 	.globl _ak820_outline_0022
                                   1508 	.globl _ak820_outline_0025
                                   1509 	.globl _ak820_outline_0034
                                   1510 	.globl _ak820_outline_0035
                                   1511 	.globl _ak820_outline_0053
                                   1512 	.globl _ak820_outline_0059
                                   1513 	.globl _ak820_outline_0066
                                   1514 	.globl _ak820_outline_0070
                                   1515 	.globl _ak820_outline_0072
                                   1516 	.globl _ak820_outline_0080
                                   1517 	.globl _ak820_outline_0083
                                   1518 	.globl _ak820_outline_0085
                                   1519 	.globl _ak820_outline_0098
                                   1520 	.globl _ak820_outline_0103
                                   1521 	.globl _ak820_outline_0105
                                   1522 	.globl _ak820_outline_0106
                                   1523 	.globl _ak820_outline_0121
                                   1524 	.globl _ak820_outline_0125
                                   1525 	.globl _ak820_outline_0127
                                   1526 	.globl _ak820_outline_0129
                                   1527 	.globl _ak820_outline_0140
                                   1528 	.globl _ak820_outline_0159
                                   1529 	.globl _ak820_outline_0160
                                   1530 	.globl _ak820_outline_0176
                                   1531 
                                   1532 	.area CSEG (CODE)
                                   1533 ; function ak820_outline_0012
      004DDC                       1534 _ak820_outline_0012:
      004DDC E0               [24] 1535 	movx	a,@dptr
      004DDD FE               [12] 1536 	mov	r6,a
      004DDE A3               [24] 1537 	inc	dptr
      004DDF E0               [24] 1538 	movx	a,@dptr
      004DE0 FF               [12] 1539 	mov	r7,a
      004DE1 8E 04            [24] 1540 	mov	ar4,r6
      004DE3 8F 05            [24] 1541 	mov	ar5,r7
      004DE5 22               [24] 1542 	ret
                                   1543 
                                   1544 	.area CSEG (CODE)
                                   1545 ; function ak820_outline_0022
      004DE6                       1546 _ak820_outline_0022:
      004DE6 EF               [12] 1547 	mov	a,r7
      004DE7 24 67            [12] 1548 	add	a,#_source_state
      004DE9 FD               [12] 1549 	mov	r5,a
      004DEA E4               [12] 1550 	clr	a
      004DEB 34 06            [12] 1551 	addc	a,#(_source_state>>8)
      004DED FE               [12] 1552 	mov	r6,a
      004DEE 8D 82            [24] 1553 	mov	dpl,r5
      004DF0 8E 83            [24] 1554 	mov	dph,r6
      004DF2 E0               [24] 1555 	movx	a,@dptr
      004DF3 FC               [12] 1556 	mov	r4,a
      004DF4 22               [24] 1557 	ret
                                   1558 
                                   1559 	.area CSEG (CODE)
                                   1560 ; function ak820_outline_0025
      004DF5                       1561 _ak820_outline_0025:
      004DF5 90 0E 84         [24] 1562 	mov	dptr,#___memcpy_PARM_2
      004DF8 EC               [12] 1563 	mov	a,r4
      004DF9 F0               [24] 1564 	movx	@dptr,a
      004DFA ED               [12] 1565 	mov	a,r5
      004DFB A3               [24] 1566 	inc	dptr
      004DFC F0               [24] 1567 	movx	@dptr,a
      004DFD E4               [12] 1568 	clr	a
      004DFE A3               [24] 1569 	inc	dptr
      004DFF F0               [24] 1570 	movx	@dptr,a
      004E00 90 0E 87         [24] 1571 	mov	dptr,#___memcpy_PARM_3
      004E03 74 02            [12] 1572 	mov	a,#0x02
      004E05 F0               [24] 1573 	movx	@dptr,a
      004E06 E4               [12] 1574 	clr	a
      004E07 A3               [24] 1575 	inc	dptr
      004E08 F0               [24] 1576 	movx	@dptr,a
      004E09 90 06 ED         [24] 1577 	mov	dptr,#_ak820_tapping_source_PARM_1
      004E0C F5 F0            [12] 1578 	mov	b,a
      004E0E 22               [24] 1579 	ret
                                   1580 
                                   1581 	.area CSEG (CODE)
                                   1582 ; function ak820_outline_0080
      004E0F                       1583 _ak820_outline_0080:
      004E0F 8D 82            [24] 1584 	mov	dpl,r5
      004E11 8E 83            [24] 1585 	mov	dph,r6
      004E13 E0               [24] 1586 	movx	a,@dptr
      004E14 FC               [12] 1587 	mov	r4,a
      004E15 22               [24] 1588 	ret
                                   1589 
                                   1590 	.area CSEG (CODE)
                                   1591 ; function ak820_outline_0159
      004E16                       1592 _ak820_outline_0159:
      004E16 90 0E 94         [24] 1593 	mov	dptr,#_pending
      004E19 74 FF            [12] 1594 	mov	a,#0xff
      004E1B F0               [24] 1595 	movx	@dptr,a
      004E1C 22               [24] 1596 	ret
