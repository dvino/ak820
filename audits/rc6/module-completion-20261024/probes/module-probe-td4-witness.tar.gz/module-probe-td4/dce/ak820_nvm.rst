                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00051D                        109 _page_data:
      00051D                        110 	.ds 64
      00055D                        111 _cached_page:
      00055D                        112 	.ds 1
      00055E                        113 _batch_depth:
      00055E                        114 	.ds 1
      00055F                        115 _first_failure_stage:
      00055F                        116 	.ds 1
      000560                        117 _nvm_fail_stage_10000_20:
      000560                        118 	.ds 1
      000561                        119 _ak820_nvm_diagnostic_out_10000_23:
      000561                        120 	.ds 2
      000563                        121 _crc_byte_PARM_2:
      000563                        122 	.ds 1
      000564                        123 _crc_byte_crc_10000_25:
      000564                        124 	.ds 2
      000566                        125 _page_crc_crc_10000_30:
      000566                        126 	.ds 2
      000568                        127 _write_page_address_10000_32:
      000568                        128 	.ds 2
      00056A                        129 _journal_header_valid_header_10000_39:
      00056A                        130 	.ds 2
      00056C                        131 _recover_journal_header_10000_46:
      00056C                        132 	.ds 9
      000575                        133 _ak820_nvm_flush_header_10000_62:
      000575                        134 	.ds 9
      00057E                        135 _ak820_nvm_flush_stage_10000_62:
      00057E                        136 	.ds 1
      00057F                        137 _load_page_page_10000_87:
      00057F                        138 	.ds 1
      000580                        139 _read_offset_offset_10000_93:
      000580                        140 	.ds 2
      000582                        141 _eeprom_read_byte_addr_10000_97:
      000582                        142 	.ds 3
      000585                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000585                        144 	.ds 3
      000588                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000588                        146 	.ds 2
      00058A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00058A                        148 	.ds 2
      00058C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058C                        150 	.ds 2
      00058E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058E                        152 	.ds 3
      000591                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      000591                        154 	.ds 2
      000593                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000593                        156 	.ds 2
      000595                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000595                        158 	.ds 3
      000598                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000598                        160 	.ds 2
      00059A                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      00059A                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B83                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B83 E5 82            [12]  215 	mov	a,dpl
      003B85 90 05 60         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B88 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B89 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003B8C 90 05 60         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B8F E0               [24]  221 	movx	a,@dptr
      003B90 90 05 5F         [24]  222 	mov	dptr,#_first_failure_stage
      003B93 F0               [24]  223 	movx	@dptr,a
      003B94                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B94 D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B96 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B97                        239 _ak820_nvm_diagnostic:
      003B97 12 38 7A         [24]  240 	lcall	_ak820_outline_0106
      003B9A 90 05 61         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B9D 12 38 75         [24]  242 	lcall	_ak820_outline_0105
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003BA0 90 05 61         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BA3 12 38 2E         [24]  245 	lcall	_ak820_outline_0059
      003BA6 A2 0B            [12]  246 	mov	c,_storage_failed
      003BA8 E4               [12]  247 	clr	a
      003BA9 33               [12]  248 	rlc	a
      003BAA 12 38 8D         [24]  249 	lcall	_ak820_outline_0121
      003BAD 12 43 43         [24]  250 	lcall	_ak820_outline_0072
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BB0 A3               [24]  252 	inc	dptr
      003BB1 A2 09            [12]  253 	mov	c,_page_valid
      003BB3 E4               [12]  254 	clr	a
      003BB4 33               [12]  255 	rlc	a
      003BB5 12 43 09         [24]  256 	lcall	_ak820_outline_0037
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BB8 A2 0A            [12]  258 	mov	c,_page_dirty
      003BBA E4               [12]  259 	clr	a
      003BBB 33               [12]  260 	rlc	a
      003BBC F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BBD 74 03            [12]  263 	mov	a,#0x03
      003BBF 12 43 7C         [24]  264 	lcall	_ak820_outline_0164
      003BC2 90 05 5E         [24]  265 	mov	dptr,#_batch_depth
      003BC5 E0               [24]  266 	movx	a,@dptr
      003BC6 12 43 61         [24]  267 	lcall	_ak820_outline_0127
                                    268 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BC9 74 04            [12]  269 	mov	a,#0x04
      003BCB 12 43 7C         [24]  270 	lcall	_ak820_outline_0164
      003BCE 90 05 5D         [24]  271 	mov	dptr,#_cached_page
      003BD1 E0               [24]  272 	movx	a,@dptr
      003BD2 12 43 61         [24]  273 	lcall	_ak820_outline_0127
                                    274 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003BD5 12 42 FF         [24]  275 	lcall	_ak820_outline_0011
      003BD8 E4               [12]  276 	clr	a
      003BD9 F0               [24]  277 	movx	@dptr,a
                                    278 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BDA 74 06            [12]  279 	mov	a,#0x06
      003BDC 2E               [12]  280 	add	a, r6
      003BDD FE               [12]  281 	mov	r6,a
      003BDE E4               [12]  282 	clr	a
      003BDF 3F               [12]  283 	addc	a, r7
      003BE0 FF               [12]  284 	mov	r7,a
      003BE1 90 05 5F         [24]  285 	mov	dptr,#_first_failure_stage
      003BE4 E0               [24]  286 	movx	a,@dptr
      003BE5 12 38 8D         [24]  287 	lcall	_ak820_outline_0121
      003BE8 F0               [24]  288 	movx	@dptr,a
                                    289 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BE9 22               [24]  290 	ret
                                    291 ;------------------------------------------------------------
                                    292 ;Allocation info for local variables in function 'crc_byte'
                                    293 ;------------------------------------------------------------
                                    294 ;value         Allocated with name '_crc_byte_PARM_2'
                                    295 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    296 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    297 ;------------------------------------------------------------
                                    298 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    299 ;	-----------------------------------------
                                    300 ;	 function crc_byte
                                    301 ;	-----------------------------------------
      003BEA                        302 _crc_byte:
      003BEA 12 38 7A         [24]  303 	lcall	_ak820_outline_0106
      003BED 90 05 64         [24]  304 	mov	dptr,#_crc_byte_crc_10000_25
      003BF0 12 38 75         [24]  305 	lcall	_ak820_outline_0105
                                    306 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BF3 90 05 63         [24]  307 	mov	dptr,#_crc_byte_PARM_2
      003BF6 E0               [24]  308 	movx	a,@dptr
      003BF7 FF               [12]  309 	mov	r7,a
      003BF8 7E 00            [12]  310 	mov	r6,#0x00
      003BFA 90 05 64         [24]  311 	mov	dptr,#_crc_byte_crc_10000_25
      003BFD E0               [24]  312 	movx	a,@dptr
      003BFE 6E               [12]  313 	xrl	a,r6
      003BFF F0               [24]  314 	movx	@dptr,a
      003C00 A3               [24]  315 	inc	dptr
      003C01 E0               [24]  316 	movx	a,@dptr
      003C02 6F               [12]  317 	xrl	a,r7
      003C03 F0               [24]  318 	movx	@dptr,a
                                    319 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C04 7F 00            [12]  320 	mov	r7,#0x00
      003C06                        321 00102$:
                                    322 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C06 90 05 64         [24]  323 	mov	dptr,#_crc_byte_crc_10000_25
      003C09 12 38 5D         [24]  324 	lcall	_ak820_outline_0085
      003C0C 30 E7 0E         [24]  325 	jnb	acc.7,00106$
      003C0F ED               [12]  326 	mov	a,r5
      003C10 2D               [12]  327 	add	a,r5
      003C11 FB               [12]  328 	mov	r3,a
      003C12 EE               [12]  329 	mov	a,r6
      003C13 33               [12]  330 	rlc	a
      003C14 FC               [12]  331 	mov	r4,a
      003C15 63 03 21         [24]  332 	xrl	ar3,#0x21
      003C18 63 04 10         [24]  333 	xrl	ar4,#0x10
      003C1B 80 06            [24]  334 	sjmp	00107$
      003C1D                        335 00106$:
      003C1D ED               [12]  336 	mov	a,r5
      003C1E 2D               [12]  337 	add	a,r5
      003C1F FB               [12]  338 	mov	r3,a
      003C20 EE               [12]  339 	mov	a,r6
      003C21 33               [12]  340 	rlc	a
      003C22 FC               [12]  341 	mov	r4,a
      003C23                        342 00107$:
      003C23 90 05 64         [24]  343 	mov	dptr,#_crc_byte_crc_10000_25
      003C26 12 38 57         [24]  344 	lcall	_ak820_outline_0082
                                    345 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C29 0F               [12]  346 	inc	r7
      003C2A BF 08 D9         [24]  347 	cjne	r7,#0x08,00102$
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C2D 12 33 FC         [24]  349 	lcall	_ak820_outline_0125
                                    350 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C30 22               [24]  351 	ret
                                    352 ;------------------------------------------------------------
                                    353 ;Allocation info for local variables in function 'page_crc'
                                    354 ;------------------------------------------------------------
                                    355 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    356 ;i             Allocated with name '_page_crc_i_10000_30'
                                    357 ;------------------------------------------------------------
                                    358 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    359 ;	-----------------------------------------
                                    360 ;	 function page_crc
                                    361 ;	-----------------------------------------
      003C31                        362 _page_crc:
                                    363 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C31 90 05 66         [24]  364 	mov	dptr,#_page_crc_crc_10000_30
      003C34 74 FF            [12]  365 	mov	a,#0xff
      003C36 F0               [24]  366 	movx	@dptr,a
      003C37 A3               [24]  367 	inc	dptr
      003C38 F0               [24]  368 	movx	@dptr,a
                                    369 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C39 7F 00            [12]  370 	mov	r7,#0x00
      003C3B                        371 00102$:
      003C3B 90 05 66         [24]  372 	mov	dptr,#_page_crc_crc_10000_30
      003C3E 12 38 5D         [24]  373 	lcall	_ak820_outline_0085
      003C41 12 43 55         [24]  374 	lcall	_ak820_outline_0108
      003C44 90 05 63         [24]  375 	mov	dptr,#_crc_byte_PARM_2
      003C47 F0               [24]  376 	movx	@dptr,a
      003C48 12 38 A7         [24]  377 	lcall	_ak820_outline_0140
      003C4B C0 07            [24]  378 	push	ar7
      003C4D 12 3B EA         [24]  379 	lcall	_crc_byte
      003C50 AD 82            [24]  380 	mov	r5, dpl
      003C52 AE 83            [24]  381 	mov	r6, dph
      003C54 D0 07            [24]  382 	pop	ar7
      003C56 90 05 66         [24]  383 	mov	dptr,#_page_crc_crc_10000_30
      003C59 12 43 82         [24]  384 	lcall	_ak820_outline_0165
      003C5C 0F               [12]  385 	inc	r7
      003C5D BF 40 DB         [24]  386 	cjne	r7,#0x40,00102$
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C60 12 38 A7         [24]  388 	lcall	_ak820_outline_0140
                                    389 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C63 22               [24]  390 	ret
                                    391 ;------------------------------------------------------------
                                    392 ;Allocation info for local variables in function 'write_page'
                                    393 ;------------------------------------------------------------
                                    394 ;address       Allocated with name '_write_page_address_10000_32'
                                    395 ;i             Allocated with name '_write_page_i_10000_33'
                                    396 ;------------------------------------------------------------
                                    397 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    398 ;	-----------------------------------------
                                    399 ;	 function write_page
                                    400 ;	-----------------------------------------
      003C64                        401 _write_page:
      003C64 12 38 7A         [24]  402 	lcall	_ak820_outline_0106
      003C67 90 05 68         [24]  403 	mov	dptr,#_write_page_address_10000_32
      003C6A 12 38 75         [24]  404 	lcall	_ak820_outline_0105
                                    405 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C6D 90 05 68         [24]  406 	mov	dptr,#_write_page_address_10000_32
      003C70 12 37 DC         [24]  407 	lcall	_ak820_outline_0005
      003C73 C0 07            [24]  408 	push	ar7
      003C75 C0 06            [24]  409 	push	ar6
      003C77 12 39 FC         [24]  410 	lcall	_ak820_flash_erase
      003C7A E5 82            [12]  411 	mov	a, dpl
      003C7C D0 06            [24]  412 	pop	ar6
      003C7E D0 07            [24]  413 	pop	ar7
      003C80 70 03            [24]  414 	jnz	00102$
      003C82 F5 82            [12]  415 	mov	dpl,a
      003C84 22               [24]  416 	ret
      003C85                        417 00102$:
                                    418 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C85 90 04 F9         [24]  419 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C88 74 1D            [12]  420 	mov	a,#_page_data
      003C8A F0               [24]  421 	movx	@dptr,a
      003C8B 74 05            [12]  422 	mov	a,#(_page_data >> 8)
      003C8D 12 43 35         [24]  423 	lcall	_ak820_outline_0064
      003C90 12 3B 10         [24]  424 	lcall	_ak820_flash_program_page
      003C93 E5 82            [12]  425 	mov	a, dpl
      003C95 70 03            [24]  426 	jnz	00120$
      003C97 F5 82            [12]  427 	mov	dpl,a
                                    428 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C99 22               [24]  429 	ret
      003C9A                        430 00120$:
      003C9A 7F 00            [12]  431 	mov	r7,#0x00
      003C9C                        432 00108$:
                                    433 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C9C 8F 05            [24]  434 	mov	ar5,r7
      003C9E 7E 00            [12]  435 	mov	r6,#0x00
      003CA0 90 05 68         [24]  436 	mov	dptr,#_write_page_address_10000_32
      003CA3 12 38 69         [24]  437 	lcall	_ak820_outline_0099
      003CA6 ED               [12]  438 	mov	a,r5
      003CA7 2B               [12]  439 	add	a, r3
      003CA8 FB               [12]  440 	mov	r3,a
      003CA9 EE               [12]  441 	mov	a,r6
      003CAA 3C               [12]  442 	addc	a, r4
      003CAB FC               [12]  443 	mov	r4,a
      003CAC 12 33 FC         [24]  444 	lcall	_ak820_outline_0125
      003CAF 12 38 EF         [24]  445 	lcall	_ak820_flash_read
      003CB2 AE 82            [24]  446 	mov	r6, dpl
      003CB4 12 43 55         [24]  447 	lcall	_ak820_outline_0108
      003CB7 FD               [12]  448 	mov	r5,a
      003CB8 EE               [12]  449 	mov	a,r6
      003CB9 B5 05 02         [24]  450 	cjne	a,ar5,00149$
      003CBC 80 04            [24]  451 	sjmp	00109$
      003CBE                        452 00149$:
      003CBE 75 82 00         [24]  453 	mov	dpl, #0x00
      003CC1 22               [24]  454 	ret
      003CC2                        455 00109$:
                                    456 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CC2 0F               [12]  457 	inc	r7
      003CC3 BF 40 D6         [24]  458 	cjne	r7,#0x40,00108$
                                    459 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CC6 75 82 01         [24]  460 	mov	dpl, #0x01
                                    461 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CC9 22               [24]  462 	ret
                                    463 ;------------------------------------------------------------
                                    464 ;Allocation info for local variables in function 'journal_header_valid'
                                    465 ;------------------------------------------------------------
                                    466 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    467 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    468 ;------------------------------------------------------------
                                    469 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    470 ;	-----------------------------------------
                                    471 ;	 function journal_header_valid
                                    472 ;	-----------------------------------------
      003CCA                        473 _journal_header_valid:
      003CCA 12 38 7A         [24]  474 	lcall	_ak820_outline_0106
      003CCD 90 05 6A         [24]  475 	mov	dptr,#_journal_header_valid_header_10000_39
      003CD0 12 38 75         [24]  476 	lcall	_ak820_outline_0105
                                    477 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003CD3 90 05 6A         [24]  478 	mov	dptr,#_journal_header_valid_header_10000_39
      003CD6 12 37 DC         [24]  479 	lcall	_ak820_outline_0005
      003CD9 E0               [24]  480 	movx	a,@dptr
      003CDA FD               [12]  481 	mov	r5,a
      003CDB BD A5 02         [24]  482 	cjne	r5,#0xa5,00138$
      003CDE 80 04            [24]  483 	sjmp	00116$
      003CE0                        484 00138$:
      003CE0 75 82 00         [24]  485 	mov	dpl, #0x00
                                    486 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CE3 22               [24]  487 	ret
      003CE4                        488 00116$:
      003CE4 7D 01            [12]  489 	mov	r5,#0x01
      003CE6                        490 00106$:
                                    491 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CE6 ED               [12]  492 	mov	a,r5
      003CE7 12 38 15         [24]  493 	lcall	_ak820_outline_0020
      003CEA FC               [12]  494 	mov	r4,a
      003CEB 8D 02            [24]  495 	mov	ar2,r5
      003CED 7B 00            [12]  496 	mov	r3,#0x00
      003CEF 74 04            [12]  497 	mov	a,#0x04
      003CF1 2A               [12]  498 	add	a, r2
      003CF2 FA               [12]  499 	mov	r2,a
      003CF3 E4               [12]  500 	clr	a
      003CF4 3B               [12]  501 	addc	a, r3
      003CF5 FB               [12]  502 	mov	r3,a
      003CF6 EA               [12]  503 	mov	a,r2
      003CF7 2E               [12]  504 	add	a, r6
      003CF8 F5 82            [12]  505 	mov	dpl,a
      003CFA EB               [12]  506 	mov	a,r3
      003CFB 3F               [12]  507 	addc	a, r7
      003CFC F5 83            [12]  508 	mov	dph,a
      003CFE E0               [24]  509 	movx	a,@dptr
      003CFF 62 04            [12]  510 	xrl	ar4,a
      003D01 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003D04 80 04            [24]  512 	sjmp	00107$
      003D06                        513 00139$:
      003D06 75 82 00         [24]  514 	mov	dpl, #0x00
      003D09 22               [24]  515 	ret
      003D0A                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D0A 0D               [12]  518 	inc	r5
      003D0B BD 05 D8         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D0E 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D11 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003D12                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D12 7F 00            [12]  538 	mov	r7,#0x00
      003D14                        539 00115$:
      003D14 EF               [12]  540 	mov	a,r7
      003D15 24 6C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003D17 FD               [12]  542 	mov	r5,a
      003D18 E4               [12]  543 	clr	a
      003D19 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D1B FE               [12]  545 	mov	r6,a
      003D1C 8F 04            [24]  546 	mov	ar4,r7
      003D1E 7B 00            [12]  547 	mov	r3,#0x00
      003D20 74 40            [12]  548 	mov	a,#0x40
      003D22 2C               [12]  549 	add	a, r4
      003D23 FC               [12]  550 	mov	r4,a
      003D24 74 EF            [12]  551 	mov	a,#0xef
      003D26 3B               [12]  552 	addc	a, r3
      003D27 FB               [12]  553 	mov	r3,a
      003D28 12 43 8D         [24]  554 	lcall	_ak820_outline_0187
      003D2B 12 38 EF         [24]  555 	lcall	_ak820_flash_read
      003D2E AC 82            [24]  556 	mov	r4, dpl
      003D30 12 43 3C         [24]  557 	lcall	_ak820_outline_0070
      003D33 0F               [12]  558 	inc	r7
      003D34 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D37 90 05 6C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003D3A 12 3C CA         [24]  562 	lcall	_journal_header_valid
      003D3D E5 82            [12]  563 	mov	a, dpl
      003D3F 70 01            [24]  564 	jnz	00103$
      003D41 22               [24]  565 	ret
      003D42                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D42 90 05 6D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D45 E0               [24]  569 	movx	a,@dptr
      003D46 FF               [12]  570 	mov	r7,a
      003D47 7E 00            [12]  571 	mov	r6,#0x00
      003D49 90 05 6E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D4C E0               [24]  573 	movx	a,@dptr
      003D4D FC               [12]  574 	mov	r4,a
      003D4E E4               [12]  575 	clr	a
      003D4F 42 07            [12]  576 	orl	ar7,a
      003D51 EC               [12]  577 	mov	a,r4
      003D52 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D54 90 05 6F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D57 E0               [24]  581 	movx	a,@dptr
      003D58 FD               [12]  582 	mov	r5,a
      003D59 7C 00            [12]  583 	mov	r4,#0x00
      003D5B 90 05 70         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D5E E0               [24]  585 	movx	a,@dptr
      003D5F FA               [12]  586 	mov	r2,a
      003D60 E4               [12]  587 	clr	a
      003D61 12 43 6C         [24]  588 	lcall	_ak820_outline_0145
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D64 C3               [12]  590 	clr	c
      003D65 EF               [12]  591 	mov	a,r7
      003D66 94 A0            [12]  592 	subb	a,#0xa0
      003D68 EE               [12]  593 	mov	a,r6
      003D69 94 00            [12]  594 	subb	a,#0x00
      003D6B 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D6D 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D70 02 3B 83         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D73                        601 00134$:
      003D73 7B 00            [12]  602 	mov	r3,#0x00
      003D75                        603 00117$:
      003D75 C0 05            [24]  604 	push	ar5
      003D77 C0 04            [24]  605 	push	ar4
      003D79 EB               [12]  606 	mov	a,r3
      003D7A 24 1D            [12]  607 	add	a, #_page_data
      003D7C F9               [12]  608 	mov	r1,a
      003D7D E4               [12]  609 	clr	a
      003D7E 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003D80 FA               [12]  611 	mov	r2,a
      003D81 8B 00            [24]  612 	mov	ar0,r3
      003D83 7D 00            [12]  613 	mov	r5,#0x00
      003D85 74 EF            [12]  614 	mov	a,#0xef
      003D87 2D               [12]  615 	add	a, r5
      003D88 FD               [12]  616 	mov	r5,a
      003D89 88 82            [24]  617 	mov	dpl, r0
      003D8B 8D 83            [24]  618 	mov	dph, r5
      003D8D 12 38 EF         [24]  619 	lcall	_ak820_flash_read
      003D90 AD 82            [24]  620 	mov	r5, dpl
      003D92 12 43 88         [24]  621 	lcall	_ak820_outline_0174
      003D95 ED               [12]  622 	mov	a,r5
      003D96 F0               [24]  623 	movx	@dptr,a
      003D97 0B               [12]  624 	inc	r3
      003D98 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      003D9B 80 06            [24]  626 	sjmp	00191$
      003D9D                        627 00190$:
      003D9D D0 04            [24]  628 	pop	ar4
      003D9F D0 05            [24]  629 	pop	ar5
      003DA1 80 D2            [24]  630 	sjmp	00117$
      003DA3                        631 00191$:
      003DA3 D0 04            [24]  632 	pop	ar4
      003DA5 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DA7 C0 07            [24]  635 	push	ar7
      003DA9 C0 06            [24]  636 	push	ar6
      003DAB C0 05            [24]  637 	push	ar5
      003DAD C0 04            [24]  638 	push	ar4
      003DAF 12 3C 31         [24]  639 	lcall	_page_crc
      003DB2 AA 82            [24]  640 	mov	r2, dpl
      003DB4 AB 83            [24]  641 	mov	r3, dph
      003DB6 D0 04            [24]  642 	pop	ar4
      003DB8 D0 05            [24]  643 	pop	ar5
      003DBA D0 06            [24]  644 	pop	ar6
      003DBC D0 07            [24]  645 	pop	ar7
      003DBE EA               [12]  646 	mov	a,r2
      003DBF B5 05 06         [24]  647 	cjne	a,ar5,00192$
      003DC2 EB               [12]  648 	mov	a,r3
      003DC3 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      003DC6 80 06            [24]  650 	sjmp	00113$
      003DC8                        651 00192$:
      003DC8 75 82 02         [24]  652 	mov	dpl, #0x02
      003DCB 02 3B 83         [24]  653 	ljmp	_nvm_fail
      003DCE                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003DCE EE               [12]  656 	mov	a,r6
      003DCF 54 03            [12]  657 	anl	a,#0x03
      003DD1 A2 E0            [12]  658 	mov	c,acc.0
      003DD3 CF               [12]  659 	xch	a,r7
      003DD4 13               [12]  660 	rrc	a
      003DD5 CF               [12]  661 	xch	a,r7
      003DD6 13               [12]  662 	rrc	a
      003DD7 A2 E0            [12]  663 	mov	c,acc.0
      003DD9 CF               [12]  664 	xch	a,r7
      003DDA 13               [12]  665 	rrc	a
      003DDB CF               [12]  666 	xch	a,r7
      003DDC 13               [12]  667 	rrc	a
      003DDD CF               [12]  668 	xch	a,r7
      003DDE 24 C7            [12]  669 	add	a,#0xc7
      003DE0 FE               [12]  670 	mov	r6,a
      003DE1 12 43 77         [24]  671 	lcall	_ak820_outline_0160
      003DE4 12 3C 64         [24]  672 	lcall	_write_page
      003DE7 E5 82            [12]  673 	mov	a, dpl
      003DE9 70 06            [24]  674 	jnz	00110$
      003DEB 75 82 03         [24]  675 	mov	dpl, #0x03
      003DEE 02 3B 83         [24]  676 	ljmp	_nvm_fail
      003DF1                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DF1 90 EF 40         [24]  679 	mov	dptr,#0xef40
      003DF4 12 39 FC         [24]  680 	lcall	_ak820_flash_erase
      003DF7 E5 82            [12]  681 	mov	a, dpl
      003DF9 70 06            [24]  682 	jnz	00119$
      003DFB 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DFE 02 3B 83         [24]  685 	ljmp	_nvm_fail
      003E01                        686 00119$:
      003E01 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      003E02                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      003E02 C2 0B            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E04 90 05 5F         [24]  700 	mov	dptr,#_first_failure_stage
      003E07 E4               [12]  701 	clr	a
      003E08 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      003E09 C2 0A            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      003E0B C2 09            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E0D 90 05 5E         [24]  709 	mov	dptr,#_batch_depth
      003E10 E4               [12]  710 	clr	a
      003E11 F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E12 12 3D 12         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E15 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      003E18                        724 _ak820_nvm_ok:
      003E18 A2 0B            [12]  725 	mov	c,_storage_failed
      003E1A B3               [12]  726 	cpl	c
      003E1B 92 0C            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E1D 12 38 AC         [24]  728 	lcall	_ak820_outline_0147
      003E20 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      003E21                        737 _ak820_nvm_schema_fault:
      003E21 75 82 10         [24]  738 	mov	dpl, #0x10
      003E24 02 3B 83         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      003E27                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E27 30 0A 03         [24]  754 	jnb	_page_dirty,00101$
      003E2A 30 0B 01         [24]  755 	jnb	_storage_failed,00102$
      003E2D                        756 00101$:
      003E2D 22               [24]  757 	ret
      003E2E                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E2E 12 3C 31         [24]  760 	lcall	_page_crc
      003E31 12 43 67         [24]  761 	lcall	_ak820_outline_0139
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E34 90 05 75         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E37 74 A5            [12]  764 	mov	a,#0xa5
      003E39 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E3A 90 05 5D         [24]  767 	mov	dptr,#_cached_page
      003E3D E0               [24]  768 	movx	a,@dptr
      003E3E 90 05 76         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E41 F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E42 90 05 77         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E45 E4               [12]  773 	clr	a
      003E46 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E47 8E 05            [24]  776 	mov	ar5,r6
      003E49 90 05 78         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E4C ED               [12]  778 	mov	a,r5
      003E4D F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E4E 8F 06            [24]  781 	mov	ar6,r7
      003E50 90 05 79         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E53 EE               [12]  783 	mov	a,r6
      003E54 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E55 7F 01            [12]  786 	mov	r7,#0x01
      003E57                        787 00128$:
      003E57 8F 06            [24]  788 	mov	ar6,r7
      003E59 EE               [12]  789 	mov	a,r6
      003E5A 24 04            [12]  790 	add	a,#0x04
      003E5C FE               [12]  791 	mov	r6,a
      003E5D 33               [12]  792 	rlc	a
      003E5E 95 E0            [12]  793 	subb	a,acc
      003E60 FD               [12]  794 	mov	r5,a
      003E61 EE               [12]  795 	mov	a,r6
      003E62 24 75            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      003E64 FE               [12]  797 	mov	r6,a
      003E65 ED               [12]  798 	mov	a,r5
      003E66 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E68 FD               [12]  800 	mov	r5,a
      003E69 12 43 18         [24]  801 	lcall	_ak820_outline_0048
      003E6C FC               [12]  802 	mov	r4,a
      003E6D 63 04 FF         [24]  803 	xrl	ar4,#0xff
      003E70 8E 82            [24]  804 	mov	dpl,r6
      003E72 8D 83            [24]  805 	mov	dph,r5
      003E74 EC               [12]  806 	mov	a,r4
      003E75 F0               [24]  807 	movx	@dptr,a
      003E76 0F               [12]  808 	inc	r7
      003E77 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E7A 90 05 7E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E7D 74 05            [12]  812 	mov	a,#0x05
      003E7F F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E80 90 EF 40         [24]  815 	mov	dptr,#0xef40
      003E83 12 39 FC         [24]  816 	lcall	_ak820_flash_erase
      003E86 E5 82            [12]  817 	mov	a, dpl
      003E88 70 03            [24]  818 	jnz	00269$
      003E8A 02 3F 71         [24]  819 	ljmp	00127$
      003E8D                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E8D 90 05 7E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E90 74 06            [12]  823 	mov	a,#0x06
      003E92 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E93 7F 00            [12]  826 	mov	r7,#0x00
      003E95                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E95 12 43 24         [24]  829 	lcall	_ak820_outline_0060
      003E98 12 38 EF         [24]  830 	lcall	_ak820_flash_read
      003E9B E5 82            [12]  831 	mov	a, dpl
      003E9D 60 03            [24]  832 	jz	00270$
      003E9F 02 3F 71         [24]  833 	ljmp	00127$
      003EA2                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EA2 0F               [12]  836 	inc	r7
      003EA3 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003EA6 90 05 7E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EA9 74 07            [12]  840 	mov	a,#0x07
      003EAB F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EAC 90 EF 00         [24]  843 	mov	dptr,#0xef00
      003EAF 12 3C 64         [24]  844 	lcall	_write_page
      003EB2 E5 82            [12]  845 	mov	a, dpl
      003EB4 70 03            [24]  846 	jnz	00273$
      003EB6 02 3F 71         [24]  847 	ljmp	00127$
      003EB9                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EB9 90 05 7E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EBC 74 08            [12]  851 	mov	a,#0x08
      003EBE F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EBF 7F 01            [12]  854 	mov	r7,#0x01
      003EC1                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003EC1 12 43 18         [24]  857 	lcall	_ak820_outline_0048
      003EC4 FE               [12]  858 	mov	r6,a
      003EC5 60 23            [24]  859 	jz	00133$
      003EC7 8F 05            [24]  860 	mov	ar5,r7
      003EC9 7C 00            [12]  861 	mov	r4,#0x00
      003ECB 74 40            [12]  862 	mov	a,#0x40
      003ECD 2D               [12]  863 	add	a, r5
      003ECE FD               [12]  864 	mov	r5,a
      003ECF 74 EF            [12]  865 	mov	a,#0xef
      003ED1 3C               [12]  866 	addc	a, r4
      003ED2 FC               [12]  867 	mov	r4,a
      003ED3 90 04 F6         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      003ED6 EE               [12]  869 	mov	a,r6
      003ED7 F0               [24]  870 	movx	@dptr,a
      003ED8 8D 82            [24]  871 	mov	dpl, r5
      003EDA 8C 83            [24]  872 	mov	dph, r4
      003EDC C0 07            [24]  873 	push	ar7
      003EDE 12 3A 5C         [24]  874 	lcall	_ak820_flash_program
      003EE1 E5 82            [12]  875 	mov	a, dpl
      003EE3 D0 07            [24]  876 	pop	ar7
      003EE5 70 03            [24]  877 	jnz	00275$
      003EE7 02 3F 71         [24]  878 	ljmp	00127$
      003EEA                        879 00275$:
      003EEA                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EEA 0F               [12]  882 	inc	r7
      003EEB BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EEE 90 05 7E         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EF1 74 09            [12]  886 	mov	a,#0x09
      003EF3 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EF4 7F 01            [12]  889 	mov	r7,#0x01
      003EF6                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EF6 12 43 24         [24]  892 	lcall	_ak820_outline_0060
      003EF9 12 38 EF         [24]  893 	lcall	_ak820_flash_read
      003EFC AE 82            [24]  894 	mov	r6, dpl
      003EFE 12 43 18         [24]  895 	lcall	_ak820_outline_0048
      003F01 FD               [12]  896 	mov	r5,a
      003F02 EE               [12]  897 	mov	a,r6
      003F03 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F06 0F               [12]  900 	inc	r7
      003F07 BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F0A 90 05 7E         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F0D 74 0A            [12]  904 	mov	a,#0x0a
      003F0F F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F10 90 05 75         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F13 E0               [24]  908 	movx	a,@dptr
      003F14 90 04 F6         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      003F17 F0               [24]  910 	movx	@dptr,a
      003F18 90 EF 40         [24]  911 	mov	dptr,#0xef40
      003F1B 12 3A 5C         [24]  912 	lcall	_ak820_flash_program
      003F1E E5 82            [12]  913 	mov	a, dpl
      003F20 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F22 90 05 7E         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F25 74 0B            [12]  917 	mov	a,#0x0b
      003F27 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F28 90 EF 40         [24]  920 	mov	dptr,#0xef40
      003F2B 12 38 EF         [24]  921 	lcall	_ak820_flash_read
      003F2E AF 82            [24]  922 	mov	r7, dpl
      003F30 90 05 75         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F33 E0               [24]  924 	movx	a,@dptr
      003F34 FE               [12]  925 	mov	r6,a
      003F35 EF               [12]  926 	mov	a,r7
      003F36 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F39 90 05 7E         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F3C 74 0C            [12]  930 	mov	a,#0x0c
      003F3E F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F3F 90 05 5D         [24]  933 	mov	dptr,#_cached_page
      003F42 E0               [24]  934 	movx	a,@dptr
      003F43 FE               [12]  935 	mov	r6,a
      003F44 E4               [12]  936 	clr	a
      003F45 C3               [12]  937 	clr	c
      003F46 CE               [12]  938 	xch	a,r6
      003F47 13               [12]  939 	rrc	a
      003F48 CE               [12]  940 	xch	a,r6
      003F49 13               [12]  941 	rrc	a
      003F4A A2 E0            [12]  942 	mov	c,acc.0
      003F4C CE               [12]  943 	xch	a,r6
      003F4D 13               [12]  944 	rrc	a
      003F4E CE               [12]  945 	xch	a,r6
      003F4F 13               [12]  946 	rrc	a
      003F50 CE               [12]  947 	xch	a,r6
      003F51 24 C7            [12]  948 	add	a,#0xc7
      003F53 FF               [12]  949 	mov	r7,a
      003F54 12 38 8D         [24]  950 	lcall	_ak820_outline_0121
      003F57 12 3C 64         [24]  951 	lcall	_write_page
      003F5A E5 82            [12]  952 	mov	a, dpl
      003F5C 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F5E 90 05 7E         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F61 74 0D            [12]  956 	mov	a,#0x0d
      003F63 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F64 90 EF 40         [24]  959 	mov	dptr,#0xef40
      003F67 12 39 FC         [24]  960 	lcall	_ak820_flash_erase
      003F6A E5 82            [12]  961 	mov	a, dpl
      003F6C 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      003F6E C2 0A            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F70 22               [24]  968 	ret
      003F71                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F71 90 05 7E         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F74 E0               [24]  972 	movx	a,@dptr
      003F75 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F77 02 3B 83         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      003F7A                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F7A 90 05 5E         [24]  985 	mov	dptr,#_batch_depth
      003F7D E0               [24]  986 	movx	a,@dptr
      003F7E FF               [12]  987 	mov	r7,a
      003F7F BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      003F82 75 82 0F         [24]  989 	mov	dpl, #0x0f
      003F85 02 3B 83         [24]  990 	ljmp	_nvm_fail
      003F88                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F88 90 05 5E         [24]  993 	mov	dptr,#_batch_depth
      003F8B EF               [12]  994 	mov	a,r7
      003F8C 04               [12]  995 	inc	a
      003F8D F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F8E 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      003F8F                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F8F 90 05 5E         [24] 1008 	mov	dptr,#_batch_depth
      003F92 E0               [24] 1009 	movx	a,@dptr
      003F93 FF               [12] 1010 	mov	r7,a
      003F94 E0               [24] 1011 	movx	a,@dptr
      003F95 60 06            [24] 1012 	jz	00102$
      003F97 EF               [12] 1013 	mov	a,r7
      003F98 14               [12] 1014 	dec	a
      003F99 90 05 5E         [24] 1015 	mov	dptr,#_batch_depth
      003F9C F0               [24] 1016 	movx	@dptr,a
      003F9D                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F9D 90 05 5E         [24] 1019 	mov	dptr,#_batch_depth
      003FA0 E0               [24] 1020 	movx	a,@dptr
      003FA1 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FA3 02 3E 27         [24] 1023 	ljmp	_ak820_nvm_flush
      003FA6                       1024 00105$:
      003FA6 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      003FA7                       1036 _load_page:
      003FA7 E5 82            [12] 1037 	mov	a,dpl
      003FA9 90 05 7F         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      003FAC F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FAD 30 09 17         [24] 1041 	jnb	_page_valid,00102$
      003FB0 90 05 5D         [24] 1042 	mov	dptr,#_cached_page
      003FB3 E0               [24] 1043 	movx	a,@dptr
      003FB4 FF               [12] 1044 	mov	r7,a
      003FB5 90 05 7F         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      003FB8 E0               [24] 1046 	movx	a,@dptr
      003FB9 FE               [12] 1047 	mov	r6,a
      003FBA EF               [12] 1048 	mov	a,r7
      003FBB B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      003FBE A2 0B            [12] 1050 	mov	c,_storage_failed
      003FC0 B3               [12] 1051 	cpl	c
      003FC1 92 0D            [24] 1052 	mov  _load_page_sloc0_1_0,c
      003FC3 12 38 AC         [24] 1053 	lcall	_ak820_outline_0147
      003FC6 22               [24] 1054 	ret
      003FC7                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FC7 12 3E 27         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FCA 30 0B 04         [24] 1059 	jnb	_storage_failed,00119$
      003FCD 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FD0 22               [24] 1062 	ret
      003FD1                       1063 00119$:
      003FD1 7F 00            [12] 1064 	mov	r7,#0x00
      003FD3                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003FD3 EF               [12] 1067 	mov	a,r7
      003FD4 24 1D            [12] 1068 	add	a, #_page_data
      003FD6 FD               [12] 1069 	mov	r5,a
      003FD7 E4               [12] 1070 	clr	a
      003FD8 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      003FDA FE               [12] 1072 	mov	r6,a
      003FDB 90 05 7F         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      003FDE E0               [24] 1074 	movx	a,@dptr
      003FDF FC               [12] 1075 	mov	r4,a
      003FE0 FA               [12] 1076 	mov	r2,a
      003FE1 E4               [12] 1077 	clr	a
      003FE2 C3               [12] 1078 	clr	c
      003FE3 CA               [12] 1079 	xch	a,r2
      003FE4 13               [12] 1080 	rrc	a
      003FE5 CA               [12] 1081 	xch	a,r2
      003FE6 13               [12] 1082 	rrc	a
      003FE7 A2 E0            [12] 1083 	mov	c,acc.0
      003FE9 CA               [12] 1084 	xch	a,r2
      003FEA 13               [12] 1085 	rrc	a
      003FEB CA               [12] 1086 	xch	a,r2
      003FEC 13               [12] 1087 	rrc	a
      003FED CA               [12] 1088 	xch	a,r2
      003FEE 24 C7            [12] 1089 	add	a,#0xc7
      003FF0 FB               [12] 1090 	mov	r3,a
      003FF1 8F 01            [24] 1091 	mov	ar1,r7
      003FF3 89 00            [24] 1092 	mov	ar0,r1
      003FF5 79 00            [12] 1093 	mov	r1,#0x00
      003FF7 E8               [12] 1094 	mov	a,r0
      003FF8 2A               [12] 1095 	add	a, r2
      003FF9 FA               [12] 1096 	mov	r2,a
      003FFA E9               [12] 1097 	mov	a,r1
      003FFB 3B               [12] 1098 	addc	a, r3
      003FFC FB               [12] 1099 	mov	r3,a
      003FFD 12 38 A2         [24] 1100 	lcall	_ak820_outline_0131
      004000 12 38 EF         [24] 1101 	lcall	_ak820_flash_read
      004003 AB 82            [24] 1102 	mov	r3, dpl
      004005 12 38 A7         [24] 1103 	lcall	_ak820_outline_0140
      004008 EB               [12] 1104 	mov	a,r3
      004009 F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00400A 0F               [12] 1107 	inc	r7
      00400B BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00400E 90 05 5D         [24] 1110 	mov	dptr,#_cached_page
      004011 EC               [12] 1111 	mov	a,r4
      004012 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004013 D2 09            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004015 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004018 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      004019                       1129 _read_offset:
      004019 12 38 7A         [24] 1130 	lcall	_ak820_outline_0106
      00401C 90 05 80         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      00401F 12 38 75         [24] 1132 	lcall	_ak820_outline_0105
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004022 90 05 80         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      004025 12 38 2E         [24] 1135 	lcall	_ak820_outline_0059
      004028 C3               [12] 1136 	clr	c
      004029 94 28            [12] 1137 	subb	a,#0x28
      00402B 40 04            [24] 1138 	jc	00102$
      00402D 75 82 00         [24] 1139 	mov	dpl, #0x00
      004030 22               [24] 1140 	ret
      004031                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004031 30 09 34         [24] 1143 	jnb	_page_valid,00104$
      004034 8E 04            [24] 1144 	mov	ar4,r6
      004036 EF               [12] 1145 	mov	a,r7
      004037 A2 E7            [12] 1146 	mov	c,acc.7
      004039 CC               [12] 1147 	xch	a,r4
      00403A 33               [12] 1148 	rlc	a
      00403B CC               [12] 1149 	xch	a,r4
      00403C 33               [12] 1150 	rlc	a
      00403D A2 E7            [12] 1151 	mov	c,acc.7
      00403F CC               [12] 1152 	xch	a,r4
      004040 33               [12] 1153 	rlc	a
      004041 CC               [12] 1154 	xch	a,r4
      004042 33               [12] 1155 	rlc	a
      004043 CC               [12] 1156 	xch	a,r4
      004044 54 03            [12] 1157 	anl	a,#0x03
      004046 FD               [12] 1158 	mov	r5,a
      004047 90 05 5D         [24] 1159 	mov	dptr,#_cached_page
      00404A E0               [24] 1160 	movx	a,@dptr
      00404B FA               [12] 1161 	mov	r2,a
      00404C 7B 00            [12] 1162 	mov	r3,#0x00
      00404E EC               [12] 1163 	mov	a,r4
      00404F B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      004052 ED               [12] 1165 	mov	a,r5
      004053 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004056 74 3F            [12] 1168 	mov	a,#0x3f
      004058 5E               [12] 1169 	anl	a,r6
      004059 7D 00            [12] 1170 	mov	r5,#0x00
      00405B 24 1D            [12] 1171 	add	a, #_page_data
      00405D F5 82            [12] 1172 	mov	dpl,a
      00405F ED               [12] 1173 	mov	a,r5
      004060 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      004062 F5 83            [12] 1175 	mov	dph,a
      004064 E0               [24] 1176 	movx	a,@dptr
      004065 F5 82            [12] 1177 	mov	dpl,a
      004067 22               [24] 1178 	ret
      004068                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004068 74 C7            [12] 1181 	mov	a,#0xc7
      00406A 2F               [12] 1182 	add	a, r7
      00406B FF               [12] 1183 	mov	r7,a
      00406C 12 38 8D         [24] 1184 	lcall	_ak820_outline_0121
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00406F 02 38 EF         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      004072                       1196 _eeprom_read_byte:
      004072 C0 07            [24] 1197 	push	ar7
      004074 C0 06            [24] 1198 	push	ar6
      004076 12 43 11         [24] 1199 	lcall	_ak820_outline_0042
      004079 90 05 82         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00407C 12 38 0D         [24] 1201 	lcall	_ak820_outline_0019
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00407F 90 05 82         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004082 12 37 DC         [24] 1204 	lcall	_ak820_outline_0005
      004085 C0 06            [24] 1205 	push	ar6
      004087 C0 05            [24] 1206 	push	ar5
      004089 C0 04            [24] 1207 	push	ar4
      00408B C0 03            [24] 1208 	push	ar3
      00408D C0 02            [24] 1209 	push	ar2
      00408F C0 01            [24] 1210 	push	ar1
      004091 C0 00            [24] 1211 	push	ar0
      004093 12 40 19         [24] 1212 	lcall	_read_offset
      004096 AF 82            [24] 1213 	mov	r7, dpl
      004098 D0 00            [24] 1214 	pop	ar0
      00409A D0 01            [24] 1215 	pop	ar1
      00409C D0 02            [24] 1216 	pop	ar2
      00409E D0 03            [24] 1217 	pop	ar3
      0040A0 D0 04            [24] 1218 	pop	ar4
      0040A2 D0 05            [24] 1219 	pop	ar5
      0040A4 D0 06            [24] 1220 	pop	ar6
      0040A6 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040A8 D0 06            [24] 1223 	pop	ar6
      0040AA D0 07            [24] 1224 	pop	ar7
      0040AC 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      0040AD                       1239 _ak820_eeprom_read_block_xdata:
      0040AD 12 38 7A         [24] 1240 	lcall	_ak820_outline_0106
      0040B0 90 05 8A         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040B3 12 38 75         [24] 1242 	lcall	_ak820_outline_0105
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040B6 90 05 85         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040B9 12 38 2E         [24] 1245 	lcall	_ak820_outline_0059
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040BC 90 05 8A         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040BF 12 38 45         [24] 1248 	lcall	_ak820_outline_0065
      0040C2 90 05 8C         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040C5 12 38 51         [24] 1250 	lcall	_ak820_outline_0079
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040C8 90 05 88         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040CB 12 38 45         [24] 1253 	lcall	_ak820_outline_0065
      0040CE                       1254 00103$:
      0040CE 8C 02            [24] 1255 	mov	ar2,r4
      0040D0 8D 03            [24] 1256 	mov	ar3,r5
      0040D2 1C               [12] 1257 	dec	r4
      0040D3 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      0040D6 1D               [12] 1259 	dec	r5
      0040D7                       1260 00130$:
      0040D7 EA               [12] 1261 	mov	a,r2
      0040D8 4B               [12] 1262 	orl	a,r3
      0040D9 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0040DB 8E 02            [24] 1265 	mov	ar2,r6
      0040DD 8F 03            [24] 1266 	mov	ar3,r7
      0040DF 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      0040E1 2B               [12] 1268 	add	a,r3
      0040E2 50 17            [24] 1269 	jnc	00102$
      0040E4 90 05 8C         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040E7 12 43 4F         [24] 1271 	lcall	_ak820_outline_0084
      0040EA 12 38 A2         [24] 1272 	lcall	_ak820_outline_0131
      0040ED E4               [12] 1273 	clr	a
      0040EE F0               [24] 1274 	movx	@dptr,a
      0040EF 90 05 8C         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F2 04               [12] 1276 	inc	a
      0040F3 2A               [12] 1277 	add	a, r2
      0040F4 F0               [24] 1278 	movx	@dptr,a
      0040F5 E4               [12] 1279 	clr	a
      0040F6 3B               [12] 1280 	addc	a, r3
      0040F7 A3               [24] 1281 	inc	dptr
      0040F8 F0               [24] 1282 	movx	@dptr,a
      0040F9 80 D3            [24] 1283 	sjmp	00103$
      0040FB                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040FB 90 05 8C         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040FE 12 43 4F         [24] 1287 	lcall	_ak820_outline_0084
      004101 12 38 8D         [24] 1288 	lcall	_ak820_outline_0121
      004104 C0 07            [24] 1289 	push	ar7
      004106 C0 06            [24] 1290 	push	ar6
      004108 C0 05            [24] 1291 	push	ar5
      00410A C0 04            [24] 1292 	push	ar4
      00410C C0 03            [24] 1293 	push	ar3
      00410E C0 02            [24] 1294 	push	ar2
      004110 12 40 19         [24] 1295 	lcall	_read_offset
      004113 A9 82            [24] 1296 	mov	r1, dpl
      004115 D0 02            [24] 1297 	pop	ar2
      004117 D0 03            [24] 1298 	pop	ar3
      004119 D0 04            [24] 1299 	pop	ar4
      00411B D0 05            [24] 1300 	pop	ar5
      00411D D0 06            [24] 1301 	pop	ar6
      00411F D0 07            [24] 1302 	pop	ar7
      004121 12 38 A2         [24] 1303 	lcall	_ak820_outline_0131
      004124 E9               [12] 1304 	mov	a,r1
      004125 F0               [24] 1305 	movx	@dptr,a
      004126 90 05 8C         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004129 74 01            [12] 1307 	mov	a,#0x01
      00412B 2A               [12] 1308 	add	a, r2
      00412C F0               [24] 1309 	movx	@dptr,a
      00412D E4               [12] 1310 	clr	a
      00412E 3B               [12] 1311 	addc	a, r3
      00412F A3               [24] 1312 	inc	dptr
      004130 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004131 0E               [12] 1315 	inc	r6
      004132 BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      004135 0F               [12] 1317 	inc	r7
      004136 80 96            [24] 1318 	sjmp	00103$
      004138                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004138 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      004139                       1337 _ak820_eeprom_write_block_xdata:
      004139 12 38 7A         [24] 1338 	lcall	_ak820_outline_0106
      00413C 90 05 93         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00413F 12 38 75         [24] 1340 	lcall	_ak820_outline_0105
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004142 90 05 8E         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004145 12 38 2E         [24] 1343 	lcall	_ak820_outline_0059
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004148 90 05 93         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00414B 12 38 45         [24] 1346 	lcall	_ak820_outline_0065
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00414E 8E 02            [24] 1348 	mov	ar2,r6
      004150 8F 03            [24] 1349 	mov	ar3,r7
      004152 C3               [12] 1350 	clr	c
      004153 E4               [12] 1351 	clr	a
      004154 9A               [12] 1352 	subb	a,r2
      004155 74 28            [12] 1353 	mov	a,#0x28
      004157 9B               [12] 1354 	subb	a,r3
      004158 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      00415A E4               [12] 1357 	clr	a
      00415B C3               [12] 1358 	clr	c
      00415C 9E               [12] 1359 	subb	a,r6
      00415D FA               [12] 1360 	mov	r2,a
      00415E 74 28            [12] 1361 	mov	a,#0x28
      004160 9F               [12] 1362 	subb	a,r7
      004161 FB               [12] 1363 	mov	r3,a
      004162 90 05 91         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004165 12 38 63         [24] 1365 	lcall	_ak820_outline_0098
      004168 C3               [12] 1366 	clr	c
      004169 EA               [12] 1367 	mov	a,r2
      00416A 98               [12] 1368 	subb	a,r0
      00416B EB               [12] 1369 	mov	a,r3
      00416C 99               [12] 1370 	subb	a,r1
      00416D 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      00416F                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00416F 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004172 02 3B 83         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004175                       1379 00125$:
      004175 90 05 91         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004178 12 43 4F         [24] 1381 	lcall	_ak820_outline_0084
      00417B                       1382 00108$:
      00417B 8A 00            [24] 1383 	mov	ar0,r2
      00417D 8B 01            [24] 1384 	mov	ar1,r3
      00417F 1A               [12] 1385 	dec	r2
      004180 BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      004183 1B               [12] 1387 	dec	r3
      004184                       1388 00159$:
      004184 E8               [12] 1389 	mov	a,r0
      004185 49               [12] 1390 	orl	a,r1
      004186 70 03            [24] 1391 	jnz	00160$
      004188 02 42 12         [24] 1392 	ljmp	00110$
      00418B                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00418B C0 02            [24] 1395 	push	ar2
      00418D C0 03            [24] 1396 	push	ar3
      00418F 12 43 49         [24] 1397 	lcall	_ak820_outline_0083
      004192 F9               [12] 1398 	mov	r1,a
      004193 A3               [24] 1399 	inc	dptr
      004194 12 43 72         [24] 1400 	lcall	_ak820_outline_0154
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004197 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004199 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00419B A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00419D E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00419F A2 E7            [12] 1406 	mov	c,acc.7
      0041A1 C8               [12] 1407 	xch	a,r0
      0041A2 33               [12] 1408 	rlc	a
      0041A3 C8               [12] 1409 	xch	a,r0
      0041A4 33               [12] 1410 	rlc	a
      0041A5 A2 E7            [12] 1411 	mov	c,acc.7
      0041A7 C8               [12] 1412 	xch	a,r0
      0041A8 33               [12] 1413 	rlc	a
      0041A9 C8               [12] 1414 	xch	a,r0
      0041AA 33               [12] 1415 	rlc	a
      0041AB C8               [12] 1416 	xch	a,r0
      0041AC 54 03            [12] 1417 	anl	a,#0x03
      0041AE FB               [12] 1418 	mov	r3,a
      0041AF 88 82            [24] 1419 	mov	dpl, r0
      0041B1 C0 07            [24] 1420 	push	ar7
      0041B3 C0 06            [24] 1421 	push	ar6
      0041B5 C0 05            [24] 1422 	push	ar5
      0041B7 C0 04            [24] 1423 	push	ar4
      0041B9 C0 03            [24] 1424 	push	ar3
      0041BB C0 02            [24] 1425 	push	ar2
      0041BD C0 01            [24] 1426 	push	ar1
      0041BF 12 3F A7         [24] 1427 	lcall	_load_page
      0041C2 E5 82            [12] 1428 	mov	a, dpl
      0041C4 D0 01            [24] 1429 	pop	ar1
      0041C6 D0 02            [24] 1430 	pop	ar2
      0041C8 D0 03            [24] 1431 	pop	ar3
      0041CA D0 04            [24] 1432 	pop	ar4
      0041CC D0 05            [24] 1433 	pop	ar5
      0041CE D0 06            [24] 1434 	pop	ar6
      0041D0 D0 07            [24] 1435 	pop	ar7
      0041D2 D0 03            [24] 1436 	pop	ar3
      0041D4 D0 02            [24] 1437 	pop	ar2
      0041D6 70 01            [24] 1438 	jnz	00105$
      0041D8 22               [24] 1439 	ret
      0041D9                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0041D9 C0 06            [24] 1442 	push	ar6
      0041DB C0 07            [24] 1443 	push	ar7
      0041DD 74 3F            [12] 1444 	mov	a,#0x3f
      0041DF 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041E1 7F 00            [12] 1446 	mov	r7,#0x00
      0041E3 24 1D            [12] 1447 	add	a, #_page_data
      0041E5 F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041E7 EF               [12] 1449 	mov	a,r7
      0041E8 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      0041EA F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041EC 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041EF 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041F2 E0               [24] 1454 	movx	a,@dptr
      0041F3 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      0041F6 D0 07            [24] 1456 	pop	ar7
      0041F8 D0 06            [24] 1457 	pop	ar6
      0041FA 80 0E            [24] 1458 	sjmp	00107$
      0041FC                       1459 00162$:
      0041FC D0 07            [24] 1460 	pop	ar7
      0041FE D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004200 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004203 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004206 E9               [12] 1465 	mov	a,r1
      004207 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      004208 D2 0A            [12] 1469 	setb	_page_dirty
      00420A                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      00420A 0E               [12] 1472 	inc	r6
      00420B BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      00420E 0F               [12] 1474 	inc	r7
      00420F                       1475 00163$:
      00420F 02 41 7B         [24] 1476 	ljmp	00108$
      004212                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004212 90 05 5E         [24] 1479 	mov	dptr,#_batch_depth
      004215 E0               [24] 1480 	movx	a,@dptr
      004216 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004218 02 3E 27         [24] 1483 	ljmp	_ak820_nvm_flush
      00421B                       1484 00113$:
      00421B 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      00421C                       1503 _ak820_eeprom_update_block_xdata:
      00421C 12 38 7A         [24] 1504 	lcall	_ak820_outline_0106
      00421F 90 05 9A         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004222 12 38 75         [24] 1506 	lcall	_ak820_outline_0105
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004225 90 05 9A         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004228 12 38 2E         [24] 1509 	lcall	_ak820_outline_0059
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00422B 90 05 95         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00422E E0               [24] 1512 	movx	a,@dptr
      00422F F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004231 A3               [24] 1514 	inc	dptr
      004232 E0               [24] 1515 	movx	a,@dptr
      004233 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004235 A3               [24] 1517 	inc	dptr
      004236 E0               [24] 1518 	movx	a,@dptr
      004237 F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004239 A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00423B AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00423D E4               [12] 1523 	clr	a
      00423E F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004240 F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004242                       1526 00105$:
      004242 90 05 98         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004245 E0               [24] 1528 	movx	a,@dptr
      004246 F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004248 A3               [24] 1530 	inc	dptr
      004249 E0               [24] 1531 	movx	a,@dptr
      00424A F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00424C C3               [12] 1533 	clr	c
      00424D E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00424F 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004251 E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004253 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004255 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004257 89 00            [24] 1540 	mov	ar0,r1
      004259 8A 05            [24] 1541 	mov	ar5,r2
      00425B E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00425D 28               [12] 1543 	add	a, r0
      00425E F8               [12] 1544 	mov	r0,a
      00425F E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004261 3D               [12] 1546 	addc	a, r5
      004262 FD               [12] 1547 	mov	r5,a
      004263 88 82            [24] 1548 	mov	dpl, r0
      004265 8D 83            [24] 1549 	mov	dph, r5
      004267 C0 07            [24] 1550 	push	ar7
      004269 C0 06            [24] 1551 	push	ar6
      00426B C0 02            [24] 1552 	push	ar2
      00426D C0 01            [24] 1553 	push	ar1
      00426F 12 40 19         [24] 1554 	lcall	_read_offset
      004272 AD 82            [24] 1555 	mov	r5, dpl
      004274 D0 01            [24] 1556 	pop	ar1
      004276 D0 02            [24] 1557 	pop	ar2
      004278 D0 06            [24] 1558 	pop	ar6
      00427A D0 07            [24] 1559 	pop	ar7
      00427C E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00427E 2E               [12] 1561 	add	a, r6
      00427F F5 82            [12] 1562 	mov	dpl,a
      004281 E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004283 3F               [12] 1564 	addc	a, r7
      004284 F5 83            [12] 1565 	mov	dph,a
      004286 E0               [24] 1566 	movx	a,@dptr
      004287 FC               [12] 1567 	mov	r4,a
      004288 ED               [12] 1568 	mov	a,r5
      004289 B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      00428C 80 27            [24] 1570 	sjmp	00106$
      00428E                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00428E 90 05 9A         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004291 E0               [24] 1574 	movx	a,@dptr
      004292 F8               [12] 1575 	mov	r0,a
      004293 A3               [24] 1576 	inc	dptr
      004294 E0               [24] 1577 	movx	a,@dptr
      004295 FD               [12] 1578 	mov	r5,a
      004296 90 05 8E         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004299 E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00429B F0               [24] 1581 	movx	@dptr,a
      00429C E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00429E A3               [24] 1583 	inc	dptr
      00429F F0               [24] 1584 	movx	@dptr,a
      0042A0 E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0042A2 A3               [24] 1586 	inc	dptr
      0042A3 F0               [24] 1587 	movx	@dptr,a
      0042A4 90 05 91         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042A7 E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042A9 F0               [24] 1590 	movx	@dptr,a
      0042AA E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042AC A3               [24] 1592 	inc	dptr
      0042AD F0               [24] 1593 	movx	@dptr,a
      0042AE 88 82            [24] 1594 	mov	dpl, r0
      0042B0 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042B2 02 41 39         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      0042B5                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042B5 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042B7 E4               [12] 1601 	clr	a
      0042B8 B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042BB 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042BD 80 83            [24] 1604 	sjmp	00105$
      0042BF                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042BF 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      0042C0                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042C0 12 3E 27         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042C3 7F 00            [12] 1622 	mov	r7,#0x00
      0042C5                       1623 00111$:
      0042C5 BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      0042C8 22               [24] 1625 	ret
      0042C9                       1626 00165$:
      0042C9 20 0B 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042CC 8F 82            [24] 1629 	mov	dpl, r7
      0042CE C0 07            [24] 1630 	push	ar7
      0042D0 12 3F A7         [24] 1631 	lcall	_load_page
      0042D3 E5 82            [12] 1632 	mov	a, dpl
      0042D5 D0 07            [24] 1633 	pop	ar7
      0042D7 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042D9 22               [24] 1636 	ret
      0042DA                       1637 00126$:
      0042DA 7E 00            [12] 1638 	mov	r6,#0x00
      0042DC                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042DC EE               [12] 1641 	mov	a,r6
      0042DD 24 1D            [12] 1642 	add	a, #_page_data
      0042DF FC               [12] 1643 	mov	r4,a
      0042E0 E4               [12] 1644 	clr	a
      0042E1 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      0042E3 FD               [12] 1646 	mov	r5,a
      0042E4 12 43 49         [24] 1647 	lcall	_ak820_outline_0083
      0042E7 60 07            [24] 1648 	jz	00108$
      0042E9 12 38 98         [24] 1649 	lcall	_ak820_outline_0129
      0042EC E4               [12] 1650 	clr	a
      0042ED F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      0042EE D2 0A            [12] 1653 	setb	_page_dirty
      0042F0                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042F0 0E               [12] 1656 	inc	r6
      0042F1 BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042F4 C0 07            [24] 1659 	push	ar7
      0042F6 12 3E 27         [24] 1660 	lcall	_ak820_nvm_flush
      0042F9 D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042FB 0F               [12] 1663 	inc	r7
      0042FC 80 C7            [24] 1664 	sjmp	00111$
      0042FE                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042FE 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0005
                                   1675 	.globl _ak820_outline_0011
                                   1676 	.globl _ak820_outline_0019
                                   1677 	.globl _ak820_outline_0020
                                   1678 	.globl _ak820_outline_0037
                                   1679 	.globl _ak820_outline_0042
                                   1680 	.globl _ak820_outline_0048
                                   1681 	.globl _ak820_outline_0059
                                   1682 	.globl _ak820_outline_0060
                                   1683 	.globl _ak820_outline_0064
                                   1684 	.globl _ak820_outline_0065
                                   1685 	.globl _ak820_outline_0070
                                   1686 	.globl _ak820_outline_0072
                                   1687 	.globl _ak820_outline_0079
                                   1688 	.globl _ak820_outline_0082
                                   1689 	.globl _ak820_outline_0083
                                   1690 	.globl _ak820_outline_0084
                                   1691 	.globl _ak820_outline_0085
                                   1692 	.globl _ak820_outline_0098
                                   1693 	.globl _ak820_outline_0099
                                   1694 	.globl _ak820_outline_0105
                                   1695 	.globl _ak820_outline_0106
                                   1696 	.globl _ak820_outline_0108
                                   1697 	.globl _ak820_outline_0121
                                   1698 	.globl _ak820_outline_0125
                                   1699 	.globl _ak820_outline_0127
                                   1700 	.globl _ak820_outline_0129
                                   1701 	.globl _ak820_outline_0131
                                   1702 	.globl _ak820_outline_0139
                                   1703 	.globl _ak820_outline_0140
                                   1704 	.globl _ak820_outline_0145
                                   1705 	.globl _ak820_outline_0147
                                   1706 	.globl _ak820_outline_0154
                                   1707 	.globl _ak820_outline_0160
                                   1708 	.globl _ak820_outline_0164
                                   1709 	.globl _ak820_outline_0165
                                   1710 	.globl _ak820_outline_0174
                                   1711 	.globl _ak820_outline_0187
                                   1712 
                                   1713 	.area CSEG (CODE)
                                   1714 ; function ak820_outline_0011
      0042FF                       1715 _ak820_outline_0011:
      0042FF 8E 82            [24] 1716 	mov	dpl,r6
      004301 8F 83            [24] 1717 	mov	dph,r7
      004303 A3               [24] 1718 	inc	dptr
      004304 A3               [24] 1719 	inc	dptr
      004305 A3               [24] 1720 	inc	dptr
      004306 A3               [24] 1721 	inc	dptr
      004307 A3               [24] 1722 	inc	dptr
      004308 22               [24] 1723 	ret
                                   1724 
                                   1725 	.area CSEG (CODE)
                                   1726 ; function ak820_outline_0037
      004309                       1727 _ak820_outline_0037:
      004309 F0               [24] 1728 	movx	@dptr,a
      00430A 8E 82            [24] 1729 	mov	dpl,r6
      00430C 8F 83            [24] 1730 	mov	dph,r7
      00430E A3               [24] 1731 	inc	dptr
      00430F A3               [24] 1732 	inc	dptr
      004310 22               [24] 1733 	ret
                                   1734 
                                   1735 	.area CSEG (CODE)
                                   1736 ; function ak820_outline_0042
      004311                       1737 _ak820_outline_0042:
      004311 AF F0            [24] 1738 	mov	r7,b
      004313 AE 83            [24] 1739 	mov	r6,dph
      004315 E5 82            [12] 1740 	mov	a,dpl
      004317 22               [24] 1741 	ret
                                   1742 
                                   1743 	.area CSEG (CODE)
                                   1744 ; function ak820_outline_0048
      004318                       1745 _ak820_outline_0048:
      004318 EF               [12] 1746 	mov	a,r7
      004319 24 75            [12] 1747 	add	a,#_ak820_nvm_flush_header_10000_62
      00431B F5 82            [12] 1748 	mov	dpl,a
      00431D E4               [12] 1749 	clr	a
      00431E 34 05            [12] 1750 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004320 F5 83            [12] 1751 	mov	dph,a
      004322 E0               [24] 1752 	movx	a,@dptr
      004323 22               [24] 1753 	ret
                                   1754 
                                   1755 	.area CSEG (CODE)
                                   1756 ; function ak820_outline_0060
      004324                       1757 _ak820_outline_0060:
      004324 8F 06            [24] 1758 	mov	ar6,r7
      004326 7D 00            [12] 1759 	mov	r5,#0x00
      004328 74 40            [12] 1760 	mov	a,#0x40
      00432A 2E               [12] 1761 	add	a,r6
      00432B FE               [12] 1762 	mov	r6,a
      00432C 74 EF            [12] 1763 	mov	a,#0xef
      00432E 3D               [12] 1764 	addc	a,r5
      00432F FD               [12] 1765 	mov	r5,a
      004330 8E 82            [24] 1766 	mov	dpl,r6
      004332 8D 83            [24] 1767 	mov	dph,r5
      004334 22               [24] 1768 	ret
                                   1769 
                                   1770 	.area CSEG (CODE)
                                   1771 ; function ak820_outline_0064
      004335                       1772 _ak820_outline_0064:
      004335 A3               [24] 1773 	inc	dptr
      004336 F0               [24] 1774 	movx	@dptr,a
      004337 8E 82            [24] 1775 	mov	dpl,r6
      004339 8F 83            [24] 1776 	mov	dph,r7
      00433B 22               [24] 1777 	ret
                                   1778 
                                   1779 	.area CSEG (CODE)
                                   1780 ; function ak820_outline_0070
      00433C                       1781 _ak820_outline_0070:
      00433C 8D 82            [24] 1782 	mov	dpl,r5
      00433E 8E 83            [24] 1783 	mov	dph,r6
      004340 EC               [12] 1784 	mov	a,r4
      004341 F0               [24] 1785 	movx	@dptr,a
      004342 22               [24] 1786 	ret
                                   1787 
                                   1788 	.area CSEG (CODE)
                                   1789 ; function ak820_outline_0072
      004343                       1790 _ak820_outline_0072:
      004343 F0               [24] 1791 	movx	@dptr,a
      004344 8E 82            [24] 1792 	mov	dpl,r6
      004346 8F 83            [24] 1793 	mov	dph,r7
      004348 22               [24] 1794 	ret
                                   1795 
                                   1796 	.area CSEG (CODE)
                                   1797 ; function ak820_outline_0083
      004349                       1798 _ak820_outline_0083:
      004349 8C 82            [24] 1799 	mov	dpl,r4
      00434B 8D 83            [24] 1800 	mov	dph,r5
      00434D E0               [24] 1801 	movx	a,@dptr
      00434E 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0084
      00434F                       1806 _ak820_outline_0084:
      00434F E0               [24] 1807 	movx	a,@dptr
      004350 FA               [12] 1808 	mov	r2,a
      004351 A3               [24] 1809 	inc	dptr
      004352 E0               [24] 1810 	movx	a,@dptr
      004353 FB               [12] 1811 	mov	r3,a
      004354 22               [24] 1812 	ret
                                   1813 
                                   1814 	.area CSEG (CODE)
                                   1815 ; function ak820_outline_0108
      004355                       1816 _ak820_outline_0108:
      004355 EF               [12] 1817 	mov	a,r7
      004356 24 1D            [12] 1818 	add	a,#_page_data
      004358 F5 82            [12] 1819 	mov	dpl,a
      00435A E4               [12] 1820 	clr	a
      00435B 34 05            [12] 1821 	addc	a,#(_page_data>>8)
      00435D F5 83            [12] 1822 	mov	dph,a
      00435F E0               [24] 1823 	movx	a,@dptr
      004360 22               [24] 1824 	ret
                                   1825 
                                   1826 	.area CSEG (CODE)
                                   1827 ; function ak820_outline_0127
      004361                       1828 _ak820_outline_0127:
      004361 8C 82            [24] 1829 	mov	dpl,r4
      004363 8D 83            [24] 1830 	mov	dph,r5
      004365 F0               [24] 1831 	movx	@dptr,a
      004366 22               [24] 1832 	ret
                                   1833 
                                   1834 	.area CSEG (CODE)
                                   1835 ; function ak820_outline_0139
      004367                       1836 _ak820_outline_0139:
      004367 AE 82            [24] 1837 	mov	r6,dpl
      004369 AF 83            [24] 1838 	mov	r7,dph
      00436B 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0145
      00436C                       1843 _ak820_outline_0145:
      00436C 42 05            [12] 1844 	orl	ar5,a
      00436E EA               [12] 1845 	mov	a,r2
      00436F 42 04            [12] 1846 	orl	ar4,a
      004371 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0154
      004372                       1851 _ak820_outline_0154:
      004372 AC 82            [24] 1852 	mov	r4,dpl
      004374 AD 83            [24] 1853 	mov	r5,dph
      004376 22               [24] 1854 	ret
                                   1855 
                                   1856 	.area CSEG (CODE)
                                   1857 ; function ak820_outline_0160
      004377                       1858 _ak820_outline_0160:
      004377 8F 82            [24] 1859 	mov	dpl,r7
      004379 8E 83            [24] 1860 	mov	dph,r6
      00437B 22               [24] 1861 	ret
                                   1862 
                                   1863 	.area CSEG (CODE)
                                   1864 ; function ak820_outline_0164
      00437C                       1865 _ak820_outline_0164:
      00437C 2E               [12] 1866 	add	a,r6
      00437D FC               [12] 1867 	mov	r4,a
      00437E E4               [12] 1868 	clr	a
      00437F 3F               [12] 1869 	addc	a,r7
      004380 FD               [12] 1870 	mov	r5,a
      004381 22               [24] 1871 	ret
                                   1872 
                                   1873 	.area CSEG (CODE)
                                   1874 ; function ak820_outline_0165
      004382                       1875 _ak820_outline_0165:
      004382 ED               [12] 1876 	mov	a,r5
      004383 F0               [24] 1877 	movx	@dptr,a
      004384 EE               [12] 1878 	mov	a,r6
      004385 A3               [24] 1879 	inc	dptr
      004386 F0               [24] 1880 	movx	@dptr,a
      004387 22               [24] 1881 	ret
                                   1882 
                                   1883 	.area CSEG (CODE)
                                   1884 ; function ak820_outline_0174
      004388                       1885 _ak820_outline_0174:
      004388 89 82            [24] 1886 	mov	dpl,r1
      00438A 8A 83            [24] 1887 	mov	dph,r2
      00438C 22               [24] 1888 	ret
                                   1889 
                                   1890 	.area CSEG (CODE)
                                   1891 ; function ak820_outline_0187
      00438D                       1892 _ak820_outline_0187:
      00438D 8C 82            [24] 1893 	mov	dpl,r4
      00438F 8B 83            [24] 1894 	mov	dph,r3
      004391 22               [24] 1895 	ret
