                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _input_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _output_sloc0_1_0:
      000001                        542 	.ds 1
      000002                        543 _ak820_combo_valid_sloc0_1_0:
      000002                        544 	.ds 1
      000003                        545 _ak820_combo_process_sloc0_1_0:
      000003                        546 	.ds 1
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      000422                        555 _input_code_10000_594:
      000422                        556 	.ds 2
      000424                        557 _output_code_10000_596:
      000424                        558 	.ds 2
      000426                        559 _combos:
      000426                        560 	.ds 32
      000446                        561 _saved:
      000446                        562 	.ds 9
      00044F                        563 _active:
      00044F                        564 	.ds 1
      000450                        565 _ak820_combo_valid_entry_10000_598:
      000450                        566 	.ds 2
      000452                        567 _ak820_combo_reload_entry_30000_610:
      000452                        568 	.ds 10
      00045C                        569 _ak820_combo_tick_now_10000_615:
      00045C                        570 	.ds 2
      00045E                        571 _ak820_combo_process_record_10000_618:
      00045E                        572 	.ds 2
      000460                        573 _ak820_combo_process_eligible_10001_633:
      000460                        574 	.ds 1
      000461                        575 _ak820_combo_process_i_40001_636:
      000461                        576 	.ds 1
      000462                        577 _ak820_combo_process_a_50001_637:
      000462                        578 	.ds 1
      000463                        579 _ak820_combo_process_b_50001_637:
      000463                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; absolute external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XABS    (ABS,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; initialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XISEG   (XDATA)
      000E92                        589 _first:
      000E92                        590 	.ds 1
      000E93                        591 _second:
      000E93                        592 	.ds 1
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    621 ;------------------------------------------------------------
                                    622 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    623 ;------------------------------------------------------------
                                    624 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function input
                                    635 ;	-----------------------------------------
      003468                        636 _input:
      003468 12 38 7A         [24]  637 	lcall	_ak820_outline_0106
      00346B 90 04 22         [24]  638 	mov	dptr,#_input_code_10000_594
      00346E 12 38 75         [24]  639 	lcall	_ak820_outline_0105
      003471 90 04 22         [24]  640 	mov	dptr,#_input_code_10000_594
      003474 12 38 2E         [24]  641 	lcall	_ak820_outline_0059
      003477 C3               [12]  642 	clr	c
      003478 EE               [12]  643 	mov	a,r6
      003479 94 04            [12]  644 	subb	a,#0x04
      00347B EF               [12]  645 	mov	a,r7
      00347C 94 00            [12]  646 	subb	a,#0x00
      00347E 40 07            [24]  647 	jc	00103$
      003480 74 A4            [12]  648 	mov	a,#0xa4
      003482 9E               [12]  649 	subb	a,r6
      003483 E4               [12]  650 	clr	a
      003484 9F               [12]  651 	subb	a,r7
      003485 50 04            [24]  652 	jnc	00104$
                                    653 ;	free result
      003487                        654 00103$:
                                    655 ;	assignBit
      003487 C2 00            [12]  656 	clr	_input_sloc0_1_0
      003489 80 02            [24]  657 	sjmp	00105$
      00348B                        658 00104$:
                                    659 ;	assignBit
      00348B D2 00            [12]  660 	setb	_input_sloc0_1_0
      00348D                        661 00105$:
      00348D A2 00            [12]  662 	mov	c,_input_sloc0_1_0
      00348F 12 38 AC         [24]  663 	lcall	_ak820_outline_0147
      003492 22               [24]  664 	ret
                                    665 ;------------------------------------------------------------
                                    666 ;Allocation info for local variables in function 'output'
                                    667 ;------------------------------------------------------------
                                    668 ;code          Allocated with name '_output_code_10000_596'
                                    669 ;basic         Allocated with name '_output_basic_10000_597'
                                    670 ;------------------------------------------------------------
                                    671 ;	keyboards/ajazz/ak820/ak820_combo.c:16: static bool output(uint16_t code) {
                                    672 ;	-----------------------------------------
                                    673 ;	 function output
                                    674 ;	-----------------------------------------
      003493                        675 _output:
      003493 12 38 7A         [24]  676 	lcall	_ak820_outline_0106
      003496 90 04 24         [24]  677 	mov	dptr,#_output_code_10000_596
      003499 12 38 75         [24]  678 	lcall	_ak820_outline_0105
                                    679 ;	keyboards/ajazz/ak820/ak820_combo.c:17: uint8_t basic = code;
      00349C 90 04 24         [24]  680 	mov	dptr,#_output_code_10000_596
      00349F 12 38 2E         [24]  681 	lcall	_ak820_outline_0059
      0034A2 8E 05            [24]  682 	mov	ar5,r6
                                    683 ;	keyboards/ajazz/ak820/ak820_combo.c:18: return code < QK_MOD_TAP && (input(basic) || (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI));
      0034A4 74 E0            [12]  684 	mov	a,#0x100 - 0x20
      0034A6 2F               [12]  685 	add	a,r7
      0034A7 40 1B            [24]  686 	jc	00103$
      0034A9 8D 06            [24]  687 	mov	ar6,r5
      0034AB 7F 00            [12]  688 	mov	r7,#0x00
      0034AD 12 38 8D         [24]  689 	lcall	_ak820_outline_0121
      0034B0 C0 05            [24]  690 	push	ar5
      0034B2 91 68            [12]  691 	acall	_input
      0034B4 E5 82            [12]  692 	mov	a, dpl
      0034B6 D0 05            [24]  693 	pop	ar5
      0034B8 70 0E            [24]  694 	jnz	00104$
      0034BA BD E0 00         [24]  695 	cjne	r5,#0xe0,00135$
      0034BD                        696 00135$:
      0034BD 40 05            [24]  697 	jc	00103$
      0034BF ED               [12]  698 	mov	a,r5
      0034C0 24 18            [12]  699 	add	a,#0xff - 0xe7
      0034C2 50 04            [24]  700 	jnc	00104$
                                    701 ;	free result
      0034C4                        702 00103$:
                                    703 ;	assignBit
      0034C4 C2 01            [12]  704 	clr	_output_sloc0_1_0
      0034C6 80 02            [24]  705 	sjmp	00105$
      0034C8                        706 00104$:
                                    707 ;	assignBit
      0034C8 D2 01            [12]  708 	setb	_output_sloc0_1_0
      0034CA                        709 00105$:
      0034CA A2 01            [12]  710 	mov	c,_output_sloc0_1_0
      0034CC 12 38 AC         [24]  711 	lcall	_ak820_outline_0147
                                    712 ;	keyboards/ajazz/ak820/ak820_combo.c:19: }
      0034CF 22               [24]  713 	ret
                                    714 ;------------------------------------------------------------
                                    715 ;Allocation info for local variables in function 'ak820_combo_valid'
                                    716 ;------------------------------------------------------------
                                    717 ;entry         Allocated with name '_ak820_combo_valid_entry_10000_598'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_combo.c:25: bool ak820_combo_valid(const vial_combo_entry_t AK820_STATE_MEM *entry) {
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_combo_valid
                                    722 ;	-----------------------------------------
      0034D0                        723 _ak820_combo_valid:
      0034D0 12 38 7A         [24]  724 	lcall	_ak820_outline_0106
      0034D3 90 04 50         [24]  725 	mov	dptr,#_ak820_combo_valid_entry_10000_598
      0034D6 12 38 75         [24]  726 	lcall	_ak820_outline_0105
                                    727 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[2] || entry->input[3]) return false;
      0034D9 90 04 50         [24]  728 	mov	dptr,#_ak820_combo_valid_entry_10000_598
      0034DC 12 37 DC         [24]  729 	lcall	_ak820_outline_0005
      0034DF A3               [24]  730 	inc	dptr
      0034E0 A3               [24]  731 	inc	dptr
      0034E1 A3               [24]  732 	inc	dptr
      0034E2 A3               [24]  733 	inc	dptr
      0034E3 E0               [24]  734 	movx	a,@dptr
      0034E4 FC               [12]  735 	mov	r4,a
      0034E5 A3               [24]  736 	inc	dptr
      0034E6 E0               [24]  737 	movx	a,@dptr
      0034E7 4C               [12]  738 	orl	a,r4
      0034E8 70 0B            [24]  739 	jnz	00101$
      0034EA 74 06            [12]  740 	mov	a,#0x06
      0034EC 12 38 15         [24]  741 	lcall	_ak820_outline_0020
      0034EF FC               [12]  742 	mov	r4,a
      0034F0 A3               [24]  743 	inc	dptr
      0034F1 E0               [24]  744 	movx	a,@dptr
      0034F2 4C               [12]  745 	orl	a,r4
      0034F3 60 04            [24]  746 	jz	00102$
      0034F5                        747 00101$:
      0034F5 75 82 00         [24]  748 	mov	dpl, #0x00
      0034F8 22               [24]  749 	ret
      0034F9                        750 00102$:
                                    751 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      0034F9 8E 04            [24]  752 	mov	ar4,r6
      0034FB 8F 05            [24]  753 	mov	ar5,r7
      0034FD 12 38 1E         [24]  754 	lcall	_ak820_outline_0034
      003500 FA               [12]  755 	mov	r2,a
      003501 A3               [24]  756 	inc	dptr
      003502 E0               [24]  757 	movx	a,@dptr
      003503 FB               [12]  758 	mov	r3,a
      003504 12 38 98         [24]  759 	lcall	_ak820_outline_0129
      003507 12 38 45         [24]  760 	lcall	_ak820_outline_0065
      00350A EA               [12]  761 	mov	a,r2
      00350B 4C               [12]  762 	orl	a,r4
      00350C F8               [12]  763 	mov	r0,a
      00350D EB               [12]  764 	mov	a,r3
      00350E 4D               [12]  765 	orl	a,r5
      00350F 48               [12]  766 	orl	a,r0
      003510 70 12            [24]  767 	jnz	00105$
      003512 74 08            [12]  768 	mov	a,#0x08
      003514 12 38 15         [24]  769 	lcall	_ak820_outline_0020
      003517 F8               [12]  770 	mov	r0,a
      003518 A3               [24]  771 	inc	dptr
      003519 E0               [24]  772 	movx	a,@dptr
      00351A 48               [12]  773 	orl	a,r0
      00351B B4 01 00         [24]  774 	cjne	a,#0x01,00152$
      00351E                        775 00152$:
      00351E 92 02            [24]  776 	mov  _ak820_combo_valid_sloc0_1_0,c
      003520 12 38 AC         [24]  777 	lcall	_ak820_outline_0147
      003523 22               [24]  778 	ret
      003524                        779 00105$:
                                    780 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (entry->input[0] == entry->input[1]) return false;
      003524 EC               [12]  781 	mov	a,r4
      003525 B5 02 08         [24]  782 	cjne	a,ar2,00107$
      003528 ED               [12]  783 	mov	a,r5
      003529 B5 03 04         [24]  784 	cjne	a,ar3,00107$
      00352C 75 82 00         [24]  785 	mov	dpl, #0x00
      00352F 22               [24]  786 	ret
      003530                        787 00107$:
                                    788 ;	keyboards/ajazz/ak820/ak820_combo.c:29: if (!input(entry->input[0])) return false;
      003530 12 38 98         [24]  789 	lcall	_ak820_outline_0129
      003533 C0 07            [24]  790 	push	ar7
      003535 C0 06            [24]  791 	push	ar6
      003537 C0 03            [24]  792 	push	ar3
      003539 C0 02            [24]  793 	push	ar2
      00353B 91 68            [12]  794 	acall	_input
      00353D E5 82            [12]  795 	mov	a, dpl
      00353F D0 02            [24]  796 	pop	ar2
      003541 D0 03            [24]  797 	pop	ar3
      003543 D0 06            [24]  798 	pop	ar6
      003545 D0 07            [24]  799 	pop	ar7
      003547 70 03            [24]  800 	jnz	00109$
      003549 F5 82            [12]  801 	mov	dpl,a
      00354B 22               [24]  802 	ret
      00354C                        803 00109$:
                                    804 ;	keyboards/ajazz/ak820/ak820_combo.c:30: if (!input(entry->input[1])) return false;
      00354C 12 38 A2         [24]  805 	lcall	_ak820_outline_0131
      00354F C0 07            [24]  806 	push	ar7
      003551 C0 06            [24]  807 	push	ar6
      003553 91 68            [12]  808 	acall	_input
      003555 E5 82            [12]  809 	mov	a, dpl
      003557 D0 06            [24]  810 	pop	ar6
      003559 D0 07            [24]  811 	pop	ar7
      00355B 70 03            [24]  812 	jnz	00111$
      00355D F5 82            [12]  813 	mov	dpl,a
      00355F 22               [24]  814 	ret
      003560                        815 00111$:
                                    816 ;	keyboards/ajazz/ak820/ak820_combo.c:31: return output(entry->output);
      003560 74 08            [12]  817 	mov	a,#0x08
      003562 12 38 26         [24]  818 	lcall	_ak820_outline_0036
      003565 12 37 DC         [24]  819 	lcall	_ak820_outline_0005
                                    820 ;	keyboards/ajazz/ak820/ak820_combo.c:32: }
      003568 81 93            [12]  821 	ajmp	_output
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    824 ;------------------------------------------------------------
                                    825 ;	keyboards/ajazz/ak820/ak820_combo.c:35: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    826 ;	-----------------------------------------
                                    827 ;	 function ak820_combo_cancel
                                    828 ;	-----------------------------------------
      00356A                        829 _ak820_combo_cancel:
      00356A 90 0E 93         [24]  830 	mov	dptr,#_second
      00356D 74 FF            [12]  831 	mov	a,#0xff
      00356F F0               [24]  832 	movx	@dptr,a
      003570 90 0E 92         [24]  833 	mov	dptr,#_first
      003573 F0               [24]  834 	movx	@dptr,a
      003574 90 04 4F         [24]  835 	mov	dptr,#_active
      003577 E4               [12]  836 	clr	a
      003578 F0               [24]  837 	movx	@dptr,a
      003579 22               [24]  838 	ret
                                    839 ;------------------------------------------------------------
                                    840 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    841 ;------------------------------------------------------------
                                    842 ;i             Allocated with name '_ak820_combo_reload_i_20000_609'
                                    843 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_610'
                                    844 ;------------------------------------------------------------
                                    845 ;	keyboards/ajazz/ak820/ak820_combo.c:36: void ak820_combo_reload(void) {
                                    846 ;	-----------------------------------------
                                    847 ;	 function ak820_combo_reload
                                    848 ;	-----------------------------------------
      00357A                        849 _ak820_combo_reload:
                                    850 ;	keyboards/ajazz/ak820/ak820_combo.c:37: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00357A 7F 00            [12]  851 	mov	r7,#0x00
      00357C                        852 00105$:
      00357C BF 08 00         [24]  853 	cjne	r7,#0x08,00131$
      00357F                        854 00131$:
      00357F 40 01            [24]  855 	jc	00132$
      003581 22               [24]  856 	ret
      003582                        857 00132$:
                                    858 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = 0;
      003582 EF               [12]  859 	mov	a,r7
      003583 12 38 C6         [24]  860 	lcall	_ak820_outline_0192
      003586 24 26            [12]  861 	add	a, #_combos
      003588 FD               [12]  862 	mov	r5,a
      003589 74 04            [12]  863 	mov	a,#(_combos >> 8)
      00358B 35 F0            [12]  864 	addc	a, b
      00358D FE               [12]  865 	mov	r6,a
      00358E 8D 03            [24]  866 	mov	ar3,r5
      003590 8E 04            [24]  867 	mov	ar4,r6
      003592 12 38 7F         [24]  868 	lcall	_ak820_outline_0114
                                    869 ;	keyboards/ajazz/ak820/ak820_combo.c:40: if (!dynamic_keymap_get_combo(i, &entry)) {
      003595 90 0B B8         [24]  870 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      003598 74 52            [12]  871 	mov	a,#_ak820_combo_reload_entry_30000_610
      00359A F0               [24]  872 	movx	@dptr,a
      00359B 74 04            [12]  873 	mov	a,#(_ak820_combo_reload_entry_30000_610 >> 8)
      00359D 12 38 4B         [24]  874 	lcall	_ak820_outline_0077
      0035A0 8F 82            [24]  875 	mov	dpl, r7
      0035A2 C0 07            [24]  876 	push	ar7
      0035A4 C0 06            [24]  877 	push	ar6
      0035A6 C0 05            [24]  878 	push	ar5
      0035A8 C0 04            [24]  879 	push	ar4
      0035AA C0 03            [24]  880 	push	ar3
      0035AC 12 8A FB         [24]  881 	lcall	_dynamic_keymap_get_combo
      0035AF 12 38 92         [24]  882 	lcall	_ak820_outline_0126
      0035B2 D0 03            [24]  883 	pop	ar3
      0035B4 D0 04            [24]  884 	pop	ar4
      0035B6 D0 05            [24]  885 	pop	ar5
      0035B8 D0 06            [24]  886 	pop	ar6
      0035BA D0 07            [24]  887 	pop	ar7
      0035BC 45 F0            [12]  888 	orl	a,b
      0035BE 70 28            [24]  889 	jnz	00106$
                                    890 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].a = entry.input[0];
      0035C0 90 04 52         [24]  891 	mov	dptr,#_ak820_combo_reload_entry_30000_610
      0035C3 E0               [24]  892 	movx	a,@dptr
      0035C4 12 33 FC         [24]  893 	lcall	_ak820_outline_0125
      0035C7 F0               [24]  894 	movx	@dptr,a
                                    895 ;	keyboards/ajazz/ak820/ak820_combo.c:42: combos[i].b = entry.input[1];
      0035C8 74 01            [12]  896 	mov	a,#0x01
      0035CA 2D               [12]  897 	add	a, r5
      0035CB FB               [12]  898 	mov	r3,a
      0035CC E4               [12]  899 	clr	a
      0035CD 3E               [12]  900 	addc	a, r6
      0035CE FC               [12]  901 	mov	r4,a
      0035CF 90 04 54         [24]  902 	mov	dptr,#(_ak820_combo_reload_entry_30000_610 + 0x0002)
      0035D2 E0               [24]  903 	movx	a,@dptr
      0035D3 12 33 FC         [24]  904 	lcall	_ak820_outline_0125
      0035D6 F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_combo.c:43: combos[i].output = entry.output;
      0035D7 74 02            [12]  907 	mov	a,#0x02
      0035D9 12 38 B6         [24]  908 	lcall	_ak820_outline_0163
      0035DC 90 04 5A         [24]  909 	mov	dptr,#(_ak820_combo_reload_entry_30000_610 + 0x0008)
      0035DF 12 38 69         [24]  910 	lcall	_ak820_outline_0099
      0035E2 12 38 A7         [24]  911 	lcall	_ak820_outline_0140
      0035E5 12 38 57         [24]  912 	lcall	_ak820_outline_0082
      0035E8                        913 00106$:
                                    914 ;	keyboards/ajazz/ak820/ak820_combo.c:37: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035E8 0F               [12]  915 	inc	r7
                                    916 ;	keyboards/ajazz/ak820/ak820_combo.c:46: }
      0035E9 A1 7C            [24]  917 	ajmp	00105$
                                    918 ;------------------------------------------------------------
                                    919 ;Allocation info for local variables in function 'flush'
                                    920 ;------------------------------------------------------------
                                    921 ;	keyboards/ajazz/ak820/ak820_combo.c:47: static void flush(void) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function flush
                                    924 ;	-----------------------------------------
      0035EB                        925 _flush:
                                    926 ;	keyboards/ajazz/ak820/ak820_combo.c:48: first = NONE;
      0035EB 90 0E 92         [24]  927 	mov	dptr,#_first
      0035EE 74 FF            [12]  928 	mov	a,#0xff
      0035F0 F0               [24]  929 	movx	@dptr,a
                                    930 ;	keyboards/ajazz/ak820/ak820_combo.c:49: process_record(&saved);
      0035F1 90 04 46         [24]  931 	mov	dptr,#_saved
                                    932 ;	keyboards/ajazz/ak820/ak820_combo.c:50: }
      0035F4 02 75 BD         [24]  933 	ljmp	_process_record
                                    934 ;------------------------------------------------------------
                                    935 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    936 ;------------------------------------------------------------
                                    937 ;now           Allocated with name '_ak820_combo_tick_now_10000_615'
                                    938 ;------------------------------------------------------------
                                    939 ;	keyboards/ajazz/ak820/ak820_combo.c:51: void ak820_combo_tick(uint16_t now) {
                                    940 ;	-----------------------------------------
                                    941 ;	 function ak820_combo_tick
                                    942 ;	-----------------------------------------
      0035F7                        943 _ak820_combo_tick:
      0035F7 12 38 7A         [24]  944 	lcall	_ak820_outline_0106
      0035FA 90 04 5C         [24]  945 	mov	dptr,#_ak820_combo_tick_now_10000_615
      0035FD 12 38 75         [24]  946 	lcall	_ak820_outline_0105
                                    947 ;	keyboards/ajazz/ak820/ak820_combo.c:52: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      003600 12 38 C1         [24]  948 	lcall	_ak820_outline_0189
      003603 FF               [12]  949 	mov	r7,a
      003604 BF FF 01         [24]  950 	cjne	r7,#0xff,00128$
      003607 22               [24]  951 	ret
      003608                        952 00128$:
      003608 90 04 4F         [24]  953 	mov	dptr,#_active
      00360B E0               [24]  954 	movx	a,@dptr
      00360C 70 1E            [24]  955 	jnz	00105$
      00360E 90 04 48         [24]  956 	mov	dptr,#(_saved + 0x0002)
      003611 12 38 2E         [24]  957 	lcall	_ak820_outline_0059
      003614 90 04 5C         [24]  958 	mov	dptr,#_ak820_combo_tick_now_10000_615
      003617 12 38 45         [24]  959 	lcall	_ak820_outline_0065
      00361A EC               [12]  960 	mov	a,r4
      00361B C3               [12]  961 	clr	c
      00361C 9E               [12]  962 	subb	a,r6
      00361D FE               [12]  963 	mov	r6,a
      00361E ED               [12]  964 	mov	a,r5
      00361F 9F               [12]  965 	subb	a,r7
      003620 FF               [12]  966 	mov	r7,a
      003621 C3               [12]  967 	clr	c
      003622 EE               [12]  968 	mov	a,r6
      003623 94 28            [12]  969 	subb	a,#0x28
      003625 EF               [12]  970 	mov	a,r7
      003626 94 00            [12]  971 	subb	a,#0x00
      003628 40 02            [24]  972 	jc	00105$
                                    973 ;	keyboards/ajazz/ak820/ak820_combo.c:53: }
      00362A A1 EB            [24]  974 	ajmp	_flush
      00362C                        975 00105$:
      00362C 22               [24]  976 	ret
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'ak820_combo_process'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_ak820_combo_process_record_10000_618'
                                    981 ;id            Allocated with name '_ak820_combo_process_id_10000_619'
                                    982 ;code          Allocated with name '_ak820_combo_process_code_10000_619'
                                    983 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_633'
                                    984 ;previous      Allocated with name '_ak820_combo_process_previous_30001_635'
                                    985 ;i             Allocated with name '_ak820_combo_process_i_40001_636'
                                    986 ;a             Allocated with name '_ak820_combo_process_a_50001_637'
                                    987 ;b             Allocated with name '_ak820_combo_process_b_50001_637'
                                    988 ;------------------------------------------------------------
                                    989 ;	keyboards/ajazz/ak820/ak820_combo.c:54: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    990 ;	-----------------------------------------
                                    991 ;	 function ak820_combo_process
                                    992 ;	-----------------------------------------
      00362D                        993 _ak820_combo_process:
      00362D 12 38 7A         [24]  994 	lcall	_ak820_outline_0106
      003630 90 04 5E         [24]  995 	mov	dptr,#_ak820_combo_process_record_10000_618
      003633 12 38 75         [24]  996 	lcall	_ak820_outline_0105
                                    997 ;	keyboards/ajazz/ak820/ak820_combo.c:55: uint8_t id, code = record->keycode;
      003636 90 04 5E         [24]  998 	mov	dptr,#_ak820_combo_process_record_10000_618
      003639 12 37 F3         [24]  999 	lcall	_ak820_outline_0008
      00363C FC               [12] 1000 	mov	r4,a
      00363D A3               [24] 1001 	inc	dptr
      00363E E0               [24] 1002 	movx	a,@dptr
      00363F FD               [12] 1003 	mov	r5,a
      003640 8C 03            [24] 1004 	mov	ar3,r4
                                   1005 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (IS_NOEVENT(record->event)) return true;
      003642 74 04            [12] 1006 	mov	a,#0x04
      003644 2E               [12] 1007 	add	a, r6
      003645 12 38 03         [24] 1008 	lcall	_ak820_outline_0017
      003648 70 04            [24] 1009 	jnz	00102$
      00364A 75 82 01         [24] 1010 	mov	dpl, #0x01
      00364D 22               [24] 1011 	ret
      00364E                       1012 00102$:
                                   1013 ;	keyboards/ajazz/ak820/ak820_combo.c:58: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00364E 12 38 86         [24] 1014 	lcall	_ak820_outline_0115
      003651 FA               [12] 1015 	mov	r2,a
      003652 BA 10 00         [24] 1016 	cjne	r2,#0x10,00300$
      003655                       1017 00300$:
      003655 50 09            [24] 1018 	jnc	00106$
      003657 12 38 6F         [24] 1019 	lcall	_ak820_outline_0103
      00365A F9               [12] 1020 	mov	r1,a
      00365B B9 08 00         [24] 1021 	cjne	r1,#0x08,00302$
      00365E                       1022 00302$:
      00365E 40 15            [24] 1023 	jc	00107$
      003660                       1024 00106$:
                                   1025 ;	keyboards/ajazz/ak820/ak820_combo.c:59: if (first != NONE && !active) flush();
      003660 12 38 C1         [24] 1026 	lcall	_ak820_outline_0189
      003663 F8               [12] 1027 	mov	r0,a
      003664 B8 FF 02         [24] 1028 	cjne	r0,#0xff,00304$
      003667 80 08            [24] 1029 	sjmp	00104$
      003669                       1030 00304$:
      003669 90 04 4F         [24] 1031 	mov	dptr,#_active
      00366C E0               [24] 1032 	movx	a,@dptr
      00366D 70 02            [24] 1033 	jnz	00104$
      00366F B1 EB            [24] 1034 	acall	_flush
      003671                       1035 00104$:
                                   1036 ;	keyboards/ajazz/ak820/ak820_combo.c:60: return true;
      003671 75 82 01         [24] 1037 	mov	dpl, #0x01
      003674 22               [24] 1038 	ret
      003675                       1039 00107$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_combo.c:62: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003675 EA               [12] 1041 	mov	a,r2
      003676 12 38 BC         [24] 1042 	lcall	_ak820_outline_0176
      003679 29               [12] 1043 	add	a,r1
      00367A FA               [12] 1044 	mov	r2,a
                                   1045 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (active) {
      00367B 90 04 4F         [24] 1046 	mov	dptr,#_active
      00367E E0               [24] 1047 	movx	a,@dptr
      00367F 60 6F            [24] 1048 	jz	00123$
                                   1049 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (id != first && id != second) return true;
      003681 12 38 C1         [24] 1050 	lcall	_ak820_outline_0189
      003684 F9               [12] 1051 	mov	r1,a
      003685 EA               [12] 1052 	mov	a,r2
      003686 B5 01 02         [24] 1053 	cjne	a,ar1,00307$
      003689 80 0F            [24] 1054 	sjmp	00110$
      00368B                       1055 00307$:
      00368B 90 0E 93         [24] 1056 	mov	dptr,#_second
      00368E E0               [24] 1057 	movx	a,@dptr
      00368F F9               [12] 1058 	mov	r1,a
      003690 EA               [12] 1059 	mov	a,r2
      003691 B5 01 02         [24] 1060 	cjne	a,ar1,00308$
      003694 80 04            [24] 1061 	sjmp	00110$
      003696                       1062 00308$:
      003696 75 82 01         [24] 1063 	mov	dpl, #0x01
      003699 22               [24] 1064 	ret
      00369A                       1065 00110$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_combo.c:65: if (!record->event.pressed) {
      00369A 90 04 5E         [24] 1067 	mov	dptr,#_ak820_combo_process_record_10000_618
      00369D 12 38 63         [24] 1068 	lcall	_ak820_outline_0098
      0036A0 74 05            [12] 1069 	mov	a,#0x05
      0036A2 28               [12] 1070 	add	a, r0
      0036A3 F8               [12] 1071 	mov	r0,a
      0036A4 E4               [12] 1072 	clr	a
      0036A5 39               [12] 1073 	addc	a, r1
      0036A6 F9               [12] 1074 	mov	r1,a
      0036A7 12 38 B1         [24] 1075 	lcall	_ak820_outline_0153
      0036AA E0               [24] 1076 	movx	a,@dptr
      0036AB 70 3F            [24] 1077 	jnz	00121$
                                   1078 ;	keyboards/ajazz/ak820/ak820_combo.c:66: if (saved.event.pressed) {
      0036AD 90 04 4B         [24] 1079 	mov	dptr,#(_saved + 0x0005)
      0036B0 E0               [24] 1080 	movx	a,@dptr
      0036B1 60 0F            [24] 1081 	jz	00113$
                                   1082 ;	keyboards/ajazz/ak820/ak820_combo.c:67: saved.event.pressed = false;
      0036B3 90 04 4B         [24] 1083 	mov	dptr,#(_saved + 0x0005)
      0036B6 E4               [12] 1084 	clr	a
      0036B7 F0               [24] 1085 	movx	@dptr,a
                                   1086 ;	keyboards/ajazz/ak820/ak820_combo.c:68: process_record(&saved);
      0036B8 90 04 46         [24] 1087 	mov	dptr,#_saved
      0036BB C0 02            [24] 1088 	push	ar2
      0036BD 12 75 BD         [24] 1089 	lcall	_process_record
      0036C0 D0 02            [24] 1090 	pop	ar2
      0036C2                       1091 00113$:
                                   1092 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (id == first) first = NONE;
      0036C2 12 38 C1         [24] 1093 	lcall	_ak820_outline_0189
      0036C5 F9               [12] 1094 	mov	r1,a
      0036C6 EA               [12] 1095 	mov	a,r2
      0036C7 B5 01 08         [24] 1096 	cjne	a,ar1,00115$
      0036CA 90 0E 92         [24] 1097 	mov	dptr,#_first
      0036CD 74 FF            [12] 1098 	mov	a,#0xff
      0036CF F0               [24] 1099 	movx	@dptr,a
      0036D0 80 06            [24] 1100 	sjmp	00116$
      0036D2                       1101 00115$:
                                   1102 ;	keyboards/ajazz/ak820/ak820_combo.c:71: else second = NONE;
      0036D2 90 0E 93         [24] 1103 	mov	dptr,#_second
      0036D5 74 FF            [12] 1104 	mov	a,#0xff
      0036D7 F0               [24] 1105 	movx	@dptr,a
      0036D8                       1106 00116$:
                                   1107 ;	keyboards/ajazz/ak820/ak820_combo.c:72: if (first == NONE && second == NONE) active = false;
      0036D8 12 38 C1         [24] 1108 	lcall	_ak820_outline_0189
      0036DB F9               [12] 1109 	mov	r1,a
      0036DC B9 FF 0D         [24] 1110 	cjne	r1,#0xff,00121$
      0036DF 90 0E 93         [24] 1111 	mov	dptr,#_second
      0036E2 E0               [24] 1112 	movx	a,@dptr
      0036E3 F9               [12] 1113 	mov	r1,a
      0036E4 B9 FF 05         [24] 1114 	cjne	r1,#0xff,00121$
      0036E7 90 04 4F         [24] 1115 	mov	dptr,#_active
      0036EA E4               [12] 1116 	clr	a
      0036EB F0               [24] 1117 	movx	@dptr,a
      0036EC                       1118 00121$:
                                   1119 ;	keyboards/ajazz/ak820/ak820_combo.c:74: return false;
      0036EC 75 82 00         [24] 1120 	mov	dpl, #0x00
      0036EF 22               [24] 1121 	ret
      0036F0                       1122 00123$:
                                   1123 ;	keyboards/ajazz/ak820/ak820_combo.c:76: bool eligible = false;
      0036F0 90 04 60         [24] 1124 	mov	dptr,#_ak820_combo_process_eligible_10001_633
      0036F3 E4               [12] 1125 	clr	a
      0036F4 F0               [24] 1126 	movx	@dptr,a
                                   1127 ;	keyboards/ajazz/ak820/ak820_combo.c:77: if (record->event.pressed && input(record->keycode)) {
      0036F5 12 37 E6         [24] 1128 	lcall	_ak820_outline_0006
      0036F8 70 02            [24] 1129 	jnz	00317$
      0036FA E1 9B            [12] 1130 	ajmp	00134$
      0036FC                       1131 00317$:
      0036FC 12 38 98         [24] 1132 	lcall	_ak820_outline_0129
      0036FF C0 03            [24] 1133 	push	ar3
      003701 C0 02            [24] 1134 	push	ar2
      003703 91 68            [12] 1135 	acall	_input
      003705 E5 82            [12] 1136 	mov	a, dpl
      003707 D0 02            [24] 1137 	pop	ar2
      003709 D0 03            [24] 1138 	pop	ar3
      00370B 70 02            [24] 1139 	jnz	00318$
      00370D E1 9B            [12] 1140 	ajmp	00134$
      00370F                       1141 00318$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t previous = saved.keycode;
      00370F 90 04 4D         [24] 1143 	mov	dptr,#(_saved + 0x0007)
      003712 E0               [24] 1144 	movx	a,@dptr
      003713 FF               [12] 1145 	mov	r7,a
                                   1146 ;	keyboards/ajazz/ak820/ak820_combo.c:79: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003714 90 04 61         [24] 1147 	mov	dptr,#_ak820_combo_process_i_40001_636
      003717 E4               [12] 1148 	clr	a
      003718 F0               [24] 1149 	movx	@dptr,a
      003719 EB               [12] 1150 	mov	a,r3
      00371A B5 07 03         [24] 1151 	cjne	a,ar7,00319$
      00371D D3               [12] 1152 	setb	c
      00371E 80 01            [24] 1153 	sjmp	00320$
      003720                       1154 00319$:
      003720 C3               [12] 1155 	clr	c
      003721                       1156 00320$:
      003721 92 03            [24] 1157 	mov	_ak820_combo_process_sloc0_1_0,c
      003723 7E 00            [12] 1158 	mov	r6,#0x00
      003725                       1159 00141$:
      003725 BE 08 00         [24] 1160 	cjne	r6,#0x08,00321$
      003728                       1161 00321$:
      003728 40 02            [24] 1162 	jc	00322$
      00372A E1 9B            [12] 1163 	ajmp	00134$
      00372C                       1164 00322$:
                                   1165 ;	keyboards/ajazz/ak820/ak820_combo.c:80: uint8_t a = combos[i].a, b = combos[i].b;
      00372C EE               [12] 1166 	mov	a,r6
      00372D 12 38 34         [24] 1167 	lcall	_ak820_outline_0061
      003730 E0               [24] 1168 	movx	a,@dptr
      003731 F9               [12] 1169 	mov	r1,a
      003732 90 04 62         [24] 1170 	mov	dptr,#_ak820_combo_process_a_50001_637
      003735 F0               [24] 1171 	movx	@dptr,a
      003736 12 38 98         [24] 1172 	lcall	_ak820_outline_0129
      003739 A3               [24] 1173 	inc	dptr
      00373A E0               [24] 1174 	movx	a,@dptr
      00373B FD               [12] 1175 	mov	r5,a
      00373C 90 04 63         [24] 1176 	mov	dptr,#_ak820_combo_process_b_50001_637
      00373F F0               [24] 1177 	movx	@dptr,a
                                   1178 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (a == code || b == code) {
      003740 E9               [12] 1179 	mov	a,r1
      003741 B5 03 02         [24] 1180 	cjne	a,ar3,00323$
      003744 80 04            [24] 1181 	sjmp	00129$
      003746                       1182 00323$:
      003746 ED               [12] 1183 	mov	a,r5
      003747 B5 03 49         [24] 1184 	cjne	a,ar3,00142$
      00374A                       1185 00129$:
                                   1186 ;	keyboards/ajazz/ak820/ak820_combo.c:82: eligible = true;
      00374A 90 04 60         [24] 1187 	mov	dptr,#_ak820_combo_process_eligible_10001_633
      00374D 74 01            [12] 1188 	mov	a,#0x01
      00374F F0               [24] 1189 	movx	@dptr,a
                                   1190 ;	keyboards/ajazz/ak820/ak820_combo.c:83: if (first != NONE && code != previous && (a == previous || b == previous)) {
      003750 12 38 C1         [24] 1191 	lcall	_ak820_outline_0189
      003753 FD               [12] 1192 	mov	r5,a
      003754 BD FF 02         [24] 1193 	cjne	r5,#0xff,00326$
      003757 80 3A            [24] 1194 	sjmp	00142$
      003759                       1195 00326$:
      003759 20 03 37         [24] 1196 	jb	_ak820_combo_process_sloc0_1_0,00142$
      00375C 90 04 62         [24] 1197 	mov	dptr,#_ak820_combo_process_a_50001_637
      00375F E0               [24] 1198 	movx	a,@dptr
      003760 B5 07 02         [24] 1199 	cjne	a,ar7,00328$
      003763 80 07            [24] 1200 	sjmp	00124$
      003765                       1201 00328$:
      003765 90 04 63         [24] 1202 	mov	dptr,#_ak820_combo_process_b_50001_637
      003768 E0               [24] 1203 	movx	a,@dptr
      003769 B5 07 27         [24] 1204 	cjne	a,ar7,00142$
      00376C                       1205 00124$:
                                   1206 ;	keyboards/ajazz/ak820/ak820_combo.c:84: second = id;
      00376C 90 0E 93         [24] 1207 	mov	dptr,#_second
      00376F EA               [12] 1208 	mov	a,r2
      003770 F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_combo.c:85: active = true;
      003771 90 04 4F         [24] 1211 	mov	dptr,#_active
      003774 74 01            [12] 1212 	mov	a,#0x01
      003776 F0               [24] 1213 	movx	@dptr,a
                                   1214 ;	keyboards/ajazz/ak820/ak820_combo.c:86: saved.keycode = combos[i].output;
      003777 90 04 61         [24] 1215 	mov	dptr,#_ak820_combo_process_i_40001_636
      00377A E0               [24] 1216 	movx	a,@dptr
      00377B 12 38 34         [24] 1217 	lcall	_ak820_outline_0061
      00377E A3               [24] 1218 	inc	dptr
      00377F A3               [24] 1219 	inc	dptr
      003780 12 38 45         [24] 1220 	lcall	_ak820_outline_0065
      003783 90 04 4D         [24] 1221 	mov	dptr,#(_saved + 0x0007)
      003786 12 38 51         [24] 1222 	lcall	_ak820_outline_0079
                                   1223 ;	keyboards/ajazz/ak820/ak820_combo.c:87: process_record(&saved);
      003789 90 04 46         [24] 1224 	mov	dptr,#_saved
      00378C 12 75 BD         [24] 1225 	lcall	_process_record
                                   1226 ;	keyboards/ajazz/ak820/ak820_combo.c:88: return false;
      00378F 75 82 00         [24] 1227 	mov	dpl, #0x00
      003792 22               [24] 1228 	ret
      003793                       1229 00142$:
                                   1230 ;	keyboards/ajazz/ak820/ak820_combo.c:79: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003793 0E               [12] 1231 	inc	r6
      003794 90 04 61         [24] 1232 	mov	dptr,#_ak820_combo_process_i_40001_636
      003797 EE               [12] 1233 	mov	a,r6
      003798 F0               [24] 1234 	movx	@dptr,a
      003799 E1 25            [24] 1235 	ajmp	00141$
      00379B                       1236 00134$:
                                   1237 ;	keyboards/ajazz/ak820/ak820_combo.c:93: if (first != NONE) flush();
      00379B 12 38 C1         [24] 1238 	lcall	_ak820_outline_0189
      00379E FF               [12] 1239 	mov	r7,a
      00379F BF FF 02         [24] 1240 	cjne	r7,#0xff,00331$
      0037A2 80 06            [24] 1241 	sjmp	00137$
      0037A4                       1242 00331$:
      0037A4 C0 02            [24] 1243 	push	ar2
      0037A6 B1 EB            [24] 1244 	acall	_flush
      0037A8 D0 02            [24] 1245 	pop	ar2
      0037AA                       1246 00137$:
                                   1247 ;	keyboards/ajazz/ak820/ak820_combo.c:94: if (eligible) {
      0037AA 90 04 60         [24] 1248 	mov	dptr,#_ak820_combo_process_eligible_10001_633
      0037AD E0               [24] 1249 	movx	a,@dptr
      0037AE 60 28            [24] 1250 	jz	00139$
                                   1251 ;	keyboards/ajazz/ak820/ak820_combo.c:95: first = id;
      0037B0 90 0E 92         [24] 1252 	mov	dptr,#_first
      0037B3 EA               [12] 1253 	mov	a,r2
      0037B4 F0               [24] 1254 	movx	@dptr,a
                                   1255 ;	keyboards/ajazz/ak820/ak820_combo.c:96: saved = *record;
      0037B5 90 04 5E         [24] 1256 	mov	dptr,#_ak820_combo_process_record_10000_618
      0037B8 12 38 5D         [24] 1257 	lcall	_ak820_outline_0085
      0037BB 7F 00            [12] 1258 	mov	r7,#0x00
      0037BD 90 0E 84         [24] 1259 	mov	dptr,#___memcpy_PARM_2
      0037C0 ED               [12] 1260 	mov	a,r5
      0037C1 12 38 0D         [24] 1261 	lcall	_ak820_outline_0019
      0037C4 90 0E 87         [24] 1262 	mov	dptr,#___memcpy_PARM_3
      0037C7 74 09            [12] 1263 	mov	a,#0x09
      0037C9 12 38 9D         [24] 1264 	lcall	_ak820_outline_0130
      0037CC 90 04 46         [24] 1265 	mov	dptr,#_saved
      0037CF F5 F0            [12] 1266 	mov	b,a
      0037D1 12 BE 0C         [24] 1267 	lcall	___memcpy
                                   1268 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return false;
      0037D4 75 82 00         [24] 1269 	mov	dpl, #0x00
      0037D7 22               [24] 1270 	ret
      0037D8                       1271 00139$:
                                   1272 ;	keyboards/ajazz/ak820/ak820_combo.c:99: return true;
      0037D8 75 82 01         [24] 1273 	mov	dpl, #0x01
                                   1274 ;	keyboards/ajazz/ak820/ak820_combo.c:100: }
      0037DB 22               [24] 1275 	ret
                                   1276 	.area CSEG    (CODE)
                                   1277 	.area CONST   (CODE)
                                   1278 	.area XINIT   (CODE)
      00C6CA                       1279 __xinit__first:
      00C6CA FF                    1280 	.db #0xff	; 255
      00C6CB                       1281 __xinit__second:
      00C6CB FF                    1282 	.db #0xff	; 255
                                   1283 	.area CABS    (ABS,CODE)
                                   1284 
                                   1285 ; Experimental exact instruction outlining.
                                   1286 	.globl _ak820_outline_0005
                                   1287 	.globl _ak820_outline_0006
                                   1288 	.globl _ak820_outline_0008
                                   1289 	.globl _ak820_outline_0017
                                   1290 	.globl _ak820_outline_0019
                                   1291 	.globl _ak820_outline_0020
                                   1292 	.globl _ak820_outline_0034
                                   1293 	.globl _ak820_outline_0036
                                   1294 	.globl _ak820_outline_0059
                                   1295 	.globl _ak820_outline_0061
                                   1296 	.globl _ak820_outline_0065
                                   1297 	.globl _ak820_outline_0077
                                   1298 	.globl _ak820_outline_0079
                                   1299 	.globl _ak820_outline_0082
                                   1300 	.globl _ak820_outline_0085
                                   1301 	.globl _ak820_outline_0098
                                   1302 	.globl _ak820_outline_0099
                                   1303 	.globl _ak820_outline_0103
                                   1304 	.globl _ak820_outline_0105
                                   1305 	.globl _ak820_outline_0106
                                   1306 	.globl _ak820_outline_0114
                                   1307 	.globl _ak820_outline_0115
                                   1308 	.globl _ak820_outline_0121
                                   1309 	.globl _ak820_outline_0125
                                   1310 	.globl _ak820_outline_0126
                                   1311 	.globl _ak820_outline_0129
                                   1312 	.globl _ak820_outline_0130
                                   1313 	.globl _ak820_outline_0131
                                   1314 	.globl _ak820_outline_0140
                                   1315 	.globl _ak820_outline_0147
                                   1316 	.globl _ak820_outline_0153
                                   1317 	.globl _ak820_outline_0163
                                   1318 	.globl _ak820_outline_0176
                                   1319 	.globl _ak820_outline_0189
                                   1320 	.globl _ak820_outline_0192
                                   1321 
                                   1322 	.area CSEG (CODE)
                                   1323 ; function ak820_outline_0005
      0037DC                       1324 _ak820_outline_0005:
      0037DC E0               [24] 1325 	movx	a,@dptr
      0037DD FE               [12] 1326 	mov	r6,a
      0037DE A3               [24] 1327 	inc	dptr
      0037DF E0               [24] 1328 	movx	a,@dptr
      0037E0 FF               [12] 1329 	mov	r7,a
      0037E1 8E 82            [24] 1330 	mov	dpl,r6
      0037E3 8F 83            [24] 1331 	mov	dph,r7
      0037E5 22               [24] 1332 	ret
                                   1333 
                                   1334 	.area CSEG (CODE)
                                   1335 ; function ak820_outline_0006
      0037E6                       1336 _ak820_outline_0006:
      0037E6 74 05            [12] 1337 	mov	a,#0x05
      0037E8 2E               [12] 1338 	add	a,r6
      0037E9 FE               [12] 1339 	mov	r6,a
      0037EA E4               [12] 1340 	clr	a
      0037EB 3F               [12] 1341 	addc	a,r7
      0037EC FF               [12] 1342 	mov	r7,a
      0037ED 8E 82            [24] 1343 	mov	dpl,r6
      0037EF 8F 83            [24] 1344 	mov	dph,r7
      0037F1 E0               [24] 1345 	movx	a,@dptr
      0037F2 22               [24] 1346 	ret
                                   1347 
                                   1348 	.area CSEG (CODE)
                                   1349 ; function ak820_outline_0008
      0037F3                       1350 _ak820_outline_0008:
      0037F3 E0               [24] 1351 	movx	a,@dptr
      0037F4 FE               [12] 1352 	mov	r6,a
      0037F5 A3               [24] 1353 	inc	dptr
      0037F6 E0               [24] 1354 	movx	a,@dptr
      0037F7 FF               [12] 1355 	mov	r7,a
      0037F8 74 07            [12] 1356 	mov	a,#0x07
      0037FA 2E               [12] 1357 	add	a,r6
      0037FB F5 82            [12] 1358 	mov	dpl,a
      0037FD E4               [12] 1359 	clr	a
      0037FE 3F               [12] 1360 	addc	a,r7
      0037FF F5 83            [12] 1361 	mov	dph,a
      003801 E0               [24] 1362 	movx	a,@dptr
      003802 22               [24] 1363 	ret
                                   1364 
                                   1365 	.area CSEG (CODE)
                                   1366 ; function ak820_outline_0017
      003803                       1367 _ak820_outline_0017:
      003803 F9               [12] 1368 	mov	r1,a
      003804 E4               [12] 1369 	clr	a
      003805 3F               [12] 1370 	addc	a,r7
      003806 FA               [12] 1371 	mov	r2,a
      003807 89 82            [24] 1372 	mov	dpl,r1
      003809 8A 83            [24] 1373 	mov	dph,r2
      00380B E0               [24] 1374 	movx	a,@dptr
      00380C 22               [24] 1375 	ret
                                   1376 
                                   1377 	.area CSEG (CODE)
                                   1378 ; function ak820_outline_0019
      00380D                       1379 _ak820_outline_0019:
      00380D F0               [24] 1380 	movx	@dptr,a
      00380E EE               [12] 1381 	mov	a,r6
      00380F A3               [24] 1382 	inc	dptr
      003810 F0               [24] 1383 	movx	@dptr,a
      003811 EF               [12] 1384 	mov	a,r7
      003812 A3               [24] 1385 	inc	dptr
      003813 F0               [24] 1386 	movx	@dptr,a
      003814 22               [24] 1387 	ret
                                   1388 
                                   1389 	.area CSEG (CODE)
                                   1390 ; function ak820_outline_0020
      003815                       1391 _ak820_outline_0020:
      003815 2E               [12] 1392 	add	a,r6
      003816 F5 82            [12] 1393 	mov	dpl,a
      003818 E4               [12] 1394 	clr	a
      003819 3F               [12] 1395 	addc	a,r7
      00381A F5 83            [12] 1396 	mov	dph,a
      00381C E0               [24] 1397 	movx	a,@dptr
      00381D 22               [24] 1398 	ret
                                   1399 
                                   1400 	.area CSEG (CODE)
                                   1401 ; function ak820_outline_0034
      00381E                       1402 _ak820_outline_0034:
      00381E 8E 82            [24] 1403 	mov	dpl,r6
      003820 8F 83            [24] 1404 	mov	dph,r7
      003822 A3               [24] 1405 	inc	dptr
      003823 A3               [24] 1406 	inc	dptr
      003824 E0               [24] 1407 	movx	a,@dptr
      003825 22               [24] 1408 	ret
                                   1409 
                                   1410 	.area CSEG (CODE)
                                   1411 ; function ak820_outline_0036
      003826                       1412 _ak820_outline_0036:
      003826 2E               [12] 1413 	add	a,r6
      003827 F5 82            [12] 1414 	mov	dpl,a
      003829 E4               [12] 1415 	clr	a
      00382A 3F               [12] 1416 	addc	a,r7
      00382B F5 83            [12] 1417 	mov	dph,a
      00382D 22               [24] 1418 	ret
                                   1419 
                                   1420 	.area CSEG (CODE)
                                   1421 ; function ak820_outline_0059
      00382E                       1422 _ak820_outline_0059:
      00382E E0               [24] 1423 	movx	a,@dptr
      00382F FE               [12] 1424 	mov	r6,a
      003830 A3               [24] 1425 	inc	dptr
      003831 E0               [24] 1426 	movx	a,@dptr
      003832 FF               [12] 1427 	mov	r7,a
      003833 22               [24] 1428 	ret
                                   1429 
                                   1430 	.area CSEG (CODE)
                                   1431 ; function ak820_outline_0061
      003834                       1432 _ak820_outline_0061:
      003834 75 F0 04         [24] 1433 	mov	b,#0x04
      003837 A4               [48] 1434 	mul	ab
      003838 24 26            [12] 1435 	add	a,#_combos
      00383A FC               [12] 1436 	mov	r4,a
      00383B 74 04            [12] 1437 	mov	a,#(_combos>>8)
      00383D 35 F0            [12] 1438 	addc	a,b
      00383F FD               [12] 1439 	mov	r5,a
      003840 8C 82            [24] 1440 	mov	dpl,r4
      003842 8D 83            [24] 1441 	mov	dph,r5
      003844 22               [24] 1442 	ret
                                   1443 
                                   1444 	.area CSEG (CODE)
                                   1445 ; function ak820_outline_0065
      003845                       1446 _ak820_outline_0065:
      003845 E0               [24] 1447 	movx	a,@dptr
      003846 FC               [12] 1448 	mov	r4,a
      003847 A3               [24] 1449 	inc	dptr
      003848 E0               [24] 1450 	movx	a,@dptr
      003849 FD               [12] 1451 	mov	r5,a
      00384A 22               [24] 1452 	ret
                                   1453 
                                   1454 	.area CSEG (CODE)
                                   1455 ; function ak820_outline_0077
      00384B                       1456 _ak820_outline_0077:
      00384B A3               [24] 1457 	inc	dptr
      00384C F0               [24] 1458 	movx	@dptr,a
      00384D E4               [12] 1459 	clr	a
      00384E A3               [24] 1460 	inc	dptr
      00384F F0               [24] 1461 	movx	@dptr,a
      003850 22               [24] 1462 	ret
                                   1463 
                                   1464 	.area CSEG (CODE)
                                   1465 ; function ak820_outline_0079
      003851                       1466 _ak820_outline_0079:
      003851 EC               [12] 1467 	mov	a,r4
      003852 F0               [24] 1468 	movx	@dptr,a
      003853 ED               [12] 1469 	mov	a,r5
      003854 A3               [24] 1470 	inc	dptr
      003855 F0               [24] 1471 	movx	@dptr,a
      003856 22               [24] 1472 	ret
                                   1473 
                                   1474 	.area CSEG (CODE)
                                   1475 ; function ak820_outline_0082
      003857                       1476 _ak820_outline_0082:
      003857 EB               [12] 1477 	mov	a,r3
      003858 F0               [24] 1478 	movx	@dptr,a
      003859 EC               [12] 1479 	mov	a,r4
      00385A A3               [24] 1480 	inc	dptr
      00385B F0               [24] 1481 	movx	@dptr,a
      00385C 22               [24] 1482 	ret
                                   1483 
                                   1484 	.area CSEG (CODE)
                                   1485 ; function ak820_outline_0085
      00385D                       1486 _ak820_outline_0085:
      00385D E0               [24] 1487 	movx	a,@dptr
      00385E FD               [12] 1488 	mov	r5,a
      00385F A3               [24] 1489 	inc	dptr
      003860 E0               [24] 1490 	movx	a,@dptr
      003861 FE               [12] 1491 	mov	r6,a
      003862 22               [24] 1492 	ret
                                   1493 
                                   1494 	.area CSEG (CODE)
                                   1495 ; function ak820_outline_0098
      003863                       1496 _ak820_outline_0098:
      003863 E0               [24] 1497 	movx	a,@dptr
      003864 F8               [12] 1498 	mov	r0,a
      003865 A3               [24] 1499 	inc	dptr
      003866 E0               [24] 1500 	movx	a,@dptr
      003867 F9               [12] 1501 	mov	r1,a
      003868 22               [24] 1502 	ret
                                   1503 
                                   1504 	.area CSEG (CODE)
                                   1505 ; function ak820_outline_0099
      003869                       1506 _ak820_outline_0099:
      003869 E0               [24] 1507 	movx	a,@dptr
      00386A FB               [12] 1508 	mov	r3,a
      00386B A3               [24] 1509 	inc	dptr
      00386C E0               [24] 1510 	movx	a,@dptr
      00386D FC               [12] 1511 	mov	r4,a
      00386E 22               [24] 1512 	ret
                                   1513 
                                   1514 	.area CSEG (CODE)
                                   1515 ; function ak820_outline_0103
      00386F                       1516 _ak820_outline_0103:
      00386F 8E 82            [24] 1517 	mov	dpl,r6
      003871 8F 83            [24] 1518 	mov	dph,r7
      003873 E0               [24] 1519 	movx	a,@dptr
      003874 22               [24] 1520 	ret
                                   1521 
                                   1522 	.area CSEG (CODE)
                                   1523 ; function ak820_outline_0105
      003875                       1524 _ak820_outline_0105:
      003875 F0               [24] 1525 	movx	@dptr,a
      003876 EF               [12] 1526 	mov	a,r7
      003877 A3               [24] 1527 	inc	dptr
      003878 F0               [24] 1528 	movx	@dptr,a
      003879 22               [24] 1529 	ret
                                   1530 
                                   1531 	.area CSEG (CODE)
                                   1532 ; function ak820_outline_0106
      00387A                       1533 _ak820_outline_0106:
      00387A AF 83            [24] 1534 	mov	r7,dph
      00387C E5 82            [12] 1535 	mov	a,dpl
      00387E 22               [24] 1536 	ret
                                   1537 
                                   1538 	.area CSEG (CODE)
                                   1539 ; function ak820_outline_0114
      00387F                       1540 _ak820_outline_0114:
      00387F 8B 82            [24] 1541 	mov	dpl,r3
      003881 8C 83            [24] 1542 	mov	dph,r4
      003883 E4               [12] 1543 	clr	a
      003884 F0               [24] 1544 	movx	@dptr,a
      003885 22               [24] 1545 	ret
                                   1546 
                                   1547 	.area CSEG (CODE)
                                   1548 ; function ak820_outline_0115
      003886                       1549 _ak820_outline_0115:
      003886 8E 82            [24] 1550 	mov	dpl,r6
      003888 8F 83            [24] 1551 	mov	dph,r7
      00388A A3               [24] 1552 	inc	dptr
      00388B E0               [24] 1553 	movx	a,@dptr
      00388C 22               [24] 1554 	ret
                                   1555 
                                   1556 	.area CSEG (CODE)
                                   1557 ; function ak820_outline_0121
      00388D                       1558 _ak820_outline_0121:
      00388D 8E 82            [24] 1559 	mov	dpl,r6
      00388F 8F 83            [24] 1560 	mov	dph,r7
      003891 22               [24] 1561 	ret
                                   1562 
                                   1563 	.area CSEG (CODE)
                                   1564 ; function ak820_outline_0126
      003892                       1565 _ak820_outline_0126:
      003892 E5 82            [12] 1566 	mov	a,dpl
      003894 85 83 F0         [24] 1567 	mov	b,dph
      003897 22               [24] 1568 	ret
                                   1569 
                                   1570 	.area CSEG (CODE)
                                   1571 ; function ak820_outline_0129
      003898                       1572 _ak820_outline_0129:
      003898 8C 82            [24] 1573 	mov	dpl,r4
      00389A 8D 83            [24] 1574 	mov	dph,r5
      00389C 22               [24] 1575 	ret
                                   1576 
                                   1577 	.area CSEG (CODE)
                                   1578 ; function ak820_outline_0130
      00389D                       1579 _ak820_outline_0130:
      00389D F0               [24] 1580 	movx	@dptr,a
      00389E E4               [12] 1581 	clr	a
      00389F A3               [24] 1582 	inc	dptr
      0038A0 F0               [24] 1583 	movx	@dptr,a
      0038A1 22               [24] 1584 	ret
                                   1585 
                                   1586 	.area CSEG (CODE)
                                   1587 ; function ak820_outline_0131
      0038A2                       1588 _ak820_outline_0131:
      0038A2 8A 82            [24] 1589 	mov	dpl,r2
      0038A4 8B 83            [24] 1590 	mov	dph,r3
      0038A6 22               [24] 1591 	ret
                                   1592 
                                   1593 	.area CSEG (CODE)
                                   1594 ; function ak820_outline_0140
      0038A7                       1595 _ak820_outline_0140:
      0038A7 8D 82            [24] 1596 	mov	dpl,r5
      0038A9 8E 83            [24] 1597 	mov	dph,r6
      0038AB 22               [24] 1598 	ret
                                   1599 
                                   1600 	.area CSEG (CODE)
                                   1601 ; function ak820_outline_0147
      0038AC                       1602 _ak820_outline_0147:
      0038AC E4               [12] 1603 	clr	a
      0038AD 33               [12] 1604 	rlc	a
      0038AE F5 82            [12] 1605 	mov	dpl,a
      0038B0 22               [24] 1606 	ret
                                   1607 
                                   1608 	.area CSEG (CODE)
                                   1609 ; function ak820_outline_0153
      0038B1                       1610 _ak820_outline_0153:
      0038B1 88 82            [24] 1611 	mov	dpl,r0
      0038B3 89 83            [24] 1612 	mov	dph,r1
      0038B5 22               [24] 1613 	ret
                                   1614 
                                   1615 	.area CSEG (CODE)
                                   1616 ; function ak820_outline_0163
      0038B6                       1617 _ak820_outline_0163:
      0038B6 2D               [12] 1618 	add	a,r5
      0038B7 FD               [12] 1619 	mov	r5,a
      0038B8 E4               [12] 1620 	clr	a
      0038B9 3E               [12] 1621 	addc	a,r6
      0038BA FE               [12] 1622 	mov	r6,a
      0038BB 22               [24] 1623 	ret
                                   1624 
                                   1625 	.area CSEG (CODE)
                                   1626 ; function ak820_outline_0176
      0038BC                       1627 _ak820_outline_0176:
      0038BC C4               [12] 1628 	swap	a
      0038BD 03               [12] 1629 	rr	a
      0038BE 54 F8            [12] 1630 	anl	a,#0xf8
      0038C0 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0189
      0038C1                       1635 _ak820_outline_0189:
      0038C1 90 0E 92         [24] 1636 	mov	dptr,#_first
      0038C4 E0               [24] 1637 	movx	a,@dptr
      0038C5 22               [24] 1638 	ret
                                   1639 
                                   1640 	.area CSEG (CODE)
                                   1641 ; function ak820_outline_0192
      0038C6                       1642 _ak820_outline_0192:
      0038C6 75 F0 04         [24] 1643 	mov	b,#0x04
      0038C9 A4               [48] 1644 	mul	ab
      0038CA 22               [24] 1645 	ret
