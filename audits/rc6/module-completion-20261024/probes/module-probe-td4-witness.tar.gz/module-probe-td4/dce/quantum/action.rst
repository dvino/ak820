                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_tap_dance_cancel
                                     21 	.globl _ak820_tap_dance_task
                                     22 	.globl _ak820_tap_dance_before
                                     23 	.globl _pre_process_record_quantum
                                     24 	.globl _get_record_keycode
                                     25 	.globl _repeat_key_cancel
                                     26 	.globl _clear_owned_usages
                                     27 	.globl _owned_usage_key
                                     28 	.globl _clear_owned_keys
                                     29 	.globl _del_owned_key
                                     30 	.globl _add_owned_key
                                     31 	.globl _clear_owned_mods
                                     32 	.globl _del_owned_weak_mods
                                     33 	.globl _add_owned_weak_mods
                                     34 	.globl _del_owned_mods
                                     35 	.globl _add_owned_mods
                                     36 	.globl _clear_weak_mods
                                     37 	.globl _clear_mods
                                     38 	.globl _send_keyboard_report
                                     39 	.globl _layer_hold_clear
                                     40 	.globl _layer_hold_off
                                     41 	.globl _layer_hold_on
                                     42 	.globl _ak820_resolve_key
                                     43 	.globl _layer_xor
                                     44 	.globl _layer_and
                                     45 	.globl _layer_or
                                     46 	.globl _layer_off
                                     47 	.globl _layer_on
                                     48 	.globl _layer_move
                                     49 	.globl _layer_clear
                                     50 	.globl _layer_state_set
                                     51 	.globl _default_layer_xor
                                     52 	.globl _default_layer_and
                                     53 	.globl _default_layer_or
                                     54 	.globl _default_layer_set
                                     55 	.globl _post_process_record_quantum
                                     56 	.globl _process_record_quantum
                                     57 	.globl _action_for_keycode
                                     58 	.globl _mDelaymS
                                     59 	.globl _host_consumer_send
                                     60 	.globl _host_system_send
                                     61 	.globl _host_keyboard_leds
                                     62 	.globl _led_set
                                     63 	.globl _clear_keys_from_report
                                     64 	.globl ___memcpy
                                     65 	.globl _ADC_START
                                     66 	.globl _S0_R_FIFO
                                     67 	.globl _S0_T_FIFO
                                     68 	.globl _S0_FREE
                                     69 	.globl _S0_IF_BYTE
                                     70 	.globl _S0_IF_FIRST
                                     71 	.globl _S0_IF_OV
                                     72 	.globl _S0_FST_ACT
                                     73 	.globl _CP_RL2
                                     74 	.globl _C_T2
                                     75 	.globl _TR2
                                     76 	.globl _EXEN2
                                     77 	.globl _TCLK
                                     78 	.globl _RCLK
                                     79 	.globl _EXF2
                                     80 	.globl _CAP1F
                                     81 	.globl _TF2
                                     82 	.globl _RI
                                     83 	.globl _TI
                                     84 	.globl _RB8
                                     85 	.globl _TB8
                                     86 	.globl _REN
                                     87 	.globl _SM2
                                     88 	.globl _SM1
                                     89 	.globl _SM0
                                     90 	.globl _IT0
                                     91 	.globl _IE0
                                     92 	.globl _IT1
                                     93 	.globl _IE1
                                     94 	.globl _TR0
                                     95 	.globl _TF0
                                     96 	.globl _TR1
                                     97 	.globl _TF1
                                     98 	.globl _P4_0
                                     99 	.globl _P4_1
                                    100 	.globl _P4_2
                                    101 	.globl _P4_3
                                    102 	.globl _P4_4
                                    103 	.globl _P4_5
                                    104 	.globl _P4_6
                                    105 	.globl _RXD
                                    106 	.globl _TXD
                                    107 	.globl _INT0
                                    108 	.globl _INT1
                                    109 	.globl _T0
                                    110 	.globl _T1
                                    111 	.globl _MOSI1
                                    112 	.globl _MISO1
                                    113 	.globl _SCK1
                                    114 	.globl _P3_0
                                    115 	.globl _P3_1
                                    116 	.globl _P3_2
                                    117 	.globl _P3_3
                                    118 	.globl _P3_4
                                    119 	.globl _P3_5
                                    120 	.globl _P3_6
                                    121 	.globl _P3_7
                                    122 	.globl _CAP1_
                                    123 	.globl _T2_
                                    124 	.globl _CAP2_
                                    125 	.globl _T2EX_
                                    126 	.globl _RXD1
                                    127 	.globl _TXD1
                                    128 	.globl _P2_0
                                    129 	.globl _P2_1
                                    130 	.globl _P2_2
                                    131 	.globl _P2_3
                                    132 	.globl _P2_4
                                    133 	.globl _P2_5
                                    134 	.globl _P2_6
                                    135 	.globl _P2_7
                                    136 	.globl _AIN0
                                    137 	.globl _AIN1
                                    138 	.globl _AIN2
                                    139 	.globl _AIN3
                                    140 	.globl _AIN4
                                    141 	.globl _AIN5
                                    142 	.globl _AIN6
                                    143 	.globl _AIN7
                                    144 	.globl _CAP1
                                    145 	.globl _T2
                                    146 	.globl _CAP2
                                    147 	.globl _T2EX
                                    148 	.globl _INT0_
                                    149 	.globl _SCS
                                    150 	.globl _MOSI
                                    151 	.globl _MISO
                                    152 	.globl _SCK
                                    153 	.globl _RXD1_
                                    154 	.globl _TXD1_
                                    155 	.globl _P1_0
                                    156 	.globl _P1_1
                                    157 	.globl _P1_2
                                    158 	.globl _P1_3
                                    159 	.globl _P1_4
                                    160 	.globl _P1_5
                                    161 	.globl _P1_6
                                    162 	.globl _P1_7
                                    163 	.globl _AIN8
                                    164 	.globl _AIN9
                                    165 	.globl _AIN10
                                    166 	.globl _AIN11
                                    167 	.globl _AIN12
                                    168 	.globl _AIN13
                                    169 	.globl _RXD_
                                    170 	.globl _TXD_
                                    171 	.globl _SCL0
                                    172 	.globl _SDA0
                                    173 	.globl _P0_0
                                    174 	.globl _P0_1
                                    175 	.globl _P0_2
                                    176 	.globl _P0_3
                                    177 	.globl _P0_4
                                    178 	.globl _P0_5
                                    179 	.globl _P0_6
                                    180 	.globl _P0_7
                                    181 	.globl _IE_SPI0
                                    182 	.globl _IE_USB
                                    183 	.globl _IE_ADC
                                    184 	.globl _IE_UART1
                                    185 	.globl _IE_PWM_I2C
                                    186 	.globl _IE_GPIO
                                    187 	.globl _IE_WDOG
                                    188 	.globl _PX0
                                    189 	.globl _PT0
                                    190 	.globl _PX1
                                    191 	.globl _PT1
                                    192 	.globl _PS
                                    193 	.globl _PT2
                                    194 	.globl _PL_FLAG
                                    195 	.globl _PH_FLAG
                                    196 	.globl _EX0
                                    197 	.globl _ET0
                                    198 	.globl _EX1
                                    199 	.globl _ET1
                                    200 	.globl _ES
                                    201 	.globl _ET2
                                    202 	.globl _E_DIS
                                    203 	.globl _EA
                                    204 	.globl _P
                                    205 	.globl _F1
                                    206 	.globl _OV
                                    207 	.globl _RS0
                                    208 	.globl _RS1
                                    209 	.globl _F0
                                    210 	.globl _AC
                                    211 	.globl _CY
                                    212 	.globl _I2CS_INT_ST
                                    213 	.globl _I2CX_INT
                                    214 	.globl _LED_STATUS
                                    215 	.globl _LED_DMA_H
                                    216 	.globl _LED_DMA_L
                                    217 	.globl _LED_DMA
                                    218 	.globl _LED_PWM_OE
                                    219 	.globl _LED_COMMON
                                    220 	.globl _ADC_CHAN
                                    221 	.globl _ADC_DAT_H
                                    222 	.globl _ADC_DAT_L
                                    223 	.globl _ADC_DAT
                                    224 	.globl _ADC_CTRL
                                    225 	.globl _SPI1_CK_SE
                                    226 	.globl _SPI1_CTRL
                                    227 	.globl _SPI1_DATA
                                    228 	.globl _SPI1_STAT
                                    229 	.globl _SIF1
                                    230 	.globl _SBAUD1
                                    231 	.globl _SBUF1
                                    232 	.globl _SCON1
                                    233 	.globl _SPI0_SETUP
                                    234 	.globl _SPI0_CK_SE
                                    235 	.globl _SPI0_CTRL
                                    236 	.globl _SPI0_DATA
                                    237 	.globl _SPI0_STAT
                                    238 	.globl _T2CAP1H
                                    239 	.globl _T2CAP1L
                                    240 	.globl _T2CAP1
                                    241 	.globl _TH2
                                    242 	.globl _TL2
                                    243 	.globl _T2COUNT
                                    244 	.globl _RCAP2H
                                    245 	.globl _RCAP2L
                                    246 	.globl _RCAP2
                                    247 	.globl _T2MOD
                                    248 	.globl _T2CON
                                    249 	.globl _SBUF
                                    250 	.globl _SCON
                                    251 	.globl _TH1
                                    252 	.globl _TH0
                                    253 	.globl _TL1
                                    254 	.globl _TL0
                                    255 	.globl _TMOD
                                    256 	.globl _TCON
                                    257 	.globl _XBUS_AUX
                                    258 	.globl _P7
                                    259 	.globl _P6_DIR
                                    260 	.globl _P6_OUT_PU
                                    261 	.globl _P6_IN
                                    262 	.globl _P5_DIR
                                    263 	.globl _P5_OUT_PU
                                    264 	.globl _P5_IN
                                    265 	.globl _P4_LED_KEY
                                    266 	.globl _P4_DIR_PU
                                    267 	.globl _P4_MOD_OC
                                    268 	.globl _P4
                                    269 	.globl _P3_DIR_PU
                                    270 	.globl _P3_MOD_OC
                                    271 	.globl _P3
                                    272 	.globl _P2_DIR_PU
                                    273 	.globl _P2_MOD_OC
                                    274 	.globl _P2
                                    275 	.globl _P1_DIR_PU
                                    276 	.globl _P1_MOD_OC
                                    277 	.globl _P1
                                    278 	.globl _P0_DIR_PU
                                    279 	.globl _P0_MOD_OC
                                    280 	.globl _P0
                                    281 	.globl _ROM_CTRL
                                    282 	.globl _ROM_DATA_HH
                                    283 	.globl _ROM_DATA_HL
                                    284 	.globl _ROM_DATA_HI
                                    285 	.globl _ROM_ADDR_H
                                    286 	.globl _ROM_ADDR_L
                                    287 	.globl _ROM_ADDR
                                    288 	.globl _GPIO_IE
                                    289 	.globl _IP_EX
                                    290 	.globl _IE_EX
                                    291 	.globl _IP
                                    292 	.globl _IE
                                    293 	.globl _WDOG_COUNT
                                    294 	.globl _RESET_KEEP
                                    295 	.globl _WAKE_CTRL
                                    296 	.globl _CLOCK_CFG
                                    297 	.globl _POWER_CFG
                                    298 	.globl _PCON
                                    299 	.globl _GLOBAL_CFG
                                    300 	.globl _SAFE_MOD
                                    301 	.globl _DPH
                                    302 	.globl _DPL
                                    303 	.globl _SP
                                    304 	.globl _A_INV
                                    305 	.globl _B
                                    306 	.globl _ACC
                                    307 	.globl _PSW
                                    308 	.globl _disable_action_cache
                                    309 	.globl _tap_code_delay_PARM_2
                                    310 	.globl _process_action_PARM_2
                                    311 	.globl _action_exec_PARM_1
                                    312 	.globl _tp_buttons
                                    313 	.globl _action_exec
                                    314 	.globl _ak820_action_exec
                                    315 	.globl _process_record
                                    316 	.globl _process_record_handler
                                    317 	.globl _process_action
                                    318 	.globl _register_code
                                    319 	.globl _unregister_code
                                    320 	.globl _tap_code_delay
                                    321 	.globl _tap_code
                                    322 	.globl _register_mods
                                    323 	.globl _unregister_mods
                                    324 	.globl _register_weak_mods
                                    325 	.globl _unregister_weak_mods
                                    326 	.globl _clear_keyboard
                                    327 	.globl _clear_keyboard_but_mods
                                    328 	.globl _clear_keyboard_but_mods_and_keys
                                    329 ;--------------------------------------------------------
                                    330 ; special function registers
                                    331 ;--------------------------------------------------------
                                    332 	.area RSEG    (ABS,DATA)
      000000                        333 	.org 0x0000
                           0000D0   334 _PSW	=	0x00d0
                           0000E0   335 _ACC	=	0x00e0
                           0000F0   336 _B	=	0x00f0
                           0000FD   337 _A_INV	=	0x00fd
                           000081   338 _SP	=	0x0081
                           000082   339 _DPL	=	0x0082
                           000083   340 _DPH	=	0x0083
                           0000A1   341 _SAFE_MOD	=	0x00a1
                           0000B1   342 _GLOBAL_CFG	=	0x00b1
                           000087   343 _PCON	=	0x0087
                           0000BA   344 _POWER_CFG	=	0x00ba
                           0000B9   345 _CLOCK_CFG	=	0x00b9
                           0000A9   346 _WAKE_CTRL	=	0x00a9
                           0000FE   347 _RESET_KEEP	=	0x00fe
                           0000FF   348 _WDOG_COUNT	=	0x00ff
                           0000A8   349 _IE	=	0x00a8
                           0000B8   350 _IP	=	0x00b8
                           0000E8   351 _IE_EX	=	0x00e8
                           0000E9   352 _IP_EX	=	0x00e9
                           0000B2   353 _GPIO_IE	=	0x00b2
                           008584   354 _ROM_ADDR	=	0x8584
                           000084   355 _ROM_ADDR_L	=	0x0084
                           000085   356 _ROM_ADDR_H	=	0x0085
                           008F8E   357 _ROM_DATA_HI	=	0x8f8e
                           00008E   358 _ROM_DATA_HL	=	0x008e
                           00008F   359 _ROM_DATA_HH	=	0x008f
                           000086   360 _ROM_CTRL	=	0x0086
                           000080   361 _P0	=	0x0080
                           0000C4   362 _P0_MOD_OC	=	0x00c4
                           0000C5   363 _P0_DIR_PU	=	0x00c5
                           000090   364 _P1	=	0x0090
                           000092   365 _P1_MOD_OC	=	0x0092
                           000093   366 _P1_DIR_PU	=	0x0093
                           0000A0   367 _P2	=	0x00a0
                           000094   368 _P2_MOD_OC	=	0x0094
                           000095   369 _P2_DIR_PU	=	0x0095
                           0000B0   370 _P3	=	0x00b0
                           000096   371 _P3_MOD_OC	=	0x0096
                           000097   372 _P3_DIR_PU	=	0x0097
                           0000C0   373 _P4	=	0x00c0
                           0000C2   374 _P4_MOD_OC	=	0x00c2
                           0000C3   375 _P4_DIR_PU	=	0x00c3
                           0000C1   376 _P4_LED_KEY	=	0x00c1
                           0000AA   377 _P5_IN	=	0x00aa
                           0000AB   378 _P5_OUT_PU	=	0x00ab
                           0000AC   379 _P5_DIR	=	0x00ac
                           0000AD   380 _P6_IN	=	0x00ad
                           0000AE   381 _P6_OUT_PU	=	0x00ae
                           0000AF   382 _P6_DIR	=	0x00af
                           0000F1   383 _P7	=	0x00f1
                           0000A2   384 _XBUS_AUX	=	0x00a2
                           000088   385 _TCON	=	0x0088
                           000089   386 _TMOD	=	0x0089
                           00008A   387 _TL0	=	0x008a
                           00008B   388 _TL1	=	0x008b
                           00008C   389 _TH0	=	0x008c
                           00008D   390 _TH1	=	0x008d
                           000098   391 _SCON	=	0x0098
                           000099   392 _SBUF	=	0x0099
                           0000C8   393 _T2CON	=	0x00c8
                           0000C9   394 _T2MOD	=	0x00c9
                           00CBCA   395 _RCAP2	=	0xcbca
                           0000CA   396 _RCAP2L	=	0x00ca
                           0000CB   397 _RCAP2H	=	0x00cb
                           00CDCC   398 _T2COUNT	=	0xcdcc
                           0000CC   399 _TL2	=	0x00cc
                           0000CD   400 _TH2	=	0x00cd
                           00CFCE   401 _T2CAP1	=	0xcfce
                           0000CE   402 _T2CAP1L	=	0x00ce
                           0000CF   403 _T2CAP1H	=	0x00cf
                           0000F8   404 _SPI0_STAT	=	0x00f8
                           0000F9   405 _SPI0_DATA	=	0x00f9
                           0000FA   406 _SPI0_CTRL	=	0x00fa
                           0000FB   407 _SPI0_CK_SE	=	0x00fb
                           0000FC   408 _SPI0_SETUP	=	0x00fc
                           0000BC   409 _SCON1	=	0x00bc
                           0000BD   410 _SBUF1	=	0x00bd
                           0000BE   411 _SBAUD1	=	0x00be
                           0000BF   412 _SIF1	=	0x00bf
                           0000B4   413 _SPI1_STAT	=	0x00b4
                           0000B5   414 _SPI1_DATA	=	0x00b5
                           0000B6   415 _SPI1_CTRL	=	0x00b6
                           0000B7   416 _SPI1_CK_SE	=	0x00b7
                           0000F3   417 _ADC_CTRL	=	0x00f3
                           00F5F4   418 _ADC_DAT	=	0xf5f4
                           0000F4   419 _ADC_DAT_L	=	0x00f4
                           0000F5   420 _ADC_DAT_H	=	0x00f5
                           0000F6   421 _ADC_CHAN	=	0x00f6
                           0000A6   422 _LED_COMMON	=	0x00a6
                           0000A7   423 _LED_PWM_OE	=	0x00a7
                           00C7C6   424 _LED_DMA	=	0xc7c6
                           0000C6   425 _LED_DMA_L	=	0x00c6
                           0000C7   426 _LED_DMA_H	=	0x00c7
                           0000F7   427 _LED_STATUS	=	0x00f7
                           0000B3   428 _I2CX_INT	=	0x00b3
                           0000BB   429 _I2CS_INT_ST	=	0x00bb
                                    430 ;--------------------------------------------------------
                                    431 ; special function bits
                                    432 ;--------------------------------------------------------
                                    433 	.area RSEG    (ABS,DATA)
      000000                        434 	.org 0x0000
                           0000D7   435 _CY	=	0x00d7
                           0000D6   436 _AC	=	0x00d6
                           0000D5   437 _F0	=	0x00d5
                           0000D4   438 _RS1	=	0x00d4
                           0000D3   439 _RS0	=	0x00d3
                           0000D2   440 _OV	=	0x00d2
                           0000D1   441 _F1	=	0x00d1
                           0000D0   442 _P	=	0x00d0
                           0000AF   443 _EA	=	0x00af
                           0000AE   444 _E_DIS	=	0x00ae
                           0000AD   445 _ET2	=	0x00ad
                           0000AC   446 _ES	=	0x00ac
                           0000AB   447 _ET1	=	0x00ab
                           0000AA   448 _EX1	=	0x00aa
                           0000A9   449 _ET0	=	0x00a9
                           0000A8   450 _EX0	=	0x00a8
                           0000BF   451 _PH_FLAG	=	0x00bf
                           0000BE   452 _PL_FLAG	=	0x00be
                           0000BD   453 _PT2	=	0x00bd
                           0000BC   454 _PS	=	0x00bc
                           0000BB   455 _PT1	=	0x00bb
                           0000BA   456 _PX1	=	0x00ba
                           0000B9   457 _PT0	=	0x00b9
                           0000B8   458 _PX0	=	0x00b8
                           0000EF   459 _IE_WDOG	=	0x00ef
                           0000EE   460 _IE_GPIO	=	0x00ee
                           0000ED   461 _IE_PWM_I2C	=	0x00ed
                           0000EC   462 _IE_UART1	=	0x00ec
                           0000EB   463 _IE_ADC	=	0x00eb
                           0000E9   464 _IE_USB	=	0x00e9
                           0000E8   465 _IE_SPI0	=	0x00e8
                           000087   466 _P0_7	=	0x0087
                           000086   467 _P0_6	=	0x0086
                           000085   468 _P0_5	=	0x0085
                           000084   469 _P0_4	=	0x0084
                           000083   470 _P0_3	=	0x0083
                           000082   471 _P0_2	=	0x0082
                           000081   472 _P0_1	=	0x0081
                           000080   473 _P0_0	=	0x0080
                           000081   474 _SDA0	=	0x0081
                           000080   475 _SCL0	=	0x0080
                           000083   476 _TXD_	=	0x0083
                           000082   477 _RXD_	=	0x0082
                           000085   478 _AIN13	=	0x0085
                           000084   479 _AIN12	=	0x0084
                           000083   480 _AIN11	=	0x0083
                           000082   481 _AIN10	=	0x0082
                           000081   482 _AIN9	=	0x0081
                           000080   483 _AIN8	=	0x0080
                           000097   484 _P1_7	=	0x0097
                           000096   485 _P1_6	=	0x0096
                           000095   486 _P1_5	=	0x0095
                           000094   487 _P1_4	=	0x0094
                           000093   488 _P1_3	=	0x0093
                           000092   489 _P1_2	=	0x0092
                           000091   490 _P1_1	=	0x0091
                           000090   491 _P1_0	=	0x0090
                           000097   492 _TXD1_	=	0x0097
                           000096   493 _RXD1_	=	0x0096
                           000097   494 _SCK	=	0x0097
                           000096   495 _MISO	=	0x0096
                           000095   496 _MOSI	=	0x0095
                           000094   497 _SCS	=	0x0094
                           000092   498 _INT0_	=	0x0092
                           000091   499 _T2EX	=	0x0091
                           000091   500 _CAP2	=	0x0091
                           000090   501 _T2	=	0x0090
                           000090   502 _CAP1	=	0x0090
                           000097   503 _AIN7	=	0x0097
                           000096   504 _AIN6	=	0x0096
                           000095   505 _AIN5	=	0x0095
                           000094   506 _AIN4	=	0x0094
                           000093   507 _AIN3	=	0x0093
                           000092   508 _AIN2	=	0x0092
                           000091   509 _AIN1	=	0x0091
                           000090   510 _AIN0	=	0x0090
                           0000A7   511 _P2_7	=	0x00a7
                           0000A6   512 _P2_6	=	0x00a6
                           0000A5   513 _P2_5	=	0x00a5
                           0000A4   514 _P2_4	=	0x00a4
                           0000A3   515 _P2_3	=	0x00a3
                           0000A2   516 _P2_2	=	0x00a2
                           0000A1   517 _P2_1	=	0x00a1
                           0000A0   518 _P2_0	=	0x00a0
                           0000A7   519 _TXD1	=	0x00a7
                           0000A6   520 _RXD1	=	0x00a6
                           0000A5   521 _T2EX_	=	0x00a5
                           0000A5   522 _CAP2_	=	0x00a5
                           0000A4   523 _T2_	=	0x00a4
                           0000A4   524 _CAP1_	=	0x00a4
                           0000B7   525 _P3_7	=	0x00b7
                           0000B6   526 _P3_6	=	0x00b6
                           0000B5   527 _P3_5	=	0x00b5
                           0000B4   528 _P3_4	=	0x00b4
                           0000B3   529 _P3_3	=	0x00b3
                           0000B2   530 _P3_2	=	0x00b2
                           0000B1   531 _P3_1	=	0x00b1
                           0000B0   532 _P3_0	=	0x00b0
                           0000B7   533 _SCK1	=	0x00b7
                           0000B6   534 _MISO1	=	0x00b6
                           0000B5   535 _MOSI1	=	0x00b5
                           0000B5   536 _T1	=	0x00b5
                           0000B4   537 _T0	=	0x00b4
                           0000B3   538 _INT1	=	0x00b3
                           0000B2   539 _INT0	=	0x00b2
                           0000B1   540 _TXD	=	0x00b1
                           0000B0   541 _RXD	=	0x00b0
                           0000C6   542 _P4_6	=	0x00c6
                           0000C5   543 _P4_5	=	0x00c5
                           0000C4   544 _P4_4	=	0x00c4
                           0000C3   545 _P4_3	=	0x00c3
                           0000C2   546 _P4_2	=	0x00c2
                           0000C1   547 _P4_1	=	0x00c1
                           0000C0   548 _P4_0	=	0x00c0
                           00008F   549 _TF1	=	0x008f
                           00008E   550 _TR1	=	0x008e
                           00008D   551 _TF0	=	0x008d
                           00008C   552 _TR0	=	0x008c
                           00008B   553 _IE1	=	0x008b
                           00008A   554 _IT1	=	0x008a
                           000089   555 _IE0	=	0x0089
                           000088   556 _IT0	=	0x0088
                           00009F   557 _SM0	=	0x009f
                           00009E   558 _SM1	=	0x009e
                           00009D   559 _SM2	=	0x009d
                           00009C   560 _REN	=	0x009c
                           00009B   561 _TB8	=	0x009b
                           00009A   562 _RB8	=	0x009a
                           000099   563 _TI	=	0x0099
                           000098   564 _RI	=	0x0098
                           0000CF   565 _TF2	=	0x00cf
                           0000CF   566 _CAP1F	=	0x00cf
                           0000CE   567 _EXF2	=	0x00ce
                           0000CD   568 _RCLK	=	0x00cd
                           0000CC   569 _TCLK	=	0x00cc
                           0000CB   570 _EXEN2	=	0x00cb
                           0000CA   571 _TR2	=	0x00ca
                           0000C9   572 _C_T2	=	0x00c9
                           0000C8   573 _CP_RL2	=	0x00c8
                           0000FF   574 _S0_FST_ACT	=	0x00ff
                           0000FE   575 _S0_IF_OV	=	0x00fe
                           0000FD   576 _S0_IF_FIRST	=	0x00fd
                           0000FC   577 _S0_IF_BYTE	=	0x00fc
                           0000FB   578 _S0_FREE	=	0x00fb
                           0000FA   579 _S0_T_FIFO	=	0x00fa
                           0000F8   580 _S0_R_FIFO	=	0x00f8
                           0000F7   581 _ADC_START	=	0x00f7
                                    582 ;--------------------------------------------------------
                                    583 ; overlayable register banks
                                    584 ;--------------------------------------------------------
                                    585 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        586 	.ds 8
                                    587 ;--------------------------------------------------------
                                    588 ; internal ram data
                                    589 ;--------------------------------------------------------
                                    590 	.area DSEG    (DATA)
      000027                        591 _process_action_sloc0_1_0:
      000027                        592 	.ds 1
                                    593 ;--------------------------------------------------------
                                    594 ; overlayable items in internal ram
                                    595 ;--------------------------------------------------------
                                    596 ;--------------------------------------------------------
                                    597 ; indirectly addressable internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area ISEG    (DATA)
                                    600 ;--------------------------------------------------------
                                    601 ; absolute internal ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area IABS    (ABS,DATA)
                                    604 	.area IABS    (ABS,DATA)
                                    605 ;--------------------------------------------------------
                                    606 ; bit data
                                    607 ;--------------------------------------------------------
                                    608 	.area BSEG    (BIT)
      000022                        609 _process_action_sloc1_1_0:
      000022                        610 	.ds 1
                                    611 ;--------------------------------------------------------
                                    612 ; paged external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area PSEG    (PAG,XDATA)
                                    615 ;--------------------------------------------------------
                                    616 ; uninitialized external ram data
                                    617 ;--------------------------------------------------------
                                    618 	.area XSEG    (XDATA)
      0008D7                        619 _tp_buttons::
      0008D7                        620 	.ds 2
      0008D9                        621 _action_exec_PARM_1:
      0008D9                        622 	.ds 6
      0008DF                        623 _action_exec_record_10001_632:
      0008DF                        624 	.ds 9
      0008E8                        625 _ak820_action_exec_event_10000_636:
      0008E8                        626 	.ds 2
      0008EA                        627 _ak820_action_exec_snapshot_10000_637:
      0008EA                        628 	.ds 6
      0008F0                        629 _process_record_record_argument_10000_640:
      0008F0                        630 	.ds 2
      0008F2                        631 _process_record_handler_record_argument_10000_648:
      0008F2                        632 	.ds 2
      0008F4                        633 _process_record_handler_action_10000_649:
      0008F4                        634 	.ds 2
      0008F6                        635 _process_action_PARM_2:
      0008F6                        636 	.ds 2
      0008F8                        637 _process_action_record_argument_10000_660:
      0008F8                        638 	.ds 2
      0008FA                        639 _process_action_on_40000_683:
      0008FA                        640 	.ds 1
      0008FB                        641 _register_code_code_10000_717:
      0008FB                        642 	.ds 1
      0008FC                        643 _unregister_code_code_10000_731:
      0008FC                        644 	.ds 1
      0008FD                        645 _tap_code_delay_PARM_2:
      0008FD                        646 	.ds 2
      0008FF                        647 _tap_code_delay_code_10000_744:
      0008FF                        648 	.ds 1
      000900                        649 _tap_code_code_10000_751:
      000900                        650 	.ds 1
      000901                        651 _register_mods_mods_10000_753:
      000901                        652 	.ds 1
      000902                        653 _unregister_mods_mods_10000_757:
      000902                        654 	.ds 1
      000903                        655 _register_weak_mods_mods_10000_761:
      000903                        656 	.ds 1
      000904                        657 _unregister_weak_mods_mods_10000_765:
      000904                        658 	.ds 1
                                    659 ;--------------------------------------------------------
                                    660 ; absolute external ram data
                                    661 ;--------------------------------------------------------
                                    662 	.area XABS    (ABS,XDATA)
                                    663 ;--------------------------------------------------------
                                    664 ; initialized external ram data
                                    665 ;--------------------------------------------------------
                                    666 	.area XISEG   (XDATA)
      000EA4                        667 _disable_action_cache::
      000EA4                        668 	.ds 1
                                    669 	.area HOME    (CODE)
                                    670 	.area GSINIT0 (CODE)
                                    671 	.area GSINIT1 (CODE)
                                    672 	.area GSINIT2 (CODE)
                                    673 	.area GSINIT3 (CODE)
                                    674 	.area GSINIT4 (CODE)
                                    675 	.area GSINIT5 (CODE)
                                    676 	.area GSINIT  (CODE)
                                    677 	.area GSFINAL (CODE)
                                    678 	.area CSEG    (CODE)
                                    679 ;--------------------------------------------------------
                                    680 ; global & static initialisations
                                    681 ;--------------------------------------------------------
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 	.area GSFINAL (CODE)
                                    685 	.area GSINIT  (CODE)
                                    686 ;--------------------------------------------------------
                                    687 ; Home
                                    688 ;--------------------------------------------------------
                                    689 	.area HOME    (CODE)
                                    690 	.area HOME    (CODE)
                                    691 ;--------------------------------------------------------
                                    692 ; code
                                    693 ;--------------------------------------------------------
                                    694 	.area CSEG    (CODE)
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    697 ;------------------------------------------------------------
                                    698 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    699 ;------------------------------------------------------------
                                    700 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    701 ;	-----------------------------------------
                           000007   702 	ar7 = 0x07
                           000006   703 	ar6 = 0x06
                           000005   704 	ar5 = 0x05
                           000004   705 	ar4 = 0x04
                           000003   706 	ar3 = 0x03
                           000002   707 	ar2 = 0x02
                           000001   708 	ar1 = 0x01
                           000000   709 	ar0 = 0x00
                                    710 ;	 function action_exec
                                    711 ;	-----------------------------------------
      00750A                        712 _action_exec:
                                    713 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      00750A 90 08 DB         [24]  714 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00750D 12 37 DC         [24]  715 	lcall	_ak820_outline_0005
      007510 12 35 F7         [24]  716 	lcall	_ak820_combo_tick
                                    717 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007513 90 08 D9         [24]  718 	mov	dptr,#_action_exec_PARM_1
      007516 12 4A 0A         [24]  719 	lcall	_ak820_tapping_before
      007519 E5 82            [12]  720 	mov	a, dpl
      00751B 70 01            [24]  721 	jnz	00102$
      00751D 22               [24]  722 	ret
      00751E                        723 00102$:
                                    724 ;	quantum/action.c:106: ak820_tap_dance_task(event.time);
      00751E 90 08 DB         [24]  725 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007521 12 37 DC         [24]  726 	lcall	_ak820_outline_0005
      007524 12 45 75         [24]  727 	lcall	_ak820_tap_dance_task
                                    728 ;	quantum/action.c:107: if (!ak820_tap_dance_before(&event)) return;
      007527 90 08 D9         [24]  729 	mov	dptr,#_action_exec_PARM_1
      00752A 12 45 C5         [24]  730 	lcall	_ak820_tap_dance_before
      00752D E5 82            [12]  731 	mov	a, dpl
      00752F 70 01            [24]  732 	jnz	00104$
      007531 22               [24]  733 	ret
      007532                        734 00104$:
                                    735 ;	quantum/action.c:126: if (event.pressed) {
      007532 90 08 DE         [24]  736 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007535 E0               [24]  737 	movx	a,@dptr
      007536 60 03            [24]  738 	jz	00106$
                                    739 ;	quantum/action.c:128: clear_weak_mods();
      007538 12 85 1A         [24]  740 	lcall	_clear_weak_mods
      00753B                        741 00106$:
                                    742 ;	quantum/action.c:140: record.event = event;
      00753B 90 0E 84         [24]  743 	mov	dptr,#___memcpy_PARM_2
      00753E 74 D9            [12]  744 	mov	a,#_action_exec_PARM_1
      007540 F0               [24]  745 	movx	@dptr,a
      007541 74 08            [12]  746 	mov	a,#(_action_exec_PARM_1 >> 8)
      007543 12 7B B2         [24]  747 	lcall	_ak820_outline_0058
      007546 12 7B D2         [24]  748 	lcall	_ak820_outline_0112
      007549 90 08 DF         [24]  749 	mov	dptr,#_action_exec_record_10001_632
      00754C F5 F0            [12]  750 	mov	b,a
      00754E 12 BE 0C         [24]  751 	lcall	___memcpy
                                    752 ;	quantum/action.c:142: record.tap.count = 0;
      007551 90 08 E5         [24]  753 	mov	dptr,#(_action_exec_record_10001_632 + 0x0006)
      007554 E0               [24]  754 	movx	a,@dptr
      007555 54 0F            [12]  755 	anl	a,#0x0f
      007557 F0               [24]  756 	movx	@dptr,a
                                    757 ;	quantum/action.c:147: record.keycode = 0;
      007558 90 08 E6         [24]  758 	mov	dptr,#(_action_exec_record_10001_632 + 0x0007)
      00755B 12 49 26         [24]  759 	lcall	_ak820_outline_0146
                                    760 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00755E 90 08 E3         [24]  761 	mov	dptr,#(_action_exec_record_10001_632 + 0x0004)
      007561 E0               [24]  762 	movx	a,@dptr
      007562 60 0A            [24]  763 	jz	00109$
      007564 90 08 DF         [24]  764 	mov	dptr,#_action_exec_record_10001_632
      007567 12 A4 3E         [24]  765 	lcall	_pre_process_record_quantum
      00756A E5 82            [12]  766 	mov	a, dpl
      00756C 60 10            [24]  767 	jz	00112$
      00756E                        768 00109$:
                                    769 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      00756E 90 08 DF         [24]  770 	mov	dptr,#_action_exec_record_10001_632
      007571 12 4A FC         [24]  771 	lcall	_ak820_tapping_process
      007574 E5 82            [12]  772 	mov	a, dpl
      007576 70 01            [24]  773 	jnz	00108$
      007578 22               [24]  774 	ret
      007579                        775 00108$:
                                    776 ;	quantum/action.c:185: process_record(&record);
      007579 90 08 DF         [24]  777 	mov	dptr,#_action_exec_record_10001_632
                                    778 ;	quantum/action.c:200: }
      00757C A1 BD            [12]  779 	ajmp	_process_record
      00757E                        780 00112$:
      00757E 22               [24]  781 	ret
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'ak820_action_exec'
                                    784 ;------------------------------------------------------------
                                    785 ;event         Allocated with name '_ak820_action_exec_event_10000_636'
                                    786 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_637'
                                    787 ;------------------------------------------------------------
                                    788 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    789 ;	-----------------------------------------
                                    790 ;	 function ak820_action_exec
                                    791 ;	-----------------------------------------
      00757F                        792 _ak820_action_exec:
      00757F 12 38 7A         [24]  793 	lcall	_ak820_outline_0106
      007582 90 08 E8         [24]  794 	mov	dptr,#_ak820_action_exec_event_10000_636
      007585 12 38 75         [24]  795 	lcall	_ak820_outline_0105
                                    796 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007588 90 08 E8         [24]  797 	mov	dptr,#_ak820_action_exec_event_10000_636
      00758B 12 38 5D         [24]  798 	lcall	_ak820_outline_0085
      00758E 7F 00            [12]  799 	mov	r7,#0x00
      007590 90 0E 84         [24]  800 	mov	dptr,#___memcpy_PARM_2
      007593 ED               [12]  801 	mov	a,r5
      007594 12 38 0D         [24]  802 	lcall	_ak820_outline_0019
      007597 90 0E 87         [24]  803 	mov	dptr,#___memcpy_PARM_3
      00759A 12 7B D2         [24]  804 	lcall	_ak820_outline_0112
      00759D 90 08 EA         [24]  805 	mov	dptr,#_ak820_action_exec_snapshot_10000_637
      0075A0 F5 F0            [12]  806 	mov	b,a
      0075A2 12 BE 0C         [24]  807 	lcall	___memcpy
                                    808 ;	quantum/action.c:207: action_exec(snapshot);
      0075A5 90 0E 84         [24]  809 	mov	dptr,#___memcpy_PARM_2
      0075A8 74 EA            [12]  810 	mov	a,#_ak820_action_exec_snapshot_10000_637
      0075AA F0               [24]  811 	movx	@dptr,a
      0075AB 74 08            [12]  812 	mov	a,#(_ak820_action_exec_snapshot_10000_637 >> 8)
      0075AD 12 7B B2         [24]  813 	lcall	_ak820_outline_0058
      0075B0 12 7B D2         [24]  814 	lcall	_ak820_outline_0112
      0075B3 90 08 D9         [24]  815 	mov	dptr,#_action_exec_PARM_1
      0075B6 F5 F0            [12]  816 	mov	b,a
      0075B8 12 BE 0C         [24]  817 	lcall	___memcpy
                                    818 ;	quantum/action.c:208: }
      0075BB A1 0A            [12]  819 	ajmp	_action_exec
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'process_record_nocache'
                                    822 ;------------------------------------------------------------
                                    823 ;record        Allocated with name '_process_record_nocache_record_10000_638'
                                    824 ;------------------------------------------------------------
                                    825 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    826 ;	-----------------------------------------
                                    827 ;	 function process_record
                                    828 ;	-----------------------------------------
      0075BD                        829 _process_record:
      0075BD 12 38 7A         [24]  830 	lcall	_ak820_outline_0106
      0075C0 90 08 F0         [24]  831 	mov	dptr,#_process_record_record_argument_10000_640
      0075C3 12 38 75         [24]  832 	lcall	_ak820_outline_0105
                                    833 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0075C6 90 08 F0         [24]  834 	mov	dptr,#_process_record_record_argument_10000_640
      0075C9 12 38 2E         [24]  835 	lcall	_ak820_outline_0059
                                    836 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0075CC 74 04            [12]  837 	mov	a,#0x04
      0075CE 12 48 CA         [24]  838 	lcall	_ak820_outline_0014
      0075D1 70 01            [24]  839 	jnz	00102$
                                    840 ;	quantum/action.c:354: return;
      0075D3 22               [24]  841 	ret
      0075D4                        842 00102$:
                                    843 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0075D4 8E 04            [24]  844 	mov	ar4,r6
      0075D6 8F 05            [24]  845 	mov	ar5,r7
      0075D8 90 0E 84         [24]  846 	mov	dptr,#___memcpy_PARM_2
      0075DB EC               [12]  847 	mov	a,r4
      0075DC F0               [24]  848 	movx	@dptr,a
      0075DD ED               [12]  849 	mov	a,r5
      0075DE 12 7B B2         [24]  850 	lcall	_ak820_outline_0058
      0075E1 12 54 86         [24]  851 	lcall	_ak820_outline_0111
      0075E4 90 06 ED         [24]  852 	mov	dptr,#_ak820_tapping_source_PARM_1
      0075E7 F5 F0            [12]  853 	mov	b,a
      0075E9 C0 07            [24]  854 	push	ar7
      0075EB C0 06            [24]  855 	push	ar6
      0075ED 12 BE 0C         [24]  856 	lcall	___memcpy
      0075F0 12 49 45         [24]  857 	lcall	_ak820_tapping_source
      0075F3 AD 82            [24]  858 	mov	r5, dpl
      0075F5 D0 06            [24]  859 	pop	ar6
      0075F7 D0 07            [24]  860 	pop	ar7
                                    861 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0075F9 12 42 FF         [24]  862 	lcall	_ak820_outline_0011
      0075FC E0               [24]  863 	movx	a,@dptr
      0075FD FC               [12]  864 	mov	r4,a
                                    865 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      0075FE 74 07            [12]  866 	mov	a,#0x07
      007600 2E               [12]  867 	add	a, r6
      007601 FA               [12]  868 	mov	r2,a
      007602 E4               [12]  869 	clr	a
      007603 3F               [12]  870 	addc	a, r7
      007604 FB               [12]  871 	mov	r3,a
      007605 90 0C CC         [24]  872 	mov	dptr,#_get_record_keycode_PARM_2
      007608 74 01            [12]  873 	mov	a,#0x01
      00760A 12 43 43         [24]  874 	lcall	_ak820_outline_0072
      00760D C0 07            [24]  875 	push	ar7
      00760F C0 06            [24]  876 	push	ar6
      007611 C0 05            [24]  877 	push	ar5
      007613 C0 04            [24]  878 	push	ar4
      007615 C0 03            [24]  879 	push	ar3
      007617 C0 02            [24]  880 	push	ar2
      007619 12 A3 FC         [24]  881 	lcall	_get_record_keycode
      00761C A8 82            [24]  882 	mov	r0, dpl
      00761E A9 83            [24]  883 	mov	r1, dph
      007620 D0 02            [24]  884 	pop	ar2
      007622 D0 03            [24]  885 	pop	ar3
      007624 D0 04            [24]  886 	pop	ar4
      007626 D0 05            [24]  887 	pop	ar5
      007628 D0 06            [24]  888 	pop	ar6
      00762A D0 07            [24]  889 	pop	ar7
      00762C 12 38 A2         [24]  890 	lcall	_ak820_outline_0131
      00762F E8               [12]  891 	mov	a,r0
      007630 F0               [24]  892 	movx	@dptr,a
      007631 E9               [12]  893 	mov	a,r1
      007632 A3               [24]  894 	inc	dptr
      007633 F0               [24]  895 	movx	@dptr,a
                                    896 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007634 74 07            [12]  897 	mov	a,#0x07
      007636 12 38 15         [24]  898 	lcall	_ak820_outline_0020
      007639 FA               [12]  899 	mov	r2,a
      00763A A3               [24]  900 	inc	dptr
      00763B E0               [24]  901 	movx	a,@dptr
      00763C FB               [12]  902 	mov	r3,a
      00763D 90 06 FD         [24]  903 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007640 ED               [12]  904 	mov	a,r5
      007641 F0               [24]  905 	movx	@dptr,a
      007642 90 06 FE         [24]  906 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007645 EC               [12]  907 	mov	a,r4
      007646 F0               [24]  908 	movx	@dptr,a
      007647 12 38 A2         [24]  909 	lcall	_ak820_outline_0131
      00764A C0 07            [24]  910 	push	ar7
      00764C C0 06            [24]  911 	push	ar6
      00764E C0 05            [24]  912 	push	ar5
      007650 C0 04            [24]  913 	push	ar4
      007652 12 4C 9C         [24]  914 	lcall	_ak820_oneshot_process
      007655 E5 82            [12]  915 	mov	a, dpl
      007657 D0 04            [24]  916 	pop	ar4
      007659 D0 05            [24]  917 	pop	ar5
      00765B D0 06            [24]  918 	pop	ar6
      00765D D0 07            [24]  919 	pop	ar7
      00765F 70 01            [24]  920 	jnz	00104$
      007661 22               [24]  921 	ret
      007662                        922 00104$:
                                    923 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      007662 12 38 8D         [24]  924 	lcall	_ak820_outline_0121
      007665 C0 07            [24]  925 	push	ar7
      007667 C0 06            [24]  926 	push	ar6
      007669 C0 05            [24]  927 	push	ar5
      00766B C0 04            [24]  928 	push	ar4
      00766D 12 A4 DC         [24]  929 	lcall	_process_record_quantum
      007670 E5 82            [12]  930 	mov	a, dpl
      007672 D0 04            [24]  931 	pop	ar4
      007674 D0 05            [24]  932 	pop	ar5
      007676 D0 06            [24]  933 	pop	ar6
      007678 D0 07            [24]  934 	pop	ar7
      00767A 70 0A            [24]  935 	jnz	00106$
                                    936 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00767C 90 05 9C         [24]  937 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00767F EC               [12]  938 	mov	a,r4
      007680 F0               [24]  939 	movx	@dptr,a
      007681 8D 82            [24]  940 	mov	dpl, r5
                                    941 ;	quantum/action.c:376: return;
      007683 02 2E BB         [24]  942 	ljmp	_ak820_oneshot_post
      007686                        943 00106$:
                                    944 ;	quantum/action.c:382: process_record_handler(record);
      007686 12 38 8D         [24]  945 	lcall	_ak820_outline_0121
      007689 C0 07            [24]  946 	push	ar7
      00768B C0 06            [24]  947 	push	ar6
      00768D C0 05            [24]  948 	push	ar5
      00768F C0 04            [24]  949 	push	ar4
      007691 D1 B3            [24]  950 	acall	_process_record_handler
      007693 D0 04            [24]  951 	pop	ar4
      007695 D0 05            [24]  952 	pop	ar5
      007697 D0 06            [24]  953 	pop	ar6
      007699 D0 07            [24]  954 	pop	ar7
                                    955 ;	quantum/action.c:386: post_process_record_quantum(record);
      00769B 12 38 8D         [24]  956 	lcall	_ak820_outline_0121
      00769E C0 05            [24]  957 	push	ar5
      0076A0 C0 04            [24]  958 	push	ar4
      0076A2 12 A4 B1         [24]  959 	lcall	_post_process_record_quantum
      0076A5 D0 04            [24]  960 	pop	ar4
      0076A7 D0 05            [24]  961 	pop	ar5
                                    962 ;	quantum/action.c:388: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0076A9 90 05 9C         [24]  963 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0076AC EC               [12]  964 	mov	a,r4
      0076AD F0               [24]  965 	movx	@dptr,a
      0076AE 8D 82            [24]  966 	mov	dpl, r5
                                    967 ;	quantum/action.c:390: }
      0076B0 02 2E BB         [24]  968 	ljmp	_ak820_oneshot_post
                                    969 ;------------------------------------------------------------
                                    970 ;Allocation info for local variables in function 'process_record_handler'
                                    971 ;------------------------------------------------------------
                                    972 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_648'
                                    973 ;record        Allocated with name '_process_record_handler_record_10000_649'
                                    974 ;action        Allocated with name '_process_record_handler_action_10000_649'
                                    975 ;------------------------------------------------------------
                                    976 ;	quantum/action.c:392: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    977 ;	-----------------------------------------
                                    978 ;	 function process_record_handler
                                    979 ;	-----------------------------------------
      0076B3                        980 _process_record_handler:
      0076B3 12 38 7A         [24]  981 	lcall	_ak820_outline_0106
      0076B6 90 08 F2         [24]  982 	mov	dptr,#_process_record_handler_record_argument_10000_648
      0076B9 12 38 75         [24]  983 	lcall	_ak820_outline_0105
                                    984 ;	quantum/action.c:396: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0076BC 90 08 F2         [24]  985 	mov	dptr,#_process_record_handler_record_argument_10000_648
      0076BF 12 37 F3         [24]  986 	lcall	_ak820_outline_0008
                                    987 ;	quantum/action.c:403: if (record->keycode) {
      0076C2 FC               [12]  988 	mov	r4,a
      0076C3 A3               [24]  989 	inc	dptr
      0076C4 E0               [24]  990 	movx	a,@dptr
      0076C5 FD               [12]  991 	mov	r5,a
      0076C6 4C               [12]  992 	orl	a,r4
      0076C7 60 19            [24]  993 	jz	00102$
                                    994 ;	quantum/action.c:404: action.code = action_for_keycode(record->keycode);
      0076C9 12 38 98         [24]  995 	lcall	_ak820_outline_0129
      0076CC C0 07            [24]  996 	push	ar7
      0076CE C0 06            [24]  997 	push	ar6
      0076D0 12 9A 42         [24]  998 	lcall	_action_for_keycode
      0076D3 12 43 72         [24]  999 	lcall	_ak820_outline_0154
      0076D6 D0 06            [24] 1000 	pop	ar6
      0076D8 D0 07            [24] 1001 	pop	ar7
      0076DA 90 08 F4         [24] 1002 	mov	dptr,#_process_record_handler_action_10000_649
      0076DD 12 38 51         [24] 1003 	lcall	_ak820_outline_0079
      0076E0 80 2B            [24] 1004 	sjmp	00104$
      0076E2                       1005 00102$:
                                   1006 ;	quantum/action.c:407: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0076E2 12 7B 9A         [24] 1007 	lcall	_ak820_outline_0023
      0076E5 7A 00            [12] 1008 	mov	r2,#0x00
      0076E7 12 43 6C         [24] 1009 	lcall	_ak820_outline_0145
      0076EA 12 42 FF         [24] 1010 	lcall	_ak820_outline_0011
      0076ED E0               [24] 1011 	movx	a,@dptr
      0076EE 90 0A 2F         [24] 1012 	mov	dptr,#_ak820_resolve_key_PARM_2
      0076F1 F0               [24] 1013 	movx	@dptr,a
      0076F2 8D 82            [24] 1014 	mov	dpl, r5
      0076F4 8C 83            [24] 1015 	mov	dph, r4
      0076F6 C0 07            [24] 1016 	push	ar7
      0076F8 C0 06            [24] 1017 	push	ar6
      0076FA 12 7F 1F         [24] 1018 	lcall	_ak820_resolve_key
      0076FD 12 9A 42         [24] 1019 	lcall	_action_for_keycode
      007700 12 43 72         [24] 1020 	lcall	_ak820_outline_0154
      007703 D0 06            [24] 1021 	pop	ar6
      007705 D0 07            [24] 1022 	pop	ar7
      007707 90 08 F4         [24] 1023 	mov	dptr,#_process_record_handler_action_10000_649
      00770A 12 38 51         [24] 1024 	lcall	_ak820_outline_0079
                                   1025 ;	quantum/action.c:416: ac_dprintf("ACTION: ");
      00770D                       1026 00104$:
                                   1027 ;	quantum/action.c:427: process_action(record, action);
      00770D 90 0E 84         [24] 1028 	mov	dptr,#___memcpy_PARM_2
      007710 74 F4            [12] 1029 	mov	a,#_process_record_handler_action_10000_649
      007712 F0               [24] 1030 	movx	@dptr,a
      007713 74 08            [12] 1031 	mov	a,#(_process_record_handler_action_10000_649 >> 8)
      007715 12 7B B2         [24] 1032 	lcall	_ak820_outline_0058
      007718 12 54 86         [24] 1033 	lcall	_ak820_outline_0111
      00771B 90 08 F6         [24] 1034 	mov	dptr,#_process_action_PARM_2
      00771E F5 F0            [12] 1035 	mov	b,a
      007720 C0 07            [24] 1036 	push	ar7
      007722 C0 06            [24] 1037 	push	ar6
      007724 12 BE 0C         [24] 1038 	lcall	___memcpy
      007727 D0 06            [24] 1039 	pop	ar6
      007729 D0 07            [24] 1040 	pop	ar7
      00772B 12 38 8D         [24] 1041 	lcall	_ak820_outline_0121
                                   1042 ;	quantum/action.c:428: }
      00772E E1 30            [24] 1043 	ajmp	_process_action
                                   1044 ;------------------------------------------------------------
                                   1045 ;Allocation info for local variables in function 'register_mouse'
                                   1046 ;------------------------------------------------------------
                                   1047 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1048 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_657'
                                   1049 ;------------------------------------------------------------
                                   1050 ;	quantum/action.c:440: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1051 ;	-----------------------------------------
                                   1052 ;	 function process_action
                                   1053 ;	-----------------------------------------
      007730                       1054 _process_action:
      007730 12 38 7A         [24] 1055 	lcall	_ak820_outline_0106
      007733 90 08 F8         [24] 1056 	mov	dptr,#_process_action_record_argument_10000_660
      007736 12 38 75         [24] 1057 	lcall	_ak820_outline_0105
                                   1058 ;	quantum/action.c:493: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007739 90 08 F8         [24] 1059 	mov	dptr,#_process_action_record_argument_10000_660
      00773C 12 37 DC         [24] 1060 	lcall	_ak820_outline_0005
                                   1061 ;	quantum/action.c:499: pressed = record->event.pressed;
      00773F A3               [24] 1062 	inc	dptr
      007740 A3               [24] 1063 	inc	dptr
      007741 A3               [24] 1064 	inc	dptr
      007742 A3               [24] 1065 	inc	dptr
      007743 A3               [24] 1066 	inc	dptr
      007744 E0               [24] 1067 	movx	a,@dptr
      007745 F5 27            [12] 1068 	mov	_process_action_sloc0_1_0,a
                                   1069 ;	quantum/action.c:523: switch (action.kind.id) {
      007747 90 08 F7         [24] 1070 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00774A E0               [24] 1071 	movx	a,@dptr
      00774B C4               [12] 1072 	swap	a
      00774C 54 0F            [12] 1073 	anl	a,#0x0f
      00774E FD               [12] 1074 	mov  r5,a
      00774F 24 F4            [12] 1075 	add	a,#0xff - 0x0b
      007751 50 03            [24] 1076 	jnc	00434$
      007753 02 79 D1         [24] 1077 	ljmp	00181$
      007756                       1078 00434$:
                                   1079 ;	free result
      007756 ED               [12] 1080 	mov	a,r5
      007757 24 0A            [12] 1081 	add	a,#(00435$-3-.)
      007759 83               [24] 1082 	movc	a,@a+pc
      00775A F5 82            [12] 1083 	mov	dpl,a
      00775C ED               [12] 1084 	mov	a,r5
      00775D 24 10            [12] 1085 	add	a,#(00436$-3-.)
      00775F 83               [24] 1086 	movc	a,@a+pc
      007760 F5 83            [12] 1087 	mov	dph,a
      007762 E4               [12] 1088 	clr	a
      007763 73               [24] 1089 	jmp	@a+dptr
      007764                       1090 00435$:
      007764 7C                    1091 	.db	00102$
      007765 7C                    1092 	.db	00102$
      007766 D1                    1093 	.db	00181$
      007767 D1                    1094 	.db	00181$
      007768 06                    1095 	.db	00123$
      007769 D1                    1096 	.db	00181$
      00776A D1                    1097 	.db	00181$
      00776B D1                    1098 	.db	00181$
      00776C 66                    1099 	.db	00131$
      00776D 38                    1100 	.db	00147$
      00776E 5E                    1101 	.db	00152$
      00776F 5E                    1102 	.db	00152$
      007770                       1103 00436$:
      007770 77                    1104 	.db	00102$>>8
      007771 77                    1105 	.db	00102$>>8
      007772 79                    1106 	.db	00181$>>8
      007773 79                    1107 	.db	00181$>>8
      007774 78                    1108 	.db	00123$>>8
      007775 79                    1109 	.db	00181$>>8
      007776 79                    1110 	.db	00181$>>8
      007777 79                    1111 	.db	00181$>>8
      007778 78                    1112 	.db	00131$>>8
      007779 79                    1113 	.db	00147$>>8
      00777A 79                    1114 	.db	00152$>>8
      00777B 79                    1115 	.db	00152$>>8
                                   1116 ;	quantum/action.c:526: case ACT_RMODS: {
      00777C                       1117 00102$:
                                   1118 ;	quantum/action.c:527: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00777C 90 08 F7         [24] 1119 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00777F E0               [24] 1120 	movx	a,@dptr
      007780 54 F0            [12] 1121 	anl	a,#0xf0
      007782 70 06            [24] 1122 	jnz	00194$
      007784 12 7B D9         [24] 1123 	lcall	_ak820_outline_0116
      007787 FD               [12] 1124 	mov	r5,a
      007788 80 07            [24] 1125 	sjmp	00195$
      00778A                       1126 00194$:
      00778A 12 7B D9         [24] 1127 	lcall	_ak820_outline_0116
      00778D C4               [12] 1128 	swap	a
      00778E 54 F0            [12] 1129 	anl	a,#0xf0
      007790 FD               [12] 1130 	mov	r5,a
      007791                       1131 00195$:
                                   1132 ;	quantum/action.c:529: if (pressed) {
      007791 E5 27            [12] 1133 	mov	a,_process_action_sloc0_1_0
      007793 60 35            [24] 1134 	jz	00119$
                                   1135 ;	quantum/action.c:530: if (mods) {
      007795 ED               [12] 1136 	mov	a,r5
      007796 60 29            [24] 1137 	jz	00110$
                                   1138 ;	quantum/action.c:531: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007798 12 7B EB         [24] 1139 	lcall	_ak820_outline_0161
      00779B FC               [12] 1140 	mov	r4,a
      00779C BC E0 00         [24] 1141 	cjne	r4,#0xe0,00440$
      00779F                       1142 00440$:
      00779F 40 07            [24] 1143 	jc	00108$
      0077A1 12 7B EB         [24] 1144 	lcall	_ak820_outline_0161
      0077A4 24 18            [12] 1145 	add	a,#0xff - 0xe7
      0077A6 50 0A            [24] 1146 	jnc	00104$
                                   1147 ;	free result
      0077A8                       1148 00108$:
      0077A8 7B F6            [12] 1149 	mov	r3,#_process_action_PARM_2
      0077AA 7C 08            [12] 1150 	mov	r4,#(_process_action_PARM_2 >> 8)
      0077AC 12 33 FC         [24] 1151 	lcall	_ak820_outline_0125
      0077AF E0               [24] 1152 	movx	a,@dptr
      0077B0 70 07            [24] 1153 	jnz	00105$
      0077B2                       1154 00104$:
                                   1155 ;	quantum/action.c:535: add_owned_mods(mods);
      0077B2 8D 82            [24] 1156 	mov	dpl, r5
      0077B4 12 81 35         [24] 1157 	lcall	_add_owned_mods
      0077B7 80 05            [24] 1158 	sjmp	00106$
      0077B9                       1159 00105$:
                                   1160 ;	quantum/action.c:537: add_owned_weak_mods(mods);
      0077B9 8D 82            [24] 1161 	mov	dpl, r5
      0077BB 12 81 52         [24] 1162 	lcall	_add_owned_weak_mods
      0077BE                       1163 00106$:
                                   1164 ;	quantum/action.c:539: send_keyboard_report();
      0077BE 12 84 6A         [24] 1165 	lcall	_send_keyboard_report
      0077C1                       1166 00110$:
                                   1167 ;	quantum/action.c:541: register_code(action.key.code);
      0077C1 12 7B C2         [24] 1168 	lcall	_ak820_outline_0081
      0077C4 12 79 E8         [24] 1169 	lcall	_register_code
      0077C7 02 79 D1         [24] 1170 	ljmp	00181$
      0077CA                       1171 00119$:
                                   1172 ;	quantum/action.c:543: unregister_code(action.key.code);
      0077CA 12 7B C2         [24] 1173 	lcall	_ak820_outline_0081
      0077CD C0 05            [24] 1174 	push	ar5
      0077CF 12 7A 55         [24] 1175 	lcall	_unregister_code
      0077D2 D0 05            [24] 1176 	pop	ar5
                                   1177 ;	quantum/action.c:544: if (mods) {
      0077D4 ED               [12] 1178 	mov	a,r5
      0077D5 70 03            [24] 1179 	jnz	00444$
      0077D7 02 79 D1         [24] 1180 	ljmp	00181$
      0077DA                       1181 00444$:
                                   1182 ;	quantum/action.c:545: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0077DA 12 7B EB         [24] 1183 	lcall	_ak820_outline_0161
      0077DD FC               [12] 1184 	mov	r4,a
      0077DE BC E0 00         [24] 1185 	cjne	r4,#0xe0,00445$
      0077E1                       1186 00445$:
      0077E1 40 07            [24] 1187 	jc	00115$
      0077E3 12 7B EB         [24] 1188 	lcall	_ak820_outline_0161
      0077E6 24 18            [12] 1189 	add	a,#0xff - 0xe7
      0077E8 50 0A            [24] 1190 	jnc	00111$
                                   1191 ;	free result
      0077EA                       1192 00115$:
      0077EA 7B F6            [12] 1193 	mov	r3,#_process_action_PARM_2
      0077EC 7C 08            [12] 1194 	mov	r4,#(_process_action_PARM_2 >> 8)
      0077EE 12 33 FC         [24] 1195 	lcall	_ak820_outline_0125
      0077F1 E0               [24] 1196 	movx	a,@dptr
      0077F2 70 07            [24] 1197 	jnz	00112$
      0077F4                       1198 00111$:
                                   1199 ;	quantum/action.c:546: del_owned_mods(mods);
      0077F4 8D 82            [24] 1200 	mov	dpl, r5
      0077F6 12 81 44         [24] 1201 	lcall	_del_owned_mods
      0077F9 80 05            [24] 1202 	sjmp	00113$
      0077FB                       1203 00112$:
                                   1204 ;	quantum/action.c:548: del_owned_weak_mods(mods);
      0077FB 8D 82            [24] 1205 	mov	dpl, r5
      0077FD 12 81 61         [24] 1206 	lcall	_del_owned_weak_mods
      007800                       1207 00113$:
                                   1208 ;	quantum/action.c:550: send_keyboard_report();
      007800 12 84 6A         [24] 1209 	lcall	_send_keyboard_report
                                   1210 ;	quantum/action.c:553: } break;
      007803 02 79 D1         [24] 1211 	ljmp	00181$
                                   1212 ;	quantum/action.c:630: case ACT_USAGE:
      007806                       1213 00123$:
                                   1214 ;	quantum/action.c:636: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007806 74 07            [12] 1215 	mov	a,#0x07
      007808 12 38 26         [24] 1216 	lcall	_ak820_outline_0036
      00780B 12 4D DC         [24] 1217 	lcall	_ak820_outline_0012
      00780E C3               [12] 1218 	clr	c
      00780F EC               [12] 1219 	mov	a,r4
      007810 94 A5            [12] 1220 	subb	a,#0xa5
      007812 ED               [12] 1221 	mov	a,r5
      007813 94 00            [12] 1222 	subb	a,#0x00
      007815 40 15            [24] 1223 	jc	00125$
      007817 74 C2            [12] 1224 	mov	a,#0xc2
      007819 9C               [12] 1225 	subb	a,r4
      00781A E4               [12] 1226 	clr	a
      00781B 9D               [12] 1227 	subb	a,r5
      00781C 40 0E            [24] 1228 	jc	00125$
                                   1229 ;	free result
                                   1230 ;	quantum/action.c:637: owned_usage_key((uint8_t)record->keycode, pressed);
      00781E 90 0B 56         [24] 1231 	mov	dptr,#_owned_usage_key_PARM_2
      007821 E5 27            [12] 1232 	mov	a,_process_action_sloc0_1_0
      007823 F0               [24] 1233 	movx	@dptr,a
      007824 8E 82            [24] 1234 	mov	dpl, r6
      007826 12 83 16         [24] 1235 	lcall	_owned_usage_key
                                   1236 ;	quantum/action.c:638: break;
      007829 02 79 D1         [24] 1237 	ljmp	00181$
      00782C                       1238 00125$:
                                   1239 ;	quantum/action.c:641: switch (action.usage.page) {
      00782C 12 7B C9         [24] 1240 	lcall	_ak820_outline_0093
      00782F FF               [12] 1241 	mov	r7,a
      007830 60 08            [24] 1242 	jz	00127$
      007832 BF 01 02         [24] 1243 	cjne	r7,#0x01,00452$
      007835 80 19            [24] 1244 	sjmp	00128$
      007837                       1245 00452$:
      007837 02 79 D1         [24] 1246 	ljmp	00181$
                                   1247 ;	quantum/action.c:642: case PAGE_SYSTEM:
      00783A                       1248 00127$:
                                   1249 ;	quantum/action.c:643: host_system_send(pressed ? action.usage.code : 0);
      00783A E5 27            [12] 1250 	mov	a,_process_action_sloc0_1_0
      00783C 60 05            [24] 1251 	jz	00196$
      00783E 12 7B E0         [24] 1252 	lcall	_ak820_outline_0137
      007841 80 04            [24] 1253 	sjmp	00197$
      007843                       1254 00196$:
      007843 7E 00            [12] 1255 	mov	r6,#0x00
      007845 7F 00            [12] 1256 	mov	r7,#0x00
      007847                       1257 00197$:
      007847 12 38 8D         [24] 1258 	lcall	_ak820_outline_0121
      00784A 12 72 18         [24] 1259 	lcall	_host_system_send
                                   1260 ;	quantum/action.c:644: break;
      00784D 02 79 D1         [24] 1261 	ljmp	00181$
                                   1262 ;	quantum/action.c:645: case PAGE_CONSUMER:
      007850                       1263 00128$:
                                   1264 ;	quantum/action.c:646: host_consumer_send(pressed ? action.usage.code : 0);
      007850 E5 27            [12] 1265 	mov	a,_process_action_sloc0_1_0
      007852 60 05            [24] 1266 	jz	00198$
      007854 12 7B E0         [24] 1267 	lcall	_ak820_outline_0137
      007857 80 04            [24] 1268 	sjmp	00199$
      007859                       1269 00198$:
      007859 7E 00            [12] 1270 	mov	r6,#0x00
      00785B 7F 00            [12] 1271 	mov	r7,#0x00
      00785D                       1272 00199$:
      00785D 12 38 8D         [24] 1273 	lcall	_ak820_outline_0121
      007860 12 72 47         [24] 1274 	lcall	_host_consumer_send
                                   1275 ;	quantum/action.c:649: break;
      007863 02 79 D1         [24] 1276 	ljmp	00181$
                                   1277 ;	quantum/action.c:656: case ACT_LAYER: {
      007866                       1278 00131$:
                                   1279 ;	quantum/action.c:657: uint8_t on = action.layer_bitop.on;
      007866 90 08 F7         [24] 1280 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007869 E0               [24] 1281 	movx	a,@dptr
      00786A 54 03            [12] 1282 	anl	a,#0x03
      00786C 90 08 FA         [24] 1283 	mov	dptr,#_process_action_on_40000_683
      00786F F0               [24] 1284 	movx	@dptr,a
                                   1285 ;	quantum/action.c:660: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007870 E0               [24] 1286 	movx	a,@dptr
      007871 FF               [12] 1287 	mov	r7,a
      007872 60 11            [24] 1288 	jz	00200$
      007874 E5 27            [12] 1289 	mov	a,_process_action_sloc0_1_0
      007876 60 07            [24] 1290 	jz	00202$
      007878 8F 06            [24] 1291 	mov	ar6,r7
      00787A 53 06 01         [24] 1292 	anl	ar6,#0x01
      00787D 80 10            [24] 1293 	sjmp	00201$
      00787F                       1294 00202$:
      00787F 74 02            [12] 1295 	mov	a,#0x02
      007881 5F               [12] 1296 	anl	a,r7
      007882 FE               [12] 1297 	mov	r6,a
      007883 80 0A            [24] 1298 	sjmp	00201$
      007885                       1299 00200$:
      007885 E5 27            [12] 1300 	mov	a,_process_action_sloc0_1_0
      007887 B4 01 00         [24] 1301 	cjne	a,#0x01,00457$
      00788A                       1302 00457$:
      00788A 92 22            [24] 1303 	mov  _process_action_sloc1_1_0,c
      00788C E4               [12] 1304 	clr	a
      00788D 33               [12] 1305 	rlc	a
      00788E FE               [12] 1306 	mov	r6,a
      00788F                       1307 00201$:
      00788F EE               [12] 1308 	mov	a,r6
      007890 70 03            [24] 1309 	jnz	00458$
      007892 02 79 D1         [24] 1310 	ljmp	00181$
      007895                       1311 00458$:
                                   1312 ;	quantum/action.c:661: uint8_t shift = action.layer_bitop.part * 4;
      007895 12 7B EB         [24] 1313 	lcall	_ak820_outline_0161
      007898 C4               [12] 1314 	swap	a
      007899 03               [12] 1315 	rr	a
      00789A 54 07            [12] 1316 	anl	a,#0x07
      00789C 25 E0            [12] 1317 	add	a,acc
      00789E 25 E0            [12] 1318 	add	a,acc
      0078A0 FF               [12] 1319 	mov	r7,a
                                   1320 ;	quantum/action.c:662: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0078A1 12 7B EB         [24] 1321 	lcall	_ak820_outline_0161
      0078A4 54 0F            [12] 1322 	anl	a,#0x0f
      0078A6 FE               [12] 1323 	mov	r6,a
      0078A7 8F F0            [24] 1324 	mov	b,r7
      0078A9 05 F0            [12] 1325 	inc	b
      0078AB EE               [12] 1326 	mov	a,r6
      0078AC 80 02            [24] 1327 	sjmp	00460$
      0078AE                       1328 00459$:
      0078AE 25 E0            [12] 1329 	add	a,acc
      0078B0                       1330 00460$:
      0078B0 D5 F0 FB         [24] 1331 	djnz	b,00459$
      0078B3 FE               [12] 1332 	mov	r6,a
                                   1333 ;	quantum/action.c:663: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0078B4 12 7B EB         [24] 1334 	lcall	_ak820_outline_0161
      0078B7 30 E4 11         [24] 1335 	jnb	acc.4,00204$
      0078BA 8F F0            [24] 1336 	mov	b,r7
      0078BC 05 F0            [12] 1337 	inc	b
      0078BE 74 0F            [12] 1338 	mov	a,#0x0f
      0078C0 80 02            [24] 1339 	sjmp	00463$
      0078C2                       1340 00462$:
      0078C2 25 E0            [12] 1341 	add	a,acc
      0078C4                       1342 00463$:
      0078C4 D5 F0 FB         [24] 1343 	djnz	b,00462$
      0078C7 F4               [12] 1344 	cpl	a
      0078C8 FF               [12] 1345 	mov	r7,a
      0078C9 80 02            [24] 1346 	sjmp	00205$
      0078CB                       1347 00204$:
      0078CB 7F 00            [12] 1348 	mov	r7,#0x00
      0078CD                       1349 00205$:
                                   1350 ;	quantum/action.c:664: bits |= mask;
      0078CD EE               [12] 1351 	mov	a,r6
      0078CE 42 07            [12] 1352 	orl	ar7,a
                                   1353 ;	quantum/action.c:665: if (!on) {
      0078D0 90 08 FA         [24] 1354 	mov	dptr,#_process_action_on_40000_683
      0078D3 E0               [24] 1355 	movx	a,@dptr
      0078D4 70 31            [24] 1356 	jnz	00143$
                                   1357 ;	quantum/action.c:666: switch (action.layer_bitop.op) {
      0078D6 12 7B C9         [24] 1358 	lcall	_ak820_outline_0093
      0078D9 FE               [12] 1359 	mov	r6,a
      0078DA 2E               [12] 1360 	add	a,r6
                                   1361 ;	quantum/action.c:667: case OP_BIT_AND: default_layer_and(bits); break;
      0078DB 90 78 DF         [24] 1362 	mov	dptr,#00465$
      0078DE 73               [24] 1363 	jmp	@a+dptr
      0078DF                       1364 00465$:
      0078DF 80 06            [24] 1365 	sjmp	00132$
      0078E1 80 0C            [24] 1366 	sjmp	00133$
      0078E3 80 12            [24] 1367 	sjmp	00134$
      0078E5 80 18            [24] 1368 	sjmp	00135$
      0078E7                       1369 00132$:
      0078E7 8F 82            [24] 1370 	mov	dpl, r7
      0078E9 12 7C 41         [24] 1371 	lcall	_default_layer_and
      0078EC 02 79 D1         [24] 1372 	ljmp	00181$
                                   1373 ;	quantum/action.c:668: case OP_BIT_OR: default_layer_or(bits); break;
      0078EF                       1374 00133$:
      0078EF 8F 82            [24] 1375 	mov	dpl, r7
      0078F1 12 7C 31         [24] 1376 	lcall	_default_layer_or
      0078F4 02 79 D1         [24] 1377 	ljmp	00181$
                                   1378 ;	quantum/action.c:669: case OP_BIT_XOR: default_layer_xor(bits); break;
      0078F7                       1379 00134$:
      0078F7 8F 82            [24] 1380 	mov	dpl, r7
      0078F9 12 7C 56         [24] 1381 	lcall	_default_layer_xor
      0078FC 02 79 D1         [24] 1382 	ljmp	00181$
                                   1383 ;	quantum/action.c:670: case OP_BIT_SET: default_layer_set(bits); break;
      0078FF                       1384 00135$:
      0078FF 8F 82            [24] 1385 	mov	dpl, r7
      007901 12 7C 27         [24] 1386 	lcall	_default_layer_set
                                   1387 ;	quantum/action.c:671: }
      007904 02 79 D1         [24] 1388 	ljmp	00181$
      007907                       1389 00143$:
                                   1390 ;	quantum/action.c:673: switch (action.layer_bitop.op) {
      007907 12 7B C9         [24] 1391 	lcall	_ak820_outline_0093
      00790A FE               [12] 1392 	mov	r6,a
      00790B 2E               [12] 1393 	add	a,r6
                                   1394 ;	quantum/action.c:674: case OP_BIT_AND: layer_and(bits); break;
      00790C 90 79 10         [24] 1395 	mov	dptr,#00466$
      00790F 73               [24] 1396 	jmp	@a+dptr
      007910                       1397 00466$:
      007910 80 06            [24] 1398 	sjmp	00137$
      007912 80 0C            [24] 1399 	sjmp	00138$
      007914 80 12            [24] 1400 	sjmp	00139$
      007916 80 18            [24] 1401 	sjmp	00140$
      007918                       1402 00137$:
      007918 8F 82            [24] 1403 	mov	dpl, r7
      00791A 12 7D CD         [24] 1404 	lcall	_layer_and
      00791D 02 79 D1         [24] 1405 	ljmp	00181$
                                   1406 ;	quantum/action.c:675: case OP_BIT_OR: layer_or(bits); break;
      007920                       1407 00138$:
      007920 8F 82            [24] 1408 	mov	dpl, r7
      007922 12 7D BD         [24] 1409 	lcall	_layer_or
      007925 02 79 D1         [24] 1410 	ljmp	00181$
                                   1411 ;	quantum/action.c:676: case OP_BIT_XOR: layer_xor(bits); break;
      007928                       1412 00139$:
      007928 8F 82            [24] 1413 	mov	dpl, r7
      00792A 12 7D E2         [24] 1414 	lcall	_layer_xor
      00792D 02 79 D1         [24] 1415 	ljmp	00181$
                                   1416 ;	quantum/action.c:677: case OP_BIT_SET: layer_state_set(bits); break;
      007930                       1417 00140$:
      007930 8F 82            [24] 1418 	mov	dpl, r7
      007932 12 7D 5F         [24] 1419 	lcall	_layer_state_set
                                   1420 ;	quantum/action.c:681: break;
      007935 02 79 D1         [24] 1421 	ljmp	00181$
                                   1422 ;	quantum/action.c:683: case ACT_LAYER_MODS:
      007938                       1423 00147$:
                                   1424 ;	quantum/action.c:684: if (pressed) {
      007938 E5 27            [12] 1425 	mov	a,_process_action_sloc0_1_0
      00793A 60 11            [24] 1426 	jz	00149$
                                   1427 ;	quantum/action.c:685: layer_hold_on(action.layer_mods.layer);
      00793C 12 7B D9         [24] 1428 	lcall	_ak820_outline_0116
      00793F F5 82            [12] 1429 	mov	dpl,a
      007941 12 7C C4         [24] 1430 	lcall	_layer_hold_on
                                   1431 ;	quantum/action.c:686: register_mods(action.layer_mods.mods);
      007944 12 7B C2         [24] 1432 	lcall	_ak820_outline_0081
      007947 12 7B 08         [24] 1433 	lcall	_register_mods
      00794A 02 79 D1         [24] 1434 	ljmp	00181$
      00794D                       1435 00149$:
                                   1436 ;	quantum/action.c:688: unregister_mods(action.layer_mods.mods);
      00794D 12 7B C2         [24] 1437 	lcall	_ak820_outline_0081
      007950 12 7B 1C         [24] 1438 	lcall	_unregister_mods
                                   1439 ;	quantum/action.c:689: layer_hold_off(action.layer_mods.layer);
      007953 12 7B D9         [24] 1440 	lcall	_ak820_outline_0116
      007956 F5 82            [12] 1441 	mov	dpl,a
      007958 12 7C FB         [24] 1442 	lcall	_layer_hold_off
                                   1443 ;	quantum/action.c:691: break;
      00795B 02 79 D1         [24] 1444 	ljmp	00181$
                                   1445 ;	quantum/action.c:693: case ACT_LAYER_TAP_EXT:
      00795E                       1446 00152$:
                                   1447 ;	quantum/action.c:694: switch (action.layer_tap.code) {
      00795E 12 7B EB         [24] 1448 	lcall	_ak820_outline_0161
      007961 FF               [12] 1449 	mov	r7,a
      007962 BF F1 02         [24] 1450 	cjne	r7,#0xf1,00468$
      007965 80 0A            [24] 1451 	sjmp	00154$
      007967                       1452 00468$:
      007967 BF F2 02         [24] 1453 	cjne	r7,#0xf2,00469$
      00796A 80 19            [24] 1454 	sjmp	00155$
      00796C                       1455 00469$:
                                   1456 ;	quantum/action.c:710: momentary_layer_action:
      00796C BF F3 3B         [24] 1457 	cjne	r7,#0xf3,00160$
      00796F 80 28            [24] 1458 	sjmp	00156$
      007971                       1459 00154$:
                                   1460 ;	quantum/action.c:711: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007971 E5 27            [12] 1461 	mov	a,_process_action_sloc0_1_0
      007973 60 08            [24] 1462 	jz	00206$
      007975 12 7B A9         [24] 1463 	lcall	_ak820_outline_0046
      007978 12 7C C4         [24] 1464 	lcall	_layer_hold_on
      00797B 80 54            [24] 1465 	sjmp	00181$
      00797D                       1466 00206$:
      00797D 12 7B A9         [24] 1467 	lcall	_ak820_outline_0046
      007980 12 7C FB         [24] 1468 	lcall	_layer_hold_off
                                   1469 ;	quantum/action.c:712: break;
                                   1470 ;	quantum/action.c:713: case OP_OFF_ON:
      007983 80 4C            [24] 1471 	sjmp	00181$
      007985                       1472 00155$:
                                   1473 ;	quantum/action.c:714: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007985 E5 27            [12] 1474 	mov	a,_process_action_sloc0_1_0
      007987 60 08            [24] 1475 	jz	00208$
      007989 12 7B A9         [24] 1476 	lcall	_ak820_outline_0046
      00798C 12 7D A0         [24] 1477 	lcall	_layer_off
      00798F 80 40            [24] 1478 	sjmp	00181$
      007991                       1479 00208$:
      007991 12 7B A9         [24] 1480 	lcall	_ak820_outline_0046
      007994 12 7D 86         [24] 1481 	lcall	_layer_on
                                   1482 ;	quantum/action.c:715: break;
                                   1483 ;	quantum/action.c:716: case OP_SET_CLEAR:
      007997 80 38            [24] 1484 	sjmp	00181$
      007999                       1485 00156$:
                                   1486 ;	quantum/action.c:717: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007999 E5 27            [12] 1487 	mov	a,_process_action_sloc0_1_0
      00799B 60 08            [24] 1488 	jz	00210$
      00799D 12 7B A9         [24] 1489 	lcall	_ak820_outline_0046
      0079A0 12 7D 71         [24] 1490 	lcall	_layer_move
      0079A3 80 2C            [24] 1491 	sjmp	00181$
      0079A5                       1492 00210$:
      0079A5 12 7D 6C         [24] 1493 	lcall	_layer_clear
                                   1494 ;	quantum/action.c:718: break;
                                   1495 ;	quantum/action.c:764: default:
      0079A8 80 27            [24] 1496 	sjmp	00181$
      0079AA                       1497 00160$:
                                   1498 ;	quantum/action.c:771: if (pressed) {
      0079AA E5 27            [12] 1499 	mov	a,_process_action_sloc0_1_0
      0079AC 60 08            [24] 1500 	jz	00163$
                                   1501 ;	quantum/action.c:773: register_code(action.layer_tap.code);
      0079AE 12 7B C2         [24] 1502 	lcall	_ak820_outline_0081
      0079B1 12 79 E8         [24] 1503 	lcall	_register_code
                                   1504 ;	quantum/action.c:775: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0079B4 80 1B            [24] 1505 	sjmp	00181$
      0079B6                       1506 00163$:
                                   1507 ;	quantum/action.c:776: if (action.layer_tap.code == KC_CAPS) {
      0079B6 12 7B EB         [24] 1508 	lcall	_ak820_outline_0161
      0079B9 FF               [12] 1509 	mov	r7,a
      0079BA BF 39 0E         [24] 1510 	cjne	r7,#0x39,00175$
                                   1511 ;	quantum/action.c:777: wait_ms(TAP_HOLD_CAPS_DELAY);
      0079BD 7F 50            [12] 1512 	mov	r7,#0x50
      0079BF                       1513 00187$:
      0079BF EF               [12] 1514 	mov	a,r7
      0079C0 60 09            [24] 1515 	jz	00175$
      0079C2 90 00 01         [24] 1516 	mov	dptr,#0x0001
      0079C5 12 5D F2         [24] 1517 	lcall	_mDelaymS
      0079C8 1F               [12] 1518 	dec	r7
                                   1519 ;	quantum/action.c:779: wait_ms(TAP_CODE_DELAY);
      0079C9 80 F4            [24] 1520 	sjmp	00187$
      0079CB                       1521 00175$:
                                   1522 ;	quantum/action.c:781: unregister_code(action.layer_tap.code);
      0079CB 12 7B C2         [24] 1523 	lcall	_ak820_outline_0081
      0079CE 12 7A 55         [24] 1524 	lcall	_unregister_code
                                   1525 ;	quantum/action.c:864: }
      0079D1                       1526 00181$:
                                   1527 ;	quantum/action.c:885: switch (action.kind.id) {
      0079D1 90 08 F7         [24] 1528 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0079D4 E0               [24] 1529 	movx	a,@dptr
      0079D5 C4               [12] 1530 	swap	a
      0079D6 54 0F            [12] 1531 	anl	a,#0x0f
      0079D8 FF               [12] 1532 	mov	r7,a
      0079D9 BF 08 02         [24] 1533 	cjne	r7,#0x08,00478$
      0079DC 80 03            [24] 1534 	sjmp	00183$
      0079DE                       1535 00478$:
      0079DE BF 09 06         [24] 1536 	cjne	r7,#0x09,00192$
                                   1537 ;	quantum/action.c:887: case ACT_LAYER_MODS:
      0079E1                       1538 00183$:
                                   1539 ;	quantum/action.c:892: led_set(host_keyboard_leds());
      0079E1 12 71 7D         [24] 1540 	lcall	_host_keyboard_leds
                                   1541 ;	quantum/action.c:896: }
                                   1542 ;	quantum/action.c:949: }
      0079E4 02 9C F3         [24] 1543 	ljmp	_led_set
      0079E7                       1544 00192$:
      0079E7 22               [24] 1545 	ret
                                   1546 ;------------------------------------------------------------
                                   1547 ;Allocation info for local variables in function 'register_code'
                                   1548 ;------------------------------------------------------------
                                   1549 ;code          Allocated with name '_register_code_code_10000_717'
                                   1550 ;------------------------------------------------------------
                                   1551 ;	quantum/action.c:955: __attribute__((weak)) void register_code(uint8_t code) {
                                   1552 ;	-----------------------------------------
                                   1553 ;	 function register_code
                                   1554 ;	-----------------------------------------
      0079E8                       1555 _register_code:
      0079E8 E5 82            [12] 1556 	mov	a,dpl
      0079EA 90 08 FB         [24] 1557 	mov	dptr,#_register_code_code_10000_717
      0079ED F0               [24] 1558 	movx	@dptr,a
                                   1559 ;	quantum/action.c:956: if (code == KC_NO) {
      0079EE E0               [24] 1560 	movx	a,@dptr
      0079EF FF               [12] 1561 	mov	r7,a
      0079F0 70 01            [24] 1562 	jnz	00123$
                                   1563 ;	quantum/action.c:957: return;
      0079F2 22               [24] 1564 	ret
      0079F3                       1565 00123$:
                                   1566 ;	quantum/action.c:992: } else if (IS_BASIC_KEYCODE(code)) {
      0079F3 BF 04 00         [24] 1567 	cjne	r7,#0x04,00186$
      0079F6                       1568 00186$:
      0079F6 40 12            [24] 1569 	jc	00119$
      0079F8 EF               [12] 1570 	mov	a,r7
      0079F9 24 5B            [12] 1571 	add	a,#0xff - 0xa4
      0079FB 40 0D            [24] 1572 	jc	00119$
                                   1573 ;	free result
                                   1574 ;	quantum/action.c:997: if (!add_owned_key(code)) return;
      0079FD 8F 82            [24] 1575 	mov	dpl, r7
      0079FF 12 81 D5         [24] 1576 	lcall	_add_owned_key
      007A02 E5 82            [12] 1577 	mov	a, dpl
      007A04 70 01            [24] 1578 	jnz	00104$
      007A06 22               [24] 1579 	ret
      007A07                       1580 00104$:
                                   1581 ;	quantum/action.c:1011: send_keyboard_report();
      007A07 02 84 6A         [24] 1582 	ljmp	_send_keyboard_report
      007A0A                       1583 00119$:
                                   1584 ;	quantum/action.c:1012: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A0A 12 7B F0         [24] 1585 	lcall	_ak820_outline_0170
      007A0D BF E0 00         [24] 1586 	cjne	r7,#0xe0,00190$
      007A10                       1587 00190$:
      007A10 40 1A            [24] 1588 	jc	00115$
      007A12 EF               [12] 1589 	mov	a,r7
      007A13 24 18            [12] 1590 	add	a,#0xff - 0xe7
      007A15 40 15            [24] 1591 	jc	00115$
                                   1592 ;	free result
                                   1593 ;	quantum/action.c:1013: add_owned_mods(MOD_BIT(code));
      007A17 74 07            [12] 1594 	mov	a,#0x07
      007A19 5F               [12] 1595 	anl	a,r7
      007A1A 12 7B BB         [24] 1596 	lcall	_ak820_outline_0068
      007A1D 80 02            [24] 1597 	sjmp	00194$
      007A1F                       1598 00193$:
      007A1F 25 E0            [12] 1599 	add	a,acc
      007A21                       1600 00194$:
      007A21 D5 F0 FB         [24] 1601 	djnz	b,00193$
      007A24 F5 82            [12] 1602 	mov	dpl,a
      007A26 12 81 35         [24] 1603 	lcall	_add_owned_mods
                                   1604 ;	quantum/action.c:1014: send_keyboard_report();
      007A29 02 84 6A         [24] 1605 	ljmp	_send_keyboard_report
      007A2C                       1606 00115$:
                                   1607 ;	quantum/action.c:1017: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A2C 12 7B F0         [24] 1608 	lcall	_ak820_outline_0170
      007A2F BF A5 00         [24] 1609 	cjne	r7,#0xa5,00195$
      007A32                       1610 00195$:
      007A32 40 05            [24] 1611 	jc	00113$
      007A34 EF               [12] 1612 	mov	a,r7
      007A35 24 58            [12] 1613 	add	a,#0xff - 0xa7
      007A37 50 0D            [24] 1614 	jnc	00108$
                                   1615 ;	free result
      007A39                       1616 00113$:
      007A39 12 7B F0         [24] 1617 	lcall	_ak820_outline_0170
      007A3C BF A8 00         [24] 1618 	cjne	r7,#0xa8,00198$
      007A3F                       1619 00198$:
      007A3F 40 13            [24] 1620 	jc	00125$
      007A41 EF               [12] 1621 	mov	a,r7
      007A42 24 3D            [12] 1622 	add	a,#0xff - 0xc2
      007A44 40 0E            [24] 1623 	jc	00125$
                                   1624 ;	free result
      007A46                       1625 00108$:
                                   1626 ;	quantum/action.c:1019: owned_usage_key(code, true);
      007A46 12 7B F0         [24] 1627 	lcall	_ak820_outline_0170
      007A49 90 0B 56         [24] 1628 	mov	dptr,#_owned_usage_key_PARM_2
      007A4C 74 01            [12] 1629 	mov	a,#0x01
      007A4E F0               [24] 1630 	movx	@dptr,a
      007A4F 8F 82            [24] 1631 	mov	dpl, r7
                                   1632 ;	quantum/action.c:1027: register_mouse(code, true);
                                   1633 ;	quantum/action.c:1029: }
      007A51 02 83 16         [24] 1634 	ljmp	_owned_usage_key
      007A54                       1635 00125$:
      007A54 22               [24] 1636 	ret
                                   1637 ;------------------------------------------------------------
                                   1638 ;Allocation info for local variables in function 'unregister_code'
                                   1639 ;------------------------------------------------------------
                                   1640 ;code          Allocated with name '_unregister_code_code_10000_731'
                                   1641 ;------------------------------------------------------------
                                   1642 ;	quantum/action.c:1035: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1643 ;	-----------------------------------------
                                   1644 ;	 function unregister_code
                                   1645 ;	-----------------------------------------
      007A55                       1646 _unregister_code:
      007A55 E5 82            [12] 1647 	mov	a,dpl
      007A57 90 08 FC         [24] 1648 	mov	dptr,#_unregister_code_code_10000_731
      007A5A F0               [24] 1649 	movx	@dptr,a
                                   1650 ;	quantum/action.c:1036: if (code == KC_NO) {
      007A5B E0               [24] 1651 	movx	a,@dptr
      007A5C FF               [12] 1652 	mov	r7,a
      007A5D 70 01            [24] 1653 	jnz	00121$
                                   1654 ;	quantum/action.c:1037: return;
      007A5F 22               [24] 1655 	ret
      007A60                       1656 00121$:
                                   1657 ;	quantum/action.c:1069: } else if (IS_BASIC_KEYCODE(code)) {
      007A60 BF 04 00         [24] 1658 	cjne	r7,#0x04,00184$
      007A63                       1659 00184$:
      007A63 40 12            [24] 1660 	jc	00117$
      007A65 EF               [12] 1661 	mov	a,r7
      007A66 24 5B            [12] 1662 	add	a,#0xff - 0xa4
      007A68 40 0D            [24] 1663 	jc	00117$
                                   1664 ;	free result
                                   1665 ;	quantum/action.c:1071: if (!del_owned_key(code)) return;
      007A6A 8F 82            [24] 1666 	mov	dpl, r7
      007A6C 12 82 4F         [24] 1667 	lcall	_del_owned_key
      007A6F E5 82            [12] 1668 	mov	a, dpl
      007A71 70 01            [24] 1669 	jnz	00102$
      007A73 22               [24] 1670 	ret
      007A74                       1671 00102$:
                                   1672 ;	quantum/action.c:1078: send_keyboard_report();
      007A74 02 84 6A         [24] 1673 	ljmp	_send_keyboard_report
      007A77                       1674 00117$:
                                   1675 ;	quantum/action.c:1079: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A77 12 7B F6         [24] 1676 	lcall	_ak820_outline_0171
      007A7A BF E0 00         [24] 1677 	cjne	r7,#0xe0,00188$
      007A7D                       1678 00188$:
      007A7D 40 1A            [24] 1679 	jc	00113$
      007A7F EF               [12] 1680 	mov	a,r7
      007A80 24 18            [12] 1681 	add	a,#0xff - 0xe7
      007A82 40 15            [24] 1682 	jc	00113$
                                   1683 ;	free result
                                   1684 ;	quantum/action.c:1080: del_owned_mods(MOD_BIT(code));
      007A84 74 07            [12] 1685 	mov	a,#0x07
      007A86 5F               [12] 1686 	anl	a,r7
      007A87 12 7B BB         [24] 1687 	lcall	_ak820_outline_0068
      007A8A 80 02            [24] 1688 	sjmp	00192$
      007A8C                       1689 00191$:
      007A8C 25 E0            [12] 1690 	add	a,acc
      007A8E                       1691 00192$:
      007A8E D5 F0 FB         [24] 1692 	djnz	b,00191$
      007A91 F5 82            [12] 1693 	mov	dpl,a
      007A93 12 81 44         [24] 1694 	lcall	_del_owned_mods
                                   1695 ;	quantum/action.c:1081: send_keyboard_report();
      007A96 02 84 6A         [24] 1696 	ljmp	_send_keyboard_report
      007A99                       1697 00113$:
                                   1698 ;	quantum/action.c:1084: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A99 12 7B F6         [24] 1699 	lcall	_ak820_outline_0171
      007A9C BF A5 00         [24] 1700 	cjne	r7,#0xa5,00193$
      007A9F                       1701 00193$:
      007A9F 40 05            [24] 1702 	jc	00111$
      007AA1 EF               [12] 1703 	mov	a,r7
      007AA2 24 58            [12] 1704 	add	a,#0xff - 0xa7
      007AA4 50 0D            [24] 1705 	jnc	00106$
                                   1706 ;	free result
      007AA6                       1707 00111$:
      007AA6 12 7B F6         [24] 1708 	lcall	_ak820_outline_0171
      007AA9 BF A8 00         [24] 1709 	cjne	r7,#0xa8,00196$
      007AAC                       1710 00196$:
      007AAC 40 12            [24] 1711 	jc	00123$
      007AAE EF               [12] 1712 	mov	a,r7
      007AAF 24 3D            [12] 1713 	add	a,#0xff - 0xc2
      007AB1 40 0D            [24] 1714 	jc	00123$
                                   1715 ;	free result
      007AB3                       1716 00106$:
                                   1717 ;	quantum/action.c:1086: owned_usage_key(code, false);
      007AB3 12 7B F6         [24] 1718 	lcall	_ak820_outline_0171
      007AB6 90 0B 56         [24] 1719 	mov	dptr,#_owned_usage_key_PARM_2
      007AB9 E4               [12] 1720 	clr	a
      007ABA F0               [24] 1721 	movx	@dptr,a
      007ABB 8F 82            [24] 1722 	mov	dpl, r7
                                   1723 ;	quantum/action.c:1094: register_mouse(code, false);
                                   1724 ;	quantum/action.c:1096: }
      007ABD 02 83 16         [24] 1725 	ljmp	_owned_usage_key
      007AC0                       1726 00123$:
      007AC0 22               [24] 1727 	ret
                                   1728 ;------------------------------------------------------------
                                   1729 ;Allocation info for local variables in function 'tap_code_delay'
                                   1730 ;------------------------------------------------------------
                                   1731 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1732 ;code          Allocated with name '_tap_code_delay_code_10000_744'
                                   1733 ;i             Allocated with name '_tap_code_delay_i_20000_746'
                                   1734 ;i             Allocated with name '_tap_code_delay_i_50000_749'
                                   1735 ;------------------------------------------------------------
                                   1736 ;	quantum/action.c:1103: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1737 ;	-----------------------------------------
                                   1738 ;	 function tap_code_delay
                                   1739 ;	-----------------------------------------
      007AC1                       1740 _tap_code_delay:
      007AC1 E5 82            [12] 1741 	mov	a,dpl
      007AC3 90 08 FF         [24] 1742 	mov	dptr,#_tap_code_delay_code_10000_744
      007AC6 F0               [24] 1743 	movx	@dptr,a
                                   1744 ;	quantum/action.c:1104: register_code(code);
      007AC7 E0               [24] 1745 	movx	a,@dptr
      007AC8 FF               [12] 1746 	mov	r7,a
      007AC9 F5 82            [12] 1747 	mov	dpl,a
      007ACB C0 07            [24] 1748 	push	ar7
      007ACD 31 E8            [12] 1749 	acall	_register_code
      007ACF D0 07            [24] 1750 	pop	ar7
                                   1751 ;	quantum/action.c:1105: for (uint16_t i = delay; i > 0; i--) {
      007AD1 90 08 FD         [24] 1752 	mov	dptr,#_tap_code_delay_PARM_2
      007AD4 12 38 5D         [24] 1753 	lcall	_ak820_outline_0085
      007AD7                       1754 00110$:
      007AD7 ED               [12] 1755 	mov	a,r5
      007AD8 4E               [12] 1756 	orl	a,r6
      007AD9 60 0D            [24] 1757 	jz	00105$
                                   1758 ;	quantum/action.c:1106: wait_ms(1);
      007ADB 90 00 01         [24] 1759 	mov	dptr,#0x0001
      007ADE 12 5D F2         [24] 1760 	lcall	_mDelaymS
                                   1761 ;	quantum/action.c:1105: for (uint16_t i = delay; i > 0; i--) {
      007AE1 1D               [12] 1762 	dec	r5
      007AE2 BD FF 01         [24] 1763 	cjne	r5,#0xff,00141$
      007AE5 1E               [12] 1764 	dec	r6
      007AE6                       1765 00141$:
      007AE6 80 EF            [24] 1766 	sjmp	00110$
      007AE8                       1767 00105$:
                                   1768 ;	quantum/action.c:1108: unregister_code(code);
      007AE8 8F 82            [24] 1769 	mov	dpl, r7
                                   1770 ;	quantum/action.c:1109: }
      007AEA 41 55            [12] 1771 	ajmp	_unregister_code
                                   1772 ;------------------------------------------------------------
                                   1773 ;Allocation info for local variables in function 'tap_code'
                                   1774 ;------------------------------------------------------------
                                   1775 ;code          Allocated with name '_tap_code_code_10000_751'
                                   1776 ;------------------------------------------------------------
                                   1777 ;	quantum/action.c:1115: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1778 ;	-----------------------------------------
                                   1779 ;	 function tap_code
                                   1780 ;	-----------------------------------------
      007AEC                       1781 _tap_code:
      007AEC E5 82            [12] 1782 	mov	a,dpl
      007AEE 90 09 00         [24] 1783 	mov	dptr,#_tap_code_code_10000_751
      007AF1 F0               [24] 1784 	movx	@dptr,a
                                   1785 ;	quantum/action.c:1116: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007AF2 E0               [24] 1786 	movx	a,@dptr
      007AF3 FF               [12] 1787 	mov	r7,a
      007AF4 BF 39 04         [24] 1788 	cjne	r7,#0x39,00103$
      007AF7 7E 50            [12] 1789 	mov	r6,#0x50
      007AF9 80 02            [24] 1790 	sjmp	00104$
      007AFB                       1791 00103$:
      007AFB 7E 00            [12] 1792 	mov	r6,#0x00
      007AFD                       1793 00104$:
      007AFD 90 08 FD         [24] 1794 	mov	dptr,#_tap_code_delay_PARM_2
      007B00 EE               [12] 1795 	mov	a,r6
      007B01 12 38 9D         [24] 1796 	lcall	_ak820_outline_0130
      007B04 8F 82            [24] 1797 	mov	dpl, r7
                                   1798 ;	quantum/action.c:1117: }
      007B06 41 C1            [12] 1799 	ajmp	_tap_code_delay
                                   1800 ;------------------------------------------------------------
                                   1801 ;Allocation info for local variables in function 'register_mods'
                                   1802 ;------------------------------------------------------------
                                   1803 ;mods          Allocated with name '_register_mods_mods_10000_753'
                                   1804 ;------------------------------------------------------------
                                   1805 ;	quantum/action.c:1123: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1806 ;	-----------------------------------------
                                   1807 ;	 function register_mods
                                   1808 ;	-----------------------------------------
      007B08                       1809 _register_mods:
      007B08 E5 82            [12] 1810 	mov	a,dpl
      007B0A 90 09 01         [24] 1811 	mov	dptr,#_register_mods_mods_10000_753
      007B0D F0               [24] 1812 	movx	@dptr,a
                                   1813 ;	quantum/action.c:1124: if (mods) {
      007B0E E0               [24] 1814 	movx	a,@dptr
      007B0F FF               [12] 1815 	mov	r7,a
      007B10 E0               [24] 1816 	movx	a,@dptr
      007B11 60 08            [24] 1817 	jz	00103$
                                   1818 ;	quantum/action.c:1125: add_owned_mods(mods);
      007B13 8F 82            [24] 1819 	mov	dpl, r7
      007B15 12 81 35         [24] 1820 	lcall	_add_owned_mods
                                   1821 ;	quantum/action.c:1126: send_keyboard_report();
                                   1822 ;	quantum/action.c:1128: }
      007B18 02 84 6A         [24] 1823 	ljmp	_send_keyboard_report
      007B1B                       1824 00103$:
      007B1B 22               [24] 1825 	ret
                                   1826 ;------------------------------------------------------------
                                   1827 ;Allocation info for local variables in function 'unregister_mods'
                                   1828 ;------------------------------------------------------------
                                   1829 ;mods          Allocated with name '_unregister_mods_mods_10000_757'
                                   1830 ;------------------------------------------------------------
                                   1831 ;	quantum/action.c:1134: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1832 ;	-----------------------------------------
                                   1833 ;	 function unregister_mods
                                   1834 ;	-----------------------------------------
      007B1C                       1835 _unregister_mods:
      007B1C E5 82            [12] 1836 	mov	a,dpl
      007B1E 90 09 02         [24] 1837 	mov	dptr,#_unregister_mods_mods_10000_757
      007B21 F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	quantum/action.c:1135: if (mods) {
      007B22 E0               [24] 1840 	movx	a,@dptr
      007B23 FF               [12] 1841 	mov	r7,a
      007B24 E0               [24] 1842 	movx	a,@dptr
      007B25 60 08            [24] 1843 	jz	00103$
                                   1844 ;	quantum/action.c:1136: del_owned_mods(mods);
      007B27 8F 82            [24] 1845 	mov	dpl, r7
      007B29 12 81 44         [24] 1846 	lcall	_del_owned_mods
                                   1847 ;	quantum/action.c:1137: send_keyboard_report();
                                   1848 ;	quantum/action.c:1139: }
      007B2C 02 84 6A         [24] 1849 	ljmp	_send_keyboard_report
      007B2F                       1850 00103$:
      007B2F 22               [24] 1851 	ret
                                   1852 ;------------------------------------------------------------
                                   1853 ;Allocation info for local variables in function 'register_weak_mods'
                                   1854 ;------------------------------------------------------------
                                   1855 ;mods          Allocated with name '_register_weak_mods_mods_10000_761'
                                   1856 ;------------------------------------------------------------
                                   1857 ;	quantum/action.c:1145: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1858 ;	-----------------------------------------
                                   1859 ;	 function register_weak_mods
                                   1860 ;	-----------------------------------------
      007B30                       1861 _register_weak_mods:
      007B30 E5 82            [12] 1862 	mov	a,dpl
      007B32 90 09 03         [24] 1863 	mov	dptr,#_register_weak_mods_mods_10000_761
      007B35 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	quantum/action.c:1146: if (mods) {
      007B36 E0               [24] 1866 	movx	a,@dptr
      007B37 FF               [12] 1867 	mov	r7,a
      007B38 E0               [24] 1868 	movx	a,@dptr
      007B39 60 08            [24] 1869 	jz	00103$
                                   1870 ;	quantum/action.c:1147: add_owned_weak_mods(mods);
      007B3B 8F 82            [24] 1871 	mov	dpl, r7
      007B3D 12 81 52         [24] 1872 	lcall	_add_owned_weak_mods
                                   1873 ;	quantum/action.c:1148: send_keyboard_report();
                                   1874 ;	quantum/action.c:1150: }
      007B40 02 84 6A         [24] 1875 	ljmp	_send_keyboard_report
      007B43                       1876 00103$:
      007B43 22               [24] 1877 	ret
                                   1878 ;------------------------------------------------------------
                                   1879 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1880 ;------------------------------------------------------------
                                   1881 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_765'
                                   1882 ;------------------------------------------------------------
                                   1883 ;	quantum/action.c:1156: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1884 ;	-----------------------------------------
                                   1885 ;	 function unregister_weak_mods
                                   1886 ;	-----------------------------------------
      007B44                       1887 _unregister_weak_mods:
      007B44 E5 82            [12] 1888 	mov	a,dpl
      007B46 90 09 04         [24] 1889 	mov	dptr,#_unregister_weak_mods_mods_10000_765
      007B49 F0               [24] 1890 	movx	@dptr,a
                                   1891 ;	quantum/action.c:1157: if (mods) {
      007B4A E0               [24] 1892 	movx	a,@dptr
      007B4B FF               [12] 1893 	mov	r7,a
      007B4C E0               [24] 1894 	movx	a,@dptr
      007B4D 60 08            [24] 1895 	jz	00103$
                                   1896 ;	quantum/action.c:1158: del_owned_weak_mods(mods);
      007B4F 8F 82            [24] 1897 	mov	dpl, r7
      007B51 12 81 61         [24] 1898 	lcall	_del_owned_weak_mods
                                   1899 ;	quantum/action.c:1159: send_keyboard_report();
                                   1900 ;	quantum/action.c:1161: }
      007B54 02 84 6A         [24] 1901 	ljmp	_send_keyboard_report
      007B57                       1902 00103$:
      007B57 22               [24] 1903 	ret
                                   1904 ;------------------------------------------------------------
                                   1905 ;Allocation info for local variables in function 'clear_keyboard'
                                   1906 ;------------------------------------------------------------
                                   1907 ;	quantum/action.c:1167: void clear_keyboard(void) {
                                   1908 ;	-----------------------------------------
                                   1909 ;	 function clear_keyboard
                                   1910 ;	-----------------------------------------
      007B58                       1911 _clear_keyboard:
                                   1912 ;	quantum/action.c:1168: clear_mods();
      007B58 12 84 E5         [24] 1913 	lcall	_clear_mods
                                   1914 ;	quantum/action.c:1169: clear_keyboard_but_mods();
                                   1915 ;	quantum/action.c:1170: }
      007B5B 61 5D            [12] 1916 	ajmp	_clear_keyboard_but_mods
                                   1917 ;------------------------------------------------------------
                                   1918 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1919 ;------------------------------------------------------------
                                   1920 ;	quantum/action.c:1176: void clear_keyboard_but_mods(void) {
                                   1921 ;	-----------------------------------------
                                   1922 ;	 function clear_keyboard_but_mods
                                   1923 ;	-----------------------------------------
      007B5D                       1924 _clear_keyboard_but_mods:
                                   1925 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B5D 90 0E A9         [24] 1926 	mov	dptr,#_actual_keyboard_report
      007B60 12 74 2B         [24] 1927 	lcall	_clear_keys_from_report
                                   1928 ;	quantum/action.c:1178: clear_keyboard_but_mods_and_keys();
                                   1929 ;	quantum/action.c:1179: }
      007B63 61 65            [12] 1930 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1931 ;------------------------------------------------------------
                                   1932 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1933 ;------------------------------------------------------------
                                   1934 ;	quantum/action.c:1185: void clear_keyboard_but_mods_and_keys(void) {
                                   1935 ;	-----------------------------------------
                                   1936 ;	 function clear_keyboard_but_mods_and_keys
                                   1937 ;	-----------------------------------------
      007B65                       1938 _clear_keyboard_but_mods_and_keys:
                                   1939 ;	quantum/action.c:1187: ak820_tapping_cancel();
      007B65 12 4C 7B         [24] 1940 	lcall	_ak820_tapping_cancel
                                   1941 ;	quantum/action.c:1189: ak820_tap_dance_cancel();
      007B68 12 48 79         [24] 1942 	lcall	_ak820_tap_dance_cancel
                                   1943 ;	quantum/action.c:1204: ak820_oneshot_cancel();
      007B6B 12 2E F0         [24] 1944 	lcall	_ak820_oneshot_cancel
                                   1945 ;	quantum/action.c:1207: ak820_combo_cancel();
      007B6E 12 35 6A         [24] 1946 	lcall	_ak820_combo_cancel
                                   1947 ;	quantum/action.c:1210: repeat_key_cancel();
      007B71 12 A6 EE         [24] 1948 	lcall	_repeat_key_cancel
                                   1949 ;	quantum/action.c:1212: clear_owned_mods();
      007B74 12 81 70         [24] 1950 	lcall	_clear_owned_mods
                                   1951 ;	quantum/action.c:1213: clear_owned_keys();
      007B77 12 81 A8         [24] 1952 	lcall	_clear_owned_keys
                                   1953 ;	quantum/action.c:1214: clear_owned_usages();
      007B7A 12 82 DE         [24] 1954 	lcall	_clear_owned_usages
                                   1955 ;	quantum/action.c:1215: layer_hold_clear();
      007B7D B1 32            [12] 1956 	acall	_layer_hold_clear
                                   1957 ;	quantum/action.c:1217: clear_macro_tri_layer();
      007B7F 12 A1 A9         [24] 1958 	lcall	_clear_macro_tri_layer
                                   1959 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B82 90 0E A9         [24] 1960 	mov	dptr,#_actual_keyboard_report
      007B85 12 74 2B         [24] 1961 	lcall	_clear_keys_from_report
                                   1962 ;	quantum/action.c:1222: host_system_send(0);
      007B88 90 00 00         [24] 1963 	mov	dptr,#0x0000
      007B8B 12 72 18         [24] 1964 	lcall	_host_system_send
                                   1965 ;	quantum/action.c:1223: host_consumer_send(0);
      007B8E 90 00 00         [24] 1966 	mov	dptr,#0x0000
      007B91 12 72 47         [24] 1967 	lcall	_host_consumer_send
                                   1968 ;	quantum/action.c:1225: clear_weak_mods();
      007B94 12 85 1A         [24] 1969 	lcall	_clear_weak_mods
                                   1970 ;	quantum/action.c:1226: send_keyboard_report();
                                   1971 ;	quantum/action.c:1234: }
      007B97 02 84 6A         [24] 1972 	ljmp	_send_keyboard_report
                                   1973 ;------------------------------------------------------------
                                   1974 ;Allocation info for local variables in function 'is_tap_record'
                                   1975 ;------------------------------------------------------------
                                   1976 ;record        Allocated with name '_is_tap_record_record_10000_781'
                                   1977 ;action        Allocated with name '_is_tap_record_action_10001_785'
                                   1978 ;------------------------------------------------------------
                                   1979 ;	quantum/action.c:1240: bool is_tap_record(keyrecord_t *record) {
                                   1980 ;	-----------------------------------------
                                   1981 	.area CSEG    (CODE)
                                   1982 	.area CONST   (CODE)
                                   1983 	.area XINIT   (CODE)
      00C6DC                       1984 __xinit__disable_action_cache:
      00C6DC 00                    1985 	.db #0x00	;  0
                                   1986 	.area CABS    (ABS,CODE)
                                   1987 
                                   1988 ; Experimental exact instruction outlining.
                                   1989 	.globl _ak820_outline_0005
                                   1990 	.globl _ak820_outline_0008
                                   1991 	.globl _ak820_outline_0011
                                   1992 	.globl _ak820_outline_0012
                                   1993 	.globl _ak820_outline_0014
                                   1994 	.globl _ak820_outline_0019
                                   1995 	.globl _ak820_outline_0020
                                   1996 	.globl _ak820_outline_0023
                                   1997 	.globl _ak820_outline_0036
                                   1998 	.globl _ak820_outline_0046
                                   1999 	.globl _ak820_outline_0058
                                   2000 	.globl _ak820_outline_0059
                                   2001 	.globl _ak820_outline_0068
                                   2002 	.globl _ak820_outline_0072
                                   2003 	.globl _ak820_outline_0079
                                   2004 	.globl _ak820_outline_0081
                                   2005 	.globl _ak820_outline_0085
                                   2006 	.globl _ak820_outline_0093
                                   2007 	.globl _ak820_outline_0105
                                   2008 	.globl _ak820_outline_0106
                                   2009 	.globl _ak820_outline_0111
                                   2010 	.globl _ak820_outline_0112
                                   2011 	.globl _ak820_outline_0116
                                   2012 	.globl _ak820_outline_0121
                                   2013 	.globl _ak820_outline_0125
                                   2014 	.globl _ak820_outline_0129
                                   2015 	.globl _ak820_outline_0130
                                   2016 	.globl _ak820_outline_0131
                                   2017 	.globl _ak820_outline_0137
                                   2018 	.globl _ak820_outline_0145
                                   2019 	.globl _ak820_outline_0146
                                   2020 	.globl _ak820_outline_0154
                                   2021 	.globl _ak820_outline_0161
                                   2022 	.globl _ak820_outline_0170
                                   2023 	.globl _ak820_outline_0171
                                   2024 
                                   2025 	.area CSEG (CODE)
                                   2026 ; function ak820_outline_0023
      007B9A                       2027 _ak820_outline_0023:
      007B9A 8E 82            [24] 2028 	mov	dpl,r6
      007B9C 8F 83            [24] 2029 	mov	dph,r7
      007B9E A3               [24] 2030 	inc	dptr
      007B9F E0               [24] 2031 	movx	a,@dptr
      007BA0 FC               [12] 2032 	mov	r4,a
      007BA1 7D 00            [12] 2033 	mov	r5,#0x00
      007BA3 8E 82            [24] 2034 	mov	dpl,r6
      007BA5 8F 83            [24] 2035 	mov	dph,r7
      007BA7 E0               [24] 2036 	movx	a,@dptr
      007BA8 22               [24] 2037 	ret
                                   2038 
                                   2039 	.area CSEG (CODE)
                                   2040 ; function ak820_outline_0046
      007BA9                       2041 _ak820_outline_0046:
      007BA9 90 08 F7         [24] 2042 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007BAC E0               [24] 2043 	movx	a,@dptr
      007BAD 54 1F            [12] 2044 	anl	a,#0x1f
      007BAF F5 82            [12] 2045 	mov	dpl,a
      007BB1 22               [24] 2046 	ret
                                   2047 
                                   2048 	.area CSEG (CODE)
                                   2049 ; function ak820_outline_0058
      007BB2                       2050 _ak820_outline_0058:
      007BB2 A3               [24] 2051 	inc	dptr
      007BB3 F0               [24] 2052 	movx	@dptr,a
      007BB4 E4               [12] 2053 	clr	a
      007BB5 A3               [24] 2054 	inc	dptr
      007BB6 F0               [24] 2055 	movx	@dptr,a
      007BB7 90 0E 87         [24] 2056 	mov	dptr,#___memcpy_PARM_3
      007BBA 22               [24] 2057 	ret
                                   2058 
                                   2059 	.area CSEG (CODE)
                                   2060 ; function ak820_outline_0068
      007BBB                       2061 _ak820_outline_0068:
      007BBB F5 F0            [12] 2062 	mov	b,a
      007BBD 05 F0            [12] 2063 	inc	b
      007BBF 74 01            [12] 2064 	mov	a,#0x01
      007BC1 22               [24] 2065 	ret
                                   2066 
                                   2067 	.area CSEG (CODE)
                                   2068 ; function ak820_outline_0081
      007BC2                       2069 _ak820_outline_0081:
      007BC2 90 08 F6         [24] 2070 	mov	dptr,#_process_action_PARM_2
      007BC5 E0               [24] 2071 	movx	a,@dptr
      007BC6 F5 82            [12] 2072 	mov	dpl,a
      007BC8 22               [24] 2073 	ret
                                   2074 
                                   2075 	.area CSEG (CODE)
                                   2076 ; function ak820_outline_0093
      007BC9                       2077 _ak820_outline_0093:
      007BC9 90 08 F7         [24] 2078 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007BCC E0               [24] 2079 	movx	a,@dptr
      007BCD 03               [12] 2080 	rr	a
      007BCE 03               [12] 2081 	rr	a
      007BCF 54 03            [12] 2082 	anl	a,#0x03
      007BD1 22               [24] 2083 	ret
                                   2084 
                                   2085 	.area CSEG (CODE)
                                   2086 ; function ak820_outline_0112
      007BD2                       2087 _ak820_outline_0112:
      007BD2 74 06            [12] 2088 	mov	a,#0x06
      007BD4 F0               [24] 2089 	movx	@dptr,a
      007BD5 E4               [12] 2090 	clr	a
      007BD6 A3               [24] 2091 	inc	dptr
      007BD7 F0               [24] 2092 	movx	@dptr,a
      007BD8 22               [24] 2093 	ret
                                   2094 
                                   2095 	.area CSEG (CODE)
                                   2096 ; function ak820_outline_0116
      007BD9                       2097 _ak820_outline_0116:
      007BD9 90 08 F7         [24] 2098 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007BDC E0               [24] 2099 	movx	a,@dptr
      007BDD 54 0F            [12] 2100 	anl	a,#0x0f
      007BDF 22               [24] 2101 	ret
                                   2102 
                                   2103 	.area CSEG (CODE)
                                   2104 ; function ak820_outline_0137
      007BE0                       2105 _ak820_outline_0137:
      007BE0 90 08 F6         [24] 2106 	mov	dptr,#_process_action_PARM_2
      007BE3 E0               [24] 2107 	movx	a,@dptr
      007BE4 FE               [12] 2108 	mov	r6,a
      007BE5 A3               [24] 2109 	inc	dptr
      007BE6 E0               [24] 2110 	movx	a,@dptr
      007BE7 54 03            [12] 2111 	anl	a,#0x03
      007BE9 FF               [12] 2112 	mov	r7,a
      007BEA 22               [24] 2113 	ret
                                   2114 
                                   2115 	.area CSEG (CODE)
                                   2116 ; function ak820_outline_0161
      007BEB                       2117 _ak820_outline_0161:
      007BEB 90 08 F6         [24] 2118 	mov	dptr,#_process_action_PARM_2
      007BEE E0               [24] 2119 	movx	a,@dptr
      007BEF 22               [24] 2120 	ret
                                   2121 
                                   2122 	.area CSEG (CODE)
                                   2123 ; function ak820_outline_0170
      007BF0                       2124 _ak820_outline_0170:
      007BF0 90 08 FB         [24] 2125 	mov	dptr,#_register_code_code_10000_717
      007BF3 E0               [24] 2126 	movx	a,@dptr
      007BF4 FF               [12] 2127 	mov	r7,a
      007BF5 22               [24] 2128 	ret
                                   2129 
                                   2130 	.area CSEG (CODE)
                                   2131 ; function ak820_outline_0171
      007BF6                       2132 _ak820_outline_0171:
      007BF6 90 08 FC         [24] 2133 	mov	dptr,#_unregister_code_code_10000_731
      007BF9 E0               [24] 2134 	movx	a,@dptr
      007BFA FF               [12] 2135 	mov	r7,a
      007BFB 22               [24] 2136 	ret
