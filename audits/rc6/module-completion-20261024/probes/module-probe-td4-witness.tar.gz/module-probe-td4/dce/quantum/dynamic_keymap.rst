                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_tap_dance_valid
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_write_block_xdata
                                     16 	.globl _ak820_eeprom_read_block_xdata
                                     17 	.globl _ak820_nvm_flush
                                     18 	.globl _ak820_nvm_ok
                                     19 	.globl _ak820_macro_reset
                                     20 	.globl _ak820_macro_write
                                     21 	.globl _ak820_macro_length
                                     22 	.globl _ak820_macro_ready
                                     23 	.globl _send_char
                                     24 	.globl _keycode_at_encodermap_location_raw
                                     25 	.globl _keycode_at_keymap_location_raw
                                     26 	.globl _vial_keycode_tap
                                     27 	.globl _vial_keycode_up
                                     28 	.globl _vial_keycode_down
                                     29 	.globl _clear_keyboard
                                     30 	.globl _tap_code
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _mDelaymS
                                     34 	.globl ___memcpy
                                     35 	.globl _memset
                                     36 	.globl _eeprom_update_byte
                                     37 	.globl _eeprom_read_byte
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    284 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    285 	.globl _keycode_at_encodermap_location_PARM_3
                                    286 	.globl _keycode_at_encodermap_location_PARM_2
                                    287 	.globl _keycode_at_keymap_location_PARM_3
                                    288 	.globl _keycode_at_keymap_location_PARM_2
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    292 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    293 	.globl _dynamic_keymap_set_combo_PARM_2
                                    294 	.globl _dynamic_keymap_get_combo_PARM_2
                                    295 	.globl _dynamic_keymap_set_tap_dance_PARM_2
                                    296 	.globl _dynamic_keymap_get_tap_dance_PARM_2
                                    297 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    298 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    299 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    300 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    301 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    302 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    303 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    304 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    305 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    306 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    307 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    309 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    310 	.globl _dynamic_keymap_get_layer_count
                                    311 	.globl _dynamic_keymap_key_to_eeprom_address
                                    312 	.globl _dynamic_keymap_get_keycode
                                    313 	.globl _dynamic_keymap_set_keycode
                                    314 	.globl _dynamic_keymap_get_encoder
                                    315 	.globl _dynamic_keymap_set_encoder
                                    316 	.globl _dynamic_keymap_get_tap_dance
                                    317 	.globl _dynamic_keymap_set_tap_dance
                                    318 	.globl _dynamic_keymap_get_combo
                                    319 	.globl _dynamic_keymap_set_combo
                                    320 	.globl _dynamic_keymap_reset
                                    321 	.globl _dynamic_keymap_get_buffer
                                    322 	.globl _dynamic_keymap_set_buffer
                                    323 	.globl _keycode_at_keymap_location
                                    324 	.globl _keycode_at_encodermap_location
                                    325 	.globl _dynamic_keymap_macro_get_count
                                    326 	.globl _dynamic_keymap_macro_get_buffer_size
                                    327 	.globl _dynamic_keymap_macro_get_buffer
                                    328 	.globl _dynamic_keymap_macro_set_buffer
                                    329 	.globl _dynamic_keymap_macro_reset
                                    330 	.globl _dynamic_keymap_macro_send
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000029                        593 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        594 	.ds 2
      00002B                        595 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        596 	.ds 1
      00002C                        597 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        598 	.ds 1
      00002D                        599 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        600 	.ds 2
      00002F                        601 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        602 	.ds 2
      000031                        603 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        604 	.ds 1
      000032                        605 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        606 	.ds 2
                                    607 ;--------------------------------------------------------
                                    608 ; overlayable items in internal ram
                                    609 ;--------------------------------------------------------
                                    610 ;--------------------------------------------------------
                                    611 ; indirectly addressable internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area ISEG    (DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; absolute internal ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area IABS    (ABS,DATA)
                                    618 	.area IABS    (ABS,DATA)
                                    619 ;--------------------------------------------------------
                                    620 ; bit data
                                    621 ;--------------------------------------------------------
                                    622 	.area BSEG    (BIT)
      000027                        623 _dynamic_keymap_macro_send_sloc0_1_0:
      000027                        624 	.ds 1
                                    625 ;--------------------------------------------------------
                                    626 ; paged external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area PSEG    (PAG,XDATA)
                                    629 ;--------------------------------------------------------
                                    630 ; uninitialized external ram data
                                    631 ;--------------------------------------------------------
                                    632 	.area XSEG    (XDATA)
      000B9B                        633 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B9B                        634 	.ds 1
      000B9C                        635 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B9C                        636 	.ds 1
      000B9D                        637 _dynamic_keymap_key_to_eeprom_address_layer_10000_371:
      000B9D                        638 	.ds 1
      000B9E                        639 _dynamic_keymap_get_keycode_PARM_2:
      000B9E                        640 	.ds 1
      000B9F                        641 _dynamic_keymap_get_keycode_PARM_3:
      000B9F                        642 	.ds 1
      000BA0                        643 _dynamic_keymap_get_keycode_layer_10000_373:
      000BA0                        644 	.ds 1
      000BA1                        645 _dynamic_keymap_set_keycode_PARM_2:
      000BA1                        646 	.ds 1
      000BA2                        647 _dynamic_keymap_set_keycode_PARM_3:
      000BA2                        648 	.ds 1
      000BA3                        649 _dynamic_keymap_set_keycode_PARM_4:
      000BA3                        650 	.ds 2
      000BA5                        651 _dynamic_keymap_set_keycode_layer_10000_377:
      000BA5                        652 	.ds 1
      000BA6                        653 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000BA6                        654 	.ds 1
      000BA7                        655 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_381:
      000BA7                        656 	.ds 1
      000BA8                        657 _dynamic_keymap_get_encoder_PARM_2:
      000BA8                        658 	.ds 1
      000BA9                        659 _dynamic_keymap_get_encoder_PARM_3:
      000BA9                        660 	.ds 1
      000BAA                        661 _dynamic_keymap_get_encoder_layer_10000_383:
      000BAA                        662 	.ds 1
      000BAB                        663 _dynamic_keymap_set_encoder_PARM_2:
      000BAB                        664 	.ds 1
      000BAC                        665 _dynamic_keymap_set_encoder_PARM_3:
      000BAC                        666 	.ds 1
      000BAD                        667 _dynamic_keymap_set_encoder_PARM_4:
      000BAD                        668 	.ds 2
      000BAF                        669 _dynamic_keymap_set_encoder_layer_10000_387:
      000BAF                        670 	.ds 1
      000BB0                        671 _dynamic_keymap_get_tap_dance_PARM_2:
      000BB0                        672 	.ds 3
      000BB3                        673 _dynamic_keymap_get_tap_dance_index_10000_391:
      000BB3                        674 	.ds 1
      000BB4                        675 _dynamic_keymap_set_tap_dance_PARM_2:
      000BB4                        676 	.ds 3
      000BB7                        677 _dynamic_keymap_set_tap_dance_index_10000_395:
      000BB7                        678 	.ds 1
      000BB8                        679 _dynamic_keymap_get_combo_PARM_2:
      000BB8                        680 	.ds 3
      000BBB                        681 _dynamic_keymap_get_combo_index_10000_398:
      000BBB                        682 	.ds 1
      000BBC                        683 _dynamic_keymap_set_combo_PARM_2:
      000BBC                        684 	.ds 3
      000BBF                        685 _dynamic_keymap_set_combo_index_10000_404:
      000BBF                        686 	.ds 1
      000BC0                        687 _dynamic_keymap_set_combo_stored_10002_409:
      000BC0                        688 	.ds 10
      000BCA                        689 _dynamic_keymap_reset_vial_unlocked_prev_10000_412:
      000BCA                        690 	.ds 1
      000BCB                        691 _dynamic_keymap_reset_td_10001_421:
      000BCB                        692 	.ds 10
      000BD5                        693 _dynamic_keymap_reset_combo_10002_424:
      000BD5                        694 	.ds 10
      000BDF                        695 _ak820_dynamic_read_buffer_PARM_2:
      000BDF                        696 	.ds 2
      000BE1                        697 _ak820_dynamic_read_buffer_PARM_3:
      000BE1                        698 	.ds 2
      000BE3                        699 _ak820_dynamic_read_buffer_PARM_4:
      000BE3                        700 	.ds 2
      000BE5                        701 _ak820_dynamic_read_buffer_PARM_5:
      000BE5                        702 	.ds 3
      000BE8                        703 _ak820_dynamic_read_buffer_base_10000_426:
      000BE8                        704 	.ds 2
      000BEA                        705 _ak820_dynamic_read_buffer_available_10000_427:
      000BEA                        706 	.ds 1
      000BEB                        707 _dynamic_keymap_get_buffer_PARM_2:
      000BEB                        708 	.ds 2
      000BED                        709 _dynamic_keymap_get_buffer_PARM_3:
      000BED                        710 	.ds 3
      000BF0                        711 _dynamic_keymap_get_buffer_offset_10000_433:
      000BF0                        712 	.ds 2
      000BF2                        713 _dynamic_keymap_set_buffer_PARM_2:
      000BF2                        714 	.ds 2
      000BF4                        715 _dynamic_keymap_set_buffer_PARM_3:
      000BF4                        716 	.ds 3
      000BF7                        717 _dynamic_keymap_set_buffer_offset_10000_435:
      000BF7                        718 	.ds 2
      000BF9                        719 _dynamic_keymap_set_buffer_chk_offset_30001_442:
      000BF9                        720 	.ds 1
      000BFA                        721 _dynamic_keymap_set_buffer_chk_sz_30001_442:
      000BFA                        722 	.ds 1
      000BFB                        723 _dynamic_keymap_set_buffer_i_40001_449:
      000BFB                        724 	.ds 1
      000BFC                        725 _keycode_at_keymap_location_PARM_2:
      000BFC                        726 	.ds 1
      000BFD                        727 _keycode_at_keymap_location_PARM_3:
      000BFD                        728 	.ds 1
      000BFE                        729 _keycode_at_keymap_location_layer_num_10000_453:
      000BFE                        730 	.ds 1
      000BFF                        731 _keycode_at_encodermap_location_PARM_2:
      000BFF                        732 	.ds 1
      000C00                        733 _keycode_at_encodermap_location_PARM_3:
      000C00                        734 	.ds 1
      000C01                        735 _keycode_at_encodermap_location_layer_num_10000_457:
      000C01                        736 	.ds 1
      000C02                        737 _dynamic_keymap_macro_get_buffer_PARM_2:
      000C02                        738 	.ds 2
      000C04                        739 _dynamic_keymap_macro_get_buffer_PARM_3:
      000C04                        740 	.ds 3
      000C07                        741 _dynamic_keymap_macro_get_buffer_offset_10000_465:
      000C07                        742 	.ds 2
      000C09                        743 _dynamic_keymap_macro_set_buffer_PARM_2:
      000C09                        744 	.ds 2
      000C0B                        745 _dynamic_keymap_macro_set_buffer_PARM_3:
      000C0B                        746 	.ds 3
      000C0E                        747 _dynamic_keymap_macro_set_buffer_offset_10000_467:
      000C0E                        748 	.ds 2
      000C10                        749 _decode_keycode_kc_10000_471:
      000C10                        750 	.ds 2
      000C12                        751 _dynamic_keymap_macro_send_id_10000_474:
      000C12                        752 	.ds 1
      000C13                        753 _dynamic_keymap_macro_send_sending_10000_475:
      000C13                        754 	.ds 1
      000C14                        755 _dynamic_keymap_macro_send_p_10001_480:
      000C14                        756 	.ds 2
      000C16                        757 _dynamic_keymap_macro_send_data_10003_487:
      000C16                        758 	.ds 4
                                    759 ;--------------------------------------------------------
                                    760 ; absolute external ram data
                                    761 ;--------------------------------------------------------
                                    762 	.area XABS    (ABS,XDATA)
                                    763 ;--------------------------------------------------------
                                    764 ; initialized external ram data
                                    765 ;--------------------------------------------------------
                                    766 	.area XISEG   (XDATA)
                                    767 	.area HOME    (CODE)
                                    768 	.area GSINIT0 (CODE)
                                    769 	.area GSINIT1 (CODE)
                                    770 	.area GSINIT2 (CODE)
                                    771 	.area GSINIT3 (CODE)
                                    772 	.area GSINIT4 (CODE)
                                    773 	.area GSINIT5 (CODE)
                                    774 	.area GSINIT  (CODE)
                                    775 	.area GSFINAL (CODE)
                                    776 	.area CSEG    (CODE)
                                    777 ;--------------------------------------------------------
                                    778 ; global & static initialisations
                                    779 ;--------------------------------------------------------
                                    780 	.area HOME    (CODE)
                                    781 	.area GSINIT  (CODE)
                                    782 	.area GSFINAL (CODE)
                                    783 	.area GSINIT  (CODE)
                                    784 ;--------------------------------------------------------
                                    785 ; Home
                                    786 ;--------------------------------------------------------
                                    787 	.area HOME    (CODE)
                                    788 	.area HOME    (CODE)
                                    789 ;--------------------------------------------------------
                                    790 ; code
                                    791 ;--------------------------------------------------------
                                    792 	.area CSEG    (CODE)
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    795 ;------------------------------------------------------------
                                    796 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_232'
                                    797 ;------------------------------------------------------------
                                    798 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    799 ;	-----------------------------------------
                           000007   800 	ar7 = 0x07
                           000006   801 	ar6 = 0x06
                           000005   802 	ar5 = 0x05
                           000004   803 	ar4 = 0x04
                           000003   804 	ar3 = 0x03
                           000002   805 	ar2 = 0x02
                           000001   806 	ar1 = 0x01
                           000000   807 	ar0 = 0x00
                                    808 ;	 function dynamic_keymap_get_layer_count
                                    809 ;	-----------------------------------------
      00880E                        810 _dynamic_keymap_get_layer_count:
                                    811 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00880E 75 82 06         [24]  812 	mov	dpl, #0x06
                                    813 ;	quantum/dynamic_keymap.c:201: }
      008811 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    817 ;------------------------------------------------------------
                                    818 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    819 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    820 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_371'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function dynamic_keymap_key_to_eeprom_address
                                    825 ;	-----------------------------------------
      008812                        826 _dynamic_keymap_key_to_eeprom_address:
      008812 E5 82            [12]  827 	mov	a,dpl
      008814 90 0B 9D         [24]  828 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_371
      008817 F0               [24]  829 	movx	@dptr,a
                                    830 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008818 E0               [24]  831 	movx	a,@dptr
      008819 FF               [12]  832 	mov	r7,a
      00881A 7E 00            [12]  833 	mov	r6,#0x00
      00881C 74 40            [12]  834 	mov	a,#0x40
      00881E 2E               [12]  835 	add	a, r6
      00881F FE               [12]  836 	mov	r6,a
      008820 E4               [12]  837 	clr	a
      008821 3F               [12]  838 	addc	a, r7
      008822 FF               [12]  839 	mov	r7,a
      008823 7D 00            [12]  840 	mov	r5,#0x00
      008825 90 0B 9B         [24]  841 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008828 E0               [24]  842 	movx	a,@dptr
      008829 75 F0 10         [24]  843 	mov	b,#0x10
      00882C A4               [48]  844 	mul	ab
      00882D 2E               [12]  845 	add	a, r6
      00882E FE               [12]  846 	mov	r6,a
      00882F EF               [12]  847 	mov	a,r7
      008830 35 F0            [12]  848 	addc	a, b
      008832 FF               [12]  849 	mov	r7,a
      008833 90 0B 9C         [24]  850 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008836 E0               [24]  851 	movx	a,@dptr
      008837 7C 00            [12]  852 	mov	r4,#0x00
      008839 25 E0            [12]  853 	add	a,acc
      00883B FB               [12]  854 	mov	r3,a
      00883C EC               [12]  855 	mov	a,r4
      00883D 33               [12]  856 	rlc	a
      00883E FC               [12]  857 	mov	r4,a
      00883F EB               [12]  858 	mov	a,r3
      008840 2E               [12]  859 	add	a, r6
      008841 FE               [12]  860 	mov	r6,a
      008842 EC               [12]  861 	mov	a,r4
      008843 3F               [12]  862 	addc	a, r7
      008844 FF               [12]  863 	mov	r7,a
      008845 12 38 8D         [24]  864 	lcall	_ak820_outline_0121
      008848 8D F0            [24]  865 	mov	b, r5
                                    866 ;	quantum/dynamic_keymap.c:206: }
      00884A 22               [24]  867 	ret
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    870 ;------------------------------------------------------------
                                    871 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    872 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    873 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_373'
                                    874 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_376'
                                    875 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_376'
                                    876 ;------------------------------------------------------------
                                    877 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function dynamic_keymap_get_keycode
                                    880 ;	-----------------------------------------
      00884B                        881 _dynamic_keymap_get_keycode:
      00884B E5 82            [12]  882 	mov	a,dpl
      00884D 90 0B A0         [24]  883 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_373
      008850 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008851 E0               [24]  886 	movx	a,@dptr
      008852 FF               [12]  887 	mov	r7,a
      008853 BF 06 00         [24]  888 	cjne	r7,#0x06,00121$
      008856                        889 00121$:
      008856 50 14            [24]  890 	jnc	00101$
      008858 90 0B 9E         [24]  891 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00885B E0               [24]  892 	movx	a,@dptr
      00885C FE               [12]  893 	mov	r6,a
      00885D BE 10 00         [24]  894 	cjne	r6,#0x10,00123$
      008860                        895 00123$:
      008860 50 0A            [24]  896 	jnc	00101$
      008862 90 0B 9F         [24]  897 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008865 E0               [24]  898 	movx	a,@dptr
      008866 FD               [12]  899 	mov	r5,a
      008867 BD 08 00         [24]  900 	cjne	r5,#0x08,00125$
      00886A                        901 00125$:
      00886A 40 04            [24]  902 	jc	00102$
      00886C                        903 00101$:
      00886C 90 00 00         [24]  904 	mov	dptr,#0x0000
      00886F 22               [24]  905 	ret
      008870                        906 00102$:
                                    907 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008870 12 94 09         [24]  908 	lcall	_ak820_outline_0102
      008873 11 12            [12]  909 	acall	_dynamic_keymap_key_to_eeprom_address
                                    910 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008875 12 94 1D         [24]  911 	lcall	_ak820_outline_0119
      008878 12 40 72         [24]  912 	lcall	_eeprom_read_byte
      00887B AB 82            [24]  913 	mov	r3,dpl
      00887D 7C 00            [12]  914 	mov	r4,#0x00
                                    915 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      00887F 0D               [12]  916 	inc	r5
      008880 BD 00 01         [24]  917 	cjne	r5,#0x00,00127$
      008883 0E               [12]  918 	inc	r6
      008884                        919 00127$:
      008884 12 54 54         [24]  920 	lcall	_ak820_outline_0052
      008887 12 40 72         [24]  921 	lcall	_eeprom_read_byte
      00888A AF 82            [24]  922 	mov	r7, dpl
      00888C 7E 00            [12]  923 	mov	r6,#0x00
      00888E EF               [12]  924 	mov	a,r7
      00888F 42 04            [12]  925 	orl	ar4,a
      008891 EE               [12]  926 	mov	a,r6
      008892 42 03            [12]  927 	orl	ar3,a
                                    928 ;	quantum/dynamic_keymap.c:214: return keycode;
      008894 12 43 8D         [24]  929 	lcall	_ak820_outline_0187
                                    930 ;	quantum/dynamic_keymap.c:215: }
      008897 22               [24]  931 	ret
                                    932 ;------------------------------------------------------------
                                    933 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    934 ;------------------------------------------------------------
                                    935 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    936 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    937 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    938 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_377'
                                    939 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_380'
                                    940 ;------------------------------------------------------------
                                    941 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    942 ;	-----------------------------------------
                                    943 ;	 function dynamic_keymap_set_keycode
                                    944 ;	-----------------------------------------
      008898                        945 _dynamic_keymap_set_keycode:
      008898 E5 82            [12]  946 	mov	a,dpl
      00889A 90 0B A5         [24]  947 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_377
      00889D F0               [24]  948 	movx	@dptr,a
                                    949 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00889E E0               [24]  950 	movx	a,@dptr
      00889F FF               [12]  951 	mov	r7,a
      0088A0 BF 06 00         [24]  952 	cjne	r7,#0x06,00121$
      0088A3                        953 00121$:
      0088A3 50 14            [24]  954 	jnc	00101$
      0088A5 90 0B A1         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0088A8 E0               [24]  956 	movx	a,@dptr
      0088A9 FE               [12]  957 	mov	r6,a
      0088AA BE 10 00         [24]  958 	cjne	r6,#0x10,00123$
      0088AD                        959 00123$:
      0088AD 50 0A            [24]  960 	jnc	00101$
      0088AF 90 0B A2         [24]  961 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0088B2 E0               [24]  962 	movx	a,@dptr
      0088B3 FD               [12]  963 	mov	r5,a
      0088B4 BD 08 00         [24]  964 	cjne	r5,#0x08,00125$
      0088B7                        965 00125$:
      0088B7 40 01            [24]  966 	jc	00102$
      0088B9                        967 00101$:
      0088B9 22               [24]  968 	ret
      0088BA                        969 00102$:
                                    970 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0088BA 12 94 09         [24]  971 	lcall	_ak820_outline_0102
      0088BD 11 12            [12]  972 	acall	_dynamic_keymap_key_to_eeprom_address
      0088BF 12 94 1D         [24]  973 	lcall	_ak820_outline_0119
                                    974 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0088C2 90 0B A3         [24]  975 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0088C5 E0               [24]  976 	movx	a,@dptr
      0088C6 FB               [12]  977 	mov	r3,a
      0088C7 A3               [24]  978 	inc	dptr
      0088C8 E0               [24]  979 	movx	a,@dptr
      0088C9 90 07 64         [24]  980 	mov	dptr,#_eeprom_update_byte_PARM_2
      0088CC F0               [24]  981 	movx	@dptr,a
      0088CD 12 54 54         [24]  982 	lcall	_ak820_outline_0052
      0088D0 12 53 3A         [24]  983 	lcall	_eeprom_update_byte
                                    984 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0088D3 0D               [12]  985 	inc	r5
      0088D4 BD 00 01         [24]  986 	cjne	r5,#0x00,00127$
      0088D7 0E               [12]  987 	inc	r6
      0088D8                        988 00127$:
      0088D8 90 07 64         [24]  989 	mov	dptr,#_eeprom_update_byte_PARM_2
      0088DB EB               [12]  990 	mov	a,r3
      0088DC F0               [24]  991 	movx	@dptr,a
      0088DD 12 54 54         [24]  992 	lcall	_ak820_outline_0052
                                    993 ;	quantum/dynamic_keymap.c:223: }
      0088E0 02 53 3A         [24]  994 	ljmp	_eeprom_update_byte
                                    995 ;------------------------------------------------------------
                                    996 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    997 ;------------------------------------------------------------
                                    998 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    999 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                   1004 ;	-----------------------------------------
      0088E3                       1005 _dynamic_keymap_encoder_to_eeprom_address:
      0088E3 E5 82            [12] 1006 	mov	a,dpl
      0088E5 90 0B A7         [24] 1007 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381
      0088E8 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0088E9 E0               [24] 1010 	movx	a,@dptr
      0088EA 12 38 C6         [24] 1011 	lcall	_ak820_outline_0192
      0088ED 24 40            [12] 1012 	add	a, #0x40
      0088EF FD               [12] 1013 	mov	r5,a
      0088F0 74 06            [12] 1014 	mov	a,#0x06
      0088F2 35 F0            [12] 1015 	addc	a, b
      0088F4 FE               [12] 1016 	mov	r6,a
      0088F5 7F 00            [12] 1017 	mov	r7,#0x00
      0088F7 90 0B A6         [24] 1018 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0088FA E0               [24] 1019 	movx	a,@dptr
      0088FB 12 38 C6         [24] 1020 	lcall	_ak820_outline_0192
      0088FE 2D               [12] 1021 	add	a, r5
      0088FF FD               [12] 1022 	mov	r5,a
      008900 EE               [12] 1023 	mov	a,r6
      008901 35 F0            [12] 1024 	addc	a, b
      008903 FE               [12] 1025 	mov	r6,a
      008904 12 54 54         [24] 1026 	lcall	_ak820_outline_0052
                                   1027 ;	quantum/dynamic_keymap.c:228: }
      008907 22               [24] 1028 	ret
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1031 ;------------------------------------------------------------
                                   1032 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1033 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1034 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_383'
                                   1035 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_386'
                                   1036 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_386'
                                   1037 ;------------------------------------------------------------
                                   1038 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1039 ;	-----------------------------------------
                                   1040 ;	 function dynamic_keymap_get_encoder
                                   1041 ;	-----------------------------------------
      008908                       1042 _dynamic_keymap_get_encoder:
      008908 E5 82            [12] 1043 	mov	a,dpl
      00890A 90 0B AA         [24] 1044 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_383
      00890D F0               [24] 1045 	movx	@dptr,a
                                   1046 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      00890E E0               [24] 1047 	movx	a,@dptr
      00890F FF               [12] 1048 	mov	r7,a
      008910 BF 06 00         [24] 1049 	cjne	r7,#0x06,00131$
      008913                       1050 00131$:
      008913 50 0A            [24] 1051 	jnc	00101$
      008915 90 0B A8         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008918 E0               [24] 1053 	movx	a,@dptr
      008919 FE               [12] 1054 	mov	r6,a
      00891A BE 01 00         [24] 1055 	cjne	r6,#0x01,00133$
      00891D                       1056 00133$:
      00891D 40 04            [24] 1057 	jc	00102$
      00891F                       1058 00101$:
      00891F 90 00 00         [24] 1059 	mov	dptr,#0x0000
      008922 22               [24] 1060 	ret
      008923                       1061 00102$:
                                   1062 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008923 90 0B A6         [24] 1063 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008926 E4               [12] 1064 	clr	a
      008927 F0               [24] 1065 	movx	@dptr,a
      008928 8F 82            [24] 1066 	mov	dpl, r7
      00892A 11 E3            [12] 1067 	acall	_dynamic_keymap_encoder_to_eeprom_address
      00892C 12 94 1D         [24] 1068 	lcall	_ak820_outline_0119
                                   1069 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      00892F 90 0B A9         [24] 1070 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008932 E0               [24] 1071 	movx	a,@dptr
      008933 FC               [12] 1072 	mov	r4,a
      008934 E0               [24] 1073 	movx	a,@dptr
      008935 60 04            [24] 1074 	jz	00106$
      008937 7B 00            [12] 1075 	mov	r3,#0x00
      008939 80 02            [24] 1076 	sjmp	00107$
      00893B                       1077 00106$:
      00893B 7B 02            [12] 1078 	mov	r3,#0x02
      00893D                       1079 00107$:
      00893D EB               [12] 1080 	mov	a,r3
      00893E 12 93 D2         [24] 1081 	lcall	_ak820_outline_0027
      008941 12 40 72         [24] 1082 	lcall	_eeprom_read_byte
      008944 AA 82            [24] 1083 	mov	r2,dpl
      008946 7B 00            [12] 1084 	mov	r3,#0x00
                                   1085 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008948 EC               [12] 1086 	mov	a,r4
      008949 60 04            [24] 1087 	jz	00108$
      00894B 7C 00            [12] 1088 	mov	r4,#0x00
      00894D 80 02            [24] 1089 	sjmp	00109$
      00894F                       1090 00108$:
      00894F 7C 02            [12] 1091 	mov	r4,#0x02
      008951                       1092 00109$:
      008951 EC               [12] 1093 	mov	a,r4
      008952 12 38 B6         [24] 1094 	lcall	_ak820_outline_0163
      008955 0D               [12] 1095 	inc	r5
      008956 BD 00 01         [24] 1096 	cjne	r5,#0x00,00137$
      008959 0E               [12] 1097 	inc	r6
      00895A                       1098 00137$:
      00895A 12 54 54         [24] 1099 	lcall	_ak820_outline_0052
      00895D 12 40 72         [24] 1100 	lcall	_eeprom_read_byte
      008960 AF 82            [24] 1101 	mov	r7, dpl
      008962 7E 00            [12] 1102 	mov	r6,#0x00
      008964 EF               [12] 1103 	mov	a,r7
      008965 42 03            [12] 1104 	orl	ar3,a
      008967 EE               [12] 1105 	mov	a,r6
      008968 42 02            [12] 1106 	orl	ar2,a
                                   1107 ;	quantum/dynamic_keymap.c:236: return keycode;
      00896A 8B 82            [24] 1108 	mov	dpl, r3
      00896C 8A 83            [24] 1109 	mov	dph, r2
                                   1110 ;	quantum/dynamic_keymap.c:237: }
      00896E 22               [24] 1111 	ret
                                   1112 ;------------------------------------------------------------
                                   1113 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1114 ;------------------------------------------------------------
                                   1115 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1116 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1117 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1118 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1119 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_387'
                                   1120 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_390'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function dynamic_keymap_set_encoder
                                   1125 ;	-----------------------------------------
      00896F                       1126 _dynamic_keymap_set_encoder:
      00896F E5 82            [12] 1127 	mov	a,dpl
      008971 90 0B AF         [24] 1128 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_387
      008974 F0               [24] 1129 	movx	@dptr,a
                                   1130 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008975 E0               [24] 1131 	movx	a,@dptr
      008976 FF               [12] 1132 	mov	r7,a
      008977 BF 06 00         [24] 1133 	cjne	r7,#0x06,00131$
      00897A                       1134 00131$:
      00897A 50 0A            [24] 1135 	jnc	00101$
      00897C 90 0B AB         [24] 1136 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00897F E0               [24] 1137 	movx	a,@dptr
      008980 FE               [12] 1138 	mov	r6,a
      008981 BE 01 00         [24] 1139 	cjne	r6,#0x01,00133$
      008984                       1140 00133$:
      008984 40 01            [24] 1141 	jc	00102$
      008986                       1142 00101$:
      008986 22               [24] 1143 	ret
      008987                       1144 00102$:
                                   1145 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008987 90 0B A6         [24] 1146 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00898A E4               [12] 1147 	clr	a
      00898B F0               [24] 1148 	movx	@dptr,a
      00898C 8F 82            [24] 1149 	mov	dpl, r7
      00898E 11 E3            [12] 1150 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008990 12 94 1D         [24] 1151 	lcall	_ak820_outline_0119
                                   1152 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008993 90 0B AC         [24] 1153 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008996 E0               [24] 1154 	movx	a,@dptr
      008997 FC               [12] 1155 	mov	r4,a
      008998 E0               [24] 1156 	movx	a,@dptr
      008999 60 04            [24] 1157 	jz	00106$
      00899B 7B 00            [12] 1158 	mov	r3,#0x00
      00899D 80 02            [24] 1159 	sjmp	00107$
      00899F                       1160 00106$:
      00899F 7B 02            [12] 1161 	mov	r3,#0x02
      0089A1                       1162 00107$:
      0089A1 EB               [12] 1163 	mov	a,r3
      0089A2 12 94 2F         [24] 1164 	lcall	_ak820_outline_0141
      0089A5 8F 03            [24] 1165 	mov	ar3,r7
      0089A7 90 0B AD         [24] 1166 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0089AA E0               [24] 1167 	movx	a,@dptr
      0089AB F5 29            [12] 1168 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0089AD A3               [24] 1169 	inc	dptr
      0089AE E0               [24] 1170 	movx	a,@dptr
      0089AF F5 2A            [12] 1171 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0089B1 90 07 64         [24] 1172 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089B4 F0               [24] 1173 	movx	@dptr,a
      0089B5 12 43 88         [24] 1174 	lcall	_ak820_outline_0174
      0089B8 8B F0            [24] 1175 	mov	b, r3
      0089BA 12 53 3A         [24] 1176 	lcall	_eeprom_update_byte
                                   1177 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0089BD EC               [12] 1178 	mov	a,r4
      0089BE 60 04            [24] 1179 	jz	00108$
      0089C0 7C 00            [12] 1180 	mov	r4,#0x00
      0089C2 80 02            [24] 1181 	sjmp	00109$
      0089C4                       1182 00108$:
      0089C4 7C 02            [12] 1183 	mov	r4,#0x02
      0089C6                       1184 00109$:
      0089C6 EC               [12] 1185 	mov	a,r4
      0089C7 12 38 B6         [24] 1186 	lcall	_ak820_outline_0163
      0089CA 0D               [12] 1187 	inc	r5
      0089CB BD 00 01         [24] 1188 	cjne	r5,#0x00,00137$
      0089CE 0E               [12] 1189 	inc	r6
      0089CF                       1190 00137$:
      0089CF 90 07 64         [24] 1191 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089D2 E5 29            [12] 1192 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0089D4 F0               [24] 1193 	movx	@dptr,a
      0089D5 12 54 54         [24] 1194 	lcall	_ak820_outline_0052
                                   1195 ;	quantum/dynamic_keymap.c:245: }
      0089D8 02 53 3A         [24] 1196 	ljmp	_eeprom_update_byte
                                   1197 ;------------------------------------------------------------
                                   1198 ;Allocation info for local variables in function 'dynamic_keymap_get_tap_dance'
                                   1199 ;------------------------------------------------------------
                                   1200 ;buffer        Allocated with name '_dynamic_keymap_get_tap_dance_PARM_2'
                                   1201 ;index         Allocated with name '_dynamic_keymap_get_tap_dance_index_10000_391'
                                   1202 ;entry         Allocated with name '_dynamic_keymap_get_tap_dance_entry_10000_392'
                                   1203 ;------------------------------------------------------------
                                   1204 ;	quantum/dynamic_keymap.c:268: int dynamic_keymap_get_tap_dance(uint8_t index, vial_tap_dance_entry_t *buffer) {
                                   1205 ;	-----------------------------------------
                                   1206 ;	 function dynamic_keymap_get_tap_dance
                                   1207 ;	-----------------------------------------
      0089DB                       1208 _dynamic_keymap_get_tap_dance:
      0089DB E5 82            [12] 1209 	mov	a,dpl
      0089DD 90 0B B3         [24] 1210 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      0089E0 F0               [24] 1211 	movx	@dptr,a
                                   1212 ;	quantum/dynamic_keymap.c:269: vial_tap_dance_entry_t AK820_STATE_MEM *entry = (vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      0089E1 90 0B B0         [24] 1213 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      0089E4 12 38 2E         [24] 1214 	lcall	_ak820_outline_0059
                                   1215 ;	quantum/dynamic_keymap.c:270: if (index >= AK820_EXTENSION_ENTRIES) return -1;
      0089E7 90 0B B3         [24] 1216 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      0089EA E0               [24] 1217 	movx	a,@dptr
      0089EB FD               [12] 1218 	mov	r5,a
      0089EC BD 08 00         [24] 1219 	cjne	r5,#0x08,00130$
      0089EF                       1220 00130$:
      0089EF 40 04            [24] 1221 	jc	00102$
      0089F1 90 FF FF         [24] 1222 	mov	dptr,#0xffff
      0089F4 22               [24] 1223 	ret
      0089F5                       1224 00102$:
                                   1225 ;	quantum/dynamic_keymap.c:271: ak820_eeprom_read_block_xdata(entry, (const void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      0089F5 8E 03            [24] 1226 	mov	ar3,r6
      0089F7 8F 04            [24] 1227 	mov	ar4,r7
      0089F9 BD 06 00         [24] 1228 	cjne	r5,#0x06,00132$
      0089FC                       1229 00132$:
      0089FC 50 0C            [24] 1230 	jnc	00107$
      0089FE 8D 02            [24] 1231 	mov	ar2,r5
      008A00 EA               [12] 1232 	mov	a,r2
      008A01 75 F0 0A         [24] 1233 	mov	b,#0x0a
      008A04 A4               [48] 1234 	mul	ab
      008A05 F9               [12] 1235 	mov	r1,a
      008A06 7A 00            [12] 1236 	mov	r2,#0x00
      008A08 80 11            [24] 1237 	sjmp	00108$
      008A0A                       1238 00107$:
      008A0A ED               [12] 1239 	mov	a,r5
      008A0B 24 FA            [12] 1240 	add	a,#0xfa
      008A0D 75 F0 0A         [24] 1241 	mov	b,#0x0a
      008A10 A4               [48] 1242 	mul	ab
      008A11 F8               [12] 1243 	mov	r0,a
      008A12 7D 00            [12] 1244 	mov	r5,#0x00
      008A14 74 40            [12] 1245 	mov	a,#0x40
      008A16 28               [12] 1246 	add	a, r0
      008A17 F9               [12] 1247 	mov	r1,a
      008A18 E4               [12] 1248 	clr	a
      008A19 3D               [12] 1249 	addc	a, r5
      008A1A FA               [12] 1250 	mov	r2,a
      008A1B                       1251 00108$:
      008A1B 74 C0            [12] 1252 	mov	a,#0xc0
      008A1D 29               [12] 1253 	add	a, r1
      008A1E F9               [12] 1254 	mov	r1,a
      008A1F 74 06            [12] 1255 	mov	a,#0x06
      008A21 3A               [12] 1256 	addc	a, r2
      008A22 FA               [12] 1257 	mov	r2,a
      008A23 90 05 85         [24] 1258 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008A26 E9               [12] 1259 	mov	a,r1
      008A27 F0               [24] 1260 	movx	@dptr,a
      008A28 EA               [12] 1261 	mov	a,r2
      008A29 12 38 4B         [24] 1262 	lcall	_ak820_outline_0077
      008A2C 90 05 88         [24] 1263 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008A2F 12 94 16         [24] 1264 	lcall	_ak820_outline_0113
      008A32 12 33 FC         [24] 1265 	lcall	_ak820_outline_0125
      008A35 C0 07            [24] 1266 	push	ar7
      008A37 C0 06            [24] 1267 	push	ar6
      008A39 12 40 AD         [24] 1268 	lcall	_ak820_eeprom_read_block_xdata
      008A3C D0 06            [24] 1269 	pop	ar6
      008A3E D0 07            [24] 1270 	pop	ar7
                                   1271 ;	quantum/dynamic_keymap.c:272: if (!ak820_tap_dance_valid(entry)) memset(entry, 0, sizeof(*entry));
      008A40 12 38 8D         [24] 1272 	lcall	_ak820_outline_0121
      008A43 C0 07            [24] 1273 	push	ar7
      008A45 C0 06            [24] 1274 	push	ar6
      008A47 12 43 92         [24] 1275 	lcall	_ak820_tap_dance_valid
      008A4A E5 82            [12] 1276 	mov	a, dpl
      008A4C D0 06            [24] 1277 	pop	ar6
      008A4E D0 07            [24] 1278 	pop	ar7
      008A50 70 07            [24] 1279 	jnz	00104$
      008A52 FD               [12] 1280 	mov	r5,a
      008A53 12 93 E0         [24] 1281 	lcall	_ak820_outline_0043
      008A56 12 BE 82         [24] 1282 	lcall	_memset
      008A59                       1283 00104$:
                                   1284 ;	quantum/dynamic_keymap.c:273: return 0;
      008A59 90 00 00         [24] 1285 	mov	dptr,#0x0000
                                   1286 ;	quantum/dynamic_keymap.c:274: }
      008A5C 22               [24] 1287 	ret
                                   1288 ;------------------------------------------------------------
                                   1289 ;Allocation info for local variables in function 'dynamic_keymap_set_tap_dance'
                                   1290 ;------------------------------------------------------------
                                   1291 ;buffer        Allocated with name '_dynamic_keymap_set_tap_dance_PARM_2'
                                   1292 ;index         Allocated with name '_dynamic_keymap_set_tap_dance_index_10000_395'
                                   1293 ;entry         Allocated with name '_dynamic_keymap_set_tap_dance_entry_10000_396'
                                   1294 ;------------------------------------------------------------
                                   1295 ;	quantum/dynamic_keymap.c:275: int dynamic_keymap_set_tap_dance(uint8_t index, const vial_tap_dance_entry_t *buffer) {
                                   1296 ;	-----------------------------------------
                                   1297 ;	 function dynamic_keymap_set_tap_dance
                                   1298 ;	-----------------------------------------
      008A5D                       1299 _dynamic_keymap_set_tap_dance:
      008A5D E5 82            [12] 1300 	mov	a,dpl
      008A5F 90 0B B7         [24] 1301 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      008A62 F0               [24] 1302 	movx	@dptr,a
                                   1303 ;	quantum/dynamic_keymap.c:276: const vial_tap_dance_entry_t AK820_STATE_MEM *entry = (const vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      008A63 90 0B B4         [24] 1304 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      008A66 12 38 2E         [24] 1305 	lcall	_ak820_outline_0059
                                   1306 ;	quantum/dynamic_keymap.c:277: if (index >= AK820_EXTENSION_ENTRIES || !ak820_tap_dance_valid(entry) || !ak820_nvm_ok()) return -1;
      008A69 90 0B B7         [24] 1307 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      008A6C E0               [24] 1308 	movx	a,@dptr
      008A6D FD               [12] 1309 	mov	r5,a
      008A6E BD 08 00         [24] 1310 	cjne	r5,#0x08,00139$
      008A71                       1311 00139$:
      008A71 50 1D            [24] 1312 	jnc	00101$
      008A73 12 38 8D         [24] 1313 	lcall	_ak820_outline_0121
      008A76 C0 07            [24] 1314 	push	ar7
      008A78 C0 06            [24] 1315 	push	ar6
      008A7A C0 05            [24] 1316 	push	ar5
      008A7C 12 43 92         [24] 1317 	lcall	_ak820_tap_dance_valid
      008A7F E5 82            [12] 1318 	mov	a, dpl
      008A81 D0 05            [24] 1319 	pop	ar5
      008A83 D0 06            [24] 1320 	pop	ar6
      008A85 D0 07            [24] 1321 	pop	ar7
      008A87 60 07            [24] 1322 	jz	00101$
      008A89 12 3E 18         [24] 1323 	lcall	_ak820_nvm_ok
      008A8C E5 82            [12] 1324 	mov	a, dpl
      008A8E 70 04            [24] 1325 	jnz	00102$
      008A90                       1326 00101$:
      008A90 90 FF FF         [24] 1327 	mov	dptr,#0xffff
      008A93 22               [24] 1328 	ret
      008A94                       1329 00102$:
                                   1330 ;	quantum/dynamic_keymap.c:278: clear_keyboard();
      008A94 C0 07            [24] 1331 	push	ar7
      008A96 C0 06            [24] 1332 	push	ar6
      008A98 C0 05            [24] 1333 	push	ar5
      008A9A 12 7B 58         [24] 1334 	lcall	_clear_keyboard
      008A9D D0 05            [24] 1335 	pop	ar5
      008A9F D0 06            [24] 1336 	pop	ar6
      008AA1 D0 07            [24] 1337 	pop	ar7
                                   1338 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_update_block_xdata(entry, (void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008AA3 BD 06 00         [24] 1339 	cjne	r5,#0x06,00143$
      008AA6                       1340 00143$:
      008AA6 50 0C            [24] 1341 	jnc	00107$
      008AA8 8D 04            [24] 1342 	mov	ar4,r5
      008AAA EC               [12] 1343 	mov	a,r4
      008AAB 75 F0 0A         [24] 1344 	mov	b,#0x0a
      008AAE A4               [48] 1345 	mul	ab
      008AAF FB               [12] 1346 	mov	r3,a
      008AB0 7C 00            [12] 1347 	mov	r4,#0x00
      008AB2 80 11            [24] 1348 	sjmp	00108$
      008AB4                       1349 00107$:
      008AB4 ED               [12] 1350 	mov	a,r5
      008AB5 24 FA            [12] 1351 	add	a,#0xfa
      008AB7 75 F0 0A         [24] 1352 	mov	b,#0x0a
      008ABA A4               [48] 1353 	mul	ab
      008ABB FD               [12] 1354 	mov	r5,a
      008ABC 7A 00            [12] 1355 	mov	r2,#0x00
      008ABE 74 40            [12] 1356 	mov	a,#0x40
      008AC0 2D               [12] 1357 	add	a, r5
      008AC1 FB               [12] 1358 	mov	r3,a
      008AC2 E4               [12] 1359 	clr	a
      008AC3 3A               [12] 1360 	addc	a, r2
      008AC4 FC               [12] 1361 	mov	r4,a
      008AC5                       1362 00108$:
      008AC5 74 C0            [12] 1363 	mov	a,#0xc0
      008AC7 2B               [12] 1364 	add	a, r3
      008AC8 FB               [12] 1365 	mov	r3,a
      008AC9 74 06            [12] 1366 	mov	a,#0x06
      008ACB 3C               [12] 1367 	addc	a, r4
      008ACC FC               [12] 1368 	mov	r4,a
      008ACD 90 05 95         [24] 1369 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      008AD0 EB               [12] 1370 	mov	a,r3
      008AD1 F0               [24] 1371 	movx	@dptr,a
      008AD2 EC               [12] 1372 	mov	a,r4
      008AD3 12 38 4B         [24] 1373 	lcall	_ak820_outline_0077
      008AD6 90 05 98         [24] 1374 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      008AD9 74 0A            [12] 1375 	mov	a,#0x0a
      008ADB F0               [24] 1376 	movx	@dptr,a
      008ADC E4               [12] 1377 	clr	a
      008ADD 12 43 35         [24] 1378 	lcall	_ak820_outline_0064
      008AE0 12 42 1C         [24] 1379 	lcall	_ak820_eeprom_update_block_xdata
                                   1380 ;	quantum/dynamic_keymap.c:280: ak820_nvm_flush();
      008AE3 12 3E 27         [24] 1381 	lcall	_ak820_nvm_flush
                                   1382 ;	quantum/dynamic_keymap.c:281: return ak820_nvm_ok() ? 0 : -1;
      008AE6 12 3E 18         [24] 1383 	lcall	_ak820_nvm_ok
      008AE9 E5 82            [12] 1384 	mov	a, dpl
      008AEB 60 06            [24] 1385 	jz	00109$
      008AED 7E 00            [12] 1386 	mov	r6,#0x00
      008AEF 7F 00            [12] 1387 	mov	r7,#0x00
      008AF1 80 04            [24] 1388 	sjmp	00110$
      008AF3                       1389 00109$:
      008AF3 7E FF            [12] 1390 	mov	r6,#0xff
      008AF5 7F FF            [12] 1391 	mov	r7,#0xff
      008AF7                       1392 00110$:
      008AF7 12 38 8D         [24] 1393 	lcall	_ak820_outline_0121
                                   1394 ;	quantum/dynamic_keymap.c:282: }
      008AFA 22               [24] 1395 	ret
                                   1396 ;------------------------------------------------------------
                                   1397 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1398 ;------------------------------------------------------------
                                   1399 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1400 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1401 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_398'
                                   1402 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_399'
                                   1403 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_401'
                                   1404 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_402'
                                   1405 ;------------------------------------------------------------
                                   1406 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1407 ;	-----------------------------------------
                                   1408 ;	 function dynamic_keymap_get_combo
                                   1409 ;	-----------------------------------------
      008AFB                       1410 _dynamic_keymap_get_combo:
      008AFB E5 82            [12] 1411 	mov	a,dpl
      008AFD 90 0B BB         [24] 1412 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008B00 F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008B01 90 0B B8         [24] 1415 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008B04 12 38 2E         [24] 1416 	lcall	_ak820_outline_0059
                                   1417 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008B07 90 0B BB         [24] 1418 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008B0A E0               [24] 1419 	movx	a,@dptr
      008B0B FD               [12] 1420 	mov	r5,a
      008B0C BD 08 00         [24] 1421 	cjne	r5,#0x08,00132$
      008B0F                       1422 00132$:
      008B0F 40 04            [24] 1423 	jc	00102$
                                   1424 ;	quantum/dynamic_keymap.c:315: return -1;
      008B11 90 FF FF         [24] 1425 	mov	dptr,#0xffff
      008B14 22               [24] 1426 	ret
      008B15                       1427 00102$:
                                   1428 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008B15 12 93 F5         [24] 1429 	lcall	_ak820_outline_0086
                                   1430 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008B18 8E 02            [24] 1431 	mov	ar2,r6
      008B1A 8F 03            [24] 1432 	mov	ar3,r7
      008B1C 90 05 85         [24] 1433 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008B1F EC               [12] 1434 	mov	a,r4
      008B20 F0               [24] 1435 	movx	@dptr,a
      008B21 ED               [12] 1436 	mov	a,r5
      008B22 12 38 4B         [24] 1437 	lcall	_ak820_outline_0077
      008B25 90 05 88         [24] 1438 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008B28 12 94 16         [24] 1439 	lcall	_ak820_outline_0113
      008B2B 12 38 A2         [24] 1440 	lcall	_ak820_outline_0131
      008B2E C0 07            [24] 1441 	push	ar7
      008B30 C0 06            [24] 1442 	push	ar6
      008B32 12 40 AD         [24] 1443 	lcall	_ak820_eeprom_read_block_xdata
      008B35 D0 06            [24] 1444 	pop	ar6
      008B37 D0 07            [24] 1445 	pop	ar7
                                   1446 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008B39 74 04            [12] 1447 	mov	a,#0x04
      008B3B 12 48 CA         [24] 1448 	lcall	_ak820_outline_0014
      008B3E FA               [12] 1449 	mov	r2,a
      008B3F A3               [24] 1450 	inc	dptr
      008B40 E0               [24] 1451 	movx	a,@dptr
      008B41 FB               [12] 1452 	mov	r3,a
      008B42 BA 20 14         [24] 1453 	cjne	r2,#0x20,00108$
      008B45 BB 08 11         [24] 1454 	cjne	r3,#0x08,00108$
      008B48 74 06            [12] 1455 	mov	a,#0x06
      008B4A 12 38 15         [24] 1456 	lcall	_ak820_outline_0020
      008B4D FA               [12] 1457 	mov	r2,a
      008B4E A3               [24] 1458 	inc	dptr
      008B4F E0               [24] 1459 	movx	a,@dptr
      008B50 FB               [12] 1460 	mov	r3,a
      008B51 BA 01 05         [24] 1461 	cjne	r2,#0x01,00136$
      008B54 BB 00 02         [24] 1462 	cjne	r3,#0x00,00136$
      008B57 80 05            [24] 1463 	sjmp	00109$
      008B59                       1464 00136$:
      008B59                       1465 00108$:
      008B59 75 2B 00         [24] 1466 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008B5C 80 03            [24] 1467 	sjmp	00110$
      008B5E                       1468 00109$:
      008B5E 75 2B 01         [24] 1469 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008B61                       1470 00110$:
                                   1471 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008B61 74 06            [12] 1472 	mov	a,#0x06
      008B63 12 38 26         [24] 1473 	lcall	_ak820_outline_0036
      008B66 12 49 26         [24] 1474 	lcall	_ak820_outline_0146
      008B69 12 43 61         [24] 1475 	lcall	_ak820_outline_0127
      008B6C A3               [24] 1476 	inc	dptr
      008B6D F0               [24] 1477 	movx	@dptr,a
                                   1478 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008B6E E5 2B            [12] 1479 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008B70 60 12            [24] 1480 	jz	00103$
      008B72 12 38 8D         [24] 1481 	lcall	_ak820_outline_0121
      008B75 C0 07            [24] 1482 	push	ar7
      008B77 C0 06            [24] 1483 	push	ar6
      008B79 12 34 D0         [24] 1484 	lcall	_ak820_combo_valid
      008B7C E5 82            [12] 1485 	mov	a, dpl
      008B7E D0 06            [24] 1486 	pop	ar6
      008B80 D0 07            [24] 1487 	pop	ar7
      008B82 70 08            [24] 1488 	jnz	00104$
      008B84                       1489 00103$:
      008B84 7D 00            [12] 1490 	mov	r5,#0x00
      008B86 12 93 E0         [24] 1491 	lcall	_ak820_outline_0043
      008B89 12 BE 82         [24] 1492 	lcall	_memset
      008B8C                       1493 00104$:
                                   1494 ;	quantum/dynamic_keymap.c:329: return 0;
      008B8C 90 00 00         [24] 1495 	mov	dptr,#0x0000
                                   1496 ;	quantum/dynamic_keymap.c:330: }
      008B8F 22               [24] 1497 	ret
                                   1498 ;------------------------------------------------------------
                                   1499 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1500 ;------------------------------------------------------------
                                   1501 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1502 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_404'
                                   1503 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_405'
                                   1504 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_408'
                                   1505 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_409'
                                   1506 ;------------------------------------------------------------
                                   1507 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1508 ;	-----------------------------------------
                                   1509 ;	 function dynamic_keymap_set_combo
                                   1510 ;	-----------------------------------------
      008B90                       1511 _dynamic_keymap_set_combo:
      008B90 E5 82            [12] 1512 	mov	a,dpl
      008B92 90 0B BF         [24] 1513 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      008B95 F0               [24] 1514 	movx	@dptr,a
                                   1515 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008B96 90 0B BC         [24] 1516 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008B99 12 37 DC         [24] 1517 	lcall	_ak820_outline_0005
                                   1518 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008B9C C0 07            [24] 1519 	push	ar7
      008B9E C0 06            [24] 1520 	push	ar6
      008BA0 12 34 D0         [24] 1521 	lcall	_ak820_combo_valid
      008BA3 E5 82            [12] 1522 	mov	a, dpl
      008BA5 D0 06            [24] 1523 	pop	ar6
      008BA7 D0 07            [24] 1524 	pop	ar7
      008BA9 60 07            [24] 1525 	jz	00101$
      008BAB 12 3E 18         [24] 1526 	lcall	_ak820_nvm_ok
      008BAE E5 82            [12] 1527 	mov	a, dpl
      008BB0 70 04            [24] 1528 	jnz	00102$
      008BB2                       1529 00101$:
      008BB2 90 FF FF         [24] 1530 	mov	dptr,#0xffff
      008BB5 22               [24] 1531 	ret
      008BB6                       1532 00102$:
                                   1533 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008BB6 90 0B BF         [24] 1534 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      008BB9 E0               [24] 1535 	movx	a,@dptr
      008BBA FD               [12] 1536 	mov	r5,a
      008BBB BD 08 00         [24] 1537 	cjne	r5,#0x08,00133$
      008BBE                       1538 00133$:
      008BBE 40 04            [24] 1539 	jc	00105$
                                   1540 ;	quantum/dynamic_keymap.c:342: return -1;
      008BC0 90 FF FF         [24] 1541 	mov	dptr,#0xffff
      008BC3 22               [24] 1542 	ret
      008BC4                       1543 00105$:
                                   1544 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008BC4 12 93 F5         [24] 1545 	lcall	_ak820_outline_0086
                                   1546 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008BC7 C0 07            [24] 1547 	push	ar7
      008BC9 C0 06            [24] 1548 	push	ar6
      008BCB C0 05            [24] 1549 	push	ar5
      008BCD C0 04            [24] 1550 	push	ar4
      008BCF 12 7B 58         [24] 1551 	lcall	_clear_keyboard
      008BD2 D0 04            [24] 1552 	pop	ar4
      008BD4 D0 05            [24] 1553 	pop	ar5
      008BD6 D0 06            [24] 1554 	pop	ar6
      008BD8 D0 07            [24] 1555 	pop	ar7
                                   1556 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008BDA 90 0E 84         [24] 1557 	mov	dptr,#___memcpy_PARM_2
      008BDD 12 49 18         [24] 1558 	lcall	_ak820_outline_0066
      008BE0 E4               [12] 1559 	clr	a
      008BE1 A3               [24] 1560 	inc	dptr
      008BE2 F0               [24] 1561 	movx	@dptr,a
      008BE3 90 0E 87         [24] 1562 	mov	dptr,#___memcpy_PARM_3
      008BE6 12 94 16         [24] 1563 	lcall	_ak820_outline_0113
      008BE9 90 0B C0         [24] 1564 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      008BEC F5 F0            [12] 1565 	mov	b,a
      008BEE C0 05            [24] 1566 	push	ar5
      008BF0 C0 04            [24] 1567 	push	ar4
      008BF2 12 BE 0C         [24] 1568 	lcall	___memcpy
      008BF5 D0 04            [24] 1569 	pop	ar4
      008BF7 D0 05            [24] 1570 	pop	ar5
                                   1571 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008BF9 90 0B C4         [24] 1572 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0004)
      008BFC 74 20            [12] 1573 	mov	a,#0x20
      008BFE F0               [24] 1574 	movx	@dptr,a
      008BFF 74 08            [12] 1575 	mov	a,#0x08
      008C01 A3               [24] 1576 	inc	dptr
      008C02 F0               [24] 1577 	movx	@dptr,a
                                   1578 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008C03 90 0B C6         [24] 1579 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0006)
      008C06 74 01            [12] 1580 	mov	a,#0x01
      008C08 12 38 9D         [24] 1581 	lcall	_ak820_outline_0130
                                   1582 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008C0B 90 05 8E         [24] 1583 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008C0E EC               [12] 1584 	mov	a,r4
      008C0F F0               [24] 1585 	movx	@dptr,a
      008C10 ED               [12] 1586 	mov	a,r5
      008C11 12 38 4B         [24] 1587 	lcall	_ak820_outline_0077
      008C14 90 05 91         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008C17 12 94 16         [24] 1589 	lcall	_ak820_outline_0113
      008C1A 90 0B C0         [24] 1590 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      008C1D 12 41 39         [24] 1591 	lcall	_ak820_eeprom_write_block_xdata
                                   1592 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008C20 12 3E 27         [24] 1593 	lcall	_ak820_nvm_flush
                                   1594 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008C23 12 3E 18         [24] 1595 	lcall	_ak820_nvm_ok
      008C26 E5 82            [12] 1596 	mov	a, dpl
      008C28 70 04            [24] 1597 	jnz	00107$
      008C2A 90 FF FF         [24] 1598 	mov	dptr,#0xffff
      008C2D 22               [24] 1599 	ret
      008C2E                       1600 00107$:
                                   1601 ;	quantum/dynamic_keymap.c:360: return 0;
      008C2E 90 00 00         [24] 1602 	mov	dptr,#0x0000
                                   1603 ;	quantum/dynamic_keymap.c:361: }
      008C31 22               [24] 1604 	ret
                                   1605 ;------------------------------------------------------------
                                   1606 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1607 ;------------------------------------------------------------
                                   1608 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_412'
                                   1609 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_413'
                                   1610 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_415'
                                   1611 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_417'
                                   1612 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_419'
                                   1613 ;td            Allocated with name '_dynamic_keymap_reset_td_10001_421'
                                   1614 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_422'
                                   1615 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10002_424'
                                   1616 ;i             Allocated with name '_dynamic_keymap_reset_i_20002_425'
                                   1617 ;------------------------------------------------------------
                                   1618 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1619 ;	-----------------------------------------
                                   1620 ;	 function dynamic_keymap_reset
                                   1621 ;	-----------------------------------------
      008C32                       1622 _dynamic_keymap_reset:
                                   1623 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008C32 90 0F 04         [24] 1624 	mov	dptr,#_vial_unlocked
      008C35 E0               [24] 1625 	movx	a,@dptr
      008C36 90 0B CA         [24] 1626 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      008C39 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008C3A 90 0F 04         [24] 1629 	mov	dptr,#_vial_unlocked
      008C3D 74 01            [12] 1630 	mov	a,#0x01
      008C3F F0               [24] 1631 	movx	@dptr,a
                                   1632 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008C40 7F 00            [12] 1633 	mov	r7,#0x00
      008C42                       1634 00117$:
      008C42 BF 06 00         [24] 1635 	cjne	r7,#0x06,00217$
      008C45                       1636 00217$:
      008C45 40 02            [24] 1637 	jc	00218$
      008C47 81 F0            [12] 1638 	ajmp	00104$
      008C49                       1639 00218$:
                                   1640 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008C49 7E 00            [12] 1641 	mov	r6,#0x00
      008C4B                       1642 00111$:
      008C4B BE 10 00         [24] 1643 	cjne	r6,#0x10,00219$
      008C4E                       1644 00219$:
      008C4E 50 4C            [24] 1645 	jnc	00102$
                                   1646 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008C50 7D 00            [12] 1647 	mov	r5,#0x00
      008C52                       1648 00108$:
      008C52 BD 08 00         [24] 1649 	cjne	r5,#0x08,00221$
      008C55                       1650 00221$:
      008C55 50 42            [24] 1651 	jnc	00112$
                                   1652 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008C57 90 0C 70         [24] 1653 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008C5A EE               [12] 1654 	mov	a,r6
      008C5B F0               [24] 1655 	movx	@dptr,a
      008C5C 90 0C 71         [24] 1656 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008C5F ED               [12] 1657 	mov	a,r5
      008C60 F0               [24] 1658 	movx	@dptr,a
      008C61 8F 82            [24] 1659 	mov	dpl, r7
      008C63 C0 07            [24] 1660 	push	ar7
      008C65 C0 06            [24] 1661 	push	ar6
      008C67 C0 05            [24] 1662 	push	ar5
      008C69 12 9C 24         [24] 1663 	lcall	_keycode_at_keymap_location_raw
      008C6C AB 82            [24] 1664 	mov	r3, dpl
      008C6E AC 83            [24] 1665 	mov	r4, dph
      008C70 D0 05            [24] 1666 	pop	ar5
      008C72 D0 06            [24] 1667 	pop	ar6
      008C74 D0 07            [24] 1668 	pop	ar7
      008C76 90 0B A1         [24] 1669 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008C79 EE               [12] 1670 	mov	a,r6
      008C7A F0               [24] 1671 	movx	@dptr,a
      008C7B 90 0B A2         [24] 1672 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008C7E ED               [12] 1673 	mov	a,r5
      008C7F F0               [24] 1674 	movx	@dptr,a
      008C80 90 0B A3         [24] 1675 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008C83 12 38 57         [24] 1676 	lcall	_ak820_outline_0082
      008C86 8F 82            [24] 1677 	mov	dpl, r7
      008C88 C0 07            [24] 1678 	push	ar7
      008C8A C0 06            [24] 1679 	push	ar6
      008C8C C0 05            [24] 1680 	push	ar5
      008C8E 11 98            [12] 1681 	acall	_dynamic_keymap_set_keycode
      008C90 D0 05            [24] 1682 	pop	ar5
      008C92 D0 06            [24] 1683 	pop	ar6
      008C94 D0 07            [24] 1684 	pop	ar7
                                   1685 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008C96 0D               [12] 1686 	inc	r5
      008C97 80 B9            [24] 1687 	sjmp	00108$
      008C99                       1688 00112$:
                                   1689 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008C99 0E               [12] 1690 	inc	r6
      008C9A 80 AF            [24] 1691 	sjmp	00111$
      008C9C                       1692 00102$:
                                   1693 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008C9C 7E 00            [12] 1694 	mov	r6,#0x00
      008C9E                       1695 00114$:
      008C9E BE 01 00         [24] 1696 	cjne	r6,#0x01,00223$
      008CA1                       1697 00223$:
      008CA1 50 4A            [24] 1698 	jnc	00118$
                                   1699 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008CA3 12 94 4B         [24] 1700 	lcall	_ak820_outline_0183
      008CA6 04               [12] 1701 	inc	a
      008CA7 F0               [24] 1702 	movx	@dptr,a
      008CA8 8F 82            [24] 1703 	mov	dpl, r7
      008CAA C0 07            [24] 1704 	push	ar7
      008CAC 12 9C 69         [24] 1705 	lcall	_keycode_at_encodermap_location_raw
      008CAF 12 43 72         [24] 1706 	lcall	_ak820_outline_0154
      008CB2 D0 07            [24] 1707 	pop	ar7
      008CB4 12 94 42         [24] 1708 	lcall	_ak820_outline_0182
      008CB7 04               [12] 1709 	inc	a
      008CB8 F0               [24] 1710 	movx	@dptr,a
      008CB9 90 0B AD         [24] 1711 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008CBC 12 38 51         [24] 1712 	lcall	_ak820_outline_0079
      008CBF 8F 82            [24] 1713 	mov	dpl, r7
      008CC1 C0 07            [24] 1714 	push	ar7
      008CC3 31 6F            [24] 1715 	acall	_dynamic_keymap_set_encoder
      008CC5 D0 07            [24] 1716 	pop	ar7
                                   1717 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008CC7 12 94 4B         [24] 1718 	lcall	_ak820_outline_0183
      008CCA F0               [24] 1719 	movx	@dptr,a
      008CCB 8F 82            [24] 1720 	mov	dpl, r7
      008CCD C0 07            [24] 1721 	push	ar7
      008CCF 12 9C 69         [24] 1722 	lcall	_keycode_at_encodermap_location_raw
      008CD2 12 43 72         [24] 1723 	lcall	_ak820_outline_0154
      008CD5 D0 07            [24] 1724 	pop	ar7
      008CD7 12 94 42         [24] 1725 	lcall	_ak820_outline_0182
      008CDA F0               [24] 1726 	movx	@dptr,a
      008CDB 90 0B AD         [24] 1727 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008CDE 12 38 51         [24] 1728 	lcall	_ak820_outline_0079
      008CE1 8F 82            [24] 1729 	mov	dpl, r7
      008CE3 C0 07            [24] 1730 	push	ar7
      008CE5 31 6F            [24] 1731 	acall	_dynamic_keymap_set_encoder
      008CE7 D0 07            [24] 1732 	pop	ar7
                                   1733 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008CE9 7E 01            [12] 1734 	mov	r6,#0x01
      008CEB 80 B1            [24] 1735 	sjmp	00114$
      008CED                       1736 00118$:
                                   1737 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008CED 0F               [12] 1738 	inc	r7
      008CEE 81 42            [12] 1739 	ajmp	00117$
      008CF0                       1740 00104$:
                                   1741 ;	quantum/dynamic_keymap.c:442: vial_tap_dance_entry_t td = { KC_NO, KC_NO, KC_NO, KC_NO, TAPPING_TERM };
      008CF0 90 0B CB         [24] 1742 	mov	dptr,#_dynamic_keymap_reset_td_10001_421
      008CF3 12 49 26         [24] 1743 	lcall	_ak820_outline_0146
      008CF6 90 0B CD         [24] 1744 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0002)
      008CF9 F0               [24] 1745 	movx	@dptr,a
      008CFA A3               [24] 1746 	inc	dptr
      008CFB F0               [24] 1747 	movx	@dptr,a
      008CFC 90 0B CF         [24] 1748 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0004)
      008CFF F0               [24] 1749 	movx	@dptr,a
      008D00 A3               [24] 1750 	inc	dptr
      008D01 F0               [24] 1751 	movx	@dptr,a
      008D02 90 0B D1         [24] 1752 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0006)
      008D05 F0               [24] 1753 	movx	@dptr,a
      008D06 A3               [24] 1754 	inc	dptr
      008D07 F0               [24] 1755 	movx	@dptr,a
      008D08 90 0B D3         [24] 1756 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0008)
      008D0B 74 C8            [12] 1757 	mov	a,#0xc8
      008D0D 12 38 9D         [24] 1758 	lcall	_ak820_outline_0130
                                   1759 ;	quantum/dynamic_keymap.c:443: for (reset_index_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      008D10 FF               [12] 1760 	mov	r7,a
      008D11                       1761 00120$:
      008D11 BF 08 00         [24] 1762 	cjne	r7,#0x08,00225$
      008D14                       1763 00225$:
      008D14 50 16            [24] 1764 	jnc	00105$
                                   1765 ;	quantum/dynamic_keymap.c:444: dynamic_keymap_set_tap_dance(i, &td);
      008D16 90 0B B4         [24] 1766 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      008D19 74 CB            [12] 1767 	mov	a,#_dynamic_keymap_reset_td_10001_421
      008D1B F0               [24] 1768 	movx	@dptr,a
      008D1C 74 0B            [12] 1769 	mov	a,#(_dynamic_keymap_reset_td_10001_421 >> 8)
      008D1E 12 38 4B         [24] 1770 	lcall	_ak820_outline_0077
      008D21 8F 82            [24] 1771 	mov	dpl, r7
      008D23 C0 07            [24] 1772 	push	ar7
      008D25 51 5D            [24] 1773 	acall	_dynamic_keymap_set_tap_dance
      008D27 D0 07            [24] 1774 	pop	ar7
                                   1775 ;	quantum/dynamic_keymap.c:443: for (reset_index_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      008D29 0F               [12] 1776 	inc	r7
      008D2A 80 E5            [24] 1777 	sjmp	00120$
      008D2C                       1778 00105$:
                                   1779 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008D2C 90 0B D5         [24] 1780 	mov	dptr,#_dynamic_keymap_reset_combo_10002_424
      008D2F 12 49 26         [24] 1781 	lcall	_ak820_outline_0146
      008D32 90 0B D7         [24] 1782 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0002)
      008D35 F0               [24] 1783 	movx	@dptr,a
      008D36 A3               [24] 1784 	inc	dptr
      008D37 F0               [24] 1785 	movx	@dptr,a
      008D38 90 0B D9         [24] 1786 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0004)
      008D3B F0               [24] 1787 	movx	@dptr,a
      008D3C A3               [24] 1788 	inc	dptr
      008D3D F0               [24] 1789 	movx	@dptr,a
      008D3E 90 0B DB         [24] 1790 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0006)
      008D41 F0               [24] 1791 	movx	@dptr,a
      008D42 A3               [24] 1792 	inc	dptr
      008D43 F0               [24] 1793 	movx	@dptr,a
      008D44 90 0B DD         [24] 1794 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0008)
      008D47 F0               [24] 1795 	movx	@dptr,a
      008D48 A3               [24] 1796 	inc	dptr
      008D49 F0               [24] 1797 	movx	@dptr,a
                                   1798 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008D4A FF               [12] 1799 	mov	r7,a
      008D4B                       1800 00123$:
      008D4B BF 08 00         [24] 1801 	cjne	r7,#0x08,00227$
      008D4E                       1802 00227$:
      008D4E 50 16            [24] 1803 	jnc	00106$
                                   1804 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008D50 90 0B BC         [24] 1805 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008D53 74 D5            [12] 1806 	mov	a,#_dynamic_keymap_reset_combo_10002_424
      008D55 F0               [24] 1807 	movx	@dptr,a
      008D56 74 0B            [12] 1808 	mov	a,#(_dynamic_keymap_reset_combo_10002_424 >> 8)
      008D58 12 38 4B         [24] 1809 	lcall	_ak820_outline_0077
      008D5B 8F 82            [24] 1810 	mov	dpl, r7
      008D5D C0 07            [24] 1811 	push	ar7
      008D5F 71 90            [12] 1812 	acall	_dynamic_keymap_set_combo
      008D61 D0 07            [24] 1813 	pop	ar7
                                   1814 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008D63 0F               [12] 1815 	inc	r7
      008D64 80 E5            [24] 1816 	sjmp	00123$
      008D66                       1817 00106$:
                                   1818 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008D66 90 0B CA         [24] 1819 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      008D69 E0               [24] 1820 	movx	a,@dptr
      008D6A 90 0F 04         [24] 1821 	mov	dptr,#_vial_unlocked
      008D6D F0               [24] 1822 	movx	@dptr,a
                                   1823 ;	quantum/dynamic_keymap.c:468: }
      008D6E 22               [24] 1824 	ret
                                   1825 ;------------------------------------------------------------
                                   1826 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1827 ;------------------------------------------------------------
                                   1828 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1829 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1830 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1831 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1832 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1833 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_426'
                                   1834 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_427'
                                   1835 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_427'
                                   1836 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_430'
                                   1837 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_432'
                                   1838 ;------------------------------------------------------------
                                   1839 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1840 ;	-----------------------------------------
                                   1841 ;	 function ak820_dynamic_read_buffer
                                   1842 ;	-----------------------------------------
      008D6F                       1843 _ak820_dynamic_read_buffer:
      008D6F 12 38 7A         [24] 1844 	lcall	_ak820_outline_0106
      008D72 90 0B E8         [24] 1845 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      008D75 12 38 75         [24] 1846 	lcall	_ak820_outline_0105
                                   1847 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008D78 90 0B E5         [24] 1848 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008D7B 12 38 2E         [24] 1849 	lcall	_ak820_outline_0059
                                   1850 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008D7E 90 0B EA         [24] 1851 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008D81 E4               [12] 1852 	clr	a
      008D82 F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008D83 90 0B E3         [24] 1855 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008D86 12 38 45         [24] 1856 	lcall	_ak820_outline_0065
      008D89 8C 02            [24] 1857 	mov	ar2,r4
      008D8B 8D 03            [24] 1858 	mov	ar3,r5
      008D8D C3               [12] 1859 	clr	c
      008D8E 74 1C            [12] 1860 	mov	a,#0x1c
      008D90 9A               [12] 1861 	subb	a,r2
      008D91 E4               [12] 1862 	clr	a
      008D92 9B               [12] 1863 	subb	a,r3
      008D93 50 01            [24] 1864 	jnc	00102$
                                   1865 ;	free result
      008D95 22               [24] 1866 	ret
      008D96                       1867 00102$:
                                   1868 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008D96 90 0B E1         [24] 1869 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008D99 12 43 4F         [24] 1870 	lcall	_ak820_outline_0084
      008D9C 90 0B DF         [24] 1871 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008D9F 12 38 63         [24] 1872 	lcall	_ak820_outline_0098
      008DA2 C3               [12] 1873 	clr	c
      008DA3 EA               [12] 1874 	mov	a,r2
      008DA4 98               [12] 1875 	subb	a,r0
      008DA5 EB               [12] 1876 	mov	a,r3
      008DA6 99               [12] 1877 	subb	a,r1
      008DA7 50 17            [24] 1878 	jnc	00104$
                                   1879 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008DA9 E8               [12] 1880 	mov	a,r0
      008DAA C3               [12] 1881 	clr	c
      008DAB 9A               [12] 1882 	subb	a,r2
      008DAC F8               [12] 1883 	mov	r0,a
      008DAD E9               [12] 1884 	mov	a,r1
      008DAE 9B               [12] 1885 	subb	a,r3
      008DAF F9               [12] 1886 	mov	r1,a
                                   1887 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008DB0 C3               [12] 1888 	clr	c
      008DB1 E8               [12] 1889 	mov	a,r0
      008DB2 9C               [12] 1890 	subb	a,r4
      008DB3 E9               [12] 1891 	mov	a,r1
      008DB4 9D               [12] 1892 	subb	a,r5
      008DB5 40 04            [24] 1893 	jc	00114$
      008DB7 8C 00            [24] 1894 	mov	ar0,r4
      008DB9 8D 01            [24] 1895 	mov	ar1,r5
      008DBB                       1896 00114$:
      008DBB 90 0B EA         [24] 1897 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008DBE E8               [12] 1898 	mov	a,r0
      008DBF F0               [24] 1899 	movx	@dptr,a
      008DC0                       1900 00104$:
                                   1901 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008DC0 90 0B EA         [24] 1902 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008DC3 E0               [24] 1903 	movx	a,@dptr
      008DC4 F5 2C            [12] 1904 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008DC6 E0               [24] 1905 	movx	a,@dptr
      008DC7 60 42            [24] 1906 	jz	00106$
      008DC9 C0 04            [24] 1907 	push	ar4
      008DCB C0 05            [24] 1908 	push	ar5
      008DCD 8E 00            [24] 1909 	mov	ar0,r6
      008DCF 8F 05            [24] 1910 	mov	ar5,r7
      008DD1 90 0B E8         [24] 1911 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      008DD4 E0               [24] 1912 	movx	a,@dptr
      008DD5 F9               [12] 1913 	mov	r1,a
      008DD6 A3               [24] 1914 	inc	dptr
      008DD7 E0               [24] 1915 	movx	a,@dptr
      008DD8 FC               [12] 1916 	mov	r4,a
      008DD9 EA               [12] 1917 	mov	a,r2
      008DDA 29               [12] 1918 	add	a, r1
      008DDB FA               [12] 1919 	mov	r2,a
      008DDC EB               [12] 1920 	mov	a,r3
      008DDD 3C               [12] 1921 	addc	a, r4
      008DDE FB               [12] 1922 	mov	r3,a
      008DDF 90 05 85         [24] 1923 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008DE2 EA               [12] 1924 	mov	a,r2
      008DE3 F0               [24] 1925 	movx	@dptr,a
      008DE4 EB               [12] 1926 	mov	a,r3
      008DE5 12 38 4B         [24] 1927 	lcall	_ak820_outline_0077
      008DE8 90 05 88         [24] 1928 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008DEB E5 2C            [12] 1929 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008DED 12 38 9D         [24] 1930 	lcall	_ak820_outline_0130
      008DF0 88 82            [24] 1931 	mov	dpl, r0
      008DF2 8D 83            [24] 1932 	mov	dph, r5
      008DF4 C0 07            [24] 1933 	push	ar7
      008DF6 C0 06            [24] 1934 	push	ar6
      008DF8 C0 05            [24] 1935 	push	ar5
      008DFA C0 04            [24] 1936 	push	ar4
      008DFC 12 40 AD         [24] 1937 	lcall	_ak820_eeprom_read_block_xdata
      008DFF D0 04            [24] 1938 	pop	ar4
      008E01 D0 05            [24] 1939 	pop	ar5
      008E03 D0 06            [24] 1940 	pop	ar6
      008E05 D0 07            [24] 1941 	pop	ar7
                                   1942 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008E07 D0 05            [24] 1943 	pop	ar5
      008E09 D0 04            [24] 1944 	pop	ar4
                                   1945 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008E0B                       1946 00106$:
                                   1947 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008E0B 90 0B EA         [24] 1948 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008E0E E0               [24] 1949 	movx	a,@dptr
      008E0F FB               [12] 1950 	mov	r3,a
      008E10                       1951 00109$:
      008E10 8B 01            [24] 1952 	mov	ar1,r3
      008E12 7A 00            [12] 1953 	mov	r2,#0x00
      008E14 C3               [12] 1954 	clr	c
      008E15 E9               [12] 1955 	mov	a,r1
      008E16 9C               [12] 1956 	subb	a,r4
      008E17 EA               [12] 1957 	mov	a,r2
      008E18 9D               [12] 1958 	subb	a,r5
      008E19 50 09            [24] 1959 	jnc	00111$
      008E1B EB               [12] 1960 	mov	a,r3
      008E1C 12 38 26         [24] 1961 	lcall	_ak820_outline_0036
      008E1F E4               [12] 1962 	clr	a
      008E20 F0               [24] 1963 	movx	@dptr,a
      008E21 0B               [12] 1964 	inc	r3
      008E22 80 EC            [24] 1965 	sjmp	00109$
      008E24                       1966 00111$:
                                   1967 ;	quantum/dynamic_keymap.c:483: }
      008E24 22               [24] 1968 	ret
                                   1969 ;------------------------------------------------------------
                                   1970 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1971 ;------------------------------------------------------------
                                   1972 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1973 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1974 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_433'
                                   1975 ;------------------------------------------------------------
                                   1976 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1977 ;	-----------------------------------------
                                   1978 ;	 function dynamic_keymap_get_buffer
                                   1979 ;	-----------------------------------------
      008E25                       1980 _dynamic_keymap_get_buffer:
      008E25 12 38 7A         [24] 1981 	lcall	_ak820_outline_0106
      008E28 90 0B F0         [24] 1982 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      008E2B 12 38 75         [24] 1983 	lcall	_ak820_outline_0105
                                   1984 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008E2E 90 0B F0         [24] 1985 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      008E31 12 38 2E         [24] 1986 	lcall	_ak820_outline_0059
      008E34 90 0B EB         [24] 1987 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008E37 12 38 45         [24] 1988 	lcall	_ak820_outline_0065
      008E3A 90 0B ED         [24] 1989 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008E3D E0               [24] 1990 	movx	a,@dptr
      008E3E F9               [12] 1991 	mov	r1,a
      008E3F A3               [24] 1992 	inc	dptr
      008E40 12 43 4F         [24] 1993 	lcall	_ak820_outline_0084
      008E43 90 0B DF         [24] 1994 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008E46 E4               [12] 1995 	clr	a
      008E47 F0               [24] 1996 	movx	@dptr,a
      008E48 74 06            [12] 1997 	mov	a,#0x06
      008E4A A3               [24] 1998 	inc	dptr
      008E4B F0               [24] 1999 	movx	@dptr,a
      008E4C 90 0B E1         [24] 2000 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008E4F 12 49 18         [24] 2001 	lcall	_ak820_outline_0066
      008E52 90 0B E3         [24] 2002 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008E55 12 38 51         [24] 2003 	lcall	_ak820_outline_0079
      008E58 90 0B E5         [24] 2004 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008E5B E9               [12] 2005 	mov	a,r1
      008E5C F0               [24] 2006 	movx	@dptr,a
      008E5D EA               [12] 2007 	mov	a,r2
      008E5E A3               [24] 2008 	inc	dptr
      008E5F 12 49 35         [24] 2009 	lcall	_ak820_outline_0162
      008E62 90 00 40         [24] 2010 	mov	dptr,#0x0040
                                   2011 ;	quantum/dynamic_keymap.c:511: }
      008E65 A1 6F            [12] 2012 	ajmp	_ak820_dynamic_read_buffer
                                   2013 ;------------------------------------------------------------
                                   2014 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   2015 ;------------------------------------------------------------
                                   2016 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   2017 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   2018 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   2019 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   2020 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   2021 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_435'
                                   2022 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_436'
                                   2023 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_436'
                                   2024 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_436'
                                   2025 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_439'
                                   2026 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_442'
                                   2027 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_442'
                                   2028 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_444'
                                   2029 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_447'
                                   2030 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_449'
                                   2031 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_450'
                                   2032 ;------------------------------------------------------------
                                   2033 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2034 ;	-----------------------------------------
                                   2035 ;	 function dynamic_keymap_set_buffer
                                   2036 ;	-----------------------------------------
      008E67                       2037 _dynamic_keymap_set_buffer:
      008E67 12 38 7A         [24] 2038 	lcall	_ak820_outline_0106
      008E6A 90 0B F7         [24] 2039 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008E6D 12 38 75         [24] 2040 	lcall	_ak820_outline_0105
                                   2041 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008E70 90 0B F7         [24] 2042 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008E73 12 4D DC         [24] 2043 	lcall	_ak820_outline_0012
      008E76 74 40            [12] 2044 	mov	a,#0x40
      008E78 2C               [12] 2045 	add	a, r4
      008E79 FA               [12] 2046 	mov	r2,a
      008E7A E4               [12] 2047 	clr	a
      008E7B 3D               [12] 2048 	addc	a, r5
      008E7C FB               [12] 2049 	mov	r3,a
                                   2050 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008E7D 90 0B F4         [24] 2051 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008E80 12 38 63         [24] 2052 	lcall	_ak820_outline_0098
                                   2053 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008E83 90 0B F2         [24] 2054 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008E86 E0               [24] 2055 	movx	a,@dptr
      008E87 F5 2D            [12] 2056 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008E89 A3               [24] 2057 	inc	dptr
      008E8A E0               [24] 2058 	movx	a,@dptr
      008E8B F5 2E            [12] 2059 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008E8D E5 2D            [12] 2060 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E8F 45 2E            [12] 2061 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E91 70 01            [24] 2062 	jnz	00102$
      008E93 22               [24] 2063 	ret
      008E94                       2064 00102$:
                                   2065 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008E94 85 2D 2F         [24] 2066 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008E97 85 2E 30         [24] 2067 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E9A C3               [12] 2068 	clr	c
      008E9B 74 1C            [12] 2069 	mov	a,#0x1c
      008E9D 95 2F            [12] 2070 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008E9F E4               [12] 2071 	clr	a
      008EA0 95 30            [12] 2072 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008EA2 50 01            [24] 2073 	jnc	00104$
                                   2074 ;	free result
      008EA4 22               [24] 2075 	ret
      008EA5                       2076 00104$:
                                   2077 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008EA5 85 2D 31         [24] 2078 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   2079 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008EA8 74 FA            [12] 2080 	mov	a,#0x100 - 0x06
      008EAA 2F               [12] 2081 	add	a,r7
      008EAB 40 11            [24] 2082 	jc	00105$
      008EAD E4               [12] 2083 	clr	a
      008EAE C3               [12] 2084 	clr	c
      008EAF 9E               [12] 2085 	subb	a,r6
      008EB0 FE               [12] 2086 	mov	r6,a
      008EB1 74 06            [12] 2087 	mov	a,#0x06
      008EB3 9F               [12] 2088 	subb	a,r7
      008EB4 FF               [12] 2089 	mov	r7,a
      008EB5 C3               [12] 2090 	clr	c
      008EB6 EE               [12] 2091 	mov	a,r6
      008EB7 95 2D            [12] 2092 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008EB9 EF               [12] 2093 	mov	a,r7
      008EBA 95 2E            [12] 2094 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008EBC 50 01            [24] 2095 	jnc	00106$
      008EBE                       2096 00105$:
                                   2097 ;	quantum/dynamic_keymap.c:529: return;
      008EBE 22               [24] 2098 	ret
      008EBF                       2099 00106$:
                                   2100 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008EBF 90 0F 04         [24] 2101 	mov	dptr,#_vial_unlocked
      008EC2 E0               [24] 2102 	movx	a,@dptr
      008EC3 60 03            [24] 2103 	jz	00207$
      008EC5 02 8F D4         [24] 2104 	ljmp	00120$
      008EC8                       2105 00207$:
                                   2106 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008EC8 90 0B F9         [24] 2107 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008ECB E4               [12] 2108 	clr	a
      008ECC F0               [24] 2109 	movx	@dptr,a
                                   2110 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008ECD 90 0B FA         [24] 2111 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008ED0 E5 31            [12] 2112 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008ED2 F0               [24] 2113 	movx	@dptr,a
                                   2114 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008ED3 EC               [12] 2115 	mov	a,r4
      008ED4 30 E0 33         [24] 2116 	jnb	acc.0,00111$
                                   2117 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008ED7 EA               [12] 2118 	mov	a,r2
      008ED8 24 FF            [12] 2119 	add	a,#0xff
      008EDA FE               [12] 2120 	mov	r6,a
      008EDB EB               [12] 2121 	mov	a,r3
      008EDC 34 FF            [12] 2122 	addc	a,#0xff
      008EDE FF               [12] 2123 	mov	r7,a
      008EDF 7D 00            [12] 2124 	mov	r5,#0x00
      008EE1 12 38 8D         [24] 2125 	lcall	_ak820_outline_0121
      008EE4 8D F0            [24] 2126 	mov	b, r5
      008EE6 12 40 72         [24] 2127 	lcall	_eeprom_read_byte
      008EE9 AE 82            [24] 2128 	mov	r6,dpl
      008EEB 7F 00            [12] 2129 	mov	r7,#0x00
      008EED 12 38 B1         [24] 2130 	lcall	_ak820_outline_0153
      008EF0 E0               [24] 2131 	movx	a,@dptr
      008EF1 7C 00            [12] 2132 	mov	r4,#0x00
      008EF3 42 07            [12] 2133 	orl	ar7,a
      008EF5 EC               [12] 2134 	mov	a,r4
      008EF6 42 06            [12] 2135 	orl	ar6,a
                                   2136 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008EF8 BF 00 09         [24] 2137 	cjne	r7,#0x00,00109$
      008EFB BE 7C 06         [24] 2138 	cjne	r6,#0x7c,00109$
                                   2139 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008EFE 12 38 B1         [24] 2140 	lcall	_ak820_outline_0153
      008F01 74 FF            [12] 2141 	mov	a,#0xff
      008F03 F0               [24] 2142 	movx	@dptr,a
      008F04                       2143 00109$:
                                   2144 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008F04 90 0B F9         [24] 2145 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008F07 74 01            [12] 2146 	mov	a,#0x01
      008F09 F0               [24] 2147 	movx	@dptr,a
      008F0A                       2148 00111$:
                                   2149 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008F0A 90 0B F7         [24] 2150 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008F0D 12 38 2E         [24] 2151 	lcall	_ak820_outline_0059
      008F10 E5 2D            [12] 2152 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008F12 2E               [12] 2153 	add	a, r6
      008F13 FE               [12] 2154 	mov	r6,a
      008F14 E5 2E            [12] 2155 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F16 3F               [12] 2156 	addc	a, r7
      008F17 EE               [12] 2157 	mov	a,r6
      008F18 30 E0 5A         [24] 2158 	jnb	acc.0,00115$
                                   2159 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008F1B AE 31            [24] 2160 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008F1D 7F 00            [12] 2161 	mov	r7,#0x00
      008F1F EE               [12] 2162 	mov	a,r6
      008F20 24 FF            [12] 2163 	add	a,#0xff
      008F22 FC               [12] 2164 	mov	r4,a
      008F23 EF               [12] 2165 	mov	a,r7
      008F24 34 FF            [12] 2166 	addc	a,#0xff
      008F26 FD               [12] 2167 	mov	r5,a
      008F27 EC               [12] 2168 	mov	a,r4
      008F28 28               [12] 2169 	add	a, r0
      008F29 F5 82            [12] 2170 	mov	dpl,a
      008F2B ED               [12] 2171 	mov	a,r5
      008F2C 39               [12] 2172 	addc	a, r1
      008F2D F5 83            [12] 2173 	mov	dph,a
      008F2F E0               [24] 2174 	movx	a,@dptr
      008F30 FC               [12] 2175 	mov	r4,a
      008F31 7D 00            [12] 2176 	mov	r5,#0x00
      008F33 E5 31            [12] 2177 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008F35 2A               [12] 2178 	add	a, r2
      008F36 FA               [12] 2179 	mov	r2,a
      008F37 E4               [12] 2180 	clr	a
      008F38 3B               [12] 2181 	addc	a, r3
      008F39 FB               [12] 2182 	mov	r3,a
      008F3A C0 00            [24] 2183 	push	ar0
      008F3C C0 01            [24] 2184 	push	ar1
      008F3E 8B 01            [24] 2185 	mov	ar1,r3
      008F40 7B 00            [12] 2186 	mov	r3,#0x00
      008F42 8A 82            [24] 2187 	mov	dpl, r2
      008F44 89 83            [24] 2188 	mov	dph, r1
      008F46 8B F0            [24] 2189 	mov	b, r3
      008F48 12 40 72         [24] 2190 	lcall	_eeprom_read_byte
      008F4B AB 82            [24] 2191 	mov	r3, dpl
      008F4D 7A 00            [12] 2192 	mov	r2,#0x00
      008F4F EB               [12] 2193 	mov	a,r3
      008F50 12 43 6C         [24] 2194 	lcall	_ak820_outline_0145
                                   2195 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008F53 BD 00 05         [24] 2196 	cjne	r5,#0x00,00212$
      008F56 BC 7C 02         [24] 2197 	cjne	r4,#0x7c,00212$
      008F59 80 06            [24] 2198 	sjmp	00213$
      008F5B                       2199 00212$:
      008F5B D0 01            [24] 2200 	pop	ar1
      008F5D D0 00            [24] 2201 	pop	ar0
      008F5F 80 0D            [24] 2202 	sjmp	00113$
      008F61                       2203 00213$:
      008F61 D0 01            [24] 2204 	pop	ar1
      008F63 D0 00            [24] 2205 	pop	ar0
                                   2206 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008F65 1E               [12] 2207 	dec	r6
      008F66 BE FF 01         [24] 2208 	cjne	r6,#0xff,00214$
      008F69 1F               [12] 2209 	dec	r7
      008F6A                       2210 00214$:
      008F6A EE               [12] 2211 	mov	a,r6
      008F6B 12 94 24         [24] 2212 	lcall	_ak820_outline_0135
      008F6E                       2213 00113$:
                                   2214 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008F6E E5 31            [12] 2215 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008F70 14               [12] 2216 	dec	a
      008F71 90 0B FA         [24] 2217 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008F74 F0               [24] 2218 	movx	@dptr,a
      008F75                       2219 00115$:
                                   2220 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008F75 90 0B F9         [24] 2221 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008F78 E0               [24] 2222 	movx	a,@dptr
      008F79 90 0B FB         [24] 2223 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008F7C F0               [24] 2224 	movx	@dptr,a
      008F7D                       2225 00122$:
      008F7D 90 0B FB         [24] 2226 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008F80 E0               [24] 2227 	movx	a,@dptr
      008F81 FF               [12] 2228 	mov	r7,a
      008F82 90 0B FA         [24] 2229 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008F85 E0               [24] 2230 	movx	a,@dptr
      008F86 FE               [12] 2231 	mov	r6,a
      008F87 C3               [12] 2232 	clr	c
      008F88 EF               [12] 2233 	mov	a,r7
      008F89 9E               [12] 2234 	subb	a,r6
      008F8A 50 48            [24] 2235 	jnc	00120$
                                   2236 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008F8C EF               [12] 2237 	mov	a,r7
      008F8D 28               [12] 2238 	add	a, r0
      008F8E FD               [12] 2239 	mov	r5,a
      008F8F E4               [12] 2240 	clr	a
      008F90 39               [12] 2241 	addc	a, r1
      008F91 FE               [12] 2242 	mov	r6,a
      008F92 12 4E 0F         [24] 2243 	lcall	_ak820_outline_0080
      008F95 7B 00            [12] 2244 	mov	r3,#0x00
      008F97 8C 2E            [24] 2245 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008F99 8B 2D            [24] 2246 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008F9B 8F 02            [24] 2247 	mov	ar2,r7
      008F9D 7F 00            [12] 2248 	mov	r7,#0x00
      008F9F 74 01            [12] 2249 	mov	a,#0x01
      008FA1 2A               [12] 2250 	add	a, r2
      008FA2 FB               [12] 2251 	mov	r3,a
      008FA3 E4               [12] 2252 	clr	a
      008FA4 3F               [12] 2253 	addc	a, r7
      008FA5 FC               [12] 2254 	mov	r4,a
      008FA6 EB               [12] 2255 	mov	a,r3
      008FA7 28               [12] 2256 	add	a, r0
      008FA8 F5 82            [12] 2257 	mov	dpl,a
      008FAA EC               [12] 2258 	mov	a,r4
      008FAB 39               [12] 2259 	addc	a, r1
      008FAC F5 83            [12] 2260 	mov	dph,a
      008FAE E0               [24] 2261 	movx	a,@dptr
      008FAF FC               [12] 2262 	mov	r4,a
      008FB0 7B 00            [12] 2263 	mov	r3,#0x00
      008FB2 E5 2E            [12] 2264 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008FB4 42 03            [12] 2265 	orl	ar3,a
                                   2266 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008FB6 BC 00 12         [24] 2267 	cjne	r4,#0x00,00123$
      008FB9 BB 7C 0F         [24] 2268 	cjne	r3,#0x7c,00123$
                                   2269 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008FBC 12 38 A7         [24] 2270 	lcall	_ak820_outline_0140
      008FBF 74 FF            [12] 2271 	mov	a,#0xff
      008FC1 F0               [24] 2272 	movx	@dptr,a
                                   2273 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008FC2 0A               [12] 2274 	inc	r2
      008FC3 BA 00 01         [24] 2275 	cjne	r2,#0x00,00218$
      008FC6 0F               [12] 2276 	inc	r7
      008FC7                       2277 00218$:
      008FC7 EA               [12] 2278 	mov	a,r2
      008FC8 12 94 24         [24] 2279 	lcall	_ak820_outline_0135
      008FCB                       2280 00123$:
                                   2281 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008FCB 90 0B FB         [24] 2282 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008FCE E0               [24] 2283 	movx	a,@dptr
      008FCF 24 02            [12] 2284 	add	a,#0x02
      008FD1 F0               [24] 2285 	movx	@dptr,a
      008FD2 80 A9            [24] 2286 	sjmp	00122$
      008FD4                       2287 00120$:
                                   2288 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008FD4 90 0B F7         [24] 2289 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008FD7 12 38 2E         [24] 2290 	lcall	_ak820_outline_0059
      008FDA 74 40            [12] 2291 	mov	a,#0x40
      008FDC 2E               [12] 2292 	add	a, r6
      008FDD FE               [12] 2293 	mov	r6,a
      008FDE E4               [12] 2294 	clr	a
      008FDF 3F               [12] 2295 	addc	a, r7
      008FE0 FF               [12] 2296 	mov	r7,a
      008FE1 90 05 8E         [24] 2297 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008FE4 12 49 18         [24] 2298 	lcall	_ak820_outline_0066
      008FE7 E4               [12] 2299 	clr	a
      008FE8 A3               [24] 2300 	inc	dptr
      008FE9 F0               [24] 2301 	movx	@dptr,a
      008FEA 90 05 91         [24] 2302 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008FED E5 2F            [12] 2303 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008FEF F0               [24] 2304 	movx	@dptr,a
      008FF0 E5 30            [12] 2305 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008FF2 A3               [24] 2306 	inc	dptr
      008FF3 F0               [24] 2307 	movx	@dptr,a
      008FF4 12 38 B1         [24] 2308 	lcall	_ak820_outline_0153
                                   2309 ;	quantum/dynamic_keymap.c:584: }
      008FF7 02 41 39         [24] 2310 	ljmp	_ak820_eeprom_write_block_xdata
                                   2311 ;------------------------------------------------------------
                                   2312 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2313 ;------------------------------------------------------------
                                   2314 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2315 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2316 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_453'
                                   2317 ;------------------------------------------------------------
                                   2318 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2319 ;	-----------------------------------------
                                   2320 ;	 function keycode_at_keymap_location
                                   2321 ;	-----------------------------------------
      008FFA                       2322 _keycode_at_keymap_location:
      008FFA E5 82            [12] 2323 	mov	a,dpl
      008FFC 90 0B FE         [24] 2324 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_453
      008FFF F0               [24] 2325 	movx	@dptr,a
                                   2326 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      009000 E0               [24] 2327 	movx	a,@dptr
      009001 FF               [12] 2328 	mov	r7,a
      009002 BF 06 00         [24] 2329 	cjne	r7,#0x06,00128$
      009005                       2330 00128$:
      009005 50 23            [24] 2331 	jnc	00102$
      009007 90 0B FC         [24] 2332 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      00900A E0               [24] 2333 	movx	a,@dptr
      00900B FE               [12] 2334 	mov	r6,a
      00900C BE 10 00         [24] 2335 	cjne	r6,#0x10,00130$
      00900F                       2336 00130$:
      00900F 50 19            [24] 2337 	jnc	00102$
      009011 90 0B FD         [24] 2338 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      009014 E0               [24] 2339 	movx	a,@dptr
      009015 FD               [12] 2340 	mov	r5,a
      009016 BD 08 00         [24] 2341 	cjne	r5,#0x08,00132$
      009019                       2342 00132$:
      009019 50 0F            [24] 2343 	jnc	00102$
                                   2344 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      00901B 90 0B 9E         [24] 2345 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00901E EE               [12] 2346 	mov	a,r6
      00901F F0               [24] 2347 	movx	@dptr,a
      009020 90 0B 9F         [24] 2348 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      009023 ED               [12] 2349 	mov	a,r5
      009024 F0               [24] 2350 	movx	@dptr,a
      009025 8F 82            [24] 2351 	mov	dpl, r7
      009027 02 88 4B         [24] 2352 	ljmp	_dynamic_keymap_get_keycode
      00902A                       2353 00102$:
                                   2354 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      00902A 90 00 00         [24] 2355 	mov	dptr,#0x0000
                                   2356 ;	quantum/dynamic_keymap.c:591: }
      00902D 22               [24] 2357 	ret
                                   2358 ;------------------------------------------------------------
                                   2359 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2360 ;------------------------------------------------------------
                                   2361 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2362 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2363 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_457'
                                   2364 ;------------------------------------------------------------
                                   2365 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2366 ;	-----------------------------------------
                                   2367 ;	 function keycode_at_encodermap_location
                                   2368 ;	-----------------------------------------
      00902E                       2369 _keycode_at_encodermap_location:
      00902E E5 82            [12] 2370 	mov	a,dpl
      009030 90 0C 01         [24] 2371 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_457
      009033 F0               [24] 2372 	movx	@dptr,a
                                   2373 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      009034 E0               [24] 2374 	movx	a,@dptr
      009035 FF               [12] 2375 	mov	r7,a
      009036 BF 06 00         [24] 2376 	cjne	r7,#0x06,00120$
      009039                       2377 00120$:
      009039 50 1E            [24] 2378 	jnc	00102$
      00903B 90 0B FF         [24] 2379 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      00903E E0               [24] 2380 	movx	a,@dptr
      00903F FE               [12] 2381 	mov	r6,a
      009040 BE 01 00         [24] 2382 	cjne	r6,#0x01,00122$
      009043                       2383 00122$:
      009043 50 14            [24] 2384 	jnc	00102$
                                   2385 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      009045 90 0C 00         [24] 2386 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      009048 E0               [24] 2387 	movx	a,@dptr
      009049 FE               [12] 2388 	mov	r6,a
      00904A 90 0B A8         [24] 2389 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00904D E4               [12] 2390 	clr	a
      00904E F0               [24] 2391 	movx	@dptr,a
      00904F 90 0B A9         [24] 2392 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      009052 EE               [12] 2393 	mov	a,r6
      009053 F0               [24] 2394 	movx	@dptr,a
      009054 8F 82            [24] 2395 	mov	dpl, r7
      009056 02 89 08         [24] 2396 	ljmp	_dynamic_keymap_get_encoder
      009059                       2397 00102$:
                                   2398 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      009059 90 00 00         [24] 2399 	mov	dptr,#0x0000
                                   2400 ;	quantum/dynamic_keymap.c:599: }
      00905C 22               [24] 2401 	ret
                                   2402 ;------------------------------------------------------------
                                   2403 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2404 ;------------------------------------------------------------
                                   2405 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2406 ;	-----------------------------------------
                                   2407 ;	 function dynamic_keymap_macro_get_count
                                   2408 ;	-----------------------------------------
      00905D                       2409 _dynamic_keymap_macro_get_count:
                                   2410 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      00905D 75 82 10         [24] 2411 	mov	dpl, #0x10
                                   2412 ;	quantum/dynamic_keymap.c:604: }
      009060 22               [24] 2413 	ret
                                   2414 ;------------------------------------------------------------
                                   2415 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2416 ;------------------------------------------------------------
                                   2417 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2418 ;	-----------------------------------------
                                   2419 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2420 ;	-----------------------------------------
      009061                       2421 _dynamic_keymap_macro_get_buffer_size:
                                   2422 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      009061 90 20 00         [24] 2423 	mov	dptr,#0x2000
                                   2424 ;	quantum/dynamic_keymap.c:608: }
      009064 22               [24] 2425 	ret
                                   2426 ;------------------------------------------------------------
                                   2427 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2428 ;------------------------------------------------------------
                                   2429 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2430 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2431 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2432 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_465'
                                   2433 ;------------------------------------------------------------
                                   2434 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2435 ;	-----------------------------------------
                                   2436 ;	 function dynamic_keymap_macro_get_buffer
                                   2437 ;	-----------------------------------------
      009065                       2438 _dynamic_keymap_macro_get_buffer:
      009065 12 38 7A         [24] 2439 	lcall	_ak820_outline_0106
      009068 90 0C 07         [24] 2440 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      00906B 12 38 75         [24] 2441 	lcall	_ak820_outline_0105
                                   2442 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      00906E 12 2B 2B         [24] 2443 	lcall	_ak820_macro_length
      009071 12 43 67         [24] 2444 	lcall	_ak820_outline_0139
      009074 90 0C 07         [24] 2445 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      009077 12 38 45         [24] 2446 	lcall	_ak820_outline_0065
      00907A 90 0C 02         [24] 2447 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00907D E0               [24] 2448 	movx	a,@dptr
      00907E F5 32            [12] 2449 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      009080 A3               [24] 2450 	inc	dptr
      009081 E0               [24] 2451 	movx	a,@dptr
      009082 F5 33            [12] 2452 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      009084 90 0C 04         [24] 2453 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      009087 12 38 63         [24] 2454 	lcall	_ak820_outline_0098
      00908A A3               [24] 2455 	inc	dptr
      00908B E0               [24] 2456 	movx	a,@dptr
      00908C FB               [12] 2457 	mov	r3,a
      00908D 90 0B DF         [24] 2458 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      009090 12 49 18         [24] 2459 	lcall	_ak820_outline_0066
      009093 90 0B E1         [24] 2460 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      009096 12 38 51         [24] 2461 	lcall	_ak820_outline_0079
      009099 90 0B E3         [24] 2462 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00909C E5 32            [12] 2463 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      00909E F0               [24] 2464 	movx	@dptr,a
      00909F E5 33            [12] 2465 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      0090A1 A3               [24] 2466 	inc	dptr
      0090A2 F0               [24] 2467 	movx	@dptr,a
      0090A3 90 0B E5         [24] 2468 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0090A6 E8               [12] 2469 	mov	a,r0
      0090A7 F0               [24] 2470 	movx	@dptr,a
      0090A8 E9               [12] 2471 	mov	a,r1
      0090A9 A3               [24] 2472 	inc	dptr
      0090AA 12 49 35         [24] 2473 	lcall	_ak820_outline_0162
      0090AD 90 08 00         [24] 2474 	mov	dptr,#0x0800
                                   2475 ;	quantum/dynamic_keymap.c:635: }
      0090B0 02 8D 6F         [24] 2476 	ljmp	_ak820_dynamic_read_buffer
                                   2477 ;------------------------------------------------------------
                                   2478 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2479 ;------------------------------------------------------------
                                   2480 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2481 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2482 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_467'
                                   2483 ;------------------------------------------------------------
                                   2484 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2485 ;	-----------------------------------------
                                   2486 ;	 function dynamic_keymap_macro_set_buffer
                                   2487 ;	-----------------------------------------
      0090B3                       2488 _dynamic_keymap_macro_set_buffer:
      0090B3 12 38 7A         [24] 2489 	lcall	_ak820_outline_0106
      0090B6 90 0C 0E         [24] 2490 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      0090B9 12 38 75         [24] 2491 	lcall	_ak820_outline_0105
                                   2492 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      0090BC 90 0C 0E         [24] 2493 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      0090BF 12 38 2E         [24] 2494 	lcall	_ak820_outline_0059
      0090C2 90 0C 09         [24] 2495 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      0090C5 12 38 45         [24] 2496 	lcall	_ak820_outline_0065
      0090C8 90 0C 0B         [24] 2497 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      0090CB E0               [24] 2498 	movx	a,@dptr
      0090CC F9               [12] 2499 	mov	r1,a
      0090CD A3               [24] 2500 	inc	dptr
      0090CE 12 43 4F         [24] 2501 	lcall	_ak820_outline_0084
      0090D1 90 05 14         [24] 2502 	mov	dptr,#_ak820_macro_write_PARM_2
      0090D4 12 38 51         [24] 2503 	lcall	_ak820_outline_0079
      0090D7 90 05 16         [24] 2504 	mov	dptr,#_ak820_macro_write_PARM_3
      0090DA E9               [12] 2505 	mov	a,r1
      0090DB F0               [24] 2506 	movx	@dptr,a
      0090DC EA               [12] 2507 	mov	a,r2
      0090DD A3               [24] 2508 	inc	dptr
      0090DE F0               [24] 2509 	movx	@dptr,a
      0090DF EB               [12] 2510 	mov	a,r3
      0090E0 12 43 35         [24] 2511 	lcall	_ak820_outline_0064
                                   2512 ;	quantum/dynamic_keymap.c:640: }
      0090E3 02 2B 45         [24] 2513 	ljmp	_ak820_macro_write
                                   2514 ;------------------------------------------------------------
                                   2515 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2516 ;------------------------------------------------------------
                                   2517 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2518 ;	-----------------------------------------
                                   2519 ;	 function dynamic_keymap_macro_reset
                                   2520 ;	-----------------------------------------
      0090E6                       2521 _dynamic_keymap_macro_reset:
                                   2522 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2523 ;	quantum/dynamic_keymap.c:666: }
      0090E6 02 2E 64         [24] 2524 	ljmp	_ak820_macro_reset
                                   2525 ;------------------------------------------------------------
                                   2526 ;Allocation info for local variables in function 'decode_keycode'
                                   2527 ;------------------------------------------------------------
                                   2528 ;kc            Allocated with name '_decode_keycode_kc_10000_471'
                                   2529 ;------------------------------------------------------------
                                   2530 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2531 ;	-----------------------------------------
                                   2532 ;	 function decode_keycode
                                   2533 ;	-----------------------------------------
      0090E9                       2534 _decode_keycode:
      0090E9 12 38 7A         [24] 2535 	lcall	_ak820_outline_0106
      0090EC 90 0C 10         [24] 2536 	mov	dptr,#_decode_keycode_kc_10000_471
      0090EF 12 38 75         [24] 2537 	lcall	_ak820_outline_0105
                                   2538 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      0090F2 90 0C 10         [24] 2539 	mov	dptr,#_decode_keycode_kc_10000_471
      0090F5 12 4D DC         [24] 2540 	lcall	_ak820_outline_0012
      0090F8 C3               [12] 2541 	clr	c
      0090F9 E4               [12] 2542 	clr	a
      0090FA 9C               [12] 2543 	subb	a,r4
      0090FB 74 FF            [12] 2544 	mov	a,#0xff
      0090FD 9D               [12] 2545 	subb	a,r5
      0090FE 50 08            [24] 2546 	jnc	00102$
                                   2547 ;	free result
                                   2548 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      009100 8C 05            [24] 2549 	mov	ar5,r4
      009102 7C 00            [12] 2550 	mov	r4,#0x00
      009104 12 38 98         [24] 2551 	lcall	_ak820_outline_0129
      009107 22               [24] 2552 	ret
      009108                       2553 00102$:
                                   2554 ;	quantum/dynamic_keymap.c:672: return kc;
      009108 12 38 8D         [24] 2555 	lcall	_ak820_outline_0121
                                   2556 ;	quantum/dynamic_keymap.c:673: }
      00910B 22               [24] 2557 	ret
                                   2558 ;------------------------------------------------------------
                                   2559 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2560 ;------------------------------------------------------------
                                   2561 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_474'
                                   2562 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_475'
                                   2563 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_480'
                                   2564 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_481'
                                   2565 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_487'
                                   2566 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_505'
                                   2567 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_509'
                                   2568 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_509'
                                   2569 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_511'
                                   2570 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_513'
                                   2571 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_517'
                                   2572 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_519'
                                   2573 ;------------------------------------------------------------
                                   2574 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2575 ;	-----------------------------------------
                                   2576 ;	 function dynamic_keymap_macro_send
                                   2577 ;	-----------------------------------------
      00910C                       2578 _dynamic_keymap_macro_send:
      00910C E5 82            [12] 2579 	mov	a,dpl
      00910E 90 0C 12         [24] 2580 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      009111 F0               [24] 2581 	movx	@dptr,a
                                   2582 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      009112 90 0C 13         [24] 2583 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      009115 E0               [24] 2584 	movx	a,@dptr
      009116 60 01            [24] 2585 	jz	00102$
      009118 22               [24] 2586 	ret
      009119                       2587 00102$:
                                   2588 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      009119 90 0C 12         [24] 2589 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      00911C E0               [24] 2590 	movx	a,@dptr
      00911D FF               [12] 2591 	mov	r7,a
      00911E BF 10 00         [24] 2592 	cjne	r7,#0x10,00422$
      009121                       2593 00422$:
      009121 40 01            [24] 2594 	jc	00104$
                                   2595 ;	quantum/dynamic_keymap.c:683: return;
      009123 22               [24] 2596 	ret
      009124                       2597 00104$:
                                   2598 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      009124 C0 07            [24] 2599 	push	ar7
      009126 12 2A F2         [24] 2600 	lcall	_ak820_macro_ready
      009129 E5 82            [12] 2601 	mov	a, dpl
      00912B D0 07            [24] 2602 	pop	ar7
      00912D 70 01            [24] 2603 	jnz	00106$
      00912F 22               [24] 2604 	ret
      009130                       2605 00106$:
                                   2606 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      009130 90 0C 14         [24] 2607 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009133 E4               [12] 2608 	clr	a
      009134 F0               [24] 2609 	movx	@dptr,a
      009135 74 08            [12] 2610 	mov	a,#0x08
      009137 A3               [24] 2611 	inc	dptr
      009138 F0               [24] 2612 	movx	@dptr,a
                                   2613 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      009139 C0 07            [24] 2614 	push	ar7
      00913B 12 2B 2B         [24] 2615 	lcall	_ak820_macro_length
      00913E AD 82            [24] 2616 	mov	r5, dpl
      009140 AE 83            [24] 2617 	mov	r6, dph
      009142 D0 07            [24] 2618 	pop	ar7
      009144 74 08            [12] 2619 	mov	a,#0x08
      009146 2E               [12] 2620 	add	a, r6
      009147 FE               [12] 2621 	mov	r6,a
                                   2622 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      009148 7B 00            [12] 2623 	mov	r3,#0x00
      00914A 7C 08            [12] 2624 	mov	r4,#0x08
      00914C                       2625 00111$:
      00914C EF               [12] 2626 	mov	a,r7
      00914D 60 31            [24] 2627 	jz	00113$
                                   2628 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      00914F EB               [12] 2629 	mov	a,r3
      009150 B5 05 05         [24] 2630 	cjne	a,ar5,00108$
      009153 EC               [12] 2631 	mov	a,r4
      009154 B5 06 01         [24] 2632 	cjne	a,ar6,00108$
                                   2633 ;	quantum/dynamic_keymap.c:717: return;
      009157 22               [24] 2634 	ret
      009158                       2635 00108$:
                                   2636 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      009158 8B 01            [24] 2637 	mov	ar1,r3
      00915A 8C 02            [24] 2638 	mov	ar2,r4
      00915C 8A 00            [24] 2639 	mov	ar0,r2
      00915E 7A 00            [12] 2640 	mov	r2,#0x00
      009160 89 82            [24] 2641 	mov	dpl, r1
      009162 88 83            [24] 2642 	mov	dph, r0
      009164 8A F0            [24] 2643 	mov	b, r2
      009166 12 40 72         [24] 2644 	lcall	_eeprom_read_byte
      009169 E5 82            [12] 2645 	mov	a, dpl
      00916B 70 06            [24] 2646 	jnz	00110$
                                   2647 ;	quantum/dynamic_keymap.c:720: --id;
      00916D 1F               [12] 2648 	dec	r7
      00916E 90 0C 12         [24] 2649 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      009171 EF               [12] 2650 	mov	a,r7
      009172 F0               [24] 2651 	movx	@dptr,a
      009173                       2652 00110$:
                                   2653 ;	quantum/dynamic_keymap.c:722: ++p;
      009173 0B               [12] 2654 	inc	r3
      009174 BB 00 01         [24] 2655 	cjne	r3,#0x00,00429$
      009177 0C               [12] 2656 	inc	r4
      009178                       2657 00429$:
      009178 90 0C 14         [24] 2658 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00917B 12 38 57         [24] 2659 	lcall	_ak820_outline_0082
      00917E 80 CC            [24] 2660 	sjmp	00111$
      009180                       2661 00113$:
                                   2662 ;	quantum/dynamic_keymap.c:728: sending = true;
      009180 90 0C 13         [24] 2663 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      009183 74 01            [12] 2664 	mov	a,#0x01
      009185 F0               [24] 2665 	movx	@dptr,a
                                   2666 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      009186 12 94 3C         [24] 2667 	lcall	_ak820_outline_0168
      009189 90 0A 4A         [24] 2668 	mov	dptr,#_ak820_macro_cancelled
      00918C F0               [24] 2669 	movx	@dptr,a
                                   2670 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      00918D 90 0C 16         [24] 2671 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009190 F0               [24] 2672 	movx	@dptr,a
      009191 90 0C 17         [24] 2673 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009194 F0               [24] 2674 	movx	@dptr,a
      009195 90 0C 18         [24] 2675 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      009198 F0               [24] 2676 	movx	@dptr,a
      009199 90 0C 19         [24] 2677 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      00919C F0               [24] 2678 	movx	@dptr,a
                                   2679 ;	quantum/dynamic_keymap.c:738: while (p < end
      00919D                       2680 00167$:
                                   2681 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      00919D 90 0C 14         [24] 2682 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0091A0 E0               [24] 2683 	movx	a,@dptr
      0091A1 FC               [12] 2684 	mov	r4,a
      0091A2 A3               [24] 2685 	inc	dptr
      0091A3 E0               [24] 2686 	movx	a,@dptr
      0091A4 FF               [12] 2687 	mov	r7,a
      0091A5 C3               [12] 2688 	clr	c
      0091A6 EC               [12] 2689 	mov	a,r4
      0091A7 9D               [12] 2690 	subb	a,r5
      0091A8 EF               [12] 2691 	mov	a,r7
      0091A9 9E               [12] 2692 	subb	a,r6
      0091AA 40 02            [24] 2693 	jc	00430$
      0091AC 61 AE            [12] 2694 	ajmp	00169$
      0091AE                       2695 00430$:
      0091AE 90 0A 4A         [24] 2696 	mov	dptr,#_ak820_macro_cancelled
      0091B1 E0               [24] 2697 	movx	a,@dptr
      0091B2 60 02            [24] 2698 	jz	00431$
      0091B4 61 AE            [12] 2699 	ajmp	00169$
      0091B6                       2700 00431$:
                                   2701 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091B6 8C 02            [24] 2702 	mov	ar2,r4
      0091B8 8F 03            [24] 2703 	mov	ar3,r7
      0091BA 90 0C 14         [24] 2704 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0091BD 74 01            [12] 2705 	mov	a,#0x01
      0091BF 2C               [12] 2706 	add	a, r4
      0091C0 F0               [24] 2707 	movx	@dptr,a
      0091C1 E4               [12] 2708 	clr	a
      0091C2 3F               [12] 2709 	addc	a, r7
      0091C3 A3               [24] 2710 	inc	dptr
      0091C4 F0               [24] 2711 	movx	@dptr,a
      0091C5 7F 00            [12] 2712 	mov	r7,#0x00
      0091C7 12 38 A2         [24] 2713 	lcall	_ak820_outline_0131
      0091CA 8F F0            [24] 2714 	mov	b, r7
      0091CC 12 40 72         [24] 2715 	lcall	_eeprom_read_byte
      0091CF AF 82            [24] 2716 	mov	r7, dpl
      0091D1 90 0C 16         [24] 2717 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      0091D4 EF               [12] 2718 	mov	a,r7
      0091D5 F0               [24] 2719 	movx	@dptr,a
                                   2720 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      0091D6 90 0C 17         [24] 2721 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      0091D9 E4               [12] 2722 	clr	a
      0091DA F0               [24] 2723 	movx	@dptr,a
                                   2724 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      0091DB 90 0C 16         [24] 2725 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      0091DE E0               [24] 2726 	movx	a,@dptr
      0091DF 70 02            [24] 2727 	jnz	00432$
      0091E1 61 AE            [12] 2728 	ajmp	00169$
      0091E3                       2729 00432$:
                                   2730 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      0091E3 90 0C 16         [24] 2731 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      0091E6 E0               [24] 2732 	movx	a,@dptr
      0091E7 FF               [12] 2733 	mov	r7,a
      0091E8 BF 01 02         [24] 2734 	cjne	r7,#0x01,00433$
      0091EB 80 02            [24] 2735 	sjmp	00434$
      0091ED                       2736 00433$:
      0091ED 61 91            [12] 2737 	ajmp	00164$
      0091EF                       2738 00434$:
                                   2739 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091EF 12 93 B6         [24] 2740 	lcall	_ak820_outline_0000
      0091F2 12 40 72         [24] 2741 	lcall	_eeprom_read_byte
      0091F5 AF 82            [24] 2742 	mov	r7, dpl
      0091F7 90 0C 17         [24] 2743 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      0091FA EF               [12] 2744 	mov	a,r7
      0091FB F0               [24] 2745 	movx	@dptr,a
                                   2746 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      0091FC EF               [12] 2747 	mov	a,r7
      0091FD 70 02            [24] 2748 	jnz	00435$
      0091FF 61 AE            [12] 2749 	ajmp	00169$
      009201                       2750 00435$:
                                   2751 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      009201 12 94 03         [24] 2752 	lcall	_ak820_outline_0096
      009204 BF 01 02         [24] 2753 	cjne	r7,#0x01,00436$
      009207 80 12            [24] 2754 	sjmp	00151$
      009209                       2755 00436$:
      009209 12 94 03         [24] 2756 	lcall	_ak820_outline_0096
      00920C BF 02 02         [24] 2757 	cjne	r7,#0x02,00437$
      00920F 80 0A            [24] 2758 	sjmp	00151$
      009211                       2759 00437$:
      009211 12 94 03         [24] 2760 	lcall	_ak820_outline_0096
      009214 BF 03 02         [24] 2761 	cjne	r7,#0x03,00438$
      009217 80 02            [24] 2762 	sjmp	00439$
      009219                       2763 00438$:
      009219 41 7A            [12] 2764 	ajmp	00152$
      00921B                       2765 00439$:
      00921B                       2766 00151$:
                                   2767 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00921B 12 93 B6         [24] 2768 	lcall	_ak820_outline_0000
      00921E 12 40 72         [24] 2769 	lcall	_eeprom_read_byte
      009221 12 94 54         [24] 2770 	lcall	_ak820_outline_0186
                                   2771 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      009224 70 02            [24] 2772 	jnz	00440$
      009226 21 9D            [12] 2773 	ajmp	00167$
      009228                       2774 00440$:
                                   2775 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      009228 12 94 03         [24] 2776 	lcall	_ak820_outline_0096
      00922B BF 01 03         [24] 2777 	cjne	r7,#0x01,00441$
      00922E D3               [12] 2778 	setb	c
      00922F 80 01            [24] 2779 	sjmp	00442$
      009231                       2780 00441$:
      009231 C3               [12] 2781 	clr	c
      009232                       2782 00442$:
      009232 92 27            [24] 2783 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009234 90 0A 49         [24] 2784 	mov	dptr,#_ak820_macro_primitive
      009237 B3               [12] 2785 	cpl	c
      009238 E4               [12] 2786 	clr	a
      009239 33               [12] 2787 	rlc	a
      00923A F0               [24] 2788 	movx	@dptr,a
                                   2789 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      00923B 12 94 03         [24] 2790 	lcall	_ak820_outline_0096
      00923E BF 01 10         [24] 2791 	cjne	r7,#0x01,00122$
      009241 12 94 35         [24] 2792 	lcall	_ak820_outline_0156
      009244 C0 06            [24] 2793 	push	ar6
      009246 C0 05            [24] 2794 	push	ar5
      009248 12 7A EC         [24] 2795 	lcall	_tap_code
      00924B D0 05            [24] 2796 	pop	ar5
      00924D D0 06            [24] 2797 	pop	ar6
      00924F 80 24            [24] 2798 	sjmp	00123$
      009251                       2799 00122$:
                                   2800 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      009251 12 94 03         [24] 2801 	lcall	_ak820_outline_0096
      009254 BF 02 10         [24] 2802 	cjne	r7,#0x02,00119$
      009257 12 94 35         [24] 2803 	lcall	_ak820_outline_0156
      00925A C0 06            [24] 2804 	push	ar6
      00925C C0 05            [24] 2805 	push	ar5
      00925E 12 79 E8         [24] 2806 	lcall	_register_code
      009261 D0 05            [24] 2807 	pop	ar5
      009263 D0 06            [24] 2808 	pop	ar6
      009265 80 0E            [24] 2809 	sjmp	00123$
      009267                       2810 00119$:
                                   2811 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      009267 12 94 35         [24] 2812 	lcall	_ak820_outline_0156
      00926A C0 06            [24] 2813 	push	ar6
      00926C C0 05            [24] 2814 	push	ar5
      00926E 12 7A 55         [24] 2815 	lcall	_unregister_code
      009271 D0 05            [24] 2816 	pop	ar5
      009273 D0 06            [24] 2817 	pop	ar6
      009275                       2818 00123$:
                                   2819 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      009275 12 94 3C         [24] 2820 	lcall	_ak820_outline_0168
      009278 21 9D            [12] 2821 	ajmp	00167$
      00927A                       2822 00152$:
                                   2823 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      00927A 12 94 03         [24] 2824 	lcall	_ak820_outline_0096
      00927D BF 05 02         [24] 2825 	cjne	r7,#0x05,00447$
      009280 80 12            [24] 2826 	sjmp	00146$
      009282                       2827 00447$:
      009282 12 94 03         [24] 2828 	lcall	_ak820_outline_0096
      009285 BF 06 02         [24] 2829 	cjne	r7,#0x06,00448$
      009288 80 0A            [24] 2830 	sjmp	00146$
      00928A                       2831 00448$:
      00928A 12 94 03         [24] 2832 	lcall	_ak820_outline_0096
      00928D BF 07 02         [24] 2833 	cjne	r7,#0x07,00449$
      009290 80 02            [24] 2834 	sjmp	00450$
      009292                       2835 00449$:
      009292 61 33            [12] 2836 	ajmp	00147$
      009294                       2837 00450$:
      009294                       2838 00146$:
                                   2839 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009294 12 93 B6         [24] 2840 	lcall	_ak820_outline_0000
      009297 12 40 72         [24] 2841 	lcall	_eeprom_read_byte
      00929A 12 94 54         [24] 2842 	lcall	_ak820_outline_0186
                                   2843 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      00929D 70 02            [24] 2844 	jnz	00451$
      00929F 21 9D            [12] 2845 	ajmp	00167$
      0092A1                       2846 00451$:
                                   2847 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092A1 12 93 B6         [24] 2848 	lcall	_ak820_outline_0000
      0092A4 12 40 72         [24] 2849 	lcall	_eeprom_read_byte
      0092A7 AF 82            [24] 2850 	mov	r7, dpl
      0092A9 90 0C 19         [24] 2851 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      0092AC EF               [12] 2852 	mov	a,r7
      0092AD F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      0092AE EF               [12] 2855 	mov	a,r7
      0092AF 70 02            [24] 2856 	jnz	00452$
      0092B1 21 9D            [12] 2857 	ajmp	00167$
      0092B3                       2858 00452$:
                                   2859 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      0092B3 90 0C 18         [24] 2860 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      0092B6 E0               [24] 2861 	movx	a,@dptr
      0092B7 FF               [12] 2862 	mov	r7,a
      0092B8 90 0C 19         [24] 2863 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      0092BB E0               [24] 2864 	movx	a,@dptr
      0092BC FB               [12] 2865 	mov	r3,a
      0092BD E4               [12] 2866 	clr	a
      0092BE FC               [12] 2867 	mov	r4,a
      0092BF FA               [12] 2868 	mov	r2,a
      0092C0 EF               [12] 2869 	mov	a,r7
      0092C1 42 04            [12] 2870 	orl	ar4,a
      0092C3 EA               [12] 2871 	mov	a,r2
      0092C4 42 03            [12] 2872 	orl	ar3,a
                                   2873 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      0092C6 12 43 8D         [24] 2874 	lcall	_ak820_outline_0187
      0092C9 C0 06            [24] 2875 	push	ar6
      0092CB C0 05            [24] 2876 	push	ar5
      0092CD 11 E9            [12] 2877 	acall	_decode_keycode
      0092CF AC 82            [24] 2878 	mov	r4, dpl
      0092D1 AF 83            [24] 2879 	mov	r7, dph
      0092D3 D0 05            [24] 2880 	pop	ar5
      0092D5 D0 06            [24] 2881 	pop	ar6
                                   2882 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      0092D7 90 0C 17         [24] 2883 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      0092DA E0               [24] 2884 	movx	a,@dptr
      0092DB FB               [12] 2885 	mov	r3,a
      0092DC BB 05 03         [24] 2886 	cjne	r3,#0x05,00453$
      0092DF D3               [12] 2887 	setb	c
      0092E0 80 01            [24] 2888 	sjmp	00454$
      0092E2                       2889 00453$:
      0092E2 C3               [12] 2890 	clr	c
      0092E3                       2891 00454$:
      0092E3 92 27            [24] 2892 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0092E5 90 0A 49         [24] 2893 	mov	dptr,#_ak820_macro_primitive
      0092E8 B3               [12] 2894 	cpl	c
      0092E9 E4               [12] 2895 	clr	a
      0092EA 33               [12] 2896 	rlc	a
      0092EB F0               [24] 2897 	movx	@dptr,a
                                   2898 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      0092EC 90 0C 17         [24] 2899 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      0092EF E0               [24] 2900 	movx	a,@dptr
      0092F0 FB               [12] 2901 	mov	r3,a
      0092F1 BB 05 02         [24] 2902 	cjne	r3,#0x05,00455$
      0092F4 80 0A            [24] 2903 	sjmp	00126$
      0092F6                       2904 00455$:
      0092F6 BB 06 02         [24] 2905 	cjne	r3,#0x06,00456$
      0092F9 80 15            [24] 2906 	sjmp	00127$
      0092FB                       2907 00456$:
                                   2908 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      0092FB BB 07 30         [24] 2909 	cjne	r3,#0x07,00129$
      0092FE 80 20            [24] 2910 	sjmp	00128$
      009300                       2911 00126$:
                                   2912 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      009300 12 49 40         [24] 2913 	lcall	_ak820_outline_0188
      009303 C0 06            [24] 2914 	push	ar6
      009305 C0 05            [24] 2915 	push	ar5
      009307 12 B8 1B         [24] 2916 	lcall	_vial_keycode_tap
      00930A D0 05            [24] 2917 	pop	ar5
      00930C D0 06            [24] 2918 	pop	ar6
                                   2919 ;	quantum/dynamic_keymap.c:795: break;
                                   2920 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      00930E 80 1E            [24] 2921 	sjmp	00129$
      009310                       2922 00127$:
                                   2923 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      009310 12 49 40         [24] 2924 	lcall	_ak820_outline_0188
      009313 C0 06            [24] 2925 	push	ar6
      009315 C0 05            [24] 2926 	push	ar5
      009317 12 B7 50         [24] 2927 	lcall	_vial_keycode_down
      00931A D0 05            [24] 2928 	pop	ar5
      00931C D0 06            [24] 2929 	pop	ar6
                                   2930 ;	quantum/dynamic_keymap.c:798: break;
                                   2931 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      00931E 80 0E            [24] 2932 	sjmp	00129$
      009320                       2933 00128$:
                                   2934 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      009320 12 49 40         [24] 2935 	lcall	_ak820_outline_0188
      009323 C0 06            [24] 2936 	push	ar6
      009325 C0 05            [24] 2937 	push	ar5
      009327 12 B7 B6         [24] 2938 	lcall	_vial_keycode_up
      00932A D0 05            [24] 2939 	pop	ar5
      00932C D0 06            [24] 2940 	pop	ar6
                                   2941 ;	quantum/dynamic_keymap.c:802: }
      00932E                       2942 00129$:
                                   2943 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      00932E 12 94 3C         [24] 2944 	lcall	_ak820_outline_0168
      009331 21 9D            [12] 2945 	ajmp	00167$
      009333                       2946 00147$:
                                   2947 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      009333 12 94 03         [24] 2948 	lcall	_ak820_outline_0096
      009336 BF 04 02         [24] 2949 	cjne	r7,#0x04,00458$
      009339 80 02            [24] 2950 	sjmp	00459$
      00933B                       2951 00458$:
      00933B 21 9D            [12] 2952 	ajmp	00167$
      00933D                       2953 00459$:
                                   2954 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00933D 12 93 B6         [24] 2955 	lcall	_ak820_outline_0000
      009340 12 40 72         [24] 2956 	lcall	_eeprom_read_byte
      009343 AF 82            [24] 2957 	mov	r7, dpl
                                   2958 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009345 90 0C 14         [24] 2959 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009348 12 38 69         [24] 2960 	lcall	_ak820_outline_0099
      00934B 90 0C 14         [24] 2961 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00934E 74 01            [12] 2962 	mov	a,#0x01
      009350 2B               [12] 2963 	add	a, r3
      009351 F0               [24] 2964 	movx	@dptr,a
      009352 E4               [12] 2965 	clr	a
      009353 3C               [12] 2966 	addc	a, r4
      009354 A3               [24] 2967 	inc	dptr
      009355 F0               [24] 2968 	movx	@dptr,a
      009356 7A 00            [12] 2969 	mov	r2,#0x00
      009358 12 33 FC         [24] 2970 	lcall	_ak820_outline_0125
      00935B 8A F0            [24] 2971 	mov	b, r2
      00935D 12 40 72         [24] 2972 	lcall	_eeprom_read_byte
      009360 AC 82            [24] 2973 	mov	r4, dpl
                                   2974 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      009362 EF               [12] 2975 	mov	a,r7
      009363 60 49            [24] 2976 	jz	00169$
      009365 EC               [12] 2977 	mov	a,r4
      009366 60 46            [24] 2978 	jz	00169$
                                   2979 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      009368 1F               [12] 2980 	dec	r7
      009369 1C               [12] 2981 	dec	r4
      00936A EC               [12] 2982 	mov	a,r4
      00936B 75 F0 FF         [24] 2983 	mov	b,#0xff
      00936E A4               [48] 2984 	mul	ab
      00936F FC               [12] 2985 	mov	r4,a
      009370 AB F0            [24] 2986 	mov	r3,b
      009372 7A 00            [12] 2987 	mov	r2,#0x00
      009374 EC               [12] 2988 	mov	a,r4
      009375 2F               [12] 2989 	add	a, r7
      009376 FC               [12] 2990 	mov	r4,a
      009377 EB               [12] 2991 	mov	a,r3
      009378 3A               [12] 2992 	addc	a, r2
      009379 FB               [12] 2993 	mov	r3,a
                                   2994 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      00937A                       2995 00141$:
      00937A 8C 02            [24] 2996 	mov	ar2,r4
      00937C 8B 07            [24] 2997 	mov	ar7,r3
      00937E 1C               [12] 2998 	dec	r4
      00937F BC FF 01         [24] 2999 	cjne	r4,#0xff,00462$
      009382 1B               [12] 3000 	dec	r3
      009383                       3001 00462$:
      009383 EA               [12] 3002 	mov	a,r2
      009384 4F               [12] 3003 	orl	a,r7
      009385 70 02            [24] 3004 	jnz	00463$
      009387 21 9D            [12] 3005 	ajmp	00167$
      009389                       3006 00463$:
      009389 90 00 01         [24] 3007 	mov	dptr,#0x0001
      00938C 12 5D F2         [24] 3008 	lcall	_mDelaymS
      00938F 80 E9            [24] 3009 	sjmp	00141$
      009391                       3010 00164$:
                                   3011 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      009391 90 0C 16         [24] 3012 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009394 E0               [24] 3013 	movx	a,@dptr
      009395 FF               [12] 3014 	mov	r7,a
      009396 BF 80 00         [24] 3015 	cjne	r7,#0x80,00464$
      009399                       3016 00464$:
      009399 50 13            [24] 3017 	jnc	00169$
                                   3018 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      00939B 90 0C 16         [24] 3019 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      00939E E0               [24] 3020 	movx	a,@dptr
      00939F F5 82            [12] 3021 	mov	dpl,a
      0093A1 C0 06            [24] 3022 	push	ar6
      0093A3 C0 05            [24] 3023 	push	ar5
      0093A5 12 AA 31         [24] 3024 	lcall	_send_char
      0093A8 D0 05            [24] 3025 	pop	ar5
      0093AA D0 06            [24] 3026 	pop	ar6
                                   3027 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      0093AC 21 9D            [12] 3028 	ajmp	00167$
      0093AE                       3029 00169$:
                                   3030 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      0093AE 12 94 3C         [24] 3031 	lcall	_ak820_outline_0168
                                   3032 ;	quantum/dynamic_keymap.c:837: sending = false;
      0093B1 90 0C 13         [24] 3033 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      0093B4 F0               [24] 3034 	movx	@dptr,a
                                   3035 ;	quantum/dynamic_keymap.c:839: }
      0093B5 22               [24] 3036 	ret
                                   3037 	.area CSEG    (CODE)
                                   3038 	.area CONST   (CODE)
                                   3039 	.area XINIT   (CODE)
                                   3040 	.area CABS    (ABS,CODE)
                                   3041 
                                   3042 ; Experimental exact instruction outlining.
                                   3043 	.globl _ak820_outline_0000
                                   3044 	.globl _ak820_outline_0005
                                   3045 	.globl _ak820_outline_0012
                                   3046 	.globl _ak820_outline_0014
                                   3047 	.globl _ak820_outline_0020
                                   3048 	.globl _ak820_outline_0027
                                   3049 	.globl _ak820_outline_0036
                                   3050 	.globl _ak820_outline_0043
                                   3051 	.globl _ak820_outline_0052
                                   3052 	.globl _ak820_outline_0059
                                   3053 	.globl _ak820_outline_0064
                                   3054 	.globl _ak820_outline_0065
                                   3055 	.globl _ak820_outline_0066
                                   3056 	.globl _ak820_outline_0077
                                   3057 	.globl _ak820_outline_0079
                                   3058 	.globl _ak820_outline_0080
                                   3059 	.globl _ak820_outline_0082
                                   3060 	.globl _ak820_outline_0084
                                   3061 	.globl _ak820_outline_0086
                                   3062 	.globl _ak820_outline_0096
                                   3063 	.globl _ak820_outline_0098
                                   3064 	.globl _ak820_outline_0099
                                   3065 	.globl _ak820_outline_0102
                                   3066 	.globl _ak820_outline_0105
                                   3067 	.globl _ak820_outline_0106
                                   3068 	.globl _ak820_outline_0113
                                   3069 	.globl _ak820_outline_0119
                                   3070 	.globl _ak820_outline_0121
                                   3071 	.globl _ak820_outline_0125
                                   3072 	.globl _ak820_outline_0127
                                   3073 	.globl _ak820_outline_0129
                                   3074 	.globl _ak820_outline_0130
                                   3075 	.globl _ak820_outline_0131
                                   3076 	.globl _ak820_outline_0135
                                   3077 	.globl _ak820_outline_0139
                                   3078 	.globl _ak820_outline_0140
                                   3079 	.globl _ak820_outline_0141
                                   3080 	.globl _ak820_outline_0145
                                   3081 	.globl _ak820_outline_0146
                                   3082 	.globl _ak820_outline_0153
                                   3083 	.globl _ak820_outline_0154
                                   3084 	.globl _ak820_outline_0156
                                   3085 	.globl _ak820_outline_0162
                                   3086 	.globl _ak820_outline_0163
                                   3087 	.globl _ak820_outline_0168
                                   3088 	.globl _ak820_outline_0174
                                   3089 	.globl _ak820_outline_0182
                                   3090 	.globl _ak820_outline_0183
                                   3091 	.globl _ak820_outline_0186
                                   3092 	.globl _ak820_outline_0187
                                   3093 	.globl _ak820_outline_0188
                                   3094 	.globl _ak820_outline_0192
                                   3095 
                                   3096 	.area CSEG (CODE)
                                   3097 ; function ak820_outline_0000
      0093B6                       3098 _ak820_outline_0000:
      0093B6 90 0C 14         [24] 3099 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0093B9 E0               [24] 3100 	movx	a,@dptr
      0093BA FC               [12] 3101 	mov	r4,a
      0093BB A3               [24] 3102 	inc	dptr
      0093BC E0               [24] 3103 	movx	a,@dptr
      0093BD FF               [12] 3104 	mov	r7,a
      0093BE 90 0C 14         [24] 3105 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0093C1 74 01            [12] 3106 	mov	a,#0x01
      0093C3 2C               [12] 3107 	add	a,r4
      0093C4 F0               [24] 3108 	movx	@dptr,a
      0093C5 E4               [12] 3109 	clr	a
      0093C6 3F               [12] 3110 	addc	a,r7
      0093C7 A3               [24] 3111 	inc	dptr
      0093C8 F0               [24] 3112 	movx	@dptr,a
      0093C9 7B 00            [12] 3113 	mov	r3,#0x00
      0093CB 8C 82            [24] 3114 	mov	dpl,r4
      0093CD 8F 83            [24] 3115 	mov	dph,r7
      0093CF 8B F0            [24] 3116 	mov	b,r3
      0093D1 22               [24] 3117 	ret
                                   3118 
                                   3119 	.area CSEG (CODE)
                                   3120 ; function ak820_outline_0027
      0093D2                       3121 _ak820_outline_0027:
      0093D2 2D               [12] 3122 	add	a,r5
      0093D3 F9               [12] 3123 	mov	r1,a
      0093D4 E4               [12] 3124 	clr	a
      0093D5 3E               [12] 3125 	addc	a,r6
      0093D6 FA               [12] 3126 	mov	r2,a
      0093D7 8F 03            [24] 3127 	mov	ar3,r7
      0093D9 89 82            [24] 3128 	mov	dpl,r1
      0093DB 8A 83            [24] 3129 	mov	dph,r2
      0093DD 8B F0            [24] 3130 	mov	b,r3
      0093DF 22               [24] 3131 	ret
                                   3132 
                                   3133 	.area CSEG (CODE)
                                   3134 ; function ak820_outline_0043
      0093E0                       3135 _ak820_outline_0043:
      0093E0 90 0E 8C         [24] 3136 	mov	dptr,#_memset_PARM_2
      0093E3 E4               [12] 3137 	clr	a
      0093E4 F0               [24] 3138 	movx	@dptr,a
      0093E5 90 0E 8D         [24] 3139 	mov	dptr,#_memset_PARM_3
      0093E8 74 0A            [12] 3140 	mov	a,#0x0a
      0093EA F0               [24] 3141 	movx	@dptr,a
      0093EB E4               [12] 3142 	clr	a
      0093EC A3               [24] 3143 	inc	dptr
      0093ED F0               [24] 3144 	movx	@dptr,a
      0093EE 8E 82            [24] 3145 	mov	dpl,r6
      0093F0 8F 83            [24] 3146 	mov	dph,r7
      0093F2 8D F0            [24] 3147 	mov	b,r5
      0093F4 22               [24] 3148 	ret
                                   3149 
                                   3150 	.area CSEG (CODE)
                                   3151 ; function ak820_outline_0086
      0093F5                       3152 _ak820_outline_0086:
      0093F5 ED               [12] 3153 	mov	a,r5
      0093F6 75 F0 0A         [24] 3154 	mov	b,#0x0a
      0093F9 A4               [48] 3155 	mul	ab
      0093FA 24 58            [12] 3156 	add	a,#0x58
      0093FC FC               [12] 3157 	mov	r4,a
      0093FD 74 06            [12] 3158 	mov	a,#0x06
      0093FF 35 F0            [12] 3159 	addc	a,b
      009401 FD               [12] 3160 	mov	r5,a
      009402 22               [24] 3161 	ret
                                   3162 
                                   3163 	.area CSEG (CODE)
                                   3164 ; function ak820_outline_0096
      009403                       3165 _ak820_outline_0096:
      009403 90 0C 17         [24] 3166 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0001)
      009406 E0               [24] 3167 	movx	a,@dptr
      009407 FF               [12] 3168 	mov	r7,a
      009408 22               [24] 3169 	ret
                                   3170 
                                   3171 	.area CSEG (CODE)
                                   3172 ; function ak820_outline_0102
      009409                       3173 _ak820_outline_0102:
      009409 90 0B 9B         [24] 3174 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00940C EE               [12] 3175 	mov	a,r6
      00940D F0               [24] 3176 	movx	@dptr,a
      00940E 90 0B 9C         [24] 3177 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009411 ED               [12] 3178 	mov	a,r5
      009412 F0               [24] 3179 	movx	@dptr,a
      009413 8F 82            [24] 3180 	mov	dpl,r7
      009415 22               [24] 3181 	ret
                                   3182 
                                   3183 	.area CSEG (CODE)
                                   3184 ; function ak820_outline_0113
      009416                       3185 _ak820_outline_0113:
      009416 74 0A            [12] 3186 	mov	a,#0x0a
      009418 F0               [24] 3187 	movx	@dptr,a
      009419 E4               [12] 3188 	clr	a
      00941A A3               [24] 3189 	inc	dptr
      00941B F0               [24] 3190 	movx	@dptr,a
      00941C 22               [24] 3191 	ret
                                   3192 
                                   3193 	.area CSEG (CODE)
                                   3194 ; function ak820_outline_0119
      00941D                       3195 _ak820_outline_0119:
      00941D AD 82            [24] 3196 	mov	r5,dpl
      00941F AE 83            [24] 3197 	mov	r6,dph
      009421 AF F0            [24] 3198 	mov	r7,b
      009423 22               [24] 3199 	ret
                                   3200 
                                   3201 	.area CSEG (CODE)
                                   3202 ; function ak820_outline_0135
      009424                       3203 _ak820_outline_0135:
      009424 28               [12] 3204 	add	a,r0
      009425 F5 82            [12] 3205 	mov	dpl,a
      009427 EF               [12] 3206 	mov	a,r7
      009428 39               [12] 3207 	addc	a,r1
      009429 F5 83            [12] 3208 	mov	dph,a
      00942B 74 FF            [12] 3209 	mov	a,#0xff
      00942D F0               [24] 3210 	movx	@dptr,a
      00942E 22               [24] 3211 	ret
                                   3212 
                                   3213 	.area CSEG (CODE)
                                   3214 ; function ak820_outline_0141
      00942F                       3215 _ak820_outline_0141:
      00942F 2D               [12] 3216 	add	a,r5
      009430 F9               [12] 3217 	mov	r1,a
      009431 E4               [12] 3218 	clr	a
      009432 3E               [12] 3219 	addc	a,r6
      009433 FA               [12] 3220 	mov	r2,a
      009434 22               [24] 3221 	ret
                                   3222 
                                   3223 	.area CSEG (CODE)
                                   3224 ; function ak820_outline_0156
      009435                       3225 _ak820_outline_0156:
      009435 90 0C 18         [24] 3226 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      009438 E0               [24] 3227 	movx	a,@dptr
      009439 F5 82            [12] 3228 	mov	dpl,a
      00943B 22               [24] 3229 	ret
                                   3230 
                                   3231 	.area CSEG (CODE)
                                   3232 ; function ak820_outline_0168
      00943C                       3233 _ak820_outline_0168:
      00943C 90 0A 49         [24] 3234 	mov	dptr,#_ak820_macro_primitive
      00943F E4               [12] 3235 	clr	a
      009440 F0               [24] 3236 	movx	@dptr,a
      009441 22               [24] 3237 	ret
                                   3238 
                                   3239 	.area CSEG (CODE)
                                   3240 ; function ak820_outline_0182
      009442                       3241 _ak820_outline_0182:
      009442 90 0B AB         [24] 3242 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009445 E4               [12] 3243 	clr	a
      009446 F0               [24] 3244 	movx	@dptr,a
      009447 90 0B AC         [24] 3245 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00944A 22               [24] 3246 	ret
                                   3247 
                                   3248 	.area CSEG (CODE)
                                   3249 ; function ak820_outline_0183
      00944B                       3250 _ak820_outline_0183:
      00944B 90 0C 73         [24] 3251 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      00944E E4               [12] 3252 	clr	a
      00944F F0               [24] 3253 	movx	@dptr,a
      009450 90 0C 74         [24] 3254 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      009453 22               [24] 3255 	ret
                                   3256 
                                   3257 	.area CSEG (CODE)
                                   3258 ; function ak820_outline_0186
      009454                       3259 _ak820_outline_0186:
      009454 AF 82            [24] 3260 	mov	r7,dpl
      009456 90 0C 18         [24] 3261 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      009459 EF               [12] 3262 	mov	a,r7
      00945A F0               [24] 3263 	movx	@dptr,a
      00945B EF               [12] 3264 	mov	a,r7
      00945C 22               [24] 3265 	ret
