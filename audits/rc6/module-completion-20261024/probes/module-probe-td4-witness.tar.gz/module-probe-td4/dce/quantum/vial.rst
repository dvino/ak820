                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_tap_dance
                                     17 	.globl _dynamic_keymap_get_tap_dance
                                     18 	.globl _dynamic_keymap_set_encoder
                                     19 	.globl _dynamic_keymap_get_encoder
                                     20 	.globl _repeat_key_cancel
                                     21 	.globl _ak820_combo_reload
                                     22 	.globl _clear_keyboard
                                     23 	.globl _ak820_action_exec
                                     24 	.globl _timer_elapsed32
                                     25 	.globl _timer_read32
                                     26 	.globl _timer_read
                                     27 	.globl ___memcpy
                                     28 	.globl _ADC_START
                                     29 	.globl _S0_R_FIFO
                                     30 	.globl _S0_T_FIFO
                                     31 	.globl _S0_FREE
                                     32 	.globl _S0_IF_BYTE
                                     33 	.globl _S0_IF_FIRST
                                     34 	.globl _S0_IF_OV
                                     35 	.globl _S0_FST_ACT
                                     36 	.globl _CP_RL2
                                     37 	.globl _C_T2
                                     38 	.globl _TR2
                                     39 	.globl _EXEN2
                                     40 	.globl _TCLK
                                     41 	.globl _RCLK
                                     42 	.globl _EXF2
                                     43 	.globl _CAP1F
                                     44 	.globl _TF2
                                     45 	.globl _RI
                                     46 	.globl _TI
                                     47 	.globl _RB8
                                     48 	.globl _TB8
                                     49 	.globl _REN
                                     50 	.globl _SM2
                                     51 	.globl _SM1
                                     52 	.globl _SM0
                                     53 	.globl _IT0
                                     54 	.globl _IE0
                                     55 	.globl _IT1
                                     56 	.globl _IE1
                                     57 	.globl _TR0
                                     58 	.globl _TF0
                                     59 	.globl _TR1
                                     60 	.globl _TF1
                                     61 	.globl _P4_0
                                     62 	.globl _P4_1
                                     63 	.globl _P4_2
                                     64 	.globl _P4_3
                                     65 	.globl _P4_4
                                     66 	.globl _P4_5
                                     67 	.globl _P4_6
                                     68 	.globl _RXD
                                     69 	.globl _TXD
                                     70 	.globl _INT0
                                     71 	.globl _INT1
                                     72 	.globl _T0
                                     73 	.globl _T1
                                     74 	.globl _MOSI1
                                     75 	.globl _MISO1
                                     76 	.globl _SCK1
                                     77 	.globl _P3_0
                                     78 	.globl _P3_1
                                     79 	.globl _P3_2
                                     80 	.globl _P3_3
                                     81 	.globl _P3_4
                                     82 	.globl _P3_5
                                     83 	.globl _P3_6
                                     84 	.globl _P3_7
                                     85 	.globl _CAP1_
                                     86 	.globl _T2_
                                     87 	.globl _CAP2_
                                     88 	.globl _T2EX_
                                     89 	.globl _RXD1
                                     90 	.globl _TXD1
                                     91 	.globl _P2_0
                                     92 	.globl _P2_1
                                     93 	.globl _P2_2
                                     94 	.globl _P2_3
                                     95 	.globl _P2_4
                                     96 	.globl _P2_5
                                     97 	.globl _P2_6
                                     98 	.globl _P2_7
                                     99 	.globl _AIN0
                                    100 	.globl _AIN1
                                    101 	.globl _AIN2
                                    102 	.globl _AIN3
                                    103 	.globl _AIN4
                                    104 	.globl _AIN5
                                    105 	.globl _AIN6
                                    106 	.globl _AIN7
                                    107 	.globl _CAP1
                                    108 	.globl _T2
                                    109 	.globl _CAP2
                                    110 	.globl _T2EX
                                    111 	.globl _INT0_
                                    112 	.globl _SCS
                                    113 	.globl _MOSI
                                    114 	.globl _MISO
                                    115 	.globl _SCK
                                    116 	.globl _RXD1_
                                    117 	.globl _TXD1_
                                    118 	.globl _P1_0
                                    119 	.globl _P1_1
                                    120 	.globl _P1_2
                                    121 	.globl _P1_3
                                    122 	.globl _P1_4
                                    123 	.globl _P1_5
                                    124 	.globl _P1_6
                                    125 	.globl _P1_7
                                    126 	.globl _AIN8
                                    127 	.globl _AIN9
                                    128 	.globl _AIN10
                                    129 	.globl _AIN11
                                    130 	.globl _AIN12
                                    131 	.globl _AIN13
                                    132 	.globl _RXD_
                                    133 	.globl _TXD_
                                    134 	.globl _SCL0
                                    135 	.globl _SDA0
                                    136 	.globl _P0_0
                                    137 	.globl _P0_1
                                    138 	.globl _P0_2
                                    139 	.globl _P0_3
                                    140 	.globl _P0_4
                                    141 	.globl _P0_5
                                    142 	.globl _P0_6
                                    143 	.globl _P0_7
                                    144 	.globl _IE_SPI0
                                    145 	.globl _IE_USB
                                    146 	.globl _IE_ADC
                                    147 	.globl _IE_UART1
                                    148 	.globl _IE_PWM_I2C
                                    149 	.globl _IE_GPIO
                                    150 	.globl _IE_WDOG
                                    151 	.globl _PX0
                                    152 	.globl _PT0
                                    153 	.globl _PX1
                                    154 	.globl _PT1
                                    155 	.globl _PS
                                    156 	.globl _PT2
                                    157 	.globl _PL_FLAG
                                    158 	.globl _PH_FLAG
                                    159 	.globl _EX0
                                    160 	.globl _ET0
                                    161 	.globl _EX1
                                    162 	.globl _ET1
                                    163 	.globl _ES
                                    164 	.globl _ET2
                                    165 	.globl _E_DIS
                                    166 	.globl _EA
                                    167 	.globl _P
                                    168 	.globl _F1
                                    169 	.globl _OV
                                    170 	.globl _RS0
                                    171 	.globl _RS1
                                    172 	.globl _F0
                                    173 	.globl _AC
                                    174 	.globl _CY
                                    175 	.globl _I2CS_INT_ST
                                    176 	.globl _I2CX_INT
                                    177 	.globl _LED_STATUS
                                    178 	.globl _LED_DMA_H
                                    179 	.globl _LED_DMA_L
                                    180 	.globl _LED_DMA
                                    181 	.globl _LED_PWM_OE
                                    182 	.globl _LED_COMMON
                                    183 	.globl _ADC_CHAN
                                    184 	.globl _ADC_DAT_H
                                    185 	.globl _ADC_DAT_L
                                    186 	.globl _ADC_DAT
                                    187 	.globl _ADC_CTRL
                                    188 	.globl _SPI1_CK_SE
                                    189 	.globl _SPI1_CTRL
                                    190 	.globl _SPI1_DATA
                                    191 	.globl _SPI1_STAT
                                    192 	.globl _SIF1
                                    193 	.globl _SBAUD1
                                    194 	.globl _SBUF1
                                    195 	.globl _SCON1
                                    196 	.globl _SPI0_SETUP
                                    197 	.globl _SPI0_CK_SE
                                    198 	.globl _SPI0_CTRL
                                    199 	.globl _SPI0_DATA
                                    200 	.globl _SPI0_STAT
                                    201 	.globl _T2CAP1H
                                    202 	.globl _T2CAP1L
                                    203 	.globl _T2CAP1
                                    204 	.globl _TH2
                                    205 	.globl _TL2
                                    206 	.globl _T2COUNT
                                    207 	.globl _RCAP2H
                                    208 	.globl _RCAP2L
                                    209 	.globl _RCAP2
                                    210 	.globl _T2MOD
                                    211 	.globl _T2CON
                                    212 	.globl _SBUF
                                    213 	.globl _SCON
                                    214 	.globl _TH1
                                    215 	.globl _TH0
                                    216 	.globl _TL1
                                    217 	.globl _TL0
                                    218 	.globl _TMOD
                                    219 	.globl _TCON
                                    220 	.globl _XBUS_AUX
                                    221 	.globl _P7
                                    222 	.globl _P6_DIR
                                    223 	.globl _P6_OUT_PU
                                    224 	.globl _P6_IN
                                    225 	.globl _P5_DIR
                                    226 	.globl _P5_OUT_PU
                                    227 	.globl _P5_IN
                                    228 	.globl _P4_LED_KEY
                                    229 	.globl _P4_DIR_PU
                                    230 	.globl _P4_MOD_OC
                                    231 	.globl _P4
                                    232 	.globl _P3_DIR_PU
                                    233 	.globl _P3_MOD_OC
                                    234 	.globl _P3
                                    235 	.globl _P2_DIR_PU
                                    236 	.globl _P2_MOD_OC
                                    237 	.globl _P2
                                    238 	.globl _P1_DIR_PU
                                    239 	.globl _P1_MOD_OC
                                    240 	.globl _P1
                                    241 	.globl _P0_DIR_PU
                                    242 	.globl _P0_MOD_OC
                                    243 	.globl _P0
                                    244 	.globl _ROM_CTRL
                                    245 	.globl _ROM_DATA_HH
                                    246 	.globl _ROM_DATA_HL
                                    247 	.globl _ROM_DATA_HI
                                    248 	.globl _ROM_ADDR_H
                                    249 	.globl _ROM_ADDR_L
                                    250 	.globl _ROM_ADDR
                                    251 	.globl _GPIO_IE
                                    252 	.globl _IP_EX
                                    253 	.globl _IE_EX
                                    254 	.globl _IP
                                    255 	.globl _IE
                                    256 	.globl _WDOG_COUNT
                                    257 	.globl _RESET_KEEP
                                    258 	.globl _WAKE_CTRL
                                    259 	.globl _CLOCK_CFG
                                    260 	.globl _POWER_CFG
                                    261 	.globl _PCON
                                    262 	.globl _GLOBAL_CFG
                                    263 	.globl _SAFE_MOD
                                    264 	.globl _DPH
                                    265 	.globl _DPL
                                    266 	.globl _SP
                                    267 	.globl _A_INV
                                    268 	.globl _B
                                    269 	.globl _ACC
                                    270 	.globl _PSW
                                    271 	.globl _vial_unlock_in_progress
                                    272 	.globl _vial_unlocked
                                    273 	.globl _g_vial_magic_keycode_override
                                    274 	.globl _vial_handle_cmd_PARM_2
                                    275 	.globl _vial_unlock_task
                                    276 	.globl _vial_init
                                    277 	.globl _vial_handle_cmd
                                    278 	.globl _vial_keycode_down
                                    279 	.globl _vial_keycode_up
                                    280 	.globl _vial_keycode_tap
                                    281 ;--------------------------------------------------------
                                    282 ; special function registers
                                    283 ;--------------------------------------------------------
                                    284 	.area RSEG    (ABS,DATA)
      000000                        285 	.org 0x0000
                           0000D0   286 _PSW	=	0x00d0
                           0000E0   287 _ACC	=	0x00e0
                           0000F0   288 _B	=	0x00f0
                           0000FD   289 _A_INV	=	0x00fd
                           000081   290 _SP	=	0x0081
                           000082   291 _DPL	=	0x0082
                           000083   292 _DPH	=	0x0083
                           0000A1   293 _SAFE_MOD	=	0x00a1
                           0000B1   294 _GLOBAL_CFG	=	0x00b1
                           000087   295 _PCON	=	0x0087
                           0000BA   296 _POWER_CFG	=	0x00ba
                           0000B9   297 _CLOCK_CFG	=	0x00b9
                           0000A9   298 _WAKE_CTRL	=	0x00a9
                           0000FE   299 _RESET_KEEP	=	0x00fe
                           0000FF   300 _WDOG_COUNT	=	0x00ff
                           0000A8   301 _IE	=	0x00a8
                           0000B8   302 _IP	=	0x00b8
                           0000E8   303 _IE_EX	=	0x00e8
                           0000E9   304 _IP_EX	=	0x00e9
                           0000B2   305 _GPIO_IE	=	0x00b2
                           008584   306 _ROM_ADDR	=	0x8584
                           000084   307 _ROM_ADDR_L	=	0x0084
                           000085   308 _ROM_ADDR_H	=	0x0085
                           008F8E   309 _ROM_DATA_HI	=	0x8f8e
                           00008E   310 _ROM_DATA_HL	=	0x008e
                           00008F   311 _ROM_DATA_HH	=	0x008f
                           000086   312 _ROM_CTRL	=	0x0086
                           000080   313 _P0	=	0x0080
                           0000C4   314 _P0_MOD_OC	=	0x00c4
                           0000C5   315 _P0_DIR_PU	=	0x00c5
                           000090   316 _P1	=	0x0090
                           000092   317 _P1_MOD_OC	=	0x0092
                           000093   318 _P1_DIR_PU	=	0x0093
                           0000A0   319 _P2	=	0x00a0
                           000094   320 _P2_MOD_OC	=	0x0094
                           000095   321 _P2_DIR_PU	=	0x0095
                           0000B0   322 _P3	=	0x00b0
                           000096   323 _P3_MOD_OC	=	0x0096
                           000097   324 _P3_DIR_PU	=	0x0097
                           0000C0   325 _P4	=	0x00c0
                           0000C2   326 _P4_MOD_OC	=	0x00c2
                           0000C3   327 _P4_DIR_PU	=	0x00c3
                           0000C1   328 _P4_LED_KEY	=	0x00c1
                           0000AA   329 _P5_IN	=	0x00aa
                           0000AB   330 _P5_OUT_PU	=	0x00ab
                           0000AC   331 _P5_DIR	=	0x00ac
                           0000AD   332 _P6_IN	=	0x00ad
                           0000AE   333 _P6_OUT_PU	=	0x00ae
                           0000AF   334 _P6_DIR	=	0x00af
                           0000F1   335 _P7	=	0x00f1
                           0000A2   336 _XBUS_AUX	=	0x00a2
                           000088   337 _TCON	=	0x0088
                           000089   338 _TMOD	=	0x0089
                           00008A   339 _TL0	=	0x008a
                           00008B   340 _TL1	=	0x008b
                           00008C   341 _TH0	=	0x008c
                           00008D   342 _TH1	=	0x008d
                           000098   343 _SCON	=	0x0098
                           000099   344 _SBUF	=	0x0099
                           0000C8   345 _T2CON	=	0x00c8
                           0000C9   346 _T2MOD	=	0x00c9
                           00CBCA   347 _RCAP2	=	0xcbca
                           0000CA   348 _RCAP2L	=	0x00ca
                           0000CB   349 _RCAP2H	=	0x00cb
                           00CDCC   350 _T2COUNT	=	0xcdcc
                           0000CC   351 _TL2	=	0x00cc
                           0000CD   352 _TH2	=	0x00cd
                           00CFCE   353 _T2CAP1	=	0xcfce
                           0000CE   354 _T2CAP1L	=	0x00ce
                           0000CF   355 _T2CAP1H	=	0x00cf
                           0000F8   356 _SPI0_STAT	=	0x00f8
                           0000F9   357 _SPI0_DATA	=	0x00f9
                           0000FA   358 _SPI0_CTRL	=	0x00fa
                           0000FB   359 _SPI0_CK_SE	=	0x00fb
                           0000FC   360 _SPI0_SETUP	=	0x00fc
                           0000BC   361 _SCON1	=	0x00bc
                           0000BD   362 _SBUF1	=	0x00bd
                           0000BE   363 _SBAUD1	=	0x00be
                           0000BF   364 _SIF1	=	0x00bf
                           0000B4   365 _SPI1_STAT	=	0x00b4
                           0000B5   366 _SPI1_DATA	=	0x00b5
                           0000B6   367 _SPI1_CTRL	=	0x00b6
                           0000B7   368 _SPI1_CK_SE	=	0x00b7
                           0000F3   369 _ADC_CTRL	=	0x00f3
                           00F5F4   370 _ADC_DAT	=	0xf5f4
                           0000F4   371 _ADC_DAT_L	=	0x00f4
                           0000F5   372 _ADC_DAT_H	=	0x00f5
                           0000F6   373 _ADC_CHAN	=	0x00f6
                           0000A6   374 _LED_COMMON	=	0x00a6
                           0000A7   375 _LED_PWM_OE	=	0x00a7
                           00C7C6   376 _LED_DMA	=	0xc7c6
                           0000C6   377 _LED_DMA_L	=	0x00c6
                           0000C7   378 _LED_DMA_H	=	0x00c7
                           0000F7   379 _LED_STATUS	=	0x00f7
                           0000B3   380 _I2CX_INT	=	0x00b3
                           0000BB   381 _I2CS_INT_ST	=	0x00bb
                                    382 ;--------------------------------------------------------
                                    383 ; special function bits
                                    384 ;--------------------------------------------------------
                                    385 	.area RSEG    (ABS,DATA)
      000000                        386 	.org 0x0000
                           0000D7   387 _CY	=	0x00d7
                           0000D6   388 _AC	=	0x00d6
                           0000D5   389 _F0	=	0x00d5
                           0000D4   390 _RS1	=	0x00d4
                           0000D3   391 _RS0	=	0x00d3
                           0000D2   392 _OV	=	0x00d2
                           0000D1   393 _F1	=	0x00d1
                           0000D0   394 _P	=	0x00d0
                           0000AF   395 _EA	=	0x00af
                           0000AE   396 _E_DIS	=	0x00ae
                           0000AD   397 _ET2	=	0x00ad
                           0000AC   398 _ES	=	0x00ac
                           0000AB   399 _ET1	=	0x00ab
                           0000AA   400 _EX1	=	0x00aa
                           0000A9   401 _ET0	=	0x00a9
                           0000A8   402 _EX0	=	0x00a8
                           0000BF   403 _PH_FLAG	=	0x00bf
                           0000BE   404 _PL_FLAG	=	0x00be
                           0000BD   405 _PT2	=	0x00bd
                           0000BC   406 _PS	=	0x00bc
                           0000BB   407 _PT1	=	0x00bb
                           0000BA   408 _PX1	=	0x00ba
                           0000B9   409 _PT0	=	0x00b9
                           0000B8   410 _PX0	=	0x00b8
                           0000EF   411 _IE_WDOG	=	0x00ef
                           0000EE   412 _IE_GPIO	=	0x00ee
                           0000ED   413 _IE_PWM_I2C	=	0x00ed
                           0000EC   414 _IE_UART1	=	0x00ec
                           0000EB   415 _IE_ADC	=	0x00eb
                           0000E9   416 _IE_USB	=	0x00e9
                           0000E8   417 _IE_SPI0	=	0x00e8
                           000087   418 _P0_7	=	0x0087
                           000086   419 _P0_6	=	0x0086
                           000085   420 _P0_5	=	0x0085
                           000084   421 _P0_4	=	0x0084
                           000083   422 _P0_3	=	0x0083
                           000082   423 _P0_2	=	0x0082
                           000081   424 _P0_1	=	0x0081
                           000080   425 _P0_0	=	0x0080
                           000081   426 _SDA0	=	0x0081
                           000080   427 _SCL0	=	0x0080
                           000083   428 _TXD_	=	0x0083
                           000082   429 _RXD_	=	0x0082
                           000085   430 _AIN13	=	0x0085
                           000084   431 _AIN12	=	0x0084
                           000083   432 _AIN11	=	0x0083
                           000082   433 _AIN10	=	0x0082
                           000081   434 _AIN9	=	0x0081
                           000080   435 _AIN8	=	0x0080
                           000097   436 _P1_7	=	0x0097
                           000096   437 _P1_6	=	0x0096
                           000095   438 _P1_5	=	0x0095
                           000094   439 _P1_4	=	0x0094
                           000093   440 _P1_3	=	0x0093
                           000092   441 _P1_2	=	0x0092
                           000091   442 _P1_1	=	0x0091
                           000090   443 _P1_0	=	0x0090
                           000097   444 _TXD1_	=	0x0097
                           000096   445 _RXD1_	=	0x0096
                           000097   446 _SCK	=	0x0097
                           000096   447 _MISO	=	0x0096
                           000095   448 _MOSI	=	0x0095
                           000094   449 _SCS	=	0x0094
                           000092   450 _INT0_	=	0x0092
                           000091   451 _T2EX	=	0x0091
                           000091   452 _CAP2	=	0x0091
                           000090   453 _T2	=	0x0090
                           000090   454 _CAP1	=	0x0090
                           000097   455 _AIN7	=	0x0097
                           000096   456 _AIN6	=	0x0096
                           000095   457 _AIN5	=	0x0095
                           000094   458 _AIN4	=	0x0094
                           000093   459 _AIN3	=	0x0093
                           000092   460 _AIN2	=	0x0092
                           000091   461 _AIN1	=	0x0091
                           000090   462 _AIN0	=	0x0090
                           0000A7   463 _P2_7	=	0x00a7
                           0000A6   464 _P2_6	=	0x00a6
                           0000A5   465 _P2_5	=	0x00a5
                           0000A4   466 _P2_4	=	0x00a4
                           0000A3   467 _P2_3	=	0x00a3
                           0000A2   468 _P2_2	=	0x00a2
                           0000A1   469 _P2_1	=	0x00a1
                           0000A0   470 _P2_0	=	0x00a0
                           0000A7   471 _TXD1	=	0x00a7
                           0000A6   472 _RXD1	=	0x00a6
                           0000A5   473 _T2EX_	=	0x00a5
                           0000A5   474 _CAP2_	=	0x00a5
                           0000A4   475 _T2_	=	0x00a4
                           0000A4   476 _CAP1_	=	0x00a4
                           0000B7   477 _P3_7	=	0x00b7
                           0000B6   478 _P3_6	=	0x00b6
                           0000B5   479 _P3_5	=	0x00b5
                           0000B4   480 _P3_4	=	0x00b4
                           0000B3   481 _P3_3	=	0x00b3
                           0000B2   482 _P3_2	=	0x00b2
                           0000B1   483 _P3_1	=	0x00b1
                           0000B0   484 _P3_0	=	0x00b0
                           0000B7   485 _SCK1	=	0x00b7
                           0000B6   486 _MISO1	=	0x00b6
                           0000B5   487 _MOSI1	=	0x00b5
                           0000B5   488 _T1	=	0x00b5
                           0000B4   489 _T0	=	0x00b4
                           0000B3   490 _INT1	=	0x00b3
                           0000B2   491 _INT0	=	0x00b2
                           0000B1   492 _TXD	=	0x00b1
                           0000B0   493 _RXD	=	0x00b0
                           0000C6   494 _P4_6	=	0x00c6
                           0000C5   495 _P4_5	=	0x00c5
                           0000C4   496 _P4_4	=	0x00c4
                           0000C3   497 _P4_3	=	0x00c3
                           0000C2   498 _P4_2	=	0x00c2
                           0000C1   499 _P4_1	=	0x00c1
                           0000C0   500 _P4_0	=	0x00c0
                           00008F   501 _TF1	=	0x008f
                           00008E   502 _TR1	=	0x008e
                           00008D   503 _TF0	=	0x008d
                           00008C   504 _TR0	=	0x008c
                           00008B   505 _IE1	=	0x008b
                           00008A   506 _IT1	=	0x008a
                           000089   507 _IE0	=	0x0089
                           000088   508 _IT0	=	0x0088
                           00009F   509 _SM0	=	0x009f
                           00009E   510 _SM1	=	0x009e
                           00009D   511 _SM2	=	0x009d
                           00009C   512 _REN	=	0x009c
                           00009B   513 _TB8	=	0x009b
                           00009A   514 _RB8	=	0x009a
                           000099   515 _TI	=	0x0099
                           000098   516 _RI	=	0x0098
                           0000CF   517 _TF2	=	0x00cf
                           0000CF   518 _CAP1F	=	0x00cf
                           0000CE   519 _EXF2	=	0x00ce
                           0000CD   520 _RCLK	=	0x00cd
                           0000CC   521 _TCLK	=	0x00cc
                           0000CB   522 _EXEN2	=	0x00cb
                           0000CA   523 _TR2	=	0x00ca
                           0000C9   524 _C_T2	=	0x00c9
                           0000C8   525 _CP_RL2	=	0x00c8
                           0000FF   526 _S0_FST_ACT	=	0x00ff
                           0000FE   527 _S0_IF_OV	=	0x00fe
                           0000FD   528 _S0_IF_FIRST	=	0x00fd
                           0000FC   529 _S0_IF_BYTE	=	0x00fc
                           0000FB   530 _S0_FREE	=	0x00fb
                           0000FA   531 _S0_T_FIFO	=	0x00fa
                           0000F8   532 _S0_R_FIFO	=	0x00f8
                           0000F7   533 _ADC_START	=	0x00f7
                                    534 ;--------------------------------------------------------
                                    535 ; overlayable register banks
                                    536 ;--------------------------------------------------------
                                    537 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        538 	.ds 8
                                    539 ;--------------------------------------------------------
                                    540 ; internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area DSEG    (DATA)
      000042                        543 _vial_handle_cmd_sloc0_1_0:
      000042                        544 	.ds 2
      000044                        545 _vial_handle_cmd_sloc1_1_0:
      000044                        546 	.ds 2
      000046                        547 _vial_handle_cmd_sloc2_1_0:
      000046                        548 	.ds 2
      000048                        549 _vial_handle_cmd_sloc3_1_0:
      000048                        550 	.ds 2
                                    551 ;--------------------------------------------------------
                                    552 ; overlayable items in internal ram
                                    553 ;--------------------------------------------------------
                                    554 ;--------------------------------------------------------
                                    555 ; indirectly addressable internal ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area ISEG    (DATA)
                                    558 ;--------------------------------------------------------
                                    559 ; absolute internal ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area IABS    (ABS,DATA)
                                    562 	.area IABS    (ABS,DATA)
                                    563 ;--------------------------------------------------------
                                    564 ; bit data
                                    565 ;--------------------------------------------------------
                                    566 	.area BSEG    (BIT)
                                    567 ;--------------------------------------------------------
                                    568 ; paged external ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area PSEG    (PAG,XDATA)
                                    571 ;--------------------------------------------------------
                                    572 ; uninitialized external ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area XSEG    (XDATA)
      000D26                        575 _vial_unlock_timer:
      000D26                        576 	.ds 4
      000D2A                        577 _vial_unlock_holding:
      000D2A                        578 	.ds 1
      000D2B                        579 _vial_keycode_firewall_in_10000_611:
      000D2B                        580 	.ds 2
      000D2D                        581 _vial_fill_packet_PARM_2:
      000D2D                        582 	.ds 1
      000D2E                        583 _vial_fill_packet_msg_10000_614:
      000D2E                        584 	.ds 2
      000D30                        585 _vial_handle_cmd_PARM_2:
      000D30                        586 	.ds 1
      000D31                        587 _vial_handle_cmd_data_10000_619:
      000D31                        588 	.ds 3
      000D34                        589 _vial_handle_cmd_td_70000_647:
      000D34                        590 	.ds 10
      000D3E                        591 _vial_handle_cmd_td_70000_648:
      000D3E                        592 	.ds 10
      000D48                        593 _vial_handle_cmd_entry_70000_649:
      000D48                        594 	.ds 10
      000D52                        595 _vial_handle_cmd_entry_70000_650:
      000D52                        596 	.ds 10
      000D5C                        597 _g_vial_magic_keycode_override::
      000D5C                        598 	.ds 2
      000D5E                        599 _vial_keycode_down_keycode_10000_652:
      000D5E                        600 	.ds 2
      000D60                        601 _vial_keycode_down_dummy_event_30000_659:
      000D60                        602 	.ds 6
      000D66                        603 _vial_keycode_up_keycode_10000_660:
      000D66                        604 	.ds 2
      000D68                        605 _vial_keycode_up_dummy_event_30000_667:
      000D68                        606 	.ds 6
      000D6E                        607 _vial_keycode_tap_keycode_10000_668:
      000D6E                        608 	.ds 2
                                    609 ;--------------------------------------------------------
                                    610 ; absolute external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XABS    (ABS,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; initialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XISEG   (XDATA)
      000F04                        617 _vial_unlocked::
      000F04                        618 	.ds 1
      000F05                        619 _vial_unlock_in_progress::
      000F05                        620 	.ds 1
      000F06                        621 _vial_unlock_counter:
      000F06                        622 	.ds 1
      000F07                        623 _vial_unlock_combo_rows:
      000F07                        624 	.ds 2
      000F09                        625 _vial_unlock_combo_cols:
      000F09                        626 	.ds 2
                                    627 	.area HOME    (CODE)
                                    628 	.area GSINIT0 (CODE)
                                    629 	.area GSINIT1 (CODE)
                                    630 	.area GSINIT2 (CODE)
                                    631 	.area GSINIT3 (CODE)
                                    632 	.area GSINIT4 (CODE)
                                    633 	.area GSINIT5 (CODE)
                                    634 	.area GSINIT  (CODE)
                                    635 	.area GSFINAL (CODE)
                                    636 	.area CSEG    (CODE)
                                    637 ;--------------------------------------------------------
                                    638 ; global & static initialisations
                                    639 ;--------------------------------------------------------
                                    640 	.area HOME    (CODE)
                                    641 	.area GSINIT  (CODE)
                                    642 	.area GSFINAL (CODE)
                                    643 	.area GSINIT  (CODE)
                                    644 ;--------------------------------------------------------
                                    645 ; Home
                                    646 ;--------------------------------------------------------
                                    647 	.area HOME    (CODE)
                                    648 	.area HOME    (CODE)
                                    649 ;--------------------------------------------------------
                                    650 ; code
                                    651 ;--------------------------------------------------------
                                    652 	.area CSEG    (CODE)
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    655 ;------------------------------------------------------------
                                    656 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    657 ;------------------------------------------------------------
                                    658 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    659 ;	-----------------------------------------
                           000007   660 	ar7 = 0x07
                           000006   661 	ar6 = 0x06
                           000005   662 	ar5 = 0x05
                           000004   663 	ar4 = 0x04
                           000003   664 	ar3 = 0x03
                           000002   665 	ar2 = 0x02
                           000001   666 	ar1 = 0x01
                           000000   667 	ar0 = 0x00
                                    668 ;	 function vial_unlock_task
                                    669 ;	-----------------------------------------
      00B1FB                        670 _vial_unlock_task:
                                    671 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B1FB 90 0F 05         [24]  672 	mov	dptr,#_vial_unlock_in_progress
      00B1FE E0               [24]  673 	movx	a,@dptr
      00B1FF 70 01            [24]  674 	jnz	00131$
      00B201 22               [24]  675 	ret
                                    676 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B202                        677 00131$:
      00B202 7F 00            [12]  678 	mov	r7,#0x00
      00B204                        679 00115$:
      00B204 BF 02 00         [24]  680 	cjne	r7,#0x02,00184$
      00B207                        681 00184$:
      00B207 50 29            [24]  682 	jnc	00105$
                                    683 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B209 EF               [12]  684 	mov	a,r7
      00B20A 12 B8 6E         [24]  685 	lcall	_ak820_outline_0134
      00B20D FE               [12]  686 	mov	r6,a
      00B20E EF               [12]  687 	mov	a,r7
      00B20F 12 B8 63         [24]  688 	lcall	_ak820_outline_0133
      00B212 90 08 28         [24]  689 	mov	dptr,#_matrix_is_on_PARM_2
      00B215 F0               [24]  690 	movx	@dptr,a
      00B216 8E 82            [24]  691 	mov	dpl, r6
      00B218 C0 07            [24]  692 	push	ar7
      00B21A 12 5E 64         [24]  693 	lcall	_matrix_is_on
      00B21D E5 82            [12]  694 	mov	a, dpl
      00B21F D0 07            [24]  695 	pop	ar7
      00B221 70 0C            [24]  696 	jnz	00116$
                                    697 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B223 90 0D 2A         [24]  698 	mov	dptr,#_vial_unlock_holding
      00B226 E4               [12]  699 	clr	a
      00B227 F0               [24]  700 	movx	@dptr,a
                                    701 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B228 90 0F 06         [24]  702 	mov	dptr,#_vial_unlock_counter
      00B22B 74 1E            [12]  703 	mov	a,#0x1e
      00B22D F0               [24]  704 	movx	@dptr,a
                                    705 ;	quantum/vial.c:69: return;
      00B22E 22               [24]  706 	ret
      00B22F                        707 00116$:
                                    708 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B22F 0F               [12]  709 	inc	r7
      00B230 80 D2            [24]  710 	sjmp	00115$
      00B232                        711 00105$:
                                    712 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B232 90 0D 2A         [24]  713 	mov	dptr,#_vial_unlock_holding
      00B235 E0               [24]  714 	movx	a,@dptr
      00B236 70 12            [24]  715 	jnz	00107$
                                    716 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B238 90 0D 2A         [24]  717 	mov	dptr,#_vial_unlock_holding
      00B23B 74 01            [12]  718 	mov	a,#0x01
      00B23D F0               [24]  719 	movx	@dptr,a
                                    720 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B23E 12 4E 62         [24]  721 	lcall	_timer_read32
      00B241 12 54 75         [24]  722 	lcall	_ak820_outline_0063
      00B244 90 0D 26         [24]  723 	mov	dptr,#_vial_unlock_timer
      00B247 12 95 D2         [24]  724 	lcall	_ak820_outline_0009
      00B24A                        725 00107$:
                                    726 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B24A 90 0D 26         [24]  727 	mov	dptr,#_vial_unlock_timer
      00B24D 12 54 64         [24]  728 	lcall	_ak820_outline_0062
      00B250 12 4E BB         [24]  729 	lcall	_timer_elapsed32
      00B253 12 54 75         [24]  730 	lcall	_ak820_outline_0063
                                    731 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B256 7B 1E            [12]  732 	mov	r3,#0x1e
      00B258                        733 00109$:
      00B258 EB               [12]  734 	mov	a,r3
      00B259 60 22            [24]  735 	jz	00111$
      00B25B C3               [12]  736 	clr	c
      00B25C EC               [12]  737 	mov	a,r4
      00B25D 94 64            [12]  738 	subb	a,#0x64
      00B25F ED               [12]  739 	mov	a,r5
      00B260 94 00            [12]  740 	subb	a,#0x00
      00B262 EE               [12]  741 	mov	a,r6
      00B263 94 00            [12]  742 	subb	a,#0x00
      00B265 EF               [12]  743 	mov	a,r7
      00B266 94 00            [12]  744 	subb	a,#0x00
      00B268 40 13            [24]  745 	jc	00111$
                                    746 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B26A EC               [12]  747 	mov	a,r4
      00B26B 24 9C            [12]  748 	add	a,#0x9c
      00B26D FC               [12]  749 	mov	r4,a
      00B26E ED               [12]  750 	mov	a,r5
      00B26F 34 FF            [12]  751 	addc	a,#0xff
      00B271 FD               [12]  752 	mov	r5,a
      00B272 EE               [12]  753 	mov	a,r6
      00B273 34 FF            [12]  754 	addc	a,#0xff
      00B275 FE               [12]  755 	mov	r6,a
      00B276 EF               [12]  756 	mov	a,r7
      00B277 34 FF            [12]  757 	addc	a,#0xff
      00B279 FF               [12]  758 	mov	r7,a
                                    759 ;	quantum/vial.c:82: --counter;
      00B27A 1B               [12]  760 	dec	r3
      00B27B 80 DB            [24]  761 	sjmp	00109$
      00B27D                        762 00111$:
                                    763 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B27D 90 0F 06         [24]  764 	mov	dptr,#_vial_unlock_counter
      00B280 EB               [12]  765 	mov	a,r3
      00B281 F0               [24]  766 	movx	@dptr,a
                                    767 ;	quantum/vial.c:85: if (!counter) {
      00B282 EB               [12]  768 	mov	a,r3
      00B283 70 0A            [24]  769 	jnz	00117$
                                    770 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B285 90 0F 05         [24]  771 	mov	dptr,#_vial_unlock_in_progress
      00B288 E4               [12]  772 	clr	a
      00B289 F0               [24]  773 	movx	@dptr,a
                                    774 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B28A 90 0F 04         [24]  775 	mov	dptr,#_vial_unlocked
      00B28D 04               [12]  776 	inc	a
      00B28E F0               [24]  777 	movx	@dptr,a
      00B28F                        778 00117$:
                                    779 ;	quantum/vial.c:90: }
      00B28F 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'vial_init'
                                    783 ;------------------------------------------------------------
                                    784 ;	quantum/vial.c:117: void vial_init(void) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function vial_init
                                    787 ;	-----------------------------------------
      00B290                        788 _vial_init:
                                    789 ;	quantum/vial.c:125: reload_combo();
                                    790 ;	quantum/vial.c:130: }
      00B290 02 35 7A         [24]  791 	ljmp	_ak820_combo_reload
                                    792 ;------------------------------------------------------------
                                    793 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    794 ;------------------------------------------------------------
                                    795 ;in            Allocated with name '_vial_keycode_firewall_in_10000_611'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function vial_keycode_firewall
                                    800 ;	-----------------------------------------
      00B293                        801 _vial_keycode_firewall:
      00B293 12 38 7A         [24]  802 	lcall	_ak820_outline_0106
      00B296 90 0D 2B         [24]  803 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B299 12 38 75         [24]  804 	lcall	_ak820_outline_0105
                                    805 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B29C 90 0D 2B         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B29F 12 4D DC         [24]  807 	lcall	_ak820_outline_0012
      00B2A2 BC 00 0D         [24]  808 	cjne	r4,#0x00,00102$
      00B2A5 BD 7C 0A         [24]  809 	cjne	r5,#0x7c,00102$
      00B2A8 90 0F 04         [24]  810 	mov	dptr,#_vial_unlocked
      00B2AB E0               [24]  811 	movx	a,@dptr
      00B2AC 70 04            [24]  812 	jnz	00102$
                                    813 ;	quantum/vial.c:134: return 0;
      00B2AE 90 00 00         [24]  814 	mov	dptr,#0x0000
      00B2B1 22               [24]  815 	ret
      00B2B2                        816 00102$:
                                    817 ;	quantum/vial.c:135: return in;
      00B2B2 12 38 8D         [24]  818 	lcall	_ak820_outline_0121
                                    819 ;	quantum/vial.c:136: }
      00B2B5 22               [24]  820 	ret
                                    821 ;------------------------------------------------------------
                                    822 ;Allocation info for local variables in function 'vial_fill_packet'
                                    823 ;------------------------------------------------------------
                                    824 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    825 ;msg           Allocated with name '_vial_fill_packet_msg_10000_614'
                                    826 ;i             Allocated with name '_vial_fill_packet_i_20000_616'
                                    827 ;------------------------------------------------------------
                                    828 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    829 ;	-----------------------------------------
                                    830 ;	 function vial_fill_packet
                                    831 ;	-----------------------------------------
      00B2B6                        832 _vial_fill_packet:
      00B2B6 12 38 7A         [24]  833 	lcall	_ak820_outline_0106
      00B2B9 90 0D 2E         [24]  834 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B2BC 12 38 75         [24]  835 	lcall	_ak820_outline_0105
                                    836 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B2BF 90 0D 2E         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B2C2 12 38 2E         [24]  838 	lcall	_ak820_outline_0059
      00B2C5 90 0D 2D         [24]  839 	mov	dptr,#_vial_fill_packet_PARM_2
      00B2C8 E0               [24]  840 	movx	a,@dptr
      00B2C9 FD               [12]  841 	mov	r5,a
      00B2CA 7C 00            [12]  842 	mov	r4,#0x00
      00B2CC                        843 00103$:
      00B2CC BC 20 00         [24]  844 	cjne	r4,#0x20,00122$
      00B2CF                        845 00122$:
      00B2CF 50 09            [24]  846 	jnc	00105$
      00B2D1 EC               [12]  847 	mov	a,r4
      00B2D2 12 38 26         [24]  848 	lcall	_ak820_outline_0036
      00B2D5 ED               [12]  849 	mov	a,r5
      00B2D6 F0               [24]  850 	movx	@dptr,a
      00B2D7 0C               [12]  851 	inc	r4
      00B2D8 80 F2            [24]  852 	sjmp	00103$
      00B2DA                        853 00105$:
                                    854 ;	quantum/vial.c:141: }
      00B2DA 22               [24]  855 	ret
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'vial_release_held_state'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function vial_release_held_state
                                    862 ;	-----------------------------------------
      00B2DB                        863 _vial_release_held_state:
                                    864 ;	quantum/vial.c:174: repeat_key_cancel();
      00B2DB 12 A6 EE         [24]  865 	lcall	_repeat_key_cancel
                                    866 ;	quantum/vial.c:176: clear_keyboard();
                                    867 ;	quantum/vial.c:177: }
      00B2DE 02 7B 58         [24]  868 	ljmp	_clear_keyboard
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    871 ;------------------------------------------------------------
                                    872 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    873 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    874 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    875 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    876 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    877 ;data          Allocated with name '_vial_handle_cmd_data_10000_619'
                                    878 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_620'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50000_625'
                                    880 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_626'
                                    881 ;page          Allocated with name '_vial_handle_cmd_page_40001_629'
                                    882 ;start         Allocated with name '_vial_handle_cmd_start_40002_631'
                                    883 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_631'
                                    884 ;count         Allocated with name '_vial_handle_cmd_count_40002_631'
                                    885 ;i             Allocated with name '_vial_handle_cmd_i_50002_632'
                                    886 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_633'
                                    887 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_633'
                                    888 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_633'
                                    889 ;i             Allocated with name '_vial_handle_cmd_i_50000_636'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    891 ;td            Allocated with name '_vial_handle_cmd_td_70000_647'
                                    892 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_648'
                                    893 ;td            Allocated with name '_vial_handle_cmd_td_70000_648'
                                    894 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_649'
                                    895 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_649'
                                    896 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_650'
                                    897 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_650'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function vial_handle_cmd
                                    902 ;	-----------------------------------------
      00B2E1                        903 _vial_handle_cmd:
      00B2E1 12 43 11         [24]  904 	lcall	_ak820_outline_0042
      00B2E4 90 0D 31         [24]  905 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B2E7 12 38 0D         [24]  906 	lcall	_ak820_outline_0019
                                    907 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B2EA 90 0D 31         [24]  908 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B2ED 12 38 2E         [24]  909 	lcall	_ak820_outline_0059
                                    910 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B2F0 90 0D 30         [24]  911 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B2F3 E0               [24]  912 	movx	a,@dptr
      00B2F4 FD               [12]  913 	mov	r5,a
      00B2F5 BD 20 02         [24]  914 	cjne	r5,#0x20,00246$
      00B2F8 80 01            [24]  915 	sjmp	00102$
      00B2FA                        916 00246$:
                                    917 ;	quantum/vial.c:190: return;
      00B2FA 22               [24]  918 	ret
      00B2FB                        919 00102$:
                                    920 ;	quantum/vial.c:193: switch (msg[1]) {
      00B2FB 74 01            [12]  921 	mov	a,#0x01
      00B2FD 12 48 CA         [24]  922 	lcall	_ak820_outline_0014
      00B300 FB               [12]  923 	mov  r3,a
      00B301 24 F2            [12]  924 	add	a,#0xff - 0x0d
      00B303 50 01            [24]  925 	jnc	00247$
      00B305 22               [24]  926 	ret
      00B306                        927 00247$:
                                    928 ;	free result
      00B306 EB               [12]  929 	mov	a,r3
      00B307 24 0A            [12]  930 	add	a,#(00248$-3-.)
      00B309 83               [24]  931 	movc	a,@a+pc
      00B30A F5 82            [12]  932 	mov	dpl,a
      00B30C EB               [12]  933 	mov	a,r3
      00B30D 24 12            [12]  934 	add	a,#(00249$-3-.)
      00B30F 83               [24]  935 	movc	a,@a+pc
      00B310 F5 83            [12]  936 	mov	dph,a
      00B312 E4               [12]  937 	clr	a
      00B313 73               [24]  938 	jmp	@a+dptr
      00B314                        939 00248$:
      00B314 30                     940 	.db	00103$
      00B315 78                     941 	.db	00105$
      00B316 8D                     942 	.db	00106$
      00B317 19                     943 	.db	00112$
      00B318 A0                     944 	.db	00113$
      00B319 EA                     945 	.db	00114$
      00B31A 59                     946 	.db	00116$
      00B31B 74                     947 	.db	00119$
      00B31C 93                     948 	.db	00120$
      00B31D A1                     949 	.db	00121$
      00B31E 4F                     950 	.db	00141$
      00B31F 4F                     951 	.db	00141$
      00B320 4F                     952 	.db	00141$
      00B321 AC                     953 	.db	00122$
      00B322                        954 00249$:
      00B322 B3                     955 	.db	00103$>>8
      00B323 B3                     956 	.db	00105$>>8
      00B324 B3                     957 	.db	00106$>>8
      00B325 B4                     958 	.db	00112$>>8
      00B326 B4                     959 	.db	00113$>>8
      00B327 B4                     960 	.db	00114$>>8
      00B328 B5                     961 	.db	00116$>>8
      00B329 B5                     962 	.db	00119$>>8
      00B32A B5                     963 	.db	00120$>>8
      00B32B B5                     964 	.db	00121$>>8
      00B32C B7                     965 	.db	00141$>>8
      00B32D B7                     966 	.db	00141$>>8
      00B32E B7                     967 	.db	00141$>>8
      00B32F B5                     968 	.db	00122$>>8
                                    969 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B330                        970 00103$:
                                    971 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B330 90 0D 2D         [24]  972 	mov	dptr,#_vial_fill_packet_PARM_2
      00B333 E4               [12]  973 	clr	a
      00B334 12 43 43         [24]  974 	lcall	_ak820_outline_0072
      00B337 C0 07            [24]  975 	push	ar7
      00B339 C0 06            [24]  976 	push	ar6
      00B33B 12 B2 B6         [24]  977 	lcall	_vial_fill_packet
      00B33E D0 06            [24]  978 	pop	ar6
      00B340 D0 07            [24]  979 	pop	ar7
                                    980 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B342 12 38 8D         [24]  981 	lcall	_ak820_outline_0121
      00B345 74 06            [12]  982 	mov	a,#0x06
      00B347 12 43 43         [24]  983 	lcall	_ak820_outline_0072
                                    984 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B34A A3               [24]  985 	inc	dptr
      00B34B E4               [12]  986 	clr	a
      00B34C 12 43 09         [24]  987 	lcall	_ak820_outline_0037
                                    988 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B34F 12 43 09         [24]  989 	lcall	_ak820_outline_0037
                                    990 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B352 A3               [24]  991 	inc	dptr
      00B353 F0               [24]  992 	movx	@dptr,a
                                    993 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B354 FB               [12]  994 	mov	r3,a
      00B355                        995 00133$:
      00B355 BB 08 00         [24]  996 	cjne	r3,#0x08,00250$
      00B358                        997 00250$:
      00B358 50 15            [24]  998 	jnc	00104$
      00B35A 8B 02            [24]  999 	mov	ar2,r3
      00B35C 74 04            [12] 1000 	mov	a,#0x04
      00B35E 2A               [12] 1001 	add	a, r2
      00B35F 2E               [12] 1002 	add	a, r6
      00B360 F9               [12] 1003 	mov	r1,a
      00B361 E4               [12] 1004 	clr	a
      00B362 3F               [12] 1005 	addc	a,r7
      00B363 FA               [12] 1006 	mov	r2,a
      00B364 EB               [12] 1007 	mov	a,r3
      00B365 90 C5 06         [24] 1008 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_624
      00B368 93               [24] 1009 	movc	a,@a+dptr
      00B369 12 71 55         [24] 1010 	lcall	_ak820_outline_0142
      00B36C 0B               [12] 1011 	inc	r3
      00B36D 80 E6            [24] 1012 	sjmp	00133$
      00B36F                       1013 00104$:
                                   1014 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B36F 74 0C            [12] 1015 	mov	a,#0x0c
      00B371 12 38 26         [24] 1016 	lcall	_ak820_outline_0036
      00B374 74 01            [12] 1017 	mov	a,#0x01
      00B376 F0               [24] 1018 	movx	@dptr,a
                                   1019 ;	quantum/vial.c:207: break;
      00B377 22               [24] 1020 	ret
                                   1021 ;	quantum/vial.c:210: case vial_get_size: {
      00B378                       1022 00105$:
                                   1023 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B378 12 38 8D         [24] 1024 	lcall	_ak820_outline_0121
      00B37B 74 7C            [12] 1025 	mov	a,#0x7c
      00B37D F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B37E 12 38 98         [24] 1028 	lcall	_ak820_outline_0129
      00B381 74 01            [12] 1029 	mov	a,#0x01
      00B383 12 43 09         [24] 1030 	lcall	_ak820_outline_0037
                                   1031 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B386 E4               [12] 1032 	clr	a
      00B387 12 43 09         [24] 1033 	lcall	_ak820_outline_0037
                                   1034 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B38A A3               [24] 1035 	inc	dptr
      00B38B F0               [24] 1036 	movx	@dptr,a
                                   1037 ;	quantum/vial.c:216: break;
      00B38C 22               [24] 1038 	ret
                                   1039 ;	quantum/vial.c:219: case vial_get_def: {
      00B38D                       1040 00106$:
                                   1041 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B38D 12 B1 BF         [24] 1042 	lcall	_ak820_outline_0024
      00B390 E0               [24] 1043 	movx	a,@dptr
      00B391 FB               [12] 1044 	mov	r3,a
      00B392 12 42 FF         [24] 1045 	lcall	_ak820_outline_0011
      00B395 E0               [24] 1046 	movx	a,@dptr
      00B396 4B               [12] 1047 	orl	a,r3
      00B397 60 01            [24] 1048 	jz	00108$
      00B399 22               [24] 1049 	ret
      00B39A                       1050 00108$:
                                   1051 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B39A 12 38 1E         [24] 1052 	lcall	_ak820_outline_0034
      00B39D FB               [12] 1053 	mov	r3,a
      00B39E 7A 00            [12] 1054 	mov	r2,#0x00
      00B3A0 12 48 D5         [24] 1055 	lcall	_ak820_outline_0016
      00B3A3 F9               [12] 1056 	mov	r1,a
      00B3A4 E4               [12] 1057 	clr	a
      00B3A5 42 03            [12] 1058 	orl	ar3,a
      00B3A7 E9               [12] 1059 	mov	a,r1
      00B3A8 42 02            [12] 1060 	orl	ar2,a
                                   1061 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B3AA C3               [12] 1062 	clr	c
      00B3AB EB               [12] 1063 	mov	a,r3
      00B3AC 94 0C            [12] 1064 	subb	a,#0x0c
      00B3AE EA               [12] 1065 	mov	a,r2
      00B3AF 94 00            [12] 1066 	subb	a,#0x00
      00B3B1 40 01            [24] 1067 	jc	00110$
      00B3B3 22               [24] 1068 	ret
      00B3B4                       1069 00110$:
                                   1070 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B3B4 EA               [12] 1071 	mov	a,r2
      00B3B5 C4               [12] 1072 	swap	a
      00B3B6 23               [12] 1073 	rl	a
      00B3B7 54 E0            [12] 1074 	anl	a,#0xe0
      00B3B9 CB               [12] 1075 	xch	a,r3
      00B3BA C4               [12] 1076 	swap	a
      00B3BB 23               [12] 1077 	rl	a
      00B3BC CB               [12] 1078 	xch	a,r3
      00B3BD 6B               [12] 1079 	xrl	a,r3
      00B3BE CB               [12] 1080 	xch	a,r3
      00B3BF 54 E0            [12] 1081 	anl	a,#0xe0
      00B3C1 CB               [12] 1082 	xch	a,r3
      00B3C2 6B               [12] 1083 	xrl	a,r3
      00B3C3 FA               [12] 1084 	mov	r2,a
      00B3C4 8B 42            [24] 1085 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B3C6 8A 43            [24] 1086 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1087 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B3C8 74 7C            [12] 1088 	mov	a,#0x7c
      00B3CA C3               [12] 1089 	clr	c
      00B3CB 95 42            [12] 1090 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B3CD F8               [12] 1091 	mov	r0,a
      00B3CE 74 01            [12] 1092 	mov	a,#0x01
      00B3D0 95 43            [12] 1093 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B3D2 F9               [12] 1094 	mov	r1,a
                                   1095 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B3D3 C3               [12] 1096 	clr	c
      00B3D4 E8               [12] 1097 	mov	a,r0
      00B3D5 94 20            [12] 1098 	subb	a,#0x20
      00B3D7 E9               [12] 1099 	mov	a,r1
      00B3D8 94 00            [12] 1100 	subb	a,#0x00
      00B3DA 40 02            [24] 1101 	jc	00144$
      00B3DC 78 20            [12] 1102 	mov	r0,#0x20
      00B3DE                       1103 00144$:
                                   1104 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B3DE 79 00            [12] 1105 	mov	r1,#0x00
      00B3E0                       1106 00136$:
      00B3E0 C3               [12] 1107 	clr	c
      00B3E1 E9               [12] 1108 	mov	a,r1
      00B3E2 98               [12] 1109 	subb	a,r0
      00B3E3 40 01            [24] 1110 	jc	00255$
      00B3E5 22               [24] 1111 	ret
      00B3E6                       1112 00255$:
      00B3E6 C0 00            [24] 1113 	push	ar0
      00B3E8 E9               [12] 1114 	mov	a,r1
      00B3E9 2E               [12] 1115 	add	a, r6
      00B3EA F5 44            [12] 1116 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B3EC E4               [12] 1117 	clr	a
      00B3ED 3F               [12] 1118 	addc	a, r7
      00B3EE F5 45            [12] 1119 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B3F0 89 46            [24] 1120 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B3F2 75 47 00         [24] 1121 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B3F5 A8 42            [24] 1122 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B3F7 AB 43            [24] 1123 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B3F9 E5 46            [12] 1124 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B3FB 28               [12] 1125 	add	a, r0
      00B3FC F8               [12] 1126 	mov	r0,a
      00B3FD E5 47            [12] 1127 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B3FF 3B               [12] 1128 	addc	a, r3
      00B400 FB               [12] 1129 	mov	r3,a
      00B401 E8               [12] 1130 	mov	a,r0
      00B402 24 8A            [12] 1131 	add	a, #_keyboard_definition
      00B404 F5 82            [12] 1132 	mov	dpl,a
      00B406 EB               [12] 1133 	mov	a,r3
      00B407 34 C3            [12] 1134 	addc	a, #(_keyboard_definition >> 8)
      00B409 F5 83            [12] 1135 	mov	dph,a
      00B40B E4               [12] 1136 	clr	a
      00B40C 93               [24] 1137 	movc	a,@a+dptr
      00B40D 85 44 82         [24] 1138 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B410 85 45 83         [24] 1139 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B413 F0               [24] 1140 	movx	@dptr,a
      00B414 09               [12] 1141 	inc	r1
      00B415 D0 00            [24] 1142 	pop	ar0
                                   1143 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B417 80 C7            [24] 1144 	sjmp	00136$
      00B419                       1145 00112$:
                                   1146 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B419 74 02            [12] 1147 	mov	a,#0x02
      00B41B 2E               [12] 1148 	add	a, r6
      00B41C 12 48 EC         [24] 1149 	lcall	_ak820_outline_0035
      00B41F F5 46            [12] 1150 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1151 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B421 74 03            [12] 1152 	mov	a,#0x03
      00B423 2E               [12] 1153 	add	a, r6
      00B424 F5 44            [12] 1154 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B426 E4               [12] 1155 	clr	a
      00B427 3F               [12] 1156 	addc	a, r7
      00B428 F5 45            [12] 1157 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B42A 85 44 82         [24] 1158 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B42D 85 45 83         [24] 1159 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B430 E0               [24] 1160 	movx	a,@dptr
                                   1161 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B431 F5 42            [12] 1162 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B433 90 0B A8         [24] 1163 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B436 F0               [24] 1164 	movx	@dptr,a
      00B437 90 0B A9         [24] 1165 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B43A E4               [12] 1166 	clr	a
      00B43B F0               [24] 1167 	movx	@dptr,a
      00B43C 85 46 82         [24] 1168 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B43F C0 07            [24] 1169 	push	ar7
      00B441 C0 06            [24] 1170 	push	ar6
      00B443 C0 05            [24] 1171 	push	ar5
      00B445 C0 04            [24] 1172 	push	ar4
      00B447 C0 03            [24] 1173 	push	ar3
      00B449 C0 02            [24] 1174 	push	ar2
      00B44B 12 89 08         [24] 1175 	lcall	_dynamic_keymap_get_encoder
      00B44E 85 82 48         [24] 1176 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B451 85 83 49         [24] 1177 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B454 D0 02            [24] 1178 	pop	ar2
      00B456 D0 03            [24] 1179 	pop	ar3
      00B458 D0 04            [24] 1180 	pop	ar4
      00B45A D0 05            [24] 1181 	pop	ar5
      00B45C D0 06            [24] 1182 	pop	ar6
      00B45E D0 07            [24] 1183 	pop	ar7
                                   1184 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B460 A9 49            [24] 1185 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B462 12 38 8D         [24] 1186 	lcall	_ak820_outline_0121
      00B465 E9               [12] 1187 	mov	a,r1
      00B466 F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B467 A8 48            [24] 1190 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B469 12 38 98         [24] 1191 	lcall	_ak820_outline_0129
      00B46C E8               [12] 1192 	mov	a,r0
      00B46D F0               [24] 1193 	movx	@dptr,a
                                   1194 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B46E 90 0B A8         [24] 1195 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B471 E5 42            [12] 1196 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B473 F0               [24] 1197 	movx	@dptr,a
      00B474 90 0B A9         [24] 1198 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B477 74 01            [12] 1199 	mov	a,#0x01
      00B479 F0               [24] 1200 	movx	@dptr,a
      00B47A 85 46 82         [24] 1201 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B47D C0 03            [24] 1202 	push	ar3
      00B47F C0 02            [24] 1203 	push	ar2
      00B481 12 89 08         [24] 1204 	lcall	_dynamic_keymap_get_encoder
      00B484 85 82 48         [24] 1205 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B487 85 83 49         [24] 1206 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B48A D0 02            [24] 1207 	pop	ar2
      00B48C D0 03            [24] 1208 	pop	ar3
                                   1209 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B48E A9 49            [24] 1210 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B490 12 38 A2         [24] 1211 	lcall	_ak820_outline_0131
      00B493 E9               [12] 1212 	mov	a,r1
      00B494 F0               [24] 1213 	movx	@dptr,a
                                   1214 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B495 A8 48            [24] 1215 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B497 85 44 82         [24] 1216 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B49A 85 45 83         [24] 1217 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B49D E8               [12] 1218 	mov	a,r0
      00B49E F0               [24] 1219 	movx	@dptr,a
                                   1220 ;	quantum/vial.c:255: break;
      00B49F 22               [24] 1221 	ret
                                   1222 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B4A0                       1223 00113$:
                                   1224 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B4A0 12 38 1E         [24] 1225 	lcall	_ak820_outline_0034
      00B4A3 F5 44            [12] 1226 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B4A5 12 48 D5         [24] 1227 	lcall	_ak820_outline_0016
      00B4A8 F5 46            [12] 1228 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B4AA 12 B1 BF         [24] 1229 	lcall	_ak820_outline_0024
      00B4AD E0               [24] 1230 	movx	a,@dptr
                                   1231 ;	assignBit
      00B4AE 24 FF            [12] 1232 	add	a,#0xff
      00B4B0 E4               [12] 1233 	clr	a
      00B4B1 33               [12] 1234 	rlc	a
      00B4B2 F5 48            [12] 1235 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B4B4 12 42 FF         [24] 1236 	lcall	_ak820_outline_0011
      00B4B7 E0               [24] 1237 	movx	a,@dptr
      00B4B8 F9               [12] 1238 	mov	r1,a
      00B4B9 78 00            [12] 1239 	mov	r0,#0x00
      00B4BB 74 06            [12] 1240 	mov	a,#0x06
      00B4BD 12 38 15         [24] 1241 	lcall	_ak820_outline_0020
      00B4C0 7B 00            [12] 1242 	mov	r3,#0x00
      00B4C2 42 00            [12] 1243 	orl	ar0,a
      00B4C4 EB               [12] 1244 	mov	a,r3
      00B4C5 42 01            [12] 1245 	orl	ar1,a
      00B4C7 12 38 B1         [24] 1246 	lcall	_ak820_outline_0153
      00B4CA 12 B2 93         [24] 1247 	lcall	_vial_keycode_firewall
      00B4CD AA 82            [24] 1248 	mov	r2, dpl
      00B4CF AB 83            [24] 1249 	mov	r3, dph
      00B4D1 90 0B AB         [24] 1250 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B4D4 E5 46            [12] 1251 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B4D6 F0               [24] 1252 	movx	@dptr,a
      00B4D7 90 0B AC         [24] 1253 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B4DA E5 48            [12] 1254 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B4DC F0               [24] 1255 	movx	@dptr,a
      00B4DD 90 0B AD         [24] 1256 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B4E0 EA               [12] 1257 	mov	a,r2
      00B4E1 12 49 35         [24] 1258 	lcall	_ak820_outline_0162
      00B4E4 85 44 82         [24] 1259 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1260 ;	quantum/vial.c:259: break;
      00B4E7 02 89 6F         [24] 1261 	ljmp	_dynamic_keymap_set_encoder
                                   1262 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B4EA                       1263 00114$:
                                   1264 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B4EA 90 0D 2D         [24] 1265 	mov	dptr,#_vial_fill_packet_PARM_2
      00B4ED 74 FF            [12] 1266 	mov	a,#0xff
      00B4EF 12 43 43         [24] 1267 	lcall	_ak820_outline_0072
      00B4F2 C0 07            [24] 1268 	push	ar7
      00B4F4 C0 06            [24] 1269 	push	ar6
      00B4F6 12 B2 B6         [24] 1270 	lcall	_vial_fill_packet
      00B4F9 D0 06            [24] 1271 	pop	ar6
      00B4FB D0 07            [24] 1272 	pop	ar7
                                   1273 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B4FD 90 0F 04         [24] 1274 	mov	dptr,#_vial_unlocked
      00B500 E0               [24] 1275 	movx	a,@dptr
      00B501 12 38 8D         [24] 1276 	lcall	_ak820_outline_0121
      00B504 F0               [24] 1277 	movx	@dptr,a
                                   1278 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B505 74 01            [12] 1279 	mov	a,#0x01
      00B507 2E               [12] 1280 	add	a, r6
      00B508 FA               [12] 1281 	mov	r2,a
      00B509 E4               [12] 1282 	clr	a
      00B50A 3F               [12] 1283 	addc	a, r7
      00B50B FB               [12] 1284 	mov	r3,a
      00B50C 90 0F 05         [24] 1285 	mov	dptr,#_vial_unlock_in_progress
      00B50F E0               [24] 1286 	movx	a,@dptr
      00B510 12 38 A2         [24] 1287 	lcall	_ak820_outline_0131
      00B513 F0               [24] 1288 	movx	@dptr,a
                                   1289 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B514 7B 00            [12] 1290 	mov	r3,#0x00
      00B516                       1291 00139$:
      00B516 BB 02 00         [24] 1292 	cjne	r3,#0x02,00256$
      00B519                       1293 00256$:
      00B519 40 01            [24] 1294 	jc	00257$
      00B51B 22               [24] 1295 	ret
      00B51C                       1296 00257$:
                                   1297 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B51C 8B 01            [24] 1298 	mov	ar1,r3
      00B51E 7A 00            [12] 1299 	mov	r2,#0x00
      00B520 E9               [12] 1300 	mov	a,r1
      00B521 29               [12] 1301 	add	a,r1
      00B522 F5 48            [12] 1302 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B524 EA               [12] 1303 	mov	a,r2
      00B525 33               [12] 1304 	rlc	a
      00B526 F5 49            [12] 1305 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B528 74 02            [12] 1306 	mov	a,#0x02
      00B52A 25 48            [12] 1307 	add	a, _vial_handle_cmd_sloc3_1_0
      00B52C F8               [12] 1308 	mov	r0,a
      00B52D E4               [12] 1309 	clr	a
      00B52E 35 49            [12] 1310 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B530 FA               [12] 1311 	mov	r2,a
      00B531 E8               [12] 1312 	mov	a,r0
      00B532 2E               [12] 1313 	add	a, r6
      00B533 F8               [12] 1314 	mov	r0,a
      00B534 EA               [12] 1315 	mov	a,r2
      00B535 3F               [12] 1316 	addc	a, r7
      00B536 FA               [12] 1317 	mov	r2,a
      00B537 EB               [12] 1318 	mov	a,r3
      00B538 12 B8 6E         [24] 1319 	lcall	_ak820_outline_0134
      00B53B 88 82            [24] 1320 	mov	dpl,r0
      00B53D 8A 83            [24] 1321 	mov	dph,r2
      00B53F F0               [24] 1322 	movx	@dptr,a
                                   1323 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B540 74 03            [12] 1324 	mov	a,#0x03
      00B542 25 48            [12] 1325 	add	a, _vial_handle_cmd_sloc3_1_0
      00B544 F9               [12] 1326 	mov	r1,a
      00B545 E4               [12] 1327 	clr	a
      00B546 35 49            [12] 1328 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B548 FA               [12] 1329 	mov	r2,a
      00B549 E9               [12] 1330 	mov	a,r1
      00B54A 2E               [12] 1331 	add	a, r6
      00B54B F9               [12] 1332 	mov	r1,a
      00B54C EA               [12] 1333 	mov	a,r2
      00B54D 3F               [12] 1334 	addc	a, r7
      00B54E FA               [12] 1335 	mov	r2,a
      00B54F EB               [12] 1336 	mov	a,r3
      00B550 12 B8 63         [24] 1337 	lcall	_ak820_outline_0133
      00B553 12 71 55         [24] 1338 	lcall	_ak820_outline_0142
                                   1339 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B556 0B               [12] 1340 	inc	r3
                                   1341 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B557 80 BD            [24] 1342 	sjmp	00139$
      00B559                       1343 00116$:
                                   1344 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B559 90 0F 05         [24] 1345 	mov	dptr,#_vial_unlock_in_progress
      00B55C E0               [24] 1346 	movx	a,@dptr
      00B55D 70 03            [24] 1347 	jnz	00118$
      00B55F 12 B2 DB         [24] 1348 	lcall	_vial_release_held_state
      00B562                       1349 00118$:
                                   1350 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B562 90 0F 05         [24] 1351 	mov	dptr,#_vial_unlock_in_progress
      00B565 74 01            [12] 1352 	mov	a,#0x01
      00B567 F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B568 90 0F 06         [24] 1355 	mov	dptr,#_vial_unlock_counter
      00B56B 74 1E            [12] 1356 	mov	a,#0x1e
      00B56D F0               [24] 1357 	movx	@dptr,a
                                   1358 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B56E 90 0D 2A         [24] 1359 	mov	dptr,#_vial_unlock_holding
      00B571 E4               [12] 1360 	clr	a
      00B572 F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/vial.c:287: break;
      00B573 22               [24] 1363 	ret
                                   1364 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B574                       1365 00119$:
                                   1366 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B574 90 0F 04         [24] 1367 	mov	dptr,#_vial_unlocked
      00B577 E0               [24] 1368 	movx	a,@dptr
      00B578 12 38 8D         [24] 1369 	lcall	_ak820_outline_0121
      00B57B F0               [24] 1370 	movx	@dptr,a
                                   1371 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B57C 90 0F 05         [24] 1372 	mov	dptr,#_vial_unlock_in_progress
      00B57F E0               [24] 1373 	movx	a,@dptr
      00B580 12 43 61         [24] 1374 	lcall	_ak820_outline_0127
                                   1375 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B583 74 02            [12] 1376 	mov	a,#0x02
      00B585 2E               [12] 1377 	add	a, r6
      00B586 FA               [12] 1378 	mov	r2,a
      00B587 E4               [12] 1379 	clr	a
      00B588 3F               [12] 1380 	addc	a, r7
      00B589 FB               [12] 1381 	mov	r3,a
      00B58A 90 0F 06         [24] 1382 	mov	dptr,#_vial_unlock_counter
      00B58D E0               [24] 1383 	movx	a,@dptr
      00B58E 12 38 A2         [24] 1384 	lcall	_ak820_outline_0131
      00B591 F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/vial.c:293: break;
      00B592 22               [24] 1387 	ret
                                   1388 ;	quantum/vial.c:295: case vial_lock: {
      00B593                       1389 00120$:
                                   1390 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B593 90 0F 04         [24] 1391 	mov	dptr,#_vial_unlocked
      00B596 E4               [12] 1392 	clr	a
      00B597 F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B598 90 0F 05         [24] 1395 	mov	dptr,#_vial_unlock_in_progress
      00B59B F0               [24] 1396 	movx	@dptr,a
                                   1397 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B59C 90 0D 2A         [24] 1398 	mov	dptr,#_vial_unlock_holding
      00B59F F0               [24] 1399 	movx	@dptr,a
                                   1400 ;	quantum/vial.c:301: break;
      00B5A0 22               [24] 1401 	ret
                                   1402 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B5A1                       1403 00121$:
                                   1404 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B5A1 90 0D 2D         [24] 1405 	mov	dptr,#_vial_fill_packet_PARM_2
      00B5A4 74 FF            [12] 1406 	mov	a,#0xff
      00B5A6 12 43 43         [24] 1407 	lcall	_ak820_outline_0072
                                   1408 ;	quantum/vial.c:314: break;
      00B5A9 02 B2 B6         [24] 1409 	ljmp	_vial_fill_packet
                                   1410 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B5AC                       1411 00122$:
                                   1412 ;	quantum/vial.c:347: switch (msg[2]) {
      00B5AC 12 38 1E         [24] 1413 	lcall	_ak820_outline_0034
      00B5AF FB               [12] 1414 	mov  r3,a
      00B5B0 24 FB            [12] 1415 	add	a,#0xff - 0x04
      00B5B2 50 01            [24] 1416 	jnc	00259$
      00B5B4 22               [24] 1417 	ret
      00B5B5                       1418 00259$:
                                   1419 ;	free result
      00B5B5 EB               [12] 1420 	mov	a,r3
      00B5B6 2B               [12] 1421 	add	a,r3
      00B5B7 2B               [12] 1422 	add	a,r3
      00B5B8 90 B5 BC         [24] 1423 	mov	dptr,#00260$
      00B5BB 73               [24] 1424 	jmp	@a+dptr
      00B5BC                       1425 00260$:
      00B5BC 02 B5 CB         [24] 1426 	ljmp	00123$
      00B5BF 02 B5 F4         [24] 1427 	ljmp	00124$
      00B5C2 02 B6 56         [24] 1428 	ljmp	00125$
      00B5C5 02 B6 96         [24] 1429 	ljmp	00126$
      00B5C8 02 B6 F4         [24] 1430 	ljmp	00127$
                                   1431 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B5CB                       1432 00123$:
                                   1433 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B5CB 90 0D 2D         [24] 1434 	mov	dptr,#_vial_fill_packet_PARM_2
      00B5CE E4               [12] 1435 	clr	a
      00B5CF 12 43 43         [24] 1436 	lcall	_ak820_outline_0072
      00B5D2 C0 07            [24] 1437 	push	ar7
      00B5D4 C0 06            [24] 1438 	push	ar6
      00B5D6 12 B2 B6         [24] 1439 	lcall	_vial_fill_packet
      00B5D9 D0 06            [24] 1440 	pop	ar6
      00B5DB D0 07            [24] 1441 	pop	ar7
                                   1442 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B5DD 12 38 8D         [24] 1443 	lcall	_ak820_outline_0121
      00B5E0 74 08            [12] 1444 	mov	a,#0x08
      00B5E2 12 43 43         [24] 1445 	lcall	_ak820_outline_0072
                                   1446 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B5E5 A3               [24] 1447 	inc	dptr
      00B5E6 12 43 09         [24] 1448 	lcall	_ak820_outline_0037
                                   1449 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B5E9 E4               [12] 1450 	clr	a
      00B5EA F0               [24] 1451 	movx	@dptr,a
                                   1452 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B5EB 74 1F            [12] 1453 	mov	a,#0x1f
      00B5ED 12 38 26         [24] 1454 	lcall	_ak820_outline_0036
      00B5F0 74 01            [12] 1455 	mov	a,#0x01
      00B5F2 F0               [24] 1456 	movx	@dptr,a
                                   1457 ;	quantum/vial.c:356: break;
      00B5F3 22               [24] 1458 	ret
                                   1459 ;	quantum/vial.c:359: case dynamic_vial_tap_dance_get: {
      00B5F4                       1460 00124$:
                                   1461 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00B5F4 12 48 D5         [24] 1462 	lcall	_ak820_outline_0016
      00B5F7 FB               [12] 1463 	mov	r3,a
                                   1464 ;	quantum/vial.c:361: vial_tap_dance_entry_t td = { 0 };
      00B5F8 90 0D 34         [24] 1465 	mov	dptr,#_vial_handle_cmd_td_70000_647
      00B5FB 12 49 26         [24] 1466 	lcall	_ak820_outline_0146
      00B5FE 90 0D 36         [24] 1467 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0002)
      00B601 F0               [24] 1468 	movx	@dptr,a
      00B602 A3               [24] 1469 	inc	dptr
      00B603 F0               [24] 1470 	movx	@dptr,a
      00B604 90 0D 38         [24] 1471 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0004)
      00B607 F0               [24] 1472 	movx	@dptr,a
      00B608 A3               [24] 1473 	inc	dptr
      00B609 F0               [24] 1474 	movx	@dptr,a
      00B60A 90 0D 3A         [24] 1475 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0006)
      00B60D F0               [24] 1476 	movx	@dptr,a
      00B60E A3               [24] 1477 	inc	dptr
      00B60F F0               [24] 1478 	movx	@dptr,a
      00B610 90 0D 3C         [24] 1479 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0008)
      00B613 F0               [24] 1480 	movx	@dptr,a
      00B614 A3               [24] 1481 	inc	dptr
      00B615 F0               [24] 1482 	movx	@dptr,a
                                   1483 ;	quantum/vial.c:362: msg[0] = dynamic_keymap_get_tap_dance(idx, &td);
      00B616 90 0B B0         [24] 1484 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      00B619 74 34            [12] 1485 	mov	a,#_vial_handle_cmd_td_70000_647
      00B61B F0               [24] 1486 	movx	@dptr,a
      00B61C 74 0D            [12] 1487 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00B61E 12 38 4B         [24] 1488 	lcall	_ak820_outline_0077
      00B621 8B 82            [24] 1489 	mov	dpl, r3
      00B623 C0 07            [24] 1490 	push	ar7
      00B625 C0 06            [24] 1491 	push	ar6
      00B627 C0 05            [24] 1492 	push	ar5
      00B629 C0 04            [24] 1493 	push	ar4
      00B62B 12 89 DB         [24] 1494 	lcall	_dynamic_keymap_get_tap_dance
      00B62E AA 82            [24] 1495 	mov	r2, dpl
      00B630 D0 04            [24] 1496 	pop	ar4
      00B632 D0 05            [24] 1497 	pop	ar5
      00B634 D0 06            [24] 1498 	pop	ar6
      00B636 D0 07            [24] 1499 	pop	ar7
      00B638 12 38 8D         [24] 1500 	lcall	_ak820_outline_0121
      00B63B EA               [12] 1501 	mov	a,r2
      00B63C F0               [24] 1502 	movx	@dptr,a
                                   1503 ;	quantum/vial.c:363: memcpy(&msg[1], &td, sizeof(td));
      00B63D 8C 01            [24] 1504 	mov	ar1,r4
      00B63F 8D 02            [24] 1505 	mov	ar2,r5
      00B641 7B 00            [12] 1506 	mov	r3,#0x00
      00B643 90 0E 84         [24] 1507 	mov	dptr,#___memcpy_PARM_2
      00B646 74 34            [12] 1508 	mov	a,#_vial_handle_cmd_td_70000_647
      00B648 F0               [24] 1509 	movx	@dptr,a
      00B649 74 0D            [12] 1510 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00B64B 12 B8 3B         [24] 1511 	lcall	_ak820_outline_0010
      00B64E 12 43 88         [24] 1512 	lcall	_ak820_outline_0174
      00B651 8B F0            [24] 1513 	mov	b, r3
                                   1514 ;	quantum/vial.c:364: break;
      00B653 02 BE 0C         [24] 1515 	ljmp	___memcpy
                                   1516 ;	quantum/vial.c:366: case dynamic_vial_tap_dance_set: {
      00B656                       1517 00125$:
                                   1518 ;	quantum/vial.c:367: uint8_t idx = msg[3];
      00B656 12 48 D5         [24] 1519 	lcall	_ak820_outline_0016
      00B659 FB               [12] 1520 	mov	r3,a
                                   1521 ;	quantum/vial.c:369: memcpy(&td, &msg[4], sizeof(td));
      00B65A 74 04            [12] 1522 	mov	a,#0x04
      00B65C 2E               [12] 1523 	add	a, r6
      00B65D F9               [12] 1524 	mov	r1,a
      00B65E E4               [12] 1525 	clr	a
      00B65F 3F               [12] 1526 	addc	a, r7
      00B660 FA               [12] 1527 	mov	r2,a
      00B661 90 0E 84         [24] 1528 	mov	dptr,#___memcpy_PARM_2
      00B664 E9               [12] 1529 	mov	a,r1
      00B665 F0               [24] 1530 	movx	@dptr,a
      00B666 EA               [12] 1531 	mov	a,r2
      00B667 12 B8 3B         [24] 1532 	lcall	_ak820_outline_0010
      00B66A 90 0D 3E         [24] 1533 	mov	dptr,#_vial_handle_cmd_td_70000_648
      00B66D F5 F0            [12] 1534 	mov	b,a
      00B66F C0 07            [24] 1535 	push	ar7
      00B671 C0 06            [24] 1536 	push	ar6
      00B673 C0 03            [24] 1537 	push	ar3
      00B675 12 BE 0C         [24] 1538 	lcall	___memcpy
      00B678 D0 03            [24] 1539 	pop	ar3
                                   1540 ;	quantum/vial.c:376: msg[0] = dynamic_keymap_set_tap_dance(idx, &td);
      00B67A 90 0B B4         [24] 1541 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      00B67D 74 3E            [12] 1542 	mov	a,#_vial_handle_cmd_td_70000_648
      00B67F F0               [24] 1543 	movx	@dptr,a
      00B680 74 0D            [12] 1544 	mov	a,#(_vial_handle_cmd_td_70000_648 >> 8)
      00B682 12 38 4B         [24] 1545 	lcall	_ak820_outline_0077
      00B685 8B 82            [24] 1546 	mov	dpl, r3
      00B687 12 8A 5D         [24] 1547 	lcall	_dynamic_keymap_set_tap_dance
      00B68A AA 82            [24] 1548 	mov	r2, dpl
      00B68C D0 06            [24] 1549 	pop	ar6
      00B68E D0 07            [24] 1550 	pop	ar7
      00B690 12 38 8D         [24] 1551 	lcall	_ak820_outline_0121
      00B693 EA               [12] 1552 	mov	a,r2
      00B694 F0               [24] 1553 	movx	@dptr,a
                                   1554 ;	quantum/vial.c:378: break;
      00B695 22               [24] 1555 	ret
                                   1556 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B696                       1557 00126$:
                                   1558 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B696 12 48 D5         [24] 1559 	lcall	_ak820_outline_0016
      00B699 FB               [12] 1560 	mov	r3,a
                                   1561 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B69A 90 0D 48         [24] 1562 	mov	dptr,#_vial_handle_cmd_entry_70000_649
      00B69D 12 49 26         [24] 1563 	lcall	_ak820_outline_0146
      00B6A0 90 0D 4A         [24] 1564 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0002)
      00B6A3 F0               [24] 1565 	movx	@dptr,a
      00B6A4 A3               [24] 1566 	inc	dptr
      00B6A5 F0               [24] 1567 	movx	@dptr,a
      00B6A6 90 0D 4C         [24] 1568 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0004)
      00B6A9 F0               [24] 1569 	movx	@dptr,a
      00B6AA A3               [24] 1570 	inc	dptr
      00B6AB F0               [24] 1571 	movx	@dptr,a
      00B6AC 90 0D 4E         [24] 1572 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0006)
      00B6AF F0               [24] 1573 	movx	@dptr,a
      00B6B0 A3               [24] 1574 	inc	dptr
      00B6B1 F0               [24] 1575 	movx	@dptr,a
      00B6B2 90 0D 50         [24] 1576 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0008)
      00B6B5 F0               [24] 1577 	movx	@dptr,a
      00B6B6 A3               [24] 1578 	inc	dptr
      00B6B7 F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B6B8 90 0B B8         [24] 1581 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B6BB 74 48            [12] 1582 	mov	a,#_vial_handle_cmd_entry_70000_649
      00B6BD F0               [24] 1583 	movx	@dptr,a
      00B6BE 74 0D            [12] 1584 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00B6C0 12 38 4B         [24] 1585 	lcall	_ak820_outline_0077
      00B6C3 8B 82            [24] 1586 	mov	dpl, r3
      00B6C5 C0 07            [24] 1587 	push	ar7
      00B6C7 C0 06            [24] 1588 	push	ar6
      00B6C9 C0 05            [24] 1589 	push	ar5
      00B6CB C0 04            [24] 1590 	push	ar4
      00B6CD 12 8A FB         [24] 1591 	lcall	_dynamic_keymap_get_combo
      00B6D0 AA 82            [24] 1592 	mov	r2, dpl
      00B6D2 D0 04            [24] 1593 	pop	ar4
      00B6D4 D0 05            [24] 1594 	pop	ar5
      00B6D6 D0 06            [24] 1595 	pop	ar6
      00B6D8 D0 07            [24] 1596 	pop	ar7
      00B6DA 12 38 8D         [24] 1597 	lcall	_ak820_outline_0121
      00B6DD EA               [12] 1598 	mov	a,r2
      00B6DE F0               [24] 1599 	movx	@dptr,a
                                   1600 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B6DF 7B 00            [12] 1601 	mov	r3,#0x00
      00B6E1 90 0E 84         [24] 1602 	mov	dptr,#___memcpy_PARM_2
      00B6E4 74 48            [12] 1603 	mov	a,#_vial_handle_cmd_entry_70000_649
      00B6E6 F0               [24] 1604 	movx	@dptr,a
      00B6E7 74 0D            [12] 1605 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00B6E9 12 B8 3B         [24] 1606 	lcall	_ak820_outline_0010
      00B6EC 12 38 98         [24] 1607 	lcall	_ak820_outline_0129
      00B6EF 8B F0            [24] 1608 	mov	b, r3
                                   1609 ;	quantum/vial.c:387: break;
      00B6F1 02 BE 0C         [24] 1610 	ljmp	___memcpy
                                   1611 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B6F4                       1612 00127$:
                                   1613 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B6F4 12 48 D5         [24] 1614 	lcall	_ak820_outline_0016
      00B6F7 FD               [12] 1615 	mov	r5,a
                                   1616 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B6F8 74 04            [12] 1617 	mov	a,#0x04
      00B6FA 2E               [12] 1618 	add	a, r6
      00B6FB FB               [12] 1619 	mov	r3,a
      00B6FC E4               [12] 1620 	clr	a
      00B6FD 3F               [12] 1621 	addc	a, r7
      00B6FE FC               [12] 1622 	mov	r4,a
      00B6FF 90 0E 84         [24] 1623 	mov	dptr,#___memcpy_PARM_2
      00B702 EB               [12] 1624 	mov	a,r3
      00B703 F0               [24] 1625 	movx	@dptr,a
      00B704 EC               [12] 1626 	mov	a,r4
      00B705 12 B8 3B         [24] 1627 	lcall	_ak820_outline_0010
      00B708 90 0D 52         [24] 1628 	mov	dptr,#_vial_handle_cmd_entry_70000_650
      00B70B F5 F0            [12] 1629 	mov	b,a
      00B70D C0 07            [24] 1630 	push	ar7
      00B70F C0 06            [24] 1631 	push	ar6
      00B711 C0 05            [24] 1632 	push	ar5
      00B713 12 BE 0C         [24] 1633 	lcall	___memcpy
                                   1634 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B716 90 0D 5A         [24] 1635 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00B719 12 38 69         [24] 1636 	lcall	_ak820_outline_0099
      00B71C 12 33 FC         [24] 1637 	lcall	_ak820_outline_0125
      00B71F 12 B2 93         [24] 1638 	lcall	_vial_keycode_firewall
      00B722 AB 82            [24] 1639 	mov	r3, dpl
      00B724 AC 83            [24] 1640 	mov	r4, dph
      00B726 D0 05            [24] 1641 	pop	ar5
      00B728 90 0D 5A         [24] 1642 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00B72B 12 38 57         [24] 1643 	lcall	_ak820_outline_0082
                                   1644 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B72E 90 0B BC         [24] 1645 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B731 74 52            [12] 1646 	mov	a,#_vial_handle_cmd_entry_70000_650
      00B733 F0               [24] 1647 	movx	@dptr,a
      00B734 74 0D            [12] 1648 	mov	a,#(_vial_handle_cmd_entry_70000_650 >> 8)
      00B736 12 38 4B         [24] 1649 	lcall	_ak820_outline_0077
      00B739 8D 82            [24] 1650 	mov	dpl, r5
      00B73B 12 8B 90         [24] 1651 	lcall	_dynamic_keymap_set_combo
      00B73E AC 82            [24] 1652 	mov	r4, dpl
      00B740 D0 06            [24] 1653 	pop	ar6
      00B742 D0 07            [24] 1654 	pop	ar7
      00B744 12 38 8D         [24] 1655 	lcall	_ak820_outline_0121
      00B747 EC               [12] 1656 	mov	a,r4
      00B748 F0               [24] 1657 	movx	@dptr,a
                                   1658 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B749 EC               [12] 1659 	mov	a,r4
      00B74A 70 03            [24] 1660 	jnz	00141$
                                   1661 ;	quantum/vial.c:423: }
                                   1662 ;	quantum/vial.c:424: }
      00B74C 02 35 7A         [24] 1663 	ljmp	_ak820_combo_reload
      00B74F                       1664 00141$:
      00B74F 22               [24] 1665 	ret
                                   1666 ;------------------------------------------------------------
                                   1667 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1668 ;------------------------------------------------------------
                                   1669 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_652'
                                   1670 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_659'
                                   1671 ;------------------------------------------------------------
                                   1672 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1673 ;	-----------------------------------------
                                   1674 ;	 function vial_keycode_down
                                   1675 ;	-----------------------------------------
      00B750                       1676 _vial_keycode_down:
      00B750 12 38 7A         [24] 1677 	lcall	_ak820_outline_0106
      00B753 90 0D 5E         [24] 1678 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B756 12 38 75         [24] 1679 	lcall	_ak820_outline_0105
                                   1680 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B759 90 0D 5E         [24] 1681 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B75C 12 4D DC         [24] 1682 	lcall	_ak820_outline_0012
      00B75F 74 E0            [12] 1683 	mov	a,#0x100 - 0x20
      00B761 2D               [12] 1684 	add	a,r5
      00B762 50 19            [24] 1685 	jnc	00104$
      00B764 C3               [12] 1686 	clr	c
      00B765 74 FF            [12] 1687 	mov	a,#0xff
      00B767 9C               [12] 1688 	subb	a,r4
      00B768 74 4F            [12] 1689 	mov	a,#0x4f
      00B76A 9D               [12] 1690 	subb	a,r5
      00B76B 40 10            [24] 1691 	jc	00104$
                                   1692 ;	free result
                                   1693 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B76D 90 0D 5E         [24] 1694 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B770 EE               [12] 1695 	mov	a,r6
      00B771 12 38 9D         [24] 1696 	lcall	_ak820_outline_0130
                                   1697 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B774 90 0D 5E         [24] 1698 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B777 E0               [24] 1699 	movx	a,@dptr
      00B778 24 FE            [12] 1700 	add	a,#0xff - 0x01
      00B77A 40 01            [24] 1701 	jc	00104$
                                   1702 ;	free result
      00B77C 22               [24] 1703 	ret
      00B77D                       1704 00104$:
                                   1705 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B77D 90 0D 5E         [24] 1706 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B780 12 B8 4A         [24] 1707 	lcall	_ak820_outline_0026
                                   1708 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B783 40 06            [24] 1709 	jc	00107$
                                   1710 ;	free result
                                   1711 ;	quantum/vial.c:440: register_code16(keycode);
      00B785 12 38 8D         [24] 1712 	lcall	_ak820_outline_0121
      00B788 02 A2 EE         [24] 1713 	ljmp	_register_code16
      00B78B                       1714 00107$:
                                   1715 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B78B 90 0D 64         [24] 1716 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0004)
      00B78E 74 01            [12] 1717 	mov	a,#0x01
      00B790 F0               [24] 1718 	movx	@dptr,a
      00B791 90 0D 61         [24] 1719 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0001)
      00B794 74 F0            [12] 1720 	mov	a,#0xf0
      00B796 F0               [24] 1721 	movx	@dptr,a
      00B797 90 0D 60         [24] 1722 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
      00B79A F0               [24] 1723 	movx	@dptr,a
      00B79B 90 0D 65         [24] 1724 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0005)
      00B79E 74 01            [12] 1725 	mov	a,#0x01
      00B7A0 F0               [24] 1726 	movx	@dptr,a
      00B7A1 12 4E 93         [24] 1727 	lcall	_timer_read
      00B7A4 12 43 67         [24] 1728 	lcall	_ak820_outline_0139
      00B7A7 43 06 01         [24] 1729 	orl	ar6,#0x01
      00B7AA 90 0D 62         [24] 1730 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0002)
      00B7AD 12 49 18         [24] 1731 	lcall	_ak820_outline_0066
                                   1732 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B7B0 90 0D 60         [24] 1733 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
                                   1734 ;	quantum/vial.c:448: }
      00B7B3 02 75 7F         [24] 1735 	ljmp	_ak820_action_exec
                                   1736 ;------------------------------------------------------------
                                   1737 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1738 ;------------------------------------------------------------
                                   1739 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_660'
                                   1740 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_667'
                                   1741 ;------------------------------------------------------------
                                   1742 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1743 ;	-----------------------------------------
                                   1744 ;	 function vial_keycode_up
                                   1745 ;	-----------------------------------------
      00B7B6                       1746 _vial_keycode_up:
      00B7B6 12 38 7A         [24] 1747 	lcall	_ak820_outline_0106
      00B7B9 90 0D 66         [24] 1748 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B7BC 12 38 75         [24] 1749 	lcall	_ak820_outline_0105
                                   1750 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B7BF 90 0D 66         [24] 1751 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B7C2 12 4D DC         [24] 1752 	lcall	_ak820_outline_0012
      00B7C5 74 E0            [12] 1753 	mov	a,#0x100 - 0x20
      00B7C7 2D               [12] 1754 	add	a,r5
      00B7C8 50 19            [24] 1755 	jnc	00104$
      00B7CA C3               [12] 1756 	clr	c
      00B7CB 74 FF            [12] 1757 	mov	a,#0xff
      00B7CD 9C               [12] 1758 	subb	a,r4
      00B7CE 74 4F            [12] 1759 	mov	a,#0x4f
      00B7D0 9D               [12] 1760 	subb	a,r5
      00B7D1 40 10            [24] 1761 	jc	00104$
                                   1762 ;	free result
                                   1763 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B7D3 90 0D 66         [24] 1764 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B7D6 EE               [12] 1765 	mov	a,r6
      00B7D7 12 38 9D         [24] 1766 	lcall	_ak820_outline_0130
                                   1767 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B7DA 90 0D 66         [24] 1768 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B7DD E0               [24] 1769 	movx	a,@dptr
      00B7DE 24 FE            [12] 1770 	add	a,#0xff - 0x01
      00B7E0 40 01            [24] 1771 	jc	00104$
                                   1772 ;	free result
      00B7E2 22               [24] 1773 	ret
      00B7E3                       1774 00104$:
                                   1775 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B7E3 90 0D 66         [24] 1776 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B7E6 12 B8 4A         [24] 1777 	lcall	_ak820_outline_0026
                                   1778 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B7E9 40 06            [24] 1779 	jc	00107$
                                   1780 ;	free result
                                   1781 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B7EB 12 38 8D         [24] 1782 	lcall	_ak820_outline_0121
      00B7EE 02 A3 32         [24] 1783 	ljmp	_unregister_code16
      00B7F1                       1784 00107$:
                                   1785 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B7F1 90 0D 6C         [24] 1786 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0004)
      00B7F4 74 01            [12] 1787 	mov	a,#0x01
      00B7F6 F0               [24] 1788 	movx	@dptr,a
      00B7F7 90 0D 69         [24] 1789 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0001)
      00B7FA 74 F0            [12] 1790 	mov	a,#0xf0
      00B7FC F0               [24] 1791 	movx	@dptr,a
      00B7FD 90 0D 68         [24] 1792 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
      00B800 F0               [24] 1793 	movx	@dptr,a
      00B801 90 0D 6D         [24] 1794 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0005)
      00B804 E4               [12] 1795 	clr	a
      00B805 F0               [24] 1796 	movx	@dptr,a
      00B806 12 4E 93         [24] 1797 	lcall	_timer_read
      00B809 12 43 67         [24] 1798 	lcall	_ak820_outline_0139
      00B80C 43 06 01         [24] 1799 	orl	ar6,#0x01
      00B80F 90 0D 6A         [24] 1800 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0002)
      00B812 12 49 18         [24] 1801 	lcall	_ak820_outline_0066
                                   1802 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B815 90 0D 68         [24] 1803 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
                                   1804 ;	quantum/vial.c:470: }
      00B818 02 75 7F         [24] 1805 	ljmp	_ak820_action_exec
                                   1806 ;------------------------------------------------------------
                                   1807 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1808 ;------------------------------------------------------------
                                   1809 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_668'
                                   1810 ;i             Allocated with name '_vial_keycode_tap_i_30000_671'
                                   1811 ;------------------------------------------------------------
                                   1812 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1813 ;	-----------------------------------------
                                   1814 ;	 function vial_keycode_tap
                                   1815 ;	-----------------------------------------
      00B81B                       1816 _vial_keycode_tap:
      00B81B 12 38 7A         [24] 1817 	lcall	_ak820_outline_0106
      00B81E 90 0D 6E         [24] 1818 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00B821 12 38 75         [24] 1819 	lcall	_ak820_outline_0105
                                   1820 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B824 90 0D 6E         [24] 1821 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00B827 12 37 DC         [24] 1822 	lcall	_ak820_outline_0005
      00B82A C0 07            [24] 1823 	push	ar7
      00B82C C0 06            [24] 1824 	push	ar6
      00B82E 12 B7 50         [24] 1825 	lcall	_vial_keycode_down
      00B831 D0 06            [24] 1826 	pop	ar6
      00B833 D0 07            [24] 1827 	pop	ar7
                                   1828 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B835 12 38 8D         [24] 1829 	lcall	_ak820_outline_0121
                                   1830 ;	quantum/vial.c:476: }
      00B838 02 B7 B6         [24] 1831 	ljmp	_vial_keycode_up
                                   1832 ;------------------------------------------------------------
                                   1833 ;Allocation info for local variables in function 'process_record_vial'
                                   1834 ;------------------------------------------------------------
                                   1835 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1836 ;keycode       Allocated with name '_process_record_vial_keycode_10000_673'
                                   1837 ;------------------------------------------------------------
                                   1838 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1839 ;	-----------------------------------------
                                   1840 	.area CSEG    (CODE)
                                   1841 	.area CONST   (CODE)
                                   1842 	.area CONST   (CODE)
      00C38A                       1843 _keyboard_definition:
      00C38A FD                    1844 	.db #0xfd	; 253
      00C38B 37                    1845 	.db #0x37	; 55	'7'
      00C38C 7A                    1846 	.db #0x7a	; 122	'z'
      00C38D 58                    1847 	.db #0x58	; 88	'X'
      00C38E 5A                    1848 	.db #0x5a	; 90	'Z'
      00C38F 00                    1849 	.db #0x00	; 0
      00C390 00                    1850 	.db #0x00	; 0
      00C391 04                    1851 	.db #0x04	; 4
      00C392 E6                    1852 	.db #0xe6	; 230
      00C393 D6                    1853 	.db #0xd6	; 214
      00C394 B4                    1854 	.db #0xb4	; 180
      00C395 46                    1855 	.db #0x46	; 70	'F'
      00C396 02                    1856 	.db #0x02	; 2
      00C397 00                    1857 	.db #0x00	; 0
      00C398 21                    1858 	.db #0x21	; 33
      00C399 01                    1859 	.db #0x01	; 1
      00C39A 00                    1860 	.db #0x00	; 0
      00C39B 00                    1861 	.db #0x00	; 0
      00C39C 00                    1862 	.db #0x00	; 0
      00C39D 00                    1863 	.db #0x00	; 0
      00C39E 37                    1864 	.db #0x37	; 55	'7'
      00C39F 27                    1865 	.db #0x27	; 39
      00C3A0 97                    1866 	.db #0x97	; 151
      00C3A1 D6                    1867 	.db #0xd6	; 214
      00C3A2 E0                    1868 	.db #0xe0	; 224
      00C3A3 03                    1869 	.db #0x03	; 3
      00C3A4 CB                    1870 	.db #0xcb	; 203
      00C3A5 01                    1871 	.db #0x01	; 1
      00C3A6 3C                    1872 	.db #0x3c	; 60
      00C3A7 00                    1873 	.db #0x00	; 0
      00C3A8 00                    1874 	.db #0x00	; 0
      00C3A9 3D                    1875 	.db #0x3d	; 61
      00C3AA 88                    1876 	.db #0x88	; 136
      00C3AB CD                    1877 	.db #0xcd	; 205
      00C3AC A5                    1878 	.db #0xa5	; 165
      00C3AD AA                    1879 	.db #0xaa	; 170
      00C3AE E5                    1880 	.db #0xe5	; 229
      00C3AF A8                    1881 	.db #0xa8	; 168
      00C3B0 76                    1882 	.db #0x76	; 118	'v'
      00C3B1 F6                    1883 	.db #0xf6	; 246
      00C3B2 43                    1884 	.db #0x43	; 67	'C'
      00C3B3 0E                    1885 	.db #0x0e	; 14
      00C3B4 D2                    1886 	.db #0xd2	; 210
      00C3B5 90                    1887 	.db #0x90	; 144
      00C3B6 7D                    1888 	.db #0x7d	; 125
      00C3B7 94                    1889 	.db #0x94	; 148
      00C3B8 79                    1890 	.db #0x79	; 121	'y'
      00C3B9 78                    1891 	.db #0x78	; 120	'x'
      00C3BA EF                    1892 	.db #0xef	; 239
      00C3BB 49                    1893 	.db #0x49	; 73	'I'
      00C3BC 3E                    1894 	.db #0x3e	; 62
      00C3BD EF                    1895 	.db #0xef	; 239
      00C3BE FD                    1896 	.db #0xfd	; 253
      00C3BF 8F                    1897 	.db #0x8f	; 143
      00C3C0 EF                    1898 	.db #0xef	; 239
      00C3C1 00                    1899 	.db #0x00	; 0
      00C3C2 C6                    1900 	.db #0xc6	; 198
      00C3C3 D1                    1901 	.db #0xd1	; 209
      00C3C4 DB                    1902 	.db #0xdb	; 219
      00C3C5 FB                    1903 	.db #0xfb	; 251
      00C3C6 EB                    1904 	.db #0xeb	; 235
      00C3C7 DE                    1905 	.db #0xde	; 222
      00C3C8 66                    1906 	.db #0x66	; 102	'f'
      00C3C9 63                    1907 	.db #0x63	; 99	'c'
      00C3CA 0C                    1908 	.db #0x0c	; 12
      00C3CB 92                    1909 	.db #0x92	; 146
      00C3CC 7B                    1910 	.db #0x7b	; 123
      00C3CD F9                    1911 	.db #0xf9	; 249
      00C3CE D4                    1912 	.db #0xd4	; 212
      00C3CF 7A                    1913 	.db #0x7a	; 122	'z'
      00C3D0 4F                    1914 	.db #0x4f	; 79	'O'
      00C3D1 83                    1915 	.db #0x83	; 131
      00C3D2 4B                    1916 	.db #0x4b	; 75	'K'
      00C3D3 86                    1917 	.db #0x86	; 134
      00C3D4 0E                    1918 	.db #0x0e	; 14
      00C3D5 6A                    1919 	.db #0x6a	; 106	'j'
      00C3D6 F2                    1920 	.db #0xf2	; 242
      00C3D7 22                    1921 	.db #0x22	; 34
      00C3D8 22                    1922 	.db #0x22	; 34
      00C3D9 0B                    1923 	.db #0x0b	; 11
      00C3DA 03                    1924 	.db #0x03	; 3
      00C3DB BA                    1925 	.db #0xba	; 186
      00C3DC 67                    1926 	.db #0x67	; 103	'g'
      00C3DD 9B                    1927 	.db #0x9b	; 155
      00C3DE 7A                    1928 	.db #0x7a	; 122	'z'
      00C3DF E1                    1929 	.db #0xe1	; 225
      00C3E0 BC                    1930 	.db #0xbc	; 188
      00C3E1 37                    1931 	.db #0x37	; 55	'7'
      00C3E2 26                    1932 	.db #0x26	; 38
      00C3E3 46                    1933 	.db #0x46	; 70	'F'
      00C3E4 78                    1934 	.db #0x78	; 120	'x'
      00C3E5 05                    1935 	.db #0x05	; 5
      00C3E6 0D                    1936 	.db #0x0d	; 13
      00C3E7 95                    1937 	.db #0x95	; 149
      00C3E8 02                    1938 	.db #0x02	; 2
      00C3E9 E4                    1939 	.db #0xe4	; 228
      00C3EA 18                    1940 	.db #0x18	; 24
      00C3EB CA                    1941 	.db #0xca	; 202
      00C3EC 33                    1942 	.db #0x33	; 51	'3'
      00C3ED EA                    1943 	.db #0xea	; 234
      00C3EE 24                    1944 	.db #0x24	; 36
      00C3EF C8                    1945 	.db #0xc8	; 200
      00C3F0 81                    1946 	.db #0x81	; 129
      00C3F1 4E                    1947 	.db #0x4e	; 78	'N'
      00C3F2 47                    1948 	.db #0x47	; 71	'G'
      00C3F3 A8                    1949 	.db #0xa8	; 168
      00C3F4 44                    1950 	.db #0x44	; 68	'D'
      00C3F5 DD                    1951 	.db #0xdd	; 221
      00C3F6 91                    1952 	.db #0x91	; 145
      00C3F7 6D                    1953 	.db #0x6d	; 109	'm'
      00C3F8 69                    1954 	.db #0x69	; 105	'i'
      00C3F9 DB                    1955 	.db #0xdb	; 219
      00C3FA 4F                    1956 	.db #0x4f	; 79	'O'
      00C3FB 3A                    1957 	.db #0x3a	; 58
      00C3FC 43                    1958 	.db #0x43	; 67	'C'
      00C3FD 9D                    1959 	.db #0x9d	; 157
      00C3FE 26                    1960 	.db #0x26	; 38
      00C3FF 49                    1961 	.db #0x49	; 73	'I'
      00C400 4C                    1962 	.db #0x4c	; 76	'L'
      00C401 EF                    1963 	.db #0xef	; 239
      00C402 2B                    1964 	.db #0x2b	; 43
      00C403 D8                    1965 	.db #0xd8	; 216
      00C404 55                    1966 	.db #0x55	; 85	'U'
      00C405 95                    1967 	.db #0x95	; 149
      00C406 70                    1968 	.db #0x70	; 112	'p'
      00C407 B1                    1969 	.db #0xb1	; 177
      00C408 CC                    1970 	.db #0xcc	; 204
      00C409 CF                    1971 	.db #0xcf	; 207
      00C40A 13                    1972 	.db #0x13	; 19
      00C40B 32                    1973 	.db #0x32	; 50	'2'
      00C40C 6A                    1974 	.db #0x6a	; 106	'j'
      00C40D A1                    1975 	.db #0xa1	; 161
      00C40E FF                    1976 	.db #0xff	; 255
      00C40F 99                    1977 	.db #0x99	; 153
      00C410 61                    1978 	.db #0x61	; 97	'a'
      00C411 95                    1979 	.db #0x95	; 149
      00C412 B1                    1980 	.db #0xb1	; 177
      00C413 89                    1981 	.db #0x89	; 137
      00C414 9B                    1982 	.db #0x9b	; 155
      00C415 11                    1983 	.db #0x11	; 17
      00C416 D9                    1984 	.db #0xd9	; 217
      00C417 35                    1985 	.db #0x35	; 53	'5'
      00C418 78                    1986 	.db #0x78	; 120	'x'
      00C419 ED                    1987 	.db #0xed	; 237
      00C41A CD                    1988 	.db #0xcd	; 205
      00C41B 94                    1989 	.db #0x94	; 148
      00C41C 6E                    1990 	.db #0x6e	; 110	'n'
      00C41D 60                    1991 	.db #0x60	; 96
      00C41E 8E                    1992 	.db #0x8e	; 142
      00C41F 63                    1993 	.db #0x63	; 99	'c'
      00C420 8B                    1994 	.db #0x8b	; 139
      00C421 FF                    1995 	.db #0xff	; 255
      00C422 4E                    1996 	.db #0x4e	; 78	'N'
      00C423 20                    1997 	.db #0x20	; 32
      00C424 7A                    1998 	.db #0x7a	; 122	'z'
      00C425 B5                    1999 	.db #0xb5	; 181
      00C426 87                    2000 	.db #0x87	; 135
      00C427 C2                    2001 	.db #0xc2	; 194
      00C428 35                    2002 	.db #0x35	; 53	'5'
      00C429 A4                    2003 	.db #0xa4	; 164
      00C42A 6D                    2004 	.db #0x6d	; 109	'm'
      00C42B 18                    2005 	.db #0x18	; 24
      00C42C C1                    2006 	.db #0xc1	; 193
      00C42D A3                    2007 	.db #0xa3	; 163
      00C42E DB                    2008 	.db #0xdb	; 219
      00C42F 53                    2009 	.db #0x53	; 83	'S'
      00C430 1D                    2010 	.db #0x1d	; 29
      00C431 EC                    2011 	.db #0xec	; 236
      00C432 F0                    2012 	.db #0xf0	; 240
      00C433 BF                    2013 	.db #0xbf	; 191
      00C434 4A                    2014 	.db #0x4a	; 74	'J'
      00C435 4C                    2015 	.db #0x4c	; 76	'L'
      00C436 4A                    2016 	.db #0x4a	; 74	'J'
      00C437 C4                    2017 	.db #0xc4	; 196
      00C438 AA                    2018 	.db #0xaa	; 170
      00C439 37                    2019 	.db #0x37	; 55	'7'
      00C43A 19                    2020 	.db #0x19	; 25
      00C43B 34                    2021 	.db #0x34	; 52	'4'
      00C43C 3F                    2022 	.db #0x3f	; 63
      00C43D A1                    2023 	.db #0xa1	; 161
      00C43E D3                    2024 	.db #0xd3	; 211
      00C43F 1A                    2025 	.db #0x1a	; 26
      00C440 5C                    2026 	.db #0x5c	; 92
      00C441 03                    2027 	.db #0x03	; 3
      00C442 4D                    2028 	.db #0x4d	; 77	'M'
      00C443 BC                    2029 	.db #0xbc	; 188
      00C444 10                    2030 	.db #0x10	; 16
      00C445 2E                    2031 	.db #0x2e	; 46
      00C446 80                    2032 	.db #0x80	; 128
      00C447 F7                    2033 	.db #0xf7	; 247
      00C448 D6                    2034 	.db #0xd6	; 214
      00C449 82                    2035 	.db #0x82	; 130
      00C44A 24                    2036 	.db #0x24	; 36
      00C44B 4C                    2037 	.db #0x4c	; 76	'L'
      00C44C 87                    2038 	.db #0x87	; 135
      00C44D B9                    2039 	.db #0xb9	; 185
      00C44E F8                    2040 	.db #0xf8	; 248
      00C44F BE                    2041 	.db #0xbe	; 190
      00C450 67                    2042 	.db #0x67	; 103	'g'
      00C451 96                    2043 	.db #0x96	; 150
      00C452 89                    2044 	.db #0x89	; 137
      00C453 30                    2045 	.db #0x30	; 48	'0'
      00C454 C8                    2046 	.db #0xc8	; 200
      00C455 8D                    2047 	.db #0x8d	; 141
      00C456 2C                    2048 	.db #0x2c	; 44
      00C457 F5                    2049 	.db #0xf5	; 245
      00C458 06                    2050 	.db #0x06	; 6
      00C459 05                    2051 	.db #0x05	; 5
      00C45A 7C                    2052 	.db #0x7c	; 124
      00C45B 48                    2053 	.db #0x48	; 72	'H'
      00C45C 1B                    2054 	.db #0x1b	; 27
      00C45D 76                    2055 	.db #0x76	; 118	'v'
      00C45E AA                    2056 	.db #0xaa	; 170
      00C45F 3D                    2057 	.db #0x3d	; 61
      00C460 28                    2058 	.db #0x28	; 40
      00C461 FC                    2059 	.db #0xfc	; 252
      00C462 80                    2060 	.db #0x80	; 128
      00C463 75                    2061 	.db #0x75	; 117	'u'
      00C464 EB                    2062 	.db #0xeb	; 235
      00C465 78                    2063 	.db #0x78	; 120	'x'
      00C466 D0                    2064 	.db #0xd0	; 208
      00C467 8A                    2065 	.db #0x8a	; 138
      00C468 8F                    2066 	.db #0x8f	; 143
      00C469 27                    2067 	.db #0x27	; 39
      00C46A F7                    2068 	.db #0xf7	; 247
      00C46B F2                    2069 	.db #0xf2	; 242
      00C46C EB                    2070 	.db #0xeb	; 235
      00C46D 58                    2071 	.db #0x58	; 88	'X'
      00C46E 37                    2072 	.db #0x37	; 55	'7'
      00C46F 3C                    2073 	.db #0x3c	; 60
      00C470 2B                    2074 	.db #0x2b	; 43
      00C471 6F                    2075 	.db #0x6f	; 111	'o'
      00C472 0E                    2076 	.db #0x0e	; 14
      00C473 C7                    2077 	.db #0xc7	; 199
      00C474 E2                    2078 	.db #0xe2	; 226
      00C475 A0                    2079 	.db #0xa0	; 160
      00C476 97                    2080 	.db #0x97	; 151
      00C477 EE                    2081 	.db #0xee	; 238
      00C478 FD                    2082 	.db #0xfd	; 253
      00C479 9F                    2083 	.db #0x9f	; 159
      00C47A 45                    2084 	.db #0x45	; 69	'E'
      00C47B 17                    2085 	.db #0x17	; 23
      00C47C 94                    2086 	.db #0x94	; 148
      00C47D E6                    2087 	.db #0xe6	; 230
      00C47E E7                    2088 	.db #0xe7	; 231
      00C47F FA                    2089 	.db #0xfa	; 250
      00C480 4C                    2090 	.db #0x4c	; 76	'L'
      00C481 7A                    2091 	.db #0x7a	; 122	'z'
      00C482 D6                    2092 	.db #0xd6	; 214
      00C483 7A                    2093 	.db #0x7a	; 122	'z'
      00C484 7B                    2094 	.db #0x7b	; 123
      00C485 ED                    2095 	.db #0xed	; 237
      00C486 10                    2096 	.db #0x10	; 16
      00C487 C5                    2097 	.db #0xc5	; 197
      00C488 BC                    2098 	.db #0xbc	; 188
      00C489 E3                    2099 	.db #0xe3	; 227
      00C48A A9                    2100 	.db #0xa9	; 169
      00C48B 1F                    2101 	.db #0x1f	; 31
      00C48C CF                    2102 	.db #0xcf	; 207
      00C48D C4                    2103 	.db #0xc4	; 196
      00C48E 9D                    2104 	.db #0x9d	; 157
      00C48F DC                    2105 	.db #0xdc	; 220
      00C490 45                    2106 	.db #0x45	; 69	'E'
      00C491 2A                    2107 	.db #0x2a	; 42
      00C492 69                    2108 	.db #0x69	; 105	'i'
      00C493 57                    2109 	.db #0x57	; 87	'W'
      00C494 8F                    2110 	.db #0x8f	; 143
      00C495 EC                    2111 	.db #0xec	; 236
      00C496 85                    2112 	.db #0x85	; 133
      00C497 6C                    2113 	.db #0x6c	; 108	'l'
      00C498 43                    2114 	.db #0x43	; 67	'C'
      00C499 1C                    2115 	.db #0x1c	; 28
      00C49A BA                    2116 	.db #0xba	; 186
      00C49B 89                    2117 	.db #0x89	; 137
      00C49C 68                    2118 	.db #0x68	; 104	'h'
      00C49D 4A                    2119 	.db #0x4a	; 74	'J'
      00C49E 1C                    2120 	.db #0x1c	; 28
      00C49F 91                    2121 	.db #0x91	; 145
      00C4A0 3F                    2122 	.db #0x3f	; 63
      00C4A1 D1                    2123 	.db #0xd1	; 209
      00C4A2 B3                    2124 	.db #0xb3	; 179
      00C4A3 96                    2125 	.db #0x96	; 150
      00C4A4 1D                    2126 	.db #0x1d	; 29
      00C4A5 7C                    2127 	.db #0x7c	; 124
      00C4A6 14                    2128 	.db #0x14	; 20
      00C4A7 77                    2129 	.db #0x77	; 119	'w'
      00C4A8 9C                    2130 	.db #0x9c	; 156
      00C4A9 74                    2131 	.db #0x74	; 116	't'
      00C4AA 36                    2132 	.db #0x36	; 54	'6'
      00C4AB FF                    2133 	.db #0xff	; 255
      00C4AC 2C                    2134 	.db #0x2c	; 44
      00C4AD 66                    2135 	.db #0x66	; 102	'f'
      00C4AE AF                    2136 	.db #0xaf	; 175
      00C4AF 0F                    2137 	.db #0x0f	; 15
      00C4B0 3C                    2138 	.db #0x3c	; 60
      00C4B1 A2                    2139 	.db #0xa2	; 162
      00C4B2 23                    2140 	.db #0x23	; 35
      00C4B3 85                    2141 	.db #0x85	; 133
      00C4B4 05                    2142 	.db #0x05	; 5
      00C4B5 87                    2143 	.db #0x87	; 135
      00C4B6 DA                    2144 	.db #0xda	; 218
      00C4B7 61                    2145 	.db #0x61	; 97	'a'
      00C4B8 5E                    2146 	.db #0x5e	; 94
      00C4B9 42                    2147 	.db #0x42	; 66	'B'
      00C4BA 54                    2148 	.db #0x54	; 84	'T'
      00C4BB 60                    2149 	.db #0x60	; 96
      00C4BC 23                    2150 	.db #0x23	; 35
      00C4BD CA                    2151 	.db #0xca	; 202
      00C4BE BC                    2152 	.db #0xbc	; 188
      00C4BF B3                    2153 	.db #0xb3	; 179
      00C4C0 18                    2154 	.db #0x18	; 24
      00C4C1 1D                    2155 	.db #0x1d	; 29
      00C4C2 F8                    2156 	.db #0xf8	; 248
      00C4C3 0A                    2157 	.db #0x0a	; 10
      00C4C4 55                    2158 	.db #0x55	; 85	'U'
      00C4C5 CD                    2159 	.db #0xcd	; 205
      00C4C6 A3                    2160 	.db #0xa3	; 163
      00C4C7 DE                    2161 	.db #0xde	; 222
      00C4C8 FF                    2162 	.db #0xff	; 255
      00C4C9 B2                    2163 	.db #0xb2	; 178
      00C4CA 2A                    2164 	.db #0x2a	; 42
      00C4CB 35                    2165 	.db #0x35	; 53	'5'
      00C4CC 00                    2166 	.db #0x00	; 0
      00C4CD D6                    2167 	.db #0xd6	; 214
      00C4CE 7B                    2168 	.db #0x7b	; 123
      00C4CF E8                    2169 	.db #0xe8	; 232
      00C4D0 F2                    2170 	.db #0xf2	; 242
      00C4D1 1A                    2171 	.db #0x1a	; 26
      00C4D2 BC                    2172 	.db #0xbc	; 188
      00C4D3 F5                    2173 	.db #0xf5	; 245
      00C4D4 7E                    2174 	.db #0x7e	; 126
      00C4D5 48                    2175 	.db #0x48	; 72	'H'
      00C4D6 72                    2176 	.db #0x72	; 114	'r'
      00C4D7 E0                    2177 	.db #0xe0	; 224
      00C4D8 E4                    2178 	.db #0xe4	; 228
      00C4D9 E0                    2179 	.db #0xe0	; 224
      00C4DA 27                    2180 	.db #0x27	; 39
      00C4DB 87                    2181 	.db #0x87	; 135
      00C4DC 9A                    2182 	.db #0x9a	; 154
      00C4DD 51                    2183 	.db #0x51	; 81	'Q'
      00C4DE D4                    2184 	.db #0xd4	; 212
      00C4DF DD                    2185 	.db #0xdd	; 221
      00C4E0 C3                    2186 	.db #0xc3	; 195
      00C4E1 AA                    2187 	.db #0xaa	; 170
      00C4E2 49                    2188 	.db #0x49	; 73	'I'
      00C4E3 5A                    2189 	.db #0x5a	; 90	'Z'
      00C4E4 2A                    2190 	.db #0x2a	; 42
      00C4E5 00                    2191 	.db #0x00	; 0
      00C4E6 A0                    2192 	.db #0xa0	; 160
      00C4E7 8C                    2193 	.db #0x8c	; 140
      00C4E8 FF                    2194 	.db #0xff	; 255
      00C4E9 74                    2195 	.db #0x74	; 116	't'
      00C4EA BF                    2196 	.db #0xbf	; 191
      00C4EB EC                    2197 	.db #0xec	; 236
      00C4EC 1D                    2198 	.db #0x1d	; 29
      00C4ED F1                    2199 	.db #0xf1	; 241
      00C4EE 00                    2200 	.db #0x00	; 0
      00C4EF 01                    2201 	.db #0x01	; 1
      00C4F0 D8                    2202 	.db #0xd8	; 216
      00C4F1 02                    2203 	.db #0x02	; 2
      00C4F2 CC                    2204 	.db #0xcc	; 204
      00C4F3 07                    2205 	.db #0x07	; 7
      00C4F4 00                    2206 	.db #0x00	; 0
      00C4F5 00                    2207 	.db #0x00	; 0
      00C4F6 C4                    2208 	.db #0xc4	; 196
      00C4F7 5E                    2209 	.db #0x5e	; 94
      00C4F8 2C                    2210 	.db #0x2c	; 44
      00C4F9 7E                    2211 	.db #0x7e	; 126
      00C4FA B1                    2212 	.db #0xb1	; 177
      00C4FB C4                    2213 	.db #0xc4	; 196
      00C4FC 67                    2214 	.db #0x67	; 103	'g'
      00C4FD FB                    2215 	.db #0xfb	; 251
      00C4FE 02                    2216 	.db #0x02	; 2
      00C4FF 00                    2217 	.db #0x00	; 0
      00C500 00                    2218 	.db #0x00	; 0
      00C501 00                    2219 	.db #0x00	; 0
      00C502 00                    2220 	.db #0x00	; 0
      00C503 04                    2221 	.db #0x04	; 4
      00C504 59                    2222 	.db #0x59	; 89	'Y'
      00C505 5A                    2223 	.db #0x5a	; 90	'Z'
                                   2224 	.area CSEG    (CODE)
                                   2225 	.area CONST   (CODE)
      00C506                       2226 _vial_handle_cmd_keyboard_uid_40000_624:
      00C506 04                    2227 	.db #0x04	; 4
      00C507 70                    2228 	.db #0x70	; 112	'p'
      00C508 FF                    2229 	.db #0xff	; 255
      00C509 90                    2230 	.db #0x90	; 144
      00C50A 01                    2231 	.db #0x01	; 1
      00C50B B9                    2232 	.db #0xb9	; 185
      00C50C 15                    2233 	.db #0x15	; 21
      00C50D D3                    2234 	.db #0xd3	; 211
                                   2235 	.area CSEG    (CODE)
                                   2236 	.area XINIT   (CODE)
      00C73C                       2237 __xinit__vial_unlocked:
      00C73C 00                    2238 	.db #0x00	;  0
      00C73D                       2239 __xinit__vial_unlock_in_progress:
      00C73D 00                    2240 	.db #0x00	;  0
      00C73E                       2241 __xinit__vial_unlock_counter:
      00C73E 00                    2242 	.db #0x00	; 0
      00C73F                       2243 __xinit__vial_unlock_combo_rows:
      00C73F 00                    2244 	.db #0x00	; 0
      00C740 00                    2245 	.db #0x00	; 0
      00C741                       2246 __xinit__vial_unlock_combo_cols:
      00C741 00                    2247 	.db #0x00	; 0
      00C742 05                    2248 	.db #0x05	; 5
                                   2249 	.area CABS    (ABS,CODE)
                                   2250 
                                   2251 ; Experimental exact instruction outlining.
                                   2252 	.globl _ak820_outline_0005
                                   2253 	.globl _ak820_outline_0009
                                   2254 	.globl _ak820_outline_0010
                                   2255 	.globl _ak820_outline_0011
                                   2256 	.globl _ak820_outline_0012
                                   2257 	.globl _ak820_outline_0014
                                   2258 	.globl _ak820_outline_0016
                                   2259 	.globl _ak820_outline_0019
                                   2260 	.globl _ak820_outline_0020
                                   2261 	.globl _ak820_outline_0024
                                   2262 	.globl _ak820_outline_0026
                                   2263 	.globl _ak820_outline_0034
                                   2264 	.globl _ak820_outline_0035
                                   2265 	.globl _ak820_outline_0036
                                   2266 	.globl _ak820_outline_0037
                                   2267 	.globl _ak820_outline_0042
                                   2268 	.globl _ak820_outline_0059
                                   2269 	.globl _ak820_outline_0062
                                   2270 	.globl _ak820_outline_0063
                                   2271 	.globl _ak820_outline_0066
                                   2272 	.globl _ak820_outline_0072
                                   2273 	.globl _ak820_outline_0077
                                   2274 	.globl _ak820_outline_0082
                                   2275 	.globl _ak820_outline_0099
                                   2276 	.globl _ak820_outline_0105
                                   2277 	.globl _ak820_outline_0106
                                   2278 	.globl _ak820_outline_0121
                                   2279 	.globl _ak820_outline_0125
                                   2280 	.globl _ak820_outline_0127
                                   2281 	.globl _ak820_outline_0129
                                   2282 	.globl _ak820_outline_0130
                                   2283 	.globl _ak820_outline_0131
                                   2284 	.globl _ak820_outline_0133
                                   2285 	.globl _ak820_outline_0134
                                   2286 	.globl _ak820_outline_0139
                                   2287 	.globl _ak820_outline_0142
                                   2288 	.globl _ak820_outline_0146
                                   2289 	.globl _ak820_outline_0153
                                   2290 	.globl _ak820_outline_0162
                                   2291 	.globl _ak820_outline_0174
                                   2292 
                                   2293 	.area CSEG (CODE)
                                   2294 ; function ak820_outline_0010
      00B83B                       2295 _ak820_outline_0010:
      00B83B A3               [24] 2296 	inc	dptr
      00B83C F0               [24] 2297 	movx	@dptr,a
      00B83D E4               [12] 2298 	clr	a
      00B83E A3               [24] 2299 	inc	dptr
      00B83F F0               [24] 2300 	movx	@dptr,a
      00B840 90 0E 87         [24] 2301 	mov	dptr,#___memcpy_PARM_3
      00B843 74 0A            [12] 2302 	mov	a,#0x0a
      00B845 F0               [24] 2303 	movx	@dptr,a
      00B846 E4               [12] 2304 	clr	a
      00B847 A3               [24] 2305 	inc	dptr
      00B848 F0               [24] 2306 	movx	@dptr,a
      00B849 22               [24] 2307 	ret
                                   2308 
                                   2309 	.area CSEG (CODE)
                                   2310 ; function ak820_outline_0026
      00B84A                       2311 _ak820_outline_0026:
      00B84A E0               [24] 2312 	movx	a,@dptr
      00B84B FE               [12] 2313 	mov	r6,a
      00B84C A3               [24] 2314 	inc	dptr
      00B84D E0               [24] 2315 	movx	a,@dptr
      00B84E FF               [12] 2316 	mov	r7,a
      00B84F 90 0D 5C         [24] 2317 	mov	dptr,#_g_vial_magic_keycode_override
      00B852 EE               [12] 2318 	mov	a,r6
      00B853 F0               [24] 2319 	movx	@dptr,a
      00B854 EF               [12] 2320 	mov	a,r7
      00B855 A3               [24] 2321 	inc	dptr
      00B856 F0               [24] 2322 	movx	@dptr,a
      00B857 8E 04            [24] 2323 	mov	ar4,r6
      00B859 8F 05            [24] 2324 	mov	ar5,r7
      00B85B C3               [12] 2325 	clr	c
      00B85C 74 FF            [12] 2326 	mov	a,#0xff
      00B85E 9C               [12] 2327 	subb	a,r4
      00B85F 74 1F            [12] 2328 	mov	a,#0x1f
      00B861 9D               [12] 2329 	subb	a,r5
      00B862 22               [24] 2330 	ret
                                   2331 
                                   2332 	.area CSEG (CODE)
                                   2333 ; function ak820_outline_0133
      00B863                       2334 _ak820_outline_0133:
      00B863 24 09            [12] 2335 	add	a,#_vial_unlock_combo_cols
      00B865 F5 82            [12] 2336 	mov	dpl,a
      00B867 E4               [12] 2337 	clr	a
      00B868 34 0F            [12] 2338 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B86A F5 83            [12] 2339 	mov	dph,a
      00B86C E0               [24] 2340 	movx	a,@dptr
      00B86D 22               [24] 2341 	ret
                                   2342 
                                   2343 	.area CSEG (CODE)
                                   2344 ; function ak820_outline_0134
      00B86E                       2345 _ak820_outline_0134:
      00B86E 24 07            [12] 2346 	add	a,#_vial_unlock_combo_rows
      00B870 F5 82            [12] 2347 	mov	dpl,a
      00B872 E4               [12] 2348 	clr	a
      00B873 34 0F            [12] 2349 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B875 F5 83            [12] 2350 	mov	dph,a
      00B877 E0               [24] 2351 	movx	a,@dptr
      00B878 22               [24] 2352 	ret
