;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module action_layer
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ak820_macro_change
	.globl _ak820_tri_layer_derived
	.globl _ak820_keycode_at
	.globl _action_for_keycode
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _layer_state
	.globl _default_layer_state
	.globl _ak820_resolve_key_PARM_2
	.globl _ak820_cache_layer_PARM_2
	.globl _ak820_cache_keycode_PARM_2
	.globl _default_layer_state_set_user
	.globl _default_layer_state_set_kb
	.globl _default_layer_set
	.globl _default_layer_or
	.globl _default_layer_and
	.globl _default_layer_xor
	.globl _ak820_layer_refresh
	.globl _layer_hold_on
	.globl _layer_hold_off
	.globl _layer_hold_clear
	.globl _layer_state_set_user
	.globl _layer_state_set_kb
	.globl _layer_state_set
	.globl _layer_clear
	.globl _layer_move
	.globl _layer_on
	.globl _layer_off
	.globl _layer_or
	.globl _layer_and
	.globl _layer_xor
	.globl _ak820_cache_keycode
	.globl _ak820_cache_layer
	.globl _ak820_cached_key
	.globl _ak820_resolve_key
	.globl _ak820_layer_for_key
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_default_layer_state_set_user_state_10000_317:
	.ds 1
_default_layer_state_set_kb_state_10000_319:
	.ds 1
_default_layer_state_set_state_10000_321:
	.ds 1
_default_layer_set_state_10000_326:
	.ds 1
_default_layer_or_state_10000_328:
	.ds 1
_default_layer_and_state_10000_330:
	.ds 1
_default_layer_xor_state_10000_332:
	.ds 1
_persistent_layers:
	.ds 1
_layer_refs:
	.ds 6
_macro_layers:
	.ds 1
_ak820_layer_refresh_state_10000_335:
	.ds 1
_layer_hold_on_layer_10000_338:
	.ds 1
_layer_hold_off_layer_10000_342:
	.ds 1
_layer_state_set_user_state_10000_349:
	.ds 1
_layer_state_set_kb_state_10000_351:
	.ds 1
_layer_state_set_state_10000_353:
	.ds 1
_layer_move_layer_10000_366:
	.ds 1
_layer_on_layer_10000_368:
	.ds 1
_layer_off_layer_10000_370:
	.ds 1
_layer_or_state_10000_374:
	.ds 1
_layer_and_state_10000_376:
	.ds 1
_layer_xor_state_10000_378:
	.ds 1
_source_keycodes_cache:
	.ds 256
_encoder_source_keycodes_cache:
	.ds 4
_source_keycode_cache_slot_position_10000_380:
	.ds 2
_ak820_cache_keycode_PARM_2:
	.ds 2
_ak820_cache_keycode_position_10000_386:
	.ds 2
_ak820_cache_layer_PARM_2:
	.ds 1
_ak820_cache_layer_position_10000_389:
	.ds 2
_ak820_cached_key_position_10000_392:
	.ds 2
_ak820_resolve_key_PARM_2:
	.ds 1
_ak820_resolve_key_position_10000_403:
	.ds 2
_ak820_layer_for_key_position_10000_410:
	.ds 2
_ak820_layer_for_key_layers_10000_411:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_default_layer_state::
	.ds 1
_layer_state::
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_190'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function default_layer_state_set_user
;	-----------------------------------------
_default_layer_state_set_user:
	mov	a,dpl
	mov	dptr,#_default_layer_state_set_user_state_10000_317
	lcall	_ak820_outline_0175
;	quantum/action_layer.c:32: return state;
;	quantum/action_layer.c:33: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'default_layer_state_set_kb'
;------------------------------------------------------------
;state         Allocated with name '_default_layer_state_set_kb_state_10000_319'
;------------------------------------------------------------
;	quantum/action_layer.c:39: __attribute__((weak)) layer_state_t default_layer_state_set_kb(layer_state_t state) {
;	-----------------------------------------
;	 function default_layer_state_set_kb
;	-----------------------------------------
_default_layer_state_set_kb:
	mov	a,dpl
	mov	dptr,#_default_layer_state_set_kb_state_10000_319
	lcall	_ak820_outline_0175
;	quantum/action_layer.c:40: return default_layer_state_set_user(state);
;	quantum/action_layer.c:41: }
	ajmp	_default_layer_state_set_user
;------------------------------------------------------------
;Allocation info for local variables in function 'default_layer_state_set'
;------------------------------------------------------------
;state         Allocated with name '_default_layer_state_set_state_10000_321'
;------------------------------------------------------------
;	quantum/action_layer.c:47: static void default_layer_state_set(layer_state_t state) {
;	-----------------------------------------
;	 function default_layer_state_set
;	-----------------------------------------
_default_layer_state_set:
	mov	a,dpl
	mov	dptr,#_default_layer_state_set_state_10000_321
	lcall	_ak820_outline_0175
;	quantum/action_layer.c:48: state = default_layer_state_set_kb(state);
	acall	_default_layer_state_set_kb
	mov	r7, dpl
	mov	dptr,#_default_layer_state_set_state_10000_321
	mov	a,r7
	movx	@dptr,a
;	quantum/action_layer.c:52: default_layer_state = state;
	mov	dptr,#_default_layer_state
	mov	a,r7
	movx	@dptr,a
;	quantum/action_layer.c:54: ak820_layer_refresh();
;	quantum/action_layer.c:57: ac_dprintf("\n");
;	quantum/action_layer.c:63: }
	ajmp	_ak820_layer_refresh
;------------------------------------------------------------
;Allocation info for local variables in function 'default_layer_set'
;------------------------------------------------------------
;state         Allocated with name '_default_layer_set_state_10000_326'
;------------------------------------------------------------
;	quantum/action_layer.c:79: void default_layer_set(layer_state_t state) {
;	-----------------------------------------
;	 function default_layer_set
;	-----------------------------------------
_default_layer_set:
	mov	a,dpl
	mov	dptr,#_default_layer_set_state_10000_326
	lcall	_ak820_outline_0175
;	quantum/action_layer.c:80: default_layer_state_set(state);
;	quantum/action_layer.c:81: }
	ajmp	_default_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'default_layer_or'
;------------------------------------------------------------
;state         Allocated with name '_default_layer_or_state_10000_328'
;------------------------------------------------------------
;	quantum/action_layer.c:88: void default_layer_or(layer_state_t state) {
;	-----------------------------------------
;	 function default_layer_or
;	-----------------------------------------
_default_layer_or:
	mov	a,dpl
	mov	dptr,#_default_layer_or_state_10000_328
	movx	@dptr,a
;	quantum/action_layer.c:89: default_layer_state_set(default_layer_state | state);
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_default_layer_state
	lcall	_ak820_outline_0144
;	quantum/action_layer.c:90: }
	ajmp	_default_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'default_layer_and'
;------------------------------------------------------------
;state         Allocated with name '_default_layer_and_state_10000_330'
;------------------------------------------------------------
;	quantum/action_layer.c:95: void default_layer_and(layer_state_t state) {
;	-----------------------------------------
;	 function default_layer_and
;	-----------------------------------------
_default_layer_and:
	mov	a,dpl
	mov	dptr,#_default_layer_and_state_10000_330
	movx	@dptr,a
;	quantum/action_layer.c:96: default_layer_state_set(default_layer_state & state);
	mov	dptr,#_default_layer_state
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_default_layer_and_state_10000_330
	movx	a,@dptr
	anl	ar7,a
	mov	dpl, r7
;	quantum/action_layer.c:97: }
	ajmp	_default_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'default_layer_xor'
;------------------------------------------------------------
;state         Allocated with name '_default_layer_xor_state_10000_332'
;------------------------------------------------------------
;	quantum/action_layer.c:102: void default_layer_xor(layer_state_t state) {
;	-----------------------------------------
;	 function default_layer_xor
;	-----------------------------------------
_default_layer_xor:
	mov	a,dpl
	mov	dptr,#_default_layer_xor_state_10000_332
	movx	@dptr,a
;	quantum/action_layer.c:103: default_layer_state_set(default_layer_state ^ state);
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_default_layer_state
	movx	a,@dptr
	xrl	ar7,a
	mov	dpl, r7
;	quantum/action_layer.c:104: }
	ajmp	_default_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_layer_refresh'
;------------------------------------------------------------
;state         Allocated with name '_ak820_layer_refresh_state_10000_335'
;i             Allocated with name '_ak820_layer_refresh_i_20000_336'
;------------------------------------------------------------
;	quantum/action_layer.c:114: void ak820_layer_refresh(void) {
;	-----------------------------------------
;	 function ak820_layer_refresh
;	-----------------------------------------
_ak820_layer_refresh:
;	quantum/action_layer.c:115: layer_state_t state = persistent_layers;
	mov	dptr,#_persistent_layers
	movx	a,@dptr
	mov	dptr,#_ak820_layer_refresh_state_10000_335
	movx	@dptr,a
;	quantum/action_layer.c:116: for (uint8_t i = 0; i < MAX_LAYER; ++i) if (layer_refs[i]) state |= (layer_state_t)1 << i;
	mov	r7,#0x00
00105$:
	cjne	r7,#0x06,00131$
00131$:
	jnc	00103$
	mov	a,r7
	add	a, #_layer_refs
	mov	r5,a
	clr	a
	addc	a, #(_layer_refs >> 8)
	mov	r6,a
	lcall	_ak820_outline_0140
	movx	a,@dptr
	jz	00106$
	mov	b,r7
	inc	b
	mov	a,#0x01
	sjmp	00135$
00134$:
	add	a,acc
00135$:
	djnz	b,00134$
	mov	r6,a
	mov	dptr,#_ak820_layer_refresh_state_10000_335
	movx	a,@dptr
	orl	a,r6
	movx	@dptr,a
00106$:
	inc	r7
	sjmp	00105$
00103$:
;	quantum/action_layer.c:118: state |= ak820_tri_layer_derived(state | default_layer_state);
	mov	dptr,#_default_layer_state
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_ak820_layer_refresh_state_10000_335
	movx	a,@dptr
	mov	r6,a
	orl	ar7,a
	mov	dpl, r7
	push	ar6
	lcall	_ak820_tri_layer_derived
	mov	r7, dpl
	pop	ar6
	mov	dptr,#_ak820_layer_refresh_state_10000_335
	mov	a,r7
	orl	a,r6
	lcall	_ak820_outline_0175
;	quantum/action_layer.c:120: layer_state = layer_state_set_kb(state);
	acall	_layer_state_set_kb
	mov	a, dpl
	mov	dptr,#_layer_state
	movx	@dptr,a
;	quantum/action_layer.c:121: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_hold_on'
;------------------------------------------------------------
;layer         Allocated with name '_layer_hold_on_layer_10000_338'
;------------------------------------------------------------
;	quantum/action_layer.c:122: void layer_hold_on(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, true)) { ++layer_refs[layer]; ak820_layer_refresh(); } }
;	-----------------------------------------
;	 function layer_hold_on
;	-----------------------------------------
_layer_hold_on:
	mov	a,dpl
	mov	dptr,#_layer_hold_on_layer_10000_338
	movx	@dptr,a
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x06,00120$
00120$:
	jnc	00104$
	lcall	_ak820_outline_0181
	mov	a,#0x01
	movx	@dptr,a
	mov	dptr,#_macro_layers
	push	ar7
	lcall	_ak820_macro_change
	mov	a, dpl
	pop	ar7
	jz	00104$
	mov	a,r7
	add	a, #_layer_refs
	mov	r7,a
	clr	a
	addc	a, #(_layer_refs >> 8)
	mov	r6,a
	lcall	_ak820_outline_0160
	movx	a,@dptr
	mov	r5,a
	inc	r5
	lcall	_ak820_outline_0160
	mov	a,r5
	movx	@dptr,a
	ajmp	_ak820_layer_refresh
00104$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_hold_off'
;------------------------------------------------------------
;layer         Allocated with name '_layer_hold_off_layer_10000_342'
;------------------------------------------------------------
;	quantum/action_layer.c:123: void layer_hold_off(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, false) && layer_refs[layer]) { --layer_refs[layer]; ak820_layer_refresh(); } }
;	-----------------------------------------
;	 function layer_hold_off
;	-----------------------------------------
_layer_hold_off:
	mov	a,dpl
	mov	dptr,#_layer_hold_off_layer_10000_342
	movx	@dptr,a
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x06,00128$
00128$:
	jnc	00105$
	lcall	_ak820_outline_0181
	clr	a
	movx	@dptr,a
	mov	dptr,#_macro_layers
	push	ar7
	lcall	_ak820_macro_change
	mov	a, dpl
	pop	ar7
	jz	00105$
	mov	a,r7
	add	a, #_layer_refs
	mov	r6,a
	clr	a
	addc	a, #(_layer_refs >> 8)
	mov	r7,a
	lcall	_ak820_outline_0103
	mov	r5,a
	jz	00105$
	dec	r5
	lcall	_ak820_outline_0121
	mov	a,r5
	movx	@dptr,a
	ajmp	_ak820_layer_refresh
00105$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_hold_clear'
;------------------------------------------------------------
;i             Allocated with name '_layer_hold_clear_i_20000_348'
;------------------------------------------------------------
;	quantum/action_layer.c:124: void layer_hold_clear(void) { macro_layers = 0; for (uint8_t i = 0; i < MAX_LAYER; ++i) layer_refs[i] = 0; ak820_layer_refresh(); }
;	-----------------------------------------
;	 function layer_hold_clear
;	-----------------------------------------
_layer_hold_clear:
	mov	dptr,#_macro_layers
	clr	a
	movx	@dptr,a
	mov	r7,a
00103$:
	cjne	r7,#0x06,00122$
00122$:
	jnc	00101$
	mov	a,r7
	add	a, #_layer_refs
	mov	dpl,a
	clr	a
	addc	a, #(_layer_refs >> 8)
	lcall	_ak820_outline_0166
	sjmp	00103$
00101$:
	ajmp	_ak820_layer_refresh
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_state_set_user'
;------------------------------------------------------------
;state         Allocated with name '_layer_state_set_user_state_10000_349'
;------------------------------------------------------------
;	quantum/action_layer.c:131: __attribute__((weak)) layer_state_t layer_state_set_user(layer_state_t state) {
;	-----------------------------------------
;	 function layer_state_set_user
;	-----------------------------------------
_layer_state_set_user:
	mov	a,dpl
	mov	dptr,#_layer_state_set_user_state_10000_349
	lcall	_ak820_outline_0175
;	quantum/action_layer.c:132: return state;
;	quantum/action_layer.c:133: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_state_set_kb'
;------------------------------------------------------------
;state         Allocated with name '_layer_state_set_kb_state_10000_351'
;------------------------------------------------------------
;	quantum/action_layer.c:139: __attribute__((weak)) layer_state_t layer_state_set_kb(layer_state_t state) {
;	-----------------------------------------
;	 function layer_state_set_kb
;	-----------------------------------------
_layer_state_set_kb:
	mov	a,dpl
	mov	dptr,#_layer_state_set_kb_state_10000_351
	lcall	_ak820_outline_0175
;	quantum/action_layer.c:140: return layer_state_set_user(state);
;	quantum/action_layer.c:141: }
	ajmp	_layer_state_set_user
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_state_set'
;------------------------------------------------------------
;state         Allocated with name '_layer_state_set_state_10000_353'
;------------------------------------------------------------
;	quantum/action_layer.c:147: void layer_state_set(layer_state_t state) {
;	-----------------------------------------
;	 function layer_state_set
;	-----------------------------------------
_layer_state_set:
	mov	a,dpl
	mov	dptr,#_layer_state_set_state_10000_353
	movx	@dptr,a
;	quantum/action_layer.c:149: persistent_layers = state;
	movx	a,@dptr
	mov	dptr,#_persistent_layers
	movx	@dptr,a
;	quantum/action_layer.c:150: ak820_layer_refresh();
;	quantum/action_layer.c:151: return;
;	quantum/action_layer.c:159: ac_dprintf("\n");
;	quantum/action_layer.c:165: }
	ajmp	_ak820_layer_refresh
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_clear'
;------------------------------------------------------------
;	quantum/action_layer.c:171: void layer_clear(void) {
;	-----------------------------------------
;	 function layer_clear
;	-----------------------------------------
_layer_clear:
;	quantum/action_layer.c:172: layer_state_set(0);
	mov	dpl, #0x00
;	quantum/action_layer.c:173: }
	ajmp	_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_state_is'
;------------------------------------------------------------
;layer         Allocated with name '_layer_state_is_layer_10000_360'
;------------------------------------------------------------
;	quantum/action_layer.c:179: bool layer_state_is(uint8_t layer) {
;	-----------------------------------------
;	 function layer_move
;	-----------------------------------------
_layer_move:
	mov	a,dpl
	mov	dptr,#_layer_move_layer_10000_366
	movx	@dptr,a
;	quantum/action_layer.c:199: layer_state_set((layer_state_t)1 << layer);
	movx	a,@dptr
	lcall	_ak820_outline_0068
	sjmp	00104$
00103$:
	add	a,acc
00104$:
	djnz	b,00103$
	mov	dpl,a
;	quantum/action_layer.c:200: }
	ajmp	_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_on'
;------------------------------------------------------------
;layer         Allocated with name '_layer_on_layer_10000_368'
;------------------------------------------------------------
;	quantum/action_layer.c:206: void layer_on(uint8_t layer) {
;	-----------------------------------------
;	 function layer_on
;	-----------------------------------------
_layer_on:
	mov	a,dpl
	mov	dptr,#_layer_on_layer_10000_368
	movx	@dptr,a
;	quantum/action_layer.c:213: ((layer_state_t)1 << layer));
	movx	a,@dptr
	lcall	_ak820_outline_0068
	sjmp	00104$
00103$:
	add	a,acc
00104$:
	djnz	b,00103$
	mov	r7,a
	mov	dptr,#_persistent_layers
	lcall	_ak820_outline_0144
;	quantum/action_layer.c:214: }
	ajmp	_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_off'
;------------------------------------------------------------
;layer         Allocated with name '_layer_off_layer_10000_370'
;------------------------------------------------------------
;	quantum/action_layer.c:220: void layer_off(uint8_t layer) {
;	-----------------------------------------
;	 function layer_off
;	-----------------------------------------
_layer_off:
	mov	a,dpl
	mov	dptr,#_layer_off_layer_10000_370
	movx	@dptr,a
;	quantum/action_layer.c:227: ~((layer_state_t)1 << layer));
	movx	a,@dptr
	lcall	_ak820_outline_0068
	sjmp	00104$
00103$:
	add	a,acc
00104$:
	djnz	b,00103$
	cpl	a
	mov	r7,a
	mov	dptr,#_persistent_layers
	movx	a,@dptr
	anl	ar7,a
	mov	dpl, r7
;	quantum/action_layer.c:228: }
	ajmp	_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_invert'
;------------------------------------------------------------
;layer         Allocated with name '_layer_invert_layer_10000_372'
;------------------------------------------------------------
;	quantum/action_layer.c:234: void layer_invert(uint8_t layer) {
;	-----------------------------------------
;	 function layer_or
;	-----------------------------------------
_layer_or:
	mov	a,dpl
	mov	dptr,#_layer_or_state_10000_374
	movx	@dptr,a
;	quantum/action_layer.c:255: state);
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_persistent_layers
	lcall	_ak820_outline_0144
;	quantum/action_layer.c:256: }
	ajmp	_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_and'
;------------------------------------------------------------
;state         Allocated with name '_layer_and_state_10000_376'
;------------------------------------------------------------
;	quantum/action_layer.c:261: void layer_and(layer_state_t state) {
;	-----------------------------------------
;	 function layer_and
;	-----------------------------------------
_layer_and:
	mov	a,dpl
	mov	dptr,#_layer_and_state_10000_376
	movx	@dptr,a
;	quantum/action_layer.c:268: state);
	mov	dptr,#_persistent_layers
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_layer_and_state_10000_376
	movx	a,@dptr
	anl	ar7,a
	mov	dpl, r7
;	quantum/action_layer.c:269: }
	ajmp	_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_xor'
;------------------------------------------------------------
;state         Allocated with name '_layer_xor_state_10000_378'
;------------------------------------------------------------
;	quantum/action_layer.c:274: void layer_xor(layer_state_t state) {
;	-----------------------------------------
;	 function layer_xor
;	-----------------------------------------
_layer_xor:
	mov	a,dpl
	mov	dptr,#_layer_xor_state_10000_378
	movx	@dptr,a
;	quantum/action_layer.c:281: state);
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_persistent_layers
	movx	a,@dptr
	xrl	ar7,a
	mov	dpl, r7
;	quantum/action_layer.c:282: }
	ajmp	_layer_state_set
;------------------------------------------------------------
;Allocation info for local variables in function 'source_keycode_cache_slot'
;------------------------------------------------------------
;position      Allocated with name '_source_keycode_cache_slot_position_10000_380'
;row           Allocated with name '_source_keycode_cache_slot_row_10000_381'
;col           Allocated with name '_source_keycode_cache_slot_col_10000_381'
;------------------------------------------------------------
;	quantum/action_layer.c:324: static uint16_t SOURCE_CACHE_MEM *source_keycode_cache_slot(uint16_t position) {
;	-----------------------------------------
;	 function source_keycode_cache_slot
;	-----------------------------------------
_source_keycode_cache_slot:
	lcall	_ak820_outline_0106
	mov	dptr,#_source_keycode_cache_slot_position_10000_380
	lcall	_ak820_outline_0105
;	quantum/action_layer.c:325: uint8_t row = position >> 8, col = position;
	mov	dptr,#_source_keycode_cache_slot_position_10000_380
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	quantum/action_layer.c:326: if (row < MATRIX_ROWS && col < MATRIX_COLS) {
	cjne	r5,#0x10,00147$
00147$:
	jnc	00102$
	cjne	r6,#0x08,00149$
00149$:
	jnc	00102$
;	quantum/action_layer.c:327: return &source_keycodes_cache[(uint8_t)(row * MATRIX_COLS + col)];
	mov	ar7,r5
	mov	a,r7
	lcall	_ak820_outline_0176
	mov	r7,a
	mov	ar4,r6
	mov	a,r4
	add	a, r7
	mov	b,#0x02
	mul	ab
	add	a, #_source_keycodes_cache
	mov	r4,a
	mov	a,#(_source_keycodes_cache >> 8)
	addc	a, b
	mov	r7,a
	lcall	_ak820_outline_0188
	ret
00102$:
;	quantum/action_layer.c:330: if ((row == KEYLOC_ENCODER_CW || row == KEYLOC_ENCODER_CCW) && col < NUM_ENCODERS) {
	cjne	r5,#0xfd,00151$
	sjmp	00107$
00151$:
	cjne	r5,#0xfc,00105$
00107$:
	cjne	r6,#0x01,00154$
00154$:
	jnc	00105$
;	quantum/action_layer.c:331: return &encoder_source_keycodes_cache[col + (row == KEYLOC_ENCODER_CCW ? NUM_ENCODERS : 0)];
	cjne	r5,#0xfc,00110$
	mov	r7,#0x01
	sjmp	00111$
00110$:
	mov	r7,#0x00
00111$:
	clr	F0
	mov	b,#0x02
	mov	a,r7
	jnb	acc.7,00158$
	cpl	F0
	cpl	a
	inc	a
00158$:
	mul	ab
	jnb	F0,00159$
	lcall	_ak820_outline_0136
00159$:
	add	a, #_encoder_source_keycodes_cache
	mov	r6,a
	mov	a,#(_encoder_source_keycodes_cache >> 8)
	addc	a, b
	mov	r7,a
	lcall	_ak820_outline_0121
	ret
00105$:
;	quantum/action_layer.c:334: return 0;
	mov	dptr,#0x0000
;	quantum/action_layer.c:335: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_cache_keycode'
;------------------------------------------------------------
;keycode       Allocated with name '_ak820_cache_keycode_PARM_2'
;position      Allocated with name '_ak820_cache_keycode_position_10000_386'
;slot          Allocated with name '_ak820_cache_keycode_slot_10000_387'
;------------------------------------------------------------
;	quantum/action_layer.c:339: bool ak820_cache_keycode(uint16_t position, uint16_t keycode) {
;	-----------------------------------------
;	 function ak820_cache_keycode
;	-----------------------------------------
_ak820_cache_keycode:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_cache_keycode_position_10000_386
	lcall	_ak820_outline_0105
;	quantum/action_layer.c:340: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
	mov	dptr,#_ak820_cache_keycode_position_10000_386
	lcall	_ak820_outline_0005
	acall	_source_keycode_cache_slot
	lcall	_ak820_outline_0139
;	quantum/action_layer.c:341: if (!slot) return false;
	mov	a,r6
	orl	a,r7
	jnz	00102$
	mov	dpl,a
	ret
00102$:
;	quantum/action_layer.c:342: *slot = keycode;
	mov	dptr,#_ak820_cache_keycode_PARM_2
	lcall	_ak820_outline_0065
	lcall	_ak820_outline_0121
	lcall	_ak820_outline_0079
;	quantum/action_layer.c:343: return true;
	mov	dpl, #0x01
;	quantum/action_layer.c:344: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_cache_layer'
;------------------------------------------------------------
;layer         Allocated with name '_ak820_cache_layer_PARM_2'
;position      Allocated with name '_ak820_cache_layer_position_10000_389'
;slot          Allocated with name '_ak820_cache_layer_slot_10000_390'
;------------------------------------------------------------
;	quantum/action_layer.c:346: void ak820_cache_layer(uint16_t position, uint8_t layer) {
;	-----------------------------------------
;	 function ak820_cache_layer
;	-----------------------------------------
_ak820_cache_layer:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_cache_layer_position_10000_389
	lcall	_ak820_outline_0105
;	quantum/action_layer.c:347: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
	mov	dptr,#_ak820_cache_layer_position_10000_389
	lcall	_ak820_outline_0005
	push	ar7
	push	ar6
	acall	_source_keycode_cache_slot
	lcall	_ak820_outline_0154
	pop	ar6
	pop	ar7
;	quantum/action_layer.c:348: if (!slot) return;
	mov	a,r4
	orl	a,r5
	jnz	00102$
	ret
00102$:
;	quantum/action_layer.c:349: layer &= (1u << MAX_LAYER_BITS) - 1;
	mov	dptr,#_ak820_cache_layer_PARM_2
	movx	a,@dptr
	anl	acc,#0x07
	movx	@dptr,a
;	quantum/action_layer.c:361: *slot = ak820_keycode_at(layer, position);
	mov	dptr,#_ak820_cache_layer_PARM_2
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_ak820_keycode_at_PARM_2
	lcall	_ak820_outline_0066
	mov	dpl, r3
	push	ar5
	push	ar4
	lcall	_ak820_keycode_at
	lcall	_ak820_outline_0139
	pop	ar4
	pop	ar5
	lcall	_ak820_outline_0129
	lcall	_ak820_outline_0066
;	quantum/action_layer.c:362: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_cached_key'
;------------------------------------------------------------
;position      Allocated with name '_ak820_cached_key_position_10000_392'
;slot          Allocated with name '_ak820_cached_key_slot_10001_396'
;------------------------------------------------------------
;	quantum/action_layer.c:383: uint16_t ak820_cached_key(uint16_t position) {
;	-----------------------------------------
;	 function ak820_cached_key
;	-----------------------------------------
_ak820_cached_key:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_cached_key_position_10000_392
	lcall	_ak820_outline_0105
;	quantum/action_layer.c:386: if (vial_unlock_in_progress) return KC_NO;
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	jz	00102$
	mov	dptr,#0x0000
	ret
00102$:
;	quantum/action_layer.c:387: if (position == (((uint16_t)VIAL_MATRIX_MAGIC << 8) | VIAL_MATRIX_MAGIC)) return g_vial_magic_keycode_override;
	mov	dptr,#_ak820_cached_key_position_10000_392
	lcall	_ak820_outline_0059
	cjne	r6,#0xf0,00104$
	cjne	r7,#0xf0,00104$
	mov	dptr,#_g_vial_magic_keycode_override
	lcall	_ak820_outline_0065
	lcall	_ak820_outline_0129
	ret
00104$:
;	quantum/action_layer.c:389: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
	lcall	_ak820_outline_0121
	acall	_source_keycode_cache_slot
	lcall	_ak820_outline_0139
;	quantum/action_layer.c:390: return slot ? *slot : KC_NO;
	mov	a,r6
	orl	a,r7
	jz	00107$
	lcall	_ak820_outline_0121
	lcall	_ak820_outline_0059
	sjmp	00108$
00107$:
	mov	r6,#0x00
	mov	r7,#0x00
00108$:
	lcall	_ak820_outline_0121
;	quantum/action_layer.c:391: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'update_source_keycode_cache'
;------------------------------------------------------------
;key           Allocated with name '_update_source_keycode_cache_PARM_1'
;keycode       Allocated with name '_update_source_keycode_cache_keycode_10000_397'
;------------------------------------------------------------
;	quantum/action_layer.c:394: bool update_source_keycode_cache(keypos_t key, uint16_t keycode) {
;	-----------------------------------------
;	 function ak820_resolve_key
;	-----------------------------------------
_ak820_resolve_key:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_resolve_key_position_10000_403
	lcall	_ak820_outline_0105
;	quantum/action_layer.c:493: if (disable_action_cache) {
	mov	dptr,#_disable_action_cache
	movx	a,@dptr
	jz	00102$
;	quantum/action_layer.c:494: return ak820_keycode_at(ak820_layer_for_key(position), position);
	mov	dptr,#_ak820_resolve_key_position_10000_403
	lcall	_ak820_outline_0005
	push	ar7
	push	ar6
	acall	_ak820_layer_for_key
	mov	r5, dpl
	pop	ar6
	pop	ar7
	mov	dptr,#_ak820_keycode_at_PARM_2
	lcall	_ak820_outline_0066
	mov	dpl, r5
	ljmp	_ak820_keycode_at
00102$:
;	quantum/action_layer.c:496: if (cache_press) ak820_cache_layer(position, ak820_layer_for_key(position));
	mov	dptr,#_ak820_resolve_key_PARM_2
	movx	a,@dptr
	jz	00104$
	mov	dptr,#_ak820_resolve_key_position_10000_403
	lcall	_ak820_outline_0005
	push	ar7
	push	ar6
	acall	_ak820_layer_for_key
	mov	a, dpl
	pop	ar6
	pop	ar7
	mov	dptr,#_ak820_cache_layer_PARM_2
	lcall	_ak820_outline_0072
	acall	_ak820_cache_layer
00104$:
;	quantum/action_layer.c:497: return ak820_cached_key(position);
	mov	dptr,#_ak820_resolve_key_position_10000_403
	lcall	_ak820_outline_0005
;	quantum/action_layer.c:498: }
	ajmp	_ak820_cached_key
;------------------------------------------------------------
;Allocation info for local variables in function 'store_or_get_action'
;------------------------------------------------------------
;key           Allocated with name '_store_or_get_action_PARM_2'
;pressed       Allocated with name '_store_or_get_action_pressed_10000_408'
;------------------------------------------------------------
;	quantum/action_layer.c:499: uint16_t store_or_get_action(bool pressed, keypos_t key) {
;	-----------------------------------------
;	 function ak820_layer_for_key
;	-----------------------------------------
_ak820_layer_for_key:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_layer_for_key_position_10000_410
	lcall	_ak820_outline_0105
;	quantum/action_layer.c:539: layer_state_t layers = layer_state | default_layer_state;
	mov	dptr,#_default_layer_state
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_layer_state
	movx	a,@dptr
	mov	dptr,#_ak820_layer_for_key_layers_10000_411
	orl	a,r7
	movx	@dptr,a
;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
	mov	dptr,#_ak820_layer_for_key_position_10000_410
	lcall	_ak820_outline_0059
	mov	r5,#0x05
00107$:
	mov	a,r5
	jb	acc.7,00105$
;	quantum/action_layer.c:542: if (layers & ((layer_state_t)1 << i)) {
	mov	b,r5
	inc	b
	mov	r3,#0x01
	mov	r4,#0x00
	sjmp	00141$
00140$:
	mov	a,r3
	add	a,r3
	mov	r3,a
	mov	a,r4
	rlc	a
	mov	r4,a
00141$:
	djnz	b,00140$
	mov	dptr,#_ak820_layer_for_key_layers_10000_411
	movx	a,@dptr
	mov	r2,#0x00
	anl	ar3,a
	mov	a,r2
	anl	ar4,a
	mov	a,r3
	orl	a,r4
	jz	00108$
;	quantum/action_layer.c:546: if (ak820_keycode_at(i, position) != KC_TRANSPARENT) {
	mov	dptr,#_ak820_keycode_at_PARM_2
	lcall	_ak820_outline_0066
	mov	dpl, r5
	push	ar7
	push	ar6
	push	ar5
	lcall	_ak820_keycode_at
	mov	r3, dpl
	mov	r4, dph
	pop	ar5
	pop	ar6
	pop	ar7
	cjne	r3,#0x01,00143$
	cjne	r4,#0x00,00143$
	sjmp	00108$
00143$:
;	quantum/action_layer.c:555: return i;
	mov	dpl, r5
	ret
00108$:
;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
	dec	r5
	sjmp	00107$
00105$:
;	quantum/action_layer.c:560: return 0;
	mov	dpl, #0x00
;	quantum/action_layer.c:565: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'layer_switch_get_layer'
;------------------------------------------------------------
;key           Allocated with name '_layer_switch_get_layer_PARM_1'
;------------------------------------------------------------
;	quantum/action_layer.c:567: uint8_t layer_switch_get_layer(keypos_t key) {
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__default_layer_state:
	.db #0x00	; 0
__xinit__layer_state:
	.db #0x00	; 0
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0005
	.globl _ak820_outline_0059
	.globl _ak820_outline_0065
	.globl _ak820_outline_0066
	.globl _ak820_outline_0068
	.globl _ak820_outline_0072
	.globl _ak820_outline_0079
	.globl _ak820_outline_0103
	.globl _ak820_outline_0105
	.globl _ak820_outline_0106
	.globl _ak820_outline_0121
	.globl _ak820_outline_0129
	.globl _ak820_outline_0136
	.globl _ak820_outline_0139
	.globl _ak820_outline_0140
	.globl _ak820_outline_0144
	.globl _ak820_outline_0154
	.globl _ak820_outline_0160
	.globl _ak820_outline_0166
	.globl _ak820_outline_0175
	.globl _ak820_outline_0176
	.globl _ak820_outline_0181
	.globl _ak820_outline_0188

	.area CSEG (CODE)
; function ak820_outline_0144
_ak820_outline_0144:
	movx	a,@dptr
	orl	ar7,a
	mov	dpl,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0166
_ak820_outline_0166:
	mov	dph,a
	clr	a
	movx	@dptr,a
	inc	r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0181
_ak820_outline_0181:
	mov	dptr,#_ak820_macro_change_PARM_2
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#_ak820_macro_change_PARM_3
	ret
