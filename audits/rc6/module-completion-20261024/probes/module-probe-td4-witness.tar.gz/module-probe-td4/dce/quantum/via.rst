                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000038                        553 _raw_hid_receive_sloc0_1_0:
      000038                        554 	.ds 4
      00003C                        555 _raw_hid_receive_sloc1_1_0:
      00003C                        556 	.ds 1
      00003D                        557 _raw_hid_receive_sloc2_1_0:
      00003D                        558 	.ds 1
      00003E                        559 _raw_hid_receive_sloc3_1_0:
      00003E                        560 	.ds 2
      000040                        561 _raw_hid_receive_sloc4_1_0:
      000040                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002C                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002C                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000D14                        589 _via_eeprom_set_valid_valid_10000_611:
      000D14                        590 	.ds 1
      000D15                        591 _via_set_layout_options_value_10000_627:
      000D15                        592 	.ds 4
      000D19                        593 _process_record_via_PARM_2:
      000D19                        594 	.ds 3
      000D1C                        595 _process_record_via_keycode_10000_629:
      000D1C                        596 	.ds 2
      000D1E                        597 _raw_hid_receive_kb_PARM_2:
      000D1E                        598 	.ds 1
      000D1F                        599 _raw_hid_receive_kb_data_10000_635:
      000D1F                        600 	.ds 3
      000D22                        601 _raw_hid_receive_PARM_2:
      000D22                        602 	.ds 1
      000D23                        603 _raw_hid_receive_packet_10000_637:
      000D23                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00AAF4                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00AAF4 90 00 25         [24]  658 	mov	dptr,#0x0025
      00AAF7 75 F0 00         [24]  659 	mov	b, #0x00
      00AAFA 12 40 72         [24]  660 	lcall	_eeprom_read_byte
      00AAFD AF 82            [24]  661 	mov	r7, dpl
      00AAFF BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00AB02 90 00 26         [24]  663 	mov	dptr,#0x0026
      00AB05 75 F0 00         [24]  664 	mov	b, #0x00
      00AB08 12 40 72         [24]  665 	lcall	_eeprom_read_byte
      00AB0B AF 82            [24]  666 	mov	r7, dpl
      00AB0D BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00AB10 90 00 27         [24]  668 	mov	dptr,#0x0027
      00AB13 75 F0 00         [24]  669 	mov	b, #0x00
      00AB16 12 40 72         [24]  670 	lcall	_eeprom_read_byte
      00AB19 AF 82            [24]  671 	mov	r7, dpl
      00AB1B BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00AB1E 80 04            [24]  673 	sjmp	00104$
      00AB20                        674 00126$:
      00AB20                        675 00103$:
                                    676 ;	assignBit
      00AB20 C2 2C            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00AB22 80 02            [24]  678 	sjmp	00105$
      00AB24                        679 00104$:
                                    680 ;	assignBit
      00AB24 D2 2C            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00AB26                        682 00105$:
      00AB26 A2 2C            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00AB28 12 38 AC         [24]  684 	lcall	_ak820_outline_0147
                                    685 ;	quantum/via.c:104: }
      00AB2B 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_611'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_612'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_612'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_612'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00AB2C                        699 _via_eeprom_set_valid:
      00AB2C E5 82            [12]  700 	mov	a,dpl
      00AB2E 90 0D 14         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AB31 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00AB32 E0               [24]  704 	movx	a,@dptr
      00AB33 60 04            [24]  705 	jz	00103$
      00AB35 7F 03            [12]  706 	mov	r7,#0x03
      00AB37 80 02            [24]  707 	sjmp	00104$
      00AB39                        708 00103$:
      00AB39 7F FF            [12]  709 	mov	r7,#0xff
      00AB3B                        710 00104$:
      00AB3B 90 07 64         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB3E EF               [12]  712 	mov	a,r7
      00AB3F F0               [24]  713 	movx	@dptr,a
      00AB40 90 00 25         [24]  714 	mov	dptr,#0x0025
      00AB43 75 F0 00         [24]  715 	mov	b, #0x00
      00AB46 12 53 3A         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00AB49 90 0D 14         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AB4C E0               [24]  719 	movx	a,@dptr
      00AB4D 60 04            [24]  720 	jz	00105$
      00AB4F 7F 20            [12]  721 	mov	r7,#0x20
      00AB51 80 02            [24]  722 	sjmp	00106$
      00AB53                        723 00105$:
      00AB53 7F FF            [12]  724 	mov	r7,#0xff
      00AB55                        725 00106$:
      00AB55 90 07 64         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB58 EF               [12]  727 	mov	a,r7
      00AB59 F0               [24]  728 	movx	@dptr,a
      00AB5A 90 00 26         [24]  729 	mov	dptr,#0x0026
      00AB5D 75 F0 00         [24]  730 	mov	b, #0x00
      00AB60 12 53 3A         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00AB63 90 0D 14         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AB66 E0               [24]  734 	movx	a,@dptr
      00AB67 60 04            [24]  735 	jz	00107$
      00AB69 7F 08            [12]  736 	mov	r7,#0x08
      00AB6B 80 02            [24]  737 	sjmp	00108$
      00AB6D                        738 00107$:
      00AB6D 7F FF            [12]  739 	mov	r7,#0xff
      00AB6F                        740 00108$:
      00AB6F 90 07 64         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB72 EF               [12]  742 	mov	a,r7
      00AB73 F0               [24]  743 	movx	@dptr,a
      00AB74 90 00 27         [24]  744 	mov	dptr,#0x0027
      00AB77 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00AB7A 02 53 3A         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00AB7D                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00AB7D 71 A0            [12]  757 	acall	_via_get_layout_options
      00AB7F 71 B8            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00AB81 51 F4            [12]  760 	acall	_via_eeprom_is_valid
      00AB83 E5 82            [12]  761 	mov	a, dpl
      00AB85 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00AB87 02 3E 21         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00AB8A                        766 00103$:
      00AB8A 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00AB8B                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00AB8B 75 82 00         [24]  777 	mov	dpl, #0x00
      00AB8E 71 2C            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00AB90 12 95 F8         [24]  780 	lcall	_ak820_outline_0157
      00AB93 71 B9            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00AB95 12 8C 32         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00AB98 12 90 E6         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00AB9B 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00AB9E 61 2C            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00ABA0                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00ABA0 90 00 28         [24]  799 	mov	dptr,#0x0028
      00ABA3 75 F0 00         [24]  800 	mov	b, #0x00
      00ABA6 12 40 72         [24]  801 	lcall	_eeprom_read_byte
      00ABA9 AF 82            [24]  802 	mov	r7, dpl
      00ABAB 7E 00            [12]  803 	mov	r6,#0x00
      00ABAD 7D 00            [12]  804 	mov	r5,#0x00
      00ABAF 7C 00            [12]  805 	mov	r4,#0x00
      00ABB1 12 43 77         [24]  806 	lcall	_ak820_outline_0160
      00ABB4 8D F0            [24]  807 	mov	b, r5
      00ABB6 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00ABB7 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_624'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00ABB8                        820 _via_set_layout_options_kb:
      00ABB8 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_627'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00ABB9                        831 _via_set_layout_options:
      00ABB9 12 95 F0         [24]  832 	lcall	_ak820_outline_0124
      00ABBC 90 0D 15         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_627
      00ABBF 12 95 DE         [24]  834 	lcall	_ak820_outline_0049
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00ABC2 90 0D 15         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_627
      00ABC5 E0               [24]  837 	movx	a,@dptr
      00ABC6 90 07 64         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00ABC9 F0               [24]  839 	movx	@dptr,a
      00ABCA 90 00 28         [24]  840 	mov	dptr,#0x0028
      00ABCD 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00ABD0 02 53 3A         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_629'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_634'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00ABD3                        855 _process_record_via:
      00ABD3 12 38 7A         [24]  856 	lcall	_ak820_outline_0106
      00ABD6 90 0D 1C         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_629
      00ABD9 12 38 75         [24]  858 	lcall	_ak820_outline_0105
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00ABDC 90 0D 19         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00ABDF 12 54 4B         [24]  861 	lcall	_ak820_outline_0015
      00ABE2 74 05            [12]  862 	mov	a,#0x05
      00ABE4 12 38 B6         [24]  863 	lcall	_ak820_outline_0163
      00ABE7 12 54 54         [24]  864 	lcall	_ak820_outline_0052
      00ABEA 12 BE E5         [24]  865 	lcall	__gptrget
      00ABED 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00ABEF 90 0D 1C         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_629
      00ABF2 12 4D DC         [24]  869 	lcall	_ak820_outline_0012
      00ABF5 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00ABF7 2D               [12]  871 	add	a,r5
      00ABF8 50 12            [24]  872 	jnc	00105$
      00ABFA C3               [12]  873 	clr	c
      00ABFB 74 7F            [12]  874 	mov	a,#0x7f
      00ABFD 9C               [12]  875 	subb	a,r4
      00ABFE 74 77            [12]  876 	mov	a,#0x77
      00AC00 9D               [12]  877 	subb	a,r5
      00AC01 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00AC03 8E 82            [24]  882 	mov	dpl, r6
      00AC05 12 91 0C         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00AC08 75 82 00         [24]  885 	mov	dpl, #0x00
      00AC0B 22               [24]  886 	ret
      00AC0C                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00AC0C 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00AC0F 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_635'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_636'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00AC10                        903 _raw_hid_receive_kb:
      00AC10 12 43 11         [24]  904 	lcall	_ak820_outline_0042
      00AC13 90 0D 1F         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AC16 12 38 0D         [24]  906 	lcall	_ak820_outline_0019
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00AC19 90 0D 1F         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AC1C 12 54 25         [24]  909 	lcall	_ak820_outline_0002
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00AC1F 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00AC21 02 BE AA         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_637'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_638'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_638'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_638'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_644'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_652'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_653'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_656'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_657'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_658'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_663'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_665'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_674'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_675'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_675'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_680'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_680'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_687'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_687'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_692'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00AC24                        950 _raw_hid_receive:
      00AC24 12 43 11         [24]  951 	lcall	_ak820_outline_0042
      00AC27 90 0D 23         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AC2A 12 38 0D         [24]  953 	lcall	_ak820_outline_0019
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00AC2D 90 0D 23         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AC30 12 38 2E         [24]  956 	lcall	_ak820_outline_0059
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00AC33 74 01            [12]  958 	mov	a,#0x01
      00AC35 12 43 7C         [24]  959 	lcall	_ak820_outline_0164
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00AC38 90 0D 22         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00AC3B E0               [24]  962 	movx	a,@dptr
      00AC3C FB               [12]  963 	mov	r3,a
      00AC3D BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00AC40 80 01            [24]  965 	sjmp	00102$
      00AC42                        966 00520$:
      00AC42 22               [24]  967 	ret
      00AC43                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AC43 90 0F 05         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00AC46 E0               [24]  971 	movx	a,@dptr
      00AC47 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AC49 12 38 6F         [24]  974 	lcall	_ak820_outline_0103
      00AC4C FA               [12]  975 	mov	r2,a
      00AC4D BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00AC50 80 01            [24]  977 	sjmp	00104$
      00AC52                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00AC52 22               [24]  980 	ret
      00AC53                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AC53 12 43 49         [24]  983 	lcall	_ak820_outline_0083
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AC56 FA               [12]  985 	mov	r2,a
      00AC57 60 21            [24]  986 	jz	00114$
      00AC59 BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00AC5C 80 1C            [24]  988 	sjmp	00114$
      00AC5E                        989 00524$:
      00AC5E BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00AC61 80 17            [24]  991 	sjmp	00114$
      00AC63                        992 00525$:
      00AC63 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00AC66 80 12            [24]  994 	sjmp	00114$
      00AC68                        995 00526$:
      00AC68 BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00AC6B 80 0D            [24]  997 	sjmp	00114$
      00AC6D                        998 00527$:
      00AC6D BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00AC70 80 08            [24] 1000 	sjmp	00114$
      00AC72                       1001 00528$:
      00AC72 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00AC75 80 03            [24] 1003 	sjmp	00530$
      00AC77                       1004 00529$:
      00AC77 02 B1 9A         [24] 1005 	ljmp	00171$
      00AC7A                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00AC7A                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00AC7A 12 38 6F         [24] 1010 	lcall	_ak820_outline_0103
      00AC7D FA               [12] 1011 	mov	r2,a
      00AC7E BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00AC81 80 68            [24] 1013 	sjmp	00115$
      00AC83                       1014 00531$:
      00AC83 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00AC86 80 70            [24] 1016 	sjmp	00116$
      00AC88                       1017 00532$:
      00AC88 BA 03 02         [24] 1018 	cjne	r2,#0x03,00533$
      00AC8B A1 B6            [24] 1019 	ajmp	00125$
      00AC8D                       1020 00533$:
      00AC8D BA 04 02         [24] 1021 	cjne	r2,#0x04,00534$
      00AC90 C1 4A            [12] 1022 	ajmp	00129$
      00AC92                       1023 00534$:
      00AC92 BA 05 02         [24] 1024 	cjne	r2,#0x05,00535$
      00AC95 C1 84            [12] 1025 	ajmp	00130$
      00AC97                       1026 00535$:
      00AC97 BA 06 02         [24] 1027 	cjne	r2,#0x06,00536$
      00AC9A C1 F0            [12] 1028 	ajmp	00135$
      00AC9C                       1029 00536$:
      00AC9C BA 07 02         [24] 1030 	cjne	r2,#0x07,00537$
      00AC9F E1 02            [12] 1031 	ajmp	00136$
      00ACA1                       1032 00537$:
      00ACA1 BA 08 02         [24] 1033 	cjne	r2,#0x08,00538$
      00ACA4 E1 1D            [12] 1034 	ajmp	00137$
      00ACA6                       1035 00538$:
      00ACA6 BA 09 03         [24] 1036 	cjne	r2,#0x09,00539$
      00ACA9 02 AF 38         [24] 1037 	ljmp	00138$
      00ACAC                       1038 00539$:
      00ACAC BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00ACAF 02 B1 2A         [24] 1040 	ljmp	00161$
      00ACB2                       1041 00540$:
      00ACB2 BA 0C 03         [24] 1042 	cjne	r2,#0x0c,00541$
      00ACB5 02 AF 53         [24] 1043 	ljmp	00139$
      00ACB8                       1044 00541$:
      00ACB8 BA 0D 03         [24] 1045 	cjne	r2,#0x0d,00542$
      00ACBB 02 AF 74         [24] 1046 	ljmp	00140$
      00ACBE                       1047 00542$:
      00ACBE BA 0E 03         [24] 1048 	cjne	r2,#0x0e,00543$
      00ACC1 02 AF 9D         [24] 1049 	ljmp	00141$
      00ACC4                       1050 00543$:
      00ACC4 BA 0F 03         [24] 1051 	cjne	r2,#0x0f,00544$
      00ACC7 02 AF E5         [24] 1052 	ljmp	00144$
      00ACCA                       1053 00544$:
      00ACCA BA 10 03         [24] 1054 	cjne	r2,#0x10,00545$
      00ACCD 02 B0 53         [24] 1055 	ljmp	00151$
      00ACD0                       1056 00545$:
      00ACD0 BA 11 03         [24] 1057 	cjne	r2,#0x11,00546$
      00ACD3 02 B0 6B         [24] 1058 	ljmp	00154$
      00ACD6                       1059 00546$:
      00ACD6 BA 12 03         [24] 1060 	cjne	r2,#0x12,00547$
      00ACD9 02 B0 8B         [24] 1061 	ljmp	00155$
      00ACDC                       1062 00547$:
      00ACDC BA 13 03         [24] 1063 	cjne	r2,#0x13,00548$
      00ACDF 02 B0 D1         [24] 1064 	ljmp	00158$
      00ACE2                       1065 00548$:
      00ACE2 BA FE 03         [24] 1066 	cjne	r2,#0xfe,00549$
      00ACE5 02 B1 69         [24] 1067 	ljmp	00168$
      00ACE8                       1068 00549$:
      00ACE8 02 B1 82         [24] 1069 	ljmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00ACEB                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00ACEB 12 38 98         [24] 1073 	lcall	_ak820_outline_0129
      00ACEE E4               [12] 1074 	clr	a
      00ACEF 12 43 09         [24] 1075 	lcall	_ak820_outline_0037
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00ACF2 74 09            [12] 1077 	mov	a,#0x09
      00ACF4 F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00ACF5 02 B1 9A         [24] 1080 	ljmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00ACF8                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00ACF8 12 43 49         [24] 1084 	lcall	_ak820_outline_0083
      00ACFB FA               [12] 1085 	mov	r2,a
      00ACFC BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00ACFF 80 0C            [24] 1087 	sjmp	00117$
      00AD01                       1088 00550$:
      00AD01 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00AD04 80 32            [24] 1090 	sjmp	00118$
      00AD06                       1091 00551$:
      00AD06 BA 03 02         [24] 1092 	cjne	r2,#0x03,00552$
      00AD09 A1 72            [24] 1093 	ajmp	00119$
      00AD0B                       1094 00552$:
      00AD0B A1 9C            [24] 1095 	ajmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00AD0D                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00AD0D 12 4E 62         [24] 1099 	lcall	_timer_read32
      00AD10 85 82 38         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AD13 85 83 39         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AD16 85 F0 3A         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AD19 F5 3B            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00AD1B 12 38 8D         [24] 1105 	lcall	_ak820_outline_0121
      00AD1E A3               [24] 1106 	inc	dptr
      00AD1F A3               [24] 1107 	inc	dptr
      00AD20 E5 3B            [12] 1108 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AD22 12 43 09         [24] 1109 	lcall	_ak820_outline_0037
                                   1110 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00AD25 A3               [24] 1111 	inc	dptr
      00AD26 E5 3A            [12] 1112 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AD28 F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00AD29 12 B1 BF         [24] 1115 	lcall	_ak820_outline_0024
      00AD2C E5 39            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD2E F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00AD2F 12 42 FF         [24] 1119 	lcall	_ak820_outline_0011
      00AD32 E5 38            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD34 F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00AD35 02 B1 9A         [24] 1123 	ljmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00AD38                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00AD38 C0 03            [24] 1127 	push	ar3
      00AD3A C0 07            [24] 1128 	push	ar7
      00AD3C C0 06            [24] 1129 	push	ar6
      00AD3E C0 03            [24] 1130 	push	ar3
      00AD40 71 A0            [12] 1131 	acall	_via_get_layout_options
      00AD42 85 82 38         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AD45 85 83 39         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AD48 85 F0 3A         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AD4B F5 3B            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AD4D D0 03            [24] 1136 	pop	ar3
      00AD4F D0 06            [24] 1137 	pop	ar6
      00AD51 D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AD53 12 38 8D         [24] 1140 	lcall	_ak820_outline_0121
      00AD56 A3               [24] 1141 	inc	dptr
      00AD57 A3               [24] 1142 	inc	dptr
      00AD58 E5 3B            [12] 1143 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AD5A 12 43 09         [24] 1144 	lcall	_ak820_outline_0037
                                   1145 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00AD5D A3               [24] 1146 	inc	dptr
      00AD5E E5 3A            [12] 1147 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AD60 F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00AD61 12 B1 BF         [24] 1150 	lcall	_ak820_outline_0024
      00AD64 E5 39            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD66 F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AD67 12 42 FF         [24] 1154 	lcall	_ak820_outline_0011
      00AD6A E5 38            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD6C F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00AD6D D0 03            [24] 1158 	pop	ar3
      00AD6F 02 B1 9A         [24] 1159 	ljmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AD72                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00AD72 90 0F 04         [24] 1163 	mov	dptr,#_vial_unlocked
      00AD75 E0               [24] 1164 	movx	a,@dptr
      00AD76 70 03            [24] 1165 	jnz	00553$
      00AD78 02 B1 9A         [24] 1166 	ljmp	00171$
      00AD7B                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AD7B 7A 01            [12] 1169 	mov	r2,#0x01
      00AD7D 79 00            [12] 1170 	mov	r1,#0x00
      00AD7F                       1171 00173$:
      00AD7F B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00AD82                       1173 00554$:
      00AD82 40 03            [24] 1174 	jc	00555$
      00AD84 02 B1 9A         [24] 1175 	ljmp	00171$
      00AD87                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AD87 89 82            [24] 1178 	mov	dpl, r1
      00AD89 12 5E B3         [24] 1179 	lcall	_matrix_get_row
      00AD8C A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AD8E EA               [12] 1182 	mov	a,r2
      00AD8F 2C               [12] 1183 	add	a, r4
      00AD90 F5 82            [12] 1184 	mov	dpl,a
      00AD92 E4               [12] 1185 	clr	a
      00AD93 3D               [12] 1186 	addc	a, r5
      00AD94 F5 83            [12] 1187 	mov	dph,a
      00AD96 0A               [12] 1188 	inc	r2
      00AD97 E8               [12] 1189 	mov	a,r0
      00AD98 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AD99 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00AD9A 80 E3            [24] 1194 	sjmp	00173$
      00AD9C                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00AD9C 12 B1 ED         [24] 1197 	lcall	_ak820_outline_0097
      00AD9F 90 0D 1E         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00ADA2 12 B1 C8         [24] 1199 	lcall	_ak820_outline_0045
      00ADA5 C0 07            [24] 1200 	push	ar7
      00ADA7 C0 06            [24] 1201 	push	ar6
      00ADA9 C0 03            [24] 1202 	push	ar3
      00ADAB 91 10            [24] 1203 	acall	_raw_hid_receive_kb
      00ADAD D0 03            [24] 1204 	pop	ar3
      00ADAF D0 06            [24] 1205 	pop	ar6
      00ADB1 D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00ADB3 02 B1 9A         [24] 1208 	ljmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00ADB6                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00ADB6 12 43 49         [24] 1212 	lcall	_ak820_outline_0083
      00ADB9 FA               [12] 1213 	mov	r2,a
      00ADBA BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00ADBD 80 02            [24] 1215 	sjmp	00557$
      00ADBF                       1216 00556$:
      00ADBF C1 30            [12] 1217 	ajmp	00127$
      00ADC1                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00ADC1 C0 03            [24] 1220 	push	ar3
      00ADC3 12 38 1E         [24] 1221 	lcall	_ak820_outline_0034
      00ADC6 F8               [12] 1222 	mov	r0,a
      00ADC7 79 00            [12] 1223 	mov	r1,#0x00
      00ADC9 7B 00            [12] 1224 	mov	r3,#0x00
      00ADCB 88 3B            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00ADCD 8B 38            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00ADCF 8B 39            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00ADD1 8B 3A            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00ADD3 12 48 D5         [24] 1229 	lcall	_ak820_outline_0016
      00ADD6 F8               [12] 1230 	mov	r0,a
      00ADD7 89 03            [24] 1231 	mov	ar3,r1
      00ADD9 88 02            [24] 1232 	mov	ar2,r0
      00ADDB E4               [12] 1233 	clr	a
      00ADDC 42 38            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00ADDE E9               [12] 1235 	mov	a,r1
      00ADDF 42 39            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00ADE1 EA               [12] 1237 	mov	a,r2
      00ADE2 42 3A            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ADE4 EB               [12] 1239 	mov	a,r3
      00ADE5 42 3B            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ADE7 12 B1 BF         [24] 1241 	lcall	_ak820_outline_0024
      00ADEA E0               [24] 1242 	movx	a,@dptr
      00ADEB F8               [12] 1243 	mov	r0,a
      00ADEC 79 00            [12] 1244 	mov	r1,#0x00
      00ADEE 7A 00            [12] 1245 	mov	r2,#0x00
      00ADF0 8A 03            [24] 1246 	mov	ar3,r2
      00ADF2 89 02            [24] 1247 	mov	ar2,r1
      00ADF4 88 01            [24] 1248 	mov	ar1,r0
      00ADF6 E4               [12] 1249 	clr	a
      00ADF7 42 38            [12] 1250 	orl	_raw_hid_receive_sloc0_1_0,a
      00ADF9 E9               [12] 1251 	mov	a,r1
      00ADFA 42 39            [12] 1252 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00ADFC EA               [12] 1253 	mov	a,r2
      00ADFD 42 3A            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ADFF EB               [12] 1255 	mov	a,r3
      00AE00 42 3B            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AE02 12 42 FF         [24] 1257 	lcall	_ak820_outline_0011
      00AE05 E0               [24] 1258 	movx	a,@dptr
      00AE06 F8               [12] 1259 	mov	r0,a
      00AE07 E4               [12] 1260 	clr	a
      00AE08 F9               [12] 1261 	mov	r1,a
      00AE09 FA               [12] 1262 	mov	r2,a
      00AE0A FB               [12] 1263 	mov	r3,a
      00AE0B E5 39            [12] 1264 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AE0D 42 01            [12] 1265 	orl	ar1,a
      00AE0F E5 3A            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AE11 42 02            [12] 1267 	orl	ar2,a
      00AE13 E5 3B            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AE15 42 03            [12] 1269 	orl	ar3,a
                                   1270 ;	quantum/via.c:323: via_set_layout_options(value);
      00AE17 12 38 B1         [24] 1271 	lcall	_ak820_outline_0153
      00AE1A 8A F0            [24] 1272 	mov	b, r2
      00AE1C EB               [12] 1273 	mov	a, r3
      00AE1D C0 07            [24] 1274 	push	ar7
      00AE1F C0 06            [24] 1275 	push	ar6
      00AE21 C0 03            [24] 1276 	push	ar3
      00AE23 71 B9            [12] 1277 	acall	_via_set_layout_options
      00AE25 D0 03            [24] 1278 	pop	ar3
      00AE27 D0 06            [24] 1279 	pop	ar6
      00AE29 D0 07            [24] 1280 	pop	ar7
                                   1281 ;	quantum/via.c:324: break;
      00AE2B D0 03            [24] 1282 	pop	ar3
      00AE2D 02 B1 9A         [24] 1283 	ljmp	00171$
                                   1284 ;	quantum/via.c:326: default: {
      00AE30                       1285 00127$:
                                   1286 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00AE30 12 B1 ED         [24] 1287 	lcall	_ak820_outline_0097
      00AE33 90 0D 1E         [24] 1288 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AE36 12 B1 C8         [24] 1289 	lcall	_ak820_outline_0045
      00AE39 C0 07            [24] 1290 	push	ar7
      00AE3B C0 06            [24] 1291 	push	ar6
      00AE3D C0 03            [24] 1292 	push	ar3
      00AE3F 91 10            [24] 1293 	acall	_raw_hid_receive_kb
      00AE41 D0 03            [24] 1294 	pop	ar3
      00AE43 D0 06            [24] 1295 	pop	ar6
      00AE45 D0 07            [24] 1296 	pop	ar7
                                   1297 ;	quantum/via.c:331: break;
      00AE47 02 B1 9A         [24] 1298 	ljmp	00171$
                                   1299 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AE4A                       1300 00129$:
                                   1301 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AE4A 12 43 49         [24] 1302 	lcall	_ak820_outline_0083
      00AE4D FA               [12] 1303 	mov	r2,a
      00AE4E 12 38 1E         [24] 1304 	lcall	_ak820_outline_0034
      00AE51 F9               [12] 1305 	mov	r1,a
      00AE52 12 48 D5         [24] 1306 	lcall	_ak820_outline_0016
      00AE55 F8               [12] 1307 	mov	r0,a
      00AE56 90 0B 9E         [24] 1308 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AE59 E9               [12] 1309 	mov	a,r1
      00AE5A F0               [24] 1310 	movx	@dptr,a
      00AE5B 90 0B 9F         [24] 1311 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AE5E E8               [12] 1312 	mov	a,r0
      00AE5F F0               [24] 1313 	movx	@dptr,a
      00AE60 8A 82            [24] 1314 	mov	dpl, r2
      00AE62 C0 07            [24] 1315 	push	ar7
      00AE64 C0 06            [24] 1316 	push	ar6
      00AE66 C0 03            [24] 1317 	push	ar3
      00AE68 12 88 4B         [24] 1318 	lcall	_dynamic_keymap_get_keycode
      00AE6B A9 82            [24] 1319 	mov	r1, dpl
      00AE6D AA 83            [24] 1320 	mov	r2, dph
      00AE6F D0 03            [24] 1321 	pop	ar3
      00AE71 D0 06            [24] 1322 	pop	ar6
      00AE73 D0 07            [24] 1323 	pop	ar7
                                   1324 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AE75 12 B1 BF         [24] 1325 	lcall	_ak820_outline_0024
      00AE78 8A 00            [24] 1326 	mov	ar0,r2
      00AE7A E8               [12] 1327 	mov	a,r0
      00AE7B F0               [24] 1328 	movx	@dptr,a
                                   1329 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AE7C 12 42 FF         [24] 1330 	lcall	_ak820_outline_0011
      00AE7F E9               [12] 1331 	mov	a,r1
      00AE80 F0               [24] 1332 	movx	@dptr,a
                                   1333 ;	quantum/via.c:337: break;
      00AE81 02 B1 9A         [24] 1334 	ljmp	00171$
                                   1335 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AE84                       1336 00130$:
                                   1337 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AE84 90 0F 04         [24] 1338 	mov	dptr,#_vial_unlocked
      00AE87 E0               [24] 1339 	movx	a,@dptr
      00AE88 70 19            [24] 1340 	jnz	00132$
      00AE8A 12 B1 BF         [24] 1341 	lcall	_ak820_outline_0024
      00AE8D E0               [24] 1342 	movx	a,@dptr
      00AE8E FA               [12] 1343 	mov	r2,a
      00AE8F BA 7C 11         [24] 1344 	cjne	r2,#0x7c,00132$
      00AE92 74 05            [12] 1345 	mov	a,#0x05
      00AE94 2E               [12] 1346 	add	a, r6
      00AE95 12 38 03         [24] 1347 	lcall	_ak820_outline_0017
      00AE98 70 09            [24] 1348 	jnz	00132$
                                   1349 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AE9A 12 38 8D         [24] 1350 	lcall	_ak820_outline_0121
      00AE9D 74 FF            [12] 1351 	mov	a,#0xff
      00AE9F F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/via.c:345: break;
      00AEA0 02 B1 9A         [24] 1354 	ljmp	00171$
      00AEA3                       1355 00132$:
                                   1356 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AEA3 C0 03            [24] 1357 	push	ar3
      00AEA5 12 43 49         [24] 1358 	lcall	_ak820_outline_0083
      00AEA8 F5 3D            [12] 1359 	mov	_raw_hid_receive_sloc2_1_0,a
      00AEAA 12 38 1E         [24] 1360 	lcall	_ak820_outline_0034
      00AEAD F5 3C            [12] 1361 	mov	_raw_hid_receive_sloc1_1_0,a
      00AEAF 12 48 D5         [24] 1362 	lcall	_ak820_outline_0016
      00AEB2 F5 38            [12] 1363 	mov	_raw_hid_receive_sloc0_1_0,a
      00AEB4 12 B1 BF         [24] 1364 	lcall	_ak820_outline_0024
      00AEB7 E0               [24] 1365 	movx	a,@dptr
      00AEB8 FB               [12] 1366 	mov	r3,a
      00AEB9 78 00            [12] 1367 	mov	r0,#0x00
      00AEBB 12 42 FF         [24] 1368 	lcall	_ak820_outline_0011
      00AEBE E0               [24] 1369 	movx	a,@dptr
      00AEBF 7A 00            [12] 1370 	mov	r2,#0x00
      00AEC1 42 00            [12] 1371 	orl	ar0,a
      00AEC3 EA               [12] 1372 	mov	a,r2
      00AEC4 42 03            [12] 1373 	orl	ar3,a
      00AEC6 90 0B A1         [24] 1374 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00AEC9 E5 3C            [12] 1375 	mov	a,_raw_hid_receive_sloc1_1_0
      00AECB F0               [24] 1376 	movx	@dptr,a
      00AECC 90 0B A2         [24] 1377 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00AECF E5 38            [12] 1378 	mov	a,_raw_hid_receive_sloc0_1_0
      00AED1 F0               [24] 1379 	movx	@dptr,a
      00AED2 90 0B A3         [24] 1380 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00AED5 E8               [12] 1381 	mov	a,r0
      00AED6 12 49 35         [24] 1382 	lcall	_ak820_outline_0162
      00AED9 85 3D 82         [24] 1383 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00AEDC C0 07            [24] 1384 	push	ar7
      00AEDE C0 06            [24] 1385 	push	ar6
      00AEE0 C0 03            [24] 1386 	push	ar3
      00AEE2 12 88 98         [24] 1387 	lcall	_dynamic_keymap_set_keycode
      00AEE5 D0 03            [24] 1388 	pop	ar3
      00AEE7 D0 06            [24] 1389 	pop	ar6
      00AEE9 D0 07            [24] 1390 	pop	ar7
                                   1391 ;	quantum/via.c:349: break;
      00AEEB D0 03            [24] 1392 	pop	ar3
      00AEED 02 B1 9A         [24] 1393 	ljmp	00171$
                                   1394 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00AEF0                       1395 00135$:
                                   1396 ;	quantum/via.c:352: dynamic_keymap_reset();
      00AEF0 C0 07            [24] 1397 	push	ar7
      00AEF2 C0 06            [24] 1398 	push	ar6
      00AEF4 C0 03            [24] 1399 	push	ar3
      00AEF6 12 8C 32         [24] 1400 	lcall	_dynamic_keymap_reset
      00AEF9 D0 03            [24] 1401 	pop	ar3
      00AEFB D0 06            [24] 1402 	pop	ar6
      00AEFD D0 07            [24] 1403 	pop	ar7
                                   1404 ;	quantum/via.c:353: break;
      00AEFF 02 B1 9A         [24] 1405 	ljmp	00171$
                                   1406 ;	quantum/via.c:355: case id_lighting_set_value: {
      00AF02                       1407 00136$:
                                   1408 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00AF02 12 B1 ED         [24] 1409 	lcall	_ak820_outline_0097
      00AF05 90 0E 7D         [24] 1410 	mov	dptr,#_vialrgb_set_value_PARM_2
      00AF08 12 B1 C8         [24] 1411 	lcall	_ak820_outline_0045
      00AF0B C0 07            [24] 1412 	push	ar7
      00AF0D C0 06            [24] 1413 	push	ar6
      00AF0F C0 03            [24] 1414 	push	ar3
      00AF11 12 BC 89         [24] 1415 	lcall	_vialrgb_set_value
      00AF14 D0 03            [24] 1416 	pop	ar3
      00AF16 D0 06            [24] 1417 	pop	ar6
      00AF18 D0 07            [24] 1418 	pop	ar7
                                   1419 ;	quantum/via.c:375: break;
      00AF1A 02 B1 9A         [24] 1420 	ljmp	00171$
                                   1421 ;	quantum/via.c:377: case id_lighting_get_value: {
      00AF1D                       1422 00137$:
                                   1423 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00AF1D 12 B1 ED         [24] 1424 	lcall	_ak820_outline_0097
      00AF20 90 0E 79         [24] 1425 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AF23 12 B1 C8         [24] 1426 	lcall	_ak820_outline_0045
      00AF26 C0 07            [24] 1427 	push	ar7
      00AF28 C0 06            [24] 1428 	push	ar6
      00AF2A C0 03            [24] 1429 	push	ar3
      00AF2C 12 BB 23         [24] 1430 	lcall	_vialrgb_get_value
      00AF2F D0 03            [24] 1431 	pop	ar3
      00AF31 D0 06            [24] 1432 	pop	ar6
      00AF33 D0 07            [24] 1433 	pop	ar7
                                   1434 ;	quantum/via.c:397: break;
      00AF35 02 B1 9A         [24] 1435 	ljmp	00171$
                                   1436 ;	quantum/via.c:399: case id_lighting_save: {
      00AF38                       1437 00138$:
                                   1438 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AF38 12 B1 ED         [24] 1439 	lcall	_ak820_outline_0097
      00AF3B 90 0E 81         [24] 1440 	mov	dptr,#_vialrgb_save_PARM_2
      00AF3E 12 B1 C8         [24] 1441 	lcall	_ak820_outline_0045
      00AF41 C0 07            [24] 1442 	push	ar7
      00AF43 C0 06            [24] 1443 	push	ar6
      00AF45 C0 03            [24] 1444 	push	ar3
      00AF47 12 BD 16         [24] 1445 	lcall	_vialrgb_save
      00AF4A D0 03            [24] 1446 	pop	ar3
      00AF4C D0 06            [24] 1447 	pop	ar6
      00AF4E D0 07            [24] 1448 	pop	ar7
                                   1449 ;	quantum/via.c:419: break;
      00AF50 02 B1 9A         [24] 1450 	ljmp	00171$
                                   1451 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AF53                       1452 00139$:
                                   1453 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AF53 C0 07            [24] 1454 	push	ar7
      00AF55 C0 06            [24] 1455 	push	ar6
      00AF57 C0 05            [24] 1456 	push	ar5
      00AF59 C0 04            [24] 1457 	push	ar4
      00AF5B C0 03            [24] 1458 	push	ar3
      00AF5D 12 90 5D         [24] 1459 	lcall	_dynamic_keymap_macro_get_count
      00AF60 AA 82            [24] 1460 	mov	r2, dpl
      00AF62 D0 03            [24] 1461 	pop	ar3
      00AF64 D0 04            [24] 1462 	pop	ar4
      00AF66 D0 05            [24] 1463 	pop	ar5
      00AF68 D0 06            [24] 1464 	pop	ar6
      00AF6A D0 07            [24] 1465 	pop	ar7
      00AF6C 12 38 98         [24] 1466 	lcall	_ak820_outline_0129
      00AF6F EA               [12] 1467 	mov	a,r2
      00AF70 F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	quantum/via.c:430: break;
      00AF71 02 B1 9A         [24] 1470 	ljmp	00171$
                                   1471 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AF74                       1472 00140$:
                                   1473 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AF74 C0 07            [24] 1474 	push	ar7
      00AF76 C0 06            [24] 1475 	push	ar6
      00AF78 C0 05            [24] 1476 	push	ar5
      00AF7A C0 04            [24] 1477 	push	ar4
      00AF7C C0 03            [24] 1478 	push	ar3
      00AF7E 12 90 61         [24] 1479 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AF81 A9 82            [24] 1480 	mov	r1, dpl
      00AF83 AA 83            [24] 1481 	mov	r2, dph
      00AF85 D0 03            [24] 1482 	pop	ar3
      00AF87 D0 04            [24] 1483 	pop	ar4
      00AF89 D0 05            [24] 1484 	pop	ar5
      00AF8B D0 06            [24] 1485 	pop	ar6
      00AF8D D0 07            [24] 1486 	pop	ar7
                                   1487 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AF8F 8A 00            [24] 1488 	mov	ar0,r2
      00AF91 12 38 98         [24] 1489 	lcall	_ak820_outline_0129
      00AF94 E8               [12] 1490 	mov	a,r0
      00AF95 12 43 09         [24] 1491 	lcall	_ak820_outline_0037
                                   1492 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AF98 E9               [12] 1493 	mov	a,r1
      00AF99 F0               [24] 1494 	movx	@dptr,a
                                   1495 ;	quantum/via.c:436: break;
      00AF9A 02 B1 9A         [24] 1496 	ljmp	00171$
                                   1497 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AF9D                       1498 00141$:
                                   1499 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AF9D C0 03            [24] 1500 	push	ar3
      00AF9F 12 B1 A8         [24] 1501 	lcall	_ak820_outline_0003
      00AFA2 89 38            [24] 1502 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AFA4 8A 39            [24] 1503 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1504 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AFA6 12 48 D5         [24] 1505 	lcall	_ak820_outline_0016
      00AFA9 FB               [12] 1506 	mov	r3,a
                                   1507 ;	quantum/via.c:441: if (size <= 28)
      00AFAA 8B 3E            [24] 1508 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AFAC 75 3F 00         [24] 1509 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AFAF C3               [12] 1510 	clr	c
      00AFB0 74 1C            [12] 1511 	mov	a,#0x1c
      00AFB2 9B               [12] 1512 	subb	a,r3
      00AFB3 D0 03            [24] 1513 	pop	ar3
      00AFB5 50 03            [24] 1514 	jnc	00562$
      00AFB7 02 B1 9A         [24] 1515 	ljmp	00171$
      00AFBA                       1516 00562$:
                                   1517 ;	free result
                                   1518 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AFBA 12 B1 D1         [24] 1519 	lcall	_ak820_outline_0075
      00AFBD 90 0C 02         [24] 1520 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AFC0 E5 3E            [12] 1521 	mov	a,_raw_hid_receive_sloc3_1_0
      00AFC2 F0               [24] 1522 	movx	@dptr,a
      00AFC3 E5 3F            [12] 1523 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AFC5 A3               [24] 1524 	inc	dptr
      00AFC6 F0               [24] 1525 	movx	@dptr,a
      00AFC7 90 0C 04         [24] 1526 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00AFCA 12 B1 DB         [24] 1527 	lcall	_ak820_outline_0091
      00AFCD 85 38 82         [24] 1528 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00AFD0 85 39 83         [24] 1529 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00AFD3 C0 07            [24] 1530 	push	ar7
      00AFD5 C0 06            [24] 1531 	push	ar6
      00AFD7 C0 03            [24] 1532 	push	ar3
      00AFD9 12 90 65         [24] 1533 	lcall	_dynamic_keymap_macro_get_buffer
      00AFDC D0 03            [24] 1534 	pop	ar3
      00AFDE D0 06            [24] 1535 	pop	ar6
      00AFE0 D0 07            [24] 1536 	pop	ar7
                                   1537 ;	quantum/via.c:443: break;
      00AFE2 02 B1 9A         [24] 1538 	ljmp	00171$
                                   1539 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00AFE5                       1540 00144$:
                                   1541 ;	quantum/via.c:448: if (!vial_unlocked) {
      00AFE5 90 0F 04         [24] 1542 	mov	dptr,#_vial_unlocked
      00AFE8 E0               [24] 1543 	movx	a,@dptr
      00AFE9 70 01            [24] 1544 	jnz	00146$
                                   1545 ;	quantum/via.c:450: return;
      00AFEB 22               [24] 1546 	ret
      00AFEC                       1547 00146$:
                                   1548 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AFEC C0 03            [24] 1549 	push	ar3
      00AFEE 12 B1 A8         [24] 1550 	lcall	_ak820_outline_0003
      00AFF1 89 3E            [24] 1551 	mov	_raw_hid_receive_sloc3_1_0,r1
      00AFF3 8A 3F            [24] 1552 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1553 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00AFF5 12 48 D5         [24] 1554 	lcall	_ak820_outline_0016
      00AFF8 F5 38            [12] 1555 	mov	_raw_hid_receive_sloc0_1_0, a
      00AFFA 75 39 00         [24] 1556 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1557 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00AFFD 85 38 40         [24] 1558 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00B000 85 39 41         [24] 1559 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00B003 C3               [12] 1560 	clr	c
      00B004 74 1C            [12] 1561 	mov	a,#0x1c
      00B006 95 40            [12] 1562 	subb	a,_raw_hid_receive_sloc4_1_0
      00B008 E4               [12] 1563 	clr	a
      00B009 95 41            [12] 1564 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B00B D0 03            [24] 1565 	pop	ar3
      00B00D 40 43            [24] 1566 	jc	00147$
                                   1567 ;	free result
      00B00F 8B 01            [24] 1568 	mov	ar1,r3
      00B011 7A 00            [12] 1569 	mov	r2,#0x00
      00B013 E9               [12] 1570 	mov	a,r1
      00B014 24 FC            [12] 1571 	add	a,#0xfc
      00B016 F9               [12] 1572 	mov	r1,a
      00B017 EA               [12] 1573 	mov	a,r2
      00B018 34 FF            [12] 1574 	addc	a,#0xff
      00B01A FA               [12] 1575 	mov	r2,a
      00B01B C3               [12] 1576 	clr	c
      00B01C E9               [12] 1577 	mov	a,r1
      00B01D 95 40            [12] 1578 	subb	a,_raw_hid_receive_sloc4_1_0
      00B01F EA               [12] 1579 	mov	a,r2
      00B020 95 41            [12] 1580 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B022 40 2E            [24] 1581 	jc	00147$
                                   1582 ;	free result
      00B024 12 B1 D1         [24] 1583 	lcall	_ak820_outline_0075
      00B027 90 0C 09         [24] 1584 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00B02A E5 38            [12] 1585 	mov	a,_raw_hid_receive_sloc0_1_0
      00B02C F0               [24] 1586 	movx	@dptr,a
      00B02D E5 39            [12] 1587 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B02F A3               [24] 1588 	inc	dptr
      00B030 F0               [24] 1589 	movx	@dptr,a
      00B031 90 0C 0B         [24] 1590 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00B034 12 B1 DB         [24] 1591 	lcall	_ak820_outline_0091
      00B037 85 3E 82         [24] 1592 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00B03A 85 3F 83         [24] 1593 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00B03D C0 07            [24] 1594 	push	ar7
      00B03F C0 06            [24] 1595 	push	ar6
      00B041 C0 03            [24] 1596 	push	ar3
      00B043 12 90 B3         [24] 1597 	lcall	_dynamic_keymap_macro_set_buffer
      00B046 E5 82            [12] 1598 	mov	a, dpl
      00B048 D0 03            [24] 1599 	pop	ar3
      00B04A D0 06            [24] 1600 	pop	ar6
      00B04C D0 07            [24] 1601 	pop	ar7
      00B04E 60 02            [24] 1602 	jz	00566$
      00B050 21 9A            [12] 1603 	ajmp	00171$
      00B052                       1604 00566$:
      00B052                       1605 00147$:
      00B052 22               [24] 1606 	ret
                                   1607 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00B053                       1608 00151$:
                                   1609 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00B053 90 0F 04         [24] 1610 	mov	dptr,#_vial_unlocked
      00B056 E0               [24] 1611 	movx	a,@dptr
      00B057 70 01            [24] 1612 	jnz	00153$
      00B059 22               [24] 1613 	ret
      00B05A                       1614 00153$:
                                   1615 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00B05A C0 07            [24] 1616 	push	ar7
      00B05C C0 06            [24] 1617 	push	ar6
      00B05E C0 03            [24] 1618 	push	ar3
      00B060 12 90 E6         [24] 1619 	lcall	_dynamic_keymap_macro_reset
      00B063 D0 03            [24] 1620 	pop	ar3
      00B065 D0 06            [24] 1621 	pop	ar6
      00B067 D0 07            [24] 1622 	pop	ar7
                                   1623 ;	quantum/via.c:473: break;
      00B069 21 9A            [12] 1624 	ajmp	00171$
                                   1625 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00B06B                       1626 00154$:
                                   1627 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00B06B C0 07            [24] 1628 	push	ar7
      00B06D C0 06            [24] 1629 	push	ar6
      00B06F C0 05            [24] 1630 	push	ar5
      00B071 C0 04            [24] 1631 	push	ar4
      00B073 C0 03            [24] 1632 	push	ar3
      00B075 12 88 0E         [24] 1633 	lcall	_dynamic_keymap_get_layer_count
      00B078 AA 82            [24] 1634 	mov	r2, dpl
      00B07A D0 03            [24] 1635 	pop	ar3
      00B07C D0 04            [24] 1636 	pop	ar4
      00B07E D0 05            [24] 1637 	pop	ar5
      00B080 D0 06            [24] 1638 	pop	ar6
      00B082 D0 07            [24] 1639 	pop	ar7
      00B084 12 38 98         [24] 1640 	lcall	_ak820_outline_0129
      00B087 EA               [12] 1641 	mov	a,r2
      00B088 F0               [24] 1642 	movx	@dptr,a
                                   1643 ;	quantum/via.c:477: break;
      00B089 21 9A            [12] 1644 	ajmp	00171$
                                   1645 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00B08B                       1646 00155$:
                                   1647 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B08B C0 03            [24] 1648 	push	ar3
      00B08D 12 B1 A8         [24] 1649 	lcall	_ak820_outline_0003
      00B090 89 40            [24] 1650 	mov	_raw_hid_receive_sloc4_1_0,r1
      00B092 8A 41            [24] 1651 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1652 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00B094 12 48 D5         [24] 1653 	lcall	_ak820_outline_0016
      00B097 FB               [12] 1654 	mov	r3,a
                                   1655 ;	quantum/via.c:482: if (size <= 28)
      00B098 8B 3E            [24] 1656 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B09A 75 3F 00         [24] 1657 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B09D C3               [12] 1658 	clr	c
      00B09E 74 1C            [12] 1659 	mov	a,#0x1c
      00B0A0 9B               [12] 1660 	subb	a,r3
      00B0A1 D0 03            [24] 1661 	pop	ar3
      00B0A3 50 02            [24] 1662 	jnc	00568$
      00B0A5 21 9A            [12] 1663 	ajmp	00171$
      00B0A7                       1664 00568$:
                                   1665 ;	free result
                                   1666 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00B0A7 12 B1 D1         [24] 1667 	lcall	_ak820_outline_0075
      00B0AA 90 0B EB         [24] 1668 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00B0AD E5 3E            [12] 1669 	mov	a,_raw_hid_receive_sloc3_1_0
      00B0AF F0               [24] 1670 	movx	@dptr,a
      00B0B0 E5 3F            [12] 1671 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B0B2 A3               [24] 1672 	inc	dptr
      00B0B3 F0               [24] 1673 	movx	@dptr,a
      00B0B4 90 0B ED         [24] 1674 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00B0B7 12 B1 DB         [24] 1675 	lcall	_ak820_outline_0091
      00B0BA 85 40 82         [24] 1676 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B0BD 85 41 83         [24] 1677 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B0C0 C0 07            [24] 1678 	push	ar7
      00B0C2 C0 06            [24] 1679 	push	ar6
      00B0C4 C0 03            [24] 1680 	push	ar3
      00B0C6 12 8E 25         [24] 1681 	lcall	_dynamic_keymap_get_buffer
      00B0C9 D0 03            [24] 1682 	pop	ar3
      00B0CB D0 06            [24] 1683 	pop	ar6
      00B0CD D0 07            [24] 1684 	pop	ar7
                                   1685 ;	quantum/via.c:484: break;
      00B0CF 21 9A            [12] 1686 	ajmp	00171$
                                   1687 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00B0D1                       1688 00158$:
                                   1689 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B0D1 12 43 49         [24] 1690 	lcall	_ak820_outline_0083
      00B0D4 FD               [12] 1691 	mov	r5,a
      00B0D5 7C 00            [12] 1692 	mov	r4,#0x00
      00B0D7 12 38 1E         [24] 1693 	lcall	_ak820_outline_0034
      00B0DA 7A 00            [12] 1694 	mov	r2,#0x00
      00B0DC 42 04            [12] 1695 	orl	ar4,a
      00B0DE EA               [12] 1696 	mov	a,r2
      00B0DF 42 05            [12] 1697 	orl	ar5,a
      00B0E1 8C 40            [24] 1698 	mov	_raw_hid_receive_sloc4_1_0,r4
      00B0E3 8D 41            [24] 1699 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1700 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00B0E5 12 48 D5         [24] 1701 	lcall	_ak820_outline_0016
      00B0E8 F9               [12] 1702 	mov	r1,a
      00B0E9 7A 00            [12] 1703 	mov	r2,#0x00
                                   1704 ;	quantum/via.c:489: if (size <= 28)
      00B0EB 89 00            [24] 1705 	mov	ar0,r1
      00B0ED E8               [12] 1706 	mov	a,r0
      00B0EE 24 E3            [12] 1707 	add	a,#0xff - 0x1c
      00B0F0 50 02            [24] 1708 	jnc	00569$
      00B0F2 21 9A            [12] 1709 	ajmp	00171$
      00B0F4                       1710 00569$:
                                   1711 ;	free result
                                   1712 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00B0F4 C0 03            [24] 1713 	push	ar3
      00B0F6 74 04            [12] 1714 	mov	a,#0x04
      00B0F8 2E               [12] 1715 	add	a, r6
      00B0F9 F8               [12] 1716 	mov	r0,a
      00B0FA E4               [12] 1717 	clr	a
      00B0FB 3F               [12] 1718 	addc	a, r7
      00B0FC FB               [12] 1719 	mov	r3,a
      00B0FD 7D 00            [12] 1720 	mov	r5,#0x00
      00B0FF 90 0B F2         [24] 1721 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00B102 E9               [12] 1722 	mov	a,r1
      00B103 F0               [24] 1723 	movx	@dptr,a
      00B104 EA               [12] 1724 	mov	a,r2
      00B105 A3               [24] 1725 	inc	dptr
      00B106 F0               [24] 1726 	movx	@dptr,a
      00B107 90 0B F4         [24] 1727 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00B10A E8               [12] 1728 	mov	a,r0
      00B10B 12 49 35         [24] 1729 	lcall	_ak820_outline_0162
      00B10E ED               [12] 1730 	mov	a,r5
      00B10F A3               [24] 1731 	inc	dptr
      00B110 F0               [24] 1732 	movx	@dptr,a
      00B111 85 40 82         [24] 1733 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B114 85 41 83         [24] 1734 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B117 C0 07            [24] 1735 	push	ar7
      00B119 C0 06            [24] 1736 	push	ar6
      00B11B C0 03            [24] 1737 	push	ar3
      00B11D 12 8E 67         [24] 1738 	lcall	_dynamic_keymap_set_buffer
      00B120 D0 03            [24] 1739 	pop	ar3
      00B122 D0 06            [24] 1740 	pop	ar6
      00B124 D0 07            [24] 1741 	pop	ar7
                                   1742 ;	quantum/via.c:491: break;
      00B126 D0 03            [24] 1743 	pop	ar3
      00B128 21 9A            [12] 1744 	ajmp	00171$
                                   1745 ;	quantum/via.c:495: case id_bootloader_jump: {
      00B12A                       1746 00161$:
                                   1747 ;	quantum/via.c:497: if (!vial_unlocked)
      00B12A 90 0F 04         [24] 1748 	mov	dptr,#_vial_unlocked
      00B12D E0               [24] 1749 	movx	a,@dptr
      00B12E 70 02            [24] 1750 	jnz	00570$
      00B130 21 9A            [12] 1751 	ajmp	00171$
      00B132                       1752 00570$:
                                   1753 ;	quantum/via.c:501: raw_hid_send(data, length);
      00B132 12 B1 F4         [24] 1754 	lcall	_ak820_outline_0155
      00B135 90 07 3E         [24] 1755 	mov	dptr,#_raw_hid_send_PARM_2
      00B138 12 B1 E4         [24] 1756 	lcall	_ak820_outline_0092
      00B13B C0 07            [24] 1757 	push	ar7
      00B13D C0 06            [24] 1758 	push	ar6
      00B13F C0 03            [24] 1759 	push	ar3
      00B141 12 50 4E         [24] 1760 	lcall	_raw_hid_send
      00B144 D0 03            [24] 1761 	pop	ar3
      00B146 D0 06            [24] 1762 	pop	ar6
      00B148 D0 07            [24] 1763 	pop	ar7
                                   1764 ;	quantum/via.c:503: wait_ms(100);
      00B14A 7D 64            [12] 1765 	mov	r5,#0x64
      00B14C                       1766 00176$:
      00B14C ED               [12] 1767 	mov	a,r5
      00B14D 60 09            [24] 1768 	jz	00166$
      00B14F 90 00 01         [24] 1769 	mov	dptr,#0x0001
      00B152 12 5D F2         [24] 1770 	lcall	_mDelaymS
      00B155 1D               [12] 1771 	dec	r5
      00B156 80 F4            [24] 1772 	sjmp	00176$
      00B158                       1773 00166$:
                                   1774 ;	quantum/via.c:504: bootloader_jump();
      00B158 C0 07            [24] 1775 	push	ar7
      00B15A C0 06            [24] 1776 	push	ar6
      00B15C C0 03            [24] 1777 	push	ar3
      00B15E 12 34 0E         [24] 1778 	lcall	_bootloader_jump
      00B161 D0 03            [24] 1779 	pop	ar3
      00B163 D0 06            [24] 1780 	pop	ar6
      00B165 D0 07            [24] 1781 	pop	ar7
                                   1782 ;	quantum/via.c:505: break;
                                   1783 ;	quantum/via.c:509: case id_vial_prefix: {
      00B167 80 31            [24] 1784 	sjmp	00171$
      00B169                       1785 00168$:
                                   1786 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B169 12 B1 F4         [24] 1787 	lcall	_ak820_outline_0155
      00B16C 90 0D 30         [24] 1788 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B16F 12 B1 E4         [24] 1789 	lcall	_ak820_outline_0092
      00B172 C0 07            [24] 1790 	push	ar7
      00B174 C0 06            [24] 1791 	push	ar6
      00B176 C0 03            [24] 1792 	push	ar3
      00B178 51 E1            [12] 1793 	acall	_vial_handle_cmd
      00B17A D0 03            [24] 1794 	pop	ar3
      00B17C D0 06            [24] 1795 	pop	ar6
      00B17E D0 07            [24] 1796 	pop	ar7
                                   1797 ;	quantum/via.c:511: break;
                                   1798 ;	quantum/via.c:514: default: {
      00B180 80 18            [24] 1799 	sjmp	00171$
      00B182                       1800 00169$:
                                   1801 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B182 12 B1 F4         [24] 1802 	lcall	_ak820_outline_0155
      00B185 90 0D 1E         [24] 1803 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B188 12 B1 E4         [24] 1804 	lcall	_ak820_outline_0092
      00B18B C0 07            [24] 1805 	push	ar7
      00B18D C0 06            [24] 1806 	push	ar6
      00B18F C0 03            [24] 1807 	push	ar3
      00B191 12 AC 10         [24] 1808 	lcall	_raw_hid_receive_kb
      00B194 D0 03            [24] 1809 	pop	ar3
      00B196 D0 06            [24] 1810 	pop	ar6
      00B198 D0 07            [24] 1811 	pop	ar7
                                   1812 ;	quantum/via.c:521: skip:
      00B19A                       1813 00171$:
                                   1814 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B19A 7D 00            [12] 1815 	mov	r5,#0x00
      00B19C 90 07 3E         [24] 1816 	mov	dptr,#_raw_hid_send_PARM_2
      00B19F EB               [12] 1817 	mov	a,r3
      00B1A0 12 43 43         [24] 1818 	lcall	_ak820_outline_0072
      00B1A3 8D F0            [24] 1819 	mov	b, r5
                                   1820 ;	quantum/via.c:526: }
      00B1A5 02 50 4E         [24] 1821 	ljmp	_raw_hid_send
                                   1822 	.area CSEG    (CODE)
                                   1823 	.area CONST   (CODE)
                                   1824 	.area XINIT   (CODE)
                                   1825 	.area CABS    (ABS,CODE)
                                   1826 
                                   1827 ; Experimental exact instruction outlining.
                                   1828 	.globl _ak820_outline_0002
                                   1829 	.globl _ak820_outline_0003
                                   1830 	.globl _ak820_outline_0011
                                   1831 	.globl _ak820_outline_0012
                                   1832 	.globl _ak820_outline_0015
                                   1833 	.globl _ak820_outline_0016
                                   1834 	.globl _ak820_outline_0017
                                   1835 	.globl _ak820_outline_0019
                                   1836 	.globl _ak820_outline_0024
                                   1837 	.globl _ak820_outline_0034
                                   1838 	.globl _ak820_outline_0037
                                   1839 	.globl _ak820_outline_0042
                                   1840 	.globl _ak820_outline_0045
                                   1841 	.globl _ak820_outline_0049
                                   1842 	.globl _ak820_outline_0052
                                   1843 	.globl _ak820_outline_0059
                                   1844 	.globl _ak820_outline_0072
                                   1845 	.globl _ak820_outline_0075
                                   1846 	.globl _ak820_outline_0083
                                   1847 	.globl _ak820_outline_0091
                                   1848 	.globl _ak820_outline_0092
                                   1849 	.globl _ak820_outline_0097
                                   1850 	.globl _ak820_outline_0103
                                   1851 	.globl _ak820_outline_0105
                                   1852 	.globl _ak820_outline_0106
                                   1853 	.globl _ak820_outline_0121
                                   1854 	.globl _ak820_outline_0124
                                   1855 	.globl _ak820_outline_0129
                                   1856 	.globl _ak820_outline_0147
                                   1857 	.globl _ak820_outline_0153
                                   1858 	.globl _ak820_outline_0155
                                   1859 	.globl _ak820_outline_0157
                                   1860 	.globl _ak820_outline_0160
                                   1861 	.globl _ak820_outline_0162
                                   1862 	.globl _ak820_outline_0163
                                   1863 	.globl _ak820_outline_0164
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0003
      00B1A8                       1867 _ak820_outline_0003:
      00B1A8 8C 82            [24] 1868 	mov	dpl,r4
      00B1AA 8D 83            [24] 1869 	mov	dph,r5
      00B1AC E0               [24] 1870 	movx	a,@dptr
      00B1AD FA               [12] 1871 	mov	r2,a
      00B1AE 79 00            [12] 1872 	mov	r1,#0x00
      00B1B0 8E 82            [24] 1873 	mov	dpl,r6
      00B1B2 8F 83            [24] 1874 	mov	dph,r7
      00B1B4 A3               [24] 1875 	inc	dptr
      00B1B5 A3               [24] 1876 	inc	dptr
      00B1B6 E0               [24] 1877 	movx	a,@dptr
      00B1B7 7B 00            [12] 1878 	mov	r3,#0x00
      00B1B9 42 01            [12] 1879 	orl	ar1,a
      00B1BB EB               [12] 1880 	mov	a,r3
      00B1BC 42 02            [12] 1881 	orl	ar2,a
      00B1BE 22               [24] 1882 	ret
                                   1883 
                                   1884 	.area CSEG (CODE)
                                   1885 ; function ak820_outline_0024
      00B1BF                       1886 _ak820_outline_0024:
      00B1BF 8E 82            [24] 1887 	mov	dpl,r6
      00B1C1 8F 83            [24] 1888 	mov	dph,r7
      00B1C3 A3               [24] 1889 	inc	dptr
      00B1C4 A3               [24] 1890 	inc	dptr
      00B1C5 A3               [24] 1891 	inc	dptr
      00B1C6 A3               [24] 1892 	inc	dptr
      00B1C7 22               [24] 1893 	ret
                                   1894 
                                   1895 	.area CSEG (CODE)
                                   1896 ; function ak820_outline_0045
      00B1C8                       1897 _ak820_outline_0045:
      00B1C8 EB               [12] 1898 	mov	a,r3
      00B1C9 F0               [24] 1899 	movx	@dptr,a
      00B1CA 88 82            [24] 1900 	mov	dpl,r0
      00B1CC 89 83            [24] 1901 	mov	dph,r1
      00B1CE 8A F0            [24] 1902 	mov	b,r2
      00B1D0 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0075
      00B1D1                       1907 _ak820_outline_0075:
      00B1D1 74 04            [12] 1908 	mov	a,#0x04
      00B1D3 2E               [12] 1909 	add	a,r6
      00B1D4 F9               [12] 1910 	mov	r1,a
      00B1D5 E4               [12] 1911 	clr	a
      00B1D6 3F               [12] 1912 	addc	a,r7
      00B1D7 F8               [12] 1913 	mov	r0,a
      00B1D8 7A 00            [12] 1914 	mov	r2,#0x00
      00B1DA 22               [24] 1915 	ret
                                   1916 
                                   1917 	.area CSEG (CODE)
                                   1918 ; function ak820_outline_0091
      00B1DB                       1919 _ak820_outline_0091:
      00B1DB E9               [12] 1920 	mov	a,r1
      00B1DC F0               [24] 1921 	movx	@dptr,a
      00B1DD E8               [12] 1922 	mov	a,r0
      00B1DE A3               [24] 1923 	inc	dptr
      00B1DF F0               [24] 1924 	movx	@dptr,a
      00B1E0 EA               [12] 1925 	mov	a,r2
      00B1E1 A3               [24] 1926 	inc	dptr
      00B1E2 F0               [24] 1927 	movx	@dptr,a
      00B1E3 22               [24] 1928 	ret
                                   1929 
                                   1930 	.area CSEG (CODE)
                                   1931 ; function ak820_outline_0092
      00B1E4                       1932 _ak820_outline_0092:
      00B1E4 EB               [12] 1933 	mov	a,r3
      00B1E5 F0               [24] 1934 	movx	@dptr,a
      00B1E6 8A 82            [24] 1935 	mov	dpl,r2
      00B1E8 8C 83            [24] 1936 	mov	dph,r4
      00B1EA 8D F0            [24] 1937 	mov	b,r5
      00B1EC 22               [24] 1938 	ret
                                   1939 
                                   1940 	.area CSEG (CODE)
                                   1941 ; function ak820_outline_0097
      00B1ED                       1942 _ak820_outline_0097:
      00B1ED 8E 00            [24] 1943 	mov	ar0,r6
      00B1EF 8F 01            [24] 1944 	mov	ar1,r7
      00B1F1 7A 00            [12] 1945 	mov	r2,#0x00
      00B1F3 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0155
      00B1F4                       1950 _ak820_outline_0155:
      00B1F4 8E 02            [24] 1951 	mov	ar2,r6
      00B1F6 8F 04            [24] 1952 	mov	ar4,r7
      00B1F8 7D 00            [12] 1953 	mov	r5,#0x00
      00B1FA 22               [24] 1954 	ret
