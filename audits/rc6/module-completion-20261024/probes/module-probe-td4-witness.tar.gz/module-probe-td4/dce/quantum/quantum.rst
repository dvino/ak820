                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_tap_dance_process
                                     18 	.globl _process_repeat_key
                                     19 	.globl _process_last_key
                                     20 	.globl _process_caps_word
                                     21 	.globl _process_record_via
                                     22 	.globl _mcu_reset
                                     23 	.globl _bootloader_jump
                                     24 	.globl _ak820_resolve_key
                                     25 	.globl _default_layer_set
                                     26 	.globl _clear_keyboard
                                     27 	.globl _unregister_weak_mods
                                     28 	.globl _register_weak_mods
                                     29 	.globl _unregister_mods
                                     30 	.globl _register_mods
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _eeconfig_disable
                                     34 	.globl _rgb_matrix_set_suspend_state
                                     35 	.globl _rgb_matrix_task
                                     36 	.globl _mDelaymS
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _process_record_quantum_helper_PARM_2
                                    281 	.globl _get_record_keycode_PARM_2
                                    282 	.globl _post_process_record_user_PARM_2
                                    283 	.globl _post_process_record_kb_PARM_2
                                    284 	.globl _process_record_user_PARM_2
                                    285 	.globl _process_record_kb_PARM_2
                                    286 	.globl _pre_process_record_user_PARM_2
                                    287 	.globl _pre_process_record_kb_PARM_2
                                    288 	.globl _register_code16
                                    289 	.globl _unregister_code16
                                    290 	.globl _pre_process_record_kb
                                    291 	.globl _pre_process_record_user
                                    292 	.globl _process_action_kb
                                    293 	.globl _process_record_kb
                                    294 	.globl _process_record_user
                                    295 	.globl _post_process_record_kb
                                    296 	.globl _post_process_record_user
                                    297 	.globl _reset_keyboard
                                    298 	.globl _soft_reset_keyboard
                                    299 	.globl _get_record_keycode
                                    300 	.globl _pre_process_record_quantum
                                    301 	.globl _post_process_record_quantum
                                    302 	.globl _process_record_quantum
                                    303 	.globl _process_record_quantum_helper
                                    304 	.globl _shutdown_user
                                    305 ;--------------------------------------------------------
                                    306 ; special function registers
                                    307 ;--------------------------------------------------------
                                    308 	.area RSEG    (ABS,DATA)
      000000                        309 	.org 0x0000
                           0000D0   310 _PSW	=	0x00d0
                           0000E0   311 _ACC	=	0x00e0
                           0000F0   312 _B	=	0x00f0
                           0000FD   313 _A_INV	=	0x00fd
                           000081   314 _SP	=	0x0081
                           000082   315 _DPL	=	0x0082
                           000083   316 _DPH	=	0x0083
                           0000A1   317 _SAFE_MOD	=	0x00a1
                           0000B1   318 _GLOBAL_CFG	=	0x00b1
                           000087   319 _PCON	=	0x0087
                           0000BA   320 _POWER_CFG	=	0x00ba
                           0000B9   321 _CLOCK_CFG	=	0x00b9
                           0000A9   322 _WAKE_CTRL	=	0x00a9
                           0000FE   323 _RESET_KEEP	=	0x00fe
                           0000FF   324 _WDOG_COUNT	=	0x00ff
                           0000A8   325 _IE	=	0x00a8
                           0000B8   326 _IP	=	0x00b8
                           0000E8   327 _IE_EX	=	0x00e8
                           0000E9   328 _IP_EX	=	0x00e9
                           0000B2   329 _GPIO_IE	=	0x00b2
                           008584   330 _ROM_ADDR	=	0x8584
                           000084   331 _ROM_ADDR_L	=	0x0084
                           000085   332 _ROM_ADDR_H	=	0x0085
                           008F8E   333 _ROM_DATA_HI	=	0x8f8e
                           00008E   334 _ROM_DATA_HL	=	0x008e
                           00008F   335 _ROM_DATA_HH	=	0x008f
                           000086   336 _ROM_CTRL	=	0x0086
                           000080   337 _P0	=	0x0080
                           0000C4   338 _P0_MOD_OC	=	0x00c4
                           0000C5   339 _P0_DIR_PU	=	0x00c5
                           000090   340 _P1	=	0x0090
                           000092   341 _P1_MOD_OC	=	0x0092
                           000093   342 _P1_DIR_PU	=	0x0093
                           0000A0   343 _P2	=	0x00a0
                           000094   344 _P2_MOD_OC	=	0x0094
                           000095   345 _P2_DIR_PU	=	0x0095
                           0000B0   346 _P3	=	0x00b0
                           000096   347 _P3_MOD_OC	=	0x0096
                           000097   348 _P3_DIR_PU	=	0x0097
                           0000C0   349 _P4	=	0x00c0
                           0000C2   350 _P4_MOD_OC	=	0x00c2
                           0000C3   351 _P4_DIR_PU	=	0x00c3
                           0000C1   352 _P4_LED_KEY	=	0x00c1
                           0000AA   353 _P5_IN	=	0x00aa
                           0000AB   354 _P5_OUT_PU	=	0x00ab
                           0000AC   355 _P5_DIR	=	0x00ac
                           0000AD   356 _P6_IN	=	0x00ad
                           0000AE   357 _P6_OUT_PU	=	0x00ae
                           0000AF   358 _P6_DIR	=	0x00af
                           0000F1   359 _P7	=	0x00f1
                           0000A2   360 _XBUS_AUX	=	0x00a2
                           000088   361 _TCON	=	0x0088
                           000089   362 _TMOD	=	0x0089
                           00008A   363 _TL0	=	0x008a
                           00008B   364 _TL1	=	0x008b
                           00008C   365 _TH0	=	0x008c
                           00008D   366 _TH1	=	0x008d
                           000098   367 _SCON	=	0x0098
                           000099   368 _SBUF	=	0x0099
                           0000C8   369 _T2CON	=	0x00c8
                           0000C9   370 _T2MOD	=	0x00c9
                           00CBCA   371 _RCAP2	=	0xcbca
                           0000CA   372 _RCAP2L	=	0x00ca
                           0000CB   373 _RCAP2H	=	0x00cb
                           00CDCC   374 _T2COUNT	=	0xcdcc
                           0000CC   375 _TL2	=	0x00cc
                           0000CD   376 _TH2	=	0x00cd
                           00CFCE   377 _T2CAP1	=	0xcfce
                           0000CE   378 _T2CAP1L	=	0x00ce
                           0000CF   379 _T2CAP1H	=	0x00cf
                           0000F8   380 _SPI0_STAT	=	0x00f8
                           0000F9   381 _SPI0_DATA	=	0x00f9
                           0000FA   382 _SPI0_CTRL	=	0x00fa
                           0000FB   383 _SPI0_CK_SE	=	0x00fb
                           0000FC   384 _SPI0_SETUP	=	0x00fc
                           0000BC   385 _SCON1	=	0x00bc
                           0000BD   386 _SBUF1	=	0x00bd
                           0000BE   387 _SBAUD1	=	0x00be
                           0000BF   388 _SIF1	=	0x00bf
                           0000B4   389 _SPI1_STAT	=	0x00b4
                           0000B5   390 _SPI1_DATA	=	0x00b5
                           0000B6   391 _SPI1_CTRL	=	0x00b6
                           0000B7   392 _SPI1_CK_SE	=	0x00b7
                           0000F3   393 _ADC_CTRL	=	0x00f3
                           00F5F4   394 _ADC_DAT	=	0xf5f4
                           0000F4   395 _ADC_DAT_L	=	0x00f4
                           0000F5   396 _ADC_DAT_H	=	0x00f5
                           0000F6   397 _ADC_CHAN	=	0x00f6
                           0000A6   398 _LED_COMMON	=	0x00a6
                           0000A7   399 _LED_PWM_OE	=	0x00a7
                           00C7C6   400 _LED_DMA	=	0xc7c6
                           0000C6   401 _LED_DMA_L	=	0x00c6
                           0000C7   402 _LED_DMA_H	=	0x00c7
                           0000F7   403 _LED_STATUS	=	0x00f7
                           0000B3   404 _I2CX_INT	=	0x00b3
                           0000BB   405 _I2CS_INT_ST	=	0x00bb
                                    406 ;--------------------------------------------------------
                                    407 ; special function bits
                                    408 ;--------------------------------------------------------
                                    409 	.area RSEG    (ABS,DATA)
      000000                        410 	.org 0x0000
                           0000D7   411 _CY	=	0x00d7
                           0000D6   412 _AC	=	0x00d6
                           0000D5   413 _F0	=	0x00d5
                           0000D4   414 _RS1	=	0x00d4
                           0000D3   415 _RS0	=	0x00d3
                           0000D2   416 _OV	=	0x00d2
                           0000D1   417 _F1	=	0x00d1
                           0000D0   418 _P	=	0x00d0
                           0000AF   419 _EA	=	0x00af
                           0000AE   420 _E_DIS	=	0x00ae
                           0000AD   421 _ET2	=	0x00ad
                           0000AC   422 _ES	=	0x00ac
                           0000AB   423 _ET1	=	0x00ab
                           0000AA   424 _EX1	=	0x00aa
                           0000A9   425 _ET0	=	0x00a9
                           0000A8   426 _EX0	=	0x00a8
                           0000BF   427 _PH_FLAG	=	0x00bf
                           0000BE   428 _PL_FLAG	=	0x00be
                           0000BD   429 _PT2	=	0x00bd
                           0000BC   430 _PS	=	0x00bc
                           0000BB   431 _PT1	=	0x00bb
                           0000BA   432 _PX1	=	0x00ba
                           0000B9   433 _PT0	=	0x00b9
                           0000B8   434 _PX0	=	0x00b8
                           0000EF   435 _IE_WDOG	=	0x00ef
                           0000EE   436 _IE_GPIO	=	0x00ee
                           0000ED   437 _IE_PWM_I2C	=	0x00ed
                           0000EC   438 _IE_UART1	=	0x00ec
                           0000EB   439 _IE_ADC	=	0x00eb
                           0000E9   440 _IE_USB	=	0x00e9
                           0000E8   441 _IE_SPI0	=	0x00e8
                           000087   442 _P0_7	=	0x0087
                           000086   443 _P0_6	=	0x0086
                           000085   444 _P0_5	=	0x0085
                           000084   445 _P0_4	=	0x0084
                           000083   446 _P0_3	=	0x0083
                           000082   447 _P0_2	=	0x0082
                           000081   448 _P0_1	=	0x0081
                           000080   449 _P0_0	=	0x0080
                           000081   450 _SDA0	=	0x0081
                           000080   451 _SCL0	=	0x0080
                           000083   452 _TXD_	=	0x0083
                           000082   453 _RXD_	=	0x0082
                           000085   454 _AIN13	=	0x0085
                           000084   455 _AIN12	=	0x0084
                           000083   456 _AIN11	=	0x0083
                           000082   457 _AIN10	=	0x0082
                           000081   458 _AIN9	=	0x0081
                           000080   459 _AIN8	=	0x0080
                           000097   460 _P1_7	=	0x0097
                           000096   461 _P1_6	=	0x0096
                           000095   462 _P1_5	=	0x0095
                           000094   463 _P1_4	=	0x0094
                           000093   464 _P1_3	=	0x0093
                           000092   465 _P1_2	=	0x0092
                           000091   466 _P1_1	=	0x0091
                           000090   467 _P1_0	=	0x0090
                           000097   468 _TXD1_	=	0x0097
                           000096   469 _RXD1_	=	0x0096
                           000097   470 _SCK	=	0x0097
                           000096   471 _MISO	=	0x0096
                           000095   472 _MOSI	=	0x0095
                           000094   473 _SCS	=	0x0094
                           000092   474 _INT0_	=	0x0092
                           000091   475 _T2EX	=	0x0091
                           000091   476 _CAP2	=	0x0091
                           000090   477 _T2	=	0x0090
                           000090   478 _CAP1	=	0x0090
                           000097   479 _AIN7	=	0x0097
                           000096   480 _AIN6	=	0x0096
                           000095   481 _AIN5	=	0x0095
                           000094   482 _AIN4	=	0x0094
                           000093   483 _AIN3	=	0x0093
                           000092   484 _AIN2	=	0x0092
                           000091   485 _AIN1	=	0x0091
                           000090   486 _AIN0	=	0x0090
                           0000A7   487 _P2_7	=	0x00a7
                           0000A6   488 _P2_6	=	0x00a6
                           0000A5   489 _P2_5	=	0x00a5
                           0000A4   490 _P2_4	=	0x00a4
                           0000A3   491 _P2_3	=	0x00a3
                           0000A2   492 _P2_2	=	0x00a2
                           0000A1   493 _P2_1	=	0x00a1
                           0000A0   494 _P2_0	=	0x00a0
                           0000A7   495 _TXD1	=	0x00a7
                           0000A6   496 _RXD1	=	0x00a6
                           0000A5   497 _T2EX_	=	0x00a5
                           0000A5   498 _CAP2_	=	0x00a5
                           0000A4   499 _T2_	=	0x00a4
                           0000A4   500 _CAP1_	=	0x00a4
                           0000B7   501 _P3_7	=	0x00b7
                           0000B6   502 _P3_6	=	0x00b6
                           0000B5   503 _P3_5	=	0x00b5
                           0000B4   504 _P3_4	=	0x00b4
                           0000B3   505 _P3_3	=	0x00b3
                           0000B2   506 _P3_2	=	0x00b2
                           0000B1   507 _P3_1	=	0x00b1
                           0000B0   508 _P3_0	=	0x00b0
                           0000B7   509 _SCK1	=	0x00b7
                           0000B6   510 _MISO1	=	0x00b6
                           0000B5   511 _MOSI1	=	0x00b5
                           0000B5   512 _T1	=	0x00b5
                           0000B4   513 _T0	=	0x00b4
                           0000B3   514 _INT1	=	0x00b3
                           0000B2   515 _INT0	=	0x00b2
                           0000B1   516 _TXD	=	0x00b1
                           0000B0   517 _RXD	=	0x00b0
                           0000C6   518 _P4_6	=	0x00c6
                           0000C5   519 _P4_5	=	0x00c5
                           0000C4   520 _P4_4	=	0x00c4
                           0000C3   521 _P4_3	=	0x00c3
                           0000C2   522 _P4_2	=	0x00c2
                           0000C1   523 _P4_1	=	0x00c1
                           0000C0   524 _P4_0	=	0x00c0
                           00008F   525 _TF1	=	0x008f
                           00008E   526 _TR1	=	0x008e
                           00008D   527 _TF0	=	0x008d
                           00008C   528 _TR0	=	0x008c
                           00008B   529 _IE1	=	0x008b
                           00008A   530 _IT1	=	0x008a
                           000089   531 _IE0	=	0x0089
                           000088   532 _IT0	=	0x0088
                           00009F   533 _SM0	=	0x009f
                           00009E   534 _SM1	=	0x009e
                           00009D   535 _SM2	=	0x009d
                           00009C   536 _REN	=	0x009c
                           00009B   537 _TB8	=	0x009b
                           00009A   538 _RB8	=	0x009a
                           000099   539 _TI	=	0x0099
                           000098   540 _RI	=	0x0098
                           0000CF   541 _TF2	=	0x00cf
                           0000CF   542 _CAP1F	=	0x00cf
                           0000CE   543 _EXF2	=	0x00ce
                           0000CD   544 _RCLK	=	0x00cd
                           0000CC   545 _TCLK	=	0x00cc
                           0000CB   546 _EXEN2	=	0x00cb
                           0000CA   547 _TR2	=	0x00ca
                           0000C9   548 _C_T2	=	0x00c9
                           0000C8   549 _CP_RL2	=	0x00c8
                           0000FF   550 _S0_FST_ACT	=	0x00ff
                           0000FE   551 _S0_IF_OV	=	0x00fe
                           0000FD   552 _S0_IF_FIRST	=	0x00fd
                           0000FC   553 _S0_IF_BYTE	=	0x00fc
                           0000FB   554 _S0_FREE	=	0x00fb
                           0000FA   555 _S0_T_FIFO	=	0x00fa
                           0000F8   556 _S0_R_FIFO	=	0x00f8
                           0000F7   557 _ADC_START	=	0x00f7
                                    558 ;--------------------------------------------------------
                                    559 ; overlayable register banks
                                    560 ;--------------------------------------------------------
                                    561 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        562 	.ds 8
                                    563 ;--------------------------------------------------------
                                    564 ; internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area DSEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; overlayable items in internal ram
                                    569 ;--------------------------------------------------------
                                    570 ;--------------------------------------------------------
                                    571 ; indirectly addressable internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area ISEG    (DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; absolute internal ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area IABS    (ABS,DATA)
                                    578 	.area IABS    (ABS,DATA)
                                    579 ;--------------------------------------------------------
                                    580 ; bit data
                                    581 ;--------------------------------------------------------
                                    582 	.area BSEG    (BIT)
      000028                        583 _get_record_keycode_sloc0_1_0:
      000028                        584 	.ds 1
      000029                        585 _pre_process_record_quantum_sloc0_1_0:
      000029                        586 	.ds 1
      00002A                        587 _process_ak820_nkro_sloc0_1_0:
      00002A                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; paged external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area PSEG    (PAG,XDATA)
                                    593 ;--------------------------------------------------------
                                    594 ; uninitialized external ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area XSEG    (XDATA)
      000CAE                        597 _extract_mod_bits_code_10000_606:
      000CAE                        598 	.ds 2
      000CB0                        599 _register_code16_code_10000_612:
      000CB0                        600 	.ds 2
      000CB2                        601 _unregister_code16_code_10000_617:
      000CB2                        602 	.ds 2
      000CB4                        603 _pre_process_record_kb_PARM_2:
      000CB4                        604 	.ds 3
      000CB7                        605 _pre_process_record_kb_keycode_10000_631:
      000CB7                        606 	.ds 2
      000CB9                        607 _pre_process_record_user_PARM_2:
      000CB9                        608 	.ds 3
      000CBC                        609 _process_record_kb_PARM_2:
      000CBC                        610 	.ds 3
      000CBF                        611 _process_record_kb_keycode_10000_637:
      000CBF                        612 	.ds 2
      000CC1                        613 _process_record_user_PARM_2:
      000CC1                        614 	.ds 3
      000CC4                        615 _post_process_record_kb_PARM_2:
      000CC4                        616 	.ds 3
      000CC7                        617 _post_process_record_kb_keycode_10000_641:
      000CC7                        618 	.ds 2
      000CC9                        619 _post_process_record_user_PARM_2:
      000CC9                        620 	.ds 3
      000CCC                        621 _get_record_keycode_PARM_2:
      000CCC                        622 	.ds 1
      000CCD                        623 _get_record_keycode_record_argument_10000_655:
      000CCD                        624 	.ds 2
      000CCF                        625 _pre_process_record_quantum_record_argument_10000_661:
      000CCF                        626 	.ds 2
      000CD1                        627 _post_process_record_quantum_record_10000_664:
      000CD1                        628 	.ds 2
      000CD3                        629 _process_record_quantum_record_10000_666:
      000CD3                        630 	.ds 2
      000CD5                        631 _process_ak820_nkro_PARM_2:
      000CD5                        632 	.ds 3
      000CD8                        633 _process_ak820_nkro_keycode_10000_668:
      000CD8                        634 	.ds 2
      000CDA                        635 _process_record_quantum_helper_PARM_2:
      000CDA                        636 	.ds 2
      000CDC                        637 _process_record_quantum_helper_keycode_10000_673:
      000CDC                        638 	.ds 2
      000CDE                        639 _get_u8_str_last_num_10000_699:
      000CDE                        640 	.ds 1
      000CDF                        641 _get_u16_str_last_num_10000_703:
      000CDF                        642 	.ds 2
                                    643 ;--------------------------------------------------------
                                    644 ; absolute external ram data
                                    645 ;--------------------------------------------------------
                                    646 	.area XABS    (ABS,XDATA)
                                    647 ;--------------------------------------------------------
                                    648 ; initialized external ram data
                                    649 ;--------------------------------------------------------
                                    650 	.area XISEG   (XDATA)
                                    651 	.area HOME    (CODE)
                                    652 	.area GSINIT0 (CODE)
                                    653 	.area GSINIT1 (CODE)
                                    654 	.area GSINIT2 (CODE)
                                    655 	.area GSINIT3 (CODE)
                                    656 	.area GSINIT4 (CODE)
                                    657 	.area GSINIT5 (CODE)
                                    658 	.area GSINIT  (CODE)
                                    659 	.area GSFINAL (CODE)
                                    660 	.area CSEG    (CODE)
                                    661 ;--------------------------------------------------------
                                    662 ; global & static initialisations
                                    663 ;--------------------------------------------------------
                                    664 	.area HOME    (CODE)
                                    665 	.area GSINIT  (CODE)
                                    666 	.area GSFINAL (CODE)
                                    667 	.area GSINIT  (CODE)
                                    668 ;------------------------------------------------------------
                                    669 ;Allocation info for local variables in function 'get_u8_str'
                                    670 ;------------------------------------------------------------
                                    671 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    672 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_698'
                                    673 ;buf           Allocated with name '_get_u8_str_buf_10000_699'
                                    674 ;last_num      Allocated with name '_get_u8_str_last_num_10000_699'
                                    675 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_699'
                                    676 ;------------------------------------------------------------
                                    677 ;	quantum/quantum.c:778: static uint8_t last_num = 0xFF;
      0030F3 90 0C DE         [24]  678 	mov	dptr,#_get_u8_str_last_num_10000_699
      0030F6 74 FF            [12]  679 	mov	a,#0xff
      0030F8 F0               [24]  680 	movx	@dptr,a
                                    681 ;------------------------------------------------------------
                                    682 ;Allocation info for local variables in function 'get_u16_str'
                                    683 ;------------------------------------------------------------
                                    684 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    685 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_702'
                                    686 ;buf           Allocated with name '_get_u16_str_buf_10000_703'
                                    687 ;last_num      Allocated with name '_get_u16_str_last_num_10000_703'
                                    688 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_703'
                                    689 ;------------------------------------------------------------
                                    690 ;	quantum/quantum.c:798: static uint16_t last_num = 0xFF;
      0030F9 90 0C DF         [24]  691 	mov	dptr,#_get_u16_str_last_num_10000_703
      0030FC 74 FF            [12]  692 	mov	a,#0xff
      0030FE F0               [24]  693 	movx	@dptr,a
      0030FF E4               [12]  694 	clr	a
      003100 A3               [24]  695 	inc	dptr
      003101 F0               [24]  696 	movx	@dptr,a
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    708 ;------------------------------------------------------------
                                    709 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    710 ;------------------------------------------------------------
                                    711 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function extract_mod_bits
                                    722 ;	-----------------------------------------
      00A2C3                        723 _extract_mod_bits:
      00A2C3 12 38 7A         [24]  724 	lcall	_ak820_outline_0106
      00A2C6 90 0C AE         [24]  725 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A2C9 12 38 75         [24]  726 	lcall	_ak820_outline_0105
                                    727 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A2CC 90 0C AE         [24]  728 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A2CF E0               [24]  729 	movx	a,@dptr
      00A2D0 A3               [24]  730 	inc	dptr
      00A2D1 E0               [24]  731 	movx	a,@dptr
                                    732 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A2D2 FF               [12]  733 	mov	r7,a
      00A2D3 60 05            [24]  734 	jz	00101$
      00A2D5 EF               [12]  735 	mov	a,r7
      00A2D6 24 E0            [12]  736 	add	a,#0xff - 0x1f
      00A2D8 50 04            [24]  737 	jnc	00102$
                                    738 ;	free result
      00A2DA                        739 00101$:
      00A2DA 75 82 00         [24]  740 	mov	dpl, #0x00
      00A2DD 22               [24]  741 	ret
      00A2DE                        742 00102$:
                                    743 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A2DE EF               [12]  744 	mov	a,r7
      00A2DF 30 E4 07         [24]  745 	jnb	acc.4,00106$
      00A2E2 EF               [12]  746 	mov	a,r7
      00A2E3 C4               [12]  747 	swap	a
      00A2E4 54 F0            [12]  748 	anl	a,#0xf0
      00A2E6 FE               [12]  749 	mov	r6,a
      00A2E7 80 02            [24]  750 	sjmp	00107$
      00A2E9                        751 00106$:
      00A2E9 8F 06            [24]  752 	mov	ar6,r7
      00A2EB                        753 00107$:
      00A2EB 8E 82            [24]  754 	mov	dpl, r6
                                    755 ;	quantum/quantum.c:143: }
      00A2ED 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'do_code16'
                                    759 ;------------------------------------------------------------
                                    760 ;f             Allocated with name '_do_code16_PARM_2'
                                    761 ;code          Allocated with name '_do_code16_code_10000_609'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function register_code16
                                    766 ;	-----------------------------------------
      00A2EE                        767 _register_code16:
      00A2EE 12 38 7A         [24]  768 	lcall	_ak820_outline_0106
      00A2F1 90 0C B0         [24]  769 	mov	dptr,#_register_code16_code_10000_612
      00A2F4 12 38 75         [24]  770 	lcall	_ak820_outline_0105
                                    771 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A2F7 90 0C B0         [24]  772 	mov	dptr,#_register_code16_code_10000_612
      00A2FA 12 37 DC         [24]  773 	lcall	_ak820_outline_0005
      00A2FD C0 07            [24]  774 	push	ar7
      00A2FF C0 06            [24]  775 	push	ar6
      00A301 51 C3            [12]  776 	acall	_extract_mod_bits
      00A303 AD 82            [24]  777 	mov	r5, dpl
      00A305 D0 06            [24]  778 	pop	ar6
      00A307 D0 07            [24]  779 	pop	ar7
                                    780 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A309 12 A0 FB         [24]  781 	lcall	_ak820_outline_0122
      00A30C 40 07            [24]  782 	jc	00105$
      00A30E 74 E7            [12]  783 	mov	a,#0xe7
      00A310 9E               [12]  784 	subb	a,r6
      00A311 E4               [12]  785 	clr	a
      00A312 9F               [12]  786 	subb	a,r7
      00A313 50 08            [24]  787 	jnc	00101$
                                    788 ;	free result
      00A315                        789 00105$:
      00A315 90 0C B0         [24]  790 	mov	dptr,#_register_code16_code_10000_612
      00A318 12 48 F6         [24]  791 	lcall	_ak820_outline_0038
      00A31B 70 07            [24]  792 	jnz	00102$
      00A31D                        793 00101$:
                                    794 ;	quantum/quantum.c:153: register_mods(mods);
      00A31D 8D 82            [24]  795 	mov	dpl, r5
      00A31F 12 7B 08         [24]  796 	lcall	_register_mods
      00A322 80 05            [24]  797 	sjmp	00103$
      00A324                        798 00102$:
                                    799 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A324 8D 82            [24]  800 	mov	dpl, r5
      00A326 12 7B 30         [24]  801 	lcall	_register_weak_mods
      00A329                        802 00103$:
                                    803 ;	quantum/quantum.c:157: register_code(code);
      00A329 90 0C B0         [24]  804 	mov	dptr,#_register_code16_code_10000_612
      00A32C E0               [24]  805 	movx	a,@dptr
      00A32D F5 82            [12]  806 	mov	dpl,a
                                    807 ;	quantum/quantum.c:167: }
      00A32F 02 79 E8         [24]  808 	ljmp	_register_code
                                    809 ;------------------------------------------------------------
                                    810 ;Allocation info for local variables in function 'unregister_code16'
                                    811 ;------------------------------------------------------------
                                    812 ;code          Allocated with name '_unregister_code16_code_10000_617'
                                    813 ;mods          Allocated with name '_unregister_code16_mods_10000_618'
                                    814 ;------------------------------------------------------------
                                    815 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    816 ;	-----------------------------------------
                                    817 ;	 function unregister_code16
                                    818 ;	-----------------------------------------
      00A332                        819 _unregister_code16:
      00A332 12 38 7A         [24]  820 	lcall	_ak820_outline_0106
      00A335 90 0C B2         [24]  821 	mov	dptr,#_unregister_code16_code_10000_617
      00A338 12 38 75         [24]  822 	lcall	_ak820_outline_0105
                                    823 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A33B 90 0C B2         [24]  824 	mov	dptr,#_unregister_code16_code_10000_617
      00A33E 12 37 DC         [24]  825 	lcall	_ak820_outline_0005
      00A341 C0 07            [24]  826 	push	ar7
      00A343 C0 06            [24]  827 	push	ar6
      00A345 51 C3            [12]  828 	acall	_extract_mod_bits
      00A347 AD 82            [24]  829 	mov	r5, dpl
      00A349 D0 06            [24]  830 	pop	ar6
                                    831 ;	quantum/quantum.c:172: unregister_code(code);
      00A34B 8E 04            [24]  832 	mov	ar4,r6
      00A34D 8C 82            [24]  833 	mov	dpl, r4
      00A34F C0 06            [24]  834 	push	ar6
      00A351 C0 05            [24]  835 	push	ar5
      00A353 12 7A 55         [24]  836 	lcall	_unregister_code
      00A356 D0 05            [24]  837 	pop	ar5
      00A358 D0 06            [24]  838 	pop	ar6
      00A35A D0 07            [24]  839 	pop	ar7
                                    840 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A35C 12 A0 FB         [24]  841 	lcall	_ak820_outline_0122
      00A35F 40 07            [24]  842 	jc	00105$
      00A361 74 E7            [12]  843 	mov	a,#0xe7
      00A363 9E               [12]  844 	subb	a,r6
      00A364 E4               [12]  845 	clr	a
      00A365 9F               [12]  846 	subb	a,r7
      00A366 50 08            [24]  847 	jnc	00101$
                                    848 ;	free result
      00A368                        849 00105$:
      00A368 90 0C B2         [24]  850 	mov	dptr,#_unregister_code16_code_10000_617
      00A36B 12 48 F6         [24]  851 	lcall	_ak820_outline_0038
      00A36E 70 05            [24]  852 	jnz	00102$
      00A370                        853 00101$:
                                    854 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A370 8D 82            [24]  855 	mov	dpl, r5
      00A372 02 7B 1C         [24]  856 	ljmp	_unregister_mods
      00A375                        857 00102$:
                                    858 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A375 8D 82            [24]  859 	mov	dpl, r5
                                    860 ;	quantum/quantum.c:187: }
      00A377 02 7B 44         [24]  861 	ljmp	_unregister_weak_mods
                                    862 ;------------------------------------------------------------
                                    863 ;Allocation info for local variables in function 'tap_code16_delay'
                                    864 ;------------------------------------------------------------
                                    865 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    866 ;code          Allocated with name '_tap_code16_delay_code_10000_622'
                                    867 ;i             Allocated with name '_tap_code16_delay_i_20000_624'
                                    868 ;i             Allocated with name '_tap_code16_delay_i_50000_627'
                                    869 ;------------------------------------------------------------
                                    870 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function pre_process_record_kb
                                    873 ;	-----------------------------------------
      00A37A                        874 _pre_process_record_kb:
      00A37A 12 38 7A         [24]  875 	lcall	_ak820_outline_0106
      00A37D 90 0C B7         [24]  876 	mov	dptr,#_pre_process_record_kb_keycode_10000_631
      00A380 12 38 75         [24]  877 	lcall	_ak820_outline_0105
                                    878 ;	quantum/quantum.c:211: return pre_process_record_user(keycode, record);
      00A383 90 0C B7         [24]  879 	mov	dptr,#_pre_process_record_kb_keycode_10000_631
      00A386 12 38 2E         [24]  880 	lcall	_ak820_outline_0059
      00A389 90 0C B4         [24]  881 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A38C 12 A0 F2         [24]  882 	lcall	_ak820_outline_0047
      00A38F 90 0C B9         [24]  883 	mov	dptr,#_pre_process_record_user_PARM_2
      00A392 12 A6 E1         [24]  884 	lcall	_ak820_outline_0018
                                    885 ;	quantum/quantum.c:212: }
      00A395 61 97            [12]  886 	ajmp	_pre_process_record_user
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'pre_process_record_user'
                                    889 ;------------------------------------------------------------
                                    890 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    891 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_633'
                                    892 ;------------------------------------------------------------
                                    893 ;	quantum/quantum.c:214: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    894 ;	-----------------------------------------
                                    895 ;	 function pre_process_record_user
                                    896 ;	-----------------------------------------
      00A397                        897 _pre_process_record_user:
                                    898 ;	quantum/quantum.c:215: return true;
      00A397 75 82 01         [24]  899 	mov	dpl, #0x01
                                    900 ;	quantum/quantum.c:216: }
      00A39A 22               [24]  901 	ret
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'process_action_kb'
                                    904 ;------------------------------------------------------------
                                    905 ;record        Allocated with name '_process_action_kb_record_10000_635'
                                    906 ;------------------------------------------------------------
                                    907 ;	quantum/quantum.c:218: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    908 ;	-----------------------------------------
                                    909 ;	 function process_action_kb
                                    910 ;	-----------------------------------------
      00A39B                        911 _process_action_kb:
                                    912 ;	quantum/quantum.c:219: return true;
      00A39B 75 82 01         [24]  913 	mov	dpl, #0x01
                                    914 ;	quantum/quantum.c:220: }
      00A39E 22               [24]  915 	ret
                                    916 ;------------------------------------------------------------
                                    917 ;Allocation info for local variables in function 'process_record_kb'
                                    918 ;------------------------------------------------------------
                                    919 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    920 ;keycode       Allocated with name '_process_record_kb_keycode_10000_637'
                                    921 ;------------------------------------------------------------
                                    922 ;	quantum/quantum.c:222: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function process_record_kb
                                    925 ;	-----------------------------------------
      00A39F                        926 _process_record_kb:
      00A39F 12 38 7A         [24]  927 	lcall	_ak820_outline_0106
      00A3A2 90 0C BF         [24]  928 	mov	dptr,#_process_record_kb_keycode_10000_637
      00A3A5 12 38 75         [24]  929 	lcall	_ak820_outline_0105
                                    930 ;	quantum/quantum.c:223: return process_record_user(keycode, record);
      00A3A8 90 0C BF         [24]  931 	mov	dptr,#_process_record_kb_keycode_10000_637
      00A3AB 12 38 2E         [24]  932 	lcall	_ak820_outline_0059
      00A3AE 90 0C BC         [24]  933 	mov	dptr,#_process_record_kb_PARM_2
      00A3B1 12 A0 F2         [24]  934 	lcall	_ak820_outline_0047
      00A3B4 90 0C C1         [24]  935 	mov	dptr,#_process_record_user_PARM_2
      00A3B7 12 A6 E1         [24]  936 	lcall	_ak820_outline_0018
                                    937 ;	quantum/quantum.c:224: }
      00A3BA 61 BC            [12]  938 	ajmp	_process_record_user
                                    939 ;------------------------------------------------------------
                                    940 ;Allocation info for local variables in function 'process_record_user'
                                    941 ;------------------------------------------------------------
                                    942 ;record        Allocated with name '_process_record_user_PARM_2'
                                    943 ;keycode       Allocated with name '_process_record_user_keycode_10000_639'
                                    944 ;------------------------------------------------------------
                                    945 ;	quantum/quantum.c:226: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function process_record_user
                                    948 ;	-----------------------------------------
      00A3BC                        949 _process_record_user:
                                    950 ;	quantum/quantum.c:227: return true;
      00A3BC 75 82 01         [24]  951 	mov	dpl, #0x01
                                    952 ;	quantum/quantum.c:228: }
      00A3BF 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'post_process_record_kb'
                                    956 ;------------------------------------------------------------
                                    957 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    958 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_641'
                                    959 ;------------------------------------------------------------
                                    960 ;	quantum/quantum.c:230: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function post_process_record_kb
                                    963 ;	-----------------------------------------
      00A3C0                        964 _post_process_record_kb:
      00A3C0 12 38 7A         [24]  965 	lcall	_ak820_outline_0106
      00A3C3 90 0C C7         [24]  966 	mov	dptr,#_post_process_record_kb_keycode_10000_641
      00A3C6 12 38 75         [24]  967 	lcall	_ak820_outline_0105
                                    968 ;	quantum/quantum.c:231: post_process_record_user(keycode, record);
      00A3C9 90 0C C7         [24]  969 	mov	dptr,#_post_process_record_kb_keycode_10000_641
      00A3CC 12 38 2E         [24]  970 	lcall	_ak820_outline_0059
      00A3CF 90 0C C4         [24]  971 	mov	dptr,#_post_process_record_kb_PARM_2
      00A3D2 12 A0 F2         [24]  972 	lcall	_ak820_outline_0047
      00A3D5 90 0C C9         [24]  973 	mov	dptr,#_post_process_record_user_PARM_2
      00A3D8 12 A6 E1         [24]  974 	lcall	_ak820_outline_0018
                                    975 ;	quantum/quantum.c:232: }
      00A3DB 61 DD            [24]  976 	ajmp	_post_process_record_user
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'post_process_record_user'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    981 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_643'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/quantum.c:234: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    984 ;	-----------------------------------------
                                    985 ;	 function post_process_record_user
                                    986 ;	-----------------------------------------
      00A3DD                        987 _post_process_record_user:
      00A3DD 22               [24]  988 	ret
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'shutdown_quantum'
                                    991 ;------------------------------------------------------------
                                    992 ;i             Allocated with name '_shutdown_quantum_i_30000_649'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/quantum.c:236: void shutdown_quantum(void) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function shutdown_quantum
                                    997 ;	-----------------------------------------
      00A3DE                        998 _shutdown_quantum:
                                    999 ;	quantum/quantum.c:237: clear_keyboard();
      00A3DE 12 7B 58         [24] 1000 	lcall	_clear_keyboard
                                   1001 ;	quantum/quantum.c:252: shutdown_user();
      00A3E1 D1 D3            [12] 1002 	acall	_shutdown_user
                                   1003 ;	quantum/quantum.c:253: wait_ms(250);
      00A3E3 7F FA            [12] 1004 	mov	r7,#0xfa
      00A3E5                       1005 00106$:
      00A3E5 EF               [12] 1006 	mov	a,r7
      00A3E6 60 09            [24] 1007 	jz	00108$
      00A3E8 90 00 01         [24] 1008 	mov	dptr,#0x0001
      00A3EB 12 5D F2         [24] 1009 	lcall	_mDelaymS
      00A3EE 1F               [12] 1010 	dec	r7
      00A3EF 80 F4            [24] 1011 	sjmp	00106$
      00A3F1                       1012 00108$:
                                   1013 ;	quantum/quantum.c:258: }
      00A3F1 22               [24] 1014 	ret
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'reset_keyboard'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function reset_keyboard
                                   1021 ;	-----------------------------------------
      00A3F2                       1022 _reset_keyboard:
                                   1023 ;	quantum/quantum.c:261: shutdown_quantum();
      00A3F2 71 DE            [24] 1024 	acall	_shutdown_quantum
                                   1025 ;	quantum/quantum.c:262: bootloader_jump();
                                   1026 ;	quantum/quantum.c:263: }
      00A3F4 02 34 0E         [24] 1027 	ljmp	_bootloader_jump
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function soft_reset_keyboard
                                   1034 ;	-----------------------------------------
      00A3F7                       1035 _soft_reset_keyboard:
                                   1036 ;	quantum/quantum.c:266: shutdown_quantum();
      00A3F7 71 DE            [24] 1037 	acall	_shutdown_quantum
                                   1038 ;	quantum/quantum.c:267: mcu_reset();
                                   1039 ;	quantum/quantum.c:268: }
      00A3F9 02 34 01         [24] 1040 	ljmp	_mcu_reset
                                   1041 ;------------------------------------------------------------
                                   1042 ;Allocation info for local variables in function 'get_record_keycode'
                                   1043 ;------------------------------------------------------------
                                   1044 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1045 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_655'
                                   1046 ;record        Allocated with name '_get_record_keycode_record_10000_656'
                                   1047 ;------------------------------------------------------------
                                   1048 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                   1049 ;	-----------------------------------------
                                   1050 ;	 function get_record_keycode
                                   1051 ;	-----------------------------------------
      00A3FC                       1052 _get_record_keycode:
      00A3FC 12 38 7A         [24] 1053 	lcall	_ak820_outline_0106
      00A3FF 90 0C CD         [24] 1054 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A402 12 38 75         [24] 1055 	lcall	_ak820_outline_0105
                                   1056 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A405 90 0C CD         [24] 1057 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A408 12 37 F3         [24] 1058 	lcall	_ak820_outline_0008
                                   1059 ;	quantum/quantum.c:278: if (record->keycode) {
      00A40B FC               [12] 1060 	mov	r4,a
      00A40C A3               [24] 1061 	inc	dptr
      00A40D E0               [24] 1062 	movx	a,@dptr
      00A40E FD               [12] 1063 	mov	r5,a
      00A40F 4C               [12] 1064 	orl	a,r4
      00A410 60 04            [24] 1065 	jz	00102$
                                   1066 ;	quantum/quantum.c:279: return record->keycode;
      00A412 12 38 98         [24] 1067 	lcall	_ak820_outline_0129
      00A415 22               [24] 1068 	ret
      00A416                       1069 00102$:
                                   1070 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A416 12 7B 9A         [24] 1071 	lcall	_ak820_outline_0023
      00A419 7A 00            [12] 1072 	mov	r2,#0x00
      00A41B 12 43 6C         [24] 1073 	lcall	_ak820_outline_0145
      00A41E 12 37 E6         [24] 1074 	lcall	_ak820_outline_0006
      00A421 60 06            [24] 1075 	jz	00105$
      00A423 90 0C CC         [24] 1076 	mov	dptr,#_get_record_keycode_PARM_2
      00A426 E0               [24] 1077 	movx	a,@dptr
      00A427 70 04            [24] 1078 	jnz	00106$
      00A429                       1079 00105$:
                                   1080 ;	assignBit
      00A429 C2 28            [12] 1081 	clr	_get_record_keycode_sloc0_1_0
      00A42B 80 02            [24] 1082 	sjmp	00107$
      00A42D                       1083 00106$:
                                   1084 ;	assignBit
      00A42D D2 28            [12] 1085 	setb	_get_record_keycode_sloc0_1_0
      00A42F                       1086 00107$:
      00A42F 90 0A 2F         [24] 1087 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A432 A2 28            [12] 1088 	mov	c,_get_record_keycode_sloc0_1_0
      00A434 E4               [12] 1089 	clr	a
      00A435 33               [12] 1090 	rlc	a
      00A436 F0               [24] 1091 	movx	@dptr,a
      00A437 8D 82            [24] 1092 	mov	dpl, r5
      00A439 8C 83            [24] 1093 	mov	dph, r4
                                   1094 ;	quantum/quantum.c:287: }
      00A43B 02 7F 1F         [24] 1095 	ljmp	_ak820_resolve_key
                                   1096 ;------------------------------------------------------------
                                   1097 ;Allocation info for local variables in function 'get_event_keycode'
                                   1098 ;------------------------------------------------------------
                                   1099 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1100 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_659'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function pre_process_record_quantum
                                   1105 ;	-----------------------------------------
      00A43E                       1106 _pre_process_record_quantum:
      00A43E 12 38 7A         [24] 1107 	lcall	_ak820_outline_0106
      00A441 90 0C CF         [24] 1108 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A444 12 38 75         [24] 1109 	lcall	_ak820_outline_0105
                                   1110 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A447 90 0C CF         [24] 1111 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A44A 12 38 2E         [24] 1112 	lcall	_ak820_outline_0059
                                   1113 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A44D 90 0C CC         [24] 1114 	mov	dptr,#_get_record_keycode_PARM_2
      00A450 74 01            [12] 1115 	mov	a,#0x01
      00A452 12 43 43         [24] 1116 	lcall	_ak820_outline_0072
      00A455 C0 07            [24] 1117 	push	ar7
      00A457 C0 06            [24] 1118 	push	ar6
      00A459 71 FC            [24] 1119 	acall	_get_record_keycode
      00A45B 12 43 72         [24] 1120 	lcall	_ak820_outline_0154
      00A45E D0 06            [24] 1121 	pop	ar6
      00A460 D0 07            [24] 1122 	pop	ar7
                                   1123 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A462 74 07            [12] 1124 	mov	a,#0x07
      00A464 12 38 26         [24] 1125 	lcall	_ak820_outline_0036
      00A467 EC               [12] 1126 	mov	a,r4
      00A468 F0               [24] 1127 	movx	@dptr,a
      00A469 ED               [12] 1128 	mov	a,r5
      00A46A 12 43 35         [24] 1129 	lcall	_ak820_outline_0064
                                   1130 ;	quantum/quantum.c:351: if (!ak820_tap_dance_process((keyrecord_t AK820_STATE_MEM *)record)) return false;
      00A46D C0 07            [24] 1131 	push	ar7
      00A46F C0 06            [24] 1132 	push	ar6
      00A471 C0 05            [24] 1133 	push	ar5
      00A473 C0 04            [24] 1134 	push	ar4
      00A475 12 46 D5         [24] 1135 	lcall	_ak820_tap_dance_process
      00A478 E5 82            [12] 1136 	mov	a, dpl
      00A47A D0 04            [24] 1137 	pop	ar4
      00A47C D0 05            [24] 1138 	pop	ar5
      00A47E D0 06            [24] 1139 	pop	ar6
      00A480 D0 07            [24] 1140 	pop	ar7
      00A482 70 03            [24] 1141 	jnz	00102$
      00A484 F5 82            [12] 1142 	mov	dpl,a
      00A486 22               [24] 1143 	ret
      00A487                       1144 00102$:
                                   1145 ;	quantum/quantum.c:353: return pre_process_record_kb(keycode, record) &&
      00A487 90 0C B4         [24] 1146 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A48A 12 A6 D4         [24] 1147 	lcall	_ak820_outline_0001
      00A48D C0 07            [24] 1148 	push	ar7
      00A48F C0 06            [24] 1149 	push	ar6
      00A491 71 7A            [12] 1150 	acall	_pre_process_record_kb
      00A493 E5 82            [12] 1151 	mov	a, dpl
      00A495 D0 06            [24] 1152 	pop	ar6
      00A497 D0 07            [24] 1153 	pop	ar7
      00A499 60 0A            [24] 1154 	jz	00105$
                                   1155 ;	quantum/quantum.c:356: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A49B 12 38 8D         [24] 1156 	lcall	_ak820_outline_0121
      00A49E 12 36 2D         [24] 1157 	lcall	_ak820_combo_process
      00A4A1 E5 82            [12] 1158 	mov	a, dpl
      00A4A3 70 04            [24] 1159 	jnz	00106$
                                   1160 ;	quantum/quantum.c:361: true;
      00A4A5                       1161 00105$:
                                   1162 ;	assignBit
      00A4A5 C2 29            [12] 1163 	clr	_pre_process_record_quantum_sloc0_1_0
      00A4A7 80 02            [24] 1164 	sjmp	00107$
      00A4A9                       1165 00106$:
                                   1166 ;	assignBit
      00A4A9 D2 29            [12] 1167 	setb	_pre_process_record_quantum_sloc0_1_0
      00A4AB                       1168 00107$:
      00A4AB A2 29            [12] 1169 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A4AD 12 38 AC         [24] 1170 	lcall	_ak820_outline_0147
                                   1171 ;	quantum/quantum.c:362: }
      00A4B0 22               [24] 1172 	ret
                                   1173 ;------------------------------------------------------------
                                   1174 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1175 ;------------------------------------------------------------
                                   1176 ;record        Allocated with name '_post_process_record_quantum_record_10000_664'
                                   1177 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_665'
                                   1178 ;------------------------------------------------------------
                                   1179 ;	quantum/quantum.c:365: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                   1180 ;	-----------------------------------------
                                   1181 ;	 function post_process_record_quantum
                                   1182 ;	-----------------------------------------
      00A4B1                       1183 _post_process_record_quantum:
      00A4B1 12 38 7A         [24] 1184 	lcall	_ak820_outline_0106
      00A4B4 90 0C D1         [24] 1185 	mov	dptr,#_post_process_record_quantum_record_10000_664
      00A4B7 12 38 75         [24] 1186 	lcall	_ak820_outline_0105
                                   1187 ;	quantum/quantum.c:366: uint16_t keycode = get_record_keycode(record, false);
      00A4BA 90 0C D1         [24] 1188 	mov	dptr,#_post_process_record_quantum_record_10000_664
      00A4BD 12 38 2E         [24] 1189 	lcall	_ak820_outline_0059
      00A4C0 90 0C CC         [24] 1190 	mov	dptr,#_get_record_keycode_PARM_2
      00A4C3 E4               [12] 1191 	clr	a
      00A4C4 12 43 43         [24] 1192 	lcall	_ak820_outline_0072
      00A4C7 71 FC            [24] 1193 	acall	_get_record_keycode
      00A4C9 12 43 67         [24] 1194 	lcall	_ak820_outline_0139
                                   1195 ;	quantum/quantum.c:367: post_process_record_kb(keycode, record);
      00A4CC 90 0C D1         [24] 1196 	mov	dptr,#_post_process_record_quantum_record_10000_664
      00A4CF 12 38 69         [24] 1197 	lcall	_ak820_outline_0099
      00A4D2 7D 00            [12] 1198 	mov	r5,#0x00
      00A4D4 90 0C C4         [24] 1199 	mov	dptr,#_post_process_record_kb_PARM_2
      00A4D7 12 A6 E1         [24] 1200 	lcall	_ak820_outline_0018
                                   1201 ;	quantum/quantum.c:368: }
      00A4DA 61 C0            [12] 1202 	ajmp	_post_process_record_kb
                                   1203 ;------------------------------------------------------------
                                   1204 ;Allocation info for local variables in function 'process_record_quantum'
                                   1205 ;------------------------------------------------------------
                                   1206 ;record        Allocated with name '_process_record_quantum_record_10000_666'
                                   1207 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_667'
                                   1208 ;------------------------------------------------------------
                                   1209 ;	quantum/quantum.c:370: bool process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                   1210 ;	-----------------------------------------
                                   1211 ;	 function process_record_quantum
                                   1212 ;	-----------------------------------------
      00A4DC                       1213 _process_record_quantum:
      00A4DC 12 38 7A         [24] 1214 	lcall	_ak820_outline_0106
      00A4DF 90 0C D3         [24] 1215 	mov	dptr,#_process_record_quantum_record_10000_666
      00A4E2 12 38 75         [24] 1216 	lcall	_ak820_outline_0105
                                   1217 ;	quantum/quantum.c:372: uint16_t keycode = get_record_keycode(record, false);
      00A4E5 90 0C D3         [24] 1218 	mov	dptr,#_process_record_quantum_record_10000_666
      00A4E8 12 38 2E         [24] 1219 	lcall	_ak820_outline_0059
      00A4EB 90 0C CC         [24] 1220 	mov	dptr,#_get_record_keycode_PARM_2
      00A4EE E4               [12] 1221 	clr	a
      00A4EF 12 43 43         [24] 1222 	lcall	_ak820_outline_0072
      00A4F2 71 FC            [24] 1223 	acall	_get_record_keycode
      00A4F4 12 43 67         [24] 1224 	lcall	_ak820_outline_0139
                                   1225 ;	quantum/quantum.c:376: return process_record_quantum_helper(keycode, record);
      00A4F7 90 0C D3         [24] 1226 	mov	dptr,#_process_record_quantum_record_10000_666
      00A4FA 12 38 45         [24] 1227 	lcall	_ak820_outline_0065
      00A4FD 90 0C DA         [24] 1228 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A500 EC               [12] 1229 	mov	a,r4
      00A501 F0               [24] 1230 	movx	@dptr,a
      00A502 ED               [12] 1231 	mov	a,r5
      00A503 12 43 35         [24] 1232 	lcall	_ak820_outline_0064
                                   1233 ;	quantum/quantum.c:377: }
      00A506 A1 73            [24] 1234 	ajmp	_process_record_quantum_helper
                                   1235 ;------------------------------------------------------------
                                   1236 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1237 ;------------------------------------------------------------
                                   1238 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1239 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_668'
                                   1240 ;record        Allocated with name '_process_ak820_nkro_record_10000_669'
                                   1241 ;------------------------------------------------------------
                                   1242 ;	quantum/quantum.c:394: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1243 ;	-----------------------------------------
                                   1244 ;	 function process_ak820_nkro
                                   1245 ;	-----------------------------------------
      00A508                       1246 _process_ak820_nkro:
      00A508 12 38 7A         [24] 1247 	lcall	_ak820_outline_0106
      00A50B 90 0C D8         [24] 1248 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A50E 12 38 75         [24] 1249 	lcall	_ak820_outline_0105
                                   1250 ;	quantum/quantum.c:396: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A511 90 0C D5         [24] 1251 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A514 12 38 2E         [24] 1252 	lcall	_ak820_outline_0059
                                   1253 ;	quantum/quantum.c:400: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A517 90 0C D8         [24] 1254 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A51A 12 38 45         [24] 1255 	lcall	_ak820_outline_0065
      00A51D C3               [12] 1256 	clr	c
      00A51E EC               [12] 1257 	mov	a,r4
      00A51F 94 11            [12] 1258 	subb	a,#0x11
      00A521 ED               [12] 1259 	mov	a,r5
      00A522 94 70            [12] 1260 	subb	a,#0x70
      00A524 40 08            [24] 1261 	jc	00101$
      00A526 74 13            [12] 1262 	mov	a,#0x13
      00A528 9C               [12] 1263 	subb	a,r4
      00A529 74 70            [12] 1264 	mov	a,#0x70
      00A52B 9D               [12] 1265 	subb	a,r5
      00A52C 50 04            [24] 1266 	jnc	00102$
                                   1267 ;	free result
      00A52E                       1268 00101$:
      00A52E 75 82 01         [24] 1269 	mov	dpl, #0x01
      00A531 22               [24] 1270 	ret
      00A532                       1271 00102$:
                                   1272 ;	quantum/quantum.c:401: if (record->event.pressed) {
      00A532 12 37 E6         [24] 1273 	lcall	_ak820_outline_0006
      00A535 60 38            [24] 1274 	jz	00105$
                                   1275 ;	quantum/quantum.c:402: clear_keyboard();
      00A537 C0 05            [24] 1276 	push	ar5
      00A539 C0 04            [24] 1277 	push	ar4
      00A53B 12 7B 58         [24] 1278 	lcall	_clear_keyboard
      00A53E D0 04            [24] 1279 	pop	ar4
      00A540 D0 05            [24] 1280 	pop	ar5
                                   1281 ;	quantum/quantum.c:403: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A542 BC 13 14         [24] 1282 	cjne	r4,#0x13,00108$
      00A545 BD 70 11         [24] 1283 	cjne	r5,#0x70,00108$
      00A548 90 0B 81         [24] 1284 	mov	dptr,#_keymap_config
      00A54B E0               [24] 1285 	movx	a,@dptr
      00A54C 23               [12] 1286 	rl	a
      00A54D 54 01            [12] 1287 	anl	a,#0x01
      00A54F B4 01 00         [24] 1288 	cjne	a,#0x01,00136$
      00A552                       1289 00136$:
      00A552 92 2A            [24] 1290 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A554 E4               [12] 1291 	clr	a
      00A555 33               [12] 1292 	rlc	a
      00A556 FF               [12] 1293 	mov	r7,a
      00A557 80 09            [24] 1294 	sjmp	00109$
      00A559                       1295 00108$:
      00A559 E4               [12] 1296 	clr	a
      00A55A BC 11 04         [24] 1297 	cjne	r4,#0x11,00137$
      00A55D BD 70 01         [24] 1298 	cjne	r5,#0x70,00137$
      00A560 04               [12] 1299 	inc	a
      00A561                       1300 00137$:
      00A561 FF               [12] 1301 	mov	r7,a
      00A562                       1302 00109$:
                                   1303 ;	assignBit
      00A562 EF               [12] 1304 	mov	a,r7
      00A563 24 FF            [12] 1305 	add	a,#0xff
      00A565 E4               [12] 1306 	clr	a
      00A566 33               [12] 1307 	rlc	a
      00A567 90 0B 81         [24] 1308 	mov	dptr,#_keymap_config
      00A56A 13               [12] 1309 	rrc	a
      00A56B E0               [24] 1310 	movx	a,@dptr
      00A56C 92 E7            [24] 1311 	mov	acc.7,c
      00A56E F0               [24] 1312 	movx	@dptr,a
      00A56F                       1313 00105$:
                                   1314 ;	quantum/quantum.c:405: return false;
      00A56F 75 82 00         [24] 1315 	mov	dpl, #0x00
                                   1316 ;	quantum/quantum.c:406: }
      00A572 22               [24] 1317 	ret
                                   1318 ;------------------------------------------------------------
                                   1319 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1320 ;------------------------------------------------------------
                                   1321 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1322 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_673'
                                   1323 ;record        Allocated with name '_process_record_quantum_helper_record_10000_674'
                                   1324 ;------------------------------------------------------------
                                   1325 ;	quantum/quantum.c:409: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1326 ;	-----------------------------------------
                                   1327 ;	 function process_record_quantum_helper
                                   1328 ;	-----------------------------------------
      00A573                       1329 _process_record_quantum_helper:
      00A573 12 38 7A         [24] 1330 	lcall	_ak820_outline_0106
      00A576 90 0C DC         [24] 1331 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A579 12 38 75         [24] 1332 	lcall	_ak820_outline_0105
                                   1333 ;	quantum/quantum.c:411: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A57C 90 0C DA         [24] 1334 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A57F 12 38 2E         [24] 1335 	lcall	_ak820_outline_0059
                                   1336 ;	quantum/quantum.c:454: process_ak820_nkro(keycode, record) &&
      00A582 90 0C DC         [24] 1337 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A585 12 38 45         [24] 1338 	lcall	_ak820_outline_0065
      00A588 90 0C D5         [24] 1339 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A58B 12 A6 D4         [24] 1340 	lcall	_ak820_outline_0001
      00A58E C0 07            [24] 1341 	push	ar7
      00A590 C0 06            [24] 1342 	push	ar6
      00A592 C0 05            [24] 1343 	push	ar5
      00A594 C0 04            [24] 1344 	push	ar4
      00A596 B1 08            [24] 1345 	acall	_process_ak820_nkro
      00A598 E5 82            [12] 1346 	mov	a, dpl
      00A59A D0 04            [24] 1347 	pop	ar4
      00A59C D0 05            [24] 1348 	pop	ar5
      00A59E D0 06            [24] 1349 	pop	ar6
      00A5A0 D0 07            [24] 1350 	pop	ar7
      00A5A2 70 02            [24] 1351 	jnz	00204$
      00A5A4 C1 91            [12] 1352 	ajmp	00101$
      00A5A6                       1353 00204$:
                                   1354 ;	quantum/quantum.c:465: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A5A6 90 0C 97         [24] 1355 	mov	dptr,#_process_last_key_PARM_2
      00A5A9 12 A6 D4         [24] 1356 	lcall	_ak820_outline_0001
      00A5AC C0 07            [24] 1357 	push	ar7
      00A5AE C0 06            [24] 1358 	push	ar6
      00A5B0 C0 05            [24] 1359 	push	ar5
      00A5B2 C0 04            [24] 1360 	push	ar4
      00A5B4 11 1F            [12] 1361 	acall	_process_last_key
      00A5B6 E5 82            [12] 1362 	mov	a, dpl
      00A5B8 D0 04            [24] 1363 	pop	ar4
      00A5BA D0 05            [24] 1364 	pop	ar5
      00A5BC D0 06            [24] 1365 	pop	ar6
      00A5BE D0 07            [24] 1366 	pop	ar7
      00A5C0 70 02            [24] 1367 	jnz	00205$
      00A5C2 C1 91            [12] 1368 	ajmp	00101$
      00A5C4                       1369 00205$:
      00A5C4 90 0C 9D         [24] 1370 	mov	dptr,#_process_repeat_key_PARM_2
      00A5C7 12 A6 D4         [24] 1371 	lcall	_ak820_outline_0001
      00A5CA C0 07            [24] 1372 	push	ar7
      00A5CC C0 06            [24] 1373 	push	ar6
      00A5CE C0 05            [24] 1374 	push	ar5
      00A5D0 C0 04            [24] 1375 	push	ar4
      00A5D2 11 9B            [12] 1376 	acall	_process_repeat_key
      00A5D4 E5 82            [12] 1377 	mov	a, dpl
      00A5D6 D0 04            [24] 1378 	pop	ar4
      00A5D8 D0 05            [24] 1379 	pop	ar5
      00A5DA D0 06            [24] 1380 	pop	ar6
      00A5DC D0 07            [24] 1381 	pop	ar7
      00A5DE 70 02            [24] 1382 	jnz	00206$
      00A5E0 C1 91            [12] 1383 	ajmp	00101$
      00A5E2                       1384 00206$:
                                   1385 ;	quantum/quantum.c:474: process_record_via(keycode, record) &&
      00A5E2 90 0D 19         [24] 1386 	mov	dptr,#_process_record_via_PARM_2
      00A5E5 12 A6 D4         [24] 1387 	lcall	_ak820_outline_0001
      00A5E8 C0 07            [24] 1388 	push	ar7
      00A5EA C0 06            [24] 1389 	push	ar6
      00A5EC C0 05            [24] 1390 	push	ar5
      00A5EE C0 04            [24] 1391 	push	ar4
      00A5F0 12 AB D3         [24] 1392 	lcall	_process_record_via
      00A5F3 E5 82            [12] 1393 	mov	a, dpl
      00A5F5 D0 04            [24] 1394 	pop	ar4
      00A5F7 D0 05            [24] 1395 	pop	ar5
      00A5F9 D0 06            [24] 1396 	pop	ar6
      00A5FB D0 07            [24] 1397 	pop	ar7
      00A5FD 70 02            [24] 1398 	jnz	00207$
      00A5FF C1 91            [12] 1399 	ajmp	00101$
      00A601                       1400 00207$:
                                   1401 ;	quantum/quantum.c:484: process_record_kb(keycode, record) &&
      00A601 90 0C BC         [24] 1402 	mov	dptr,#_process_record_kb_PARM_2
      00A604 12 A6 D4         [24] 1403 	lcall	_ak820_outline_0001
      00A607 C0 07            [24] 1404 	push	ar7
      00A609 C0 06            [24] 1405 	push	ar6
      00A60B C0 05            [24] 1406 	push	ar5
      00A60D C0 04            [24] 1407 	push	ar4
      00A60F 71 9F            [12] 1408 	acall	_process_record_kb
      00A611 E5 82            [12] 1409 	mov	a, dpl
      00A613 D0 04            [24] 1410 	pop	ar4
      00A615 D0 05            [24] 1411 	pop	ar5
      00A617 D0 06            [24] 1412 	pop	ar6
      00A619 D0 07            [24] 1413 	pop	ar7
      00A61B 70 02            [24] 1414 	jnz	00208$
      00A61D C1 91            [12] 1415 	ajmp	00101$
      00A61F                       1416 00208$:
                                   1417 ;	quantum/quantum.c:507: process_caps_word(keycode, record) &&
      00A61F 90 0C 7F         [24] 1418 	mov	dptr,#_process_caps_word_PARM_2
      00A622 12 A6 D4         [24] 1419 	lcall	_ak820_outline_0001
      00A625 C0 07            [24] 1420 	push	ar7
      00A627 C0 06            [24] 1421 	push	ar6
      00A629 C0 05            [24] 1422 	push	ar5
      00A62B C0 04            [24] 1423 	push	ar4
      00A62D 12 9D AA         [24] 1424 	lcall	_process_caps_word
      00A630 E5 82            [12] 1425 	mov	a, dpl
      00A632 D0 04            [24] 1426 	pop	ar4
      00A634 D0 05            [24] 1427 	pop	ar5
      00A636 D0 06            [24] 1428 	pop	ar6
      00A638 D0 07            [24] 1429 	pop	ar7
      00A63A 60 55            [24] 1430 	jz	00101$
                                   1431 ;	quantum/quantum.c:537: process_grave_esc(keycode, record) &&
      00A63C 90 0C 84         [24] 1432 	mov	dptr,#_process_grave_esc_PARM_2
      00A63F 12 A6 D4         [24] 1433 	lcall	_ak820_outline_0001
      00A642 C0 07            [24] 1434 	push	ar7
      00A644 C0 06            [24] 1435 	push	ar6
      00A646 C0 05            [24] 1436 	push	ar5
      00A648 C0 04            [24] 1437 	push	ar4
      00A64A 12 9E BD         [24] 1438 	lcall	_process_grave_esc
      00A64D E5 82            [12] 1439 	mov	a, dpl
      00A64F D0 04            [24] 1440 	pop	ar4
      00A651 D0 05            [24] 1441 	pop	ar5
      00A653 D0 06            [24] 1442 	pop	ar6
      00A655 D0 07            [24] 1443 	pop	ar7
      00A657 60 38            [24] 1444 	jz	00101$
                                   1445 ;	quantum/quantum.c:540: process_rgb(keycode, record) &&
      00A659 90 0C A2         [24] 1446 	mov	dptr,#_process_rgb_PARM_2
      00A65C 12 A6 D4         [24] 1447 	lcall	_ak820_outline_0001
      00A65F C0 07            [24] 1448 	push	ar7
      00A661 C0 06            [24] 1449 	push	ar6
      00A663 C0 05            [24] 1450 	push	ar5
      00A665 C0 04            [24] 1451 	push	ar4
      00A667 31 03            [12] 1452 	acall	_process_rgb
      00A669 E5 82            [12] 1453 	mov	a, dpl
      00A66B D0 04            [24] 1454 	pop	ar4
      00A66D D0 05            [24] 1455 	pop	ar5
      00A66F D0 06            [24] 1456 	pop	ar6
      00A671 D0 07            [24] 1457 	pop	ar7
      00A673 60 1C            [24] 1458 	jz	00101$
                                   1459 ;	quantum/quantum.c:552: process_tri_layer(keycode, record) &&
      00A675 90 0C A8         [24] 1460 	mov	dptr,#_process_tri_layer_PARM_2
      00A678 12 A6 D4         [24] 1461 	lcall	_ak820_outline_0001
      00A67B C0 07            [24] 1462 	push	ar7
      00A67D C0 06            [24] 1463 	push	ar6
      00A67F C0 05            [24] 1464 	push	ar5
      00A681 C0 04            [24] 1465 	push	ar4
      00A683 31 B4            [12] 1466 	acall	_process_tri_layer
      00A685 E5 82            [12] 1467 	mov	a, dpl
      00A687 D0 04            [24] 1468 	pop	ar4
      00A689 D0 05            [24] 1469 	pop	ar5
      00A68B D0 06            [24] 1470 	pop	ar6
      00A68D D0 07            [24] 1471 	pop	ar7
      00A68F 70 04            [24] 1472 	jnz	00102$
                                   1473 ;	quantum/quantum.c:554: true)) {
      00A691                       1474 00101$:
                                   1475 ;	quantum/quantum.c:555: return false;
      00A691 75 82 00         [24] 1476 	mov	dpl, #0x00
      00A694 22               [24] 1477 	ret
      00A695                       1478 00102$:
                                   1479 ;	quantum/quantum.c:558: if (record->event.pressed) {
      00A695 74 05            [12] 1480 	mov	a,#0x05
      00A697 2E               [12] 1481 	add	a, r6
      00A698 12 48 EC         [24] 1482 	lcall	_ak820_outline_0035
      00A69B 60 2D            [24] 1483 	jz	00117$
                                   1484 ;	quantum/quantum.c:559: switch (keycode) {
      00A69D BC 00 05         [24] 1485 	cjne	r4,#0x00,00214$
      00A6A0 BD 7C 02         [24] 1486 	cjne	r5,#0x7c,00214$
      00A6A3 80 10            [24] 1487 	sjmp	00112$
      00A6A5                       1488 00214$:
      00A6A5 BC 01 05         [24] 1489 	cjne	r4,#0x01,00215$
      00A6A8 BD 7C 02         [24] 1490 	cjne	r5,#0x7c,00215$
      00A6AB 80 0E            [24] 1491 	sjmp	00113$
      00A6AD                       1492 00215$:
                                   1493 ;	quantum/quantum.c:561: case QK_BOOTLOADER:
      00A6AD BC 03 1A         [24] 1494 	cjne	r4,#0x03,00117$
      00A6B0 BD 7C 17         [24] 1495 	cjne	r5,#0x7c,00117$
      00A6B3 80 0C            [24] 1496 	sjmp	00114$
      00A6B5                       1497 00112$:
                                   1498 ;	quantum/quantum.c:562: reset_keyboard();
      00A6B5 71 F2            [24] 1499 	acall	_reset_keyboard
                                   1500 ;	quantum/quantum.c:563: return false;
      00A6B7 75 82 00         [24] 1501 	mov	dpl, #0x00
                                   1502 ;	quantum/quantum.c:564: case QK_REBOOT:
      00A6BA 22               [24] 1503 	ret
      00A6BB                       1504 00113$:
                                   1505 ;	quantum/quantum.c:565: soft_reset_keyboard();
      00A6BB 71 F7            [24] 1506 	acall	_soft_reset_keyboard
                                   1507 ;	quantum/quantum.c:566: return false;
      00A6BD 75 82 00         [24] 1508 	mov	dpl, #0x00
                                   1509 ;	quantum/quantum.c:578: case QK_CLEAR_EEPROM:
      00A6C0 22               [24] 1510 	ret
      00A6C1                       1511 00114$:
                                   1512 ;	quantum/quantum.c:585: eeconfig_disable();
      00A6C1 12 95 39         [24] 1513 	lcall	_eeconfig_disable
                                   1514 ;	quantum/quantum.c:586: soft_reset_keyboard();
      00A6C4 71 F7            [24] 1515 	acall	_soft_reset_keyboard
                                   1516 ;	quantum/quantum.c:588: return false;
      00A6C6 75 82 00         [24] 1517 	mov	dpl, #0x00
                                   1518 ;	quantum/quantum.c:643: }
      00A6C9 22               [24] 1519 	ret
      00A6CA                       1520 00117$:
                                   1521 ;	quantum/quantum.c:646: return process_action_kb(record);
      00A6CA 7D 00            [12] 1522 	mov	r5,#0x00
      00A6CC 12 38 8D         [24] 1523 	lcall	_ak820_outline_0121
      00A6CF 8D F0            [24] 1524 	mov	b, r5
                                   1525 ;	quantum/quantum.c:647: }
      00A6D1 61 9B            [12] 1526 	ajmp	_process_action_kb
                                   1527 ;------------------------------------------------------------
                                   1528 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1529 ;------------------------------------------------------------
                                   1530 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_681'
                                   1531 ;------------------------------------------------------------
                                   1532 ;	quantum/quantum.c:649: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1533 ;	-----------------------------------------
                                   1534 ;	 function shutdown_user
                                   1535 ;	-----------------------------------------
      00A6D3                       1536 _shutdown_user:
      00A6D3 22               [24] 1537 	ret
                                   1538 ;------------------------------------------------------------
                                   1539 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1540 ;------------------------------------------------------------
                                   1541 ;	quantum/quantum.c:665: void suspend_power_down_quantum(void) {
                                   1542 ;	-----------------------------------------
                                   1543 	.area CSEG    (CODE)
                                   1544 	.area CONST   (CODE)
                                   1545 	.area XINIT   (CODE)
                                   1546 	.area CABS    (ABS,CODE)
                                   1547 
                                   1548 ; Experimental exact instruction outlining.
                                   1549 	.globl _ak820_outline_0001
                                   1550 	.globl _ak820_outline_0005
                                   1551 	.globl _ak820_outline_0006
                                   1552 	.globl _ak820_outline_0008
                                   1553 	.globl _ak820_outline_0018
                                   1554 	.globl _ak820_outline_0023
                                   1555 	.globl _ak820_outline_0035
                                   1556 	.globl _ak820_outline_0036
                                   1557 	.globl _ak820_outline_0038
                                   1558 	.globl _ak820_outline_0047
                                   1559 	.globl _ak820_outline_0059
                                   1560 	.globl _ak820_outline_0064
                                   1561 	.globl _ak820_outline_0065
                                   1562 	.globl _ak820_outline_0072
                                   1563 	.globl _ak820_outline_0099
                                   1564 	.globl _ak820_outline_0105
                                   1565 	.globl _ak820_outline_0106
                                   1566 	.globl _ak820_outline_0121
                                   1567 	.globl _ak820_outline_0122
                                   1568 	.globl _ak820_outline_0129
                                   1569 	.globl _ak820_outline_0139
                                   1570 	.globl _ak820_outline_0145
                                   1571 	.globl _ak820_outline_0147
                                   1572 	.globl _ak820_outline_0154
                                   1573 
                                   1574 	.area CSEG (CODE)
                                   1575 ; function ak820_outline_0001
      00A6D4                       1576 _ak820_outline_0001:
      00A6D4 EE               [12] 1577 	mov	a,r6
      00A6D5 F0               [24] 1578 	movx	@dptr,a
      00A6D6 EF               [12] 1579 	mov	a,r7
      00A6D7 A3               [24] 1580 	inc	dptr
      00A6D8 F0               [24] 1581 	movx	@dptr,a
      00A6D9 E4               [12] 1582 	clr	a
      00A6DA A3               [24] 1583 	inc	dptr
      00A6DB F0               [24] 1584 	movx	@dptr,a
      00A6DC 8C 82            [24] 1585 	mov	dpl,r4
      00A6DE 8D 83            [24] 1586 	mov	dph,r5
      00A6E0 22               [24] 1587 	ret
                                   1588 
                                   1589 	.area CSEG (CODE)
                                   1590 ; function ak820_outline_0018
      00A6E1                       1591 _ak820_outline_0018:
      00A6E1 EB               [12] 1592 	mov	a,r3
      00A6E2 F0               [24] 1593 	movx	@dptr,a
      00A6E3 EC               [12] 1594 	mov	a,r4
      00A6E4 A3               [24] 1595 	inc	dptr
      00A6E5 F0               [24] 1596 	movx	@dptr,a
      00A6E6 ED               [12] 1597 	mov	a,r5
      00A6E7 A3               [24] 1598 	inc	dptr
      00A6E8 F0               [24] 1599 	movx	@dptr,a
      00A6E9 8E 82            [24] 1600 	mov	dpl,r6
      00A6EB 8F 83            [24] 1601 	mov	dph,r7
      00A6ED 22               [24] 1602 	ret
