;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_nvm
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _eeprom_driver_erase
	.globl _eeprom_read_byte
	.globl _eeprom_driver_init
	.globl _ak820_macro_init
	.globl _ak820_flash_program_page
	.globl _ak820_flash_program
	.globl _ak820_flash_erase
	.globl _ak820_flash_read
	.globl _ak820_eeprom_update_block_xdata_PARM_3
	.globl _ak820_eeprom_update_block_xdata_PARM_2
	.globl _ak820_eeprom_write_block_xdata_PARM_3
	.globl _ak820_eeprom_write_block_xdata_PARM_2
	.globl _ak820_eeprom_read_block_xdata_PARM_3
	.globl _ak820_eeprom_read_block_xdata_PARM_2
	.globl _ak820_nvm_diagnostic
	.globl _ak820_nvm_ok
	.globl _ak820_nvm_schema_fault
	.globl _ak820_nvm_flush
	.globl _ak820_nvm_begin
	.globl _ak820_nvm_end
	.globl _ak820_eeprom_read_block_xdata
	.globl _ak820_eeprom_write_block_xdata
	.globl _ak820_eeprom_update_block_xdata
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; overlayable bit register bank
;--------------------------------------------------------
	.area BIT_BANK	(REL,OVR,DATA)
bits:
	.ds 1
	b0 = bits[0]
	b1 = bits[1]
	b2 = bits[2]
	b3 = bits[3]
	b4 = bits[4]
	b5 = bits[5]
	b6 = bits[6]
	b7 = bits[7]
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_ak820_eeprom_write_block_xdata_sloc0_1_0:
	.ds 2
_ak820_eeprom_update_block_xdata_sloc0_1_0:
	.ds 2
_ak820_eeprom_update_block_xdata_sloc1_1_0:
	.ds 2
_ak820_eeprom_update_block_xdata_sloc2_1_0:
	.ds 3
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_page_valid:
	.ds 1
_page_dirty:
	.ds 1
_storage_failed:
	.ds 1
_ak820_nvm_ok_sloc0_1_0:
	.ds 1
_load_page_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_page_data:
	.ds 64
_cached_page:
	.ds 1
_batch_depth:
	.ds 1
_first_failure_stage:
	.ds 1
_nvm_fail_stage_10000_20:
	.ds 1
_ak820_nvm_diagnostic_out_10000_23:
	.ds 2
_crc_byte_PARM_2:
	.ds 1
_crc_byte_crc_10000_25:
	.ds 2
_page_crc_crc_10000_30:
	.ds 2
_write_page_address_10000_32:
	.ds 2
_journal_header_valid_header_10000_39:
	.ds 2
_recover_journal_header_10000_46:
	.ds 9
_ak820_nvm_flush_header_10000_62:
	.ds 9
_ak820_nvm_flush_stage_10000_62:
	.ds 1
_load_page_page_10000_87:
	.ds 1
_read_offset_offset_10000_93:
	.ds 2
_eeprom_read_byte_addr_10000_97:
	.ds 3
_ak820_eeprom_read_block_xdata_PARM_2:
	.ds 3
_ak820_eeprom_read_block_xdata_PARM_3:
	.ds 2
_ak820_eeprom_read_block_xdata_buf_10000_113:
	.ds 2
_ak820_eeprom_read_block_xdata_out_10000_114:
	.ds 2
_ak820_eeprom_write_block_xdata_PARM_2:
	.ds 3
_ak820_eeprom_write_block_xdata_PARM_3:
	.ds 2
_ak820_eeprom_write_block_xdata_buf_10000_118:
	.ds 2
_ak820_eeprom_update_block_xdata_PARM_2:
	.ds 3
_ak820_eeprom_update_block_xdata_PARM_3:
	.ds 2
_ak820_eeprom_update_block_xdata_buf_10000_127:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'nvm_fail'
;------------------------------------------------------------
;stage         Allocated with name '_nvm_fail_stage_10000_20'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
;	-----------------------------------------
;	 function nvm_fail
;	-----------------------------------------
_nvm_fail:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	mov	a,dpl
	mov	dptr,#_nvm_fail_stage_10000_20
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
	jb	_storage_failed,00102$
	mov	dptr,#_nvm_fail_stage_10000_20
	movx	a,@dptr
	mov	dptr,#_first_failure_stage
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
;	assignBit
	setb	_storage_failed
;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_diagnostic'
;------------------------------------------------------------
;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
;	-----------------------------------------
;	 function ak820_nvm_diagnostic
;	-----------------------------------------
_ak820_nvm_diagnostic:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
	lcall	_ak820_outline_0059
	mov	c,_storage_failed
	clr	a
	rlc	a
	lcall	_ak820_outline_0121
	lcall	_ak820_outline_0072
;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
	inc	dptr
	mov	c,_page_valid
	clr	a
	rlc	a
	lcall	_ak820_outline_0037
;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
	mov	c,_page_dirty
	clr	a
	rlc	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
	mov	a,#0x03
	lcall	_ak820_outline_0164
	mov	dptr,#_batch_depth
	movx	a,@dptr
	lcall	_ak820_outline_0127
;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
	mov	a,#0x04
	lcall	_ak820_outline_0164
	mov	dptr,#_cached_page
	movx	a,@dptr
	lcall	_ak820_outline_0127
;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
	lcall	_ak820_outline_0011
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
	mov	a,#0x06
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dptr,#_first_failure_stage
	movx	a,@dptr
	lcall	_ak820_outline_0121
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'crc_byte'
;------------------------------------------------------------
;value         Allocated with name '_crc_byte_PARM_2'
;crc           Allocated with name '_crc_byte_crc_10000_25'
;bit           Allocated with name '_crc_byte_bit_10000_26'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
;	-----------------------------------------
;	 function crc_byte
;	-----------------------------------------
_crc_byte:
	lcall	_ak820_outline_0106
	mov	dptr,#_crc_byte_crc_10000_25
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
	mov	dptr,#_crc_byte_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	r6,#0x00
	mov	dptr,#_crc_byte_crc_10000_25
	movx	a,@dptr
	xrl	a,r6
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	xrl	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
	mov	r7,#0x00
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
	mov	dptr,#_crc_byte_crc_10000_25
	lcall	_ak820_outline_0085
	jnb	acc.7,00106$
	mov	a,r5
	add	a,r5
	mov	r3,a
	mov	a,r6
	rlc	a
	mov	r4,a
	xrl	ar3,#0x21
	xrl	ar4,#0x10
	sjmp	00107$
00106$:
	mov	a,r5
	add	a,r5
	mov	r3,a
	mov	a,r6
	rlc	a
	mov	r4,a
00107$:
	mov	dptr,#_crc_byte_crc_10000_25
	lcall	_ak820_outline_0082
;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
	inc	r7
	cjne	r7,#0x08,00102$
;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
	lcall	_ak820_outline_0125
;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'page_crc'
;------------------------------------------------------------
;crc           Allocated with name '_page_crc_crc_10000_30'
;i             Allocated with name '_page_crc_i_10000_30'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
;	-----------------------------------------
;	 function page_crc
;	-----------------------------------------
_page_crc:
;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
	mov	dptr,#_page_crc_crc_10000_30
	mov	a,#0xff
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
	mov	r7,#0x00
00102$:
	mov	dptr,#_page_crc_crc_10000_30
	lcall	_ak820_outline_0085
	lcall	_ak820_outline_0108
	mov	dptr,#_crc_byte_PARM_2
	movx	@dptr,a
	lcall	_ak820_outline_0140
	push	ar7
	lcall	_crc_byte
	mov	r5, dpl
	mov	r6, dph
	pop	ar7
	mov	dptr,#_page_crc_crc_10000_30
	lcall	_ak820_outline_0165
	inc	r7
	cjne	r7,#0x40,00102$
;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
	lcall	_ak820_outline_0140
;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'write_page'
;------------------------------------------------------------
;address       Allocated with name '_write_page_address_10000_32'
;i             Allocated with name '_write_page_i_10000_33'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
;	-----------------------------------------
;	 function write_page
;	-----------------------------------------
_write_page:
	lcall	_ak820_outline_0106
	mov	dptr,#_write_page_address_10000_32
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
	mov	dptr,#_write_page_address_10000_32
	lcall	_ak820_outline_0005
	push	ar7
	push	ar6
	lcall	_ak820_flash_erase
	mov	a, dpl
	pop	ar6
	pop	ar7
	jnz	00102$
	mov	dpl,a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
	mov	dptr,#_ak820_flash_program_page_PARM_2
	mov	a,#_page_data
	movx	@dptr,a
	mov	a,#(_page_data >> 8)
	lcall	_ak820_outline_0064
	lcall	_ak820_flash_program_page
	mov	a, dpl
	jnz	00120$
	mov	dpl,a
;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	ret
00120$:
	mov	r7,#0x00
00108$:
;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
	mov	ar5,r7
	mov	r6,#0x00
	mov	dptr,#_write_page_address_10000_32
	lcall	_ak820_outline_0099
	mov	a,r5
	add	a, r3
	mov	r3,a
	mov	a,r6
	addc	a, r4
	mov	r4,a
	lcall	_ak820_outline_0125
	lcall	_ak820_flash_read
	mov	r6, dpl
	lcall	_ak820_outline_0108
	mov	r5,a
	mov	a,r6
	cjne	a,ar5,00149$
	sjmp	00109$
00149$:
	mov	dpl, #0x00
	ret
00109$:
;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	inc	r7
	cjne	r7,#0x40,00108$
;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'journal_header_valid'
;------------------------------------------------------------
;header        Allocated with name '_journal_header_valid_header_10000_39'
;i             Allocated with name '_journal_header_valid_i_10000_40'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
;	-----------------------------------------
;	 function journal_header_valid
;	-----------------------------------------
_journal_header_valid:
	lcall	_ak820_outline_0106
	mov	dptr,#_journal_header_valid_header_10000_39
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
	mov	dptr,#_journal_header_valid_header_10000_39
	lcall	_ak820_outline_0005
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0xa5,00138$
	sjmp	00116$
00138$:
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
	ret
00116$:
	mov	r5,#0x01
00106$:
;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
	mov	a,r5
	lcall	_ak820_outline_0020
	mov	r4,a
	mov	ar2,r5
	mov	r3,#0x00
	mov	a,#0x04
	add	a, r2
	mov	r2,a
	clr	a
	addc	a, r3
	mov	r3,a
	mov	a,r2
	add	a, r6
	mov	dpl,a
	mov	a,r3
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	xrl	ar4,a
	cjne	r4,#0xff,00139$
	sjmp	00107$
00139$:
	mov	dpl, #0x00
	ret
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
	inc	r5
	cjne	r5,#0x05,00106$
;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'recover_journal'
;------------------------------------------------------------
;header        Allocated with name '_recover_journal_header_10000_46'
;i             Allocated with name '_recover_journal_i_10000_46'
;page          Allocated with name '_recover_journal_page_10000_46'
;crc           Allocated with name '_recover_journal_crc_10000_46'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
;	-----------------------------------------
;	 function recover_journal
;	-----------------------------------------
_recover_journal:
;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
	mov	r7,#0x00
00115$:
	mov	a,r7
	add	a, #_recover_journal_header_10000_46
	mov	r5,a
	clr	a
	addc	a, #(_recover_journal_header_10000_46 >> 8)
	mov	r6,a
	mov	ar4,r7
	mov	r3,#0x00
	mov	a,#0x40
	add	a, r4
	mov	r4,a
	mov	a,#0xef
	addc	a, r3
	mov	r3,a
	lcall	_ak820_outline_0187
	lcall	_ak820_flash_read
	mov	r4, dpl
	lcall	_ak820_outline_0070
	inc	r7
	cjne	r7,#0x09,00115$
;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
	mov	dptr,#_recover_journal_header_10000_46
	lcall	_journal_header_valid
	mov	a, dpl
	jnz	00103$
	ret
00103$:
;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
	movx	a,@dptr
	mov	r7,a
	mov	r6,#0x00
	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
	movx	a,@dptr
	mov	r4,a
	clr	a
	orl	ar7,a
	mov	a,r4
	orl	ar6,a
;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
	movx	a,@dptr
	mov	r5,a
	mov	r4,#0x00
	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
	movx	a,@dptr
	mov	r2,a
	clr	a
	lcall	_ak820_outline_0145
;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
	clr	c
	mov	a,r7
	subb	a,#0xa0
	mov	a,r6
	subb	a,#0x00
	jc	00134$
;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
	ljmp	_nvm_fail
;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
00134$:
	mov	r3,#0x00
00117$:
	push	ar5
	push	ar4
	mov	a,r3
	add	a, #_page_data
	mov	r1,a
	clr	a
	addc	a, #(_page_data >> 8)
	mov	r2,a
	mov	ar0,r3
	mov	r5,#0x00
	mov	a,#0xef
	add	a, r5
	mov	r5,a
	mov	dpl, r0
	mov	dph, r5
	lcall	_ak820_flash_read
	mov	r5, dpl
	lcall	_ak820_outline_0174
	mov	a,r5
	movx	@dptr,a
	inc	r3
	cjne	r3,#0x40,00190$
	sjmp	00191$
00190$:
	pop	ar4
	pop	ar5
	sjmp	00117$
00191$:
	pop	ar4
	pop	ar5
;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_page_crc
	mov	r2, dpl
	mov	r3, dph
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	mov	a,r2
	cjne	a,ar5,00192$
	mov	a,r3
	cjne	a,ar4,00192$
	sjmp	00113$
00192$:
	mov	dpl, #0x02
	ljmp	_nvm_fail
00113$:
;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
	mov	a,r6
	anl	a,#0x03
	mov	c,acc.0
	xch	a,r7
	rrc	a
	xch	a,r7
	rrc	a
	mov	c,acc.0
	xch	a,r7
	rrc	a
	xch	a,r7
	rrc	a
	xch	a,r7
	add	a,#0xc7
	mov	r6,a
	lcall	_ak820_outline_0160
	lcall	_write_page
	mov	a, dpl
	jnz	00110$
	mov	dpl, #0x03
	ljmp	_nvm_fail
00110$:
;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
	mov	dptr,#0xef40
	lcall	_ak820_flash_erase
	mov	a, dpl
	jnz	00119$
	mov	dpl, #0x04
;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
	ljmp	_nvm_fail
00119$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_driver_init'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
;	-----------------------------------------
;	 function eeprom_driver_init
;	-----------------------------------------
_eeprom_driver_init:
;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
;	assignBit
	clr	_storage_failed
;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
	mov	dptr,#_first_failure_stage
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
;	assignBit
	clr	_page_dirty
;	assignBit
	clr	_page_valid
;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
	mov	dptr,#_batch_depth
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
	lcall	_recover_journal
;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
	ljmp	_ak820_macro_init
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_ok'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
;	-----------------------------------------
;	 function ak820_nvm_ok
;	-----------------------------------------
_ak820_nvm_ok:
	mov	c,_storage_failed
	cpl	c
	mov  _ak820_nvm_ok_sloc0_1_0,c
	lcall	_ak820_outline_0147
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_schema_fault'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
;	-----------------------------------------
;	 function ak820_nvm_schema_fault
;	-----------------------------------------
_ak820_nvm_schema_fault:
	mov	dpl, #0x10
	ljmp	_nvm_fail
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_flush'
;------------------------------------------------------------
;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
;	-----------------------------------------
;	 function ak820_nvm_flush
;	-----------------------------------------
_ak820_nvm_flush:
;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
	jnb	_page_dirty,00101$
	jnb	_storage_failed,00102$
00101$:
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
	lcall	_page_crc
	lcall	_ak820_outline_0139
;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
	mov	dptr,#_ak820_nvm_flush_header_10000_62
	mov	a,#0xa5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
	mov	dptr,#_cached_page
	movx	a,@dptr
	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
	mov	ar5,r6
	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
	mov	ar6,r7
	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
	mov	r7,#0x01
00128$:
	mov	ar6,r7
	mov	a,r6
	add	a,#0x04
	mov	r6,a
	rlc	a
	subb	a,acc
	mov	r5,a
	mov	a,r6
	add	a, #_ak820_nvm_flush_header_10000_62
	mov	r6,a
	mov	a,r5
	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
	mov	r5,a
	lcall	_ak820_outline_0048
	mov	r4,a
	xrl	ar4,#0xff
	mov	dpl,r6
	mov	dph,r5
	mov	a,r4
	movx	@dptr,a
	inc	r7
	cjne	r7,#0x05,00128$
;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x05
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
	mov	dptr,#0xef40
	lcall	_ak820_flash_erase
	mov	a, dpl
	jnz	00269$
	ljmp	00127$
00269$:
;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x06
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	mov	r7,#0x00
00130$:
;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
	lcall	_ak820_outline_0060
	lcall	_ak820_flash_read
	mov	a, dpl
	jz	00270$
	ljmp	00127$
00270$:
;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	inc	r7
	cjne	r7,#0x40,00130$
;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x07
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
	mov	dptr,#0xef00
	lcall	_write_page
	mov	a, dpl
	jnz	00273$
	ljmp	00127$
00273$:
;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x08
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
	mov	r7,#0x01
00132$:
;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
	lcall	_ak820_outline_0048
	mov	r6,a
	jz	00133$
	mov	ar5,r7
	mov	r4,#0x00
	mov	a,#0x40
	add	a, r5
	mov	r5,a
	mov	a,#0xef
	addc	a, r4
	mov	r4,a
	mov	dptr,#_ak820_flash_program_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r4
	push	ar7
	lcall	_ak820_flash_program
	mov	a, dpl
	pop	ar7
	jnz	00275$
	ljmp	00127$
00275$:
00133$:
;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
	inc	r7
	cjne	r7,#0x09,00132$
;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x09
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
	mov	r7,#0x01
00134$:
;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
	lcall	_ak820_outline_0060
	lcall	_ak820_flash_read
	mov	r6, dpl
	lcall	_ak820_outline_0048
	mov	r5,a
	mov	a,r6
	cjne	a,ar5,00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
	inc	r7
	cjne	r7,#0x09,00134$
;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x0a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
	mov	dptr,#_ak820_nvm_flush_header_10000_62
	movx	a,@dptr
	mov	dptr,#_ak820_flash_program_PARM_2
	movx	@dptr,a
	mov	dptr,#0xef40
	lcall	_ak820_flash_program
	mov	a, dpl
	jz	00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x0b
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
	mov	dptr,#0xef40
	lcall	_ak820_flash_read
	mov	r7, dpl
	mov	dptr,#_ak820_nvm_flush_header_10000_62
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x0c
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
	mov	dptr,#_cached_page
	movx	a,@dptr
	mov	r6,a
	clr	a
	clr	c
	xch	a,r6
	rrc	a
	xch	a,r6
	rrc	a
	mov	c,acc.0
	xch	a,r6
	rrc	a
	xch	a,r6
	rrc	a
	xch	a,r6
	add	a,#0xc7
	mov	r7,a
	lcall	_ak820_outline_0121
	lcall	_write_page
	mov	a, dpl
	jz	00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x0d
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
	mov	dptr,#0xef40
	lcall	_ak820_flash_erase
	mov	a, dpl
	jz	00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
;	assignBit
	clr	_page_dirty
;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
	ret
00127$:
;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	movx	a,@dptr
	mov	dpl,a
;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
	ljmp	_nvm_fail
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_begin'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
;	-----------------------------------------
;	 function ak820_nvm_begin
;	-----------------------------------------
_ak820_nvm_begin:
;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
	mov	dptr,#_batch_depth
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00102$
	mov	dpl, #0x0f
	ljmp	_nvm_fail
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
	mov	dptr,#_batch_depth
	mov	a,r7
	inc	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_end'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
;	-----------------------------------------
;	 function ak820_nvm_end
;	-----------------------------------------
_ak820_nvm_end:
;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
	mov	dptr,#_batch_depth
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jz	00102$
	mov	a,r7
	dec	a
	mov	dptr,#_batch_depth
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
	mov	dptr,#_batch_depth
	movx	a,@dptr
	jnz	00105$
;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
	ljmp	_ak820_nvm_flush
00105$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'load_page'
;------------------------------------------------------------
;page          Allocated with name '_load_page_page_10000_87'
;i             Allocated with name '_load_page_i_10000_88'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
;	-----------------------------------------
;	 function load_page
;	-----------------------------------------
_load_page:
	mov	a,dpl
	mov	dptr,#_load_page_page_10000_87
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
	jnb	_page_valid,00102$
	mov	dptr,#_cached_page
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_load_page_page_10000_87
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00102$
	mov	c,_storage_failed
	cpl	c
	mov  _load_page_sloc0_1_0,c
	lcall	_ak820_outline_0147
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
	lcall	_ak820_nvm_flush
;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
	jnb	_storage_failed,00119$
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	ret
00119$:
	mov	r7,#0x00
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
	mov	a,r7
	add	a, #_page_data
	mov	r5,a
	clr	a
	addc	a, #(_page_data >> 8)
	mov	r6,a
	mov	dptr,#_load_page_page_10000_87
	movx	a,@dptr
	mov	r4,a
	mov	r2,a
	clr	a
	clr	c
	xch	a,r2
	rrc	a
	xch	a,r2
	rrc	a
	mov	c,acc.0
	xch	a,r2
	rrc	a
	xch	a,r2
	rrc	a
	xch	a,r2
	add	a,#0xc7
	mov	r3,a
	mov	ar1,r7
	mov	ar0,r1
	mov	r1,#0x00
	mov	a,r0
	add	a, r2
	mov	r2,a
	mov	a,r1
	addc	a, r3
	mov	r3,a
	lcall	_ak820_outline_0131
	lcall	_ak820_flash_read
	mov	r3, dpl
	lcall	_ak820_outline_0140
	mov	a,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	inc	r7
	cjne	r7,#0x40,00107$
;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
	mov	dptr,#_cached_page
	mov	a,r4
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
;	assignBit
	setb	_page_valid
;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'read_offset'
;------------------------------------------------------------
;offset        Allocated with name '_read_offset_offset_10000_93'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
;	-----------------------------------------
;	 function read_offset
;	-----------------------------------------
_read_offset:
	lcall	_ak820_outline_0106
	mov	dptr,#_read_offset_offset_10000_93
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
	mov	dptr,#_read_offset_offset_10000_93
	lcall	_ak820_outline_0059
	clr	c
	subb	a,#0x28
	jc	00102$
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
	jnb	_page_valid,00104$
	mov	ar4,r6
	mov	a,r7
	mov	c,acc.7
	xch	a,r4
	rlc	a
	xch	a,r4
	rlc	a
	mov	c,acc.7
	xch	a,r4
	rlc	a
	xch	a,r4
	rlc	a
	xch	a,r4
	anl	a,#0x03
	mov	r5,a
	mov	dptr,#_cached_page
	movx	a,@dptr
	mov	r2,a
	mov	r3,#0x00
	mov	a,r4
	cjne	a,ar2,00104$
	mov	a,r5
	cjne	a,ar3,00104$
;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
	mov	a,#0x3f
	anl	a,r6
	mov	r5,#0x00
	add	a, #_page_data
	mov	dpl,a
	mov	a,r5
	addc	a, #(_page_data >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	dpl,a
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
	mov	a,#0xc7
	add	a, r7
	mov	r7,a
	lcall	_ak820_outline_0121
;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
	ljmp	_ak820_flash_read
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_read_byte'
;------------------------------------------------------------
;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
;	-----------------------------------------
;	 function eeprom_read_byte
;	-----------------------------------------
_eeprom_read_byte:
	push	ar7
	push	ar6
	lcall	_ak820_outline_0042
	mov	dptr,#_eeprom_read_byte_addr_10000_97
	lcall	_ak820_outline_0019
;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
	mov	dptr,#_eeprom_read_byte_addr_10000_97
	lcall	_ak820_outline_0005
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_read_offset
	mov	r7, dpl
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	mov	dpl, r7
;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
	pop	ar6
	pop	ar7
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_read_block'
;------------------------------------------------------------
;addr          Allocated with name '_eeprom_read_block_PARM_2'
;len           Allocated with name '_eeprom_read_block_PARM_3'
;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
;out           Allocated with name '_eeprom_read_block_out_10000_100'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
;	-----------------------------------------
;	 function ak820_eeprom_read_block_xdata
;	-----------------------------------------
_ak820_eeprom_read_block_xdata:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
	lcall	_ak820_outline_0059
;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
	lcall	_ak820_outline_0065
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	lcall	_ak820_outline_0079
;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
	lcall	_ak820_outline_0065
00103$:
	mov	ar2,r4
	mov	ar3,r5
	dec	r4
	cjne	r4,#0xff,00130$
	dec	r5
00130$:
	mov	a,r2
	orl	a,r3
	jz	00106$
;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
	mov	ar2,r6
	mov	ar3,r7
	mov	a,#0x100 - 0x28
	add	a,r3
	jnc	00102$
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	lcall	_ak820_outline_0084
	lcall	_ak820_outline_0131
	clr	a
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	inc	a
	add	a, r2
	movx	@dptr,a
	clr	a
	addc	a, r3
	inc	dptr
	movx	@dptr,a
	sjmp	00103$
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	lcall	_ak820_outline_0084
	lcall	_ak820_outline_0121
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_read_offset
	mov	r1, dpl
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	lcall	_ak820_outline_0131
	mov	a,r1
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	mov	a,#0x01
	add	a, r2
	movx	@dptr,a
	clr	a
	addc	a, r3
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
	inc	r6
	cjne	r6,#0x00,00103$
	inc	r7
	sjmp	00103$
00106$:
;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
;	-----------------------------------------
;	 function ak820_eeprom_write_block_xdata
;	-----------------------------------------
_ak820_eeprom_write_block_xdata:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
	lcall	_ak820_outline_0059
;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
	lcall	_ak820_outline_0065
;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
	mov	ar2,r6
	mov	ar3,r7
	clr	c
	clr	a
	subb	a,r2
	mov	a,#0x28
	subb	a,r3
	jc	00101$
;	free result
	clr	a
	clr	c
	subb	a,r6
	mov	r2,a
	mov	a,#0x28
	subb	a,r7
	mov	r3,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	lcall	_ak820_outline_0098
	clr	c
	mov	a,r2
	subb	a,r0
	mov	a,r3
	subb	a,r1
	jnc	00125$
;	free result
00101$:
;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
	mov	dpl, #0x0e
;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
	ljmp	_nvm_fail
;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
00125$:
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	lcall	_ak820_outline_0084
00108$:
	mov	ar0,r2
	mov	ar1,r3
	dec	r2
	cjne	r2,#0xff,00159$
	dec	r3
00159$:
	mov	a,r0
	orl	a,r1
	jnz	00160$
	ljmp	00110$
00160$:
;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
	push	ar2
	push	ar3
	lcall	_ak820_outline_0083
	mov	r1,a
	inc	dptr
	lcall	_ak820_outline_0154
;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
	mov	c,acc.7
	xch	a,r0
	rlc	a
	xch	a,r0
	rlc	a
	mov	c,acc.7
	xch	a,r0
	rlc	a
	xch	a,r0
	rlc	a
	xch	a,r0
	anl	a,#0x03
	mov	r3,a
	mov	dpl, r0
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	lcall	_load_page
	mov	a, dpl
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	pop	ar3
	pop	ar2
	jnz	00105$
	ret
00105$:
;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
	push	ar6
	push	ar7
	mov	a,#0x3f
	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
	mov	r7,#0x00
	add	a, #_page_data
	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
	mov	a,r7
	addc	a, #(_page_data >> 8)
	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
	movx	a,@dptr
	cjne	a,ar1,00162$
	pop	ar7
	pop	ar6
	sjmp	00107$
00162$:
	pop	ar7
	pop	ar6
;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
	mov	a,r1
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
;	assignBit
	setb	_page_dirty
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
	inc	r6
	cjne	r6,#0x00,00163$
	inc	r7
00163$:
	ljmp	00108$
00110$:
;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
	mov	dptr,#_batch_depth
	movx	a,@dptr
	jnz	00113$
;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
	ljmp	_ak820_nvm_flush
00113$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
;	-----------------------------------------
;	 function ak820_eeprom_update_block_xdata
;	-----------------------------------------
_ak820_eeprom_update_block_xdata:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
	lcall	_ak820_outline_0059
;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
	movx	a,@dptr
	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
	clr	a
	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
00105$:
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
	movx	a,@dptr
	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
	clr	c
	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
	jnc	00107$
;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
	mov	ar0,r1
	mov	ar5,r2
	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
	add	a, r0
	mov	r0,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
	addc	a, r5
	mov	r5,a
	mov	dpl, r0
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar2
	push	ar1
	lcall	_read_offset
	mov	r5, dpl
	pop	ar1
	pop	ar2
	pop	ar6
	pop	ar7
	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
	add	a, r6
	mov	dpl,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	mov	a,r5
	cjne	a,ar4,00131$
	sjmp	00106$
00131$:
;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
	movx	@dptr,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
	movx	@dptr,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	dpl, r0
	mov	dph, r5
;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
	ljmp	_ak820_eeprom_write_block_xdata
00106$:
;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
	clr	a
	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
	sjmp	00105$
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_driver_erase'
;------------------------------------------------------------
;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
;	-----------------------------------------
;	 function eeprom_driver_erase
;	-----------------------------------------
_eeprom_driver_erase:
;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
	lcall	_ak820_nvm_flush
;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
	mov	r7,#0x00
00111$:
	cjne	r7,#0xa0,00165$
	ret
00165$:
	jb	_storage_failed,00113$
;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
	mov	dpl, r7
	push	ar7
	lcall	_load_page
	mov	a, dpl
	pop	ar7
	jnz	00126$
;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	ret
00126$:
	mov	r6,#0x00
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
	mov	a,r6
	add	a, #_page_data
	mov	r4,a
	clr	a
	addc	a, #(_page_data >> 8)
	mov	r5,a
	lcall	_ak820_outline_0083
	jz	00108$
	lcall	_ak820_outline_0129
	clr	a
	movx	@dptr,a
;	assignBit
	setb	_page_dirty
00108$:
;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	inc	r6
	cjne	r6,#0x40,00107$
;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
	push	ar7
	lcall	_ak820_nvm_flush
	pop	ar7
;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
	inc	r7
	sjmp	00111$
00113$:
;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0005
	.globl _ak820_outline_0011
	.globl _ak820_outline_0019
	.globl _ak820_outline_0020
	.globl _ak820_outline_0037
	.globl _ak820_outline_0042
	.globl _ak820_outline_0048
	.globl _ak820_outline_0059
	.globl _ak820_outline_0060
	.globl _ak820_outline_0064
	.globl _ak820_outline_0065
	.globl _ak820_outline_0070
	.globl _ak820_outline_0072
	.globl _ak820_outline_0079
	.globl _ak820_outline_0082
	.globl _ak820_outline_0083
	.globl _ak820_outline_0084
	.globl _ak820_outline_0085
	.globl _ak820_outline_0098
	.globl _ak820_outline_0099
	.globl _ak820_outline_0105
	.globl _ak820_outline_0106
	.globl _ak820_outline_0108
	.globl _ak820_outline_0121
	.globl _ak820_outline_0125
	.globl _ak820_outline_0127
	.globl _ak820_outline_0129
	.globl _ak820_outline_0131
	.globl _ak820_outline_0139
	.globl _ak820_outline_0140
	.globl _ak820_outline_0145
	.globl _ak820_outline_0147
	.globl _ak820_outline_0154
	.globl _ak820_outline_0160
	.globl _ak820_outline_0164
	.globl _ak820_outline_0165
	.globl _ak820_outline_0174
	.globl _ak820_outline_0187

	.area CSEG (CODE)
; function ak820_outline_0011
_ak820_outline_0011:
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0037
_ak820_outline_0037:
	movx	@dptr,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0042
_ak820_outline_0042:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	ret

	.area CSEG (CODE)
; function ak820_outline_0048
_ak820_outline_0048:
	mov	a,r7
	add	a,#_ak820_nvm_flush_header_10000_62
	mov	dpl,a
	clr	a
	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
	mov	dph,a
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0060
_ak820_outline_0060:
	mov	ar6,r7
	mov	r5,#0x00
	mov	a,#0x40
	add	a,r6
	mov	r6,a
	mov	a,#0xef
	addc	a,r5
	mov	r5,a
	mov	dpl,r6
	mov	dph,r5
	ret

	.area CSEG (CODE)
; function ak820_outline_0064
_ak820_outline_0064:
	inc	dptr
	movx	@dptr,a
	mov	dpl,r6
	mov	dph,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0070
_ak820_outline_0070:
	mov	dpl,r5
	mov	dph,r6
	mov	a,r4
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0072
_ak820_outline_0072:
	movx	@dptr,a
	mov	dpl,r6
	mov	dph,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0083
_ak820_outline_0083:
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0084
_ak820_outline_0084:
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0108
_ak820_outline_0108:
	mov	a,r7
	add	a,#_page_data
	mov	dpl,a
	clr	a
	addc	a,#(_page_data>>8)
	mov	dph,a
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0127
_ak820_outline_0127:
	mov	dpl,r4
	mov	dph,r5
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0139
_ak820_outline_0139:
	mov	r6,dpl
	mov	r7,dph
	ret

	.area CSEG (CODE)
; function ak820_outline_0145
_ak820_outline_0145:
	orl	ar5,a
	mov	a,r2
	orl	ar4,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0154
_ak820_outline_0154:
	mov	r4,dpl
	mov	r5,dph
	ret

	.area CSEG (CODE)
; function ak820_outline_0160
_ak820_outline_0160:
	mov	dpl,r7
	mov	dph,r6
	ret

	.area CSEG (CODE)
; function ak820_outline_0164
_ak820_outline_0164:
	add	a,r6
	mov	r4,a
	clr	a
	addc	a,r7
	mov	r5,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0165
_ak820_outline_0165:
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0174
_ak820_outline_0174:
	mov	dpl,r1
	mov	dph,r2
	ret

	.area CSEG (CODE)
; function ak820_outline_0187
_ak820_outline_0187:
	mov	dpl,r4
	mov	dph,r3
	ret
