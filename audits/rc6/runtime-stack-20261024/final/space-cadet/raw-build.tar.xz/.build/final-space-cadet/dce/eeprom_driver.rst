                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000676                         85 _eeprom_read_word_addr_10000_91:
      000676                         86 	.ds 3
      000679                         87 _eeprom_read_word_ret_10000_92:
      000679                         88 	.ds 2
      00067B                         89 _eeprom_read_dword_addr_10000_93:
      00067B                         90 	.ds 3
      00067E                         91 _eeprom_read_dword_ret_10000_94:
      00067E                         92 	.ds 4
      000682                         93 _eeprom_write_byte_PARM_2:
      000682                         94 	.ds 1
      000683                         95 _eeprom_write_byte_addr_10000_95:
      000683                         96 	.ds 3
      000686                         97 _eeprom_write_word_PARM_2:
      000686                         98 	.ds 2
      000688                         99 _eeprom_write_word_addr_10000_97:
      000688                        100 	.ds 3
      00068B                        101 _eeprom_write_dword_PARM_2:
      00068B                        102 	.ds 4
      00068F                        103 _eeprom_write_dword_addr_10000_99:
      00068F                        104 	.ds 3
      000692                        105 _eeprom_update_byte_PARM_2:
      000692                        106 	.ds 1
      000693                        107 _eeprom_update_byte_addr_10000_107:
      000693                        108 	.ds 3
      000696                        109 _eeprom_update_word_PARM_2:
      000696                        110 	.ds 2
      000698                        111 _eeprom_update_word_addr_10000_111:
      000698                        112 	.ds 3
      00069B                        113 _eeprom_update_dword_PARM_2:
      00069B                        114 	.ds 4
      00069F                        115 _eeprom_update_dword_addr_10000_115:
      00069F                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004BDE                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004BDE 12 43 0E         [24]  170 	lcall	_ak820_outline_0035
      004BE1 90 06 76         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004BE4 12 38 20         [24]  172 	lcall	_ak820_outline_0015
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004BE7 90 06 79         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004BEA 12 4D E7         [24]  175 	lcall	_ak820_outline_0166
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004BED 90 06 76         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004BF0 12 4D 9B         [24]  178 	lcall	_ak820_outline_0012
      004BF3 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004BF6 ED               [12]  180 	mov	a,r5
      004BF7 12 38 20         [24]  181 	lcall	_ak820_outline_0015
      004BFA 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004BFD 74 02            [12]  183 	mov	a,#0x02
      004BFF 12 38 97         [24]  184 	lcall	_ak820_outline_0122
      004C02 90 06 79         [24]  185 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004C05 12 40 AA         [24]  186 	lcall	_ak820_eeprom_read_block_xdata
                                    187 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004C08 90 06 79         [24]  188 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004C0B 12 4D D7         [24]  189 	lcall	_ak820_outline_0089
                                    190 ;	drivers/eeprom/eeprom_driver.c:48: }
      004C0E 22               [24]  191 	ret
                                    192 ;------------------------------------------------------------
                                    193 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    194 ;------------------------------------------------------------
                                    195 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    196 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    197 ;------------------------------------------------------------
                                    198 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    199 ;	-----------------------------------------
                                    200 ;	 function eeprom_read_dword
                                    201 ;	-----------------------------------------
      004C0F                        202 _eeprom_read_dword:
      004C0F 12 43 0E         [24]  203 	lcall	_ak820_outline_0035
      004C12 90 06 7B         [24]  204 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004C15 12 38 20         [24]  205 	lcall	_ak820_outline_0015
                                    206 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004C18 90 06 7E         [24]  207 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004C1B 12 4D AC         [24]  208 	lcall	_ak820_outline_0051
                                    209 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004C1E 90 06 7B         [24]  210 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004C21 12 4D 9B         [24]  211 	lcall	_ak820_outline_0012
      004C24 90 05 85         [24]  212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004C27 ED               [12]  213 	mov	a,r5
      004C28 12 38 20         [24]  214 	lcall	_ak820_outline_0015
      004C2B 90 05 88         [24]  215 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004C2E 74 04            [12]  216 	mov	a,#0x04
      004C30 12 38 97         [24]  217 	lcall	_ak820_outline_0122
      004C33 90 06 7E         [24]  218 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004C36 12 40 AA         [24]  219 	lcall	_ak820_eeprom_read_block_xdata
                                    220 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004C39 90 06 7E         [24]  221 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004C3C 12 4D B5         [24]  222 	lcall	_ak820_outline_0055
                                    223 ;	drivers/eeprom/eeprom_driver.c:54: }
      004C3F 22               [24]  224 	ret
                                    225 ;------------------------------------------------------------
                                    226 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    227 ;------------------------------------------------------------
                                    228 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    229 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    230 ;------------------------------------------------------------
                                    231 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    232 ;	-----------------------------------------
                                    233 ;	 function eeprom_write_byte
                                    234 ;	-----------------------------------------
      004C40                        235 _eeprom_write_byte:
      004C40 12 43 0E         [24]  236 	lcall	_ak820_outline_0035
      004C43 90 06 83         [24]  237 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004C46 12 38 20         [24]  238 	lcall	_ak820_outline_0015
                                    239 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004C49 90 06 83         [24]  240 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004C4C 12 4D 84         [24]  241 	lcall	_ak820_outline_0004
      004C4F 74 01            [12]  242 	mov	a,#0x01
      004C51 12 38 97         [24]  243 	lcall	_ak820_outline_0122
      004C54 90 06 82         [24]  244 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    245 ;	drivers/eeprom/eeprom_driver.c:58: }
      004C57 02 41 36         [24]  246 	ljmp	_ak820_eeprom_write_block_xdata
                                    247 ;------------------------------------------------------------
                                    248 ;Allocation info for local variables in function 'eeprom_write_word'
                                    249 ;------------------------------------------------------------
                                    250 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    251 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    252 ;------------------------------------------------------------
                                    253 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    254 ;	-----------------------------------------
                                    255 ;	 function eeprom_write_word
                                    256 ;	-----------------------------------------
      004C5A                        257 _eeprom_write_word:
      004C5A 12 43 0E         [24]  258 	lcall	_ak820_outline_0035
      004C5D 90 06 88         [24]  259 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004C60 12 38 20         [24]  260 	lcall	_ak820_outline_0015
                                    261 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004C63 90 06 88         [24]  262 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004C66 12 4D 84         [24]  263 	lcall	_ak820_outline_0004
      004C69 74 02            [12]  264 	mov	a,#0x02
      004C6B 12 38 97         [24]  265 	lcall	_ak820_outline_0122
      004C6E 90 06 86         [24]  266 	mov	dptr,#_eeprom_write_word_PARM_2
                                    267 ;	drivers/eeprom/eeprom_driver.c:62: }
      004C71 02 41 36         [24]  268 	ljmp	_ak820_eeprom_write_block_xdata
                                    269 ;------------------------------------------------------------
                                    270 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    271 ;------------------------------------------------------------
                                    272 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    273 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    274 ;------------------------------------------------------------
                                    275 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    276 ;	-----------------------------------------
                                    277 ;	 function eeprom_write_dword
                                    278 ;	-----------------------------------------
      004C74                        279 _eeprom_write_dword:
      004C74 12 43 0E         [24]  280 	lcall	_ak820_outline_0035
      004C77 90 06 8F         [24]  281 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004C7A 12 38 20         [24]  282 	lcall	_ak820_outline_0015
                                    283 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004C7D 90 06 8F         [24]  284 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004C80 12 4D 84         [24]  285 	lcall	_ak820_outline_0004
      004C83 74 04            [12]  286 	mov	a,#0x04
      004C85 12 38 97         [24]  287 	lcall	_ak820_outline_0122
      004C88 90 06 8B         [24]  288 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    289 ;	drivers/eeprom/eeprom_driver.c:66: }
      004C8B 02 41 36         [24]  290 	ljmp	_ak820_eeprom_write_block_xdata
                                    291 ;------------------------------------------------------------
                                    292 ;Allocation info for local variables in function 'eeprom_update_block'
                                    293 ;------------------------------------------------------------
                                    294 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    295 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    296 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    297 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    298 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    299 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    300 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    301 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    302 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    303 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    304 ;------------------------------------------------------------
                                    305 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    306 ;	-----------------------------------------
                                    307 ;	 function eeprom_update_byte
                                    308 ;	-----------------------------------------
      004C8E                        309 _eeprom_update_byte:
      004C8E C0 07            [24]  310 	push	ar7
      004C90 C0 06            [24]  311 	push	ar6
      004C92 C0 05            [24]  312 	push	ar5
      004C94 C0 04            [24]  313 	push	ar4
      004C96 12 43 0E         [24]  314 	lcall	_ak820_outline_0035
      004C99 90 06 93         [24]  315 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004C9C 12 38 20         [24]  316 	lcall	_ak820_outline_0015
                                    317 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004C9F 90 06 93         [24]  318 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004CA2 12 4D 75         [24]  319 	lcall	_ak820_outline_0001
      004CA5 12 40 6F         [24]  320 	lcall	_eeprom_read_byte
      004CA8 AF 82            [24]  321 	mov	r7, dpl
                                    322 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004CAA 90 06 92         [24]  323 	mov	dptr,#_eeprom_update_byte_PARM_2
      004CAD E0               [24]  324 	movx	a,@dptr
      004CAE FE               [12]  325 	mov	r6,a
      004CAF EF               [12]  326 	mov	a,r7
      004CB0 B5 06 02         [24]  327 	cjne	a,ar6,00112$
      004CB3 80 36            [24]  328 	sjmp	00103$
      004CB5                        329 00112$:
                                    330 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004CB5 90 06 93         [24]  331 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004CB8 12 38 59         [24]  332 	lcall	_ak820_outline_0061
      004CBB A3               [24]  333 	inc	dptr
      004CBC E0               [24]  334 	movx	a,@dptr
      004CBD FF               [12]  335 	mov	r7,a
      004CBE 90 06 82         [24]  336 	mov	dptr,#_eeprom_write_byte_PARM_2
      004CC1 EE               [12]  337 	mov	a,r6
      004CC2 F0               [24]  338 	movx	@dptr,a
      004CC3 12 38 92         [24]  339 	lcall	_ak820_outline_0121
      004CC6 8F F0            [24]  340 	mov	b, r7
      004CC8 C0 07            [24]  341 	push	ar7
      004CCA C0 06            [24]  342 	push	ar6
      004CCC C0 05            [24]  343 	push	ar5
      004CCE C0 04            [24]  344 	push	ar4
      004CD0 C0 03            [24]  345 	push	ar3
      004CD2 C0 02            [24]  346 	push	ar2
      004CD4 C0 01            [24]  347 	push	ar1
      004CD6 C0 00            [24]  348 	push	ar0
      004CD8 12 4C 40         [24]  349 	lcall	_eeprom_write_byte
      004CDB D0 00            [24]  350 	pop	ar0
      004CDD D0 01            [24]  351 	pop	ar1
      004CDF D0 02            [24]  352 	pop	ar2
      004CE1 D0 03            [24]  353 	pop	ar3
      004CE3 D0 04            [24]  354 	pop	ar4
      004CE5 D0 05            [24]  355 	pop	ar5
      004CE7 D0 06            [24]  356 	pop	ar6
      004CE9 D0 07            [24]  357 	pop	ar7
      004CEB                        358 00103$:
                                    359 ;	drivers/eeprom/eeprom_driver.c:87: }
      004CEB D0 04            [24]  360 	pop	ar4
      004CED D0 05            [24]  361 	pop	ar5
      004CEF D0 06            [24]  362 	pop	ar6
      004CF1 D0 07            [24]  363 	pop	ar7
      004CF3 22               [24]  364 	ret
                                    365 ;------------------------------------------------------------
                                    366 ;Allocation info for local variables in function 'eeprom_update_word'
                                    367 ;------------------------------------------------------------
                                    368 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    369 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    370 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    371 ;------------------------------------------------------------
                                    372 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    373 ;	-----------------------------------------
                                    374 ;	 function eeprom_update_word
                                    375 ;	-----------------------------------------
      004CF4                        376 _eeprom_update_word:
      004CF4 12 43 0E         [24]  377 	lcall	_ak820_outline_0035
      004CF7 90 06 98         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004CFA 12 38 20         [24]  379 	lcall	_ak820_outline_0015
                                    380 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004CFD 90 06 98         [24]  381 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004D00 12 4D 75         [24]  382 	lcall	_ak820_outline_0001
      004D03 12 4B DE         [24]  383 	lcall	_eeprom_read_word
      004D06 12 43 56         [24]  384 	lcall	_ak820_outline_0131
                                    385 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004D09 90 06 96         [24]  386 	mov	dptr,#_eeprom_update_word_PARM_2
      004D0C 12 38 59         [24]  387 	lcall	_ak820_outline_0061
      004D0F EE               [12]  388 	mov	a,r6
      004D10 B5 04 05         [24]  389 	cjne	a,ar4,00112$
      004D13 EF               [12]  390 	mov	a,r7
      004D14 B5 05 01         [24]  391 	cjne	a,ar5,00112$
      004D17 22               [24]  392 	ret
      004D18                        393 00112$:
                                    394 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004D18 90 06 98         [24]  395 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004D1B E0               [24]  396 	movx	a,@dptr
      004D1C FB               [12]  397 	mov	r3,a
      004D1D A3               [24]  398 	inc	dptr
      004D1E 12 38 42         [24]  399 	lcall	_ak820_outline_0052
      004D21 90 06 86         [24]  400 	mov	dptr,#_eeprom_write_word_PARM_2
      004D24 12 38 5F         [24]  401 	lcall	_ak820_outline_0071
      004D27 8B 82            [24]  402 	mov	dpl, r3
      004D29 8E 83            [24]  403 	mov	dph, r6
      004D2B 8F F0            [24]  404 	mov	b, r7
                                    405 ;	drivers/eeprom/eeprom_driver.c:94: }
      004D2D 02 4C 5A         [24]  406 	ljmp	_eeprom_write_word
                                    407 ;------------------------------------------------------------
                                    408 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    409 ;------------------------------------------------------------
                                    410 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    411 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    412 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    413 ;------------------------------------------------------------
                                    414 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    415 ;	-----------------------------------------
                                    416 ;	 function eeprom_update_dword
                                    417 ;	-----------------------------------------
      004D30                        418 _eeprom_update_dword:
      004D30 12 43 0E         [24]  419 	lcall	_ak820_outline_0035
      004D33 90 06 9F         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004D36 12 38 20         [24]  421 	lcall	_ak820_outline_0015
                                    422 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004D39 90 06 9F         [24]  423 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004D3C 12 4D 75         [24]  424 	lcall	_ak820_outline_0001
      004D3F 12 4C 0F         [24]  425 	lcall	_eeprom_read_dword
      004D42 12 4D C6         [24]  426 	lcall	_ak820_outline_0057
                                    427 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004D45 90 06 9B         [24]  428 	mov	dptr,#_eeprom_update_dword_PARM_2
      004D48 E0               [24]  429 	movx	a,@dptr
      004D49 F8               [12]  430 	mov	r0,a
      004D4A A3               [24]  431 	inc	dptr
      004D4B 12 4D CE         [24]  432 	lcall	_ak820_outline_0088
      004D4E EC               [12]  433 	mov	a,r4
      004D4F B5 00 0D         [24]  434 	cjne	a,ar0,00112$
      004D52 ED               [12]  435 	mov	a,r5
      004D53 B5 01 09         [24]  436 	cjne	a,ar1,00112$
      004D56 EE               [12]  437 	mov	a,r6
      004D57 B5 02 05         [24]  438 	cjne	a,ar2,00112$
      004D5A EF               [12]  439 	mov	a,r7
      004D5B B5 03 01         [24]  440 	cjne	a,ar3,00112$
      004D5E 22               [24]  441 	ret
      004D5F                        442 00112$:
                                    443 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004D5F 90 06 9F         [24]  444 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004D62 12 4D 9B         [24]  445 	lcall	_ak820_outline_0012
      004D65 90 06 8B         [24]  446 	mov	dptr,#_eeprom_write_dword_PARM_2
      004D68 E8               [12]  447 	mov	a,r0
      004D69 F0               [24]  448 	movx	@dptr,a
      004D6A E9               [12]  449 	mov	a,r1
      004D6B A3               [24]  450 	inc	dptr
      004D6C 12 4D E0         [24]  451 	lcall	_ak820_outline_0152
      004D6F 12 4D A4         [24]  452 	lcall	_ak820_outline_0038
                                    453 ;	drivers/eeprom/eeprom_driver.c:101: }
      004D72 02 4C 74         [24]  454 	ljmp	_eeprom_write_dword
                                    455 	.area CSEG    (CODE)
                                    456 	.area CONST   (CODE)
                                    457 	.area XINIT   (CODE)
                                    458 	.area CABS    (ABS,CODE)
                                    459 
                                    460 ; Experimental exact instruction outlining.
                                    461 	.globl _ak820_outline_0001
                                    462 	.globl _ak820_outline_0004
                                    463 	.globl _ak820_outline_0012
                                    464 	.globl _ak820_outline_0015
                                    465 	.globl _ak820_outline_0035
                                    466 	.globl _ak820_outline_0038
                                    467 	.globl _ak820_outline_0051
                                    468 	.globl _ak820_outline_0052
                                    469 	.globl _ak820_outline_0055
                                    470 	.globl _ak820_outline_0057
                                    471 	.globl _ak820_outline_0061
                                    472 	.globl _ak820_outline_0071
                                    473 	.globl _ak820_outline_0088
                                    474 	.globl _ak820_outline_0089
                                    475 	.globl _ak820_outline_0121
                                    476 	.globl _ak820_outline_0122
                                    477 	.globl _ak820_outline_0131
                                    478 	.globl _ak820_outline_0152
                                    479 	.globl _ak820_outline_0166
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0001
      004D75                        483 _ak820_outline_0001:
      004D75 E0               [24]  484 	movx	a,@dptr
      004D76 FD               [12]  485 	mov	r5,a
      004D77 A3               [24]  486 	inc	dptr
      004D78 E0               [24]  487 	movx	a,@dptr
      004D79 FE               [12]  488 	mov	r6,a
      004D7A A3               [24]  489 	inc	dptr
      004D7B E0               [24]  490 	movx	a,@dptr
      004D7C FF               [12]  491 	mov	r7,a
      004D7D 8D 82            [24]  492 	mov	dpl,r5
      004D7F 8E 83            [24]  493 	mov	dph,r6
      004D81 8F F0            [24]  494 	mov	b,r7
      004D83 22               [24]  495 	ret
                                    496 
                                    497 	.area CSEG (CODE)
                                    498 ; function ak820_outline_0004
      004D84                        499 _ak820_outline_0004:
      004D84 E0               [24]  500 	movx	a,@dptr
      004D85 FD               [12]  501 	mov	r5,a
      004D86 A3               [24]  502 	inc	dptr
      004D87 E0               [24]  503 	movx	a,@dptr
      004D88 FE               [12]  504 	mov	r6,a
      004D89 A3               [24]  505 	inc	dptr
      004D8A E0               [24]  506 	movx	a,@dptr
      004D8B FF               [12]  507 	mov	r7,a
      004D8C 90 05 8E         [24]  508 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004D8F ED               [12]  509 	mov	a,r5
      004D90 F0               [24]  510 	movx	@dptr,a
      004D91 EE               [12]  511 	mov	a,r6
      004D92 A3               [24]  512 	inc	dptr
      004D93 F0               [24]  513 	movx	@dptr,a
      004D94 EF               [12]  514 	mov	a,r7
      004D95 A3               [24]  515 	inc	dptr
      004D96 F0               [24]  516 	movx	@dptr,a
      004D97 90 05 91         [24]  517 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004D9A 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0012
      004D9B                        522 _ak820_outline_0012:
      004D9B E0               [24]  523 	movx	a,@dptr
      004D9C FD               [12]  524 	mov	r5,a
      004D9D A3               [24]  525 	inc	dptr
      004D9E E0               [24]  526 	movx	a,@dptr
      004D9F FE               [12]  527 	mov	r6,a
      004DA0 A3               [24]  528 	inc	dptr
      004DA1 E0               [24]  529 	movx	a,@dptr
      004DA2 FF               [12]  530 	mov	r7,a
      004DA3 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0038
      004DA4                        535 _ak820_outline_0038:
      004DA4 F0               [24]  536 	movx	@dptr,a
      004DA5 8D 82            [24]  537 	mov	dpl,r5
      004DA7 8E 83            [24]  538 	mov	dph,r6
      004DA9 8F F0            [24]  539 	mov	b,r7
      004DAB 22               [24]  540 	ret
                                    541 
                                    542 	.area CSEG (CODE)
                                    543 ; function ak820_outline_0051
      004DAC                        544 _ak820_outline_0051:
      004DAC E4               [12]  545 	clr	a
      004DAD F0               [24]  546 	movx	@dptr,a
      004DAE A3               [24]  547 	inc	dptr
      004DAF F0               [24]  548 	movx	@dptr,a
      004DB0 A3               [24]  549 	inc	dptr
      004DB1 F0               [24]  550 	movx	@dptr,a
      004DB2 A3               [24]  551 	inc	dptr
      004DB3 F0               [24]  552 	movx	@dptr,a
      004DB4 22               [24]  553 	ret
                                    554 
                                    555 	.area CSEG (CODE)
                                    556 ; function ak820_outline_0055
      004DB5                        557 _ak820_outline_0055:
      004DB5 E0               [24]  558 	movx	a,@dptr
      004DB6 FC               [12]  559 	mov	r4,a
      004DB7 A3               [24]  560 	inc	dptr
      004DB8 E0               [24]  561 	movx	a,@dptr
      004DB9 FD               [12]  562 	mov	r5,a
      004DBA A3               [24]  563 	inc	dptr
      004DBB E0               [24]  564 	movx	a,@dptr
      004DBC FE               [12]  565 	mov	r6,a
      004DBD A3               [24]  566 	inc	dptr
      004DBE E0               [24]  567 	movx	a,@dptr
      004DBF 8C 82            [24]  568 	mov	dpl,r4
      004DC1 8D 83            [24]  569 	mov	dph,r5
      004DC3 8E F0            [24]  570 	mov	b,r6
      004DC5 22               [24]  571 	ret
                                    572 
                                    573 	.area CSEG (CODE)
                                    574 ; function ak820_outline_0057
      004DC6                        575 _ak820_outline_0057:
      004DC6 AC 82            [24]  576 	mov	r4,dpl
      004DC8 AD 83            [24]  577 	mov	r5,dph
      004DCA AE F0            [24]  578 	mov	r6,b
      004DCC FF               [12]  579 	mov	r7,a
      004DCD 22               [24]  580 	ret
                                    581 
                                    582 	.area CSEG (CODE)
                                    583 ; function ak820_outline_0088
      004DCE                        584 _ak820_outline_0088:
      004DCE E0               [24]  585 	movx	a,@dptr
      004DCF F9               [12]  586 	mov	r1,a
      004DD0 A3               [24]  587 	inc	dptr
      004DD1 E0               [24]  588 	movx	a,@dptr
      004DD2 FA               [12]  589 	mov	r2,a
      004DD3 A3               [24]  590 	inc	dptr
      004DD4 E0               [24]  591 	movx	a,@dptr
      004DD5 FB               [12]  592 	mov	r3,a
      004DD6 22               [24]  593 	ret
                                    594 
                                    595 	.area CSEG (CODE)
                                    596 ; function ak820_outline_0089
      004DD7                        597 _ak820_outline_0089:
      004DD7 E0               [24]  598 	movx	a,@dptr
      004DD8 FE               [12]  599 	mov	r6,a
      004DD9 A3               [24]  600 	inc	dptr
      004DDA E0               [24]  601 	movx	a,@dptr
      004DDB 8E 82            [24]  602 	mov	dpl,r6
      004DDD F5 83            [12]  603 	mov	dph,a
      004DDF 22               [24]  604 	ret
                                    605 
                                    606 	.area CSEG (CODE)
                                    607 ; function ak820_outline_0152
      004DE0                        608 _ak820_outline_0152:
      004DE0 F0               [24]  609 	movx	@dptr,a
      004DE1 EA               [12]  610 	mov	a,r2
      004DE2 A3               [24]  611 	inc	dptr
      004DE3 F0               [24]  612 	movx	@dptr,a
      004DE4 EB               [12]  613 	mov	a,r3
      004DE5 A3               [24]  614 	inc	dptr
      004DE6 22               [24]  615 	ret
                                    616 
                                    617 	.area CSEG (CODE)
                                    618 ; function ak820_outline_0166
      004DE7                        619 _ak820_outline_0166:
      004DE7 E4               [12]  620 	clr	a
      004DE8 F0               [24]  621 	movx	@dptr,a
      004DE9 A3               [24]  622 	inc	dptr
      004DEA F0               [24]  623 	movx	@dptr,a
      004DEB 22               [24]  624 	ret
