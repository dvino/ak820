;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ch555_ak820
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _protocol_post_task
	.globl _protocol_pre_task
	.globl _protocol_post_init
	.globl _protocol_pre_init
	.globl _protocol_setup
	.globl _ak820_host_send_extra
	.globl _ak820_host_send_keyboard
	.globl _ak820_host_keyboard_leds
	.globl _rgb_matrix_set_suspend_state
	.globl _ak820_nvm_end
	.globl _ak820_nvm_begin
	.globl _ak820_update_indicators
	.globl _ak820_clock_init
	.globl _usb_device_state_init
	.globl _usb_device_state_set_resume
	.globl _usb_device_state_set_suspend
	.globl _usb_device_state_set_configuration
	.globl _ak820_usb_take_keyboard_reset
	.globl _ak820_usb_raw_send
	.globl _ak820_usb_raw_task
	.globl _ak820_usb_try_send
	.globl _ak820_usb_send
	.globl _clear_keyboard
	.globl _timer_elapsed
	.globl _timer_read
	.globl _host_last_consumer_usage
	.globl _host_last_system_usage
	.globl _host_set_driver
	.globl _USB_Device_Init
	.globl _memset
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ch555_usb_stack_driver
	.globl _keyboard_protocol
	.globl _raw_hid_send_PARM_2
	.globl _keyboard_idle
	.globl _raw_hid_send
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_protocol_pre_task_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_keyboard_idle::
	.ds 1
_last_keyboard_report:
	.ds 32
_last_keyboard_time:
	.ds 2
_pending_reports:
	.ds 1
_send_keyboard_report_10000_295:
	.ds 3
_send_keyboard_endpoint_10000_296:
	.ds 1
_send_keyboard_length_10000_296:
	.ds 1
_send_mouse_report_10000_301:
	.ds 3
_send_extra_report_10000_303:
	.ds 3
_ak820_host_send_keyboard_report_10000_310:
	.ds 3
_ak820_host_send_extra_report_10000_314:
	.ds 3
_raw_hid_send_PARM_2:
	.ds 1
_raw_hid_send_data_10000_316:
	.ds 3
_protocol_post_task_endpoint_10000_333:
	.ds 1
_protocol_post_task_length_10000_333:
	.ds 1
_protocol_post_task_report_30000_339:
	.ds 3
_protocol_post_task_pending_30000_339:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_keyboard_protocol::
	.ds 1
_ch555_usb_stack_driver::
	.ds 8
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function keyboard_leds
;	-----------------------------------------
_keyboard_leds:
;	tmk_core/protocol/ch555/ch555_ak820.c:36: return KB_USB_SetReport;
	mov	dptr,#_KB_USB_SetReport
	movx	a,@dptr
;	tmk_core/protocol/ch555/ch555_ak820.c:37: }
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'send_keyboard'
;------------------------------------------------------------
;report        Allocated with name '_send_keyboard_report_10000_295'
;endpoint      Allocated with name '_send_keyboard_endpoint_10000_296'
;length        Allocated with name '_send_keyboard_length_10000_296'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:39: static void send_keyboard(report_keyboard_t *report) {
;	-----------------------------------------
;	 function send_keyboard
;	-----------------------------------------
_send_keyboard:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_send_keyboard_report_10000_295
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:40: uint8_t endpoint = KEYBOARD_IN_EPNUM;
	mov	dptr,#_send_keyboard_endpoint_10000_296
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:41: uint8_t length = KEYBOARD_REPORT_SIZE;
	mov	dptr,#_send_keyboard_length_10000_296
	mov	a,#0x08
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:43: if (keyboard_protocol && keymap_config.nkro) {
	mov	dptr,#_keyboard_protocol
	movx	a,@dptr
	jz	00102$
	mov	dptr,#_keymap_config
	movx	a,@dptr
	jnb	acc.7,00102$
;	tmk_core/protocol/ch555/ch555_ak820.c:44: endpoint = SHARED_IN_EPNUM;
	mov	dptr,#_send_keyboard_endpoint_10000_296
	mov	a,#0x02
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:45: length = sizeof(struct nkro_report);
	mov	dptr,#_send_keyboard_length_10000_296
	swap	a
	movx	@dptr,a
00102$:
;	tmk_core/protocol/ch555/ch555_ak820.c:48: last_keyboard_report = *report;
	mov	dptr,#_send_keyboard_report_10000_295
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#___memcpy_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x20
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_last_keyboard_report
	mov	b,a
	lcall	___memcpy
;	tmk_core/protocol/ch555/ch555_ak820.c:49: pending_reports |= PENDING_KEYBOARD;
	mov	dptr,#_pending_reports
	movx	a,@dptr
	orl	acc,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:50: if (ak820_usb_send(endpoint, (const uint8_t __xdata *)&last_keyboard_report, length)) {
	mov	dptr,#_send_keyboard_endpoint_10000_296
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_send_keyboard_length_10000_296
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_ak820_usb_send_PARM_2
	mov	a,#_last_keyboard_report
	movx	@dptr,a
	mov	a,#(_last_keyboard_report >> 8)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_usb_send_PARM_3
	mov	a,r6
	movx	@dptr,a
	mov	dpl, r7
	lcall	_ak820_usb_send
	mov	a, dpl
	jz	00106$
;	tmk_core/protocol/ch555/ch555_ak820.c:51: pending_reports &= (uint8_t)~PENDING_KEYBOARD;
	mov	dptr,#_pending_reports
	movx	a,@dptr
	anl	acc,#0xfe
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:52: last_keyboard_time = timer_read();
	lcall	_timer_read
	mov	a, dpl
	mov	b, dph
	mov	dptr,#_last_keyboard_time
	movx	@dptr,a
	mov	a,b
	inc	dptr
	movx	@dptr,a
00106$:
;	tmk_core/protocol/ch555/ch555_ak820.c:54: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'send_mouse'
;------------------------------------------------------------
;report        Allocated with name '_send_mouse_report_10000_301'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:56: static void send_mouse(report_mouse_t *report) {
;	-----------------------------------------
;	 function send_mouse
;	-----------------------------------------
_send_mouse:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_send_mouse_report_10000_301
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:58: ak820_usb_send(MOUSE_IN_EPNUM, (const uint8_t __xdata *)report, sizeof(report_mouse_t));
	mov	dptr,#_send_mouse_report_10000_301
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_ak820_usb_send_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_usb_send_PARM_3
	mov	a,#0x06
	movx	@dptr,a
	mov	dpl, #0x02
;	tmk_core/protocol/ch555/ch555_ak820.c:62: }
	ljmp	_ak820_usb_send
;------------------------------------------------------------
;Allocation info for local variables in function 'send_extra'
;------------------------------------------------------------
;report        Allocated with name '_send_extra_report_10000_303'
;pending       Allocated with name '_send_extra_pending_10000_304'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:64: static void send_extra(report_extra_t *report) {
;	-----------------------------------------
;	 function send_extra
;	-----------------------------------------
_send_extra:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_send_extra_report_10000_303
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:66: uint8_t pending = report->report_id == REPORT_ID_SYSTEM ? PENDING_SYSTEM : PENDING_CONSUMER;
	mov	dptr,#_send_extra_report_10000_303
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar2,r5
	mov	ar3,r6
	mov	ar4,r7
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
	cjne	r2,#0x03,00106$
	mov	r4,#0x02
	sjmp	00107$
00106$:
	mov	r4,#0x04
00107$:
;	tmk_core/protocol/ch555/ch555_ak820.c:67: if (ak820_usb_send(SHARED_IN_EPNUM, (const uint8_t __xdata *)report, sizeof(report_extra_t))) {
	mov	dptr,#_ak820_usb_send_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_usb_send_PARM_3
	mov	a,#0x03
	movx	@dptr,a
	mov	dpl, #0x02
	push	ar4
	lcall	_ak820_usb_send
	mov	a, dpl
	pop	ar4
	jz	00102$
;	tmk_core/protocol/ch555/ch555_ak820.c:68: pending_reports &= (uint8_t)~pending;
	mov	a,#0xff
	xrl	a,r4
	mov	r7,a
	mov	dptr,#_pending_reports
	movx	a,@dptr
	anl	a,r7
	movx	@dptr,a
	ret
00102$:
;	tmk_core/protocol/ch555/ch555_ak820.c:70: pending_reports |= pending;
	mov	dptr,#_pending_reports
	movx	a,@dptr
	orl	a,r4
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:75: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_host_keyboard_leds'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:79: uint8_t ak820_host_keyboard_leds(void) { return keyboard_leds(); }
;	-----------------------------------------
;	 function ak820_host_keyboard_leds
;	-----------------------------------------
_ak820_host_keyboard_leds:
	ljmp	_keyboard_leds
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_host_send_keyboard'
;------------------------------------------------------------
;report        Allocated with name '_ak820_host_send_keyboard_report_10000_310'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:80: void ak820_host_send_keyboard(report_keyboard_t *report) { send_keyboard(report); }
;	-----------------------------------------
;	 function ak820_host_send_keyboard
;	-----------------------------------------
_ak820_host_send_keyboard:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_ak820_host_send_keyboard_report_10000_310
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_host_send_keyboard_report_10000_310
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
	ljmp	_send_keyboard
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_host_send_mouse'
;------------------------------------------------------------
;report        Allocated with name '_ak820_host_send_mouse_report_10000_312'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:81: void ak820_host_send_mouse(report_mouse_t *report) { send_mouse(report); }
;	-----------------------------------------
;	 function ak820_host_send_extra
;	-----------------------------------------
_ak820_host_send_extra:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_ak820_host_send_extra_report_10000_314
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_host_send_extra_report_10000_314
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
	ljmp	_send_extra
;------------------------------------------------------------
;Allocation info for local variables in function 'raw_hid_send'
;------------------------------------------------------------
;length        Allocated with name '_raw_hid_send_PARM_2'
;data          Allocated with name '_raw_hid_send_data_10000_316'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:86: void raw_hid_send(uint8_t *data, uint8_t length) {
;	-----------------------------------------
;	 function raw_hid_send
;	-----------------------------------------
_raw_hid_send:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_raw_hid_send_data_10000_316
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:87: ak820_usb_raw_send(data, length);
	mov	dptr,#_raw_hid_send_data_10000_316
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_raw_hid_send_PARM_2
	movx	a,@dptr
	mov	dptr,#_ak820_usb_raw_send_PARM_2
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
;	tmk_core/protocol/ch555/ch555_ak820.c:88: }
	ljmp	_ak820_usb_raw_send
;------------------------------------------------------------
;Allocation info for local variables in function 'protocol_setup'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:90: void protocol_setup(void) {
;	-----------------------------------------
;	 function protocol_setup
;	-----------------------------------------
_protocol_setup:
;	tmk_core/protocol/ch555/ch555_ak820.c:91: ak820_clock_init();
	lcall	_ak820_clock_init
;	tmk_core/protocol/ch555/ch555_ak820.c:92: usb_device_state_init();
;	tmk_core/protocol/ch555/ch555_ak820.c:93: }
	ljmp	_usb_device_state_init
;------------------------------------------------------------
;Allocation info for local variables in function 'protocol_pre_init'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:95: void protocol_pre_init(void) {
;	-----------------------------------------
;	 function protocol_pre_init
;	-----------------------------------------
_protocol_pre_init:
;	tmk_core/protocol/ch555/ch555_ak820.c:96: ak820_boot_stage = 1;
	mov	dptr,#_ak820_boot_stage
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:98: ak820_nvm_begin();
	lcall	_ak820_nvm_begin
;	tmk_core/protocol/ch555/ch555_ak820.c:99: USB_Device_Init();
;	tmk_core/protocol/ch555/ch555_ak820.c:100: }
	ljmp	_USB_Device_Init
;------------------------------------------------------------
;Allocation info for local variables in function 'protocol_post_init'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:102: void protocol_post_init(void) {
;	-----------------------------------------
;	 function protocol_post_init
;	-----------------------------------------
_protocol_post_init:
;	tmk_core/protocol/ch555/ch555_ak820.c:103: ak820_nvm_end();
	lcall	_ak820_nvm_end
;	tmk_core/protocol/ch555/ch555_ak820.c:104: host_set_driver(&ch555_usb_stack_driver);
	mov	dptr,#_ch555_usb_stack_driver
	mov	b, #0x00
	lcall	_host_set_driver
;	tmk_core/protocol/ch555/ch555_ak820.c:105: ak820_boot_stage = 2;
	mov	dptr,#_ak820_boot_stage
	mov	a,#0x02
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:106: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'protocol_pre_task'
;------------------------------------------------------------
;next          Allocated with name '_protocol_pre_task_next_10000_325'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:108: void protocol_pre_task(void) {
;	-----------------------------------------
;	 function protocol_pre_task
;	-----------------------------------------
_protocol_pre_task:
;	tmk_core/protocol/ch555/ch555_ak820.c:110: enum usb_device_state next = (USB_SleepStatus & 2) ? USB_DEVICE_STATE_SUSPEND :
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	jnb	acc.1,00113$
	mov	r7,#0x03
	sjmp	00114$
00113$:
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jz	00115$
	mov	r6,#0x02
	sjmp	00116$
00115$:
	mov	r6,#0x01
00116$:
	mov	ar7,r6
00114$:
;	tmk_core/protocol/ch555/ch555_ak820.c:112: if (next != usb_device_state) {
	mov	dptr,#_usb_device_state
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00161$
	sjmp	00108$
00161$:
;	tmk_core/protocol/ch555/ch555_ak820.c:113: if (next == USB_DEVICE_STATE_SUSPEND) usb_device_state_set_suspend(D0UsbConfig != 0, D0UsbConfig);
	cjne	r7,#0x03,00105$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	cjne	a,#0x01,00164$
00164$:
	cpl	c
	mov	_protocol_pre_task_sloc0_1_0,c
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	mov	dptr,#_usb_device_state_set_suspend_PARM_2
	movx	@dptr,a
	mov	c,_protocol_pre_task_sloc0_1_0
	clr	a
	rlc	a
	mov	dpl, a
	push	ar7
	lcall	_usb_device_state_set_suspend
	pop	ar7
	sjmp	00106$
00105$:
;	tmk_core/protocol/ch555/ch555_ak820.c:114: else if (usb_device_state == USB_DEVICE_STATE_SUSPEND) usb_device_state_set_resume(D0UsbConfig != 0, D0UsbConfig);
	cjne	r6,#0x03,00102$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	cjne	a,#0x01,00167$
00167$:
	cpl	c
	mov	_protocol_pre_task_sloc0_1_0,c
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	mov	dptr,#_usb_device_state_set_resume_PARM_2
	movx	@dptr,a
	mov	c,_protocol_pre_task_sloc0_1_0
	clr	a
	rlc	a
	mov	dpl, a
	push	ar7
	lcall	_usb_device_state_set_resume
	pop	ar7
	sjmp	00106$
00102$:
;	tmk_core/protocol/ch555/ch555_ak820.c:115: else usb_device_state_set_configuration(D0UsbConfig != 0, D0UsbConfig);
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	cjne	a,#0x01,00168$
00168$:
	cpl	c
	mov	_protocol_pre_task_sloc0_1_0,c
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	mov	dptr,#_usb_device_state_set_configuration_PARM_2
	movx	@dptr,a
	mov	c,_protocol_pre_task_sloc0_1_0
	clr	a
	rlc	a
	mov	dpl, a
	push	ar7
	lcall	_usb_device_state_set_configuration
	pop	ar7
00106$:
;	tmk_core/protocol/ch555/ch555_ak820.c:119: rgb_matrix_set_suspend_state(next == USB_DEVICE_STATE_SUSPEND);
	cjne	r7,#0x03,00169$
	setb	c
	sjmp	00170$
00169$:
	clr	c
00170$:
	mov  _protocol_pre_task_sloc0_1_0,c
	clr	a
	rlc	a
	mov	dpl, a
	lcall	_rgb_matrix_set_suspend_state
00108$:
;	tmk_core/protocol/ch555/ch555_ak820.c:122: if (ak820_usb_take_keyboard_reset()) {
	lcall	_ak820_usb_take_keyboard_reset
	mov	a, dpl
	jz	00111$
;	tmk_core/protocol/ch555/ch555_ak820.c:123: pending_reports = 0;
	mov	dptr,#_pending_reports
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:124: memset(&last_keyboard_report, 0, sizeof(last_keyboard_report));
	mov	dptr,#_memset_PARM_2
	movx	@dptr,a
	mov	dptr,#_memset_PARM_3
	mov	a,#0x20
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_last_keyboard_report
	mov	b,a
	lcall	_memset
;	tmk_core/protocol/ch555/ch555_ak820.c:125: last_keyboard_time = timer_read();
	lcall	_timer_read
	mov	a, dpl
	mov	b, dph
	mov	dptr,#_last_keyboard_time
	movx	@dptr,a
	mov	a,b
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:126: clear_keyboard();
;	tmk_core/protocol/ch555/ch555_ak820.c:128: }
	ljmp	_clear_keyboard
00111$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'protocol_post_task'
;------------------------------------------------------------
;endpoint      Allocated with name '_protocol_post_task_endpoint_10000_333'
;length        Allocated with name '_protocol_post_task_length_10000_333'
;report        Allocated with name '_protocol_post_task_report_30000_339'
;pending       Allocated with name '_protocol_post_task_pending_30000_339'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/ch555_ak820.c:130: void protocol_post_task(void) {
;	-----------------------------------------
;	 function protocol_post_task
;	-----------------------------------------
_protocol_post_task:
;	tmk_core/protocol/ch555/ch555_ak820.c:131: uint8_t endpoint = KEYBOARD_IN_EPNUM;
	mov	dptr,#_protocol_post_task_endpoint_10000_333
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:132: uint8_t length = KEYBOARD_REPORT_SIZE;
	mov	dptr,#_protocol_post_task_length_10000_333
	mov	a,#0x08
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:133: ak820_boot_stage = 3;
	mov	dptr,#_ak820_boot_stage
	mov	a,#0x03
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:134: ++ak820_main_heartbeat;
	mov	dptr,#_ak820_main_heartbeat
	movx	a,@dptr
	add	a, #0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:135: ak820_usb_raw_task();
	lcall	_ak820_usb_raw_task
;	tmk_core/protocol/ch555/ch555_ak820.c:137: if (keyboard_protocol && keymap_config.nkro) {
	mov	dptr,#_keyboard_protocol
	movx	a,@dptr
	jz	00102$
	mov	dptr,#_keymap_config
	movx	a,@dptr
	jnb	acc.7,00102$
;	tmk_core/protocol/ch555/ch555_ak820.c:138: endpoint = SHARED_IN_EPNUM;
	mov	dptr,#_protocol_post_task_endpoint_10000_333
	mov	a,#0x02
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:139: length = sizeof(struct nkro_report);
	mov	dptr,#_protocol_post_task_length_10000_333
	swap	a
	movx	@dptr,a
00102$:
;	tmk_core/protocol/ch555/ch555_ak820.c:145: if (((pending_reports & PENDING_KEYBOARD) ||
	mov	dptr,#_pending_reports
	movx	a,@dptr
	jb	acc.0,00110$
;	tmk_core/protocol/ch555/ch555_ak820.c:146: (keyboard_idle && (!keyboard_protocol || !keymap_config.nkro) &&
	mov	dptr,#_keyboard_idle
	movx	a,@dptr
	jz	00105$
	mov	dptr,#_keyboard_protocol
	movx	a,@dptr
	jz	00108$
	mov	dptr,#_keymap_config
	movx	a,@dptr
	jb	acc.7,00105$
00108$:
;	tmk_core/protocol/ch555/ch555_ak820.c:147: timer_elapsed(last_keyboard_time) >= (uint16_t)keyboard_idle * 4u)) &&
	mov	dptr,#_last_keyboard_time
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	lcall	_timer_elapsed
	mov	r6, dpl
	mov	r7, dph
	mov	dptr,#_keyboard_idle
	movx	a,@dptr
	mov	r5,#0x00
	add	a,acc
	mov	r4,a
	mov	a,r5
	rlc	a
	mov	r5,a
	mov	a,r4
	add	a,r4
	mov	r4,a
	mov	a,r5
	rlc	a
	mov	r5,a
	clr	c
	mov	a,r6
	subb	a,r4
	mov	a,r7
	subb	a,r5
	jc	00105$
00110$:
;	tmk_core/protocol/ch555/ch555_ak820.c:148: ak820_usb_try_send(endpoint, (const uint8_t __xdata *)&last_keyboard_report, length)) {
	mov	dptr,#_protocol_post_task_endpoint_10000_333
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_protocol_post_task_length_10000_333
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_ak820_usb_try_send_PARM_2
	mov	a,#_last_keyboard_report
	movx	@dptr,a
	mov	a,#(_last_keyboard_report >> 8)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_usb_try_send_PARM_3
	mov	a,r6
	movx	@dptr,a
	mov	dpl, r7
	lcall	_ak820_usb_try_send
	mov	a, dpl
	jz	00105$
;	tmk_core/protocol/ch555/ch555_ak820.c:149: pending_reports &= (uint8_t)~PENDING_KEYBOARD;
	mov	dptr,#_pending_reports
	movx	a,@dptr
	anl	acc,#0xfe
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:150: last_keyboard_time = timer_read();
	lcall	_timer_read
	mov	a, dpl
	mov	b, dph
	mov	dptr,#_last_keyboard_time
	movx	@dptr,a
	mov	a,b
	inc	dptr
	movx	@dptr,a
00105$:
;	tmk_core/protocol/ch555/ch555_ak820.c:153: if (pending_reports & (PENDING_SYSTEM | PENDING_CONSUMER)) {
	mov	dptr,#_pending_reports
	movx	a,@dptr
	mov	r7,a
	anl	a,#0x06
	jz	00117$
;	tmk_core/protocol/ch555/ch555_ak820.c:159: if (pending_reports & PENDING_SYSTEM) {
	mov	a,r7
	jnb	acc.1,00112$
;	tmk_core/protocol/ch555/ch555_ak820.c:160: pending = PENDING_SYSTEM;
	mov	dptr,#_protocol_post_task_pending_30000_339
	mov	a,#0x02
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:161: report.report_id = REPORT_ID_SYSTEM;
	mov	dptr,#_protocol_post_task_report_30000_339
	inc	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:162: report.usage = host_last_system_usage();
	lcall	_host_last_system_usage
	mov	r6, dpl
	mov	r7, dph
	mov	dptr,#(_protocol_post_task_report_30000_339 + 0x0001)
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	sjmp	00113$
00112$:
;	tmk_core/protocol/ch555/ch555_ak820.c:164: pending = PENDING_CONSUMER;
	mov	dptr,#_protocol_post_task_pending_30000_339
	mov	a,#0x04
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:165: report.report_id = REPORT_ID_CONSUMER;
	mov	dptr,#_protocol_post_task_report_30000_339
	movx	@dptr,a
;	tmk_core/protocol/ch555/ch555_ak820.c:166: report.usage = host_last_consumer_usage();
	lcall	_host_last_consumer_usage
	mov	r6, dpl
	mov	r7, dph
	mov	dptr,#(_protocol_post_task_report_30000_339 + 0x0001)
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
00113$:
;	tmk_core/protocol/ch555/ch555_ak820.c:168: if (ak820_usb_try_send(SHARED_IN_EPNUM, (const uint8_t __xdata *)&report, sizeof(report))) {
	mov	dptr,#_ak820_usb_try_send_PARM_2
	mov	a,#_protocol_post_task_report_30000_339
	movx	@dptr,a
	mov	a,#(_protocol_post_task_report_30000_339 >> 8)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_usb_try_send_PARM_3
	mov	a,#0x03
	movx	@dptr,a
	mov	dpl, #0x02
	lcall	_ak820_usb_try_send
	mov	a, dpl
	jz	00117$
;	tmk_core/protocol/ch555/ch555_ak820.c:169: pending_reports &= (uint8_t)~pending;
	mov	dptr,#_protocol_post_task_pending_30000_339
	movx	a,@dptr
	cpl	a
	mov	r7,a
	mov	dptr,#_pending_reports
	movx	a,@dptr
	anl	a,r7
	movx	@dptr,a
00117$:
;	tmk_core/protocol/ch555/ch555_ak820.c:176: ak820_update_indicators();
;	tmk_core/protocol/ch555/ch555_ak820.c:177: }
	ljmp	_ak820_update_indicators
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__keyboard_protocol:
	.db #0x01	; 1
__xinit__ch555_usb_stack_driver:
	.byte _keyboard_leds, (_keyboard_leds >> 8)
	.byte _send_keyboard, (_send_keyboard >> 8)
	.byte _send_mouse, (_send_mouse >> 8)
	.byte _send_extra, (_send_extra >> 8)
	.area CABS    (ABS,CODE)
