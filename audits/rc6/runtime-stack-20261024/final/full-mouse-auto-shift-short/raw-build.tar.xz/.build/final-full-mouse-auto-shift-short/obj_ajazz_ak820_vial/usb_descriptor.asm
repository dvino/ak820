;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module usb_descriptor
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _SerialNumberString
	.globl _ProductString
	.globl _ManufacturerString
	.globl _LanguageString
	.globl _ConfigurationDescriptor
	.globl _DeviceDescriptor
	.globl _RawReport_size
	.globl _RawReport
	.globl _SharedReport_size
	.globl _SharedReport
	.globl _KeyboardReport_size
	.globl _KeyboardReport
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _get_usb_descriptor_PARM_4
	.globl _get_usb_descriptor_PARM_3
	.globl _get_usb_descriptor_PARM_2
	.globl _get_usb_descriptor
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_KEYCODE2SYSTEM_key_10000_49:
	.ds 1
_get_usb_descriptor_PARM_2:
	.ds 2
_get_usb_descriptor_PARM_3:
	.ds 2
_get_usb_descriptor_PARM_4:
	.ds 3
_get_usb_descriptor_wValue_10000_64:
	.ds 2
_get_usb_descriptor_Address_10000_65:
	.ds 3
_get_usb_descriptor_Size_10000_65:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_49'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
;	 function KEYCODE2SYSTEM
;	-----------------------------------------
_KEYCODE2SYSTEM:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	mov	a,dpl
	mov	dptr,#_KEYCODE2SYSTEM_key_10000_49
	movx	@dptr,a
;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xa5,00113$
00113$:
	jc	00101$
	mov	a,r7
	add	a,#0xff - 0xa7
	jnc	00102$
;	free result
00101$:
	mov	dptr,#0x0000
	ret
00102$:
;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
	mov	a,#0xdc
	add	a, r7
	mov	r7,a
	mov	r6,#0x00
	mov	dpl, r7
	mov	dph, r6
;	tmk_core/protocol/report.h:278: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'get_usb_descriptor'
;------------------------------------------------------------
;wIndex        Allocated with name '_get_usb_descriptor_PARM_2'
;wLength       Allocated with name '_get_usb_descriptor_PARM_3'
;DescriptorAddress Allocated with name '_get_usb_descriptor_PARM_4'
;wValue        Allocated with name '_get_usb_descriptor_wValue_10000_64'
;DescriptorType Allocated with name '_get_usb_descriptor_DescriptorType_10000_65'
;DescriptorIndex Allocated with name '_get_usb_descriptor_DescriptorIndex_10000_65'
;Address       Allocated with name '_get_usb_descriptor_Address_10000_65'
;Size          Allocated with name '_get_usb_descriptor_Size_10000_65'
;------------------------------------------------------------
;	tmk_core/protocol/usb_descriptor.c:1128: uint16_t get_usb_descriptor(const uint16_t wValue, const uint16_t wIndex, const uint16_t wLength, const void** const DescriptorAddress) {
;	-----------------------------------------
;	 function get_usb_descriptor
;	-----------------------------------------
_get_usb_descriptor:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_get_usb_descriptor_wValue_10000_64
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1129: const uint8_t DescriptorType  = (wValue >> 8);
	mov	dptr,#_get_usb_descriptor_wValue_10000_64
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	r5,a
;	tmk_core/protocol/usb_descriptor.c:1130: const uint8_t DescriptorIndex = (wValue & 0xFF);
;	tmk_core/protocol/usb_descriptor.c:1131: const void*   Address         = NULL;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1132: uint16_t      Size            = NO_DESCRIPTOR;
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1134: switch (DescriptorType) {
	cjne	r5,#0x01,00206$
	sjmp	00101$
00206$:
	cjne	r5,#0x02,00207$
	sjmp	00102$
00207$:
	cjne	r5,#0x03,00208$
	sjmp	00103$
00208$:
	cjne	r5,#0x21,00209$
	ljmp	00109$
00209$:
	cjne	r5,#0x22,00210$
	ljmp	00114$
00210$:
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1135: case DTYPE_Device:
00101$:
;	tmk_core/protocol/usb_descriptor.c:1136: Address = &DeviceDescriptor;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#_DeviceDescriptor
	movx	@dptr,a
	mov	a,#(_DeviceDescriptor >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1137: Size    = sizeof(USB_Descriptor_Device_t);
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	mov	a,#0x12
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1139: break;
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1140: case DTYPE_Configuration:
00102$:
;	tmk_core/protocol/usb_descriptor.c:1141: Address = &ConfigurationDescriptor;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#_ConfigurationDescriptor
	movx	@dptr,a
	mov	a,#(_ConfigurationDescriptor >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1142: Size    = sizeof(USB_Descriptor_Configuration_t);
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	mov	a,#0x54
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1144: break;
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1145: case DTYPE_String:
00103$:
;	tmk_core/protocol/usb_descriptor.c:1146: switch (DescriptorIndex) {
	mov	a,r6
	add	a,#0xff - 0x03
	jnc	00211$
	ljmp	00119$
00211$:
;	free result
	mov	a,r6
	add	a,r6
;	tmk_core/protocol/usb_descriptor.c:1147: case 0x00:
	mov	dptr,#00212$
	jmp	@a+dptr
00212$:
	sjmp	00104$
	sjmp	00105$
	sjmp	00106$
	sjmp	00107$
00104$:
;	tmk_core/protocol/usb_descriptor.c:1148: Address = &LanguageString;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#_LanguageString
	movx	@dptr,a
	mov	a,#(_LanguageString >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1149: Size    = pgm_read_byte(&LanguageString.Header.Size);
	mov	dptr,#_LanguageString
	clr	a
	movc	a,@a+dptr
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1151: break;
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1152: case 0x01:
00105$:
;	tmk_core/protocol/usb_descriptor.c:1153: Address = &ManufacturerString;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#_ManufacturerString
	movx	@dptr,a
	mov	a,#(_ManufacturerString >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1154: Size    = pgm_read_byte(&ManufacturerString.Header.Size);
	mov	dptr,#_ManufacturerString
	clr	a
	movc	a,@a+dptr
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1156: break;
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1157: case 0x02:
00106$:
;	tmk_core/protocol/usb_descriptor.c:1158: Address = &ProductString;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#_ProductString
	movx	@dptr,a
	mov	a,#(_ProductString >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1159: Size    = pgm_read_byte(&ProductString.Header.Size);
	mov	dptr,#_ProductString
	clr	a
	movc	a,@a+dptr
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1161: break;
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1163: case 0x03:
00107$:
;	tmk_core/protocol/usb_descriptor.c:1164: Address = &SerialNumberString;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#_SerialNumberString
	movx	@dptr,a
	mov	a,#(_SerialNumberString >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1165: Size    = pgm_read_byte(&SerialNumberString.Header.Size);
	mov	dptr,#_SerialNumberString
	clr	a
	movc	a,@a+dptr
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1174: break;
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1175: case HID_DTYPE_HID:
00109$:
;	tmk_core/protocol/usb_descriptor.c:1176: switch (wIndex) {
	mov	dptr,#_get_usb_descriptor_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r6
	mov	ar5,r7
	mov	a,r4
	orl	a,r5
	jz	00110$
	cjne	r6,#0x01,00214$
	cjne	r7,#0x00,00214$
	sjmp	00112$
00214$:
	cjne	r6,#0x02,00215$
	cjne	r7,#0x00,00215$
	sjmp	00111$
00215$:
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1178: case KEYBOARD_INTERFACE:
00110$:
;	tmk_core/protocol/usb_descriptor.c:1179: Address = &ConfigurationDescriptor.Keyboard_HID;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#(_ConfigurationDescriptor + 0x0012)
	movx	@dptr,a
	mov	a,#((_ConfigurationDescriptor + 0x0012) >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1180: Size    = sizeof(USB_HID_Descriptor_HID_t);
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	mov	a,#0x09
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1181: break;
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1193: case SHARED_INTERFACE:
00111$:
;	tmk_core/protocol/usb_descriptor.c:1194: Address = &ConfigurationDescriptor.Shared_HID;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#(_ConfigurationDescriptor + 0x0044)
	movx	@dptr,a
	mov	a,#((_ConfigurationDescriptor + 0x0044) >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1195: Size    = sizeof(USB_HID_Descriptor_HID_t);
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	mov	a,#0x09
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1197: break;
	ljmp	00119$
;	tmk_core/protocol/usb_descriptor.c:1201: case RAW_INTERFACE:
00112$:
;	tmk_core/protocol/usb_descriptor.c:1202: Address = &ConfigurationDescriptor.Raw_HID;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#(_ConfigurationDescriptor + 0x002b)
	movx	@dptr,a
	mov	a,#((_ConfigurationDescriptor + 0x002b) >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1203: Size    = sizeof(USB_HID_Descriptor_HID_t);
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	mov	a,#0x09
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1230: break;
;	tmk_core/protocol/usb_descriptor.c:1231: case HID_DTYPE_Report:
	sjmp	00119$
00114$:
;	tmk_core/protocol/usb_descriptor.c:1232: switch (wIndex) {
	mov	dptr,#_get_usb_descriptor_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r6
	mov	ar5,r7
	mov	a,r4
	orl	a,r5
	jz	00115$
	cjne	r6,#0x01,00217$
	cjne	r7,#0x00,00217$
	sjmp	00117$
00217$:
;	tmk_core/protocol/usb_descriptor.c:1234: case KEYBOARD_INTERFACE:
	cjne	r6,#0x02,00119$
	cjne	r7,#0x00,00119$
	sjmp	00116$
00115$:
;	tmk_core/protocol/usb_descriptor.c:1235: Address = &KeyboardReport;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#_KeyboardReport
	movx	@dptr,a
	mov	a,#(_KeyboardReport >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1236: Size    = sizeof(KeyboardReport);
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	mov	a,#0x44
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1238: break;
;	tmk_core/protocol/usb_descriptor.c:1250: case SHARED_INTERFACE:
	sjmp	00119$
00116$:
;	tmk_core/protocol/usb_descriptor.c:1251: Address = &SharedReport;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#_SharedReport
	movx	@dptr,a
	mov	a,#(_SharedReport >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1252: Size    = sizeof(SharedReport);
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	mov	a,#0xb6
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1254: break;
;	tmk_core/protocol/usb_descriptor.c:1258: case RAW_INTERFACE:
	sjmp	00119$
00117$:
;	tmk_core/protocol/usb_descriptor.c:1259: Address = &RawReport;
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	mov	a,#_RawReport
	movx	@dptr,a
	mov	a,#(_RawReport >> 8)
	inc	dptr
	movx	@dptr,a
	mov	a,#0x80
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1260: Size    = sizeof(RawReport);
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	mov	a,#0x28
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/usb_descriptor.c:1287: }
00119$:
;	tmk_core/protocol/usb_descriptor.c:1289: *DescriptorAddress = Address;
	mov	dptr,#_get_usb_descriptor_PARM_4
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_get_usb_descriptor_Address_10000_65
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	a,r2
	lcall	__gptrput
	inc	dptr
	mov	a,r3
	lcall	__gptrput
	inc	dptr
	mov	a,r4
	lcall	__gptrput
;	tmk_core/protocol/usb_descriptor.c:1291: return Size;
	mov	dptr,#_get_usb_descriptor_Size_10000_65
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
;	tmk_core/protocol/usb_descriptor.c:1292: }
	mov	dpl,r6
	mov	dph,a
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
__str_0:
	.byte 65,0
	.byte 0,0
	.area CSEG    (CODE)
	.area CONST   (CODE)
_KeyboardReport:
	.db #0x05	; 5
	.db #0x01	; 1
	.db #0x09	; 9
	.db #0x06	; 6
	.db #0xa1	; 161
	.db #0x01	; 1
	.db #0x05	; 5
	.db #0x07	; 7
	.db #0x19	; 25
	.db #0xe0	; 224
	.db #0x29	; 41
	.db #0xe7	; 231
	.db #0x15	; 21
	.db #0x00	; 0
	.db #0x25	; 37
	.db #0x01	; 1
	.db #0x95	; 149
	.db #0x08	; 8
	.db #0x75	; 117	'u'
	.db #0x01	; 1
	.db #0x81	; 129
	.db #0x02	; 2
	.db #0x95	; 149
	.db #0x01	; 1
	.db #0x75	; 117	'u'
	.db #0x08	; 8
	.db #0x81	; 129
	.db #0x01	; 1
	.db #0x05	; 5
	.db #0x07	; 7
	.db #0x19	; 25
	.db #0x00	; 0
	.db #0x29	; 41
	.db #0xff	; 255
	.db #0x15	; 21
	.db #0x00	; 0
	.db #0x26	; 38
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x95	; 149
	.db #0x06	; 6
	.db #0x75	; 117	'u'
	.db #0x08	; 8
	.db #0x81	; 129
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x08	; 8
	.db #0x19	; 25
	.db #0x01	; 1
	.db #0x29	; 41
	.db #0x05	; 5
	.db #0x15	; 21
	.db #0x00	; 0
	.db #0x25	; 37
	.db #0x01	; 1
	.db #0x95	; 149
	.db #0x05	; 5
	.db #0x75	; 117	'u'
	.db #0x01	; 1
	.db #0x91	; 145
	.db #0x02	; 2
	.db #0x95	; 149
	.db #0x01	; 1
	.db #0x75	; 117	'u'
	.db #0x03	; 3
	.db #0x91	; 145
	.db #0x01	; 1
	.db #0xc0	; 192
	.area CSEG    (CODE)
	.area CONST   (CODE)
_KeyboardReport_size:
	.db #0x44	; 68	'D'
	.area CSEG    (CODE)
	.area CONST   (CODE)
_SharedReport:
	.db #0x05	; 5
	.db #0x01	; 1
	.db #0x09	; 9
	.db #0x02	; 2
	.db #0xa1	; 161
	.db #0x01	; 1
	.db #0x85	; 133
	.db #0x02	; 2
	.db #0x09	; 9
	.db #0x01	; 1
	.db #0xa1	; 161
	.db #0x00	; 0
	.db #0x05	; 5
	.db #0x09	; 9
	.db #0x19	; 25
	.db #0x01	; 1
	.db #0x29	; 41
	.db #0x08	; 8
	.db #0x15	; 21
	.db #0x00	; 0
	.db #0x25	; 37
	.db #0x01	; 1
	.db #0x95	; 149
	.db #0x08	; 8
	.db #0x75	; 117	'u'
	.db #0x01	; 1
	.db #0x81	; 129
	.db #0x02	; 2
	.db #0x05	; 5
	.db #0x01	; 1
	.db #0x09	; 9
	.db #0x30	; 48	'0'
	.db #0x09	; 9
	.db #0x31	; 49	'1'
	.db #0x15	; 21
	.db #0x81	; 129
	.db #0x25	; 37
	.db #0x7f	; 127
	.db #0x95	; 149
	.db #0x02	; 2
	.db #0x75	; 117	'u'
	.db #0x08	; 8
	.db #0x81	; 129
	.db #0x06	; 6
	.db #0x09	; 9
	.db #0x38	; 56	'8'
	.db #0x15	; 21
	.db #0x81	; 129
	.db #0x25	; 37
	.db #0x7f	; 127
	.db #0x95	; 149
	.db #0x01	; 1
	.db #0x75	; 117	'u'
	.db #0x08	; 8
	.db #0x81	; 129
	.db #0x06	; 6
	.db #0x05	; 5
	.db #0x0c	; 12
	.db #0x0a	; 10
	.db #0x38	; 56	'8'
	.db #0x02	; 2
	.db #0x15	; 21
	.db #0x81	; 129
	.db #0x25	; 37
	.db #0x7f	; 127
	.db #0x95	; 149
	.db #0x01	; 1
	.db #0x75	; 117	'u'
	.db #0x08	; 8
	.db #0x81	; 129
	.db #0x06	; 6
	.db #0xc0	; 192
	.db #0xc0	; 192
	.db #0x05	; 5
	.db #0x01	; 1
	.db #0x09	; 9
	.db #0x80	; 128
	.db #0xa1	; 161
	.db #0x01	; 1
	.db #0x85	; 133
	.db #0x03	; 3
	.db #0x19	; 25
	.db #0x01	; 1
	.db #0x2a	; 42
	.db #0xb7	; 183
	.db #0x00	; 0
	.db #0x15	; 21
	.db #0x01	; 1
	.db #0x26	; 38
	.db #0xb7	; 183
	.db #0x00	; 0
	.db #0x95	; 149
	.db #0x01	; 1
	.db #0x75	; 117	'u'
	.db #0x10	; 16
	.db #0x81	; 129
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x05	; 5
	.db #0x0c	; 12
	.db #0x09	; 9
	.db #0x01	; 1
	.db #0xa1	; 161
	.db #0x01	; 1
	.db #0x85	; 133
	.db #0x04	; 4
	.db #0x19	; 25
	.db #0x01	; 1
	.db #0x2a	; 42
	.db #0xa0	; 160
	.db #0x02	; 2
	.db #0x15	; 21
	.db #0x01	; 1
	.db #0x26	; 38
	.db #0xa0	; 160
	.db #0x02	; 2
	.db #0x95	; 149
	.db #0x01	; 1
	.db #0x75	; 117	'u'
	.db #0x10	; 16
	.db #0x81	; 129
	.db #0x00	; 0
	.db #0xc0	; 192
	.db #0x05	; 5
	.db #0x01	; 1
	.db #0x09	; 9
	.db #0x06	; 6
	.db #0xa1	; 161
	.db #0x01	; 1
	.db #0x85	; 133
	.db #0x06	; 6
	.db #0x05	; 5
	.db #0x07	; 7
	.db #0x19	; 25
	.db #0xe0	; 224
	.db #0x29	; 41
	.db #0xe7	; 231
	.db #0x15	; 21
	.db #0x00	; 0
	.db #0x25	; 37
	.db #0x01	; 1
	.db #0x95	; 149
	.db #0x08	; 8
	.db #0x75	; 117	'u'
	.db #0x01	; 1
	.db #0x81	; 129
	.db #0x02	; 2
	.db #0x05	; 5
	.db #0x07	; 7
	.db #0x19	; 25
	.db #0x00	; 0
	.db #0x29	; 41
	.db #0xef	; 239
	.db #0x15	; 21
	.db #0x00	; 0
	.db #0x25	; 37
	.db #0x01	; 1
	.db #0x95	; 149
	.db #0xf0	; 240
	.db #0x75	; 117	'u'
	.db #0x01	; 1
	.db #0x81	; 129
	.db #0x02	; 2
	.db #0x05	; 5
	.db #0x08	; 8
	.db #0x19	; 25
	.db #0x01	; 1
	.db #0x29	; 41
	.db #0x05	; 5
	.db #0x95	; 149
	.db #0x05	; 5
	.db #0x75	; 117	'u'
	.db #0x01	; 1
	.db #0x91	; 145
	.db #0x02	; 2
	.db #0x95	; 149
	.db #0x01	; 1
	.db #0x75	; 117	'u'
	.db #0x03	; 3
	.db #0x91	; 145
	.db #0x01	; 1
	.db #0xc0	; 192
	.area CSEG    (CODE)
	.area CONST   (CODE)
_SharedReport_size:
	.db #0xb6	; 182
	.area CSEG    (CODE)
	.area CONST   (CODE)
_RawReport:
	.db #0x06	; 6
	.db #0x60	; 96
	.db #0xff	; 255
	.db #0x09	; 9
	.db #0x61	; 97	'a'
	.db #0xa1	; 161
	.db #0x01	; 1
	.db #0x09	; 9
	.db #0x62	; 98	'b'
	.db #0x15	; 21
	.db #0x00	; 0
	.db #0x26	; 38
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x95	; 149
	.db #0x20	; 32
	.db #0x75	; 117	'u'
	.db #0x08	; 8
	.db #0x81	; 129
	.db #0x02	; 2
	.db #0x09	; 9
	.db #0x63	; 99	'c'
	.db #0x15	; 21
	.db #0x00	; 0
	.db #0x26	; 38
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x95	; 149
	.db #0x20	; 32
	.db #0x75	; 117	'u'
	.db #0x08	; 8
	.db #0x91	; 145
	.db #0x02	; 2
	.db #0x09	; 9
	.db #0x64	; 100	'd'
	.db #0x95	; 149
	.db #0x08	; 8
	.db #0xb1	; 177
	.db #0x02	; 2
	.db #0xc0	; 192
	.area CSEG    (CODE)
	.area CONST   (CODE)
_RawReport_size:
	.db #0x28	; 40
	.area CSEG    (CODE)
	.area CONST   (CODE)
_DeviceDescriptor:
	.db #0x12	; 18
	.db #0x01	; 1
	.byte #0x00, #0x02	; 512
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x40	; 64
	.byte #0x0f, #0x32	; 12815
	.byte #0x5b, #0x50	; 20571
	.byte #0x00, #0x01	; 256
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x03	; 3
	.db #0x01	; 1
	.area CSEG    (CODE)
	.area CONST   (CODE)
_ConfigurationDescriptor:
	.db #0x09	; 9
	.db #0x02	; 2
	.byte #0x54, #0x00	; 84
	.db #0x03	; 3
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0xfa	; 250
	.db #0x09	; 9
	.db #0x04	; 4
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x03	; 3
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x09	; 9
	.db #0x21	; 33
	.byte #0x11, #0x01	; 273
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x22	; 34
	.byte #0x44, #0x00	; 68
	.db #0x07	; 7
	.db #0x05	; 5
	.db #0x81	; 129
	.db #0x03	; 3
	.byte #0x08, #0x00	; 8
	.db #0x01	; 1
	.db #0x09	; 9
	.db #0x04	; 4
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x09	; 9
	.db #0x21	; 33
	.byte #0x11, #0x01	; 273
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x22	; 34
	.byte #0x28, #0x00	; 40
	.db #0x07	; 7
	.db #0x05	; 5
	.db #0x83	; 131
	.db #0x03	; 3
	.byte #0x20, #0x00	; 32
	.db #0x01	; 1
	.db #0x09	; 9
	.db #0x04	; 4
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x09	; 9
	.db #0x21	; 33
	.byte #0x11, #0x01	; 273
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x22	; 34
	.byte #0xb6, #0x00	; 182
	.db #0x07	; 7
	.db #0x05	; 5
	.db #0x82	; 130
	.db #0x03	; 3
	.byte #0x20, #0x00	; 32
	.db #0x01	; 1
	.area CSEG    (CODE)
	.area CONST   (CODE)
_LanguageString:
	.db #0x04	; 4
	.db #0x03	; 3
	.byte #0x09, #0x04	; 1033
	.area CSEG    (CODE)
	.area CONST   (CODE)
_ManufacturerString:
	.db #0x0c	; 12
	.db #0x03	; 3
	.byte 65,0
	.byte 74,0
	.byte 65,0
	.byte 90,0
	.byte 90,0
	.byte 0,0
	.area CSEG    (CODE)
	.area CONST   (CODE)
_ProductString:
	.db #0x36	; 54	'6'
	.db #0x03	; 3
	.byte 65,0
	.byte 75,0
	.byte 56,0
	.byte 50,0
	.byte 48,0
	.byte 32,0
	.byte 119,0
	.byte 105,0
	.byte 114,0
	.byte 101,0
	.byte 100,0
	.byte 32,0
	.byte 82,0
	.byte 71,0
	.byte 66,0
	.byte 32,0
	.byte 40,0
	.byte 86,0
	.byte 83,0
	.byte 49,0
	.byte 49,0
	.byte 75,0
	.byte 50,0
	.byte 56,0
	.byte 65,0
	.byte 41,0
	.byte 0,0
	.area CSEG    (CODE)
	.area CONST   (CODE)
_SerialNumberString:
	.db #0x1c	; 28
	.db #0x03	; 3
	.byte 118,0
	.byte 105,0
	.byte 97,0
	.byte 108,0
	.byte 58,0
	.byte 102,0
	.byte 54,0
	.byte 52,0
	.byte 99,0
	.byte 50,0
	.byte 98,0
	.byte 51,0
	.byte 99,0
	.byte 0,0
	.area CSEG    (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
