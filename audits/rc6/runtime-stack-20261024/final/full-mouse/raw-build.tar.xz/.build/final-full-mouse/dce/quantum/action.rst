                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_oneshot_cancel
                                     15 	.globl _ak820_oneshot_post
                                     16 	.globl _ak820_oneshot_process
                                     17 	.globl _ak820_tapping_source
                                     18 	.globl _ak820_tapping_cancel
                                     19 	.globl _ak820_tapping_process
                                     20 	.globl _ak820_tapping_before
                                     21 	.globl _pre_process_record_quantum
                                     22 	.globl _get_record_keycode
                                     23 	.globl _repeat_key_cancel
                                     24 	.globl _clear_owned_usages
                                     25 	.globl _owned_usage_key
                                     26 	.globl _clear_owned_keys
                                     27 	.globl _del_owned_key
                                     28 	.globl _add_owned_key
                                     29 	.globl _clear_owned_mods
                                     30 	.globl _del_owned_weak_mods
                                     31 	.globl _add_owned_weak_mods
                                     32 	.globl _del_owned_mods
                                     33 	.globl _add_owned_mods
                                     34 	.globl _clear_weak_mods
                                     35 	.globl _clear_mods
                                     36 	.globl _send_keyboard_report
                                     37 	.globl _layer_hold_clear
                                     38 	.globl _layer_hold_off
                                     39 	.globl _layer_hold_on
                                     40 	.globl _ak820_resolve_key
                                     41 	.globl _layer_xor
                                     42 	.globl _layer_and
                                     43 	.globl _layer_or
                                     44 	.globl _layer_off
                                     45 	.globl _layer_on
                                     46 	.globl _layer_move
                                     47 	.globl _layer_clear
                                     48 	.globl _layer_state_set
                                     49 	.globl _default_layer_xor
                                     50 	.globl _default_layer_and
                                     51 	.globl _default_layer_or
                                     52 	.globl _default_layer_set
                                     53 	.globl _post_process_record_quantum
                                     54 	.globl _process_record_quantum
                                     55 	.globl _action_for_keycode
                                     56 	.globl _mousekey_send
                                     57 	.globl _mousekey_clear
                                     58 	.globl _mousekey_off
                                     59 	.globl _mousekey_on
                                     60 	.globl _mDelaymS
                                     61 	.globl _host_consumer_send
                                     62 	.globl _host_system_send
                                     63 	.globl _host_keyboard_leds
                                     64 	.globl _led_set
                                     65 	.globl _clear_keys_from_report
                                     66 	.globl ___memcpy
                                     67 	.globl _ADC_START
                                     68 	.globl _S0_R_FIFO
                                     69 	.globl _S0_T_FIFO
                                     70 	.globl _S0_FREE
                                     71 	.globl _S0_IF_BYTE
                                     72 	.globl _S0_IF_FIRST
                                     73 	.globl _S0_IF_OV
                                     74 	.globl _S0_FST_ACT
                                     75 	.globl _CP_RL2
                                     76 	.globl _C_T2
                                     77 	.globl _TR2
                                     78 	.globl _EXEN2
                                     79 	.globl _TCLK
                                     80 	.globl _RCLK
                                     81 	.globl _EXF2
                                     82 	.globl _CAP1F
                                     83 	.globl _TF2
                                     84 	.globl _RI
                                     85 	.globl _TI
                                     86 	.globl _RB8
                                     87 	.globl _TB8
                                     88 	.globl _REN
                                     89 	.globl _SM2
                                     90 	.globl _SM1
                                     91 	.globl _SM0
                                     92 	.globl _IT0
                                     93 	.globl _IE0
                                     94 	.globl _IT1
                                     95 	.globl _IE1
                                     96 	.globl _TR0
                                     97 	.globl _TF0
                                     98 	.globl _TR1
                                     99 	.globl _TF1
                                    100 	.globl _P4_0
                                    101 	.globl _P4_1
                                    102 	.globl _P4_2
                                    103 	.globl _P4_3
                                    104 	.globl _P4_4
                                    105 	.globl _P4_5
                                    106 	.globl _P4_6
                                    107 	.globl _RXD
                                    108 	.globl _TXD
                                    109 	.globl _INT0
                                    110 	.globl _INT1
                                    111 	.globl _T0
                                    112 	.globl _T1
                                    113 	.globl _MOSI1
                                    114 	.globl _MISO1
                                    115 	.globl _SCK1
                                    116 	.globl _P3_0
                                    117 	.globl _P3_1
                                    118 	.globl _P3_2
                                    119 	.globl _P3_3
                                    120 	.globl _P3_4
                                    121 	.globl _P3_5
                                    122 	.globl _P3_6
                                    123 	.globl _P3_7
                                    124 	.globl _CAP1_
                                    125 	.globl _T2_
                                    126 	.globl _CAP2_
                                    127 	.globl _T2EX_
                                    128 	.globl _RXD1
                                    129 	.globl _TXD1
                                    130 	.globl _P2_0
                                    131 	.globl _P2_1
                                    132 	.globl _P2_2
                                    133 	.globl _P2_3
                                    134 	.globl _P2_4
                                    135 	.globl _P2_5
                                    136 	.globl _P2_6
                                    137 	.globl _P2_7
                                    138 	.globl _AIN0
                                    139 	.globl _AIN1
                                    140 	.globl _AIN2
                                    141 	.globl _AIN3
                                    142 	.globl _AIN4
                                    143 	.globl _AIN5
                                    144 	.globl _AIN6
                                    145 	.globl _AIN7
                                    146 	.globl _CAP1
                                    147 	.globl _T2
                                    148 	.globl _CAP2
                                    149 	.globl _T2EX
                                    150 	.globl _INT0_
                                    151 	.globl _SCS
                                    152 	.globl _MOSI
                                    153 	.globl _MISO
                                    154 	.globl _SCK
                                    155 	.globl _RXD1_
                                    156 	.globl _TXD1_
                                    157 	.globl _P1_0
                                    158 	.globl _P1_1
                                    159 	.globl _P1_2
                                    160 	.globl _P1_3
                                    161 	.globl _P1_4
                                    162 	.globl _P1_5
                                    163 	.globl _P1_6
                                    164 	.globl _P1_7
                                    165 	.globl _AIN8
                                    166 	.globl _AIN9
                                    167 	.globl _AIN10
                                    168 	.globl _AIN11
                                    169 	.globl _AIN12
                                    170 	.globl _AIN13
                                    171 	.globl _RXD_
                                    172 	.globl _TXD_
                                    173 	.globl _SCL0
                                    174 	.globl _SDA0
                                    175 	.globl _P0_0
                                    176 	.globl _P0_1
                                    177 	.globl _P0_2
                                    178 	.globl _P0_3
                                    179 	.globl _P0_4
                                    180 	.globl _P0_5
                                    181 	.globl _P0_6
                                    182 	.globl _P0_7
                                    183 	.globl _IE_SPI0
                                    184 	.globl _IE_USB
                                    185 	.globl _IE_ADC
                                    186 	.globl _IE_UART1
                                    187 	.globl _IE_PWM_I2C
                                    188 	.globl _IE_GPIO
                                    189 	.globl _IE_WDOG
                                    190 	.globl _PX0
                                    191 	.globl _PT0
                                    192 	.globl _PX1
                                    193 	.globl _PT1
                                    194 	.globl _PS
                                    195 	.globl _PT2
                                    196 	.globl _PL_FLAG
                                    197 	.globl _PH_FLAG
                                    198 	.globl _EX0
                                    199 	.globl _ET0
                                    200 	.globl _EX1
                                    201 	.globl _ET1
                                    202 	.globl _ES
                                    203 	.globl _ET2
                                    204 	.globl _E_DIS
                                    205 	.globl _EA
                                    206 	.globl _P
                                    207 	.globl _F1
                                    208 	.globl _OV
                                    209 	.globl _RS0
                                    210 	.globl _RS1
                                    211 	.globl _F0
                                    212 	.globl _AC
                                    213 	.globl _CY
                                    214 	.globl _I2CS_INT_ST
                                    215 	.globl _I2CX_INT
                                    216 	.globl _LED_STATUS
                                    217 	.globl _LED_DMA_H
                                    218 	.globl _LED_DMA_L
                                    219 	.globl _LED_DMA
                                    220 	.globl _LED_PWM_OE
                                    221 	.globl _LED_COMMON
                                    222 	.globl _ADC_CHAN
                                    223 	.globl _ADC_DAT_H
                                    224 	.globl _ADC_DAT_L
                                    225 	.globl _ADC_DAT
                                    226 	.globl _ADC_CTRL
                                    227 	.globl _SPI1_CK_SE
                                    228 	.globl _SPI1_CTRL
                                    229 	.globl _SPI1_DATA
                                    230 	.globl _SPI1_STAT
                                    231 	.globl _SIF1
                                    232 	.globl _SBAUD1
                                    233 	.globl _SBUF1
                                    234 	.globl _SCON1
                                    235 	.globl _SPI0_SETUP
                                    236 	.globl _SPI0_CK_SE
                                    237 	.globl _SPI0_CTRL
                                    238 	.globl _SPI0_DATA
                                    239 	.globl _SPI0_STAT
                                    240 	.globl _T2CAP1H
                                    241 	.globl _T2CAP1L
                                    242 	.globl _T2CAP1
                                    243 	.globl _TH2
                                    244 	.globl _TL2
                                    245 	.globl _T2COUNT
                                    246 	.globl _RCAP2H
                                    247 	.globl _RCAP2L
                                    248 	.globl _RCAP2
                                    249 	.globl _T2MOD
                                    250 	.globl _T2CON
                                    251 	.globl _SBUF
                                    252 	.globl _SCON
                                    253 	.globl _TH1
                                    254 	.globl _TH0
                                    255 	.globl _TL1
                                    256 	.globl _TL0
                                    257 	.globl _TMOD
                                    258 	.globl _TCON
                                    259 	.globl _XBUS_AUX
                                    260 	.globl _P7
                                    261 	.globl _P6_DIR
                                    262 	.globl _P6_OUT_PU
                                    263 	.globl _P6_IN
                                    264 	.globl _P5_DIR
                                    265 	.globl _P5_OUT_PU
                                    266 	.globl _P5_IN
                                    267 	.globl _P4_LED_KEY
                                    268 	.globl _P4_DIR_PU
                                    269 	.globl _P4_MOD_OC
                                    270 	.globl _P4
                                    271 	.globl _P3_DIR_PU
                                    272 	.globl _P3_MOD_OC
                                    273 	.globl _P3
                                    274 	.globl _P2_DIR_PU
                                    275 	.globl _P2_MOD_OC
                                    276 	.globl _P2
                                    277 	.globl _P1_DIR_PU
                                    278 	.globl _P1_MOD_OC
                                    279 	.globl _P1
                                    280 	.globl _P0_DIR_PU
                                    281 	.globl _P0_MOD_OC
                                    282 	.globl _P0
                                    283 	.globl _ROM_CTRL
                                    284 	.globl _ROM_DATA_HH
                                    285 	.globl _ROM_DATA_HL
                                    286 	.globl _ROM_DATA_HI
                                    287 	.globl _ROM_ADDR_H
                                    288 	.globl _ROM_ADDR_L
                                    289 	.globl _ROM_ADDR
                                    290 	.globl _GPIO_IE
                                    291 	.globl _IP_EX
                                    292 	.globl _IE_EX
                                    293 	.globl _IP
                                    294 	.globl _IE
                                    295 	.globl _WDOG_COUNT
                                    296 	.globl _RESET_KEEP
                                    297 	.globl _WAKE_CTRL
                                    298 	.globl _CLOCK_CFG
                                    299 	.globl _POWER_CFG
                                    300 	.globl _PCON
                                    301 	.globl _GLOBAL_CFG
                                    302 	.globl _SAFE_MOD
                                    303 	.globl _DPH
                                    304 	.globl _DPL
                                    305 	.globl _SP
                                    306 	.globl _A_INV
                                    307 	.globl _B
                                    308 	.globl _ACC
                                    309 	.globl _PSW
                                    310 	.globl _disable_action_cache
                                    311 	.globl _tap_code_delay_PARM_2
                                    312 	.globl _process_action_PARM_2
                                    313 	.globl _register_mouse_PARM_2
                                    314 	.globl _action_exec_PARM_1
                                    315 	.globl _tp_buttons
                                    316 	.globl _action_exec
                                    317 	.globl _ak820_action_exec
                                    318 	.globl _process_record
                                    319 	.globl _process_record_handler
                                    320 	.globl _process_action
                                    321 	.globl _register_code
                                    322 	.globl _unregister_code
                                    323 	.globl _tap_code_delay
                                    324 	.globl _tap_code
                                    325 	.globl _register_mods
                                    326 	.globl _unregister_mods
                                    327 	.globl _register_weak_mods
                                    328 	.globl _unregister_weak_mods
                                    329 	.globl _clear_keyboard
                                    330 	.globl _clear_keyboard_but_mods
                                    331 	.globl _clear_keyboard_but_mods_and_keys
                                    332 ;--------------------------------------------------------
                                    333 ; special function registers
                                    334 ;--------------------------------------------------------
                                    335 	.area RSEG    (ABS,DATA)
      000000                        336 	.org 0x0000
                           0000D0   337 _PSW	=	0x00d0
                           0000E0   338 _ACC	=	0x00e0
                           0000F0   339 _B	=	0x00f0
                           0000FD   340 _A_INV	=	0x00fd
                           000081   341 _SP	=	0x0081
                           000082   342 _DPL	=	0x0082
                           000083   343 _DPH	=	0x0083
                           0000A1   344 _SAFE_MOD	=	0x00a1
                           0000B1   345 _GLOBAL_CFG	=	0x00b1
                           000087   346 _PCON	=	0x0087
                           0000BA   347 _POWER_CFG	=	0x00ba
                           0000B9   348 _CLOCK_CFG	=	0x00b9
                           0000A9   349 _WAKE_CTRL	=	0x00a9
                           0000FE   350 _RESET_KEEP	=	0x00fe
                           0000FF   351 _WDOG_COUNT	=	0x00ff
                           0000A8   352 _IE	=	0x00a8
                           0000B8   353 _IP	=	0x00b8
                           0000E8   354 _IE_EX	=	0x00e8
                           0000E9   355 _IP_EX	=	0x00e9
                           0000B2   356 _GPIO_IE	=	0x00b2
                           008584   357 _ROM_ADDR	=	0x8584
                           000084   358 _ROM_ADDR_L	=	0x0084
                           000085   359 _ROM_ADDR_H	=	0x0085
                           008F8E   360 _ROM_DATA_HI	=	0x8f8e
                           00008E   361 _ROM_DATA_HL	=	0x008e
                           00008F   362 _ROM_DATA_HH	=	0x008f
                           000086   363 _ROM_CTRL	=	0x0086
                           000080   364 _P0	=	0x0080
                           0000C4   365 _P0_MOD_OC	=	0x00c4
                           0000C5   366 _P0_DIR_PU	=	0x00c5
                           000090   367 _P1	=	0x0090
                           000092   368 _P1_MOD_OC	=	0x0092
                           000093   369 _P1_DIR_PU	=	0x0093
                           0000A0   370 _P2	=	0x00a0
                           000094   371 _P2_MOD_OC	=	0x0094
                           000095   372 _P2_DIR_PU	=	0x0095
                           0000B0   373 _P3	=	0x00b0
                           000096   374 _P3_MOD_OC	=	0x0096
                           000097   375 _P3_DIR_PU	=	0x0097
                           0000C0   376 _P4	=	0x00c0
                           0000C2   377 _P4_MOD_OC	=	0x00c2
                           0000C3   378 _P4_DIR_PU	=	0x00c3
                           0000C1   379 _P4_LED_KEY	=	0x00c1
                           0000AA   380 _P5_IN	=	0x00aa
                           0000AB   381 _P5_OUT_PU	=	0x00ab
                           0000AC   382 _P5_DIR	=	0x00ac
                           0000AD   383 _P6_IN	=	0x00ad
                           0000AE   384 _P6_OUT_PU	=	0x00ae
                           0000AF   385 _P6_DIR	=	0x00af
                           0000F1   386 _P7	=	0x00f1
                           0000A2   387 _XBUS_AUX	=	0x00a2
                           000088   388 _TCON	=	0x0088
                           000089   389 _TMOD	=	0x0089
                           00008A   390 _TL0	=	0x008a
                           00008B   391 _TL1	=	0x008b
                           00008C   392 _TH0	=	0x008c
                           00008D   393 _TH1	=	0x008d
                           000098   394 _SCON	=	0x0098
                           000099   395 _SBUF	=	0x0099
                           0000C8   396 _T2CON	=	0x00c8
                           0000C9   397 _T2MOD	=	0x00c9
                           00CBCA   398 _RCAP2	=	0xcbca
                           0000CA   399 _RCAP2L	=	0x00ca
                           0000CB   400 _RCAP2H	=	0x00cb
                           00CDCC   401 _T2COUNT	=	0xcdcc
                           0000CC   402 _TL2	=	0x00cc
                           0000CD   403 _TH2	=	0x00cd
                           00CFCE   404 _T2CAP1	=	0xcfce
                           0000CE   405 _T2CAP1L	=	0x00ce
                           0000CF   406 _T2CAP1H	=	0x00cf
                           0000F8   407 _SPI0_STAT	=	0x00f8
                           0000F9   408 _SPI0_DATA	=	0x00f9
                           0000FA   409 _SPI0_CTRL	=	0x00fa
                           0000FB   410 _SPI0_CK_SE	=	0x00fb
                           0000FC   411 _SPI0_SETUP	=	0x00fc
                           0000BC   412 _SCON1	=	0x00bc
                           0000BD   413 _SBUF1	=	0x00bd
                           0000BE   414 _SBAUD1	=	0x00be
                           0000BF   415 _SIF1	=	0x00bf
                           0000B4   416 _SPI1_STAT	=	0x00b4
                           0000B5   417 _SPI1_DATA	=	0x00b5
                           0000B6   418 _SPI1_CTRL	=	0x00b6
                           0000B7   419 _SPI1_CK_SE	=	0x00b7
                           0000F3   420 _ADC_CTRL	=	0x00f3
                           00F5F4   421 _ADC_DAT	=	0xf5f4
                           0000F4   422 _ADC_DAT_L	=	0x00f4
                           0000F5   423 _ADC_DAT_H	=	0x00f5
                           0000F6   424 _ADC_CHAN	=	0x00f6
                           0000A6   425 _LED_COMMON	=	0x00a6
                           0000A7   426 _LED_PWM_OE	=	0x00a7
                           00C7C6   427 _LED_DMA	=	0xc7c6
                           0000C6   428 _LED_DMA_L	=	0x00c6
                           0000C7   429 _LED_DMA_H	=	0x00c7
                           0000F7   430 _LED_STATUS	=	0x00f7
                           0000B3   431 _I2CX_INT	=	0x00b3
                           0000BB   432 _I2CS_INT_ST	=	0x00bb
                                    433 ;--------------------------------------------------------
                                    434 ; special function bits
                                    435 ;--------------------------------------------------------
                                    436 	.area RSEG    (ABS,DATA)
      000000                        437 	.org 0x0000
                           0000D7   438 _CY	=	0x00d7
                           0000D6   439 _AC	=	0x00d6
                           0000D5   440 _F0	=	0x00d5
                           0000D4   441 _RS1	=	0x00d4
                           0000D3   442 _RS0	=	0x00d3
                           0000D2   443 _OV	=	0x00d2
                           0000D1   444 _F1	=	0x00d1
                           0000D0   445 _P	=	0x00d0
                           0000AF   446 _EA	=	0x00af
                           0000AE   447 _E_DIS	=	0x00ae
                           0000AD   448 _ET2	=	0x00ad
                           0000AC   449 _ES	=	0x00ac
                           0000AB   450 _ET1	=	0x00ab
                           0000AA   451 _EX1	=	0x00aa
                           0000A9   452 _ET0	=	0x00a9
                           0000A8   453 _EX0	=	0x00a8
                           0000BF   454 _PH_FLAG	=	0x00bf
                           0000BE   455 _PL_FLAG	=	0x00be
                           0000BD   456 _PT2	=	0x00bd
                           0000BC   457 _PS	=	0x00bc
                           0000BB   458 _PT1	=	0x00bb
                           0000BA   459 _PX1	=	0x00ba
                           0000B9   460 _PT0	=	0x00b9
                           0000B8   461 _PX0	=	0x00b8
                           0000EF   462 _IE_WDOG	=	0x00ef
                           0000EE   463 _IE_GPIO	=	0x00ee
                           0000ED   464 _IE_PWM_I2C	=	0x00ed
                           0000EC   465 _IE_UART1	=	0x00ec
                           0000EB   466 _IE_ADC	=	0x00eb
                           0000E9   467 _IE_USB	=	0x00e9
                           0000E8   468 _IE_SPI0	=	0x00e8
                           000087   469 _P0_7	=	0x0087
                           000086   470 _P0_6	=	0x0086
                           000085   471 _P0_5	=	0x0085
                           000084   472 _P0_4	=	0x0084
                           000083   473 _P0_3	=	0x0083
                           000082   474 _P0_2	=	0x0082
                           000081   475 _P0_1	=	0x0081
                           000080   476 _P0_0	=	0x0080
                           000081   477 _SDA0	=	0x0081
                           000080   478 _SCL0	=	0x0080
                           000083   479 _TXD_	=	0x0083
                           000082   480 _RXD_	=	0x0082
                           000085   481 _AIN13	=	0x0085
                           000084   482 _AIN12	=	0x0084
                           000083   483 _AIN11	=	0x0083
                           000082   484 _AIN10	=	0x0082
                           000081   485 _AIN9	=	0x0081
                           000080   486 _AIN8	=	0x0080
                           000097   487 _P1_7	=	0x0097
                           000096   488 _P1_6	=	0x0096
                           000095   489 _P1_5	=	0x0095
                           000094   490 _P1_4	=	0x0094
                           000093   491 _P1_3	=	0x0093
                           000092   492 _P1_2	=	0x0092
                           000091   493 _P1_1	=	0x0091
                           000090   494 _P1_0	=	0x0090
                           000097   495 _TXD1_	=	0x0097
                           000096   496 _RXD1_	=	0x0096
                           000097   497 _SCK	=	0x0097
                           000096   498 _MISO	=	0x0096
                           000095   499 _MOSI	=	0x0095
                           000094   500 _SCS	=	0x0094
                           000092   501 _INT0_	=	0x0092
                           000091   502 _T2EX	=	0x0091
                           000091   503 _CAP2	=	0x0091
                           000090   504 _T2	=	0x0090
                           000090   505 _CAP1	=	0x0090
                           000097   506 _AIN7	=	0x0097
                           000096   507 _AIN6	=	0x0096
                           000095   508 _AIN5	=	0x0095
                           000094   509 _AIN4	=	0x0094
                           000093   510 _AIN3	=	0x0093
                           000092   511 _AIN2	=	0x0092
                           000091   512 _AIN1	=	0x0091
                           000090   513 _AIN0	=	0x0090
                           0000A7   514 _P2_7	=	0x00a7
                           0000A6   515 _P2_6	=	0x00a6
                           0000A5   516 _P2_5	=	0x00a5
                           0000A4   517 _P2_4	=	0x00a4
                           0000A3   518 _P2_3	=	0x00a3
                           0000A2   519 _P2_2	=	0x00a2
                           0000A1   520 _P2_1	=	0x00a1
                           0000A0   521 _P2_0	=	0x00a0
                           0000A7   522 _TXD1	=	0x00a7
                           0000A6   523 _RXD1	=	0x00a6
                           0000A5   524 _T2EX_	=	0x00a5
                           0000A5   525 _CAP2_	=	0x00a5
                           0000A4   526 _T2_	=	0x00a4
                           0000A4   527 _CAP1_	=	0x00a4
                           0000B7   528 _P3_7	=	0x00b7
                           0000B6   529 _P3_6	=	0x00b6
                           0000B5   530 _P3_5	=	0x00b5
                           0000B4   531 _P3_4	=	0x00b4
                           0000B3   532 _P3_3	=	0x00b3
                           0000B2   533 _P3_2	=	0x00b2
                           0000B1   534 _P3_1	=	0x00b1
                           0000B0   535 _P3_0	=	0x00b0
                           0000B7   536 _SCK1	=	0x00b7
                           0000B6   537 _MISO1	=	0x00b6
                           0000B5   538 _MOSI1	=	0x00b5
                           0000B5   539 _T1	=	0x00b5
                           0000B4   540 _T0	=	0x00b4
                           0000B3   541 _INT1	=	0x00b3
                           0000B2   542 _INT0	=	0x00b2
                           0000B1   543 _TXD	=	0x00b1
                           0000B0   544 _RXD	=	0x00b0
                           0000C6   545 _P4_6	=	0x00c6
                           0000C5   546 _P4_5	=	0x00c5
                           0000C4   547 _P4_4	=	0x00c4
                           0000C3   548 _P4_3	=	0x00c3
                           0000C2   549 _P4_2	=	0x00c2
                           0000C1   550 _P4_1	=	0x00c1
                           0000C0   551 _P4_0	=	0x00c0
                           00008F   552 _TF1	=	0x008f
                           00008E   553 _TR1	=	0x008e
                           00008D   554 _TF0	=	0x008d
                           00008C   555 _TR0	=	0x008c
                           00008B   556 _IE1	=	0x008b
                           00008A   557 _IT1	=	0x008a
                           000089   558 _IE0	=	0x0089
                           000088   559 _IT0	=	0x0088
                           00009F   560 _SM0	=	0x009f
                           00009E   561 _SM1	=	0x009e
                           00009D   562 _SM2	=	0x009d
                           00009C   563 _REN	=	0x009c
                           00009B   564 _TB8	=	0x009b
                           00009A   565 _RB8	=	0x009a
                           000099   566 _TI	=	0x0099
                           000098   567 _RI	=	0x0098
                           0000CF   568 _TF2	=	0x00cf
                           0000CF   569 _CAP1F	=	0x00cf
                           0000CE   570 _EXF2	=	0x00ce
                           0000CD   571 _RCLK	=	0x00cd
                           0000CC   572 _TCLK	=	0x00cc
                           0000CB   573 _EXEN2	=	0x00cb
                           0000CA   574 _TR2	=	0x00ca
                           0000C9   575 _C_T2	=	0x00c9
                           0000C8   576 _CP_RL2	=	0x00c8
                           0000FF   577 _S0_FST_ACT	=	0x00ff
                           0000FE   578 _S0_IF_OV	=	0x00fe
                           0000FD   579 _S0_IF_FIRST	=	0x00fd
                           0000FC   580 _S0_IF_BYTE	=	0x00fc
                           0000FB   581 _S0_FREE	=	0x00fb
                           0000FA   582 _S0_T_FIFO	=	0x00fa
                           0000F8   583 _S0_R_FIFO	=	0x00f8
                           0000F7   584 _ADC_START	=	0x00f7
                                    585 ;--------------------------------------------------------
                                    586 ; overlayable register banks
                                    587 ;--------------------------------------------------------
                                    588 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        589 	.ds 8
                                    590 ;--------------------------------------------------------
                                    591 ; internal ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area DSEG    (DATA)
      000027                        594 _process_action_sloc0_1_0:
      000027                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; overlayable items in internal ram
                                    598 ;--------------------------------------------------------
                                    599 ;--------------------------------------------------------
                                    600 ; indirectly addressable internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area ISEG    (DATA)
                                    603 ;--------------------------------------------------------
                                    604 ; absolute internal ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area IABS    (ABS,DATA)
                                    607 	.area IABS    (ABS,DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; bit data
                                    610 ;--------------------------------------------------------
                                    611 	.area BSEG    (BIT)
      00001F                        612 _process_action_sloc1_1_0:
      00001F                        613 	.ds 1
                                    614 ;--------------------------------------------------------
                                    615 ; paged external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area PSEG    (PAG,XDATA)
                                    618 ;--------------------------------------------------------
                                    619 ; uninitialized external ram data
                                    620 ;--------------------------------------------------------
                                    621 	.area XSEG    (XDATA)
      000831                        622 _tp_buttons::
      000831                        623 	.ds 2
      000833                        624 _action_exec_PARM_1:
      000833                        625 	.ds 6
      000839                        626 _action_exec_record_10001_625:
      000839                        627 	.ds 9
      000842                        628 _ak820_action_exec_event_10000_629:
      000842                        629 	.ds 2
      000844                        630 _ak820_action_exec_snapshot_10000_630:
      000844                        631 	.ds 6
      00084A                        632 _process_record_record_10000_633:
      00084A                        633 	.ds 3
      00084D                        634 _process_record_handler_record_argument_10000_641:
      00084D                        635 	.ds 3
      000850                        636 _process_record_handler_action_10000_642:
      000850                        637 	.ds 2
      000852                        638 _register_mouse_PARM_2:
      000852                        639 	.ds 1
      000853                        640 _register_mouse_mouse_keycode_10000_650:
      000853                        641 	.ds 1
      000854                        642 _process_action_PARM_2:
      000854                        643 	.ds 2
      000856                        644 _process_action_record_argument_10000_657:
      000856                        645 	.ds 3
      000859                        646 _process_action_on_40000_680:
      000859                        647 	.ds 1
      00085A                        648 _register_code_code_10000_714:
      00085A                        649 	.ds 1
      00085B                        650 _unregister_code_code_10000_728:
      00085B                        651 	.ds 1
      00085C                        652 _tap_code_delay_PARM_2:
      00085C                        653 	.ds 2
      00085E                        654 _tap_code_delay_code_10000_741:
      00085E                        655 	.ds 1
      00085F                        656 _tap_code_code_10000_748:
      00085F                        657 	.ds 1
      000860                        658 _register_mods_mods_10000_750:
      000860                        659 	.ds 1
      000861                        660 _unregister_mods_mods_10000_754:
      000861                        661 	.ds 1
      000862                        662 _register_weak_mods_mods_10000_758:
      000862                        663 	.ds 1
      000863                        664 _unregister_weak_mods_mods_10000_762:
      000863                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000DE2                        674 _disable_action_cache::
      000DE2                        675 	.ds 1
                                    676 	.area HOME    (CODE)
                                    677 	.area GSINIT0 (CODE)
                                    678 	.area GSINIT1 (CODE)
                                    679 	.area GSINIT2 (CODE)
                                    680 	.area GSINIT3 (CODE)
                                    681 	.area GSINIT4 (CODE)
                                    682 	.area GSINIT5 (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 	.area GSFINAL (CODE)
                                    685 	.area CSEG    (CODE)
                                    686 ;--------------------------------------------------------
                                    687 ; global & static initialisations
                                    688 ;--------------------------------------------------------
                                    689 	.area HOME    (CODE)
                                    690 	.area GSINIT  (CODE)
                                    691 	.area GSFINAL (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 ;--------------------------------------------------------
                                    694 ; Home
                                    695 ;--------------------------------------------------------
                                    696 	.area HOME    (CODE)
                                    697 	.area HOME    (CODE)
                                    698 ;--------------------------------------------------------
                                    699 ; code
                                    700 ;--------------------------------------------------------
                                    701 	.area CSEG    (CODE)
                                    702 ;------------------------------------------------------------
                                    703 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    704 ;------------------------------------------------------------
                                    705 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    706 ;------------------------------------------------------------
                                    707 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    708 ;	-----------------------------------------
                           000007   709 	ar7 = 0x07
                           000006   710 	ar6 = 0x06
                           000005   711 	ar5 = 0x05
                           000004   712 	ar4 = 0x04
                           000003   713 	ar3 = 0x03
                           000002   714 	ar2 = 0x02
                           000001   715 	ar1 = 0x01
                           000000   716 	ar0 = 0x00
                                    717 ;	 function action_exec
                                    718 ;	-----------------------------------------
      0072A8                        719 _action_exec:
                                    720 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      0072A8 90 08 35         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0072AB 12 37 F4         [24]  722 	lcall	_ak820_outline_0005
      0072AE 12 36 04         [24]  723 	lcall	_ak820_combo_tick
                                    724 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      0072B1 90 08 33         [24]  725 	mov	dptr,#_action_exec_PARM_1
      0072B4 12 44 53         [24]  726 	lcall	_ak820_tapping_before
      0072B7 E5 82            [12]  727 	mov	a, dpl
      0072B9 70 01            [24]  728 	jnz	00102$
      0072BB 22               [24]  729 	ret
      0072BC                        730 00102$:
                                    731 ;	quantum/action.c:113: if (event.pressed) {
      0072BC 90 08 38         [24]  732 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0072BF E0               [24]  733 	movx	a,@dptr
      0072C0 60 03            [24]  734 	jz	00104$
                                    735 ;	quantum/action.c:115: clear_weak_mods();
      0072C2 12 83 7E         [24]  736 	lcall	_clear_weak_mods
      0072C5                        737 00104$:
                                    738 ;	quantum/action.c:127: record.event = event;
      0072C5 90 0D C2         [24]  739 	mov	dptr,#___memcpy_PARM_2
      0072C8 74 33            [12]  740 	mov	a,#_action_exec_PARM_1
      0072CA F0               [24]  741 	movx	@dptr,a
      0072CB 74 08            [12]  742 	mov	a,#(_action_exec_PARM_1 >> 8)
      0072CD 12 38 70         [24]  743 	lcall	_ak820_outline_0094
      0072D0 12 79 E6         [24]  744 	lcall	_ak820_outline_0071
      0072D3 90 08 39         [24]  745 	mov	dptr,#_action_exec_record_10001_625
      0072D6 F5 F0            [12]  746 	mov	b,a
      0072D8 12 BA AE         [24]  747 	lcall	___memcpy
                                    748 ;	quantum/action.c:129: record.tap.count = 0;
      0072DB 90 08 3F         [24]  749 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      0072DE E0               [24]  750 	movx	a,@dptr
      0072DF 54 0F            [12]  751 	anl	a,#0x0f
      0072E1 F0               [24]  752 	movx	@dptr,a
                                    753 ;	quantum/action.c:134: record.keycode = 0;
      0072E2 90 08 40         [24]  754 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      0072E5 12 4F 67         [24]  755 	lcall	_ak820_outline_0184
                                    756 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0072E8 90 08 3D         [24]  757 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      0072EB E0               [24]  758 	movx	a,@dptr
      0072EC 60 0D            [24]  759 	jz	00107$
      0072EE 90 08 39         [24]  760 	mov	dptr,#_action_exec_record_10001_625
      0072F1 75 F0 00         [24]  761 	mov	b, #0x00
      0072F4 12 A1 5D         [24]  762 	lcall	_pre_process_record_quantum
      0072F7 E5 82            [12]  763 	mov	a, dpl
      0072F9 60 14            [24]  764 	jz	00110$
      0072FB                        765 00107$:
                                    766 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      0072FB 90 08 39         [24]  767 	mov	dptr,#_action_exec_record_10001_625
      0072FE 12 45 3A         [24]  768 	lcall	_ak820_tapping_process
      007301 E5 82            [12]  769 	mov	a, dpl
      007303 70 01            [24]  770 	jnz	00106$
      007305 22               [24]  771 	ret
      007306                        772 00106$:
                                    773 ;	quantum/action.c:172: process_record(&record);
      007306 90 08 39         [24]  774 	mov	dptr,#_action_exec_record_10001_625
      007309 75 F0 00         [24]  775 	mov	b, #0x00
                                    776 ;	quantum/action.c:182: }
      00730C 02 73 4C         [24]  777 	ljmp	_process_record
      00730F                        778 00110$:
      00730F 22               [24]  779 	ret
                                    780 ;------------------------------------------------------------
                                    781 ;Allocation info for local variables in function 'ak820_action_exec'
                                    782 ;------------------------------------------------------------
                                    783 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    784 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    785 ;------------------------------------------------------------
                                    786 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    787 ;	-----------------------------------------
                                    788 ;	 function ak820_action_exec
                                    789 ;	-----------------------------------------
      007310                        790 _ak820_action_exec:
      007310 12 38 82         [24]  791 	lcall	_ak820_outline_0109
      007313 90 08 42         [24]  792 	mov	dptr,#_ak820_action_exec_event_10000_629
      007316 12 38 87         [24]  793 	lcall	_ak820_outline_0110
                                    794 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      007319 90 08 42         [24]  795 	mov	dptr,#_ak820_action_exec_event_10000_629
      00731C 12 38 64         [24]  796 	lcall	_ak820_outline_0080
      00731F 7F 00            [12]  797 	mov	r7,#0x00
      007321 90 0D C2         [24]  798 	mov	dptr,#___memcpy_PARM_2
      007324 ED               [12]  799 	mov	a,r5
      007325 12 38 1F         [24]  800 	lcall	_ak820_outline_0016
      007328 12 79 E6         [24]  801 	lcall	_ak820_outline_0071
      00732B 90 08 44         [24]  802 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      00732E F5 F0            [12]  803 	mov	b,a
      007330 12 BA AE         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:189: action_exec(snapshot);
      007333 90 0D C2         [24]  806 	mov	dptr,#___memcpy_PARM_2
      007336 74 44            [12]  807 	mov	a,#_ak820_action_exec_snapshot_10000_630
      007338 F0               [24]  808 	movx	@dptr,a
      007339 74 08            [12]  809 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      00733B 12 38 70         [24]  810 	lcall	_ak820_outline_0094
      00733E 12 79 E6         [24]  811 	lcall	_ak820_outline_0071
      007341 90 08 33         [24]  812 	mov	dptr,#_action_exec_PARM_1
      007344 F5 F0            [12]  813 	mov	b,a
      007346 12 BA AE         [24]  814 	lcall	___memcpy
                                    815 ;	quantum/action.c:190: }
      007349 02 72 A8         [24]  816 	ljmp	_action_exec
                                    817 ;------------------------------------------------------------
                                    818 ;Allocation info for local variables in function 'process_record_nocache'
                                    819 ;------------------------------------------------------------
                                    820 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function process_record
                                    825 ;	-----------------------------------------
      00734C                        826 _process_record:
      00734C 12 43 13         [24]  827 	lcall	_ak820_outline_0036
      00734F 90 08 4A         [24]  828 	mov	dptr,#_process_record_record_10000_633
      007352 12 38 1F         [24]  829 	lcall	_ak820_outline_0016
                                    830 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      007355 90 08 4A         [24]  831 	mov	dptr,#_process_record_record_10000_633
      007358 12 4F 14         [24]  832 	lcall	_ak820_outline_0012
      00735B 74 04            [12]  833 	mov	a,#0x04
      00735D 12 79 B9         [24]  834 	lcall	_ak820_outline_0014
      007360 12 BB 87         [24]  835 	lcall	__gptrget
      007363 70 01            [24]  836 	jnz	00102$
                                    837 ;	quantum/action.c:330: return;
      007365 22               [24]  838 	ret
      007366                        839 00102$:
                                    840 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007366 8D 02            [24]  841 	mov	ar2,r5
      007368 8E 03            [24]  842 	mov	ar3,r6
      00736A 8F 04            [24]  843 	mov	ar4,r7
      00736C 90 0D C2         [24]  844 	mov	dptr,#___memcpy_PARM_2
      00736F EA               [12]  845 	mov	a,r2
      007370 12 7A 2D         [24]  846 	lcall	_ak820_outline_0189
      007373 EC               [12]  847 	mov	a,r4
      007374 A3               [24]  848 	inc	dptr
      007375 F0               [24]  849 	movx	@dptr,a
      007376 90 0D C5         [24]  850 	mov	dptr,#___memcpy_PARM_3
      007379 12 4F 59         [24]  851 	lcall	_ak820_outline_0112
      00737C 90 06 24         [24]  852 	mov	dptr,#_ak820_tapping_source_PARM_1
      00737F F5 F0            [12]  853 	mov	b,a
      007381 C0 07            [24]  854 	push	ar7
      007383 C0 06            [24]  855 	push	ar6
      007385 C0 05            [24]  856 	push	ar5
      007387 12 BA AE         [24]  857 	lcall	___memcpy
      00738A 12 43 8D         [24]  858 	lcall	_ak820_tapping_source
      00738D AC 82            [24]  859 	mov	r4, dpl
      00738F D0 05            [24]  860 	pop	ar5
      007391 D0 06            [24]  861 	pop	ar6
      007393 D0 07            [24]  862 	pop	ar7
                                    863 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      007395 74 05            [12]  864 	mov	a,#0x05
      007397 12 79 AB         [24]  865 	lcall	_ak820_outline_0013
      00739A 12 BB 87         [24]  866 	lcall	__gptrget
      00739D FB               [12]  867 	mov	r3,a
                                    868 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      00739E 12 7A 1E         [24]  869 	lcall	_ak820_outline_0150
      0073A1 90 0C 19         [24]  870 	mov	dptr,#_get_record_keycode_PARM_2
      0073A4 74 01            [12]  871 	mov	a,#0x01
      0073A6 12 4F 1D         [24]  872 	lcall	_ak820_outline_0034
      0073A9 C0 04            [24]  873 	push	ar4
      0073AB C0 03            [24]  874 	push	ar3
      0073AD C0 02            [24]  875 	push	ar2
      0073AF C0 01            [24]  876 	push	ar1
      0073B1 C0 00            [24]  877 	push	ar0
      0073B3 12 A1 1F         [24]  878 	lcall	_get_record_keycode
      0073B6 12 43 5C         [24]  879 	lcall	_ak820_outline_0135
      0073B9 D0 00            [24]  880 	pop	ar0
      0073BB D0 01            [24]  881 	pop	ar1
      0073BD D0 02            [24]  882 	pop	ar2
      0073BF D0 03            [24]  883 	pop	ar3
      0073C1 D0 04            [24]  884 	pop	ar4
      0073C3 12 48 B2         [24]  885 	lcall	_ak820_outline_0114
      0073C6 EE               [12]  886 	mov	a,r6
      0073C7 12 BB 4C         [24]  887 	lcall	__gptrput
      0073CA A3               [24]  888 	inc	dptr
      0073CB EF               [12]  889 	mov	a,r7
      0073CC 12 BB 4C         [24]  890 	lcall	__gptrput
                                    891 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0073CF 90 08 4A         [24]  892 	mov	dptr,#_process_record_record_10000_633
      0073D2 12 4F 14         [24]  893 	lcall	_ak820_outline_0012
      0073D5 12 7A 1E         [24]  894 	lcall	_ak820_outline_0150
      0073D8 12 48 B2         [24]  895 	lcall	_ak820_outline_0114
      0073DB 12 BB 87         [24]  896 	lcall	__gptrget
      0073DE F8               [12]  897 	mov	r0,a
      0073DF A3               [24]  898 	inc	dptr
      0073E0 12 BB 87         [24]  899 	lcall	__gptrget
      0073E3 F9               [12]  900 	mov	r1,a
      0073E4 90 06 34         [24]  901 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0073E7 EC               [12]  902 	mov	a,r4
      0073E8 F0               [24]  903 	movx	@dptr,a
      0073E9 90 06 35         [24]  904 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0073EC EB               [12]  905 	mov	a,r3
      0073ED F0               [24]  906 	movx	@dptr,a
      0073EE 12 38 B6         [24]  907 	lcall	_ak820_outline_0163
      0073F1 C0 07            [24]  908 	push	ar7
      0073F3 C0 06            [24]  909 	push	ar6
      0073F5 C0 05            [24]  910 	push	ar5
      0073F7 C0 04            [24]  911 	push	ar4
      0073F9 C0 03            [24]  912 	push	ar3
      0073FB 12 46 EC         [24]  913 	lcall	_ak820_oneshot_process
      0073FE E5 82            [12]  914 	mov	a, dpl
      007400 D0 03            [24]  915 	pop	ar3
      007402 D0 04            [24]  916 	pop	ar4
      007404 D0 05            [24]  917 	pop	ar5
      007406 D0 06            [24]  918 	pop	ar6
      007408 D0 07            [24]  919 	pop	ar7
      00740A 70 01            [24]  920 	jnz	00104$
      00740C 22               [24]  921 	ret
      00740D                        922 00104$:
                                    923 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      00740D 12 6F EE         [24]  924 	lcall	_ak820_outline_0059
      007410 C0 04            [24]  925 	push	ar4
      007412 C0 03            [24]  926 	push	ar3
      007414 12 A1 E5         [24]  927 	lcall	_process_record_quantum
      007417 E5 82            [12]  928 	mov	a, dpl
      007419 D0 03            [24]  929 	pop	ar3
      00741B D0 04            [24]  930 	pop	ar4
      00741D 70 0A            [24]  931 	jnz	00106$
                                    932 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00741F 90 05 9C         [24]  933 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007422 EB               [12]  934 	mov	a,r3
      007423 F0               [24]  935 	movx	@dptr,a
      007424 8C 82            [24]  936 	mov	dpl, r4
                                    937 ;	quantum/action.c:352: return;
      007426 02 2E BB         [24]  938 	ljmp	_ak820_oneshot_post
      007429                        939 00106$:
                                    940 ;	quantum/action.c:358: process_record_handler(record);
      007429 90 08 4A         [24]  941 	mov	dptr,#_process_record_record_10000_633
      00742C 12 4E EE         [24]  942 	lcall	_ak820_outline_0001
      00742F C0 04            [24]  943 	push	ar4
      007431 C0 03            [24]  944 	push	ar3
      007433 12 74 4D         [24]  945 	lcall	_process_record_handler
                                    946 ;	quantum/action.c:362: post_process_record_quantum(record);
      007436 90 08 4A         [24]  947 	mov	dptr,#_process_record_record_10000_633
      007439 12 4E EE         [24]  948 	lcall	_ak820_outline_0001
      00743C 12 A1 BA         [24]  949 	lcall	_post_process_record_quantum
      00743F D0 03            [24]  950 	pop	ar3
      007441 D0 04            [24]  951 	pop	ar4
                                    952 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007443 90 05 9C         [24]  953 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007446 EB               [12]  954 	mov	a,r3
      007447 F0               [24]  955 	movx	@dptr,a
      007448 8C 82            [24]  956 	mov	dpl, r4
                                    957 ;	quantum/action.c:366: }
      00744A 02 2E BB         [24]  958 	ljmp	_ak820_oneshot_post
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'process_record_handler'
                                    961 ;------------------------------------------------------------
                                    962 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    963 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    964 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    965 ;------------------------------------------------------------
                                    966 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function process_record_handler
                                    969 ;	-----------------------------------------
      00744D                        970 _process_record_handler:
      00744D 12 43 13         [24]  971 	lcall	_ak820_outline_0036
      007450 90 08 4D         [24]  972 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007453 12 38 1F         [24]  973 	lcall	_ak820_outline_0016
                                    974 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007456 90 08 4D         [24]  975 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007459 12 37 FE         [24]  976 	lcall	_ak820_outline_0007
                                    977 ;	quantum/action.c:379: if (record->keycode) {
      00745C 4C               [12]  978 	orl	a,r4
      00745D 60 19            [24]  979 	jz	00102$
                                    980 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      00745F 12 38 97         [24]  981 	lcall	_ak820_outline_0126
      007462 C0 07            [24]  982 	push	ar7
      007464 C0 06            [24]  983 	push	ar6
      007466 12 97 5C         [24]  984 	lcall	_action_for_keycode
      007469 12 43 6D         [24]  985 	lcall	_ak820_outline_0154
      00746C D0 06            [24]  986 	pop	ar6
      00746E D0 07            [24]  987 	pop	ar7
      007470 90 08 50         [24]  988 	mov	dptr,#_process_record_handler_action_10000_642
      007473 12 38 5E         [24]  989 	lcall	_ak820_outline_0072
      007476 80 2B            [24]  990 	sjmp	00104$
      007478                        991 00102$:
                                    992 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007478 12 79 C7         [24]  993 	lcall	_ak820_outline_0021
      00747B 7A 00            [12]  994 	mov	r2,#0x00
      00747D 12 43 67         [24]  995 	lcall	_ak820_outline_0146
      007480 12 43 01         [24]  996 	lcall	_ak820_outline_0011
      007483 E0               [24]  997 	movx	a,@dptr
      007484 90 09 8E         [24]  998 	mov	dptr,#_ak820_resolve_key_PARM_2
      007487 F0               [24]  999 	movx	@dptr,a
      007488 8D 82            [24] 1000 	mov	dpl, r5
      00748A 8C 83            [24] 1001 	mov	dph, r4
      00748C C0 07            [24] 1002 	push	ar7
      00748E C0 06            [24] 1003 	push	ar6
      007490 12 7D 73         [24] 1004 	lcall	_ak820_resolve_key
      007493 12 97 5C         [24] 1005 	lcall	_action_for_keycode
      007496 12 43 6D         [24] 1006 	lcall	_ak820_outline_0154
      007499 D0 06            [24] 1007 	pop	ar6
      00749B D0 07            [24] 1008 	pop	ar7
      00749D 90 08 50         [24] 1009 	mov	dptr,#_process_record_handler_action_10000_642
      0074A0 12 38 5E         [24] 1010 	lcall	_ak820_outline_0072
                                   1011 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      0074A3                       1012 00104$:
                                   1013 ;	quantum/action.c:403: process_action(record, action);
      0074A3 7D 00            [12] 1014 	mov	r5,#0x00
      0074A5 90 0D C2         [24] 1015 	mov	dptr,#___memcpy_PARM_2
      0074A8 74 50            [12] 1016 	mov	a,#_process_record_handler_action_10000_642
      0074AA F0               [24] 1017 	movx	@dptr,a
      0074AB 74 08            [12] 1018 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      0074AD 12 38 70         [24] 1019 	lcall	_ak820_outline_0094
      0074B0 90 0D C5         [24] 1020 	mov	dptr,#___memcpy_PARM_3
      0074B3 12 4F 59         [24] 1021 	lcall	_ak820_outline_0112
      0074B6 90 08 54         [24] 1022 	mov	dptr,#_process_action_PARM_2
      0074B9 F5 F0            [12] 1023 	mov	b,a
      0074BB C0 07            [24] 1024 	push	ar7
      0074BD C0 06            [24] 1025 	push	ar6
      0074BF C0 05            [24] 1026 	push	ar5
      0074C1 12 BA AE         [24] 1027 	lcall	___memcpy
      0074C4 D0 05            [24] 1028 	pop	ar5
      0074C6 D0 06            [24] 1029 	pop	ar6
      0074C8 D0 07            [24] 1030 	pop	ar7
      0074CA 12 72 13         [24] 1031 	lcall	_ak820_outline_0050
                                   1032 ;	quantum/action.c:404: }
      0074CD 02 74 F3         [24] 1033 	ljmp	_process_action
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'register_mouse'
                                   1036 ;------------------------------------------------------------
                                   1037 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1038 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function register_mouse
                                   1043 ;	-----------------------------------------
      0074D0                       1044 _register_mouse:
      0074D0 E5 82            [12] 1045 	mov	a,dpl
      0074D2 90 08 53         [24] 1046 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      0074D5 F0               [24] 1047 	movx	@dptr,a
                                   1048 ;	quantum/action.c:419: if (pressed) {
      0074D6 90 08 52         [24] 1049 	mov	dptr,#_register_mouse_PARM_2
      0074D9 E0               [24] 1050 	movx	a,@dptr
      0074DA 60 0B            [24] 1051 	jz	00102$
                                   1052 ;	quantum/action.c:420: mousekey_on(mouse_keycode);
      0074DC 90 08 53         [24] 1053 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      0074DF E0               [24] 1054 	movx	a,@dptr
      0074E0 F5 82            [12] 1055 	mov	dpl,a
      0074E2 12 4F B7         [24] 1056 	lcall	_mousekey_on
      0074E5 80 09            [24] 1057 	sjmp	00103$
      0074E7                       1058 00102$:
                                   1059 ;	quantum/action.c:422: mousekey_off(mouse_keycode);
      0074E7 90 08 53         [24] 1060 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      0074EA E0               [24] 1061 	movx	a,@dptr
      0074EB F5 82            [12] 1062 	mov	dpl,a
      0074ED 12 50 2B         [24] 1063 	lcall	_mousekey_off
      0074F0                       1064 00103$:
                                   1065 ;	quantum/action.c:443: mousekey_send();
                                   1066 ;	quantum/action.c:445: }
                                   1067 ;	quantum/action.c:461: }
      0074F0 02 50 8A         [24] 1068 	ljmp	_mousekey_send
                                   1069 ;------------------------------------------------------------
                                   1070 ;Allocation info for local variables in function 'process_action'
                                   1071 ;------------------------------------------------------------
                                   1072 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1073 ;action        Allocated with name '_process_action_PARM_2'
                                   1074 ;record_argument Allocated with name '_process_action_record_argument_10000_657'
                                   1075 ;record        Allocated with name '_process_action_record_10000_658'
                                   1076 ;pressed       Allocated with name '_process_action_pressed_10000_658'
                                   1077 ;mods          Allocated with name '_process_action_mods_10000_658'
                                   1078 ;on            Allocated with name '_process_action_on_40000_680'
                                   1079 ;shift         Allocated with name '_process_action_shift_60000_682'
                                   1080 ;bits          Allocated with name '_process_action_bits_60000_682'
                                   1081 ;mask          Allocated with name '_process_action_mask_60000_682'
                                   1082 ;i             Allocated with name '_process_action_i_110000_706'
                                   1083 ;i             Allocated with name '_process_action_i_110000_710'
                                   1084 ;------------------------------------------------------------
                                   1085 ;	quantum/action.c:467: void process_action(keyrecord_t *record_argument, action_t action) {
                                   1086 ;	-----------------------------------------
                                   1087 ;	 function process_action
                                   1088 ;	-----------------------------------------
      0074F3                       1089 _process_action:
      0074F3 12 43 13         [24] 1090 	lcall	_ak820_outline_0036
      0074F6 90 08 56         [24] 1091 	mov	dptr,#_process_action_record_argument_10000_657
      0074F9 12 38 1F         [24] 1092 	lcall	_ak820_outline_0016
                                   1093 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0074FC 90 08 56         [24] 1094 	mov	dptr,#_process_action_record_argument_10000_657
      0074FF 12 37 F4         [24] 1095 	lcall	_ak820_outline_0005
                                   1096 ;	quantum/action.c:475: pressed = record->event.pressed;
      007502 A3               [24] 1097 	inc	dptr
      007503 A3               [24] 1098 	inc	dptr
      007504 A3               [24] 1099 	inc	dptr
      007505 A3               [24] 1100 	inc	dptr
      007506 A3               [24] 1101 	inc	dptr
      007507 E0               [24] 1102 	movx	a,@dptr
      007508 F5 27            [12] 1103 	mov	_process_action_sloc0_1_0,a
                                   1104 ;	quantum/action.c:499: switch (action.kind.id) {
      00750A 90 08 55         [24] 1105 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00750D E0               [24] 1106 	movx	a,@dptr
      00750E C4               [12] 1107 	swap	a
      00750F 54 0F            [12] 1108 	anl	a,#0x0f
      007511 FD               [12] 1109 	mov  r5,a
      007512 24 F4            [12] 1110 	add	a,#0xff - 0x0b
      007514 50 03            [24] 1111 	jnc	00434$
      007516 02 77 A6         [24] 1112 	ljmp	00181$
      007519                       1113 00434$:
                                   1114 ;	free result
      007519 ED               [12] 1115 	mov	a,r5
      00751A 24 0A            [12] 1116 	add	a,#(00435$-3-.)
      00751C 83               [24] 1117 	movc	a,@a+pc
      00751D F5 82            [12] 1118 	mov	dpl,a
      00751F ED               [12] 1119 	mov	a,r5
      007520 24 10            [12] 1120 	add	a,#(00436$-3-.)
      007522 83               [24] 1121 	movc	a,@a+pc
      007523 F5 83            [12] 1122 	mov	dph,a
      007525 E4               [12] 1123 	clr	a
      007526 73               [24] 1124 	jmp	@a+dptr
      007527                       1125 00435$:
      007527 3F                    1126 	.db	00102$
      007528 3F                    1127 	.db	00102$
      007529 A6                    1128 	.db	00181$
      00752A A6                    1129 	.db	00181$
      00752B C9                    1130 	.db	00123$
      00752C 29                    1131 	.db	00130$
      00752D A6                    1132 	.db	00181$
      00752E A6                    1133 	.db	00181$
      00752F 3B                    1134 	.db	00131$
      007530 0D                    1135 	.db	00147$
      007531 33                    1136 	.db	00152$
      007532 33                    1137 	.db	00152$
      007533                       1138 00436$:
      007533 75                    1139 	.db	00102$>>8
      007534 75                    1140 	.db	00102$>>8
      007535 77                    1141 	.db	00181$>>8
      007536 77                    1142 	.db	00181$>>8
      007537 75                    1143 	.db	00123$>>8
      007538 76                    1144 	.db	00130$>>8
      007539 77                    1145 	.db	00181$>>8
      00753A 77                    1146 	.db	00181$>>8
      00753B 76                    1147 	.db	00131$>>8
      00753C 77                    1148 	.db	00147$>>8
      00753D 77                    1149 	.db	00152$>>8
      00753E 77                    1150 	.db	00152$>>8
                                   1151 ;	quantum/action.c:502: case ACT_RMODS: {
      00753F                       1152 00102$:
                                   1153 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00753F 90 08 55         [24] 1154 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007542 E0               [24] 1155 	movx	a,@dptr
      007543 54 F0            [12] 1156 	anl	a,#0xf0
      007545 70 06            [24] 1157 	jnz	00194$
      007547 12 7A 00         [24] 1158 	lcall	_ak820_outline_0115
      00754A FD               [12] 1159 	mov	r5,a
      00754B 80 07            [24] 1160 	sjmp	00195$
      00754D                       1161 00194$:
      00754D 12 7A 00         [24] 1162 	lcall	_ak820_outline_0115
      007550 C4               [12] 1163 	swap	a
      007551 54 F0            [12] 1164 	anl	a,#0xf0
      007553 FD               [12] 1165 	mov	r5,a
      007554                       1166 00195$:
                                   1167 ;	quantum/action.c:505: if (pressed) {
      007554 E5 27            [12] 1168 	mov	a,_process_action_sloc0_1_0
      007556 60 35            [24] 1169 	jz	00119$
                                   1170 ;	quantum/action.c:506: if (mods) {
      007558 ED               [12] 1171 	mov	a,r5
      007559 60 29            [24] 1172 	jz	00110$
                                   1173 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00755B 12 7A 28         [24] 1174 	lcall	_ak820_outline_0153
      00755E FC               [12] 1175 	mov	r4,a
      00755F BC E0 00         [24] 1176 	cjne	r4,#0xe0,00440$
      007562                       1177 00440$:
      007562 40 07            [24] 1178 	jc	00108$
      007564 12 7A 28         [24] 1179 	lcall	_ak820_outline_0153
      007567 24 18            [12] 1180 	add	a,#0xff - 0xe7
      007569 50 0A            [24] 1181 	jnc	00104$
                                   1182 ;	free result
      00756B                       1183 00108$:
      00756B 7B 54            [12] 1184 	mov	r3,#_process_action_PARM_2
      00756D 7C 08            [12] 1185 	mov	r4,#(_process_action_PARM_2 >> 8)
      00756F 12 33 FC         [24] 1186 	lcall	_ak820_outline_0125
      007572 E0               [24] 1187 	movx	a,@dptr
      007573 70 07            [24] 1188 	jnz	00105$
      007575                       1189 00104$:
                                   1190 ;	quantum/action.c:511: add_owned_mods(mods);
      007575 8D 82            [24] 1191 	mov	dpl, r5
      007577 12 7F 8D         [24] 1192 	lcall	_add_owned_mods
      00757A 80 05            [24] 1193 	sjmp	00106$
      00757C                       1194 00105$:
                                   1195 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      00757C 8D 82            [24] 1196 	mov	dpl, r5
      00757E 12 7F AB         [24] 1197 	lcall	_add_owned_weak_mods
      007581                       1198 00106$:
                                   1199 ;	quantum/action.c:515: send_keyboard_report();
      007581 12 82 CE         [24] 1200 	lcall	_send_keyboard_report
      007584                       1201 00110$:
                                   1202 ;	quantum/action.c:517: register_code(action.key.code);
      007584 12 79 F0         [24] 1203 	lcall	_ak820_outline_0078
      007587 12 77 BD         [24] 1204 	lcall	_register_code
      00758A 02 77 A6         [24] 1205 	ljmp	00181$
      00758D                       1206 00119$:
                                   1207 ;	quantum/action.c:519: unregister_code(action.key.code);
      00758D 12 79 F0         [24] 1208 	lcall	_ak820_outline_0078
      007590 C0 05            [24] 1209 	push	ar5
      007592 12 78 42         [24] 1210 	lcall	_unregister_code
      007595 D0 05            [24] 1211 	pop	ar5
                                   1212 ;	quantum/action.c:520: if (mods) {
      007597 ED               [12] 1213 	mov	a,r5
      007598 70 03            [24] 1214 	jnz	00444$
      00759A 02 77 A6         [24] 1215 	ljmp	00181$
      00759D                       1216 00444$:
                                   1217 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00759D 12 7A 28         [24] 1218 	lcall	_ak820_outline_0153
      0075A0 FC               [12] 1219 	mov	r4,a
      0075A1 BC E0 00         [24] 1220 	cjne	r4,#0xe0,00445$
      0075A4                       1221 00445$:
      0075A4 40 07            [24] 1222 	jc	00115$
      0075A6 12 7A 28         [24] 1223 	lcall	_ak820_outline_0153
      0075A9 24 18            [12] 1224 	add	a,#0xff - 0xe7
      0075AB 50 0A            [24] 1225 	jnc	00111$
                                   1226 ;	free result
      0075AD                       1227 00115$:
      0075AD 7B 54            [12] 1228 	mov	r3,#_process_action_PARM_2
      0075AF 7C 08            [12] 1229 	mov	r4,#(_process_action_PARM_2 >> 8)
      0075B1 12 33 FC         [24] 1230 	lcall	_ak820_outline_0125
      0075B4 E0               [24] 1231 	movx	a,@dptr
      0075B5 70 07            [24] 1232 	jnz	00112$
      0075B7                       1233 00111$:
                                   1234 ;	quantum/action.c:522: del_owned_mods(mods);
      0075B7 8D 82            [24] 1235 	mov	dpl, r5
      0075B9 12 7F 9D         [24] 1236 	lcall	_del_owned_mods
      0075BC 80 05            [24] 1237 	sjmp	00113$
      0075BE                       1238 00112$:
                                   1239 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      0075BE 8D 82            [24] 1240 	mov	dpl, r5
      0075C0 12 7F BB         [24] 1241 	lcall	_del_owned_weak_mods
      0075C3                       1242 00113$:
                                   1243 ;	quantum/action.c:526: send_keyboard_report();
      0075C3 12 82 CE         [24] 1244 	lcall	_send_keyboard_report
                                   1245 ;	quantum/action.c:529: } break;
      0075C6 02 77 A6         [24] 1246 	ljmp	00181$
                                   1247 ;	quantum/action.c:606: case ACT_USAGE:
      0075C9                       1248 00123$:
                                   1249 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0075C9 74 07            [12] 1250 	mov	a,#0x07
      0075CB 12 38 31         [24] 1251 	lcall	_ak820_outline_0022
      0075CE 12 48 26         [24] 1252 	lcall	_ak820_outline_0008
      0075D1 C3               [12] 1253 	clr	c
      0075D2 EC               [12] 1254 	mov	a,r4
      0075D3 94 A5            [12] 1255 	subb	a,#0xa5
      0075D5 ED               [12] 1256 	mov	a,r5
      0075D6 94 00            [12] 1257 	subb	a,#0x00
      0075D8 40 15            [24] 1258 	jc	00125$
      0075DA 74 C2            [12] 1259 	mov	a,#0xc2
      0075DC 9C               [12] 1260 	subb	a,r4
      0075DD E4               [12] 1261 	clr	a
      0075DE 9D               [12] 1262 	subb	a,r5
      0075DF 40 0E            [24] 1263 	jc	00125$
                                   1264 ;	free result
                                   1265 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      0075E1 90 0A B5         [24] 1266 	mov	dptr,#_owned_usage_key_PARM_2
      0075E4 E5 27            [12] 1267 	mov	a,_process_action_sloc0_1_0
      0075E6 F0               [24] 1268 	movx	@dptr,a
      0075E7 8E 82            [24] 1269 	mov	dpl, r6
      0075E9 12 81 79         [24] 1270 	lcall	_owned_usage_key
                                   1271 ;	quantum/action.c:614: break;
      0075EC 02 77 A6         [24] 1272 	ljmp	00181$
      0075EF                       1273 00125$:
                                   1274 ;	quantum/action.c:617: switch (action.usage.page) {
      0075EF 12 79 F7         [24] 1275 	lcall	_ak820_outline_0090
      0075F2 FF               [12] 1276 	mov	r7,a
      0075F3 60 08            [24] 1277 	jz	00127$
      0075F5 BF 01 02         [24] 1278 	cjne	r7,#0x01,00452$
      0075F8 80 19            [24] 1279 	sjmp	00128$
      0075FA                       1280 00452$:
      0075FA 02 77 A6         [24] 1281 	ljmp	00181$
                                   1282 ;	quantum/action.c:618: case PAGE_SYSTEM:
      0075FD                       1283 00127$:
                                   1284 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      0075FD E5 27            [12] 1285 	mov	a,_process_action_sloc0_1_0
      0075FF 60 05            [24] 1286 	jz	00196$
      007601 12 7A 07         [24] 1287 	lcall	_ak820_outline_0132
      007604 80 04            [24] 1288 	sjmp	00197$
      007606                       1289 00196$:
      007606 7E 00            [12] 1290 	mov	r6,#0x00
      007608 7F 00            [12] 1291 	mov	r7,#0x00
      00760A                       1292 00197$:
      00760A 12 38 8C         [24] 1293 	lcall	_ak820_outline_0120
      00760D 12 6F 78         [24] 1294 	lcall	_host_system_send
                                   1295 ;	quantum/action.c:620: break;
      007610 02 77 A6         [24] 1296 	ljmp	00181$
                                   1297 ;	quantum/action.c:621: case PAGE_CONSUMER:
      007613                       1298 00128$:
                                   1299 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      007613 E5 27            [12] 1300 	mov	a,_process_action_sloc0_1_0
      007615 60 05            [24] 1301 	jz	00198$
      007617 12 7A 07         [24] 1302 	lcall	_ak820_outline_0132
      00761A 80 04            [24] 1303 	sjmp	00199$
      00761C                       1304 00198$:
      00761C 7E 00            [12] 1305 	mov	r6,#0x00
      00761E 7F 00            [12] 1306 	mov	r7,#0x00
      007620                       1307 00199$:
      007620 12 38 8C         [24] 1308 	lcall	_ak820_outline_0120
      007623 12 6F A8         [24] 1309 	lcall	_host_consumer_send
                                   1310 ;	quantum/action.c:625: break;
      007626 02 77 A6         [24] 1311 	ljmp	00181$
                                   1312 ;	quantum/action.c:628: case ACT_MOUSEKEY:
      007629                       1313 00130$:
                                   1314 ;	quantum/action.c:629: register_mouse(action.key.code, pressed);
      007629 12 7A 28         [24] 1315 	lcall	_ak820_outline_0153
      00762C FF               [12] 1316 	mov	r7,a
      00762D 90 08 52         [24] 1317 	mov	dptr,#_register_mouse_PARM_2
      007630 E5 27            [12] 1318 	mov	a,_process_action_sloc0_1_0
      007632 F0               [24] 1319 	movx	@dptr,a
      007633 8F 82            [24] 1320 	mov	dpl, r7
      007635 12 74 D0         [24] 1321 	lcall	_register_mouse
                                   1322 ;	quantum/action.c:630: break;
      007638 02 77 A6         [24] 1323 	ljmp	00181$
                                   1324 ;	quantum/action.c:632: case ACT_LAYER: {
      00763B                       1325 00131$:
                                   1326 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      00763B 90 08 55         [24] 1327 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00763E E0               [24] 1328 	movx	a,@dptr
      00763F 54 03            [12] 1329 	anl	a,#0x03
      007641 90 08 59         [24] 1330 	mov	dptr,#_process_action_on_40000_680
      007644 F0               [24] 1331 	movx	@dptr,a
                                   1332 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007645 E0               [24] 1333 	movx	a,@dptr
      007646 FF               [12] 1334 	mov	r7,a
      007647 60 11            [24] 1335 	jz	00200$
      007649 E5 27            [12] 1336 	mov	a,_process_action_sloc0_1_0
      00764B 60 07            [24] 1337 	jz	00202$
      00764D 8F 06            [24] 1338 	mov	ar6,r7
      00764F 53 06 01         [24] 1339 	anl	ar6,#0x01
      007652 80 10            [24] 1340 	sjmp	00201$
      007654                       1341 00202$:
      007654 74 02            [12] 1342 	mov	a,#0x02
      007656 5F               [12] 1343 	anl	a,r7
      007657 FE               [12] 1344 	mov	r6,a
      007658 80 0A            [24] 1345 	sjmp	00201$
      00765A                       1346 00200$:
      00765A E5 27            [12] 1347 	mov	a,_process_action_sloc0_1_0
      00765C B4 01 00         [24] 1348 	cjne	a,#0x01,00457$
      00765F                       1349 00457$:
      00765F 92 1F            [24] 1350 	mov  _process_action_sloc1_1_0,c
      007661 E4               [12] 1351 	clr	a
      007662 33               [12] 1352 	rlc	a
      007663 FE               [12] 1353 	mov	r6,a
      007664                       1354 00201$:
      007664 EE               [12] 1355 	mov	a,r6
      007665 70 03            [24] 1356 	jnz	00458$
      007667 02 77 A6         [24] 1357 	ljmp	00181$
      00766A                       1358 00458$:
                                   1359 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      00766A 12 7A 28         [24] 1360 	lcall	_ak820_outline_0153
      00766D C4               [12] 1361 	swap	a
      00766E 03               [12] 1362 	rr	a
      00766F 54 07            [12] 1363 	anl	a,#0x07
      007671 25 E0            [12] 1364 	add	a,acc
      007673 25 E0            [12] 1365 	add	a,acc
      007675 FF               [12] 1366 	mov	r7,a
                                   1367 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007676 12 7A 28         [24] 1368 	lcall	_ak820_outline_0153
      007679 54 0F            [12] 1369 	anl	a,#0x0f
      00767B FE               [12] 1370 	mov	r6,a
      00767C 8F F0            [24] 1371 	mov	b,r7
      00767E 05 F0            [12] 1372 	inc	b
      007680 EE               [12] 1373 	mov	a,r6
      007681 80 02            [24] 1374 	sjmp	00460$
      007683                       1375 00459$:
      007683 25 E0            [12] 1376 	add	a,acc
      007685                       1377 00460$:
      007685 D5 F0 FB         [24] 1378 	djnz	b,00459$
      007688 FE               [12] 1379 	mov	r6,a
                                   1380 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007689 12 7A 28         [24] 1381 	lcall	_ak820_outline_0153
      00768C 30 E4 11         [24] 1382 	jnb	acc.4,00204$
      00768F 8F F0            [24] 1383 	mov	b,r7
      007691 05 F0            [12] 1384 	inc	b
      007693 74 0F            [12] 1385 	mov	a,#0x0f
      007695 80 02            [24] 1386 	sjmp	00463$
      007697                       1387 00462$:
      007697 25 E0            [12] 1388 	add	a,acc
      007699                       1389 00463$:
      007699 D5 F0 FB         [24] 1390 	djnz	b,00462$
      00769C F4               [12] 1391 	cpl	a
      00769D FF               [12] 1392 	mov	r7,a
      00769E 80 02            [24] 1393 	sjmp	00205$
      0076A0                       1394 00204$:
      0076A0 7F 00            [12] 1395 	mov	r7,#0x00
      0076A2                       1396 00205$:
                                   1397 ;	quantum/action.c:640: bits |= mask;
      0076A2 EE               [12] 1398 	mov	a,r6
      0076A3 42 07            [12] 1399 	orl	ar7,a
                                   1400 ;	quantum/action.c:641: if (!on) {
      0076A5 90 08 59         [24] 1401 	mov	dptr,#_process_action_on_40000_680
      0076A8 E0               [24] 1402 	movx	a,@dptr
      0076A9 70 31            [24] 1403 	jnz	00143$
                                   1404 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      0076AB 12 79 F7         [24] 1405 	lcall	_ak820_outline_0090
      0076AE FE               [12] 1406 	mov	r6,a
      0076AF 2E               [12] 1407 	add	a,r6
                                   1408 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      0076B0 90 76 B4         [24] 1409 	mov	dptr,#00465$
      0076B3 73               [24] 1410 	jmp	@a+dptr
      0076B4                       1411 00465$:
      0076B4 80 06            [24] 1412 	sjmp	00132$
      0076B6 80 0C            [24] 1413 	sjmp	00133$
      0076B8 80 12            [24] 1414 	sjmp	00134$
      0076BA 80 18            [24] 1415 	sjmp	00135$
      0076BC                       1416 00132$:
      0076BC 8F 82            [24] 1417 	mov	dpl, r7
      0076BE 12 7A 81         [24] 1418 	lcall	_default_layer_and
      0076C1 02 77 A6         [24] 1419 	ljmp	00181$
                                   1420 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      0076C4                       1421 00133$:
      0076C4 8F 82            [24] 1422 	mov	dpl, r7
      0076C6 12 7A 70         [24] 1423 	lcall	_default_layer_or
      0076C9 02 77 A6         [24] 1424 	ljmp	00181$
                                   1425 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      0076CC                       1426 00134$:
      0076CC 8F 82            [24] 1427 	mov	dpl, r7
      0076CE 12 7A 97         [24] 1428 	lcall	_default_layer_xor
      0076D1 02 77 A6         [24] 1429 	ljmp	00181$
                                   1430 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      0076D4                       1431 00135$:
      0076D4 8F 82            [24] 1432 	mov	dpl, r7
      0076D6 12 7A 65         [24] 1433 	lcall	_default_layer_set
                                   1434 ;	quantum/action.c:647: }
      0076D9 02 77 A6         [24] 1435 	ljmp	00181$
      0076DC                       1436 00143$:
                                   1437 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      0076DC 12 79 F7         [24] 1438 	lcall	_ak820_outline_0090
      0076DF FE               [12] 1439 	mov	r6,a
      0076E0 2E               [12] 1440 	add	a,r6
                                   1441 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      0076E1 90 76 E5         [24] 1442 	mov	dptr,#00466$
      0076E4 73               [24] 1443 	jmp	@a+dptr
      0076E5                       1444 00466$:
      0076E5 80 06            [24] 1445 	sjmp	00137$
      0076E7 80 0C            [24] 1446 	sjmp	00138$
      0076E9 80 12            [24] 1447 	sjmp	00139$
      0076EB 80 18            [24] 1448 	sjmp	00140$
      0076ED                       1449 00137$:
      0076ED 8F 82            [24] 1450 	mov	dpl, r7
      0076EF 12 7C 1B         [24] 1451 	lcall	_layer_and
      0076F2 02 77 A6         [24] 1452 	ljmp	00181$
                                   1453 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      0076F5                       1454 00138$:
      0076F5 8F 82            [24] 1455 	mov	dpl, r7
      0076F7 12 7C 0A         [24] 1456 	lcall	_layer_or
      0076FA 02 77 A6         [24] 1457 	ljmp	00181$
                                   1458 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      0076FD                       1459 00139$:
      0076FD 8F 82            [24] 1460 	mov	dpl, r7
      0076FF 12 7C 31         [24] 1461 	lcall	_layer_xor
      007702 02 77 A6         [24] 1462 	ljmp	00181$
                                   1463 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      007705                       1464 00140$:
      007705 8F 82            [24] 1465 	mov	dpl, r7
      007707 12 7B A7         [24] 1466 	lcall	_layer_state_set
                                   1467 ;	quantum/action.c:657: break;
      00770A 02 77 A6         [24] 1468 	ljmp	00181$
                                   1469 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      00770D                       1470 00147$:
                                   1471 ;	quantum/action.c:660: if (pressed) {
      00770D E5 27            [12] 1472 	mov	a,_process_action_sloc0_1_0
      00770F 60 11            [24] 1473 	jz	00149$
                                   1474 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      007711 12 7A 00         [24] 1475 	lcall	_ak820_outline_0115
      007714 F5 82            [12] 1476 	mov	dpl,a
      007716 12 7B 07         [24] 1477 	lcall	_layer_hold_on
                                   1478 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      007719 12 79 F0         [24] 1479 	lcall	_ak820_outline_0078
      00771C 12 79 0D         [24] 1480 	lcall	_register_mods
      00771F 02 77 A6         [24] 1481 	ljmp	00181$
      007722                       1482 00149$:
                                   1483 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      007722 12 79 F0         [24] 1484 	lcall	_ak820_outline_0078
      007725 12 79 21         [24] 1485 	lcall	_unregister_mods
                                   1486 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      007728 12 7A 00         [24] 1487 	lcall	_ak820_outline_0115
      00772B F5 82            [12] 1488 	mov	dpl,a
      00772D 12 7B 3F         [24] 1489 	lcall	_layer_hold_off
                                   1490 ;	quantum/action.c:667: break;
      007730 02 77 A6         [24] 1491 	ljmp	00181$
                                   1492 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      007733                       1493 00152$:
                                   1494 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      007733 12 7A 28         [24] 1495 	lcall	_ak820_outline_0153
      007736 FF               [12] 1496 	mov	r7,a
      007737 BF F1 02         [24] 1497 	cjne	r7,#0xf1,00468$
      00773A 80 0A            [24] 1498 	sjmp	00154$
      00773C                       1499 00468$:
      00773C BF F2 02         [24] 1500 	cjne	r7,#0xf2,00469$
      00773F 80 19            [24] 1501 	sjmp	00155$
      007741                       1502 00469$:
                                   1503 ;	quantum/action.c:686: momentary_layer_action:
      007741 BF F3 3B         [24] 1504 	cjne	r7,#0xf3,00160$
      007744 80 28            [24] 1505 	sjmp	00156$
      007746                       1506 00154$:
                                   1507 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007746 E5 27            [12] 1508 	mov	a,_process_action_sloc0_1_0
      007748 60 08            [24] 1509 	jz	00206$
      00774A 12 79 D6         [24] 1510 	lcall	_ak820_outline_0042
      00774D 12 7B 07         [24] 1511 	lcall	_layer_hold_on
      007750 80 54            [24] 1512 	sjmp	00181$
      007752                       1513 00206$:
      007752 12 79 D6         [24] 1514 	lcall	_ak820_outline_0042
      007755 12 7B 3F         [24] 1515 	lcall	_layer_hold_off
                                   1516 ;	quantum/action.c:688: break;
                                   1517 ;	quantum/action.c:689: case OP_OFF_ON:
      007758 80 4C            [24] 1518 	sjmp	00181$
      00775A                       1519 00155$:
                                   1520 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      00775A E5 27            [12] 1521 	mov	a,_process_action_sloc0_1_0
      00775C 60 08            [24] 1522 	jz	00208$
      00775E 12 79 D6         [24] 1523 	lcall	_ak820_outline_0042
      007761 12 7B EC         [24] 1524 	lcall	_layer_off
      007764 80 40            [24] 1525 	sjmp	00181$
      007766                       1526 00208$:
      007766 12 79 D6         [24] 1527 	lcall	_ak820_outline_0042
      007769 12 7B D1         [24] 1528 	lcall	_layer_on
                                   1529 ;	quantum/action.c:691: break;
                                   1530 ;	quantum/action.c:692: case OP_SET_CLEAR:
      00776C 80 38            [24] 1531 	sjmp	00181$
      00776E                       1532 00156$:
                                   1533 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00776E E5 27            [12] 1534 	mov	a,_process_action_sloc0_1_0
      007770 60 08            [24] 1535 	jz	00210$
      007772 12 79 D6         [24] 1536 	lcall	_ak820_outline_0042
      007775 12 7B BB         [24] 1537 	lcall	_layer_move
      007778 80 2C            [24] 1538 	sjmp	00181$
      00777A                       1539 00210$:
      00777A 12 7B B5         [24] 1540 	lcall	_layer_clear
                                   1541 ;	quantum/action.c:694: break;
                                   1542 ;	quantum/action.c:740: default:
      00777D 80 27            [24] 1543 	sjmp	00181$
      00777F                       1544 00160$:
                                   1545 ;	quantum/action.c:747: if (pressed) {
      00777F E5 27            [12] 1546 	mov	a,_process_action_sloc0_1_0
      007781 60 08            [24] 1547 	jz	00163$
                                   1548 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      007783 12 79 F0         [24] 1549 	lcall	_ak820_outline_0078
      007786 12 77 BD         [24] 1550 	lcall	_register_code
                                   1551 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007789 80 1B            [24] 1552 	sjmp	00181$
      00778B                       1553 00163$:
                                   1554 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      00778B 12 7A 28         [24] 1555 	lcall	_ak820_outline_0153
      00778E FF               [12] 1556 	mov	r7,a
      00778F BF 39 0E         [24] 1557 	cjne	r7,#0x39,00175$
                                   1558 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      007792 7F 50            [12] 1559 	mov	r7,#0x50
      007794                       1560 00187$:
      007794 EF               [12] 1561 	mov	a,r7
      007795 60 09            [24] 1562 	jz	00175$
      007797 90 00 01         [24] 1563 	mov	dptr,#0x0001
      00779A 12 5B 4C         [24] 1564 	lcall	_mDelaymS
      00779D 1F               [12] 1565 	dec	r7
                                   1566 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      00779E 80 F4            [24] 1567 	sjmp	00187$
      0077A0                       1568 00175$:
                                   1569 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      0077A0 12 79 F0         [24] 1570 	lcall	_ak820_outline_0078
      0077A3 12 78 42         [24] 1571 	lcall	_unregister_code
                                   1572 ;	quantum/action.c:840: }
      0077A6                       1573 00181$:
                                   1574 ;	quantum/action.c:861: switch (action.kind.id) {
      0077A6 90 08 55         [24] 1575 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077A9 E0               [24] 1576 	movx	a,@dptr
      0077AA C4               [12] 1577 	swap	a
      0077AB 54 0F            [12] 1578 	anl	a,#0x0f
      0077AD FF               [12] 1579 	mov	r7,a
      0077AE BF 08 02         [24] 1580 	cjne	r7,#0x08,00478$
      0077B1 80 03            [24] 1581 	sjmp	00183$
      0077B3                       1582 00478$:
      0077B3 BF 09 06         [24] 1583 	cjne	r7,#0x09,00192$
                                   1584 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      0077B6                       1585 00183$:
                                   1586 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      0077B6 12 6E DD         [24] 1587 	lcall	_host_keyboard_leds
                                   1588 ;	quantum/action.c:872: }
                                   1589 ;	quantum/action.c:925: }
      0077B9 02 9A 11         [24] 1590 	ljmp	_led_set
      0077BC                       1591 00192$:
      0077BC 22               [24] 1592 	ret
                                   1593 ;------------------------------------------------------------
                                   1594 ;Allocation info for local variables in function 'register_code'
                                   1595 ;------------------------------------------------------------
                                   1596 ;code          Allocated with name '_register_code_code_10000_714'
                                   1597 ;------------------------------------------------------------
                                   1598 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1599 ;	-----------------------------------------
                                   1600 ;	 function register_code
                                   1601 ;	-----------------------------------------
      0077BD                       1602 _register_code:
      0077BD E5 82            [12] 1603 	mov	a,dpl
      0077BF 90 08 5A         [24] 1604 	mov	dptr,#_register_code_code_10000_714
      0077C2 F0               [24] 1605 	movx	@dptr,a
                                   1606 ;	quantum/action.c:932: if (code == KC_NO) {
      0077C3 E0               [24] 1607 	movx	a,@dptr
      0077C4 FF               [12] 1608 	mov	r7,a
      0077C5 70 01            [24] 1609 	jnz	00123$
                                   1610 ;	quantum/action.c:933: return;
      0077C7 22               [24] 1611 	ret
      0077C8                       1612 00123$:
                                   1613 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      0077C8 BF 04 00         [24] 1614 	cjne	r7,#0x04,00198$
      0077CB                       1615 00198$:
      0077CB 40 12            [24] 1616 	jc	00119$
      0077CD EF               [12] 1617 	mov	a,r7
      0077CE 24 5B            [12] 1618 	add	a,#0xff - 0xa4
      0077D0 40 0D            [24] 1619 	jc	00119$
                                   1620 ;	free result
                                   1621 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      0077D2 8F 82            [24] 1622 	mov	dpl, r7
      0077D4 12 80 30         [24] 1623 	lcall	_add_owned_key
      0077D7 E5 82            [12] 1624 	mov	a, dpl
      0077D9 70 01            [24] 1625 	jnz	00104$
      0077DB 22               [24] 1626 	ret
      0077DC                       1627 00104$:
                                   1628 ;	quantum/action.c:987: send_keyboard_report();
      0077DC 02 82 CE         [24] 1629 	ljmp	_send_keyboard_report
      0077DF                       1630 00119$:
                                   1631 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      0077DF 12 7A 12         [24] 1632 	lcall	_ak820_outline_0143
      0077E2 BF E0 00         [24] 1633 	cjne	r7,#0xe0,00202$
      0077E5                       1634 00202$:
      0077E5 40 1A            [24] 1635 	jc	00115$
      0077E7 EF               [12] 1636 	mov	a,r7
      0077E8 24 18            [12] 1637 	add	a,#0xff - 0xe7
      0077EA 40 15            [24] 1638 	jc	00115$
                                   1639 ;	free result
                                   1640 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      0077EC 74 07            [12] 1641 	mov	a,#0x07
      0077EE 5F               [12] 1642 	anl	a,r7
      0077EF 12 79 DF         [24] 1643 	lcall	_ak820_outline_0063
      0077F2 80 02            [24] 1644 	sjmp	00206$
      0077F4                       1645 00205$:
      0077F4 25 E0            [12] 1646 	add	a,acc
      0077F6                       1647 00206$:
      0077F6 D5 F0 FB         [24] 1648 	djnz	b,00205$
      0077F9 F5 82            [12] 1649 	mov	dpl,a
      0077FB 12 7F 8D         [24] 1650 	lcall	_add_owned_mods
                                   1651 ;	quantum/action.c:990: send_keyboard_report();
      0077FE 02 82 CE         [24] 1652 	ljmp	_send_keyboard_report
      007801                       1653 00115$:
                                   1654 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007801 12 7A 12         [24] 1655 	lcall	_ak820_outline_0143
      007804 BF A5 00         [24] 1656 	cjne	r7,#0xa5,00207$
      007807                       1657 00207$:
      007807 40 05            [24] 1658 	jc	00113$
      007809 EF               [12] 1659 	mov	a,r7
      00780A 24 58            [12] 1660 	add	a,#0xff - 0xa7
      00780C 50 0D            [24] 1661 	jnc	00108$
                                   1662 ;	free result
      00780E                       1663 00113$:
      00780E 12 7A 12         [24] 1664 	lcall	_ak820_outline_0143
      007811 BF A8 00         [24] 1665 	cjne	r7,#0xa8,00210$
      007814                       1666 00210$:
      007814 40 13            [24] 1667 	jc	00109$
      007816 EF               [12] 1668 	mov	a,r7
      007817 24 3D            [12] 1669 	add	a,#0xff - 0xc2
      007819 40 0E            [24] 1670 	jc	00109$
                                   1671 ;	free result
      00781B                       1672 00108$:
                                   1673 ;	quantum/action.c:995: owned_usage_key(code, true);
      00781B 12 7A 12         [24] 1674 	lcall	_ak820_outline_0143
      00781E 90 0A B5         [24] 1675 	mov	dptr,#_owned_usage_key_PARM_2
      007821 74 01            [12] 1676 	mov	a,#0x01
      007823 F0               [24] 1677 	movx	@dptr,a
      007824 8F 82            [24] 1678 	mov	dpl, r7
      007826 02 81 79         [24] 1679 	ljmp	_owned_usage_key
      007829                       1680 00109$:
                                   1681 ;	quantum/action.c:1002: } else if (IS_MOUSE_KEYCODE(code)) {
      007829 12 7A 12         [24] 1682 	lcall	_ak820_outline_0143
      00782C BF CD 00         [24] 1683 	cjne	r7,#0xcd,00213$
      00782F                       1684 00213$:
      00782F 40 10            [24] 1685 	jc	00125$
      007831 EF               [12] 1686 	mov	a,r7
      007832 24 20            [12] 1687 	add	a,#0xff - 0xdf
      007834 40 0B            [24] 1688 	jc	00125$
                                   1689 ;	free result
                                   1690 ;	quantum/action.c:1003: register_mouse(code, true);
      007836 90 08 52         [24] 1691 	mov	dptr,#_register_mouse_PARM_2
      007839 74 01            [12] 1692 	mov	a,#0x01
      00783B F0               [24] 1693 	movx	@dptr,a
      00783C 8F 82            [24] 1694 	mov	dpl, r7
                                   1695 ;	quantum/action.c:1005: }
      00783E 02 74 D0         [24] 1696 	ljmp	_register_mouse
      007841                       1697 00125$:
      007841 22               [24] 1698 	ret
                                   1699 ;------------------------------------------------------------
                                   1700 ;Allocation info for local variables in function 'unregister_code'
                                   1701 ;------------------------------------------------------------
                                   1702 ;code          Allocated with name '_unregister_code_code_10000_728'
                                   1703 ;------------------------------------------------------------
                                   1704 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1705 ;	-----------------------------------------
                                   1706 ;	 function unregister_code
                                   1707 ;	-----------------------------------------
      007842                       1708 _unregister_code:
      007842 E5 82            [12] 1709 	mov	a,dpl
      007844 90 08 5B         [24] 1710 	mov	dptr,#_unregister_code_code_10000_728
      007847 F0               [24] 1711 	movx	@dptr,a
                                   1712 ;	quantum/action.c:1012: if (code == KC_NO) {
      007848 E0               [24] 1713 	movx	a,@dptr
      007849 FF               [12] 1714 	mov	r7,a
      00784A 70 01            [24] 1715 	jnz	00121$
                                   1716 ;	quantum/action.c:1013: return;
      00784C 22               [24] 1717 	ret
      00784D                       1718 00121$:
                                   1719 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      00784D BF 04 00         [24] 1720 	cjne	r7,#0x04,00196$
      007850                       1721 00196$:
      007850 40 12            [24] 1722 	jc	00117$
      007852 EF               [12] 1723 	mov	a,r7
      007853 24 5B            [12] 1724 	add	a,#0xff - 0xa4
      007855 40 0D            [24] 1725 	jc	00117$
                                   1726 ;	free result
                                   1727 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      007857 8F 82            [24] 1728 	mov	dpl, r7
      007859 12 80 AD         [24] 1729 	lcall	_del_owned_key
      00785C E5 82            [12] 1730 	mov	a, dpl
      00785E 70 01            [24] 1731 	jnz	00102$
      007860 22               [24] 1732 	ret
      007861                       1733 00102$:
                                   1734 ;	quantum/action.c:1054: send_keyboard_report();
      007861 02 82 CE         [24] 1735 	ljmp	_send_keyboard_report
      007864                       1736 00117$:
                                   1737 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      007864 12 7A 18         [24] 1738 	lcall	_ak820_outline_0144
      007867 BF E0 00         [24] 1739 	cjne	r7,#0xe0,00200$
      00786A                       1740 00200$:
      00786A 40 1A            [24] 1741 	jc	00113$
      00786C EF               [12] 1742 	mov	a,r7
      00786D 24 18            [12] 1743 	add	a,#0xff - 0xe7
      00786F 40 15            [24] 1744 	jc	00113$
                                   1745 ;	free result
                                   1746 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      007871 74 07            [12] 1747 	mov	a,#0x07
      007873 5F               [12] 1748 	anl	a,r7
      007874 12 79 DF         [24] 1749 	lcall	_ak820_outline_0063
      007877 80 02            [24] 1750 	sjmp	00204$
      007879                       1751 00203$:
      007879 25 E0            [12] 1752 	add	a,acc
      00787B                       1753 00204$:
      00787B D5 F0 FB         [24] 1754 	djnz	b,00203$
      00787E F5 82            [12] 1755 	mov	dpl,a
      007880 12 7F 9D         [24] 1756 	lcall	_del_owned_mods
                                   1757 ;	quantum/action.c:1057: send_keyboard_report();
      007883 02 82 CE         [24] 1758 	ljmp	_send_keyboard_report
      007886                       1759 00113$:
                                   1760 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007886 12 7A 18         [24] 1761 	lcall	_ak820_outline_0144
      007889 BF A5 00         [24] 1762 	cjne	r7,#0xa5,00205$
      00788C                       1763 00205$:
      00788C 40 05            [24] 1764 	jc	00111$
      00788E EF               [12] 1765 	mov	a,r7
      00788F 24 58            [12] 1766 	add	a,#0xff - 0xa7
      007891 50 0D            [24] 1767 	jnc	00106$
                                   1768 ;	free result
      007893                       1769 00111$:
      007893 12 7A 18         [24] 1770 	lcall	_ak820_outline_0144
      007896 BF A8 00         [24] 1771 	cjne	r7,#0xa8,00208$
      007899                       1772 00208$:
      007899 40 11            [24] 1773 	jc	00107$
      00789B EF               [12] 1774 	mov	a,r7
      00789C 24 3D            [12] 1775 	add	a,#0xff - 0xc2
      00789E 40 0C            [24] 1776 	jc	00107$
                                   1777 ;	free result
      0078A0                       1778 00106$:
                                   1779 ;	quantum/action.c:1062: owned_usage_key(code, false);
      0078A0 12 7A 18         [24] 1780 	lcall	_ak820_outline_0144
      0078A3 90 0A B5         [24] 1781 	mov	dptr,#_owned_usage_key_PARM_2
      0078A6 12 7A 32         [24] 1782 	lcall	_ak820_outline_0191
      0078A9 02 81 79         [24] 1783 	ljmp	_owned_usage_key
      0078AC                       1784 00107$:
                                   1785 ;	quantum/action.c:1069: } else if (IS_MOUSE_KEYCODE(code)) {
      0078AC 12 7A 18         [24] 1786 	lcall	_ak820_outline_0144
      0078AF BF CD 00         [24] 1787 	cjne	r7,#0xcd,00211$
      0078B2                       1788 00211$:
      0078B2 40 0E            [24] 1789 	jc	00123$
      0078B4 EF               [12] 1790 	mov	a,r7
      0078B5 24 20            [12] 1791 	add	a,#0xff - 0xdf
      0078B7 40 09            [24] 1792 	jc	00123$
                                   1793 ;	free result
                                   1794 ;	quantum/action.c:1070: register_mouse(code, false);
      0078B9 90 08 52         [24] 1795 	mov	dptr,#_register_mouse_PARM_2
      0078BC 12 7A 32         [24] 1796 	lcall	_ak820_outline_0191
                                   1797 ;	quantum/action.c:1072: }
      0078BF 02 74 D0         [24] 1798 	ljmp	_register_mouse
      0078C2                       1799 00123$:
      0078C2 22               [24] 1800 	ret
                                   1801 ;------------------------------------------------------------
                                   1802 ;Allocation info for local variables in function 'tap_code_delay'
                                   1803 ;------------------------------------------------------------
                                   1804 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1805 ;code          Allocated with name '_tap_code_delay_code_10000_741'
                                   1806 ;i             Allocated with name '_tap_code_delay_i_20000_743'
                                   1807 ;i             Allocated with name '_tap_code_delay_i_50000_746'
                                   1808 ;------------------------------------------------------------
                                   1809 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1810 ;	-----------------------------------------
                                   1811 ;	 function tap_code_delay
                                   1812 ;	-----------------------------------------
      0078C3                       1813 _tap_code_delay:
      0078C3 E5 82            [12] 1814 	mov	a,dpl
      0078C5 90 08 5E         [24] 1815 	mov	dptr,#_tap_code_delay_code_10000_741
      0078C8 F0               [24] 1816 	movx	@dptr,a
                                   1817 ;	quantum/action.c:1080: register_code(code);
      0078C9 E0               [24] 1818 	movx	a,@dptr
      0078CA FF               [12] 1819 	mov	r7,a
      0078CB F5 82            [12] 1820 	mov	dpl,a
      0078CD C0 07            [24] 1821 	push	ar7
      0078CF 12 77 BD         [24] 1822 	lcall	_register_code
      0078D2 D0 07            [24] 1823 	pop	ar7
                                   1824 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      0078D4 90 08 5C         [24] 1825 	mov	dptr,#_tap_code_delay_PARM_2
      0078D7 12 38 64         [24] 1826 	lcall	_ak820_outline_0080
      0078DA                       1827 00110$:
      0078DA ED               [12] 1828 	mov	a,r5
      0078DB 4E               [12] 1829 	orl	a,r6
      0078DC 60 0D            [24] 1830 	jz	00105$
                                   1831 ;	quantum/action.c:1082: wait_ms(1);
      0078DE 90 00 01         [24] 1832 	mov	dptr,#0x0001
      0078E1 12 5B 4C         [24] 1833 	lcall	_mDelaymS
                                   1834 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      0078E4 1D               [12] 1835 	dec	r5
      0078E5 BD FF 01         [24] 1836 	cjne	r5,#0xff,00141$
      0078E8 1E               [12] 1837 	dec	r6
      0078E9                       1838 00141$:
      0078E9 80 EF            [24] 1839 	sjmp	00110$
      0078EB                       1840 00105$:
                                   1841 ;	quantum/action.c:1084: unregister_code(code);
      0078EB 8F 82            [24] 1842 	mov	dpl, r7
                                   1843 ;	quantum/action.c:1085: }
      0078ED 02 78 42         [24] 1844 	ljmp	_unregister_code
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'tap_code'
                                   1847 ;------------------------------------------------------------
                                   1848 ;code          Allocated with name '_tap_code_code_10000_748'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function tap_code
                                   1853 ;	-----------------------------------------
      0078F0                       1854 _tap_code:
      0078F0 E5 82            [12] 1855 	mov	a,dpl
      0078F2 90 08 5F         [24] 1856 	mov	dptr,#_tap_code_code_10000_748
      0078F5 F0               [24] 1857 	movx	@dptr,a
                                   1858 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0078F6 E0               [24] 1859 	movx	a,@dptr
      0078F7 FF               [12] 1860 	mov	r7,a
      0078F8 BF 39 04         [24] 1861 	cjne	r7,#0x39,00103$
      0078FB 7E 50            [12] 1862 	mov	r6,#0x50
      0078FD 80 02            [24] 1863 	sjmp	00104$
      0078FF                       1864 00103$:
      0078FF 7E 00            [12] 1865 	mov	r6,#0x00
      007901                       1866 00104$:
      007901 90 08 5C         [24] 1867 	mov	dptr,#_tap_code_delay_PARM_2
      007904 EE               [12] 1868 	mov	a,r6
      007905 12 38 9C         [24] 1869 	lcall	_ak820_outline_0136
      007908 8F 82            [24] 1870 	mov	dpl, r7
                                   1871 ;	quantum/action.c:1093: }
      00790A 02 78 C3         [24] 1872 	ljmp	_tap_code_delay
                                   1873 ;------------------------------------------------------------
                                   1874 ;Allocation info for local variables in function 'register_mods'
                                   1875 ;------------------------------------------------------------
                                   1876 ;mods          Allocated with name '_register_mods_mods_10000_750'
                                   1877 ;------------------------------------------------------------
                                   1878 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1879 ;	-----------------------------------------
                                   1880 ;	 function register_mods
                                   1881 ;	-----------------------------------------
      00790D                       1882 _register_mods:
      00790D E5 82            [12] 1883 	mov	a,dpl
      00790F 90 08 60         [24] 1884 	mov	dptr,#_register_mods_mods_10000_750
      007912 F0               [24] 1885 	movx	@dptr,a
                                   1886 ;	quantum/action.c:1100: if (mods) {
      007913 E0               [24] 1887 	movx	a,@dptr
      007914 FF               [12] 1888 	mov	r7,a
      007915 E0               [24] 1889 	movx	a,@dptr
      007916 60 08            [24] 1890 	jz	00103$
                                   1891 ;	quantum/action.c:1101: add_owned_mods(mods);
      007918 8F 82            [24] 1892 	mov	dpl, r7
      00791A 12 7F 8D         [24] 1893 	lcall	_add_owned_mods
                                   1894 ;	quantum/action.c:1102: send_keyboard_report();
                                   1895 ;	quantum/action.c:1104: }
      00791D 02 82 CE         [24] 1896 	ljmp	_send_keyboard_report
      007920                       1897 00103$:
      007920 22               [24] 1898 	ret
                                   1899 ;------------------------------------------------------------
                                   1900 ;Allocation info for local variables in function 'unregister_mods'
                                   1901 ;------------------------------------------------------------
                                   1902 ;mods          Allocated with name '_unregister_mods_mods_10000_754'
                                   1903 ;------------------------------------------------------------
                                   1904 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1905 ;	-----------------------------------------
                                   1906 ;	 function unregister_mods
                                   1907 ;	-----------------------------------------
      007921                       1908 _unregister_mods:
      007921 E5 82            [12] 1909 	mov	a,dpl
      007923 90 08 61         [24] 1910 	mov	dptr,#_unregister_mods_mods_10000_754
      007926 F0               [24] 1911 	movx	@dptr,a
                                   1912 ;	quantum/action.c:1111: if (mods) {
      007927 E0               [24] 1913 	movx	a,@dptr
      007928 FF               [12] 1914 	mov	r7,a
      007929 E0               [24] 1915 	movx	a,@dptr
      00792A 60 08            [24] 1916 	jz	00103$
                                   1917 ;	quantum/action.c:1112: del_owned_mods(mods);
      00792C 8F 82            [24] 1918 	mov	dpl, r7
      00792E 12 7F 9D         [24] 1919 	lcall	_del_owned_mods
                                   1920 ;	quantum/action.c:1113: send_keyboard_report();
                                   1921 ;	quantum/action.c:1115: }
      007931 02 82 CE         [24] 1922 	ljmp	_send_keyboard_report
      007934                       1923 00103$:
      007934 22               [24] 1924 	ret
                                   1925 ;------------------------------------------------------------
                                   1926 ;Allocation info for local variables in function 'register_weak_mods'
                                   1927 ;------------------------------------------------------------
                                   1928 ;mods          Allocated with name '_register_weak_mods_mods_10000_758'
                                   1929 ;------------------------------------------------------------
                                   1930 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1931 ;	-----------------------------------------
                                   1932 ;	 function register_weak_mods
                                   1933 ;	-----------------------------------------
      007935                       1934 _register_weak_mods:
      007935 E5 82            [12] 1935 	mov	a,dpl
      007937 90 08 62         [24] 1936 	mov	dptr,#_register_weak_mods_mods_10000_758
      00793A F0               [24] 1937 	movx	@dptr,a
                                   1938 ;	quantum/action.c:1122: if (mods) {
      00793B E0               [24] 1939 	movx	a,@dptr
      00793C FF               [12] 1940 	mov	r7,a
      00793D E0               [24] 1941 	movx	a,@dptr
      00793E 60 08            [24] 1942 	jz	00103$
                                   1943 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      007940 8F 82            [24] 1944 	mov	dpl, r7
      007942 12 7F AB         [24] 1945 	lcall	_add_owned_weak_mods
                                   1946 ;	quantum/action.c:1124: send_keyboard_report();
                                   1947 ;	quantum/action.c:1126: }
      007945 02 82 CE         [24] 1948 	ljmp	_send_keyboard_report
      007948                       1949 00103$:
      007948 22               [24] 1950 	ret
                                   1951 ;------------------------------------------------------------
                                   1952 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1953 ;------------------------------------------------------------
                                   1954 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_762'
                                   1955 ;------------------------------------------------------------
                                   1956 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1957 ;	-----------------------------------------
                                   1958 ;	 function unregister_weak_mods
                                   1959 ;	-----------------------------------------
      007949                       1960 _unregister_weak_mods:
      007949 E5 82            [12] 1961 	mov	a,dpl
      00794B 90 08 63         [24] 1962 	mov	dptr,#_unregister_weak_mods_mods_10000_762
      00794E F0               [24] 1963 	movx	@dptr,a
                                   1964 ;	quantum/action.c:1133: if (mods) {
      00794F E0               [24] 1965 	movx	a,@dptr
      007950 FF               [12] 1966 	mov	r7,a
      007951 E0               [24] 1967 	movx	a,@dptr
      007952 60 08            [24] 1968 	jz	00103$
                                   1969 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      007954 8F 82            [24] 1970 	mov	dpl, r7
      007956 12 7F BB         [24] 1971 	lcall	_del_owned_weak_mods
                                   1972 ;	quantum/action.c:1135: send_keyboard_report();
                                   1973 ;	quantum/action.c:1137: }
      007959 02 82 CE         [24] 1974 	ljmp	_send_keyboard_report
      00795C                       1975 00103$:
      00795C 22               [24] 1976 	ret
                                   1977 ;------------------------------------------------------------
                                   1978 ;Allocation info for local variables in function 'clear_keyboard'
                                   1979 ;------------------------------------------------------------
                                   1980 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1981 ;	-----------------------------------------
                                   1982 ;	 function clear_keyboard
                                   1983 ;	-----------------------------------------
      00795D                       1984 _clear_keyboard:
                                   1985 ;	quantum/action.c:1144: clear_mods();
      00795D 12 83 49         [24] 1986 	lcall	_clear_mods
                                   1987 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   1988 ;	quantum/action.c:1146: }
      007960 02 79 63         [24] 1989 	ljmp	_clear_keyboard_but_mods
                                   1990 ;------------------------------------------------------------
                                   1991 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1992 ;------------------------------------------------------------
                                   1993 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   1994 ;	-----------------------------------------
                                   1995 ;	 function clear_keyboard_but_mods
                                   1996 ;	-----------------------------------------
      007963                       1997 _clear_keyboard_but_mods:
                                   1998 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007963 90 0D E7         [24] 1999 	mov	dptr,#_actual_keyboard_report
      007966 75 F0 00         [24] 2000 	mov	b, #0x00
      007969 12 71 B4         [24] 2001 	lcall	_clear_keys_from_report
                                   2002 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   2003 ;	quantum/action.c:1155: }
      00796C 02 79 6F         [24] 2004 	ljmp	_clear_keyboard_but_mods_and_keys
                                   2005 ;------------------------------------------------------------
                                   2006 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2007 ;------------------------------------------------------------
                                   2008 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   2009 ;	-----------------------------------------
                                   2010 ;	 function clear_keyboard_but_mods_and_keys
                                   2011 ;	-----------------------------------------
      00796F                       2012 _clear_keyboard_but_mods_and_keys:
                                   2013 ;	quantum/action.c:1163: ak820_tapping_cancel();
      00796F 12 46 CB         [24] 2014 	lcall	_ak820_tapping_cancel
                                   2015 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      007972 12 2E F0         [24] 2016 	lcall	_ak820_oneshot_cancel
                                   2017 ;	quantum/action.c:1174: ak820_combo_cancel();
      007975 12 35 70         [24] 2018 	lcall	_ak820_combo_cancel
                                   2019 ;	quantum/action.c:1177: repeat_key_cancel();
      007978 12 A4 02         [24] 2020 	lcall	_repeat_key_cancel
                                   2021 ;	quantum/action.c:1179: clear_owned_mods();
      00797B 12 7F CB         [24] 2022 	lcall	_clear_owned_mods
                                   2023 ;	quantum/action.c:1180: clear_owned_keys();
      00797E 12 80 03         [24] 2024 	lcall	_clear_owned_keys
                                   2025 ;	quantum/action.c:1181: clear_owned_usages();
      007981 12 81 41         [24] 2026 	lcall	_clear_owned_usages
                                   2027 ;	quantum/action.c:1182: layer_hold_clear();
      007984 12 7B 78         [24] 2028 	lcall	_layer_hold_clear
                                   2029 ;	quantum/action.c:1184: clear_macro_tri_layer();
      007987 12 9E C6         [24] 2030 	lcall	_clear_macro_tri_layer
                                   2031 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00798A 90 0D E7         [24] 2032 	mov	dptr,#_actual_keyboard_report
      00798D 75 F0 00         [24] 2033 	mov	b, #0x00
      007990 12 71 B4         [24] 2034 	lcall	_clear_keys_from_report
                                   2035 ;	quantum/action.c:1189: host_system_send(0);
      007993 90 00 00         [24] 2036 	mov	dptr,#0x0000
      007996 12 6F 78         [24] 2037 	lcall	_host_system_send
                                   2038 ;	quantum/action.c:1190: host_consumer_send(0);
      007999 90 00 00         [24] 2039 	mov	dptr,#0x0000
      00799C 12 6F A8         [24] 2040 	lcall	_host_consumer_send
                                   2041 ;	quantum/action.c:1192: clear_weak_mods();
      00799F 12 83 7E         [24] 2042 	lcall	_clear_weak_mods
                                   2043 ;	quantum/action.c:1193: send_keyboard_report();
      0079A2 12 82 CE         [24] 2044 	lcall	_send_keyboard_report
                                   2045 ;	quantum/action.c:1195: mousekey_clear();
      0079A5 12 51 C2         [24] 2046 	lcall	_mousekey_clear
                                   2047 ;	quantum/action.c:1196: mousekey_send();
                                   2048 ;	quantum/action.c:1201: }
      0079A8 02 50 8A         [24] 2049 	ljmp	_mousekey_send
                                   2050 ;------------------------------------------------------------
                                   2051 ;Allocation info for local variables in function 'is_tap_record'
                                   2052 ;------------------------------------------------------------
                                   2053 ;record        Allocated with name '_is_tap_record_record_10000_778'
                                   2054 ;action        Allocated with name '_is_tap_record_action_10001_782'
                                   2055 ;------------------------------------------------------------
                                   2056 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   2057 ;	-----------------------------------------
                                   2058 	.area CSEG    (CODE)
                                   2059 	.area CONST   (CODE)
                                   2060 	.area XINIT   (CODE)
      00C3CF                       2061 __xinit__disable_action_cache:
      00C3CF 00                    2062 	.db #0x00	;  0
                                   2063 	.area CABS    (ABS,CODE)
                                   2064 
                                   2065 ; Experimental exact instruction outlining.
                                   2066 	.globl _ak820_outline_0001
                                   2067 	.globl _ak820_outline_0005
                                   2068 	.globl _ak820_outline_0007
                                   2069 	.globl _ak820_outline_0008
                                   2070 	.globl _ak820_outline_0011
                                   2071 	.globl _ak820_outline_0012
                                   2072 	.globl _ak820_outline_0013
                                   2073 	.globl _ak820_outline_0014
                                   2074 	.globl _ak820_outline_0016
                                   2075 	.globl _ak820_outline_0021
                                   2076 	.globl _ak820_outline_0022
                                   2077 	.globl _ak820_outline_0034
                                   2078 	.globl _ak820_outline_0036
                                   2079 	.globl _ak820_outline_0042
                                   2080 	.globl _ak820_outline_0050
                                   2081 	.globl _ak820_outline_0059
                                   2082 	.globl _ak820_outline_0063
                                   2083 	.globl _ak820_outline_0071
                                   2084 	.globl _ak820_outline_0072
                                   2085 	.globl _ak820_outline_0078
                                   2086 	.globl _ak820_outline_0080
                                   2087 	.globl _ak820_outline_0090
                                   2088 	.globl _ak820_outline_0094
                                   2089 	.globl _ak820_outline_0109
                                   2090 	.globl _ak820_outline_0110
                                   2091 	.globl _ak820_outline_0112
                                   2092 	.globl _ak820_outline_0114
                                   2093 	.globl _ak820_outline_0115
                                   2094 	.globl _ak820_outline_0120
                                   2095 	.globl _ak820_outline_0125
                                   2096 	.globl _ak820_outline_0126
                                   2097 	.globl _ak820_outline_0132
                                   2098 	.globl _ak820_outline_0135
                                   2099 	.globl _ak820_outline_0136
                                   2100 	.globl _ak820_outline_0143
                                   2101 	.globl _ak820_outline_0144
                                   2102 	.globl _ak820_outline_0146
                                   2103 	.globl _ak820_outline_0150
                                   2104 	.globl _ak820_outline_0153
                                   2105 	.globl _ak820_outline_0154
                                   2106 	.globl _ak820_outline_0163
                                   2107 	.globl _ak820_outline_0184
                                   2108 	.globl _ak820_outline_0189
                                   2109 	.globl _ak820_outline_0191
                                   2110 
                                   2111 	.area CSEG (CODE)
                                   2112 ; function ak820_outline_0013
      0079AB                       2113 _ak820_outline_0013:
      0079AB 2D               [12] 2114 	add	a,r5
      0079AC F9               [12] 2115 	mov	r1,a
      0079AD E4               [12] 2116 	clr	a
      0079AE 3E               [12] 2117 	addc	a,r6
      0079AF FA               [12] 2118 	mov	r2,a
      0079B0 8F 03            [24] 2119 	mov	ar3,r7
      0079B2 89 82            [24] 2120 	mov	dpl,r1
      0079B4 8A 83            [24] 2121 	mov	dph,r2
      0079B6 8B F0            [24] 2122 	mov	b,r3
      0079B8 22               [24] 2123 	ret
                                   2124 
                                   2125 	.area CSEG (CODE)
                                   2126 ; function ak820_outline_0014
      0079B9                       2127 _ak820_outline_0014:
      0079B9 2D               [12] 2128 	add	a,r5
      0079BA FA               [12] 2129 	mov	r2,a
      0079BB E4               [12] 2130 	clr	a
      0079BC 3E               [12] 2131 	addc	a,r6
      0079BD FB               [12] 2132 	mov	r3,a
      0079BE 8F 04            [24] 2133 	mov	ar4,r7
      0079C0 8A 82            [24] 2134 	mov	dpl,r2
      0079C2 8B 83            [24] 2135 	mov	dph,r3
      0079C4 8C F0            [24] 2136 	mov	b,r4
      0079C6 22               [24] 2137 	ret
                                   2138 
                                   2139 	.area CSEG (CODE)
                                   2140 ; function ak820_outline_0021
      0079C7                       2141 _ak820_outline_0021:
      0079C7 8E 82            [24] 2142 	mov	dpl,r6
      0079C9 8F 83            [24] 2143 	mov	dph,r7
      0079CB A3               [24] 2144 	inc	dptr
      0079CC E0               [24] 2145 	movx	a,@dptr
      0079CD FC               [12] 2146 	mov	r4,a
      0079CE 7D 00            [12] 2147 	mov	r5,#0x00
      0079D0 8E 82            [24] 2148 	mov	dpl,r6
      0079D2 8F 83            [24] 2149 	mov	dph,r7
      0079D4 E0               [24] 2150 	movx	a,@dptr
      0079D5 22               [24] 2151 	ret
                                   2152 
                                   2153 	.area CSEG (CODE)
                                   2154 ; function ak820_outline_0042
      0079D6                       2155 _ak820_outline_0042:
      0079D6 90 08 55         [24] 2156 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0079D9 E0               [24] 2157 	movx	a,@dptr
      0079DA 54 1F            [12] 2158 	anl	a,#0x1f
      0079DC F5 82            [12] 2159 	mov	dpl,a
      0079DE 22               [24] 2160 	ret
                                   2161 
                                   2162 	.area CSEG (CODE)
                                   2163 ; function ak820_outline_0063
      0079DF                       2164 _ak820_outline_0063:
      0079DF F5 F0            [12] 2165 	mov	b,a
      0079E1 05 F0            [12] 2166 	inc	b
      0079E3 74 01            [12] 2167 	mov	a,#0x01
      0079E5 22               [24] 2168 	ret
                                   2169 
                                   2170 	.area CSEG (CODE)
                                   2171 ; function ak820_outline_0071
      0079E6                       2172 _ak820_outline_0071:
      0079E6 90 0D C5         [24] 2173 	mov	dptr,#___memcpy_PARM_3
      0079E9 74 06            [12] 2174 	mov	a,#0x06
      0079EB F0               [24] 2175 	movx	@dptr,a
      0079EC E4               [12] 2176 	clr	a
      0079ED A3               [24] 2177 	inc	dptr
      0079EE F0               [24] 2178 	movx	@dptr,a
      0079EF 22               [24] 2179 	ret
                                   2180 
                                   2181 	.area CSEG (CODE)
                                   2182 ; function ak820_outline_0078
      0079F0                       2183 _ak820_outline_0078:
      0079F0 90 08 54         [24] 2184 	mov	dptr,#_process_action_PARM_2
      0079F3 E0               [24] 2185 	movx	a,@dptr
      0079F4 F5 82            [12] 2186 	mov	dpl,a
      0079F6 22               [24] 2187 	ret
                                   2188 
                                   2189 	.area CSEG (CODE)
                                   2190 ; function ak820_outline_0090
      0079F7                       2191 _ak820_outline_0090:
      0079F7 90 08 55         [24] 2192 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0079FA E0               [24] 2193 	movx	a,@dptr
      0079FB 03               [12] 2194 	rr	a
      0079FC 03               [12] 2195 	rr	a
      0079FD 54 03            [12] 2196 	anl	a,#0x03
      0079FF 22               [24] 2197 	ret
                                   2198 
                                   2199 	.area CSEG (CODE)
                                   2200 ; function ak820_outline_0115
      007A00                       2201 _ak820_outline_0115:
      007A00 90 08 55         [24] 2202 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A03 E0               [24] 2203 	movx	a,@dptr
      007A04 54 0F            [12] 2204 	anl	a,#0x0f
      007A06 22               [24] 2205 	ret
                                   2206 
                                   2207 	.area CSEG (CODE)
                                   2208 ; function ak820_outline_0132
      007A07                       2209 _ak820_outline_0132:
      007A07 90 08 54         [24] 2210 	mov	dptr,#_process_action_PARM_2
      007A0A E0               [24] 2211 	movx	a,@dptr
      007A0B FE               [12] 2212 	mov	r6,a
      007A0C A3               [24] 2213 	inc	dptr
      007A0D E0               [24] 2214 	movx	a,@dptr
      007A0E 54 03            [12] 2215 	anl	a,#0x03
      007A10 FF               [12] 2216 	mov	r7,a
      007A11 22               [24] 2217 	ret
                                   2218 
                                   2219 	.area CSEG (CODE)
                                   2220 ; function ak820_outline_0143
      007A12                       2221 _ak820_outline_0143:
      007A12 90 08 5A         [24] 2222 	mov	dptr,#_register_code_code_10000_714
      007A15 E0               [24] 2223 	movx	a,@dptr
      007A16 FF               [12] 2224 	mov	r7,a
      007A17 22               [24] 2225 	ret
                                   2226 
                                   2227 	.area CSEG (CODE)
                                   2228 ; function ak820_outline_0144
      007A18                       2229 _ak820_outline_0144:
      007A18 90 08 5B         [24] 2230 	mov	dptr,#_unregister_code_code_10000_728
      007A1B E0               [24] 2231 	movx	a,@dptr
      007A1C FF               [12] 2232 	mov	r7,a
      007A1D 22               [24] 2233 	ret
                                   2234 
                                   2235 	.area CSEG (CODE)
                                   2236 ; function ak820_outline_0150
      007A1E                       2237 _ak820_outline_0150:
      007A1E 74 07            [12] 2238 	mov	a,#0x07
      007A20 2D               [12] 2239 	add	a,r5
      007A21 F8               [12] 2240 	mov	r0,a
      007A22 E4               [12] 2241 	clr	a
      007A23 3E               [12] 2242 	addc	a,r6
      007A24 F9               [12] 2243 	mov	r1,a
      007A25 8F 02            [24] 2244 	mov	ar2,r7
      007A27 22               [24] 2245 	ret
                                   2246 
                                   2247 	.area CSEG (CODE)
                                   2248 ; function ak820_outline_0153
      007A28                       2249 _ak820_outline_0153:
      007A28 90 08 54         [24] 2250 	mov	dptr,#_process_action_PARM_2
      007A2B E0               [24] 2251 	movx	a,@dptr
      007A2C 22               [24] 2252 	ret
                                   2253 
                                   2254 	.area CSEG (CODE)
                                   2255 ; function ak820_outline_0189
      007A2D                       2256 _ak820_outline_0189:
      007A2D F0               [24] 2257 	movx	@dptr,a
      007A2E EB               [12] 2258 	mov	a,r3
      007A2F A3               [24] 2259 	inc	dptr
      007A30 F0               [24] 2260 	movx	@dptr,a
      007A31 22               [24] 2261 	ret
                                   2262 
                                   2263 	.area CSEG (CODE)
                                   2264 ; function ak820_outline_0191
      007A32                       2265 _ak820_outline_0191:
      007A32 E4               [12] 2266 	clr	a
      007A33 F0               [24] 2267 	movx	@dptr,a
      007A34 8F 82            [24] 2268 	mov	dpl,r7
      007A36 22               [24] 2269 	ret
