                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000024                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000024                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AFA                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AFA                        628 	.ds 1
      000AFB                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AFB                        630 	.ds 1
      000AFC                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000AFC                        632 	.ds 1
      000AFD                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AFD                        634 	.ds 1
      000AFE                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AFE                        636 	.ds 1
      000AFF                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000AFF                        638 	.ds 1
      000B00                        639 _dynamic_keymap_set_keycode_PARM_2:
      000B00                        640 	.ds 1
      000B01                        641 _dynamic_keymap_set_keycode_PARM_3:
      000B01                        642 	.ds 1
      000B02                        643 _dynamic_keymap_set_keycode_PARM_4:
      000B02                        644 	.ds 2
      000B04                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000B04                        646 	.ds 1
      000B05                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B05                        648 	.ds 1
      000B06                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000B06                        650 	.ds 1
      000B07                        651 _dynamic_keymap_get_encoder_PARM_2:
      000B07                        652 	.ds 1
      000B08                        653 _dynamic_keymap_get_encoder_PARM_3:
      000B08                        654 	.ds 1
      000B09                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000B09                        656 	.ds 1
      000B0A                        657 _dynamic_keymap_set_encoder_PARM_2:
      000B0A                        658 	.ds 1
      000B0B                        659 _dynamic_keymap_set_encoder_PARM_3:
      000B0B                        660 	.ds 1
      000B0C                        661 _dynamic_keymap_set_encoder_PARM_4:
      000B0C                        662 	.ds 2
      000B0E                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000B0E                        664 	.ds 1
      000B0F                        665 _dynamic_keymap_get_combo_PARM_2:
      000B0F                        666 	.ds 3
      000B12                        667 _dynamic_keymap_get_combo_index_10000_385:
      000B12                        668 	.ds 1
      000B13                        669 _dynamic_keymap_set_combo_PARM_2:
      000B13                        670 	.ds 3
      000B16                        671 _dynamic_keymap_set_combo_index_10000_391:
      000B16                        672 	.ds 1
      000B17                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000B17                        674 	.ds 10
      000B21                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B21                        676 	.ds 1
      000B22                        677 _dynamic_keymap_reset_combo_10001_408:
      000B22                        678 	.ds 10
      000B2C                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B2C                        680 	.ds 2
      000B2E                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B2E                        682 	.ds 2
      000B30                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B30                        684 	.ds 2
      000B32                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B32                        686 	.ds 3
      000B35                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B35                        688 	.ds 2
      000B37                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B37                        690 	.ds 1
      000B38                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B38                        692 	.ds 2
      000B3A                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B3A                        694 	.ds 3
      000B3D                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B3D                        696 	.ds 2
      000B3F                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B3F                        698 	.ds 2
      000B41                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B41                        700 	.ds 3
      000B44                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B44                        702 	.ds 2
      000B46                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B46                        704 	.ds 1
      000B47                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B47                        706 	.ds 1
      000B48                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B48                        708 	.ds 1
      000B49                        709 _keycode_at_keymap_location_PARM_2:
      000B49                        710 	.ds 1
      000B4A                        711 _keycode_at_keymap_location_PARM_3:
      000B4A                        712 	.ds 1
      000B4B                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B4B                        714 	.ds 1
      000B4C                        715 _keycode_at_encodermap_location_PARM_2:
      000B4C                        716 	.ds 1
      000B4D                        717 _keycode_at_encodermap_location_PARM_3:
      000B4D                        718 	.ds 1
      000B4E                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B4E                        720 	.ds 1
      000B4F                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B4F                        722 	.ds 2
      000B51                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B51                        724 	.ds 3
      000B54                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B54                        726 	.ds 2
      000B56                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B56                        728 	.ds 2
      000B58                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B58                        730 	.ds 3
      000B5B                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B5B                        732 	.ds 2
      000B5D                        733 _decode_keycode_kc_10000_455:
      000B5D                        734 	.ds 2
      000B5F                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B5F                        736 	.ds 1
      000B60                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B60                        738 	.ds 1
      000B61                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B61                        740 	.ds 2
      000B63                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B63                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008673                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008673 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      008676 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008677                        810 _dynamic_keymap_key_to_eeprom_address:
      008677 E5 82            [12]  811 	mov	a,dpl
      008679 90 0A FC         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      00867C F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      00867D E0               [24]  815 	movx	a,@dptr
      00867E FF               [12]  816 	mov	r7,a
      00867F 7E 00            [12]  817 	mov	r6,#0x00
      008681 74 40            [12]  818 	mov	a,#0x40
      008683 12 43 61         [24]  819 	lcall	_ak820_outline_0139
      008686 7D 00            [12]  820 	mov	r5,#0x00
      008688 90 0A FA         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00868B E0               [24]  822 	movx	a,@dptr
      00868C 75 F0 10         [24]  823 	mov	b,#0x10
      00868F A4               [48]  824 	mul	ab
      008690 2E               [12]  825 	add	a, r6
      008691 FE               [12]  826 	mov	r6,a
      008692 EF               [12]  827 	mov	a,r7
      008693 35 F0            [12]  828 	addc	a, b
      008695 FF               [12]  829 	mov	r7,a
      008696 90 0A FB         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008699 E0               [24]  831 	movx	a,@dptr
      00869A 7C 00            [12]  832 	mov	r4,#0x00
      00869C 25 E0            [12]  833 	add	a,acc
      00869E FB               [12]  834 	mov	r3,a
      00869F EC               [12]  835 	mov	a,r4
      0086A0 33               [12]  836 	rlc	a
      0086A1 FC               [12]  837 	mov	r4,a
      0086A2 EB               [12]  838 	mov	a,r3
      0086A3 2E               [12]  839 	add	a, r6
      0086A4 FE               [12]  840 	mov	r6,a
      0086A5 EC               [12]  841 	mov	a,r4
      0086A6 3F               [12]  842 	addc	a, r7
      0086A7 FF               [12]  843 	mov	r7,a
      0086A8 12 72 13         [24]  844 	lcall	_ak820_outline_0050
                                    845 ;	quantum/dynamic_keymap.c:184: }
      0086AB 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      0086AC                        860 _dynamic_keymap_get_keycode:
      0086AC E5 82            [12]  861 	mov	a,dpl
      0086AE 90 0A FF         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      0086B1 F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0086B2 E0               [24]  865 	movx	a,@dptr
      0086B3 FF               [12]  866 	mov	r7,a
      0086B4 BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      0086B7                        868 00121$:
      0086B7 50 14            [24]  869 	jnc	00101$
      0086B9 90 0A FD         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0086BC E0               [24]  871 	movx	a,@dptr
      0086BD FE               [12]  872 	mov	r6,a
      0086BE BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      0086C1                        874 00123$:
      0086C1 50 0A            [24]  875 	jnc	00101$
      0086C3 90 0A FE         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0086C6 E0               [24]  877 	movx	a,@dptr
      0086C7 FD               [12]  878 	mov	r5,a
      0086C8 BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      0086CB                        880 00125$:
      0086CB 40 04            [24]  881 	jc	00102$
      0086CD                        882 00101$:
      0086CD 90 00 00         [24]  883 	mov	dptr,#0x0000
      0086D0 22               [24]  884 	ret
      0086D1                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0086D1 12 91 05         [24]  887 	lcall	_ak820_outline_0100
      0086D4 12 86 77         [24]  888 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      0086D7 12 91 19         [24]  890 	lcall	_ak820_outline_0118
      0086DA 12 40 74         [24]  891 	lcall	_eeprom_read_byte
      0086DD AB 82            [24]  892 	mov	r3,dpl
      0086DF 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      0086E1 0D               [12]  895 	inc	r5
      0086E2 BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      0086E5 0E               [12]  897 	inc	r6
      0086E6                        898 00127$:
      0086E6 12 6F EE         [24]  899 	lcall	_ak820_outline_0059
      0086E9 12 40 74         [24]  900 	lcall	_eeprom_read_byte
      0086EC AF 82            [24]  901 	mov	r7, dpl
      0086EE 7E 00            [12]  902 	mov	r6,#0x00
      0086F0 EF               [12]  903 	mov	a,r7
      0086F1 42 04            [12]  904 	orl	ar4,a
      0086F3 EE               [12]  905 	mov	a,r6
      0086F4 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      0086F6 12 43 88         [24]  908 	lcall	_ak820_outline_0186
                                    909 ;	quantum/dynamic_keymap.c:193: }
      0086F9 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      0086FA                        924 _dynamic_keymap_set_keycode:
      0086FA E5 82            [12]  925 	mov	a,dpl
      0086FC 90 0B 04         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      0086FF F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008700 E0               [24]  929 	movx	a,@dptr
      008701 FF               [12]  930 	mov	r7,a
      008702 BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      008705                        932 00121$:
      008705 50 14            [24]  933 	jnc	00101$
      008707 90 0B 00         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00870A E0               [24]  935 	movx	a,@dptr
      00870B FE               [12]  936 	mov	r6,a
      00870C BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      00870F                        938 00123$:
      00870F 50 0A            [24]  939 	jnc	00101$
      008711 90 0B 01         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008714 E0               [24]  941 	movx	a,@dptr
      008715 FD               [12]  942 	mov	r5,a
      008716 BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      008719                        944 00125$:
      008719 40 01            [24]  945 	jc	00102$
      00871B                        946 00101$:
      00871B 22               [24]  947 	ret
      00871C                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00871C 12 91 05         [24]  950 	lcall	_ak820_outline_0100
      00871F 12 86 77         [24]  951 	lcall	_dynamic_keymap_key_to_eeprom_address
      008722 12 91 19         [24]  952 	lcall	_ak820_outline_0118
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008725 90 0B 02         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008728 E0               [24]  955 	movx	a,@dptr
      008729 FB               [12]  956 	mov	r3,a
      00872A A3               [24]  957 	inc	dptr
      00872B E0               [24]  958 	movx	a,@dptr
      00872C 90 06 9E         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      00872F 12 4F 1D         [24]  960 	lcall	_ak820_outline_0034
      008732 12 4E 08         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008735 0D               [12]  963 	inc	r5
      008736 BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      008739 0E               [12]  965 	inc	r6
      00873A                        966 00127$:
      00873A 90 06 9E         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      00873D EB               [12]  968 	mov	a,r3
      00873E 12 4F 1D         [24]  969 	lcall	_ak820_outline_0034
                                    970 ;	quantum/dynamic_keymap.c:201: }
      008741 02 4E 08         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      008744                        982 _dynamic_keymap_encoder_to_eeprom_address:
      008744 E5 82            [12]  983 	mov	a,dpl
      008746 90 0B 06         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      008749 F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      00874A E0               [24]  987 	movx	a,@dptr
      00874B 75 F0 04         [24]  988 	mov	b,#0x04
      00874E A4               [48]  989 	mul	ab
      00874F 24 40            [12]  990 	add	a, #0x40
      008751 FD               [12]  991 	mov	r5,a
      008752 74 06            [12]  992 	mov	a,#0x06
      008754 35 F0            [12]  993 	addc	a, b
      008756 FE               [12]  994 	mov	r6,a
      008757 7F 00            [12]  995 	mov	r7,#0x00
      008759 90 0B 05         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00875C E0               [24]  997 	movx	a,@dptr
      00875D 75 F0 04         [24]  998 	mov	b,#0x04
      008760 A4               [48]  999 	mul	ab
      008761 2D               [12] 1000 	add	a, r5
      008762 FD               [12] 1001 	mov	r5,a
      008763 EE               [12] 1002 	mov	a,r6
      008764 35 F0            [12] 1003 	addc	a, b
      008766 FE               [12] 1004 	mov	r6,a
      008767 12 6F EE         [24] 1005 	lcall	_ak820_outline_0059
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      00876A 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      00876B                       1021 _dynamic_keymap_get_encoder:
      00876B E5 82            [12] 1022 	mov	a,dpl
      00876D 90 0B 09         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      008770 F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008771 E0               [24] 1026 	movx	a,@dptr
      008772 FF               [12] 1027 	mov	r7,a
      008773 BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      008776                       1029 00131$:
      008776 50 0A            [24] 1030 	jnc	00101$
      008778 90 0B 07         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00877B E0               [24] 1032 	movx	a,@dptr
      00877C FE               [12] 1033 	mov	r6,a
      00877D BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      008780                       1035 00133$:
      008780 40 04            [24] 1036 	jc	00102$
      008782                       1037 00101$:
      008782 90 00 00         [24] 1038 	mov	dptr,#0x0000
      008785 22               [24] 1039 	ret
      008786                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008786 90 0B 05         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008789 12 7A 32         [24] 1043 	lcall	_ak820_outline_0191
      00878C 12 87 44         [24] 1044 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      00878F 12 91 19         [24] 1045 	lcall	_ak820_outline_0118
                                   1046 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008792 90 0B 08         [24] 1047 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008795 E0               [24] 1048 	movx	a,@dptr
      008796 FC               [12] 1049 	mov	r4,a
      008797 E0               [24] 1050 	movx	a,@dptr
      008798 60 04            [24] 1051 	jz	00106$
      00879A 7B 00            [12] 1052 	mov	r3,#0x00
      00879C 80 02            [24] 1053 	sjmp	00107$
      00879E                       1054 00106$:
      00879E 7B 02            [12] 1055 	mov	r3,#0x02
      0087A0                       1056 00107$:
      0087A0 EB               [12] 1057 	mov	a,r3
      0087A1 12 79 AB         [24] 1058 	lcall	_ak820_outline_0013
      0087A4 12 40 74         [24] 1059 	lcall	_eeprom_read_byte
      0087A7 AA 82            [24] 1060 	mov	r2,dpl
      0087A9 7B 00            [12] 1061 	mov	r3,#0x00
                                   1062 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0087AB EC               [12] 1063 	mov	a,r4
      0087AC 60 04            [24] 1064 	jz	00108$
      0087AE 7C 00            [12] 1065 	mov	r4,#0x00
      0087B0 80 02            [24] 1066 	sjmp	00109$
      0087B2                       1067 00108$:
      0087B2 7C 02            [12] 1068 	mov	r4,#0x02
      0087B4                       1069 00109$:
      0087B4 EC               [12] 1070 	mov	a,r4
      0087B5 12 38 BB         [24] 1071 	lcall	_ak820_outline_0165
      0087B8 0D               [12] 1072 	inc	r5
      0087B9 BD 00 01         [24] 1073 	cjne	r5,#0x00,00137$
      0087BC 0E               [12] 1074 	inc	r6
      0087BD                       1075 00137$:
      0087BD 12 6F EE         [24] 1076 	lcall	_ak820_outline_0059
      0087C0 12 40 74         [24] 1077 	lcall	_eeprom_read_byte
      0087C3 AF 82            [24] 1078 	mov	r7, dpl
      0087C5 7E 00            [12] 1079 	mov	r6,#0x00
      0087C7 EF               [12] 1080 	mov	a,r7
      0087C8 42 03            [12] 1081 	orl	ar3,a
      0087CA EE               [12] 1082 	mov	a,r6
      0087CB 42 02            [12] 1083 	orl	ar2,a
                                   1084 ;	quantum/dynamic_keymap.c:214: return keycode;
      0087CD 8B 82            [24] 1085 	mov	dpl, r3
      0087CF 8A 83            [24] 1086 	mov	dph, r2
                                   1087 ;	quantum/dynamic_keymap.c:215: }
      0087D1 22               [24] 1088 	ret
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1091 ;------------------------------------------------------------
                                   1092 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1093 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1094 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1095 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1096 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1097 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1098 ;------------------------------------------------------------
                                   1099 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1100 ;	-----------------------------------------
                                   1101 ;	 function dynamic_keymap_set_encoder
                                   1102 ;	-----------------------------------------
      0087D2                       1103 _dynamic_keymap_set_encoder:
      0087D2 E5 82            [12] 1104 	mov	a,dpl
      0087D4 90 0B 0E         [24] 1105 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      0087D7 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0087D8 E0               [24] 1108 	movx	a,@dptr
      0087D9 FF               [12] 1109 	mov	r7,a
      0087DA BF 06 00         [24] 1110 	cjne	r7,#0x06,00131$
      0087DD                       1111 00131$:
      0087DD 50 0A            [24] 1112 	jnc	00101$
      0087DF 90 0B 0A         [24] 1113 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0087E2 E0               [24] 1114 	movx	a,@dptr
      0087E3 FE               [12] 1115 	mov	r6,a
      0087E4 BE 01 00         [24] 1116 	cjne	r6,#0x01,00133$
      0087E7                       1117 00133$:
      0087E7 40 01            [24] 1118 	jc	00102$
      0087E9                       1119 00101$:
      0087E9 22               [24] 1120 	ret
      0087EA                       1121 00102$:
                                   1122 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0087EA 90 0B 05         [24] 1123 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0087ED 12 7A 32         [24] 1124 	lcall	_ak820_outline_0191
      0087F0 12 87 44         [24] 1125 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0087F3 12 91 19         [24] 1126 	lcall	_ak820_outline_0118
                                   1127 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      0087F6 90 0B 0B         [24] 1128 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0087F9 E0               [24] 1129 	movx	a,@dptr
      0087FA FC               [12] 1130 	mov	r4,a
      0087FB E0               [24] 1131 	movx	a,@dptr
      0087FC 60 04            [24] 1132 	jz	00106$
      0087FE 7B 00            [12] 1133 	mov	r3,#0x00
      008800 80 02            [24] 1134 	sjmp	00107$
      008802                       1135 00106$:
      008802 7B 02            [12] 1136 	mov	r3,#0x02
      008804                       1137 00107$:
      008804 EB               [12] 1138 	mov	a,r3
      008805 12 91 2B         [24] 1139 	lcall	_ak820_outline_0138
      008808 8F 03            [24] 1140 	mov	ar3,r7
      00880A 90 0B 0C         [24] 1141 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00880D E0               [24] 1142 	movx	a,@dptr
      00880E F5 29            [12] 1143 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008810 A3               [24] 1144 	inc	dptr
      008811 E0               [24] 1145 	movx	a,@dptr
      008812 F5 2A            [12] 1146 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008814 90 06 9E         [24] 1147 	mov	dptr,#_eeprom_update_byte_PARM_2
      008817 F0               [24] 1148 	movx	@dptr,a
      008818 12 43 83         [24] 1149 	lcall	_ak820_outline_0185
      00881B 8B F0            [24] 1150 	mov	b, r3
      00881D 12 4E 08         [24] 1151 	lcall	_eeprom_update_byte
                                   1152 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008820 EC               [12] 1153 	mov	a,r4
      008821 60 04            [24] 1154 	jz	00108$
      008823 7C 00            [12] 1155 	mov	r4,#0x00
      008825 80 02            [24] 1156 	sjmp	00109$
      008827                       1157 00108$:
      008827 7C 02            [12] 1158 	mov	r4,#0x02
      008829                       1159 00109$:
      008829 EC               [12] 1160 	mov	a,r4
      00882A 12 38 BB         [24] 1161 	lcall	_ak820_outline_0165
      00882D 0D               [12] 1162 	inc	r5
      00882E BD 00 01         [24] 1163 	cjne	r5,#0x00,00137$
      008831 0E               [12] 1164 	inc	r6
      008832                       1165 00137$:
      008832 90 06 9E         [24] 1166 	mov	dptr,#_eeprom_update_byte_PARM_2
      008835 E5 29            [12] 1167 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008837 12 4F 1D         [24] 1168 	lcall	_ak820_outline_0034
                                   1169 ;	quantum/dynamic_keymap.c:223: }
      00883A 02 4E 08         [24] 1170 	ljmp	_eeprom_update_byte
                                   1171 ;------------------------------------------------------------
                                   1172 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1173 ;------------------------------------------------------------
                                   1174 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1175 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1176 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1177 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1178 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1179 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function dynamic_keymap_get_combo
                                   1184 ;	-----------------------------------------
      00883D                       1185 _dynamic_keymap_get_combo:
      00883D E5 82            [12] 1186 	mov	a,dpl
      00883F 90 0B 12         [24] 1187 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008842 F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008843 90 0B 0F         [24] 1190 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008846 12 38 41         [24] 1191 	lcall	_ak820_outline_0052
                                   1192 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      008849 90 0B 12         [24] 1193 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      00884C E0               [24] 1194 	movx	a,@dptr
      00884D FD               [12] 1195 	mov	r5,a
      00884E BD 08 00         [24] 1196 	cjne	r5,#0x08,00132$
      008851                       1197 00132$:
      008851 40 04            [24] 1198 	jc	00102$
                                   1199 ;	quantum/dynamic_keymap.c:275: return -1;
      008853 90 FF FF         [24] 1200 	mov	dptr,#0xffff
      008856 22               [24] 1201 	ret
      008857                       1202 00102$:
                                   1203 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008857 12 90 F1         [24] 1204 	lcall	_ak820_outline_0082
                                   1205 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      00885A 8E 02            [24] 1206 	mov	ar2,r6
      00885C 8F 03            [24] 1207 	mov	ar3,r7
      00885E 90 05 85         [24] 1208 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008861 12 38 5E         [24] 1209 	lcall	_ak820_outline_0072
      008864 E4               [12] 1210 	clr	a
      008865 A3               [24] 1211 	inc	dptr
      008866 F0               [24] 1212 	movx	@dptr,a
      008867 90 05 88         [24] 1213 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00886A 12 91 12         [24] 1214 	lcall	_ak820_outline_0113
      00886D 12 38 AC         [24] 1215 	lcall	_ak820_outline_0147
      008870 C0 07            [24] 1216 	push	ar7
      008872 C0 06            [24] 1217 	push	ar6
      008874 12 40 AF         [24] 1218 	lcall	_ak820_eeprom_read_block_xdata
      008877 D0 06            [24] 1219 	pop	ar6
      008879 D0 07            [24] 1220 	pop	ar7
                                   1221 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      00887B 74 04            [12] 1222 	mov	a,#0x04
      00887D 12 48 70         [24] 1223 	lcall	_ak820_outline_0033
      008880 FA               [12] 1224 	mov	r2,a
      008881 A3               [24] 1225 	inc	dptr
      008882 E0               [24] 1226 	movx	a,@dptr
      008883 FB               [12] 1227 	mov	r3,a
      008884 BA 20 13         [24] 1228 	cjne	r2,#0x20,00108$
      008887 BB 08 10         [24] 1229 	cjne	r3,#0x08,00108$
      00888A 74 06            [12] 1230 	mov	a,#0x06
      00888C 12 38 31         [24] 1231 	lcall	_ak820_outline_0022
      00888F 12 43 4A         [24] 1232 	lcall	_ak820_outline_0105
      008892 BA 01 05         [24] 1233 	cjne	r2,#0x01,00136$
      008895 BB 00 02         [24] 1234 	cjne	r3,#0x00,00136$
      008898 80 05            [24] 1235 	sjmp	00109$
      00889A                       1236 00136$:
      00889A                       1237 00108$:
      00889A 75 2B 00         [24] 1238 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      00889D 80 03            [24] 1239 	sjmp	00110$
      00889F                       1240 00109$:
      00889F 75 2B 01         [24] 1241 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0088A2                       1242 00110$:
                                   1243 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      0088A2 74 06            [12] 1244 	mov	a,#0x06
      0088A4 12 38 31         [24] 1245 	lcall	_ak820_outline_0022
      0088A7 E4               [12] 1246 	clr	a
      0088A8 F0               [24] 1247 	movx	@dptr,a
      0088A9 A3               [24] 1248 	inc	dptr
      0088AA 12 38 76         [24] 1249 	lcall	_ak820_outline_0103
      0088AD F0               [24] 1250 	movx	@dptr,a
      0088AE A3               [24] 1251 	inc	dptr
      0088AF F0               [24] 1252 	movx	@dptr,a
                                   1253 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      0088B0 E5 2B            [12] 1254 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      0088B2 60 12            [24] 1255 	jz	00103$
      0088B4 12 38 8C         [24] 1256 	lcall	_ak820_outline_0120
      0088B7 C0 07            [24] 1257 	push	ar7
      0088B9 C0 06            [24] 1258 	push	ar6
      0088BB 12 34 D1         [24] 1259 	lcall	_ak820_combo_valid
      0088BE E5 82            [12] 1260 	mov	a, dpl
      0088C0 D0 06            [24] 1261 	pop	ar6
      0088C2 D0 07            [24] 1262 	pop	ar7
      0088C4 70 13            [24] 1263 	jnz	00104$
      0088C6                       1264 00103$:
      0088C6 7D 00            [12] 1265 	mov	r5,#0x00
      0088C8 90 0D CA         [24] 1266 	mov	dptr,#_memset_PARM_2
      0088CB E4               [12] 1267 	clr	a
      0088CC F0               [24] 1268 	movx	@dptr,a
      0088CD 90 0D CB         [24] 1269 	mov	dptr,#_memset_PARM_3
      0088D0 12 91 12         [24] 1270 	lcall	_ak820_outline_0113
      0088D3 12 72 13         [24] 1271 	lcall	_ak820_outline_0050
      0088D6 12 BB 24         [24] 1272 	lcall	_memset
      0088D9                       1273 00104$:
                                   1274 ;	quantum/dynamic_keymap.c:289: return 0;
      0088D9 90 00 00         [24] 1275 	mov	dptr,#0x0000
                                   1276 ;	quantum/dynamic_keymap.c:290: }
      0088DC 22               [24] 1277 	ret
                                   1278 ;------------------------------------------------------------
                                   1279 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1280 ;------------------------------------------------------------
                                   1281 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1282 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1283 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1284 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1285 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1286 ;------------------------------------------------------------
                                   1287 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1288 ;	-----------------------------------------
                                   1289 ;	 function dynamic_keymap_set_combo
                                   1290 ;	-----------------------------------------
      0088DD                       1291 _dynamic_keymap_set_combo:
      0088DD E5 82            [12] 1292 	mov	a,dpl
      0088DF 90 0B 16         [24] 1293 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      0088E2 F0               [24] 1294 	movx	@dptr,a
                                   1295 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0088E3 90 0B 13         [24] 1296 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0088E6 12 37 F4         [24] 1297 	lcall	_ak820_outline_0005
                                   1298 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      0088E9 C0 07            [24] 1299 	push	ar7
      0088EB C0 06            [24] 1300 	push	ar6
      0088ED 12 34 D1         [24] 1301 	lcall	_ak820_combo_valid
      0088F0 E5 82            [12] 1302 	mov	a, dpl
      0088F2 D0 06            [24] 1303 	pop	ar6
      0088F4 D0 07            [24] 1304 	pop	ar7
      0088F6 60 07            [24] 1305 	jz	00101$
      0088F8 12 3E 1A         [24] 1306 	lcall	_ak820_nvm_ok
      0088FB E5 82            [12] 1307 	mov	a, dpl
      0088FD 70 04            [24] 1308 	jnz	00102$
      0088FF                       1309 00101$:
      0088FF 90 FF FF         [24] 1310 	mov	dptr,#0xffff
      008902 22               [24] 1311 	ret
      008903                       1312 00102$:
                                   1313 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008903 90 0B 16         [24] 1314 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008906 E0               [24] 1315 	movx	a,@dptr
      008907 FD               [12] 1316 	mov	r5,a
      008908 BD 08 00         [24] 1317 	cjne	r5,#0x08,00133$
      00890B                       1318 00133$:
      00890B 40 04            [24] 1319 	jc	00105$
                                   1320 ;	quantum/dynamic_keymap.c:302: return -1;
      00890D 90 FF FF         [24] 1321 	mov	dptr,#0xffff
      008910 22               [24] 1322 	ret
      008911                       1323 00105$:
                                   1324 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008911 12 90 F1         [24] 1325 	lcall	_ak820_outline_0082
                                   1326 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      008914 C0 07            [24] 1327 	push	ar7
      008916 C0 06            [24] 1328 	push	ar6
      008918 C0 05            [24] 1329 	push	ar5
      00891A C0 04            [24] 1330 	push	ar4
      00891C 12 79 5D         [24] 1331 	lcall	_clear_keyboard
      00891F D0 04            [24] 1332 	pop	ar4
      008921 D0 05            [24] 1333 	pop	ar5
      008923 D0 06            [24] 1334 	pop	ar6
      008925 D0 07            [24] 1335 	pop	ar7
                                   1336 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      008927 90 0D C2         [24] 1337 	mov	dptr,#___memcpy_PARM_2
      00892A 12 48 83         [24] 1338 	lcall	_ak820_outline_0060
      00892D E4               [12] 1339 	clr	a
      00892E A3               [24] 1340 	inc	dptr
      00892F F0               [24] 1341 	movx	@dptr,a
      008930 90 0D C5         [24] 1342 	mov	dptr,#___memcpy_PARM_3
      008933 12 91 12         [24] 1343 	lcall	_ak820_outline_0113
      008936 90 0B 17         [24] 1344 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008939 F5 F0            [12] 1345 	mov	b,a
      00893B C0 05            [24] 1346 	push	ar5
      00893D C0 04            [24] 1347 	push	ar4
      00893F 12 BA AE         [24] 1348 	lcall	___memcpy
      008942 D0 04            [24] 1349 	pop	ar4
      008944 D0 05            [24] 1350 	pop	ar5
                                   1351 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008946 90 0B 1B         [24] 1352 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      008949 74 20            [12] 1353 	mov	a,#0x20
      00894B F0               [24] 1354 	movx	@dptr,a
      00894C 74 08            [12] 1355 	mov	a,#0x08
      00894E A3               [24] 1356 	inc	dptr
      00894F F0               [24] 1357 	movx	@dptr,a
                                   1358 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      008950 90 0B 1D         [24] 1359 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      008953 74 01            [12] 1360 	mov	a,#0x01
      008955 12 38 9C         [24] 1361 	lcall	_ak820_outline_0136
                                   1362 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008958 90 05 8E         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00895B 12 38 5E         [24] 1364 	lcall	_ak820_outline_0072
      00895E E4               [12] 1365 	clr	a
      00895F A3               [24] 1366 	inc	dptr
      008960 F0               [24] 1367 	movx	@dptr,a
      008961 90 05 91         [24] 1368 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008964 12 91 12         [24] 1369 	lcall	_ak820_outline_0113
      008967 90 0B 17         [24] 1370 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      00896A 12 41 3B         [24] 1371 	lcall	_ak820_eeprom_write_block_xdata
                                   1372 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      00896D 12 3E 29         [24] 1373 	lcall	_ak820_nvm_flush
                                   1374 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      008970 12 3E 1A         [24] 1375 	lcall	_ak820_nvm_ok
      008973 E5 82            [12] 1376 	mov	a, dpl
      008975 70 04            [24] 1377 	jnz	00107$
      008977 90 FF FF         [24] 1378 	mov	dptr,#0xffff
      00897A 22               [24] 1379 	ret
      00897B                       1380 00107$:
                                   1381 ;	quantum/dynamic_keymap.c:320: return 0;
      00897B 90 00 00         [24] 1382 	mov	dptr,#0x0000
                                   1383 ;	quantum/dynamic_keymap.c:321: }
      00897E 22               [24] 1384 	ret
                                   1385 ;------------------------------------------------------------
                                   1386 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1387 ;------------------------------------------------------------
                                   1388 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1389 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1390 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1391 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1392 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1393 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1394 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1395 ;------------------------------------------------------------
                                   1396 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1397 ;	-----------------------------------------
                                   1398 ;	 function dynamic_keymap_reset
                                   1399 ;	-----------------------------------------
      00897F                       1400 _dynamic_keymap_reset:
                                   1401 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      00897F 90 0E 42         [24] 1402 	mov	dptr,#_vial_unlocked
      008982 E0               [24] 1403 	movx	a,@dptr
      008983 90 0B 21         [24] 1404 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008986 F0               [24] 1405 	movx	@dptr,a
                                   1406 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      008987 90 0E 42         [24] 1407 	mov	dptr,#_vial_unlocked
      00898A 74 01            [12] 1408 	mov	a,#0x01
      00898C F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00898D 7F 00            [12] 1411 	mov	r7,#0x00
      00898F                       1412 00116$:
      00898F BF 06 00         [24] 1413 	cjne	r7,#0x06,00198$
      008992                       1414 00198$:
      008992 40 03            [24] 1415 	jc	00199$
      008994 02 8A 42         [24] 1416 	ljmp	00104$
      008997                       1417 00199$:
                                   1418 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008997 7E 00            [12] 1419 	mov	r6,#0x00
      008999                       1420 00110$:
      008999 BE 10 00         [24] 1421 	cjne	r6,#0x10,00200$
      00899C                       1422 00200$:
      00899C 50 4D            [24] 1423 	jnc	00102$
                                   1424 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      00899E 7D 00            [12] 1425 	mov	r5,#0x00
      0089A0                       1426 00107$:
      0089A0 BD 08 00         [24] 1427 	cjne	r5,#0x08,00202$
      0089A3                       1428 00202$:
      0089A3 50 43            [24] 1429 	jnc	00111$
                                   1430 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0089A5 90 0B BD         [24] 1431 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0089A8 EE               [12] 1432 	mov	a,r6
      0089A9 F0               [24] 1433 	movx	@dptr,a
      0089AA 90 0B BE         [24] 1434 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0089AD ED               [12] 1435 	mov	a,r5
      0089AE F0               [24] 1436 	movx	@dptr,a
      0089AF 8F 82            [24] 1437 	mov	dpl, r7
      0089B1 C0 07            [24] 1438 	push	ar7
      0089B3 C0 06            [24] 1439 	push	ar6
      0089B5 C0 05            [24] 1440 	push	ar5
      0089B7 12 99 3F         [24] 1441 	lcall	_keycode_at_keymap_location_raw
      0089BA AB 82            [24] 1442 	mov	r3, dpl
      0089BC AC 83            [24] 1443 	mov	r4, dph
      0089BE D0 05            [24] 1444 	pop	ar5
      0089C0 D0 06            [24] 1445 	pop	ar6
      0089C2 D0 07            [24] 1446 	pop	ar7
      0089C4 90 0B 00         [24] 1447 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0089C7 EE               [12] 1448 	mov	a,r6
      0089C8 F0               [24] 1449 	movx	@dptr,a
      0089C9 90 0B 01         [24] 1450 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0089CC ED               [12] 1451 	mov	a,r5
      0089CD F0               [24] 1452 	movx	@dptr,a
      0089CE 90 0B 02         [24] 1453 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0089D1 12 38 6A         [24] 1454 	lcall	_ak820_outline_0086
      0089D4 8F 82            [24] 1455 	mov	dpl, r7
      0089D6 C0 07            [24] 1456 	push	ar7
      0089D8 C0 06            [24] 1457 	push	ar6
      0089DA C0 05            [24] 1458 	push	ar5
      0089DC 12 86 FA         [24] 1459 	lcall	_dynamic_keymap_set_keycode
      0089DF D0 05            [24] 1460 	pop	ar5
      0089E1 D0 06            [24] 1461 	pop	ar6
      0089E3 D0 07            [24] 1462 	pop	ar7
                                   1463 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0089E5 0D               [12] 1464 	inc	r5
      0089E6 80 B8            [24] 1465 	sjmp	00107$
      0089E8                       1466 00111$:
                                   1467 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0089E8 0E               [12] 1468 	inc	r6
      0089E9 80 AE            [24] 1469 	sjmp	00110$
      0089EB                       1470 00102$:
                                   1471 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0089EB 7E 00            [12] 1472 	mov	r6,#0x00
      0089ED                       1473 00113$:
      0089ED BE 01 00         [24] 1474 	cjne	r6,#0x01,00204$
      0089F0                       1475 00204$:
      0089F0 50 4C            [24] 1476 	jnc	00117$
                                   1477 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      0089F2 12 91 47         [24] 1478 	lcall	_ak820_outline_0180
      0089F5 04               [12] 1479 	inc	a
      0089F6 F0               [24] 1480 	movx	@dptr,a
      0089F7 8F 82            [24] 1481 	mov	dpl, r7
      0089F9 C0 07            [24] 1482 	push	ar7
      0089FB 12 99 84         [24] 1483 	lcall	_keycode_at_encodermap_location_raw
      0089FE 12 43 6D         [24] 1484 	lcall	_ak820_outline_0154
      008A01 D0 07            [24] 1485 	pop	ar7
      008A03 12 91 3E         [24] 1486 	lcall	_ak820_outline_0179
      008A06 04               [12] 1487 	inc	a
      008A07 F0               [24] 1488 	movx	@dptr,a
      008A08 90 0B 0C         [24] 1489 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008A0B 12 38 5E         [24] 1490 	lcall	_ak820_outline_0072
      008A0E 8F 82            [24] 1491 	mov	dpl, r7
      008A10 C0 07            [24] 1492 	push	ar7
      008A12 12 87 D2         [24] 1493 	lcall	_dynamic_keymap_set_encoder
      008A15 D0 07            [24] 1494 	pop	ar7
                                   1495 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008A17 12 91 47         [24] 1496 	lcall	_ak820_outline_0180
      008A1A F0               [24] 1497 	movx	@dptr,a
      008A1B 8F 82            [24] 1498 	mov	dpl, r7
      008A1D C0 07            [24] 1499 	push	ar7
      008A1F 12 99 84         [24] 1500 	lcall	_keycode_at_encodermap_location_raw
      008A22 12 43 6D         [24] 1501 	lcall	_ak820_outline_0154
      008A25 D0 07            [24] 1502 	pop	ar7
      008A27 12 91 3E         [24] 1503 	lcall	_ak820_outline_0179
      008A2A F0               [24] 1504 	movx	@dptr,a
      008A2B 90 0B 0C         [24] 1505 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008A2E 12 38 5E         [24] 1506 	lcall	_ak820_outline_0072
      008A31 8F 82            [24] 1507 	mov	dpl, r7
      008A33 C0 07            [24] 1508 	push	ar7
      008A35 12 87 D2         [24] 1509 	lcall	_dynamic_keymap_set_encoder
      008A38 D0 07            [24] 1510 	pop	ar7
                                   1511 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008A3A 7E 01            [12] 1512 	mov	r6,#0x01
      008A3C 80 AF            [24] 1513 	sjmp	00113$
      008A3E                       1514 00117$:
                                   1515 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008A3E 0F               [12] 1516 	inc	r7
      008A3F 02 89 8F         [24] 1517 	ljmp	00116$
      008A42                       1518 00104$:
                                   1519 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      008A42 90 0B 22         [24] 1520 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      008A45 12 4F 67         [24] 1521 	lcall	_ak820_outline_0184
      008A48 90 0B 24         [24] 1522 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      008A4B F0               [24] 1523 	movx	@dptr,a
      008A4C A3               [24] 1524 	inc	dptr
      008A4D F0               [24] 1525 	movx	@dptr,a
      008A4E 90 0B 26         [24] 1526 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      008A51 F0               [24] 1527 	movx	@dptr,a
      008A52 A3               [24] 1528 	inc	dptr
      008A53 F0               [24] 1529 	movx	@dptr,a
      008A54 90 0B 28         [24] 1530 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      008A57 F0               [24] 1531 	movx	@dptr,a
      008A58 A3               [24] 1532 	inc	dptr
      008A59 F0               [24] 1533 	movx	@dptr,a
      008A5A 90 0B 2A         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      008A5D F0               [24] 1535 	movx	@dptr,a
      008A5E A3               [24] 1536 	inc	dptr
      008A5F F0               [24] 1537 	movx	@dptr,a
                                   1538 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008A60 FF               [12] 1539 	mov	r7,a
      008A61                       1540 00119$:
      008A61 BF 08 00         [24] 1541 	cjne	r7,#0x08,00206$
      008A64                       1542 00206$:
      008A64 50 19            [24] 1543 	jnc	00105$
                                   1544 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      008A66 8F 06            [24] 1545 	mov	ar6,r7
      008A68 90 0B 13         [24] 1546 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008A6B 74 22            [12] 1547 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      008A6D F0               [24] 1548 	movx	@dptr,a
      008A6E 74 0B            [12] 1549 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      008A70 12 38 70         [24] 1550 	lcall	_ak820_outline_0094
      008A73 8E 82            [24] 1551 	mov	dpl, r6
      008A75 C0 07            [24] 1552 	push	ar7
      008A77 12 88 DD         [24] 1553 	lcall	_dynamic_keymap_set_combo
      008A7A D0 07            [24] 1554 	pop	ar7
                                   1555 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008A7C 0F               [12] 1556 	inc	r7
      008A7D 80 E2            [24] 1557 	sjmp	00119$
      008A7F                       1558 00105$:
                                   1559 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      008A7F 90 0B 21         [24] 1560 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008A82 E0               [24] 1561 	movx	a,@dptr
      008A83 90 0E 42         [24] 1562 	mov	dptr,#_vial_unlocked
      008A86 F0               [24] 1563 	movx	@dptr,a
                                   1564 ;	quantum/dynamic_keymap.c:405: }
      008A87 22               [24] 1565 	ret
                                   1566 ;------------------------------------------------------------
                                   1567 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1568 ;------------------------------------------------------------
                                   1569 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1570 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1571 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1572 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1573 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1574 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1575 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1576 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1577 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1578 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1579 ;------------------------------------------------------------
                                   1580 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1581 ;	-----------------------------------------
                                   1582 ;	 function ak820_dynamic_read_buffer
                                   1583 ;	-----------------------------------------
      008A88                       1584 _ak820_dynamic_read_buffer:
      008A88 12 38 82         [24] 1585 	lcall	_ak820_outline_0109
      008A8B 90 0B 35         [24] 1586 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008A8E 12 38 87         [24] 1587 	lcall	_ak820_outline_0110
                                   1588 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008A91 90 0B 32         [24] 1589 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008A94 12 38 41         [24] 1590 	lcall	_ak820_outline_0052
                                   1591 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      008A97 90 0B 37         [24] 1592 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008A9A E4               [12] 1593 	clr	a
      008A9B F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      008A9C 90 0B 30         [24] 1596 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008A9F 12 38 58         [24] 1597 	lcall	_ak820_outline_0061
      008AA2 8C 02            [24] 1598 	mov	ar2,r4
      008AA4 8D 03            [24] 1599 	mov	ar3,r5
      008AA6 C3               [12] 1600 	clr	c
      008AA7 74 1C            [12] 1601 	mov	a,#0x1c
      008AA9 9A               [12] 1602 	subb	a,r2
      008AAA E4               [12] 1603 	clr	a
      008AAB 9B               [12] 1604 	subb	a,r3
      008AAC 50 01            [24] 1605 	jnc	00102$
                                   1606 ;	free result
      008AAE 22               [24] 1607 	ret
      008AAF                       1608 00102$:
                                   1609 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      008AAF 90 0B 2E         [24] 1610 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008AB2 12 43 4A         [24] 1611 	lcall	_ak820_outline_0105
      008AB5 90 0B 2C         [24] 1612 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008AB8 12 38 7C         [24] 1613 	lcall	_ak820_outline_0104
      008ABB C3               [12] 1614 	clr	c
      008ABC EA               [12] 1615 	mov	a,r2
      008ABD 98               [12] 1616 	subb	a,r0
      008ABE EB               [12] 1617 	mov	a,r3
      008ABF 99               [12] 1618 	subb	a,r1
      008AC0 50 17            [24] 1619 	jnc	00104$
                                   1620 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      008AC2 E8               [12] 1621 	mov	a,r0
      008AC3 C3               [12] 1622 	clr	c
      008AC4 9A               [12] 1623 	subb	a,r2
      008AC5 F8               [12] 1624 	mov	r0,a
      008AC6 E9               [12] 1625 	mov	a,r1
      008AC7 9B               [12] 1626 	subb	a,r3
      008AC8 F9               [12] 1627 	mov	r1,a
                                   1628 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      008AC9 C3               [12] 1629 	clr	c
      008ACA E8               [12] 1630 	mov	a,r0
      008ACB 9C               [12] 1631 	subb	a,r4
      008ACC E9               [12] 1632 	mov	a,r1
      008ACD 9D               [12] 1633 	subb	a,r5
      008ACE 40 04            [24] 1634 	jc	00114$
      008AD0 8C 00            [24] 1635 	mov	ar0,r4
      008AD2 8D 01            [24] 1636 	mov	ar1,r5
      008AD4                       1637 00114$:
      008AD4 90 0B 37         [24] 1638 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008AD7 E8               [12] 1639 	mov	a,r0
      008AD8 F0               [24] 1640 	movx	@dptr,a
      008AD9                       1641 00104$:
                                   1642 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008AD9 90 0B 37         [24] 1643 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008ADC E0               [24] 1644 	movx	a,@dptr
      008ADD F5 2C            [12] 1645 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008ADF E0               [24] 1646 	movx	a,@dptr
      008AE0 60 42            [24] 1647 	jz	00106$
      008AE2 C0 04            [24] 1648 	push	ar4
      008AE4 C0 05            [24] 1649 	push	ar5
      008AE6 8E 00            [24] 1650 	mov	ar0,r6
      008AE8 8F 05            [24] 1651 	mov	ar5,r7
      008AEA 90 0B 35         [24] 1652 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008AED E0               [24] 1653 	movx	a,@dptr
      008AEE F9               [12] 1654 	mov	r1,a
      008AEF A3               [24] 1655 	inc	dptr
      008AF0 E0               [24] 1656 	movx	a,@dptr
      008AF1 FC               [12] 1657 	mov	r4,a
      008AF2 EA               [12] 1658 	mov	a,r2
      008AF3 29               [12] 1659 	add	a, r1
      008AF4 FA               [12] 1660 	mov	r2,a
      008AF5 EB               [12] 1661 	mov	a,r3
      008AF6 3C               [12] 1662 	addc	a, r4
      008AF7 FB               [12] 1663 	mov	r3,a
      008AF8 90 05 85         [24] 1664 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008AFB EA               [12] 1665 	mov	a,r2
      008AFC F0               [24] 1666 	movx	@dptr,a
      008AFD EB               [12] 1667 	mov	a,r3
      008AFE 12 38 70         [24] 1668 	lcall	_ak820_outline_0094
      008B01 90 05 88         [24] 1669 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008B04 E5 2C            [12] 1670 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008B06 12 38 9C         [24] 1671 	lcall	_ak820_outline_0136
      008B09 88 82            [24] 1672 	mov	dpl, r0
      008B0B 8D 83            [24] 1673 	mov	dph, r5
      008B0D C0 07            [24] 1674 	push	ar7
      008B0F C0 06            [24] 1675 	push	ar6
      008B11 C0 05            [24] 1676 	push	ar5
      008B13 C0 04            [24] 1677 	push	ar4
      008B15 12 40 AF         [24] 1678 	lcall	_ak820_eeprom_read_block_xdata
      008B18 D0 04            [24] 1679 	pop	ar4
      008B1A D0 05            [24] 1680 	pop	ar5
      008B1C D0 06            [24] 1681 	pop	ar6
      008B1E D0 07            [24] 1682 	pop	ar7
                                   1683 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008B20 D0 05            [24] 1684 	pop	ar5
      008B22 D0 04            [24] 1685 	pop	ar4
                                   1686 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008B24                       1687 00106$:
                                   1688 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008B24 90 0B 37         [24] 1689 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008B27 E0               [24] 1690 	movx	a,@dptr
      008B28 FB               [12] 1691 	mov	r3,a
      008B29                       1692 00109$:
      008B29 8B 01            [24] 1693 	mov	ar1,r3
      008B2B 7A 00            [12] 1694 	mov	r2,#0x00
      008B2D C3               [12] 1695 	clr	c
      008B2E E9               [12] 1696 	mov	a,r1
      008B2F 9C               [12] 1697 	subb	a,r4
      008B30 EA               [12] 1698 	mov	a,r2
      008B31 9D               [12] 1699 	subb	a,r5
      008B32 50 09            [24] 1700 	jnc	00111$
      008B34 EB               [12] 1701 	mov	a,r3
      008B35 12 38 31         [24] 1702 	lcall	_ak820_outline_0022
      008B38 E4               [12] 1703 	clr	a
      008B39 F0               [24] 1704 	movx	@dptr,a
      008B3A 0B               [12] 1705 	inc	r3
      008B3B 80 EC            [24] 1706 	sjmp	00109$
      008B3D                       1707 00111$:
                                   1708 ;	quantum/dynamic_keymap.c:420: }
      008B3D 22               [24] 1709 	ret
                                   1710 ;------------------------------------------------------------
                                   1711 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1712 ;------------------------------------------------------------
                                   1713 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1714 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1715 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1716 ;------------------------------------------------------------
                                   1717 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1718 ;	-----------------------------------------
                                   1719 ;	 function dynamic_keymap_get_buffer
                                   1720 ;	-----------------------------------------
      008B3E                       1721 _dynamic_keymap_get_buffer:
      008B3E 12 38 82         [24] 1722 	lcall	_ak820_outline_0109
      008B41 90 0B 3D         [24] 1723 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008B44 12 38 87         [24] 1724 	lcall	_ak820_outline_0110
                                   1725 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008B47 90 0B 3D         [24] 1726 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008B4A 12 38 41         [24] 1727 	lcall	_ak820_outline_0052
      008B4D 90 0B 38         [24] 1728 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008B50 12 38 58         [24] 1729 	lcall	_ak820_outline_0061
      008B53 90 0B 3A         [24] 1730 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008B56 12 4F 47         [24] 1731 	lcall	_ak820_outline_0092
      008B59 90 0B 2C         [24] 1732 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008B5C E4               [12] 1733 	clr	a
      008B5D F0               [24] 1734 	movx	@dptr,a
      008B5E 74 06            [12] 1735 	mov	a,#0x06
      008B60 A3               [24] 1736 	inc	dptr
      008B61 F0               [24] 1737 	movx	@dptr,a
      008B62 90 0B 2E         [24] 1738 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008B65 12 48 83         [24] 1739 	lcall	_ak820_outline_0060
      008B68 90 0B 30         [24] 1740 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008B6B 12 38 5E         [24] 1741 	lcall	_ak820_outline_0072
      008B6E 90 0B 32         [24] 1742 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008B71 E9               [12] 1743 	mov	a,r1
      008B72 12 4F 60         [24] 1744 	lcall	_ak820_outline_0161
      008B75 F0               [24] 1745 	movx	@dptr,a
      008B76 90 00 40         [24] 1746 	mov	dptr,#0x0040
                                   1747 ;	quantum/dynamic_keymap.c:448: }
      008B79 02 8A 88         [24] 1748 	ljmp	_ak820_dynamic_read_buffer
                                   1749 ;------------------------------------------------------------
                                   1750 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1751 ;------------------------------------------------------------
                                   1752 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1753 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1754 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1755 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1756 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1757 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1758 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1759 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1760 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1761 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1762 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1763 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1764 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1765 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1766 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1767 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1768 ;------------------------------------------------------------
                                   1769 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1770 ;	-----------------------------------------
                                   1771 ;	 function dynamic_keymap_set_buffer
                                   1772 ;	-----------------------------------------
      008B7C                       1773 _dynamic_keymap_set_buffer:
      008B7C 12 38 82         [24] 1774 	lcall	_ak820_outline_0109
      008B7F 90 0B 44         [24] 1775 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008B82 12 38 87         [24] 1776 	lcall	_ak820_outline_0110
                                   1777 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008B85 90 0B 44         [24] 1778 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008B88 12 48 26         [24] 1779 	lcall	_ak820_outline_0008
      008B8B 74 40            [12] 1780 	mov	a,#0x40
      008B8D 2C               [12] 1781 	add	a, r4
      008B8E FA               [12] 1782 	mov	r2,a
      008B8F E4               [12] 1783 	clr	a
      008B90 3D               [12] 1784 	addc	a, r5
      008B91 FB               [12] 1785 	mov	r3,a
                                   1786 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008B92 90 0B 41         [24] 1787 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008B95 12 38 7C         [24] 1788 	lcall	_ak820_outline_0104
                                   1789 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008B98 90 0B 3F         [24] 1790 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008B9B E0               [24] 1791 	movx	a,@dptr
      008B9C F5 2D            [12] 1792 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008B9E A3               [24] 1793 	inc	dptr
      008B9F E0               [24] 1794 	movx	a,@dptr
      008BA0 F5 2E            [12] 1795 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008BA2 E5 2D            [12] 1796 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008BA4 45 2E            [12] 1797 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008BA6 70 01            [24] 1798 	jnz	00102$
      008BA8 22               [24] 1799 	ret
      008BA9                       1800 00102$:
                                   1801 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008BA9 85 2D 2F         [24] 1802 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008BAC 85 2E 30         [24] 1803 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008BAF C3               [12] 1804 	clr	c
      008BB0 74 1C            [12] 1805 	mov	a,#0x1c
      008BB2 95 2F            [12] 1806 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008BB4 E4               [12] 1807 	clr	a
      008BB5 95 30            [12] 1808 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008BB7 50 01            [24] 1809 	jnc	00104$
                                   1810 ;	free result
      008BB9 22               [24] 1811 	ret
      008BBA                       1812 00104$:
                                   1813 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      008BBA 85 2D 31         [24] 1814 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1815 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008BBD 74 FA            [12] 1816 	mov	a,#0x100 - 0x06
      008BBF 2F               [12] 1817 	add	a,r7
      008BC0 40 11            [24] 1818 	jc	00105$
      008BC2 E4               [12] 1819 	clr	a
      008BC3 C3               [12] 1820 	clr	c
      008BC4 9E               [12] 1821 	subb	a,r6
      008BC5 FE               [12] 1822 	mov	r6,a
      008BC6 74 06            [12] 1823 	mov	a,#0x06
      008BC8 9F               [12] 1824 	subb	a,r7
      008BC9 FF               [12] 1825 	mov	r7,a
      008BCA C3               [12] 1826 	clr	c
      008BCB EE               [12] 1827 	mov	a,r6
      008BCC 95 2D            [12] 1828 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008BCE EF               [12] 1829 	mov	a,r7
      008BCF 95 2E            [12] 1830 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008BD1 50 01            [24] 1831 	jnc	00106$
      008BD3                       1832 00105$:
                                   1833 ;	quantum/dynamic_keymap.c:466: return;
      008BD3 22               [24] 1834 	ret
      008BD4                       1835 00106$:
                                   1836 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      008BD4 90 0E 42         [24] 1837 	mov	dptr,#_vial_unlocked
      008BD7 E0               [24] 1838 	movx	a,@dptr
      008BD8 60 03            [24] 1839 	jz	00207$
      008BDA 02 8C E7         [24] 1840 	ljmp	00120$
      008BDD                       1841 00207$:
                                   1842 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      008BDD 90 0B 46         [24] 1843 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008BE0 E4               [12] 1844 	clr	a
      008BE1 F0               [24] 1845 	movx	@dptr,a
                                   1846 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      008BE2 90 0B 47         [24] 1847 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008BE5 E5 31            [12] 1848 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008BE7 F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      008BE8 EC               [12] 1851 	mov	a,r4
      008BE9 30 E0 31         [24] 1852 	jnb	acc.0,00111$
                                   1853 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008BEC EA               [12] 1854 	mov	a,r2
      008BED 24 FF            [12] 1855 	add	a,#0xff
      008BEF FE               [12] 1856 	mov	r6,a
      008BF0 EB               [12] 1857 	mov	a,r3
      008BF1 34 FF            [12] 1858 	addc	a,#0xff
      008BF3 FF               [12] 1859 	mov	r7,a
      008BF4 7D 00            [12] 1860 	mov	r5,#0x00
      008BF6 12 72 13         [24] 1861 	lcall	_ak820_outline_0050
      008BF9 12 40 74         [24] 1862 	lcall	_eeprom_read_byte
      008BFC AE 82            [24] 1863 	mov	r6,dpl
      008BFE 7F 00            [12] 1864 	mov	r7,#0x00
      008C00 12 38 B6         [24] 1865 	lcall	_ak820_outline_0163
      008C03 E0               [24] 1866 	movx	a,@dptr
      008C04 7C 00            [12] 1867 	mov	r4,#0x00
      008C06 42 07            [12] 1868 	orl	ar7,a
      008C08 EC               [12] 1869 	mov	a,r4
      008C09 42 06            [12] 1870 	orl	ar6,a
                                   1871 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      008C0B BF 00 09         [24] 1872 	cjne	r7,#0x00,00109$
      008C0E BE 7C 06         [24] 1873 	cjne	r6,#0x7c,00109$
                                   1874 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008C11 12 38 B6         [24] 1875 	lcall	_ak820_outline_0163
      008C14 74 FF            [12] 1876 	mov	a,#0xff
      008C16 F0               [24] 1877 	movx	@dptr,a
      008C17                       1878 00109$:
                                   1879 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      008C17 90 0B 46         [24] 1880 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008C1A 74 01            [12] 1881 	mov	a,#0x01
      008C1C F0               [24] 1882 	movx	@dptr,a
      008C1D                       1883 00111$:
                                   1884 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      008C1D 90 0B 44         [24] 1885 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008C20 12 38 41         [24] 1886 	lcall	_ak820_outline_0052
      008C23 E5 2D            [12] 1887 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008C25 2E               [12] 1888 	add	a, r6
      008C26 FE               [12] 1889 	mov	r6,a
      008C27 E5 2E            [12] 1890 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008C29 3F               [12] 1891 	addc	a, r7
      008C2A EE               [12] 1892 	mov	a,r6
      008C2B 30 E0 5A         [24] 1893 	jnb	acc.0,00115$
                                   1894 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008C2E AE 31            [24] 1895 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008C30 7F 00            [12] 1896 	mov	r7,#0x00
      008C32 EE               [12] 1897 	mov	a,r6
      008C33 24 FF            [12] 1898 	add	a,#0xff
      008C35 FC               [12] 1899 	mov	r4,a
      008C36 EF               [12] 1900 	mov	a,r7
      008C37 34 FF            [12] 1901 	addc	a,#0xff
      008C39 FD               [12] 1902 	mov	r5,a
      008C3A EC               [12] 1903 	mov	a,r4
      008C3B 28               [12] 1904 	add	a, r0
      008C3C F5 82            [12] 1905 	mov	dpl,a
      008C3E ED               [12] 1906 	mov	a,r5
      008C3F 39               [12] 1907 	addc	a, r1
      008C40 F5 83            [12] 1908 	mov	dph,a
      008C42 E0               [24] 1909 	movx	a,@dptr
      008C43 FC               [12] 1910 	mov	r4,a
      008C44 7D 00            [12] 1911 	mov	r5,#0x00
      008C46 E5 31            [12] 1912 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008C48 2A               [12] 1913 	add	a, r2
      008C49 FA               [12] 1914 	mov	r2,a
      008C4A E4               [12] 1915 	clr	a
      008C4B 3B               [12] 1916 	addc	a, r3
      008C4C FB               [12] 1917 	mov	r3,a
      008C4D C0 00            [24] 1918 	push	ar0
      008C4F C0 01            [24] 1919 	push	ar1
      008C51 8B 01            [24] 1920 	mov	ar1,r3
      008C53 7B 00            [12] 1921 	mov	r3,#0x00
      008C55 8A 82            [24] 1922 	mov	dpl, r2
      008C57 89 83            [24] 1923 	mov	dph, r1
      008C59 8B F0            [24] 1924 	mov	b, r3
      008C5B 12 40 74         [24] 1925 	lcall	_eeprom_read_byte
      008C5E AB 82            [24] 1926 	mov	r3, dpl
      008C60 7A 00            [12] 1927 	mov	r2,#0x00
      008C62 EB               [12] 1928 	mov	a,r3
      008C63 12 43 67         [24] 1929 	lcall	_ak820_outline_0146
                                   1930 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008C66 BD 00 05         [24] 1931 	cjne	r5,#0x00,00212$
      008C69 BC 7C 02         [24] 1932 	cjne	r4,#0x7c,00212$
      008C6C 80 06            [24] 1933 	sjmp	00213$
      008C6E                       1934 00212$:
      008C6E D0 01            [24] 1935 	pop	ar1
      008C70 D0 00            [24] 1936 	pop	ar0
      008C72 80 0D            [24] 1937 	sjmp	00113$
      008C74                       1938 00213$:
      008C74 D0 01            [24] 1939 	pop	ar1
      008C76 D0 00            [24] 1940 	pop	ar0
                                   1941 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008C78 1E               [12] 1942 	dec	r6
      008C79 BE FF 01         [24] 1943 	cjne	r6,#0xff,00214$
      008C7C 1F               [12] 1944 	dec	r7
      008C7D                       1945 00214$:
      008C7D EE               [12] 1946 	mov	a,r6
      008C7E 12 91 20         [24] 1947 	lcall	_ak820_outline_0130
      008C81                       1948 00113$:
                                   1949 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008C81 E5 31            [12] 1950 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008C83 14               [12] 1951 	dec	a
      008C84 90 0B 47         [24] 1952 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008C87 F0               [24] 1953 	movx	@dptr,a
      008C88                       1954 00115$:
                                   1955 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008C88 90 0B 46         [24] 1956 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008C8B E0               [24] 1957 	movx	a,@dptr
      008C8C 90 0B 48         [24] 1958 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008C8F F0               [24] 1959 	movx	@dptr,a
      008C90                       1960 00122$:
      008C90 90 0B 48         [24] 1961 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008C93 E0               [24] 1962 	movx	a,@dptr
      008C94 FF               [12] 1963 	mov	r7,a
      008C95 90 0B 47         [24] 1964 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008C98 E0               [24] 1965 	movx	a,@dptr
      008C99 FE               [12] 1966 	mov	r6,a
      008C9A C3               [12] 1967 	clr	c
      008C9B EF               [12] 1968 	mov	a,r7
      008C9C 9E               [12] 1969 	subb	a,r6
      008C9D 50 48            [24] 1970 	jnc	00120$
                                   1971 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008C9F EF               [12] 1972 	mov	a,r7
      008CA0 28               [12] 1973 	add	a, r0
      008CA1 FD               [12] 1974 	mov	r5,a
      008CA2 E4               [12] 1975 	clr	a
      008CA3 39               [12] 1976 	addc	a, r1
      008CA4 FE               [12] 1977 	mov	r6,a
      008CA5 12 48 90         [24] 1978 	lcall	_ak820_outline_0077
      008CA8 7B 00            [12] 1979 	mov	r3,#0x00
      008CAA 8C 2E            [24] 1980 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008CAC 8B 2D            [24] 1981 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008CAE 8F 02            [24] 1982 	mov	ar2,r7
      008CB0 7F 00            [12] 1983 	mov	r7,#0x00
      008CB2 74 01            [12] 1984 	mov	a,#0x01
      008CB4 2A               [12] 1985 	add	a, r2
      008CB5 FB               [12] 1986 	mov	r3,a
      008CB6 E4               [12] 1987 	clr	a
      008CB7 3F               [12] 1988 	addc	a, r7
      008CB8 FC               [12] 1989 	mov	r4,a
      008CB9 EB               [12] 1990 	mov	a,r3
      008CBA 28               [12] 1991 	add	a, r0
      008CBB F5 82            [12] 1992 	mov	dpl,a
      008CBD EC               [12] 1993 	mov	a,r4
      008CBE 39               [12] 1994 	addc	a, r1
      008CBF F5 83            [12] 1995 	mov	dph,a
      008CC1 E0               [24] 1996 	movx	a,@dptr
      008CC2 FC               [12] 1997 	mov	r4,a
      008CC3 7B 00            [12] 1998 	mov	r3,#0x00
      008CC5 E5 2E            [12] 1999 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008CC7 42 03            [12] 2000 	orl	ar3,a
                                   2001 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008CC9 BC 00 12         [24] 2002 	cjne	r4,#0x00,00123$
      008CCC BB 7C 0F         [24] 2003 	cjne	r3,#0x7c,00123$
                                   2004 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008CCF 12 38 A1         [24] 2005 	lcall	_ak820_outline_0137
      008CD2 74 FF            [12] 2006 	mov	a,#0xff
      008CD4 F0               [24] 2007 	movx	@dptr,a
                                   2008 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008CD5 0A               [12] 2009 	inc	r2
      008CD6 BA 00 01         [24] 2010 	cjne	r2,#0x00,00218$
      008CD9 0F               [12] 2011 	inc	r7
      008CDA                       2012 00218$:
      008CDA EA               [12] 2013 	mov	a,r2
      008CDB 12 91 20         [24] 2014 	lcall	_ak820_outline_0130
      008CDE                       2015 00123$:
                                   2016 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008CDE 90 0B 48         [24] 2017 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008CE1 E0               [24] 2018 	movx	a,@dptr
      008CE2 24 02            [12] 2019 	add	a,#0x02
      008CE4 F0               [24] 2020 	movx	@dptr,a
      008CE5 80 A9            [24] 2021 	sjmp	00122$
      008CE7                       2022 00120$:
                                   2023 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008CE7 90 0B 44         [24] 2024 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008CEA 12 38 41         [24] 2025 	lcall	_ak820_outline_0052
      008CED 74 40            [12] 2026 	mov	a,#0x40
      008CEF 12 43 61         [24] 2027 	lcall	_ak820_outline_0139
      008CF2 90 05 8E         [24] 2028 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008CF5 12 48 83         [24] 2029 	lcall	_ak820_outline_0060
      008CF8 E4               [12] 2030 	clr	a
      008CF9 A3               [24] 2031 	inc	dptr
      008CFA F0               [24] 2032 	movx	@dptr,a
      008CFB 90 05 91         [24] 2033 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008CFE E5 2F            [12] 2034 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008D00 F0               [24] 2035 	movx	@dptr,a
      008D01 E5 30            [12] 2036 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008D03 A3               [24] 2037 	inc	dptr
      008D04 F0               [24] 2038 	movx	@dptr,a
      008D05 12 38 B6         [24] 2039 	lcall	_ak820_outline_0163
                                   2040 ;	quantum/dynamic_keymap.c:521: }
      008D08 02 41 3B         [24] 2041 	ljmp	_ak820_eeprom_write_block_xdata
                                   2042 ;------------------------------------------------------------
                                   2043 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2044 ;------------------------------------------------------------
                                   2045 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2046 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2047 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2048 ;------------------------------------------------------------
                                   2049 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2050 ;	-----------------------------------------
                                   2051 ;	 function keycode_at_keymap_location
                                   2052 ;	-----------------------------------------
      008D0B                       2053 _keycode_at_keymap_location:
      008D0B E5 82            [12] 2054 	mov	a,dpl
      008D0D 90 0B 4B         [24] 2055 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008D10 F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008D11 E0               [24] 2058 	movx	a,@dptr
      008D12 FF               [12] 2059 	mov	r7,a
      008D13 BF 06 00         [24] 2060 	cjne	r7,#0x06,00128$
      008D16                       2061 00128$:
      008D16 50 23            [24] 2062 	jnc	00102$
      008D18 90 0B 49         [24] 2063 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008D1B E0               [24] 2064 	movx	a,@dptr
      008D1C FE               [12] 2065 	mov	r6,a
      008D1D BE 10 00         [24] 2066 	cjne	r6,#0x10,00130$
      008D20                       2067 00130$:
      008D20 50 19            [24] 2068 	jnc	00102$
      008D22 90 0B 4A         [24] 2069 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008D25 E0               [24] 2070 	movx	a,@dptr
      008D26 FD               [12] 2071 	mov	r5,a
      008D27 BD 08 00         [24] 2072 	cjne	r5,#0x08,00132$
      008D2A                       2073 00132$:
      008D2A 50 0F            [24] 2074 	jnc	00102$
                                   2075 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      008D2C 90 0A FD         [24] 2076 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008D2F EE               [12] 2077 	mov	a,r6
      008D30 F0               [24] 2078 	movx	@dptr,a
      008D31 90 0A FE         [24] 2079 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008D34 ED               [12] 2080 	mov	a,r5
      008D35 F0               [24] 2081 	movx	@dptr,a
      008D36 8F 82            [24] 2082 	mov	dpl, r7
      008D38 02 86 AC         [24] 2083 	ljmp	_dynamic_keymap_get_keycode
      008D3B                       2084 00102$:
                                   2085 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008D3B 90 00 00         [24] 2086 	mov	dptr,#0x0000
                                   2087 ;	quantum/dynamic_keymap.c:528: }
      008D3E 22               [24] 2088 	ret
                                   2089 ;------------------------------------------------------------
                                   2090 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2091 ;------------------------------------------------------------
                                   2092 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2093 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2094 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2095 ;------------------------------------------------------------
                                   2096 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2097 ;	-----------------------------------------
                                   2098 ;	 function keycode_at_encodermap_location
                                   2099 ;	-----------------------------------------
      008D3F                       2100 _keycode_at_encodermap_location:
      008D3F E5 82            [12] 2101 	mov	a,dpl
      008D41 90 0B 4E         [24] 2102 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008D44 F0               [24] 2103 	movx	@dptr,a
                                   2104 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008D45 E0               [24] 2105 	movx	a,@dptr
      008D46 FF               [12] 2106 	mov	r7,a
      008D47 BF 06 00         [24] 2107 	cjne	r7,#0x06,00120$
      008D4A                       2108 00120$:
      008D4A 50 1E            [24] 2109 	jnc	00102$
      008D4C 90 0B 4C         [24] 2110 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008D4F E0               [24] 2111 	movx	a,@dptr
      008D50 FE               [12] 2112 	mov	r6,a
      008D51 BE 01 00         [24] 2113 	cjne	r6,#0x01,00122$
      008D54                       2114 00122$:
      008D54 50 14            [24] 2115 	jnc	00102$
                                   2116 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008D56 90 0B 4D         [24] 2117 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008D59 E0               [24] 2118 	movx	a,@dptr
      008D5A FE               [12] 2119 	mov	r6,a
      008D5B 90 0B 07         [24] 2120 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008D5E E4               [12] 2121 	clr	a
      008D5F F0               [24] 2122 	movx	@dptr,a
      008D60 90 0B 08         [24] 2123 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008D63 EE               [12] 2124 	mov	a,r6
      008D64 F0               [24] 2125 	movx	@dptr,a
      008D65 8F 82            [24] 2126 	mov	dpl, r7
      008D67 02 87 6B         [24] 2127 	ljmp	_dynamic_keymap_get_encoder
      008D6A                       2128 00102$:
                                   2129 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008D6A 90 00 00         [24] 2130 	mov	dptr,#0x0000
                                   2131 ;	quantum/dynamic_keymap.c:536: }
      008D6D 22               [24] 2132 	ret
                                   2133 ;------------------------------------------------------------
                                   2134 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2135 ;------------------------------------------------------------
                                   2136 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2137 ;	-----------------------------------------
                                   2138 ;	 function dynamic_keymap_macro_get_count
                                   2139 ;	-----------------------------------------
      008D6E                       2140 _dynamic_keymap_macro_get_count:
                                   2141 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008D6E 75 82 10         [24] 2142 	mov	dpl, #0x10
                                   2143 ;	quantum/dynamic_keymap.c:541: }
      008D71 22               [24] 2144 	ret
                                   2145 ;------------------------------------------------------------
                                   2146 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2147 ;------------------------------------------------------------
                                   2148 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2149 ;	-----------------------------------------
                                   2150 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2151 ;	-----------------------------------------
      008D72                       2152 _dynamic_keymap_macro_get_buffer_size:
                                   2153 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008D72 90 20 00         [24] 2154 	mov	dptr,#0x2000
                                   2155 ;	quantum/dynamic_keymap.c:545: }
      008D75 22               [24] 2156 	ret
                                   2157 ;------------------------------------------------------------
                                   2158 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2159 ;------------------------------------------------------------
                                   2160 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2161 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2162 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2163 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2164 ;------------------------------------------------------------
                                   2165 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2166 ;	-----------------------------------------
                                   2167 ;	 function dynamic_keymap_macro_get_buffer
                                   2168 ;	-----------------------------------------
      008D76                       2169 _dynamic_keymap_macro_get_buffer:
      008D76 12 38 82         [24] 2170 	lcall	_ak820_outline_0109
      008D79 90 0B 54         [24] 2171 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008D7C 12 38 87         [24] 2172 	lcall	_ak820_outline_0110
                                   2173 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008D7F 12 2B 2B         [24] 2174 	lcall	_ak820_macro_length
      008D82 12 43 5C         [24] 2175 	lcall	_ak820_outline_0135
      008D85 90 0B 54         [24] 2176 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008D88 12 38 58         [24] 2177 	lcall	_ak820_outline_0061
      008D8B 90 0B 4F         [24] 2178 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008D8E E0               [24] 2179 	movx	a,@dptr
      008D8F F5 32            [12] 2180 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008D91 A3               [24] 2181 	inc	dptr
      008D92 E0               [24] 2182 	movx	a,@dptr
      008D93 F5 33            [12] 2183 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008D95 90 0B 51         [24] 2184 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008D98 12 38 7C         [24] 2185 	lcall	_ak820_outline_0104
      008D9B A3               [24] 2186 	inc	dptr
      008D9C E0               [24] 2187 	movx	a,@dptr
      008D9D FB               [12] 2188 	mov	r3,a
      008D9E 90 0B 2C         [24] 2189 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008DA1 12 48 83         [24] 2190 	lcall	_ak820_outline_0060
      008DA4 90 0B 2E         [24] 2191 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008DA7 12 38 5E         [24] 2192 	lcall	_ak820_outline_0072
      008DAA 90 0B 30         [24] 2193 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008DAD E5 32            [12] 2194 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008DAF F0               [24] 2195 	movx	@dptr,a
      008DB0 E5 33            [12] 2196 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008DB2 A3               [24] 2197 	inc	dptr
      008DB3 F0               [24] 2198 	movx	@dptr,a
      008DB4 90 0B 32         [24] 2199 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008DB7 E8               [12] 2200 	mov	a,r0
      008DB8 F0               [24] 2201 	movx	@dptr,a
      008DB9 E9               [12] 2202 	mov	a,r1
      008DBA A3               [24] 2203 	inc	dptr
      008DBB 12 7A 2D         [24] 2204 	lcall	_ak820_outline_0189
      008DBE 90 08 00         [24] 2205 	mov	dptr,#0x0800
                                   2206 ;	quantum/dynamic_keymap.c:572: }
      008DC1 02 8A 88         [24] 2207 	ljmp	_ak820_dynamic_read_buffer
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2210 ;------------------------------------------------------------
                                   2211 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2212 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2213 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2214 ;------------------------------------------------------------
                                   2215 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2216 ;	-----------------------------------------
                                   2217 ;	 function dynamic_keymap_macro_set_buffer
                                   2218 ;	-----------------------------------------
      008DC4                       2219 _dynamic_keymap_macro_set_buffer:
      008DC4 12 38 82         [24] 2220 	lcall	_ak820_outline_0109
      008DC7 90 0B 5B         [24] 2221 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008DCA 12 38 87         [24] 2222 	lcall	_ak820_outline_0110
                                   2223 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      008DCD 90 0B 5B         [24] 2224 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008DD0 12 38 41         [24] 2225 	lcall	_ak820_outline_0052
      008DD3 90 0B 56         [24] 2226 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008DD6 12 38 58         [24] 2227 	lcall	_ak820_outline_0061
      008DD9 90 0B 58         [24] 2228 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008DDC 12 4F 47         [24] 2229 	lcall	_ak820_outline_0092
      008DDF 90 05 14         [24] 2230 	mov	dptr,#_ak820_macro_write_PARM_2
      008DE2 12 38 5E         [24] 2231 	lcall	_ak820_outline_0072
      008DE5 90 05 16         [24] 2232 	mov	dptr,#_ak820_macro_write_PARM_3
      008DE8 E9               [12] 2233 	mov	a,r1
      008DE9 12 4F 60         [24] 2234 	lcall	_ak820_outline_0161
      008DEC 12 43 3E         [24] 2235 	lcall	_ak820_outline_0079
                                   2236 ;	quantum/dynamic_keymap.c:577: }
      008DEF 02 2B 45         [24] 2237 	ljmp	_ak820_macro_write
                                   2238 ;------------------------------------------------------------
                                   2239 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2240 ;------------------------------------------------------------
                                   2241 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2242 ;	-----------------------------------------
                                   2243 ;	 function dynamic_keymap_macro_reset
                                   2244 ;	-----------------------------------------
      008DF2                       2245 _dynamic_keymap_macro_reset:
                                   2246 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2247 ;	quantum/dynamic_keymap.c:603: }
      008DF2 02 2E 64         [24] 2248 	ljmp	_ak820_macro_reset
                                   2249 ;------------------------------------------------------------
                                   2250 ;Allocation info for local variables in function 'decode_keycode'
                                   2251 ;------------------------------------------------------------
                                   2252 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2253 ;------------------------------------------------------------
                                   2254 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2255 ;	-----------------------------------------
                                   2256 ;	 function decode_keycode
                                   2257 ;	-----------------------------------------
      008DF5                       2258 _decode_keycode:
      008DF5 12 38 82         [24] 2259 	lcall	_ak820_outline_0109
      008DF8 90 0B 5D         [24] 2260 	mov	dptr,#_decode_keycode_kc_10000_455
      008DFB 12 38 87         [24] 2261 	lcall	_ak820_outline_0110
                                   2262 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      008DFE 90 0B 5D         [24] 2263 	mov	dptr,#_decode_keycode_kc_10000_455
      008E01 12 48 26         [24] 2264 	lcall	_ak820_outline_0008
      008E04 C3               [12] 2265 	clr	c
      008E05 E4               [12] 2266 	clr	a
      008E06 9C               [12] 2267 	subb	a,r4
      008E07 74 FF            [12] 2268 	mov	a,#0xff
      008E09 9D               [12] 2269 	subb	a,r5
      008E0A 50 08            [24] 2270 	jnc	00102$
                                   2271 ;	free result
                                   2272 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      008E0C 8C 05            [24] 2273 	mov	ar5,r4
      008E0E 7C 00            [12] 2274 	mov	r4,#0x00
      008E10 12 38 97         [24] 2275 	lcall	_ak820_outline_0126
      008E13 22               [24] 2276 	ret
      008E14                       2277 00102$:
                                   2278 ;	quantum/dynamic_keymap.c:609: return kc;
      008E14 12 38 8C         [24] 2279 	lcall	_ak820_outline_0120
                                   2280 ;	quantum/dynamic_keymap.c:610: }
      008E17 22               [24] 2281 	ret
                                   2282 ;------------------------------------------------------------
                                   2283 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2284 ;------------------------------------------------------------
                                   2285 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2286 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2287 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2288 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2289 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2290 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2291 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2292 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2293 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2294 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2295 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2296 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2297 ;------------------------------------------------------------
                                   2298 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2299 ;	-----------------------------------------
                                   2300 ;	 function dynamic_keymap_macro_send
                                   2301 ;	-----------------------------------------
      008E18                       2302 _dynamic_keymap_macro_send:
      008E18 E5 82            [12] 2303 	mov	a,dpl
      008E1A 90 0B 5F         [24] 2304 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008E1D F0               [24] 2305 	movx	@dptr,a
                                   2306 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      008E1E 90 0B 60         [24] 2307 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008E21 E0               [24] 2308 	movx	a,@dptr
      008E22 60 01            [24] 2309 	jz	00102$
      008E24 22               [24] 2310 	ret
      008E25                       2311 00102$:
                                   2312 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008E25 90 0B 5F         [24] 2313 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008E28 E0               [24] 2314 	movx	a,@dptr
      008E29 FF               [12] 2315 	mov	r7,a
      008E2A BF 10 00         [24] 2316 	cjne	r7,#0x10,00422$
      008E2D                       2317 00422$:
      008E2D 40 01            [24] 2318 	jc	00104$
                                   2319 ;	quantum/dynamic_keymap.c:620: return;
      008E2F 22               [24] 2320 	ret
      008E30                       2321 00104$:
                                   2322 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      008E30 C0 07            [24] 2323 	push	ar7
      008E32 12 2A F2         [24] 2324 	lcall	_ak820_macro_ready
      008E35 E5 82            [12] 2325 	mov	a, dpl
      008E37 D0 07            [24] 2326 	pop	ar7
      008E39 70 01            [24] 2327 	jnz	00106$
      008E3B 22               [24] 2328 	ret
      008E3C                       2329 00106$:
                                   2330 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008E3C 90 0B 61         [24] 2331 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E3F E4               [12] 2332 	clr	a
      008E40 F0               [24] 2333 	movx	@dptr,a
      008E41 74 08            [12] 2334 	mov	a,#0x08
      008E43 A3               [24] 2335 	inc	dptr
      008E44 F0               [24] 2336 	movx	@dptr,a
                                   2337 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008E45 C0 07            [24] 2338 	push	ar7
      008E47 12 2B 2B         [24] 2339 	lcall	_ak820_macro_length
      008E4A AD 82            [24] 2340 	mov	r5, dpl
      008E4C AE 83            [24] 2341 	mov	r6, dph
      008E4E D0 07            [24] 2342 	pop	ar7
      008E50 74 08            [12] 2343 	mov	a,#0x08
      008E52 2E               [12] 2344 	add	a, r6
      008E53 FE               [12] 2345 	mov	r6,a
                                   2346 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      008E54 7B 00            [12] 2347 	mov	r3,#0x00
      008E56 7C 08            [12] 2348 	mov	r4,#0x08
      008E58                       2349 00111$:
      008E58 EF               [12] 2350 	mov	a,r7
      008E59 60 31            [24] 2351 	jz	00113$
                                   2352 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      008E5B EB               [12] 2353 	mov	a,r3
      008E5C B5 05 05         [24] 2354 	cjne	a,ar5,00108$
      008E5F EC               [12] 2355 	mov	a,r4
      008E60 B5 06 01         [24] 2356 	cjne	a,ar6,00108$
                                   2357 ;	quantum/dynamic_keymap.c:654: return;
      008E63 22               [24] 2358 	ret
      008E64                       2359 00108$:
                                   2360 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008E64 8B 01            [24] 2361 	mov	ar1,r3
      008E66 8C 02            [24] 2362 	mov	ar2,r4
      008E68 8A 00            [24] 2363 	mov	ar0,r2
      008E6A 7A 00            [12] 2364 	mov	r2,#0x00
      008E6C 89 82            [24] 2365 	mov	dpl, r1
      008E6E 88 83            [24] 2366 	mov	dph, r0
      008E70 8A F0            [24] 2367 	mov	b, r2
      008E72 12 40 74         [24] 2368 	lcall	_eeprom_read_byte
      008E75 E5 82            [12] 2369 	mov	a, dpl
      008E77 70 06            [24] 2370 	jnz	00110$
                                   2371 ;	quantum/dynamic_keymap.c:657: --id;
      008E79 1F               [12] 2372 	dec	r7
      008E7A 90 0B 5F         [24] 2373 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008E7D EF               [12] 2374 	mov	a,r7
      008E7E F0               [24] 2375 	movx	@dptr,a
      008E7F                       2376 00110$:
                                   2377 ;	quantum/dynamic_keymap.c:659: ++p;
      008E7F 0B               [12] 2378 	inc	r3
      008E80 BB 00 01         [24] 2379 	cjne	r3,#0x00,00429$
      008E83 0C               [12] 2380 	inc	r4
      008E84                       2381 00429$:
      008E84 90 0B 61         [24] 2382 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E87 12 38 6A         [24] 2383 	lcall	_ak820_outline_0086
      008E8A 80 CC            [24] 2384 	sjmp	00111$
      008E8C                       2385 00113$:
                                   2386 ;	quantum/dynamic_keymap.c:665: sending = true;
      008E8C 90 0B 60         [24] 2387 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008E8F 74 01            [12] 2388 	mov	a,#0x01
      008E91 F0               [24] 2389 	movx	@dptr,a
                                   2390 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      008E92 12 91 38         [24] 2391 	lcall	_ak820_outline_0170
      008E95 90 09 A9         [24] 2392 	mov	dptr,#_ak820_macro_cancelled
      008E98 F0               [24] 2393 	movx	@dptr,a
                                   2394 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      008E99 90 0B 63         [24] 2395 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008E9C F0               [24] 2396 	movx	@dptr,a
      008E9D 90 0B 64         [24] 2397 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008EA0 F0               [24] 2398 	movx	@dptr,a
      008EA1 90 0B 65         [24] 2399 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008EA4 F0               [24] 2400 	movx	@dptr,a
      008EA5 90 0B 66         [24] 2401 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008EA8 F0               [24] 2402 	movx	@dptr,a
                                   2403 ;	quantum/dynamic_keymap.c:675: while (p < end
      008EA9                       2404 00167$:
                                   2405 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      008EA9 90 0B 61         [24] 2406 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008EAC E0               [24] 2407 	movx	a,@dptr
      008EAD FC               [12] 2408 	mov	r4,a
      008EAE A3               [24] 2409 	inc	dptr
      008EAF E0               [24] 2410 	movx	a,@dptr
      008EB0 FF               [12] 2411 	mov	r7,a
      008EB1 C3               [12] 2412 	clr	c
      008EB2 EC               [12] 2413 	mov	a,r4
      008EB3 9D               [12] 2414 	subb	a,r5
      008EB4 EF               [12] 2415 	mov	a,r7
      008EB5 9E               [12] 2416 	subb	a,r6
      008EB6 40 03            [24] 2417 	jc	00430$
      008EB8 02 90 CD         [24] 2418 	ljmp	00169$
      008EBB                       2419 00430$:
      008EBB 90 09 A9         [24] 2420 	mov	dptr,#_ak820_macro_cancelled
      008EBE E0               [24] 2421 	movx	a,@dptr
      008EBF 60 03            [24] 2422 	jz	00431$
      008EC1 02 90 CD         [24] 2423 	ljmp	00169$
      008EC4                       2424 00431$:
                                   2425 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EC4 8C 02            [24] 2426 	mov	ar2,r4
      008EC6 8F 03            [24] 2427 	mov	ar3,r7
      008EC8 90 0B 61         [24] 2428 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008ECB 74 01            [12] 2429 	mov	a,#0x01
      008ECD 2C               [12] 2430 	add	a, r4
      008ECE F0               [24] 2431 	movx	@dptr,a
      008ECF E4               [12] 2432 	clr	a
      008ED0 3F               [12] 2433 	addc	a, r7
      008ED1 A3               [24] 2434 	inc	dptr
      008ED2 F0               [24] 2435 	movx	@dptr,a
      008ED3 7F 00            [12] 2436 	mov	r7,#0x00
      008ED5 12 38 AC         [24] 2437 	lcall	_ak820_outline_0147
      008ED8 8F F0            [24] 2438 	mov	b, r7
      008EDA 12 40 74         [24] 2439 	lcall	_eeprom_read_byte
      008EDD AF 82            [24] 2440 	mov	r7, dpl
      008EDF 90 0B 63         [24] 2441 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008EE2 EF               [12] 2442 	mov	a,r7
      008EE3 F0               [24] 2443 	movx	@dptr,a
                                   2444 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      008EE4 90 0B 64         [24] 2445 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008EE7 E4               [12] 2446 	clr	a
      008EE8 F0               [24] 2447 	movx	@dptr,a
                                   2448 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      008EE9 90 0B 63         [24] 2449 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008EEC E0               [24] 2450 	movx	a,@dptr
      008EED 70 03            [24] 2451 	jnz	00432$
      008EEF 02 90 CD         [24] 2452 	ljmp	00169$
      008EF2                       2453 00432$:
                                   2454 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      008EF2 90 0B 63         [24] 2455 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008EF5 E0               [24] 2456 	movx	a,@dptr
      008EF6 FF               [12] 2457 	mov	r7,a
      008EF7 BF 01 02         [24] 2458 	cjne	r7,#0x01,00433$
      008EFA 80 03            [24] 2459 	sjmp	00434$
      008EFC                       2460 00433$:
      008EFC 02 90 AF         [24] 2461 	ljmp	00164$
      008EFF                       2462 00434$:
                                   2463 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EFF 12 90 D5         [24] 2464 	lcall	_ak820_outline_0000
      008F02 12 40 74         [24] 2465 	lcall	_eeprom_read_byte
      008F05 AF 82            [24] 2466 	mov	r7, dpl
      008F07 90 0B 64         [24] 2467 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008F0A EF               [12] 2468 	mov	a,r7
      008F0B F0               [24] 2469 	movx	@dptr,a
                                   2470 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      008F0C EF               [12] 2471 	mov	a,r7
      008F0D 70 03            [24] 2472 	jnz	00435$
      008F0F 02 90 CD         [24] 2473 	ljmp	00169$
      008F12                       2474 00435$:
                                   2475 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008F12 12 90 FF         [24] 2476 	lcall	_ak820_outline_0095
      008F15 BF 01 02         [24] 2477 	cjne	r7,#0x01,00436$
      008F18 80 13            [24] 2478 	sjmp	00151$
      008F1A                       2479 00436$:
      008F1A 12 90 FF         [24] 2480 	lcall	_ak820_outline_0095
      008F1D BF 02 02         [24] 2481 	cjne	r7,#0x02,00437$
      008F20 80 0B            [24] 2482 	sjmp	00151$
      008F22                       2483 00437$:
      008F22 12 90 FF         [24] 2484 	lcall	_ak820_outline_0095
      008F25 BF 03 02         [24] 2485 	cjne	r7,#0x03,00438$
      008F28 80 03            [24] 2486 	sjmp	00439$
      008F2A                       2487 00438$:
      008F2A 02 8F 8E         [24] 2488 	ljmp	00152$
      008F2D                       2489 00439$:
      008F2D                       2490 00151$:
                                   2491 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F2D 12 90 D5         [24] 2492 	lcall	_ak820_outline_0000
      008F30 12 40 74         [24] 2493 	lcall	_eeprom_read_byte
      008F33 12 91 50         [24] 2494 	lcall	_ak820_outline_0183
                                   2495 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      008F36 70 03            [24] 2496 	jnz	00440$
      008F38 02 8E A9         [24] 2497 	ljmp	00167$
      008F3B                       2498 00440$:
                                   2499 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008F3B 12 90 FF         [24] 2500 	lcall	_ak820_outline_0095
      008F3E BF 01 03         [24] 2501 	cjne	r7,#0x01,00441$
      008F41 D3               [12] 2502 	setb	c
      008F42 80 01            [24] 2503 	sjmp	00442$
      008F44                       2504 00441$:
      008F44 C3               [12] 2505 	clr	c
      008F45                       2506 00442$:
      008F45 92 24            [24] 2507 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008F47 90 09 A8         [24] 2508 	mov	dptr,#_ak820_macro_primitive
      008F4A B3               [12] 2509 	cpl	c
      008F4B E4               [12] 2510 	clr	a
      008F4C 33               [12] 2511 	rlc	a
      008F4D F0               [24] 2512 	movx	@dptr,a
                                   2513 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008F4E 12 90 FF         [24] 2514 	lcall	_ak820_outline_0095
      008F51 BF 01 10         [24] 2515 	cjne	r7,#0x01,00122$
      008F54 12 91 31         [24] 2516 	lcall	_ak820_outline_0157
      008F57 C0 06            [24] 2517 	push	ar6
      008F59 C0 05            [24] 2518 	push	ar5
      008F5B 12 78 F0         [24] 2519 	lcall	_tap_code
      008F5E D0 05            [24] 2520 	pop	ar5
      008F60 D0 06            [24] 2521 	pop	ar6
      008F62 80 24            [24] 2522 	sjmp	00123$
      008F64                       2523 00122$:
                                   2524 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008F64 12 90 FF         [24] 2525 	lcall	_ak820_outline_0095
      008F67 BF 02 10         [24] 2526 	cjne	r7,#0x02,00119$
      008F6A 12 91 31         [24] 2527 	lcall	_ak820_outline_0157
      008F6D C0 06            [24] 2528 	push	ar6
      008F6F C0 05            [24] 2529 	push	ar5
      008F71 12 77 BD         [24] 2530 	lcall	_register_code
      008F74 D0 05            [24] 2531 	pop	ar5
      008F76 D0 06            [24] 2532 	pop	ar6
      008F78 80 0E            [24] 2533 	sjmp	00123$
      008F7A                       2534 00119$:
                                   2535 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      008F7A 12 91 31         [24] 2536 	lcall	_ak820_outline_0157
      008F7D C0 06            [24] 2537 	push	ar6
      008F7F C0 05            [24] 2538 	push	ar5
      008F81 12 78 42         [24] 2539 	lcall	_unregister_code
      008F84 D0 05            [24] 2540 	pop	ar5
      008F86 D0 06            [24] 2541 	pop	ar6
      008F88                       2542 00123$:
                                   2543 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      008F88 12 91 38         [24] 2544 	lcall	_ak820_outline_0170
      008F8B 02 8E A9         [24] 2545 	ljmp	00167$
      008F8E                       2546 00152$:
                                   2547 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008F8E 12 90 FF         [24] 2548 	lcall	_ak820_outline_0095
      008F91 BF 05 02         [24] 2549 	cjne	r7,#0x05,00447$
      008F94 80 13            [24] 2550 	sjmp	00146$
      008F96                       2551 00447$:
      008F96 12 90 FF         [24] 2552 	lcall	_ak820_outline_0095
      008F99 BF 06 02         [24] 2553 	cjne	r7,#0x06,00448$
      008F9C 80 0B            [24] 2554 	sjmp	00146$
      008F9E                       2555 00448$:
      008F9E 12 90 FF         [24] 2556 	lcall	_ak820_outline_0095
      008FA1 BF 07 02         [24] 2557 	cjne	r7,#0x07,00449$
      008FA4 80 03            [24] 2558 	sjmp	00450$
      008FA6                       2559 00449$:
      008FA6 02 90 4F         [24] 2560 	ljmp	00147$
      008FA9                       2561 00450$:
      008FA9                       2562 00146$:
                                   2563 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008FA9 12 90 D5         [24] 2564 	lcall	_ak820_outline_0000
      008FAC 12 40 74         [24] 2565 	lcall	_eeprom_read_byte
      008FAF 12 91 50         [24] 2566 	lcall	_ak820_outline_0183
                                   2567 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      008FB2 70 03            [24] 2568 	jnz	00451$
      008FB4 02 8E A9         [24] 2569 	ljmp	00167$
      008FB7                       2570 00451$:
                                   2571 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008FB7 12 90 D5         [24] 2572 	lcall	_ak820_outline_0000
      008FBA 12 40 74         [24] 2573 	lcall	_eeprom_read_byte
      008FBD AF 82            [24] 2574 	mov	r7, dpl
      008FBF 90 0B 66         [24] 2575 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008FC2 EF               [12] 2576 	mov	a,r7
      008FC3 F0               [24] 2577 	movx	@dptr,a
                                   2578 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      008FC4 EF               [12] 2579 	mov	a,r7
      008FC5 70 03            [24] 2580 	jnz	00452$
      008FC7 02 8E A9         [24] 2581 	ljmp	00167$
      008FCA                       2582 00452$:
                                   2583 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008FCA 90 0B 65         [24] 2584 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008FCD E0               [24] 2585 	movx	a,@dptr
      008FCE FF               [12] 2586 	mov	r7,a
      008FCF 90 0B 66         [24] 2587 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008FD2 E0               [24] 2588 	movx	a,@dptr
      008FD3 FB               [12] 2589 	mov	r3,a
      008FD4 E4               [12] 2590 	clr	a
      008FD5 FC               [12] 2591 	mov	r4,a
      008FD6 FA               [12] 2592 	mov	r2,a
      008FD7 EF               [12] 2593 	mov	a,r7
      008FD8 42 04            [12] 2594 	orl	ar4,a
      008FDA EA               [12] 2595 	mov	a,r2
      008FDB 42 03            [12] 2596 	orl	ar3,a
                                   2597 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      008FDD 12 43 88         [24] 2598 	lcall	_ak820_outline_0186
      008FE0 C0 06            [24] 2599 	push	ar6
      008FE2 C0 05            [24] 2600 	push	ar5
      008FE4 12 8D F5         [24] 2601 	lcall	_decode_keycode
      008FE7 AC 82            [24] 2602 	mov	r4, dpl
      008FE9 AF 83            [24] 2603 	mov	r7, dph
      008FEB D0 05            [24] 2604 	pop	ar5
      008FED D0 06            [24] 2605 	pop	ar6
                                   2606 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008FEF 90 0B 64         [24] 2607 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008FF2 E0               [24] 2608 	movx	a,@dptr
      008FF3 FB               [12] 2609 	mov	r3,a
      008FF4 BB 05 03         [24] 2610 	cjne	r3,#0x05,00453$
      008FF7 D3               [12] 2611 	setb	c
      008FF8 80 01            [24] 2612 	sjmp	00454$
      008FFA                       2613 00453$:
      008FFA C3               [12] 2614 	clr	c
      008FFB                       2615 00454$:
      008FFB 92 24            [24] 2616 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008FFD 90 09 A8         [24] 2617 	mov	dptr,#_ak820_macro_primitive
      009000 B3               [12] 2618 	cpl	c
      009001 E4               [12] 2619 	clr	a
      009002 33               [12] 2620 	rlc	a
      009003 F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      009004 90 0B 64         [24] 2623 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009007 E0               [24] 2624 	movx	a,@dptr
      009008 FB               [12] 2625 	mov	r3,a
      009009 BB 05 02         [24] 2626 	cjne	r3,#0x05,00455$
      00900C 80 0A            [24] 2627 	sjmp	00126$
      00900E                       2628 00455$:
      00900E BB 06 02         [24] 2629 	cjne	r3,#0x06,00456$
      009011 80 16            [24] 2630 	sjmp	00127$
      009013                       2631 00456$:
                                   2632 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      009013 BB 07 33         [24] 2633 	cjne	r3,#0x07,00129$
      009016 80 22            [24] 2634 	sjmp	00128$
      009018                       2635 00126$:
                                   2636 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      009018 8C 82            [24] 2637 	mov	dpl, r4
      00901A 8F 83            [24] 2638 	mov	dph, r7
      00901C C0 06            [24] 2639 	push	ar6
      00901E C0 05            [24] 2640 	push	ar5
      009020 12 B4 AA         [24] 2641 	lcall	_vial_keycode_tap
      009023 D0 05            [24] 2642 	pop	ar5
      009025 D0 06            [24] 2643 	pop	ar6
                                   2644 ;	quantum/dynamic_keymap.c:732: break;
                                   2645 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      009027 80 20            [24] 2646 	sjmp	00129$
      009029                       2647 00127$:
                                   2648 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      009029 8C 82            [24] 2649 	mov	dpl, r4
      00902B 8F 83            [24] 2650 	mov	dph, r7
      00902D C0 06            [24] 2651 	push	ar6
      00902F C0 05            [24] 2652 	push	ar5
      009031 12 B3 DF         [24] 2653 	lcall	_vial_keycode_down
      009034 D0 05            [24] 2654 	pop	ar5
      009036 D0 06            [24] 2655 	pop	ar6
                                   2656 ;	quantum/dynamic_keymap.c:735: break;
                                   2657 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      009038 80 0F            [24] 2658 	sjmp	00129$
      00903A                       2659 00128$:
                                   2660 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      00903A 8C 82            [24] 2661 	mov	dpl, r4
      00903C 8F 83            [24] 2662 	mov	dph, r7
      00903E C0 06            [24] 2663 	push	ar6
      009040 C0 05            [24] 2664 	push	ar5
      009042 12 B4 45         [24] 2665 	lcall	_vial_keycode_up
      009045 D0 05            [24] 2666 	pop	ar5
      009047 D0 06            [24] 2667 	pop	ar6
                                   2668 ;	quantum/dynamic_keymap.c:739: }
      009049                       2669 00129$:
                                   2670 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      009049 12 91 38         [24] 2671 	lcall	_ak820_outline_0170
      00904C 02 8E A9         [24] 2672 	ljmp	00167$
      00904F                       2673 00147$:
                                   2674 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      00904F 12 90 FF         [24] 2675 	lcall	_ak820_outline_0095
      009052 BF 04 02         [24] 2676 	cjne	r7,#0x04,00458$
      009055 80 03            [24] 2677 	sjmp	00459$
      009057                       2678 00458$:
      009057 02 8E A9         [24] 2679 	ljmp	00167$
      00905A                       2680 00459$:
                                   2681 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00905A 12 90 D5         [24] 2682 	lcall	_ak820_outline_0000
      00905D 12 40 74         [24] 2683 	lcall	_eeprom_read_byte
      009060 AF 82            [24] 2684 	mov	r7, dpl
                                   2685 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009062 90 0B 61         [24] 2686 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009065 12 38 91         [24] 2687 	lcall	_ak820_outline_0124
      009068 90 0B 61         [24] 2688 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      00906B 74 01            [12] 2689 	mov	a,#0x01
      00906D 2B               [12] 2690 	add	a, r3
      00906E F0               [24] 2691 	movx	@dptr,a
      00906F E4               [12] 2692 	clr	a
      009070 3C               [12] 2693 	addc	a, r4
      009071 A3               [24] 2694 	inc	dptr
      009072 F0               [24] 2695 	movx	@dptr,a
      009073 7A 00            [12] 2696 	mov	r2,#0x00
      009075 12 33 FC         [24] 2697 	lcall	_ak820_outline_0125
      009078 8A F0            [24] 2698 	mov	b, r2
      00907A 12 40 74         [24] 2699 	lcall	_eeprom_read_byte
      00907D AC 82            [24] 2700 	mov	r4, dpl
                                   2701 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      00907F EF               [12] 2702 	mov	a,r7
      009080 60 4B            [24] 2703 	jz	00169$
      009082 EC               [12] 2704 	mov	a,r4
      009083 60 48            [24] 2705 	jz	00169$
                                   2706 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      009085 1F               [12] 2707 	dec	r7
      009086 1C               [12] 2708 	dec	r4
      009087 EC               [12] 2709 	mov	a,r4
      009088 75 F0 FF         [24] 2710 	mov	b,#0xff
      00908B A4               [48] 2711 	mul	ab
      00908C FC               [12] 2712 	mov	r4,a
      00908D AB F0            [24] 2713 	mov	r3,b
      00908F 7A 00            [12] 2714 	mov	r2,#0x00
      009091 EC               [12] 2715 	mov	a,r4
      009092 2F               [12] 2716 	add	a, r7
      009093 FC               [12] 2717 	mov	r4,a
      009094 EB               [12] 2718 	mov	a,r3
      009095 3A               [12] 2719 	addc	a, r2
      009096 FB               [12] 2720 	mov	r3,a
                                   2721 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      009097                       2722 00141$:
      009097 8C 02            [24] 2723 	mov	ar2,r4
      009099 8B 07            [24] 2724 	mov	ar7,r3
      00909B 1C               [12] 2725 	dec	r4
      00909C BC FF 01         [24] 2726 	cjne	r4,#0xff,00462$
      00909F 1B               [12] 2727 	dec	r3
      0090A0                       2728 00462$:
      0090A0 EA               [12] 2729 	mov	a,r2
      0090A1 4F               [12] 2730 	orl	a,r7
      0090A2 70 03            [24] 2731 	jnz	00463$
      0090A4 02 8E A9         [24] 2732 	ljmp	00167$
      0090A7                       2733 00463$:
      0090A7 90 00 01         [24] 2734 	mov	dptr,#0x0001
      0090AA 12 5B 4C         [24] 2735 	lcall	_mDelaymS
      0090AD 80 E8            [24] 2736 	sjmp	00141$
      0090AF                       2737 00164$:
                                   2738 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      0090AF 90 0B 63         [24] 2739 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      0090B2 E0               [24] 2740 	movx	a,@dptr
      0090B3 FF               [12] 2741 	mov	r7,a
      0090B4 BF 80 00         [24] 2742 	cjne	r7,#0x80,00464$
      0090B7                       2743 00464$:
      0090B7 50 14            [24] 2744 	jnc	00169$
                                   2745 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      0090B9 90 0B 63         [24] 2746 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      0090BC E0               [24] 2747 	movx	a,@dptr
      0090BD F5 82            [12] 2748 	mov	dpl,a
      0090BF C0 06            [24] 2749 	push	ar6
      0090C1 C0 05            [24] 2750 	push	ar5
      0090C3 12 A7 51         [24] 2751 	lcall	_send_char
      0090C6 D0 05            [24] 2752 	pop	ar5
      0090C8 D0 06            [24] 2753 	pop	ar6
                                   2754 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      0090CA 02 8E A9         [24] 2755 	ljmp	00167$
      0090CD                       2756 00169$:
                                   2757 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      0090CD 12 91 38         [24] 2758 	lcall	_ak820_outline_0170
                                   2759 ;	quantum/dynamic_keymap.c:774: sending = false;
      0090D0 90 0B 60         [24] 2760 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      0090D3 F0               [24] 2761 	movx	@dptr,a
                                   2762 ;	quantum/dynamic_keymap.c:776: }
      0090D4 22               [24] 2763 	ret
                                   2764 	.area CSEG    (CODE)
                                   2765 	.area CONST   (CODE)
                                   2766 	.area XINIT   (CODE)
                                   2767 	.area CABS    (ABS,CODE)
                                   2768 
                                   2769 ; Experimental exact instruction outlining.
                                   2770 	.globl _ak820_outline_0000
                                   2771 	.globl _ak820_outline_0005
                                   2772 	.globl _ak820_outline_0008
                                   2773 	.globl _ak820_outline_0013
                                   2774 	.globl _ak820_outline_0022
                                   2775 	.globl _ak820_outline_0033
                                   2776 	.globl _ak820_outline_0034
                                   2777 	.globl _ak820_outline_0050
                                   2778 	.globl _ak820_outline_0052
                                   2779 	.globl _ak820_outline_0059
                                   2780 	.globl _ak820_outline_0060
                                   2781 	.globl _ak820_outline_0061
                                   2782 	.globl _ak820_outline_0072
                                   2783 	.globl _ak820_outline_0077
                                   2784 	.globl _ak820_outline_0079
                                   2785 	.globl _ak820_outline_0082
                                   2786 	.globl _ak820_outline_0086
                                   2787 	.globl _ak820_outline_0092
                                   2788 	.globl _ak820_outline_0094
                                   2789 	.globl _ak820_outline_0095
                                   2790 	.globl _ak820_outline_0100
                                   2791 	.globl _ak820_outline_0103
                                   2792 	.globl _ak820_outline_0104
                                   2793 	.globl _ak820_outline_0105
                                   2794 	.globl _ak820_outline_0109
                                   2795 	.globl _ak820_outline_0110
                                   2796 	.globl _ak820_outline_0113
                                   2797 	.globl _ak820_outline_0118
                                   2798 	.globl _ak820_outline_0120
                                   2799 	.globl _ak820_outline_0124
                                   2800 	.globl _ak820_outline_0125
                                   2801 	.globl _ak820_outline_0126
                                   2802 	.globl _ak820_outline_0130
                                   2803 	.globl _ak820_outline_0135
                                   2804 	.globl _ak820_outline_0136
                                   2805 	.globl _ak820_outline_0137
                                   2806 	.globl _ak820_outline_0138
                                   2807 	.globl _ak820_outline_0139
                                   2808 	.globl _ak820_outline_0146
                                   2809 	.globl _ak820_outline_0147
                                   2810 	.globl _ak820_outline_0154
                                   2811 	.globl _ak820_outline_0157
                                   2812 	.globl _ak820_outline_0161
                                   2813 	.globl _ak820_outline_0163
                                   2814 	.globl _ak820_outline_0165
                                   2815 	.globl _ak820_outline_0170
                                   2816 	.globl _ak820_outline_0179
                                   2817 	.globl _ak820_outline_0180
                                   2818 	.globl _ak820_outline_0183
                                   2819 	.globl _ak820_outline_0184
                                   2820 	.globl _ak820_outline_0185
                                   2821 	.globl _ak820_outline_0186
                                   2822 	.globl _ak820_outline_0189
                                   2823 	.globl _ak820_outline_0191
                                   2824 
                                   2825 	.area CSEG (CODE)
                                   2826 ; function ak820_outline_0000
      0090D5                       2827 _ak820_outline_0000:
      0090D5 90 0B 61         [24] 2828 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0090D8 E0               [24] 2829 	movx	a,@dptr
      0090D9 FC               [12] 2830 	mov	r4,a
      0090DA A3               [24] 2831 	inc	dptr
      0090DB E0               [24] 2832 	movx	a,@dptr
      0090DC FF               [12] 2833 	mov	r7,a
      0090DD 90 0B 61         [24] 2834 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0090E0 74 01            [12] 2835 	mov	a,#0x01
      0090E2 2C               [12] 2836 	add	a,r4
      0090E3 F0               [24] 2837 	movx	@dptr,a
      0090E4 E4               [12] 2838 	clr	a
      0090E5 3F               [12] 2839 	addc	a,r7
      0090E6 A3               [24] 2840 	inc	dptr
      0090E7 F0               [24] 2841 	movx	@dptr,a
      0090E8 7B 00            [12] 2842 	mov	r3,#0x00
      0090EA 8C 82            [24] 2843 	mov	dpl,r4
      0090EC 8F 83            [24] 2844 	mov	dph,r7
      0090EE 8B F0            [24] 2845 	mov	b,r3
      0090F0 22               [24] 2846 	ret
                                   2847 
                                   2848 	.area CSEG (CODE)
                                   2849 ; function ak820_outline_0082
      0090F1                       2850 _ak820_outline_0082:
      0090F1 ED               [12] 2851 	mov	a,r5
      0090F2 75 F0 0A         [24] 2852 	mov	b,#0x0a
      0090F5 A4               [48] 2853 	mul	ab
      0090F6 24 58            [12] 2854 	add	a,#0x58
      0090F8 FC               [12] 2855 	mov	r4,a
      0090F9 74 06            [12] 2856 	mov	a,#0x06
      0090FB 35 F0            [12] 2857 	addc	a,b
      0090FD FD               [12] 2858 	mov	r5,a
      0090FE 22               [24] 2859 	ret
                                   2860 
                                   2861 	.area CSEG (CODE)
                                   2862 ; function ak820_outline_0095
      0090FF                       2863 _ak820_outline_0095:
      0090FF 90 0B 64         [24] 2864 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      009102 E0               [24] 2865 	movx	a,@dptr
      009103 FF               [12] 2866 	mov	r7,a
      009104 22               [24] 2867 	ret
                                   2868 
                                   2869 	.area CSEG (CODE)
                                   2870 ; function ak820_outline_0100
      009105                       2871 _ak820_outline_0100:
      009105 90 0A FA         [24] 2872 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      009108 EE               [12] 2873 	mov	a,r6
      009109 F0               [24] 2874 	movx	@dptr,a
      00910A 90 0A FB         [24] 2875 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      00910D ED               [12] 2876 	mov	a,r5
      00910E F0               [24] 2877 	movx	@dptr,a
      00910F 8F 82            [24] 2878 	mov	dpl,r7
      009111 22               [24] 2879 	ret
                                   2880 
                                   2881 	.area CSEG (CODE)
                                   2882 ; function ak820_outline_0113
      009112                       2883 _ak820_outline_0113:
      009112 74 0A            [12] 2884 	mov	a,#0x0a
      009114 F0               [24] 2885 	movx	@dptr,a
      009115 E4               [12] 2886 	clr	a
      009116 A3               [24] 2887 	inc	dptr
      009117 F0               [24] 2888 	movx	@dptr,a
      009118 22               [24] 2889 	ret
                                   2890 
                                   2891 	.area CSEG (CODE)
                                   2892 ; function ak820_outline_0118
      009119                       2893 _ak820_outline_0118:
      009119 AD 82            [24] 2894 	mov	r5,dpl
      00911B AE 83            [24] 2895 	mov	r6,dph
      00911D AF F0            [24] 2896 	mov	r7,b
      00911F 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0130
      009120                       2901 _ak820_outline_0130:
      009120 28               [12] 2902 	add	a,r0
      009121 F5 82            [12] 2903 	mov	dpl,a
      009123 EF               [12] 2904 	mov	a,r7
      009124 39               [12] 2905 	addc	a,r1
      009125 F5 83            [12] 2906 	mov	dph,a
      009127 74 FF            [12] 2907 	mov	a,#0xff
      009129 F0               [24] 2908 	movx	@dptr,a
      00912A 22               [24] 2909 	ret
                                   2910 
                                   2911 	.area CSEG (CODE)
                                   2912 ; function ak820_outline_0138
      00912B                       2913 _ak820_outline_0138:
      00912B 2D               [12] 2914 	add	a,r5
      00912C F9               [12] 2915 	mov	r1,a
      00912D E4               [12] 2916 	clr	a
      00912E 3E               [12] 2917 	addc	a,r6
      00912F FA               [12] 2918 	mov	r2,a
      009130 22               [24] 2919 	ret
                                   2920 
                                   2921 	.area CSEG (CODE)
                                   2922 ; function ak820_outline_0157
      009131                       2923 _ak820_outline_0157:
      009131 90 0B 65         [24] 2924 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      009134 E0               [24] 2925 	movx	a,@dptr
      009135 F5 82            [12] 2926 	mov	dpl,a
      009137 22               [24] 2927 	ret
                                   2928 
                                   2929 	.area CSEG (CODE)
                                   2930 ; function ak820_outline_0170
      009138                       2931 _ak820_outline_0170:
      009138 90 09 A8         [24] 2932 	mov	dptr,#_ak820_macro_primitive
      00913B E4               [12] 2933 	clr	a
      00913C F0               [24] 2934 	movx	@dptr,a
      00913D 22               [24] 2935 	ret
                                   2936 
                                   2937 	.area CSEG (CODE)
                                   2938 ; function ak820_outline_0179
      00913E                       2939 _ak820_outline_0179:
      00913E 90 0B 0A         [24] 2940 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009141 E4               [12] 2941 	clr	a
      009142 F0               [24] 2942 	movx	@dptr,a
      009143 90 0B 0B         [24] 2943 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      009146 22               [24] 2944 	ret
                                   2945 
                                   2946 	.area CSEG (CODE)
                                   2947 ; function ak820_outline_0180
      009147                       2948 _ak820_outline_0180:
      009147 90 0B C0         [24] 2949 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      00914A E4               [12] 2950 	clr	a
      00914B F0               [24] 2951 	movx	@dptr,a
      00914C 90 0B C1         [24] 2952 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      00914F 22               [24] 2953 	ret
                                   2954 
                                   2955 	.area CSEG (CODE)
                                   2956 ; function ak820_outline_0183
      009150                       2957 _ak820_outline_0183:
      009150 AF 82            [24] 2958 	mov	r7,dpl
      009152 90 0B 65         [24] 2959 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      009155 EF               [12] 2960 	mov	a,r7
      009156 F0               [24] 2961 	movx	@dptr,a
      009157 EF               [12] 2962 	mov	a,r7
      009158 22               [24] 2963 	ret
