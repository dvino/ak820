;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_tapping
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _layer_hold_off
	.globl _layer_hold_on
	.globl _unregister_mods
	.globl _register_mods
	.globl _process_record
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_tapping_before
	.globl _ak820_tapping_process
	.globl _ak820_tapping_cancel
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_ak820_tapping_process_sloc0_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_ak820_tapping_before_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_source_state:
	.ds 130
_pending_time:
	.ds 2
_pending_code:
	.ds 2
_source_PARM_1:
	.ds 2
_hold_PARM_2:
	.ds 1
_hold_code_10000_597:
	.ds 2
_hold_mods_30000_600:
	.ds 1
_commit_pending_id_10000_606:
	.ds 1
_ak820_tapping_before_event_10000_607:
	.ds 2
_ak820_tapping_process_record_10000_618:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_pending:
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function source
;	-----------------------------------------
_source:
;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
	mov	dptr,#(_source_PARM_1 + 0x0001)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x10,00147$
00147$:
	jnc	00102$
	mov	dptr,#_source_PARM_1
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x08,00149$
00149$:
	jnc	00102$
	mov	ar5,r7
	mov	a,r5
	swap	a
	rr	a
	anl	a,#0xf8
	add	a,r6
	mov	dpl,a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
	mov	dptr,#_source_PARM_1
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x01,00151$
00151$:
	jnc	00109$
;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
	cjne	r7,#0xfd,00105$
	mov	dpl, #0x80
	ret
00105$:
;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
	cjne	r7,#0xfc,00109$
	mov	dpl, #0x81
	ret
00109$:
;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
	mov	dpl, #0xff
;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'hold'
;------------------------------------------------------------
;pressed       Allocated with name '_hold_PARM_2'
;code          Allocated with name '_hold_code_10000_597'
;mods          Allocated with name '_hold_mods_30000_600'
;layer         Allocated with name '_hold_layer_30000_603'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
;	-----------------------------------------
;	 function hold
;	-----------------------------------------
_hold:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_hold_code_10000_597
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
	mov	dptr,#_hold_code_10000_597
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r6
	mov	ar5,r7
	mov	a,#0x100 - 0x40
	add	a,r5
	jc	00110$
;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
	mov	ar5,r7
	anl	ar5,#0x1f
	mov	dptr,#_hold_mods_30000_600
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
	mov	a,r5
	jnb	acc.4,00102$
	mov	a,r5
	swap	a
	anl	a,#0xf0
	mov	dptr,#_hold_mods_30000_600
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
	mov	dptr,#_hold_PARM_2
	movx	a,@dptr
	jz	00104$
	mov	dptr,#_hold_mods_30000_600
	movx	a,@dptr
	mov	dpl,a
	ljmp	_register_mods
00104$:
;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
	mov	dptr,#_hold_mods_30000_600
	movx	a,@dptr
	mov	dpl,a
	ljmp	_unregister_mods
00110$:
;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
	mov	ar6,r7
	mov	a,#0x0f
	anl	a,r6
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
	mov	dptr,#_hold_PARM_2
	movx	a,@dptr
	jz	00107$
	mov	dpl, r7
	ljmp	_layer_hold_on
00107$:
;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
	mov	dpl, r7
;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
	ljmp	_layer_hold_off
;------------------------------------------------------------
;Allocation info for local variables in function 'commit_pending'
;------------------------------------------------------------
;id            Allocated with name '_commit_pending_id_10000_606'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
;	-----------------------------------------
;	 function commit_pending
;	-----------------------------------------
_commit_pending:
;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
	mov	dptr,#_pending
	movx	a,@dptr
	mov	dptr,#_commit_pending_id_10000_606
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
	mov	dptr,#_pending
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
	mov	dptr,#_commit_pending_id_10000_606
	movx	a,@dptr
	add	a,#_source_state
	mov	r7,a
	clr	a
	addc	a, #(_source_state >> 8)
	mov	r6,a
	mov	dpl,r7
	mov	dph,r6
	movx	a,@dptr
	mov	r5,a
	orl	ar5,#0x04
	mov	dpl,r7
	mov	dph,r6
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
	mov	dptr,#_pending_code
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_hold_PARM_2
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
	ljmp	_hold
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tapping_before'
;------------------------------------------------------------
;event         Allocated with name '_ak820_tapping_before_event_10000_607'
;id            Allocated with name '_ak820_tapping_before_id_10000_608'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
;	-----------------------------------------
;	 function ak820_tapping_before
;	-----------------------------------------
_ak820_tapping_before:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tapping_before_event_10000_607
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
	mov	dptr,#_ak820_tapping_before_event_10000_607
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r6
	mov	ar5,r7
	mov	dptr,#___memcpy_PARM_2
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x02
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_source_PARM_1
	mov	b,a
	push	ar7
	push	ar6
	lcall	___memcpy
	lcall	_source
	mov	r5, dpl
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	jz	00106$
;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
	mov	a,#0x04
	add	a, r6
	mov	r3,a
	clr	a
	addc	a, r7
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	jz	00102$
	cjne	r5,#0xff,00218$
	sjmp	00102$
00218$:
	mov	a,#0x05
	add	a, r6
	mov	r3,a
	clr	a
	addc	a, r7
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	jnz	00102$
	mov	a,r5
	add	a, #_source_state
	mov	r3,a
	clr	a
	addc	a, #(_source_state >> 8)
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	mov	r2,a
	anl	ar2,#0xfd
	mov	dpl,r3
	mov	dph,r4
	mov	a,r2
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
	mov	dpl, #0x00
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
	mov	dptr,#_pending
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0xff,00220$
	sjmp	00108$
00220$:
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_pending_time
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	mov	a,r2
	clr	c
	subb	a,r0
	mov	r2,a
	mov	a,r3
	subb	a,r1
	mov	r3,a
	clr	c
	mov	a,r2
	subb	a,#0xc8
	mov	a,r3
	subb	a,#0x00
	jnc	00107$
;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
	mov	a,#0x04
	add	a, r6
	mov	r2,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	jz	00108$
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00108$
	cjne	r5,#0xff,00224$
	sjmp	00107$
00224$:
	mov	a,r5
	cjne	a,ar4,00225$
	sjmp	00108$
00225$:
00107$:
	push	ar5
	lcall	_commit_pending
	pop	ar5
00108$:
;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
	mov	dptr,#_ak820_tapping_before_event_10000_607
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x04
	add	a, r6
	mov	r3,a
	clr	a
	addc	a, r7
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	jz	00114$
	cjne	r5,#0xff,00115$
00114$:
	mov	dpl, #0x01
	ret
00115$:
;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
	mov	a,r5
	add	a, #_source_state
	mov	r4,a
	clr	a
	addc	a, #(_source_state >> 8)
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r3,a
	jnb	acc.1,00120$
;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
	mov	a,#0x05
	add	a, r6
	mov	r1,a
	clr	a
	addc	a, r7
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	movx	a,@dptr
	jnz	00118$
	mov	a,#0xfd
	anl	a,r3
	mov	dpl,r4
	mov	dph,r5
	movx	@dptr,a
00118$:
;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
	mov	dpl, #0x00
	ret
00120$:
;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar6,r3
	anl	ar6,#0x01
	mov	a,r6
	cjne	a,#0x01,00231$
00231$:
	cpl	c
	mov	_ak820_tapping_before_sloc0_1_0,c
	mov	b,r7
	clr	a
	rlc	a
	cjne	a,b,00122$
	mov	dpl, #0x00
	ret
00122$:
;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
	xrl	ar3,#0x01
	mov	dpl,r4
	mov	dph,r5
	mov	a,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tapping_process'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_tapping_process_sloc0_1_0'
;record        Allocated with name '_ak820_tapping_process_record_10000_618'
;id            Allocated with name '_ak820_tapping_process_id_10000_619'
;kind          Allocated with name '_ak820_tapping_process_kind_10000_619'
;code          Allocated with name '_ak820_tapping_process_code_10000_619'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
;	-----------------------------------------
;	 function ak820_tapping_process
;	-----------------------------------------
_ak820_tapping_process:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tapping_process_record_10000_618
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
	mov	dptr,#_ak820_tapping_process_record_10000_618
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x04
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	jnz	00102$
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
	mov	ar4,r6
	mov	ar5,r7
	mov	dptr,#___memcpy_PARM_2
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x02
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_source_PARM_1
	mov	b,a
	push	ar7
	push	ar6
	lcall	___memcpy
	lcall	_source
	mov	r5, dpl
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
	cjne	r5,#0xff,00104$
	mov	dpl, #0x01
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	_ak820_tapping_process_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_tapping_process_sloc0_1_0 + 1),a
;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
	mov	r4,(_ak820_tapping_process_sloc0_1_0 + 1)
;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
	cjne	r4,#0x20,00189$
00189$:
	jc	00105$
	cjne	r4,#0x50,00191$
00191$:
	jc	00106$
00105$:
	mov	dpl, #0x01
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
	cjne	r4,#0x40,00193$
00193$:
	jc	00109$
	anl	ar4,#0x0f
	cjne	r4,#0x06,00195$
00195$:
	jc	00109$
	mov	dpl, #0x00
	ret
00109$:
;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
	mov	dptr,#_ak820_tapping_process_record_10000_618
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	a,#0x05
	add	a, r3
	mov	r1,a
	clr	a
	addc	a, r4
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	movx	a,@dptr
	jz	00119$
;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
	mov	dptr,#_pending
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
	mov	dpl,r3
	mov	dph,r4
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_pending_time
	mov	a,r0
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
	mov	dptr,#_pending_code
	mov	a,_ak820_tapping_process_sloc0_1_0
	movx	@dptr,a
	mov	a,(_ak820_tapping_process_sloc0_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	ljmp	00120$
00119$:
;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
	mov	dptr,#_pending
	movx	a,@dptr
	mov	r7,a
	mov	a,r5
	cjne	a,ar7,00116$
;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
	mov	dptr,#_pending
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
	mov	a,#0x07
	add	a, r3
	mov	dpl,a
	clr	a
	addc	a, r4
	mov	dph,a
	mov	r6,_ak820_tapping_process_sloc0_1_0
	mov	r7,#0x00
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
	clr	c
	inc	a
	subb	a,r6
	jnc	00120$
;	free result
;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
	mov	a,#0x06
	add	a, r3
	mov	dpl,a
	clr	a
	addc	a, r4
	mov	dph,a
	movx	a,@dptr
	anl	a,#0x0f
	orl	a,#0x10
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
	mov	dpl,r1
	mov	dph,r2
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
	mov	ar0,r3
	mov	ar6,r4
	mov	r7,#0x00
	mov	dpl, r0
	mov	dph, r6
	mov	b, r7
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	lcall	_process_record
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
	mov	dpl,r1
	mov	dph,r2
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
	mov	r7,a
	mov	dpl, r3
	mov	dph, r4
	mov	b, r7
	lcall	_process_record
	sjmp	00120$
00116$:
;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
	mov	a,r5
	add	a, #_source_state
	mov	r6,a
	clr	a
	addc	a, #(_source_state >> 8)
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r5,a
	jnb	acc.2,00120$
;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
	anl	ar5,#0xfb
	mov	dpl,r6
	mov	dph,r7
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
	mov	dptr,#_hold_PARM_2
	clr	a
	movx	@dptr,a
	mov	dpl, _ak820_tapping_process_sloc0_1_0
	mov	dph, (_ak820_tapping_process_sloc0_1_0 + 1)
	lcall	_hold
00120$:
;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tapping_cancel'
;------------------------------------------------------------
;i             Allocated with name '_ak820_tapping_cancel_i_20000_634'
;state         Allocated with name '_ak820_tapping_cancel_state_30000_635'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
;	-----------------------------------------
;	 function ak820_tapping_cancel
;	-----------------------------------------
_ak820_tapping_cancel:
;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
	mov	dptr,#_pending
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
	mov	r7,#0x00
00103$:
	cjne	r7,#0x82,00122$
00122$:
	jnc	00105$
;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
	mov	a,r7
	add	a, #_source_state
	mov	r5,a
	clr	a
	addc	a, #(_source_state >> 8)
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	mov	r4,a
;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
	mov	a,#0x02
	anl	a,r4
	mov	r3,a
	anl	ar4,#0x01
	mov	a,r4
	add	a,r4
	orl	ar3,a
	mov	dpl,r5
	mov	dph,r6
	mov	a,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
	inc	r7
	sjmp	00103$
00105$:
;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__pending:
	.db #0xff	; 255
	.area CABS    (ABS,CODE)
