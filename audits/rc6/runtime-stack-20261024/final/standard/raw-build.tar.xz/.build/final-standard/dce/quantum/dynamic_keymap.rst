                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000031                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000031                        588 	.ds 2
      000033                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      000033                        590 	.ds 1
      000034                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      000034                        592 	.ds 1
      000035                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      000035                        594 	.ds 2
      000037                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      000037                        596 	.ds 2
      000039                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000039                        598 	.ds 1
      00003A                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      00003A                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000024                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000024                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AD0                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AD0                        628 	.ds 1
      000AD1                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AD1                        630 	.ds 1
      000AD2                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000AD2                        632 	.ds 1
      000AD3                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AD3                        634 	.ds 1
      000AD4                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AD4                        636 	.ds 1
      000AD5                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000AD5                        638 	.ds 1
      000AD6                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AD6                        640 	.ds 1
      000AD7                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AD7                        642 	.ds 1
      000AD8                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AD8                        644 	.ds 2
      000ADA                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000ADA                        646 	.ds 1
      000ADB                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000ADB                        648 	.ds 1
      000ADC                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000ADC                        650 	.ds 1
      000ADD                        651 _dynamic_keymap_get_encoder_PARM_2:
      000ADD                        652 	.ds 1
      000ADE                        653 _dynamic_keymap_get_encoder_PARM_3:
      000ADE                        654 	.ds 1
      000ADF                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000ADF                        656 	.ds 1
      000AE0                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AE0                        658 	.ds 1
      000AE1                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AE1                        660 	.ds 1
      000AE2                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AE2                        662 	.ds 2
      000AE4                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000AE4                        664 	.ds 1
      000AE5                        665 _dynamic_keymap_get_combo_PARM_2:
      000AE5                        666 	.ds 3
      000AE8                        667 _dynamic_keymap_get_combo_index_10000_384:
      000AE8                        668 	.ds 1
      000AE9                        669 _dynamic_keymap_set_combo_PARM_2:
      000AE9                        670 	.ds 3
      000AEC                        671 _dynamic_keymap_set_combo_index_10000_390:
      000AEC                        672 	.ds 1
      000AED                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000AED                        674 	.ds 10
      000AF7                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000AF7                        676 	.ds 1
      000AF8                        677 _dynamic_keymap_reset_combo_10001_407:
      000AF8                        678 	.ds 10
      000B02                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B02                        680 	.ds 2
      000B04                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B04                        682 	.ds 2
      000B06                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B06                        684 	.ds 2
      000B08                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B08                        686 	.ds 3
      000B0B                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B0B                        688 	.ds 2
      000B0D                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B0D                        690 	.ds 1
      000B0E                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B0E                        692 	.ds 2
      000B10                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B10                        694 	.ds 3
      000B13                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B13                        696 	.ds 2
      000B15                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B15                        698 	.ds 2
      000B17                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B17                        700 	.ds 3
      000B1A                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B1A                        702 	.ds 2
      000B1C                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B1C                        704 	.ds 1
      000B1D                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B1D                        706 	.ds 1
      000B1E                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B1E                        708 	.ds 1
      000B1F                        709 _keycode_at_keymap_location_PARM_2:
      000B1F                        710 	.ds 1
      000B20                        711 _keycode_at_keymap_location_PARM_3:
      000B20                        712 	.ds 1
      000B21                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B21                        714 	.ds 1
      000B22                        715 _keycode_at_encodermap_location_PARM_2:
      000B22                        716 	.ds 1
      000B23                        717 _keycode_at_encodermap_location_PARM_3:
      000B23                        718 	.ds 1
      000B24                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B24                        720 	.ds 1
      000B25                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B25                        722 	.ds 2
      000B27                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B27                        724 	.ds 3
      000B2A                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000B2A                        726 	.ds 2
      000B2C                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B2C                        728 	.ds 2
      000B2E                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B2E                        730 	.ds 3
      000B31                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000B31                        732 	.ds 2
      000B33                        733 _decode_keycode_kc_10000_454:
      000B33                        734 	.ds 2
      000B35                        735 _dynamic_keymap_macro_send_id_10000_457:
      000B35                        736 	.ds 1
      000B36                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000B36                        738 	.ds 1
      000B37                        739 _dynamic_keymap_macro_send_p_10001_463:
      000B37                        740 	.ds 2
      000B39                        741 _dynamic_keymap_macro_send_data_10003_470:
      000B39                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      0080C4                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0080C4 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      0080C7 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      0080C8                        810 _dynamic_keymap_key_to_eeprom_address:
      0080C8 E5 82            [12]  811 	mov	a,dpl
      0080CA 90 0A D2         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      0080CD F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0080CE E0               [24]  815 	movx	a,@dptr
      0080CF FF               [12]  816 	mov	r7,a
      0080D0 7E 00            [12]  817 	mov	r6,#0x00
      0080D2 74 40            [12]  818 	mov	a,#0x40
      0080D4 12 43 5B         [24]  819 	lcall	_ak820_outline_0133
      0080D7 7D 00            [12]  820 	mov	r5,#0x00
      0080D9 90 0A D0         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0080DC E0               [24]  822 	movx	a,@dptr
      0080DD 75 F0 10         [24]  823 	mov	b,#0x10
      0080E0 A4               [48]  824 	mul	ab
      0080E1 2E               [12]  825 	add	a, r6
      0080E2 FE               [12]  826 	mov	r6,a
      0080E3 EF               [12]  827 	mov	a,r7
      0080E4 35 F0            [12]  828 	addc	a, b
      0080E6 FF               [12]  829 	mov	r7,a
      0080E7 90 0A D1         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0080EA E0               [24]  831 	movx	a,@dptr
      0080EB 7C 00            [12]  832 	mov	r4,#0x00
      0080ED 25 E0            [12]  833 	add	a,acc
      0080EF FB               [12]  834 	mov	r3,a
      0080F0 EC               [12]  835 	mov	a,r4
      0080F1 33               [12]  836 	rlc	a
      0080F2 FC               [12]  837 	mov	r4,a
      0080F3 EB               [12]  838 	mov	a,r3
      0080F4 2E               [12]  839 	add	a, r6
      0080F5 FE               [12]  840 	mov	r6,a
      0080F6 EC               [12]  841 	mov	a,r4
      0080F7 3F               [12]  842 	addc	a, r7
      0080F8 FF               [12]  843 	mov	r7,a
      0080F9 12 6D B4         [24]  844 	lcall	_ak820_outline_0050
                                    845 ;	quantum/dynamic_keymap.c:184: }
      0080FC 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      0080FD                        860 _dynamic_keymap_get_keycode:
      0080FD E5 82            [12]  861 	mov	a,dpl
      0080FF 90 0A D5         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      008102 F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008103 E0               [24]  865 	movx	a,@dptr
      008104 FF               [12]  866 	mov	r7,a
      008105 BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      008108                        868 00121$:
      008108 50 14            [24]  869 	jnc	00101$
      00810A 90 0A D3         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00810D E0               [24]  871 	movx	a,@dptr
      00810E FE               [12]  872 	mov	r6,a
      00810F BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      008112                        874 00123$:
      008112 50 0A            [24]  875 	jnc	00101$
      008114 90 0A D4         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008117 E0               [24]  877 	movx	a,@dptr
      008118 FD               [12]  878 	mov	r5,a
      008119 BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      00811C                        880 00125$:
      00811C 40 04            [24]  881 	jc	00102$
      00811E                        882 00101$:
      00811E 90 00 00         [24]  883 	mov	dptr,#0x0000
      008121 22               [24]  884 	ret
      008122                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008122 12 8B 64         [24]  887 	lcall	_ak820_outline_0096
      008125 12 80 C8         [24]  888 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      008128 12 8B 78         [24]  890 	lcall	_ak820_outline_0110
      00812B 12 40 6F         [24]  891 	lcall	_eeprom_read_byte
      00812E AB 82            [24]  892 	mov	r3,dpl
      008130 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      008132 0D               [12]  895 	inc	r5
      008133 BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      008136 0E               [12]  897 	inc	r6
      008137                        898 00127$:
      008137 12 6B 91         [24]  899 	lcall	_ak820_outline_0046
      00813A 12 40 6F         [24]  900 	lcall	_eeprom_read_byte
      00813D AF 82            [24]  901 	mov	r7, dpl
      00813F 7E 00            [12]  902 	mov	r6,#0x00
      008141 EF               [12]  903 	mov	a,r7
      008142 42 04            [12]  904 	orl	ar4,a
      008144 EE               [12]  905 	mov	a,r6
      008145 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      008147 12 43 82         [24]  908 	lcall	_ak820_outline_0179
                                    909 ;	quantum/dynamic_keymap.c:193: }
      00814A 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      00814B                        924 _dynamic_keymap_set_keycode:
      00814B E5 82            [12]  925 	mov	a,dpl
      00814D 90 0A DA         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      008150 F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008151 E0               [24]  929 	movx	a,@dptr
      008152 FF               [12]  930 	mov	r7,a
      008153 BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      008156                        932 00121$:
      008156 50 14            [24]  933 	jnc	00101$
      008158 90 0A D6         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00815B E0               [24]  935 	movx	a,@dptr
      00815C FE               [12]  936 	mov	r6,a
      00815D BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      008160                        938 00123$:
      008160 50 0A            [24]  939 	jnc	00101$
      008162 90 0A D7         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008165 E0               [24]  941 	movx	a,@dptr
      008166 FD               [12]  942 	mov	r5,a
      008167 BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      00816A                        944 00125$:
      00816A 40 01            [24]  945 	jc	00102$
      00816C                        946 00101$:
      00816C 22               [24]  947 	ret
      00816D                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00816D 12 8B 64         [24]  950 	lcall	_ak820_outline_0096
      008170 12 80 C8         [24]  951 	lcall	_dynamic_keymap_key_to_eeprom_address
      008173 12 8B 78         [24]  952 	lcall	_ak820_outline_0110
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008176 90 0A D8         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008179 E0               [24]  955 	movx	a,@dptr
      00817A FB               [12]  956 	mov	r3,a
      00817B A3               [24]  957 	inc	dptr
      00817C E0               [24]  958 	movx	a,@dptr
      00817D 90 06 8F         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      008180 12 4D 30         [24]  960 	lcall	_ak820_outline_0038
      008183 12 4C 1A         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008186 0D               [12]  963 	inc	r5
      008187 BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      00818A 0E               [12]  965 	inc	r6
      00818B                        966 00127$:
      00818B 90 06 8F         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      00818E EB               [12]  968 	mov	a,r3
      00818F 12 4D 30         [24]  969 	lcall	_ak820_outline_0038
                                    970 ;	quantum/dynamic_keymap.c:201: }
      008192 02 4C 1A         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      008195                        982 _dynamic_keymap_encoder_to_eeprom_address:
      008195 E5 82            [12]  983 	mov	a,dpl
      008197 90 0A DC         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      00819A F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      00819B E0               [24]  987 	movx	a,@dptr
      00819C 75 F0 04         [24]  988 	mov	b,#0x04
      00819F A4               [48]  989 	mul	ab
      0081A0 24 40            [12]  990 	add	a, #0x40
      0081A2 FD               [12]  991 	mov	r5,a
      0081A3 74 06            [12]  992 	mov	a,#0x06
      0081A5 35 F0            [12]  993 	addc	a, b
      0081A7 FE               [12]  994 	mov	r6,a
      0081A8 7F 00            [12]  995 	mov	r7,#0x00
      0081AA 90 0A DB         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0081AD E0               [24]  997 	movx	a,@dptr
      0081AE 75 F0 04         [24]  998 	mov	b,#0x04
      0081B1 A4               [48]  999 	mul	ab
      0081B2 2D               [12] 1000 	add	a, r5
      0081B3 FD               [12] 1001 	mov	r5,a
      0081B4 EE               [12] 1002 	mov	a,r6
      0081B5 35 F0            [12] 1003 	addc	a, b
      0081B7 FE               [12] 1004 	mov	r6,a
      0081B8 12 6B 91         [24] 1005 	lcall	_ak820_outline_0046
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      0081BB 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      0081BC                       1021 _dynamic_keymap_get_encoder:
      0081BC E5 82            [12] 1022 	mov	a,dpl
      0081BE 90 0A DF         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      0081C1 F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0081C2 E0               [24] 1026 	movx	a,@dptr
      0081C3 FF               [12] 1027 	mov	r7,a
      0081C4 BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      0081C7                       1029 00131$:
      0081C7 50 0A            [24] 1030 	jnc	00101$
      0081C9 90 0A DD         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0081CC E0               [24] 1032 	movx	a,@dptr
      0081CD FE               [12] 1033 	mov	r6,a
      0081CE BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      0081D1                       1035 00133$:
      0081D1 40 04            [24] 1036 	jc	00102$
      0081D3                       1037 00101$:
      0081D3 90 00 00         [24] 1038 	mov	dptr,#0x0000
      0081D6 22               [24] 1039 	ret
      0081D7                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0081D7 90 0A DB         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0081DA E4               [12] 1043 	clr	a
      0081DB F0               [24] 1044 	movx	@dptr,a
      0081DC 8F 82            [24] 1045 	mov	dpl, r7
      0081DE 12 81 95         [24] 1046 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0081E1 12 8B 78         [24] 1047 	lcall	_ak820_outline_0110
                                   1048 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0081E4 90 0A DE         [24] 1049 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0081E7 E0               [24] 1050 	movx	a,@dptr
      0081E8 FC               [12] 1051 	mov	r4,a
      0081E9 E0               [24] 1052 	movx	a,@dptr
      0081EA 60 04            [24] 1053 	jz	00106$
      0081EC 7B 00            [12] 1054 	mov	r3,#0x00
      0081EE 80 02            [24] 1055 	sjmp	00107$
      0081F0                       1056 00106$:
      0081F0 7B 02            [12] 1057 	mov	r3,#0x02
      0081F2                       1058 00107$:
      0081F2 EB               [12] 1059 	mov	a,r3
      0081F3 12 8B 42         [24] 1060 	lcall	_ak820_outline_0025
      0081F6 12 40 6F         [24] 1061 	lcall	_eeprom_read_byte
      0081F9 AA 82            [24] 1062 	mov	r2,dpl
      0081FB 7B 00            [12] 1063 	mov	r3,#0x00
                                   1064 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0081FD EC               [12] 1065 	mov	a,r4
      0081FE 60 04            [24] 1066 	jz	00108$
      008200 7C 00            [12] 1067 	mov	r4,#0x00
      008202 80 02            [24] 1068 	sjmp	00109$
      008204                       1069 00108$:
      008204 7C 02            [12] 1070 	mov	r4,#0x02
      008206                       1071 00109$:
      008206 EC               [12] 1072 	mov	a,r4
      008207 12 38 B6         [24] 1073 	lcall	_ak820_outline_0156
      00820A 0D               [12] 1074 	inc	r5
      00820B BD 00 01         [24] 1075 	cjne	r5,#0x00,00137$
      00820E 0E               [12] 1076 	inc	r6
      00820F                       1077 00137$:
      00820F 12 6B 91         [24] 1078 	lcall	_ak820_outline_0046
      008212 12 40 6F         [24] 1079 	lcall	_eeprom_read_byte
      008215 AF 82            [24] 1080 	mov	r7, dpl
      008217 7E 00            [12] 1081 	mov	r6,#0x00
      008219 EF               [12] 1082 	mov	a,r7
      00821A 42 03            [12] 1083 	orl	ar3,a
      00821C EE               [12] 1084 	mov	a,r6
      00821D 42 02            [12] 1085 	orl	ar2,a
                                   1086 ;	quantum/dynamic_keymap.c:214: return keycode;
      00821F 8B 82            [24] 1087 	mov	dpl, r3
      008221 8A 83            [24] 1088 	mov	dph, r2
                                   1089 ;	quantum/dynamic_keymap.c:215: }
      008223 22               [24] 1090 	ret
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1093 ;------------------------------------------------------------
                                   1094 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1095 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1096 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1097 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1098 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1099 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1100 ;------------------------------------------------------------
                                   1101 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1102 ;	-----------------------------------------
                                   1103 ;	 function dynamic_keymap_set_encoder
                                   1104 ;	-----------------------------------------
      008224                       1105 _dynamic_keymap_set_encoder:
      008224 E5 82            [12] 1106 	mov	a,dpl
      008226 90 0A E4         [24] 1107 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      008229 F0               [24] 1108 	movx	@dptr,a
                                   1109 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      00822A E0               [24] 1110 	movx	a,@dptr
      00822B FF               [12] 1111 	mov	r7,a
      00822C BF 06 00         [24] 1112 	cjne	r7,#0x06,00131$
      00822F                       1113 00131$:
      00822F 50 0A            [24] 1114 	jnc	00101$
      008231 90 0A E0         [24] 1115 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008234 E0               [24] 1116 	movx	a,@dptr
      008235 FE               [12] 1117 	mov	r6,a
      008236 BE 01 00         [24] 1118 	cjne	r6,#0x01,00133$
      008239                       1119 00133$:
      008239 40 01            [24] 1120 	jc	00102$
      00823B                       1121 00101$:
      00823B 22               [24] 1122 	ret
      00823C                       1123 00102$:
                                   1124 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00823C 90 0A DB         [24] 1125 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00823F E4               [12] 1126 	clr	a
      008240 F0               [24] 1127 	movx	@dptr,a
      008241 8F 82            [24] 1128 	mov	dpl, r7
      008243 12 81 95         [24] 1129 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008246 12 8B 78         [24] 1130 	lcall	_ak820_outline_0110
                                   1131 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008249 90 0A E1         [24] 1132 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00824C E0               [24] 1133 	movx	a,@dptr
      00824D FC               [12] 1134 	mov	r4,a
      00824E E0               [24] 1135 	movx	a,@dptr
      00824F 60 04            [24] 1136 	jz	00106$
      008251 7B 00            [12] 1137 	mov	r3,#0x00
      008253 80 02            [24] 1138 	sjmp	00107$
      008255                       1139 00106$:
      008255 7B 02            [12] 1140 	mov	r3,#0x02
      008257                       1141 00107$:
      008257 EB               [12] 1142 	mov	a,r3
      008258 12 8B 8A         [24] 1143 	lcall	_ak820_outline_0132
      00825B 8F 03            [24] 1144 	mov	ar3,r7
      00825D 90 0A E2         [24] 1145 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008260 E0               [24] 1146 	movx	a,@dptr
      008261 F5 31            [12] 1147 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008263 A3               [24] 1148 	inc	dptr
      008264 E0               [24] 1149 	movx	a,@dptr
      008265 F5 32            [12] 1150 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008267 90 06 8F         [24] 1151 	mov	dptr,#_eeprom_update_byte_PARM_2
      00826A F0               [24] 1152 	movx	@dptr,a
      00826B 12 43 67         [24] 1153 	lcall	_ak820_outline_0143
      00826E 8B F0            [24] 1154 	mov	b, r3
      008270 12 4C 1A         [24] 1155 	lcall	_eeprom_update_byte
                                   1156 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008273 EC               [12] 1157 	mov	a,r4
      008274 60 04            [24] 1158 	jz	00108$
      008276 7C 00            [12] 1159 	mov	r4,#0x00
      008278 80 02            [24] 1160 	sjmp	00109$
      00827A                       1161 00108$:
      00827A 7C 02            [12] 1162 	mov	r4,#0x02
      00827C                       1163 00109$:
      00827C EC               [12] 1164 	mov	a,r4
      00827D 12 38 B6         [24] 1165 	lcall	_ak820_outline_0156
      008280 0D               [12] 1166 	inc	r5
      008281 BD 00 01         [24] 1167 	cjne	r5,#0x00,00137$
      008284 0E               [12] 1168 	inc	r6
      008285                       1169 00137$:
      008285 90 06 8F         [24] 1170 	mov	dptr,#_eeprom_update_byte_PARM_2
      008288 E5 31            [12] 1171 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      00828A 12 4D 30         [24] 1172 	lcall	_ak820_outline_0038
                                   1173 ;	quantum/dynamic_keymap.c:223: }
      00828D 02 4C 1A         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      008290                       1189 _dynamic_keymap_get_combo:
      008290 E5 82            [12] 1190 	mov	a,dpl
      008292 90 0A E8         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      008295 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008296 90 0A E5         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008299 12 38 42         [24] 1195 	lcall	_ak820_outline_0052
                                   1196 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      00829C 90 0A E8         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      00829F E0               [24] 1198 	movx	a,@dptr
      0082A0 FD               [12] 1199 	mov	r5,a
      0082A1 BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      0082A4                       1201 00132$:
      0082A4 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:275: return -1;
      0082A6 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      0082A9 22               [24] 1205 	ret
      0082AA                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0082AA 12 8B 50         [24] 1208 	lcall	_ak820_outline_0077
                                   1209 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      0082AD 8E 02            [24] 1210 	mov	ar2,r6
      0082AF 8F 03            [24] 1211 	mov	ar3,r7
      0082B1 90 05 85         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0082B4 12 38 5F         [24] 1213 	lcall	_ak820_outline_0071
      0082B7 E4               [12] 1214 	clr	a
      0082B8 A3               [24] 1215 	inc	dptr
      0082B9 F0               [24] 1216 	movx	@dptr,a
      0082BA 90 05 88         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0082BD 12 8B 71         [24] 1218 	lcall	_ak820_outline_0106
      0082C0 12 38 A7         [24] 1219 	lcall	_ak820_outline_0139
      0082C3 C0 07            [24] 1220 	push	ar7
      0082C5 C0 06            [24] 1221 	push	ar6
      0082C7 12 40 AA         [24] 1222 	lcall	_ak820_eeprom_read_block_xdata
      0082CA D0 06            [24] 1223 	pop	ar6
      0082CC D0 07            [24] 1224 	pop	ar7
                                   1225 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      0082CE 74 04            [12] 1226 	mov	a,#0x04
      0082D0 12 46 C3         [24] 1227 	lcall	_ak820_outline_0031
      0082D3 FA               [12] 1228 	mov	r2,a
      0082D4 A3               [24] 1229 	inc	dptr
      0082D5 E0               [24] 1230 	movx	a,@dptr
      0082D6 FB               [12] 1231 	mov	r3,a
      0082D7 BA 20 13         [24] 1232 	cjne	r2,#0x20,00108$
      0082DA BB 08 10         [24] 1233 	cjne	r3,#0x08,00108$
      0082DD 74 06            [12] 1234 	mov	a,#0x06
      0082DF 12 38 32         [24] 1235 	lcall	_ak820_outline_0021
      0082E2 12 43 3E         [24] 1236 	lcall	_ak820_outline_0100
      0082E5 BA 01 05         [24] 1237 	cjne	r2,#0x01,00136$
      0082E8 BB 00 02         [24] 1238 	cjne	r3,#0x00,00136$
      0082EB 80 05            [24] 1239 	sjmp	00109$
      0082ED                       1240 00136$:
      0082ED                       1241 00108$:
      0082ED 75 33 00         [24] 1242 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      0082F0 80 03            [24] 1243 	sjmp	00110$
      0082F2                       1244 00109$:
      0082F2 75 33 01         [24] 1245 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0082F5                       1246 00110$:
                                   1247 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      0082F5 74 06            [12] 1248 	mov	a,#0x06
      0082F7 12 38 32         [24] 1249 	lcall	_ak820_outline_0021
      0082FA 12 4D 73         [24] 1250 	lcall	_ak820_outline_0166
      0082FD 12 43 50         [24] 1251 	lcall	_ak820_outline_0118
      008300 A3               [24] 1252 	inc	dptr
      008301 F0               [24] 1253 	movx	@dptr,a
                                   1254 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008302 E5 33            [12] 1255 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008304 60 12            [24] 1256 	jz	00103$
      008306 12 38 8D         [24] 1257 	lcall	_ak820_outline_0114
      008309 C0 07            [24] 1258 	push	ar7
      00830B C0 06            [24] 1259 	push	ar6
      00830D 12 34 D1         [24] 1260 	lcall	_ak820_combo_valid
      008310 E5 82            [12] 1261 	mov	a, dpl
      008312 D0 06            [24] 1262 	pop	ar6
      008314 D0 07            [24] 1263 	pop	ar7
      008316 70 13            [24] 1264 	jnz	00104$
      008318                       1265 00103$:
      008318 7D 00            [12] 1266 	mov	r5,#0x00
      00831A 90 0D 9B         [24] 1267 	mov	dptr,#_memset_PARM_2
      00831D E4               [12] 1268 	clr	a
      00831E F0               [24] 1269 	movx	@dptr,a
      00831F 90 0D 9C         [24] 1270 	mov	dptr,#_memset_PARM_3
      008322 12 8B 71         [24] 1271 	lcall	_ak820_outline_0106
      008325 12 6D B4         [24] 1272 	lcall	_ak820_outline_0050
      008328 12 B5 19         [24] 1273 	lcall	_memset
      00832B                       1274 00104$:
                                   1275 ;	quantum/dynamic_keymap.c:289: return 0;
      00832B 90 00 00         [24] 1276 	mov	dptr,#0x0000
                                   1277 ;	quantum/dynamic_keymap.c:290: }
      00832E 22               [24] 1278 	ret
                                   1279 ;------------------------------------------------------------
                                   1280 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1281 ;------------------------------------------------------------
                                   1282 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1283 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1284 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1285 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1286 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1287 ;------------------------------------------------------------
                                   1288 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1289 ;	-----------------------------------------
                                   1290 ;	 function dynamic_keymap_set_combo
                                   1291 ;	-----------------------------------------
      00832F                       1292 _dynamic_keymap_set_combo:
      00832F E5 82            [12] 1293 	mov	a,dpl
      008331 90 0A EC         [24] 1294 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008334 F0               [24] 1295 	movx	@dptr,a
                                   1296 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008335 90 0A E9         [24] 1297 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008338 12 37 F5         [24] 1298 	lcall	_ak820_outline_0005
                                   1299 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      00833B C0 07            [24] 1300 	push	ar7
      00833D C0 06            [24] 1301 	push	ar6
      00833F 12 34 D1         [24] 1302 	lcall	_ak820_combo_valid
      008342 E5 82            [12] 1303 	mov	a, dpl
      008344 D0 06            [24] 1304 	pop	ar6
      008346 D0 07            [24] 1305 	pop	ar7
      008348 60 07            [24] 1306 	jz	00101$
      00834A 12 3E 15         [24] 1307 	lcall	_ak820_nvm_ok
      00834D E5 82            [12] 1308 	mov	a, dpl
      00834F 70 04            [24] 1309 	jnz	00102$
      008351                       1310 00101$:
      008351 90 FF FF         [24] 1311 	mov	dptr,#0xffff
      008354 22               [24] 1312 	ret
      008355                       1313 00102$:
                                   1314 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008355 90 0A EC         [24] 1315 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008358 E0               [24] 1316 	movx	a,@dptr
      008359 FD               [12] 1317 	mov	r5,a
      00835A BD 08 00         [24] 1318 	cjne	r5,#0x08,00133$
      00835D                       1319 00133$:
      00835D 40 04            [24] 1320 	jc	00105$
                                   1321 ;	quantum/dynamic_keymap.c:302: return -1;
      00835F 90 FF FF         [24] 1322 	mov	dptr,#0xffff
      008362 22               [24] 1323 	ret
      008363                       1324 00105$:
                                   1325 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008363 12 8B 50         [24] 1326 	lcall	_ak820_outline_0077
                                   1327 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      008366 C0 07            [24] 1328 	push	ar7
      008368 C0 06            [24] 1329 	push	ar6
      00836A C0 05            [24] 1330 	push	ar5
      00836C C0 04            [24] 1331 	push	ar4
      00836E 12 73 D6         [24] 1332 	lcall	_clear_keyboard
      008371 D0 04            [24] 1333 	pop	ar4
      008373 D0 05            [24] 1334 	pop	ar5
      008375 D0 06            [24] 1335 	pop	ar6
      008377 D0 07            [24] 1336 	pop	ar7
                                   1337 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      008379 90 0D 93         [24] 1338 	mov	dptr,#___memcpy_PARM_2
      00837C 12 46 DE         [24] 1339 	lcall	_ak820_outline_0060
      00837F E4               [12] 1340 	clr	a
      008380 A3               [24] 1341 	inc	dptr
      008381 F0               [24] 1342 	movx	@dptr,a
      008382 90 0D 96         [24] 1343 	mov	dptr,#___memcpy_PARM_3
      008385 12 8B 71         [24] 1344 	lcall	_ak820_outline_0106
      008388 90 0A ED         [24] 1345 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      00838B F5 F0            [12] 1346 	mov	b,a
      00838D C0 05            [24] 1347 	push	ar5
      00838F C0 04            [24] 1348 	push	ar4
      008391 12 B4 A3         [24] 1349 	lcall	___memcpy
      008394 D0 04            [24] 1350 	pop	ar4
      008396 D0 05            [24] 1351 	pop	ar5
                                   1352 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008398 90 0A F1         [24] 1353 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      00839B 74 20            [12] 1354 	mov	a,#0x20
      00839D F0               [24] 1355 	movx	@dptr,a
      00839E 74 08            [12] 1356 	mov	a,#0x08
      0083A0 A3               [24] 1357 	inc	dptr
      0083A1 F0               [24] 1358 	movx	@dptr,a
                                   1359 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      0083A2 90 0A F3         [24] 1360 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      0083A5 74 01            [12] 1361 	mov	a,#0x01
      0083A7 12 38 97         [24] 1362 	lcall	_ak820_outline_0122
                                   1363 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      0083AA 90 05 8E         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0083AD 12 38 5F         [24] 1365 	lcall	_ak820_outline_0071
      0083B0 E4               [12] 1366 	clr	a
      0083B1 A3               [24] 1367 	inc	dptr
      0083B2 F0               [24] 1368 	movx	@dptr,a
      0083B3 90 05 91         [24] 1369 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0083B6 12 8B 71         [24] 1370 	lcall	_ak820_outline_0106
      0083B9 90 0A ED         [24] 1371 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      0083BC 12 41 36         [24] 1372 	lcall	_ak820_eeprom_write_block_xdata
                                   1373 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      0083BF 12 3E 24         [24] 1374 	lcall	_ak820_nvm_flush
                                   1375 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      0083C2 12 3E 15         [24] 1376 	lcall	_ak820_nvm_ok
      0083C5 E5 82            [12] 1377 	mov	a, dpl
      0083C7 70 04            [24] 1378 	jnz	00107$
      0083C9 90 FF FF         [24] 1379 	mov	dptr,#0xffff
      0083CC 22               [24] 1380 	ret
      0083CD                       1381 00107$:
                                   1382 ;	quantum/dynamic_keymap.c:320: return 0;
      0083CD 90 00 00         [24] 1383 	mov	dptr,#0x0000
                                   1384 ;	quantum/dynamic_keymap.c:321: }
      0083D0 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1388 ;------------------------------------------------------------
                                   1389 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1390 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1391 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1392 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1393 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1394 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1395 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1396 ;------------------------------------------------------------
                                   1397 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1398 ;	-----------------------------------------
                                   1399 ;	 function dynamic_keymap_reset
                                   1400 ;	-----------------------------------------
      0083D1                       1401 _dynamic_keymap_reset:
                                   1402 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      0083D1 90 0E 12         [24] 1403 	mov	dptr,#_vial_unlocked
      0083D4 E0               [24] 1404 	movx	a,@dptr
      0083D5 90 0A F7         [24] 1405 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      0083D8 F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      0083D9 90 0E 12         [24] 1408 	mov	dptr,#_vial_unlocked
      0083DC 74 01            [12] 1409 	mov	a,#0x01
      0083DE F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0083DF 7F 00            [12] 1412 	mov	r7,#0x00
      0083E1                       1413 00116$:
      0083E1 BF 06 00         [24] 1414 	cjne	r7,#0x06,00198$
      0083E4                       1415 00198$:
      0083E4 40 03            [24] 1416 	jc	00199$
      0083E6 02 84 94         [24] 1417 	ljmp	00104$
      0083E9                       1418 00199$:
                                   1419 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0083E9 7E 00            [12] 1420 	mov	r6,#0x00
      0083EB                       1421 00110$:
      0083EB BE 10 00         [24] 1422 	cjne	r6,#0x10,00200$
      0083EE                       1423 00200$:
      0083EE 50 4D            [24] 1424 	jnc	00102$
                                   1425 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0083F0 7D 00            [12] 1426 	mov	r5,#0x00
      0083F2                       1427 00107$:
      0083F2 BD 08 00         [24] 1428 	cjne	r5,#0x08,00202$
      0083F5                       1429 00202$:
      0083F5 50 43            [24] 1430 	jnc	00111$
                                   1431 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0083F7 90 0B 93         [24] 1432 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0083FA EE               [12] 1433 	mov	a,r6
      0083FB F0               [24] 1434 	movx	@dptr,a
      0083FC 90 0B 94         [24] 1435 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0083FF ED               [12] 1436 	mov	a,r5
      008400 F0               [24] 1437 	movx	@dptr,a
      008401 8F 82            [24] 1438 	mov	dpl, r7
      008403 C0 07            [24] 1439 	push	ar7
      008405 C0 06            [24] 1440 	push	ar6
      008407 C0 05            [24] 1441 	push	ar5
      008409 12 93 A1         [24] 1442 	lcall	_keycode_at_keymap_location_raw
      00840C AB 82            [24] 1443 	mov	r3, dpl
      00840E AC 83            [24] 1444 	mov	r4, dph
      008410 D0 05            [24] 1445 	pop	ar5
      008412 D0 06            [24] 1446 	pop	ar6
      008414 D0 07            [24] 1447 	pop	ar7
      008416 90 0A D6         [24] 1448 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008419 EE               [12] 1449 	mov	a,r6
      00841A F0               [24] 1450 	movx	@dptr,a
      00841B 90 0A D7         [24] 1451 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00841E ED               [12] 1452 	mov	a,r5
      00841F F0               [24] 1453 	movx	@dptr,a
      008420 90 0A D8         [24] 1454 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008423 12 38 65         [24] 1455 	lcall	_ak820_outline_0081
      008426 8F 82            [24] 1456 	mov	dpl, r7
      008428 C0 07            [24] 1457 	push	ar7
      00842A C0 06            [24] 1458 	push	ar6
      00842C C0 05            [24] 1459 	push	ar5
      00842E 12 81 4B         [24] 1460 	lcall	_dynamic_keymap_set_keycode
      008431 D0 05            [24] 1461 	pop	ar5
      008433 D0 06            [24] 1462 	pop	ar6
      008435 D0 07            [24] 1463 	pop	ar7
                                   1464 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008437 0D               [12] 1465 	inc	r5
      008438 80 B8            [24] 1466 	sjmp	00107$
      00843A                       1467 00111$:
                                   1468 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      00843A 0E               [12] 1469 	inc	r6
      00843B 80 AE            [24] 1470 	sjmp	00110$
      00843D                       1471 00102$:
                                   1472 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      00843D 7E 00            [12] 1473 	mov	r6,#0x00
      00843F                       1474 00113$:
      00843F BE 01 00         [24] 1475 	cjne	r6,#0x01,00204$
      008442                       1476 00204$:
      008442 50 4C            [24] 1477 	jnc	00117$
                                   1478 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008444 12 8B A6         [24] 1479 	lcall	_ak820_outline_0175
      008447 04               [12] 1480 	inc	a
      008448 F0               [24] 1481 	movx	@dptr,a
      008449 8F 82            [24] 1482 	mov	dpl, r7
      00844B C0 07            [24] 1483 	push	ar7
      00844D 12 93 E6         [24] 1484 	lcall	_keycode_at_encodermap_location_raw
      008450 12 43 6C         [24] 1485 	lcall	_ak820_outline_0144
      008453 D0 07            [24] 1486 	pop	ar7
      008455 12 8B 9D         [24] 1487 	lcall	_ak820_outline_0174
      008458 04               [12] 1488 	inc	a
      008459 F0               [24] 1489 	movx	@dptr,a
      00845A 90 0A E2         [24] 1490 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00845D 12 38 5F         [24] 1491 	lcall	_ak820_outline_0071
      008460 8F 82            [24] 1492 	mov	dpl, r7
      008462 C0 07            [24] 1493 	push	ar7
      008464 12 82 24         [24] 1494 	lcall	_dynamic_keymap_set_encoder
      008467 D0 07            [24] 1495 	pop	ar7
                                   1496 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008469 12 8B A6         [24] 1497 	lcall	_ak820_outline_0175
      00846C F0               [24] 1498 	movx	@dptr,a
      00846D 8F 82            [24] 1499 	mov	dpl, r7
      00846F C0 07            [24] 1500 	push	ar7
      008471 12 93 E6         [24] 1501 	lcall	_keycode_at_encodermap_location_raw
      008474 12 43 6C         [24] 1502 	lcall	_ak820_outline_0144
      008477 D0 07            [24] 1503 	pop	ar7
      008479 12 8B 9D         [24] 1504 	lcall	_ak820_outline_0174
      00847C F0               [24] 1505 	movx	@dptr,a
      00847D 90 0A E2         [24] 1506 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008480 12 38 5F         [24] 1507 	lcall	_ak820_outline_0071
      008483 8F 82            [24] 1508 	mov	dpl, r7
      008485 C0 07            [24] 1509 	push	ar7
      008487 12 82 24         [24] 1510 	lcall	_dynamic_keymap_set_encoder
      00848A D0 07            [24] 1511 	pop	ar7
                                   1512 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      00848C 7E 01            [12] 1513 	mov	r6,#0x01
      00848E 80 AF            [24] 1514 	sjmp	00113$
      008490                       1515 00117$:
                                   1516 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008490 0F               [12] 1517 	inc	r7
      008491 02 83 E1         [24] 1518 	ljmp	00116$
      008494                       1519 00104$:
                                   1520 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      008494 90 0A F8         [24] 1521 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      008497 12 4D 73         [24] 1522 	lcall	_ak820_outline_0166
      00849A 90 0A FA         [24] 1523 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      00849D F0               [24] 1524 	movx	@dptr,a
      00849E A3               [24] 1525 	inc	dptr
      00849F F0               [24] 1526 	movx	@dptr,a
      0084A0 90 0A FC         [24] 1527 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      0084A3 F0               [24] 1528 	movx	@dptr,a
      0084A4 A3               [24] 1529 	inc	dptr
      0084A5 F0               [24] 1530 	movx	@dptr,a
      0084A6 90 0A FE         [24] 1531 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      0084A9 F0               [24] 1532 	movx	@dptr,a
      0084AA A3               [24] 1533 	inc	dptr
      0084AB F0               [24] 1534 	movx	@dptr,a
      0084AC 90 0B 00         [24] 1535 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      0084AF F0               [24] 1536 	movx	@dptr,a
      0084B0 A3               [24] 1537 	inc	dptr
      0084B1 F0               [24] 1538 	movx	@dptr,a
                                   1539 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0084B2 FF               [12] 1540 	mov	r7,a
      0084B3                       1541 00119$:
      0084B3 BF 08 00         [24] 1542 	cjne	r7,#0x08,00206$
      0084B6                       1543 00206$:
      0084B6 50 19            [24] 1544 	jnc	00105$
                                   1545 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      0084B8 8F 06            [24] 1546 	mov	ar6,r7
      0084BA 90 0A E9         [24] 1547 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0084BD 74 F8            [12] 1548 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      0084BF F0               [24] 1549 	movx	@dptr,a
      0084C0 74 0A            [12] 1550 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      0084C2 12 38 6B         [24] 1551 	lcall	_ak820_outline_0089
      0084C5 8E 82            [24] 1552 	mov	dpl, r6
      0084C7 C0 07            [24] 1553 	push	ar7
      0084C9 12 83 2F         [24] 1554 	lcall	_dynamic_keymap_set_combo
      0084CC D0 07            [24] 1555 	pop	ar7
                                   1556 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0084CE 0F               [12] 1557 	inc	r7
      0084CF 80 E2            [24] 1558 	sjmp	00119$
      0084D1                       1559 00105$:
                                   1560 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      0084D1 90 0A F7         [24] 1561 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      0084D4 E0               [24] 1562 	movx	a,@dptr
      0084D5 90 0E 12         [24] 1563 	mov	dptr,#_vial_unlocked
      0084D8 F0               [24] 1564 	movx	@dptr,a
                                   1565 ;	quantum/dynamic_keymap.c:405: }
      0084D9 22               [24] 1566 	ret
                                   1567 ;------------------------------------------------------------
                                   1568 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1569 ;------------------------------------------------------------
                                   1570 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1571 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1572 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1573 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1574 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1575 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1576 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1577 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1578 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1579 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1580 ;------------------------------------------------------------
                                   1581 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1582 ;	-----------------------------------------
                                   1583 ;	 function ak820_dynamic_read_buffer
                                   1584 ;	-----------------------------------------
      0084DA                       1585 _ak820_dynamic_read_buffer:
      0084DA 12 38 88         [24] 1586 	lcall	_ak820_outline_0113
      0084DD 90 0B 0B         [24] 1587 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      0084E0 12 38 83         [24] 1588 	lcall	_ak820_outline_0112
                                   1589 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0084E3 90 0B 08         [24] 1590 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0084E6 12 38 42         [24] 1591 	lcall	_ak820_outline_0052
                                   1592 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      0084E9 90 0B 0D         [24] 1593 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0084EC E4               [12] 1594 	clr	a
      0084ED F0               [24] 1595 	movx	@dptr,a
                                   1596 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      0084EE 90 0B 06         [24] 1597 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0084F1 12 38 59         [24] 1598 	lcall	_ak820_outline_0061
      0084F4 8C 02            [24] 1599 	mov	ar2,r4
      0084F6 8D 03            [24] 1600 	mov	ar3,r5
      0084F8 C3               [12] 1601 	clr	c
      0084F9 74 1C            [12] 1602 	mov	a,#0x1c
      0084FB 9A               [12] 1603 	subb	a,r2
      0084FC E4               [12] 1604 	clr	a
      0084FD 9B               [12] 1605 	subb	a,r3
      0084FE 50 01            [24] 1606 	jnc	00102$
                                   1607 ;	free result
      008500 22               [24] 1608 	ret
      008501                       1609 00102$:
                                   1610 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      008501 90 0B 04         [24] 1611 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008504 12 43 3E         [24] 1612 	lcall	_ak820_outline_0100
      008507 90 0B 02         [24] 1613 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00850A 12 38 77         [24] 1614 	lcall	_ak820_outline_0099
      00850D C3               [12] 1615 	clr	c
      00850E EA               [12] 1616 	mov	a,r2
      00850F 98               [12] 1617 	subb	a,r0
      008510 EB               [12] 1618 	mov	a,r3
      008511 99               [12] 1619 	subb	a,r1
      008512 50 17            [24] 1620 	jnc	00104$
                                   1621 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      008514 E8               [12] 1622 	mov	a,r0
      008515 C3               [12] 1623 	clr	c
      008516 9A               [12] 1624 	subb	a,r2
      008517 F8               [12] 1625 	mov	r0,a
      008518 E9               [12] 1626 	mov	a,r1
      008519 9B               [12] 1627 	subb	a,r3
      00851A F9               [12] 1628 	mov	r1,a
                                   1629 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      00851B C3               [12] 1630 	clr	c
      00851C E8               [12] 1631 	mov	a,r0
      00851D 9C               [12] 1632 	subb	a,r4
      00851E E9               [12] 1633 	mov	a,r1
      00851F 9D               [12] 1634 	subb	a,r5
      008520 40 04            [24] 1635 	jc	00114$
      008522 8C 00            [24] 1636 	mov	ar0,r4
      008524 8D 01            [24] 1637 	mov	ar1,r5
      008526                       1638 00114$:
      008526 90 0B 0D         [24] 1639 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008529 E8               [12] 1640 	mov	a,r0
      00852A F0               [24] 1641 	movx	@dptr,a
      00852B                       1642 00104$:
                                   1643 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      00852B 90 0B 0D         [24] 1644 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      00852E E0               [24] 1645 	movx	a,@dptr
      00852F F5 34            [12] 1646 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008531 E0               [24] 1647 	movx	a,@dptr
      008532 60 42            [24] 1648 	jz	00106$
      008534 C0 04            [24] 1649 	push	ar4
      008536 C0 05            [24] 1650 	push	ar5
      008538 8E 00            [24] 1651 	mov	ar0,r6
      00853A 8F 05            [24] 1652 	mov	ar5,r7
      00853C 90 0B 0B         [24] 1653 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      00853F E0               [24] 1654 	movx	a,@dptr
      008540 F9               [12] 1655 	mov	r1,a
      008541 A3               [24] 1656 	inc	dptr
      008542 E0               [24] 1657 	movx	a,@dptr
      008543 FC               [12] 1658 	mov	r4,a
      008544 EA               [12] 1659 	mov	a,r2
      008545 29               [12] 1660 	add	a, r1
      008546 FA               [12] 1661 	mov	r2,a
      008547 EB               [12] 1662 	mov	a,r3
      008548 3C               [12] 1663 	addc	a, r4
      008549 FB               [12] 1664 	mov	r3,a
      00854A 90 05 85         [24] 1665 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00854D EA               [12] 1666 	mov	a,r2
      00854E F0               [24] 1667 	movx	@dptr,a
      00854F EB               [12] 1668 	mov	a,r3
      008550 12 38 6B         [24] 1669 	lcall	_ak820_outline_0089
      008553 90 05 88         [24] 1670 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008556 E5 34            [12] 1671 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008558 12 38 97         [24] 1672 	lcall	_ak820_outline_0122
      00855B 88 82            [24] 1673 	mov	dpl, r0
      00855D 8D 83            [24] 1674 	mov	dph, r5
      00855F C0 07            [24] 1675 	push	ar7
      008561 C0 06            [24] 1676 	push	ar6
      008563 C0 05            [24] 1677 	push	ar5
      008565 C0 04            [24] 1678 	push	ar4
      008567 12 40 AA         [24] 1679 	lcall	_ak820_eeprom_read_block_xdata
      00856A D0 04            [24] 1680 	pop	ar4
      00856C D0 05            [24] 1681 	pop	ar5
      00856E D0 06            [24] 1682 	pop	ar6
      008570 D0 07            [24] 1683 	pop	ar7
                                   1684 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008572 D0 05            [24] 1685 	pop	ar5
      008574 D0 04            [24] 1686 	pop	ar4
                                   1687 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008576                       1688 00106$:
                                   1689 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008576 90 0B 0D         [24] 1690 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008579 E0               [24] 1691 	movx	a,@dptr
      00857A FB               [12] 1692 	mov	r3,a
      00857B                       1693 00109$:
      00857B 8B 01            [24] 1694 	mov	ar1,r3
      00857D 7A 00            [12] 1695 	mov	r2,#0x00
      00857F C3               [12] 1696 	clr	c
      008580 E9               [12] 1697 	mov	a,r1
      008581 9C               [12] 1698 	subb	a,r4
      008582 EA               [12] 1699 	mov	a,r2
      008583 9D               [12] 1700 	subb	a,r5
      008584 50 09            [24] 1701 	jnc	00111$
      008586 EB               [12] 1702 	mov	a,r3
      008587 12 38 32         [24] 1703 	lcall	_ak820_outline_0021
      00858A E4               [12] 1704 	clr	a
      00858B F0               [24] 1705 	movx	@dptr,a
      00858C 0B               [12] 1706 	inc	r3
      00858D 80 EC            [24] 1707 	sjmp	00109$
      00858F                       1708 00111$:
                                   1709 ;	quantum/dynamic_keymap.c:420: }
      00858F 22               [24] 1710 	ret
                                   1711 ;------------------------------------------------------------
                                   1712 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1713 ;------------------------------------------------------------
                                   1714 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1715 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1716 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1717 ;------------------------------------------------------------
                                   1718 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1719 ;	-----------------------------------------
                                   1720 ;	 function dynamic_keymap_get_buffer
                                   1721 ;	-----------------------------------------
      008590                       1722 _dynamic_keymap_get_buffer:
      008590 12 38 88         [24] 1723 	lcall	_ak820_outline_0113
      008593 90 0B 13         [24] 1724 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008596 12 38 83         [24] 1725 	lcall	_ak820_outline_0112
                                   1726 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008599 90 0B 13         [24] 1727 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      00859C 12 38 42         [24] 1728 	lcall	_ak820_outline_0052
      00859F 90 0B 0E         [24] 1729 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      0085A2 12 38 59         [24] 1730 	lcall	_ak820_outline_0061
      0085A5 90 0B 10         [24] 1731 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      0085A8 12 4D 5A         [24] 1732 	lcall	_ak820_outline_0087
      0085AB 90 0B 02         [24] 1733 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0085AE E4               [12] 1734 	clr	a
      0085AF F0               [24] 1735 	movx	@dptr,a
      0085B0 74 06            [12] 1736 	mov	a,#0x06
      0085B2 A3               [24] 1737 	inc	dptr
      0085B3 F0               [24] 1738 	movx	@dptr,a
      0085B4 90 0B 04         [24] 1739 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0085B7 12 46 DE         [24] 1740 	lcall	_ak820_outline_0060
      0085BA 90 0B 06         [24] 1741 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0085BD 12 38 5F         [24] 1742 	lcall	_ak820_outline_0071
      0085C0 90 0B 08         [24] 1743 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0085C3 E9               [12] 1744 	mov	a,r1
      0085C4 12 4D 6C         [24] 1745 	lcall	_ak820_outline_0151
      0085C7 F0               [24] 1746 	movx	@dptr,a
      0085C8 90 00 40         [24] 1747 	mov	dptr,#0x0040
                                   1748 ;	quantum/dynamic_keymap.c:448: }
      0085CB 02 84 DA         [24] 1749 	ljmp	_ak820_dynamic_read_buffer
                                   1750 ;------------------------------------------------------------
                                   1751 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1752 ;------------------------------------------------------------
                                   1753 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1754 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1755 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1756 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1757 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1758 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1759 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1760 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1761 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1762 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1763 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1764 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1765 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1766 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1767 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1768 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1769 ;------------------------------------------------------------
                                   1770 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1771 ;	-----------------------------------------
                                   1772 ;	 function dynamic_keymap_set_buffer
                                   1773 ;	-----------------------------------------
      0085CE                       1774 _dynamic_keymap_set_buffer:
      0085CE 12 38 88         [24] 1775 	lcall	_ak820_outline_0113
      0085D1 90 0B 1A         [24] 1776 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0085D4 12 38 83         [24] 1777 	lcall	_ak820_outline_0112
                                   1778 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      0085D7 90 0B 1A         [24] 1779 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0085DA 12 46 89         [24] 1780 	lcall	_ak820_outline_0008
      0085DD 74 40            [12] 1781 	mov	a,#0x40
      0085DF 2C               [12] 1782 	add	a, r4
      0085E0 FA               [12] 1783 	mov	r2,a
      0085E1 E4               [12] 1784 	clr	a
      0085E2 3D               [12] 1785 	addc	a, r5
      0085E3 FB               [12] 1786 	mov	r3,a
                                   1787 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0085E4 90 0B 17         [24] 1788 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      0085E7 12 38 77         [24] 1789 	lcall	_ak820_outline_0099
                                   1790 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      0085EA 90 0B 15         [24] 1791 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      0085ED E0               [24] 1792 	movx	a,@dptr
      0085EE F5 35            [12] 1793 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      0085F0 A3               [24] 1794 	inc	dptr
      0085F1 E0               [24] 1795 	movx	a,@dptr
      0085F2 F5 36            [12] 1796 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      0085F4 E5 35            [12] 1797 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0085F6 45 36            [12] 1798 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0085F8 70 01            [24] 1799 	jnz	00102$
      0085FA 22               [24] 1800 	ret
      0085FB                       1801 00102$:
                                   1802 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      0085FB 85 35 37         [24] 1803 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      0085FE 85 36 38         [24] 1804 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008601 C3               [12] 1805 	clr	c
      008602 74 1C            [12] 1806 	mov	a,#0x1c
      008604 95 37            [12] 1807 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008606 E4               [12] 1808 	clr	a
      008607 95 38            [12] 1809 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008609 50 01            [24] 1810 	jnc	00104$
                                   1811 ;	free result
      00860B 22               [24] 1812 	ret
      00860C                       1813 00104$:
                                   1814 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      00860C 85 35 39         [24] 1815 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1816 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      00860F 74 FA            [12] 1817 	mov	a,#0x100 - 0x06
      008611 2F               [12] 1818 	add	a,r7
      008612 40 11            [24] 1819 	jc	00105$
      008614 E4               [12] 1820 	clr	a
      008615 C3               [12] 1821 	clr	c
      008616 9E               [12] 1822 	subb	a,r6
      008617 FE               [12] 1823 	mov	r6,a
      008618 74 06            [12] 1824 	mov	a,#0x06
      00861A 9F               [12] 1825 	subb	a,r7
      00861B FF               [12] 1826 	mov	r7,a
      00861C C3               [12] 1827 	clr	c
      00861D EE               [12] 1828 	mov	a,r6
      00861E 95 35            [12] 1829 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008620 EF               [12] 1830 	mov	a,r7
      008621 95 36            [12] 1831 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008623 50 01            [24] 1832 	jnc	00106$
      008625                       1833 00105$:
                                   1834 ;	quantum/dynamic_keymap.c:466: return;
      008625 22               [24] 1835 	ret
      008626                       1836 00106$:
                                   1837 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      008626 90 0E 12         [24] 1838 	mov	dptr,#_vial_unlocked
      008629 E0               [24] 1839 	movx	a,@dptr
      00862A 60 03            [24] 1840 	jz	00207$
      00862C 02 87 38         [24] 1841 	ljmp	00120$
      00862F                       1842 00207$:
                                   1843 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      00862F 90 0B 1C         [24] 1844 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008632 E4               [12] 1845 	clr	a
      008633 F0               [24] 1846 	movx	@dptr,a
                                   1847 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      008634 90 0B 1D         [24] 1848 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008637 E5 39            [12] 1849 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008639 F0               [24] 1850 	movx	@dptr,a
                                   1851 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      00863A EC               [12] 1852 	mov	a,r4
      00863B 30 E0 31         [24] 1853 	jnb	acc.0,00111$
                                   1854 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      00863E EA               [12] 1855 	mov	a,r2
      00863F 24 FF            [12] 1856 	add	a,#0xff
      008641 FE               [12] 1857 	mov	r6,a
      008642 EB               [12] 1858 	mov	a,r3
      008643 34 FF            [12] 1859 	addc	a,#0xff
      008645 FF               [12] 1860 	mov	r7,a
      008646 7D 00            [12] 1861 	mov	r5,#0x00
      008648 12 6D B4         [24] 1862 	lcall	_ak820_outline_0050
      00864B 12 40 6F         [24] 1863 	lcall	_eeprom_read_byte
      00864E AE 82            [24] 1864 	mov	r6,dpl
      008650 7F 00            [12] 1865 	mov	r7,#0x00
      008652 12 38 B1         [24] 1866 	lcall	_ak820_outline_0153
      008655 E0               [24] 1867 	movx	a,@dptr
      008656 7C 00            [12] 1868 	mov	r4,#0x00
      008658 42 07            [12] 1869 	orl	ar7,a
      00865A EC               [12] 1870 	mov	a,r4
      00865B 42 06            [12] 1871 	orl	ar6,a
                                   1872 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      00865D BF 00 09         [24] 1873 	cjne	r7,#0x00,00109$
      008660 BE 7C 06         [24] 1874 	cjne	r6,#0x7c,00109$
                                   1875 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008663 12 38 B1         [24] 1876 	lcall	_ak820_outline_0153
      008666 74 FF            [12] 1877 	mov	a,#0xff
      008668 F0               [24] 1878 	movx	@dptr,a
      008669                       1879 00109$:
                                   1880 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      008669 90 0B 1C         [24] 1881 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      00866C 74 01            [12] 1882 	mov	a,#0x01
      00866E F0               [24] 1883 	movx	@dptr,a
      00866F                       1884 00111$:
                                   1885 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      00866F 90 0B 1A         [24] 1886 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008672 12 38 42         [24] 1887 	lcall	_ak820_outline_0052
      008675 E5 35            [12] 1888 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008677 2E               [12] 1889 	add	a, r6
      008678 FE               [12] 1890 	mov	r6,a
      008679 E5 36            [12] 1891 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00867B 3F               [12] 1892 	addc	a, r7
      00867C EE               [12] 1893 	mov	a,r6
      00867D 30 E0 5A         [24] 1894 	jnb	acc.0,00115$
                                   1895 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008680 AE 39            [24] 1896 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008682 7F 00            [12] 1897 	mov	r7,#0x00
      008684 EE               [12] 1898 	mov	a,r6
      008685 24 FF            [12] 1899 	add	a,#0xff
      008687 FC               [12] 1900 	mov	r4,a
      008688 EF               [12] 1901 	mov	a,r7
      008689 34 FF            [12] 1902 	addc	a,#0xff
      00868B FD               [12] 1903 	mov	r5,a
      00868C EC               [12] 1904 	mov	a,r4
      00868D 28               [12] 1905 	add	a, r0
      00868E F5 82            [12] 1906 	mov	dpl,a
      008690 ED               [12] 1907 	mov	a,r5
      008691 39               [12] 1908 	addc	a, r1
      008692 F5 83            [12] 1909 	mov	dph,a
      008694 E0               [24] 1910 	movx	a,@dptr
      008695 FC               [12] 1911 	mov	r4,a
      008696 7D 00            [12] 1912 	mov	r5,#0x00
      008698 E5 39            [12] 1913 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00869A 2A               [12] 1914 	add	a, r2
      00869B FA               [12] 1915 	mov	r2,a
      00869C E4               [12] 1916 	clr	a
      00869D 3B               [12] 1917 	addc	a, r3
      00869E FB               [12] 1918 	mov	r3,a
      00869F C0 00            [24] 1919 	push	ar0
      0086A1 C0 01            [24] 1920 	push	ar1
      0086A3 8B 01            [24] 1921 	mov	ar1,r3
      0086A5 7B 00            [12] 1922 	mov	r3,#0x00
      0086A7 8A 82            [24] 1923 	mov	dpl, r2
      0086A9 89 83            [24] 1924 	mov	dph, r1
      0086AB 8B F0            [24] 1925 	mov	b, r3
      0086AD 12 40 6F         [24] 1926 	lcall	_eeprom_read_byte
      0086B0 AB 82            [24] 1927 	mov	r3, dpl
      0086B2 7A 00            [12] 1928 	mov	r2,#0x00
      0086B4 EB               [12] 1929 	mov	a,r3
      0086B5 12 43 61         [24] 1930 	lcall	_ak820_outline_0138
                                   1931 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      0086B8 BD 00 05         [24] 1932 	cjne	r5,#0x00,00212$
      0086BB BC 7C 02         [24] 1933 	cjne	r4,#0x7c,00212$
      0086BE 80 06            [24] 1934 	sjmp	00213$
      0086C0                       1935 00212$:
      0086C0 D0 01            [24] 1936 	pop	ar1
      0086C2 D0 00            [24] 1937 	pop	ar0
      0086C4 80 0D            [24] 1938 	sjmp	00113$
      0086C6                       1939 00213$:
      0086C6 D0 01            [24] 1940 	pop	ar1
      0086C8 D0 00            [24] 1941 	pop	ar0
                                   1942 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      0086CA 1E               [12] 1943 	dec	r6
      0086CB BE FF 01         [24] 1944 	cjne	r6,#0xff,00214$
      0086CE 1F               [12] 1945 	dec	r7
      0086CF                       1946 00214$:
      0086CF EE               [12] 1947 	mov	a,r6
      0086D0 12 8B 7F         [24] 1948 	lcall	_ak820_outline_0126
      0086D3                       1949 00113$:
                                   1950 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      0086D3 E5 39            [12] 1951 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0086D5 14               [12] 1952 	dec	a
      0086D6 90 0B 1D         [24] 1953 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      0086D9 F0               [24] 1954 	movx	@dptr,a
      0086DA                       1955 00115$:
                                   1956 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0086DA 90 0B 1C         [24] 1957 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0086DD E0               [24] 1958 	movx	a,@dptr
      0086DE 90 0B 1E         [24] 1959 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      0086E1 F0               [24] 1960 	movx	@dptr,a
      0086E2                       1961 00122$:
      0086E2 90 0B 1E         [24] 1962 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      0086E5 E0               [24] 1963 	movx	a,@dptr
      0086E6 FF               [12] 1964 	mov	r7,a
      0086E7 90 0B 1D         [24] 1965 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      0086EA E0               [24] 1966 	movx	a,@dptr
      0086EB FE               [12] 1967 	mov	r6,a
      0086EC C3               [12] 1968 	clr	c
      0086ED EF               [12] 1969 	mov	a,r7
      0086EE 9E               [12] 1970 	subb	a,r6
      0086EF 50 47            [24] 1971 	jnc	00120$
                                   1972 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      0086F1 EF               [12] 1973 	mov	a,r7
      0086F2 28               [12] 1974 	add	a, r0
      0086F3 FD               [12] 1975 	mov	r5,a
      0086F4 E4               [12] 1976 	clr	a
      0086F5 39               [12] 1977 	addc	a, r1
      0086F6 12 46 D6         [24] 1978 	lcall	_ak820_outline_0058
      0086F9 7B 00            [12] 1979 	mov	r3,#0x00
      0086FB 8C 36            [24] 1980 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      0086FD 8B 35            [24] 1981 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      0086FF 8F 02            [24] 1982 	mov	ar2,r7
      008701 7F 00            [12] 1983 	mov	r7,#0x00
      008703 74 01            [12] 1984 	mov	a,#0x01
      008705 2A               [12] 1985 	add	a, r2
      008706 FB               [12] 1986 	mov	r3,a
      008707 E4               [12] 1987 	clr	a
      008708 3F               [12] 1988 	addc	a, r7
      008709 FC               [12] 1989 	mov	r4,a
      00870A EB               [12] 1990 	mov	a,r3
      00870B 28               [12] 1991 	add	a, r0
      00870C F5 82            [12] 1992 	mov	dpl,a
      00870E EC               [12] 1993 	mov	a,r4
      00870F 39               [12] 1994 	addc	a, r1
      008710 F5 83            [12] 1995 	mov	dph,a
      008712 E0               [24] 1996 	movx	a,@dptr
      008713 FC               [12] 1997 	mov	r4,a
      008714 7B 00            [12] 1998 	mov	r3,#0x00
      008716 E5 36            [12] 1999 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008718 42 03            [12] 2000 	orl	ar3,a
                                   2001 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      00871A BC 00 12         [24] 2002 	cjne	r4,#0x00,00123$
      00871D BB 7C 0F         [24] 2003 	cjne	r3,#0x7c,00123$
                                   2004 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008720 12 38 9C         [24] 2005 	lcall	_ak820_outline_0130
      008723 74 FF            [12] 2006 	mov	a,#0xff
      008725 F0               [24] 2007 	movx	@dptr,a
                                   2008 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008726 0A               [12] 2009 	inc	r2
      008727 BA 00 01         [24] 2010 	cjne	r2,#0x00,00218$
      00872A 0F               [12] 2011 	inc	r7
      00872B                       2012 00218$:
      00872B EA               [12] 2013 	mov	a,r2
      00872C 12 8B 7F         [24] 2014 	lcall	_ak820_outline_0126
      00872F                       2015 00123$:
                                   2016 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      00872F 90 0B 1E         [24] 2017 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008732 E0               [24] 2018 	movx	a,@dptr
      008733 24 02            [12] 2019 	add	a,#0x02
      008735 F0               [24] 2020 	movx	@dptr,a
      008736 80 AA            [24] 2021 	sjmp	00122$
      008738                       2022 00120$:
                                   2023 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008738 90 0B 1A         [24] 2024 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      00873B 12 38 42         [24] 2025 	lcall	_ak820_outline_0052
      00873E 74 40            [12] 2026 	mov	a,#0x40
      008740 12 43 5B         [24] 2027 	lcall	_ak820_outline_0133
      008743 90 05 8E         [24] 2028 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008746 12 46 DE         [24] 2029 	lcall	_ak820_outline_0060
      008749 E4               [12] 2030 	clr	a
      00874A A3               [24] 2031 	inc	dptr
      00874B F0               [24] 2032 	movx	@dptr,a
      00874C 90 05 91         [24] 2033 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00874F E5 37            [12] 2034 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008751 F0               [24] 2035 	movx	@dptr,a
      008752 E5 38            [12] 2036 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008754 A3               [24] 2037 	inc	dptr
      008755 F0               [24] 2038 	movx	@dptr,a
      008756 12 38 B1         [24] 2039 	lcall	_ak820_outline_0153
                                   2040 ;	quantum/dynamic_keymap.c:521: }
      008759 02 41 36         [24] 2041 	ljmp	_ak820_eeprom_write_block_xdata
                                   2042 ;------------------------------------------------------------
                                   2043 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2044 ;------------------------------------------------------------
                                   2045 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2046 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2047 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2048 ;------------------------------------------------------------
                                   2049 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2050 ;	-----------------------------------------
                                   2051 ;	 function keycode_at_keymap_location
                                   2052 ;	-----------------------------------------
      00875C                       2053 _keycode_at_keymap_location:
      00875C E5 82            [12] 2054 	mov	a,dpl
      00875E 90 0B 21         [24] 2055 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      008761 F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008762 E0               [24] 2058 	movx	a,@dptr
      008763 FF               [12] 2059 	mov	r7,a
      008764 BF 06 00         [24] 2060 	cjne	r7,#0x06,00128$
      008767                       2061 00128$:
      008767 50 23            [24] 2062 	jnc	00102$
      008769 90 0B 1F         [24] 2063 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      00876C E0               [24] 2064 	movx	a,@dptr
      00876D FE               [12] 2065 	mov	r6,a
      00876E BE 10 00         [24] 2066 	cjne	r6,#0x10,00130$
      008771                       2067 00130$:
      008771 50 19            [24] 2068 	jnc	00102$
      008773 90 0B 20         [24] 2069 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008776 E0               [24] 2070 	movx	a,@dptr
      008777 FD               [12] 2071 	mov	r5,a
      008778 BD 08 00         [24] 2072 	cjne	r5,#0x08,00132$
      00877B                       2073 00132$:
      00877B 50 0F            [24] 2074 	jnc	00102$
                                   2075 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      00877D 90 0A D3         [24] 2076 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008780 EE               [12] 2077 	mov	a,r6
      008781 F0               [24] 2078 	movx	@dptr,a
      008782 90 0A D4         [24] 2079 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008785 ED               [12] 2080 	mov	a,r5
      008786 F0               [24] 2081 	movx	@dptr,a
      008787 8F 82            [24] 2082 	mov	dpl, r7
      008789 02 80 FD         [24] 2083 	ljmp	_dynamic_keymap_get_keycode
      00878C                       2084 00102$:
                                   2085 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      00878C 90 00 00         [24] 2086 	mov	dptr,#0x0000
                                   2087 ;	quantum/dynamic_keymap.c:528: }
      00878F 22               [24] 2088 	ret
                                   2089 ;------------------------------------------------------------
                                   2090 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2091 ;------------------------------------------------------------
                                   2092 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2093 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2094 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2095 ;------------------------------------------------------------
                                   2096 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2097 ;	-----------------------------------------
                                   2098 ;	 function keycode_at_encodermap_location
                                   2099 ;	-----------------------------------------
      008790                       2100 _keycode_at_encodermap_location:
      008790 E5 82            [12] 2101 	mov	a,dpl
      008792 90 0B 24         [24] 2102 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      008795 F0               [24] 2103 	movx	@dptr,a
                                   2104 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008796 E0               [24] 2105 	movx	a,@dptr
      008797 FF               [12] 2106 	mov	r7,a
      008798 BF 06 00         [24] 2107 	cjne	r7,#0x06,00120$
      00879B                       2108 00120$:
      00879B 50 1E            [24] 2109 	jnc	00102$
      00879D 90 0B 22         [24] 2110 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0087A0 E0               [24] 2111 	movx	a,@dptr
      0087A1 FE               [12] 2112 	mov	r6,a
      0087A2 BE 01 00         [24] 2113 	cjne	r6,#0x01,00122$
      0087A5                       2114 00122$:
      0087A5 50 14            [24] 2115 	jnc	00102$
                                   2116 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      0087A7 90 0B 23         [24] 2117 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0087AA E0               [24] 2118 	movx	a,@dptr
      0087AB FE               [12] 2119 	mov	r6,a
      0087AC 90 0A DD         [24] 2120 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0087AF E4               [12] 2121 	clr	a
      0087B0 F0               [24] 2122 	movx	@dptr,a
      0087B1 90 0A DE         [24] 2123 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0087B4 EE               [12] 2124 	mov	a,r6
      0087B5 F0               [24] 2125 	movx	@dptr,a
      0087B6 8F 82            [24] 2126 	mov	dpl, r7
      0087B8 02 81 BC         [24] 2127 	ljmp	_dynamic_keymap_get_encoder
      0087BB                       2128 00102$:
                                   2129 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      0087BB 90 00 00         [24] 2130 	mov	dptr,#0x0000
                                   2131 ;	quantum/dynamic_keymap.c:536: }
      0087BE 22               [24] 2132 	ret
                                   2133 ;------------------------------------------------------------
                                   2134 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2135 ;------------------------------------------------------------
                                   2136 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2137 ;	-----------------------------------------
                                   2138 ;	 function dynamic_keymap_macro_get_count
                                   2139 ;	-----------------------------------------
      0087BF                       2140 _dynamic_keymap_macro_get_count:
                                   2141 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      0087BF 75 82 10         [24] 2142 	mov	dpl, #0x10
                                   2143 ;	quantum/dynamic_keymap.c:541: }
      0087C2 22               [24] 2144 	ret
                                   2145 ;------------------------------------------------------------
                                   2146 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2147 ;------------------------------------------------------------
                                   2148 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2149 ;	-----------------------------------------
                                   2150 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2151 ;	-----------------------------------------
      0087C3                       2152 _dynamic_keymap_macro_get_buffer_size:
                                   2153 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      0087C3 90 20 00         [24] 2154 	mov	dptr,#0x2000
                                   2155 ;	quantum/dynamic_keymap.c:545: }
      0087C6 22               [24] 2156 	ret
                                   2157 ;------------------------------------------------------------
                                   2158 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2159 ;------------------------------------------------------------
                                   2160 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2161 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2162 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2163 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2164 ;------------------------------------------------------------
                                   2165 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2166 ;	-----------------------------------------
                                   2167 ;	 function dynamic_keymap_macro_get_buffer
                                   2168 ;	-----------------------------------------
      0087C7                       2169 _dynamic_keymap_macro_get_buffer:
      0087C7 12 38 88         [24] 2170 	lcall	_ak820_outline_0113
      0087CA 90 0B 2A         [24] 2171 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      0087CD 12 38 83         [24] 2172 	lcall	_ak820_outline_0112
                                   2173 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      0087D0 12 2B 2B         [24] 2174 	lcall	_ak820_macro_length
      0087D3 12 43 56         [24] 2175 	lcall	_ak820_outline_0131
      0087D6 90 0B 2A         [24] 2176 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      0087D9 12 38 59         [24] 2177 	lcall	_ak820_outline_0061
      0087DC 90 0B 25         [24] 2178 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      0087DF E0               [24] 2179 	movx	a,@dptr
      0087E0 F5 3A            [12] 2180 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      0087E2 A3               [24] 2181 	inc	dptr
      0087E3 E0               [24] 2182 	movx	a,@dptr
      0087E4 F5 3B            [12] 2183 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      0087E6 90 0B 27         [24] 2184 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      0087E9 12 38 77         [24] 2185 	lcall	_ak820_outline_0099
      0087EC A3               [24] 2186 	inc	dptr
      0087ED E0               [24] 2187 	movx	a,@dptr
      0087EE FB               [12] 2188 	mov	r3,a
      0087EF 90 0B 02         [24] 2189 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0087F2 12 46 DE         [24] 2190 	lcall	_ak820_outline_0060
      0087F5 90 0B 04         [24] 2191 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0087F8 12 38 5F         [24] 2192 	lcall	_ak820_outline_0071
      0087FB 90 0B 06         [24] 2193 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0087FE E5 3A            [12] 2194 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008800 F0               [24] 2195 	movx	@dptr,a
      008801 E5 3B            [12] 2196 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008803 A3               [24] 2197 	inc	dptr
      008804 F0               [24] 2198 	movx	@dptr,a
      008805 90 0B 08         [24] 2199 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008808 E8               [12] 2200 	mov	a,r0
      008809 F0               [24] 2201 	movx	@dptr,a
      00880A E9               [12] 2202 	mov	a,r1
      00880B A3               [24] 2203 	inc	dptr
      00880C 12 8B B8         [24] 2204 	lcall	_ak820_outline_0184
      00880F 90 08 00         [24] 2205 	mov	dptr,#0x0800
                                   2206 ;	quantum/dynamic_keymap.c:572: }
      008812 02 84 DA         [24] 2207 	ljmp	_ak820_dynamic_read_buffer
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2210 ;------------------------------------------------------------
                                   2211 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2212 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2213 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2214 ;------------------------------------------------------------
                                   2215 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2216 ;	-----------------------------------------
                                   2217 ;	 function dynamic_keymap_macro_set_buffer
                                   2218 ;	-----------------------------------------
      008815                       2219 _dynamic_keymap_macro_set_buffer:
      008815 12 38 88         [24] 2220 	lcall	_ak820_outline_0113
      008818 90 0B 31         [24] 2221 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      00881B 12 38 83         [24] 2222 	lcall	_ak820_outline_0112
                                   2223 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      00881E 90 0B 31         [24] 2224 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008821 12 38 42         [24] 2225 	lcall	_ak820_outline_0052
      008824 90 0B 2C         [24] 2226 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008827 12 38 59         [24] 2227 	lcall	_ak820_outline_0061
      00882A 90 0B 2E         [24] 2228 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00882D 12 4D 5A         [24] 2229 	lcall	_ak820_outline_0087
      008830 90 05 14         [24] 2230 	mov	dptr,#_ak820_macro_write_PARM_2
      008833 12 38 5F         [24] 2231 	lcall	_ak820_outline_0071
      008836 90 05 16         [24] 2232 	mov	dptr,#_ak820_macro_write_PARM_3
      008839 E9               [12] 2233 	mov	a,r1
      00883A 12 4D 6C         [24] 2234 	lcall	_ak820_outline_0151
      00883D 12 43 32         [24] 2235 	lcall	_ak820_outline_0076
                                   2236 ;	quantum/dynamic_keymap.c:577: }
      008840 02 2B 45         [24] 2237 	ljmp	_ak820_macro_write
                                   2238 ;------------------------------------------------------------
                                   2239 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2240 ;------------------------------------------------------------
                                   2241 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2242 ;	-----------------------------------------
                                   2243 ;	 function dynamic_keymap_macro_reset
                                   2244 ;	-----------------------------------------
      008843                       2245 _dynamic_keymap_macro_reset:
                                   2246 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2247 ;	quantum/dynamic_keymap.c:603: }
      008843 02 2E 64         [24] 2248 	ljmp	_ak820_macro_reset
                                   2249 ;------------------------------------------------------------
                                   2250 ;Allocation info for local variables in function 'decode_keycode'
                                   2251 ;------------------------------------------------------------
                                   2252 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2253 ;------------------------------------------------------------
                                   2254 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2255 ;	-----------------------------------------
                                   2256 ;	 function decode_keycode
                                   2257 ;	-----------------------------------------
      008846                       2258 _decode_keycode:
      008846 12 38 88         [24] 2259 	lcall	_ak820_outline_0113
      008849 90 0B 33         [24] 2260 	mov	dptr,#_decode_keycode_kc_10000_454
      00884C 12 38 83         [24] 2261 	lcall	_ak820_outline_0112
                                   2262 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      00884F 90 0B 33         [24] 2263 	mov	dptr,#_decode_keycode_kc_10000_454
      008852 12 46 89         [24] 2264 	lcall	_ak820_outline_0008
      008855 C3               [12] 2265 	clr	c
      008856 E4               [12] 2266 	clr	a
      008857 9C               [12] 2267 	subb	a,r4
      008858 74 FF            [12] 2268 	mov	a,#0xff
      00885A 9D               [12] 2269 	subb	a,r5
      00885B 50 08            [24] 2270 	jnc	00102$
                                   2271 ;	free result
                                   2272 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      00885D 8C 05            [24] 2273 	mov	ar5,r4
      00885F 7C 00            [12] 2274 	mov	r4,#0x00
      008861 12 38 92         [24] 2275 	lcall	_ak820_outline_0121
      008864 22               [24] 2276 	ret
      008865                       2277 00102$:
                                   2278 ;	quantum/dynamic_keymap.c:609: return kc;
      008865 12 38 8D         [24] 2279 	lcall	_ak820_outline_0114
                                   2280 ;	quantum/dynamic_keymap.c:610: }
      008868 22               [24] 2281 	ret
                                   2282 ;------------------------------------------------------------
                                   2283 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2284 ;------------------------------------------------------------
                                   2285 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2286 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2287 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2288 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2289 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2290 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2291 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2292 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2293 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2294 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2295 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2296 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2297 ;------------------------------------------------------------
                                   2298 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2299 ;	-----------------------------------------
                                   2300 ;	 function dynamic_keymap_macro_send
                                   2301 ;	-----------------------------------------
      008869                       2302 _dynamic_keymap_macro_send:
      008869 E5 82            [12] 2303 	mov	a,dpl
      00886B 90 0B 35         [24] 2304 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      00886E F0               [24] 2305 	movx	@dptr,a
                                   2306 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      00886F 90 0B 36         [24] 2307 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008872 E0               [24] 2308 	movx	a,@dptr
      008873 60 01            [24] 2309 	jz	00102$
      008875 22               [24] 2310 	ret
      008876                       2311 00102$:
                                   2312 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008876 90 0B 35         [24] 2313 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008879 E0               [24] 2314 	movx	a,@dptr
      00887A FF               [12] 2315 	mov	r7,a
      00887B BF 10 00         [24] 2316 	cjne	r7,#0x10,00422$
      00887E                       2317 00422$:
      00887E 40 01            [24] 2318 	jc	00104$
                                   2319 ;	quantum/dynamic_keymap.c:620: return;
      008880 22               [24] 2320 	ret
      008881                       2321 00104$:
                                   2322 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      008881 C0 07            [24] 2323 	push	ar7
      008883 12 2A F2         [24] 2324 	lcall	_ak820_macro_ready
      008886 E5 82            [12] 2325 	mov	a, dpl
      008888 D0 07            [24] 2326 	pop	ar7
      00888A 70 01            [24] 2327 	jnz	00106$
      00888C 22               [24] 2328 	ret
      00888D                       2329 00106$:
                                   2330 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      00888D 90 0B 37         [24] 2331 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008890 E4               [12] 2332 	clr	a
      008891 F0               [24] 2333 	movx	@dptr,a
      008892 74 08            [12] 2334 	mov	a,#0x08
      008894 A3               [24] 2335 	inc	dptr
      008895 F0               [24] 2336 	movx	@dptr,a
                                   2337 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008896 C0 07            [24] 2338 	push	ar7
      008898 12 2B 2B         [24] 2339 	lcall	_ak820_macro_length
      00889B AD 82            [24] 2340 	mov	r5, dpl
      00889D AE 83            [24] 2341 	mov	r6, dph
      00889F D0 07            [24] 2342 	pop	ar7
      0088A1 74 08            [12] 2343 	mov	a,#0x08
      0088A3 2E               [12] 2344 	add	a, r6
      0088A4 FE               [12] 2345 	mov	r6,a
                                   2346 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      0088A5 7B 00            [12] 2347 	mov	r3,#0x00
      0088A7 7C 08            [12] 2348 	mov	r4,#0x08
      0088A9                       2349 00111$:
      0088A9 EF               [12] 2350 	mov	a,r7
      0088AA 60 31            [24] 2351 	jz	00113$
                                   2352 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      0088AC EB               [12] 2353 	mov	a,r3
      0088AD B5 05 05         [24] 2354 	cjne	a,ar5,00108$
      0088B0 EC               [12] 2355 	mov	a,r4
      0088B1 B5 06 01         [24] 2356 	cjne	a,ar6,00108$
                                   2357 ;	quantum/dynamic_keymap.c:654: return;
      0088B4 22               [24] 2358 	ret
      0088B5                       2359 00108$:
                                   2360 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      0088B5 8B 01            [24] 2361 	mov	ar1,r3
      0088B7 8C 02            [24] 2362 	mov	ar2,r4
      0088B9 8A 00            [24] 2363 	mov	ar0,r2
      0088BB 7A 00            [12] 2364 	mov	r2,#0x00
      0088BD 89 82            [24] 2365 	mov	dpl, r1
      0088BF 88 83            [24] 2366 	mov	dph, r0
      0088C1 8A F0            [24] 2367 	mov	b, r2
      0088C3 12 40 6F         [24] 2368 	lcall	_eeprom_read_byte
      0088C6 E5 82            [12] 2369 	mov	a, dpl
      0088C8 70 06            [24] 2370 	jnz	00110$
                                   2371 ;	quantum/dynamic_keymap.c:657: --id;
      0088CA 1F               [12] 2372 	dec	r7
      0088CB 90 0B 35         [24] 2373 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      0088CE EF               [12] 2374 	mov	a,r7
      0088CF F0               [24] 2375 	movx	@dptr,a
      0088D0                       2376 00110$:
                                   2377 ;	quantum/dynamic_keymap.c:659: ++p;
      0088D0 0B               [12] 2378 	inc	r3
      0088D1 BB 00 01         [24] 2379 	cjne	r3,#0x00,00429$
      0088D4 0C               [12] 2380 	inc	r4
      0088D5                       2381 00429$:
      0088D5 90 0B 37         [24] 2382 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      0088D8 12 38 65         [24] 2383 	lcall	_ak820_outline_0081
      0088DB 80 CC            [24] 2384 	sjmp	00111$
      0088DD                       2385 00113$:
                                   2386 ;	quantum/dynamic_keymap.c:665: sending = true;
      0088DD 90 0B 36         [24] 2387 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      0088E0 74 01            [12] 2388 	mov	a,#0x01
      0088E2 F0               [24] 2389 	movx	@dptr,a
                                   2390 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      0088E3 12 8B 97         [24] 2391 	lcall	_ak820_outline_0161
      0088E6 90 09 7F         [24] 2392 	mov	dptr,#_ak820_macro_cancelled
      0088E9 F0               [24] 2393 	movx	@dptr,a
                                   2394 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      0088EA 90 0B 39         [24] 2395 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      0088ED F0               [24] 2396 	movx	@dptr,a
      0088EE 90 0B 3A         [24] 2397 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      0088F1 F0               [24] 2398 	movx	@dptr,a
      0088F2 90 0B 3B         [24] 2399 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      0088F5 F0               [24] 2400 	movx	@dptr,a
      0088F6 90 0B 3C         [24] 2401 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      0088F9 F0               [24] 2402 	movx	@dptr,a
                                   2403 ;	quantum/dynamic_keymap.c:675: while (p < end
      0088FA                       2404 00167$:
                                   2405 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      0088FA 90 0B 37         [24] 2406 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      0088FD E0               [24] 2407 	movx	a,@dptr
      0088FE FC               [12] 2408 	mov	r4,a
      0088FF A3               [24] 2409 	inc	dptr
      008900 E0               [24] 2410 	movx	a,@dptr
      008901 FF               [12] 2411 	mov	r7,a
      008902 C3               [12] 2412 	clr	c
      008903 EC               [12] 2413 	mov	a,r4
      008904 9D               [12] 2414 	subb	a,r5
      008905 EF               [12] 2415 	mov	a,r7
      008906 9E               [12] 2416 	subb	a,r6
      008907 40 03            [24] 2417 	jc	00430$
      008909 02 8B 1E         [24] 2418 	ljmp	00169$
      00890C                       2419 00430$:
      00890C 90 09 7F         [24] 2420 	mov	dptr,#_ak820_macro_cancelled
      00890F E0               [24] 2421 	movx	a,@dptr
      008910 60 03            [24] 2422 	jz	00431$
      008912 02 8B 1E         [24] 2423 	ljmp	00169$
      008915                       2424 00431$:
                                   2425 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008915 8C 02            [24] 2426 	mov	ar2,r4
      008917 8F 03            [24] 2427 	mov	ar3,r7
      008919 90 0B 37         [24] 2428 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      00891C 74 01            [12] 2429 	mov	a,#0x01
      00891E 2C               [12] 2430 	add	a, r4
      00891F F0               [24] 2431 	movx	@dptr,a
      008920 E4               [12] 2432 	clr	a
      008921 3F               [12] 2433 	addc	a, r7
      008922 A3               [24] 2434 	inc	dptr
      008923 F0               [24] 2435 	movx	@dptr,a
      008924 7F 00            [12] 2436 	mov	r7,#0x00
      008926 12 38 A7         [24] 2437 	lcall	_ak820_outline_0139
      008929 8F F0            [24] 2438 	mov	b, r7
      00892B 12 40 6F         [24] 2439 	lcall	_eeprom_read_byte
      00892E AF 82            [24] 2440 	mov	r7, dpl
      008930 90 0B 39         [24] 2441 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008933 EF               [12] 2442 	mov	a,r7
      008934 F0               [24] 2443 	movx	@dptr,a
                                   2444 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      008935 90 0B 3A         [24] 2445 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008938 E4               [12] 2446 	clr	a
      008939 F0               [24] 2447 	movx	@dptr,a
                                   2448 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      00893A 90 0B 39         [24] 2449 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      00893D E0               [24] 2450 	movx	a,@dptr
      00893E 70 03            [24] 2451 	jnz	00432$
      008940 02 8B 1E         [24] 2452 	ljmp	00169$
      008943                       2453 00432$:
                                   2454 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      008943 90 0B 39         [24] 2455 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008946 E0               [24] 2456 	movx	a,@dptr
      008947 FF               [12] 2457 	mov	r7,a
      008948 BF 01 02         [24] 2458 	cjne	r7,#0x01,00433$
      00894B 80 03            [24] 2459 	sjmp	00434$
      00894D                       2460 00433$:
      00894D 02 8B 00         [24] 2461 	ljmp	00164$
      008950                       2462 00434$:
                                   2463 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008950 12 8B 26         [24] 2464 	lcall	_ak820_outline_0000
      008953 12 40 6F         [24] 2465 	lcall	_eeprom_read_byte
      008956 AF 82            [24] 2466 	mov	r7, dpl
      008958 90 0B 3A         [24] 2467 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      00895B EF               [12] 2468 	mov	a,r7
      00895C F0               [24] 2469 	movx	@dptr,a
                                   2470 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      00895D EF               [12] 2471 	mov	a,r7
      00895E 70 03            [24] 2472 	jnz	00435$
      008960 02 8B 1E         [24] 2473 	ljmp	00169$
      008963                       2474 00435$:
                                   2475 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008963 12 8B 5E         [24] 2476 	lcall	_ak820_outline_0091
      008966 BF 01 02         [24] 2477 	cjne	r7,#0x01,00436$
      008969 80 13            [24] 2478 	sjmp	00151$
      00896B                       2479 00436$:
      00896B 12 8B 5E         [24] 2480 	lcall	_ak820_outline_0091
      00896E BF 02 02         [24] 2481 	cjne	r7,#0x02,00437$
      008971 80 0B            [24] 2482 	sjmp	00151$
      008973                       2483 00437$:
      008973 12 8B 5E         [24] 2484 	lcall	_ak820_outline_0091
      008976 BF 03 02         [24] 2485 	cjne	r7,#0x03,00438$
      008979 80 03            [24] 2486 	sjmp	00439$
      00897B                       2487 00438$:
      00897B 02 89 DF         [24] 2488 	ljmp	00152$
      00897E                       2489 00439$:
      00897E                       2490 00151$:
                                   2491 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00897E 12 8B 26         [24] 2492 	lcall	_ak820_outline_0000
      008981 12 40 6F         [24] 2493 	lcall	_eeprom_read_byte
      008984 12 8B AF         [24] 2494 	lcall	_ak820_outline_0178
                                   2495 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      008987 70 03            [24] 2496 	jnz	00440$
      008989 02 88 FA         [24] 2497 	ljmp	00167$
      00898C                       2498 00440$:
                                   2499 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      00898C 12 8B 5E         [24] 2500 	lcall	_ak820_outline_0091
      00898F BF 01 03         [24] 2501 	cjne	r7,#0x01,00441$
      008992 D3               [12] 2502 	setb	c
      008993 80 01            [24] 2503 	sjmp	00442$
      008995                       2504 00441$:
      008995 C3               [12] 2505 	clr	c
      008996                       2506 00442$:
      008996 92 24            [24] 2507 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008998 90 09 7E         [24] 2508 	mov	dptr,#_ak820_macro_primitive
      00899B B3               [12] 2509 	cpl	c
      00899C E4               [12] 2510 	clr	a
      00899D 33               [12] 2511 	rlc	a
      00899E F0               [24] 2512 	movx	@dptr,a
                                   2513 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      00899F 12 8B 5E         [24] 2514 	lcall	_ak820_outline_0091
      0089A2 BF 01 10         [24] 2515 	cjne	r7,#0x01,00122$
      0089A5 12 8B 90         [24] 2516 	lcall	_ak820_outline_0147
      0089A8 C0 06            [24] 2517 	push	ar6
      0089AA C0 05            [24] 2518 	push	ar5
      0089AC 12 73 69         [24] 2519 	lcall	_tap_code
      0089AF D0 05            [24] 2520 	pop	ar5
      0089B1 D0 06            [24] 2521 	pop	ar6
      0089B3 80 24            [24] 2522 	sjmp	00123$
      0089B5                       2523 00122$:
                                   2524 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0089B5 12 8B 5E         [24] 2525 	lcall	_ak820_outline_0091
      0089B8 BF 02 10         [24] 2526 	cjne	r7,#0x02,00119$
      0089BB 12 8B 90         [24] 2527 	lcall	_ak820_outline_0147
      0089BE C0 06            [24] 2528 	push	ar6
      0089C0 C0 05            [24] 2529 	push	ar5
      0089C2 12 72 63         [24] 2530 	lcall	_register_code
      0089C5 D0 05            [24] 2531 	pop	ar5
      0089C7 D0 06            [24] 2532 	pop	ar6
      0089C9 80 0E            [24] 2533 	sjmp	00123$
      0089CB                       2534 00119$:
                                   2535 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      0089CB 12 8B 90         [24] 2536 	lcall	_ak820_outline_0147
      0089CE C0 06            [24] 2537 	push	ar6
      0089D0 C0 05            [24] 2538 	push	ar5
      0089D2 12 72 D0         [24] 2539 	lcall	_unregister_code
      0089D5 D0 05            [24] 2540 	pop	ar5
      0089D7 D0 06            [24] 2541 	pop	ar6
      0089D9                       2542 00123$:
                                   2543 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      0089D9 12 8B 97         [24] 2544 	lcall	_ak820_outline_0161
      0089DC 02 88 FA         [24] 2545 	ljmp	00167$
      0089DF                       2546 00152$:
                                   2547 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0089DF 12 8B 5E         [24] 2548 	lcall	_ak820_outline_0091
      0089E2 BF 05 02         [24] 2549 	cjne	r7,#0x05,00447$
      0089E5 80 13            [24] 2550 	sjmp	00146$
      0089E7                       2551 00447$:
      0089E7 12 8B 5E         [24] 2552 	lcall	_ak820_outline_0091
      0089EA BF 06 02         [24] 2553 	cjne	r7,#0x06,00448$
      0089ED 80 0B            [24] 2554 	sjmp	00146$
      0089EF                       2555 00448$:
      0089EF 12 8B 5E         [24] 2556 	lcall	_ak820_outline_0091
      0089F2 BF 07 02         [24] 2557 	cjne	r7,#0x07,00449$
      0089F5 80 03            [24] 2558 	sjmp	00450$
      0089F7                       2559 00449$:
      0089F7 02 8A A0         [24] 2560 	ljmp	00147$
      0089FA                       2561 00450$:
      0089FA                       2562 00146$:
                                   2563 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0089FA 12 8B 26         [24] 2564 	lcall	_ak820_outline_0000
      0089FD 12 40 6F         [24] 2565 	lcall	_eeprom_read_byte
      008A00 12 8B AF         [24] 2566 	lcall	_ak820_outline_0178
                                   2567 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      008A03 70 03            [24] 2568 	jnz	00451$
      008A05 02 88 FA         [24] 2569 	ljmp	00167$
      008A08                       2570 00451$:
                                   2571 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008A08 12 8B 26         [24] 2572 	lcall	_ak820_outline_0000
      008A0B 12 40 6F         [24] 2573 	lcall	_eeprom_read_byte
      008A0E AF 82            [24] 2574 	mov	r7, dpl
      008A10 90 0B 3C         [24] 2575 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008A13 EF               [12] 2576 	mov	a,r7
      008A14 F0               [24] 2577 	movx	@dptr,a
                                   2578 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      008A15 EF               [12] 2579 	mov	a,r7
      008A16 70 03            [24] 2580 	jnz	00452$
      008A18 02 88 FA         [24] 2581 	ljmp	00167$
      008A1B                       2582 00452$:
                                   2583 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008A1B 90 0B 3B         [24] 2584 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008A1E E0               [24] 2585 	movx	a,@dptr
      008A1F FF               [12] 2586 	mov	r7,a
      008A20 90 0B 3C         [24] 2587 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008A23 E0               [24] 2588 	movx	a,@dptr
      008A24 FB               [12] 2589 	mov	r3,a
      008A25 E4               [12] 2590 	clr	a
      008A26 FC               [12] 2591 	mov	r4,a
      008A27 FA               [12] 2592 	mov	r2,a
      008A28 EF               [12] 2593 	mov	a,r7
      008A29 42 04            [12] 2594 	orl	ar4,a
      008A2B EA               [12] 2595 	mov	a,r2
      008A2C 42 03            [12] 2596 	orl	ar3,a
                                   2597 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      008A2E 12 43 82         [24] 2598 	lcall	_ak820_outline_0179
      008A31 C0 06            [24] 2599 	push	ar6
      008A33 C0 05            [24] 2600 	push	ar5
      008A35 12 88 46         [24] 2601 	lcall	_decode_keycode
      008A38 AC 82            [24] 2602 	mov	r4, dpl
      008A3A AF 83            [24] 2603 	mov	r7, dph
      008A3C D0 05            [24] 2604 	pop	ar5
      008A3E D0 06            [24] 2605 	pop	ar6
                                   2606 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008A40 90 0B 3A         [24] 2607 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008A43 E0               [24] 2608 	movx	a,@dptr
      008A44 FB               [12] 2609 	mov	r3,a
      008A45 BB 05 03         [24] 2610 	cjne	r3,#0x05,00453$
      008A48 D3               [12] 2611 	setb	c
      008A49 80 01            [24] 2612 	sjmp	00454$
      008A4B                       2613 00453$:
      008A4B C3               [12] 2614 	clr	c
      008A4C                       2615 00454$:
      008A4C 92 24            [24] 2616 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008A4E 90 09 7E         [24] 2617 	mov	dptr,#_ak820_macro_primitive
      008A51 B3               [12] 2618 	cpl	c
      008A52 E4               [12] 2619 	clr	a
      008A53 33               [12] 2620 	rlc	a
      008A54 F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      008A55 90 0B 3A         [24] 2623 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008A58 E0               [24] 2624 	movx	a,@dptr
      008A59 FB               [12] 2625 	mov	r3,a
      008A5A BB 05 02         [24] 2626 	cjne	r3,#0x05,00455$
      008A5D 80 0A            [24] 2627 	sjmp	00126$
      008A5F                       2628 00455$:
      008A5F BB 06 02         [24] 2629 	cjne	r3,#0x06,00456$
      008A62 80 16            [24] 2630 	sjmp	00127$
      008A64                       2631 00456$:
                                   2632 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      008A64 BB 07 33         [24] 2633 	cjne	r3,#0x07,00129$
      008A67 80 22            [24] 2634 	sjmp	00128$
      008A69                       2635 00126$:
                                   2636 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      008A69 8C 82            [24] 2637 	mov	dpl, r4
      008A6B 8F 83            [24] 2638 	mov	dph, r7
      008A6D C0 06            [24] 2639 	push	ar6
      008A6F C0 05            [24] 2640 	push	ar5
      008A71 12 AE 9E         [24] 2641 	lcall	_vial_keycode_tap
      008A74 D0 05            [24] 2642 	pop	ar5
      008A76 D0 06            [24] 2643 	pop	ar6
                                   2644 ;	quantum/dynamic_keymap.c:732: break;
                                   2645 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      008A78 80 20            [24] 2646 	sjmp	00129$
      008A7A                       2647 00127$:
                                   2648 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      008A7A 8C 82            [24] 2649 	mov	dpl, r4
      008A7C 8F 83            [24] 2650 	mov	dph, r7
      008A7E C0 06            [24] 2651 	push	ar6
      008A80 C0 05            [24] 2652 	push	ar5
      008A82 12 AD D3         [24] 2653 	lcall	_vial_keycode_down
      008A85 D0 05            [24] 2654 	pop	ar5
      008A87 D0 06            [24] 2655 	pop	ar6
                                   2656 ;	quantum/dynamic_keymap.c:735: break;
                                   2657 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      008A89 80 0F            [24] 2658 	sjmp	00129$
      008A8B                       2659 00128$:
                                   2660 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      008A8B 8C 82            [24] 2661 	mov	dpl, r4
      008A8D 8F 83            [24] 2662 	mov	dph, r7
      008A8F C0 06            [24] 2663 	push	ar6
      008A91 C0 05            [24] 2664 	push	ar5
      008A93 12 AE 39         [24] 2665 	lcall	_vial_keycode_up
      008A96 D0 05            [24] 2666 	pop	ar5
      008A98 D0 06            [24] 2667 	pop	ar6
                                   2668 ;	quantum/dynamic_keymap.c:739: }
      008A9A                       2669 00129$:
                                   2670 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      008A9A 12 8B 97         [24] 2671 	lcall	_ak820_outline_0161
      008A9D 02 88 FA         [24] 2672 	ljmp	00167$
      008AA0                       2673 00147$:
                                   2674 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      008AA0 12 8B 5E         [24] 2675 	lcall	_ak820_outline_0091
      008AA3 BF 04 02         [24] 2676 	cjne	r7,#0x04,00458$
      008AA6 80 03            [24] 2677 	sjmp	00459$
      008AA8                       2678 00458$:
      008AA8 02 88 FA         [24] 2679 	ljmp	00167$
      008AAB                       2680 00459$:
                                   2681 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008AAB 12 8B 26         [24] 2682 	lcall	_ak820_outline_0000
      008AAE 12 40 6F         [24] 2683 	lcall	_eeprom_read_byte
      008AB1 AF 82            [24] 2684 	mov	r7, dpl
                                   2685 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008AB3 90 0B 37         [24] 2686 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008AB6 12 38 7D         [24] 2687 	lcall	_ak820_outline_0101
      008AB9 90 0B 37         [24] 2688 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008ABC 74 01            [12] 2689 	mov	a,#0x01
      008ABE 2B               [12] 2690 	add	a, r3
      008ABF F0               [24] 2691 	movx	@dptr,a
      008AC0 E4               [12] 2692 	clr	a
      008AC1 3C               [12] 2693 	addc	a, r4
      008AC2 A3               [24] 2694 	inc	dptr
      008AC3 F0               [24] 2695 	movx	@dptr,a
      008AC4 7A 00            [12] 2696 	mov	r2,#0x00
      008AC6 12 33 FC         [24] 2697 	lcall	_ak820_outline_0120
      008AC9 8A F0            [24] 2698 	mov	b, r2
      008ACB 12 40 6F         [24] 2699 	lcall	_eeprom_read_byte
      008ACE AC 82            [24] 2700 	mov	r4, dpl
                                   2701 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      008AD0 EF               [12] 2702 	mov	a,r7
      008AD1 60 4B            [24] 2703 	jz	00169$
      008AD3 EC               [12] 2704 	mov	a,r4
      008AD4 60 48            [24] 2705 	jz	00169$
                                   2706 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008AD6 1F               [12] 2707 	dec	r7
      008AD7 1C               [12] 2708 	dec	r4
      008AD8 EC               [12] 2709 	mov	a,r4
      008AD9 75 F0 FF         [24] 2710 	mov	b,#0xff
      008ADC A4               [48] 2711 	mul	ab
      008ADD FC               [12] 2712 	mov	r4,a
      008ADE AB F0            [24] 2713 	mov	r3,b
      008AE0 7A 00            [12] 2714 	mov	r2,#0x00
      008AE2 EC               [12] 2715 	mov	a,r4
      008AE3 2F               [12] 2716 	add	a, r7
      008AE4 FC               [12] 2717 	mov	r4,a
      008AE5 EB               [12] 2718 	mov	a,r3
      008AE6 3A               [12] 2719 	addc	a, r2
      008AE7 FB               [12] 2720 	mov	r3,a
                                   2721 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      008AE8                       2722 00141$:
      008AE8 8C 02            [24] 2723 	mov	ar2,r4
      008AEA 8B 07            [24] 2724 	mov	ar7,r3
      008AEC 1C               [12] 2725 	dec	r4
      008AED BC FF 01         [24] 2726 	cjne	r4,#0xff,00462$
      008AF0 1B               [12] 2727 	dec	r3
      008AF1                       2728 00462$:
      008AF1 EA               [12] 2729 	mov	a,r2
      008AF2 4F               [12] 2730 	orl	a,r7
      008AF3 70 03            [24] 2731 	jnz	00463$
      008AF5 02 88 FA         [24] 2732 	ljmp	00167$
      008AF8                       2733 00463$:
      008AF8 90 00 01         [24] 2734 	mov	dptr,#0x0001
      008AFB 12 56 F5         [24] 2735 	lcall	_mDelaymS
      008AFE 80 E8            [24] 2736 	sjmp	00141$
      008B00                       2737 00164$:
                                   2738 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      008B00 90 0B 39         [24] 2739 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008B03 E0               [24] 2740 	movx	a,@dptr
      008B04 FF               [12] 2741 	mov	r7,a
      008B05 BF 80 00         [24] 2742 	cjne	r7,#0x80,00464$
      008B08                       2743 00464$:
      008B08 50 14            [24] 2744 	jnc	00169$
                                   2745 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      008B0A 90 0B 39         [24] 2746 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008B0D E0               [24] 2747 	movx	a,@dptr
      008B0E F5 82            [12] 2748 	mov	dpl,a
      008B10 C0 06            [24] 2749 	push	ar6
      008B12 C0 05            [24] 2750 	push	ar5
      008B14 12 A1 3C         [24] 2751 	lcall	_send_char
      008B17 D0 05            [24] 2752 	pop	ar5
      008B19 D0 06            [24] 2753 	pop	ar6
                                   2754 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008B1B 02 88 FA         [24] 2755 	ljmp	00167$
      008B1E                       2756 00169$:
                                   2757 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      008B1E 12 8B 97         [24] 2758 	lcall	_ak820_outline_0161
                                   2759 ;	quantum/dynamic_keymap.c:774: sending = false;
      008B21 90 0B 36         [24] 2760 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008B24 F0               [24] 2761 	movx	@dptr,a
                                   2762 ;	quantum/dynamic_keymap.c:776: }
      008B25 22               [24] 2763 	ret
                                   2764 	.area CSEG    (CODE)
                                   2765 	.area CONST   (CODE)
                                   2766 	.area XINIT   (CODE)
                                   2767 	.area CABS    (ABS,CODE)
                                   2768 
                                   2769 ; Experimental exact instruction outlining.
                                   2770 	.globl _ak820_outline_0000
                                   2771 	.globl _ak820_outline_0005
                                   2772 	.globl _ak820_outline_0008
                                   2773 	.globl _ak820_outline_0021
                                   2774 	.globl _ak820_outline_0025
                                   2775 	.globl _ak820_outline_0031
                                   2776 	.globl _ak820_outline_0038
                                   2777 	.globl _ak820_outline_0046
                                   2778 	.globl _ak820_outline_0050
                                   2779 	.globl _ak820_outline_0052
                                   2780 	.globl _ak820_outline_0058
                                   2781 	.globl _ak820_outline_0060
                                   2782 	.globl _ak820_outline_0061
                                   2783 	.globl _ak820_outline_0071
                                   2784 	.globl _ak820_outline_0076
                                   2785 	.globl _ak820_outline_0077
                                   2786 	.globl _ak820_outline_0081
                                   2787 	.globl _ak820_outline_0087
                                   2788 	.globl _ak820_outline_0089
                                   2789 	.globl _ak820_outline_0091
                                   2790 	.globl _ak820_outline_0096
                                   2791 	.globl _ak820_outline_0099
                                   2792 	.globl _ak820_outline_0100
                                   2793 	.globl _ak820_outline_0101
                                   2794 	.globl _ak820_outline_0106
                                   2795 	.globl _ak820_outline_0110
                                   2796 	.globl _ak820_outline_0112
                                   2797 	.globl _ak820_outline_0113
                                   2798 	.globl _ak820_outline_0114
                                   2799 	.globl _ak820_outline_0118
                                   2800 	.globl _ak820_outline_0120
                                   2801 	.globl _ak820_outline_0121
                                   2802 	.globl _ak820_outline_0122
                                   2803 	.globl _ak820_outline_0126
                                   2804 	.globl _ak820_outline_0130
                                   2805 	.globl _ak820_outline_0131
                                   2806 	.globl _ak820_outline_0132
                                   2807 	.globl _ak820_outline_0133
                                   2808 	.globl _ak820_outline_0138
                                   2809 	.globl _ak820_outline_0139
                                   2810 	.globl _ak820_outline_0143
                                   2811 	.globl _ak820_outline_0144
                                   2812 	.globl _ak820_outline_0147
                                   2813 	.globl _ak820_outline_0151
                                   2814 	.globl _ak820_outline_0153
                                   2815 	.globl _ak820_outline_0156
                                   2816 	.globl _ak820_outline_0161
                                   2817 	.globl _ak820_outline_0166
                                   2818 	.globl _ak820_outline_0174
                                   2819 	.globl _ak820_outline_0175
                                   2820 	.globl _ak820_outline_0178
                                   2821 	.globl _ak820_outline_0179
                                   2822 	.globl _ak820_outline_0184
                                   2823 
                                   2824 	.area CSEG (CODE)
                                   2825 ; function ak820_outline_0000
      008B26                       2826 _ak820_outline_0000:
      008B26 90 0B 37         [24] 2827 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008B29 E0               [24] 2828 	movx	a,@dptr
      008B2A FC               [12] 2829 	mov	r4,a
      008B2B A3               [24] 2830 	inc	dptr
      008B2C E0               [24] 2831 	movx	a,@dptr
      008B2D FF               [12] 2832 	mov	r7,a
      008B2E 90 0B 37         [24] 2833 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008B31 74 01            [12] 2834 	mov	a,#0x01
      008B33 2C               [12] 2835 	add	a,r4
      008B34 F0               [24] 2836 	movx	@dptr,a
      008B35 E4               [12] 2837 	clr	a
      008B36 3F               [12] 2838 	addc	a,r7
      008B37 A3               [24] 2839 	inc	dptr
      008B38 F0               [24] 2840 	movx	@dptr,a
      008B39 7B 00            [12] 2841 	mov	r3,#0x00
      008B3B 8C 82            [24] 2842 	mov	dpl,r4
      008B3D 8F 83            [24] 2843 	mov	dph,r7
      008B3F 8B F0            [24] 2844 	mov	b,r3
      008B41 22               [24] 2845 	ret
                                   2846 
                                   2847 	.area CSEG (CODE)
                                   2848 ; function ak820_outline_0025
      008B42                       2849 _ak820_outline_0025:
      008B42 2D               [12] 2850 	add	a,r5
      008B43 F9               [12] 2851 	mov	r1,a
      008B44 E4               [12] 2852 	clr	a
      008B45 3E               [12] 2853 	addc	a,r6
      008B46 FA               [12] 2854 	mov	r2,a
      008B47 8F 03            [24] 2855 	mov	ar3,r7
      008B49 89 82            [24] 2856 	mov	dpl,r1
      008B4B 8A 83            [24] 2857 	mov	dph,r2
      008B4D 8B F0            [24] 2858 	mov	b,r3
      008B4F 22               [24] 2859 	ret
                                   2860 
                                   2861 	.area CSEG (CODE)
                                   2862 ; function ak820_outline_0077
      008B50                       2863 _ak820_outline_0077:
      008B50 ED               [12] 2864 	mov	a,r5
      008B51 75 F0 0A         [24] 2865 	mov	b,#0x0a
      008B54 A4               [48] 2866 	mul	ab
      008B55 24 58            [12] 2867 	add	a,#0x58
      008B57 FC               [12] 2868 	mov	r4,a
      008B58 74 06            [12] 2869 	mov	a,#0x06
      008B5A 35 F0            [12] 2870 	addc	a,b
      008B5C FD               [12] 2871 	mov	r5,a
      008B5D 22               [24] 2872 	ret
                                   2873 
                                   2874 	.area CSEG (CODE)
                                   2875 ; function ak820_outline_0091
      008B5E                       2876 _ak820_outline_0091:
      008B5E 90 0B 3A         [24] 2877 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      008B61 E0               [24] 2878 	movx	a,@dptr
      008B62 FF               [12] 2879 	mov	r7,a
      008B63 22               [24] 2880 	ret
                                   2881 
                                   2882 	.area CSEG (CODE)
                                   2883 ; function ak820_outline_0096
      008B64                       2884 _ak820_outline_0096:
      008B64 90 0A D0         [24] 2885 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008B67 EE               [12] 2886 	mov	a,r6
      008B68 F0               [24] 2887 	movx	@dptr,a
      008B69 90 0A D1         [24] 2888 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008B6C ED               [12] 2889 	mov	a,r5
      008B6D F0               [24] 2890 	movx	@dptr,a
      008B6E 8F 82            [24] 2891 	mov	dpl,r7
      008B70 22               [24] 2892 	ret
                                   2893 
                                   2894 	.area CSEG (CODE)
                                   2895 ; function ak820_outline_0106
      008B71                       2896 _ak820_outline_0106:
      008B71 74 0A            [12] 2897 	mov	a,#0x0a
      008B73 F0               [24] 2898 	movx	@dptr,a
      008B74 E4               [12] 2899 	clr	a
      008B75 A3               [24] 2900 	inc	dptr
      008B76 F0               [24] 2901 	movx	@dptr,a
      008B77 22               [24] 2902 	ret
                                   2903 
                                   2904 	.area CSEG (CODE)
                                   2905 ; function ak820_outline_0110
      008B78                       2906 _ak820_outline_0110:
      008B78 AD 82            [24] 2907 	mov	r5,dpl
      008B7A AE 83            [24] 2908 	mov	r6,dph
      008B7C AF F0            [24] 2909 	mov	r7,b
      008B7E 22               [24] 2910 	ret
                                   2911 
                                   2912 	.area CSEG (CODE)
                                   2913 ; function ak820_outline_0126
      008B7F                       2914 _ak820_outline_0126:
      008B7F 28               [12] 2915 	add	a,r0
      008B80 F5 82            [12] 2916 	mov	dpl,a
      008B82 EF               [12] 2917 	mov	a,r7
      008B83 39               [12] 2918 	addc	a,r1
      008B84 F5 83            [12] 2919 	mov	dph,a
      008B86 74 FF            [12] 2920 	mov	a,#0xff
      008B88 F0               [24] 2921 	movx	@dptr,a
      008B89 22               [24] 2922 	ret
                                   2923 
                                   2924 	.area CSEG (CODE)
                                   2925 ; function ak820_outline_0132
      008B8A                       2926 _ak820_outline_0132:
      008B8A 2D               [12] 2927 	add	a,r5
      008B8B F9               [12] 2928 	mov	r1,a
      008B8C E4               [12] 2929 	clr	a
      008B8D 3E               [12] 2930 	addc	a,r6
      008B8E FA               [12] 2931 	mov	r2,a
      008B8F 22               [24] 2932 	ret
                                   2933 
                                   2934 	.area CSEG (CODE)
                                   2935 ; function ak820_outline_0147
      008B90                       2936 _ak820_outline_0147:
      008B90 90 0B 3B         [24] 2937 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008B93 E0               [24] 2938 	movx	a,@dptr
      008B94 F5 82            [12] 2939 	mov	dpl,a
      008B96 22               [24] 2940 	ret
                                   2941 
                                   2942 	.area CSEG (CODE)
                                   2943 ; function ak820_outline_0161
      008B97                       2944 _ak820_outline_0161:
      008B97 90 09 7E         [24] 2945 	mov	dptr,#_ak820_macro_primitive
      008B9A E4               [12] 2946 	clr	a
      008B9B F0               [24] 2947 	movx	@dptr,a
      008B9C 22               [24] 2948 	ret
                                   2949 
                                   2950 	.area CSEG (CODE)
                                   2951 ; function ak820_outline_0174
      008B9D                       2952 _ak820_outline_0174:
      008B9D 90 0A E0         [24] 2953 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008BA0 E4               [12] 2954 	clr	a
      008BA1 F0               [24] 2955 	movx	@dptr,a
      008BA2 90 0A E1         [24] 2956 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008BA5 22               [24] 2957 	ret
                                   2958 
                                   2959 	.area CSEG (CODE)
                                   2960 ; function ak820_outline_0175
      008BA6                       2961 _ak820_outline_0175:
      008BA6 90 0B 96         [24] 2962 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008BA9 E4               [12] 2963 	clr	a
      008BAA F0               [24] 2964 	movx	@dptr,a
      008BAB 90 0B 97         [24] 2965 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008BAE 22               [24] 2966 	ret
                                   2967 
                                   2968 	.area CSEG (CODE)
                                   2969 ; function ak820_outline_0178
      008BAF                       2970 _ak820_outline_0178:
      008BAF AF 82            [24] 2971 	mov	r7,dpl
      008BB1 90 0B 3B         [24] 2972 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008BB4 EF               [12] 2973 	mov	a,r7
      008BB5 F0               [24] 2974 	movx	@dptr,a
      008BB6 EF               [12] 2975 	mov	a,r7
      008BB7 22               [24] 2976 	ret
                                   2977 
                                   2978 	.area CSEG (CODE)
                                   2979 ; function ak820_outline_0184
      008BB8                       2980 _ak820_outline_0184:
      008BB8 F0               [24] 2981 	movx	@dptr,a
      008BB9 EB               [12] 2982 	mov	a,r3
      008BBA A3               [24] 2983 	inc	dptr
      008BBB F0               [24] 2984 	movx	@dptr,a
      008BBC 22               [24] 2985 	ret
