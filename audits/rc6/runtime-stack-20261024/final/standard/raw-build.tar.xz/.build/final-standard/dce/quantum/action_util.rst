                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000058                        551 _change_owned_sloc1_1_0:
      000058                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      00096A                        580 _owned_mod_refs:
      00096A                        581 	.ds 8
      000972                        582 _owned_weak_refs:
      000972                        583 	.ds 8
      00097A                        584 _owned_mods:
      00097A                        585 	.ds 1
      00097B                        586 _owned_weak_mods:
      00097B                        587 	.ds 1
      00097C                        588 _macro_mods:
      00097C                        589 	.ds 2
      00097E                        590 _ak820_macro_primitive::
      00097E                        591 	.ds 1
      00097F                        592 _ak820_macro_cancelled::
      00097F                        593 	.ds 1
      000980                        594 _ak820_macro_change_PARM_2:
      000980                        595 	.ds 1
      000981                        596 _ak820_macro_change_PARM_3:
      000981                        597 	.ds 1
      000982                        598 _ak820_macro_change_bits_10000_293:
      000982                        599 	.ds 2
      000984                        600 _change_owned_PARM_2:
      000984                        601 	.ds 1
      000985                        602 _change_owned_mods_10000_298:
      000985                        603 	.ds 1
      000986                        604 _change_owned_result_10001_302:
      000986                        605 	.ds 1
      000987                        606 _change_owned_bit_20001_303:
      000987                        607 	.ds 1
      000988                        608 _add_owned_mods_mods_10000_311:
      000988                        609 	.ds 1
      000989                        610 _del_owned_mods_mods_10000_313:
      000989                        611 	.ds 1
      00098A                        612 _add_owned_weak_mods_mods_10000_315:
      00098A                        613 	.ds 1
      00098B                        614 _del_owned_weak_mods_mods_10000_317:
      00098B                        615 	.ds 1
      00098C                        616 _key_refs:
      00098C                        617 	.ds 165
      000A31                        618 _distinct_keys:
      000A31                        619 	.ds 1
      000A32                        620 _macro_keys:
      000A32                        621 	.ds 21
      000A47                        622 _add_owned_key_code_10000_326:
      000A47                        623 	.ds 1
      000A48                        624 _del_owned_key_code_10000_341:
      000A48                        625 	.ds 1
      000A49                        626 _usage_refs:
      000A49                        627 	.ds 30
      000A67                        628 _usage_order:
      000A67                        629 	.ds 30
      000A85                        630 _usage_lengths:
      000A85                        631 	.ds 2
      000A87                        632 _macro_usages:
      000A87                        633 	.ds 4
      000A8B                        634 _owned_usage_key_PARM_2:
      000A8B                        635 	.ds 1
      000A8C                        636 _owned_usage_key_code_10000_368:
      000A8C                        637 	.ds 1
      000A8D                        638 _owned_usage_key___200000085_20000_369:
      000A8D                        639 	.ds 2
      000A8F                        640 _owned_usage_key_which_10000_369:
      000A8F                        641 	.ds 1
      000A90                        642 _owned_usage_key_count_10000_369:
      000A90                        643 	.ds 1
      000A91                        644 _owned_usage_key_pos_30001_376:
      000A91                        645 	.ds 1
      000A92                        646 _owned_usage_key_key_40000_381:
      000A92                        647 	.ds 1
      000A93                        648 _send_keyboard_report_last_report_10001_388:
      000A93                        649 	.ds 32
      000AB3                        650 _send_keyboard_report_changed_10001_388:
      000AB3                        651 	.ds 1
      000AB4                        652 _add_weak_mods_mods_10000_406:
      000AB4                        653 	.ds 1
      000AB5                        654 _del_weak_mods_mods_10000_408:
      000AB5                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DB5                        664 _real_mods:
      000DB5                        665 	.ds 1
      000DB6                        666 _weak_mods:
      000DB6                        667 	.ds 1
      000DB7                        668 _actual_keyboard_report::
      000DB7                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      0078A0                        713 _ak820_macro_change:
      0078A0 12 38 88         [24]  714 	lcall	_ak820_outline_0113
      0078A3 90 09 82         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078A6 12 38 83         [24]  716 	lcall	_ak820_outline_0112
                                    717 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      0078A9 90 09 7E         [24]  718 	mov	dptr,#_ak820_macro_primitive
      0078AC E0               [24]  719 	movx	a,@dptr
      0078AD 70 04            [24]  720 	jnz	00102$
      0078AF 75 82 01         [24]  721 	mov	dpl, #0x01
      0078B2 22               [24]  722 	ret
      0078B3                        723 00102$:
                                    724 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      0078B3 90 09 80         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      0078B6 E0               [24]  726 	movx	a,@dptr
      0078B7 FF               [12]  727 	mov	r7,a
      0078B8 74 07            [12]  728 	mov	a,#0x07
      0078BA 5F               [12]  729 	anl	a,r7
      0078BB 12 74 41         [24]  730 	lcall	_ak820_outline_0063
      0078BE 80 02            [24]  731 	sjmp	00123$
      0078C0                        732 00122$:
      0078C0 25 E0            [12]  733 	add	a,acc
      0078C2                        734 00123$:
      0078C2 D5 F0 FB         [24]  735 	djnz	b,00122$
      0078C5 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:81: bits += index >> 3;
      0078C6 EF               [12]  738 	mov	a,r7
      0078C7 12 55 6E         [24]  739 	lcall	_ak820_outline_0182
      0078CA FF               [12]  740 	mov	r7,a
      0078CB 90 09 82         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078CE 12 38 59         [24]  742 	lcall	_ak820_outline_0061
      0078D1 90 09 82         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078D4 EF               [12]  744 	mov	a,r7
      0078D5 2C               [12]  745 	add	a, r4
      0078D6 F0               [24]  746 	movx	@dptr,a
      0078D7 E4               [12]  747 	clr	a
      0078D8 3D               [12]  748 	addc	a, r5
      0078D9 A3               [24]  749 	inc	dptr
      0078DA F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      0078DB 90 09 82         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078DE E0               [24]  753 	movx	a,@dptr
      0078DF FD               [12]  754 	mov	r5,a
      0078E0 A3               [24]  755 	inc	dptr
      0078E1 E0               [24]  756 	movx	a,@dptr
      0078E2 FF               [12]  757 	mov	r7,a
      0078E3 12 7E 2D         [24]  758 	lcall	_ak820_outline_0183
      0078E6 E0               [24]  759 	movx	a,@dptr
      0078E7 FC               [12]  760 	mov	r4,a
      0078E8 EE               [12]  761 	mov	a,r6
      0078E9 5C               [12]  762 	anl	a,r4
      0078EA B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      0078ED                        764 00124$:
      0078ED B3               [12]  765 	cpl	c
      0078EE 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      0078F0 90 09 81         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      0078F3 E0               [24]  768 	movx	a,@dptr
      0078F4 FB               [12]  769 	mov	r3,a
      0078F5 A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      0078F7 E4               [12]  771 	clr	a
      0078F8 33               [12]  772 	rlc	a
      0078F9 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      0078FC 75 82 00         [24]  774 	mov	dpl, #0x00
      0078FF 22               [24]  775 	ret
      007900                        776 00104$:
                                    777 ;	quantum/action_util.c:83: *bits ^= mask;
      007900 EC               [12]  778 	mov	a,r4
      007901 62 06            [12]  779 	xrl	ar6,a
      007903 12 7E 2D         [24]  780 	lcall	_ak820_outline_0183
      007906 EE               [12]  781 	mov	a,r6
      007907 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:84: return true;
      007908 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:85: }
      00790B 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      00790C                        805 _change_owned:
      00790C E5 82            [12]  806 	mov	a,dpl
      00790E 90 09 85         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      007911 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      007912 90 09 84         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007915 E0               [24]  811 	movx	a,@dptr
      007916 FF               [12]  812 	mov	r7,a
      007917 C3               [12]  813 	clr	c
      007918 13               [12]  814 	rrc	a
      007919 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      00791A 53 07 01         [24]  817 	anl	ar7,#0x01
      00791D EF               [12]  818 	mov	a,r7
      00791E B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007921                        820 00205$:
      007921 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007923 B3               [12]  822 	cpl	c
      007924 E4               [12]  823 	clr	a
      007925 33               [12]  824 	rlc	a
      007926 F5 58            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007928 EE               [12]  827 	mov	a,r6
      007929 60 06            [24]  828 	jz	00121$
      00792B 7D 72            [12]  829 	mov	r5,#_owned_weak_refs
      00792D 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      00792F 80 04            [24]  831 	sjmp	00122$
      007931                        832 00121$:
      007931 7D 6A            [12]  833 	mov	r5,#_owned_mod_refs
      007933 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007935                        835 00122$:
                                    836 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      007935 90 09 7E         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007938 E0               [24]  838 	movx	a,@dptr
      007939 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      00793B EE               [12]  841 	mov	a,r6
      00793C 24 7C            [12]  842 	add	a, #_macro_mods
      00793E FB               [12]  843 	mov	r3,a
      00793F E4               [12]  844 	clr	a
      007940 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007942 12 46 CE         [24]  846 	lcall	_ak820_outline_0056
                                    847 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007945 E5 58            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007947 60 0A            [24]  849 	jz	00123$
      007949 90 09 85         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      00794C E0               [24]  851 	movx	a,@dptr
      00794D F9               [12]  852 	mov	r1,a
      00794E EA               [12]  853 	mov	a,r2
      00794F 42 01            [12]  854 	orl	ar1,a
      007951 80 07            [24]  855 	sjmp	00124$
      007953                        856 00123$:
      007953 90 09 85         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      007956 E0               [24]  858 	movx	a,@dptr
      007957 F4               [12]  859 	cpl	a
      007958 5A               [12]  860 	anl	a,r2
      007959 F9               [12]  861 	mov	r1,a
      00795A                        862 00124$:
      00795A 12 33 FC         [24]  863 	lcall	_ak820_outline_0120
      00795D E9               [12]  864 	mov	a,r1
      00795E F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      00795F E5 58            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007961 60 06            [24]  868 	jz	00125$
      007963 74 FF            [12]  869 	mov	a,#0xff
      007965 6A               [12]  870 	xrl	a,r2
      007966 FC               [12]  871 	mov	r4,a
      007967 80 02            [24]  872 	sjmp	00126$
      007969                        873 00125$:
      007969 8A 04            [24]  874 	mov	ar4,r2
      00796B                        875 00126$:
      00796B 90 09 85         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      00796E E0               [24]  877 	movx	a,@dptr
      00796F 5C               [12]  878 	anl	a,r4
      007970 F0               [24]  879 	movx	@dptr,a
      007971                        880 00102$:
                                    881 ;	quantum/action_util.c:95: uint8_t result = 0;
      007971 90 09 86         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007974 E4               [12]  883 	clr	a
      007975 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007976 90 09 87         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      007979 04               [12]  887 	inc	a
      00797A F0               [24]  888 	movx	@dptr,a
      00797B 90 09 85         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      00797E E0               [24]  890 	movx	a,@dptr
      00797F FC               [12]  891 	mov	r4,a
      007980 7B 00            [12]  892 	mov	r3,#0x00
      007982                        893 00117$:
      007982 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007985                        895 00210$:
      007985 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:97: if (mods & bit) {
      007987 90 09 87         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      00798A E0               [24]  899 	movx	a,@dptr
      00798B 5C               [12]  900 	anl	a,r4
      00798C 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      00798E E5 58            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007990 60 0C            [24]  904 	jz	00106$
      007992 EB               [12]  905 	mov	a,r3
      007993 2D               [12]  906 	add	a, r5
      007994 12 38 28         [24]  907 	lcall	_ak820_outline_0015
      007997 F8               [12]  908 	mov	r0,a
      007998 08               [12]  909 	inc	r0
      007999 12 7D EA         [24]  910 	lcall	_ak820_outline_0064
      00799C 80 0C            [24]  911 	sjmp	00109$
      00799E                        912 00106$:
                                    913 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      00799E EB               [12]  914 	mov	a,r3
      00799F 2D               [12]  915 	add	a, r5
      0079A0 12 38 28         [24]  916 	lcall	_ak820_outline_0015
      0079A3 F8               [12]  917 	mov	r0,a
      0079A4 60 04            [24]  918 	jz	00109$
      0079A6 18               [12]  919 	dec	r0
      0079A7 12 7D EA         [24]  920 	lcall	_ak820_outline_0064
      0079AA                        921 00109$:
                                    922 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      0079AA EB               [12]  923 	mov	a,r3
      0079AB 2D               [12]  924 	add	a, r5
      0079AC 12 38 28         [24]  925 	lcall	_ak820_outline_0015
      0079AF 60 0B            [24]  926 	jz	00118$
      0079B1 90 09 87         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      0079B4 E0               [24]  928 	movx	a,@dptr
      0079B5 FA               [12]  929 	mov	r2,a
      0079B6 90 09 86         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      0079B9 E0               [24]  931 	movx	a,@dptr
      0079BA 4A               [12]  932 	orl	a,r2
      0079BB F0               [24]  933 	movx	@dptr,a
      0079BC                        934 00118$:
                                    935 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0079BC 0B               [12]  936 	inc	r3
      0079BD 90 09 87         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      0079C0 E0               [24]  938 	movx	a,@dptr
      0079C1 25 E0            [12]  939 	add	a,acc
      0079C3 F0               [24]  940 	movx	@dptr,a
      0079C4 80 BC            [24]  941 	sjmp	00117$
      0079C6                        942 00112$:
                                    943 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      0079C6 EE               [12]  944 	mov	a,r6
      0079C7 60 09            [24]  945 	jz	00114$
      0079C9 90 09 86         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      0079CC E0               [24]  947 	movx	a,@dptr
      0079CD 90 09 7B         [24]  948 	mov	dptr,#_owned_weak_mods
      0079D0 F0               [24]  949 	movx	@dptr,a
      0079D1 22               [24]  950 	ret
      0079D2                        951 00114$:
                                    952 ;	quantum/action_util.c:104: else owned_mods = result;
      0079D2 90 09 86         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      0079D5 E0               [24]  954 	movx	a,@dptr
      0079D6 90 09 7A         [24]  955 	mov	dptr,#_owned_mods
      0079D9 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:105: }
      0079DA 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      0079DB                        968 _add_owned_mods:
      0079DB E5 82            [12]  969 	mov	a,dpl
      0079DD 90 09 88         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      0079E0 12 7E 0A         [24]  971 	lcall	_ak820_outline_0111
      0079E3 74 01            [12]  972 	mov	a,#0x01
      0079E5 F0               [24]  973 	movx	@dptr,a
      0079E6 8F 82            [24]  974 	mov	dpl, r7
      0079E8 02 79 0C         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      0079EB                        985 _del_owned_mods:
      0079EB E5 82            [12]  986 	mov	a,dpl
      0079ED 90 09 89         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      0079F0 12 7E 0A         [24]  988 	lcall	_ak820_outline_0111
      0079F3 E4               [12]  989 	clr	a
      0079F4 F0               [24]  990 	movx	@dptr,a
      0079F5 8F 82            [24]  991 	mov	dpl, r7
      0079F7 02 79 0C         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      0079FA                       1002 _add_owned_weak_mods:
      0079FA E5 82            [12] 1003 	mov	a,dpl
      0079FC 90 09 8A         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      0079FF 12 7E 0A         [24] 1005 	lcall	_ak820_outline_0111
      007A02 74 03            [12] 1006 	mov	a,#0x03
      007A04 F0               [24] 1007 	movx	@dptr,a
      007A05 8F 82            [24] 1008 	mov	dpl, r7
      007A07 02 79 0C         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007A0A                       1019 _del_owned_weak_mods:
      007A0A E5 82            [12] 1020 	mov	a,dpl
      007A0C 90 09 8B         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      007A0F 12 7E 0A         [24] 1022 	lcall	_ak820_outline_0111
      007A12 74 02            [12] 1023 	mov	a,#0x02
      007A14 F0               [24] 1024 	movx	@dptr,a
      007A15 8F 82            [24] 1025 	mov	dpl, r7
      007A17 02 79 0C         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007A1A                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007A1A 7F 00            [12] 1038 	mov	r7,#0x00
      007A1C                       1039 00103$:
      007A1C BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007A1F                       1041 00122$:
      007A1F 50 1A            [24] 1042 	jnc	00101$
      007A21 EF               [12] 1043 	mov	a,r7
      007A22 24 6A            [12] 1044 	add	a, #_owned_mod_refs
      007A24 FD               [12] 1045 	mov	r5,a
      007A25 E4               [12] 1046 	clr	a
      007A26 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007A28 FE               [12] 1048 	mov	r6,a
      007A29 EF               [12] 1049 	mov	a,r7
      007A2A 24 72            [12] 1050 	add	a, #_owned_weak_refs
      007A2C F5 82            [12] 1051 	mov	dpl,a
      007A2E E4               [12] 1052 	clr	a
      007A2F 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007A31 F5 83            [12] 1054 	mov	dph,a
      007A33 E4               [12] 1055 	clr	a
      007A34 F0               [24] 1056 	movx	@dptr,a
      007A35 12 7E 11         [24] 1057 	lcall	_ak820_outline_0119
      007A38 0F               [12] 1058 	inc	r7
      007A39 80 E1            [24] 1059 	sjmp	00103$
      007A3B                       1060 00101$:
                                   1061 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007A3B 90 09 7D         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007A3E E4               [12] 1063 	clr	a
      007A3F F0               [24] 1064 	movx	@dptr,a
      007A40 90 09 7C         [24] 1065 	mov	dptr,#_macro_mods
      007A43 F0               [24] 1066 	movx	@dptr,a
      007A44 90 09 7B         [24] 1067 	mov	dptr,#_owned_weak_mods
      007A47 F0               [24] 1068 	movx	@dptr,a
      007A48 90 09 7A         [24] 1069 	mov	dptr,#_owned_mods
      007A4B F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      007A4C 90 09 7F         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007A4F 04               [12] 1073 	inc	a
      007A50 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:114: }
      007A51 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007A52                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007A52 7F 00            [12] 1089 	mov	r7,#0x00
      007A54                       1090 00104$:
      007A54 EF               [12] 1091 	mov	a,r7
      007A55 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007A57 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007A59 EF               [12] 1095 	mov	a,r7
      007A5A 24 8C            [12] 1096 	add	a, #_key_refs
      007A5C F5 82            [12] 1097 	mov	dpl,a
      007A5E E4               [12] 1098 	clr	a
      007A5F 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007A61 12 78 91         [24] 1100 	lcall	_ak820_outline_0159
      007A64 80 EE            [24] 1101 	sjmp	00104$
      007A66                       1102 00101$:
                                   1103 ;	quantum/action_util.c:122: distinct_keys = 0;
      007A66 90 0A 31         [24] 1104 	mov	dptr,#_distinct_keys
      007A69 E4               [12] 1105 	clr	a
      007A6A F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007A6B FF               [12] 1108 	mov	r7,a
      007A6C                       1109 00107$:
      007A6C BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007A6F                       1111 00142$:
      007A6F 50 0D            [24] 1112 	jnc	00109$
      007A71 EF               [12] 1113 	mov	a,r7
      007A72 24 32            [12] 1114 	add	a, #_macro_keys
      007A74 F5 82            [12] 1115 	mov	dpl,a
      007A76 E4               [12] 1116 	clr	a
      007A77 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007A79 12 78 91         [24] 1118 	lcall	_ak820_outline_0159
      007A7C 80 EE            [24] 1119 	sjmp	00107$
      007A7E                       1120 00109$:
                                   1121 ;	quantum/action_util.c:124: }
      007A7E 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007A7F                       1137 _add_owned_key:
      007A7F E5 82            [12] 1138 	mov	a,dpl
      007A81 90 0A 47         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007A84 12 7E 22         [24] 1140 	lcall	_ak820_outline_0129
                                   1141 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007A87 74 01            [12] 1142 	mov	a,#0x01
      007A89 F0               [24] 1143 	movx	@dptr,a
      007A8A 90 0A 32         [24] 1144 	mov	dptr,#_macro_keys
      007A8D C0 07            [24] 1145 	push	ar7
      007A8F 12 78 A0         [24] 1146 	lcall	_ak820_macro_change
      007A92 E5 82            [12] 1147 	mov	a, dpl
      007A94 D0 07            [24] 1148 	pop	ar7
      007A96 70 03            [24] 1149 	jnz	00102$
      007A98 F5 82            [12] 1150 	mov	dpl,a
      007A9A 22               [24] 1151 	ret
      007A9B                       1152 00102$:
                                   1153 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      007A9B 12 7D D4         [24] 1154 	lcall	_ak820_outline_0029
      007A9E FC               [12] 1155 	mov	r4,a
      007A9F 04               [12] 1156 	inc	a
      007AA0 12 7E 11         [24] 1157 	lcall	_ak820_outline_0119
      007AA3 EC               [12] 1158 	mov	a,r4
      007AA4 60 04            [24] 1159 	jz	00104$
      007AA6 75 82 00         [24] 1160 	mov	dpl, #0x00
      007AA9 22               [24] 1161 	ret
      007AAA                       1162 00104$:
                                   1163 ;	quantum/action_util.c:128: ++distinct_keys;
      007AAA 90 0A 31         [24] 1164 	mov	dptr,#_distinct_keys
      007AAD E0               [24] 1165 	movx	a,@dptr
      007AAE 24 01            [12] 1166 	add	a, #0x01
      007AB0 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007AB1 90 0D A4         [24] 1169 	mov	dptr,#_keyboard_protocol
      007AB4 E0               [24] 1170 	movx	a,@dptr
      007AB5 60 15            [24] 1171 	jz	00106$
      007AB7 90 0A B6         [24] 1172 	mov	dptr,#_keymap_config
      007ABA E0               [24] 1173 	movx	a,@dptr
      007ABB 30 E7 0E         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007ABE 90 07 F7         [24] 1176 	mov	dptr,#_add_key_to_report_PARM_2
      007AC1 EF               [12] 1177 	mov	a,r7
      007AC2 12 7D E2         [24] 1178 	lcall	_ak820_outline_0059
      007AC5 12 6C D9         [24] 1179 	lcall	_add_key_to_report
                                   1180 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007AC8 75 82 01         [24] 1181 	mov	dpl, #0x01
      007ACB 22               [24] 1182 	ret
      007ACC                       1183 00106$:
                                   1184 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007ACC 90 0A 31         [24] 1185 	mov	dptr,#_distinct_keys
      007ACF E0               [24] 1186 	movx	a,@dptr
      007AD0 24 F9            [12] 1187 	add	a,#0xff - 0x06
      007AD2 50 17            [24] 1188 	jnc	00110$
                                   1189 ;	free result
                                   1190 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007AD4 7F 00            [12] 1191 	mov	r7,#0x00
      007AD6                       1192 00115$:
      007AD6 BF 06 00         [24] 1193 	cjne	r7,#0x06,00174$
      007AD9                       1194 00174$:
      007AD9 50 1D            [24] 1195 	jnc	00111$
      007ADB EF               [12] 1196 	mov	a,r7
      007ADC 24 B9            [12] 1197 	add	a, #(_actual_keyboard_report + 0x0002)
      007ADE F5 82            [12] 1198 	mov	dpl,a
      007AE0 E4               [12] 1199 	clr	a
      007AE1 34 0D            [12] 1200 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007AE3 F5 83            [12] 1201 	mov	dph,a
      007AE5 74 01            [12] 1202 	mov	a,#0x01
      007AE7 F0               [24] 1203 	movx	@dptr,a
      007AE8 0F               [12] 1204 	inc	r7
      007AE9 80 EB            [24] 1205 	sjmp	00115$
      007AEB                       1206 00110$:
                                   1207 ;	quantum/action_util.c:134: } else add_key(code);
      007AEB 90 0A 47         [24] 1208 	mov	dptr,#_add_owned_key_code_10000_326
      007AEE E0               [24] 1209 	movx	a,@dptr
                                   1210 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007AEF 90 07 F7         [24] 1211 	mov	dptr,#_add_key_to_report_PARM_2
      007AF2 12 7D E2         [24] 1212 	lcall	_ak820_outline_0059
      007AF5 12 6C D9         [24] 1213 	lcall	_add_key_to_report
                                   1214 ;	quantum/action_util.c:134: } else add_key(code);
      007AF8                       1215 00111$:
                                   1216 ;	quantum/action_util.c:135: return true;
      007AF8 75 82 01         [24] 1217 	mov	dpl, #0x01
                                   1218 ;	quantum/action_util.c:136: }
      007AFB 22               [24] 1219 	ret
                                   1220 ;------------------------------------------------------------
                                   1221 ;Allocation info for local variables in function 'del_owned_key'
                                   1222 ;------------------------------------------------------------
                                   1223 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1224 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1225 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1226 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1227 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1228 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1229 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1230 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1231 ;------------------------------------------------------------
                                   1232 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1233 ;	-----------------------------------------
                                   1234 ;	 function del_owned_key
                                   1235 ;	-----------------------------------------
      007AFC                       1236 _del_owned_key:
      007AFC E5 82            [12] 1237 	mov	a,dpl
      007AFE 90 0A 48         [24] 1238 	mov	dptr,#_del_owned_key_code_10000_341
      007B01 12 7E 22         [24] 1239 	lcall	_ak820_outline_0129
                                   1240 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007B04 E4               [12] 1241 	clr	a
      007B05 F0               [24] 1242 	movx	@dptr,a
      007B06 90 0A 32         [24] 1243 	mov	dptr,#_macro_keys
      007B09 C0 07            [24] 1244 	push	ar7
      007B0B 12 78 A0         [24] 1245 	lcall	_ak820_macro_change
      007B0E E5 82            [12] 1246 	mov	a, dpl
      007B10 D0 07            [24] 1247 	pop	ar7
      007B12 70 03            [24] 1248 	jnz	00102$
      007B14 F5 82            [12] 1249 	mov	dpl,a
      007B16 22               [24] 1250 	ret
      007B17                       1251 00102$:
                                   1252 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      007B17 12 7D D4         [24] 1253 	lcall	_ak820_outline_0029
      007B1A FC               [12] 1254 	mov	r4,a
      007B1B 60 09            [24] 1255 	jz	00103$
      007B1D 1C               [12] 1256 	dec	r4
      007B1E 12 38 9C         [24] 1257 	lcall	_ak820_outline_0130
      007B21 EC               [12] 1258 	mov	a,r4
      007B22 F0               [24] 1259 	movx	@dptr,a
      007B23 EC               [12] 1260 	mov	a,r4
      007B24 60 04            [24] 1261 	jz	00104$
      007B26                       1262 00103$:
      007B26 75 82 00         [24] 1263 	mov	dpl, #0x00
      007B29 22               [24] 1264 	ret
      007B2A                       1265 00104$:
                                   1266 ;	quantum/action_util.c:140: --distinct_keys;
      007B2A 90 0A 31         [24] 1267 	mov	dptr,#_distinct_keys
      007B2D E0               [24] 1268 	movx	a,@dptr
      007B2E 14               [12] 1269 	dec	a
      007B2F F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007B30 90 0D A4         [24] 1272 	mov	dptr,#_keyboard_protocol
      007B33 E0               [24] 1273 	movx	a,@dptr
      007B34 60 15            [24] 1274 	jz	00107$
      007B36 90 0A B6         [24] 1275 	mov	dptr,#_keymap_config
      007B39 E0               [24] 1276 	movx	a,@dptr
      007B3A 30 E7 0E         [24] 1277 	jnb	acc.7,00107$
                                   1278 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007B3D 90 07 FB         [24] 1279 	mov	dptr,#_del_key_from_report_PARM_2
      007B40 EF               [12] 1280 	mov	a,r7
      007B41 12 7D E2         [24] 1281 	lcall	_ak820_outline_0059
      007B44 12 6D 17         [24] 1282 	lcall	_del_key_from_report
                                   1283 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007B47 75 82 01         [24] 1284 	mov	dpl, #0x01
      007B4A 22               [24] 1285 	ret
      007B4B                       1286 00107$:
                                   1287 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007B4B 90 0A 31         [24] 1288 	mov	dptr,#_distinct_keys
      007B4E E0               [24] 1289 	movx	a,@dptr
      007B4F FF               [12] 1290 	mov  r7,a
      007B50 24 F9            [12] 1291 	add	a,#0xff - 0x06
      007B52 50 04            [24] 1292 	jnc	00110$
                                   1293 ;	free result
      007B54 75 82 01         [24] 1294 	mov	dpl, #0x01
      007B57 22               [24] 1295 	ret
      007B58                       1296 00110$:
                                   1297 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007B58 BF 06 26         [24] 1298 	cjne	r7,#0x06,00115$
                                   1299 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B5B 90 0D B7         [24] 1300 	mov	dptr,#_actual_keyboard_report
      007B5E 75 F0 00         [24] 1301 	mov	b, #0x00
      007B61 12 6D 55         [24] 1302 	lcall	_clear_keys_from_report
                                   1303 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007B64 7F 04            [12] 1304 	mov	r7,#0x04
      007B66                       1305 00122$:
      007B66 EF               [12] 1306 	mov	a,r7
      007B67 24 5B            [12] 1307 	add	a,#0xff - 0xa4
      007B69 40 23            [24] 1308 	jc	00116$
                                   1309 ;	free result
      007B6B 12 7D D4         [24] 1310 	lcall	_ak820_outline_0029
      007B6E 60 0E            [24] 1311 	jz	00123$
                                   1312 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007B70 90 07 F7         [24] 1313 	mov	dptr,#_add_key_to_report_PARM_2
      007B73 EF               [12] 1314 	mov	a,r7
      007B74 12 7D E2         [24] 1315 	lcall	_ak820_outline_0059
      007B77 C0 07            [24] 1316 	push	ar7
      007B79 12 6C D9         [24] 1317 	lcall	_add_key_to_report
      007B7C D0 07            [24] 1318 	pop	ar7
                                   1319 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007B7E                       1320 00123$:
      007B7E 0F               [12] 1321 	inc	r7
      007B7F 80 E5            [24] 1322 	sjmp	00122$
      007B81                       1323 00115$:
                                   1324 ;	quantum/action_util.c:149: } else del_key(code);
      007B81 90 0A 48         [24] 1325 	mov	dptr,#_del_owned_key_code_10000_341
      007B84 E0               [24] 1326 	movx	a,@dptr
                                   1327 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007B85 90 07 FB         [24] 1328 	mov	dptr,#_del_key_from_report_PARM_2
      007B88 12 7D E2         [24] 1329 	lcall	_ak820_outline_0059
      007B8B 12 6D 17         [24] 1330 	lcall	_del_key_from_report
                                   1331 ;	quantum/action_util.c:149: } else del_key(code);
      007B8E                       1332 00116$:
                                   1333 ;	quantum/action_util.c:150: return true;
      007B8E 75 82 01         [24] 1334 	mov	dpl, #0x01
                                   1335 ;	quantum/action_util.c:151: }
      007B91 22               [24] 1336 	ret
                                   1337 ;------------------------------------------------------------
                                   1338 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1339 ;------------------------------------------------------------
                                   1340 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1341 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1342 ;------------------------------------------------------------
                                   1343 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1344 ;	-----------------------------------------
                                   1345 ;	 function clear_owned_usages
                                   1346 ;	-----------------------------------------
      007B92                       1347 _clear_owned_usages:
                                   1348 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007B92 7F 00            [12] 1349 	mov	r7,#0x00
      007B94                       1350 00104$:
      007B94 BF 1E 00         [24] 1351 	cjne	r7,#0x1e,00141$
      007B97                       1352 00141$:
      007B97 50 14            [24] 1353 	jnc	00101$
      007B99 EF               [12] 1354 	mov	a,r7
      007B9A 24 49            [12] 1355 	add	a, #_usage_refs
      007B9C FD               [12] 1356 	mov	r5,a
      007B9D E4               [12] 1357 	clr	a
      007B9E 34 0A            [12] 1358 	addc	a, #(_usage_refs >> 8)
      007BA0 FE               [12] 1359 	mov	r6,a
      007BA1 EF               [12] 1360 	mov	a,r7
      007BA2 12 7D F1         [24] 1361 	lcall	_ak820_outline_0067
      007BA5 E4               [12] 1362 	clr	a
      007BA6 F0               [24] 1363 	movx	@dptr,a
      007BA7 12 7E 11         [24] 1364 	lcall	_ak820_outline_0119
      007BAA 0F               [12] 1365 	inc	r7
      007BAB 80 E7            [24] 1366 	sjmp	00104$
      007BAD                       1367 00101$:
                                   1368 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      007BAD 90 0A 86         [24] 1369 	mov	dptr,#(_usage_lengths + 0x0001)
      007BB0 E4               [12] 1370 	clr	a
      007BB1 F0               [24] 1371 	movx	@dptr,a
      007BB2 90 0A 85         [24] 1372 	mov	dptr,#_usage_lengths
      007BB5 F0               [24] 1373 	movx	@dptr,a
                                   1374 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007BB6 FF               [12] 1375 	mov	r7,a
      007BB7                       1376 00107$:
      007BB7 BF 04 00         [24] 1377 	cjne	r7,#0x04,00143$
      007BBA                       1378 00143$:
      007BBA 50 0D            [24] 1379 	jnc	00109$
      007BBC EF               [12] 1380 	mov	a,r7
      007BBD 24 87            [12] 1381 	add	a, #_macro_usages
      007BBF F5 82            [12] 1382 	mov	dpl,a
      007BC1 E4               [12] 1383 	clr	a
      007BC2 34 0A            [12] 1384 	addc	a, #(_macro_usages >> 8)
      007BC4 12 78 91         [24] 1385 	lcall	_ak820_outline_0159
      007BC7 80 EE            [24] 1386 	sjmp	00107$
      007BC9                       1387 00109$:
                                   1388 ;	quantum/action_util.c:165: }
      007BC9 22               [24] 1389 	ret
                                   1390 ;------------------------------------------------------------
                                   1391 ;Allocation info for local variables in function 'owned_usage_key'
                                   1392 ;------------------------------------------------------------
                                   1393 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1394 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1395 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1396 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1397 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1398 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1399 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1400 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1401 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1402 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1403 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1404 ;------------------------------------------------------------
                                   1405 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1406 ;	-----------------------------------------
                                   1407 ;	 function owned_usage_key
                                   1408 ;	-----------------------------------------
      007BCA                       1409 _owned_usage_key:
      007BCA E5 82            [12] 1410 	mov	a,dpl
      007BCC 90 0A 8C         [24] 1411 	mov	dptr,#_owned_usage_key_code_10000_368
      007BCF F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      007BD0 E0               [24] 1414 	movx	a,@dptr
      007BD1 FF               [12] 1415 	mov	r7,a
      007BD2 BF A8 00         [24] 1416 	cjne	r7,#0xa8,00244$
      007BD5                       1417 00244$:
      007BD5 B3               [12] 1418 	cpl	c
      007BD6 92 22            [24] 1419 	mov	_owned_usage_key_sloc0_1_0,c
      007BD8 E4               [12] 1420 	clr	a
      007BD9 33               [12] 1421 	rlc	a
      007BDA FF               [12] 1422 	mov	r7,a
      007BDB 90 0A 8F         [24] 1423 	mov	dptr,#_owned_usage_key_which_10000_369
      007BDE F0               [24] 1424 	movx	@dptr,a
                                   1425 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      007BDF EF               [12] 1426 	mov	a,r7
      007BE0 60 02            [24] 1427 	jz	00129$
      007BE2 74 03            [12] 1428 	mov	a,#0x03
      007BE4                       1429 00129$:
      007BE4 FE               [12] 1430 	mov	r6,a
                                   1431 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      007BE5 EF               [12] 1432 	mov	a,r7
      007BE6 24 85            [12] 1433 	add	a, #_usage_lengths
      007BE8 FD               [12] 1434 	mov	r5,a
      007BE9 E4               [12] 1435 	clr	a
      007BEA 34 0A            [12] 1436 	addc	a, #(_usage_lengths >> 8)
      007BEC FF               [12] 1437 	mov	r7,a
      007BED 12 7E 2D         [24] 1438 	lcall	_ak820_outline_0183
      007BF0 E0               [24] 1439 	movx	a,@dptr
      007BF1 FC               [12] 1440 	mov	r4,a
                                   1441 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      007BF2 90 0A 8C         [24] 1442 	mov	dptr,#_owned_usage_key_code_10000_368
      007BF5 E0               [24] 1443 	movx	a,@dptr
      007BF6 24 5B            [12] 1444 	add	a,#0x5b
      007BF8 FB               [12] 1445 	mov	r3,a
                                   1446 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007BF9 90 0A 8B         [24] 1447 	mov	dptr,#_owned_usage_key_PARM_2
      007BFC E0               [24] 1448 	movx	a,@dptr
      007BFD FA               [12] 1449 	mov	r2,a
      007BFE 90 09 80         [24] 1450 	mov	dptr,#_ak820_macro_change_PARM_2
      007C01 EB               [12] 1451 	mov	a,r3
      007C02 F0               [24] 1452 	movx	@dptr,a
      007C03 90 09 81         [24] 1453 	mov	dptr,#_ak820_macro_change_PARM_3
      007C06 EA               [12] 1454 	mov	a,r2
      007C07 F0               [24] 1455 	movx	@dptr,a
      007C08 90 0A 87         [24] 1456 	mov	dptr,#_macro_usages
      007C0B C0 07            [24] 1457 	push	ar7
      007C0D C0 06            [24] 1458 	push	ar6
      007C0F C0 05            [24] 1459 	push	ar5
      007C11 C0 04            [24] 1460 	push	ar4
      007C13 C0 03            [24] 1461 	push	ar3
      007C15 C0 02            [24] 1462 	push	ar2
      007C17 12 78 A0         [24] 1463 	lcall	_ak820_macro_change
      007C1A E5 82            [12] 1464 	mov	a, dpl
      007C1C D0 02            [24] 1465 	pop	ar2
      007C1E D0 03            [24] 1466 	pop	ar3
      007C20 D0 04            [24] 1467 	pop	ar4
      007C22 D0 05            [24] 1468 	pop	ar5
      007C24 D0 06            [24] 1469 	pop	ar6
      007C26 D0 07            [24] 1470 	pop	ar7
      007C28 70 01            [24] 1471 	jnz	00102$
      007C2A 22               [24] 1472 	ret
      007C2B                       1473 00102$:
                                   1474 ;	quantum/action_util.c:172: if (pressed) {
      007C2B EA               [12] 1475 	mov	a,r2
      007C2C 60 1B            [24] 1476 	jz	00115$
                                   1477 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      007C2E 12 7D FB         [24] 1478 	lcall	_ak820_outline_0074
      007C31 04               [12] 1479 	inc	a
      007C32 12 6A 58         [24] 1480 	lcall	_ak820_outline_0135
      007C35 E8               [12] 1481 	mov	a,r0
      007C36 60 01            [24] 1482 	jz	00104$
      007C38 22               [24] 1483 	ret
      007C39                       1484 00104$:
                                   1485 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      007C39 90 0A 90         [24] 1486 	mov	dptr,#_owned_usage_key_count_10000_369
      007C3C EC               [12] 1487 	mov	a,r4
      007C3D 04               [12] 1488 	inc	a
      007C3E F0               [24] 1489 	movx	@dptr,a
      007C3F EC               [12] 1490 	mov	a,r4
      007C40 2E               [12] 1491 	add	a, r6
      007C41 12 7D F1         [24] 1492 	lcall	_ak820_outline_0067
      007C44 EB               [12] 1493 	mov	a,r3
      007C45 F0               [24] 1494 	movx	@dptr,a
      007C46 02 7C AA         [24] 1495 	ljmp	00116$
      007C49                       1496 00115$:
                                   1497 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      007C49 12 7D FB         [24] 1498 	lcall	_ak820_outline_0074
      007C4C 60 07            [24] 1499 	jz	00105$
      007C4E 18               [12] 1500 	dec	r0
      007C4F 12 7D EA         [24] 1501 	lcall	_ak820_outline_0064
      007C52 E8               [12] 1502 	mov	a,r0
      007C53 60 01            [24] 1503 	jz	00106$
      007C55                       1504 00105$:
      007C55 22               [24] 1505 	ret
      007C56                       1506 00106$:
                                   1507 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      007C56 7A 00            [12] 1508 	mov	r2,#0x00
      007C58                       1509 00108$:
      007C58 EA               [12] 1510 	mov	a,r2
      007C59 2E               [12] 1511 	add	a, r6
      007C5A 12 7D F1         [24] 1512 	lcall	_ak820_outline_0067
      007C5D E0               [24] 1513 	movx	a,@dptr
      007C5E B5 03 02         [24] 1514 	cjne	a,ar3,00251$
      007C61 80 03            [24] 1515 	sjmp	00167$
      007C63                       1516 00251$:
      007C63 0A               [12] 1517 	inc	r2
      007C64 80 F2            [24] 1518 	sjmp	00108$
      007C66                       1519 00167$:
      007C66 90 0A 91         [24] 1520 	mov	dptr,#_owned_usage_key_pos_30001_376
      007C69 EA               [12] 1521 	mov	a,r2
      007C6A F0               [24] 1522 	movx	@dptr,a
                                   1523 ;	quantum/action_util.c:179: --count;
      007C6B 1C               [12] 1524 	dec	r4
      007C6C 90 0A 90         [24] 1525 	mov	dptr,#_owned_usage_key_count_10000_369
      007C6F EC               [12] 1526 	mov	a,r4
      007C70 F0               [24] 1527 	movx	@dptr,a
                                   1528 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007C71 8A 03            [24] 1529 	mov	ar3,r2
      007C73                       1530 00125$:
      007C73 C3               [12] 1531 	clr	c
      007C74 EB               [12] 1532 	mov	a,r3
      007C75 9C               [12] 1533 	subb	a,r4
      007C76 50 23            [24] 1534 	jnc	00111$
      007C78 C0 05            [24] 1535 	push	ar5
      007C7A C0 07            [24] 1536 	push	ar7
      007C7C EB               [12] 1537 	mov	a,r3
      007C7D 2E               [12] 1538 	add	a, r6
      007C7E FA               [12] 1539 	mov	r2,a
      007C7F 24 67            [12] 1540 	add	a, #_usage_order
      007C81 F8               [12] 1541 	mov	r0,a
      007C82 E4               [12] 1542 	clr	a
      007C83 34 0A            [12] 1543 	addc	a, #(_usage_order >> 8)
      007C85 F9               [12] 1544 	mov	r1,a
      007C86 0A               [12] 1545 	inc	r2
      007C87 EA               [12] 1546 	mov	a,r2
      007C88 33               [12] 1547 	rlc	a
      007C89 95 E0            [12] 1548 	subb	a,acc
      007C8B FF               [12] 1549 	mov	r7,a
      007C8C EA               [12] 1550 	mov	a,r2
      007C8D 12 7E 17         [24] 1551 	lcall	_ak820_outline_0123
      007C90 12 38 B1         [24] 1552 	lcall	_ak820_outline_0153
      007C93 F0               [24] 1553 	movx	@dptr,a
      007C94 0B               [12] 1554 	inc	r3
      007C95 D0 07            [24] 1555 	pop	ar7
      007C97 D0 05            [24] 1556 	pop	ar5
      007C99 80 D8            [24] 1557 	sjmp	00125$
      007C9B                       1558 00111$:
                                   1559 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      007C9B 12 7E 2D         [24] 1560 	lcall	_ak820_outline_0183
      007C9E EC               [12] 1561 	mov	a,r4
      007C9F F0               [24] 1562 	movx	@dptr,a
                                   1563 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      007CA0 90 0A 91         [24] 1564 	mov	dptr,#_owned_usage_key_pos_30001_376
      007CA3 E0               [24] 1565 	movx	a,@dptr
      007CA4 B5 04 02         [24] 1566 	cjne	a,ar4,00253$
      007CA7 80 01            [24] 1567 	sjmp	00116$
      007CA9                       1568 00253$:
      007CA9 22               [24] 1569 	ret
      007CAA                       1570 00116$:
                                   1571 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      007CAA 90 0A 90         [24] 1572 	mov	dptr,#_owned_usage_key_count_10000_369
      007CAD E0               [24] 1573 	movx	a,@dptr
      007CAE FC               [12] 1574 	mov	r4,a
      007CAF 12 7E 2D         [24] 1575 	lcall	_ak820_outline_0183
      007CB2 F0               [24] 1576 	movx	@dptr,a
                                   1577 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007CB3 EC               [12] 1578 	mov	a,r4
      007CB4 60 15            [24] 1579 	jz	00131$
      007CB6 EC               [12] 1580 	mov	a,r4
      007CB7 2E               [12] 1581 	add	a, r6
      007CB8 FE               [12] 1582 	mov	r6,a
      007CB9 1E               [12] 1583 	dec	r6
      007CBA EE               [12] 1584 	mov	a,r6
      007CBB 33               [12] 1585 	rlc	a
      007CBC 95 E0            [12] 1586 	subb	a,acc
      007CBE FF               [12] 1587 	mov	r7,a
      007CBF EE               [12] 1588 	mov	a,r6
      007CC0 12 7E 17         [24] 1589 	lcall	_ak820_outline_0123
      007CC3 24 A5            [12] 1590 	add	a,#0xa5
      007CC5 FE               [12] 1591 	mov	r6,a
      007CC6 33               [12] 1592 	rlc	a
      007CC7 95 E0            [12] 1593 	subb	a,acc
      007CC9 80 02            [24] 1594 	sjmp	00132$
      007CCB                       1595 00131$:
      007CCB 7E 00            [12] 1596 	mov	r6,#0x00
      007CCD                       1597 00132$:
      007CCD 90 0A 8C         [24] 1598 	mov	dptr,#_owned_usage_key_code_10000_368
      007CD0 EE               [12] 1599 	mov	a,r6
      007CD1 F0               [24] 1600 	movx	@dptr,a
                                   1601 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007CD2 90 0A 8F         [24] 1602 	mov	dptr,#_owned_usage_key_which_10000_369
      007CD5 E0               [24] 1603 	movx	a,@dptr
      007CD6 60 18            [24] 1604 	jz	00118$
      007CD8 EE               [12] 1605 	mov	a,r6
      007CD9 60 0B            [24] 1606 	jz	00133$
      007CDB 8E 82            [24] 1607 	mov	dpl, r6
      007CDD 12 6B 98         [24] 1608 	lcall	_KEYCODE2CONSUMER
      007CE0 AD 82            [24] 1609 	mov	r5, dpl
      007CE2 AF 83            [24] 1610 	mov	r7, dph
      007CE4 80 04            [24] 1611 	sjmp	00134$
      007CE6                       1612 00133$:
      007CE6 7D 00            [12] 1613 	mov	r5,#0x00
      007CE8 7F 00            [12] 1614 	mov	r7,#0x00
      007CEA                       1615 00134$:
      007CEA 12 7E 2D         [24] 1616 	lcall	_ak820_outline_0183
      007CED 02 6B 4B         [24] 1617 	ljmp	_host_consumer_send
      007CF0                       1618 00118$:
                                   1619 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007CF0 EE               [12] 1620 	mov	a,r6
      007CF1 60 22            [24] 1621 	jz	00135$
                                   1622 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007CF3 BE A5 00         [24] 1623 	cjne	r6,#0xa5,00258$
      007CF6                       1624 00258$:
      007CF6 40 05            [24] 1625 	jc	00121$
      007CF8 EE               [12] 1626 	mov	a,r6
      007CF9 24 58            [12] 1627 	add	a,#0xff - 0xa7
      007CFB 50 08            [24] 1628 	jnc	00122$
                                   1629 ;	free result
      007CFD                       1630 00121$:
      007CFD 90 0A 8D         [24] 1631 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007D00 12 4D 73         [24] 1632 	lcall	_ak820_outline_0166
      007D03 80 09            [24] 1633 	sjmp	00123$
      007D05                       1634 00122$:
                                   1635 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007D05 74 DC            [12] 1636 	mov	a,#0xdc
      007D07 2E               [12] 1637 	add	a, r6
      007D08 90 0A 8D         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007D0B 12 38 97         [24] 1639 	lcall	_ak820_outline_0122
                                   1640 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007D0E                       1641 00123$:
      007D0E 90 0A 8D         [24] 1642 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007D11 E0               [24] 1643 	movx	a,@dptr
      007D12 FF               [12] 1644 	mov	r7,a
      007D13 80 02            [24] 1645 	sjmp	00136$
      007D15                       1646 00135$:
      007D15 7F 00            [12] 1647 	mov	r7,#0x00
      007D17                       1648 00136$:
      007D17 7E 00            [12] 1649 	mov	r6,#0x00
      007D19 12 43 71         [24] 1650 	lcall	_ak820_outline_0154
                                   1651 ;	quantum/action_util.c:188: }
      007D1C 02 6B 1B         [24] 1652 	ljmp	_host_system_send
                                   1653 ;------------------------------------------------------------
                                   1654 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1655 ;------------------------------------------------------------
                                   1656 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1657 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1658 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1659 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1660 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1661 ;------------------------------------------------------------
                                   1662 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1663 ;	-----------------------------------------
                                   1664 ;	 function send_keyboard_report
                                   1665 ;	-----------------------------------------
      007D1F                       1666 _send_keyboard_report:
                                   1667 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      007D1F 90 0D B5         [24] 1668 	mov	dptr,#_real_mods
      007D22 E0               [24] 1669 	movx	a,@dptr
      007D23 FF               [12] 1670 	mov	r7,a
      007D24 90 0D B7         [24] 1671 	mov	dptr,#_actual_keyboard_report
      007D27 F0               [24] 1672 	movx	@dptr,a
                                   1673 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      007D28 90 0D B6         [24] 1674 	mov	dptr,#_weak_mods
      007D2B E0               [24] 1675 	movx	a,@dptr
      007D2C 42 07            [12] 1676 	orl	ar7,a
      007D2E 90 0D B7         [24] 1677 	mov	dptr,#_actual_keyboard_report
      007D31 EF               [12] 1678 	mov	a,r7
      007D32 F0               [24] 1679 	movx	@dptr,a
                                   1680 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007D33 90 09 7B         [24] 1681 	mov	dptr,#_owned_weak_mods
      007D36 E0               [24] 1682 	movx	a,@dptr
      007D37 FE               [12] 1683 	mov	r6,a
      007D38 90 09 7A         [24] 1684 	mov	dptr,#_owned_mods
      007D3B E0               [24] 1685 	movx	a,@dptr
      007D3C 4E               [12] 1686 	orl	a,r6
      007D3D 42 07            [12] 1687 	orl	ar7,a
      007D3F 90 0D B7         [24] 1688 	mov	dptr,#_actual_keyboard_report
      007D42 EF               [12] 1689 	mov	a,r7
      007D43 F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:455: bool changed = false;
      007D44 90 0A B3         [24] 1692 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D47 E4               [12] 1693 	clr	a
      007D48 F0               [24] 1694 	movx	@dptr,a
                                   1695 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1696 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1697 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007D49 FF               [12] 1698 	mov	r7,a
      007D4A                       1699 00107$:
      007D4A BF 20 00         [24] 1700 	cjne	r7,#0x20,00140$
      007D4D                       1701 00140$:
      007D4D 50 2A            [24] 1702 	jnc	00103$
                                   1703 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      007D4F EF               [12] 1704 	mov	a,r7
      007D50 24 93            [12] 1705 	add	a, #_send_keyboard_report_last_report_10001_388
      007D52 FD               [12] 1706 	mov	r5,a
      007D53 E4               [12] 1707 	clr	a
      007D54 34 0A            [12] 1708 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      007D56 12 46 D6         [24] 1709 	lcall	_ak820_outline_0058
      007D59 EF               [12] 1710 	mov	a,r7
      007D5A 24 B7            [12] 1711 	add	a, #_actual_keyboard_report
      007D5C F5 82            [12] 1712 	mov	dpl,a
      007D5E E4               [12] 1713 	clr	a
      007D5F 34 0D            [12] 1714 	addc	a, #(_actual_keyboard_report >> 8)
      007D61 F5 83            [12] 1715 	mov	dph,a
      007D63 E0               [24] 1716 	movx	a,@dptr
      007D64 FB               [12] 1717 	mov	r3,a
      007D65 EC               [12] 1718 	mov	a,r4
      007D66 B5 03 02         [24] 1719 	cjne	a,ar3,00142$
      007D69 80 0B            [24] 1720 	sjmp	00108$
      007D6B                       1721 00142$:
                                   1722 ;	quantum/action_util.c:465: dest[i] = src[i];
      007D6B 12 38 9C         [24] 1723 	lcall	_ak820_outline_0130
      007D6E EB               [12] 1724 	mov	a,r3
      007D6F F0               [24] 1725 	movx	@dptr,a
                                   1726 ;	quantum/action_util.c:466: changed = true;
      007D70 90 0A B3         [24] 1727 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D73 74 01            [12] 1728 	mov	a,#0x01
      007D75 F0               [24] 1729 	movx	@dptr,a
      007D76                       1730 00108$:
                                   1731 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007D76 0F               [12] 1732 	inc	r7
      007D77 80 D1            [24] 1733 	sjmp	00107$
      007D79                       1734 00103$:
                                   1735 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      007D79 90 0A B3         [24] 1736 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D7C E0               [24] 1737 	movx	a,@dptr
      007D7D 60 09            [24] 1738 	jz	00109$
      007D7F 90 0D B7         [24] 1739 	mov	dptr,#_actual_keyboard_report
      007D82 75 F0 00         [24] 1740 	mov	b, #0x00
                                   1741 ;	quantum/action_util.c:477: }
      007D85 02 6A 90         [24] 1742 	ljmp	_host_keyboard_send
      007D88                       1743 00109$:
      007D88 22               [24] 1744 	ret
                                   1745 ;------------------------------------------------------------
                                   1746 ;Allocation info for local variables in function 'get_mods'
                                   1747 ;------------------------------------------------------------
                                   1748 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1749 ;	-----------------------------------------
                                   1750 ;	 function get_mods
                                   1751 ;	-----------------------------------------
      007D89                       1752 _get_mods:
      007D89 C0 07            [24] 1753 	push	ar7
                                   1754 ;	quantum/action_util.c:488: ;
      007D8B 90 09 7A         [24] 1755 	mov	dptr,#_owned_mods
      007D8E E0               [24] 1756 	movx	a,@dptr
      007D8F FF               [12] 1757 	mov	r7,a
      007D90 90 0D B5         [24] 1758 	mov	dptr,#_real_mods
      007D93 12 78 8B         [24] 1759 	lcall	_ak820_outline_0137
                                   1760 ;	quantum/action_util.c:489: }
      007D96 D0 07            [24] 1761 	pop	ar7
      007D98 22               [24] 1762 	ret
                                   1763 ;------------------------------------------------------------
                                   1764 ;Allocation info for local variables in function 'add_mods'
                                   1765 ;------------------------------------------------------------
                                   1766 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1767 ;------------------------------------------------------------
                                   1768 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1769 ;	-----------------------------------------
                                   1770 ;	 function clear_mods
                                   1771 ;	-----------------------------------------
      007D99                       1772 _clear_mods:
                                   1773 ;	quantum/action_util.c:516: real_mods = 0;
      007D99 90 0D B5         [24] 1774 	mov	dptr,#_real_mods
      007D9C E4               [12] 1775 	clr	a
      007D9D F0               [24] 1776 	movx	@dptr,a
                                   1777 ;	quantum/action_util.c:517: }
      007D9E 22               [24] 1778 	ret
                                   1779 ;------------------------------------------------------------
                                   1780 ;Allocation info for local variables in function 'get_weak_mods'
                                   1781 ;------------------------------------------------------------
                                   1782 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1783 ;	-----------------------------------------
                                   1784 ;	 function get_weak_mods
                                   1785 ;	-----------------------------------------
      007D9F                       1786 _get_weak_mods:
      007D9F C0 07            [24] 1787 	push	ar7
                                   1788 ;	quantum/action_util.c:528: ;
      007DA1 90 09 7B         [24] 1789 	mov	dptr,#_owned_weak_mods
      007DA4 E0               [24] 1790 	movx	a,@dptr
      007DA5 FF               [12] 1791 	mov	r7,a
      007DA6 90 0D B6         [24] 1792 	mov	dptr,#_weak_mods
      007DA9 12 78 8B         [24] 1793 	lcall	_ak820_outline_0137
                                   1794 ;	quantum/action_util.c:529: }
      007DAC D0 07            [24] 1795 	pop	ar7
      007DAE 22               [24] 1796 	ret
                                   1797 ;------------------------------------------------------------
                                   1798 ;Allocation info for local variables in function 'add_weak_mods'
                                   1799 ;------------------------------------------------------------
                                   1800 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1801 ;------------------------------------------------------------
                                   1802 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1803 ;	-----------------------------------------
                                   1804 ;	 function add_weak_mods
                                   1805 ;	-----------------------------------------
      007DAF                       1806 _add_weak_mods:
      007DAF E5 82            [12] 1807 	mov	a,dpl
      007DB1 90 0A B4         [24] 1808 	mov	dptr,#_add_weak_mods_mods_10000_406
      007DB4 F0               [24] 1809 	movx	@dptr,a
                                   1810 ;	quantum/action_util.c:535: weak_mods |= mods;
      007DB5 E0               [24] 1811 	movx	a,@dptr
      007DB6 FF               [12] 1812 	mov	r7,a
      007DB7 90 0D B6         [24] 1813 	mov	dptr,#_weak_mods
      007DBA E0               [24] 1814 	movx	a,@dptr
      007DBB 4F               [12] 1815 	orl	a,r7
      007DBC F0               [24] 1816 	movx	@dptr,a
                                   1817 ;	quantum/action_util.c:536: }
      007DBD 22               [24] 1818 	ret
                                   1819 ;------------------------------------------------------------
                                   1820 ;Allocation info for local variables in function 'del_weak_mods'
                                   1821 ;------------------------------------------------------------
                                   1822 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1823 ;------------------------------------------------------------
                                   1824 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1825 ;	-----------------------------------------
                                   1826 ;	 function del_weak_mods
                                   1827 ;	-----------------------------------------
      007DBE                       1828 _del_weak_mods:
      007DBE E5 82            [12] 1829 	mov	a,dpl
      007DC0 90 0A B5         [24] 1830 	mov	dptr,#_del_weak_mods_mods_10000_408
      007DC3 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      007DC4 E0               [24] 1833 	movx	a,@dptr
      007DC5 F4               [12] 1834 	cpl	a
      007DC6 FF               [12] 1835 	mov	r7,a
      007DC7 90 0D B6         [24] 1836 	mov	dptr,#_weak_mods
      007DCA E0               [24] 1837 	movx	a,@dptr
      007DCB 5F               [12] 1838 	anl	a,r7
      007DCC F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	quantum/action_util.c:543: }
      007DCD 22               [24] 1841 	ret
                                   1842 ;------------------------------------------------------------
                                   1843 ;Allocation info for local variables in function 'set_weak_mods'
                                   1844 ;------------------------------------------------------------
                                   1845 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1846 ;------------------------------------------------------------
                                   1847 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   1848 ;	-----------------------------------------
                                   1849 ;	 function clear_weak_mods
                                   1850 ;	-----------------------------------------
      007DCE                       1851 _clear_weak_mods:
                                   1852 ;	quantum/action_util.c:556: weak_mods = 0;
      007DCE 90 0D B6         [24] 1853 	mov	dptr,#_weak_mods
      007DD1 E4               [12] 1854 	clr	a
      007DD2 F0               [24] 1855 	movx	@dptr,a
                                   1856 ;	quantum/action_util.c:557: }
      007DD3 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1860 ;------------------------------------------------------------
                                   1861 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1862 ;------------------------------------------------------------
                                   1863 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1864 ;	-----------------------------------------
                                   1865 	.area CSEG    (CODE)
                                   1866 	.area CONST   (CODE)
                                   1867 	.area XINIT   (CODE)
      00BD75                       1868 __xinit__real_mods:
      00BD75 00                    1869 	.db #0x00	; 0
      00BD76                       1870 __xinit__weak_mods:
      00BD76 00                    1871 	.db #0x00	; 0
      00BD77                       1872 __xinit__actual_keyboard_report:
      00BD77 00                    1873 	.db #0x00	; 0
      00BD78 00                    1874 	.db #0x00	; 0
      00BD79 00                    1875 	.db #0x00	; 0
      00BD7A 00                    1876 	.db #0x00	; 0
      00BD7B 00                    1877 	.db #0x00	; 0
      00BD7C 00                    1878 	.db #0x00	; 0
      00BD7D 00                    1879 	.db #0x00	; 0
      00BD7E 00                    1880 	.db #0x00	; 0
      00BD7F 00                    1881 	.db 0x00
      00BD80 00                    1882 	.db 0x00
      00BD81 00                    1883 	.db 0x00
      00BD82 00                    1884 	.db 0x00
      00BD83 00                    1885 	.db 0x00
      00BD84 00                    1886 	.db 0x00
      00BD85 00                    1887 	.db 0x00
      00BD86 00                    1888 	.db 0x00
      00BD87 00                    1889 	.db 0x00
      00BD88 00                    1890 	.db 0x00
      00BD89 00                    1891 	.db 0x00
      00BD8A 00                    1892 	.db 0x00
      00BD8B 00                    1893 	.db 0x00
      00BD8C 00                    1894 	.db 0x00
      00BD8D 00                    1895 	.db 0x00
      00BD8E 00                    1896 	.db 0x00
      00BD8F 00                    1897 	.db 0x00
      00BD90 00                    1898 	.db 0x00
      00BD91 00                    1899 	.db 0x00
      00BD92 00                    1900 	.db 0x00
      00BD93 00                    1901 	.db 0x00
      00BD94 00                    1902 	.db 0x00
      00BD95 00                    1903 	.db 0x00
      00BD96 00                    1904 	.db 0x00
                                   1905 	.area CABS    (ABS,CODE)
                                   1906 
                                   1907 ; Experimental exact instruction outlining.
                                   1908 	.globl _ak820_outline_0015
                                   1909 	.globl _ak820_outline_0029
                                   1910 	.globl _ak820_outline_0056
                                   1911 	.globl _ak820_outline_0058
                                   1912 	.globl _ak820_outline_0059
                                   1913 	.globl _ak820_outline_0061
                                   1914 	.globl _ak820_outline_0063
                                   1915 	.globl _ak820_outline_0064
                                   1916 	.globl _ak820_outline_0067
                                   1917 	.globl _ak820_outline_0074
                                   1918 	.globl _ak820_outline_0111
                                   1919 	.globl _ak820_outline_0112
                                   1920 	.globl _ak820_outline_0113
                                   1921 	.globl _ak820_outline_0119
                                   1922 	.globl _ak820_outline_0120
                                   1923 	.globl _ak820_outline_0122
                                   1924 	.globl _ak820_outline_0123
                                   1925 	.globl _ak820_outline_0129
                                   1926 	.globl _ak820_outline_0130
                                   1927 	.globl _ak820_outline_0135
                                   1928 	.globl _ak820_outline_0137
                                   1929 	.globl _ak820_outline_0153
                                   1930 	.globl _ak820_outline_0154
                                   1931 	.globl _ak820_outline_0159
                                   1932 	.globl _ak820_outline_0166
                                   1933 	.globl _ak820_outline_0182
                                   1934 	.globl _ak820_outline_0183
                                   1935 
                                   1936 	.area CSEG (CODE)
                                   1937 ; function ak820_outline_0029
      007DD4                       1938 _ak820_outline_0029:
      007DD4 EF               [12] 1939 	mov	a,r7
      007DD5 24 8C            [12] 1940 	add	a,#_key_refs
      007DD7 FD               [12] 1941 	mov	r5,a
      007DD8 E4               [12] 1942 	clr	a
      007DD9 34 09            [12] 1943 	addc	a,#(_key_refs>>8)
      007DDB FE               [12] 1944 	mov	r6,a
      007DDC 8D 82            [24] 1945 	mov	dpl,r5
      007DDE 8E 83            [24] 1946 	mov	dph,r6
      007DE0 E0               [24] 1947 	movx	a,@dptr
      007DE1 22               [24] 1948 	ret
                                   1949 
                                   1950 	.area CSEG (CODE)
                                   1951 ; function ak820_outline_0059
      007DE2                       1952 _ak820_outline_0059:
      007DE2 F0               [24] 1953 	movx	@dptr,a
      007DE3 90 0D B7         [24] 1954 	mov	dptr,#_actual_keyboard_report
      007DE6 75 F0 00         [24] 1955 	mov	b,#0x00
      007DE9 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0064
      007DEA                       1960 _ak820_outline_0064:
      007DEA 89 82            [24] 1961 	mov	dpl,r1
      007DEC 8A 83            [24] 1962 	mov	dph,r2
      007DEE E8               [12] 1963 	mov	a,r0
      007DEF F0               [24] 1964 	movx	@dptr,a
      007DF0 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0067
      007DF1                       1969 _ak820_outline_0067:
      007DF1 24 67            [12] 1970 	add	a,#_usage_order
      007DF3 F5 82            [12] 1971 	mov	dpl,a
      007DF5 E4               [12] 1972 	clr	a
      007DF6 34 0A            [12] 1973 	addc	a,#(_usage_order>>8)
      007DF8 F5 83            [12] 1974 	mov	dph,a
      007DFA 22               [24] 1975 	ret
                                   1976 
                                   1977 	.area CSEG (CODE)
                                   1978 ; function ak820_outline_0074
      007DFB                       1979 _ak820_outline_0074:
      007DFB EB               [12] 1980 	mov	a,r3
      007DFC 24 49            [12] 1981 	add	a,#_usage_refs
      007DFE F9               [12] 1982 	mov	r1,a
      007DFF E4               [12] 1983 	clr	a
      007E00 34 0A            [12] 1984 	addc	a,#(_usage_refs>>8)
      007E02 FA               [12] 1985 	mov	r2,a
      007E03 89 82            [24] 1986 	mov	dpl,r1
      007E05 8A 83            [24] 1987 	mov	dph,r2
      007E07 E0               [24] 1988 	movx	a,@dptr
      007E08 F8               [12] 1989 	mov	r0,a
      007E09 22               [24] 1990 	ret
                                   1991 
                                   1992 	.area CSEG (CODE)
                                   1993 ; function ak820_outline_0111
      007E0A                       1994 _ak820_outline_0111:
      007E0A F0               [24] 1995 	movx	@dptr,a
      007E0B E0               [24] 1996 	movx	a,@dptr
      007E0C FF               [12] 1997 	mov	r7,a
      007E0D 90 09 84         [24] 1998 	mov	dptr,#_change_owned_PARM_2
      007E10 22               [24] 1999 	ret
                                   2000 
                                   2001 	.area CSEG (CODE)
                                   2002 ; function ak820_outline_0119
      007E11                       2003 _ak820_outline_0119:
      007E11 8D 82            [24] 2004 	mov	dpl,r5
      007E13 8E 83            [24] 2005 	mov	dph,r6
      007E15 F0               [24] 2006 	movx	@dptr,a
      007E16 22               [24] 2007 	ret
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0123
      007E17                       2011 _ak820_outline_0123:
      007E17 24 67            [12] 2012 	add	a,#_usage_order
      007E19 F5 82            [12] 2013 	mov	dpl,a
      007E1B EF               [12] 2014 	mov	a,r7
      007E1C 34 0A            [12] 2015 	addc	a,#(_usage_order>>8)
      007E1E F5 83            [12] 2016 	mov	dph,a
      007E20 E0               [24] 2017 	movx	a,@dptr
      007E21 22               [24] 2018 	ret
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0129
      007E22                       2022 _ak820_outline_0129:
      007E22 F0               [24] 2023 	movx	@dptr,a
      007E23 E0               [24] 2024 	movx	a,@dptr
      007E24 FF               [12] 2025 	mov	r7,a
      007E25 90 09 80         [24] 2026 	mov	dptr,#_ak820_macro_change_PARM_2
      007E28 F0               [24] 2027 	movx	@dptr,a
      007E29 90 09 81         [24] 2028 	mov	dptr,#_ak820_macro_change_PARM_3
      007E2C 22               [24] 2029 	ret
                                   2030 
                                   2031 	.area CSEG (CODE)
                                   2032 ; function ak820_outline_0183
      007E2D                       2033 _ak820_outline_0183:
      007E2D 8D 82            [24] 2034 	mov	dpl,r5
      007E2F 8F 83            [24] 2035 	mov	dph,r7
      007E31 22               [24] 2036 	ret
