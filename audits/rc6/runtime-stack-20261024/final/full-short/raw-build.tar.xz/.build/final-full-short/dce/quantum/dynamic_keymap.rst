                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000024                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000024                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000ADC                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000ADC                        628 	.ds 1
      000ADD                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000ADD                        630 	.ds 1
      000ADE                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000ADE                        632 	.ds 1
      000ADF                        633 _dynamic_keymap_get_keycode_PARM_2:
      000ADF                        634 	.ds 1
      000AE0                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AE0                        636 	.ds 1
      000AE1                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000AE1                        638 	.ds 1
      000AE2                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AE2                        640 	.ds 1
      000AE3                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AE3                        642 	.ds 1
      000AE4                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AE4                        644 	.ds 2
      000AE6                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000AE6                        646 	.ds 1
      000AE7                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AE7                        648 	.ds 1
      000AE8                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000AE8                        650 	.ds 1
      000AE9                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AE9                        652 	.ds 1
      000AEA                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AEA                        654 	.ds 1
      000AEB                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000AEB                        656 	.ds 1
      000AEC                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AEC                        658 	.ds 1
      000AED                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AED                        660 	.ds 1
      000AEE                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AEE                        662 	.ds 2
      000AF0                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000AF0                        664 	.ds 1
      000AF1                        665 _dynamic_keymap_get_combo_PARM_2:
      000AF1                        666 	.ds 3
      000AF4                        667 _dynamic_keymap_get_combo_index_10000_384:
      000AF4                        668 	.ds 1
      000AF5                        669 _dynamic_keymap_set_combo_PARM_2:
      000AF5                        670 	.ds 3
      000AF8                        671 _dynamic_keymap_set_combo_index_10000_390:
      000AF8                        672 	.ds 1
      000AF9                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000AF9                        674 	.ds 10
      000B03                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000B03                        676 	.ds 1
      000B04                        677 _dynamic_keymap_reset_combo_10001_407:
      000B04                        678 	.ds 10
      000B0E                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B0E                        680 	.ds 2
      000B10                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B10                        682 	.ds 2
      000B12                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B12                        684 	.ds 2
      000B14                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B14                        686 	.ds 3
      000B17                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B17                        688 	.ds 2
      000B19                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B19                        690 	.ds 1
      000B1A                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B1A                        692 	.ds 2
      000B1C                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B1C                        694 	.ds 3
      000B1F                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B1F                        696 	.ds 2
      000B21                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B21                        698 	.ds 2
      000B23                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B23                        700 	.ds 3
      000B26                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B26                        702 	.ds 2
      000B28                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B28                        704 	.ds 1
      000B29                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B29                        706 	.ds 1
      000B2A                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B2A                        708 	.ds 1
      000B2B                        709 _keycode_at_keymap_location_PARM_2:
      000B2B                        710 	.ds 1
      000B2C                        711 _keycode_at_keymap_location_PARM_3:
      000B2C                        712 	.ds 1
      000B2D                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B2D                        714 	.ds 1
      000B2E                        715 _keycode_at_encodermap_location_PARM_2:
      000B2E                        716 	.ds 1
      000B2F                        717 _keycode_at_encodermap_location_PARM_3:
      000B2F                        718 	.ds 1
      000B30                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B30                        720 	.ds 1
      000B31                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B31                        722 	.ds 2
      000B33                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B33                        724 	.ds 3
      000B36                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000B36                        726 	.ds 2
      000B38                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B38                        728 	.ds 2
      000B3A                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B3A                        730 	.ds 3
      000B3D                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000B3D                        732 	.ds 2
      000B3F                        733 _decode_keycode_kc_10000_454:
      000B3F                        734 	.ds 2
      000B41                        735 _dynamic_keymap_macro_send_id_10000_457:
      000B41                        736 	.ds 1
      000B42                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000B42                        738 	.ds 1
      000B43                        739 _dynamic_keymap_macro_send_p_10001_463:
      000B43                        740 	.ds 2
      000B45                        741 _dynamic_keymap_macro_send_data_10003_470:
      000B45                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008303                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008303 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      008306 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008307                        810 _dynamic_keymap_key_to_eeprom_address:
      008307 E5 82            [12]  811 	mov	a,dpl
      008309 90 0A DE         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      00830C F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      00830D E0               [24]  815 	movx	a,@dptr
      00830E FF               [12]  816 	mov	r7,a
      00830F 7E 00            [12]  817 	mov	r6,#0x00
      008311 74 40            [12]  818 	mov	a,#0x40
      008313 12 43 54         [24]  819 	lcall	_ak820_outline_0139
      008316 7D 00            [12]  820 	mov	r5,#0x00
      008318 90 0A DC         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00831B E0               [24]  822 	movx	a,@dptr
      00831C 75 F0 10         [24]  823 	mov	b,#0x10
      00831F A4               [48]  824 	mul	ab
      008320 2E               [12]  825 	add	a, r6
      008321 FE               [12]  826 	mov	r6,a
      008322 EF               [12]  827 	mov	a,r7
      008323 35 F0            [12]  828 	addc	a, b
      008325 FF               [12]  829 	mov	r7,a
      008326 90 0A DD         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008329 E0               [24]  831 	movx	a,@dptr
      00832A 7C 00            [12]  832 	mov	r4,#0x00
      00832C 25 E0            [12]  833 	add	a,acc
      00832E FB               [12]  834 	mov	r3,a
      00832F EC               [12]  835 	mov	a,r4
      008330 33               [12]  836 	rlc	a
      008331 FC               [12]  837 	mov	r4,a
      008332 EB               [12]  838 	mov	a,r3
      008333 2E               [12]  839 	add	a, r6
      008334 FE               [12]  840 	mov	r6,a
      008335 EC               [12]  841 	mov	a,r4
      008336 3F               [12]  842 	addc	a, r7
      008337 FF               [12]  843 	mov	r7,a
      008338 12 6F 38         [24]  844 	lcall	_ak820_outline_0050
                                    845 ;	quantum/dynamic_keymap.c:184: }
      00833B 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      00833C                        860 _dynamic_keymap_get_keycode:
      00833C E5 82            [12]  861 	mov	a,dpl
      00833E 90 0A E1         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      008341 F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008342 E0               [24]  865 	movx	a,@dptr
      008343 FF               [12]  866 	mov	r7,a
      008344 BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      008347                        868 00121$:
      008347 50 14            [24]  869 	jnc	00101$
      008349 90 0A DF         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00834C E0               [24]  871 	movx	a,@dptr
      00834D FE               [12]  872 	mov	r6,a
      00834E BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      008351                        874 00123$:
      008351 50 0A            [24]  875 	jnc	00101$
      008353 90 0A E0         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008356 E0               [24]  877 	movx	a,@dptr
      008357 FD               [12]  878 	mov	r5,a
      008358 BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      00835B                        880 00125$:
      00835B 40 04            [24]  881 	jc	00102$
      00835D                        882 00101$:
      00835D 90 00 00         [24]  883 	mov	dptr,#0x0000
      008360 22               [24]  884 	ret
      008361                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008361 12 8D 7C         [24]  887 	lcall	_ak820_outline_0100
      008364 71 07            [12]  888 	acall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      008366 12 8D 90         [24]  890 	lcall	_ak820_outline_0118
      008369 12 40 67         [24]  891 	lcall	_eeprom_read_byte
      00836C AB 82            [24]  892 	mov	r3,dpl
      00836E 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      008370 0D               [12]  895 	inc	r5
      008371 BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      008374 0E               [12]  897 	inc	r6
      008375                        898 00127$:
      008375 12 6D 17         [24]  899 	lcall	_ak820_outline_0059
      008378 12 40 67         [24]  900 	lcall	_eeprom_read_byte
      00837B AF 82            [24]  901 	mov	r7, dpl
      00837D 7E 00            [12]  902 	mov	r6,#0x00
      00837F EF               [12]  903 	mov	a,r7
      008380 42 04            [12]  904 	orl	ar4,a
      008382 EE               [12]  905 	mov	a,r6
      008383 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      008385 12 43 7B         [24]  908 	lcall	_ak820_outline_0186
                                    909 ;	quantum/dynamic_keymap.c:193: }
      008388 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      008389                        924 _dynamic_keymap_set_keycode:
      008389 E5 82            [12]  925 	mov	a,dpl
      00838B 90 0A E6         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      00838E F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00838F E0               [24]  929 	movx	a,@dptr
      008390 FF               [12]  930 	mov	r7,a
      008391 BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      008394                        932 00121$:
      008394 50 14            [24]  933 	jnc	00101$
      008396 90 0A E2         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008399 E0               [24]  935 	movx	a,@dptr
      00839A FE               [12]  936 	mov	r6,a
      00839B BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      00839E                        938 00123$:
      00839E 50 0A            [24]  939 	jnc	00101$
      0083A0 90 0A E3         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0083A3 E0               [24]  941 	movx	a,@dptr
      0083A4 FD               [12]  942 	mov	r5,a
      0083A5 BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      0083A8                        944 00125$:
      0083A8 40 01            [24]  945 	jc	00102$
      0083AA                        946 00101$:
      0083AA 22               [24]  947 	ret
      0083AB                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0083AB 12 8D 7C         [24]  950 	lcall	_ak820_outline_0100
      0083AE 71 07            [12]  951 	acall	_dynamic_keymap_key_to_eeprom_address
      0083B0 12 8D 90         [24]  952 	lcall	_ak820_outline_0118
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0083B3 90 0A E4         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0083B6 E0               [24]  955 	movx	a,@dptr
      0083B7 FB               [12]  956 	mov	r3,a
      0083B8 A3               [24]  957 	inc	dptr
      0083B9 E0               [24]  958 	movx	a,@dptr
      0083BA 90 06 9B         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      0083BD 12 4E DC         [24]  960 	lcall	_ak820_outline_0034
      0083C0 12 4D C7         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0083C3 0D               [12]  963 	inc	r5
      0083C4 BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      0083C7 0E               [12]  965 	inc	r6
      0083C8                        966 00127$:
      0083C8 90 06 9B         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      0083CB EB               [12]  968 	mov	a,r3
      0083CC 12 4E DC         [24]  969 	lcall	_ak820_outline_0034
                                    970 ;	quantum/dynamic_keymap.c:201: }
      0083CF 02 4D C7         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      0083D2                        982 _dynamic_keymap_encoder_to_eeprom_address:
      0083D2 E5 82            [12]  983 	mov	a,dpl
      0083D4 90 0A E8         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      0083D7 F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0083D8 E0               [24]  987 	movx	a,@dptr
      0083D9 75 F0 04         [24]  988 	mov	b,#0x04
      0083DC A4               [48]  989 	mul	ab
      0083DD 24 40            [12]  990 	add	a, #0x40
      0083DF FD               [12]  991 	mov	r5,a
      0083E0 74 06            [12]  992 	mov	a,#0x06
      0083E2 35 F0            [12]  993 	addc	a, b
      0083E4 FE               [12]  994 	mov	r6,a
      0083E5 7F 00            [12]  995 	mov	r7,#0x00
      0083E7 90 0A E7         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0083EA E0               [24]  997 	movx	a,@dptr
      0083EB 75 F0 04         [24]  998 	mov	b,#0x04
      0083EE A4               [48]  999 	mul	ab
      0083EF 2D               [12] 1000 	add	a, r5
      0083F0 FD               [12] 1001 	mov	r5,a
      0083F1 EE               [12] 1002 	mov	a,r6
      0083F2 35 F0            [12] 1003 	addc	a, b
      0083F4 FE               [12] 1004 	mov	r6,a
      0083F5 12 6D 17         [24] 1005 	lcall	_ak820_outline_0059
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      0083F8 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      0083F9                       1021 _dynamic_keymap_get_encoder:
      0083F9 E5 82            [12] 1022 	mov	a,dpl
      0083FB 90 0A EB         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      0083FE F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0083FF E0               [24] 1026 	movx	a,@dptr
      008400 FF               [12] 1027 	mov	r7,a
      008401 BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      008404                       1029 00131$:
      008404 50 0A            [24] 1030 	jnc	00101$
      008406 90 0A E9         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008409 E0               [24] 1032 	movx	a,@dptr
      00840A FE               [12] 1033 	mov	r6,a
      00840B BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      00840E                       1035 00133$:
      00840E 40 04            [24] 1036 	jc	00102$
      008410                       1037 00101$:
      008410 90 00 00         [24] 1038 	mov	dptr,#0x0000
      008413 22               [24] 1039 	ret
      008414                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008414 90 0A E7         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008417 E4               [12] 1043 	clr	a
      008418 F0               [24] 1044 	movx	@dptr,a
      008419 8F 82            [24] 1045 	mov	dpl, r7
      00841B 71 D2            [12] 1046 	acall	_dynamic_keymap_encoder_to_eeprom_address
      00841D 12 8D 90         [24] 1047 	lcall	_ak820_outline_0118
                                   1048 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008420 90 0A EA         [24] 1049 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008423 E0               [24] 1050 	movx	a,@dptr
      008424 FC               [12] 1051 	mov	r4,a
      008425 E0               [24] 1052 	movx	a,@dptr
      008426 60 04            [24] 1053 	jz	00106$
      008428 7B 00            [12] 1054 	mov	r3,#0x00
      00842A 80 02            [24] 1055 	sjmp	00107$
      00842C                       1056 00106$:
      00842C 7B 02            [12] 1057 	mov	r3,#0x02
      00842E                       1058 00107$:
      00842E EB               [12] 1059 	mov	a,r3
      00842F 12 76 60         [24] 1060 	lcall	_ak820_outline_0013
      008432 12 40 67         [24] 1061 	lcall	_eeprom_read_byte
      008435 AA 82            [24] 1062 	mov	r2,dpl
      008437 7B 00            [12] 1063 	mov	r3,#0x00
                                   1064 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008439 EC               [12] 1065 	mov	a,r4
      00843A 60 04            [24] 1066 	jz	00108$
      00843C 7C 00            [12] 1067 	mov	r4,#0x00
      00843E 80 02            [24] 1068 	sjmp	00109$
      008440                       1069 00108$:
      008440 7C 02            [12] 1070 	mov	r4,#0x02
      008442                       1071 00109$:
      008442 EC               [12] 1072 	mov	a,r4
      008443 12 38 AE         [24] 1073 	lcall	_ak820_outline_0163
      008446 0D               [12] 1074 	inc	r5
      008447 BD 00 01         [24] 1075 	cjne	r5,#0x00,00137$
      00844A 0E               [12] 1076 	inc	r6
      00844B                       1077 00137$:
      00844B 12 6D 17         [24] 1078 	lcall	_ak820_outline_0059
      00844E 12 40 67         [24] 1079 	lcall	_eeprom_read_byte
      008451 AF 82            [24] 1080 	mov	r7, dpl
      008453 7E 00            [12] 1081 	mov	r6,#0x00
      008455 EF               [12] 1082 	mov	a,r7
      008456 42 03            [12] 1083 	orl	ar3,a
      008458 EE               [12] 1084 	mov	a,r6
      008459 42 02            [12] 1085 	orl	ar2,a
                                   1086 ;	quantum/dynamic_keymap.c:214: return keycode;
      00845B 8B 82            [24] 1087 	mov	dpl, r3
      00845D 8A 83            [24] 1088 	mov	dph, r2
                                   1089 ;	quantum/dynamic_keymap.c:215: }
      00845F 22               [24] 1090 	ret
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1093 ;------------------------------------------------------------
                                   1094 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1095 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1096 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1097 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1098 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1099 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1100 ;------------------------------------------------------------
                                   1101 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1102 ;	-----------------------------------------
                                   1103 ;	 function dynamic_keymap_set_encoder
                                   1104 ;	-----------------------------------------
      008460                       1105 _dynamic_keymap_set_encoder:
      008460 E5 82            [12] 1106 	mov	a,dpl
      008462 90 0A F0         [24] 1107 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      008465 F0               [24] 1108 	movx	@dptr,a
                                   1109 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008466 E0               [24] 1110 	movx	a,@dptr
      008467 FF               [12] 1111 	mov	r7,a
      008468 BF 06 00         [24] 1112 	cjne	r7,#0x06,00131$
      00846B                       1113 00131$:
      00846B 50 0A            [24] 1114 	jnc	00101$
      00846D 90 0A EC         [24] 1115 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008470 E0               [24] 1116 	movx	a,@dptr
      008471 FE               [12] 1117 	mov	r6,a
      008472 BE 01 00         [24] 1118 	cjne	r6,#0x01,00133$
      008475                       1119 00133$:
      008475 40 01            [24] 1120 	jc	00102$
      008477                       1121 00101$:
      008477 22               [24] 1122 	ret
      008478                       1123 00102$:
                                   1124 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008478 90 0A E7         [24] 1125 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00847B E4               [12] 1126 	clr	a
      00847C F0               [24] 1127 	movx	@dptr,a
      00847D 8F 82            [24] 1128 	mov	dpl, r7
      00847F 71 D2            [12] 1129 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008481 12 8D 90         [24] 1130 	lcall	_ak820_outline_0118
                                   1131 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008484 90 0A ED         [24] 1132 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008487 E0               [24] 1133 	movx	a,@dptr
      008488 FC               [12] 1134 	mov	r4,a
      008489 E0               [24] 1135 	movx	a,@dptr
      00848A 60 04            [24] 1136 	jz	00106$
      00848C 7B 00            [12] 1137 	mov	r3,#0x00
      00848E 80 02            [24] 1138 	sjmp	00107$
      008490                       1139 00106$:
      008490 7B 02            [12] 1140 	mov	r3,#0x02
      008492                       1141 00107$:
      008492 EB               [12] 1142 	mov	a,r3
      008493 12 8D A2         [24] 1143 	lcall	_ak820_outline_0138
      008496 8F 03            [24] 1144 	mov	ar3,r7
      008498 90 0A EE         [24] 1145 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00849B E0               [24] 1146 	movx	a,@dptr
      00849C F5 29            [12] 1147 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      00849E A3               [24] 1148 	inc	dptr
      00849F E0               [24] 1149 	movx	a,@dptr
      0084A0 F5 2A            [12] 1150 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0084A2 90 06 9B         [24] 1151 	mov	dptr,#_eeprom_update_byte_PARM_2
      0084A5 F0               [24] 1152 	movx	@dptr,a
      0084A6 12 43 76         [24] 1153 	lcall	_ak820_outline_0185
      0084A9 8B F0            [24] 1154 	mov	b, r3
      0084AB 12 4D C7         [24] 1155 	lcall	_eeprom_update_byte
                                   1156 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0084AE EC               [12] 1157 	mov	a,r4
      0084AF 60 04            [24] 1158 	jz	00108$
      0084B1 7C 00            [12] 1159 	mov	r4,#0x00
      0084B3 80 02            [24] 1160 	sjmp	00109$
      0084B5                       1161 00108$:
      0084B5 7C 02            [12] 1162 	mov	r4,#0x02
      0084B7                       1163 00109$:
      0084B7 EC               [12] 1164 	mov	a,r4
      0084B8 12 38 AE         [24] 1165 	lcall	_ak820_outline_0163
      0084BB 0D               [12] 1166 	inc	r5
      0084BC BD 00 01         [24] 1167 	cjne	r5,#0x00,00137$
      0084BF 0E               [12] 1168 	inc	r6
      0084C0                       1169 00137$:
      0084C0 90 06 9B         [24] 1170 	mov	dptr,#_eeprom_update_byte_PARM_2
      0084C3 E5 29            [12] 1171 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0084C5 12 4E DC         [24] 1172 	lcall	_ak820_outline_0034
                                   1173 ;	quantum/dynamic_keymap.c:223: }
      0084C8 02 4D C7         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      0084CB                       1189 _dynamic_keymap_get_combo:
      0084CB E5 82            [12] 1190 	mov	a,dpl
      0084CD 90 0A F4         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      0084D0 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0084D1 90 0A F1         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0084D4 12 38 34         [24] 1195 	lcall	_ak820_outline_0052
                                   1196 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      0084D7 90 0A F4         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      0084DA E0               [24] 1198 	movx	a,@dptr
      0084DB FD               [12] 1199 	mov	r5,a
      0084DC BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      0084DF                       1201 00132$:
      0084DF 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:275: return -1;
      0084E1 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      0084E4 22               [24] 1205 	ret
      0084E5                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0084E5 12 8D 68         [24] 1208 	lcall	_ak820_outline_0082
                                   1209 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      0084E8 8E 02            [24] 1210 	mov	ar2,r6
      0084EA 8F 03            [24] 1211 	mov	ar3,r7
      0084EC 90 05 85         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0084EF 12 38 51         [24] 1213 	lcall	_ak820_outline_0072
      0084F2 E4               [12] 1214 	clr	a
      0084F3 A3               [24] 1215 	inc	dptr
      0084F4 F0               [24] 1216 	movx	@dptr,a
      0084F5 90 05 88         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0084F8 12 8D 89         [24] 1218 	lcall	_ak820_outline_0113
      0084FB 12 38 9F         [24] 1219 	lcall	_ak820_outline_0145
      0084FE C0 07            [24] 1220 	push	ar7
      008500 C0 06            [24] 1221 	push	ar6
      008502 12 40 A2         [24] 1222 	lcall	_ak820_eeprom_read_block_xdata
      008505 D0 06            [24] 1223 	pop	ar6
      008507 D0 07            [24] 1224 	pop	ar7
                                   1225 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008509 74 04            [12] 1226 	mov	a,#0x04
      00850B 12 48 5A         [24] 1227 	lcall	_ak820_outline_0033
      00850E FA               [12] 1228 	mov	r2,a
      00850F A3               [24] 1229 	inc	dptr
      008510 E0               [24] 1230 	movx	a,@dptr
      008511 FB               [12] 1231 	mov	r3,a
      008512 BA 20 13         [24] 1232 	cjne	r2,#0x20,00108$
      008515 BB 08 10         [24] 1233 	cjne	r3,#0x08,00108$
      008518 74 06            [12] 1234 	mov	a,#0x06
      00851A 12 38 24         [24] 1235 	lcall	_ak820_outline_0022
      00851D 12 43 3D         [24] 1236 	lcall	_ak820_outline_0105
      008520 BA 01 05         [24] 1237 	cjne	r2,#0x01,00136$
      008523 BB 00 02         [24] 1238 	cjne	r3,#0x00,00136$
      008526 80 05            [24] 1239 	sjmp	00109$
      008528                       1240 00136$:
      008528                       1241 00108$:
      008528 75 2B 00         [24] 1242 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      00852B 80 03            [24] 1243 	sjmp	00110$
      00852D                       1244 00109$:
      00852D 75 2B 01         [24] 1245 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008530                       1246 00110$:
                                   1247 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      008530 74 06            [12] 1248 	mov	a,#0x06
      008532 12 38 24         [24] 1249 	lcall	_ak820_outline_0022
      008535 E4               [12] 1250 	clr	a
      008536 F0               [24] 1251 	movx	@dptr,a
      008537 A3               [24] 1252 	inc	dptr
      008538 12 38 69         [24] 1253 	lcall	_ak820_outline_0103
      00853B F0               [24] 1254 	movx	@dptr,a
      00853C A3               [24] 1255 	inc	dptr
      00853D F0               [24] 1256 	movx	@dptr,a
                                   1257 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      00853E E5 2B            [12] 1258 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008540 60 12            [24] 1259 	jz	00103$
      008542 12 38 7F         [24] 1260 	lcall	_ak820_outline_0120
      008545 C0 07            [24] 1261 	push	ar7
      008547 C0 06            [24] 1262 	push	ar6
      008549 12 34 D0         [24] 1263 	lcall	_ak820_combo_valid
      00854C E5 82            [12] 1264 	mov	a, dpl
      00854E D0 06            [24] 1265 	pop	ar6
      008550 D0 07            [24] 1266 	pop	ar7
      008552 70 13            [24] 1267 	jnz	00104$
      008554                       1268 00103$:
      008554 7D 00            [12] 1269 	mov	r5,#0x00
      008556 90 0D AC         [24] 1270 	mov	dptr,#_memset_PARM_2
      008559 E4               [12] 1271 	clr	a
      00855A F0               [24] 1272 	movx	@dptr,a
      00855B 90 0D AD         [24] 1273 	mov	dptr,#_memset_PARM_3
      00855E 12 8D 89         [24] 1274 	lcall	_ak820_outline_0113
      008561 12 6F 38         [24] 1275 	lcall	_ak820_outline_0050
      008564 12 B7 2B         [24] 1276 	lcall	_memset
      008567                       1277 00104$:
                                   1278 ;	quantum/dynamic_keymap.c:289: return 0;
      008567 90 00 00         [24] 1279 	mov	dptr,#0x0000
                                   1280 ;	quantum/dynamic_keymap.c:290: }
      00856A 22               [24] 1281 	ret
                                   1282 ;------------------------------------------------------------
                                   1283 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1284 ;------------------------------------------------------------
                                   1285 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1286 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1287 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1288 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1289 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1290 ;------------------------------------------------------------
                                   1291 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1292 ;	-----------------------------------------
                                   1293 ;	 function dynamic_keymap_set_combo
                                   1294 ;	-----------------------------------------
      00856B                       1295 _dynamic_keymap_set_combo:
      00856B E5 82            [12] 1296 	mov	a,dpl
      00856D 90 0A F8         [24] 1297 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008570 F0               [24] 1298 	movx	@dptr,a
                                   1299 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008571 90 0A F5         [24] 1300 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008574 12 37 E7         [24] 1301 	lcall	_ak820_outline_0005
                                   1302 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008577 C0 07            [24] 1303 	push	ar7
      008579 C0 06            [24] 1304 	push	ar6
      00857B 12 34 D0         [24] 1305 	lcall	_ak820_combo_valid
      00857E E5 82            [12] 1306 	mov	a, dpl
      008580 D0 06            [24] 1307 	pop	ar6
      008582 D0 07            [24] 1308 	pop	ar7
      008584 60 07            [24] 1309 	jz	00101$
      008586 12 3E 0D         [24] 1310 	lcall	_ak820_nvm_ok
      008589 E5 82            [12] 1311 	mov	a, dpl
      00858B 70 04            [24] 1312 	jnz	00102$
      00858D                       1313 00101$:
      00858D 90 FF FF         [24] 1314 	mov	dptr,#0xffff
      008590 22               [24] 1315 	ret
      008591                       1316 00102$:
                                   1317 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008591 90 0A F8         [24] 1318 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008594 E0               [24] 1319 	movx	a,@dptr
      008595 FD               [12] 1320 	mov	r5,a
      008596 BD 08 00         [24] 1321 	cjne	r5,#0x08,00133$
      008599                       1322 00133$:
      008599 40 04            [24] 1323 	jc	00105$
                                   1324 ;	quantum/dynamic_keymap.c:302: return -1;
      00859B 90 FF FF         [24] 1325 	mov	dptr,#0xffff
      00859E 22               [24] 1326 	ret
      00859F                       1327 00105$:
                                   1328 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00859F 12 8D 68         [24] 1329 	lcall	_ak820_outline_0082
                                   1330 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      0085A2 C0 07            [24] 1331 	push	ar7
      0085A4 C0 06            [24] 1332 	push	ar6
      0085A6 C0 05            [24] 1333 	push	ar5
      0085A8 C0 04            [24] 1334 	push	ar4
      0085AA 12 76 1A         [24] 1335 	lcall	_clear_keyboard
      0085AD D0 04            [24] 1336 	pop	ar4
      0085AF D0 05            [24] 1337 	pop	ar5
      0085B1 D0 06            [24] 1338 	pop	ar6
      0085B3 D0 07            [24] 1339 	pop	ar7
                                   1340 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      0085B5 90 0D A4         [24] 1341 	mov	dptr,#___memcpy_PARM_2
      0085B8 12 48 6D         [24] 1342 	lcall	_ak820_outline_0060
      0085BB E4               [12] 1343 	clr	a
      0085BC A3               [24] 1344 	inc	dptr
      0085BD F0               [24] 1345 	movx	@dptr,a
      0085BE 90 0D A7         [24] 1346 	mov	dptr,#___memcpy_PARM_3
      0085C1 12 8D 89         [24] 1347 	lcall	_ak820_outline_0113
      0085C4 90 0A F9         [24] 1348 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      0085C7 F5 F0            [12] 1349 	mov	b,a
      0085C9 C0 05            [24] 1350 	push	ar5
      0085CB C0 04            [24] 1351 	push	ar4
      0085CD 12 B6 B5         [24] 1352 	lcall	___memcpy
      0085D0 D0 04            [24] 1353 	pop	ar4
      0085D2 D0 05            [24] 1354 	pop	ar5
                                   1355 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      0085D4 90 0A FD         [24] 1356 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      0085D7 74 20            [12] 1357 	mov	a,#0x20
      0085D9 F0               [24] 1358 	movx	@dptr,a
      0085DA 74 08            [12] 1359 	mov	a,#0x08
      0085DC A3               [24] 1360 	inc	dptr
      0085DD F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      0085DE 90 0A FF         [24] 1363 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      0085E1 74 01            [12] 1364 	mov	a,#0x01
      0085E3 12 38 8F         [24] 1365 	lcall	_ak820_outline_0136
                                   1366 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      0085E6 90 05 8E         [24] 1367 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0085E9 12 38 51         [24] 1368 	lcall	_ak820_outline_0072
      0085EC E4               [12] 1369 	clr	a
      0085ED A3               [24] 1370 	inc	dptr
      0085EE F0               [24] 1371 	movx	@dptr,a
      0085EF 90 05 91         [24] 1372 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0085F2 12 8D 89         [24] 1373 	lcall	_ak820_outline_0113
      0085F5 90 0A F9         [24] 1374 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      0085F8 12 41 2E         [24] 1375 	lcall	_ak820_eeprom_write_block_xdata
                                   1376 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      0085FB 12 3E 1C         [24] 1377 	lcall	_ak820_nvm_flush
                                   1378 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      0085FE 12 3E 0D         [24] 1379 	lcall	_ak820_nvm_ok
      008601 E5 82            [12] 1380 	mov	a, dpl
      008603 70 04            [24] 1381 	jnz	00107$
      008605 90 FF FF         [24] 1382 	mov	dptr,#0xffff
      008608 22               [24] 1383 	ret
      008609                       1384 00107$:
                                   1385 ;	quantum/dynamic_keymap.c:320: return 0;
      008609 90 00 00         [24] 1386 	mov	dptr,#0x0000
                                   1387 ;	quantum/dynamic_keymap.c:321: }
      00860C 22               [24] 1388 	ret
                                   1389 ;------------------------------------------------------------
                                   1390 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1391 ;------------------------------------------------------------
                                   1392 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1393 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1394 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1395 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1396 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1397 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1398 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1399 ;------------------------------------------------------------
                                   1400 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1401 ;	-----------------------------------------
                                   1402 ;	 function dynamic_keymap_reset
                                   1403 ;	-----------------------------------------
      00860D                       1404 _dynamic_keymap_reset:
                                   1405 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      00860D 90 0E 24         [24] 1406 	mov	dptr,#_vial_unlocked
      008610 E0               [24] 1407 	movx	a,@dptr
      008611 90 0B 03         [24] 1408 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008614 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      008615 90 0E 24         [24] 1411 	mov	dptr,#_vial_unlocked
      008618 74 01            [12] 1412 	mov	a,#0x01
      00861A F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00861B 7F 00            [12] 1415 	mov	r7,#0x00
      00861D                       1416 00116$:
      00861D BF 06 00         [24] 1417 	cjne	r7,#0x06,00198$
      008620                       1418 00198$:
      008620 40 02            [24] 1419 	jc	00199$
      008622 C1 CB            [12] 1420 	ajmp	00104$
      008624                       1421 00199$:
                                   1422 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008624 7E 00            [12] 1423 	mov	r6,#0x00
      008626                       1424 00110$:
      008626 BE 10 00         [24] 1425 	cjne	r6,#0x10,00200$
      008629                       1426 00200$:
      008629 50 4C            [24] 1427 	jnc	00102$
                                   1428 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      00862B 7D 00            [12] 1429 	mov	r5,#0x00
      00862D                       1430 00107$:
      00862D BD 08 00         [24] 1431 	cjne	r5,#0x08,00202$
      008630                       1432 00202$:
      008630 50 42            [24] 1433 	jnc	00111$
                                   1434 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008632 90 0B 9F         [24] 1435 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008635 EE               [12] 1436 	mov	a,r6
      008636 F0               [24] 1437 	movx	@dptr,a
      008637 90 0B A0         [24] 1438 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      00863A ED               [12] 1439 	mov	a,r5
      00863B F0               [24] 1440 	movx	@dptr,a
      00863C 8F 82            [24] 1441 	mov	dpl, r7
      00863E C0 07            [24] 1442 	push	ar7
      008640 C0 06            [24] 1443 	push	ar6
      008642 C0 05            [24] 1444 	push	ar5
      008644 12 95 99         [24] 1445 	lcall	_keycode_at_keymap_location_raw
      008647 AB 82            [24] 1446 	mov	r3, dpl
      008649 AC 83            [24] 1447 	mov	r4, dph
      00864B D0 05            [24] 1448 	pop	ar5
      00864D D0 06            [24] 1449 	pop	ar6
      00864F D0 07            [24] 1450 	pop	ar7
      008651 90 0A E2         [24] 1451 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008654 EE               [12] 1452 	mov	a,r6
      008655 F0               [24] 1453 	movx	@dptr,a
      008656 90 0A E3         [24] 1454 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008659 ED               [12] 1455 	mov	a,r5
      00865A F0               [24] 1456 	movx	@dptr,a
      00865B 90 0A E4         [24] 1457 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00865E 12 38 5D         [24] 1458 	lcall	_ak820_outline_0086
      008661 8F 82            [24] 1459 	mov	dpl, r7
      008663 C0 07            [24] 1460 	push	ar7
      008665 C0 06            [24] 1461 	push	ar6
      008667 C0 05            [24] 1462 	push	ar5
      008669 71 89            [12] 1463 	acall	_dynamic_keymap_set_keycode
      00866B D0 05            [24] 1464 	pop	ar5
      00866D D0 06            [24] 1465 	pop	ar6
      00866F D0 07            [24] 1466 	pop	ar7
                                   1467 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008671 0D               [12] 1468 	inc	r5
      008672 80 B9            [24] 1469 	sjmp	00107$
      008674                       1470 00111$:
                                   1471 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008674 0E               [12] 1472 	inc	r6
      008675 80 AF            [24] 1473 	sjmp	00110$
      008677                       1474 00102$:
                                   1475 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008677 7E 00            [12] 1476 	mov	r6,#0x00
      008679                       1477 00113$:
      008679 BE 01 00         [24] 1478 	cjne	r6,#0x01,00204$
      00867C                       1479 00204$:
      00867C 50 4A            [24] 1480 	jnc	00117$
                                   1481 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      00867E 12 8D BE         [24] 1482 	lcall	_ak820_outline_0180
      008681 04               [12] 1483 	inc	a
      008682 F0               [24] 1484 	movx	@dptr,a
      008683 8F 82            [24] 1485 	mov	dpl, r7
      008685 C0 07            [24] 1486 	push	ar7
      008687 12 95 DE         [24] 1487 	lcall	_keycode_at_encodermap_location_raw
      00868A 12 43 60         [24] 1488 	lcall	_ak820_outline_0151
      00868D D0 07            [24] 1489 	pop	ar7
      00868F 12 8D B5         [24] 1490 	lcall	_ak820_outline_0179
      008692 04               [12] 1491 	inc	a
      008693 F0               [24] 1492 	movx	@dptr,a
      008694 90 0A EE         [24] 1493 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008697 12 38 51         [24] 1494 	lcall	_ak820_outline_0072
      00869A 8F 82            [24] 1495 	mov	dpl, r7
      00869C C0 07            [24] 1496 	push	ar7
      00869E 91 60            [24] 1497 	acall	_dynamic_keymap_set_encoder
      0086A0 D0 07            [24] 1498 	pop	ar7
                                   1499 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      0086A2 12 8D BE         [24] 1500 	lcall	_ak820_outline_0180
      0086A5 F0               [24] 1501 	movx	@dptr,a
      0086A6 8F 82            [24] 1502 	mov	dpl, r7
      0086A8 C0 07            [24] 1503 	push	ar7
      0086AA 12 95 DE         [24] 1504 	lcall	_keycode_at_encodermap_location_raw
      0086AD 12 43 60         [24] 1505 	lcall	_ak820_outline_0151
      0086B0 D0 07            [24] 1506 	pop	ar7
      0086B2 12 8D B5         [24] 1507 	lcall	_ak820_outline_0179
      0086B5 F0               [24] 1508 	movx	@dptr,a
      0086B6 90 0A EE         [24] 1509 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0086B9 12 38 51         [24] 1510 	lcall	_ak820_outline_0072
      0086BC 8F 82            [24] 1511 	mov	dpl, r7
      0086BE C0 07            [24] 1512 	push	ar7
      0086C0 91 60            [24] 1513 	acall	_dynamic_keymap_set_encoder
      0086C2 D0 07            [24] 1514 	pop	ar7
                                   1515 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0086C4 7E 01            [12] 1516 	mov	r6,#0x01
      0086C6 80 B1            [24] 1517 	sjmp	00113$
      0086C8                       1518 00117$:
                                   1519 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0086C8 0F               [12] 1520 	inc	r7
      0086C9 C1 1D            [12] 1521 	ajmp	00116$
      0086CB                       1522 00104$:
                                   1523 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      0086CB 90 0B 04         [24] 1524 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      0086CE 12 4F 26         [24] 1525 	lcall	_ak820_outline_0184
      0086D1 90 0B 06         [24] 1526 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      0086D4 F0               [24] 1527 	movx	@dptr,a
      0086D5 A3               [24] 1528 	inc	dptr
      0086D6 F0               [24] 1529 	movx	@dptr,a
      0086D7 90 0B 08         [24] 1530 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      0086DA F0               [24] 1531 	movx	@dptr,a
      0086DB A3               [24] 1532 	inc	dptr
      0086DC F0               [24] 1533 	movx	@dptr,a
      0086DD 90 0B 0A         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      0086E0 F0               [24] 1535 	movx	@dptr,a
      0086E1 A3               [24] 1536 	inc	dptr
      0086E2 F0               [24] 1537 	movx	@dptr,a
      0086E3 90 0B 0C         [24] 1538 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      0086E6 F0               [24] 1539 	movx	@dptr,a
      0086E7 A3               [24] 1540 	inc	dptr
      0086E8 F0               [24] 1541 	movx	@dptr,a
                                   1542 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0086E9 FF               [12] 1543 	mov	r7,a
      0086EA                       1544 00119$:
      0086EA BF 08 00         [24] 1545 	cjne	r7,#0x08,00206$
      0086ED                       1546 00206$:
      0086ED 50 18            [24] 1547 	jnc	00105$
                                   1548 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      0086EF 8F 06            [24] 1549 	mov	ar6,r7
      0086F1 90 0A F5         [24] 1550 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0086F4 74 04            [12] 1551 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      0086F6 F0               [24] 1552 	movx	@dptr,a
      0086F7 74 0B            [12] 1553 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      0086F9 12 38 63         [24] 1554 	lcall	_ak820_outline_0094
      0086FC 8E 82            [24] 1555 	mov	dpl, r6
      0086FE C0 07            [24] 1556 	push	ar7
      008700 B1 6B            [24] 1557 	acall	_dynamic_keymap_set_combo
      008702 D0 07            [24] 1558 	pop	ar7
                                   1559 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008704 0F               [12] 1560 	inc	r7
      008705 80 E3            [24] 1561 	sjmp	00119$
      008707                       1562 00105$:
                                   1563 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      008707 90 0B 03         [24] 1564 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      00870A E0               [24] 1565 	movx	a,@dptr
      00870B 90 0E 24         [24] 1566 	mov	dptr,#_vial_unlocked
      00870E F0               [24] 1567 	movx	@dptr,a
                                   1568 ;	quantum/dynamic_keymap.c:405: }
      00870F 22               [24] 1569 	ret
                                   1570 ;------------------------------------------------------------
                                   1571 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1572 ;------------------------------------------------------------
                                   1573 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1574 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1575 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1576 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1577 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1578 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1579 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1580 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1581 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1582 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1583 ;------------------------------------------------------------
                                   1584 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1585 ;	-----------------------------------------
                                   1586 ;	 function ak820_dynamic_read_buffer
                                   1587 ;	-----------------------------------------
      008710                       1588 _ak820_dynamic_read_buffer:
      008710 12 38 75         [24] 1589 	lcall	_ak820_outline_0109
      008713 90 0B 17         [24] 1590 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008716 12 38 7A         [24] 1591 	lcall	_ak820_outline_0110
                                   1592 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008719 90 0B 14         [24] 1593 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00871C 12 38 34         [24] 1594 	lcall	_ak820_outline_0052
                                   1595 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      00871F 90 0B 19         [24] 1596 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008722 E4               [12] 1597 	clr	a
      008723 F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      008724 90 0B 12         [24] 1600 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008727 12 38 4B         [24] 1601 	lcall	_ak820_outline_0061
      00872A 8C 02            [24] 1602 	mov	ar2,r4
      00872C 8D 03            [24] 1603 	mov	ar3,r5
      00872E C3               [12] 1604 	clr	c
      00872F 74 1C            [12] 1605 	mov	a,#0x1c
      008731 9A               [12] 1606 	subb	a,r2
      008732 E4               [12] 1607 	clr	a
      008733 9B               [12] 1608 	subb	a,r3
      008734 50 01            [24] 1609 	jnc	00102$
                                   1610 ;	free result
      008736 22               [24] 1611 	ret
      008737                       1612 00102$:
                                   1613 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      008737 90 0B 10         [24] 1614 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00873A 12 43 3D         [24] 1615 	lcall	_ak820_outline_0105
      00873D 90 0B 0E         [24] 1616 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008740 12 38 6F         [24] 1617 	lcall	_ak820_outline_0104
      008743 C3               [12] 1618 	clr	c
      008744 EA               [12] 1619 	mov	a,r2
      008745 98               [12] 1620 	subb	a,r0
      008746 EB               [12] 1621 	mov	a,r3
      008747 99               [12] 1622 	subb	a,r1
      008748 50 17            [24] 1623 	jnc	00104$
                                   1624 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      00874A E8               [12] 1625 	mov	a,r0
      00874B C3               [12] 1626 	clr	c
      00874C 9A               [12] 1627 	subb	a,r2
      00874D F8               [12] 1628 	mov	r0,a
      00874E E9               [12] 1629 	mov	a,r1
      00874F 9B               [12] 1630 	subb	a,r3
      008750 F9               [12] 1631 	mov	r1,a
                                   1632 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      008751 C3               [12] 1633 	clr	c
      008752 E8               [12] 1634 	mov	a,r0
      008753 9C               [12] 1635 	subb	a,r4
      008754 E9               [12] 1636 	mov	a,r1
      008755 9D               [12] 1637 	subb	a,r5
      008756 40 04            [24] 1638 	jc	00114$
      008758 8C 00            [24] 1639 	mov	ar0,r4
      00875A 8D 01            [24] 1640 	mov	ar1,r5
      00875C                       1641 00114$:
      00875C 90 0B 19         [24] 1642 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      00875F E8               [12] 1643 	mov	a,r0
      008760 F0               [24] 1644 	movx	@dptr,a
      008761                       1645 00104$:
                                   1646 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008761 90 0B 19         [24] 1647 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008764 E0               [24] 1648 	movx	a,@dptr
      008765 F5 2C            [12] 1649 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008767 E0               [24] 1650 	movx	a,@dptr
      008768 60 42            [24] 1651 	jz	00106$
      00876A C0 04            [24] 1652 	push	ar4
      00876C C0 05            [24] 1653 	push	ar5
      00876E 8E 00            [24] 1654 	mov	ar0,r6
      008770 8F 05            [24] 1655 	mov	ar5,r7
      008772 90 0B 17         [24] 1656 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008775 E0               [24] 1657 	movx	a,@dptr
      008776 F9               [12] 1658 	mov	r1,a
      008777 A3               [24] 1659 	inc	dptr
      008778 E0               [24] 1660 	movx	a,@dptr
      008779 FC               [12] 1661 	mov	r4,a
      00877A EA               [12] 1662 	mov	a,r2
      00877B 29               [12] 1663 	add	a, r1
      00877C FA               [12] 1664 	mov	r2,a
      00877D EB               [12] 1665 	mov	a,r3
      00877E 3C               [12] 1666 	addc	a, r4
      00877F FB               [12] 1667 	mov	r3,a
      008780 90 05 85         [24] 1668 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008783 EA               [12] 1669 	mov	a,r2
      008784 F0               [24] 1670 	movx	@dptr,a
      008785 EB               [12] 1671 	mov	a,r3
      008786 12 38 63         [24] 1672 	lcall	_ak820_outline_0094
      008789 90 05 88         [24] 1673 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00878C E5 2C            [12] 1674 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      00878E 12 38 8F         [24] 1675 	lcall	_ak820_outline_0136
      008791 88 82            [24] 1676 	mov	dpl, r0
      008793 8D 83            [24] 1677 	mov	dph, r5
      008795 C0 07            [24] 1678 	push	ar7
      008797 C0 06            [24] 1679 	push	ar6
      008799 C0 05            [24] 1680 	push	ar5
      00879B C0 04            [24] 1681 	push	ar4
      00879D 12 40 A2         [24] 1682 	lcall	_ak820_eeprom_read_block_xdata
      0087A0 D0 04            [24] 1683 	pop	ar4
      0087A2 D0 05            [24] 1684 	pop	ar5
      0087A4 D0 06            [24] 1685 	pop	ar6
      0087A6 D0 07            [24] 1686 	pop	ar7
                                   1687 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0087A8 D0 05            [24] 1688 	pop	ar5
      0087AA D0 04            [24] 1689 	pop	ar4
                                   1690 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0087AC                       1691 00106$:
                                   1692 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0087AC 90 0B 19         [24] 1693 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0087AF E0               [24] 1694 	movx	a,@dptr
      0087B0 FB               [12] 1695 	mov	r3,a
      0087B1                       1696 00109$:
      0087B1 8B 01            [24] 1697 	mov	ar1,r3
      0087B3 7A 00            [12] 1698 	mov	r2,#0x00
      0087B5 C3               [12] 1699 	clr	c
      0087B6 E9               [12] 1700 	mov	a,r1
      0087B7 9C               [12] 1701 	subb	a,r4
      0087B8 EA               [12] 1702 	mov	a,r2
      0087B9 9D               [12] 1703 	subb	a,r5
      0087BA 50 09            [24] 1704 	jnc	00111$
      0087BC EB               [12] 1705 	mov	a,r3
      0087BD 12 38 24         [24] 1706 	lcall	_ak820_outline_0022
      0087C0 E4               [12] 1707 	clr	a
      0087C1 F0               [24] 1708 	movx	@dptr,a
      0087C2 0B               [12] 1709 	inc	r3
      0087C3 80 EC            [24] 1710 	sjmp	00109$
      0087C5                       1711 00111$:
                                   1712 ;	quantum/dynamic_keymap.c:420: }
      0087C5 22               [24] 1713 	ret
                                   1714 ;------------------------------------------------------------
                                   1715 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1716 ;------------------------------------------------------------
                                   1717 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1718 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1719 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1720 ;------------------------------------------------------------
                                   1721 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1722 ;	-----------------------------------------
                                   1723 ;	 function dynamic_keymap_get_buffer
                                   1724 ;	-----------------------------------------
      0087C6                       1725 _dynamic_keymap_get_buffer:
      0087C6 12 38 75         [24] 1726 	lcall	_ak820_outline_0109
      0087C9 90 0B 1F         [24] 1727 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      0087CC 12 38 7A         [24] 1728 	lcall	_ak820_outline_0110
                                   1729 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      0087CF 90 0B 1F         [24] 1730 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      0087D2 12 38 34         [24] 1731 	lcall	_ak820_outline_0052
      0087D5 90 0B 1A         [24] 1732 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      0087D8 12 38 4B         [24] 1733 	lcall	_ak820_outline_0061
      0087DB 90 0B 1C         [24] 1734 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      0087DE 12 4F 06         [24] 1735 	lcall	_ak820_outline_0092
      0087E1 90 0B 0E         [24] 1736 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0087E4 E4               [12] 1737 	clr	a
      0087E5 F0               [24] 1738 	movx	@dptr,a
      0087E6 74 06            [12] 1739 	mov	a,#0x06
      0087E8 A3               [24] 1740 	inc	dptr
      0087E9 F0               [24] 1741 	movx	@dptr,a
      0087EA 90 0B 10         [24] 1742 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0087ED 12 48 6D         [24] 1743 	lcall	_ak820_outline_0060
      0087F0 90 0B 12         [24] 1744 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0087F3 12 38 51         [24] 1745 	lcall	_ak820_outline_0072
      0087F6 90 0B 14         [24] 1746 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0087F9 E9               [12] 1747 	mov	a,r1
      0087FA 12 4F 1F         [24] 1748 	lcall	_ak820_outline_0158
      0087FD F0               [24] 1749 	movx	@dptr,a
      0087FE 90 00 40         [24] 1750 	mov	dptr,#0x0040
                                   1751 ;	quantum/dynamic_keymap.c:448: }
      008801 02 87 10         [24] 1752 	ljmp	_ak820_dynamic_read_buffer
                                   1753 ;------------------------------------------------------------
                                   1754 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1755 ;------------------------------------------------------------
                                   1756 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1757 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1758 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1759 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1760 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1761 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1762 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1763 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1764 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1765 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1766 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1767 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1768 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1769 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1770 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1771 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1772 ;------------------------------------------------------------
                                   1773 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1774 ;	-----------------------------------------
                                   1775 ;	 function dynamic_keymap_set_buffer
                                   1776 ;	-----------------------------------------
      008804                       1777 _dynamic_keymap_set_buffer:
      008804 12 38 75         [24] 1778 	lcall	_ak820_outline_0109
      008807 90 0B 26         [24] 1779 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      00880A 12 38 7A         [24] 1780 	lcall	_ak820_outline_0110
                                   1781 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      00880D 90 0B 26         [24] 1782 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008810 12 48 10         [24] 1783 	lcall	_ak820_outline_0008
      008813 74 40            [12] 1784 	mov	a,#0x40
      008815 2C               [12] 1785 	add	a, r4
      008816 FA               [12] 1786 	mov	r2,a
      008817 E4               [12] 1787 	clr	a
      008818 3D               [12] 1788 	addc	a, r5
      008819 FB               [12] 1789 	mov	r3,a
                                   1790 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      00881A 90 0B 23         [24] 1791 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00881D 12 38 6F         [24] 1792 	lcall	_ak820_outline_0104
                                   1793 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008820 90 0B 21         [24] 1794 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008823 E0               [24] 1795 	movx	a,@dptr
      008824 F5 2D            [12] 1796 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008826 A3               [24] 1797 	inc	dptr
      008827 E0               [24] 1798 	movx	a,@dptr
      008828 F5 2E            [12] 1799 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      00882A E5 2D            [12] 1800 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00882C 45 2E            [12] 1801 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00882E 70 01            [24] 1802 	jnz	00102$
      008830 22               [24] 1803 	ret
      008831                       1804 00102$:
                                   1805 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008831 85 2D 2F         [24] 1806 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008834 85 2E 30         [24] 1807 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008837 C3               [12] 1808 	clr	c
      008838 74 1C            [12] 1809 	mov	a,#0x1c
      00883A 95 2F            [12] 1810 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      00883C E4               [12] 1811 	clr	a
      00883D 95 30            [12] 1812 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      00883F 50 01            [24] 1813 	jnc	00104$
                                   1814 ;	free result
      008841 22               [24] 1815 	ret
      008842                       1816 00104$:
                                   1817 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      008842 85 2D 31         [24] 1818 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1819 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008845 74 FA            [12] 1820 	mov	a,#0x100 - 0x06
      008847 2F               [12] 1821 	add	a,r7
      008848 40 11            [24] 1822 	jc	00105$
      00884A E4               [12] 1823 	clr	a
      00884B C3               [12] 1824 	clr	c
      00884C 9E               [12] 1825 	subb	a,r6
      00884D FE               [12] 1826 	mov	r6,a
      00884E 74 06            [12] 1827 	mov	a,#0x06
      008850 9F               [12] 1828 	subb	a,r7
      008851 FF               [12] 1829 	mov	r7,a
      008852 C3               [12] 1830 	clr	c
      008853 EE               [12] 1831 	mov	a,r6
      008854 95 2D            [12] 1832 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008856 EF               [12] 1833 	mov	a,r7
      008857 95 2E            [12] 1834 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008859 50 01            [24] 1835 	jnc	00106$
      00885B                       1836 00105$:
                                   1837 ;	quantum/dynamic_keymap.c:466: return;
      00885B 22               [24] 1838 	ret
      00885C                       1839 00106$:
                                   1840 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      00885C 90 0E 24         [24] 1841 	mov	dptr,#_vial_unlocked
      00885F E0               [24] 1842 	movx	a,@dptr
      008860 60 02            [24] 1843 	jz	00207$
      008862 21 6E            [12] 1844 	ajmp	00120$
      008864                       1845 00207$:
                                   1846 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      008864 90 0B 28         [24] 1847 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008867 E4               [12] 1848 	clr	a
      008868 F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      008869 90 0B 29         [24] 1851 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      00886C E5 31            [12] 1852 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00886E F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      00886F EC               [12] 1855 	mov	a,r4
      008870 30 E0 31         [24] 1856 	jnb	acc.0,00111$
                                   1857 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008873 EA               [12] 1858 	mov	a,r2
      008874 24 FF            [12] 1859 	add	a,#0xff
      008876 FE               [12] 1860 	mov	r6,a
      008877 EB               [12] 1861 	mov	a,r3
      008878 34 FF            [12] 1862 	addc	a,#0xff
      00887A FF               [12] 1863 	mov	r7,a
      00887B 7D 00            [12] 1864 	mov	r5,#0x00
      00887D 12 6F 38         [24] 1865 	lcall	_ak820_outline_0050
      008880 12 40 67         [24] 1866 	lcall	_eeprom_read_byte
      008883 AE 82            [24] 1867 	mov	r6,dpl
      008885 7F 00            [12] 1868 	mov	r7,#0x00
      008887 12 38 A9         [24] 1869 	lcall	_ak820_outline_0160
      00888A E0               [24] 1870 	movx	a,@dptr
      00888B 7C 00            [12] 1871 	mov	r4,#0x00
      00888D 42 07            [12] 1872 	orl	ar7,a
      00888F EC               [12] 1873 	mov	a,r4
      008890 42 06            [12] 1874 	orl	ar6,a
                                   1875 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      008892 BF 00 09         [24] 1876 	cjne	r7,#0x00,00109$
      008895 BE 7C 06         [24] 1877 	cjne	r6,#0x7c,00109$
                                   1878 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008898 12 38 A9         [24] 1879 	lcall	_ak820_outline_0160
      00889B 74 FF            [12] 1880 	mov	a,#0xff
      00889D F0               [24] 1881 	movx	@dptr,a
      00889E                       1882 00109$:
                                   1883 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      00889E 90 0B 28         [24] 1884 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0088A1 74 01            [12] 1885 	mov	a,#0x01
      0088A3 F0               [24] 1886 	movx	@dptr,a
      0088A4                       1887 00111$:
                                   1888 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      0088A4 90 0B 26         [24] 1889 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0088A7 12 38 34         [24] 1890 	lcall	_ak820_outline_0052
      0088AA E5 2D            [12] 1891 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0088AC 2E               [12] 1892 	add	a, r6
      0088AD FE               [12] 1893 	mov	r6,a
      0088AE E5 2E            [12] 1894 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0088B0 3F               [12] 1895 	addc	a, r7
      0088B1 EE               [12] 1896 	mov	a,r6
      0088B2 30 E0 5A         [24] 1897 	jnb	acc.0,00115$
                                   1898 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      0088B5 AE 31            [24] 1899 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      0088B7 7F 00            [12] 1900 	mov	r7,#0x00
      0088B9 EE               [12] 1901 	mov	a,r6
      0088BA 24 FF            [12] 1902 	add	a,#0xff
      0088BC FC               [12] 1903 	mov	r4,a
      0088BD EF               [12] 1904 	mov	a,r7
      0088BE 34 FF            [12] 1905 	addc	a,#0xff
      0088C0 FD               [12] 1906 	mov	r5,a
      0088C1 EC               [12] 1907 	mov	a,r4
      0088C2 28               [12] 1908 	add	a, r0
      0088C3 F5 82            [12] 1909 	mov	dpl,a
      0088C5 ED               [12] 1910 	mov	a,r5
      0088C6 39               [12] 1911 	addc	a, r1
      0088C7 F5 83            [12] 1912 	mov	dph,a
      0088C9 E0               [24] 1913 	movx	a,@dptr
      0088CA FC               [12] 1914 	mov	r4,a
      0088CB 7D 00            [12] 1915 	mov	r5,#0x00
      0088CD E5 31            [12] 1916 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0088CF 2A               [12] 1917 	add	a, r2
      0088D0 FA               [12] 1918 	mov	r2,a
      0088D1 E4               [12] 1919 	clr	a
      0088D2 3B               [12] 1920 	addc	a, r3
      0088D3 FB               [12] 1921 	mov	r3,a
      0088D4 C0 00            [24] 1922 	push	ar0
      0088D6 C0 01            [24] 1923 	push	ar1
      0088D8 8B 01            [24] 1924 	mov	ar1,r3
      0088DA 7B 00            [12] 1925 	mov	r3,#0x00
      0088DC 8A 82            [24] 1926 	mov	dpl, r2
      0088DE 89 83            [24] 1927 	mov	dph, r1
      0088E0 8B F0            [24] 1928 	mov	b, r3
      0088E2 12 40 67         [24] 1929 	lcall	_eeprom_read_byte
      0088E5 AB 82            [24] 1930 	mov	r3, dpl
      0088E7 7A 00            [12] 1931 	mov	r2,#0x00
      0088E9 EB               [12] 1932 	mov	a,r3
      0088EA 12 43 5A         [24] 1933 	lcall	_ak820_outline_0144
                                   1934 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      0088ED BD 00 05         [24] 1935 	cjne	r5,#0x00,00212$
      0088F0 BC 7C 02         [24] 1936 	cjne	r4,#0x7c,00212$
      0088F3 80 06            [24] 1937 	sjmp	00213$
      0088F5                       1938 00212$:
      0088F5 D0 01            [24] 1939 	pop	ar1
      0088F7 D0 00            [24] 1940 	pop	ar0
      0088F9 80 0D            [24] 1941 	sjmp	00113$
      0088FB                       1942 00213$:
      0088FB D0 01            [24] 1943 	pop	ar1
      0088FD D0 00            [24] 1944 	pop	ar0
                                   1945 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      0088FF 1E               [12] 1946 	dec	r6
      008900 BE FF 01         [24] 1947 	cjne	r6,#0xff,00214$
      008903 1F               [12] 1948 	dec	r7
      008904                       1949 00214$:
      008904 EE               [12] 1950 	mov	a,r6
      008905 12 8D 97         [24] 1951 	lcall	_ak820_outline_0130
      008908                       1952 00113$:
                                   1953 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008908 E5 31            [12] 1954 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00890A 14               [12] 1955 	dec	a
      00890B 90 0B 29         [24] 1956 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      00890E F0               [24] 1957 	movx	@dptr,a
      00890F                       1958 00115$:
                                   1959 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      00890F 90 0B 28         [24] 1960 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008912 E0               [24] 1961 	movx	a,@dptr
      008913 90 0B 2A         [24] 1962 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008916 F0               [24] 1963 	movx	@dptr,a
      008917                       1964 00122$:
      008917 90 0B 2A         [24] 1965 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      00891A E0               [24] 1966 	movx	a,@dptr
      00891B FF               [12] 1967 	mov	r7,a
      00891C 90 0B 29         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      00891F E0               [24] 1969 	movx	a,@dptr
      008920 FE               [12] 1970 	mov	r6,a
      008921 C3               [12] 1971 	clr	c
      008922 EF               [12] 1972 	mov	a,r7
      008923 9E               [12] 1973 	subb	a,r6
      008924 50 48            [24] 1974 	jnc	00120$
                                   1975 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008926 EF               [12] 1976 	mov	a,r7
      008927 28               [12] 1977 	add	a, r0
      008928 FD               [12] 1978 	mov	r5,a
      008929 E4               [12] 1979 	clr	a
      00892A 39               [12] 1980 	addc	a, r1
      00892B FE               [12] 1981 	mov	r6,a
      00892C 12 48 7A         [24] 1982 	lcall	_ak820_outline_0077
      00892F 7B 00            [12] 1983 	mov	r3,#0x00
      008931 8C 2E            [24] 1984 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008933 8B 2D            [24] 1985 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008935 8F 02            [24] 1986 	mov	ar2,r7
      008937 7F 00            [12] 1987 	mov	r7,#0x00
      008939 74 01            [12] 1988 	mov	a,#0x01
      00893B 2A               [12] 1989 	add	a, r2
      00893C FB               [12] 1990 	mov	r3,a
      00893D E4               [12] 1991 	clr	a
      00893E 3F               [12] 1992 	addc	a, r7
      00893F FC               [12] 1993 	mov	r4,a
      008940 EB               [12] 1994 	mov	a,r3
      008941 28               [12] 1995 	add	a, r0
      008942 F5 82            [12] 1996 	mov	dpl,a
      008944 EC               [12] 1997 	mov	a,r4
      008945 39               [12] 1998 	addc	a, r1
      008946 F5 83            [12] 1999 	mov	dph,a
      008948 E0               [24] 2000 	movx	a,@dptr
      008949 FC               [12] 2001 	mov	r4,a
      00894A 7B 00            [12] 2002 	mov	r3,#0x00
      00894C E5 2E            [12] 2003 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00894E 42 03            [12] 2004 	orl	ar3,a
                                   2005 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008950 BC 00 12         [24] 2006 	cjne	r4,#0x00,00123$
      008953 BB 7C 0F         [24] 2007 	cjne	r3,#0x7c,00123$
                                   2008 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008956 12 38 94         [24] 2009 	lcall	_ak820_outline_0137
      008959 74 FF            [12] 2010 	mov	a,#0xff
      00895B F0               [24] 2011 	movx	@dptr,a
                                   2012 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      00895C 0A               [12] 2013 	inc	r2
      00895D BA 00 01         [24] 2014 	cjne	r2,#0x00,00218$
      008960 0F               [12] 2015 	inc	r7
      008961                       2016 00218$:
      008961 EA               [12] 2017 	mov	a,r2
      008962 12 8D 97         [24] 2018 	lcall	_ak820_outline_0130
      008965                       2019 00123$:
                                   2020 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008965 90 0B 2A         [24] 2021 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008968 E0               [24] 2022 	movx	a,@dptr
      008969 24 02            [12] 2023 	add	a,#0x02
      00896B F0               [24] 2024 	movx	@dptr,a
      00896C 80 A9            [24] 2025 	sjmp	00122$
      00896E                       2026 00120$:
                                   2027 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      00896E 90 0B 26         [24] 2028 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008971 12 38 34         [24] 2029 	lcall	_ak820_outline_0052
      008974 74 40            [12] 2030 	mov	a,#0x40
      008976 12 43 54         [24] 2031 	lcall	_ak820_outline_0139
      008979 90 05 8E         [24] 2032 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00897C 12 48 6D         [24] 2033 	lcall	_ak820_outline_0060
      00897F E4               [12] 2034 	clr	a
      008980 A3               [24] 2035 	inc	dptr
      008981 F0               [24] 2036 	movx	@dptr,a
      008982 90 05 91         [24] 2037 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008985 E5 2F            [12] 2038 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008987 F0               [24] 2039 	movx	@dptr,a
      008988 E5 30            [12] 2040 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      00898A A3               [24] 2041 	inc	dptr
      00898B F0               [24] 2042 	movx	@dptr,a
      00898C 12 38 A9         [24] 2043 	lcall	_ak820_outline_0160
                                   2044 ;	quantum/dynamic_keymap.c:521: }
      00898F 02 41 2E         [24] 2045 	ljmp	_ak820_eeprom_write_block_xdata
                                   2046 ;------------------------------------------------------------
                                   2047 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2048 ;------------------------------------------------------------
                                   2049 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2050 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2051 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2052 ;------------------------------------------------------------
                                   2053 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2054 ;	-----------------------------------------
                                   2055 ;	 function keycode_at_keymap_location
                                   2056 ;	-----------------------------------------
      008992                       2057 _keycode_at_keymap_location:
      008992 E5 82            [12] 2058 	mov	a,dpl
      008994 90 0B 2D         [24] 2059 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      008997 F0               [24] 2060 	movx	@dptr,a
                                   2061 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008998 E0               [24] 2062 	movx	a,@dptr
      008999 FF               [12] 2063 	mov	r7,a
      00899A BF 06 00         [24] 2064 	cjne	r7,#0x06,00128$
      00899D                       2065 00128$:
      00899D 50 23            [24] 2066 	jnc	00102$
      00899F 90 0B 2B         [24] 2067 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      0089A2 E0               [24] 2068 	movx	a,@dptr
      0089A3 FE               [12] 2069 	mov	r6,a
      0089A4 BE 10 00         [24] 2070 	cjne	r6,#0x10,00130$
      0089A7                       2071 00130$:
      0089A7 50 19            [24] 2072 	jnc	00102$
      0089A9 90 0B 2C         [24] 2073 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      0089AC E0               [24] 2074 	movx	a,@dptr
      0089AD FD               [12] 2075 	mov	r5,a
      0089AE BD 08 00         [24] 2076 	cjne	r5,#0x08,00132$
      0089B1                       2077 00132$:
      0089B1 50 0F            [24] 2078 	jnc	00102$
                                   2079 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      0089B3 90 0A DF         [24] 2080 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0089B6 EE               [12] 2081 	mov	a,r6
      0089B7 F0               [24] 2082 	movx	@dptr,a
      0089B8 90 0A E0         [24] 2083 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0089BB ED               [12] 2084 	mov	a,r5
      0089BC F0               [24] 2085 	movx	@dptr,a
      0089BD 8F 82            [24] 2086 	mov	dpl, r7
      0089BF 02 83 3C         [24] 2087 	ljmp	_dynamic_keymap_get_keycode
      0089C2                       2088 00102$:
                                   2089 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      0089C2 90 00 00         [24] 2090 	mov	dptr,#0x0000
                                   2091 ;	quantum/dynamic_keymap.c:528: }
      0089C5 22               [24] 2092 	ret
                                   2093 ;------------------------------------------------------------
                                   2094 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2095 ;------------------------------------------------------------
                                   2096 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2097 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2098 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2099 ;------------------------------------------------------------
                                   2100 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2101 ;	-----------------------------------------
                                   2102 ;	 function keycode_at_encodermap_location
                                   2103 ;	-----------------------------------------
      0089C6                       2104 _keycode_at_encodermap_location:
      0089C6 E5 82            [12] 2105 	mov	a,dpl
      0089C8 90 0B 30         [24] 2106 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      0089CB F0               [24] 2107 	movx	@dptr,a
                                   2108 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      0089CC E0               [24] 2109 	movx	a,@dptr
      0089CD FF               [12] 2110 	mov	r7,a
      0089CE BF 06 00         [24] 2111 	cjne	r7,#0x06,00120$
      0089D1                       2112 00120$:
      0089D1 50 1E            [24] 2113 	jnc	00102$
      0089D3 90 0B 2E         [24] 2114 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0089D6 E0               [24] 2115 	movx	a,@dptr
      0089D7 FE               [12] 2116 	mov	r6,a
      0089D8 BE 01 00         [24] 2117 	cjne	r6,#0x01,00122$
      0089DB                       2118 00122$:
      0089DB 50 14            [24] 2119 	jnc	00102$
                                   2120 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      0089DD 90 0B 2F         [24] 2121 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0089E0 E0               [24] 2122 	movx	a,@dptr
      0089E1 FE               [12] 2123 	mov	r6,a
      0089E2 90 0A E9         [24] 2124 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0089E5 E4               [12] 2125 	clr	a
      0089E6 F0               [24] 2126 	movx	@dptr,a
      0089E7 90 0A EA         [24] 2127 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0089EA EE               [12] 2128 	mov	a,r6
      0089EB F0               [24] 2129 	movx	@dptr,a
      0089EC 8F 82            [24] 2130 	mov	dpl, r7
      0089EE 02 83 F9         [24] 2131 	ljmp	_dynamic_keymap_get_encoder
      0089F1                       2132 00102$:
                                   2133 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      0089F1 90 00 00         [24] 2134 	mov	dptr,#0x0000
                                   2135 ;	quantum/dynamic_keymap.c:536: }
      0089F4 22               [24] 2136 	ret
                                   2137 ;------------------------------------------------------------
                                   2138 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2139 ;------------------------------------------------------------
                                   2140 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2141 ;	-----------------------------------------
                                   2142 ;	 function dynamic_keymap_macro_get_count
                                   2143 ;	-----------------------------------------
      0089F5                       2144 _dynamic_keymap_macro_get_count:
                                   2145 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      0089F5 75 82 10         [24] 2146 	mov	dpl, #0x10
                                   2147 ;	quantum/dynamic_keymap.c:541: }
      0089F8 22               [24] 2148 	ret
                                   2149 ;------------------------------------------------------------
                                   2150 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2151 ;------------------------------------------------------------
                                   2152 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2153 ;	-----------------------------------------
                                   2154 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2155 ;	-----------------------------------------
      0089F9                       2156 _dynamic_keymap_macro_get_buffer_size:
                                   2157 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      0089F9 90 20 00         [24] 2158 	mov	dptr,#0x2000
                                   2159 ;	quantum/dynamic_keymap.c:545: }
      0089FC 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2163 ;------------------------------------------------------------
                                   2164 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2165 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2166 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2167 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2168 ;------------------------------------------------------------
                                   2169 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2170 ;	-----------------------------------------
                                   2171 ;	 function dynamic_keymap_macro_get_buffer
                                   2172 ;	-----------------------------------------
      0089FD                       2173 _dynamic_keymap_macro_get_buffer:
      0089FD 12 38 75         [24] 2174 	lcall	_ak820_outline_0109
      008A00 90 0B 36         [24] 2175 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008A03 12 38 7A         [24] 2176 	lcall	_ak820_outline_0110
                                   2177 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008A06 12 2B 2B         [24] 2178 	lcall	_ak820_macro_length
      008A09 12 43 4F         [24] 2179 	lcall	_ak820_outline_0135
      008A0C 90 0B 36         [24] 2180 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008A0F 12 38 4B         [24] 2181 	lcall	_ak820_outline_0061
      008A12 90 0B 31         [24] 2182 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008A15 E0               [24] 2183 	movx	a,@dptr
      008A16 F5 32            [12] 2184 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008A18 A3               [24] 2185 	inc	dptr
      008A19 E0               [24] 2186 	movx	a,@dptr
      008A1A F5 33            [12] 2187 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008A1C 90 0B 33         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008A1F 12 38 6F         [24] 2189 	lcall	_ak820_outline_0104
      008A22 A3               [24] 2190 	inc	dptr
      008A23 E0               [24] 2191 	movx	a,@dptr
      008A24 FB               [12] 2192 	mov	r3,a
      008A25 90 0B 0E         [24] 2193 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008A28 12 48 6D         [24] 2194 	lcall	_ak820_outline_0060
      008A2B 90 0B 10         [24] 2195 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008A2E 12 38 51         [24] 2196 	lcall	_ak820_outline_0072
      008A31 90 0B 12         [24] 2197 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008A34 E5 32            [12] 2198 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008A36 F0               [24] 2199 	movx	@dptr,a
      008A37 E5 33            [12] 2200 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008A39 A3               [24] 2201 	inc	dptr
      008A3A F0               [24] 2202 	movx	@dptr,a
      008A3B 90 0B 14         [24] 2203 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008A3E E8               [12] 2204 	mov	a,r0
      008A3F F0               [24] 2205 	movx	@dptr,a
      008A40 E9               [12] 2206 	mov	a,r1
      008A41 A3               [24] 2207 	inc	dptr
      008A42 12 76 E2         [24] 2208 	lcall	_ak820_outline_0189
      008A45 90 08 00         [24] 2209 	mov	dptr,#0x0800
                                   2210 ;	quantum/dynamic_keymap.c:572: }
      008A48 02 87 10         [24] 2211 	ljmp	_ak820_dynamic_read_buffer
                                   2212 ;------------------------------------------------------------
                                   2213 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2214 ;------------------------------------------------------------
                                   2215 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2216 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2217 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2218 ;------------------------------------------------------------
                                   2219 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2220 ;	-----------------------------------------
                                   2221 ;	 function dynamic_keymap_macro_set_buffer
                                   2222 ;	-----------------------------------------
      008A4B                       2223 _dynamic_keymap_macro_set_buffer:
      008A4B 12 38 75         [24] 2224 	lcall	_ak820_outline_0109
      008A4E 90 0B 3D         [24] 2225 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008A51 12 38 7A         [24] 2226 	lcall	_ak820_outline_0110
                                   2227 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      008A54 90 0B 3D         [24] 2228 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008A57 12 38 34         [24] 2229 	lcall	_ak820_outline_0052
      008A5A 90 0B 38         [24] 2230 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008A5D 12 38 4B         [24] 2231 	lcall	_ak820_outline_0061
      008A60 90 0B 3A         [24] 2232 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008A63 12 4F 06         [24] 2233 	lcall	_ak820_outline_0092
      008A66 90 05 14         [24] 2234 	mov	dptr,#_ak820_macro_write_PARM_2
      008A69 12 38 51         [24] 2235 	lcall	_ak820_outline_0072
      008A6C 90 05 16         [24] 2236 	mov	dptr,#_ak820_macro_write_PARM_3
      008A6F E9               [12] 2237 	mov	a,r1
      008A70 12 4F 1F         [24] 2238 	lcall	_ak820_outline_0158
      008A73 12 43 31         [24] 2239 	lcall	_ak820_outline_0079
                                   2240 ;	quantum/dynamic_keymap.c:577: }
      008A76 02 2B 45         [24] 2241 	ljmp	_ak820_macro_write
                                   2242 ;------------------------------------------------------------
                                   2243 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2244 ;------------------------------------------------------------
                                   2245 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2246 ;	-----------------------------------------
                                   2247 ;	 function dynamic_keymap_macro_reset
                                   2248 ;	-----------------------------------------
      008A79                       2249 _dynamic_keymap_macro_reset:
                                   2250 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2251 ;	quantum/dynamic_keymap.c:603: }
      008A79 02 2E 64         [24] 2252 	ljmp	_ak820_macro_reset
                                   2253 ;------------------------------------------------------------
                                   2254 ;Allocation info for local variables in function 'decode_keycode'
                                   2255 ;------------------------------------------------------------
                                   2256 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2257 ;------------------------------------------------------------
                                   2258 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2259 ;	-----------------------------------------
                                   2260 ;	 function decode_keycode
                                   2261 ;	-----------------------------------------
      008A7C                       2262 _decode_keycode:
      008A7C 12 38 75         [24] 2263 	lcall	_ak820_outline_0109
      008A7F 90 0B 3F         [24] 2264 	mov	dptr,#_decode_keycode_kc_10000_454
      008A82 12 38 7A         [24] 2265 	lcall	_ak820_outline_0110
                                   2266 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      008A85 90 0B 3F         [24] 2267 	mov	dptr,#_decode_keycode_kc_10000_454
      008A88 12 48 10         [24] 2268 	lcall	_ak820_outline_0008
      008A8B C3               [12] 2269 	clr	c
      008A8C E4               [12] 2270 	clr	a
      008A8D 9C               [12] 2271 	subb	a,r4
      008A8E 74 FF            [12] 2272 	mov	a,#0xff
      008A90 9D               [12] 2273 	subb	a,r5
      008A91 50 08            [24] 2274 	jnc	00102$
                                   2275 ;	free result
                                   2276 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      008A93 8C 05            [24] 2277 	mov	ar5,r4
      008A95 7C 00            [12] 2278 	mov	r4,#0x00
      008A97 12 38 8A         [24] 2279 	lcall	_ak820_outline_0126
      008A9A 22               [24] 2280 	ret
      008A9B                       2281 00102$:
                                   2282 ;	quantum/dynamic_keymap.c:609: return kc;
      008A9B 12 38 7F         [24] 2283 	lcall	_ak820_outline_0120
                                   2284 ;	quantum/dynamic_keymap.c:610: }
      008A9E 22               [24] 2285 	ret
                                   2286 ;------------------------------------------------------------
                                   2287 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2288 ;------------------------------------------------------------
                                   2289 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2290 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2291 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2292 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2293 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2294 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2295 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2296 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2297 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2298 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2299 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2300 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2301 ;------------------------------------------------------------
                                   2302 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2303 ;	-----------------------------------------
                                   2304 ;	 function dynamic_keymap_macro_send
                                   2305 ;	-----------------------------------------
      008A9F                       2306 _dynamic_keymap_macro_send:
      008A9F E5 82            [12] 2307 	mov	a,dpl
      008AA1 90 0B 41         [24] 2308 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008AA4 F0               [24] 2309 	movx	@dptr,a
                                   2310 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      008AA5 90 0B 42         [24] 2311 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008AA8 E0               [24] 2312 	movx	a,@dptr
      008AA9 60 01            [24] 2313 	jz	00102$
      008AAB 22               [24] 2314 	ret
      008AAC                       2315 00102$:
                                   2316 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008AAC 90 0B 41         [24] 2317 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008AAF E0               [24] 2318 	movx	a,@dptr
      008AB0 FF               [12] 2319 	mov	r7,a
      008AB1 BF 10 00         [24] 2320 	cjne	r7,#0x10,00422$
      008AB4                       2321 00422$:
      008AB4 40 01            [24] 2322 	jc	00104$
                                   2323 ;	quantum/dynamic_keymap.c:620: return;
      008AB6 22               [24] 2324 	ret
      008AB7                       2325 00104$:
                                   2326 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      008AB7 C0 07            [24] 2327 	push	ar7
      008AB9 12 2A F2         [24] 2328 	lcall	_ak820_macro_ready
      008ABC E5 82            [12] 2329 	mov	a, dpl
      008ABE D0 07            [24] 2330 	pop	ar7
      008AC0 70 01            [24] 2331 	jnz	00106$
      008AC2 22               [24] 2332 	ret
      008AC3                       2333 00106$:
                                   2334 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008AC3 90 0B 43         [24] 2335 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008AC6 E4               [12] 2336 	clr	a
      008AC7 F0               [24] 2337 	movx	@dptr,a
      008AC8 74 08            [12] 2338 	mov	a,#0x08
      008ACA A3               [24] 2339 	inc	dptr
      008ACB F0               [24] 2340 	movx	@dptr,a
                                   2341 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008ACC C0 07            [24] 2342 	push	ar7
      008ACE 12 2B 2B         [24] 2343 	lcall	_ak820_macro_length
      008AD1 AD 82            [24] 2344 	mov	r5, dpl
      008AD3 AE 83            [24] 2345 	mov	r6, dph
      008AD5 D0 07            [24] 2346 	pop	ar7
      008AD7 74 08            [12] 2347 	mov	a,#0x08
      008AD9 2E               [12] 2348 	add	a, r6
      008ADA FE               [12] 2349 	mov	r6,a
                                   2350 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      008ADB 7B 00            [12] 2351 	mov	r3,#0x00
      008ADD 7C 08            [12] 2352 	mov	r4,#0x08
      008ADF                       2353 00111$:
      008ADF EF               [12] 2354 	mov	a,r7
      008AE0 60 31            [24] 2355 	jz	00113$
                                   2356 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      008AE2 EB               [12] 2357 	mov	a,r3
      008AE3 B5 05 05         [24] 2358 	cjne	a,ar5,00108$
      008AE6 EC               [12] 2359 	mov	a,r4
      008AE7 B5 06 01         [24] 2360 	cjne	a,ar6,00108$
                                   2361 ;	quantum/dynamic_keymap.c:654: return;
      008AEA 22               [24] 2362 	ret
      008AEB                       2363 00108$:
                                   2364 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008AEB 8B 01            [24] 2365 	mov	ar1,r3
      008AED 8C 02            [24] 2366 	mov	ar2,r4
      008AEF 8A 00            [24] 2367 	mov	ar0,r2
      008AF1 7A 00            [12] 2368 	mov	r2,#0x00
      008AF3 89 82            [24] 2369 	mov	dpl, r1
      008AF5 88 83            [24] 2370 	mov	dph, r0
      008AF7 8A F0            [24] 2371 	mov	b, r2
      008AF9 12 40 67         [24] 2372 	lcall	_eeprom_read_byte
      008AFC E5 82            [12] 2373 	mov	a, dpl
      008AFE 70 06            [24] 2374 	jnz	00110$
                                   2375 ;	quantum/dynamic_keymap.c:657: --id;
      008B00 1F               [12] 2376 	dec	r7
      008B01 90 0B 41         [24] 2377 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008B04 EF               [12] 2378 	mov	a,r7
      008B05 F0               [24] 2379 	movx	@dptr,a
      008B06                       2380 00110$:
                                   2381 ;	quantum/dynamic_keymap.c:659: ++p;
      008B06 0B               [12] 2382 	inc	r3
      008B07 BB 00 01         [24] 2383 	cjne	r3,#0x00,00429$
      008B0A 0C               [12] 2384 	inc	r4
      008B0B                       2385 00429$:
      008B0B 90 0B 43         [24] 2386 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008B0E 12 38 5D         [24] 2387 	lcall	_ak820_outline_0086
      008B11 80 CC            [24] 2388 	sjmp	00111$
      008B13                       2389 00113$:
                                   2390 ;	quantum/dynamic_keymap.c:665: sending = true;
      008B13 90 0B 42         [24] 2391 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008B16 74 01            [12] 2392 	mov	a,#0x01
      008B18 F0               [24] 2393 	movx	@dptr,a
                                   2394 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      008B19 12 8D AF         [24] 2395 	lcall	_ak820_outline_0168
      008B1C 90 09 8B         [24] 2396 	mov	dptr,#_ak820_macro_cancelled
      008B1F F0               [24] 2397 	movx	@dptr,a
                                   2398 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      008B20 90 0B 45         [24] 2399 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008B23 F0               [24] 2400 	movx	@dptr,a
      008B24 90 0B 46         [24] 2401 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008B27 F0               [24] 2402 	movx	@dptr,a
      008B28 90 0B 47         [24] 2403 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008B2B F0               [24] 2404 	movx	@dptr,a
      008B2C 90 0B 48         [24] 2405 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008B2F F0               [24] 2406 	movx	@dptr,a
                                   2407 ;	quantum/dynamic_keymap.c:675: while (p < end
      008B30                       2408 00167$:
                                   2409 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      008B30 90 0B 43         [24] 2410 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008B33 E0               [24] 2411 	movx	a,@dptr
      008B34 FC               [12] 2412 	mov	r4,a
      008B35 A3               [24] 2413 	inc	dptr
      008B36 E0               [24] 2414 	movx	a,@dptr
      008B37 FF               [12] 2415 	mov	r7,a
      008B38 C3               [12] 2416 	clr	c
      008B39 EC               [12] 2417 	mov	a,r4
      008B3A 9D               [12] 2418 	subb	a,r5
      008B3B EF               [12] 2419 	mov	a,r7
      008B3C 9E               [12] 2420 	subb	a,r6
      008B3D 40 02            [24] 2421 	jc	00430$
      008B3F A1 44            [12] 2422 	ajmp	00169$
      008B41                       2423 00430$:
      008B41 90 09 8B         [24] 2424 	mov	dptr,#_ak820_macro_cancelled
      008B44 E0               [24] 2425 	movx	a,@dptr
      008B45 60 02            [24] 2426 	jz	00431$
      008B47 A1 44            [12] 2427 	ajmp	00169$
      008B49                       2428 00431$:
                                   2429 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B49 8C 02            [24] 2430 	mov	ar2,r4
      008B4B 8F 03            [24] 2431 	mov	ar3,r7
      008B4D 90 0B 43         [24] 2432 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008B50 74 01            [12] 2433 	mov	a,#0x01
      008B52 2C               [12] 2434 	add	a, r4
      008B53 F0               [24] 2435 	movx	@dptr,a
      008B54 E4               [12] 2436 	clr	a
      008B55 3F               [12] 2437 	addc	a, r7
      008B56 A3               [24] 2438 	inc	dptr
      008B57 F0               [24] 2439 	movx	@dptr,a
      008B58 7F 00            [12] 2440 	mov	r7,#0x00
      008B5A 12 38 9F         [24] 2441 	lcall	_ak820_outline_0145
      008B5D 8F F0            [24] 2442 	mov	b, r7
      008B5F 12 40 67         [24] 2443 	lcall	_eeprom_read_byte
      008B62 AF 82            [24] 2444 	mov	r7, dpl
      008B64 90 0B 45         [24] 2445 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008B67 EF               [12] 2446 	mov	a,r7
      008B68 F0               [24] 2447 	movx	@dptr,a
                                   2448 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      008B69 90 0B 46         [24] 2449 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008B6C E4               [12] 2450 	clr	a
      008B6D F0               [24] 2451 	movx	@dptr,a
                                   2452 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      008B6E 90 0B 45         [24] 2453 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008B71 E0               [24] 2454 	movx	a,@dptr
      008B72 70 02            [24] 2455 	jnz	00432$
      008B74 A1 44            [12] 2456 	ajmp	00169$
      008B76                       2457 00432$:
                                   2458 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      008B76 90 0B 45         [24] 2459 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008B79 E0               [24] 2460 	movx	a,@dptr
      008B7A FF               [12] 2461 	mov	r7,a
      008B7B BF 01 02         [24] 2462 	cjne	r7,#0x01,00433$
      008B7E 80 02            [24] 2463 	sjmp	00434$
      008B80                       2464 00433$:
      008B80 A1 27            [12] 2465 	ajmp	00164$
      008B82                       2466 00434$:
                                   2467 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B82 12 8D 4C         [24] 2468 	lcall	_ak820_outline_0000
      008B85 12 40 67         [24] 2469 	lcall	_eeprom_read_byte
      008B88 AF 82            [24] 2470 	mov	r7, dpl
      008B8A 90 0B 46         [24] 2471 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008B8D EF               [12] 2472 	mov	a,r7
      008B8E F0               [24] 2473 	movx	@dptr,a
                                   2474 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      008B8F EF               [12] 2475 	mov	a,r7
      008B90 70 02            [24] 2476 	jnz	00435$
      008B92 A1 44            [12] 2477 	ajmp	00169$
      008B94                       2478 00435$:
                                   2479 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008B94 12 8D 76         [24] 2480 	lcall	_ak820_outline_0095
      008B97 BF 01 02         [24] 2481 	cjne	r7,#0x01,00436$
      008B9A 80 12            [24] 2482 	sjmp	00151$
      008B9C                       2483 00436$:
      008B9C 12 8D 76         [24] 2484 	lcall	_ak820_outline_0095
      008B9F BF 02 02         [24] 2485 	cjne	r7,#0x02,00437$
      008BA2 80 0A            [24] 2486 	sjmp	00151$
      008BA4                       2487 00437$:
      008BA4 12 8D 76         [24] 2488 	lcall	_ak820_outline_0095
      008BA7 BF 03 02         [24] 2489 	cjne	r7,#0x03,00438$
      008BAA 80 02            [24] 2490 	sjmp	00439$
      008BAC                       2491 00438$:
      008BAC 81 0D            [12] 2492 	ajmp	00152$
      008BAE                       2493 00439$:
      008BAE                       2494 00151$:
                                   2495 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008BAE 12 8D 4C         [24] 2496 	lcall	_ak820_outline_0000
      008BB1 12 40 67         [24] 2497 	lcall	_eeprom_read_byte
      008BB4 12 8D C7         [24] 2498 	lcall	_ak820_outline_0183
                                   2499 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      008BB7 70 02            [24] 2500 	jnz	00440$
      008BB9 61 30            [12] 2501 	ajmp	00167$
      008BBB                       2502 00440$:
                                   2503 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008BBB 12 8D 76         [24] 2504 	lcall	_ak820_outline_0095
      008BBE BF 01 03         [24] 2505 	cjne	r7,#0x01,00441$
      008BC1 D3               [12] 2506 	setb	c
      008BC2 80 01            [24] 2507 	sjmp	00442$
      008BC4                       2508 00441$:
      008BC4 C3               [12] 2509 	clr	c
      008BC5                       2510 00442$:
      008BC5 92 24            [24] 2511 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008BC7 90 09 8A         [24] 2512 	mov	dptr,#_ak820_macro_primitive
      008BCA B3               [12] 2513 	cpl	c
      008BCB E4               [12] 2514 	clr	a
      008BCC 33               [12] 2515 	rlc	a
      008BCD F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008BCE 12 8D 76         [24] 2518 	lcall	_ak820_outline_0095
      008BD1 BF 01 10         [24] 2519 	cjne	r7,#0x01,00122$
      008BD4 12 8D A8         [24] 2520 	lcall	_ak820_outline_0154
      008BD7 C0 06            [24] 2521 	push	ar6
      008BD9 C0 05            [24] 2522 	push	ar5
      008BDB 12 75 AE         [24] 2523 	lcall	_tap_code
      008BDE D0 05            [24] 2524 	pop	ar5
      008BE0 D0 06            [24] 2525 	pop	ar6
      008BE2 80 24            [24] 2526 	sjmp	00123$
      008BE4                       2527 00122$:
                                   2528 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008BE4 12 8D 76         [24] 2529 	lcall	_ak820_outline_0095
      008BE7 BF 02 10         [24] 2530 	cjne	r7,#0x02,00119$
      008BEA 12 8D A8         [24] 2531 	lcall	_ak820_outline_0154
      008BED C0 06            [24] 2532 	push	ar6
      008BEF C0 05            [24] 2533 	push	ar5
      008BF1 12 74 AA         [24] 2534 	lcall	_register_code
      008BF4 D0 05            [24] 2535 	pop	ar5
      008BF6 D0 06            [24] 2536 	pop	ar6
      008BF8 80 0E            [24] 2537 	sjmp	00123$
      008BFA                       2538 00119$:
                                   2539 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      008BFA 12 8D A8         [24] 2540 	lcall	_ak820_outline_0154
      008BFD C0 06            [24] 2541 	push	ar6
      008BFF C0 05            [24] 2542 	push	ar5
      008C01 12 75 17         [24] 2543 	lcall	_unregister_code
      008C04 D0 05            [24] 2544 	pop	ar5
      008C06 D0 06            [24] 2545 	pop	ar6
      008C08                       2546 00123$:
                                   2547 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      008C08 12 8D AF         [24] 2548 	lcall	_ak820_outline_0168
      008C0B 61 30            [12] 2549 	ajmp	00167$
      008C0D                       2550 00152$:
                                   2551 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008C0D 12 8D 76         [24] 2552 	lcall	_ak820_outline_0095
      008C10 BF 05 02         [24] 2553 	cjne	r7,#0x05,00447$
      008C13 80 12            [24] 2554 	sjmp	00146$
      008C15                       2555 00447$:
      008C15 12 8D 76         [24] 2556 	lcall	_ak820_outline_0095
      008C18 BF 06 02         [24] 2557 	cjne	r7,#0x06,00448$
      008C1B 80 0A            [24] 2558 	sjmp	00146$
      008C1D                       2559 00448$:
      008C1D 12 8D 76         [24] 2560 	lcall	_ak820_outline_0095
      008C20 BF 07 02         [24] 2561 	cjne	r7,#0x07,00449$
      008C23 80 02            [24] 2562 	sjmp	00450$
      008C25                       2563 00449$:
      008C25 81 C9            [12] 2564 	ajmp	00147$
      008C27                       2565 00450$:
      008C27                       2566 00146$:
                                   2567 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C27 12 8D 4C         [24] 2568 	lcall	_ak820_outline_0000
      008C2A 12 40 67         [24] 2569 	lcall	_eeprom_read_byte
      008C2D 12 8D C7         [24] 2570 	lcall	_ak820_outline_0183
                                   2571 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      008C30 70 02            [24] 2572 	jnz	00451$
      008C32 61 30            [12] 2573 	ajmp	00167$
      008C34                       2574 00451$:
                                   2575 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C34 12 8D 4C         [24] 2576 	lcall	_ak820_outline_0000
      008C37 12 40 67         [24] 2577 	lcall	_eeprom_read_byte
      008C3A AF 82            [24] 2578 	mov	r7, dpl
      008C3C 90 0B 48         [24] 2579 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008C3F EF               [12] 2580 	mov	a,r7
      008C40 F0               [24] 2581 	movx	@dptr,a
                                   2582 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      008C41 EF               [12] 2583 	mov	a,r7
      008C42 70 02            [24] 2584 	jnz	00452$
      008C44 61 30            [12] 2585 	ajmp	00167$
      008C46                       2586 00452$:
                                   2587 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008C46 90 0B 47         [24] 2588 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008C49 E0               [24] 2589 	movx	a,@dptr
      008C4A FF               [12] 2590 	mov	r7,a
      008C4B 90 0B 48         [24] 2591 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008C4E E0               [24] 2592 	movx	a,@dptr
      008C4F FB               [12] 2593 	mov	r3,a
      008C50 E4               [12] 2594 	clr	a
      008C51 FC               [12] 2595 	mov	r4,a
      008C52 FA               [12] 2596 	mov	r2,a
      008C53 EF               [12] 2597 	mov	a,r7
      008C54 42 04            [12] 2598 	orl	ar4,a
      008C56 EA               [12] 2599 	mov	a,r2
      008C57 42 03            [12] 2600 	orl	ar3,a
                                   2601 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      008C59 12 43 7B         [24] 2602 	lcall	_ak820_outline_0186
      008C5C C0 06            [24] 2603 	push	ar6
      008C5E C0 05            [24] 2604 	push	ar5
      008C60 51 7C            [12] 2605 	acall	_decode_keycode
      008C62 AC 82            [24] 2606 	mov	r4, dpl
      008C64 AF 83            [24] 2607 	mov	r7, dph
      008C66 D0 05            [24] 2608 	pop	ar5
      008C68 D0 06            [24] 2609 	pop	ar6
                                   2610 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008C6A 90 0B 46         [24] 2611 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008C6D E0               [24] 2612 	movx	a,@dptr
      008C6E FB               [12] 2613 	mov	r3,a
      008C6F BB 05 03         [24] 2614 	cjne	r3,#0x05,00453$
      008C72 D3               [12] 2615 	setb	c
      008C73 80 01            [24] 2616 	sjmp	00454$
      008C75                       2617 00453$:
      008C75 C3               [12] 2618 	clr	c
      008C76                       2619 00454$:
      008C76 92 24            [24] 2620 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008C78 90 09 8A         [24] 2621 	mov	dptr,#_ak820_macro_primitive
      008C7B B3               [12] 2622 	cpl	c
      008C7C E4               [12] 2623 	clr	a
      008C7D 33               [12] 2624 	rlc	a
      008C7E F0               [24] 2625 	movx	@dptr,a
                                   2626 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      008C7F 90 0B 46         [24] 2627 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008C82 E0               [24] 2628 	movx	a,@dptr
      008C83 FB               [12] 2629 	mov	r3,a
      008C84 BB 05 02         [24] 2630 	cjne	r3,#0x05,00455$
      008C87 80 0A            [24] 2631 	sjmp	00126$
      008C89                       2632 00455$:
      008C89 BB 06 02         [24] 2633 	cjne	r3,#0x06,00456$
      008C8C 80 16            [24] 2634 	sjmp	00127$
      008C8E                       2635 00456$:
                                   2636 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      008C8E BB 07 33         [24] 2637 	cjne	r3,#0x07,00129$
      008C91 80 22            [24] 2638 	sjmp	00128$
      008C93                       2639 00126$:
                                   2640 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      008C93 8C 82            [24] 2641 	mov	dpl, r4
      008C95 8F 83            [24] 2642 	mov	dph, r7
      008C97 C0 06            [24] 2643 	push	ar6
      008C99 C0 05            [24] 2644 	push	ar5
      008C9B 12 B0 BD         [24] 2645 	lcall	_vial_keycode_tap
      008C9E D0 05            [24] 2646 	pop	ar5
      008CA0 D0 06            [24] 2647 	pop	ar6
                                   2648 ;	quantum/dynamic_keymap.c:732: break;
                                   2649 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      008CA2 80 20            [24] 2650 	sjmp	00129$
      008CA4                       2651 00127$:
                                   2652 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      008CA4 8C 82            [24] 2653 	mov	dpl, r4
      008CA6 8F 83            [24] 2654 	mov	dph, r7
      008CA8 C0 06            [24] 2655 	push	ar6
      008CAA C0 05            [24] 2656 	push	ar5
      008CAC 12 AF F2         [24] 2657 	lcall	_vial_keycode_down
      008CAF D0 05            [24] 2658 	pop	ar5
      008CB1 D0 06            [24] 2659 	pop	ar6
                                   2660 ;	quantum/dynamic_keymap.c:735: break;
                                   2661 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      008CB3 80 0F            [24] 2662 	sjmp	00129$
      008CB5                       2663 00128$:
                                   2664 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      008CB5 8C 82            [24] 2665 	mov	dpl, r4
      008CB7 8F 83            [24] 2666 	mov	dph, r7
      008CB9 C0 06            [24] 2667 	push	ar6
      008CBB C0 05            [24] 2668 	push	ar5
      008CBD 12 B0 58         [24] 2669 	lcall	_vial_keycode_up
      008CC0 D0 05            [24] 2670 	pop	ar5
      008CC2 D0 06            [24] 2671 	pop	ar6
                                   2672 ;	quantum/dynamic_keymap.c:739: }
      008CC4                       2673 00129$:
                                   2674 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      008CC4 12 8D AF         [24] 2675 	lcall	_ak820_outline_0168
      008CC7 61 30            [12] 2676 	ajmp	00167$
      008CC9                       2677 00147$:
                                   2678 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      008CC9 12 8D 76         [24] 2679 	lcall	_ak820_outline_0095
      008CCC BF 04 02         [24] 2680 	cjne	r7,#0x04,00458$
      008CCF 80 02            [24] 2681 	sjmp	00459$
      008CD1                       2682 00458$:
      008CD1 61 30            [12] 2683 	ajmp	00167$
      008CD3                       2684 00459$:
                                   2685 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008CD3 12 8D 4C         [24] 2686 	lcall	_ak820_outline_0000
      008CD6 12 40 67         [24] 2687 	lcall	_eeprom_read_byte
      008CD9 AF 82            [24] 2688 	mov	r7, dpl
                                   2689 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008CDB 90 0B 43         [24] 2690 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008CDE 12 38 84         [24] 2691 	lcall	_ak820_outline_0124
      008CE1 90 0B 43         [24] 2692 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008CE4 74 01            [12] 2693 	mov	a,#0x01
      008CE6 2B               [12] 2694 	add	a, r3
      008CE7 F0               [24] 2695 	movx	@dptr,a
      008CE8 E4               [12] 2696 	clr	a
      008CE9 3C               [12] 2697 	addc	a, r4
      008CEA A3               [24] 2698 	inc	dptr
      008CEB F0               [24] 2699 	movx	@dptr,a
      008CEC 7A 00            [12] 2700 	mov	r2,#0x00
      008CEE 12 33 FC         [24] 2701 	lcall	_ak820_outline_0125
      008CF1 8A F0            [24] 2702 	mov	b, r2
      008CF3 12 40 67         [24] 2703 	lcall	_eeprom_read_byte
      008CF6 AC 82            [24] 2704 	mov	r4, dpl
                                   2705 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      008CF8 EF               [12] 2706 	mov	a,r7
      008CF9 60 49            [24] 2707 	jz	00169$
      008CFB EC               [12] 2708 	mov	a,r4
      008CFC 60 46            [24] 2709 	jz	00169$
                                   2710 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008CFE 1F               [12] 2711 	dec	r7
      008CFF 1C               [12] 2712 	dec	r4
      008D00 EC               [12] 2713 	mov	a,r4
      008D01 75 F0 FF         [24] 2714 	mov	b,#0xff
      008D04 A4               [48] 2715 	mul	ab
      008D05 FC               [12] 2716 	mov	r4,a
      008D06 AB F0            [24] 2717 	mov	r3,b
      008D08 7A 00            [12] 2718 	mov	r2,#0x00
      008D0A EC               [12] 2719 	mov	a,r4
      008D0B 2F               [12] 2720 	add	a, r7
      008D0C FC               [12] 2721 	mov	r4,a
      008D0D EB               [12] 2722 	mov	a,r3
      008D0E 3A               [12] 2723 	addc	a, r2
      008D0F FB               [12] 2724 	mov	r3,a
                                   2725 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      008D10                       2726 00141$:
      008D10 8C 02            [24] 2727 	mov	ar2,r4
      008D12 8B 07            [24] 2728 	mov	ar7,r3
      008D14 1C               [12] 2729 	dec	r4
      008D15 BC FF 01         [24] 2730 	cjne	r4,#0xff,00462$
      008D18 1B               [12] 2731 	dec	r3
      008D19                       2732 00462$:
      008D19 EA               [12] 2733 	mov	a,r2
      008D1A 4F               [12] 2734 	orl	a,r7
      008D1B 70 02            [24] 2735 	jnz	00463$
      008D1D 61 30            [12] 2736 	ajmp	00167$
      008D1F                       2737 00463$:
      008D1F 90 00 01         [24] 2738 	mov	dptr,#0x0001
      008D22 12 58 7D         [24] 2739 	lcall	_mDelaymS
      008D25 80 E9            [24] 2740 	sjmp	00141$
      008D27                       2741 00164$:
                                   2742 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      008D27 90 0B 45         [24] 2743 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008D2A E0               [24] 2744 	movx	a,@dptr
      008D2B FF               [12] 2745 	mov	r7,a
      008D2C BF 80 00         [24] 2746 	cjne	r7,#0x80,00464$
      008D2F                       2747 00464$:
      008D2F 50 13            [24] 2748 	jnc	00169$
                                   2749 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      008D31 90 0B 45         [24] 2750 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008D34 E0               [24] 2751 	movx	a,@dptr
      008D35 F5 82            [12] 2752 	mov	dpl,a
      008D37 C0 06            [24] 2753 	push	ar6
      008D39 C0 05            [24] 2754 	push	ar5
      008D3B 12 A3 81         [24] 2755 	lcall	_send_char
      008D3E D0 05            [24] 2756 	pop	ar5
      008D40 D0 06            [24] 2757 	pop	ar6
                                   2758 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008D42 61 30            [12] 2759 	ajmp	00167$
      008D44                       2760 00169$:
                                   2761 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      008D44 12 8D AF         [24] 2762 	lcall	_ak820_outline_0168
                                   2763 ;	quantum/dynamic_keymap.c:774: sending = false;
      008D47 90 0B 42         [24] 2764 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008D4A F0               [24] 2765 	movx	@dptr,a
                                   2766 ;	quantum/dynamic_keymap.c:776: }
      008D4B 22               [24] 2767 	ret
                                   2768 	.area CSEG    (CODE)
                                   2769 	.area CONST   (CODE)
                                   2770 	.area XINIT   (CODE)
                                   2771 	.area CABS    (ABS,CODE)
                                   2772 
                                   2773 ; Experimental exact instruction outlining.
                                   2774 	.globl _ak820_outline_0000
                                   2775 	.globl _ak820_outline_0005
                                   2776 	.globl _ak820_outline_0008
                                   2777 	.globl _ak820_outline_0013
                                   2778 	.globl _ak820_outline_0022
                                   2779 	.globl _ak820_outline_0033
                                   2780 	.globl _ak820_outline_0034
                                   2781 	.globl _ak820_outline_0050
                                   2782 	.globl _ak820_outline_0052
                                   2783 	.globl _ak820_outline_0059
                                   2784 	.globl _ak820_outline_0060
                                   2785 	.globl _ak820_outline_0061
                                   2786 	.globl _ak820_outline_0072
                                   2787 	.globl _ak820_outline_0077
                                   2788 	.globl _ak820_outline_0079
                                   2789 	.globl _ak820_outline_0082
                                   2790 	.globl _ak820_outline_0086
                                   2791 	.globl _ak820_outline_0092
                                   2792 	.globl _ak820_outline_0094
                                   2793 	.globl _ak820_outline_0095
                                   2794 	.globl _ak820_outline_0100
                                   2795 	.globl _ak820_outline_0103
                                   2796 	.globl _ak820_outline_0104
                                   2797 	.globl _ak820_outline_0105
                                   2798 	.globl _ak820_outline_0109
                                   2799 	.globl _ak820_outline_0110
                                   2800 	.globl _ak820_outline_0113
                                   2801 	.globl _ak820_outline_0118
                                   2802 	.globl _ak820_outline_0120
                                   2803 	.globl _ak820_outline_0124
                                   2804 	.globl _ak820_outline_0125
                                   2805 	.globl _ak820_outline_0126
                                   2806 	.globl _ak820_outline_0130
                                   2807 	.globl _ak820_outline_0135
                                   2808 	.globl _ak820_outline_0136
                                   2809 	.globl _ak820_outline_0137
                                   2810 	.globl _ak820_outline_0138
                                   2811 	.globl _ak820_outline_0139
                                   2812 	.globl _ak820_outline_0144
                                   2813 	.globl _ak820_outline_0145
                                   2814 	.globl _ak820_outline_0151
                                   2815 	.globl _ak820_outline_0154
                                   2816 	.globl _ak820_outline_0158
                                   2817 	.globl _ak820_outline_0160
                                   2818 	.globl _ak820_outline_0163
                                   2819 	.globl _ak820_outline_0168
                                   2820 	.globl _ak820_outline_0179
                                   2821 	.globl _ak820_outline_0180
                                   2822 	.globl _ak820_outline_0183
                                   2823 	.globl _ak820_outline_0184
                                   2824 	.globl _ak820_outline_0185
                                   2825 	.globl _ak820_outline_0186
                                   2826 	.globl _ak820_outline_0189
                                   2827 
                                   2828 	.area CSEG (CODE)
                                   2829 ; function ak820_outline_0000
      008D4C                       2830 _ak820_outline_0000:
      008D4C 90 0B 43         [24] 2831 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008D4F E0               [24] 2832 	movx	a,@dptr
      008D50 FC               [12] 2833 	mov	r4,a
      008D51 A3               [24] 2834 	inc	dptr
      008D52 E0               [24] 2835 	movx	a,@dptr
      008D53 FF               [12] 2836 	mov	r7,a
      008D54 90 0B 43         [24] 2837 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008D57 74 01            [12] 2838 	mov	a,#0x01
      008D59 2C               [12] 2839 	add	a,r4
      008D5A F0               [24] 2840 	movx	@dptr,a
      008D5B E4               [12] 2841 	clr	a
      008D5C 3F               [12] 2842 	addc	a,r7
      008D5D A3               [24] 2843 	inc	dptr
      008D5E F0               [24] 2844 	movx	@dptr,a
      008D5F 7B 00            [12] 2845 	mov	r3,#0x00
      008D61 8C 82            [24] 2846 	mov	dpl,r4
      008D63 8F 83            [24] 2847 	mov	dph,r7
      008D65 8B F0            [24] 2848 	mov	b,r3
      008D67 22               [24] 2849 	ret
                                   2850 
                                   2851 	.area CSEG (CODE)
                                   2852 ; function ak820_outline_0082
      008D68                       2853 _ak820_outline_0082:
      008D68 ED               [12] 2854 	mov	a,r5
      008D69 75 F0 0A         [24] 2855 	mov	b,#0x0a
      008D6C A4               [48] 2856 	mul	ab
      008D6D 24 58            [12] 2857 	add	a,#0x58
      008D6F FC               [12] 2858 	mov	r4,a
      008D70 74 06            [12] 2859 	mov	a,#0x06
      008D72 35 F0            [12] 2860 	addc	a,b
      008D74 FD               [12] 2861 	mov	r5,a
      008D75 22               [24] 2862 	ret
                                   2863 
                                   2864 	.area CSEG (CODE)
                                   2865 ; function ak820_outline_0095
      008D76                       2866 _ak820_outline_0095:
      008D76 90 0B 46         [24] 2867 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      008D79 E0               [24] 2868 	movx	a,@dptr
      008D7A FF               [12] 2869 	mov	r7,a
      008D7B 22               [24] 2870 	ret
                                   2871 
                                   2872 	.area CSEG (CODE)
                                   2873 ; function ak820_outline_0100
      008D7C                       2874 _ak820_outline_0100:
      008D7C 90 0A DC         [24] 2875 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008D7F EE               [12] 2876 	mov	a,r6
      008D80 F0               [24] 2877 	movx	@dptr,a
      008D81 90 0A DD         [24] 2878 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008D84 ED               [12] 2879 	mov	a,r5
      008D85 F0               [24] 2880 	movx	@dptr,a
      008D86 8F 82            [24] 2881 	mov	dpl,r7
      008D88 22               [24] 2882 	ret
                                   2883 
                                   2884 	.area CSEG (CODE)
                                   2885 ; function ak820_outline_0113
      008D89                       2886 _ak820_outline_0113:
      008D89 74 0A            [12] 2887 	mov	a,#0x0a
      008D8B F0               [24] 2888 	movx	@dptr,a
      008D8C E4               [12] 2889 	clr	a
      008D8D A3               [24] 2890 	inc	dptr
      008D8E F0               [24] 2891 	movx	@dptr,a
      008D8F 22               [24] 2892 	ret
                                   2893 
                                   2894 	.area CSEG (CODE)
                                   2895 ; function ak820_outline_0118
      008D90                       2896 _ak820_outline_0118:
      008D90 AD 82            [24] 2897 	mov	r5,dpl
      008D92 AE 83            [24] 2898 	mov	r6,dph
      008D94 AF F0            [24] 2899 	mov	r7,b
      008D96 22               [24] 2900 	ret
                                   2901 
                                   2902 	.area CSEG (CODE)
                                   2903 ; function ak820_outline_0130
      008D97                       2904 _ak820_outline_0130:
      008D97 28               [12] 2905 	add	a,r0
      008D98 F5 82            [12] 2906 	mov	dpl,a
      008D9A EF               [12] 2907 	mov	a,r7
      008D9B 39               [12] 2908 	addc	a,r1
      008D9C F5 83            [12] 2909 	mov	dph,a
      008D9E 74 FF            [12] 2910 	mov	a,#0xff
      008DA0 F0               [24] 2911 	movx	@dptr,a
      008DA1 22               [24] 2912 	ret
                                   2913 
                                   2914 	.area CSEG (CODE)
                                   2915 ; function ak820_outline_0138
      008DA2                       2916 _ak820_outline_0138:
      008DA2 2D               [12] 2917 	add	a,r5
      008DA3 F9               [12] 2918 	mov	r1,a
      008DA4 E4               [12] 2919 	clr	a
      008DA5 3E               [12] 2920 	addc	a,r6
      008DA6 FA               [12] 2921 	mov	r2,a
      008DA7 22               [24] 2922 	ret
                                   2923 
                                   2924 	.area CSEG (CODE)
                                   2925 ; function ak820_outline_0154
      008DA8                       2926 _ak820_outline_0154:
      008DA8 90 0B 47         [24] 2927 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008DAB E0               [24] 2928 	movx	a,@dptr
      008DAC F5 82            [12] 2929 	mov	dpl,a
      008DAE 22               [24] 2930 	ret
                                   2931 
                                   2932 	.area CSEG (CODE)
                                   2933 ; function ak820_outline_0168
      008DAF                       2934 _ak820_outline_0168:
      008DAF 90 09 8A         [24] 2935 	mov	dptr,#_ak820_macro_primitive
      008DB2 E4               [12] 2936 	clr	a
      008DB3 F0               [24] 2937 	movx	@dptr,a
      008DB4 22               [24] 2938 	ret
                                   2939 
                                   2940 	.area CSEG (CODE)
                                   2941 ; function ak820_outline_0179
      008DB5                       2942 _ak820_outline_0179:
      008DB5 90 0A EC         [24] 2943 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008DB8 E4               [12] 2944 	clr	a
      008DB9 F0               [24] 2945 	movx	@dptr,a
      008DBA 90 0A ED         [24] 2946 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008DBD 22               [24] 2947 	ret
                                   2948 
                                   2949 	.area CSEG (CODE)
                                   2950 ; function ak820_outline_0180
      008DBE                       2951 _ak820_outline_0180:
      008DBE 90 0B A2         [24] 2952 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008DC1 E4               [12] 2953 	clr	a
      008DC2 F0               [24] 2954 	movx	@dptr,a
      008DC3 90 0B A3         [24] 2955 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008DC6 22               [24] 2956 	ret
                                   2957 
                                   2958 	.area CSEG (CODE)
                                   2959 ; function ak820_outline_0183
      008DC7                       2960 _ak820_outline_0183:
      008DC7 AF 82            [24] 2961 	mov	r7,dpl
      008DC9 90 0B 47         [24] 2962 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008DCC EF               [12] 2963 	mov	a,r7
      008DCD F0               [24] 2964 	movx	@dptr,a
      008DCE EF               [12] 2965 	mov	a,r7
      008DCF 22               [24] 2966 	ret
