                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _post_process_record_quantum
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000027                        588 _process_action_sloc0_1_0:
      000027                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      00001F                        606 _process_action_sloc1_1_0:
      00001F                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      000815                        616 _tp_buttons::
      000815                        617 	.ds 2
      000817                        618 _action_exec_PARM_1:
      000817                        619 	.ds 6
      00081D                        620 _action_exec_record_10001_624:
      00081D                        621 	.ds 9
      000826                        622 _ak820_action_exec_event_10000_628:
      000826                        623 	.ds 2
      000828                        624 _ak820_action_exec_snapshot_10000_629:
      000828                        625 	.ds 6
      00082E                        626 _process_record_record_10000_632:
      00082E                        627 	.ds 3
      000831                        628 _process_record_handler_record_argument_10000_640:
      000831                        629 	.ds 3
      000834                        630 _process_record_handler_action_10000_641:
      000834                        631 	.ds 2
      000836                        632 _process_action_PARM_2:
      000836                        633 	.ds 2
      000838                        634 _process_action_record_argument_10000_652:
      000838                        635 	.ds 3
      00083B                        636 _process_action_on_40000_675:
      00083B                        637 	.ds 1
      00083C                        638 _register_code_code_10000_709:
      00083C                        639 	.ds 1
      00083D                        640 _unregister_code_code_10000_723:
      00083D                        641 	.ds 1
      00083E                        642 _tap_code_delay_PARM_2:
      00083E                        643 	.ds 2
      000840                        644 _tap_code_delay_code_10000_736:
      000840                        645 	.ds 1
      000841                        646 _tap_code_code_10000_743:
      000841                        647 	.ds 1
      000842                        648 _register_mods_mods_10000_745:
      000842                        649 	.ds 1
      000843                        650 _unregister_mods_mods_10000_749:
      000843                        651 	.ds 1
      000844                        652 _register_weak_mods_mods_10000_753:
      000844                        653 	.ds 1
      000845                        654 _unregister_weak_mods_mods_10000_757:
      000845                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC4                        664 _disable_action_cache::
      000DC4                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      006FCA                        709 _action_exec:
                                    710 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      006FCA 90 08 19         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006FCD 12 37 E7         [24]  712 	lcall	_ak820_outline_0005
      006FD0 12 35 FF         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      006FD3 90 08 17         [24]  715 	mov	dptr,#_action_exec_PARM_1
      006FD6 12 44 45         [24]  716 	lcall	_ak820_tapping_before
      006FD9 E5 82            [12]  717 	mov	a, dpl
      006FDB 70 01            [24]  718 	jnz	00102$
      006FDD 22               [24]  719 	ret
      006FDE                        720 00102$:
                                    721 ;	quantum/action.c:113: if (event.pressed) {
      006FDE 90 08 1C         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006FE1 E0               [24]  723 	movx	a,@dptr
      006FE2 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:115: clear_weak_mods();
      006FE4 12 80 0B         [24]  726 	lcall	_clear_weak_mods
      006FE7                        727 00104$:
                                    728 ;	quantum/action.c:127: record.event = event;
      006FE7 90 0D A4         [24]  729 	mov	dptr,#___memcpy_PARM_2
      006FEA 74 17            [12]  730 	mov	a,#_action_exec_PARM_1
      006FEC F0               [24]  731 	movx	@dptr,a
      006FED 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      006FEF 12 38 63         [24]  733 	lcall	_ak820_outline_0094
      006FF2 12 76 97         [24]  734 	lcall	_ak820_outline_0071
      006FF5 90 08 1D         [24]  735 	mov	dptr,#_action_exec_record_10001_624
      006FF8 F5 F0            [12]  736 	mov	b,a
      006FFA 12 B6 A6         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:129: record.tap.count = 0;
      006FFD 90 08 23         [24]  739 	mov	dptr,#(_action_exec_record_10001_624 + 0x0006)
      007000 E0               [24]  740 	movx	a,@dptr
      007001 54 0F            [12]  741 	anl	a,#0x0f
      007003 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:134: record.keycode = 0;
      007004 90 08 24         [24]  744 	mov	dptr,#(_action_exec_record_10001_624 + 0x0007)
      007007 12 4F 26         [24]  745 	lcall	_ak820_outline_0184
                                    746 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00700A 90 08 21         [24]  747 	mov	dptr,#(_action_exec_record_10001_624 + 0x0004)
      00700D E0               [24]  748 	movx	a,@dptr
      00700E 60 0D            [24]  749 	jz	00107$
      007010 90 08 1D         [24]  750 	mov	dptr,#_action_exec_record_10001_624
      007013 75 F0 00         [24]  751 	mov	b, #0x00
      007016 12 9D 98         [24]  752 	lcall	_pre_process_record_quantum
      007019 E5 82            [12]  753 	mov	a, dpl
      00701B 60 13            [24]  754 	jz	00110$
      00701D                        755 00107$:
                                    756 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      00701D 90 08 1D         [24]  757 	mov	dptr,#_action_exec_record_10001_624
      007020 12 45 2A         [24]  758 	lcall	_ak820_tapping_process
      007023 E5 82            [12]  759 	mov	a, dpl
      007025 70 01            [24]  760 	jnz	00106$
      007027 22               [24]  761 	ret
      007028                        762 00106$:
                                    763 ;	quantum/action.c:172: process_record(&record);
      007028 90 08 1D         [24]  764 	mov	dptr,#_action_exec_record_10001_624
      00702B 75 F0 00         [24]  765 	mov	b, #0x00
                                    766 ;	quantum/action.c:182: }
      00702E 01 6C            [12]  767 	ajmp	_process_record
      007030                        768 00110$:
      007030 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_628'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_629'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      007031                        780 _ak820_action_exec:
      007031 12 38 75         [24]  781 	lcall	_ak820_outline_0109
      007034 90 08 26         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_628
      007037 12 38 7A         [24]  783 	lcall	_ak820_outline_0110
                                    784 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      00703A 90 08 26         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_628
      00703D 12 38 57         [24]  786 	lcall	_ak820_outline_0080
      007040 7F 00            [12]  787 	mov	r7,#0x00
      007042 90 0D A4         [24]  788 	mov	dptr,#___memcpy_PARM_2
      007045 ED               [12]  789 	mov	a,r5
      007046 12 38 12         [24]  790 	lcall	_ak820_outline_0016
      007049 12 76 97         [24]  791 	lcall	_ak820_outline_0071
      00704C 90 08 28         [24]  792 	mov	dptr,#_ak820_action_exec_snapshot_10000_629
      00704F F5 F0            [12]  793 	mov	b,a
      007051 12 B6 A6         [24]  794 	lcall	___memcpy
                                    795 ;	quantum/action.c:189: action_exec(snapshot);
      007054 90 0D A4         [24]  796 	mov	dptr,#___memcpy_PARM_2
      007057 74 28            [12]  797 	mov	a,#_ak820_action_exec_snapshot_10000_629
      007059 F0               [24]  798 	movx	@dptr,a
      00705A 74 08            [12]  799 	mov	a,#(_ak820_action_exec_snapshot_10000_629 >> 8)
      00705C 12 38 63         [24]  800 	lcall	_ak820_outline_0094
      00705F 12 76 97         [24]  801 	lcall	_ak820_outline_0071
      007062 90 08 17         [24]  802 	mov	dptr,#_action_exec_PARM_1
      007065 F5 F0            [12]  803 	mov	b,a
      007067 12 B6 A6         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:190: }
?ASlink-Warning-2K Page relocation error
      00706A E1 CA            [12]  806 	ajmp	_action_exec
                                    807 ;------------------------------------------------------------
                                    808 ;Allocation info for local variables in function 'process_record_nocache'
                                    809 ;------------------------------------------------------------
                                    810 ;record        Allocated with name '_process_record_nocache_record_10000_630'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    813 ;	-----------------------------------------
                                    814 ;	 function process_record
                                    815 ;	-----------------------------------------
      00706C                        816 _process_record:
      00706C 12 43 06         [24]  817 	lcall	_ak820_outline_0036
      00706F 90 08 2E         [24]  818 	mov	dptr,#_process_record_record_10000_632
      007072 12 38 12         [24]  819 	lcall	_ak820_outline_0016
                                    820 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      007075 90 08 2E         [24]  821 	mov	dptr,#_process_record_record_10000_632
      007078 12 4E D3         [24]  822 	lcall	_ak820_outline_0012
      00707B 74 04            [12]  823 	mov	a,#0x04
      00707D 12 76 6A         [24]  824 	lcall	_ak820_outline_0014
      007080 12 B7 7F         [24]  825 	lcall	__gptrget
      007083 70 01            [24]  826 	jnz	00102$
                                    827 ;	quantum/action.c:330: return;
      007085 22               [24]  828 	ret
      007086                        829 00102$:
                                    830 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007086 8D 02            [24]  831 	mov	ar2,r5
      007088 8E 03            [24]  832 	mov	ar3,r6
      00708A 8F 04            [24]  833 	mov	ar4,r7
      00708C 90 0D A4         [24]  834 	mov	dptr,#___memcpy_PARM_2
      00708F EA               [12]  835 	mov	a,r2
      007090 12 76 DE         [24]  836 	lcall	_ak820_outline_0189
      007093 EC               [12]  837 	mov	a,r4
      007094 A3               [24]  838 	inc	dptr
      007095 F0               [24]  839 	movx	@dptr,a
      007096 90 0D A7         [24]  840 	mov	dptr,#___memcpy_PARM_3
      007099 12 4F 18         [24]  841 	lcall	_ak820_outline_0112
      00709C 90 06 24         [24]  842 	mov	dptr,#_ak820_tapping_source_PARM_1
      00709F F5 F0            [12]  843 	mov	b,a
      0070A1 C0 07            [24]  844 	push	ar7
      0070A3 C0 06            [24]  845 	push	ar6
      0070A5 C0 05            [24]  846 	push	ar5
      0070A7 12 B6 A6         [24]  847 	lcall	___memcpy
      0070AA 12 43 80         [24]  848 	lcall	_ak820_tapping_source
      0070AD AC 82            [24]  849 	mov	r4, dpl
      0070AF D0 05            [24]  850 	pop	ar5
      0070B1 D0 06            [24]  851 	pop	ar6
      0070B3 D0 07            [24]  852 	pop	ar7
                                    853 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      0070B5 74 05            [12]  854 	mov	a,#0x05
      0070B7 12 76 5C         [24]  855 	lcall	_ak820_outline_0013
      0070BA 12 B7 7F         [24]  856 	lcall	__gptrget
      0070BD FB               [12]  857 	mov	r3,a
                                    858 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      0070BE 12 76 C3         [24]  859 	lcall	_ak820_outline_0148
      0070C1 90 0B FB         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      0070C4 74 01            [12]  861 	mov	a,#0x01
      0070C6 12 4E DC         [24]  862 	lcall	_ak820_outline_0034
      0070C9 C0 04            [24]  863 	push	ar4
      0070CB C0 03            [24]  864 	push	ar3
      0070CD C0 02            [24]  865 	push	ar2
      0070CF C0 01            [24]  866 	push	ar1
      0070D1 C0 00            [24]  867 	push	ar0
      0070D3 12 9D 5A         [24]  868 	lcall	_get_record_keycode
      0070D6 12 43 4F         [24]  869 	lcall	_ak820_outline_0135
      0070D9 D0 00            [24]  870 	pop	ar0
      0070DB D0 01            [24]  871 	pop	ar1
      0070DD D0 02            [24]  872 	pop	ar2
      0070DF D0 03            [24]  873 	pop	ar3
      0070E1 D0 04            [24]  874 	pop	ar4
      0070E3 12 48 9C         [24]  875 	lcall	_ak820_outline_0114
      0070E6 EE               [12]  876 	mov	a,r6
      0070E7 12 B7 44         [24]  877 	lcall	__gptrput
      0070EA A3               [24]  878 	inc	dptr
      0070EB EF               [12]  879 	mov	a,r7
      0070EC 12 B7 44         [24]  880 	lcall	__gptrput
                                    881 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0070EF 90 08 2E         [24]  882 	mov	dptr,#_process_record_record_10000_632
      0070F2 12 4E D3         [24]  883 	lcall	_ak820_outline_0012
      0070F5 12 76 C3         [24]  884 	lcall	_ak820_outline_0148
      0070F8 12 48 9C         [24]  885 	lcall	_ak820_outline_0114
      0070FB 12 B7 7F         [24]  886 	lcall	__gptrget
      0070FE F8               [12]  887 	mov	r0,a
      0070FF A3               [24]  888 	inc	dptr
      007100 12 B7 7F         [24]  889 	lcall	__gptrget
      007103 F9               [12]  890 	mov	r1,a
      007104 90 06 34         [24]  891 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007107 EC               [12]  892 	mov	a,r4
      007108 F0               [24]  893 	movx	@dptr,a
      007109 90 06 35         [24]  894 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00710C EB               [12]  895 	mov	a,r3
      00710D F0               [24]  896 	movx	@dptr,a
      00710E 12 38 A9         [24]  897 	lcall	_ak820_outline_0160
      007111 C0 07            [24]  898 	push	ar7
      007113 C0 06            [24]  899 	push	ar6
      007115 C0 05            [24]  900 	push	ar5
      007117 C0 04            [24]  901 	push	ar4
      007119 C0 03            [24]  902 	push	ar3
      00711B 12 46 D8         [24]  903 	lcall	_ak820_oneshot_process
      00711E E5 82            [12]  904 	mov	a, dpl
      007120 D0 03            [24]  905 	pop	ar3
      007122 D0 04            [24]  906 	pop	ar4
      007124 D0 05            [24]  907 	pop	ar5
      007126 D0 06            [24]  908 	pop	ar6
      007128 D0 07            [24]  909 	pop	ar7
      00712A 70 01            [24]  910 	jnz	00104$
      00712C 22               [24]  911 	ret
      00712D                        912 00104$:
                                    913 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      00712D 12 6D 14         [24]  914 	lcall	_ak820_outline_0059
      007130 C0 04            [24]  915 	push	ar4
      007132 C0 03            [24]  916 	push	ar3
      007134 12 9E 1C         [24]  917 	lcall	_process_record_quantum
      007137 E5 82            [12]  918 	mov	a, dpl
      007139 D0 03            [24]  919 	pop	ar3
      00713B D0 04            [24]  920 	pop	ar4
      00713D 70 0A            [24]  921 	jnz	00106$
                                    922 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00713F 90 05 9C         [24]  923 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007142 EB               [12]  924 	mov	a,r3
      007143 F0               [24]  925 	movx	@dptr,a
      007144 8C 82            [24]  926 	mov	dpl, r4
                                    927 ;	quantum/action.c:352: return;
      007146 02 2E BB         [24]  928 	ljmp	_ak820_oneshot_post
      007149                        929 00106$:
                                    930 ;	quantum/action.c:358: process_record_handler(record);
      007149 90 08 2E         [24]  931 	mov	dptr,#_process_record_record_10000_632
      00714C 12 4E AD         [24]  932 	lcall	_ak820_outline_0001
      00714F C0 04            [24]  933 	push	ar4
      007151 C0 03            [24]  934 	push	ar3
      007153 31 6C            [24]  935 	acall	_process_record_handler
                                    936 ;	quantum/action.c:362: post_process_record_quantum(record);
      007155 90 08 2E         [24]  937 	mov	dptr,#_process_record_record_10000_632
      007158 12 4E AD         [24]  938 	lcall	_ak820_outline_0001
      00715B 12 9D F3         [24]  939 	lcall	_post_process_record_quantum
      00715E D0 03            [24]  940 	pop	ar3
      007160 D0 04            [24]  941 	pop	ar4
                                    942 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007162 90 05 9C         [24]  943 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007165 EB               [12]  944 	mov	a,r3
      007166 F0               [24]  945 	movx	@dptr,a
      007167 8C 82            [24]  946 	mov	dpl, r4
                                    947 ;	quantum/action.c:366: }
      007169 02 2E BB         [24]  948 	ljmp	_ak820_oneshot_post
                                    949 ;------------------------------------------------------------
                                    950 ;Allocation info for local variables in function 'process_record_handler'
                                    951 ;------------------------------------------------------------
                                    952 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_640'
                                    953 ;record        Allocated with name '_process_record_handler_record_10000_641'
                                    954 ;action        Allocated with name '_process_record_handler_action_10000_641'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function process_record_handler
                                    959 ;	-----------------------------------------
      00716C                        960 _process_record_handler:
      00716C 12 43 06         [24]  961 	lcall	_ak820_outline_0036
      00716F 90 08 31         [24]  962 	mov	dptr,#_process_record_handler_record_argument_10000_640
      007172 12 38 12         [24]  963 	lcall	_ak820_outline_0016
                                    964 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007175 90 08 31         [24]  965 	mov	dptr,#_process_record_handler_record_argument_10000_640
      007178 12 37 F1         [24]  966 	lcall	_ak820_outline_0007
                                    967 ;	quantum/action.c:379: if (record->keycode) {
      00717B 4C               [12]  968 	orl	a,r4
      00717C 60 19            [24]  969 	jz	00102$
                                    970 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      00717E 12 38 8A         [24]  971 	lcall	_ak820_outline_0126
      007181 C0 07            [24]  972 	push	ar7
      007183 C0 06            [24]  973 	push	ar6
      007185 12 93 AD         [24]  974 	lcall	_action_for_keycode
      007188 12 43 60         [24]  975 	lcall	_ak820_outline_0151
      00718B D0 06            [24]  976 	pop	ar6
      00718D D0 07            [24]  977 	pop	ar7
      00718F 90 08 34         [24]  978 	mov	dptr,#_process_record_handler_action_10000_641
      007192 12 38 51         [24]  979 	lcall	_ak820_outline_0072
      007195 80 2B            [24]  980 	sjmp	00104$
      007197                        981 00102$:
                                    982 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007197 12 76 78         [24]  983 	lcall	_ak820_outline_0021
      00719A 7A 00            [12]  984 	mov	r2,#0x00
      00719C 12 43 5A         [24]  985 	lcall	_ak820_outline_0144
      00719F 12 42 F4         [24]  986 	lcall	_ak820_outline_0011
      0071A2 E0               [24]  987 	movx	a,@dptr
      0071A3 90 09 70         [24]  988 	mov	dptr,#_ak820_resolve_key_PARM_2
      0071A6 F0               [24]  989 	movx	@dptr,a
      0071A7 8D 82            [24]  990 	mov	dpl, r5
      0071A9 8C 83            [24]  991 	mov	dph, r4
      0071AB C0 07            [24]  992 	push	ar7
      0071AD C0 06            [24]  993 	push	ar6
      0071AF 12 7A 0B         [24]  994 	lcall	_ak820_resolve_key
      0071B2 12 93 AD         [24]  995 	lcall	_action_for_keycode
      0071B5 12 43 60         [24]  996 	lcall	_ak820_outline_0151
      0071B8 D0 06            [24]  997 	pop	ar6
      0071BA D0 07            [24]  998 	pop	ar7
      0071BC 90 08 34         [24]  999 	mov	dptr,#_process_record_handler_action_10000_641
      0071BF 12 38 51         [24] 1000 	lcall	_ak820_outline_0072
                                   1001 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      0071C2                       1002 00104$:
                                   1003 ;	quantum/action.c:403: process_action(record, action);
      0071C2 7D 00            [12] 1004 	mov	r5,#0x00
      0071C4 90 0D A4         [24] 1005 	mov	dptr,#___memcpy_PARM_2
      0071C7 74 34            [12] 1006 	mov	a,#_process_record_handler_action_10000_641
      0071C9 F0               [24] 1007 	movx	@dptr,a
      0071CA 74 08            [12] 1008 	mov	a,#(_process_record_handler_action_10000_641 >> 8)
      0071CC 12 38 63         [24] 1009 	lcall	_ak820_outline_0094
      0071CF 90 0D A7         [24] 1010 	mov	dptr,#___memcpy_PARM_3
      0071D2 12 4F 18         [24] 1011 	lcall	_ak820_outline_0112
      0071D5 90 08 36         [24] 1012 	mov	dptr,#_process_action_PARM_2
      0071D8 F5 F0            [12] 1013 	mov	b,a
      0071DA C0 07            [24] 1014 	push	ar7
      0071DC C0 06            [24] 1015 	push	ar6
      0071DE C0 05            [24] 1016 	push	ar5
      0071E0 12 B6 A6         [24] 1017 	lcall	___memcpy
      0071E3 D0 05            [24] 1018 	pop	ar5
      0071E5 D0 06            [24] 1019 	pop	ar6
      0071E7 D0 07            [24] 1020 	pop	ar7
      0071E9 12 6F 35         [24] 1021 	lcall	_ak820_outline_0050
                                   1022 ;	quantum/action.c:404: }
      0071EC 21 EE            [24] 1023 	ajmp	_process_action
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'register_mouse'
                                   1026 ;------------------------------------------------------------
                                   1027 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1028 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_649'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function process_action
                                   1033 ;	-----------------------------------------
      0071EE                       1034 _process_action:
      0071EE 12 43 06         [24] 1035 	lcall	_ak820_outline_0036
      0071F1 90 08 38         [24] 1036 	mov	dptr,#_process_action_record_argument_10000_652
      0071F4 12 38 12         [24] 1037 	lcall	_ak820_outline_0016
                                   1038 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0071F7 90 08 38         [24] 1039 	mov	dptr,#_process_action_record_argument_10000_652
      0071FA 12 37 E7         [24] 1040 	lcall	_ak820_outline_0005
                                   1041 ;	quantum/action.c:475: pressed = record->event.pressed;
      0071FD A3               [24] 1042 	inc	dptr
      0071FE A3               [24] 1043 	inc	dptr
      0071FF A3               [24] 1044 	inc	dptr
      007200 A3               [24] 1045 	inc	dptr
      007201 A3               [24] 1046 	inc	dptr
      007202 E0               [24] 1047 	movx	a,@dptr
      007203 F5 27            [12] 1048 	mov	_process_action_sloc0_1_0,a
                                   1049 ;	quantum/action.c:499: switch (action.kind.id) {
      007205 90 08 37         [24] 1050 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007208 E0               [24] 1051 	movx	a,@dptr
      007209 C4               [12] 1052 	swap	a
      00720A 54 0F            [12] 1053 	anl	a,#0x0f
      00720C FD               [12] 1054 	mov  r5,a
      00720D 24 F4            [12] 1055 	add	a,#0xff - 0x0b
      00720F 50 03            [24] 1056 	jnc	00434$
      007211 02 74 8F         [24] 1057 	ljmp	00181$
      007214                       1058 00434$:
                                   1059 ;	free result
      007214 ED               [12] 1060 	mov	a,r5
      007215 24 0A            [12] 1061 	add	a,#(00435$-3-.)
      007217 83               [24] 1062 	movc	a,@a+pc
      007218 F5 82            [12] 1063 	mov	dpl,a
      00721A ED               [12] 1064 	mov	a,r5
      00721B 24 10            [12] 1065 	add	a,#(00436$-3-.)
      00721D 83               [24] 1066 	movc	a,@a+pc
      00721E F5 83            [12] 1067 	mov	dph,a
      007220 E4               [12] 1068 	clr	a
      007221 73               [24] 1069 	jmp	@a+dptr
      007222                       1070 00435$:
      007222 3A                    1071 	.db	00102$
      007223 3A                    1072 	.db	00102$
      007224 8F                    1073 	.db	00181$
      007225 8F                    1074 	.db	00181$
      007226 C4                    1075 	.db	00123$
      007227 8F                    1076 	.db	00181$
      007228 8F                    1077 	.db	00181$
      007229 8F                    1078 	.db	00181$
      00722A 24                    1079 	.db	00131$
      00722B F6                    1080 	.db	00147$
      00722C 1C                    1081 	.db	00152$
      00722D 1C                    1082 	.db	00152$
      00722E                       1083 00436$:
      00722E 72                    1084 	.db	00102$>>8
      00722F 72                    1085 	.db	00102$>>8
      007230 74                    1086 	.db	00181$>>8
      007231 74                    1087 	.db	00181$>>8
      007232 72                    1088 	.db	00123$>>8
      007233 74                    1089 	.db	00181$>>8
      007234 74                    1090 	.db	00181$>>8
      007235 74                    1091 	.db	00181$>>8
      007236 73                    1092 	.db	00131$>>8
      007237 73                    1093 	.db	00147$>>8
      007238 74                    1094 	.db	00152$>>8
      007239 74                    1095 	.db	00152$>>8
                                   1096 ;	quantum/action.c:502: case ACT_RMODS: {
      00723A                       1097 00102$:
                                   1098 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00723A 90 08 37         [24] 1099 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00723D E0               [24] 1100 	movx	a,@dptr
      00723E 54 F0            [12] 1101 	anl	a,#0xf0
      007240 70 06            [24] 1102 	jnz	00194$
      007242 12 76 B1         [24] 1103 	lcall	_ak820_outline_0115
      007245 FD               [12] 1104 	mov	r5,a
      007246 80 07            [24] 1105 	sjmp	00195$
      007248                       1106 00194$:
      007248 12 76 B1         [24] 1107 	lcall	_ak820_outline_0115
      00724B C4               [12] 1108 	swap	a
      00724C 54 F0            [12] 1109 	anl	a,#0xf0
      00724E FD               [12] 1110 	mov	r5,a
      00724F                       1111 00195$:
                                   1112 ;	quantum/action.c:505: if (pressed) {
      00724F E5 27            [12] 1113 	mov	a,_process_action_sloc0_1_0
      007251 60 35            [24] 1114 	jz	00119$
                                   1115 ;	quantum/action.c:506: if (mods) {
      007253 ED               [12] 1116 	mov	a,r5
      007254 60 29            [24] 1117 	jz	00110$
                                   1118 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007256 12 76 CD         [24] 1119 	lcall	_ak820_outline_0162
      007259 FC               [12] 1120 	mov	r4,a
      00725A BC E0 00         [24] 1121 	cjne	r4,#0xe0,00440$
      00725D                       1122 00440$:
      00725D 40 07            [24] 1123 	jc	00108$
      00725F 12 76 CD         [24] 1124 	lcall	_ak820_outline_0162
      007262 24 18            [12] 1125 	add	a,#0xff - 0xe7
      007264 50 0A            [24] 1126 	jnc	00104$
                                   1127 ;	free result
      007266                       1128 00108$:
      007266 7B 36            [12] 1129 	mov	r3,#_process_action_PARM_2
      007268 7C 08            [12] 1130 	mov	r4,#(_process_action_PARM_2 >> 8)
      00726A 12 33 FC         [24] 1131 	lcall	_ak820_outline_0125
      00726D E0               [24] 1132 	movx	a,@dptr
      00726E 70 07            [24] 1133 	jnz	00105$
      007270                       1134 00104$:
                                   1135 ;	quantum/action.c:511: add_owned_mods(mods);
      007270 8D 82            [24] 1136 	mov	dpl, r5
      007272 12 7C 21         [24] 1137 	lcall	_add_owned_mods
      007275 80 05            [24] 1138 	sjmp	00106$
      007277                       1139 00105$:
                                   1140 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      007277 8D 82            [24] 1141 	mov	dpl, r5
      007279 12 7C 3E         [24] 1142 	lcall	_add_owned_weak_mods
      00727C                       1143 00106$:
                                   1144 ;	quantum/action.c:515: send_keyboard_report();
      00727C 12 7F 5B         [24] 1145 	lcall	_send_keyboard_report
      00727F                       1146 00110$:
                                   1147 ;	quantum/action.c:517: register_code(action.key.code);
      00727F 12 76 A1         [24] 1148 	lcall	_ak820_outline_0078
      007282 12 74 A6         [24] 1149 	lcall	_register_code
      007285 02 74 8F         [24] 1150 	ljmp	00181$
      007288                       1151 00119$:
                                   1152 ;	quantum/action.c:519: unregister_code(action.key.code);
      007288 12 76 A1         [24] 1153 	lcall	_ak820_outline_0078
      00728B C0 05            [24] 1154 	push	ar5
      00728D 12 75 13         [24] 1155 	lcall	_unregister_code
      007290 D0 05            [24] 1156 	pop	ar5
                                   1157 ;	quantum/action.c:520: if (mods) {
      007292 ED               [12] 1158 	mov	a,r5
      007293 70 03            [24] 1159 	jnz	00444$
      007295 02 74 8F         [24] 1160 	ljmp	00181$
      007298                       1161 00444$:
                                   1162 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007298 12 76 CD         [24] 1163 	lcall	_ak820_outline_0162
      00729B FC               [12] 1164 	mov	r4,a
      00729C BC E0 00         [24] 1165 	cjne	r4,#0xe0,00445$
      00729F                       1166 00445$:
      00729F 40 07            [24] 1167 	jc	00115$
      0072A1 12 76 CD         [24] 1168 	lcall	_ak820_outline_0162
      0072A4 24 18            [12] 1169 	add	a,#0xff - 0xe7
      0072A6 50 0A            [24] 1170 	jnc	00111$
                                   1171 ;	free result
      0072A8                       1172 00115$:
      0072A8 7B 36            [12] 1173 	mov	r3,#_process_action_PARM_2
      0072AA 7C 08            [12] 1174 	mov	r4,#(_process_action_PARM_2 >> 8)
      0072AC 12 33 FC         [24] 1175 	lcall	_ak820_outline_0125
      0072AF E0               [24] 1176 	movx	a,@dptr
      0072B0 70 07            [24] 1177 	jnz	00112$
      0072B2                       1178 00111$:
                                   1179 ;	quantum/action.c:522: del_owned_mods(mods);
      0072B2 8D 82            [24] 1180 	mov	dpl, r5
      0072B4 12 7C 30         [24] 1181 	lcall	_del_owned_mods
      0072B7 80 05            [24] 1182 	sjmp	00113$
      0072B9                       1183 00112$:
                                   1184 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      0072B9 8D 82            [24] 1185 	mov	dpl, r5
      0072BB 12 7C 4D         [24] 1186 	lcall	_del_owned_weak_mods
      0072BE                       1187 00113$:
                                   1188 ;	quantum/action.c:526: send_keyboard_report();
      0072BE 12 7F 5B         [24] 1189 	lcall	_send_keyboard_report
                                   1190 ;	quantum/action.c:529: } break;
      0072C1 02 74 8F         [24] 1191 	ljmp	00181$
                                   1192 ;	quantum/action.c:606: case ACT_USAGE:
      0072C4                       1193 00123$:
                                   1194 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0072C4 74 07            [12] 1195 	mov	a,#0x07
      0072C6 12 38 24         [24] 1196 	lcall	_ak820_outline_0022
      0072C9 12 48 10         [24] 1197 	lcall	_ak820_outline_0008
      0072CC C3               [12] 1198 	clr	c
      0072CD EC               [12] 1199 	mov	a,r4
      0072CE 94 A5            [12] 1200 	subb	a,#0xa5
      0072D0 ED               [12] 1201 	mov	a,r5
      0072D1 94 00            [12] 1202 	subb	a,#0x00
      0072D3 40 15            [24] 1203 	jc	00125$
      0072D5 74 C2            [12] 1204 	mov	a,#0xc2
      0072D7 9C               [12] 1205 	subb	a,r4
      0072D8 E4               [12] 1206 	clr	a
      0072D9 9D               [12] 1207 	subb	a,r5
      0072DA 40 0E            [24] 1208 	jc	00125$
                                   1209 ;	free result
                                   1210 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      0072DC 90 0A 97         [24] 1211 	mov	dptr,#_owned_usage_key_PARM_2
      0072DF E5 27            [12] 1212 	mov	a,_process_action_sloc0_1_0
      0072E1 F0               [24] 1213 	movx	@dptr,a
      0072E2 8E 82            [24] 1214 	mov	dpl, r6
      0072E4 12 7E 08         [24] 1215 	lcall	_owned_usage_key
                                   1216 ;	quantum/action.c:614: break;
      0072E7 02 74 8F         [24] 1217 	ljmp	00181$
      0072EA                       1218 00125$:
                                   1219 ;	quantum/action.c:617: switch (action.usage.page) {
      0072EA 12 76 A8         [24] 1220 	lcall	_ak820_outline_0090
      0072ED FF               [12] 1221 	mov	r7,a
      0072EE 60 08            [24] 1222 	jz	00127$
      0072F0 BF 01 02         [24] 1223 	cjne	r7,#0x01,00452$
      0072F3 80 19            [24] 1224 	sjmp	00128$
      0072F5                       1225 00452$:
      0072F5 02 74 8F         [24] 1226 	ljmp	00181$
                                   1227 ;	quantum/action.c:618: case PAGE_SYSTEM:
      0072F8                       1228 00127$:
                                   1229 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      0072F8 E5 27            [12] 1230 	mov	a,_process_action_sloc0_1_0
      0072FA 60 05            [24] 1231 	jz	00196$
      0072FC 12 76 B8         [24] 1232 	lcall	_ak820_outline_0132
      0072FF 80 04            [24] 1233 	sjmp	00197$
      007301                       1234 00196$:
      007301 7E 00            [12] 1235 	mov	r6,#0x00
      007303 7F 00            [12] 1236 	mov	r7,#0x00
      007305                       1237 00197$:
      007305 12 38 7F         [24] 1238 	lcall	_ak820_outline_0120
      007308 12 6C A0         [24] 1239 	lcall	_host_system_send
                                   1240 ;	quantum/action.c:620: break;
      00730B 02 74 8F         [24] 1241 	ljmp	00181$
                                   1242 ;	quantum/action.c:621: case PAGE_CONSUMER:
      00730E                       1243 00128$:
                                   1244 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      00730E E5 27            [12] 1245 	mov	a,_process_action_sloc0_1_0
      007310 60 05            [24] 1246 	jz	00198$
      007312 12 76 B8         [24] 1247 	lcall	_ak820_outline_0132
      007315 80 04            [24] 1248 	sjmp	00199$
      007317                       1249 00198$:
      007317 7E 00            [12] 1250 	mov	r6,#0x00
      007319 7F 00            [12] 1251 	mov	r7,#0x00
      00731B                       1252 00199$:
      00731B 12 38 7F         [24] 1253 	lcall	_ak820_outline_0120
      00731E 12 6C CF         [24] 1254 	lcall	_host_consumer_send
                                   1255 ;	quantum/action.c:625: break;
      007321 02 74 8F         [24] 1256 	ljmp	00181$
                                   1257 ;	quantum/action.c:632: case ACT_LAYER: {
      007324                       1258 00131$:
                                   1259 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      007324 90 08 37         [24] 1260 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007327 E0               [24] 1261 	movx	a,@dptr
      007328 54 03            [12] 1262 	anl	a,#0x03
      00732A 90 08 3B         [24] 1263 	mov	dptr,#_process_action_on_40000_675
      00732D F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00732E E0               [24] 1266 	movx	a,@dptr
      00732F FF               [12] 1267 	mov	r7,a
      007330 60 11            [24] 1268 	jz	00200$
      007332 E5 27            [12] 1269 	mov	a,_process_action_sloc0_1_0
      007334 60 07            [24] 1270 	jz	00202$
      007336 8F 06            [24] 1271 	mov	ar6,r7
      007338 53 06 01         [24] 1272 	anl	ar6,#0x01
      00733B 80 10            [24] 1273 	sjmp	00201$
      00733D                       1274 00202$:
      00733D 74 02            [12] 1275 	mov	a,#0x02
      00733F 5F               [12] 1276 	anl	a,r7
      007340 FE               [12] 1277 	mov	r6,a
      007341 80 0A            [24] 1278 	sjmp	00201$
      007343                       1279 00200$:
      007343 E5 27            [12] 1280 	mov	a,_process_action_sloc0_1_0
      007345 B4 01 00         [24] 1281 	cjne	a,#0x01,00457$
      007348                       1282 00457$:
      007348 92 1F            [24] 1283 	mov  _process_action_sloc1_1_0,c
      00734A E4               [12] 1284 	clr	a
      00734B 33               [12] 1285 	rlc	a
      00734C FE               [12] 1286 	mov	r6,a
      00734D                       1287 00201$:
      00734D EE               [12] 1288 	mov	a,r6
      00734E 70 03            [24] 1289 	jnz	00458$
      007350 02 74 8F         [24] 1290 	ljmp	00181$
      007353                       1291 00458$:
                                   1292 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      007353 12 76 CD         [24] 1293 	lcall	_ak820_outline_0162
      007356 C4               [12] 1294 	swap	a
      007357 03               [12] 1295 	rr	a
      007358 54 07            [12] 1296 	anl	a,#0x07
      00735A 25 E0            [12] 1297 	add	a,acc
      00735C 25 E0            [12] 1298 	add	a,acc
      00735E FF               [12] 1299 	mov	r7,a
                                   1300 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00735F 12 76 CD         [24] 1301 	lcall	_ak820_outline_0162
      007362 54 0F            [12] 1302 	anl	a,#0x0f
      007364 FE               [12] 1303 	mov	r6,a
      007365 8F F0            [24] 1304 	mov	b,r7
      007367 05 F0            [12] 1305 	inc	b
      007369 EE               [12] 1306 	mov	a,r6
      00736A 80 02            [24] 1307 	sjmp	00460$
      00736C                       1308 00459$:
      00736C 25 E0            [12] 1309 	add	a,acc
      00736E                       1310 00460$:
      00736E D5 F0 FB         [24] 1311 	djnz	b,00459$
      007371 FE               [12] 1312 	mov	r6,a
                                   1313 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007372 12 76 CD         [24] 1314 	lcall	_ak820_outline_0162
      007375 30 E4 11         [24] 1315 	jnb	acc.4,00204$
      007378 8F F0            [24] 1316 	mov	b,r7
      00737A 05 F0            [12] 1317 	inc	b
      00737C 74 0F            [12] 1318 	mov	a,#0x0f
      00737E 80 02            [24] 1319 	sjmp	00463$
      007380                       1320 00462$:
      007380 25 E0            [12] 1321 	add	a,acc
      007382                       1322 00463$:
      007382 D5 F0 FB         [24] 1323 	djnz	b,00462$
      007385 F4               [12] 1324 	cpl	a
      007386 FF               [12] 1325 	mov	r7,a
      007387 80 02            [24] 1326 	sjmp	00205$
      007389                       1327 00204$:
      007389 7F 00            [12] 1328 	mov	r7,#0x00
      00738B                       1329 00205$:
                                   1330 ;	quantum/action.c:640: bits |= mask;
      00738B EE               [12] 1331 	mov	a,r6
      00738C 42 07            [12] 1332 	orl	ar7,a
                                   1333 ;	quantum/action.c:641: if (!on) {
      00738E 90 08 3B         [24] 1334 	mov	dptr,#_process_action_on_40000_675
      007391 E0               [24] 1335 	movx	a,@dptr
      007392 70 31            [24] 1336 	jnz	00143$
                                   1337 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      007394 12 76 A8         [24] 1338 	lcall	_ak820_outline_0090
      007397 FE               [12] 1339 	mov	r6,a
      007398 2E               [12] 1340 	add	a,r6
                                   1341 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      007399 90 73 9D         [24] 1342 	mov	dptr,#00465$
      00739C 73               [24] 1343 	jmp	@a+dptr
      00739D                       1344 00465$:
      00739D 80 06            [24] 1345 	sjmp	00132$
      00739F 80 0C            [24] 1346 	sjmp	00133$
      0073A1 80 12            [24] 1347 	sjmp	00134$
      0073A3 80 18            [24] 1348 	sjmp	00135$
      0073A5                       1349 00132$:
      0073A5 8F 82            [24] 1350 	mov	dpl, r7
      0073A7 12 77 28         [24] 1351 	lcall	_default_layer_and
      0073AA 02 74 8F         [24] 1352 	ljmp	00181$
                                   1353 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      0073AD                       1354 00133$:
      0073AD 8F 82            [24] 1355 	mov	dpl, r7
      0073AF 12 77 18         [24] 1356 	lcall	_default_layer_or
      0073B2 02 74 8F         [24] 1357 	ljmp	00181$
                                   1358 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      0073B5                       1359 00134$:
      0073B5 8F 82            [24] 1360 	mov	dpl, r7
      0073B7 12 77 3D         [24] 1361 	lcall	_default_layer_xor
      0073BA 02 74 8F         [24] 1362 	ljmp	00181$
                                   1363 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      0073BD                       1364 00135$:
      0073BD 8F 82            [24] 1365 	mov	dpl, r7
      0073BF 12 77 0E         [24] 1366 	lcall	_default_layer_set
                                   1367 ;	quantum/action.c:647: }
      0073C2 02 74 8F         [24] 1368 	ljmp	00181$
      0073C5                       1369 00143$:
                                   1370 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      0073C5 12 76 A8         [24] 1371 	lcall	_ak820_outline_0090
      0073C8 FE               [12] 1372 	mov	r6,a
      0073C9 2E               [12] 1373 	add	a,r6
                                   1374 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      0073CA 90 73 CE         [24] 1375 	mov	dptr,#00466$
      0073CD 73               [24] 1376 	jmp	@a+dptr
      0073CE                       1377 00466$:
      0073CE 80 06            [24] 1378 	sjmp	00137$
      0073D0 80 0C            [24] 1379 	sjmp	00138$
      0073D2 80 12            [24] 1380 	sjmp	00139$
      0073D4 80 18            [24] 1381 	sjmp	00140$
      0073D6                       1382 00137$:
      0073D6 8F 82            [24] 1383 	mov	dpl, r7
      0073D8 12 78 B8         [24] 1384 	lcall	_layer_and
      0073DB 02 74 8F         [24] 1385 	ljmp	00181$
                                   1386 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      0073DE                       1387 00138$:
      0073DE 8F 82            [24] 1388 	mov	dpl, r7
      0073E0 12 78 A8         [24] 1389 	lcall	_layer_or
      0073E3 02 74 8F         [24] 1390 	ljmp	00181$
                                   1391 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      0073E6                       1392 00139$:
      0073E6 8F 82            [24] 1393 	mov	dpl, r7
      0073E8 12 78 CD         [24] 1394 	lcall	_layer_xor
      0073EB 02 74 8F         [24] 1395 	ljmp	00181$
                                   1396 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      0073EE                       1397 00140$:
      0073EE 8F 82            [24] 1398 	mov	dpl, r7
      0073F0 12 78 49         [24] 1399 	lcall	_layer_state_set
                                   1400 ;	quantum/action.c:657: break;
      0073F3 02 74 8F         [24] 1401 	ljmp	00181$
                                   1402 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      0073F6                       1403 00147$:
                                   1404 ;	quantum/action.c:660: if (pressed) {
      0073F6 E5 27            [12] 1405 	mov	a,_process_action_sloc0_1_0
      0073F8 60 11            [24] 1406 	jz	00149$
                                   1407 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      0073FA 12 76 B1         [24] 1408 	lcall	_ak820_outline_0115
      0073FD F5 82            [12] 1409 	mov	dpl,a
      0073FF 12 77 AC         [24] 1410 	lcall	_layer_hold_on
                                   1411 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      007402 12 76 A1         [24] 1412 	lcall	_ak820_outline_0078
      007405 12 75 C6         [24] 1413 	lcall	_register_mods
      007408 02 74 8F         [24] 1414 	ljmp	00181$
      00740B                       1415 00149$:
                                   1416 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      00740B 12 76 A1         [24] 1417 	lcall	_ak820_outline_0078
      00740E 12 75 DA         [24] 1418 	lcall	_unregister_mods
                                   1419 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      007411 12 76 B1         [24] 1420 	lcall	_ak820_outline_0115
      007414 F5 82            [12] 1421 	mov	dpl,a
      007416 12 77 E3         [24] 1422 	lcall	_layer_hold_off
                                   1423 ;	quantum/action.c:667: break;
      007419 02 74 8F         [24] 1424 	ljmp	00181$
                                   1425 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      00741C                       1426 00152$:
                                   1427 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      00741C 12 76 CD         [24] 1428 	lcall	_ak820_outline_0162
      00741F FF               [12] 1429 	mov	r7,a
      007420 BF F1 02         [24] 1430 	cjne	r7,#0xf1,00468$
      007423 80 0A            [24] 1431 	sjmp	00154$
      007425                       1432 00468$:
      007425 BF F2 02         [24] 1433 	cjne	r7,#0xf2,00469$
      007428 80 19            [24] 1434 	sjmp	00155$
      00742A                       1435 00469$:
                                   1436 ;	quantum/action.c:686: momentary_layer_action:
      00742A BF F3 3B         [24] 1437 	cjne	r7,#0xf3,00160$
      00742D 80 28            [24] 1438 	sjmp	00156$
      00742F                       1439 00154$:
                                   1440 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00742F E5 27            [12] 1441 	mov	a,_process_action_sloc0_1_0
      007431 60 08            [24] 1442 	jz	00206$
      007433 12 76 87         [24] 1443 	lcall	_ak820_outline_0042
      007436 12 77 AC         [24] 1444 	lcall	_layer_hold_on
      007439 80 54            [24] 1445 	sjmp	00181$
      00743B                       1446 00206$:
      00743B 12 76 87         [24] 1447 	lcall	_ak820_outline_0042
      00743E 12 77 E3         [24] 1448 	lcall	_layer_hold_off
                                   1449 ;	quantum/action.c:688: break;
                                   1450 ;	quantum/action.c:689: case OP_OFF_ON:
      007441 80 4C            [24] 1451 	sjmp	00181$
      007443                       1452 00155$:
                                   1453 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007443 E5 27            [12] 1454 	mov	a,_process_action_sloc0_1_0
      007445 60 08            [24] 1455 	jz	00208$
      007447 12 76 87         [24] 1456 	lcall	_ak820_outline_0042
      00744A 12 78 8B         [24] 1457 	lcall	_layer_off
      00744D 80 40            [24] 1458 	sjmp	00181$
      00744F                       1459 00208$:
      00744F 12 76 87         [24] 1460 	lcall	_ak820_outline_0042
      007452 12 78 71         [24] 1461 	lcall	_layer_on
                                   1462 ;	quantum/action.c:691: break;
                                   1463 ;	quantum/action.c:692: case OP_SET_CLEAR:
      007455 80 38            [24] 1464 	sjmp	00181$
      007457                       1465 00156$:
                                   1466 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007457 E5 27            [12] 1467 	mov	a,_process_action_sloc0_1_0
      007459 60 08            [24] 1468 	jz	00210$
      00745B 12 76 87         [24] 1469 	lcall	_ak820_outline_0042
      00745E 12 78 5C         [24] 1470 	lcall	_layer_move
      007461 80 2C            [24] 1471 	sjmp	00181$
      007463                       1472 00210$:
      007463 12 78 57         [24] 1473 	lcall	_layer_clear
                                   1474 ;	quantum/action.c:694: break;
                                   1475 ;	quantum/action.c:740: default:
      007466 80 27            [24] 1476 	sjmp	00181$
      007468                       1477 00160$:
                                   1478 ;	quantum/action.c:747: if (pressed) {
      007468 E5 27            [12] 1479 	mov	a,_process_action_sloc0_1_0
      00746A 60 08            [24] 1480 	jz	00163$
                                   1481 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      00746C 12 76 A1         [24] 1482 	lcall	_ak820_outline_0078
      00746F 12 74 A6         [24] 1483 	lcall	_register_code
                                   1484 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007472 80 1B            [24] 1485 	sjmp	00181$
      007474                       1486 00163$:
                                   1487 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      007474 12 76 CD         [24] 1488 	lcall	_ak820_outline_0162
      007477 FF               [12] 1489 	mov	r7,a
      007478 BF 39 0E         [24] 1490 	cjne	r7,#0x39,00175$
                                   1491 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      00747B 7F 50            [12] 1492 	mov	r7,#0x50
      00747D                       1493 00187$:
      00747D EF               [12] 1494 	mov	a,r7
      00747E 60 09            [24] 1495 	jz	00175$
      007480 90 00 01         [24] 1496 	mov	dptr,#0x0001
      007483 12 58 7A         [24] 1497 	lcall	_mDelaymS
      007486 1F               [12] 1498 	dec	r7
                                   1499 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      007487 80 F4            [24] 1500 	sjmp	00187$
      007489                       1501 00175$:
                                   1502 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      007489 12 76 A1         [24] 1503 	lcall	_ak820_outline_0078
      00748C 12 75 13         [24] 1504 	lcall	_unregister_code
                                   1505 ;	quantum/action.c:840: }
      00748F                       1506 00181$:
                                   1507 ;	quantum/action.c:861: switch (action.kind.id) {
      00748F 90 08 37         [24] 1508 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007492 E0               [24] 1509 	movx	a,@dptr
      007493 C4               [12] 1510 	swap	a
      007494 54 0F            [12] 1511 	anl	a,#0x0f
      007496 FF               [12] 1512 	mov	r7,a
      007497 BF 08 02         [24] 1513 	cjne	r7,#0x08,00478$
      00749A 80 03            [24] 1514 	sjmp	00183$
      00749C                       1515 00478$:
      00749C BF 09 06         [24] 1516 	cjne	r7,#0x09,00192$
                                   1517 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      00749F                       1518 00183$:
                                   1519 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      00749F 12 6C 05         [24] 1520 	lcall	_host_keyboard_leds
                                   1521 ;	quantum/action.c:872: }
                                   1522 ;	quantum/action.c:925: }
      0074A2 02 96 60         [24] 1523 	ljmp	_led_set
      0074A5                       1524 00192$:
      0074A5 22               [24] 1525 	ret
                                   1526 ;------------------------------------------------------------
                                   1527 ;Allocation info for local variables in function 'register_code'
                                   1528 ;------------------------------------------------------------
                                   1529 ;code          Allocated with name '_register_code_code_10000_709'
                                   1530 ;------------------------------------------------------------
                                   1531 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1532 ;	-----------------------------------------
                                   1533 ;	 function register_code
                                   1534 ;	-----------------------------------------
      0074A6                       1535 _register_code:
      0074A6 E5 82            [12] 1536 	mov	a,dpl
      0074A8 90 08 3C         [24] 1537 	mov	dptr,#_register_code_code_10000_709
      0074AB F0               [24] 1538 	movx	@dptr,a
                                   1539 ;	quantum/action.c:932: if (code == KC_NO) {
      0074AC E0               [24] 1540 	movx	a,@dptr
      0074AD FF               [12] 1541 	mov	r7,a
      0074AE 70 01            [24] 1542 	jnz	00123$
                                   1543 ;	quantum/action.c:933: return;
      0074B0 22               [24] 1544 	ret
      0074B1                       1545 00123$:
                                   1546 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      0074B1 BF 04 00         [24] 1547 	cjne	r7,#0x04,00186$
      0074B4                       1548 00186$:
      0074B4 40 12            [24] 1549 	jc	00119$
      0074B6 EF               [12] 1550 	mov	a,r7
      0074B7 24 5B            [12] 1551 	add	a,#0xff - 0xa4
      0074B9 40 0D            [24] 1552 	jc	00119$
                                   1553 ;	free result
                                   1554 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      0074BB 8F 82            [24] 1555 	mov	dpl, r7
      0074BD 12 7C C1         [24] 1556 	lcall	_add_owned_key
      0074C0 E5 82            [12] 1557 	mov	a, dpl
      0074C2 70 01            [24] 1558 	jnz	00104$
      0074C4 22               [24] 1559 	ret
      0074C5                       1560 00104$:
                                   1561 ;	quantum/action.c:987: send_keyboard_report();
      0074C5 02 7F 5B         [24] 1562 	ljmp	_send_keyboard_report
      0074C8                       1563 00119$:
                                   1564 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      0074C8 12 76 D2         [24] 1565 	lcall	_ak820_outline_0170
      0074CB BF E0 00         [24] 1566 	cjne	r7,#0xe0,00190$
      0074CE                       1567 00190$:
      0074CE 40 1A            [24] 1568 	jc	00115$
      0074D0 EF               [12] 1569 	mov	a,r7
      0074D1 24 18            [12] 1570 	add	a,#0xff - 0xe7
      0074D3 40 15            [24] 1571 	jc	00115$
                                   1572 ;	free result
                                   1573 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      0074D5 74 07            [12] 1574 	mov	a,#0x07
      0074D7 5F               [12] 1575 	anl	a,r7
      0074D8 12 76 90         [24] 1576 	lcall	_ak820_outline_0063
      0074DB 80 02            [24] 1577 	sjmp	00194$
      0074DD                       1578 00193$:
      0074DD 25 E0            [12] 1579 	add	a,acc
      0074DF                       1580 00194$:
      0074DF D5 F0 FB         [24] 1581 	djnz	b,00193$
      0074E2 F5 82            [12] 1582 	mov	dpl,a
      0074E4 12 7C 21         [24] 1583 	lcall	_add_owned_mods
                                   1584 ;	quantum/action.c:990: send_keyboard_report();
      0074E7 02 7F 5B         [24] 1585 	ljmp	_send_keyboard_report
      0074EA                       1586 00115$:
                                   1587 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0074EA 12 76 D2         [24] 1588 	lcall	_ak820_outline_0170
      0074ED BF A5 00         [24] 1589 	cjne	r7,#0xa5,00195$
      0074F0                       1590 00195$:
      0074F0 40 05            [24] 1591 	jc	00113$
      0074F2 EF               [12] 1592 	mov	a,r7
      0074F3 24 58            [12] 1593 	add	a,#0xff - 0xa7
      0074F5 50 0D            [24] 1594 	jnc	00108$
                                   1595 ;	free result
      0074F7                       1596 00113$:
      0074F7 12 76 D2         [24] 1597 	lcall	_ak820_outline_0170
      0074FA BF A8 00         [24] 1598 	cjne	r7,#0xa8,00198$
      0074FD                       1599 00198$:
      0074FD 40 13            [24] 1600 	jc	00125$
      0074FF EF               [12] 1601 	mov	a,r7
      007500 24 3D            [12] 1602 	add	a,#0xff - 0xc2
      007502 40 0E            [24] 1603 	jc	00125$
                                   1604 ;	free result
      007504                       1605 00108$:
                                   1606 ;	quantum/action.c:995: owned_usage_key(code, true);
      007504 12 76 D2         [24] 1607 	lcall	_ak820_outline_0170
      007507 90 0A 97         [24] 1608 	mov	dptr,#_owned_usage_key_PARM_2
      00750A 74 01            [12] 1609 	mov	a,#0x01
      00750C F0               [24] 1610 	movx	@dptr,a
      00750D 8F 82            [24] 1611 	mov	dpl, r7
                                   1612 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1613 ;	quantum/action.c:1005: }
      00750F 02 7E 08         [24] 1614 	ljmp	_owned_usage_key
      007512                       1615 00125$:
      007512 22               [24] 1616 	ret
                                   1617 ;------------------------------------------------------------
                                   1618 ;Allocation info for local variables in function 'unregister_code'
                                   1619 ;------------------------------------------------------------
                                   1620 ;code          Allocated with name '_unregister_code_code_10000_723'
                                   1621 ;------------------------------------------------------------
                                   1622 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1623 ;	-----------------------------------------
                                   1624 ;	 function unregister_code
                                   1625 ;	-----------------------------------------
      007513                       1626 _unregister_code:
      007513 E5 82            [12] 1627 	mov	a,dpl
      007515 90 08 3D         [24] 1628 	mov	dptr,#_unregister_code_code_10000_723
      007518 F0               [24] 1629 	movx	@dptr,a
                                   1630 ;	quantum/action.c:1012: if (code == KC_NO) {
      007519 E0               [24] 1631 	movx	a,@dptr
      00751A FF               [12] 1632 	mov	r7,a
      00751B 70 01            [24] 1633 	jnz	00121$
                                   1634 ;	quantum/action.c:1013: return;
      00751D 22               [24] 1635 	ret
      00751E                       1636 00121$:
                                   1637 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      00751E BF 04 00         [24] 1638 	cjne	r7,#0x04,00184$
      007521                       1639 00184$:
      007521 40 12            [24] 1640 	jc	00117$
      007523 EF               [12] 1641 	mov	a,r7
      007524 24 5B            [12] 1642 	add	a,#0xff - 0xa4
      007526 40 0D            [24] 1643 	jc	00117$
                                   1644 ;	free result
                                   1645 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      007528 8F 82            [24] 1646 	mov	dpl, r7
      00752A 12 7D 3D         [24] 1647 	lcall	_del_owned_key
      00752D E5 82            [12] 1648 	mov	a, dpl
      00752F 70 01            [24] 1649 	jnz	00102$
      007531 22               [24] 1650 	ret
      007532                       1651 00102$:
                                   1652 ;	quantum/action.c:1054: send_keyboard_report();
      007532 02 7F 5B         [24] 1653 	ljmp	_send_keyboard_report
      007535                       1654 00117$:
                                   1655 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      007535 12 76 D8         [24] 1656 	lcall	_ak820_outline_0171
      007538 BF E0 00         [24] 1657 	cjne	r7,#0xe0,00188$
      00753B                       1658 00188$:
      00753B 40 1A            [24] 1659 	jc	00113$
      00753D EF               [12] 1660 	mov	a,r7
      00753E 24 18            [12] 1661 	add	a,#0xff - 0xe7
      007540 40 15            [24] 1662 	jc	00113$
                                   1663 ;	free result
                                   1664 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      007542 74 07            [12] 1665 	mov	a,#0x07
      007544 5F               [12] 1666 	anl	a,r7
      007545 12 76 90         [24] 1667 	lcall	_ak820_outline_0063
      007548 80 02            [24] 1668 	sjmp	00192$
      00754A                       1669 00191$:
      00754A 25 E0            [12] 1670 	add	a,acc
      00754C                       1671 00192$:
      00754C D5 F0 FB         [24] 1672 	djnz	b,00191$
      00754F F5 82            [12] 1673 	mov	dpl,a
      007551 12 7C 30         [24] 1674 	lcall	_del_owned_mods
                                   1675 ;	quantum/action.c:1057: send_keyboard_report();
      007554 02 7F 5B         [24] 1676 	ljmp	_send_keyboard_report
      007557                       1677 00113$:
                                   1678 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007557 12 76 D8         [24] 1679 	lcall	_ak820_outline_0171
      00755A BF A5 00         [24] 1680 	cjne	r7,#0xa5,00193$
      00755D                       1681 00193$:
      00755D 40 05            [24] 1682 	jc	00111$
      00755F EF               [12] 1683 	mov	a,r7
      007560 24 58            [12] 1684 	add	a,#0xff - 0xa7
      007562 50 0D            [24] 1685 	jnc	00106$
                                   1686 ;	free result
      007564                       1687 00111$:
      007564 12 76 D8         [24] 1688 	lcall	_ak820_outline_0171
      007567 BF A8 00         [24] 1689 	cjne	r7,#0xa8,00196$
      00756A                       1690 00196$:
      00756A 40 12            [24] 1691 	jc	00123$
      00756C EF               [12] 1692 	mov	a,r7
      00756D 24 3D            [12] 1693 	add	a,#0xff - 0xc2
      00756F 40 0D            [24] 1694 	jc	00123$
                                   1695 ;	free result
      007571                       1696 00106$:
                                   1697 ;	quantum/action.c:1062: owned_usage_key(code, false);
      007571 12 76 D8         [24] 1698 	lcall	_ak820_outline_0171
      007574 90 0A 97         [24] 1699 	mov	dptr,#_owned_usage_key_PARM_2
      007577 E4               [12] 1700 	clr	a
      007578 F0               [24] 1701 	movx	@dptr,a
      007579 8F 82            [24] 1702 	mov	dpl, r7
                                   1703 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1704 ;	quantum/action.c:1072: }
      00757B 02 7E 08         [24] 1705 	ljmp	_owned_usage_key
      00757E                       1706 00123$:
      00757E 22               [24] 1707 	ret
                                   1708 ;------------------------------------------------------------
                                   1709 ;Allocation info for local variables in function 'tap_code_delay'
                                   1710 ;------------------------------------------------------------
                                   1711 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1712 ;code          Allocated with name '_tap_code_delay_code_10000_736'
                                   1713 ;i             Allocated with name '_tap_code_delay_i_20000_738'
                                   1714 ;i             Allocated with name '_tap_code_delay_i_50000_741'
                                   1715 ;------------------------------------------------------------
                                   1716 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1717 ;	-----------------------------------------
                                   1718 ;	 function tap_code_delay
                                   1719 ;	-----------------------------------------
      00757F                       1720 _tap_code_delay:
      00757F E5 82            [12] 1721 	mov	a,dpl
      007581 90 08 40         [24] 1722 	mov	dptr,#_tap_code_delay_code_10000_736
      007584 F0               [24] 1723 	movx	@dptr,a
                                   1724 ;	quantum/action.c:1080: register_code(code);
      007585 E0               [24] 1725 	movx	a,@dptr
      007586 FF               [12] 1726 	mov	r7,a
      007587 F5 82            [12] 1727 	mov	dpl,a
      007589 C0 07            [24] 1728 	push	ar7
      00758B 91 A6            [12] 1729 	acall	_register_code
      00758D D0 07            [24] 1730 	pop	ar7
                                   1731 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      00758F 90 08 3E         [24] 1732 	mov	dptr,#_tap_code_delay_PARM_2
      007592 12 38 57         [24] 1733 	lcall	_ak820_outline_0080
      007595                       1734 00110$:
      007595 ED               [12] 1735 	mov	a,r5
      007596 4E               [12] 1736 	orl	a,r6
      007597 60 0D            [24] 1737 	jz	00105$
                                   1738 ;	quantum/action.c:1082: wait_ms(1);
      007599 90 00 01         [24] 1739 	mov	dptr,#0x0001
      00759C 12 58 7A         [24] 1740 	lcall	_mDelaymS
                                   1741 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      00759F 1D               [12] 1742 	dec	r5
      0075A0 BD FF 01         [24] 1743 	cjne	r5,#0xff,00141$
      0075A3 1E               [12] 1744 	dec	r6
      0075A4                       1745 00141$:
      0075A4 80 EF            [24] 1746 	sjmp	00110$
      0075A6                       1747 00105$:
                                   1748 ;	quantum/action.c:1084: unregister_code(code);
      0075A6 8F 82            [24] 1749 	mov	dpl, r7
                                   1750 ;	quantum/action.c:1085: }
      0075A8 A1 13            [12] 1751 	ajmp	_unregister_code
                                   1752 ;------------------------------------------------------------
                                   1753 ;Allocation info for local variables in function 'tap_code'
                                   1754 ;------------------------------------------------------------
                                   1755 ;code          Allocated with name '_tap_code_code_10000_743'
                                   1756 ;------------------------------------------------------------
                                   1757 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1758 ;	-----------------------------------------
                                   1759 ;	 function tap_code
                                   1760 ;	-----------------------------------------
      0075AA                       1761 _tap_code:
      0075AA E5 82            [12] 1762 	mov	a,dpl
      0075AC 90 08 41         [24] 1763 	mov	dptr,#_tap_code_code_10000_743
      0075AF F0               [24] 1764 	movx	@dptr,a
                                   1765 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0075B0 E0               [24] 1766 	movx	a,@dptr
      0075B1 FF               [12] 1767 	mov	r7,a
      0075B2 BF 39 04         [24] 1768 	cjne	r7,#0x39,00103$
      0075B5 7E 50            [12] 1769 	mov	r6,#0x50
      0075B7 80 02            [24] 1770 	sjmp	00104$
      0075B9                       1771 00103$:
      0075B9 7E 00            [12] 1772 	mov	r6,#0x00
      0075BB                       1773 00104$:
      0075BB 90 08 3E         [24] 1774 	mov	dptr,#_tap_code_delay_PARM_2
      0075BE EE               [12] 1775 	mov	a,r6
      0075BF 12 38 8F         [24] 1776 	lcall	_ak820_outline_0136
      0075C2 8F 82            [24] 1777 	mov	dpl, r7
                                   1778 ;	quantum/action.c:1093: }
      0075C4 A1 7F            [12] 1779 	ajmp	_tap_code_delay
                                   1780 ;------------------------------------------------------------
                                   1781 ;Allocation info for local variables in function 'register_mods'
                                   1782 ;------------------------------------------------------------
                                   1783 ;mods          Allocated with name '_register_mods_mods_10000_745'
                                   1784 ;------------------------------------------------------------
                                   1785 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1786 ;	-----------------------------------------
                                   1787 ;	 function register_mods
                                   1788 ;	-----------------------------------------
      0075C6                       1789 _register_mods:
      0075C6 E5 82            [12] 1790 	mov	a,dpl
      0075C8 90 08 42         [24] 1791 	mov	dptr,#_register_mods_mods_10000_745
      0075CB F0               [24] 1792 	movx	@dptr,a
                                   1793 ;	quantum/action.c:1100: if (mods) {
      0075CC E0               [24] 1794 	movx	a,@dptr
      0075CD FF               [12] 1795 	mov	r7,a
      0075CE E0               [24] 1796 	movx	a,@dptr
      0075CF 60 08            [24] 1797 	jz	00103$
                                   1798 ;	quantum/action.c:1101: add_owned_mods(mods);
      0075D1 8F 82            [24] 1799 	mov	dpl, r7
      0075D3 12 7C 21         [24] 1800 	lcall	_add_owned_mods
                                   1801 ;	quantum/action.c:1102: send_keyboard_report();
                                   1802 ;	quantum/action.c:1104: }
      0075D6 02 7F 5B         [24] 1803 	ljmp	_send_keyboard_report
      0075D9                       1804 00103$:
      0075D9 22               [24] 1805 	ret
                                   1806 ;------------------------------------------------------------
                                   1807 ;Allocation info for local variables in function 'unregister_mods'
                                   1808 ;------------------------------------------------------------
                                   1809 ;mods          Allocated with name '_unregister_mods_mods_10000_749'
                                   1810 ;------------------------------------------------------------
                                   1811 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1812 ;	-----------------------------------------
                                   1813 ;	 function unregister_mods
                                   1814 ;	-----------------------------------------
      0075DA                       1815 _unregister_mods:
      0075DA E5 82            [12] 1816 	mov	a,dpl
      0075DC 90 08 43         [24] 1817 	mov	dptr,#_unregister_mods_mods_10000_749
      0075DF F0               [24] 1818 	movx	@dptr,a
                                   1819 ;	quantum/action.c:1111: if (mods) {
      0075E0 E0               [24] 1820 	movx	a,@dptr
      0075E1 FF               [12] 1821 	mov	r7,a
      0075E2 E0               [24] 1822 	movx	a,@dptr
      0075E3 60 08            [24] 1823 	jz	00103$
                                   1824 ;	quantum/action.c:1112: del_owned_mods(mods);
      0075E5 8F 82            [24] 1825 	mov	dpl, r7
      0075E7 12 7C 30         [24] 1826 	lcall	_del_owned_mods
                                   1827 ;	quantum/action.c:1113: send_keyboard_report();
                                   1828 ;	quantum/action.c:1115: }
      0075EA 02 7F 5B         [24] 1829 	ljmp	_send_keyboard_report
      0075ED                       1830 00103$:
      0075ED 22               [24] 1831 	ret
                                   1832 ;------------------------------------------------------------
                                   1833 ;Allocation info for local variables in function 'register_weak_mods'
                                   1834 ;------------------------------------------------------------
                                   1835 ;mods          Allocated with name '_register_weak_mods_mods_10000_753'
                                   1836 ;------------------------------------------------------------
                                   1837 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1838 ;	-----------------------------------------
                                   1839 ;	 function register_weak_mods
                                   1840 ;	-----------------------------------------
      0075EE                       1841 _register_weak_mods:
      0075EE E5 82            [12] 1842 	mov	a,dpl
      0075F0 90 08 44         [24] 1843 	mov	dptr,#_register_weak_mods_mods_10000_753
      0075F3 F0               [24] 1844 	movx	@dptr,a
                                   1845 ;	quantum/action.c:1122: if (mods) {
      0075F4 E0               [24] 1846 	movx	a,@dptr
      0075F5 FF               [12] 1847 	mov	r7,a
      0075F6 E0               [24] 1848 	movx	a,@dptr
      0075F7 60 08            [24] 1849 	jz	00103$
                                   1850 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      0075F9 8F 82            [24] 1851 	mov	dpl, r7
      0075FB 12 7C 3E         [24] 1852 	lcall	_add_owned_weak_mods
                                   1853 ;	quantum/action.c:1124: send_keyboard_report();
                                   1854 ;	quantum/action.c:1126: }
      0075FE 02 7F 5B         [24] 1855 	ljmp	_send_keyboard_report
      007601                       1856 00103$:
      007601 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1860 ;------------------------------------------------------------
                                   1861 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_757'
                                   1862 ;------------------------------------------------------------
                                   1863 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1864 ;	-----------------------------------------
                                   1865 ;	 function unregister_weak_mods
                                   1866 ;	-----------------------------------------
      007602                       1867 _unregister_weak_mods:
      007602 E5 82            [12] 1868 	mov	a,dpl
      007604 90 08 45         [24] 1869 	mov	dptr,#_unregister_weak_mods_mods_10000_757
      007607 F0               [24] 1870 	movx	@dptr,a
                                   1871 ;	quantum/action.c:1133: if (mods) {
      007608 E0               [24] 1872 	movx	a,@dptr
      007609 FF               [12] 1873 	mov	r7,a
      00760A E0               [24] 1874 	movx	a,@dptr
      00760B 60 08            [24] 1875 	jz	00103$
                                   1876 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      00760D 8F 82            [24] 1877 	mov	dpl, r7
      00760F 12 7C 4D         [24] 1878 	lcall	_del_owned_weak_mods
                                   1879 ;	quantum/action.c:1135: send_keyboard_report();
                                   1880 ;	quantum/action.c:1137: }
      007612 02 7F 5B         [24] 1881 	ljmp	_send_keyboard_report
      007615                       1882 00103$:
      007615 22               [24] 1883 	ret
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'clear_keyboard'
                                   1886 ;------------------------------------------------------------
                                   1887 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1888 ;	-----------------------------------------
                                   1889 ;	 function clear_keyboard
                                   1890 ;	-----------------------------------------
      007616                       1891 _clear_keyboard:
                                   1892 ;	quantum/action.c:1144: clear_mods();
      007616 12 7F D6         [24] 1893 	lcall	_clear_mods
                                   1894 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   1895 ;	quantum/action.c:1146: }
      007619 C1 1B            [12] 1896 	ajmp	_clear_keyboard_but_mods
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function clear_keyboard_but_mods
                                   1903 ;	-----------------------------------------
      00761B                       1904 _clear_keyboard_but_mods:
                                   1905 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00761B 90 0D C9         [24] 1906 	mov	dptr,#_actual_keyboard_report
      00761E 75 F0 00         [24] 1907 	mov	b, #0x00
      007621 12 6E D6         [24] 1908 	lcall	_clear_keys_from_report
                                   1909 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   1910 ;	quantum/action.c:1155: }
      007624 C1 26            [12] 1911 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1912 ;------------------------------------------------------------
                                   1913 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1914 ;------------------------------------------------------------
                                   1915 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   1916 ;	-----------------------------------------
                                   1917 ;	 function clear_keyboard_but_mods_and_keys
                                   1918 ;	-----------------------------------------
      007626                       1919 _clear_keyboard_but_mods_and_keys:
                                   1920 ;	quantum/action.c:1163: ak820_tapping_cancel();
      007626 12 46 B7         [24] 1921 	lcall	_ak820_tapping_cancel
                                   1922 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      007629 12 2E F0         [24] 1923 	lcall	_ak820_oneshot_cancel
                                   1924 ;	quantum/action.c:1174: ak820_combo_cancel();
      00762C 12 35 6C         [24] 1925 	lcall	_ak820_combo_cancel
                                   1926 ;	quantum/action.c:1177: repeat_key_cancel();
      00762F 12 A0 32         [24] 1927 	lcall	_repeat_key_cancel
                                   1928 ;	quantum/action.c:1179: clear_owned_mods();
      007632 12 7C 5C         [24] 1929 	lcall	_clear_owned_mods
                                   1930 ;	quantum/action.c:1180: clear_owned_keys();
      007635 12 7C 94         [24] 1931 	lcall	_clear_owned_keys
                                   1932 ;	quantum/action.c:1181: clear_owned_usages();
      007638 12 7D D0         [24] 1933 	lcall	_clear_owned_usages
                                   1934 ;	quantum/action.c:1182: layer_hold_clear();
      00763B 12 78 1B         [24] 1935 	lcall	_layer_hold_clear
                                   1936 ;	quantum/action.c:1184: clear_macro_tri_layer();
      00763E 12 9B 08         [24] 1937 	lcall	_clear_macro_tri_layer
                                   1938 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007641 90 0D C9         [24] 1939 	mov	dptr,#_actual_keyboard_report
      007644 75 F0 00         [24] 1940 	mov	b, #0x00
      007647 12 6E D6         [24] 1941 	lcall	_clear_keys_from_report
                                   1942 ;	quantum/action.c:1189: host_system_send(0);
      00764A 90 00 00         [24] 1943 	mov	dptr,#0x0000
      00764D 12 6C A0         [24] 1944 	lcall	_host_system_send
                                   1945 ;	quantum/action.c:1190: host_consumer_send(0);
      007650 90 00 00         [24] 1946 	mov	dptr,#0x0000
      007653 12 6C CF         [24] 1947 	lcall	_host_consumer_send
                                   1948 ;	quantum/action.c:1192: clear_weak_mods();
      007656 12 80 0B         [24] 1949 	lcall	_clear_weak_mods
                                   1950 ;	quantum/action.c:1193: send_keyboard_report();
                                   1951 ;	quantum/action.c:1201: }
      007659 02 7F 5B         [24] 1952 	ljmp	_send_keyboard_report
                                   1953 ;------------------------------------------------------------
                                   1954 ;Allocation info for local variables in function 'is_tap_record'
                                   1955 ;------------------------------------------------------------
                                   1956 ;record        Allocated with name '_is_tap_record_record_10000_773'
                                   1957 ;action        Allocated with name '_is_tap_record_action_10001_777'
                                   1958 ;------------------------------------------------------------
                                   1959 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   1960 ;	-----------------------------------------
                                   1961 	.area CSEG    (CODE)
                                   1962 	.area CONST   (CODE)
                                   1963 	.area XINIT   (CODE)
      00BF76                       1964 __xinit__disable_action_cache:
      00BF76 00                    1965 	.db #0x00	;  0
                                   1966 	.area CABS    (ABS,CODE)
                                   1967 
                                   1968 ; Experimental exact instruction outlining.
                                   1969 	.globl _ak820_outline_0001
                                   1970 	.globl _ak820_outline_0005
                                   1971 	.globl _ak820_outline_0007
                                   1972 	.globl _ak820_outline_0008
                                   1973 	.globl _ak820_outline_0011
                                   1974 	.globl _ak820_outline_0012
                                   1975 	.globl _ak820_outline_0013
                                   1976 	.globl _ak820_outline_0014
                                   1977 	.globl _ak820_outline_0016
                                   1978 	.globl _ak820_outline_0021
                                   1979 	.globl _ak820_outline_0022
                                   1980 	.globl _ak820_outline_0034
                                   1981 	.globl _ak820_outline_0036
                                   1982 	.globl _ak820_outline_0042
                                   1983 	.globl _ak820_outline_0050
                                   1984 	.globl _ak820_outline_0059
                                   1985 	.globl _ak820_outline_0063
                                   1986 	.globl _ak820_outline_0071
                                   1987 	.globl _ak820_outline_0072
                                   1988 	.globl _ak820_outline_0078
                                   1989 	.globl _ak820_outline_0080
                                   1990 	.globl _ak820_outline_0090
                                   1991 	.globl _ak820_outline_0094
                                   1992 	.globl _ak820_outline_0109
                                   1993 	.globl _ak820_outline_0110
                                   1994 	.globl _ak820_outline_0112
                                   1995 	.globl _ak820_outline_0114
                                   1996 	.globl _ak820_outline_0115
                                   1997 	.globl _ak820_outline_0120
                                   1998 	.globl _ak820_outline_0125
                                   1999 	.globl _ak820_outline_0126
                                   2000 	.globl _ak820_outline_0132
                                   2001 	.globl _ak820_outline_0135
                                   2002 	.globl _ak820_outline_0136
                                   2003 	.globl _ak820_outline_0144
                                   2004 	.globl _ak820_outline_0148
                                   2005 	.globl _ak820_outline_0151
                                   2006 	.globl _ak820_outline_0160
                                   2007 	.globl _ak820_outline_0162
                                   2008 	.globl _ak820_outline_0170
                                   2009 	.globl _ak820_outline_0171
                                   2010 	.globl _ak820_outline_0184
                                   2011 	.globl _ak820_outline_0189
                                   2012 
                                   2013 	.area CSEG (CODE)
                                   2014 ; function ak820_outline_0013
      00765C                       2015 _ak820_outline_0013:
      00765C 2D               [12] 2016 	add	a,r5
      00765D F9               [12] 2017 	mov	r1,a
      00765E E4               [12] 2018 	clr	a
      00765F 3E               [12] 2019 	addc	a,r6
      007660 FA               [12] 2020 	mov	r2,a
      007661 8F 03            [24] 2021 	mov	ar3,r7
      007663 89 82            [24] 2022 	mov	dpl,r1
      007665 8A 83            [24] 2023 	mov	dph,r2
      007667 8B F0            [24] 2024 	mov	b,r3
      007669 22               [24] 2025 	ret
                                   2026 
                                   2027 	.area CSEG (CODE)
                                   2028 ; function ak820_outline_0014
      00766A                       2029 _ak820_outline_0014:
      00766A 2D               [12] 2030 	add	a,r5
      00766B FA               [12] 2031 	mov	r2,a
      00766C E4               [12] 2032 	clr	a
      00766D 3E               [12] 2033 	addc	a,r6
      00766E FB               [12] 2034 	mov	r3,a
      00766F 8F 04            [24] 2035 	mov	ar4,r7
      007671 8A 82            [24] 2036 	mov	dpl,r2
      007673 8B 83            [24] 2037 	mov	dph,r3
      007675 8C F0            [24] 2038 	mov	b,r4
      007677 22               [24] 2039 	ret
                                   2040 
                                   2041 	.area CSEG (CODE)
                                   2042 ; function ak820_outline_0021
      007678                       2043 _ak820_outline_0021:
      007678 8E 82            [24] 2044 	mov	dpl,r6
      00767A 8F 83            [24] 2045 	mov	dph,r7
      00767C A3               [24] 2046 	inc	dptr
      00767D E0               [24] 2047 	movx	a,@dptr
      00767E FC               [12] 2048 	mov	r4,a
      00767F 7D 00            [12] 2049 	mov	r5,#0x00
      007681 8E 82            [24] 2050 	mov	dpl,r6
      007683 8F 83            [24] 2051 	mov	dph,r7
      007685 E0               [24] 2052 	movx	a,@dptr
      007686 22               [24] 2053 	ret
                                   2054 
                                   2055 	.area CSEG (CODE)
                                   2056 ; function ak820_outline_0042
      007687                       2057 _ak820_outline_0042:
      007687 90 08 37         [24] 2058 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00768A E0               [24] 2059 	movx	a,@dptr
      00768B 54 1F            [12] 2060 	anl	a,#0x1f
      00768D F5 82            [12] 2061 	mov	dpl,a
      00768F 22               [24] 2062 	ret
                                   2063 
                                   2064 	.area CSEG (CODE)
                                   2065 ; function ak820_outline_0063
      007690                       2066 _ak820_outline_0063:
      007690 F5 F0            [12] 2067 	mov	b,a
      007692 05 F0            [12] 2068 	inc	b
      007694 74 01            [12] 2069 	mov	a,#0x01
      007696 22               [24] 2070 	ret
                                   2071 
                                   2072 	.area CSEG (CODE)
                                   2073 ; function ak820_outline_0071
      007697                       2074 _ak820_outline_0071:
      007697 90 0D A7         [24] 2075 	mov	dptr,#___memcpy_PARM_3
      00769A 74 06            [12] 2076 	mov	a,#0x06
      00769C F0               [24] 2077 	movx	@dptr,a
      00769D E4               [12] 2078 	clr	a
      00769E A3               [24] 2079 	inc	dptr
      00769F F0               [24] 2080 	movx	@dptr,a
      0076A0 22               [24] 2081 	ret
                                   2082 
                                   2083 	.area CSEG (CODE)
                                   2084 ; function ak820_outline_0078
      0076A1                       2085 _ak820_outline_0078:
      0076A1 90 08 36         [24] 2086 	mov	dptr,#_process_action_PARM_2
      0076A4 E0               [24] 2087 	movx	a,@dptr
      0076A5 F5 82            [12] 2088 	mov	dpl,a
      0076A7 22               [24] 2089 	ret
                                   2090 
                                   2091 	.area CSEG (CODE)
                                   2092 ; function ak820_outline_0090
      0076A8                       2093 _ak820_outline_0090:
      0076A8 90 08 37         [24] 2094 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076AB E0               [24] 2095 	movx	a,@dptr
      0076AC 03               [12] 2096 	rr	a
      0076AD 03               [12] 2097 	rr	a
      0076AE 54 03            [12] 2098 	anl	a,#0x03
      0076B0 22               [24] 2099 	ret
                                   2100 
                                   2101 	.area CSEG (CODE)
                                   2102 ; function ak820_outline_0115
      0076B1                       2103 _ak820_outline_0115:
      0076B1 90 08 37         [24] 2104 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076B4 E0               [24] 2105 	movx	a,@dptr
      0076B5 54 0F            [12] 2106 	anl	a,#0x0f
      0076B7 22               [24] 2107 	ret
                                   2108 
                                   2109 	.area CSEG (CODE)
                                   2110 ; function ak820_outline_0132
      0076B8                       2111 _ak820_outline_0132:
      0076B8 90 08 36         [24] 2112 	mov	dptr,#_process_action_PARM_2
      0076BB E0               [24] 2113 	movx	a,@dptr
      0076BC FE               [12] 2114 	mov	r6,a
      0076BD A3               [24] 2115 	inc	dptr
      0076BE E0               [24] 2116 	movx	a,@dptr
      0076BF 54 03            [12] 2117 	anl	a,#0x03
      0076C1 FF               [12] 2118 	mov	r7,a
      0076C2 22               [24] 2119 	ret
                                   2120 
                                   2121 	.area CSEG (CODE)
                                   2122 ; function ak820_outline_0148
      0076C3                       2123 _ak820_outline_0148:
      0076C3 74 07            [12] 2124 	mov	a,#0x07
      0076C5 2D               [12] 2125 	add	a,r5
      0076C6 F8               [12] 2126 	mov	r0,a
      0076C7 E4               [12] 2127 	clr	a
      0076C8 3E               [12] 2128 	addc	a,r6
      0076C9 F9               [12] 2129 	mov	r1,a
      0076CA 8F 02            [24] 2130 	mov	ar2,r7
      0076CC 22               [24] 2131 	ret
                                   2132 
                                   2133 	.area CSEG (CODE)
                                   2134 ; function ak820_outline_0162
      0076CD                       2135 _ak820_outline_0162:
      0076CD 90 08 36         [24] 2136 	mov	dptr,#_process_action_PARM_2
      0076D0 E0               [24] 2137 	movx	a,@dptr
      0076D1 22               [24] 2138 	ret
                                   2139 
                                   2140 	.area CSEG (CODE)
                                   2141 ; function ak820_outline_0170
      0076D2                       2142 _ak820_outline_0170:
      0076D2 90 08 3C         [24] 2143 	mov	dptr,#_register_code_code_10000_709
      0076D5 E0               [24] 2144 	movx	a,@dptr
      0076D6 FF               [12] 2145 	mov	r7,a
      0076D7 22               [24] 2146 	ret
                                   2147 
                                   2148 	.area CSEG (CODE)
                                   2149 ; function ak820_outline_0171
      0076D8                       2150 _ak820_outline_0171:
      0076D8 90 08 3D         [24] 2151 	mov	dptr,#_unregister_code_code_10000_723
      0076DB E0               [24] 2152 	movx	a,@dptr
      0076DC FF               [12] 2153 	mov	r7,a
      0076DD 22               [24] 2154 	ret
                                   2155 
                                   2156 	.area CSEG (CODE)
                                   2157 ; function ak820_outline_0189
      0076DE                       2158 _ak820_outline_0189:
      0076DE F0               [24] 2159 	movx	@dptr,a
      0076DF EB               [12] 2160 	mov	a,r3
      0076E0 A3               [24] 2161 	inc	dptr
      0076E1 F0               [24] 2162 	movx	@dptr,a
      0076E2 22               [24] 2163 	ret
