                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _input_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _output_sloc0_1_0:
      000001                        542 	.ds 1
      000002                        543 _ak820_combo_valid_sloc0_1_0:
      000002                        544 	.ds 1
      000003                        545 _ak820_combo_process_sloc0_1_0:
      000003                        546 	.ds 1
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      000422                        555 _input_code_10000_592:
      000422                        556 	.ds 2
      000424                        557 _output_code_10000_594:
      000424                        558 	.ds 2
      000426                        559 _combos:
      000426                        560 	.ds 32
      000446                        561 _saved:
      000446                        562 	.ds 9
      00044F                        563 _active:
      00044F                        564 	.ds 1
      000450                        565 _ak820_combo_valid_entry_10000_596:
      000450                        566 	.ds 2
      000452                        567 _ak820_combo_reload_entry_30000_608:
      000452                        568 	.ds 10
      00045C                        569 _ak820_combo_tick_now_10000_613:
      00045C                        570 	.ds 2
      00045E                        571 _ak820_combo_process_record_10000_616:
      00045E                        572 	.ds 2
      000460                        573 _ak820_combo_process_eligible_10001_631:
      000460                        574 	.ds 1
      000461                        575 _ak820_combo_process_i_40001_634:
      000461                        576 	.ds 1
      000462                        577 _ak820_combo_process_a_50001_635:
      000462                        578 	.ds 1
      000463                        579 _ak820_combo_process_b_50001_635:
      000463                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; absolute external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XABS    (ABS,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; initialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XISEG   (XDATA)
      000DB2                        589 _first:
      000DB2                        590 	.ds 1
      000DB3                        591 _second:
      000DB3                        592 	.ds 1
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    621 ;------------------------------------------------------------
                                    622 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    623 ;------------------------------------------------------------
                                    624 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function input
                                    635 ;	-----------------------------------------
      003468                        636 _input:
      003468 12 38 75         [24]  637 	lcall	_ak820_outline_0109
      00346B 90 04 22         [24]  638 	mov	dptr,#_input_code_10000_592
      00346E 12 38 7A         [24]  639 	lcall	_ak820_outline_0110
      003471 90 04 22         [24]  640 	mov	dptr,#_input_code_10000_592
      003474 12 38 34         [24]  641 	lcall	_ak820_outline_0052
      003477 C3               [12]  642 	clr	c
      003478 EE               [12]  643 	mov	a,r6
      003479 94 04            [12]  644 	subb	a,#0x04
      00347B EF               [12]  645 	mov	a,r7
      00347C 94 00            [12]  646 	subb	a,#0x00
      00347E 40 07            [24]  647 	jc	00103$
      003480 74 A4            [12]  648 	mov	a,#0xa4
      003482 9E               [12]  649 	subb	a,r6
      003483 E4               [12]  650 	clr	a
      003484 9F               [12]  651 	subb	a,r7
      003485 50 04            [24]  652 	jnc	00104$
                                    653 ;	free result
      003487                        654 00103$:
                                    655 ;	assignBit
      003487 C2 00            [12]  656 	clr	_input_sloc0_1_0
      003489 80 02            [24]  657 	sjmp	00105$
      00348B                        658 00104$:
                                    659 ;	assignBit
      00348B D2 00            [12]  660 	setb	_input_sloc0_1_0
      00348D                        661 00105$:
      00348D A2 00            [12]  662 	mov	c,_input_sloc0_1_0
      00348F 12 38 A4         [24]  663 	lcall	_ak820_outline_0159
      003492 22               [24]  664 	ret
                                    665 ;------------------------------------------------------------
                                    666 ;Allocation info for local variables in function 'output'
                                    667 ;------------------------------------------------------------
                                    668 ;code          Allocated with name '_output_code_10000_594'
                                    669 ;basic         Allocated with name '_output_basic_10000_595'
                                    670 ;------------------------------------------------------------
                                    671 ;	keyboards/ajazz/ak820/ak820_combo.c:10: static bool output(uint16_t code) {
                                    672 ;	-----------------------------------------
                                    673 ;	 function output
                                    674 ;	-----------------------------------------
      003493                        675 _output:
      003493 12 38 75         [24]  676 	lcall	_ak820_outline_0109
      003496 90 04 24         [24]  677 	mov	dptr,#_output_code_10000_594
      003499 12 38 7A         [24]  678 	lcall	_ak820_outline_0110
                                    679 ;	keyboards/ajazz/ak820/ak820_combo.c:11: uint8_t basic = code;
      00349C 90 04 24         [24]  680 	mov	dptr,#_output_code_10000_594
      00349F 12 38 34         [24]  681 	lcall	_ak820_outline_0052
      0034A2 8E 05            [24]  682 	mov	ar5,r6
                                    683 ;	keyboards/ajazz/ak820/ak820_combo.c:12: return code < QK_MOD_TAP && (input(basic) || (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI));
      0034A4 74 E0            [12]  684 	mov	a,#0x100 - 0x20
      0034A6 2F               [12]  685 	add	a,r7
      0034A7 40 1B            [24]  686 	jc	00103$
      0034A9 8D 06            [24]  687 	mov	ar6,r5
      0034AB 7F 00            [12]  688 	mov	r7,#0x00
      0034AD 12 38 7F         [24]  689 	lcall	_ak820_outline_0120
      0034B0 C0 05            [24]  690 	push	ar5
      0034B2 91 68            [12]  691 	acall	_input
      0034B4 E5 82            [12]  692 	mov	a, dpl
      0034B6 D0 05            [24]  693 	pop	ar5
      0034B8 70 0E            [24]  694 	jnz	00104$
      0034BA BD E0 00         [24]  695 	cjne	r5,#0xe0,00135$
      0034BD                        696 00135$:
      0034BD 40 05            [24]  697 	jc	00103$
      0034BF ED               [12]  698 	mov	a,r5
      0034C0 24 18            [12]  699 	add	a,#0xff - 0xe7
      0034C2 50 04            [24]  700 	jnc	00104$
                                    701 ;	free result
      0034C4                        702 00103$:
                                    703 ;	assignBit
      0034C4 C2 01            [12]  704 	clr	_output_sloc0_1_0
      0034C6 80 02            [24]  705 	sjmp	00105$
      0034C8                        706 00104$:
                                    707 ;	assignBit
      0034C8 D2 01            [12]  708 	setb	_output_sloc0_1_0
      0034CA                        709 00105$:
      0034CA A2 01            [12]  710 	mov	c,_output_sloc0_1_0
      0034CC 12 38 A4         [24]  711 	lcall	_ak820_outline_0159
                                    712 ;	keyboards/ajazz/ak820/ak820_combo.c:13: }
      0034CF 22               [24]  713 	ret
                                    714 ;------------------------------------------------------------
                                    715 ;Allocation info for local variables in function 'ak820_combo_valid'
                                    716 ;------------------------------------------------------------
                                    717 ;entry         Allocated with name '_ak820_combo_valid_entry_10000_596'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_combo.c:19: bool ak820_combo_valid(const vial_combo_entry_t AK820_STATE_MEM *entry) {
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_combo_valid
                                    722 ;	-----------------------------------------
      0034D0                        723 _ak820_combo_valid:
      0034D0 12 38 75         [24]  724 	lcall	_ak820_outline_0109
      0034D3 90 04 50         [24]  725 	mov	dptr,#_ak820_combo_valid_entry_10000_596
      0034D6 12 38 7A         [24]  726 	lcall	_ak820_outline_0110
                                    727 ;	keyboards/ajazz/ak820/ak820_combo.c:20: if (entry->input[2] || entry->input[3]) return false;
      0034D9 90 04 50         [24]  728 	mov	dptr,#_ak820_combo_valid_entry_10000_596
      0034DC 12 37 E7         [24]  729 	lcall	_ak820_outline_0005
      0034DF A3               [24]  730 	inc	dptr
      0034E0 A3               [24]  731 	inc	dptr
      0034E1 A3               [24]  732 	inc	dptr
      0034E2 A3               [24]  733 	inc	dptr
      0034E3 E0               [24]  734 	movx	a,@dptr
      0034E4 FC               [12]  735 	mov	r4,a
      0034E5 A3               [24]  736 	inc	dptr
      0034E6 E0               [24]  737 	movx	a,@dptr
      0034E7 4C               [12]  738 	orl	a,r4
      0034E8 70 0C            [24]  739 	jnz	00101$
      0034EA 74 06            [12]  740 	mov	a,#0x06
      0034EC 12 38 24         [24]  741 	lcall	_ak820_outline_0022
      0034EF E0               [24]  742 	movx	a,@dptr
      0034F0 FC               [12]  743 	mov	r4,a
      0034F1 A3               [24]  744 	inc	dptr
      0034F2 E0               [24]  745 	movx	a,@dptr
      0034F3 4C               [12]  746 	orl	a,r4
      0034F4 60 04            [24]  747 	jz	00102$
      0034F6                        748 00101$:
      0034F6 75 82 00         [24]  749 	mov	dpl, #0x00
      0034F9 22               [24]  750 	ret
      0034FA                        751 00102$:
                                    752 ;	keyboards/ajazz/ak820/ak820_combo.c:21: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      0034FA 8E 04            [24]  753 	mov	ar4,r6
      0034FC 8F 05            [24]  754 	mov	ar5,r7
      0034FE 12 38 2C         [24]  755 	lcall	_ak820_outline_0037
      003501 FA               [12]  756 	mov	r2,a
      003502 A3               [24]  757 	inc	dptr
      003503 E0               [24]  758 	movx	a,@dptr
      003504 FB               [12]  759 	mov	r3,a
      003505 12 38 8A         [24]  760 	lcall	_ak820_outline_0126
      003508 12 38 4B         [24]  761 	lcall	_ak820_outline_0061
      00350B EA               [12]  762 	mov	a,r2
      00350C 4C               [12]  763 	orl	a,r4
      00350D F8               [12]  764 	mov	r0,a
      00350E EB               [12]  765 	mov	a,r3
      00350F 4D               [12]  766 	orl	a,r5
      003510 48               [12]  767 	orl	a,r0
      003511 70 13            [24]  768 	jnz	00105$
      003513 74 08            [12]  769 	mov	a,#0x08
      003515 12 38 24         [24]  770 	lcall	_ak820_outline_0022
      003518 E0               [24]  771 	movx	a,@dptr
      003519 F8               [12]  772 	mov	r0,a
      00351A A3               [24]  773 	inc	dptr
      00351B E0               [24]  774 	movx	a,@dptr
      00351C 48               [12]  775 	orl	a,r0
      00351D B4 01 00         [24]  776 	cjne	a,#0x01,00152$
      003520                        777 00152$:
      003520 92 02            [24]  778 	mov  _ak820_combo_valid_sloc0_1_0,c
      003522 12 38 A4         [24]  779 	lcall	_ak820_outline_0159
      003525 22               [24]  780 	ret
      003526                        781 00105$:
                                    782 ;	keyboards/ajazz/ak820/ak820_combo.c:22: if (entry->input[0] == entry->input[1]) return false;
      003526 EC               [12]  783 	mov	a,r4
      003527 B5 02 08         [24]  784 	cjne	a,ar2,00107$
      00352A ED               [12]  785 	mov	a,r5
      00352B B5 03 04         [24]  786 	cjne	a,ar3,00107$
      00352E 75 82 00         [24]  787 	mov	dpl, #0x00
      003531 22               [24]  788 	ret
      003532                        789 00107$:
                                    790 ;	keyboards/ajazz/ak820/ak820_combo.c:23: if (!input(entry->input[0])) return false;
      003532 12 38 8A         [24]  791 	lcall	_ak820_outline_0126
      003535 C0 07            [24]  792 	push	ar7
      003537 C0 06            [24]  793 	push	ar6
      003539 C0 03            [24]  794 	push	ar3
      00353B C0 02            [24]  795 	push	ar2
      00353D 91 68            [12]  796 	acall	_input
      00353F E5 82            [12]  797 	mov	a, dpl
      003541 D0 02            [24]  798 	pop	ar2
      003543 D0 03            [24]  799 	pop	ar3
      003545 D0 06            [24]  800 	pop	ar6
      003547 D0 07            [24]  801 	pop	ar7
      003549 70 03            [24]  802 	jnz	00109$
      00354B F5 82            [12]  803 	mov	dpl,a
      00354D 22               [24]  804 	ret
      00354E                        805 00109$:
                                    806 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (!input(entry->input[1])) return false;
      00354E 12 38 9F         [24]  807 	lcall	_ak820_outline_0145
      003551 C0 07            [24]  808 	push	ar7
      003553 C0 06            [24]  809 	push	ar6
      003555 91 68            [12]  810 	acall	_input
      003557 E5 82            [12]  811 	mov	a, dpl
      003559 D0 06            [24]  812 	pop	ar6
      00355B D0 07            [24]  813 	pop	ar7
      00355D 70 03            [24]  814 	jnz	00111$
      00355F F5 82            [12]  815 	mov	dpl,a
      003561 22               [24]  816 	ret
      003562                        817 00111$:
                                    818 ;	keyboards/ajazz/ak820/ak820_combo.c:25: return output(entry->output);
      003562 74 08            [12]  819 	mov	a,#0x08
      003564 12 38 24         [24]  820 	lcall	_ak820_outline_0022
      003567 12 37 E7         [24]  821 	lcall	_ak820_outline_0005
                                    822 ;	keyboards/ajazz/ak820/ak820_combo.c:26: }
      00356A 81 93            [12]  823 	ajmp	_output
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    826 ;------------------------------------------------------------
                                    827 ;	keyboards/ajazz/ak820/ak820_combo.c:29: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    828 ;	-----------------------------------------
                                    829 ;	 function ak820_combo_cancel
                                    830 ;	-----------------------------------------
      00356C                        831 _ak820_combo_cancel:
      00356C 90 0D B3         [24]  832 	mov	dptr,#_second
      00356F 74 FF            [12]  833 	mov	a,#0xff
      003571 F0               [24]  834 	movx	@dptr,a
      003572 90 0D B2         [24]  835 	mov	dptr,#_first
      003575 F0               [24]  836 	movx	@dptr,a
      003576 90 04 4F         [24]  837 	mov	dptr,#_active
      003579 E4               [12]  838 	clr	a
      00357A F0               [24]  839 	movx	@dptr,a
      00357B 22               [24]  840 	ret
                                    841 ;------------------------------------------------------------
                                    842 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    843 ;------------------------------------------------------------
                                    844 ;i             Allocated with name '_ak820_combo_reload_i_20000_607'
                                    845 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_608'
                                    846 ;------------------------------------------------------------
                                    847 ;	keyboards/ajazz/ak820/ak820_combo.c:30: void ak820_combo_reload(void) {
                                    848 ;	-----------------------------------------
                                    849 ;	 function ak820_combo_reload
                                    850 ;	-----------------------------------------
      00357C                        851 _ak820_combo_reload:
                                    852 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00357C 7F 00            [12]  853 	mov	r7,#0x00
      00357E                        854 00105$:
      00357E BF 08 00         [24]  855 	cjne	r7,#0x08,00131$
      003581                        856 00131$:
      003581 40 01            [24]  857 	jc	00132$
      003583 22               [24]  858 	ret
      003584                        859 00132$:
                                    860 ;	keyboards/ajazz/ak820/ak820_combo.c:33: combos[i].a = 0;
      003584 EF               [12]  861 	mov	a,r7
      003585 75 F0 04         [24]  862 	mov	b,#0x04
      003588 A4               [48]  863 	mul	ab
      003589 24 26            [12]  864 	add	a, #_combos
      00358B FD               [12]  865 	mov	r5,a
      00358C 74 04            [12]  866 	mov	a,#(_combos >> 8)
      00358E 35 F0            [12]  867 	addc	a, b
      003590 FE               [12]  868 	mov	r6,a
      003591 8D 03            [24]  869 	mov	ar3,r5
      003593 8E 04            [24]  870 	mov	ar4,r6
      003595 12 33 FC         [24]  871 	lcall	_ak820_outline_0125
      003598 E4               [12]  872 	clr	a
      003599 F0               [24]  873 	movx	@dptr,a
                                    874 ;	keyboards/ajazz/ak820/ak820_combo.c:34: if (!dynamic_keymap_get_combo(i, &entry)) {
      00359A 90 0A F1         [24]  875 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00359D 74 52            [12]  876 	mov	a,#_ak820_combo_reload_entry_30000_608
      00359F F0               [24]  877 	movx	@dptr,a
      0035A0 74 04            [12]  878 	mov	a,#(_ak820_combo_reload_entry_30000_608 >> 8)
      0035A2 12 38 63         [24]  879 	lcall	_ak820_outline_0094
      0035A5 8F 82            [24]  880 	mov	dpl, r7
      0035A7 C0 07            [24]  881 	push	ar7
      0035A9 C0 06            [24]  882 	push	ar6
      0035AB C0 05            [24]  883 	push	ar5
      0035AD C0 04            [24]  884 	push	ar4
      0035AF C0 03            [24]  885 	push	ar3
      0035B1 12 84 CB         [24]  886 	lcall	_dynamic_keymap_get_combo
      0035B4 12 38 99         [24]  887 	lcall	_ak820_outline_0140
      0035B7 D0 03            [24]  888 	pop	ar3
      0035B9 D0 04            [24]  889 	pop	ar4
      0035BB D0 05            [24]  890 	pop	ar5
      0035BD D0 06            [24]  891 	pop	ar6
      0035BF D0 07            [24]  892 	pop	ar7
      0035C1 45 F0            [12]  893 	orl	a,b
      0035C3 70 28            [24]  894 	jnz	00106$
                                    895 ;	keyboards/ajazz/ak820/ak820_combo.c:35: combos[i].a = entry.input[0];
      0035C5 90 04 52         [24]  896 	mov	dptr,#_ak820_combo_reload_entry_30000_608
      0035C8 E0               [24]  897 	movx	a,@dptr
      0035C9 12 33 FC         [24]  898 	lcall	_ak820_outline_0125
      0035CC F0               [24]  899 	movx	@dptr,a
                                    900 ;	keyboards/ajazz/ak820/ak820_combo.c:36: combos[i].b = entry.input[1];
      0035CD 74 01            [12]  901 	mov	a,#0x01
      0035CF 2D               [12]  902 	add	a, r5
      0035D0 FB               [12]  903 	mov	r3,a
      0035D1 E4               [12]  904 	clr	a
      0035D2 3E               [12]  905 	addc	a, r6
      0035D3 FC               [12]  906 	mov	r4,a
      0035D4 90 04 54         [24]  907 	mov	dptr,#(_ak820_combo_reload_entry_30000_608 + 0x0002)
      0035D7 E0               [24]  908 	movx	a,@dptr
      0035D8 12 33 FC         [24]  909 	lcall	_ak820_outline_0125
      0035DB F0               [24]  910 	movx	@dptr,a
                                    911 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].output = entry.output;
      0035DC 74 02            [12]  912 	mov	a,#0x02
      0035DE 12 38 AE         [24]  913 	lcall	_ak820_outline_0163
      0035E1 90 04 5A         [24]  914 	mov	dptr,#(_ak820_combo_reload_entry_30000_608 + 0x0008)
      0035E4 12 38 84         [24]  915 	lcall	_ak820_outline_0124
      0035E7 12 38 94         [24]  916 	lcall	_ak820_outline_0137
      0035EA 12 38 5D         [24]  917 	lcall	_ak820_outline_0086
      0035ED                        918 00106$:
                                    919 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035ED 0F               [12]  920 	inc	r7
                                    921 ;	keyboards/ajazz/ak820/ak820_combo.c:40: }
      0035EE A1 7E            [24]  922 	ajmp	00105$
                                    923 ;------------------------------------------------------------
                                    924 ;Allocation info for local variables in function 'flush'
                                    925 ;------------------------------------------------------------
                                    926 ;	keyboards/ajazz/ak820/ak820_combo.c:41: static void flush(void) {
                                    927 ;	-----------------------------------------
                                    928 ;	 function flush
                                    929 ;	-----------------------------------------
      0035F0                        930 _flush:
                                    931 ;	keyboards/ajazz/ak820/ak820_combo.c:42: first = NONE;
      0035F0 90 0D B2         [24]  932 	mov	dptr,#_first
      0035F3 74 FF            [12]  933 	mov	a,#0xff
      0035F5 F0               [24]  934 	movx	@dptr,a
                                    935 ;	keyboards/ajazz/ak820/ak820_combo.c:43: process_record(&saved);
      0035F6 90 04 46         [24]  936 	mov	dptr,#_saved
      0035F9 75 F0 00         [24]  937 	mov	b, #0x00
                                    938 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      0035FC 02 70 70         [24]  939 	ljmp	_process_record
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    942 ;------------------------------------------------------------
                                    943 ;now           Allocated with name '_ak820_combo_tick_now_10000_613'
                                    944 ;------------------------------------------------------------
                                    945 ;	keyboards/ajazz/ak820/ak820_combo.c:45: void ak820_combo_tick(uint16_t now) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function ak820_combo_tick
                                    948 ;	-----------------------------------------
      0035FF                        949 _ak820_combo_tick:
      0035FF 12 38 75         [24]  950 	lcall	_ak820_outline_0109
      003602 90 04 5C         [24]  951 	mov	dptr,#_ak820_combo_tick_now_10000_613
      003605 12 38 7A         [24]  952 	lcall	_ak820_outline_0110
                                    953 ;	keyboards/ajazz/ak820/ak820_combo.c:46: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= 40) flush();
      003608 12 38 B4         [24]  954 	lcall	_ak820_outline_0187
      00360B FF               [12]  955 	mov	r7,a
      00360C BF FF 01         [24]  956 	cjne	r7,#0xff,00128$
      00360F 22               [24]  957 	ret
      003610                        958 00128$:
      003610 90 04 4F         [24]  959 	mov	dptr,#_active
      003613 E0               [24]  960 	movx	a,@dptr
      003614 70 1E            [24]  961 	jnz	00105$
      003616 90 04 48         [24]  962 	mov	dptr,#(_saved + 0x0002)
      003619 12 38 34         [24]  963 	lcall	_ak820_outline_0052
      00361C 90 04 5C         [24]  964 	mov	dptr,#_ak820_combo_tick_now_10000_613
      00361F 12 38 4B         [24]  965 	lcall	_ak820_outline_0061
      003622 EC               [12]  966 	mov	a,r4
      003623 C3               [12]  967 	clr	c
      003624 9E               [12]  968 	subb	a,r6
      003625 FE               [12]  969 	mov	r6,a
      003626 ED               [12]  970 	mov	a,r5
      003627 9F               [12]  971 	subb	a,r7
      003628 FF               [12]  972 	mov	r7,a
      003629 C3               [12]  973 	clr	c
      00362A EE               [12]  974 	mov	a,r6
      00362B 94 28            [12]  975 	subb	a,#0x28
      00362D EF               [12]  976 	mov	a,r7
      00362E 94 00            [12]  977 	subb	a,#0x00
      003630 40 02            [24]  978 	jc	00105$
                                    979 ;	keyboards/ajazz/ak820/ak820_combo.c:47: }
      003632 A1 F0            [24]  980 	ajmp	_flush
      003634                        981 00105$:
      003634 22               [24]  982 	ret
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'ak820_combo_process'
                                    985 ;------------------------------------------------------------
                                    986 ;record        Allocated with name '_ak820_combo_process_record_10000_616'
                                    987 ;id            Allocated with name '_ak820_combo_process_id_10000_617'
                                    988 ;code          Allocated with name '_ak820_combo_process_code_10000_617'
                                    989 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_631'
                                    990 ;previous      Allocated with name '_ak820_combo_process_previous_30001_633'
                                    991 ;i             Allocated with name '_ak820_combo_process_i_40001_634'
                                    992 ;a             Allocated with name '_ak820_combo_process_a_50001_635'
                                    993 ;b             Allocated with name '_ak820_combo_process_b_50001_635'
                                    994 ;------------------------------------------------------------
                                    995 ;	keyboards/ajazz/ak820/ak820_combo.c:48: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    996 ;	-----------------------------------------
                                    997 ;	 function ak820_combo_process
                                    998 ;	-----------------------------------------
      003635                        999 _ak820_combo_process:
      003635 12 38 75         [24] 1000 	lcall	_ak820_outline_0109
      003638 90 04 5E         [24] 1001 	mov	dptr,#_ak820_combo_process_record_10000_616
      00363B 12 38 7A         [24] 1002 	lcall	_ak820_outline_0110
                                   1003 ;	keyboards/ajazz/ak820/ak820_combo.c:49: uint8_t id, code = record->keycode;
      00363E 90 04 5E         [24] 1004 	mov	dptr,#_ak820_combo_process_record_10000_616
      003641 12 37 F1         [24] 1005 	lcall	_ak820_outline_0007
      003644 8C 03            [24] 1006 	mov	ar3,r4
                                   1007 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (IS_NOEVENT(record->event)) return true;
      003646 74 04            [12] 1008 	mov	a,#0x04
      003648 2E               [12] 1009 	add	a, r6
      003649 12 38 1A         [24] 1010 	lcall	_ak820_outline_0017
      00364C 70 04            [24] 1011 	jnz	00102$
      00364E 75 82 01         [24] 1012 	mov	dpl, #0x01
      003651 22               [24] 1013 	ret
      003652                       1014 00102$:
                                   1015 ;	keyboards/ajazz/ak820/ak820_combo.c:52: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      003652 12 38 7F         [24] 1016 	lcall	_ak820_outline_0120
      003655 A3               [24] 1017 	inc	dptr
      003656 E0               [24] 1018 	movx	a,@dptr
      003657 FA               [12] 1019 	mov	r2,a
      003658 BA 10 00         [24] 1020 	cjne	r2,#0x10,00300$
      00365B                       1021 00300$:
      00365B 50 0A            [24] 1022 	jnc	00106$
      00365D 12 38 7F         [24] 1023 	lcall	_ak820_outline_0120
      003660 E0               [24] 1024 	movx	a,@dptr
      003661 F9               [12] 1025 	mov	r1,a
      003662 B9 08 00         [24] 1026 	cjne	r1,#0x08,00302$
      003665                       1027 00302$:
      003665 40 15            [24] 1028 	jc	00107$
      003667                       1029 00106$:
                                   1030 ;	keyboards/ajazz/ak820/ak820_combo.c:53: if (first != NONE && !active) flush();
      003667 12 38 B4         [24] 1031 	lcall	_ak820_outline_0187
      00366A F8               [12] 1032 	mov	r0,a
      00366B B8 FF 02         [24] 1033 	cjne	r0,#0xff,00304$
      00366E 80 08            [24] 1034 	sjmp	00104$
      003670                       1035 00304$:
      003670 90 04 4F         [24] 1036 	mov	dptr,#_active
      003673 E0               [24] 1037 	movx	a,@dptr
      003674 70 02            [24] 1038 	jnz	00104$
      003676 B1 F0            [24] 1039 	acall	_flush
      003678                       1040 00104$:
                                   1041 ;	keyboards/ajazz/ak820/ak820_combo.c:54: return true;
      003678 75 82 01         [24] 1042 	mov	dpl, #0x01
      00367B 22               [24] 1043 	ret
      00367C                       1044 00107$:
                                   1045 ;	keyboards/ajazz/ak820/ak820_combo.c:56: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      00367C EA               [12] 1046 	mov	a,r2
      00367D 12 38 B9         [24] 1047 	lcall	_ak820_outline_0192
      003680 29               [12] 1048 	add	a,r1
      003681 FA               [12] 1049 	mov	r2,a
                                   1050 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (active) {
      003682 90 04 4F         [24] 1051 	mov	dptr,#_active
      003685 E0               [24] 1052 	movx	a,@dptr
      003686 60 71            [24] 1053 	jz	00123$
                                   1054 ;	keyboards/ajazz/ak820/ak820_combo.c:58: if (id != first && id != second) return true;
      003688 12 38 B4         [24] 1055 	lcall	_ak820_outline_0187
      00368B F9               [12] 1056 	mov	r1,a
      00368C EA               [12] 1057 	mov	a,r2
      00368D B5 01 02         [24] 1058 	cjne	a,ar1,00307$
      003690 80 0F            [24] 1059 	sjmp	00110$
      003692                       1060 00307$:
      003692 90 0D B3         [24] 1061 	mov	dptr,#_second
      003695 E0               [24] 1062 	movx	a,@dptr
      003696 F9               [12] 1063 	mov	r1,a
      003697 EA               [12] 1064 	mov	a,r2
      003698 B5 01 02         [24] 1065 	cjne	a,ar1,00308$
      00369B 80 04            [24] 1066 	sjmp	00110$
      00369D                       1067 00308$:
      00369D 75 82 01         [24] 1068 	mov	dpl, #0x01
      0036A0 22               [24] 1069 	ret
      0036A1                       1070 00110$:
                                   1071 ;	keyboards/ajazz/ak820/ak820_combo.c:59: if (!record->event.pressed) {
      0036A1 90 04 5E         [24] 1072 	mov	dptr,#_ak820_combo_process_record_10000_616
      0036A4 12 38 6F         [24] 1073 	lcall	_ak820_outline_0104
      0036A7 74 05            [12] 1074 	mov	a,#0x05
      0036A9 28               [12] 1075 	add	a, r0
      0036AA F8               [12] 1076 	mov	r0,a
      0036AB E4               [12] 1077 	clr	a
      0036AC 39               [12] 1078 	addc	a, r1
      0036AD F9               [12] 1079 	mov	r1,a
      0036AE 12 38 A9         [24] 1080 	lcall	_ak820_outline_0160
      0036B1 E0               [24] 1081 	movx	a,@dptr
      0036B2 70 41            [24] 1082 	jnz	00121$
                                   1083 ;	keyboards/ajazz/ak820/ak820_combo.c:60: if (saved.event.pressed) {
      0036B4 90 04 4B         [24] 1084 	mov	dptr,#(_saved + 0x0005)
      0036B7 E0               [24] 1085 	movx	a,@dptr
      0036B8 60 11            [24] 1086 	jz	00113$
                                   1087 ;	keyboards/ajazz/ak820/ak820_combo.c:61: saved.event.pressed = false;
      0036BA 90 04 4B         [24] 1088 	mov	dptr,#(_saved + 0x0005)
      0036BD E4               [12] 1089 	clr	a
      0036BE F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	keyboards/ajazz/ak820/ak820_combo.c:62: process_record(&saved);
      0036BF 90 04 46         [24] 1092 	mov	dptr,#_saved
      0036C2 F5 F0            [12] 1093 	mov	b,a
      0036C4 C0 02            [24] 1094 	push	ar2
      0036C6 12 70 70         [24] 1095 	lcall	_process_record
      0036C9 D0 02            [24] 1096 	pop	ar2
      0036CB                       1097 00113$:
                                   1098 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (id == first) first = NONE;
      0036CB 12 38 B4         [24] 1099 	lcall	_ak820_outline_0187
      0036CE F9               [12] 1100 	mov	r1,a
      0036CF EA               [12] 1101 	mov	a,r2
      0036D0 B5 01 08         [24] 1102 	cjne	a,ar1,00115$
      0036D3 90 0D B2         [24] 1103 	mov	dptr,#_first
      0036D6 74 FF            [12] 1104 	mov	a,#0xff
      0036D8 F0               [24] 1105 	movx	@dptr,a
      0036D9 80 06            [24] 1106 	sjmp	00116$
      0036DB                       1107 00115$:
                                   1108 ;	keyboards/ajazz/ak820/ak820_combo.c:65: else second = NONE;
      0036DB 90 0D B3         [24] 1109 	mov	dptr,#_second
      0036DE 74 FF            [12] 1110 	mov	a,#0xff
      0036E0 F0               [24] 1111 	movx	@dptr,a
      0036E1                       1112 00116$:
                                   1113 ;	keyboards/ajazz/ak820/ak820_combo.c:66: if (first == NONE && second == NONE) active = false;
      0036E1 12 38 B4         [24] 1114 	lcall	_ak820_outline_0187
      0036E4 F9               [12] 1115 	mov	r1,a
      0036E5 B9 FF 0D         [24] 1116 	cjne	r1,#0xff,00121$
      0036E8 90 0D B3         [24] 1117 	mov	dptr,#_second
      0036EB E0               [24] 1118 	movx	a,@dptr
      0036EC F9               [12] 1119 	mov	r1,a
      0036ED B9 FF 05         [24] 1120 	cjne	r1,#0xff,00121$
      0036F0 90 04 4F         [24] 1121 	mov	dptr,#_active
      0036F3 E4               [12] 1122 	clr	a
      0036F4 F0               [24] 1123 	movx	@dptr,a
      0036F5                       1124 00121$:
                                   1125 ;	keyboards/ajazz/ak820/ak820_combo.c:68: return false;
      0036F5 75 82 00         [24] 1126 	mov	dpl, #0x00
      0036F8 22               [24] 1127 	ret
      0036F9                       1128 00123$:
                                   1129 ;	keyboards/ajazz/ak820/ak820_combo.c:70: bool eligible = false;
      0036F9 90 04 60         [24] 1130 	mov	dptr,#_ak820_combo_process_eligible_10001_631
      0036FC E4               [12] 1131 	clr	a
      0036FD F0               [24] 1132 	movx	@dptr,a
                                   1133 ;	keyboards/ajazz/ak820/ak820_combo.c:71: if (record->event.pressed && input(record->keycode)) {
      0036FE 12 38 05         [24] 1134 	lcall	_ak820_outline_0009
      003701 70 02            [24] 1135 	jnz	00317$
      003703 E1 A6            [12] 1136 	ajmp	00134$
      003705                       1137 00317$:
      003705 12 38 8A         [24] 1138 	lcall	_ak820_outline_0126
      003708 C0 03            [24] 1139 	push	ar3
      00370A C0 02            [24] 1140 	push	ar2
      00370C 91 68            [12] 1141 	acall	_input
      00370E E5 82            [12] 1142 	mov	a, dpl
      003710 D0 02            [24] 1143 	pop	ar2
      003712 D0 03            [24] 1144 	pop	ar3
      003714 70 02            [24] 1145 	jnz	00318$
      003716 E1 A6            [12] 1146 	ajmp	00134$
      003718                       1147 00318$:
                                   1148 ;	keyboards/ajazz/ak820/ak820_combo.c:72: uint8_t previous = saved.keycode;
      003718 90 04 4D         [24] 1149 	mov	dptr,#(_saved + 0x0007)
      00371B E0               [24] 1150 	movx	a,@dptr
      00371C FF               [12] 1151 	mov	r7,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00371D 90 04 61         [24] 1153 	mov	dptr,#_ak820_combo_process_i_40001_634
      003720 E4               [12] 1154 	clr	a
      003721 F0               [24] 1155 	movx	@dptr,a
      003722 EB               [12] 1156 	mov	a,r3
      003723 B5 07 03         [24] 1157 	cjne	a,ar7,00319$
      003726 D3               [12] 1158 	setb	c
      003727 80 01            [24] 1159 	sjmp	00320$
      003729                       1160 00319$:
      003729 C3               [12] 1161 	clr	c
      00372A                       1162 00320$:
      00372A 92 03            [24] 1163 	mov	_ak820_combo_process_sloc0_1_0,c
      00372C 7E 00            [12] 1164 	mov	r6,#0x00
      00372E                       1165 00141$:
      00372E BE 08 00         [24] 1166 	cjne	r6,#0x08,00321$
      003731                       1167 00321$:
      003731 40 02            [24] 1168 	jc	00322$
      003733 E1 A6            [12] 1169 	ajmp	00134$
      003735                       1170 00322$:
                                   1171 ;	keyboards/ajazz/ak820/ak820_combo.c:74: uint8_t a = combos[i].a, b = combos[i].b;
      003735 EE               [12] 1172 	mov	a,r6
      003736 12 38 3A         [24] 1173 	lcall	_ak820_outline_0054
      003739 E0               [24] 1174 	movx	a,@dptr
      00373A F9               [12] 1175 	mov	r1,a
      00373B 90 04 62         [24] 1176 	mov	dptr,#_ak820_combo_process_a_50001_635
      00373E 12 38 69         [24] 1177 	lcall	_ak820_outline_0103
      003741 A3               [24] 1178 	inc	dptr
      003742 E0               [24] 1179 	movx	a,@dptr
      003743 FD               [12] 1180 	mov	r5,a
      003744 90 04 63         [24] 1181 	mov	dptr,#_ak820_combo_process_b_50001_635
      003747 F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (a == code || b == code) {
      003748 E9               [12] 1184 	mov	a,r1
      003749 B5 03 02         [24] 1185 	cjne	a,ar3,00323$
      00374C 80 04            [24] 1186 	sjmp	00129$
      00374E                       1187 00323$:
      00374E ED               [12] 1188 	mov	a,r5
      00374F B5 03 4C         [24] 1189 	cjne	a,ar3,00142$
      003752                       1190 00129$:
                                   1191 ;	keyboards/ajazz/ak820/ak820_combo.c:76: eligible = true;
      003752 90 04 60         [24] 1192 	mov	dptr,#_ak820_combo_process_eligible_10001_631
      003755 74 01            [12] 1193 	mov	a,#0x01
      003757 F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	keyboards/ajazz/ak820/ak820_combo.c:77: if (first != NONE && code != previous && (a == previous || b == previous)) {
      003758 12 38 B4         [24] 1196 	lcall	_ak820_outline_0187
      00375B FD               [12] 1197 	mov	r5,a
      00375C BD FF 02         [24] 1198 	cjne	r5,#0xff,00326$
      00375F 80 3D            [24] 1199 	sjmp	00142$
      003761                       1200 00326$:
      003761 20 03 3A         [24] 1201 	jb	_ak820_combo_process_sloc0_1_0,00142$
      003764 90 04 62         [24] 1202 	mov	dptr,#_ak820_combo_process_a_50001_635
      003767 E0               [24] 1203 	movx	a,@dptr
      003768 B5 07 02         [24] 1204 	cjne	a,ar7,00328$
      00376B 80 07            [24] 1205 	sjmp	00124$
      00376D                       1206 00328$:
      00376D 90 04 63         [24] 1207 	mov	dptr,#_ak820_combo_process_b_50001_635
      003770 E0               [24] 1208 	movx	a,@dptr
      003771 B5 07 2A         [24] 1209 	cjne	a,ar7,00142$
      003774                       1210 00124$:
                                   1211 ;	keyboards/ajazz/ak820/ak820_combo.c:78: second = id;
      003774 90 0D B3         [24] 1212 	mov	dptr,#_second
      003777 EA               [12] 1213 	mov	a,r2
      003778 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_combo.c:79: active = true;
      003779 90 04 4F         [24] 1216 	mov	dptr,#_active
      00377C 74 01            [12] 1217 	mov	a,#0x01
      00377E F0               [24] 1218 	movx	@dptr,a
                                   1219 ;	keyboards/ajazz/ak820/ak820_combo.c:80: saved.keycode = combos[i].output;
      00377F 90 04 61         [24] 1220 	mov	dptr,#_ak820_combo_process_i_40001_634
      003782 E0               [24] 1221 	movx	a,@dptr
      003783 12 38 3A         [24] 1222 	lcall	_ak820_outline_0054
      003786 A3               [24] 1223 	inc	dptr
      003787 A3               [24] 1224 	inc	dptr
      003788 12 38 4B         [24] 1225 	lcall	_ak820_outline_0061
      00378B 90 04 4D         [24] 1226 	mov	dptr,#(_saved + 0x0007)
      00378E 12 38 51         [24] 1227 	lcall	_ak820_outline_0072
                                   1228 ;	keyboards/ajazz/ak820/ak820_combo.c:81: process_record(&saved);
      003791 90 04 46         [24] 1229 	mov	dptr,#_saved
      003794 75 F0 00         [24] 1230 	mov	b, #0x00
      003797 12 70 70         [24] 1231 	lcall	_process_record
                                   1232 ;	keyboards/ajazz/ak820/ak820_combo.c:82: return false;
      00379A 75 82 00         [24] 1233 	mov	dpl, #0x00
      00379D 22               [24] 1234 	ret
      00379E                       1235 00142$:
                                   1236 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00379E 0E               [12] 1237 	inc	r6
      00379F 90 04 61         [24] 1238 	mov	dptr,#_ak820_combo_process_i_40001_634
      0037A2 EE               [12] 1239 	mov	a,r6
      0037A3 F0               [24] 1240 	movx	@dptr,a
      0037A4 E1 2E            [24] 1241 	ajmp	00141$
      0037A6                       1242 00134$:
                                   1243 ;	keyboards/ajazz/ak820/ak820_combo.c:87: if (first != NONE) flush();
      0037A6 12 38 B4         [24] 1244 	lcall	_ak820_outline_0187
      0037A9 FF               [12] 1245 	mov	r7,a
      0037AA BF FF 02         [24] 1246 	cjne	r7,#0xff,00331$
      0037AD 80 06            [24] 1247 	sjmp	00137$
      0037AF                       1248 00331$:
      0037AF C0 02            [24] 1249 	push	ar2
      0037B1 B1 F0            [24] 1250 	acall	_flush
      0037B3 D0 02            [24] 1251 	pop	ar2
      0037B5                       1252 00137$:
                                   1253 ;	keyboards/ajazz/ak820/ak820_combo.c:88: if (eligible) {
      0037B5 90 04 60         [24] 1254 	mov	dptr,#_ak820_combo_process_eligible_10001_631
      0037B8 E0               [24] 1255 	movx	a,@dptr
      0037B9 60 28            [24] 1256 	jz	00139$
                                   1257 ;	keyboards/ajazz/ak820/ak820_combo.c:89: first = id;
      0037BB 90 0D B2         [24] 1258 	mov	dptr,#_first
      0037BE EA               [12] 1259 	mov	a,r2
      0037BF F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	keyboards/ajazz/ak820/ak820_combo.c:90: saved = *record;
      0037C0 90 04 5E         [24] 1262 	mov	dptr,#_ak820_combo_process_record_10000_616
      0037C3 12 38 57         [24] 1263 	lcall	_ak820_outline_0080
      0037C6 7F 00            [12] 1264 	mov	r7,#0x00
      0037C8 90 0D A4         [24] 1265 	mov	dptr,#___memcpy_PARM_2
      0037CB ED               [12] 1266 	mov	a,r5
      0037CC 12 38 12         [24] 1267 	lcall	_ak820_outline_0016
      0037CF 90 0D A7         [24] 1268 	mov	dptr,#___memcpy_PARM_3
      0037D2 74 09            [12] 1269 	mov	a,#0x09
      0037D4 12 38 8F         [24] 1270 	lcall	_ak820_outline_0136
      0037D7 90 04 46         [24] 1271 	mov	dptr,#_saved
      0037DA F5 F0            [12] 1272 	mov	b,a
      0037DC 12 B6 B5         [24] 1273 	lcall	___memcpy
                                   1274 ;	keyboards/ajazz/ak820/ak820_combo.c:91: return false;
      0037DF 75 82 00         [24] 1275 	mov	dpl, #0x00
      0037E2 22               [24] 1276 	ret
      0037E3                       1277 00139$:
                                   1278 ;	keyboards/ajazz/ak820/ak820_combo.c:93: return true;
      0037E3 75 82 01         [24] 1279 	mov	dpl, #0x01
                                   1280 ;	keyboards/ajazz/ak820/ak820_combo.c:94: }
      0037E6 22               [24] 1281 	ret
                                   1282 	.area CSEG    (CODE)
                                   1283 	.area CONST   (CODE)
                                   1284 	.area XINIT   (CODE)
      00BF73                       1285 __xinit__first:
      00BF73 FF                    1286 	.db #0xff	; 255
      00BF74                       1287 __xinit__second:
      00BF74 FF                    1288 	.db #0xff	; 255
                                   1289 	.area CABS    (ABS,CODE)
                                   1290 
                                   1291 ; Experimental exact instruction outlining.
                                   1292 	.globl _ak820_outline_0005
                                   1293 	.globl _ak820_outline_0007
                                   1294 	.globl _ak820_outline_0009
                                   1295 	.globl _ak820_outline_0016
                                   1296 	.globl _ak820_outline_0017
                                   1297 	.globl _ak820_outline_0022
                                   1298 	.globl _ak820_outline_0037
                                   1299 	.globl _ak820_outline_0052
                                   1300 	.globl _ak820_outline_0054
                                   1301 	.globl _ak820_outline_0061
                                   1302 	.globl _ak820_outline_0072
                                   1303 	.globl _ak820_outline_0080
                                   1304 	.globl _ak820_outline_0086
                                   1305 	.globl _ak820_outline_0094
                                   1306 	.globl _ak820_outline_0103
                                   1307 	.globl _ak820_outline_0104
                                   1308 	.globl _ak820_outline_0109
                                   1309 	.globl _ak820_outline_0110
                                   1310 	.globl _ak820_outline_0120
                                   1311 	.globl _ak820_outline_0124
                                   1312 	.globl _ak820_outline_0125
                                   1313 	.globl _ak820_outline_0126
                                   1314 	.globl _ak820_outline_0136
                                   1315 	.globl _ak820_outline_0137
                                   1316 	.globl _ak820_outline_0140
                                   1317 	.globl _ak820_outline_0145
                                   1318 	.globl _ak820_outline_0159
                                   1319 	.globl _ak820_outline_0160
                                   1320 	.globl _ak820_outline_0163
                                   1321 	.globl _ak820_outline_0187
                                   1322 	.globl _ak820_outline_0192
                                   1323 
                                   1324 	.area CSEG (CODE)
                                   1325 ; function ak820_outline_0005
      0037E7                       1326 _ak820_outline_0005:
      0037E7 E0               [24] 1327 	movx	a,@dptr
      0037E8 FE               [12] 1328 	mov	r6,a
      0037E9 A3               [24] 1329 	inc	dptr
      0037EA E0               [24] 1330 	movx	a,@dptr
      0037EB FF               [12] 1331 	mov	r7,a
      0037EC 8E 82            [24] 1332 	mov	dpl,r6
      0037EE 8F 83            [24] 1333 	mov	dph,r7
      0037F0 22               [24] 1334 	ret
                                   1335 
                                   1336 	.area CSEG (CODE)
                                   1337 ; function ak820_outline_0007
      0037F1                       1338 _ak820_outline_0007:
      0037F1 E0               [24] 1339 	movx	a,@dptr
      0037F2 FE               [12] 1340 	mov	r6,a
      0037F3 A3               [24] 1341 	inc	dptr
      0037F4 E0               [24] 1342 	movx	a,@dptr
      0037F5 FF               [12] 1343 	mov	r7,a
      0037F6 74 07            [12] 1344 	mov	a,#0x07
      0037F8 2E               [12] 1345 	add	a,r6
      0037F9 F5 82            [12] 1346 	mov	dpl,a
      0037FB E4               [12] 1347 	clr	a
      0037FC 3F               [12] 1348 	addc	a,r7
      0037FD F5 83            [12] 1349 	mov	dph,a
      0037FF E0               [24] 1350 	movx	a,@dptr
      003800 FC               [12] 1351 	mov	r4,a
      003801 A3               [24] 1352 	inc	dptr
      003802 E0               [24] 1353 	movx	a,@dptr
      003803 FD               [12] 1354 	mov	r5,a
      003804 22               [24] 1355 	ret
                                   1356 
                                   1357 	.area CSEG (CODE)
                                   1358 ; function ak820_outline_0009
      003805                       1359 _ak820_outline_0009:
      003805 74 05            [12] 1360 	mov	a,#0x05
      003807 2E               [12] 1361 	add	a,r6
      003808 FE               [12] 1362 	mov	r6,a
      003809 E4               [12] 1363 	clr	a
      00380A 3F               [12] 1364 	addc	a,r7
      00380B FF               [12] 1365 	mov	r7,a
      00380C 8E 82            [24] 1366 	mov	dpl,r6
      00380E 8F 83            [24] 1367 	mov	dph,r7
      003810 E0               [24] 1368 	movx	a,@dptr
      003811 22               [24] 1369 	ret
                                   1370 
                                   1371 	.area CSEG (CODE)
                                   1372 ; function ak820_outline_0016
      003812                       1373 _ak820_outline_0016:
      003812 F0               [24] 1374 	movx	@dptr,a
      003813 EE               [12] 1375 	mov	a,r6
      003814 A3               [24] 1376 	inc	dptr
      003815 F0               [24] 1377 	movx	@dptr,a
      003816 EF               [12] 1378 	mov	a,r7
      003817 A3               [24] 1379 	inc	dptr
      003818 F0               [24] 1380 	movx	@dptr,a
      003819 22               [24] 1381 	ret
                                   1382 
                                   1383 	.area CSEG (CODE)
                                   1384 ; function ak820_outline_0017
      00381A                       1385 _ak820_outline_0017:
      00381A F9               [12] 1386 	mov	r1,a
      00381B E4               [12] 1387 	clr	a
      00381C 3F               [12] 1388 	addc	a,r7
      00381D FA               [12] 1389 	mov	r2,a
      00381E 89 82            [24] 1390 	mov	dpl,r1
      003820 8A 83            [24] 1391 	mov	dph,r2
      003822 E0               [24] 1392 	movx	a,@dptr
      003823 22               [24] 1393 	ret
                                   1394 
                                   1395 	.area CSEG (CODE)
                                   1396 ; function ak820_outline_0022
      003824                       1397 _ak820_outline_0022:
      003824 2E               [12] 1398 	add	a,r6
      003825 F5 82            [12] 1399 	mov	dpl,a
      003827 E4               [12] 1400 	clr	a
      003828 3F               [12] 1401 	addc	a,r7
      003829 F5 83            [12] 1402 	mov	dph,a
      00382B 22               [24] 1403 	ret
                                   1404 
                                   1405 	.area CSEG (CODE)
                                   1406 ; function ak820_outline_0037
      00382C                       1407 _ak820_outline_0037:
      00382C 8E 82            [24] 1408 	mov	dpl,r6
      00382E 8F 83            [24] 1409 	mov	dph,r7
      003830 A3               [24] 1410 	inc	dptr
      003831 A3               [24] 1411 	inc	dptr
      003832 E0               [24] 1412 	movx	a,@dptr
      003833 22               [24] 1413 	ret
                                   1414 
                                   1415 	.area CSEG (CODE)
                                   1416 ; function ak820_outline_0052
      003834                       1417 _ak820_outline_0052:
      003834 E0               [24] 1418 	movx	a,@dptr
      003835 FE               [12] 1419 	mov	r6,a
      003836 A3               [24] 1420 	inc	dptr
      003837 E0               [24] 1421 	movx	a,@dptr
      003838 FF               [12] 1422 	mov	r7,a
      003839 22               [24] 1423 	ret
                                   1424 
                                   1425 	.area CSEG (CODE)
                                   1426 ; function ak820_outline_0054
      00383A                       1427 _ak820_outline_0054:
      00383A 75 F0 04         [24] 1428 	mov	b,#0x04
      00383D A4               [48] 1429 	mul	ab
      00383E 24 26            [12] 1430 	add	a,#_combos
      003840 FC               [12] 1431 	mov	r4,a
      003841 74 04            [12] 1432 	mov	a,#(_combos>>8)
      003843 35 F0            [12] 1433 	addc	a,b
      003845 FD               [12] 1434 	mov	r5,a
      003846 8C 82            [24] 1435 	mov	dpl,r4
      003848 8D 83            [24] 1436 	mov	dph,r5
      00384A 22               [24] 1437 	ret
                                   1438 
                                   1439 	.area CSEG (CODE)
                                   1440 ; function ak820_outline_0061
      00384B                       1441 _ak820_outline_0061:
      00384B E0               [24] 1442 	movx	a,@dptr
      00384C FC               [12] 1443 	mov	r4,a
      00384D A3               [24] 1444 	inc	dptr
      00384E E0               [24] 1445 	movx	a,@dptr
      00384F FD               [12] 1446 	mov	r5,a
      003850 22               [24] 1447 	ret
                                   1448 
                                   1449 	.area CSEG (CODE)
                                   1450 ; function ak820_outline_0072
      003851                       1451 _ak820_outline_0072:
      003851 EC               [12] 1452 	mov	a,r4
      003852 F0               [24] 1453 	movx	@dptr,a
      003853 ED               [12] 1454 	mov	a,r5
      003854 A3               [24] 1455 	inc	dptr
      003855 F0               [24] 1456 	movx	@dptr,a
      003856 22               [24] 1457 	ret
                                   1458 
                                   1459 	.area CSEG (CODE)
                                   1460 ; function ak820_outline_0080
      003857                       1461 _ak820_outline_0080:
      003857 E0               [24] 1462 	movx	a,@dptr
      003858 FD               [12] 1463 	mov	r5,a
      003859 A3               [24] 1464 	inc	dptr
      00385A E0               [24] 1465 	movx	a,@dptr
      00385B FE               [12] 1466 	mov	r6,a
      00385C 22               [24] 1467 	ret
                                   1468 
                                   1469 	.area CSEG (CODE)
                                   1470 ; function ak820_outline_0086
      00385D                       1471 _ak820_outline_0086:
      00385D EB               [12] 1472 	mov	a,r3
      00385E F0               [24] 1473 	movx	@dptr,a
      00385F EC               [12] 1474 	mov	a,r4
      003860 A3               [24] 1475 	inc	dptr
      003861 F0               [24] 1476 	movx	@dptr,a
      003862 22               [24] 1477 	ret
                                   1478 
                                   1479 	.area CSEG (CODE)
                                   1480 ; function ak820_outline_0094
      003863                       1481 _ak820_outline_0094:
      003863 A3               [24] 1482 	inc	dptr
      003864 F0               [24] 1483 	movx	@dptr,a
      003865 E4               [12] 1484 	clr	a
      003866 A3               [24] 1485 	inc	dptr
      003867 F0               [24] 1486 	movx	@dptr,a
      003868 22               [24] 1487 	ret
                                   1488 
                                   1489 	.area CSEG (CODE)
                                   1490 ; function ak820_outline_0103
      003869                       1491 _ak820_outline_0103:
      003869 F0               [24] 1492 	movx	@dptr,a
      00386A 8C 82            [24] 1493 	mov	dpl,r4
      00386C 8D 83            [24] 1494 	mov	dph,r5
      00386E 22               [24] 1495 	ret
                                   1496 
                                   1497 	.area CSEG (CODE)
                                   1498 ; function ak820_outline_0104
      00386F                       1499 _ak820_outline_0104:
      00386F E0               [24] 1500 	movx	a,@dptr
      003870 F8               [12] 1501 	mov	r0,a
      003871 A3               [24] 1502 	inc	dptr
      003872 E0               [24] 1503 	movx	a,@dptr
      003873 F9               [12] 1504 	mov	r1,a
      003874 22               [24] 1505 	ret
                                   1506 
                                   1507 	.area CSEG (CODE)
                                   1508 ; function ak820_outline_0109
      003875                       1509 _ak820_outline_0109:
      003875 AF 83            [24] 1510 	mov	r7,dph
      003877 E5 82            [12] 1511 	mov	a,dpl
      003879 22               [24] 1512 	ret
                                   1513 
                                   1514 	.area CSEG (CODE)
                                   1515 ; function ak820_outline_0110
      00387A                       1516 _ak820_outline_0110:
      00387A F0               [24] 1517 	movx	@dptr,a
      00387B EF               [12] 1518 	mov	a,r7
      00387C A3               [24] 1519 	inc	dptr
      00387D F0               [24] 1520 	movx	@dptr,a
      00387E 22               [24] 1521 	ret
                                   1522 
                                   1523 	.area CSEG (CODE)
                                   1524 ; function ak820_outline_0120
      00387F                       1525 _ak820_outline_0120:
      00387F 8E 82            [24] 1526 	mov	dpl,r6
      003881 8F 83            [24] 1527 	mov	dph,r7
      003883 22               [24] 1528 	ret
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0124
      003884                       1532 _ak820_outline_0124:
      003884 E0               [24] 1533 	movx	a,@dptr
      003885 FB               [12] 1534 	mov	r3,a
      003886 A3               [24] 1535 	inc	dptr
      003887 E0               [24] 1536 	movx	a,@dptr
      003888 FC               [12] 1537 	mov	r4,a
      003889 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0126
      00388A                       1542 _ak820_outline_0126:
      00388A 8C 82            [24] 1543 	mov	dpl,r4
      00388C 8D 83            [24] 1544 	mov	dph,r5
      00388E 22               [24] 1545 	ret
                                   1546 
                                   1547 	.area CSEG (CODE)
                                   1548 ; function ak820_outline_0136
      00388F                       1549 _ak820_outline_0136:
      00388F F0               [24] 1550 	movx	@dptr,a
      003890 E4               [12] 1551 	clr	a
      003891 A3               [24] 1552 	inc	dptr
      003892 F0               [24] 1553 	movx	@dptr,a
      003893 22               [24] 1554 	ret
                                   1555 
                                   1556 	.area CSEG (CODE)
                                   1557 ; function ak820_outline_0137
      003894                       1558 _ak820_outline_0137:
      003894 8D 82            [24] 1559 	mov	dpl,r5
      003896 8E 83            [24] 1560 	mov	dph,r6
      003898 22               [24] 1561 	ret
                                   1562 
                                   1563 	.area CSEG (CODE)
                                   1564 ; function ak820_outline_0140
      003899                       1565 _ak820_outline_0140:
      003899 E5 82            [12] 1566 	mov	a,dpl
      00389B 85 83 F0         [24] 1567 	mov	b,dph
      00389E 22               [24] 1568 	ret
                                   1569 
                                   1570 	.area CSEG (CODE)
                                   1571 ; function ak820_outline_0145
      00389F                       1572 _ak820_outline_0145:
      00389F 8A 82            [24] 1573 	mov	dpl,r2
      0038A1 8B 83            [24] 1574 	mov	dph,r3
      0038A3 22               [24] 1575 	ret
                                   1576 
                                   1577 	.area CSEG (CODE)
                                   1578 ; function ak820_outline_0159
      0038A4                       1579 _ak820_outline_0159:
      0038A4 E4               [12] 1580 	clr	a
      0038A5 33               [12] 1581 	rlc	a
      0038A6 F5 82            [12] 1582 	mov	dpl,a
      0038A8 22               [24] 1583 	ret
                                   1584 
                                   1585 	.area CSEG (CODE)
                                   1586 ; function ak820_outline_0160
      0038A9                       1587 _ak820_outline_0160:
      0038A9 88 82            [24] 1588 	mov	dpl,r0
      0038AB 89 83            [24] 1589 	mov	dph,r1
      0038AD 22               [24] 1590 	ret
                                   1591 
                                   1592 	.area CSEG (CODE)
                                   1593 ; function ak820_outline_0163
      0038AE                       1594 _ak820_outline_0163:
      0038AE 2D               [12] 1595 	add	a,r5
      0038AF FD               [12] 1596 	mov	r5,a
      0038B0 E4               [12] 1597 	clr	a
      0038B1 3E               [12] 1598 	addc	a,r6
      0038B2 FE               [12] 1599 	mov	r6,a
      0038B3 22               [24] 1600 	ret
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0187
      0038B4                       1604 _ak820_outline_0187:
      0038B4 90 0D B2         [24] 1605 	mov	dptr,#_first
      0038B7 E0               [24] 1606 	movx	a,@dptr
      0038B8 22               [24] 1607 	ret
                                   1608 
                                   1609 	.area CSEG (CODE)
                                   1610 ; function ak820_outline_0192
      0038B9                       1611 _ak820_outline_0192:
      0038B9 C4               [12] 1612 	swap	a
      0038BA 03               [12] 1613 	rr	a
      0038BB 54 F8            [12] 1614 	anl	a,#0xf8
      0038BD 22               [24] 1615 	ret
