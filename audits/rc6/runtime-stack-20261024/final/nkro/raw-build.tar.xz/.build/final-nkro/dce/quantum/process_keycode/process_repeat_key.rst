                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module process_repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_weak_mods
                                     12 	.globl _get_mods
                                     13 	.globl _alt_repeat_key_invoke
                                     14 	.globl _repeat_key_invoke
                                     15 	.globl _get_repeat_key_count
                                     16 	.globl _set_last_record
                                     17 	.globl _set_last_mods
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _process_repeat_key_PARM_2
                                    262 	.globl _process_last_key_PARM_2
                                    263 	.globl _remember_last_key_user_PARM_3
                                    264 	.globl _remember_last_key_user_PARM_2
                                    265 	.globl _remember_last_key_user
                                    266 	.globl _process_last_key
                                    267 	.globl _process_repeat_key
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000BAC                        554 _remember_last_key_user_PARM_2:
      000BAC                        555 	.ds 3
      000BAF                        556 _remember_last_key_user_PARM_3:
      000BAF                        557 	.ds 3
      000BB2                        558 _remember_last_key_PARM_2:
      000BB2                        559 	.ds 3
      000BB5                        560 _remember_last_key_PARM_3:
      000BB5                        561 	.ds 3
      000BB8                        562 _remember_last_key_keycode_10000_239:
      000BB8                        563 	.ds 2
      000BBA                        564 _process_last_key_PARM_2:
      000BBA                        565 	.ds 3
      000BBD                        566 _process_last_key_keycode_10000_242:
      000BBD                        567 	.ds 2
      000BBF                        568 _process_last_key_remembered_mods_30000_247:
      000BBF                        569 	.ds 1
      000BC0                        570 _process_repeat_key_PARM_2:
      000BC0                        571 	.ds 3
      000BC3                        572 _process_repeat_key_keycode_10000_250:
      000BC3                        573 	.ds 2
                                    574 ;--------------------------------------------------------
                                    575 ; absolute external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area XABS    (ABS,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; initialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XISEG   (XDATA)
                                    582 	.area HOME    (CODE)
                                    583 	.area GSINIT0 (CODE)
                                    584 	.area GSINIT1 (CODE)
                                    585 	.area GSINIT2 (CODE)
                                    586 	.area GSINIT3 (CODE)
                                    587 	.area GSINIT4 (CODE)
                                    588 	.area GSINIT5 (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 	.area GSFINAL (CODE)
                                    591 	.area CSEG    (CODE)
                                    592 ;--------------------------------------------------------
                                    593 ; global & static initialisations
                                    594 ;--------------------------------------------------------
                                    595 	.area HOME    (CODE)
                                    596 	.area GSINIT  (CODE)
                                    597 	.area GSFINAL (CODE)
                                    598 	.area GSINIT  (CODE)
                                    599 ;--------------------------------------------------------
                                    600 ; Home
                                    601 ;--------------------------------------------------------
                                    602 	.area HOME    (CODE)
                                    603 	.area HOME    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; code
                                    606 ;--------------------------------------------------------
                                    607 	.area CSEG    (CODE)
                                    608 ;------------------------------------------------------------
                                    609 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    610 ;------------------------------------------------------------
                                    611 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_165'
                                    612 ;------------------------------------------------------------
                                    613 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    614 ;	-----------------------------------------
                           000007   615 	ar7 = 0x07
                           000006   616 	ar6 = 0x06
                           000005   617 	ar5 = 0x05
                           000004   618 	ar4 = 0x04
                           000003   619 	ar3 = 0x03
                           000002   620 	ar2 = 0x02
                           000001   621 	ar1 = 0x01
                           000000   622 	ar0 = 0x00
                                    623 ;	 function remember_last_key_user
                                    624 ;	-----------------------------------------
      009708                        625 _remember_last_key_user:
                                    626 ;	quantum/process_keycode/process_repeat_key.c:23: return true;
      009708 75 82 01         [24]  627 	mov	dpl, #0x01
                                    628 ;	quantum/process_keycode/process_repeat_key.c:24: }
      00970B 22               [24]  629 	ret
                                    630 ;------------------------------------------------------------
                                    631 ;Allocation info for local variables in function 'remember_last_key'
                                    632 ;------------------------------------------------------------
                                    633 ;record        Allocated with name '_remember_last_key_PARM_2'
                                    634 ;remembered_mods Allocated with name '_remember_last_key_PARM_3'
                                    635 ;keycode       Allocated with name '_remember_last_key_keycode_10000_239'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/process_keycode/process_repeat_key.c:26: static bool remember_last_key(uint16_t keycode, keyrecord_t* record, uint8_t* remembered_mods) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function remember_last_key
                                    640 ;	-----------------------------------------
      00970C                        641 _remember_last_key:
      00970C 12 38 88         [24]  642 	lcall	_ak820_outline_0113
      00970F 90 0B B8         [24]  643 	mov	dptr,#_remember_last_key_keycode_10000_239
      009712 12 38 83         [24]  644 	lcall	_ak820_outline_0105
                                    645 ;	quantum/process_keycode/process_repeat_key.c:36: if (keycode == KC_NO || keycode == KC_TRANSPARENT ||
      009715 90 0B B8         [24]  646 	mov	dptr,#_remember_last_key_keycode_10000_239
      009718 12 38 42         [24]  647 	lcall	_ak820_outline_0052
      00971B 90 0B B8         [24]  648 	mov	dptr,#_remember_last_key_keycode_10000_239
      00971E 12 6B 89         [24]  649 	lcall	_ak820_outline_0039
      009721 60 6D            [24]  650 	jz	00101$
      009723 BE 01 05         [24]  651 	cjne	r6,#0x01,00189$
      009726 BF 00 02         [24]  652 	cjne	r7,#0x00,00189$
      009729 80 65            [24]  653 	sjmp	00101$
      00972B                        654 00189$:
                                    655 ;	quantum/process_keycode/process_repeat_key.c:41: (keycode >= QK_LAYER_MOD && keycode <= QK_TOGGLE_LAYER_MAX) ||
      00972B 74 B0            [12]  656 	mov	a,#0x100 - 0x50
      00972D 2F               [12]  657 	add	a,r7
      00972E 50 09            [24]  658 	jnc	00107$
      009730 C3               [12]  659 	clr	c
      009731 74 7F            [12]  660 	mov	a,#0x7f
      009733 9E               [12]  661 	subb	a,r6
      009734 74 52            [12]  662 	mov	a,#0x52
      009736 9F               [12]  663 	subb	a,r7
      009737 50 57            [24]  664 	jnc	00101$
                                    665 ;	free result
      009739                        666 00107$:
                                    667 ;	quantum/process_keycode/process_repeat_key.c:42: (keycode >= QK_LAYER_TAP_TOGGLE && keycode <= QK_LAYER_TAP_TOGGLE_MAX) ||
      009739 90 0B B8         [24]  668 	mov	dptr,#_remember_last_key_keycode_10000_239
      00973C 12 38 42         [24]  669 	lcall	_ak820_outline_0052
      00973F C3               [12]  670 	clr	c
      009740 EE               [12]  671 	mov	a,r6
      009741 94 C0            [12]  672 	subb	a,#0xc0
      009743 EF               [12]  673 	mov	a,r7
      009744 94 52            [12]  674 	subb	a,#0x52
      009746 40 08            [24]  675 	jc	00109$
      009748 74 DF            [12]  676 	mov	a,#0xdf
      00974A 9E               [12]  677 	subb	a,r6
      00974B 74 52            [12]  678 	mov	a,#0x52
      00974D 9F               [12]  679 	subb	a,r7
      00974E 50 40            [24]  680 	jnc	00101$
                                    681 ;	free result
      009750                        682 00109$:
                                    683 ;	quantum/process_keycode/process_repeat_key.c:52: (keycode >= KC_LCTL && keycode <= KC_RGUI) ||
      009750 12 98 8C         [24]  684 	lcall	_ak820_outline_0116
      009753 40 07            [24]  685 	jc	00110$
      009755 74 E7            [12]  686 	mov	a,#0xe7
      009757 9E               [12]  687 	subb	a,r6
      009758 E4               [12]  688 	clr	a
      009759 9F               [12]  689 	subb	a,r7
      00975A 50 34            [24]  690 	jnc	00101$
                                    691 ;	free result
      00975C                        692 00110$:
                                    693 ;	quantum/process_keycode/process_repeat_key.c:53: keycode == KC_HYPR || keycode == KC_MEH || keycode == QK_REPEAT_KEY
      00975C 90 0B B8         [24]  694 	mov	dptr,#_remember_last_key_keycode_10000_239
      00975F 12 46 89         [24]  695 	lcall	_ak820_outline_0008
      009762 BC 00 05         [24]  696 	cjne	r4,#0x00,00196$
      009765 BD 0F 02         [24]  697 	cjne	r5,#0x0f,00196$
      009768 80 26            [24]  698 	sjmp	00101$
      00976A                        699 00196$:
      00976A BC 00 05         [24]  700 	cjne	r4,#0x00,00197$
      00976D BD 07 02         [24]  701 	cjne	r5,#0x07,00197$
      009770 80 1E            [24]  702 	sjmp	00101$
      009772                        703 00197$:
                                    704 ;	quantum/process_keycode/process_repeat_key.c:55: || keycode == QK_ALT_REPEAT_KEY
      009772 BC 79 05         [24]  705 	cjne	r4,#0x79,00198$
      009775 BD 7C 02         [24]  706 	cjne	r5,#0x7c,00198$
      009778 80 16            [24]  707 	sjmp	00101$
      00977A                        708 00198$:
                                    709 ;	quantum/process_keycode/process_repeat_key.c:62: || keycode == QK_TRI_LAYER_LOWER || keycode == QK_TRI_LAYER_UPPER
      00977A BC 7A 05         [24]  710 	cjne	r4,#0x7a,00199$
      00977D BD 7C 02         [24]  711 	cjne	r5,#0x7c,00199$
      009780 80 0E            [24]  712 	sjmp	00101$
      009782                        713 00199$:
      009782 BC 77 05         [24]  714 	cjne	r4,#0x77,00200$
      009785 BD 7C 02         [24]  715 	cjne	r5,#0x7c,00200$
      009788 80 06            [24]  716 	sjmp	00101$
      00978A                        717 00200$:
                                    718 ;	quantum/process_keycode/process_repeat_key.c:64: ) return false;
      00978A BC 78 07         [24]  719 	cjne	r4,#0x78,00102$
      00978D BD 7C 04         [24]  720 	cjne	r5,#0x7c,00102$
      009790                        721 00101$:
      009790 75 82 00         [24]  722 	mov	dpl, #0x00
      009793 22               [24]  723 	ret
      009794                        724 00102$:
                                    725 ;	quantum/process_keycode/process_repeat_key.c:77: return remember_last_key_user(keycode, record, remembered_mods);
      009794 90 0B B2         [24]  726 	mov	dptr,#_remember_last_key_PARM_2
      009797 12 98 83         [24]  727 	lcall	_ak820_outline_0024
      00979A 90 0B B5         [24]  728 	mov	dptr,#_remember_last_key_PARM_3
      00979D 12 38 77         [24]  729 	lcall	_ak820_outline_0099
      0097A0 A3               [24]  730 	inc	dptr
      0097A1 E0               [24]  731 	movx	a,@dptr
      0097A2 FA               [12]  732 	mov	r2,a
      0097A3 90 0B AC         [24]  733 	mov	dptr,#_remember_last_key_user_PARM_2
      0097A6 12 38 65         [24]  734 	lcall	_ak820_outline_0081
      0097A9 ED               [12]  735 	mov	a,r5
      0097AA A3               [24]  736 	inc	dptr
      0097AB F0               [24]  737 	movx	@dptr,a
      0097AC 90 0B AF         [24]  738 	mov	dptr,#_remember_last_key_user_PARM_3
      0097AF E8               [12]  739 	mov	a,r0
      0097B0 F0               [24]  740 	movx	@dptr,a
      0097B1 E9               [12]  741 	mov	a,r1
      0097B2 A3               [24]  742 	inc	dptr
      0097B3 F0               [24]  743 	movx	@dptr,a
      0097B4 EA               [12]  744 	mov	a,r2
      0097B5 A3               [24]  745 	inc	dptr
      0097B6 12 43 32         [24]  746 	lcall	_ak820_outline_0076
                                    747 ;	quantum/process_keycode/process_repeat_key.c:78: }
      0097B9 02 97 08         [24]  748 	ljmp	_remember_last_key_user
                                    749 ;------------------------------------------------------------
                                    750 ;Allocation info for local variables in function 'process_last_key'
                                    751 ;------------------------------------------------------------
                                    752 ;record        Allocated with name '_process_last_key_PARM_2'
                                    753 ;keycode       Allocated with name '_process_last_key_keycode_10000_242'
                                    754 ;remembered_mods Allocated with name '_process_last_key_remembered_mods_30000_247'
                                    755 ;------------------------------------------------------------
                                    756 ;	quantum/process_keycode/process_repeat_key.c:80: bool process_last_key(uint16_t keycode, keyrecord_t* record) {
                                    757 ;	-----------------------------------------
                                    758 ;	 function process_last_key
                                    759 ;	-----------------------------------------
      0097BC                        760 _process_last_key:
      0097BC 12 38 88         [24]  761 	lcall	_ak820_outline_0113
      0097BF 90 0B BD         [24]  762 	mov	dptr,#_process_last_key_keycode_10000_242
      0097C2 12 38 83         [24]  763 	lcall	_ak820_outline_0105
                                    764 ;	quantum/process_keycode/process_repeat_key.c:81: if (get_repeat_key_count()) {
      0097C5 12 9F 0B         [24]  765 	lcall	_get_repeat_key_count
      0097C8 E5 82            [12]  766 	mov	a, dpl
      0097CA 60 04            [24]  767 	jz	00102$
                                    768 ;	quantum/process_keycode/process_repeat_key.c:82: return true;
      0097CC 75 82 01         [24]  769 	mov	dpl, #0x01
      0097CF 22               [24]  770 	ret
      0097D0                        771 00102$:
                                    772 ;	quantum/process_keycode/process_repeat_key.c:85: if (record->event.pressed) {
      0097D0 90 0B BA         [24]  773 	mov	dptr,#_process_last_key_PARM_2
      0097D3 12 4D 27         [24]  774 	lcall	_ak820_outline_0013
      0097D6 74 05            [12]  775 	mov	a,#0x05
      0097D8 12 74 1B         [24]  776 	lcall	_ak820_outline_0012
      0097DB 12 B6 07         [24]  777 	lcall	__gptrget
      0097DE 60 56            [24]  778 	jz	00106$
                                    779 ;	quantum/process_keycode/process_repeat_key.c:86: uint8_t remembered_mods = get_mods() | get_weak_mods();
      0097E0 12 7D 89         [24]  780 	lcall	_get_mods
      0097E3 AC 82            [24]  781 	mov	r4, dpl
      0097E5 12 7D 9F         [24]  782 	lcall	_get_weak_mods
      0097E8 AB 82            [24]  783 	mov	r3, dpl
      0097EA 90 0B BF         [24]  784 	mov	dptr,#_process_last_key_remembered_mods_30000_247
      0097ED EB               [12]  785 	mov	a,r3
      0097EE 4C               [12]  786 	orl	a,r4
      0097EF F0               [24]  787 	movx	@dptr,a
                                    788 ;	quantum/process_keycode/process_repeat_key.c:91: if (remember_last_key(keycode, record, &remembered_mods)) {
      0097F0 90 0B BD         [24]  789 	mov	dptr,#_process_last_key_keycode_10000_242
      0097F3 12 38 7D         [24]  790 	lcall	_ak820_outline_0101
      0097F6 90 0B B2         [24]  791 	mov	dptr,#_remember_last_key_PARM_2
      0097F9 ED               [12]  792 	mov	a,r5
      0097FA 12 38 20         [24]  793 	lcall	_ak820_outline_0014
      0097FD 90 0B B5         [24]  794 	mov	dptr,#_remember_last_key_PARM_3
      009800 74 BF            [12]  795 	mov	a,#_process_last_key_remembered_mods_30000_247
      009802 F0               [24]  796 	movx	@dptr,a
      009803 74 0B            [12]  797 	mov	a,#(_process_last_key_remembered_mods_30000_247 >> 8)
      009805 12 38 6B         [24]  798 	lcall	_ak820_outline_0089
      009808 12 33 FC         [24]  799 	lcall	_ak820_outline_0120
      00980B C0 04            [24]  800 	push	ar4
      00980D C0 03            [24]  801 	push	ar3
      00980F 12 97 0C         [24]  802 	lcall	_remember_last_key
      009812 E5 82            [12]  803 	mov	a, dpl
      009814 D0 03            [24]  804 	pop	ar3
      009816 D0 04            [24]  805 	pop	ar4
      009818 60 1C            [24]  806 	jz	00106$
                                    807 ;	quantum/process_keycode/process_repeat_key.c:92: set_last_record(keycode, record);
      00981A 90 0B BA         [24]  808 	mov	dptr,#_process_last_key_PARM_2
      00981D 12 4D 27         [24]  809 	lcall	_ak820_outline_0013
      009820 90 0C 1F         [24]  810 	mov	dptr,#_set_last_record_PARM_2
      009823 ED               [12]  811 	mov	a,r5
      009824 12 38 20         [24]  812 	lcall	_ak820_outline_0014
      009827 12 33 FC         [24]  813 	lcall	_ak820_outline_0120
      00982A 12 9E 8A         [24]  814 	lcall	_set_last_record
                                    815 ;	quantum/process_keycode/process_repeat_key.c:93: set_last_mods(remembered_mods);
      00982D 90 0B BF         [24]  816 	mov	dptr,#_process_last_key_remembered_mods_30000_247
      009830 E0               [24]  817 	movx	a,@dptr
      009831 F5 82            [12]  818 	mov	dpl,a
      009833 12 9E 7E         [24]  819 	lcall	_set_last_mods
      009836                        820 00106$:
                                    821 ;	quantum/process_keycode/process_repeat_key.c:97: return true;
      009836 75 82 01         [24]  822 	mov	dpl, #0x01
                                    823 ;	quantum/process_keycode/process_repeat_key.c:98: }
      009839 22               [24]  824 	ret
                                    825 ;------------------------------------------------------------
                                    826 ;Allocation info for local variables in function 'process_repeat_key'
                                    827 ;------------------------------------------------------------
                                    828 ;record        Allocated with name '_process_repeat_key_PARM_2'
                                    829 ;keycode       Allocated with name '_process_repeat_key_keycode_10000_250'
                                    830 ;------------------------------------------------------------
                                    831 ;	quantum/process_keycode/process_repeat_key.c:100: bool process_repeat_key(uint16_t keycode, keyrecord_t* record) {
                                    832 ;	-----------------------------------------
                                    833 ;	 function process_repeat_key
                                    834 ;	-----------------------------------------
      00983A                        835 _process_repeat_key:
      00983A 12 38 88         [24]  836 	lcall	_ak820_outline_0113
      00983D 90 0B C3         [24]  837 	mov	dptr,#_process_repeat_key_keycode_10000_250
      009840 12 38 83         [24]  838 	lcall	_ak820_outline_0105
                                    839 ;	quantum/process_keycode/process_repeat_key.c:101: if (get_repeat_key_count()) {
      009843 12 9F 0B         [24]  840 	lcall	_get_repeat_key_count
      009846 E5 82            [12]  841 	mov	a, dpl
      009848 60 04            [24]  842 	jz	00102$
                                    843 ;	quantum/process_keycode/process_repeat_key.c:102: return true;
      00984A 75 82 01         [24]  844 	mov	dpl, #0x01
      00984D 22               [24]  845 	ret
      00984E                        846 00102$:
                                    847 ;	quantum/process_keycode/process_repeat_key.c:105: if (keycode == QK_REPEAT_KEY) {
      00984E 90 0B C3         [24]  848 	mov	dptr,#_process_repeat_key_keycode_10000_250
      009851 12 38 42         [24]  849 	lcall	_ak820_outline_0052
      009854 BE 79 15         [24]  850 	cjne	r6,#0x79,00106$
      009857 BF 7C 12         [24]  851 	cjne	r7,#0x7c,00106$
                                    852 ;	quantum/process_keycode/process_repeat_key.c:106: repeat_key_invoke(&record->event);
      00985A 90 0B C0         [24]  853 	mov	dptr,#_process_repeat_key_PARM_2
      00985D 12 98 83         [24]  854 	lcall	_ak820_outline_0024
      009860 12 33 FC         [24]  855 	lcall	_ak820_outline_0120
      009863 8D F0            [24]  856 	mov	b, r5
      009865 12 A0 31         [24]  857 	lcall	_repeat_key_invoke
                                    858 ;	quantum/process_keycode/process_repeat_key.c:107: return false;
      009868 75 82 00         [24]  859 	mov	dpl, #0x00
      00986B 22               [24]  860 	ret
      00986C                        861 00106$:
                                    862 ;	quantum/process_keycode/process_repeat_key.c:109: } else if (keycode == QK_ALT_REPEAT_KEY) {
      00986C BE 7A 10         [24]  863 	cjne	r6,#0x7a,00107$
      00986F BF 7C 0D         [24]  864 	cjne	r7,#0x7c,00107$
                                    865 ;	quantum/process_keycode/process_repeat_key.c:110: alt_repeat_key_invoke(&record->event);
      009872 90 0B C0         [24]  866 	mov	dptr,#_process_repeat_key_PARM_2
      009875 12 4D 01         [24]  867 	lcall	_ak820_outline_0001
      009878 12 A1 A0         [24]  868 	lcall	_alt_repeat_key_invoke
                                    869 ;	quantum/process_keycode/process_repeat_key.c:111: return false;
      00987B 75 82 00         [24]  870 	mov	dpl, #0x00
      00987E 22               [24]  871 	ret
      00987F                        872 00107$:
                                    873 ;	quantum/process_keycode/process_repeat_key.c:115: return true;
      00987F 75 82 01         [24]  874 	mov	dpl, #0x01
                                    875 ;	quantum/process_keycode/process_repeat_key.c:116: }
      009882 22               [24]  876 	ret
                                    877 	.area CSEG    (CODE)
                                    878 	.area CONST   (CODE)
                                    879 	.area XINIT   (CODE)
                                    880 	.area CABS    (ABS,CODE)
                                    881 
                                    882 ; Experimental exact instruction outlining.
                                    883 	.globl _ak820_outline_0001
                                    884 	.globl _ak820_outline_0008
                                    885 	.globl _ak820_outline_0012
                                    886 	.globl _ak820_outline_0013
                                    887 	.globl _ak820_outline_0014
                                    888 	.globl _ak820_outline_0024
                                    889 	.globl _ak820_outline_0039
                                    890 	.globl _ak820_outline_0052
                                    891 	.globl _ak820_outline_0076
                                    892 	.globl _ak820_outline_0081
                                    893 	.globl _ak820_outline_0089
                                    894 	.globl _ak820_outline_0099
                                    895 	.globl _ak820_outline_0101
                                    896 	.globl _ak820_outline_0105
                                    897 	.globl _ak820_outline_0113
                                    898 	.globl _ak820_outline_0116
                                    899 	.globl _ak820_outline_0120
                                    900 
                                    901 	.area CSEG (CODE)
                                    902 ; function ak820_outline_0024
      009883                        903 _ak820_outline_0024:
      009883 E0               [24]  904 	movx	a,@dptr
      009884 FB               [12]  905 	mov	r3,a
      009885 A3               [24]  906 	inc	dptr
      009886 E0               [24]  907 	movx	a,@dptr
      009887 FC               [12]  908 	mov	r4,a
      009888 A3               [24]  909 	inc	dptr
      009889 E0               [24]  910 	movx	a,@dptr
      00988A FD               [12]  911 	mov	r5,a
      00988B 22               [24]  912 	ret
                                    913 
                                    914 	.area CSEG (CODE)
                                    915 ; function ak820_outline_0116
      00988C                        916 _ak820_outline_0116:
      00988C C3               [12]  917 	clr	c
      00988D EE               [12]  918 	mov	a,r6
      00988E 94 E0            [12]  919 	subb	a,#0xe0
      009890 EF               [12]  920 	mov	a,r7
      009891 94 00            [12]  921 	subb	a,#0x00
      009893 22               [24]  922 	ret
