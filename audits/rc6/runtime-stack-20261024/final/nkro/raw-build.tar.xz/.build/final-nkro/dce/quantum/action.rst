                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_tapping_cancel
                                     14 	.globl _ak820_tapping_process
                                     15 	.globl _ak820_tapping_before
                                     16 	.globl _pre_process_record_quantum
                                     17 	.globl _repeat_key_cancel
                                     18 	.globl _clear_owned_usages
                                     19 	.globl _owned_usage_key
                                     20 	.globl _clear_owned_keys
                                     21 	.globl _del_owned_key
                                     22 	.globl _add_owned_key
                                     23 	.globl _clear_owned_mods
                                     24 	.globl _del_owned_weak_mods
                                     25 	.globl _add_owned_weak_mods
                                     26 	.globl _del_owned_mods
                                     27 	.globl _add_owned_mods
                                     28 	.globl _clear_weak_mods
                                     29 	.globl _clear_mods
                                     30 	.globl _send_keyboard_report
                                     31 	.globl _layer_hold_clear
                                     32 	.globl _layer_hold_off
                                     33 	.globl _layer_hold_on
                                     34 	.globl _ak820_resolve_key
                                     35 	.globl _layer_xor
                                     36 	.globl _layer_and
                                     37 	.globl _layer_or
                                     38 	.globl _layer_off
                                     39 	.globl _layer_on
                                     40 	.globl _layer_move
                                     41 	.globl _layer_clear
                                     42 	.globl _layer_state_set
                                     43 	.globl _default_layer_xor
                                     44 	.globl _default_layer_and
                                     45 	.globl _default_layer_or
                                     46 	.globl _default_layer_set
                                     47 	.globl _post_process_record_quantum
                                     48 	.globl _process_record_quantum
                                     49 	.globl _action_for_keycode
                                     50 	.globl _mDelaymS
                                     51 	.globl _host_consumer_send
                                     52 	.globl _host_system_send
                                     53 	.globl _host_keyboard_leds
                                     54 	.globl _led_set
                                     55 	.globl _clear_keys_from_report
                                     56 	.globl ___memcpy
                                     57 	.globl _ADC_START
                                     58 	.globl _S0_R_FIFO
                                     59 	.globl _S0_T_FIFO
                                     60 	.globl _S0_FREE
                                     61 	.globl _S0_IF_BYTE
                                     62 	.globl _S0_IF_FIRST
                                     63 	.globl _S0_IF_OV
                                     64 	.globl _S0_FST_ACT
                                     65 	.globl _CP_RL2
                                     66 	.globl _C_T2
                                     67 	.globl _TR2
                                     68 	.globl _EXEN2
                                     69 	.globl _TCLK
                                     70 	.globl _RCLK
                                     71 	.globl _EXF2
                                     72 	.globl _CAP1F
                                     73 	.globl _TF2
                                     74 	.globl _RI
                                     75 	.globl _TI
                                     76 	.globl _RB8
                                     77 	.globl _TB8
                                     78 	.globl _REN
                                     79 	.globl _SM2
                                     80 	.globl _SM1
                                     81 	.globl _SM0
                                     82 	.globl _IT0
                                     83 	.globl _IE0
                                     84 	.globl _IT1
                                     85 	.globl _IE1
                                     86 	.globl _TR0
                                     87 	.globl _TF0
                                     88 	.globl _TR1
                                     89 	.globl _TF1
                                     90 	.globl _P4_0
                                     91 	.globl _P4_1
                                     92 	.globl _P4_2
                                     93 	.globl _P4_3
                                     94 	.globl _P4_4
                                     95 	.globl _P4_5
                                     96 	.globl _P4_6
                                     97 	.globl _RXD
                                     98 	.globl _TXD
                                     99 	.globl _INT0
                                    100 	.globl _INT1
                                    101 	.globl _T0
                                    102 	.globl _T1
                                    103 	.globl _MOSI1
                                    104 	.globl _MISO1
                                    105 	.globl _SCK1
                                    106 	.globl _P3_0
                                    107 	.globl _P3_1
                                    108 	.globl _P3_2
                                    109 	.globl _P3_3
                                    110 	.globl _P3_4
                                    111 	.globl _P3_5
                                    112 	.globl _P3_6
                                    113 	.globl _P3_7
                                    114 	.globl _CAP1_
                                    115 	.globl _T2_
                                    116 	.globl _CAP2_
                                    117 	.globl _T2EX_
                                    118 	.globl _RXD1
                                    119 	.globl _TXD1
                                    120 	.globl _P2_0
                                    121 	.globl _P2_1
                                    122 	.globl _P2_2
                                    123 	.globl _P2_3
                                    124 	.globl _P2_4
                                    125 	.globl _P2_5
                                    126 	.globl _P2_6
                                    127 	.globl _P2_7
                                    128 	.globl _AIN0
                                    129 	.globl _AIN1
                                    130 	.globl _AIN2
                                    131 	.globl _AIN3
                                    132 	.globl _AIN4
                                    133 	.globl _AIN5
                                    134 	.globl _AIN6
                                    135 	.globl _AIN7
                                    136 	.globl _CAP1
                                    137 	.globl _T2
                                    138 	.globl _CAP2
                                    139 	.globl _T2EX
                                    140 	.globl _INT0_
                                    141 	.globl _SCS
                                    142 	.globl _MOSI
                                    143 	.globl _MISO
                                    144 	.globl _SCK
                                    145 	.globl _RXD1_
                                    146 	.globl _TXD1_
                                    147 	.globl _P1_0
                                    148 	.globl _P1_1
                                    149 	.globl _P1_2
                                    150 	.globl _P1_3
                                    151 	.globl _P1_4
                                    152 	.globl _P1_5
                                    153 	.globl _P1_6
                                    154 	.globl _P1_7
                                    155 	.globl _AIN8
                                    156 	.globl _AIN9
                                    157 	.globl _AIN10
                                    158 	.globl _AIN11
                                    159 	.globl _AIN12
                                    160 	.globl _AIN13
                                    161 	.globl _RXD_
                                    162 	.globl _TXD_
                                    163 	.globl _SCL0
                                    164 	.globl _SDA0
                                    165 	.globl _P0_0
                                    166 	.globl _P0_1
                                    167 	.globl _P0_2
                                    168 	.globl _P0_3
                                    169 	.globl _P0_4
                                    170 	.globl _P0_5
                                    171 	.globl _P0_6
                                    172 	.globl _P0_7
                                    173 	.globl _IE_SPI0
                                    174 	.globl _IE_USB
                                    175 	.globl _IE_ADC
                                    176 	.globl _IE_UART1
                                    177 	.globl _IE_PWM_I2C
                                    178 	.globl _IE_GPIO
                                    179 	.globl _IE_WDOG
                                    180 	.globl _PX0
                                    181 	.globl _PT0
                                    182 	.globl _PX1
                                    183 	.globl _PT1
                                    184 	.globl _PS
                                    185 	.globl _PT2
                                    186 	.globl _PL_FLAG
                                    187 	.globl _PH_FLAG
                                    188 	.globl _EX0
                                    189 	.globl _ET0
                                    190 	.globl _EX1
                                    191 	.globl _ET1
                                    192 	.globl _ES
                                    193 	.globl _ET2
                                    194 	.globl _E_DIS
                                    195 	.globl _EA
                                    196 	.globl _P
                                    197 	.globl _F1
                                    198 	.globl _OV
                                    199 	.globl _RS0
                                    200 	.globl _RS1
                                    201 	.globl _F0
                                    202 	.globl _AC
                                    203 	.globl _CY
                                    204 	.globl _I2CS_INT_ST
                                    205 	.globl _I2CX_INT
                                    206 	.globl _LED_STATUS
                                    207 	.globl _LED_DMA_H
                                    208 	.globl _LED_DMA_L
                                    209 	.globl _LED_DMA
                                    210 	.globl _LED_PWM_OE
                                    211 	.globl _LED_COMMON
                                    212 	.globl _ADC_CHAN
                                    213 	.globl _ADC_DAT_H
                                    214 	.globl _ADC_DAT_L
                                    215 	.globl _ADC_DAT
                                    216 	.globl _ADC_CTRL
                                    217 	.globl _SPI1_CK_SE
                                    218 	.globl _SPI1_CTRL
                                    219 	.globl _SPI1_DATA
                                    220 	.globl _SPI1_STAT
                                    221 	.globl _SIF1
                                    222 	.globl _SBAUD1
                                    223 	.globl _SBUF1
                                    224 	.globl _SCON1
                                    225 	.globl _SPI0_SETUP
                                    226 	.globl _SPI0_CK_SE
                                    227 	.globl _SPI0_CTRL
                                    228 	.globl _SPI0_DATA
                                    229 	.globl _SPI0_STAT
                                    230 	.globl _T2CAP1H
                                    231 	.globl _T2CAP1L
                                    232 	.globl _T2CAP1
                                    233 	.globl _TH2
                                    234 	.globl _TL2
                                    235 	.globl _T2COUNT
                                    236 	.globl _RCAP2H
                                    237 	.globl _RCAP2L
                                    238 	.globl _RCAP2
                                    239 	.globl _T2MOD
                                    240 	.globl _T2CON
                                    241 	.globl _SBUF
                                    242 	.globl _SCON
                                    243 	.globl _TH1
                                    244 	.globl _TH0
                                    245 	.globl _TL1
                                    246 	.globl _TL0
                                    247 	.globl _TMOD
                                    248 	.globl _TCON
                                    249 	.globl _XBUS_AUX
                                    250 	.globl _P7
                                    251 	.globl _P6_DIR
                                    252 	.globl _P6_OUT_PU
                                    253 	.globl _P6_IN
                                    254 	.globl _P5_DIR
                                    255 	.globl _P5_OUT_PU
                                    256 	.globl _P5_IN
                                    257 	.globl _P4_LED_KEY
                                    258 	.globl _P4_DIR_PU
                                    259 	.globl _P4_MOD_OC
                                    260 	.globl _P4
                                    261 	.globl _P3_DIR_PU
                                    262 	.globl _P3_MOD_OC
                                    263 	.globl _P3
                                    264 	.globl _P2_DIR_PU
                                    265 	.globl _P2_MOD_OC
                                    266 	.globl _P2
                                    267 	.globl _P1_DIR_PU
                                    268 	.globl _P1_MOD_OC
                                    269 	.globl _P1
                                    270 	.globl _P0_DIR_PU
                                    271 	.globl _P0_MOD_OC
                                    272 	.globl _P0
                                    273 	.globl _ROM_CTRL
                                    274 	.globl _ROM_DATA_HH
                                    275 	.globl _ROM_DATA_HL
                                    276 	.globl _ROM_DATA_HI
                                    277 	.globl _ROM_ADDR_H
                                    278 	.globl _ROM_ADDR_L
                                    279 	.globl _ROM_ADDR
                                    280 	.globl _GPIO_IE
                                    281 	.globl _IP_EX
                                    282 	.globl _IE_EX
                                    283 	.globl _IP
                                    284 	.globl _IE
                                    285 	.globl _WDOG_COUNT
                                    286 	.globl _RESET_KEEP
                                    287 	.globl _WAKE_CTRL
                                    288 	.globl _CLOCK_CFG
                                    289 	.globl _POWER_CFG
                                    290 	.globl _PCON
                                    291 	.globl _GLOBAL_CFG
                                    292 	.globl _SAFE_MOD
                                    293 	.globl _DPH
                                    294 	.globl _DPL
                                    295 	.globl _SP
                                    296 	.globl _A_INV
                                    297 	.globl _B
                                    298 	.globl _ACC
                                    299 	.globl _PSW
                                    300 	.globl _disable_action_cache
                                    301 	.globl _tap_code_delay_PARM_2
                                    302 	.globl _process_action_PARM_2
                                    303 	.globl _action_exec_PARM_1
                                    304 	.globl _tp_buttons
                                    305 	.globl _action_exec
                                    306 	.globl _ak820_action_exec
                                    307 	.globl _process_record
                                    308 	.globl _process_record_handler
                                    309 	.globl _process_action
                                    310 	.globl _register_code
                                    311 	.globl _unregister_code
                                    312 	.globl _tap_code_delay
                                    313 	.globl _tap_code
                                    314 	.globl _register_mods
                                    315 	.globl _unregister_mods
                                    316 	.globl _register_weak_mods
                                    317 	.globl _unregister_weak_mods
                                    318 	.globl _clear_keyboard
                                    319 	.globl _clear_keyboard_but_mods
                                    320 	.globl _clear_keyboard_but_mods_and_keys
                                    321 ;--------------------------------------------------------
                                    322 ; special function registers
                                    323 ;--------------------------------------------------------
                                    324 	.area RSEG    (ABS,DATA)
      000000                        325 	.org 0x0000
                           0000D0   326 _PSW	=	0x00d0
                           0000E0   327 _ACC	=	0x00e0
                           0000F0   328 _B	=	0x00f0
                           0000FD   329 _A_INV	=	0x00fd
                           000081   330 _SP	=	0x0081
                           000082   331 _DPL	=	0x0082
                           000083   332 _DPH	=	0x0083
                           0000A1   333 _SAFE_MOD	=	0x00a1
                           0000B1   334 _GLOBAL_CFG	=	0x00b1
                           000087   335 _PCON	=	0x0087
                           0000BA   336 _POWER_CFG	=	0x00ba
                           0000B9   337 _CLOCK_CFG	=	0x00b9
                           0000A9   338 _WAKE_CTRL	=	0x00a9
                           0000FE   339 _RESET_KEEP	=	0x00fe
                           0000FF   340 _WDOG_COUNT	=	0x00ff
                           0000A8   341 _IE	=	0x00a8
                           0000B8   342 _IP	=	0x00b8
                           0000E8   343 _IE_EX	=	0x00e8
                           0000E9   344 _IP_EX	=	0x00e9
                           0000B2   345 _GPIO_IE	=	0x00b2
                           008584   346 _ROM_ADDR	=	0x8584
                           000084   347 _ROM_ADDR_L	=	0x0084
                           000085   348 _ROM_ADDR_H	=	0x0085
                           008F8E   349 _ROM_DATA_HI	=	0x8f8e
                           00008E   350 _ROM_DATA_HL	=	0x008e
                           00008F   351 _ROM_DATA_HH	=	0x008f
                           000086   352 _ROM_CTRL	=	0x0086
                           000080   353 _P0	=	0x0080
                           0000C4   354 _P0_MOD_OC	=	0x00c4
                           0000C5   355 _P0_DIR_PU	=	0x00c5
                           000090   356 _P1	=	0x0090
                           000092   357 _P1_MOD_OC	=	0x0092
                           000093   358 _P1_DIR_PU	=	0x0093
                           0000A0   359 _P2	=	0x00a0
                           000094   360 _P2_MOD_OC	=	0x0094
                           000095   361 _P2_DIR_PU	=	0x0095
                           0000B0   362 _P3	=	0x00b0
                           000096   363 _P3_MOD_OC	=	0x0096
                           000097   364 _P3_DIR_PU	=	0x0097
                           0000C0   365 _P4	=	0x00c0
                           0000C2   366 _P4_MOD_OC	=	0x00c2
                           0000C3   367 _P4_DIR_PU	=	0x00c3
                           0000C1   368 _P4_LED_KEY	=	0x00c1
                           0000AA   369 _P5_IN	=	0x00aa
                           0000AB   370 _P5_OUT_PU	=	0x00ab
                           0000AC   371 _P5_DIR	=	0x00ac
                           0000AD   372 _P6_IN	=	0x00ad
                           0000AE   373 _P6_OUT_PU	=	0x00ae
                           0000AF   374 _P6_DIR	=	0x00af
                           0000F1   375 _P7	=	0x00f1
                           0000A2   376 _XBUS_AUX	=	0x00a2
                           000088   377 _TCON	=	0x0088
                           000089   378 _TMOD	=	0x0089
                           00008A   379 _TL0	=	0x008a
                           00008B   380 _TL1	=	0x008b
                           00008C   381 _TH0	=	0x008c
                           00008D   382 _TH1	=	0x008d
                           000098   383 _SCON	=	0x0098
                           000099   384 _SBUF	=	0x0099
                           0000C8   385 _T2CON	=	0x00c8
                           0000C9   386 _T2MOD	=	0x00c9
                           00CBCA   387 _RCAP2	=	0xcbca
                           0000CA   388 _RCAP2L	=	0x00ca
                           0000CB   389 _RCAP2H	=	0x00cb
                           00CDCC   390 _T2COUNT	=	0xcdcc
                           0000CC   391 _TL2	=	0x00cc
                           0000CD   392 _TH2	=	0x00cd
                           00CFCE   393 _T2CAP1	=	0xcfce
                           0000CE   394 _T2CAP1L	=	0x00ce
                           0000CF   395 _T2CAP1H	=	0x00cf
                           0000F8   396 _SPI0_STAT	=	0x00f8
                           0000F9   397 _SPI0_DATA	=	0x00f9
                           0000FA   398 _SPI0_CTRL	=	0x00fa
                           0000FB   399 _SPI0_CK_SE	=	0x00fb
                           0000FC   400 _SPI0_SETUP	=	0x00fc
                           0000BC   401 _SCON1	=	0x00bc
                           0000BD   402 _SBUF1	=	0x00bd
                           0000BE   403 _SBAUD1	=	0x00be
                           0000BF   404 _SIF1	=	0x00bf
                           0000B4   405 _SPI1_STAT	=	0x00b4
                           0000B5   406 _SPI1_DATA	=	0x00b5
                           0000B6   407 _SPI1_CTRL	=	0x00b6
                           0000B7   408 _SPI1_CK_SE	=	0x00b7
                           0000F3   409 _ADC_CTRL	=	0x00f3
                           00F5F4   410 _ADC_DAT	=	0xf5f4
                           0000F4   411 _ADC_DAT_L	=	0x00f4
                           0000F5   412 _ADC_DAT_H	=	0x00f5
                           0000F6   413 _ADC_CHAN	=	0x00f6
                           0000A6   414 _LED_COMMON	=	0x00a6
                           0000A7   415 _LED_PWM_OE	=	0x00a7
                           00C7C6   416 _LED_DMA	=	0xc7c6
                           0000C6   417 _LED_DMA_L	=	0x00c6
                           0000C7   418 _LED_DMA_H	=	0x00c7
                           0000F7   419 _LED_STATUS	=	0x00f7
                           0000B3   420 _I2CX_INT	=	0x00b3
                           0000BB   421 _I2CS_INT_ST	=	0x00bb
                                    422 ;--------------------------------------------------------
                                    423 ; special function bits
                                    424 ;--------------------------------------------------------
                                    425 	.area RSEG    (ABS,DATA)
      000000                        426 	.org 0x0000
                           0000D7   427 _CY	=	0x00d7
                           0000D6   428 _AC	=	0x00d6
                           0000D5   429 _F0	=	0x00d5
                           0000D4   430 _RS1	=	0x00d4
                           0000D3   431 _RS0	=	0x00d3
                           0000D2   432 _OV	=	0x00d2
                           0000D1   433 _F1	=	0x00d1
                           0000D0   434 _P	=	0x00d0
                           0000AF   435 _EA	=	0x00af
                           0000AE   436 _E_DIS	=	0x00ae
                           0000AD   437 _ET2	=	0x00ad
                           0000AC   438 _ES	=	0x00ac
                           0000AB   439 _ET1	=	0x00ab
                           0000AA   440 _EX1	=	0x00aa
                           0000A9   441 _ET0	=	0x00a9
                           0000A8   442 _EX0	=	0x00a8
                           0000BF   443 _PH_FLAG	=	0x00bf
                           0000BE   444 _PL_FLAG	=	0x00be
                           0000BD   445 _PT2	=	0x00bd
                           0000BC   446 _PS	=	0x00bc
                           0000BB   447 _PT1	=	0x00bb
                           0000BA   448 _PX1	=	0x00ba
                           0000B9   449 _PT0	=	0x00b9
                           0000B8   450 _PX0	=	0x00b8
                           0000EF   451 _IE_WDOG	=	0x00ef
                           0000EE   452 _IE_GPIO	=	0x00ee
                           0000ED   453 _IE_PWM_I2C	=	0x00ed
                           0000EC   454 _IE_UART1	=	0x00ec
                           0000EB   455 _IE_ADC	=	0x00eb
                           0000E9   456 _IE_USB	=	0x00e9
                           0000E8   457 _IE_SPI0	=	0x00e8
                           000087   458 _P0_7	=	0x0087
                           000086   459 _P0_6	=	0x0086
                           000085   460 _P0_5	=	0x0085
                           000084   461 _P0_4	=	0x0084
                           000083   462 _P0_3	=	0x0083
                           000082   463 _P0_2	=	0x0082
                           000081   464 _P0_1	=	0x0081
                           000080   465 _P0_0	=	0x0080
                           000081   466 _SDA0	=	0x0081
                           000080   467 _SCL0	=	0x0080
                           000083   468 _TXD_	=	0x0083
                           000082   469 _RXD_	=	0x0082
                           000085   470 _AIN13	=	0x0085
                           000084   471 _AIN12	=	0x0084
                           000083   472 _AIN11	=	0x0083
                           000082   473 _AIN10	=	0x0082
                           000081   474 _AIN9	=	0x0081
                           000080   475 _AIN8	=	0x0080
                           000097   476 _P1_7	=	0x0097
                           000096   477 _P1_6	=	0x0096
                           000095   478 _P1_5	=	0x0095
                           000094   479 _P1_4	=	0x0094
                           000093   480 _P1_3	=	0x0093
                           000092   481 _P1_2	=	0x0092
                           000091   482 _P1_1	=	0x0091
                           000090   483 _P1_0	=	0x0090
                           000097   484 _TXD1_	=	0x0097
                           000096   485 _RXD1_	=	0x0096
                           000097   486 _SCK	=	0x0097
                           000096   487 _MISO	=	0x0096
                           000095   488 _MOSI	=	0x0095
                           000094   489 _SCS	=	0x0094
                           000092   490 _INT0_	=	0x0092
                           000091   491 _T2EX	=	0x0091
                           000091   492 _CAP2	=	0x0091
                           000090   493 _T2	=	0x0090
                           000090   494 _CAP1	=	0x0090
                           000097   495 _AIN7	=	0x0097
                           000096   496 _AIN6	=	0x0096
                           000095   497 _AIN5	=	0x0095
                           000094   498 _AIN4	=	0x0094
                           000093   499 _AIN3	=	0x0093
                           000092   500 _AIN2	=	0x0092
                           000091   501 _AIN1	=	0x0091
                           000090   502 _AIN0	=	0x0090
                           0000A7   503 _P2_7	=	0x00a7
                           0000A6   504 _P2_6	=	0x00a6
                           0000A5   505 _P2_5	=	0x00a5
                           0000A4   506 _P2_4	=	0x00a4
                           0000A3   507 _P2_3	=	0x00a3
                           0000A2   508 _P2_2	=	0x00a2
                           0000A1   509 _P2_1	=	0x00a1
                           0000A0   510 _P2_0	=	0x00a0
                           0000A7   511 _TXD1	=	0x00a7
                           0000A6   512 _RXD1	=	0x00a6
                           0000A5   513 _T2EX_	=	0x00a5
                           0000A5   514 _CAP2_	=	0x00a5
                           0000A4   515 _T2_	=	0x00a4
                           0000A4   516 _CAP1_	=	0x00a4
                           0000B7   517 _P3_7	=	0x00b7
                           0000B6   518 _P3_6	=	0x00b6
                           0000B5   519 _P3_5	=	0x00b5
                           0000B4   520 _P3_4	=	0x00b4
                           0000B3   521 _P3_3	=	0x00b3
                           0000B2   522 _P3_2	=	0x00b2
                           0000B1   523 _P3_1	=	0x00b1
                           0000B0   524 _P3_0	=	0x00b0
                           0000B7   525 _SCK1	=	0x00b7
                           0000B6   526 _MISO1	=	0x00b6
                           0000B5   527 _MOSI1	=	0x00b5
                           0000B5   528 _T1	=	0x00b5
                           0000B4   529 _T0	=	0x00b4
                           0000B3   530 _INT1	=	0x00b3
                           0000B2   531 _INT0	=	0x00b2
                           0000B1   532 _TXD	=	0x00b1
                           0000B0   533 _RXD	=	0x00b0
                           0000C6   534 _P4_6	=	0x00c6
                           0000C5   535 _P4_5	=	0x00c5
                           0000C4   536 _P4_4	=	0x00c4
                           0000C3   537 _P4_3	=	0x00c3
                           0000C2   538 _P4_2	=	0x00c2
                           0000C1   539 _P4_1	=	0x00c1
                           0000C0   540 _P4_0	=	0x00c0
                           00008F   541 _TF1	=	0x008f
                           00008E   542 _TR1	=	0x008e
                           00008D   543 _TF0	=	0x008d
                           00008C   544 _TR0	=	0x008c
                           00008B   545 _IE1	=	0x008b
                           00008A   546 _IT1	=	0x008a
                           000089   547 _IE0	=	0x0089
                           000088   548 _IT0	=	0x0088
                           00009F   549 _SM0	=	0x009f
                           00009E   550 _SM1	=	0x009e
                           00009D   551 _SM2	=	0x009d
                           00009C   552 _REN	=	0x009c
                           00009B   553 _TB8	=	0x009b
                           00009A   554 _RB8	=	0x009a
                           000099   555 _TI	=	0x0099
                           000098   556 _RI	=	0x0098
                           0000CF   557 _TF2	=	0x00cf
                           0000CF   558 _CAP1F	=	0x00cf
                           0000CE   559 _EXF2	=	0x00ce
                           0000CD   560 _RCLK	=	0x00cd
                           0000CC   561 _TCLK	=	0x00cc
                           0000CB   562 _EXEN2	=	0x00cb
                           0000CA   563 _TR2	=	0x00ca
                           0000C9   564 _C_T2	=	0x00c9
                           0000C8   565 _CP_RL2	=	0x00c8
                           0000FF   566 _S0_FST_ACT	=	0x00ff
                           0000FE   567 _S0_IF_OV	=	0x00fe
                           0000FD   568 _S0_IF_FIRST	=	0x00fd
                           0000FC   569 _S0_IF_BYTE	=	0x00fc
                           0000FB   570 _S0_FREE	=	0x00fb
                           0000FA   571 _S0_T_FIFO	=	0x00fa
                           0000F8   572 _S0_R_FIFO	=	0x00f8
                           0000F7   573 _ADC_START	=	0x00f7
                                    574 ;--------------------------------------------------------
                                    575 ; overlayable register banks
                                    576 ;--------------------------------------------------------
                                    577 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        578 	.ds 8
                                    579 ;--------------------------------------------------------
                                    580 ; internal ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area DSEG    (DATA)
      000018                        583 _process_action_sloc0_1_0:
      000018                        584 	.ds 1
                                    585 ;--------------------------------------------------------
                                    586 ; overlayable items in internal ram
                                    587 ;--------------------------------------------------------
                                    588 ;--------------------------------------------------------
                                    589 ; indirectly addressable internal ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area ISEG    (DATA)
                                    592 ;--------------------------------------------------------
                                    593 ; absolute internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area IABS    (ABS,DATA)
                                    596 	.area IABS    (ABS,DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; bit data
                                    599 ;--------------------------------------------------------
                                    600 	.area BSEG    (BIT)
      00001F                        601 _process_action_sloc1_1_0:
      00001F                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      000809                        611 _tp_buttons::
      000809                        612 	.ds 2
      00080B                        613 _action_exec_PARM_1:
      00080B                        614 	.ds 6
      000811                        615 _action_exec_record_10001_620:
      000811                        616 	.ds 9
      00081A                        617 _ak820_action_exec_event_10000_624:
      00081A                        618 	.ds 2
      00081C                        619 _ak820_action_exec_snapshot_10000_625:
      00081C                        620 	.ds 6
      000822                        621 _process_record_record_10000_628:
      000822                        622 	.ds 3
      000825                        623 _process_record_handler_record_argument_10000_634:
      000825                        624 	.ds 3
      000828                        625 _process_record_handler_action_10000_635:
      000828                        626 	.ds 2
      00082A                        627 _process_action_PARM_2:
      00082A                        628 	.ds 2
      00082C                        629 _process_action_record_argument_10000_646:
      00082C                        630 	.ds 3
      00082F                        631 _process_action_on_40000_669:
      00082F                        632 	.ds 1
      000830                        633 _register_code_code_10000_703:
      000830                        634 	.ds 1
      000831                        635 _unregister_code_code_10000_717:
      000831                        636 	.ds 1
      000832                        637 _tap_code_delay_PARM_2:
      000832                        638 	.ds 2
      000834                        639 _tap_code_delay_code_10000_730:
      000834                        640 	.ds 1
      000835                        641 _tap_code_code_10000_737:
      000835                        642 	.ds 1
      000836                        643 _register_mods_mods_10000_739:
      000836                        644 	.ds 1
      000837                        645 _unregister_mods_mods_10000_743:
      000837                        646 	.ds 1
      000838                        647 _register_weak_mods_mods_10000_747:
      000838                        648 	.ds 1
      000839                        649 _unregister_weak_mods_mods_10000_751:
      000839                        650 	.ds 1
                                    651 ;--------------------------------------------------------
                                    652 ; absolute external ram data
                                    653 ;--------------------------------------------------------
                                    654 	.area XABS    (ABS,XDATA)
                                    655 ;--------------------------------------------------------
                                    656 ; initialized external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XISEG   (XDATA)
      000DB7                        659 _disable_action_cache::
      000DB7                        660 	.ds 1
                                    661 	.area HOME    (CODE)
                                    662 	.area GSINIT0 (CODE)
                                    663 	.area GSINIT1 (CODE)
                                    664 	.area GSINIT2 (CODE)
                                    665 	.area GSINIT3 (CODE)
                                    666 	.area GSINIT4 (CODE)
                                    667 	.area GSINIT5 (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area CSEG    (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; global & static initialisations
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; Home
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area HOME    (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; code
                                    685 ;--------------------------------------------------------
                                    686 	.area CSEG    (CODE)
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    689 ;------------------------------------------------------------
                                    690 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    693 ;	-----------------------------------------
                           000007   694 	ar7 = 0x07
                           000006   695 	ar6 = 0x06
                           000005   696 	ar5 = 0x05
                           000004   697 	ar4 = 0x04
                           000003   698 	ar3 = 0x03
                           000002   699 	ar2 = 0x02
                           000001   700 	ar1 = 0x01
                           000000   701 	ar0 = 0x00
                                    702 ;	 function action_exec
                                    703 ;	-----------------------------------------
      006E42                        704 _action_exec:
                                    705 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      006E42 90 08 0D         [24]  706 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006E45 12 37 F5         [24]  707 	lcall	_ak820_outline_0005
      006E48 12 36 04         [24]  708 	lcall	_ak820_combo_tick
                                    709 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      006E4B 90 08 0B         [24]  710 	mov	dptr,#_action_exec_PARM_1
      006E4E 12 44 4D         [24]  711 	lcall	_ak820_tapping_before
      006E51 E5 82            [12]  712 	mov	a, dpl
      006E53 70 01            [24]  713 	jnz	00102$
      006E55 22               [24]  714 	ret
      006E56                        715 00102$:
                                    716 ;	quantum/action.c:113: if (event.pressed) {
      006E56 90 08 10         [24]  717 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006E59 E0               [24]  718 	movx	a,@dptr
      006E5A 60 03            [24]  719 	jz	00104$
                                    720 ;	quantum/action.c:115: clear_weak_mods();
      006E5C 12 7D CE         [24]  721 	lcall	_clear_weak_mods
      006E5F                        722 00104$:
                                    723 ;	quantum/action.c:127: record.event = event;
      006E5F 90 0D 98         [24]  724 	mov	dptr,#___memcpy_PARM_2
      006E62 74 0B            [12]  725 	mov	a,#_action_exec_PARM_1
      006E64 F0               [24]  726 	movx	@dptr,a
      006E65 74 08            [12]  727 	mov	a,#(_action_exec_PARM_1 >> 8)
      006E67 12 38 6B         [24]  728 	lcall	_ak820_outline_0089
      006E6A 12 74 48         [24]  729 	lcall	_ak820_outline_0070
      006E6D 90 08 11         [24]  730 	mov	dptr,#_action_exec_record_10001_620
      006E70 F5 F0            [12]  731 	mov	b,a
      006E72 12 B5 2E         [24]  732 	lcall	___memcpy
                                    733 ;	quantum/action.c:129: record.tap.count = 0;
      006E75 90 08 17         [24]  734 	mov	dptr,#(_action_exec_record_10001_620 + 0x0006)
      006E78 E0               [24]  735 	movx	a,@dptr
      006E79 54 0F            [12]  736 	anl	a,#0x0f
      006E7B F0               [24]  737 	movx	@dptr,a
                                    738 ;	quantum/action.c:134: record.keycode = 0;
      006E7C 90 08 18         [24]  739 	mov	dptr,#(_action_exec_record_10001_620 + 0x0007)
      006E7F 12 4D 73         [24]  740 	lcall	_ak820_outline_0166
                                    741 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      006E82 90 08 15         [24]  742 	mov	dptr,#(_action_exec_record_10001_620 + 0x0004)
      006E85 E0               [24]  743 	movx	a,@dptr
      006E86 60 0D            [24]  744 	jz	00107$
      006E88 90 08 11         [24]  745 	mov	dptr,#_action_exec_record_10001_620
      006E8B 75 F0 00         [24]  746 	mov	b, #0x00
      006E8E 12 9B D2         [24]  747 	lcall	_pre_process_record_quantum
      006E91 E5 82            [12]  748 	mov	a, dpl
      006E93 60 14            [24]  749 	jz	00110$
      006E95                        750 00107$:
                                    751 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      006E95 90 08 11         [24]  752 	mov	dptr,#_action_exec_record_10001_620
      006E98 12 45 40         [24]  753 	lcall	_ak820_tapping_process
      006E9B E5 82            [12]  754 	mov	a, dpl
      006E9D 70 01            [24]  755 	jnz	00106$
      006E9F 22               [24]  756 	ret
      006EA0                        757 00106$:
                                    758 ;	quantum/action.c:172: process_record(&record);
      006EA0 90 08 11         [24]  759 	mov	dptr,#_action_exec_record_10001_620
      006EA3 75 F0 00         [24]  760 	mov	b, #0x00
                                    761 ;	quantum/action.c:182: }
      006EA6 02 6E E6         [24]  762 	ljmp	_process_record
      006EA9                        763 00110$:
      006EA9 22               [24]  764 	ret
                                    765 ;------------------------------------------------------------
                                    766 ;Allocation info for local variables in function 'ak820_action_exec'
                                    767 ;------------------------------------------------------------
                                    768 ;event         Allocated with name '_ak820_action_exec_event_10000_624'
                                    769 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_625'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function ak820_action_exec
                                    774 ;	-----------------------------------------
      006EAA                        775 _ak820_action_exec:
      006EAA 12 38 88         [24]  776 	lcall	_ak820_outline_0113
      006EAD 90 08 1A         [24]  777 	mov	dptr,#_ak820_action_exec_event_10000_624
      006EB0 12 38 83         [24]  778 	lcall	_ak820_outline_0105
                                    779 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      006EB3 90 08 1A         [24]  780 	mov	dptr,#_ak820_action_exec_event_10000_624
      006EB6 12 38 71         [24]  781 	lcall	_ak820_outline_0092
      006EB9 7F 00            [12]  782 	mov	r7,#0x00
      006EBB 90 0D 98         [24]  783 	mov	dptr,#___memcpy_PARM_2
      006EBE ED               [12]  784 	mov	a,r5
      006EBF 12 38 20         [24]  785 	lcall	_ak820_outline_0014
      006EC2 12 74 48         [24]  786 	lcall	_ak820_outline_0070
      006EC5 90 08 1C         [24]  787 	mov	dptr,#_ak820_action_exec_snapshot_10000_625
      006EC8 F5 F0            [12]  788 	mov	b,a
      006ECA 12 B5 2E         [24]  789 	lcall	___memcpy
                                    790 ;	quantum/action.c:189: action_exec(snapshot);
      006ECD 90 0D 98         [24]  791 	mov	dptr,#___memcpy_PARM_2
      006ED0 74 1C            [12]  792 	mov	a,#_ak820_action_exec_snapshot_10000_625
      006ED2 F0               [24]  793 	movx	@dptr,a
      006ED3 74 08            [12]  794 	mov	a,#(_ak820_action_exec_snapshot_10000_625 >> 8)
      006ED5 12 38 6B         [24]  795 	lcall	_ak820_outline_0089
      006ED8 12 74 48         [24]  796 	lcall	_ak820_outline_0070
      006EDB 90 08 0B         [24]  797 	mov	dptr,#_action_exec_PARM_1
      006EDE F5 F0            [12]  798 	mov	b,a
      006EE0 12 B5 2E         [24]  799 	lcall	___memcpy
                                    800 ;	quantum/action.c:190: }
      006EE3 02 6E 42         [24]  801 	ljmp	_action_exec
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'process_record_nocache'
                                    804 ;------------------------------------------------------------
                                    805 ;record        Allocated with name '_process_record_nocache_record_10000_626'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function process_record
                                    810 ;	-----------------------------------------
      006EE6                        811 _process_record:
      006EE6 12 43 0E         [24]  812 	lcall	_ak820_outline_0035
      006EE9 90 08 22         [24]  813 	mov	dptr,#_process_record_record_10000_628
      006EEC 12 38 20         [24]  814 	lcall	_ak820_outline_0014
                                    815 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      006EEF 90 08 22         [24]  816 	mov	dptr,#_process_record_record_10000_628
      006EF2 12 4D 27         [24]  817 	lcall	_ak820_outline_0013
      006EF5 74 04            [12]  818 	mov	a,#0x04
      006EF7 12 74 1B         [24]  819 	lcall	_ak820_outline_0012
      006EFA 12 B6 07         [24]  820 	lcall	__gptrget
      006EFD 70 01            [24]  821 	jnz	00102$
                                    822 ;	quantum/action.c:330: return;
      006EFF 22               [24]  823 	ret
      006F00                        824 00102$:
                                    825 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      006F00 12 6B 91         [24]  826 	lcall	_ak820_outline_0046
      006F03 C0 07            [24]  827 	push	ar7
      006F05 C0 06            [24]  828 	push	ar6
      006F07 C0 05            [24]  829 	push	ar5
      006F09 12 9C 5A         [24]  830 	lcall	_process_record_quantum
      006F0C E5 82            [12]  831 	mov	a, dpl
      006F0E D0 05            [24]  832 	pop	ar5
      006F10 D0 06            [24]  833 	pop	ar6
      006F12 D0 07            [24]  834 	pop	ar7
      006F14 70 01            [24]  835 	jnz	00104$
                                    836 ;	quantum/action.c:352: return;
      006F16 22               [24]  837 	ret
      006F17                        838 00104$:
                                    839 ;	quantum/action.c:358: process_record_handler(record);
      006F17 12 6B 91         [24]  840 	lcall	_ak820_outline_0046
      006F1A 12 6F 26         [24]  841 	lcall	_process_record_handler
                                    842 ;	quantum/action.c:362: post_process_record_quantum(record);
      006F1D 90 08 22         [24]  843 	mov	dptr,#_process_record_record_10000_628
      006F20 12 4D 01         [24]  844 	lcall	_ak820_outline_0001
                                    845 ;	quantum/action.c:366: }
      006F23 02 9C 2F         [24]  846 	ljmp	_post_process_record_quantum
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'process_record_handler'
                                    849 ;------------------------------------------------------------
                                    850 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_634'
                                    851 ;record        Allocated with name '_process_record_handler_record_10000_635'
                                    852 ;action        Allocated with name '_process_record_handler_action_10000_635'
                                    853 ;------------------------------------------------------------
                                    854 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    855 ;	-----------------------------------------
                                    856 ;	 function process_record_handler
                                    857 ;	-----------------------------------------
      006F26                        858 _process_record_handler:
      006F26 12 43 0E         [24]  859 	lcall	_ak820_outline_0035
      006F29 90 08 25         [24]  860 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006F2C 12 38 20         [24]  861 	lcall	_ak820_outline_0014
                                    862 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      006F2F 90 08 25         [24]  863 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006F32 12 37 FF         [24]  864 	lcall	_ak820_outline_0007
                                    865 ;	quantum/action.c:379: if (record->keycode) {
      006F35 4C               [12]  866 	orl	a,r4
      006F36 60 19            [24]  867 	jz	00102$
                                    868 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      006F38 12 38 92         [24]  869 	lcall	_ak820_outline_0121
      006F3B C0 07            [24]  870 	push	ar7
      006F3D C0 06            [24]  871 	push	ar6
      006F3F 12 91 BE         [24]  872 	lcall	_action_for_keycode
      006F42 12 43 6C         [24]  873 	lcall	_ak820_outline_0144
      006F45 D0 06            [24]  874 	pop	ar6
      006F47 D0 07            [24]  875 	pop	ar7
      006F49 90 08 28         [24]  876 	mov	dptr,#_process_record_handler_action_10000_635
      006F4C 12 38 5F         [24]  877 	lcall	_ak820_outline_0071
      006F4F 80 2B            [24]  878 	sjmp	00104$
      006F51                        879 00102$:
                                    880 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      006F51 12 74 29         [24]  881 	lcall	_ak820_outline_0019
      006F54 7A 00            [12]  882 	mov	r2,#0x00
      006F56 12 43 61         [24]  883 	lcall	_ak820_outline_0138
      006F59 12 42 FC         [24]  884 	lcall	_ak820_outline_0011
      006F5C E0               [24]  885 	movx	a,@dptr
      006F5D 90 09 64         [24]  886 	mov	dptr,#_ak820_resolve_key_PARM_2
      006F60 F0               [24]  887 	movx	@dptr,a
      006F61 8D 82            [24]  888 	mov	dpl, r5
      006F63 8C 83            [24]  889 	mov	dph, r4
      006F65 C0 07            [24]  890 	push	ar7
      006F67 C0 06            [24]  891 	push	ar6
      006F69 12 77 C1         [24]  892 	lcall	_ak820_resolve_key
      006F6C 12 91 BE         [24]  893 	lcall	_action_for_keycode
      006F6F 12 43 6C         [24]  894 	lcall	_ak820_outline_0144
      006F72 D0 06            [24]  895 	pop	ar6
      006F74 D0 07            [24]  896 	pop	ar7
      006F76 90 08 28         [24]  897 	mov	dptr,#_process_record_handler_action_10000_635
      006F79 12 38 5F         [24]  898 	lcall	_ak820_outline_0071
                                    899 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      006F7C                        900 00104$:
                                    901 ;	quantum/action.c:403: process_action(record, action);
      006F7C 7D 00            [12]  902 	mov	r5,#0x00
      006F7E 90 0D 98         [24]  903 	mov	dptr,#___memcpy_PARM_2
      006F81 74 28            [12]  904 	mov	a,#_process_record_handler_action_10000_635
      006F83 F0               [24]  905 	movx	@dptr,a
      006F84 74 08            [12]  906 	mov	a,#(_process_record_handler_action_10000_635 >> 8)
      006F86 12 38 6B         [24]  907 	lcall	_ak820_outline_0089
      006F89 90 0D 9B         [24]  908 	mov	dptr,#___memcpy_PARM_3
      006F8C 74 02            [12]  909 	mov	a,#0x02
      006F8E 12 38 97         [24]  910 	lcall	_ak820_outline_0122
      006F91 90 08 2A         [24]  911 	mov	dptr,#_process_action_PARM_2
      006F94 F5 F0            [12]  912 	mov	b,a
      006F96 C0 07            [24]  913 	push	ar7
      006F98 C0 06            [24]  914 	push	ar6
      006F9A C0 05            [24]  915 	push	ar5
      006F9C 12 B5 2E         [24]  916 	lcall	___memcpy
      006F9F D0 05            [24]  917 	pop	ar5
      006FA1 D0 06            [24]  918 	pop	ar6
      006FA3 D0 07            [24]  919 	pop	ar7
      006FA5 12 6D B4         [24]  920 	lcall	_ak820_outline_0050
                                    921 ;	quantum/action.c:404: }
      006FA8 02 6F AB         [24]  922 	ljmp	_process_action
                                    923 ;------------------------------------------------------------
                                    924 ;Allocation info for local variables in function 'register_mouse'
                                    925 ;------------------------------------------------------------
                                    926 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                    927 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_643'
                                    928 ;------------------------------------------------------------
                                    929 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                    930 ;	-----------------------------------------
                                    931 ;	 function process_action
                                    932 ;	-----------------------------------------
      006FAB                        933 _process_action:
      006FAB 12 43 0E         [24]  934 	lcall	_ak820_outline_0035
      006FAE 90 08 2C         [24]  935 	mov	dptr,#_process_action_record_argument_10000_646
      006FB1 12 38 20         [24]  936 	lcall	_ak820_outline_0014
                                    937 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      006FB4 90 08 2C         [24]  938 	mov	dptr,#_process_action_record_argument_10000_646
      006FB7 12 37 F5         [24]  939 	lcall	_ak820_outline_0005
                                    940 ;	quantum/action.c:475: pressed = record->event.pressed;
      006FBA A3               [24]  941 	inc	dptr
      006FBB A3               [24]  942 	inc	dptr
      006FBC A3               [24]  943 	inc	dptr
      006FBD A3               [24]  944 	inc	dptr
      006FBE A3               [24]  945 	inc	dptr
      006FBF E0               [24]  946 	movx	a,@dptr
      006FC0 F5 18            [12]  947 	mov	_process_action_sloc0_1_0,a
                                    948 ;	quantum/action.c:499: switch (action.kind.id) {
      006FC2 90 08 2B         [24]  949 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      006FC5 E0               [24]  950 	movx	a,@dptr
      006FC6 C4               [12]  951 	swap	a
      006FC7 54 0F            [12]  952 	anl	a,#0x0f
      006FC9 FD               [12]  953 	mov  r5,a
      006FCA 24 F4            [12]  954 	add	a,#0xff - 0x0b
      006FCC 50 03            [24]  955 	jnc	00434$
      006FCE 02 72 4C         [24]  956 	ljmp	00181$
      006FD1                        957 00434$:
                                    958 ;	free result
      006FD1 ED               [12]  959 	mov	a,r5
      006FD2 24 0A            [12]  960 	add	a,#(00435$-3-.)
      006FD4 83               [24]  961 	movc	a,@a+pc
      006FD5 F5 82            [12]  962 	mov	dpl,a
      006FD7 ED               [12]  963 	mov	a,r5
      006FD8 24 10            [12]  964 	add	a,#(00436$-3-.)
      006FDA 83               [24]  965 	movc	a,@a+pc
      006FDB F5 83            [12]  966 	mov	dph,a
      006FDD E4               [12]  967 	clr	a
      006FDE 73               [24]  968 	jmp	@a+dptr
      006FDF                        969 00435$:
      006FDF F7                     970 	.db	00102$
      006FE0 F7                     971 	.db	00102$
      006FE1 4C                     972 	.db	00181$
      006FE2 4C                     973 	.db	00181$
      006FE3 81                     974 	.db	00123$
      006FE4 4C                     975 	.db	00181$
      006FE5 4C                     976 	.db	00181$
      006FE6 4C                     977 	.db	00181$
      006FE7 E1                     978 	.db	00131$
      006FE8 B3                     979 	.db	00147$
      006FE9 D9                     980 	.db	00152$
      006FEA D9                     981 	.db	00152$
      006FEB                        982 00436$:
      006FEB 6F                     983 	.db	00102$>>8
      006FEC 6F                     984 	.db	00102$>>8
      006FED 72                     985 	.db	00181$>>8
      006FEE 72                     986 	.db	00181$>>8
      006FEF 70                     987 	.db	00123$>>8
      006FF0 72                     988 	.db	00181$>>8
      006FF1 72                     989 	.db	00181$>>8
      006FF2 72                     990 	.db	00181$>>8
      006FF3 70                     991 	.db	00131$>>8
      006FF4 71                     992 	.db	00147$>>8
      006FF5 71                     993 	.db	00152$>>8
      006FF6 71                     994 	.db	00152$>>8
                                    995 ;	quantum/action.c:502: case ACT_RMODS: {
      006FF7                        996 00102$:
                                    997 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      006FF7 90 08 2B         [24]  998 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      006FFA E0               [24]  999 	movx	a,@dptr
      006FFB 54 F0            [12] 1000 	anl	a,#0xf0
      006FFD 70 06            [24] 1001 	jnz	00194$
      006FFF 12 74 62         [24] 1002 	lcall	_ak820_outline_0108
      007002 FD               [12] 1003 	mov	r5,a
      007003 80 07            [24] 1004 	sjmp	00195$
      007005                       1005 00194$:
      007005 12 74 62         [24] 1006 	lcall	_ak820_outline_0108
      007008 C4               [12] 1007 	swap	a
      007009 54 F0            [12] 1008 	anl	a,#0xf0
      00700B FD               [12] 1009 	mov	r5,a
      00700C                       1010 00195$:
                                   1011 ;	quantum/action.c:505: if (pressed) {
      00700C E5 18            [12] 1012 	mov	a,_process_action_sloc0_1_0
      00700E 60 35            [24] 1013 	jz	00119$
                                   1014 ;	quantum/action.c:506: if (mods) {
      007010 ED               [12] 1015 	mov	a,r5
      007011 60 29            [24] 1016 	jz	00110$
                                   1017 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007013 12 74 74         [24] 1018 	lcall	_ak820_outline_0155
      007016 FC               [12] 1019 	mov	r4,a
      007017 BC E0 00         [24] 1020 	cjne	r4,#0xe0,00440$
      00701A                       1021 00440$:
      00701A 40 07            [24] 1022 	jc	00108$
      00701C 12 74 74         [24] 1023 	lcall	_ak820_outline_0155
      00701F 24 18            [12] 1024 	add	a,#0xff - 0xe7
      007021 50 0A            [24] 1025 	jnc	00104$
                                   1026 ;	free result
      007023                       1027 00108$:
      007023 7B 2A            [12] 1028 	mov	r3,#_process_action_PARM_2
      007025 7C 08            [12] 1029 	mov	r4,#(_process_action_PARM_2 >> 8)
      007027 12 33 FC         [24] 1030 	lcall	_ak820_outline_0120
      00702A E0               [24] 1031 	movx	a,@dptr
      00702B 70 07            [24] 1032 	jnz	00105$
      00702D                       1033 00104$:
                                   1034 ;	quantum/action.c:511: add_owned_mods(mods);
      00702D 8D 82            [24] 1035 	mov	dpl, r5
      00702F 12 79 DB         [24] 1036 	lcall	_add_owned_mods
      007032 80 05            [24] 1037 	sjmp	00106$
      007034                       1038 00105$:
                                   1039 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      007034 8D 82            [24] 1040 	mov	dpl, r5
      007036 12 79 FA         [24] 1041 	lcall	_add_owned_weak_mods
      007039                       1042 00106$:
                                   1043 ;	quantum/action.c:515: send_keyboard_report();
      007039 12 7D 1F         [24] 1044 	lcall	_send_keyboard_report
      00703C                       1045 00110$:
                                   1046 ;	quantum/action.c:517: register_code(action.key.code);
      00703C 12 74 52         [24] 1047 	lcall	_ak820_outline_0075
      00703F 12 72 63         [24] 1048 	lcall	_register_code
      007042 02 72 4C         [24] 1049 	ljmp	00181$
      007045                       1050 00119$:
                                   1051 ;	quantum/action.c:519: unregister_code(action.key.code);
      007045 12 74 52         [24] 1052 	lcall	_ak820_outline_0075
      007048 C0 05            [24] 1053 	push	ar5
      00704A 12 72 D0         [24] 1054 	lcall	_unregister_code
      00704D D0 05            [24] 1055 	pop	ar5
                                   1056 ;	quantum/action.c:520: if (mods) {
      00704F ED               [12] 1057 	mov	a,r5
      007050 70 03            [24] 1058 	jnz	00444$
      007052 02 72 4C         [24] 1059 	ljmp	00181$
      007055                       1060 00444$:
                                   1061 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007055 12 74 74         [24] 1062 	lcall	_ak820_outline_0155
      007058 FC               [12] 1063 	mov	r4,a
      007059 BC E0 00         [24] 1064 	cjne	r4,#0xe0,00445$
      00705C                       1065 00445$:
      00705C 40 07            [24] 1066 	jc	00115$
      00705E 12 74 74         [24] 1067 	lcall	_ak820_outline_0155
      007061 24 18            [12] 1068 	add	a,#0xff - 0xe7
      007063 50 0A            [24] 1069 	jnc	00111$
                                   1070 ;	free result
      007065                       1071 00115$:
      007065 7B 2A            [12] 1072 	mov	r3,#_process_action_PARM_2
      007067 7C 08            [12] 1073 	mov	r4,#(_process_action_PARM_2 >> 8)
      007069 12 33 FC         [24] 1074 	lcall	_ak820_outline_0120
      00706C E0               [24] 1075 	movx	a,@dptr
      00706D 70 07            [24] 1076 	jnz	00112$
      00706F                       1077 00111$:
                                   1078 ;	quantum/action.c:522: del_owned_mods(mods);
      00706F 8D 82            [24] 1079 	mov	dpl, r5
      007071 12 79 EB         [24] 1080 	lcall	_del_owned_mods
      007074 80 05            [24] 1081 	sjmp	00113$
      007076                       1082 00112$:
                                   1083 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      007076 8D 82            [24] 1084 	mov	dpl, r5
      007078 12 7A 0A         [24] 1085 	lcall	_del_owned_weak_mods
      00707B                       1086 00113$:
                                   1087 ;	quantum/action.c:526: send_keyboard_report();
      00707B 12 7D 1F         [24] 1088 	lcall	_send_keyboard_report
                                   1089 ;	quantum/action.c:529: } break;
      00707E 02 72 4C         [24] 1090 	ljmp	00181$
                                   1091 ;	quantum/action.c:606: case ACT_USAGE:
      007081                       1092 00123$:
                                   1093 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007081 74 07            [12] 1094 	mov	a,#0x07
      007083 12 38 32         [24] 1095 	lcall	_ak820_outline_0021
      007086 12 46 89         [24] 1096 	lcall	_ak820_outline_0008
      007089 C3               [12] 1097 	clr	c
      00708A EC               [12] 1098 	mov	a,r4
      00708B 94 A5            [12] 1099 	subb	a,#0xa5
      00708D ED               [12] 1100 	mov	a,r5
      00708E 94 00            [12] 1101 	subb	a,#0x00
      007090 40 15            [24] 1102 	jc	00125$
      007092 74 C2            [12] 1103 	mov	a,#0xc2
      007094 9C               [12] 1104 	subb	a,r4
      007095 E4               [12] 1105 	clr	a
      007096 9D               [12] 1106 	subb	a,r5
      007097 40 0E            [24] 1107 	jc	00125$
                                   1108 ;	free result
                                   1109 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      007099 90 0A 8B         [24] 1110 	mov	dptr,#_owned_usage_key_PARM_2
      00709C E5 18            [12] 1111 	mov	a,_process_action_sloc0_1_0
      00709E F0               [24] 1112 	movx	@dptr,a
      00709F 8E 82            [24] 1113 	mov	dpl, r6
      0070A1 12 7B CA         [24] 1114 	lcall	_owned_usage_key
                                   1115 ;	quantum/action.c:614: break;
      0070A4 02 72 4C         [24] 1116 	ljmp	00181$
      0070A7                       1117 00125$:
                                   1118 ;	quantum/action.c:617: switch (action.usage.page) {
      0070A7 12 74 59         [24] 1119 	lcall	_ak820_outline_0085
      0070AA FF               [12] 1120 	mov	r7,a
      0070AB 60 08            [24] 1121 	jz	00127$
      0070AD BF 01 02         [24] 1122 	cjne	r7,#0x01,00452$
      0070B0 80 19            [24] 1123 	sjmp	00128$
      0070B2                       1124 00452$:
      0070B2 02 72 4C         [24] 1125 	ljmp	00181$
                                   1126 ;	quantum/action.c:618: case PAGE_SYSTEM:
      0070B5                       1127 00127$:
                                   1128 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      0070B5 E5 18            [12] 1129 	mov	a,_process_action_sloc0_1_0
      0070B7 60 05            [24] 1130 	jz	00196$
      0070B9 12 74 69         [24] 1131 	lcall	_ak820_outline_0128
      0070BC 80 04            [24] 1132 	sjmp	00197$
      0070BE                       1133 00196$:
      0070BE 7E 00            [12] 1134 	mov	r6,#0x00
      0070C0 7F 00            [12] 1135 	mov	r7,#0x00
      0070C2                       1136 00197$:
      0070C2 12 38 8D         [24] 1137 	lcall	_ak820_outline_0114
      0070C5 12 6B 1B         [24] 1138 	lcall	_host_system_send
                                   1139 ;	quantum/action.c:620: break;
      0070C8 02 72 4C         [24] 1140 	ljmp	00181$
                                   1141 ;	quantum/action.c:621: case PAGE_CONSUMER:
      0070CB                       1142 00128$:
                                   1143 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      0070CB E5 18            [12] 1144 	mov	a,_process_action_sloc0_1_0
      0070CD 60 05            [24] 1145 	jz	00198$
      0070CF 12 74 69         [24] 1146 	lcall	_ak820_outline_0128
      0070D2 80 04            [24] 1147 	sjmp	00199$
      0070D4                       1148 00198$:
      0070D4 7E 00            [12] 1149 	mov	r6,#0x00
      0070D6 7F 00            [12] 1150 	mov	r7,#0x00
      0070D8                       1151 00199$:
      0070D8 12 38 8D         [24] 1152 	lcall	_ak820_outline_0114
      0070DB 12 6B 4B         [24] 1153 	lcall	_host_consumer_send
                                   1154 ;	quantum/action.c:625: break;
      0070DE 02 72 4C         [24] 1155 	ljmp	00181$
                                   1156 ;	quantum/action.c:632: case ACT_LAYER: {
      0070E1                       1157 00131$:
                                   1158 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      0070E1 90 08 2B         [24] 1159 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0070E4 E0               [24] 1160 	movx	a,@dptr
      0070E5 54 03            [12] 1161 	anl	a,#0x03
      0070E7 90 08 2F         [24] 1162 	mov	dptr,#_process_action_on_40000_669
      0070EA F0               [24] 1163 	movx	@dptr,a
                                   1164 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0070EB E0               [24] 1165 	movx	a,@dptr
      0070EC FF               [12] 1166 	mov	r7,a
      0070ED 60 11            [24] 1167 	jz	00200$
      0070EF E5 18            [12] 1168 	mov	a,_process_action_sloc0_1_0
      0070F1 60 07            [24] 1169 	jz	00202$
      0070F3 8F 06            [24] 1170 	mov	ar6,r7
      0070F5 53 06 01         [24] 1171 	anl	ar6,#0x01
      0070F8 80 10            [24] 1172 	sjmp	00201$
      0070FA                       1173 00202$:
      0070FA 74 02            [12] 1174 	mov	a,#0x02
      0070FC 5F               [12] 1175 	anl	a,r7
      0070FD FE               [12] 1176 	mov	r6,a
      0070FE 80 0A            [24] 1177 	sjmp	00201$
      007100                       1178 00200$:
      007100 E5 18            [12] 1179 	mov	a,_process_action_sloc0_1_0
      007102 B4 01 00         [24] 1180 	cjne	a,#0x01,00457$
      007105                       1181 00457$:
      007105 92 1F            [24] 1182 	mov  _process_action_sloc1_1_0,c
      007107 E4               [12] 1183 	clr	a
      007108 33               [12] 1184 	rlc	a
      007109 FE               [12] 1185 	mov	r6,a
      00710A                       1186 00201$:
      00710A EE               [12] 1187 	mov	a,r6
      00710B 70 03            [24] 1188 	jnz	00458$
      00710D 02 72 4C         [24] 1189 	ljmp	00181$
      007110                       1190 00458$:
                                   1191 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      007110 12 74 74         [24] 1192 	lcall	_ak820_outline_0155
      007113 C4               [12] 1193 	swap	a
      007114 03               [12] 1194 	rr	a
      007115 54 07            [12] 1195 	anl	a,#0x07
      007117 25 E0            [12] 1196 	add	a,acc
      007119 25 E0            [12] 1197 	add	a,acc
      00711B FF               [12] 1198 	mov	r7,a
                                   1199 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00711C 12 74 74         [24] 1200 	lcall	_ak820_outline_0155
      00711F 54 0F            [12] 1201 	anl	a,#0x0f
      007121 FE               [12] 1202 	mov	r6,a
      007122 8F F0            [24] 1203 	mov	b,r7
      007124 05 F0            [12] 1204 	inc	b
      007126 EE               [12] 1205 	mov	a,r6
      007127 80 02            [24] 1206 	sjmp	00460$
      007129                       1207 00459$:
      007129 25 E0            [12] 1208 	add	a,acc
      00712B                       1209 00460$:
      00712B D5 F0 FB         [24] 1210 	djnz	b,00459$
      00712E FE               [12] 1211 	mov	r6,a
                                   1212 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00712F 12 74 74         [24] 1213 	lcall	_ak820_outline_0155
      007132 30 E4 11         [24] 1214 	jnb	acc.4,00204$
      007135 8F F0            [24] 1215 	mov	b,r7
      007137 05 F0            [12] 1216 	inc	b
      007139 74 0F            [12] 1217 	mov	a,#0x0f
      00713B 80 02            [24] 1218 	sjmp	00463$
      00713D                       1219 00462$:
      00713D 25 E0            [12] 1220 	add	a,acc
      00713F                       1221 00463$:
      00713F D5 F0 FB         [24] 1222 	djnz	b,00462$
      007142 F4               [12] 1223 	cpl	a
      007143 FF               [12] 1224 	mov	r7,a
      007144 80 02            [24] 1225 	sjmp	00205$
      007146                       1226 00204$:
      007146 7F 00            [12] 1227 	mov	r7,#0x00
      007148                       1228 00205$:
                                   1229 ;	quantum/action.c:640: bits |= mask;
      007148 EE               [12] 1230 	mov	a,r6
      007149 42 07            [12] 1231 	orl	ar7,a
                                   1232 ;	quantum/action.c:641: if (!on) {
      00714B 90 08 2F         [24] 1233 	mov	dptr,#_process_action_on_40000_669
      00714E E0               [24] 1234 	movx	a,@dptr
      00714F 70 31            [24] 1235 	jnz	00143$
                                   1236 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      007151 12 74 59         [24] 1237 	lcall	_ak820_outline_0085
      007154 FE               [12] 1238 	mov	r6,a
      007155 2E               [12] 1239 	add	a,r6
                                   1240 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      007156 90 71 5A         [24] 1241 	mov	dptr,#00465$
      007159 73               [24] 1242 	jmp	@a+dptr
      00715A                       1243 00465$:
      00715A 80 06            [24] 1244 	sjmp	00132$
      00715C 80 0C            [24] 1245 	sjmp	00133$
      00715E 80 12            [24] 1246 	sjmp	00134$
      007160 80 18            [24] 1247 	sjmp	00135$
      007162                       1248 00132$:
      007162 8F 82            [24] 1249 	mov	dpl, r7
      007164 12 74 CF         [24] 1250 	lcall	_default_layer_and
      007167 02 72 4C         [24] 1251 	ljmp	00181$
                                   1252 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      00716A                       1253 00133$:
      00716A 8F 82            [24] 1254 	mov	dpl, r7
      00716C 12 74 BE         [24] 1255 	lcall	_default_layer_or
      00716F 02 72 4C         [24] 1256 	ljmp	00181$
                                   1257 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      007172                       1258 00134$:
      007172 8F 82            [24] 1259 	mov	dpl, r7
      007174 12 74 E5         [24] 1260 	lcall	_default_layer_xor
      007177 02 72 4C         [24] 1261 	ljmp	00181$
                                   1262 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      00717A                       1263 00135$:
      00717A 8F 82            [24] 1264 	mov	dpl, r7
      00717C 12 74 B3         [24] 1265 	lcall	_default_layer_set
                                   1266 ;	quantum/action.c:647: }
      00717F 02 72 4C         [24] 1267 	ljmp	00181$
      007182                       1268 00143$:
                                   1269 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      007182 12 74 59         [24] 1270 	lcall	_ak820_outline_0085
      007185 FE               [12] 1271 	mov	r6,a
      007186 2E               [12] 1272 	add	a,r6
                                   1273 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007187 90 71 8B         [24] 1274 	mov	dptr,#00466$
      00718A 73               [24] 1275 	jmp	@a+dptr
      00718B                       1276 00466$:
      00718B 80 06            [24] 1277 	sjmp	00137$
      00718D 80 0C            [24] 1278 	sjmp	00138$
      00718F 80 12            [24] 1279 	sjmp	00139$
      007191 80 18            [24] 1280 	sjmp	00140$
      007193                       1281 00137$:
      007193 8F 82            [24] 1282 	mov	dpl, r7
      007195 12 76 69         [24] 1283 	lcall	_layer_and
      007198 02 72 4C         [24] 1284 	ljmp	00181$
                                   1285 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      00719B                       1286 00138$:
      00719B 8F 82            [24] 1287 	mov	dpl, r7
      00719D 12 76 58         [24] 1288 	lcall	_layer_or
      0071A0 02 72 4C         [24] 1289 	ljmp	00181$
                                   1290 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      0071A3                       1291 00139$:
      0071A3 8F 82            [24] 1292 	mov	dpl, r7
      0071A5 12 76 7F         [24] 1293 	lcall	_layer_xor
      0071A8 02 72 4C         [24] 1294 	ljmp	00181$
                                   1295 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      0071AB                       1296 00140$:
      0071AB 8F 82            [24] 1297 	mov	dpl, r7
      0071AD 12 75 F5         [24] 1298 	lcall	_layer_state_set
                                   1299 ;	quantum/action.c:657: break;
      0071B0 02 72 4C         [24] 1300 	ljmp	00181$
                                   1301 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      0071B3                       1302 00147$:
                                   1303 ;	quantum/action.c:660: if (pressed) {
      0071B3 E5 18            [12] 1304 	mov	a,_process_action_sloc0_1_0
      0071B5 60 11            [24] 1305 	jz	00149$
                                   1306 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      0071B7 12 74 62         [24] 1307 	lcall	_ak820_outline_0108
      0071BA F5 82            [12] 1308 	mov	dpl,a
      0071BC 12 75 55         [24] 1309 	lcall	_layer_hold_on
                                   1310 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      0071BF 12 74 52         [24] 1311 	lcall	_ak820_outline_0075
      0071C2 12 73 86         [24] 1312 	lcall	_register_mods
      0071C5 02 72 4C         [24] 1313 	ljmp	00181$
      0071C8                       1314 00149$:
                                   1315 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      0071C8 12 74 52         [24] 1316 	lcall	_ak820_outline_0075
      0071CB 12 73 9A         [24] 1317 	lcall	_unregister_mods
                                   1318 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      0071CE 12 74 62         [24] 1319 	lcall	_ak820_outline_0108
      0071D1 F5 82            [12] 1320 	mov	dpl,a
      0071D3 12 75 8D         [24] 1321 	lcall	_layer_hold_off
                                   1322 ;	quantum/action.c:667: break;
      0071D6 02 72 4C         [24] 1323 	ljmp	00181$
                                   1324 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      0071D9                       1325 00152$:
                                   1326 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      0071D9 12 74 74         [24] 1327 	lcall	_ak820_outline_0155
      0071DC FF               [12] 1328 	mov	r7,a
      0071DD BF F1 02         [24] 1329 	cjne	r7,#0xf1,00468$
      0071E0 80 0A            [24] 1330 	sjmp	00154$
      0071E2                       1331 00468$:
      0071E2 BF F2 02         [24] 1332 	cjne	r7,#0xf2,00469$
      0071E5 80 19            [24] 1333 	sjmp	00155$
      0071E7                       1334 00469$:
                                   1335 ;	quantum/action.c:686: momentary_layer_action:
      0071E7 BF F3 3B         [24] 1336 	cjne	r7,#0xf3,00160$
      0071EA 80 28            [24] 1337 	sjmp	00156$
      0071EC                       1338 00154$:
                                   1339 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0071EC E5 18            [12] 1340 	mov	a,_process_action_sloc0_1_0
      0071EE 60 08            [24] 1341 	jz	00206$
      0071F0 12 74 38         [24] 1342 	lcall	_ak820_outline_0041
      0071F3 12 75 55         [24] 1343 	lcall	_layer_hold_on
      0071F6 80 54            [24] 1344 	sjmp	00181$
      0071F8                       1345 00206$:
      0071F8 12 74 38         [24] 1346 	lcall	_ak820_outline_0041
      0071FB 12 75 8D         [24] 1347 	lcall	_layer_hold_off
                                   1348 ;	quantum/action.c:688: break;
                                   1349 ;	quantum/action.c:689: case OP_OFF_ON:
      0071FE 80 4C            [24] 1350 	sjmp	00181$
      007200                       1351 00155$:
                                   1352 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007200 E5 18            [12] 1353 	mov	a,_process_action_sloc0_1_0
      007202 60 08            [24] 1354 	jz	00208$
      007204 12 74 38         [24] 1355 	lcall	_ak820_outline_0041
      007207 12 76 3A         [24] 1356 	lcall	_layer_off
      00720A 80 40            [24] 1357 	sjmp	00181$
      00720C                       1358 00208$:
      00720C 12 74 38         [24] 1359 	lcall	_ak820_outline_0041
      00720F 12 76 1F         [24] 1360 	lcall	_layer_on
                                   1361 ;	quantum/action.c:691: break;
                                   1362 ;	quantum/action.c:692: case OP_SET_CLEAR:
      007212 80 38            [24] 1363 	sjmp	00181$
      007214                       1364 00156$:
                                   1365 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007214 E5 18            [12] 1366 	mov	a,_process_action_sloc0_1_0
      007216 60 08            [24] 1367 	jz	00210$
      007218 12 74 38         [24] 1368 	lcall	_ak820_outline_0041
      00721B 12 76 09         [24] 1369 	lcall	_layer_move
      00721E 80 2C            [24] 1370 	sjmp	00181$
      007220                       1371 00210$:
      007220 12 76 03         [24] 1372 	lcall	_layer_clear
                                   1373 ;	quantum/action.c:694: break;
                                   1374 ;	quantum/action.c:740: default:
      007223 80 27            [24] 1375 	sjmp	00181$
      007225                       1376 00160$:
                                   1377 ;	quantum/action.c:747: if (pressed) {
      007225 E5 18            [12] 1378 	mov	a,_process_action_sloc0_1_0
      007227 60 08            [24] 1379 	jz	00163$
                                   1380 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      007229 12 74 52         [24] 1381 	lcall	_ak820_outline_0075
      00722C 12 72 63         [24] 1382 	lcall	_register_code
                                   1383 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      00722F 80 1B            [24] 1384 	sjmp	00181$
      007231                       1385 00163$:
                                   1386 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      007231 12 74 74         [24] 1387 	lcall	_ak820_outline_0155
      007234 FF               [12] 1388 	mov	r7,a
      007235 BF 39 0E         [24] 1389 	cjne	r7,#0x39,00175$
                                   1390 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      007238 7F 50            [12] 1391 	mov	r7,#0x50
      00723A                       1392 00187$:
      00723A EF               [12] 1393 	mov	a,r7
      00723B 60 09            [24] 1394 	jz	00175$
      00723D 90 00 01         [24] 1395 	mov	dptr,#0x0001
      007240 12 56 F5         [24] 1396 	lcall	_mDelaymS
      007243 1F               [12] 1397 	dec	r7
                                   1398 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      007244 80 F4            [24] 1399 	sjmp	00187$
      007246                       1400 00175$:
                                   1401 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      007246 12 74 52         [24] 1402 	lcall	_ak820_outline_0075
      007249 12 72 D0         [24] 1403 	lcall	_unregister_code
                                   1404 ;	quantum/action.c:840: }
      00724C                       1405 00181$:
                                   1406 ;	quantum/action.c:861: switch (action.kind.id) {
      00724C 90 08 2B         [24] 1407 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00724F E0               [24] 1408 	movx	a,@dptr
      007250 C4               [12] 1409 	swap	a
      007251 54 0F            [12] 1410 	anl	a,#0x0f
      007253 FF               [12] 1411 	mov	r7,a
      007254 BF 08 02         [24] 1412 	cjne	r7,#0x08,00478$
      007257 80 03            [24] 1413 	sjmp	00183$
      007259                       1414 00478$:
      007259 BF 09 06         [24] 1415 	cjne	r7,#0x09,00192$
                                   1416 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      00725C                       1417 00183$:
                                   1418 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      00725C 12 6A 80         [24] 1419 	lcall	_host_keyboard_leds
                                   1420 ;	quantum/action.c:872: }
                                   1421 ;	quantum/action.c:925: }
      00725F 02 94 73         [24] 1422 	ljmp	_led_set
      007262                       1423 00192$:
      007262 22               [24] 1424 	ret
                                   1425 ;------------------------------------------------------------
                                   1426 ;Allocation info for local variables in function 'register_code'
                                   1427 ;------------------------------------------------------------
                                   1428 ;code          Allocated with name '_register_code_code_10000_703'
                                   1429 ;------------------------------------------------------------
                                   1430 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1431 ;	-----------------------------------------
                                   1432 ;	 function register_code
                                   1433 ;	-----------------------------------------
      007263                       1434 _register_code:
      007263 E5 82            [12] 1435 	mov	a,dpl
      007265 90 08 30         [24] 1436 	mov	dptr,#_register_code_code_10000_703
      007268 F0               [24] 1437 	movx	@dptr,a
                                   1438 ;	quantum/action.c:932: if (code == KC_NO) {
      007269 E0               [24] 1439 	movx	a,@dptr
      00726A FF               [12] 1440 	mov	r7,a
      00726B 70 01            [24] 1441 	jnz	00123$
                                   1442 ;	quantum/action.c:933: return;
      00726D 22               [24] 1443 	ret
      00726E                       1444 00123$:
                                   1445 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      00726E BF 04 00         [24] 1446 	cjne	r7,#0x04,00186$
      007271                       1447 00186$:
      007271 40 12            [24] 1448 	jc	00119$
      007273 EF               [12] 1449 	mov	a,r7
      007274 24 5B            [12] 1450 	add	a,#0xff - 0xa4
      007276 40 0D            [24] 1451 	jc	00119$
                                   1452 ;	free result
                                   1453 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      007278 8F 82            [24] 1454 	mov	dpl, r7
      00727A 12 7A 7F         [24] 1455 	lcall	_add_owned_key
      00727D E5 82            [12] 1456 	mov	a, dpl
      00727F 70 01            [24] 1457 	jnz	00104$
      007281 22               [24] 1458 	ret
      007282                       1459 00104$:
                                   1460 ;	quantum/action.c:987: send_keyboard_report();
      007282 02 7D 1F         [24] 1461 	ljmp	_send_keyboard_report
      007285                       1462 00119$:
                                   1463 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007285 12 74 79         [24] 1464 	lcall	_ak820_outline_0163
      007288 BF E0 00         [24] 1465 	cjne	r7,#0xe0,00190$
      00728B                       1466 00190$:
      00728B 40 1A            [24] 1467 	jc	00115$
      00728D EF               [12] 1468 	mov	a,r7
      00728E 24 18            [12] 1469 	add	a,#0xff - 0xe7
      007290 40 15            [24] 1470 	jc	00115$
                                   1471 ;	free result
                                   1472 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      007292 74 07            [12] 1473 	mov	a,#0x07
      007294 5F               [12] 1474 	anl	a,r7
      007295 12 74 41         [24] 1475 	lcall	_ak820_outline_0063
      007298 80 02            [24] 1476 	sjmp	00194$
      00729A                       1477 00193$:
      00729A 25 E0            [12] 1478 	add	a,acc
      00729C                       1479 00194$:
      00729C D5 F0 FB         [24] 1480 	djnz	b,00193$
      00729F F5 82            [12] 1481 	mov	dpl,a
      0072A1 12 79 DB         [24] 1482 	lcall	_add_owned_mods
                                   1483 ;	quantum/action.c:990: send_keyboard_report();
      0072A4 02 7D 1F         [24] 1484 	ljmp	_send_keyboard_report
      0072A7                       1485 00115$:
                                   1486 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0072A7 12 74 79         [24] 1487 	lcall	_ak820_outline_0163
      0072AA BF A5 00         [24] 1488 	cjne	r7,#0xa5,00195$
      0072AD                       1489 00195$:
      0072AD 40 05            [24] 1490 	jc	00113$
      0072AF EF               [12] 1491 	mov	a,r7
      0072B0 24 58            [12] 1492 	add	a,#0xff - 0xa7
      0072B2 50 0D            [24] 1493 	jnc	00108$
                                   1494 ;	free result
      0072B4                       1495 00113$:
      0072B4 12 74 79         [24] 1496 	lcall	_ak820_outline_0163
      0072B7 BF A8 00         [24] 1497 	cjne	r7,#0xa8,00198$
      0072BA                       1498 00198$:
      0072BA 40 13            [24] 1499 	jc	00125$
      0072BC EF               [12] 1500 	mov	a,r7
      0072BD 24 3D            [12] 1501 	add	a,#0xff - 0xc2
      0072BF 40 0E            [24] 1502 	jc	00125$
                                   1503 ;	free result
      0072C1                       1504 00108$:
                                   1505 ;	quantum/action.c:995: owned_usage_key(code, true);
      0072C1 12 74 79         [24] 1506 	lcall	_ak820_outline_0163
      0072C4 90 0A 8B         [24] 1507 	mov	dptr,#_owned_usage_key_PARM_2
      0072C7 74 01            [12] 1508 	mov	a,#0x01
      0072C9 F0               [24] 1509 	movx	@dptr,a
      0072CA 8F 82            [24] 1510 	mov	dpl, r7
                                   1511 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1512 ;	quantum/action.c:1005: }
      0072CC 02 7B CA         [24] 1513 	ljmp	_owned_usage_key
      0072CF                       1514 00125$:
      0072CF 22               [24] 1515 	ret
                                   1516 ;------------------------------------------------------------
                                   1517 ;Allocation info for local variables in function 'unregister_code'
                                   1518 ;------------------------------------------------------------
                                   1519 ;code          Allocated with name '_unregister_code_code_10000_717'
                                   1520 ;------------------------------------------------------------
                                   1521 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1522 ;	-----------------------------------------
                                   1523 ;	 function unregister_code
                                   1524 ;	-----------------------------------------
      0072D0                       1525 _unregister_code:
      0072D0 E5 82            [12] 1526 	mov	a,dpl
      0072D2 90 08 31         [24] 1527 	mov	dptr,#_unregister_code_code_10000_717
      0072D5 F0               [24] 1528 	movx	@dptr,a
                                   1529 ;	quantum/action.c:1012: if (code == KC_NO) {
      0072D6 E0               [24] 1530 	movx	a,@dptr
      0072D7 FF               [12] 1531 	mov	r7,a
      0072D8 70 01            [24] 1532 	jnz	00121$
                                   1533 ;	quantum/action.c:1013: return;
      0072DA 22               [24] 1534 	ret
      0072DB                       1535 00121$:
                                   1536 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      0072DB BF 04 00         [24] 1537 	cjne	r7,#0x04,00184$
      0072DE                       1538 00184$:
      0072DE 40 12            [24] 1539 	jc	00117$
      0072E0 EF               [12] 1540 	mov	a,r7
      0072E1 24 5B            [12] 1541 	add	a,#0xff - 0xa4
      0072E3 40 0D            [24] 1542 	jc	00117$
                                   1543 ;	free result
                                   1544 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      0072E5 8F 82            [24] 1545 	mov	dpl, r7
      0072E7 12 7A FC         [24] 1546 	lcall	_del_owned_key
      0072EA E5 82            [12] 1547 	mov	a, dpl
      0072EC 70 01            [24] 1548 	jnz	00102$
      0072EE 22               [24] 1549 	ret
      0072EF                       1550 00102$:
                                   1551 ;	quantum/action.c:1054: send_keyboard_report();
      0072EF 02 7D 1F         [24] 1552 	ljmp	_send_keyboard_report
      0072F2                       1553 00117$:
                                   1554 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      0072F2 12 74 7F         [24] 1555 	lcall	_ak820_outline_0164
      0072F5 BF E0 00         [24] 1556 	cjne	r7,#0xe0,00188$
      0072F8                       1557 00188$:
      0072F8 40 1A            [24] 1558 	jc	00113$
      0072FA EF               [12] 1559 	mov	a,r7
      0072FB 24 18            [12] 1560 	add	a,#0xff - 0xe7
      0072FD 40 15            [24] 1561 	jc	00113$
                                   1562 ;	free result
                                   1563 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      0072FF 74 07            [12] 1564 	mov	a,#0x07
      007301 5F               [12] 1565 	anl	a,r7
      007302 12 74 41         [24] 1566 	lcall	_ak820_outline_0063
      007305 80 02            [24] 1567 	sjmp	00192$
      007307                       1568 00191$:
      007307 25 E0            [12] 1569 	add	a,acc
      007309                       1570 00192$:
      007309 D5 F0 FB         [24] 1571 	djnz	b,00191$
      00730C F5 82            [12] 1572 	mov	dpl,a
      00730E 12 79 EB         [24] 1573 	lcall	_del_owned_mods
                                   1574 ;	quantum/action.c:1057: send_keyboard_report();
      007311 02 7D 1F         [24] 1575 	ljmp	_send_keyboard_report
      007314                       1576 00113$:
                                   1577 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007314 12 74 7F         [24] 1578 	lcall	_ak820_outline_0164
      007317 BF A5 00         [24] 1579 	cjne	r7,#0xa5,00193$
      00731A                       1580 00193$:
      00731A 40 05            [24] 1581 	jc	00111$
      00731C EF               [12] 1582 	mov	a,r7
      00731D 24 58            [12] 1583 	add	a,#0xff - 0xa7
      00731F 50 0D            [24] 1584 	jnc	00106$
                                   1585 ;	free result
      007321                       1586 00111$:
      007321 12 74 7F         [24] 1587 	lcall	_ak820_outline_0164
      007324 BF A8 00         [24] 1588 	cjne	r7,#0xa8,00196$
      007327                       1589 00196$:
      007327 40 12            [24] 1590 	jc	00123$
      007329 EF               [12] 1591 	mov	a,r7
      00732A 24 3D            [12] 1592 	add	a,#0xff - 0xc2
      00732C 40 0D            [24] 1593 	jc	00123$
                                   1594 ;	free result
      00732E                       1595 00106$:
                                   1596 ;	quantum/action.c:1062: owned_usage_key(code, false);
      00732E 12 74 7F         [24] 1597 	lcall	_ak820_outline_0164
      007331 90 0A 8B         [24] 1598 	mov	dptr,#_owned_usage_key_PARM_2
      007334 E4               [12] 1599 	clr	a
      007335 F0               [24] 1600 	movx	@dptr,a
      007336 8F 82            [24] 1601 	mov	dpl, r7
                                   1602 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1603 ;	quantum/action.c:1072: }
      007338 02 7B CA         [24] 1604 	ljmp	_owned_usage_key
      00733B                       1605 00123$:
      00733B 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'tap_code_delay'
                                   1609 ;------------------------------------------------------------
                                   1610 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1611 ;code          Allocated with name '_tap_code_delay_code_10000_730'
                                   1612 ;i             Allocated with name '_tap_code_delay_i_20000_732'
                                   1613 ;i             Allocated with name '_tap_code_delay_i_50000_735'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function tap_code_delay
                                   1618 ;	-----------------------------------------
      00733C                       1619 _tap_code_delay:
      00733C E5 82            [12] 1620 	mov	a,dpl
      00733E 90 08 34         [24] 1621 	mov	dptr,#_tap_code_delay_code_10000_730
      007341 F0               [24] 1622 	movx	@dptr,a
                                   1623 ;	quantum/action.c:1080: register_code(code);
      007342 E0               [24] 1624 	movx	a,@dptr
      007343 FF               [12] 1625 	mov	r7,a
      007344 F5 82            [12] 1626 	mov	dpl,a
      007346 C0 07            [24] 1627 	push	ar7
      007348 12 72 63         [24] 1628 	lcall	_register_code
      00734B D0 07            [24] 1629 	pop	ar7
                                   1630 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      00734D 90 08 32         [24] 1631 	mov	dptr,#_tap_code_delay_PARM_2
      007350 12 38 71         [24] 1632 	lcall	_ak820_outline_0092
      007353                       1633 00110$:
      007353 ED               [12] 1634 	mov	a,r5
      007354 4E               [12] 1635 	orl	a,r6
      007355 60 0D            [24] 1636 	jz	00105$
                                   1637 ;	quantum/action.c:1082: wait_ms(1);
      007357 90 00 01         [24] 1638 	mov	dptr,#0x0001
      00735A 12 56 F5         [24] 1639 	lcall	_mDelaymS
                                   1640 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      00735D 1D               [12] 1641 	dec	r5
      00735E BD FF 01         [24] 1642 	cjne	r5,#0xff,00141$
      007361 1E               [12] 1643 	dec	r6
      007362                       1644 00141$:
      007362 80 EF            [24] 1645 	sjmp	00110$
      007364                       1646 00105$:
                                   1647 ;	quantum/action.c:1084: unregister_code(code);
      007364 8F 82            [24] 1648 	mov	dpl, r7
                                   1649 ;	quantum/action.c:1085: }
      007366 02 72 D0         [24] 1650 	ljmp	_unregister_code
                                   1651 ;------------------------------------------------------------
                                   1652 ;Allocation info for local variables in function 'tap_code'
                                   1653 ;------------------------------------------------------------
                                   1654 ;code          Allocated with name '_tap_code_code_10000_737'
                                   1655 ;------------------------------------------------------------
                                   1656 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1657 ;	-----------------------------------------
                                   1658 ;	 function tap_code
                                   1659 ;	-----------------------------------------
      007369                       1660 _tap_code:
      007369 E5 82            [12] 1661 	mov	a,dpl
      00736B 90 08 35         [24] 1662 	mov	dptr,#_tap_code_code_10000_737
      00736E F0               [24] 1663 	movx	@dptr,a
                                   1664 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      00736F E0               [24] 1665 	movx	a,@dptr
      007370 FF               [12] 1666 	mov	r7,a
      007371 BF 39 04         [24] 1667 	cjne	r7,#0x39,00103$
      007374 7E 50            [12] 1668 	mov	r6,#0x50
      007376 80 02            [24] 1669 	sjmp	00104$
      007378                       1670 00103$:
      007378 7E 00            [12] 1671 	mov	r6,#0x00
      00737A                       1672 00104$:
      00737A 90 08 32         [24] 1673 	mov	dptr,#_tap_code_delay_PARM_2
      00737D EE               [12] 1674 	mov	a,r6
      00737E 12 38 97         [24] 1675 	lcall	_ak820_outline_0122
      007381 8F 82            [24] 1676 	mov	dpl, r7
                                   1677 ;	quantum/action.c:1093: }
      007383 02 73 3C         [24] 1678 	ljmp	_tap_code_delay
                                   1679 ;------------------------------------------------------------
                                   1680 ;Allocation info for local variables in function 'register_mods'
                                   1681 ;------------------------------------------------------------
                                   1682 ;mods          Allocated with name '_register_mods_mods_10000_739'
                                   1683 ;------------------------------------------------------------
                                   1684 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1685 ;	-----------------------------------------
                                   1686 ;	 function register_mods
                                   1687 ;	-----------------------------------------
      007386                       1688 _register_mods:
      007386 E5 82            [12] 1689 	mov	a,dpl
      007388 90 08 36         [24] 1690 	mov	dptr,#_register_mods_mods_10000_739
      00738B F0               [24] 1691 	movx	@dptr,a
                                   1692 ;	quantum/action.c:1100: if (mods) {
      00738C E0               [24] 1693 	movx	a,@dptr
      00738D FF               [12] 1694 	mov	r7,a
      00738E E0               [24] 1695 	movx	a,@dptr
      00738F 60 08            [24] 1696 	jz	00103$
                                   1697 ;	quantum/action.c:1101: add_owned_mods(mods);
      007391 8F 82            [24] 1698 	mov	dpl, r7
      007393 12 79 DB         [24] 1699 	lcall	_add_owned_mods
                                   1700 ;	quantum/action.c:1102: send_keyboard_report();
                                   1701 ;	quantum/action.c:1104: }
      007396 02 7D 1F         [24] 1702 	ljmp	_send_keyboard_report
      007399                       1703 00103$:
      007399 22               [24] 1704 	ret
                                   1705 ;------------------------------------------------------------
                                   1706 ;Allocation info for local variables in function 'unregister_mods'
                                   1707 ;------------------------------------------------------------
                                   1708 ;mods          Allocated with name '_unregister_mods_mods_10000_743'
                                   1709 ;------------------------------------------------------------
                                   1710 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1711 ;	-----------------------------------------
                                   1712 ;	 function unregister_mods
                                   1713 ;	-----------------------------------------
      00739A                       1714 _unregister_mods:
      00739A E5 82            [12] 1715 	mov	a,dpl
      00739C 90 08 37         [24] 1716 	mov	dptr,#_unregister_mods_mods_10000_743
      00739F F0               [24] 1717 	movx	@dptr,a
                                   1718 ;	quantum/action.c:1111: if (mods) {
      0073A0 E0               [24] 1719 	movx	a,@dptr
      0073A1 FF               [12] 1720 	mov	r7,a
      0073A2 E0               [24] 1721 	movx	a,@dptr
      0073A3 60 08            [24] 1722 	jz	00103$
                                   1723 ;	quantum/action.c:1112: del_owned_mods(mods);
      0073A5 8F 82            [24] 1724 	mov	dpl, r7
      0073A7 12 79 EB         [24] 1725 	lcall	_del_owned_mods
                                   1726 ;	quantum/action.c:1113: send_keyboard_report();
                                   1727 ;	quantum/action.c:1115: }
      0073AA 02 7D 1F         [24] 1728 	ljmp	_send_keyboard_report
      0073AD                       1729 00103$:
      0073AD 22               [24] 1730 	ret
                                   1731 ;------------------------------------------------------------
                                   1732 ;Allocation info for local variables in function 'register_weak_mods'
                                   1733 ;------------------------------------------------------------
                                   1734 ;mods          Allocated with name '_register_weak_mods_mods_10000_747'
                                   1735 ;------------------------------------------------------------
                                   1736 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1737 ;	-----------------------------------------
                                   1738 ;	 function register_weak_mods
                                   1739 ;	-----------------------------------------
      0073AE                       1740 _register_weak_mods:
      0073AE E5 82            [12] 1741 	mov	a,dpl
      0073B0 90 08 38         [24] 1742 	mov	dptr,#_register_weak_mods_mods_10000_747
      0073B3 F0               [24] 1743 	movx	@dptr,a
                                   1744 ;	quantum/action.c:1122: if (mods) {
      0073B4 E0               [24] 1745 	movx	a,@dptr
      0073B5 FF               [12] 1746 	mov	r7,a
      0073B6 E0               [24] 1747 	movx	a,@dptr
      0073B7 60 08            [24] 1748 	jz	00103$
                                   1749 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      0073B9 8F 82            [24] 1750 	mov	dpl, r7
      0073BB 12 79 FA         [24] 1751 	lcall	_add_owned_weak_mods
                                   1752 ;	quantum/action.c:1124: send_keyboard_report();
                                   1753 ;	quantum/action.c:1126: }
      0073BE 02 7D 1F         [24] 1754 	ljmp	_send_keyboard_report
      0073C1                       1755 00103$:
      0073C1 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1759 ;------------------------------------------------------------
                                   1760 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_751'
                                   1761 ;------------------------------------------------------------
                                   1762 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1763 ;	-----------------------------------------
                                   1764 ;	 function unregister_weak_mods
                                   1765 ;	-----------------------------------------
      0073C2                       1766 _unregister_weak_mods:
      0073C2 E5 82            [12] 1767 	mov	a,dpl
      0073C4 90 08 39         [24] 1768 	mov	dptr,#_unregister_weak_mods_mods_10000_751
      0073C7 F0               [24] 1769 	movx	@dptr,a
                                   1770 ;	quantum/action.c:1133: if (mods) {
      0073C8 E0               [24] 1771 	movx	a,@dptr
      0073C9 FF               [12] 1772 	mov	r7,a
      0073CA E0               [24] 1773 	movx	a,@dptr
      0073CB 60 08            [24] 1774 	jz	00103$
                                   1775 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      0073CD 8F 82            [24] 1776 	mov	dpl, r7
      0073CF 12 7A 0A         [24] 1777 	lcall	_del_owned_weak_mods
                                   1778 ;	quantum/action.c:1135: send_keyboard_report();
                                   1779 ;	quantum/action.c:1137: }
      0073D2 02 7D 1F         [24] 1780 	ljmp	_send_keyboard_report
      0073D5                       1781 00103$:
      0073D5 22               [24] 1782 	ret
                                   1783 ;------------------------------------------------------------
                                   1784 ;Allocation info for local variables in function 'clear_keyboard'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function clear_keyboard
                                   1789 ;	-----------------------------------------
      0073D6                       1790 _clear_keyboard:
                                   1791 ;	quantum/action.c:1144: clear_mods();
      0073D6 12 7D 99         [24] 1792 	lcall	_clear_mods
                                   1793 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   1794 ;	quantum/action.c:1146: }
      0073D9 02 73 DC         [24] 1795 	ljmp	_clear_keyboard_but_mods
                                   1796 ;------------------------------------------------------------
                                   1797 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function clear_keyboard_but_mods
                                   1802 ;	-----------------------------------------
      0073DC                       1803 _clear_keyboard_but_mods:
                                   1804 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0073DC 90 0D BC         [24] 1805 	mov	dptr,#_actual_keyboard_report
      0073DF 75 F0 00         [24] 1806 	mov	b, #0x00
      0073E2 12 6D 55         [24] 1807 	lcall	_clear_keys_from_report
                                   1808 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   1809 ;	quantum/action.c:1155: }
      0073E5 02 73 E8         [24] 1810 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1811 ;------------------------------------------------------------
                                   1812 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1813 ;------------------------------------------------------------
                                   1814 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   1815 ;	-----------------------------------------
                                   1816 ;	 function clear_keyboard_but_mods_and_keys
                                   1817 ;	-----------------------------------------
      0073E8                       1818 _clear_keyboard_but_mods_and_keys:
                                   1819 ;	quantum/action.c:1163: ak820_tapping_cancel();
      0073E8 12 46 61         [24] 1820 	lcall	_ak820_tapping_cancel
                                   1821 ;	quantum/action.c:1174: ak820_combo_cancel();
      0073EB 12 35 70         [24] 1822 	lcall	_ak820_combo_cancel
                                   1823 ;	quantum/action.c:1177: repeat_key_cancel();
      0073EE 12 9E 77         [24] 1824 	lcall	_repeat_key_cancel
                                   1825 ;	quantum/action.c:1179: clear_owned_mods();
      0073F1 12 7A 1A         [24] 1826 	lcall	_clear_owned_mods
                                   1827 ;	quantum/action.c:1180: clear_owned_keys();
      0073F4 12 7A 52         [24] 1828 	lcall	_clear_owned_keys
                                   1829 ;	quantum/action.c:1181: clear_owned_usages();
      0073F7 12 7B 92         [24] 1830 	lcall	_clear_owned_usages
                                   1831 ;	quantum/action.c:1182: layer_hold_clear();
      0073FA 12 75 C6         [24] 1832 	lcall	_layer_hold_clear
                                   1833 ;	quantum/action.c:1184: clear_macro_tri_layer();
      0073FD 12 99 3A         [24] 1834 	lcall	_clear_macro_tri_layer
                                   1835 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007400 90 0D BC         [24] 1836 	mov	dptr,#_actual_keyboard_report
      007403 75 F0 00         [24] 1837 	mov	b, #0x00
      007406 12 6D 55         [24] 1838 	lcall	_clear_keys_from_report
                                   1839 ;	quantum/action.c:1189: host_system_send(0);
      007409 90 00 00         [24] 1840 	mov	dptr,#0x0000
      00740C 12 6B 1B         [24] 1841 	lcall	_host_system_send
                                   1842 ;	quantum/action.c:1190: host_consumer_send(0);
      00740F 90 00 00         [24] 1843 	mov	dptr,#0x0000
      007412 12 6B 4B         [24] 1844 	lcall	_host_consumer_send
                                   1845 ;	quantum/action.c:1192: clear_weak_mods();
      007415 12 7D CE         [24] 1846 	lcall	_clear_weak_mods
                                   1847 ;	quantum/action.c:1193: send_keyboard_report();
                                   1848 ;	quantum/action.c:1201: }
      007418 02 7D 1F         [24] 1849 	ljmp	_send_keyboard_report
                                   1850 ;------------------------------------------------------------
                                   1851 ;Allocation info for local variables in function 'is_tap_record'
                                   1852 ;------------------------------------------------------------
                                   1853 ;record        Allocated with name '_is_tap_record_record_10000_767'
                                   1854 ;action        Allocated with name '_is_tap_record_action_10001_771'
                                   1855 ;------------------------------------------------------------
                                   1856 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   1857 ;	-----------------------------------------
                                   1858 	.area CSEG    (CODE)
                                   1859 	.area CONST   (CODE)
                                   1860 	.area XINIT   (CODE)
      00BDFD                       1861 __xinit__disable_action_cache:
      00BDFD 00                    1862 	.db #0x00	;  0
                                   1863 	.area CABS    (ABS,CODE)
                                   1864 
                                   1865 ; Experimental exact instruction outlining.
                                   1866 	.globl _ak820_outline_0001
                                   1867 	.globl _ak820_outline_0005
                                   1868 	.globl _ak820_outline_0007
                                   1869 	.globl _ak820_outline_0008
                                   1870 	.globl _ak820_outline_0011
                                   1871 	.globl _ak820_outline_0012
                                   1872 	.globl _ak820_outline_0013
                                   1873 	.globl _ak820_outline_0014
                                   1874 	.globl _ak820_outline_0019
                                   1875 	.globl _ak820_outline_0021
                                   1876 	.globl _ak820_outline_0035
                                   1877 	.globl _ak820_outline_0041
                                   1878 	.globl _ak820_outline_0046
                                   1879 	.globl _ak820_outline_0050
                                   1880 	.globl _ak820_outline_0063
                                   1881 	.globl _ak820_outline_0070
                                   1882 	.globl _ak820_outline_0071
                                   1883 	.globl _ak820_outline_0075
                                   1884 	.globl _ak820_outline_0085
                                   1885 	.globl _ak820_outline_0089
                                   1886 	.globl _ak820_outline_0092
                                   1887 	.globl _ak820_outline_0105
                                   1888 	.globl _ak820_outline_0108
                                   1889 	.globl _ak820_outline_0113
                                   1890 	.globl _ak820_outline_0114
                                   1891 	.globl _ak820_outline_0120
                                   1892 	.globl _ak820_outline_0121
                                   1893 	.globl _ak820_outline_0122
                                   1894 	.globl _ak820_outline_0128
                                   1895 	.globl _ak820_outline_0138
                                   1896 	.globl _ak820_outline_0144
                                   1897 	.globl _ak820_outline_0155
                                   1898 	.globl _ak820_outline_0163
                                   1899 	.globl _ak820_outline_0164
                                   1900 	.globl _ak820_outline_0166
                                   1901 
                                   1902 	.area CSEG (CODE)
                                   1903 ; function ak820_outline_0012
      00741B                       1904 _ak820_outline_0012:
      00741B 2D               [12] 1905 	add	a,r5
      00741C FA               [12] 1906 	mov	r2,a
      00741D E4               [12] 1907 	clr	a
      00741E 3E               [12] 1908 	addc	a,r6
      00741F FB               [12] 1909 	mov	r3,a
      007420 8F 04            [24] 1910 	mov	ar4,r7
      007422 8A 82            [24] 1911 	mov	dpl,r2
      007424 8B 83            [24] 1912 	mov	dph,r3
      007426 8C F0            [24] 1913 	mov	b,r4
      007428 22               [24] 1914 	ret
                                   1915 
                                   1916 	.area CSEG (CODE)
                                   1917 ; function ak820_outline_0019
      007429                       1918 _ak820_outline_0019:
      007429 8E 82            [24] 1919 	mov	dpl,r6
      00742B 8F 83            [24] 1920 	mov	dph,r7
      00742D A3               [24] 1921 	inc	dptr
      00742E E0               [24] 1922 	movx	a,@dptr
      00742F FC               [12] 1923 	mov	r4,a
      007430 7D 00            [12] 1924 	mov	r5,#0x00
      007432 8E 82            [24] 1925 	mov	dpl,r6
      007434 8F 83            [24] 1926 	mov	dph,r7
      007436 E0               [24] 1927 	movx	a,@dptr
      007437 22               [24] 1928 	ret
                                   1929 
                                   1930 	.area CSEG (CODE)
                                   1931 ; function ak820_outline_0041
      007438                       1932 _ak820_outline_0041:
      007438 90 08 2B         [24] 1933 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00743B E0               [24] 1934 	movx	a,@dptr
      00743C 54 1F            [12] 1935 	anl	a,#0x1f
      00743E F5 82            [12] 1936 	mov	dpl,a
      007440 22               [24] 1937 	ret
                                   1938 
                                   1939 	.area CSEG (CODE)
                                   1940 ; function ak820_outline_0063
      007441                       1941 _ak820_outline_0063:
      007441 F5 F0            [12] 1942 	mov	b,a
      007443 05 F0            [12] 1943 	inc	b
      007445 74 01            [12] 1944 	mov	a,#0x01
      007447 22               [24] 1945 	ret
                                   1946 
                                   1947 	.area CSEG (CODE)
                                   1948 ; function ak820_outline_0070
      007448                       1949 _ak820_outline_0070:
      007448 90 0D 9B         [24] 1950 	mov	dptr,#___memcpy_PARM_3
      00744B 74 06            [12] 1951 	mov	a,#0x06
      00744D F0               [24] 1952 	movx	@dptr,a
      00744E E4               [12] 1953 	clr	a
      00744F A3               [24] 1954 	inc	dptr
      007450 F0               [24] 1955 	movx	@dptr,a
      007451 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0075
      007452                       1960 _ak820_outline_0075:
      007452 90 08 2A         [24] 1961 	mov	dptr,#_process_action_PARM_2
      007455 E0               [24] 1962 	movx	a,@dptr
      007456 F5 82            [12] 1963 	mov	dpl,a
      007458 22               [24] 1964 	ret
                                   1965 
                                   1966 	.area CSEG (CODE)
                                   1967 ; function ak820_outline_0085
      007459                       1968 _ak820_outline_0085:
      007459 90 08 2B         [24] 1969 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00745C E0               [24] 1970 	movx	a,@dptr
      00745D 03               [12] 1971 	rr	a
      00745E 03               [12] 1972 	rr	a
      00745F 54 03            [12] 1973 	anl	a,#0x03
      007461 22               [24] 1974 	ret
                                   1975 
                                   1976 	.area CSEG (CODE)
                                   1977 ; function ak820_outline_0108
      007462                       1978 _ak820_outline_0108:
      007462 90 08 2B         [24] 1979 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007465 E0               [24] 1980 	movx	a,@dptr
      007466 54 0F            [12] 1981 	anl	a,#0x0f
      007468 22               [24] 1982 	ret
                                   1983 
                                   1984 	.area CSEG (CODE)
                                   1985 ; function ak820_outline_0128
      007469                       1986 _ak820_outline_0128:
      007469 90 08 2A         [24] 1987 	mov	dptr,#_process_action_PARM_2
      00746C E0               [24] 1988 	movx	a,@dptr
      00746D FE               [12] 1989 	mov	r6,a
      00746E A3               [24] 1990 	inc	dptr
      00746F E0               [24] 1991 	movx	a,@dptr
      007470 54 03            [12] 1992 	anl	a,#0x03
      007472 FF               [12] 1993 	mov	r7,a
      007473 22               [24] 1994 	ret
                                   1995 
                                   1996 	.area CSEG (CODE)
                                   1997 ; function ak820_outline_0155
      007474                       1998 _ak820_outline_0155:
      007474 90 08 2A         [24] 1999 	mov	dptr,#_process_action_PARM_2
      007477 E0               [24] 2000 	movx	a,@dptr
      007478 22               [24] 2001 	ret
                                   2002 
                                   2003 	.area CSEG (CODE)
                                   2004 ; function ak820_outline_0163
      007479                       2005 _ak820_outline_0163:
      007479 90 08 30         [24] 2006 	mov	dptr,#_register_code_code_10000_703
      00747C E0               [24] 2007 	movx	a,@dptr
      00747D FF               [12] 2008 	mov	r7,a
      00747E 22               [24] 2009 	ret
                                   2010 
                                   2011 	.area CSEG (CODE)
                                   2012 ; function ak820_outline_0164
      00747F                       2013 _ak820_outline_0164:
      00747F 90 08 31         [24] 2014 	mov	dptr,#_unregister_code_code_10000_717
      007482 E0               [24] 2015 	movx	a,@dptr
      007483 FF               [12] 2016 	mov	r7,a
      007484 22               [24] 2017 	ret
