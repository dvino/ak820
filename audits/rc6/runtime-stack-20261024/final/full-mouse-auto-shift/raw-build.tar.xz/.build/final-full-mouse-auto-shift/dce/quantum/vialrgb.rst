                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CBE                        569 _g_direct_mode_colors::
      000CBE                        570 	.ds 246
      000DB4                        571 _get_supported_PARM_2:
      000DB4                        572 	.ds 1
      000DB5                        573 _get_supported_args_10000_255:
      000DB5                        574 	.ds 2
      000DB7                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000DB7                        576 	.ds 2
      000DB9                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000DB9                        578 	.ds 2
      000DBB                        579 _set_mode_mode_10000_275:
      000DBB                        580 	.ds 2
      000DBD                        581 _get_matrix_pos_for_led_PARM_2:
      000DBD                        582 	.ds 2
      000DBF                        583 _get_matrix_pos_for_led_led_10000_280:
      000DBF                        584 	.ds 2
      000DC1                        585 _fast_set_leds_PARM_2:
      000DC1                        586 	.ds 1
      000DC2                        587 _fast_set_leds_args_10000_282:
      000DC2                        588 	.ds 2
      000DC4                        589 _fast_set_leds_first_index_10001_285:
      000DC4                        590 	.ds 2
      000DC6                        591 _fast_set_leds_num_leds_10001_285:
      000DC6                        592 	.ds 1
      000DC7                        593 _vialrgb_get_value_PARM_2:
      000DC7                        594 	.ds 1
      000DC8                        595 _vialrgb_get_value_data_10000_291:
      000DC8                        596 	.ds 3
      000DCB                        597 _vialrgb_set_value_PARM_2:
      000DCB                        598 	.ds 1
      000DCC                        599 _vialrgb_set_value_data_10000_302:
      000DCC                        600 	.ds 3
      000DCF                        601 _vialrgb_save_PARM_2:
      000DCF                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B76C                        654 _get_supported:
      00B76C 12 3A CD         [24]  655 	lcall	_ak820_outline_0109
      00B76F 90 0D B5         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B772 12 3A D2         [24]  657 	lcall	_ak820_outline_0110
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B775 90 0D B5         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B778 12 3A 3F         [24]  660 	lcall	_ak820_outline_0005
      00B77B E0               [24]  661 	movx	a,@dptr
      00B77C FD               [12]  662 	mov	r5,a
      00B77D 7C 00            [12]  663 	mov	r4,#0x00
      00B77F 12 3A D7         [24]  664 	lcall	_ak820_outline_0120
      00B782 A3               [24]  665 	inc	dptr
      00B783 E0               [24]  666 	movx	a,@dptr
      00B784 FA               [12]  667 	mov	r2,a
      00B785 E4               [12]  668 	clr	a
      00B786 12 45 B2         [24]  669 	lcall	_ak820_outline_0146
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B789 90 0D B4         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00B78C E0               [24]  672 	movx	a,@dptr
      00B78D FB               [12]  673 	mov	r3,a
      00B78E 7A 00            [12]  674 	mov	r2,#0x00
      00B790                        675 00107$:
      00B790 C3               [12]  676 	clr	c
      00B791 EA               [12]  677 	mov	a,r2
      00B792 9B               [12]  678 	subb	a,r3
      00B793 50 0A            [24]  679 	jnc	00101$
      00B795 EA               [12]  680 	mov	a,r2
      00B796 12 3A 7C         [24]  681 	lcall	_ak820_outline_0022
      00B799 74 FF            [12]  682 	mov	a,#0xff
      00B79B F0               [24]  683 	movx	@dptr,a
      00B79C 0A               [12]  684 	inc	r2
      00B79D 80 F1            [24]  685 	sjmp	00107$
      00B79F                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B79F 8D 06            [24]  688 	mov	ar6,r5
      00B7A1 8C 07            [24]  689 	mov	ar7,r4
      00B7A3 8B 05            [24]  690 	mov	ar5,r3
      00B7A5 90 0D B5         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00B7A8 12 3A DC         [24]  692 	lcall	_ak820_outline_0124
      00B7AB 7A 00            [12]  693 	mov	r2,#0x00
      00B7AD                        694 00110$:
      00B7AD BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00B7B0                        696 00159$:
      00B7B0 50 45            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B7B2 EA               [12]  699 	mov	a,r2
      00B7B3 75 F0 02         [24]  700 	mov	b,#0x02
      00B7B6 A4               [48]  701 	mul	ab
      00B7B7 24 1C            [12]  702 	add	a, #_supported_modes
      00B7B9 F5 82            [12]  703 	mov	dpl,a
      00B7BB 74 C4            [12]  704 	mov	a,#(_supported_modes >> 8)
      00B7BD 12 5B DA         [24]  705 	lcall	_ak820_outline_0111
      00B7C0 F8               [12]  706 	mov	r0,a
      00B7C1 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B7C3 C3               [12]  709 	clr	c
      00B7C4 EE               [12]  710 	mov	a,r6
      00B7C5 98               [12]  711 	subb	a,r0
      00B7C6 EF               [12]  712 	mov	a,r7
      00B7C7 99               [12]  713 	subb	a,r1
      00B7C8 50 2A            [24]  714 	jnc	00111$
                                    715 ;	free result
      00B7CA BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00B7CD                        717 00162$:
      00B7CD 40 25            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00B7CF C0 06            [24]  720 	push	ar6
      00B7D1 C0 07            [24]  721 	push	ar7
      00B7D3 88 07            [24]  722 	mov	ar7,r0
      00B7D5 12 36 47         [24]  723 	lcall	_ak820_outline_0125
      00B7D8 EF               [12]  724 	mov	a,r7
      00B7D9 12 74 65         [24]  725 	lcall	_ak820_outline_0102
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B7DC A3               [24]  727 	inc	dptr
      00B7DD 89 00            [24]  728 	mov	ar0,r1
      00B7DF E8               [12]  729 	mov	a,r0
      00B7E0 F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B7E1 1D               [12]  732 	dec	r5
      00B7E2 1D               [12]  733 	dec	r5
                                    734 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B7E3 74 02            [12]  735 	mov	a,#0x02
      00B7E5 2B               [12]  736 	add	a, r3
      00B7E6 FB               [12]  737 	mov	r3,a
      00B7E7 E4               [12]  738 	clr	a
      00B7E8 3C               [12]  739 	addc	a, r4
      00B7E9 FC               [12]  740 	mov	r4,a
      00B7EA 90 0D B5         [24]  741 	mov	dptr,#_get_supported_args_10000_255
      00B7ED 12 3A B5         [24]  742 	lcall	_ak820_outline_0086
                                    743 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7F0 D0 07            [24]  744 	pop	ar7
      00B7F2 D0 06            [24]  745 	pop	ar6
                                    746 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B7F4                        747 00111$:
                                    748 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7F4 0A               [12]  749 	inc	r2
      00B7F5 80 B6            [24]  750 	sjmp	00110$
      00B7F7                        751 00127$:
      00B7F7 90 0D B5         [24]  752 	mov	dptr,#_get_supported_args_10000_255
      00B7FA 12 3A B5         [24]  753 	lcall	_ak820_outline_0086
                                    754 ;	quantum/vialrgb.c:55: }
      00B7FD 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    758 ;------------------------------------------------------------
                                    759 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    760 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    761 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function qmk_id_to_vialrgb_id
                                    766 ;	-----------------------------------------
      00B7FE                        767 _qmk_id_to_vialrgb_id:
      00B7FE 12 3A CD         [24]  768 	lcall	_ak820_outline_0109
      00B801 90 0D B7         [24]  769 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B804 12 3A D2         [24]  770 	lcall	_ak820_outline_0110
                                    771 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B807 90 0D B7         [24]  772 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B80A 12 3A 8C         [24]  773 	lcall	_ak820_outline_0052
      00B80D 7D 00            [12]  774 	mov	r5,#0x00
      00B80F                        775 00105$:
      00B80F BD 07 00         [24]  776 	cjne	r5,#0x07,00130$
      00B812                        777 00130$:
      00B812 50 19            [24]  778 	jnc	00103$
                                    779 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B814 12 BC 33         [24]  780 	lcall	_ak820_outline_0047
      00B817 A3               [24]  781 	inc	dptr
      00B818 E4               [12]  782 	clr	a
      00B819 93               [24]  783 	movc	a,@a+dptr
                                    784 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B81A 7A 00            [12]  785 	mov	r2,#0x00
      00B81C B5 06 0B         [24]  786 	cjne	a,ar6,00106$
      00B81F EA               [12]  787 	mov	a,r2
      00B820 B5 07 07         [24]  788 	cjne	a,ar7,00106$
                                    789 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B823 12 36 47         [24]  790 	lcall	_ak820_outline_0125
      00B826 12 BC 5F         [24]  791 	lcall	_ak820_outline_0148
      00B829 22               [24]  792 	ret
      00B82A                        793 00106$:
                                    794 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B82A 0D               [12]  795 	inc	r5
      00B82B 80 E2            [24]  796 	sjmp	00105$
      00B82D                        797 00103$:
                                    798 ;	quantum/vialrgb.c:63: return 0;
      00B82D 90 00 00         [24]  799 	mov	dptr,#0x0000
                                    800 ;	quantum/vialrgb.c:64: }
      00B830 22               [24]  801 	ret
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    804 ;------------------------------------------------------------
                                    805 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    806 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    807 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function vialrgb_id_to_qmk_id
                                    812 ;	-----------------------------------------
      00B831                        813 _vialrgb_id_to_qmk_id:
      00B831 12 3A CD         [24]  814 	lcall	_ak820_outline_0109
      00B834 90 0D B9         [24]  815 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B837 12 3A D2         [24]  816 	lcall	_ak820_outline_0110
                                    817 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B83A 90 0D B9         [24]  818 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B83D 12 3A 8C         [24]  819 	lcall	_ak820_outline_0052
      00B840 7D 00            [12]  820 	mov	r5,#0x00
      00B842                        821 00105$:
      00B842 BD 07 00         [24]  822 	cjne	r5,#0x07,00130$
      00B845                        823 00130$:
      00B845 50 19            [24]  824 	jnc	00103$
                                    825 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B847 12 BC 33         [24]  826 	lcall	_ak820_outline_0047
      00B84A E4               [12]  827 	clr	a
      00B84B 93               [24]  828 	movc	a,@a+dptr
                                    829 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B84C 7A 00            [12]  830 	mov	r2,#0x00
      00B84E B5 06 0C         [24]  831 	cjne	a,ar6,00106$
      00B851 EA               [12]  832 	mov	a,r2
      00B852 B5 07 08         [24]  833 	cjne	a,ar7,00106$
                                    834 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B855 12 36 47         [24]  835 	lcall	_ak820_outline_0125
      00B858 A3               [24]  836 	inc	dptr
      00B859 12 BC 5F         [24]  837 	lcall	_ak820_outline_0148
      00B85C 22               [24]  838 	ret
      00B85D                        839 00106$:
                                    840 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B85D 0D               [12]  841 	inc	r5
      00B85E 80 E2            [24]  842 	sjmp	00105$
      00B860                        843 00103$:
                                    844 ;	quantum/vialrgb.c:72: return 0;
      00B860 90 00 00         [24]  845 	mov	dptr,#0x0000
                                    846 ;	quantum/vialrgb.c:73: }
      00B863 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'get_mode'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function get_mode
                                    854 ;	-----------------------------------------
      00B864                        855 _get_mode:
                                    856 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B864 12 59 C0         [24]  857 	lcall	_rgb_matrix_is_enabled
      00B867 E5 82            [12]  858 	mov	a, dpl
      00B869 70 04            [24]  859 	jnz	00102$
                                    860 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B86B 90 00 00         [24]  861 	mov	dptr,#0x0000
      00B86E 22               [24]  862 	ret
      00B86F                        863 00102$:
                                    864 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B86F 12 59 C6         [24]  865 	lcall	_rgb_matrix_get_mode
      00B872 7E 00            [12]  866 	mov	r6,#0x00
      00B874 8E 83            [24]  867 	mov	dph, r6
                                    868 ;	quantum/vialrgb.c:80: }
      00B876 02 B7 FE         [24]  869 	ljmp	_qmk_id_to_vialrgb_id
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'set_mode'
                                    872 ;------------------------------------------------------------
                                    873 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    874 ;------------------------------------------------------------
                                    875 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    876 ;	-----------------------------------------
                                    877 ;	 function set_mode
                                    878 ;	-----------------------------------------
      00B879                        879 _set_mode:
      00B879 12 3A CD         [24]  880 	lcall	_ak820_outline_0109
      00B87C 90 0D BB         [24]  881 	mov	dptr,#_set_mode_mode_10000_275
      00B87F 12 3A D2         [24]  882 	lcall	_ak820_outline_0110
                                    883 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B882 90 0D BB         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00B885 12 3A 8C         [24]  885 	lcall	_ak820_outline_0052
      00B888 90 0D BB         [24]  886 	mov	dptr,#_set_mode_mode_10000_275
      00B88B 12 72 31         [24]  887 	lcall	_ak820_outline_0040
      00B88E 70 03            [24]  888 	jnz	00102$
                                    889 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B890 02 5A 13         [24]  890 	ljmp	_rgb_matrix_disable_noeeprom
      00B893                        891 00102$:
                                    892 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B893 C0 07            [24]  893 	push	ar7
      00B895 C0 06            [24]  894 	push	ar6
      00B897 12 5A 02         [24]  895 	lcall	_rgb_matrix_enable_noeeprom
      00B89A D0 06            [24]  896 	pop	ar6
      00B89C D0 07            [24]  897 	pop	ar7
                                    898 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B89E 12 3A D7         [24]  899 	lcall	_ak820_outline_0120
      00B8A1 12 B8 31         [24]  900 	lcall	_vialrgb_id_to_qmk_id
                                    901 ;	quantum/vialrgb.c:90: }
      00B8A4 02 5A 1C         [24]  902 	ljmp	_rgb_matrix_mode_noeeprom
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    905 ;------------------------------------------------------------
                                    906 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    907 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    908 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    909 ;------------------------------------------------------------
                                    910 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    911 ;	-----------------------------------------
                                    912 ;	 function get_matrix_pos_for_led
                                    913 ;	-----------------------------------------
      00B8A7                        914 _get_matrix_pos_for_led:
      00B8A7 12 3A CD         [24]  915 	lcall	_ak820_outline_0109
      00B8AA 90 0D BF         [24]  916 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B8AD 12 3A D2         [24]  917 	lcall	_ak820_outline_0110
                                    918 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B8B0 90 0D BF         [24]  919 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B8B3 12 3A 8C         [24]  920 	lcall	_ak820_outline_0052
      00B8B6 EE               [12]  921 	mov	a,r6
      00B8B7 24 1B            [12]  922 	add	a, #_ak820_rgb_slots
      00B8B9 F5 82            [12]  923 	mov	dpl,a
      00B8BB EF               [12]  924 	mov	a,r7
      00B8BC 34 BE            [12]  925 	addc	a, #(_ak820_rgb_slots >> 8)
      00B8BE F5 83            [12]  926 	mov	dph,a
      00B8C0 E4               [12]  927 	clr	a
      00B8C1 93               [24]  928 	movc	a,@a+dptr
      00B8C2 FF               [12]  929 	mov	r7,a
                                    930 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B8C3 90 0D BD         [24]  931 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B8C6 12 3A AF         [24]  932 	lcall	_ak820_outline_0080
      00B8C9 EF               [12]  933 	mov	a,r7
      00B8CA 12 5C 10         [24]  934 	lcall	_ak820_outline_0190
      00B8CD 12 86 25         [24]  935 	lcall	_ak820_outline_0123
                                    936 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B8D0 12 3A EC         [24]  937 	lcall	_ak820_outline_0137
      00B8D3 A3               [24]  938 	inc	dptr
      00B8D4 53 07 07         [24]  939 	anl	ar7,#0x07
      00B8D7 EF               [12]  940 	mov	a,r7
      00B8D8 F0               [24]  941 	movx	@dptr,a
                                    942 ;	quantum/vialrgb.c:110: }
      00B8D9 22               [24]  943 	ret
                                    944 ;------------------------------------------------------------
                                    945 ;Allocation info for local variables in function 'fast_set_leds'
                                    946 ;------------------------------------------------------------
                                    947 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    948 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    949 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    950 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    951 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    952 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    953 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    954 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    955 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    958 ;	-----------------------------------------
                                    959 ;	 function fast_set_leds
                                    960 ;	-----------------------------------------
      00B8DA                        961 _fast_set_leds:
      00B8DA 12 3A CD         [24]  962 	lcall	_ak820_outline_0109
      00B8DD 90 0D C2         [24]  963 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8E0 12 3A D2         [24]  964 	lcall	_ak820_outline_0110
                                    965 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B8E3 90 0D C1         [24]  966 	mov	dptr,#_fast_set_leds_PARM_2
      00B8E6 E0               [24]  967 	movx	a,@dptr
      00B8E7 FF               [12]  968 	mov	r7,a
      00B8E8 BF 03 00         [24]  969 	cjne	r7,#0x03,00159$
      00B8EB                        970 00159$:
      00B8EB 50 01            [24]  971 	jnc	00102$
      00B8ED 22               [24]  972 	ret
      00B8EE                        973 00102$:
                                    974 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B8EE 90 0D C2         [24]  975 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8F1 12 3A AF         [24]  976 	lcall	_ak820_outline_0080
      00B8F4 12 4A DB         [24]  977 	lcall	_ak820_outline_0077
      00B8F7 7B 00            [12]  978 	mov	r3,#0x00
      00B8F9 12 3A EC         [24]  979 	lcall	_ak820_outline_0137
      00B8FC A3               [24]  980 	inc	dptr
      00B8FD E0               [24]  981 	movx	a,@dptr
      00B8FE FA               [12]  982 	mov	r2,a
      00B8FF 79 00            [12]  983 	mov	r1,#0x00
      00B901 90 0D C4         [24]  984 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B904 E9               [12]  985 	mov	a,r1
      00B905 4C               [12]  986 	orl	a,r4
      00B906 F0               [24]  987 	movx	@dptr,a
      00B907 EA               [12]  988 	mov	a,r2
      00B908 4B               [12]  989 	orl	a,r3
      00B909 A3               [24]  990 	inc	dptr
      00B90A F0               [24]  991 	movx	@dptr,a
                                    992 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B90B 12 3A EC         [24]  993 	lcall	_ak820_outline_0137
      00B90E A3               [24]  994 	inc	dptr
      00B90F A3               [24]  995 	inc	dptr
      00B910 E0               [24]  996 	movx	a,@dptr
      00B911 90 0D C6         [24]  997 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B914 F0               [24]  998 	movx	@dptr,a
                                    999 ;	quantum/vialrgb.c:119: length -= 3;
      00B915 EF               [12] 1000 	mov	a,r7
      00B916 24 FD            [12] 1001 	add	a,#0xfd
      00B918 90 0D C1         [24] 1002 	mov	dptr,#_fast_set_leds_PARM_2
      00B91B F0               [24] 1003 	movx	@dptr,a
                                   1004 ;	quantum/vialrgb.c:120: args += 3;
      00B91C 90 0D C2         [24] 1005 	mov	dptr,#_fast_set_leds_args_10000_282
      00B91F 74 03            [12] 1006 	mov	a,#0x03
      00B921 2D               [12] 1007 	add	a, r5
      00B922 F0               [24] 1008 	movx	@dptr,a
      00B923 E4               [12] 1009 	clr	a
      00B924 3E               [12] 1010 	addc	a, r6
      00B925 A3               [24] 1011 	inc	dptr
      00B926 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B927 90 0D C6         [24] 1014 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B92A E0               [24] 1015 	movx	a,@dptr
      00B92B FF               [12] 1016 	mov	r7,a
      00B92C 75 F0 03         [24] 1017 	mov	b,#0x03
      00B92F A4               [48] 1018 	mul	ab
      00B930 FE               [12] 1019 	mov	r6,a
      00B931 AD F0            [24] 1020 	mov	r5,b
      00B933 90 0D C1         [24] 1021 	mov	dptr,#_fast_set_leds_PARM_2
      00B936 E0               [24] 1022 	movx	a,@dptr
      00B937 FB               [12] 1023 	mov	r3,a
      00B938 7C 00            [12] 1024 	mov	r4,#0x00
      00B93A C3               [12] 1025 	clr	c
      00B93B EB               [12] 1026 	mov	a,r3
      00B93C 9E               [12] 1027 	subb	a,r6
      00B93D EC               [12] 1028 	mov	a,r4
      00B93E 9D               [12] 1029 	subb	a,r5
      00B93F 40 13            [24] 1030 	jc	00103$
                                   1031 ;	free result
      00B941 90 0D C4         [24] 1032 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B944 12 3A AF         [24] 1033 	lcall	_ak820_outline_0080
      00B947 8D 03            [24] 1034 	mov	ar3,r5
      00B949 8E 04            [24] 1035 	mov	ar4,r6
      00B94B C3               [12] 1036 	clr	c
      00B94C EB               [12] 1037 	mov	a,r3
      00B94D 94 52            [12] 1038 	subb	a,#0x52
      00B94F EC               [12] 1039 	mov	a,r4
      00B950 94 00            [12] 1040 	subb	a,#0x00
      00B952 40 01            [24] 1041 	jc	00104$
      00B954                       1042 00103$:
      00B954 22               [24] 1043 	ret
      00B955                       1044 00104$:
                                   1045 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B955 74 52            [12] 1046 	mov	a,#0x52
      00B957 C3               [12] 1047 	clr	c
      00B958 9D               [12] 1048 	subb	a,r5
      00B959 FB               [12] 1049 	mov	r3,a
      00B95A E4               [12] 1050 	clr	a
      00B95B 9E               [12] 1051 	subb	a,r6
      00B95C FC               [12] 1052 	mov	r4,a
      00B95D 7A 00            [12] 1053 	mov	r2,#0x00
      00B95F C3               [12] 1054 	clr	c
      00B960 EB               [12] 1055 	mov	a,r3
      00B961 9F               [12] 1056 	subb	a,r7
      00B962 EC               [12] 1057 	mov	a,r4
      00B963 9A               [12] 1058 	subb	a,r2
      00B964 50 08            [24] 1059 	jnc	00127$
                                   1060 ;	free result
      00B966 90 0D C6         [24] 1061 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B969 74 52            [12] 1062 	mov	a,#0x52
      00B96B C3               [12] 1063 	clr	c
      00B96C 9D               [12] 1064 	subb	a,r5
      00B96D F0               [24] 1065 	movx	@dptr,a
                                   1066 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B96E                       1067 00127$:
      00B96E 90 0D C6         [24] 1068 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B971 E0               [24] 1069 	movx	a,@dptr
      00B972 FF               [12] 1070 	mov	r7,a
      00B973 90 0D C4         [24] 1071 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B976 12 3A AF         [24] 1072 	lcall	_ak820_outline_0080
      00B979 7C 00            [12] 1073 	mov	r4,#0x00
      00B97B                       1074 00110$:
      00B97B C3               [12] 1075 	clr	c
      00B97C EC               [12] 1076 	mov	a,r4
      00B97D 9F               [12] 1077 	subb	a,r7
      00B97E 40 01            [24] 1078 	jc	00164$
      00B980 22               [24] 1079 	ret
      00B981                       1080 00164$:
                                   1081 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B981 C0 07            [24] 1082 	push	ar7
      00B983 90 0D DE         [24] 1083 	mov	dptr,#__mulint_PARM_2
      00B986 12 45 C8         [24] 1084 	lcall	_ak820_outline_0167
      00B989 90 00 03         [24] 1085 	mov	dptr,#0x0003
      00B98C C0 07            [24] 1086 	push	ar7
      00B98E C0 06            [24] 1087 	push	ar6
      00B990 C0 05            [24] 1088 	push	ar5
      00B992 C0 04            [24] 1089 	push	ar4
      00B994 12 BD CB         [24] 1090 	lcall	__mulint
      00B997 AA 82            [24] 1091 	mov	r2, dpl
      00B999 AB 83            [24] 1092 	mov	r3, dph
      00B99B D0 04            [24] 1093 	pop	ar4
      00B99D D0 05            [24] 1094 	pop	ar5
      00B99F D0 06            [24] 1095 	pop	ar6
      00B9A1 D0 07            [24] 1096 	pop	ar7
      00B9A3 0D               [12] 1097 	inc	r5
      00B9A4 BD 00 01         [24] 1098 	cjne	r5,#0x00,00165$
      00B9A7 0E               [12] 1099 	inc	r6
      00B9A8                       1100 00165$:
      00B9A8 EA               [12] 1101 	mov	a,r2
      00B9A9 24 BE            [12] 1102 	add	a, #_g_direct_mode_colors
      00B9AB FA               [12] 1103 	mov	r2,a
      00B9AC EB               [12] 1104 	mov	a,r3
      00B9AD 34 0C            [12] 1105 	addc	a, #(_g_direct_mode_colors >> 8)
      00B9AF FB               [12] 1106 	mov	r3,a
                                   1107 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B9B0 8A 4A            [24] 1108 	mov	_fast_set_leds_sloc0_1_0,r2
      00B9B2 8B 4B            [24] 1109 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B9B4 12 BC 45         [24] 1110 	lcall	_ak820_outline_0085
      00B9B7 F8               [12] 1111 	mov	r0,a
      00B9B8 12 BC 53         [24] 1112 	lcall	_ak820_outline_0108
      00B9BB 85 4A 82         [24] 1113 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9BE 85 4B 83         [24] 1114 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9C1 E8               [12] 1115 	mov	a,r0
      00B9C2 F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B9C3 74 01            [12] 1118 	mov	a,#0x01
      00B9C5 2A               [12] 1119 	add	a, r2
      00B9C6 F5 4A            [12] 1120 	mov	_fast_set_leds_sloc0_1_0,a
      00B9C8 E4               [12] 1121 	clr	a
      00B9C9 3B               [12] 1122 	addc	a, r3
      00B9CA F5 4B            [12] 1123 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B9CC 90 0D C2         [24] 1124 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9CF E0               [24] 1125 	movx	a,@dptr
      00B9D0 F8               [12] 1126 	mov	r0,a
      00B9D1 A3               [24] 1127 	inc	dptr
      00B9D2 E0               [24] 1128 	movx	a,@dptr
      00B9D3 FF               [12] 1129 	mov	r7,a
      00B9D4 88 82            [24] 1130 	mov	dpl,r0
      00B9D6 8F 83            [24] 1131 	mov	dph,r7
      00B9D8 E0               [24] 1132 	movx	a,@dptr
      00B9D9 F9               [12] 1133 	mov	r1,a
      00B9DA 90 0D C2         [24] 1134 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9DD 74 01            [12] 1135 	mov	a,#0x01
      00B9DF 28               [12] 1136 	add	a, r0
      00B9E0 F0               [24] 1137 	movx	@dptr,a
      00B9E1 E4               [12] 1138 	clr	a
      00B9E2 3F               [12] 1139 	addc	a, r7
      00B9E3 A3               [24] 1140 	inc	dptr
      00B9E4 F0               [24] 1141 	movx	@dptr,a
      00B9E5 85 4A 82         [24] 1142 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9E8 85 4B 83         [24] 1143 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9EB E9               [12] 1144 	mov	a,r1
      00B9EC F0               [24] 1145 	movx	@dptr,a
                                   1146 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B9ED 12 BC 45         [24] 1147 	lcall	_ak820_outline_0085
      00B9F0 F5 4A            [12] 1148 	mov	_fast_set_leds_sloc0_1_0,a
      00B9F2 12 BC 53         [24] 1149 	lcall	_ak820_outline_0108
                                   1150 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B9F5 74 02            [12] 1151 	mov	a,#0x02
      00B9F7 2A               [12] 1152 	add	a, r2
      00B9F8 F5 4C            [12] 1153 	mov	_fast_set_leds_sloc1_1_0,a
      00B9FA E4               [12] 1154 	clr	a
      00B9FB 3B               [12] 1155 	addc	a, r3
      00B9FC F5 4D            [12] 1156 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B9FE C3               [12] 1157 	clr	c
      00B9FF 74 A0            [12] 1158 	mov	a,#0xa0
      00BA01 95 4A            [12] 1159 	subb	a,_fast_set_leds_sloc0_1_0
      00BA03 D0 07            [24] 1160 	pop	ar7
      00BA05 50 04            [24] 1161 	jnc	00114$
                                   1162 ;	free result
      00BA07 7B A0            [12] 1163 	mov	r3,#0xa0
      00BA09 80 04            [24] 1164 	sjmp	00115$
      00BA0B                       1165 00114$:
      00BA0B AA 4A            [24] 1166 	mov	r2,_fast_set_leds_sloc0_1_0
      00BA0D 8A 03            [24] 1167 	mov	ar3,r2
      00BA0F                       1168 00115$:
      00BA0F 85 4C 82         [24] 1169 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BA12 85 4D 83         [24] 1170 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BA15 EB               [12] 1171 	mov	a,r3
      00BA16 F0               [24] 1172 	movx	@dptr,a
                                   1173 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BA17 0C               [12] 1174 	inc	r4
                                   1175 ;	quantum/vialrgb.c:133: }
      00BA18 02 B9 7B         [24] 1176 	ljmp	00110$
                                   1177 ;------------------------------------------------------------
                                   1178 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1179 ;------------------------------------------------------------
                                   1180 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1181 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1182 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1183 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1184 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1185 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1186 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1187 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function vialrgb_get_value
                                   1192 ;	-----------------------------------------
      00BA1B                       1193 _vialrgb_get_value:
      00BA1B 12 45 5E         [24] 1194 	lcall	_ak820_outline_0036
      00BA1E 90 0D C8         [24] 1195 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BA21 12 3A 6A         [24] 1196 	lcall	_ak820_outline_0016
                                   1197 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BA24 90 0D C7         [24] 1198 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BA27 E0               [24] 1199 	movx	a,@dptr
      00BA28 FF               [12] 1200 	mov	r7,a
      00BA29 BF 20 02         [24] 1201 	cjne	r7,#0x20,00162$
      00BA2C 80 01            [24] 1202 	sjmp	00102$
      00BA2E                       1203 00162$:
      00BA2E 22               [24] 1204 	ret
      00BA2F                       1205 00102$:
                                   1206 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BA2F 90 0D C8         [24] 1207 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BA32 12 BC 1F         [24] 1208 	lcall	_ak820_outline_0046
                                   1209 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1210 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BA35 BA 40 02         [24] 1211 	cjne	r2,#0x40,00163$
      00BA38 80 18            [24] 1212 	sjmp	00103$
      00BA3A                       1213 00163$:
      00BA3A BA 41 02         [24] 1214 	cjne	r2,#0x41,00164$
      00BA3D 80 26            [24] 1215 	sjmp	00104$
      00BA3F                       1216 00164$:
      00BA3F BA 42 03         [24] 1217 	cjne	r2,#0x42,00165$
      00BA42 02 BA F7         [24] 1218 	ljmp	00105$
      00BA45                       1219 00165$:
      00BA45 BA 43 03         [24] 1220 	cjne	r2,#0x43,00166$
      00BA48 02 BB 03         [24] 1221 	ljmp	00106$
      00BA4B                       1222 00166$:
      00BA4B BA 44 03         [24] 1223 	cjne	r2,#0x44,00167$
      00BA4E 02 BB 0F         [24] 1224 	ljmp	00107$
      00BA51                       1225 00167$:
      00BA51 22               [24] 1226 	ret
                                   1227 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BA52                       1228 00103$:
                                   1229 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BA52 12 36 47         [24] 1230 	lcall	_ak820_outline_0125
      00BA55 74 01            [12] 1231 	mov	a,#0x01
      00BA57 F0               [24] 1232 	movx	@dptr,a
                                   1233 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BA58 12 BC 17         [24] 1234 	lcall	_ak820_outline_0039
      00BA5B E4               [12] 1235 	clr	a
      00BA5C F0               [24] 1236 	movx	@dptr,a
                                   1237 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BA5D 12 BC 17         [24] 1238 	lcall	_ak820_outline_0039
      00BA60 A3               [24] 1239 	inc	dptr
      00BA61 74 A0            [12] 1240 	mov	a,#0xa0
      00BA63 F0               [24] 1241 	movx	@dptr,a
                                   1242 ;	quantum/vialrgb.c:147: break;
      00BA64 22               [24] 1243 	ret
                                   1244 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BA65                       1245 00104$:
                                   1246 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BA65 C0 06            [24] 1247 	push	ar6
      00BA67 C0 05            [24] 1248 	push	ar5
      00BA69 C0 04            [24] 1249 	push	ar4
      00BA6B C0 03            [24] 1250 	push	ar3
      00BA6D 12 B8 64         [24] 1251 	lcall	_get_mode
      00BA70 A9 82            [24] 1252 	mov	r1, dpl
      00BA72 AA 83            [24] 1253 	mov	r2, dph
      00BA74 D0 03            [24] 1254 	pop	ar3
      00BA76 D0 04            [24] 1255 	pop	ar4
      00BA78 D0 05            [24] 1256 	pop	ar5
      00BA7A D0 06            [24] 1257 	pop	ar6
                                   1258 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BA7C 89 00            [24] 1259 	mov	ar0,r1
      00BA7E 12 36 47         [24] 1260 	lcall	_ak820_outline_0125
      00BA81 E8               [12] 1261 	mov	a,r0
      00BA82 F0               [24] 1262 	movx	@dptr,a
                                   1263 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BA83 12 BC 17         [24] 1264 	lcall	_ak820_outline_0039
      00BA86 8A 01            [24] 1265 	mov	ar1,r2
      00BA88 E9               [12] 1266 	mov	a,r1
      00BA89 F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BA8A 74 04            [12] 1269 	mov	a,#0x04
      00BA8C 12 93 8F         [24] 1270 	lcall	_ak820_outline_0138
      00BA8F C0 06            [24] 1271 	push	ar6
      00BA91 C0 05            [24] 1272 	push	ar5
      00BA93 C0 02            [24] 1273 	push	ar2
      00BA95 C0 01            [24] 1274 	push	ar1
      00BA97 12 59 E1         [24] 1275 	lcall	_rgb_matrix_get_speed
      00BA9A A8 82            [24] 1276 	mov	r0, dpl
      00BA9C D0 01            [24] 1277 	pop	ar1
      00BA9E D0 02            [24] 1278 	pop	ar2
      00BAA0 D0 05            [24] 1279 	pop	ar5
      00BAA2 D0 06            [24] 1280 	pop	ar6
      00BAA4 12 85 FE         [24] 1281 	lcall	_ak820_outline_0064
                                   1282 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BAA7 74 05            [12] 1283 	mov	a,#0x05
      00BAA9 12 93 8F         [24] 1284 	lcall	_ak820_outline_0138
      00BAAC C0 06            [24] 1285 	push	ar6
      00BAAE C0 05            [24] 1286 	push	ar5
      00BAB0 C0 02            [24] 1287 	push	ar2
      00BAB2 C0 01            [24] 1288 	push	ar1
      00BAB4 12 59 CC         [24] 1289 	lcall	_rgb_matrix_get_hue
      00BAB7 A8 82            [24] 1290 	mov	r0, dpl
      00BAB9 D0 01            [24] 1291 	pop	ar1
      00BABB D0 02            [24] 1292 	pop	ar2
      00BABD D0 05            [24] 1293 	pop	ar5
      00BABF D0 06            [24] 1294 	pop	ar6
      00BAC1 12 85 FE         [24] 1295 	lcall	_ak820_outline_0064
                                   1296 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BAC4 74 06            [12] 1297 	mov	a,#0x06
      00BAC6 12 93 8F         [24] 1298 	lcall	_ak820_outline_0138
      00BAC9 C0 06            [24] 1299 	push	ar6
      00BACB C0 05            [24] 1300 	push	ar5
      00BACD C0 02            [24] 1301 	push	ar2
      00BACF C0 01            [24] 1302 	push	ar1
      00BAD1 12 59 D3         [24] 1303 	lcall	_rgb_matrix_get_sat
      00BAD4 A8 82            [24] 1304 	mov	r0, dpl
      00BAD6 D0 01            [24] 1305 	pop	ar1
      00BAD8 D0 02            [24] 1306 	pop	ar2
      00BADA D0 05            [24] 1307 	pop	ar5
      00BADC D0 06            [24] 1308 	pop	ar6
      00BADE 12 85 FE         [24] 1309 	lcall	_ak820_outline_0064
                                   1310 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BAE1 74 07            [12] 1311 	mov	a,#0x07
      00BAE3 12 93 8F         [24] 1312 	lcall	_ak820_outline_0138
      00BAE6 C0 02            [24] 1313 	push	ar2
      00BAE8 C0 01            [24] 1314 	push	ar1
      00BAEA 12 59 DA         [24] 1315 	lcall	_rgb_matrix_get_val
      00BAED A8 82            [24] 1316 	mov	r0, dpl
      00BAEF D0 01            [24] 1317 	pop	ar1
      00BAF1 D0 02            [24] 1318 	pop	ar2
      00BAF3 12 85 FE         [24] 1319 	lcall	_ak820_outline_0064
                                   1320 ;	quantum/vialrgb.c:156: break;
      00BAF6 22               [24] 1321 	ret
                                   1322 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BAF7                       1323 00105$:
                                   1324 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BAF7 EF               [12] 1325 	mov	a,r7
      00BAF8 24 FE            [12] 1326 	add	a,#0xfe
      00BAFA 90 0D B4         [24] 1327 	mov	dptr,#_get_supported_PARM_2
      00BAFD 12 74 65         [24] 1328 	lcall	_ak820_outline_0102
                                   1329 ;	quantum/vialrgb.c:160: break;
      00BB00 02 B7 6C         [24] 1330 	ljmp	_get_supported
                                   1331 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BB03                       1332 00106$:
                                   1333 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BB03 12 36 47         [24] 1334 	lcall	_ak820_outline_0125
      00BB06 74 52            [12] 1335 	mov	a,#0x52
      00BB08 F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BB09 12 BC 17         [24] 1338 	lcall	_ak820_outline_0039
      00BB0C E4               [12] 1339 	clr	a
      00BB0D F0               [24] 1340 	movx	@dptr,a
                                   1341 ;	quantum/vialrgb.c:166: break;
      00BB0E 22               [24] 1342 	ret
                                   1343 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BB0F                       1344 00107$:
                                   1345 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BB0F 12 36 47         [24] 1346 	lcall	_ak820_outline_0125
      00BB12 E0               [24] 1347 	movx	a,@dptr
      00BB13 FF               [12] 1348 	mov	r7,a
      00BB14 7A 00            [12] 1349 	mov	r2,#0x00
      00BB16 74 03            [12] 1350 	mov	a,#0x03
      00BB18 2D               [12] 1351 	add	a, r5
      00BB19 F8               [12] 1352 	mov	r0,a
      00BB1A E4               [12] 1353 	clr	a
      00BB1B 3E               [12] 1354 	addc	a, r6
      00BB1C F9               [12] 1355 	mov	r1,a
      00BB1D C0 03            [24] 1356 	push	ar3
      00BB1F C0 04            [24] 1357 	push	ar4
      00BB21 12 3B 01         [24] 1358 	lcall	_ak820_outline_0163
      00BB24 E0               [24] 1359 	movx	a,@dptr
      00BB25 FB               [12] 1360 	mov	r3,a
      00BB26 E4               [12] 1361 	clr	a
      00BB27 4F               [12] 1362 	orl	a,r7
      00BB28 F5 4E            [12] 1363 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BB2A EB               [12] 1364 	mov	a,r3
      00BB2B 4A               [12] 1365 	orl	a,r2
      00BB2C F5 4F            [12] 1366 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1367 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BB2E AC 4E            [24] 1368 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BB30 AF 4F            [24] 1369 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB32 C3               [12] 1370 	clr	c
      00BB33 EC               [12] 1371 	mov	a,r4
      00BB34 94 52            [12] 1372 	subb	a,#0x52
      00BB36 EF               [12] 1373 	mov	a,r7
      00BB37 94 00            [12] 1374 	subb	a,#0x00
      00BB39 D0 04            [24] 1375 	pop	ar4
      00BB3B D0 03            [24] 1376 	pop	ar3
      00BB3D 40 01            [24] 1377 	jc	00109$
      00BB3F 22               [24] 1378 	ret
      00BB40                       1379 00109$:
                                   1380 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BB40 E5 4E            [12] 1381 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BB42 25 4E            [12] 1382 	add	a,_vialrgb_get_value_sloc0_1_0
      00BB44 FA               [12] 1383 	mov	r2,a
      00BB45 E5 4F            [12] 1384 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB47 33               [12] 1385 	rlc	a
      00BB48 FF               [12] 1386 	mov	r7,a
      00BB49 EA               [12] 1387 	mov	a,r2
      00BB4A 24 D5            [12] 1388 	add	a, #_ak820_led_points
      00BB4C F5 50            [12] 1389 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BB4E EF               [12] 1390 	mov	a,r7
      00BB4F 34 C0            [12] 1391 	addc	a, #(_ak820_led_points >> 8)
      00BB51 F5 51            [12] 1392 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BB53 85 50 82         [24] 1393 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB56 85 51 83         [24] 1394 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB59 E4               [12] 1395 	clr	a
      00BB5A 93               [24] 1396 	movc	a,@a+dptr
      00BB5B 12 36 47         [24] 1397 	lcall	_ak820_outline_0125
      00BB5E F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BB5F 85 50 82         [24] 1400 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB62 85 51 83         [24] 1401 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB65 A3               [24] 1402 	inc	dptr
      00BB66 E4               [12] 1403 	clr	a
      00BB67 93               [24] 1404 	movc	a,@a+dptr
      00BB68 12 3B 01         [24] 1405 	lcall	_ak820_outline_0163
      00BB6B F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BB6C 12 BC 17         [24] 1408 	lcall	_ak820_outline_0039
      00BB6F A3               [24] 1409 	inc	dptr
      00BB70 74 04            [12] 1410 	mov	a,#0x04
      00BB72 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BB73 90 0D BD         [24] 1413 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BB76 04               [12] 1414 	inc	a
      00BB77 2D               [12] 1415 	add	a, r5
      00BB78 F0               [24] 1416 	movx	@dptr,a
      00BB79 E4               [12] 1417 	clr	a
      00BB7A 3E               [12] 1418 	addc	a, r6
      00BB7B A3               [24] 1419 	inc	dptr
      00BB7C F0               [24] 1420 	movx	@dptr,a
      00BB7D 85 4E 82         [24] 1421 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BB80 85 4F 83         [24] 1422 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1423 ;	quantum/vialrgb.c:187: }
                                   1424 ;	quantum/vialrgb.c:188: }
      00BB83 02 B8 A7         [24] 1425 	ljmp	_get_matrix_pos_for_led
                                   1426 ;------------------------------------------------------------
                                   1427 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1428 ;------------------------------------------------------------
                                   1429 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1430 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1431 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1432 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1433 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1434 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1435 ;------------------------------------------------------------
                                   1436 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1437 ;	-----------------------------------------
                                   1438 ;	 function vialrgb_set_value
                                   1439 ;	-----------------------------------------
      00BB86                       1440 _vialrgb_set_value:
      00BB86 12 45 5E         [24] 1441 	lcall	_ak820_outline_0036
      00BB89 90 0D CC         [24] 1442 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB8C 12 3A 6A         [24] 1443 	lcall	_ak820_outline_0016
                                   1444 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BB8F 90 0D CB         [24] 1445 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BB92 E0               [24] 1446 	movx	a,@dptr
      00BB93 FF               [12] 1447 	mov	r7,a
      00BB94 BF 20 02         [24] 1448 	cjne	r7,#0x20,00129$
      00BB97 80 01            [24] 1449 	sjmp	00102$
      00BB99                       1450 00129$:
      00BB99 22               [24] 1451 	ret
      00BB9A                       1452 00102$:
                                   1453 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BB9A 90 0D CC         [24] 1454 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB9D 12 BC 1F         [24] 1455 	lcall	_ak820_outline_0046
                                   1456 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1457 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BBA0 BA 41 02         [24] 1458 	cjne	r2,#0x41,00130$
      00BBA3 80 06            [24] 1459 	sjmp	00103$
      00BBA5                       1460 00130$:
      00BBA5 BA 42 02         [24] 1461 	cjne	r2,#0x42,00131$
      00BBA8 80 5E            [24] 1462 	sjmp	00104$
      00BBAA                       1463 00131$:
      00BBAA 22               [24] 1464 	ret
                                   1465 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BBAB                       1466 00103$:
                                   1467 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BBAB 12 36 47         [24] 1468 	lcall	_ak820_outline_0125
      00BBAE E0               [24] 1469 	movx	a,@dptr
      00BBAF FA               [12] 1470 	mov	r2,a
      00BBB0 12 BC 17         [24] 1471 	lcall	_ak820_outline_0039
      00BBB3 E0               [24] 1472 	movx	a,@dptr
      00BBB4 F8               [12] 1473 	mov	r0,a
      00BBB5 79 00            [12] 1474 	mov	r1,#0x00
      00BBB7 88 53            [24] 1475 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BBB9 89 52            [24] 1476 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BBBB 8A 01            [24] 1477 	mov	ar1,r2
      00BBBD 7A 00            [12] 1478 	mov	r2,#0x00
      00BBBF E5 53            [12] 1479 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BBC1 42 02            [12] 1480 	orl	ar2,a
                                   1481 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BBC3 12 45 CE         [24] 1482 	lcall	_ak820_outline_0185
      00BBC6 C0 06            [24] 1483 	push	ar6
      00BBC8 C0 05            [24] 1484 	push	ar5
      00BBCA 12 B8 79         [24] 1485 	lcall	_set_mode
      00BBCD D0 05            [24] 1486 	pop	ar5
      00BBCF D0 06            [24] 1487 	pop	ar6
                                   1488 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BBD1 12 BC 17         [24] 1489 	lcall	_ak820_outline_0039
      00BBD4 A3               [24] 1490 	inc	dptr
      00BBD5 E0               [24] 1491 	movx	a,@dptr
      00BBD6 F5 82            [12] 1492 	mov	dpl,a
      00BBD8 C0 06            [24] 1493 	push	ar6
      00BBDA C0 05            [24] 1494 	push	ar5
      00BBDC 12 5A AF         [24] 1495 	lcall	_rgb_matrix_set_speed_noeeprom
      00BBDF D0 05            [24] 1496 	pop	ar5
      00BBE1 D0 06            [24] 1497 	pop	ar6
                                   1498 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BBE3 12 BC 17         [24] 1499 	lcall	_ak820_outline_0039
      00BBE6 A3               [24] 1500 	inc	dptr
      00BBE7 A3               [24] 1501 	inc	dptr
      00BBE8 E0               [24] 1502 	movx	a,@dptr
      00BBE9 F9               [12] 1503 	mov	r1,a
      00BBEA 7A 00            [12] 1504 	mov	r2,#0x00
      00BBEC 74 06            [12] 1505 	mov	a,#0x06
      00BBEE 12 BC 69         [24] 1506 	lcall	_ak820_outline_0174
      00BBF1 F8               [12] 1507 	mov	r0,a
      00BBF2 74 07            [12] 1508 	mov	a,#0x07
      00BBF4 12 BC 69         [24] 1509 	lcall	_ak820_outline_0174
      00BBF7 FE               [12] 1510 	mov	r6,a
      00BBF8 90 07 56         [24] 1511 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BBFB E8               [12] 1512 	mov	a,r0
      00BBFC F0               [24] 1513 	movx	@dptr,a
      00BBFD 90 07 57         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BC00 EE               [12] 1515 	mov	a,r6
      00BC01 F0               [24] 1516 	movx	@dptr,a
      00BC02 12 45 CE         [24] 1517 	lcall	_ak820_outline_0185
                                   1518 ;	quantum/vialrgb.c:202: break;
                                   1519 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BC05 02 5A 80         [24] 1520 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BC08                       1521 00104$:
                                   1522 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BC08 EF               [12] 1523 	mov	a,r7
      00BC09 24 FE            [12] 1524 	add	a,#0xfe
      00BC0B 90 0D C1         [24] 1525 	mov	dptr,#_fast_set_leds_PARM_2
      00BC0E 12 74 65         [24] 1526 	lcall	_ak820_outline_0102
                                   1527 ;	quantum/vialrgb.c:210: }
                                   1528 ;	quantum/vialrgb.c:211: }
      00BC11 02 B8 DA         [24] 1529 	ljmp	_fast_set_leds
                                   1530 ;------------------------------------------------------------
                                   1531 ;Allocation info for local variables in function 'vialrgb_save'
                                   1532 ;------------------------------------------------------------
                                   1533 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1534 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1535 ;------------------------------------------------------------
                                   1536 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1537 ;	-----------------------------------------
                                   1538 ;	 function vialrgb_save
                                   1539 ;	-----------------------------------------
      00BC14                       1540 _vialrgb_save:
                                   1541 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1542 ;	quantum/vialrgb.c:218: }
      00BC14 02 55 07         [24] 1543 	ljmp	_eeconfig_update_rgb_matrix
                                   1544 	.area CSEG    (CODE)
                                   1545 	.area CONST   (CODE)
                                   1546 	.area CONST   (CODE)
      00C41C                       1547 _supported_modes:
      00C41C 00                    1548 	.db #0x00	; 0
      00C41D 00                    1549 	.db #0x00	; 0
      00C41E 01                    1550 	.db #0x01	; 1
      00C41F 05                    1551 	.db #0x05	; 5
      00C420 02                    1552 	.db #0x02	; 2
      00C421 01                    1553 	.db #0x01	; 1
      00C422 06                    1554 	.db #0x06	; 6
      00C423 02                    1555 	.db #0x02	; 2
      00C424 0D                    1556 	.db #0x0d	; 13
      00C425 03                    1557 	.db #0x03	; 3
      00C426 0E                    1558 	.db #0x0e	; 14
      00C427 04                    1559 	.db #0x04	; 4
      00C428 1F                    1560 	.db #0x1f	; 31
      00C429 06                    1561 	.db #0x06	; 6
                                   1562 	.area CSEG    (CODE)
                                   1563 	.area XINIT   (CODE)
                                   1564 	.area CABS    (ABS,CODE)
                                   1565 
                                   1566 ; Experimental exact instruction outlining.
                                   1567 	.globl _ak820_outline_0005
                                   1568 	.globl _ak820_outline_0016
                                   1569 	.globl _ak820_outline_0022
                                   1570 	.globl _ak820_outline_0036
                                   1571 	.globl _ak820_outline_0039
                                   1572 	.globl _ak820_outline_0040
                                   1573 	.globl _ak820_outline_0046
                                   1574 	.globl _ak820_outline_0047
                                   1575 	.globl _ak820_outline_0052
                                   1576 	.globl _ak820_outline_0064
                                   1577 	.globl _ak820_outline_0077
                                   1578 	.globl _ak820_outline_0080
                                   1579 	.globl _ak820_outline_0085
                                   1580 	.globl _ak820_outline_0086
                                   1581 	.globl _ak820_outline_0102
                                   1582 	.globl _ak820_outline_0108
                                   1583 	.globl _ak820_outline_0109
                                   1584 	.globl _ak820_outline_0110
                                   1585 	.globl _ak820_outline_0111
                                   1586 	.globl _ak820_outline_0120
                                   1587 	.globl _ak820_outline_0123
                                   1588 	.globl _ak820_outline_0124
                                   1589 	.globl _ak820_outline_0125
                                   1590 	.globl _ak820_outline_0137
                                   1591 	.globl _ak820_outline_0138
                                   1592 	.globl _ak820_outline_0146
                                   1593 	.globl _ak820_outline_0148
                                   1594 	.globl _ak820_outline_0163
                                   1595 	.globl _ak820_outline_0167
                                   1596 	.globl _ak820_outline_0174
                                   1597 	.globl _ak820_outline_0185
                                   1598 	.globl _ak820_outline_0190
                                   1599 
                                   1600 	.area CSEG (CODE)
                                   1601 ; function ak820_outline_0039
      00BC17                       1602 _ak820_outline_0039:
      00BC17 8D 82            [24] 1603 	mov	dpl,r5
      00BC19 8E 83            [24] 1604 	mov	dph,r6
      00BC1B A3               [24] 1605 	inc	dptr
      00BC1C A3               [24] 1606 	inc	dptr
      00BC1D A3               [24] 1607 	inc	dptr
      00BC1E 22               [24] 1608 	ret
                                   1609 
                                   1610 	.area CSEG (CODE)
                                   1611 ; function ak820_outline_0046
      00BC1F                       1612 _ak820_outline_0046:
      00BC1F E0               [24] 1613 	movx	a,@dptr
      00BC20 FD               [12] 1614 	mov	r5,a
      00BC21 A3               [24] 1615 	inc	dptr
      00BC22 E0               [24] 1616 	movx	a,@dptr
      00BC23 FE               [12] 1617 	mov	r6,a
      00BC24 74 02            [12] 1618 	mov	a,#0x02
      00BC26 2D               [12] 1619 	add	a,r5
      00BC27 FB               [12] 1620 	mov	r3,a
      00BC28 E4               [12] 1621 	clr	a
      00BC29 3E               [12] 1622 	addc	a,r6
      00BC2A FC               [12] 1623 	mov	r4,a
      00BC2B 8D 82            [24] 1624 	mov	dpl,r5
      00BC2D 8E 83            [24] 1625 	mov	dph,r6
      00BC2F A3               [24] 1626 	inc	dptr
      00BC30 E0               [24] 1627 	movx	a,@dptr
      00BC31 FA               [12] 1628 	mov	r2,a
      00BC32 22               [24] 1629 	ret
                                   1630 
                                   1631 	.area CSEG (CODE)
                                   1632 ; function ak820_outline_0047
      00BC33                       1633 _ak820_outline_0047:
      00BC33 ED               [12] 1634 	mov	a,r5
      00BC34 75 F0 02         [24] 1635 	mov	b,#0x02
      00BC37 A4               [48] 1636 	mul	ab
      00BC38 24 1C            [12] 1637 	add	a,#_supported_modes
      00BC3A FB               [12] 1638 	mov	r3,a
      00BC3B 74 C4            [12] 1639 	mov	a,#(_supported_modes>>8)
      00BC3D 35 F0            [12] 1640 	addc	a,b
      00BC3F FC               [12] 1641 	mov	r4,a
      00BC40 8B 82            [24] 1642 	mov	dpl,r3
      00BC42 8C 83            [24] 1643 	mov	dph,r4
      00BC44 22               [24] 1644 	ret
                                   1645 
                                   1646 	.area CSEG (CODE)
                                   1647 ; function ak820_outline_0085
      00BC45                       1648 _ak820_outline_0085:
      00BC45 90 0D C2         [24] 1649 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC48 E0               [24] 1650 	movx	a,@dptr
      00BC49 F9               [12] 1651 	mov	r1,a
      00BC4A A3               [24] 1652 	inc	dptr
      00BC4B E0               [24] 1653 	movx	a,@dptr
      00BC4C FF               [12] 1654 	mov	r7,a
      00BC4D 89 82            [24] 1655 	mov	dpl,r1
      00BC4F 8F 83            [24] 1656 	mov	dph,r7
      00BC51 E0               [24] 1657 	movx	a,@dptr
      00BC52 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0108
      00BC53                       1662 _ak820_outline_0108:
      00BC53 90 0D C2         [24] 1663 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC56 74 01            [12] 1664 	mov	a,#0x01
      00BC58 29               [12] 1665 	add	a,r1
      00BC59 F0               [24] 1666 	movx	@dptr,a
      00BC5A E4               [12] 1667 	clr	a
      00BC5B 3F               [12] 1668 	addc	a,r7
      00BC5C A3               [24] 1669 	inc	dptr
      00BC5D F0               [24] 1670 	movx	@dptr,a
      00BC5E 22               [24] 1671 	ret
                                   1672 
                                   1673 	.area CSEG (CODE)
                                   1674 ; function ak820_outline_0148
      00BC5F                       1675 _ak820_outline_0148:
      00BC5F E4               [12] 1676 	clr	a
      00BC60 93               [24] 1677 	movc	a,@a+dptr
      00BC61 FC               [12] 1678 	mov	r4,a
      00BC62 7B 00            [12] 1679 	mov	r3,#0x00
      00BC64 8C 82            [24] 1680 	mov	dpl,r4
      00BC66 8B 83            [24] 1681 	mov	dph,r3
      00BC68 22               [24] 1682 	ret
                                   1683 
                                   1684 	.area CSEG (CODE)
                                   1685 ; function ak820_outline_0174
      00BC69                       1686 _ak820_outline_0174:
      00BC69 2D               [12] 1687 	add	a,r5
      00BC6A F5 82            [12] 1688 	mov	dpl,a
      00BC6C E4               [12] 1689 	clr	a
      00BC6D 3E               [12] 1690 	addc	a,r6
      00BC6E F5 83            [12] 1691 	mov	dph,a
      00BC70 E0               [24] 1692 	movx	a,@dptr
      00BC71 22               [24] 1693 	ret
