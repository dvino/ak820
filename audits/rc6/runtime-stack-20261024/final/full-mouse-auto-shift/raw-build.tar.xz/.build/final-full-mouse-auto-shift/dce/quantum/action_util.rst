                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000054                        551 _change_owned_sloc1_1_0:
      000054                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000021                        566 _ak820_macro_change_sloc0_1_0:
      000021                        567 	.ds 1
      000022                        568 _change_owned_sloc0_1_0:
      000022                        569 	.ds 1
      000023                        570 _owned_usage_key_sloc0_1_0:
      000023                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      0009A4                        580 _owned_mod_refs:
      0009A4                        581 	.ds 8
      0009AC                        582 _owned_weak_refs:
      0009AC                        583 	.ds 8
      0009B4                        584 _owned_mods:
      0009B4                        585 	.ds 1
      0009B5                        586 _owned_weak_mods:
      0009B5                        587 	.ds 1
      0009B6                        588 _macro_mods:
      0009B6                        589 	.ds 2
      0009B8                        590 _ak820_macro_primitive::
      0009B8                        591 	.ds 1
      0009B9                        592 _ak820_macro_cancelled::
      0009B9                        593 	.ds 1
      0009BA                        594 _ak820_macro_change_PARM_2:
      0009BA                        595 	.ds 1
      0009BB                        596 _ak820_macro_change_PARM_3:
      0009BB                        597 	.ds 1
      0009BC                        598 _ak820_macro_change_bits_10000_294:
      0009BC                        599 	.ds 2
      0009BE                        600 _change_owned_PARM_2:
      0009BE                        601 	.ds 1
      0009BF                        602 _change_owned_mods_10000_299:
      0009BF                        603 	.ds 1
      0009C0                        604 _change_owned_result_10001_303:
      0009C0                        605 	.ds 1
      0009C1                        606 _change_owned_bit_20001_304:
      0009C1                        607 	.ds 1
      0009C2                        608 _add_owned_mods_mods_10000_312:
      0009C2                        609 	.ds 1
      0009C3                        610 _del_owned_mods_mods_10000_314:
      0009C3                        611 	.ds 1
      0009C4                        612 _add_owned_weak_mods_mods_10000_316:
      0009C4                        613 	.ds 1
      0009C5                        614 _del_owned_weak_mods_mods_10000_318:
      0009C5                        615 	.ds 1
      0009C6                        616 _key_refs:
      0009C6                        617 	.ds 165
      000A6B                        618 _distinct_keys:
      000A6B                        619 	.ds 1
      000A6C                        620 _macro_keys:
      000A6C                        621 	.ds 21
      000A81                        622 _add_owned_key_code_10000_327:
      000A81                        623 	.ds 1
      000A82                        624 _del_owned_key_code_10000_342:
      000A82                        625 	.ds 1
      000A83                        626 _usage_refs:
      000A83                        627 	.ds 30
      000AA1                        628 _usage_order:
      000AA1                        629 	.ds 30
      000ABF                        630 _usage_lengths:
      000ABF                        631 	.ds 2
      000AC1                        632 _macro_usages:
      000AC1                        633 	.ds 4
      000AC5                        634 _owned_usage_key_PARM_2:
      000AC5                        635 	.ds 1
      000AC6                        636 _owned_usage_key_code_10000_369:
      000AC6                        637 	.ds 1
      000AC7                        638 _owned_usage_key___200000085_20000_370:
      000AC7                        639 	.ds 2
      000AC9                        640 _owned_usage_key_which_10000_370:
      000AC9                        641 	.ds 1
      000ACA                        642 _owned_usage_key_count_10000_370:
      000ACA                        643 	.ds 1
      000ACB                        644 _owned_usage_key_pos_30001_377:
      000ACB                        645 	.ds 1
      000ACC                        646 _owned_usage_key_key_40000_382:
      000ACC                        647 	.ds 1
      000ACD                        648 _send_keyboard_report_last_report_10001_389:
      000ACD                        649 	.ds 32
      000AED                        650 _send_keyboard_report_changed_10001_389:
      000AED                        651 	.ds 1
      000AEE                        652 _add_weak_mods_mods_10000_407:
      000AEE                        653 	.ds 1
      000AEF                        654 _del_weak_mods_mods_10000_409:
      000AEF                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DF6                        664 _real_mods:
      000DF6                        665 	.ds 1
      000DF7                        666 _weak_mods:
      000DF7                        667 	.ds 1
      000DF8                        668 _actual_keyboard_report::
      000DF8                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      0080B6                        713 _ak820_macro_change:
      0080B6 12 3A CD         [24]  714 	lcall	_ak820_outline_0109
      0080B9 90 09 BC         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_294
      0080BC 12 3A D2         [24]  716 	lcall	_ak820_outline_0110
                                    717 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      0080BF 90 09 B8         [24]  718 	mov	dptr,#_ak820_macro_primitive
      0080C2 E0               [24]  719 	movx	a,@dptr
      0080C3 70 04            [24]  720 	jnz	00102$
      0080C5 75 82 01         [24]  721 	mov	dpl, #0x01
      0080C8 22               [24]  722 	ret
      0080C9                        723 00102$:
                                    724 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      0080C9 90 09 BA         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      0080CC E0               [24]  726 	movx	a,@dptr
      0080CD FF               [12]  727 	mov	r7,a
      0080CE 74 07            [12]  728 	mov	a,#0x07
      0080D0 5F               [12]  729 	anl	a,r7
      0080D1 12 7C 43         [24]  730 	lcall	_ak820_outline_0063
      0080D4 80 02            [24]  731 	sjmp	00123$
      0080D6                        732 00122$:
      0080D6 25 E0            [12]  733 	add	a,acc
      0080D8                        734 00123$:
      0080D8 D5 F0 FB         [24]  735 	djnz	b,00122$
      0080DB FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:81: bits += index >> 3;
      0080DC EF               [12]  738 	mov	a,r7
      0080DD 12 5C 10         [24]  739 	lcall	_ak820_outline_0190
      0080E0 FF               [12]  740 	mov	r7,a
      0080E1 90 09 BC         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_294
      0080E4 12 3A A3         [24]  742 	lcall	_ak820_outline_0061
      0080E7 90 09 BC         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_294
      0080EA EF               [12]  744 	mov	a,r7
      0080EB 2C               [12]  745 	add	a, r4
      0080EC F0               [24]  746 	movx	@dptr,a
      0080ED E4               [12]  747 	clr	a
      0080EE 3D               [12]  748 	addc	a, r5
      0080EF A3               [24]  749 	inc	dptr
      0080F0 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      0080F1 90 09 BC         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_294
      0080F4 E0               [24]  753 	movx	a,@dptr
      0080F5 FD               [12]  754 	mov	r5,a
      0080F6 A3               [24]  755 	inc	dptr
      0080F7 E0               [24]  756 	movx	a,@dptr
      0080F8 FF               [12]  757 	mov	r7,a
      0080F9 12 86 41         [24]  758 	lcall	_ak820_outline_0192
      0080FC E0               [24]  759 	movx	a,@dptr
      0080FD FC               [12]  760 	mov	r4,a
      0080FE EE               [12]  761 	mov	a,r6
      0080FF 5C               [12]  762 	anl	a,r4
      008100 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      008103                        764 00124$:
      008103 B3               [12]  765 	cpl	c
      008104 92 21            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      008106 90 09 BB         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      008109 E0               [24]  768 	movx	a,@dptr
      00810A FB               [12]  769 	mov	r3,a
      00810B A2 21            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      00810D E4               [12]  771 	clr	a
      00810E 33               [12]  772 	rlc	a
      00810F B5 03 04         [24]  773 	cjne	a,ar3,00104$
      008112 75 82 00         [24]  774 	mov	dpl, #0x00
      008115 22               [24]  775 	ret
      008116                        776 00104$:
                                    777 ;	quantum/action_util.c:83: *bits ^= mask;
      008116 EC               [12]  778 	mov	a,r4
      008117 62 06            [12]  779 	xrl	ar6,a
      008119 12 86 41         [24]  780 	lcall	_ak820_outline_0192
      00811C EE               [12]  781 	mov	a,r6
      00811D F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:84: return true;
      00811E 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:85: }
      008121 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_299'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_300'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_300'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_300'
                                    795 ;old           Allocated with name '_change_owned_old_30000_302'
                                    796 ;result        Allocated with name '_change_owned_result_10001_303'
                                    797 ;i             Allocated with name '_change_owned_i_20001_304'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_304'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      008122                        805 _change_owned:
      008122 E5 82            [12]  806 	mov	a,dpl
      008124 90 09 BF         [24]  807 	mov	dptr,#_change_owned_mods_10000_299
      008127 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      008128 90 09 BE         [24]  810 	mov	dptr,#_change_owned_PARM_2
      00812B E0               [24]  811 	movx	a,@dptr
      00812C FF               [12]  812 	mov	r7,a
      00812D C3               [12]  813 	clr	c
      00812E 13               [12]  814 	rrc	a
      00812F FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      008130 53 07 01         [24]  817 	anl	ar7,#0x01
      008133 EF               [12]  818 	mov	a,r7
      008134 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      008137                        820 00205$:
      008137 92 22            [24]  821 	mov  _change_owned_sloc0_1_0,c
      008139 B3               [12]  822 	cpl	c
      00813A E4               [12]  823 	clr	a
      00813B 33               [12]  824 	rlc	a
      00813C F5 54            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      00813E EE               [12]  827 	mov	a,r6
      00813F 60 06            [24]  828 	jz	00121$
      008141 7D AC            [12]  829 	mov	r5,#_owned_weak_refs
      008143 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      008145 80 04            [24]  831 	sjmp	00122$
      008147                        832 00121$:
      008147 7D A4            [12]  833 	mov	r5,#_owned_mod_refs
      008149 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      00814B                        835 00122$:
                                    836 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      00814B 90 09 B8         [24]  837 	mov	dptr,#_ak820_macro_primitive
      00814E E0               [24]  838 	movx	a,@dptr
      00814F 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      008151 EE               [12]  841 	mov	a,r6
      008152 24 B6            [12]  842 	add	a, #_macro_mods
      008154 FB               [12]  843 	mov	r3,a
      008155 E4               [12]  844 	clr	a
      008156 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      008158 12 4A C6         [24]  846 	lcall	_ak820_outline_0056
                                    847 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      00815B E5 54            [12]  848 	mov	a,_change_owned_sloc1_1_0
      00815D 60 0A            [24]  849 	jz	00123$
      00815F 90 09 BF         [24]  850 	mov	dptr,#_change_owned_mods_10000_299
      008162 E0               [24]  851 	movx	a,@dptr
      008163 F9               [12]  852 	mov	r1,a
      008164 EA               [12]  853 	mov	a,r2
      008165 42 01            [12]  854 	orl	ar1,a
      008167 80 07            [24]  855 	sjmp	00124$
      008169                        856 00123$:
      008169 90 09 BF         [24]  857 	mov	dptr,#_change_owned_mods_10000_299
      00816C E0               [24]  858 	movx	a,@dptr
      00816D F4               [12]  859 	cpl	a
      00816E 5A               [12]  860 	anl	a,r2
      00816F F9               [12]  861 	mov	r1,a
      008170                        862 00124$:
      008170 12 36 47         [24]  863 	lcall	_ak820_outline_0125
      008173 E9               [12]  864 	mov	a,r1
      008174 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      008175 E5 54            [12]  867 	mov	a,_change_owned_sloc1_1_0
      008177 60 06            [24]  868 	jz	00125$
      008179 74 FF            [12]  869 	mov	a,#0xff
      00817B 6A               [12]  870 	xrl	a,r2
      00817C FC               [12]  871 	mov	r4,a
      00817D 80 02            [24]  872 	sjmp	00126$
      00817F                        873 00125$:
      00817F 8A 04            [24]  874 	mov	ar4,r2
      008181                        875 00126$:
      008181 90 09 BF         [24]  876 	mov	dptr,#_change_owned_mods_10000_299
      008184 E0               [24]  877 	movx	a,@dptr
      008185 5C               [12]  878 	anl	a,r4
      008186 F0               [24]  879 	movx	@dptr,a
      008187                        880 00102$:
                                    881 ;	quantum/action_util.c:95: uint8_t result = 0;
      008187 90 09 C0         [24]  882 	mov	dptr,#_change_owned_result_10001_303
      00818A E4               [12]  883 	clr	a
      00818B F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00818C 90 09 C1         [24]  886 	mov	dptr,#_change_owned_bit_20001_304
      00818F 04               [12]  887 	inc	a
      008190 F0               [24]  888 	movx	@dptr,a
      008191 90 09 BF         [24]  889 	mov	dptr,#_change_owned_mods_10000_299
      008194 E0               [24]  890 	movx	a,@dptr
      008195 FC               [12]  891 	mov	r4,a
      008196 7B 00            [12]  892 	mov	r3,#0x00
      008198                        893 00117$:
      008198 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      00819B                        895 00210$:
      00819B 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:97: if (mods & bit) {
      00819D 90 09 C1         [24]  898 	mov	dptr,#_change_owned_bit_20001_304
      0081A0 E0               [24]  899 	movx	a,@dptr
      0081A1 5C               [12]  900 	anl	a,r4
      0081A2 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      0081A4 E5 54            [12]  903 	mov	a,_change_owned_sloc1_1_0
      0081A6 60 0C            [24]  904 	jz	00106$
      0081A8 EB               [12]  905 	mov	a,r3
      0081A9 2D               [12]  906 	add	a, r5
      0081AA 12 3A 72         [24]  907 	lcall	_ak820_outline_0017
      0081AD F8               [12]  908 	mov	r0,a
      0081AE 08               [12]  909 	inc	r0
      0081AF 12 85 FE         [24]  910 	lcall	_ak820_outline_0064
      0081B2 80 0C            [24]  911 	sjmp	00109$
      0081B4                        912 00106$:
                                    913 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      0081B4 EB               [12]  914 	mov	a,r3
      0081B5 2D               [12]  915 	add	a, r5
      0081B6 12 3A 72         [24]  916 	lcall	_ak820_outline_0017
      0081B9 F8               [12]  917 	mov	r0,a
      0081BA 60 04            [24]  918 	jz	00109$
      0081BC 18               [12]  919 	dec	r0
      0081BD 12 85 FE         [24]  920 	lcall	_ak820_outline_0064
      0081C0                        921 00109$:
                                    922 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      0081C0 EB               [12]  923 	mov	a,r3
      0081C1 2D               [12]  924 	add	a, r5
      0081C2 12 3A 72         [24]  925 	lcall	_ak820_outline_0017
      0081C5 60 0B            [24]  926 	jz	00118$
      0081C7 90 09 C1         [24]  927 	mov	dptr,#_change_owned_bit_20001_304
      0081CA E0               [24]  928 	movx	a,@dptr
      0081CB FA               [12]  929 	mov	r2,a
      0081CC 90 09 C0         [24]  930 	mov	dptr,#_change_owned_result_10001_303
      0081CF E0               [24]  931 	movx	a,@dptr
      0081D0 4A               [12]  932 	orl	a,r2
      0081D1 F0               [24]  933 	movx	@dptr,a
      0081D2                        934 00118$:
                                    935 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0081D2 0B               [12]  936 	inc	r3
      0081D3 90 09 C1         [24]  937 	mov	dptr,#_change_owned_bit_20001_304
      0081D6 E0               [24]  938 	movx	a,@dptr
      0081D7 25 E0            [12]  939 	add	a,acc
      0081D9 F0               [24]  940 	movx	@dptr,a
      0081DA 80 BC            [24]  941 	sjmp	00117$
      0081DC                        942 00112$:
                                    943 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      0081DC EE               [12]  944 	mov	a,r6
      0081DD 60 09            [24]  945 	jz	00114$
      0081DF 90 09 C0         [24]  946 	mov	dptr,#_change_owned_result_10001_303
      0081E2 E0               [24]  947 	movx	a,@dptr
      0081E3 90 09 B5         [24]  948 	mov	dptr,#_owned_weak_mods
      0081E6 F0               [24]  949 	movx	@dptr,a
      0081E7 22               [24]  950 	ret
      0081E8                        951 00114$:
                                    952 ;	quantum/action_util.c:104: else owned_mods = result;
      0081E8 90 09 C0         [24]  953 	mov	dptr,#_change_owned_result_10001_303
      0081EB E0               [24]  954 	movx	a,@dptr
      0081EC 90 09 B4         [24]  955 	mov	dptr,#_owned_mods
      0081EF F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:105: }
      0081F0 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_312'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      0081F1                        968 _add_owned_mods:
      0081F1 E5 82            [12]  969 	mov	a,dpl
      0081F3 90 09 C2         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_312
      0081F6 12 86 1E         [24]  971 	lcall	_ak820_outline_0119
      0081F9 74 01            [12]  972 	mov	a,#0x01
      0081FB F0               [24]  973 	movx	@dptr,a
      0081FC 8F 82            [24]  974 	mov	dpl, r7
      0081FE 02 81 22         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_314'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      008201                        985 _del_owned_mods:
      008201 E5 82            [12]  986 	mov	a,dpl
      008203 90 09 C3         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_314
      008206 12 86 1E         [24]  988 	lcall	_ak820_outline_0119
      008209 12 7C 96         [24]  989 	lcall	_ak820_outline_0191
      00820C 02 81 22         [24]  990 	ljmp	_change_owned
                                    991 ;------------------------------------------------------------
                                    992 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    993 ;------------------------------------------------------------
                                    994 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_316'
                                    995 ;------------------------------------------------------------
                                    996 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    997 ;	-----------------------------------------
                                    998 ;	 function add_owned_weak_mods
                                    999 ;	-----------------------------------------
      00820F                       1000 _add_owned_weak_mods:
      00820F E5 82            [12] 1001 	mov	a,dpl
      008211 90 09 C4         [24] 1002 	mov	dptr,#_add_owned_weak_mods_mods_10000_316
      008214 12 86 1E         [24] 1003 	lcall	_ak820_outline_0119
      008217 74 03            [12] 1004 	mov	a,#0x03
      008219 F0               [24] 1005 	movx	@dptr,a
      00821A 8F 82            [24] 1006 	mov	dpl, r7
      00821C 02 81 22         [24] 1007 	ljmp	_change_owned
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1010 ;------------------------------------------------------------
                                   1011 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_318'
                                   1012 ;------------------------------------------------------------
                                   1013 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1014 ;	-----------------------------------------
                                   1015 ;	 function del_owned_weak_mods
                                   1016 ;	-----------------------------------------
      00821F                       1017 _del_owned_weak_mods:
      00821F E5 82            [12] 1018 	mov	a,dpl
      008221 90 09 C5         [24] 1019 	mov	dptr,#_del_owned_weak_mods_mods_10000_318
      008224 12 86 1E         [24] 1020 	lcall	_ak820_outline_0119
      008227 74 02            [12] 1021 	mov	a,#0x02
      008229 F0               [24] 1022 	movx	@dptr,a
      00822A 8F 82            [24] 1023 	mov	dpl, r7
      00822C 02 81 22         [24] 1024 	ljmp	_change_owned
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1027 ;------------------------------------------------------------
                                   1028 ;i             Allocated with name '_clear_owned_mods_i_20000_322'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function clear_owned_mods
                                   1033 ;	-----------------------------------------
      00822F                       1034 _clear_owned_mods:
                                   1035 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      00822F 7F 00            [12] 1036 	mov	r7,#0x00
      008231                       1037 00103$:
      008231 BF 08 00         [24] 1038 	cjne	r7,#0x08,00122$
      008234                       1039 00122$:
      008234 50 1A            [24] 1040 	jnc	00101$
      008236 EF               [12] 1041 	mov	a,r7
      008237 24 A4            [12] 1042 	add	a, #_owned_mod_refs
      008239 FD               [12] 1043 	mov	r5,a
      00823A E4               [12] 1044 	clr	a
      00823B 34 09            [12] 1045 	addc	a, #(_owned_mod_refs >> 8)
      00823D FE               [12] 1046 	mov	r6,a
      00823E EF               [12] 1047 	mov	a,r7
      00823F 24 AC            [12] 1048 	add	a, #_owned_weak_refs
      008241 F5 82            [12] 1049 	mov	dpl,a
      008243 E4               [12] 1050 	clr	a
      008244 34 09            [12] 1051 	addc	a, #(_owned_weak_refs >> 8)
      008246 F5 83            [12] 1052 	mov	dph,a
      008248 E4               [12] 1053 	clr	a
      008249 F0               [24] 1054 	movx	@dptr,a
      00824A 12 86 25         [24] 1055 	lcall	_ak820_outline_0123
      00824D 0F               [12] 1056 	inc	r7
      00824E 80 E1            [24] 1057 	sjmp	00103$
      008250                       1058 00101$:
                                   1059 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      008250 90 09 B7         [24] 1060 	mov	dptr,#(_macro_mods + 0x0001)
      008253 E4               [12] 1061 	clr	a
      008254 F0               [24] 1062 	movx	@dptr,a
      008255 90 09 B6         [24] 1063 	mov	dptr,#_macro_mods
      008258 F0               [24] 1064 	movx	@dptr,a
      008259 90 09 B5         [24] 1065 	mov	dptr,#_owned_weak_mods
      00825C F0               [24] 1066 	movx	@dptr,a
      00825D 90 09 B4         [24] 1067 	mov	dptr,#_owned_mods
      008260 F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      008261 90 09 B9         [24] 1070 	mov	dptr,#_ak820_macro_cancelled
      008264 04               [12] 1071 	inc	a
      008265 F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	quantum/action_util.c:114: }
      008266 22               [24] 1074 	ret
                                   1075 ;------------------------------------------------------------
                                   1076 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1077 ;------------------------------------------------------------
                                   1078 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1079 ;i             Allocated with name '_clear_owned_keys_i_20000_326'
                                   1080 ;------------------------------------------------------------
                                   1081 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1082 ;	-----------------------------------------
                                   1083 ;	 function clear_owned_keys
                                   1084 ;	-----------------------------------------
      008267                       1085 _clear_owned_keys:
                                   1086 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      008267 7F 00            [12] 1087 	mov	r7,#0x00
      008269                       1088 00104$:
      008269 EF               [12] 1089 	mov	a,r7
      00826A 24 5B            [12] 1090 	add	a,#0xff - 0xa4
      00826C 40 0D            [24] 1091 	jc	00101$
                                   1092 ;	free result
      00826E EF               [12] 1093 	mov	a,r7
      00826F 24 C6            [12] 1094 	add	a, #_key_refs
      008271 F5 82            [12] 1095 	mov	dpl,a
      008273 E4               [12] 1096 	clr	a
      008274 34 09            [12] 1097 	addc	a, #(_key_refs >> 8)
      008276 12 80 A7         [24] 1098 	lcall	_ak820_outline_0168
      008279 80 EE            [24] 1099 	sjmp	00104$
      00827B                       1100 00101$:
                                   1101 ;	quantum/action_util.c:122: distinct_keys = 0;
      00827B 90 0A 6B         [24] 1102 	mov	dptr,#_distinct_keys
      00827E E4               [12] 1103 	clr	a
      00827F F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      008280 FF               [12] 1106 	mov	r7,a
      008281                       1107 00107$:
      008281 BF 15 00         [24] 1108 	cjne	r7,#0x15,00142$
      008284                       1109 00142$:
      008284 50 0D            [24] 1110 	jnc	00109$
      008286 EF               [12] 1111 	mov	a,r7
      008287 24 6C            [12] 1112 	add	a, #_macro_keys
      008289 F5 82            [12] 1113 	mov	dpl,a
      00828B E4               [12] 1114 	clr	a
      00828C 34 0A            [12] 1115 	addc	a, #(_macro_keys >> 8)
      00828E 12 80 A7         [24] 1116 	lcall	_ak820_outline_0168
      008291 80 EE            [24] 1117 	sjmp	00107$
      008293                       1118 00109$:
                                   1119 ;	quantum/action_util.c:124: }
      008293 22               [24] 1120 	ret
                                   1121 ;------------------------------------------------------------
                                   1122 ;Allocation info for local variables in function 'add_owned_key'
                                   1123 ;------------------------------------------------------------
                                   1124 ;code          Allocated with name '_add_owned_key_code_10000_327'
                                   1125 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_336'
                                   1126 ;key           Allocated with name '_add_owned_key_key_50000_337'
                                   1127 ;i             Allocated with name '_add_owned_key_i_40000_335'
                                   1128 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_339'
                                   1129 ;key           Allocated with name '_add_owned_key_key_40000_340'
                                   1130 ;------------------------------------------------------------
                                   1131 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1132 ;	-----------------------------------------
                                   1133 ;	 function add_owned_key
                                   1134 ;	-----------------------------------------
      008294                       1135 _add_owned_key:
      008294 E5 82            [12] 1136 	mov	a,dpl
      008296 90 0A 81         [24] 1137 	mov	dptr,#_add_owned_key_code_10000_327
      008299 12 86 36         [24] 1138 	lcall	_ak820_outline_0134
                                   1139 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      00829C 74 01            [12] 1140 	mov	a,#0x01
      00829E F0               [24] 1141 	movx	@dptr,a
      00829F 90 0A 6C         [24] 1142 	mov	dptr,#_macro_keys
      0082A2 C0 07            [24] 1143 	push	ar7
      0082A4 12 80 B6         [24] 1144 	lcall	_ak820_macro_change
      0082A7 E5 82            [12] 1145 	mov	a, dpl
      0082A9 D0 07            [24] 1146 	pop	ar7
      0082AB 70 03            [24] 1147 	jnz	00102$
      0082AD F5 82            [12] 1148 	mov	dpl,a
      0082AF 22               [24] 1149 	ret
      0082B0                       1150 00102$:
                                   1151 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      0082B0 12 85 E8         [24] 1152 	lcall	_ak820_outline_0030
      0082B3 FC               [12] 1153 	mov	r4,a
      0082B4 04               [12] 1154 	inc	a
      0082B5 12 86 25         [24] 1155 	lcall	_ak820_outline_0123
      0082B8 EC               [12] 1156 	mov	a,r4
      0082B9 60 04            [24] 1157 	jz	00104$
      0082BB 75 82 00         [24] 1158 	mov	dpl, #0x00
      0082BE 22               [24] 1159 	ret
      0082BF                       1160 00104$:
                                   1161 ;	quantum/action_util.c:128: ++distinct_keys;
      0082BF 90 0A 6B         [24] 1162 	mov	dptr,#_distinct_keys
      0082C2 E0               [24] 1163 	movx	a,@dptr
      0082C3 24 01            [12] 1164 	add	a, #0x01
      0082C5 F0               [24] 1165 	movx	@dptr,a
                                   1166 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0082C6 90 0D E5         [24] 1167 	mov	dptr,#_keyboard_protocol
      0082C9 E0               [24] 1168 	movx	a,@dptr
      0082CA 60 15            [24] 1169 	jz	00106$
      0082CC 90 0A F0         [24] 1170 	mov	dptr,#_keymap_config
      0082CF E0               [24] 1171 	movx	a,@dptr
      0082D0 30 E7 0E         [24] 1172 	jnb	acc.7,00106$
                                   1173 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0082D3 90 08 2F         [24] 1174 	mov	dptr,#_add_key_to_report_PARM_2
      0082D6 EF               [12] 1175 	mov	a,r7
      0082D7 12 85 F6         [24] 1176 	lcall	_ak820_outline_0058
      0082DA 12 73 83         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0082DD 75 82 01         [24] 1179 	mov	dpl, #0x01
      0082E0 22               [24] 1180 	ret
      0082E1                       1181 00106$:
                                   1182 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      0082E1 90 0A 6B         [24] 1183 	mov	dptr,#_distinct_keys
      0082E4 E0               [24] 1184 	movx	a,@dptr
      0082E5 24 F9            [12] 1185 	add	a,#0xff - 0x06
      0082E7 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      0082E9 7F 00            [12] 1189 	mov	r7,#0x00
      0082EB                       1190 00115$:
      0082EB BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      0082EE                       1192 00174$:
      0082EE 50 1D            [24] 1193 	jnc	00111$
      0082F0 EF               [12] 1194 	mov	a,r7
      0082F1 24 FA            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      0082F3 F5 82            [12] 1196 	mov	dpl,a
      0082F5 E4               [12] 1197 	clr	a
      0082F6 34 0D            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      0082F8 F5 83            [12] 1199 	mov	dph,a
      0082FA 74 01            [12] 1200 	mov	a,#0x01
      0082FC F0               [24] 1201 	movx	@dptr,a
      0082FD 0F               [12] 1202 	inc	r7
      0082FE 80 EB            [24] 1203 	sjmp	00115$
      008300                       1204 00110$:
                                   1205 ;	quantum/action_util.c:134: } else add_key(code);
      008300 90 0A 81         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_327
      008303 E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008304 90 08 2F         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      008307 12 85 F6         [24] 1210 	lcall	_ak820_outline_0058
      00830A 12 73 83         [24] 1211 	lcall	_add_key_to_report
                                   1212 ;	quantum/action_util.c:134: } else add_key(code);
      00830D                       1213 00111$:
                                   1214 ;	quantum/action_util.c:135: return true;
      00830D 75 82 01         [24] 1215 	mov	dpl, #0x01
                                   1216 ;	quantum/action_util.c:136: }
      008310 22               [24] 1217 	ret
                                   1218 ;------------------------------------------------------------
                                   1219 ;Allocation info for local variables in function 'del_owned_key'
                                   1220 ;------------------------------------------------------------
                                   1221 ;code          Allocated with name '_del_owned_key_code_10000_342'
                                   1222 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_353'
                                   1223 ;key           Allocated with name '_del_owned_key_key_50000_354'
                                   1224 ;key           Allocated with name '_del_owned_key_key_40000_351'
                                   1225 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_359'
                                   1226 ;key           Allocated with name '_del_owned_key_key_70000_360'
                                   1227 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_362'
                                   1228 ;key           Allocated with name '_del_owned_key_key_40000_363'
                                   1229 ;------------------------------------------------------------
                                   1230 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1231 ;	-----------------------------------------
                                   1232 ;	 function del_owned_key
                                   1233 ;	-----------------------------------------
      008311                       1234 _del_owned_key:
      008311 E5 82            [12] 1235 	mov	a,dpl
      008313 90 0A 82         [24] 1236 	mov	dptr,#_del_owned_key_code_10000_342
      008316 12 86 36         [24] 1237 	lcall	_ak820_outline_0134
                                   1238 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      008319 E4               [12] 1239 	clr	a
      00831A F0               [24] 1240 	movx	@dptr,a
      00831B 90 0A 6C         [24] 1241 	mov	dptr,#_macro_keys
      00831E C0 07            [24] 1242 	push	ar7
      008320 12 80 B6         [24] 1243 	lcall	_ak820_macro_change
      008323 E5 82            [12] 1244 	mov	a, dpl
      008325 D0 07            [24] 1245 	pop	ar7
      008327 70 03            [24] 1246 	jnz	00102$
      008329 F5 82            [12] 1247 	mov	dpl,a
      00832B 22               [24] 1248 	ret
      00832C                       1249 00102$:
                                   1250 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      00832C 12 85 E8         [24] 1251 	lcall	_ak820_outline_0030
      00832F FC               [12] 1252 	mov	r4,a
      008330 60 07            [24] 1253 	jz	00103$
      008332 1C               [12] 1254 	dec	r4
      008333 12 45 82         [24] 1255 	lcall	_ak820_outline_0065
      008336 EC               [12] 1256 	mov	a,r4
      008337 60 04            [24] 1257 	jz	00104$
      008339                       1258 00103$:
      008339 75 82 00         [24] 1259 	mov	dpl, #0x00
      00833C 22               [24] 1260 	ret
      00833D                       1261 00104$:
                                   1262 ;	quantum/action_util.c:140: --distinct_keys;
      00833D 90 0A 6B         [24] 1263 	mov	dptr,#_distinct_keys
      008340 E0               [24] 1264 	movx	a,@dptr
      008341 14               [12] 1265 	dec	a
      008342 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008343 90 0D E5         [24] 1268 	mov	dptr,#_keyboard_protocol
      008346 E0               [24] 1269 	movx	a,@dptr
      008347 60 15            [24] 1270 	jz	00107$
      008349 90 0A F0         [24] 1271 	mov	dptr,#_keymap_config
      00834C E0               [24] 1272 	movx	a,@dptr
      00834D 30 E7 0E         [24] 1273 	jnb	acc.7,00107$
                                   1274 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008350 90 08 33         [24] 1275 	mov	dptr,#_del_key_from_report_PARM_2
      008353 EF               [12] 1276 	mov	a,r7
      008354 12 85 F6         [24] 1277 	lcall	_ak820_outline_0058
      008357 12 73 C1         [24] 1278 	lcall	_del_key_from_report
                                   1279 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      00835A 75 82 01         [24] 1280 	mov	dpl, #0x01
      00835D 22               [24] 1281 	ret
      00835E                       1282 00107$:
                                   1283 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      00835E 90 0A 6B         [24] 1284 	mov	dptr,#_distinct_keys
      008361 E0               [24] 1285 	movx	a,@dptr
      008362 FF               [12] 1286 	mov  r7,a
      008363 24 F9            [12] 1287 	add	a,#0xff - 0x06
      008365 50 04            [24] 1288 	jnc	00110$
                                   1289 ;	free result
      008367 75 82 01         [24] 1290 	mov	dpl, #0x01
      00836A 22               [24] 1291 	ret
      00836B                       1292 00110$:
                                   1293 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      00836B BF 06 26         [24] 1294 	cjne	r7,#0x06,00115$
                                   1295 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00836E 90 0D F8         [24] 1296 	mov	dptr,#_actual_keyboard_report
      008371 75 F0 00         [24] 1297 	mov	b, #0x00
      008374 12 73 FF         [24] 1298 	lcall	_clear_keys_from_report
                                   1299 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008377 7F 04            [12] 1300 	mov	r7,#0x04
      008379                       1301 00122$:
      008379 EF               [12] 1302 	mov	a,r7
      00837A 24 5B            [12] 1303 	add	a,#0xff - 0xa4
      00837C 40 23            [24] 1304 	jc	00116$
                                   1305 ;	free result
      00837E 12 85 E8         [24] 1306 	lcall	_ak820_outline_0030
      008381 60 0E            [24] 1307 	jz	00123$
                                   1308 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008383 90 08 2F         [24] 1309 	mov	dptr,#_add_key_to_report_PARM_2
      008386 EF               [12] 1310 	mov	a,r7
      008387 12 85 F6         [24] 1311 	lcall	_ak820_outline_0058
      00838A C0 07            [24] 1312 	push	ar7
      00838C 12 73 83         [24] 1313 	lcall	_add_key_to_report
      00838F D0 07            [24] 1314 	pop	ar7
                                   1315 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008391                       1316 00123$:
      008391 0F               [12] 1317 	inc	r7
      008392 80 E5            [24] 1318 	sjmp	00122$
      008394                       1319 00115$:
                                   1320 ;	quantum/action_util.c:149: } else del_key(code);
      008394 90 0A 82         [24] 1321 	mov	dptr,#_del_owned_key_code_10000_342
      008397 E0               [24] 1322 	movx	a,@dptr
                                   1323 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008398 90 08 33         [24] 1324 	mov	dptr,#_del_key_from_report_PARM_2
      00839B 12 85 F6         [24] 1325 	lcall	_ak820_outline_0058
      00839E 12 73 C1         [24] 1326 	lcall	_del_key_from_report
                                   1327 ;	quantum/action_util.c:149: } else del_key(code);
      0083A1                       1328 00116$:
                                   1329 ;	quantum/action_util.c:150: return true;
      0083A1 75 82 01         [24] 1330 	mov	dpl, #0x01
                                   1331 ;	quantum/action_util.c:151: }
      0083A4 22               [24] 1332 	ret
                                   1333 ;------------------------------------------------------------
                                   1334 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1335 ;------------------------------------------------------------
                                   1336 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1337 ;i             Allocated with name '_clear_owned_usages_i_20000_368'
                                   1338 ;------------------------------------------------------------
                                   1339 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function clear_owned_usages
                                   1342 ;	-----------------------------------------
      0083A5                       1343 _clear_owned_usages:
                                   1344 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      0083A5 7F 00            [12] 1345 	mov	r7,#0x00
      0083A7                       1346 00104$:
      0083A7 BF 1E 00         [24] 1347 	cjne	r7,#0x1e,00141$
      0083AA                       1348 00141$:
      0083AA 50 14            [24] 1349 	jnc	00101$
      0083AC EF               [12] 1350 	mov	a,r7
      0083AD 24 83            [12] 1351 	add	a, #_usage_refs
      0083AF FD               [12] 1352 	mov	r5,a
      0083B0 E4               [12] 1353 	clr	a
      0083B1 34 0A            [12] 1354 	addc	a, #(_usage_refs >> 8)
      0083B3 FE               [12] 1355 	mov	r6,a
      0083B4 EF               [12] 1356 	mov	a,r7
      0083B5 12 86 05         [24] 1357 	lcall	_ak820_outline_0068
      0083B8 E4               [12] 1358 	clr	a
      0083B9 F0               [24] 1359 	movx	@dptr,a
      0083BA 12 86 25         [24] 1360 	lcall	_ak820_outline_0123
      0083BD 0F               [12] 1361 	inc	r7
      0083BE 80 E7            [24] 1362 	sjmp	00104$
      0083C0                       1363 00101$:
                                   1364 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      0083C0 90 0A C0         [24] 1365 	mov	dptr,#(_usage_lengths + 0x0001)
      0083C3 E4               [12] 1366 	clr	a
      0083C4 F0               [24] 1367 	movx	@dptr,a
      0083C5 90 0A BF         [24] 1368 	mov	dptr,#_usage_lengths
      0083C8 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      0083C9 FF               [12] 1371 	mov	r7,a
      0083CA                       1372 00107$:
      0083CA BF 04 00         [24] 1373 	cjne	r7,#0x04,00143$
      0083CD                       1374 00143$:
      0083CD 50 0D            [24] 1375 	jnc	00109$
      0083CF EF               [12] 1376 	mov	a,r7
      0083D0 24 C1            [12] 1377 	add	a, #_macro_usages
      0083D2 F5 82            [12] 1378 	mov	dpl,a
      0083D4 E4               [12] 1379 	clr	a
      0083D5 34 0A            [12] 1380 	addc	a, #(_macro_usages >> 8)
      0083D7 12 80 A7         [24] 1381 	lcall	_ak820_outline_0168
      0083DA 80 EE            [24] 1382 	sjmp	00107$
      0083DC                       1383 00109$:
                                   1384 ;	quantum/action_util.c:165: }
      0083DC 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'owned_usage_key'
                                   1388 ;------------------------------------------------------------
                                   1389 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1390 ;code          Allocated with name '_owned_usage_key_code_10000_369'
                                   1391 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_370'
                                   1392 ;which         Allocated with name '_owned_usage_key_which_10000_370'
                                   1393 ;base          Allocated with name '_owned_usage_key_base_10000_370'
                                   1394 ;count         Allocated with name '_owned_usage_key_count_10000_370'
                                   1395 ;index         Allocated with name '_owned_usage_key_index_10000_370'
                                   1396 ;pos           Allocated with name '_owned_usage_key_pos_30001_377'
                                   1397 ;i             Allocated with name '_owned_usage_key_i_40001_378'
                                   1398 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_381'
                                   1399 ;key           Allocated with name '_owned_usage_key_key_40000_382'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function owned_usage_key
                                   1404 ;	-----------------------------------------
      0083DD                       1405 _owned_usage_key:
      0083DD E5 82            [12] 1406 	mov	a,dpl
      0083DF 90 0A C6         [24] 1407 	mov	dptr,#_owned_usage_key_code_10000_369
      0083E2 F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      0083E3 E0               [24] 1410 	movx	a,@dptr
      0083E4 FF               [12] 1411 	mov	r7,a
      0083E5 BF A8 00         [24] 1412 	cjne	r7,#0xa8,00244$
      0083E8                       1413 00244$:
      0083E8 B3               [12] 1414 	cpl	c
      0083E9 92 23            [24] 1415 	mov	_owned_usage_key_sloc0_1_0,c
      0083EB E4               [12] 1416 	clr	a
      0083EC 33               [12] 1417 	rlc	a
      0083ED FF               [12] 1418 	mov	r7,a
      0083EE 90 0A C9         [24] 1419 	mov	dptr,#_owned_usage_key_which_10000_370
      0083F1 F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      0083F2 EF               [12] 1422 	mov	a,r7
      0083F3 60 02            [24] 1423 	jz	00129$
      0083F5 74 03            [12] 1424 	mov	a,#0x03
      0083F7                       1425 00129$:
      0083F7 FE               [12] 1426 	mov	r6,a
                                   1427 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      0083F8 EF               [12] 1428 	mov	a,r7
      0083F9 24 BF            [12] 1429 	add	a, #_usage_lengths
      0083FB FD               [12] 1430 	mov	r5,a
      0083FC E4               [12] 1431 	clr	a
      0083FD 34 0A            [12] 1432 	addc	a, #(_usage_lengths >> 8)
      0083FF FF               [12] 1433 	mov	r7,a
      008400 12 86 41         [24] 1434 	lcall	_ak820_outline_0192
      008403 E0               [24] 1435 	movx	a,@dptr
      008404 FC               [12] 1436 	mov	r4,a
                                   1437 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      008405 90 0A C6         [24] 1438 	mov	dptr,#_owned_usage_key_code_10000_369
      008408 E0               [24] 1439 	movx	a,@dptr
      008409 24 5B            [12] 1440 	add	a,#0x5b
      00840B FB               [12] 1441 	mov	r3,a
                                   1442 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      00840C 90 0A C5         [24] 1443 	mov	dptr,#_owned_usage_key_PARM_2
      00840F E0               [24] 1444 	movx	a,@dptr
      008410 FA               [12] 1445 	mov	r2,a
      008411 90 09 BA         [24] 1446 	mov	dptr,#_ak820_macro_change_PARM_2
      008414 EB               [12] 1447 	mov	a,r3
      008415 F0               [24] 1448 	movx	@dptr,a
      008416 90 09 BB         [24] 1449 	mov	dptr,#_ak820_macro_change_PARM_3
      008419 EA               [12] 1450 	mov	a,r2
      00841A F0               [24] 1451 	movx	@dptr,a
      00841B 90 0A C1         [24] 1452 	mov	dptr,#_macro_usages
      00841E C0 07            [24] 1453 	push	ar7
      008420 C0 06            [24] 1454 	push	ar6
      008422 C0 05            [24] 1455 	push	ar5
      008424 C0 04            [24] 1456 	push	ar4
      008426 C0 03            [24] 1457 	push	ar3
      008428 C0 02            [24] 1458 	push	ar2
      00842A 12 80 B6         [24] 1459 	lcall	_ak820_macro_change
      00842D E5 82            [12] 1460 	mov	a, dpl
      00842F D0 02            [24] 1461 	pop	ar2
      008431 D0 03            [24] 1462 	pop	ar3
      008433 D0 04            [24] 1463 	pop	ar4
      008435 D0 05            [24] 1464 	pop	ar5
      008437 D0 06            [24] 1465 	pop	ar6
      008439 D0 07            [24] 1466 	pop	ar7
      00843B 70 01            [24] 1467 	jnz	00102$
      00843D 22               [24] 1468 	ret
      00843E                       1469 00102$:
                                   1470 ;	quantum/action_util.c:172: if (pressed) {
      00843E EA               [12] 1471 	mov	a,r2
      00843F 60 1B            [24] 1472 	jz	00115$
                                   1473 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      008441 12 86 0F         [24] 1474 	lcall	_ak820_outline_0075
      008444 04               [12] 1475 	inc	a
      008445 12 71 00         [24] 1476 	lcall	_ak820_outline_0141
      008448 E8               [12] 1477 	mov	a,r0
      008449 60 01            [24] 1478 	jz	00104$
      00844B 22               [24] 1479 	ret
      00844C                       1480 00104$:
                                   1481 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      00844C 90 0A CA         [24] 1482 	mov	dptr,#_owned_usage_key_count_10000_370
      00844F EC               [12] 1483 	mov	a,r4
      008450 04               [12] 1484 	inc	a
      008451 F0               [24] 1485 	movx	@dptr,a
      008452 EC               [12] 1486 	mov	a,r4
      008453 2E               [12] 1487 	add	a, r6
      008454 12 86 05         [24] 1488 	lcall	_ak820_outline_0068
      008457 EB               [12] 1489 	mov	a,r3
      008458 F0               [24] 1490 	movx	@dptr,a
      008459 02 84 BD         [24] 1491 	ljmp	00116$
      00845C                       1492 00115$:
                                   1493 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      00845C 12 86 0F         [24] 1494 	lcall	_ak820_outline_0075
      00845F 60 07            [24] 1495 	jz	00105$
      008461 18               [12] 1496 	dec	r0
      008462 12 85 FE         [24] 1497 	lcall	_ak820_outline_0064
      008465 E8               [12] 1498 	mov	a,r0
      008466 60 01            [24] 1499 	jz	00106$
      008468                       1500 00105$:
      008468 22               [24] 1501 	ret
      008469                       1502 00106$:
                                   1503 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      008469 7A 00            [12] 1504 	mov	r2,#0x00
      00846B                       1505 00108$:
      00846B EA               [12] 1506 	mov	a,r2
      00846C 2E               [12] 1507 	add	a, r6
      00846D 12 86 05         [24] 1508 	lcall	_ak820_outline_0068
      008470 E0               [24] 1509 	movx	a,@dptr
      008471 B5 03 02         [24] 1510 	cjne	a,ar3,00251$
      008474 80 03            [24] 1511 	sjmp	00167$
      008476                       1512 00251$:
      008476 0A               [12] 1513 	inc	r2
      008477 80 F2            [24] 1514 	sjmp	00108$
      008479                       1515 00167$:
      008479 90 0A CB         [24] 1516 	mov	dptr,#_owned_usage_key_pos_30001_377
      00847C EA               [12] 1517 	mov	a,r2
      00847D F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	quantum/action_util.c:179: --count;
      00847E 1C               [12] 1520 	dec	r4
      00847F 90 0A CA         [24] 1521 	mov	dptr,#_owned_usage_key_count_10000_370
      008482 EC               [12] 1522 	mov	a,r4
      008483 F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      008484 8A 03            [24] 1525 	mov	ar3,r2
      008486                       1526 00125$:
      008486 C3               [12] 1527 	clr	c
      008487 EB               [12] 1528 	mov	a,r3
      008488 9C               [12] 1529 	subb	a,r4
      008489 50 23            [24] 1530 	jnc	00111$
      00848B C0 05            [24] 1531 	push	ar5
      00848D C0 07            [24] 1532 	push	ar7
      00848F EB               [12] 1533 	mov	a,r3
      008490 2E               [12] 1534 	add	a, r6
      008491 FA               [12] 1535 	mov	r2,a
      008492 24 A1            [12] 1536 	add	a, #_usage_order
      008494 F8               [12] 1537 	mov	r0,a
      008495 E4               [12] 1538 	clr	a
      008496 34 0A            [12] 1539 	addc	a, #(_usage_order >> 8)
      008498 F9               [12] 1540 	mov	r1,a
      008499 0A               [12] 1541 	inc	r2
      00849A EA               [12] 1542 	mov	a,r2
      00849B 33               [12] 1543 	rlc	a
      00849C 95 E0            [12] 1544 	subb	a,acc
      00849E FF               [12] 1545 	mov	r7,a
      00849F EA               [12] 1546 	mov	a,r2
      0084A0 12 86 2B         [24] 1547 	lcall	_ak820_outline_0127
      0084A3 12 3B 01         [24] 1548 	lcall	_ak820_outline_0163
      0084A6 F0               [24] 1549 	movx	@dptr,a
      0084A7 0B               [12] 1550 	inc	r3
      0084A8 D0 07            [24] 1551 	pop	ar7
      0084AA D0 05            [24] 1552 	pop	ar5
      0084AC 80 D8            [24] 1553 	sjmp	00125$
      0084AE                       1554 00111$:
                                   1555 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      0084AE 12 86 41         [24] 1556 	lcall	_ak820_outline_0192
      0084B1 EC               [12] 1557 	mov	a,r4
      0084B2 F0               [24] 1558 	movx	@dptr,a
                                   1559 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      0084B3 90 0A CB         [24] 1560 	mov	dptr,#_owned_usage_key_pos_30001_377
      0084B6 E0               [24] 1561 	movx	a,@dptr
      0084B7 B5 04 02         [24] 1562 	cjne	a,ar4,00253$
      0084BA 80 01            [24] 1563 	sjmp	00116$
      0084BC                       1564 00253$:
      0084BC 22               [24] 1565 	ret
      0084BD                       1566 00116$:
                                   1567 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      0084BD 90 0A CA         [24] 1568 	mov	dptr,#_owned_usage_key_count_10000_370
      0084C0 E0               [24] 1569 	movx	a,@dptr
      0084C1 FC               [12] 1570 	mov	r4,a
      0084C2 12 86 41         [24] 1571 	lcall	_ak820_outline_0192
      0084C5 F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0084C6 EC               [12] 1574 	mov	a,r4
      0084C7 60 15            [24] 1575 	jz	00131$
      0084C9 EC               [12] 1576 	mov	a,r4
      0084CA 2E               [12] 1577 	add	a, r6
      0084CB FE               [12] 1578 	mov	r6,a
      0084CC 1E               [12] 1579 	dec	r6
      0084CD EE               [12] 1580 	mov	a,r6
      0084CE 33               [12] 1581 	rlc	a
      0084CF 95 E0            [12] 1582 	subb	a,acc
      0084D1 FF               [12] 1583 	mov	r7,a
      0084D2 EE               [12] 1584 	mov	a,r6
      0084D3 12 86 2B         [24] 1585 	lcall	_ak820_outline_0127
      0084D6 24 A5            [12] 1586 	add	a,#0xa5
      0084D8 FE               [12] 1587 	mov	r6,a
      0084D9 33               [12] 1588 	rlc	a
      0084DA 95 E0            [12] 1589 	subb	a,acc
      0084DC 80 02            [24] 1590 	sjmp	00132$
      0084DE                       1591 00131$:
      0084DE 7E 00            [12] 1592 	mov	r6,#0x00
      0084E0                       1593 00132$:
      0084E0 90 0A C6         [24] 1594 	mov	dptr,#_owned_usage_key_code_10000_369
      0084E3 EE               [12] 1595 	mov	a,r6
      0084E4 F0               [24] 1596 	movx	@dptr,a
                                   1597 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0084E5 90 0A C9         [24] 1598 	mov	dptr,#_owned_usage_key_which_10000_370
      0084E8 E0               [24] 1599 	movx	a,@dptr
      0084E9 60 18            [24] 1600 	jz	00118$
      0084EB EE               [12] 1601 	mov	a,r6
      0084EC 60 0B            [24] 1602 	jz	00133$
      0084EE 8E 82            [24] 1603 	mov	dpl, r6
      0084F0 12 72 40         [24] 1604 	lcall	_KEYCODE2CONSUMER
      0084F3 AD 82            [24] 1605 	mov	r5, dpl
      0084F5 AF 83            [24] 1606 	mov	r7, dph
      0084F7 80 04            [24] 1607 	sjmp	00134$
      0084F9                       1608 00133$:
      0084F9 7D 00            [12] 1609 	mov	r5,#0x00
      0084FB 7F 00            [12] 1610 	mov	r7,#0x00
      0084FD                       1611 00134$:
      0084FD 12 86 41         [24] 1612 	lcall	_ak820_outline_0192
      008500 02 71 F3         [24] 1613 	ljmp	_host_consumer_send
      008503                       1614 00118$:
                                   1615 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008503 EE               [12] 1616 	mov	a,r6
      008504 60 22            [24] 1617 	jz	00135$
                                   1618 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008506 BE A5 00         [24] 1619 	cjne	r6,#0xa5,00258$
      008509                       1620 00258$:
      008509 40 05            [24] 1621 	jc	00121$
      00850B EE               [12] 1622 	mov	a,r6
      00850C 24 58            [12] 1623 	add	a,#0xff - 0xa7
      00850E 50 08            [24] 1624 	jnc	00122$
                                   1625 ;	free result
      008510                       1626 00121$:
      008510 90 0A C7         [24] 1627 	mov	dptr,#_owned_usage_key___200000085_20000_370
      008513 12 51 B2         [24] 1628 	lcall	_ak820_outline_0184
      008516 80 09            [24] 1629 	sjmp	00123$
      008518                       1630 00122$:
                                   1631 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008518 74 DC            [12] 1632 	mov	a,#0xdc
      00851A 2E               [12] 1633 	add	a, r6
      00851B 90 0A C7         [24] 1634 	mov	dptr,#_owned_usage_key___200000085_20000_370
      00851E 12 3A E7         [24] 1635 	lcall	_ak820_outline_0136
                                   1636 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008521                       1637 00123$:
      008521 90 0A C7         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_370
      008524 E0               [24] 1639 	movx	a,@dptr
      008525 FF               [12] 1640 	mov	r7,a
      008526 80 02            [24] 1641 	sjmp	00136$
      008528                       1642 00135$:
      008528 7F 00            [12] 1643 	mov	r7,#0x00
      00852A                       1644 00136$:
      00852A 7E 00            [12] 1645 	mov	r6,#0x00
      00852C 12 45 BD         [24] 1646 	lcall	_ak820_outline_0164
                                   1647 ;	quantum/action_util.c:188: }
      00852F 02 71 C3         [24] 1648 	ljmp	_host_system_send
                                   1649 ;------------------------------------------------------------
                                   1650 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1651 ;------------------------------------------------------------
                                   1652 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_389'
                                   1653 ;changed       Allocated with name '_send_keyboard_report_changed_10001_389'
                                   1654 ;dest          Allocated with name '_send_keyboard_report_dest_10001_389'
                                   1655 ;src           Allocated with name '_send_keyboard_report_src_10001_389'
                                   1656 ;i             Allocated with name '_send_keyboard_report_i_20001_390'
                                   1657 ;------------------------------------------------------------
                                   1658 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1659 ;	-----------------------------------------
                                   1660 ;	 function send_keyboard_report
                                   1661 ;	-----------------------------------------
      008532                       1662 _send_keyboard_report:
                                   1663 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      008532 90 0D F6         [24] 1664 	mov	dptr,#_real_mods
      008535 E0               [24] 1665 	movx	a,@dptr
      008536 FF               [12] 1666 	mov	r7,a
      008537 90 0D F8         [24] 1667 	mov	dptr,#_actual_keyboard_report
      00853A F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      00853B 90 0D F7         [24] 1670 	mov	dptr,#_weak_mods
      00853E E0               [24] 1671 	movx	a,@dptr
      00853F 42 07            [12] 1672 	orl	ar7,a
      008541 90 0D F8         [24] 1673 	mov	dptr,#_actual_keyboard_report
      008544 EF               [12] 1674 	mov	a,r7
      008545 F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008546 90 09 B5         [24] 1677 	mov	dptr,#_owned_weak_mods
      008549 E0               [24] 1678 	movx	a,@dptr
      00854A FE               [12] 1679 	mov	r6,a
      00854B 90 09 B4         [24] 1680 	mov	dptr,#_owned_mods
      00854E E0               [24] 1681 	movx	a,@dptr
      00854F 4E               [12] 1682 	orl	a,r6
      008550 42 07            [12] 1683 	orl	ar7,a
      008552 90 0D F8         [24] 1684 	mov	dptr,#_actual_keyboard_report
      008555 EF               [12] 1685 	mov	a,r7
      008556 F0               [24] 1686 	movx	@dptr,a
                                   1687 ;	quantum/action_util.c:455: bool changed = false;
      008557 90 0A ED         [24] 1688 	mov	dptr,#_send_keyboard_report_changed_10001_389
      00855A E4               [12] 1689 	clr	a
      00855B F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1692 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1693 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      00855C FF               [12] 1694 	mov	r7,a
      00855D                       1695 00107$:
      00855D BF 20 00         [24] 1696 	cjne	r7,#0x20,00140$
      008560                       1697 00140$:
      008560 50 2B            [24] 1698 	jnc	00103$
                                   1699 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      008562 EF               [12] 1700 	mov	a,r7
      008563 24 CD            [12] 1701 	add	a, #_send_keyboard_report_last_report_10001_389
      008565 FD               [12] 1702 	mov	r5,a
      008566 E4               [12] 1703 	clr	a
      008567 34 0A            [12] 1704 	addc	a, #(_send_keyboard_report_last_report_10001_389 >> 8)
      008569 FE               [12] 1705 	mov	r6,a
      00856A 12 4A DB         [24] 1706 	lcall	_ak820_outline_0077
      00856D EF               [12] 1707 	mov	a,r7
      00856E 24 F8            [12] 1708 	add	a, #_actual_keyboard_report
      008570 F5 82            [12] 1709 	mov	dpl,a
      008572 E4               [12] 1710 	clr	a
      008573 34 0D            [12] 1711 	addc	a, #(_actual_keyboard_report >> 8)
      008575 F5 83            [12] 1712 	mov	dph,a
      008577 E0               [24] 1713 	movx	a,@dptr
      008578 FB               [12] 1714 	mov	r3,a
      008579 EC               [12] 1715 	mov	a,r4
      00857A B5 03 02         [24] 1716 	cjne	a,ar3,00142$
      00857D 80 0B            [24] 1717 	sjmp	00108$
      00857F                       1718 00142$:
                                   1719 ;	quantum/action_util.c:465: dest[i] = src[i];
      00857F 12 3A EC         [24] 1720 	lcall	_ak820_outline_0137
      008582 EB               [12] 1721 	mov	a,r3
      008583 F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:466: changed = true;
      008584 90 0A ED         [24] 1724 	mov	dptr,#_send_keyboard_report_changed_10001_389
      008587 74 01            [12] 1725 	mov	a,#0x01
      008589 F0               [24] 1726 	movx	@dptr,a
      00858A                       1727 00108$:
                                   1728 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      00858A 0F               [12] 1729 	inc	r7
      00858B 80 D0            [24] 1730 	sjmp	00107$
      00858D                       1731 00103$:
                                   1732 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      00858D 90 0A ED         [24] 1733 	mov	dptr,#_send_keyboard_report_changed_10001_389
      008590 E0               [24] 1734 	movx	a,@dptr
      008591 60 09            [24] 1735 	jz	00109$
      008593 90 0D F8         [24] 1736 	mov	dptr,#_actual_keyboard_report
      008596 75 F0 00         [24] 1737 	mov	b, #0x00
                                   1738 ;	quantum/action_util.c:477: }
      008599 02 71 38         [24] 1739 	ljmp	_host_keyboard_send
      00859C                       1740 00109$:
      00859C 22               [24] 1741 	ret
                                   1742 ;------------------------------------------------------------
                                   1743 ;Allocation info for local variables in function 'get_mods'
                                   1744 ;------------------------------------------------------------
                                   1745 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function get_mods
                                   1748 ;	-----------------------------------------
      00859D                       1749 _get_mods:
      00859D C0 07            [24] 1750 	push	ar7
                                   1751 ;	quantum/action_util.c:488: ;
      00859F 90 09 B4         [24] 1752 	mov	dptr,#_owned_mods
      0085A2 E0               [24] 1753 	movx	a,@dptr
      0085A3 FF               [12] 1754 	mov	r7,a
      0085A4 90 0D F6         [24] 1755 	mov	dptr,#_real_mods
      0085A7 12 80 A1         [24] 1756 	lcall	_ak820_outline_0145
                                   1757 ;	quantum/action_util.c:489: }
      0085AA D0 07            [24] 1758 	pop	ar7
      0085AC 22               [24] 1759 	ret
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'add_mods'
                                   1762 ;------------------------------------------------------------
                                   1763 ;mods          Allocated with name '_add_mods_mods_10000_397'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function clear_mods
                                   1768 ;	-----------------------------------------
      0085AD                       1769 _clear_mods:
                                   1770 ;	quantum/action_util.c:516: real_mods = 0;
      0085AD 90 0D F6         [24] 1771 	mov	dptr,#_real_mods
      0085B0 E4               [12] 1772 	clr	a
      0085B1 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action_util.c:517: }
      0085B2 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'get_weak_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1780 ;	-----------------------------------------
                                   1781 ;	 function get_weak_mods
                                   1782 ;	-----------------------------------------
      0085B3                       1783 _get_weak_mods:
      0085B3 C0 07            [24] 1784 	push	ar7
                                   1785 ;	quantum/action_util.c:528: ;
      0085B5 90 09 B5         [24] 1786 	mov	dptr,#_owned_weak_mods
      0085B8 E0               [24] 1787 	movx	a,@dptr
      0085B9 FF               [12] 1788 	mov	r7,a
      0085BA 90 0D F7         [24] 1789 	mov	dptr,#_weak_mods
      0085BD 12 80 A1         [24] 1790 	lcall	_ak820_outline_0145
                                   1791 ;	quantum/action_util.c:529: }
      0085C0 D0 07            [24] 1792 	pop	ar7
      0085C2 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'add_weak_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_add_weak_mods_mods_10000_407'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function add_weak_mods
                                   1802 ;	-----------------------------------------
      0085C3                       1803 _add_weak_mods:
      0085C3 E5 82            [12] 1804 	mov	a,dpl
      0085C5 90 0A EE         [24] 1805 	mov	dptr,#_add_weak_mods_mods_10000_407
      0085C8 F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action_util.c:535: weak_mods |= mods;
      0085C9 E0               [24] 1808 	movx	a,@dptr
      0085CA FF               [12] 1809 	mov	r7,a
      0085CB 90 0D F7         [24] 1810 	mov	dptr,#_weak_mods
      0085CE E0               [24] 1811 	movx	a,@dptr
      0085CF 4F               [12] 1812 	orl	a,r7
      0085D0 F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:536: }
      0085D1 22               [24] 1815 	ret
                                   1816 ;------------------------------------------------------------
                                   1817 ;Allocation info for local variables in function 'del_weak_mods'
                                   1818 ;------------------------------------------------------------
                                   1819 ;mods          Allocated with name '_del_weak_mods_mods_10000_409'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function del_weak_mods
                                   1824 ;	-----------------------------------------
      0085D2                       1825 _del_weak_mods:
      0085D2 E5 82            [12] 1826 	mov	a,dpl
      0085D4 90 0A EF         [24] 1827 	mov	dptr,#_del_weak_mods_mods_10000_409
      0085D7 F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      0085D8 E0               [24] 1830 	movx	a,@dptr
      0085D9 F4               [12] 1831 	cpl	a
      0085DA FF               [12] 1832 	mov	r7,a
      0085DB 90 0D F7         [24] 1833 	mov	dptr,#_weak_mods
      0085DE E0               [24] 1834 	movx	a,@dptr
      0085DF 5F               [12] 1835 	anl	a,r7
      0085E0 F0               [24] 1836 	movx	@dptr,a
                                   1837 ;	quantum/action_util.c:543: }
      0085E1 22               [24] 1838 	ret
                                   1839 ;------------------------------------------------------------
                                   1840 ;Allocation info for local variables in function 'set_weak_mods'
                                   1841 ;------------------------------------------------------------
                                   1842 ;mods          Allocated with name '_set_weak_mods_mods_10000_411'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function clear_weak_mods
                                   1847 ;	-----------------------------------------
      0085E2                       1848 _clear_weak_mods:
                                   1849 ;	quantum/action_util.c:556: weak_mods = 0;
      0085E2 90 0D F7         [24] 1850 	mov	dptr,#_weak_mods
      0085E5 E4               [12] 1851 	clr	a
      0085E6 F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action_util.c:557: }
      0085E7 22               [24] 1854 	ret
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1857 ;------------------------------------------------------------
                                   1858 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_415'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1861 ;	-----------------------------------------
                                   1862 	.area CSEG    (CODE)
                                   1863 	.area CONST   (CODE)
                                   1864 	.area XINIT   (CODE)
      00C637                       1865 __xinit__real_mods:
      00C637 00                    1866 	.db #0x00	; 0
      00C638                       1867 __xinit__weak_mods:
      00C638 00                    1868 	.db #0x00	; 0
      00C639                       1869 __xinit__actual_keyboard_report:
      00C639 00                    1870 	.db #0x00	; 0
      00C63A 00                    1871 	.db #0x00	; 0
      00C63B 00                    1872 	.db #0x00	; 0
      00C63C 00                    1873 	.db #0x00	; 0
      00C63D 00                    1874 	.db #0x00	; 0
      00C63E 00                    1875 	.db #0x00	; 0
      00C63F 00                    1876 	.db #0x00	; 0
      00C640 00                    1877 	.db #0x00	; 0
      00C641 00                    1878 	.db 0x00
      00C642 00                    1879 	.db 0x00
      00C643 00                    1880 	.db 0x00
      00C644 00                    1881 	.db 0x00
      00C645 00                    1882 	.db 0x00
      00C646 00                    1883 	.db 0x00
      00C647 00                    1884 	.db 0x00
      00C648 00                    1885 	.db 0x00
      00C649 00                    1886 	.db 0x00
      00C64A 00                    1887 	.db 0x00
      00C64B 00                    1888 	.db 0x00
      00C64C 00                    1889 	.db 0x00
      00C64D 00                    1890 	.db 0x00
      00C64E 00                    1891 	.db 0x00
      00C64F 00                    1892 	.db 0x00
      00C650 00                    1893 	.db 0x00
      00C651 00                    1894 	.db 0x00
      00C652 00                    1895 	.db 0x00
      00C653 00                    1896 	.db 0x00
      00C654 00                    1897 	.db 0x00
      00C655 00                    1898 	.db 0x00
      00C656 00                    1899 	.db 0x00
      00C657 00                    1900 	.db 0x00
      00C658 00                    1901 	.db 0x00
                                   1902 	.area CABS    (ABS,CODE)
                                   1903 
                                   1904 ; Experimental exact instruction outlining.
                                   1905 	.globl _ak820_outline_0017
                                   1906 	.globl _ak820_outline_0030
                                   1907 	.globl _ak820_outline_0056
                                   1908 	.globl _ak820_outline_0058
                                   1909 	.globl _ak820_outline_0061
                                   1910 	.globl _ak820_outline_0063
                                   1911 	.globl _ak820_outline_0064
                                   1912 	.globl _ak820_outline_0065
                                   1913 	.globl _ak820_outline_0068
                                   1914 	.globl _ak820_outline_0075
                                   1915 	.globl _ak820_outline_0077
                                   1916 	.globl _ak820_outline_0109
                                   1917 	.globl _ak820_outline_0110
                                   1918 	.globl _ak820_outline_0119
                                   1919 	.globl _ak820_outline_0123
                                   1920 	.globl _ak820_outline_0125
                                   1921 	.globl _ak820_outline_0127
                                   1922 	.globl _ak820_outline_0134
                                   1923 	.globl _ak820_outline_0136
                                   1924 	.globl _ak820_outline_0137
                                   1925 	.globl _ak820_outline_0141
                                   1926 	.globl _ak820_outline_0145
                                   1927 	.globl _ak820_outline_0163
                                   1928 	.globl _ak820_outline_0164
                                   1929 	.globl _ak820_outline_0168
                                   1930 	.globl _ak820_outline_0184
                                   1931 	.globl _ak820_outline_0190
                                   1932 	.globl _ak820_outline_0191
                                   1933 	.globl _ak820_outline_0192
                                   1934 
                                   1935 	.area CSEG (CODE)
                                   1936 ; function ak820_outline_0030
      0085E8                       1937 _ak820_outline_0030:
      0085E8 EF               [12] 1938 	mov	a,r7
      0085E9 24 C6            [12] 1939 	add	a,#_key_refs
      0085EB FD               [12] 1940 	mov	r5,a
      0085EC E4               [12] 1941 	clr	a
      0085ED 34 09            [12] 1942 	addc	a,#(_key_refs>>8)
      0085EF FE               [12] 1943 	mov	r6,a
      0085F0 8D 82            [24] 1944 	mov	dpl,r5
      0085F2 8E 83            [24] 1945 	mov	dph,r6
      0085F4 E0               [24] 1946 	movx	a,@dptr
      0085F5 22               [24] 1947 	ret
                                   1948 
                                   1949 	.area CSEG (CODE)
                                   1950 ; function ak820_outline_0058
      0085F6                       1951 _ak820_outline_0058:
      0085F6 F0               [24] 1952 	movx	@dptr,a
      0085F7 90 0D F8         [24] 1953 	mov	dptr,#_actual_keyboard_report
      0085FA 75 F0 00         [24] 1954 	mov	b,#0x00
      0085FD 22               [24] 1955 	ret
                                   1956 
                                   1957 	.area CSEG (CODE)
                                   1958 ; function ak820_outline_0064
      0085FE                       1959 _ak820_outline_0064:
      0085FE 89 82            [24] 1960 	mov	dpl,r1
      008600 8A 83            [24] 1961 	mov	dph,r2
      008602 E8               [12] 1962 	mov	a,r0
      008603 F0               [24] 1963 	movx	@dptr,a
      008604 22               [24] 1964 	ret
                                   1965 
                                   1966 	.area CSEG (CODE)
                                   1967 ; function ak820_outline_0068
      008605                       1968 _ak820_outline_0068:
      008605 24 A1            [12] 1969 	add	a,#_usage_order
      008607 F5 82            [12] 1970 	mov	dpl,a
      008609 E4               [12] 1971 	clr	a
      00860A 34 0A            [12] 1972 	addc	a,#(_usage_order>>8)
      00860C F5 83            [12] 1973 	mov	dph,a
      00860E 22               [24] 1974 	ret
                                   1975 
                                   1976 	.area CSEG (CODE)
                                   1977 ; function ak820_outline_0075
      00860F                       1978 _ak820_outline_0075:
      00860F EB               [12] 1979 	mov	a,r3
      008610 24 83            [12] 1980 	add	a,#_usage_refs
      008612 F9               [12] 1981 	mov	r1,a
      008613 E4               [12] 1982 	clr	a
      008614 34 0A            [12] 1983 	addc	a,#(_usage_refs>>8)
      008616 FA               [12] 1984 	mov	r2,a
      008617 89 82            [24] 1985 	mov	dpl,r1
      008619 8A 83            [24] 1986 	mov	dph,r2
      00861B E0               [24] 1987 	movx	a,@dptr
      00861C F8               [12] 1988 	mov	r0,a
      00861D 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0119
      00861E                       1993 _ak820_outline_0119:
      00861E F0               [24] 1994 	movx	@dptr,a
      00861F E0               [24] 1995 	movx	a,@dptr
      008620 FF               [12] 1996 	mov	r7,a
      008621 90 09 BE         [24] 1997 	mov	dptr,#_change_owned_PARM_2
      008624 22               [24] 1998 	ret
                                   1999 
                                   2000 	.area CSEG (CODE)
                                   2001 ; function ak820_outline_0123
      008625                       2002 _ak820_outline_0123:
      008625 8D 82            [24] 2003 	mov	dpl,r5
      008627 8E 83            [24] 2004 	mov	dph,r6
      008629 F0               [24] 2005 	movx	@dptr,a
      00862A 22               [24] 2006 	ret
                                   2007 
                                   2008 	.area CSEG (CODE)
                                   2009 ; function ak820_outline_0127
      00862B                       2010 _ak820_outline_0127:
      00862B 24 A1            [12] 2011 	add	a,#_usage_order
      00862D F5 82            [12] 2012 	mov	dpl,a
      00862F EF               [12] 2013 	mov	a,r7
      008630 34 0A            [12] 2014 	addc	a,#(_usage_order>>8)
      008632 F5 83            [12] 2015 	mov	dph,a
      008634 E0               [24] 2016 	movx	a,@dptr
      008635 22               [24] 2017 	ret
                                   2018 
                                   2019 	.area CSEG (CODE)
                                   2020 ; function ak820_outline_0134
      008636                       2021 _ak820_outline_0134:
      008636 F0               [24] 2022 	movx	@dptr,a
      008637 E0               [24] 2023 	movx	a,@dptr
      008638 FF               [12] 2024 	mov	r7,a
      008639 90 09 BA         [24] 2025 	mov	dptr,#_ak820_macro_change_PARM_2
      00863C F0               [24] 2026 	movx	@dptr,a
      00863D 90 09 BB         [24] 2027 	mov	dptr,#_ak820_macro_change_PARM_3
      008640 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0192
      008641                       2032 _ak820_outline_0192:
      008641 8D 82            [24] 2033 	mov	dpl,r5
      008643 8F 83            [24] 2034 	mov	dph,r7
      008645 22               [24] 2035 	ret
