                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000016                        576 _control_setup_valid_interface_10000_286:
      000016                        577 	.ds 1
      000017                        578 _control_setup_zero_index_10000_286:
      000017                        579 	.ds 1
      000018                        580 _control_setup_zero_value_10000_286:
      000018                        581 	.ds 1
      000019                        582 _control_setup_zero_length_10000_286:
      000019                        583 	.ds 1
      00001A                        584 _control_setup_sloc0_1_0:
      00001A                        585 	.ds 1
      00001B                        586 _control_setup_sloc2_1_0:
      00001B                        587 	.ds 1
      00001C                        588 _ak820_usb_try_send_sloc0_1_0:
      00001C                        589 	.ds 1
      00001D                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001D                        591 	.ds 1
      00001E                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001E                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      000765                        602 _D0SetupReqCode::
      000765                        603 	.ds 1
      000766                        604 _D0SetupLen::
      000766                        605 	.ds 2
      000768                        606 _pD0Descr::
      000768                        607 	.ds 3
      00076B                        608 _D0UsbConfig::
      00076B                        609 	.ds 1
      00076C                        610 _USB_EnumStatus::
      00076C                        611 	.ds 1
      00076D                        612 _USB_SleepStatus::
      00076D                        613 	.ds 1
      00076E                        614 _MCU_Sleep_Operate::
      00076E                        615 	.ds 1
      00076F                        616 _KB_USB_UpStatus::
      00076F                        617 	.ds 1
      000770                        618 _KB_USB_SetReport::
      000770                        619 	.ds 1
      000771                        620 _ak820_boot_stage::
      000771                        621 	.ds 1
      000772                        622 _ak820_main_heartbeat::
      000772                        623 	.ds 1
      000773                        624 _raw_state:
      000773                        625 	.ds 1
      000774                        626 _raw_buffer:
      000774                        627 	.ds 32
      000794                        628 _raw_reply_without_nvm:
      000794                        629 	.ds 1
      000795                        630 _keyboard_reset:
      000795                        631 	.ds 1
      000796                        632 _input_snapshot:
      000796                        633 	.ds 46
      0007C4                        634 _control_phase:
      0007C4                        635 	.ds 1
      0007C5                        636 _output_kind:
      0007C5                        637 	.ds 1
      0007C6                        638 _output_report_id:
      0007C6                        639 	.ds 1
      0007C7                        640 _control_zlp:
      0007C7                        641 	.ds 1
      0007C8                        642 _control_pointer:
      0007C8                        643 	.ds 2
      0007CA                        644 _descriptor_select_PARM_2:
      0007CA                        645 	.ds 1
      0007CB                        646 _descriptor_select_PARM_3:
      0007CB                        647 	.ds 2
      0007CD                        648 _descriptor_select_type_10000_268:
      0007CD                        649 	.ds 1
      0007CE                        650 _control_setup_length_10000_286:
      0007CE                        651 	.ds 2
      0007D0                        652 _control_setup_offset_10000_286:
      0007D0                        653 	.ds 1
      0007D1                        654 _ak820_usb_send_PARM_2:
      0007D1                        655 	.ds 2
      0007D3                        656 _ak820_usb_send_PARM_3:
      0007D3                        657 	.ds 1
      0007D4                        658 _ak820_usb_send_endpoint_10000_422:
      0007D4                        659 	.ds 1
      0007D5                        660 _ak820_usb_send_offset_10000_423:
      0007D5                        661 	.ds 1
      0007D6                        662 _ak820_usb_try_send_PARM_2:
      0007D6                        663 	.ds 2
      0007D8                        664 _ak820_usb_try_send_PARM_3:
      0007D8                        665 	.ds 1
      0007D9                        666 _ak820_usb_try_send_endpoint_10000_443:
      0007D9                        667 	.ds 1
      0007DA                        668 _ak820_usb_try_send_sent_10000_444:
      0007DA                        669 	.ds 1
      0007DB                        670 _ak820_usb_raw_send_PARM_2:
      0007DB                        671 	.ds 1
      0007DC                        672 _ak820_usb_raw_send_report_10000_459:
      0007DC                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005A20                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005A20 90 07 73         [24]  727 	mov	dptr,#_raw_state
      005A23 E0               [24]  728 	movx	a,@dptr
      005A24 FF               [12]  729 	mov	r7,a
      005A25 BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005A28 80 1C            [24]  731 	sjmp	00101$
      005A2A                        732 00130$:
      005A2A 90 07 73         [24]  733 	mov	dptr,#_raw_state
      005A2D E0               [24]  734 	movx	a,@dptr
      005A2E FF               [12]  735 	mov	r7,a
      005A2F BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005A32 80 12            [24]  737 	sjmp	00101$
      005A34                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005A34 90 07 73         [24]  740 	mov	dptr,#_raw_state
      005A37 E0               [24]  741 	movx	a,@dptr
      005A38 FF               [12]  742 	mov	r7,a
      005A39 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005A3C 80 08            [24]  744 	sjmp	00101$
      005A3E                        745 00132$:
      005A3E 90 07 73         [24]  746 	mov	dptr,#_raw_state
      005A41 E0               [24]  747 	movx	a,@dptr
      005A42 FF               [12]  748 	mov	r7,a
      005A43 BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005A46                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005A46 90 07 73         [24]  752 	mov	dptr,#_raw_state
      005A49 74 07            [12]  753 	mov	a,#0x07
      005A4B F0               [24]  754 	movx	@dptr,a
      005A4C 80 05            [24]  755 	sjmp	00103$
      005A4E                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005A4E 90 07 73         [24]  758 	mov	dptr,#_raw_state
      005A51 E4               [12]  759 	clr	a
      005A52 F0               [24]  760 	movx	@dptr,a
      005A53                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005A53 90 07 C5         [24]  763 	mov	dptr,#_output_kind
      005A56 E4               [12]  764 	clr	a
      005A57 F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005A58 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005A59                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005A59 90 07 73         [24]  777 	mov	dptr,#_raw_state
      005A5C E0               [24]  778 	movx	a,@dptr
      005A5D FF               [12]  779 	mov	r7,a
      005A5E BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005A61 90 07 73         [24]  781 	mov	dptr,#_raw_state
      005A64 74 06            [12]  782 	mov	a,#0x06
      005A66 F0               [24]  783 	movx	@dptr,a
      005A67 22               [24]  784 	ret
      005A68                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005A68 90 07 73         [24]  787 	mov	dptr,#_raw_state
      005A6B E0               [24]  788 	movx	a,@dptr
      005A6C FF               [12]  789 	mov	r7,a
      005A6D BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005A70 90 07 73         [24]  791 	mov	dptr,#_raw_state
      005A73 E4               [12]  792 	clr	a
      005A74 F0               [24]  793 	movx	@dptr,a
      005A75                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005A75 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005A76                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005A76 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005A79 74 01            [12]  809 	mov	a,#0x01
      005A7B F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A7C F5 82            [12]  812 	mov	dpl,a
      005A7E 74 12            [12]  813 	mov	a,#0x12
      005A80 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A81 A3               [24]  816 	inc	dptr
      005A82 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A83 A3               [24]  819 	inc	dptr
      005A84 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005A85 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005A88 E4               [12]  823 	clr	a
      005A89 F0               [24]  824 	movx	@dptr,a
      005A8A 15 82            [12]  825 	dec	dpl
      005A8C F0               [24]  826 	movx	@dptr,a
      005A8D 15 82            [12]  827 	dec	dpl
      005A8F F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005A90 FF               [12]  830 	mov	r7,a
      005A91                        831 00103$:
      005A91 EF               [12]  832 	mov	a,r7
      005A92 24 96            [12]  833 	add	a, #_input_snapshot
      005A94 F5 82            [12]  834 	mov	dpl,a
      005A96 E4               [12]  835 	clr	a
      005A97 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005A99 F5 83            [12]  837 	mov	dph,a
      005A9B E4               [12]  838 	clr	a
      005A9C F0               [24]  839 	movx	@dptr,a
      005A9D 0F               [12]  840 	inc	r7
      005A9E BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      005AA1                        842 00139$:
      005AA1 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005AA3 90 07 9E         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005AA6 74 06            [12]  846 	mov	a,#0x06
      005AA8 F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005AA9 90 07 BE         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005AAC 03               [12]  850 	rr	a
      005AAD F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005AAE 90 07 C1         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      005AB1 04               [12]  854 	inc	a
      005AB2 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005AB3 7F 00            [12]  857 	mov	r7,#0x00
      005AB5                        858 00105$:
      005AB5 8F 06            [24]  859 	mov	ar6,r7
      005AB7 74 C0            [12]  860 	mov	a,#0xc0
      005AB9 2E               [12]  861 	add	a, r6
      005ABA F5 82            [12]  862 	mov	dpl,a
      005ABC 74 10            [12]  863 	mov	a,#0x10
      005ABE 24 00            [12]  864 	add	a, #0x00
      005AC0 F5 83            [12]  865 	mov	dph,a
      005AC2 E4               [12]  866 	clr	a
      005AC3 F0               [24]  867 	movx	@dptr,a
      005AC4 0F               [12]  868 	inc	r7
      005AC5 BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005AC8                        870 00141$:
      005AC8 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005ACA 02 5A 20         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005ACD                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005ACD 90 07 73         [24]  884 	mov	dptr,#_raw_state
      005AD0 E0               [24]  885 	movx	a,@dptr
      005AD1 FF               [12]  886 	mov	r7,a
      005AD2 BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005AD5 90 07 73         [24]  888 	mov	dptr,#_raw_state
      005AD8 E4               [12]  889 	clr	a
      005AD9 F0               [24]  890 	movx	@dptr,a
      005ADA                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005ADA 90 07 C5         [24]  893 	mov	dptr,#_output_kind
      005ADD E4               [12]  894 	clr	a
      005ADE F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      005ADF 90 07 C4         [24]  897 	mov	dptr,#_control_phase
      005AE2 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      005AE3 90 07 65         [24]  900 	mov	dptr,#_D0SetupReqCode
      005AE6 14               [12]  901 	dec	a
      005AE7 F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005AE8 90 22 00         [24]  904 	mov	dptr,#0x2200
      005AEB 74 CF            [12]  905 	mov	a,#0xcf
      005AED F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      005AEE 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      005AEF                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005AEF 90 07 66         [24]  921 	mov	dptr,#_D0SetupLen
      005AF2 E0               [24]  922 	movx	a,@dptr
      005AF3 FE               [12]  923 	mov	r6,a
      005AF4 A3               [24]  924 	inc	dptr
      005AF5 E0               [24]  925 	movx	a,@dptr
      005AF6 FF               [12]  926 	mov	r7,a
      005AF7 C3               [12]  927 	clr	c
      005AF8 74 40            [12]  928 	mov	a,#0x40
      005AFA 9E               [12]  929 	subb	a,r6
      005AFB E4               [12]  930 	clr	a
      005AFC 9F               [12]  931 	subb	a,r7
      005AFD 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      005AFF 7E 40            [12]  934 	mov	r6,#0x40
      005B01 80 07            [24]  935 	sjmp	00110$
      005B03                        936 00109$:
      005B03 90 07 66         [24]  937 	mov	dptr,#_D0SetupLen
      005B06 E0               [24]  938 	movx	a,@dptr
      005B07 FE               [12]  939 	mov	r6,a
      005B08 A3               [24]  940 	inc	dptr
      005B09 E0               [24]  941 	movx	a,@dptr
      005B0A                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005B0A 7F 00            [12]  944 	mov	r7,#0x00
      005B0C                        945 00105$:
      005B0C C3               [12]  946 	clr	c
      005B0D EF               [12]  947 	mov	a,r7
      005B0E 9E               [12]  948 	subb	a,r6
      005B0F 50 2A            [24]  949 	jnc	00101$
      005B11 8F 04            [24]  950 	mov	ar4,r7
      005B13 74 10            [12]  951 	mov	a,#0x10
      005B15 24 00            [12]  952 	add	a, #0x00
      005B17 FD               [12]  953 	mov	r5,a
      005B18 90 07 C8         [24]  954 	mov	dptr,#_control_pointer
      005B1B E0               [24]  955 	movx	a,@dptr
      005B1C FA               [12]  956 	mov	r2,a
      005B1D A3               [24]  957 	inc	dptr
      005B1E E0               [24]  958 	movx	a,@dptr
      005B1F FB               [12]  959 	mov	r3,a
      005B20 8A 82            [24]  960 	mov	dpl,r2
      005B22 8B 83            [24]  961 	mov	dph,r3
      005B24 E4               [12]  962 	clr	a
      005B25 93               [24]  963 	movc	a,@a+dptr
      005B26 F9               [12]  964 	mov	r1,a
      005B27 90 07 C8         [24]  965 	mov	dptr,#_control_pointer
      005B2A 74 01            [12]  966 	mov	a,#0x01
      005B2C 2A               [12]  967 	add	a, r2
      005B2D F0               [24]  968 	movx	@dptr,a
      005B2E E4               [12]  969 	clr	a
      005B2F 3B               [12]  970 	addc	a, r3
      005B30 A3               [24]  971 	inc	dptr
      005B31 F0               [24]  972 	movx	@dptr,a
      005B32 8C 82            [24]  973 	mov	dpl,r4
      005B34 8D 83            [24]  974 	mov	dph,r5
      005B36 E9               [12]  975 	mov	a,r1
      005B37 F0               [24]  976 	movx	@dptr,a
      005B38 0F               [12]  977 	inc	r7
      005B39 80 D1            [24]  978 	sjmp	00105$
      005B3B                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      005B3B 8E 05            [24]  981 	mov	ar5,r6
      005B3D 7F 00            [12]  982 	mov	r7,#0x00
      005B3F 90 07 66         [24]  983 	mov	dptr,#_D0SetupLen
      005B42 E0               [24]  984 	movx	a,@dptr
      005B43 FB               [12]  985 	mov	r3,a
      005B44 A3               [24]  986 	inc	dptr
      005B45 E0               [24]  987 	movx	a,@dptr
      005B46 FC               [12]  988 	mov	r4,a
      005B47 EB               [12]  989 	mov	a,r3
      005B48 C3               [12]  990 	clr	c
      005B49 9D               [12]  991 	subb	a,r5
      005B4A FB               [12]  992 	mov	r3,a
      005B4B EC               [12]  993 	mov	a,r4
      005B4C 9F               [12]  994 	subb	a,r7
      005B4D FC               [12]  995 	mov	r4,a
      005B4E 90 07 66         [24]  996 	mov	dptr,#_D0SetupLen
      005B51 EB               [12]  997 	mov	a,r3
      005B52 F0               [24]  998 	movx	@dptr,a
      005B53 EC               [12]  999 	mov	a,r4
      005B54 A3               [24] 1000 	inc	dptr
      005B55 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      005B56 EE               [12] 1003 	mov	a,r6
      005B57 70 05            [24] 1004 	jnz	00103$
      005B59 90 07 C7         [24] 1005 	mov	dptr,#_control_zlp
      005B5C E4               [12] 1006 	clr	a
      005B5D F0               [24] 1007 	movx	@dptr,a
      005B5E                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      005B5E 90 22 08         [24] 1010 	mov	dptr,#0x2208
      005B61 EE               [12] 1011 	mov	a,r6
      005B62 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005B63 90 22 00         [24] 1014 	mov	dptr,#0x2200
      005B66 E0               [24] 1015 	movx	a,@dptr
      005B67 54 C0            [12] 1016 	anl	a,#0xc0
      005B69 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      005B6A 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      005B6B                       1032 _descriptor_select:
      005B6B E5 82            [12] 1033 	mov	a,dpl
      005B6D 90 07 CD         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      005B70 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005B71 E0               [24] 1037 	movx	a,@dptr
      005B72 FF               [12] 1038 	mov	r7,a
      005B73 BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      005B76 90 07 CA         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      005B79 E0               [24] 1041 	movx	a,@dptr
      005B7A 70 1A            [24] 1042 	jnz	00102$
      005B7C 90 07 CB         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      005B7F E0               [24] 1044 	movx	a,@dptr
      005B80 F5 F0            [12] 1045 	mov	b,a
      005B82 A3               [24] 1046 	inc	dptr
      005B83 E0               [24] 1047 	movx	a,@dptr
      005B84 45 F0            [12] 1048 	orl	a,b
      005B86 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005B88 90 07 C8         [24] 1051 	mov	dptr,#_control_pointer
      005B8B 74 9D            [12] 1052 	mov	a,#_DeviceDescriptor
      005B8D F0               [24] 1053 	movx	@dptr,a
      005B8E 74 BF            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      005B90 A3               [24] 1055 	inc	dptr
      005B91 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      005B92 90 00 12         [24] 1058 	mov	dptr,#0x0012
      005B95 22               [24] 1059 	ret
      005B96                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005B96 90 07 CD         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      005B99 E0               [24] 1063 	movx	a,@dptr
      005B9A FF               [12] 1064 	mov	r7,a
      005B9B BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      005B9E 90 07 CA         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      005BA1 E0               [24] 1067 	movx	a,@dptr
      005BA2 70 1A            [24] 1068 	jnz	00106$
      005BA4 90 07 CB         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      005BA7 E0               [24] 1070 	movx	a,@dptr
      005BA8 F5 F0            [12] 1071 	mov	b,a
      005BAA A3               [24] 1072 	inc	dptr
      005BAB E0               [24] 1073 	movx	a,@dptr
      005BAC 45 F0            [12] 1074 	orl	a,b
      005BAE 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005BB0 90 07 C8         [24] 1077 	mov	dptr,#_control_pointer
      005BB3 74 AF            [12] 1078 	mov	a,#_ConfigurationDescriptor
      005BB5 F0               [24] 1079 	movx	@dptr,a
      005BB6 74 BF            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      005BB8 A3               [24] 1081 	inc	dptr
      005BB9 F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      005BBA 90 00 54         [24] 1084 	mov	dptr,#0x0054
      005BBD 22               [24] 1085 	ret
      005BBE                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      005BBE 90 07 CD         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      005BC1 E0               [24] 1089 	movx	a,@dptr
      005BC2 FF               [12] 1090 	mov	r7,a
      005BC3 BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      005BC6 80 03            [24] 1092 	sjmp	00239$
      005BC8                       1093 00238$:
      005BC8 02 5C 62         [24] 1094 	ljmp	00119$
      005BCB                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      005BCB 90 07 CB         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      005BCE E0               [24] 1098 	movx	a,@dptr
      005BCF FD               [12] 1099 	mov	r5,a
      005BD0 A3               [24] 1100 	inc	dptr
      005BD1 E0               [24] 1101 	movx	a,@dptr
      005BD2 FE               [12] 1102 	mov	r6,a
      005BD3 90 07 CB         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      005BD6 E0               [24] 1104 	movx	a,@dptr
      005BD7 F5 F0            [12] 1105 	mov	b,a
      005BD9 A3               [24] 1106 	inc	dptr
      005BDA E0               [24] 1107 	movx	a,@dptr
      005BDB 45 F0            [12] 1108 	orl	a,b
      005BDD 60 0C            [24] 1109 	jz	00110$
      005BDF BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      005BE2 BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      005BE5 80 04            [24] 1112 	sjmp	00110$
      005BE7                       1113 00241$:
      005BE7 90 00 00         [24] 1114 	mov	dptr,#0x0000
      005BEA 22               [24] 1115 	ret
      005BEB                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      005BEB 90 07 CA         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      005BEE E0               [24] 1119 	movx	a,@dptr
      005BEF FE               [12] 1120 	mov  r6,a
      005BF0 24 FC            [12] 1121 	add	a,#0xff - 0x03
      005BF2 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      005BF4 EE               [12] 1124 	mov	a,r6
      005BF5 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005BF6 90 5B FA         [24] 1127 	mov	dptr,#00243$
      005BF9 73               [24] 1128 	jmp	@a+dptr
      005BFA                       1129 00243$:
      005BFA 80 06            [24] 1130 	sjmp	00112$
      005BFC 80 1B            [24] 1131 	sjmp	00113$
      005BFE 80 30            [24] 1132 	sjmp	00114$
      005C00 80 45            [24] 1133 	sjmp	00115$
      005C02                       1134 00112$:
      005C02 90 07 C8         [24] 1135 	mov	dptr,#_control_pointer
      005C05 74 03            [12] 1136 	mov	a,#_LanguageString
      005C07 F0               [24] 1137 	movx	@dptr,a
      005C08 74 C0            [12] 1138 	mov	a,#(_LanguageString >> 8)
      005C0A A3               [24] 1139 	inc	dptr
      005C0B F0               [24] 1140 	movx	@dptr,a
      005C0C 90 C0 03         [24] 1141 	mov	dptr,#_LanguageString
      005C0F E4               [12] 1142 	clr	a
      005C10 93               [24] 1143 	movc	a,@a+dptr
      005C11 FE               [12] 1144 	mov	r6,a
      005C12 7D 00            [12] 1145 	mov	r5,#0x00
      005C14 8E 82            [24] 1146 	mov	dpl, r6
      005C16 8D 83            [24] 1147 	mov	dph, r5
      005C18 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005C19                       1150 00113$:
      005C19 90 07 C8         [24] 1151 	mov	dptr,#_control_pointer
      005C1C 74 07            [12] 1152 	mov	a,#_ManufacturerString
      005C1E F0               [24] 1153 	movx	@dptr,a
      005C1F 74 C0            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      005C21 A3               [24] 1155 	inc	dptr
      005C22 F0               [24] 1156 	movx	@dptr,a
      005C23 90 C0 07         [24] 1157 	mov	dptr,#_ManufacturerString
      005C26 E4               [12] 1158 	clr	a
      005C27 93               [24] 1159 	movc	a,@a+dptr
      005C28 FE               [12] 1160 	mov	r6,a
      005C29 7D 00            [12] 1161 	mov	r5,#0x00
      005C2B 8E 82            [24] 1162 	mov	dpl, r6
      005C2D 8D 83            [24] 1163 	mov	dph, r5
      005C2F 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005C30                       1166 00114$:
      005C30 90 07 C8         [24] 1167 	mov	dptr,#_control_pointer
      005C33 74 15            [12] 1168 	mov	a,#_ProductString
      005C35 F0               [24] 1169 	movx	@dptr,a
      005C36 74 C0            [12] 1170 	mov	a,#(_ProductString >> 8)
      005C38 A3               [24] 1171 	inc	dptr
      005C39 F0               [24] 1172 	movx	@dptr,a
      005C3A 90 C0 15         [24] 1173 	mov	dptr,#_ProductString
      005C3D E4               [12] 1174 	clr	a
      005C3E 93               [24] 1175 	movc	a,@a+dptr
      005C3F FE               [12] 1176 	mov	r6,a
      005C40 7D 00            [12] 1177 	mov	r5,#0x00
      005C42 8E 82            [24] 1178 	mov	dpl, r6
      005C44 8D 83            [24] 1179 	mov	dph, r5
      005C46 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005C47                       1182 00115$:
      005C47 90 07 C8         [24] 1183 	mov	dptr,#_control_pointer
      005C4A 74 4D            [12] 1184 	mov	a,#_SerialNumberString
      005C4C F0               [24] 1185 	movx	@dptr,a
      005C4D 74 C0            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      005C4F A3               [24] 1187 	inc	dptr
      005C50 F0               [24] 1188 	movx	@dptr,a
      005C51 90 C0 4D         [24] 1189 	mov	dptr,#_SerialNumberString
      005C54 E4               [12] 1190 	clr	a
      005C55 93               [24] 1191 	movc	a,@a+dptr
      005C56 FE               [12] 1192 	mov	r6,a
      005C57 7D 00            [12] 1193 	mov	r5,#0x00
      005C59 8E 82            [24] 1194 	mov	dpl, r6
      005C5B 8D 83            [24] 1195 	mov	dph, r5
      005C5D 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      005C5E                       1198 00116$:
      005C5E 90 00 00         [24] 1199 	mov	dptr,#0x0000
      005C61 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      005C62                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      005C62 90 07 CA         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      005C65 E0               [24] 1205 	movx	a,@dptr
      005C66 70 11            [24] 1206 	jnz	00120$
      005C68 90 07 CB         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      005C6B E0               [24] 1208 	movx	a,@dptr
      005C6C FD               [12] 1209 	mov	r5,a
      005C6D A3               [24] 1210 	inc	dptr
      005C6E E0               [24] 1211 	movx	a,@dptr
      005C6F FE               [12] 1212 	mov	r6,a
      005C70 C3               [12] 1213 	clr	c
      005C71 ED               [12] 1214 	mov	a,r5
      005C72 94 03            [12] 1215 	subb	a,#0x03
      005C74 EE               [12] 1216 	mov	a,r6
      005C75 94 00            [12] 1217 	subb	a,#0x00
      005C77 40 04            [24] 1218 	jc	00121$
      005C79                       1219 00120$:
      005C79 90 00 00         [24] 1220 	mov	dptr,#0x0000
      005C7C 22               [24] 1221 	ret
      005C7D                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005C7D BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      005C80 80 03            [24] 1225 	sjmp	00127$
      005C82                       1226 00246$:
      005C82 BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      005C85                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005C85 ED               [12] 1230 	mov	a,r5
      005C86 75 F0 04         [24] 1231 	mov	b,#0x04
      005C89 A4               [48] 1232 	mul	ab
      005C8A 24 26            [12] 1233 	add	a, #_interface_descriptors
      005C8C FE               [12] 1234 	mov	r6,a
      005C8D 74 B9            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      005C8F 35 F0            [12] 1236 	addc	a, b
      005C91 FF               [12] 1237 	mov	r7,a
      005C92 8E 82            [24] 1238 	mov	dpl,r6
      005C94 8F 83            [24] 1239 	mov	dph,r7
      005C96 A3               [24] 1240 	inc	dptr
      005C97 A3               [24] 1241 	inc	dptr
      005C98 E4               [12] 1242 	clr	a
      005C99 93               [24] 1243 	movc	a,@a+dptr
      005C9A FC               [12] 1244 	mov	r4,a
      005C9B A3               [24] 1245 	inc	dptr
      005C9C E4               [12] 1246 	clr	a
      005C9D 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      005C9E FD               [12] 1249 	mov	r5,a
      005C9F 4C               [12] 1250 	orl	a,r4
      005CA0 70 04            [24] 1251 	jnz	00124$
      005CA2 90 00 00         [24] 1252 	mov	dptr,#0x0000
      005CA5 22               [24] 1253 	ret
      005CA6                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      005CA6 90 07 CD         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      005CA9 E0               [24] 1257 	movx	a,@dptr
      005CAA FB               [12] 1258 	mov	r3,a
      005CAB BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005CAE 8E 82            [24] 1261 	mov	dpl,r6
      005CB0 8F 83            [24] 1262 	mov	dph,r7
      005CB2 E4               [12] 1263 	clr	a
      005CB3 93               [24] 1264 	movc	a,@a+dptr
      005CB4 FE               [12] 1265 	mov	r6,a
      005CB5 A3               [24] 1266 	inc	dptr
      005CB6 E4               [12] 1267 	clr	a
      005CB7 93               [24] 1268 	movc	a,@a+dptr
      005CB8 FF               [12] 1269 	mov	r7,a
      005CB9 90 07 C8         [24] 1270 	mov	dptr,#_control_pointer
      005CBC EE               [12] 1271 	mov	a,r6
      005CBD F0               [24] 1272 	movx	@dptr,a
      005CBE EF               [12] 1273 	mov	a,r7
      005CBF A3               [24] 1274 	inc	dptr
      005CC0 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      005CC1 74 07            [12] 1277 	mov	a,#0x07
      005CC3 2C               [12] 1278 	add	a, r4
      005CC4 F5 82            [12] 1279 	mov	dpl,a
      005CC6 E4               [12] 1280 	clr	a
      005CC7 3D               [12] 1281 	addc	a, r5
      005CC8 F5 83            [12] 1282 	mov	dph,a
      005CCA E4               [12] 1283 	clr	a
      005CCB 93               [24] 1284 	movc	a,@a+dptr
      005CCC FE               [12] 1285 	mov	r6,a
      005CCD A3               [24] 1286 	inc	dptr
      005CCE E4               [12] 1287 	clr	a
      005CCF 93               [24] 1288 	movc	a,@a+dptr
      005CD0 FF               [12] 1289 	mov	r7,a
      005CD1 8E 82            [24] 1290 	mov	dpl, r6
      005CD3 8F 83            [24] 1291 	mov	dph, r7
      005CD5 22               [24] 1292 	ret
      005CD6                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      005CD6 90 07 C8         [24] 1295 	mov	dptr,#_control_pointer
      005CD9 EC               [12] 1296 	mov	a,r4
      005CDA F0               [24] 1297 	movx	@dptr,a
      005CDB ED               [12] 1298 	mov	a,r5
      005CDC A3               [24] 1299 	inc	dptr
      005CDD F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      005CDE 90 00 09         [24] 1302 	mov	dptr,#0x0009
      005CE1 22               [24] 1303 	ret
      005CE2                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      005CE2 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      005CE5 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      005CE6                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005CE6 90 10 00         [24] 1330 	mov	dptr,#0x1000
      005CE9 E0               [24] 1331 	movx	a,@dptr
      005CEA FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005CEB A3               [24] 1334 	inc	dptr
      005CEC A3               [24] 1335 	inc	dptr
      005CED E0               [24] 1336 	movx	a,@dptr
      005CEE FE               [12] 1337 	mov	r6,a
      005CEF A3               [24] 1338 	inc	dptr
      005CF0 E0               [24] 1339 	movx	a,@dptr
      005CF1 FC               [12] 1340 	mov	r4,a
      005CF2 7D 00            [12] 1341 	mov	r5,#0x00
      005CF4 8E 03            [24] 1342 	mov	ar3,r6
      005CF6 7E 00            [12] 1343 	mov	r6,#0x00
      005CF8 ED               [12] 1344 	mov	a,r5
      005CF9 4B               [12] 1345 	orl	a,r3
      005CFA FD               [12] 1346 	mov	r5,a
      005CFB EC               [12] 1347 	mov	a,r4
      005CFC 4E               [12] 1348 	orl	a,r6
      005CFD FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005CFE A3               [24] 1351 	inc	dptr
      005CFF E0               [24] 1352 	movx	a,@dptr
      005D00 FC               [12] 1353 	mov	r4,a
      005D01 A3               [24] 1354 	inc	dptr
      005D02 E0               [24] 1355 	movx	a,@dptr
      005D03 FA               [12] 1356 	mov	r2,a
      005D04 7B 00            [12] 1357 	mov	r3,#0x00
      005D06 8C 01            [24] 1358 	mov	ar1,r4
      005D08 7C 00            [12] 1359 	mov	r4,#0x00
      005D0A EB               [12] 1360 	mov	a,r3
      005D0B 49               [12] 1361 	orl	a,r1
      005D0C FB               [12] 1362 	mov	r3,a
      005D0D EA               [12] 1363 	mov	a,r2
      005D0E 4C               [12] 1364 	orl	a,r4
      005D0F FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      005D10 C3               [12] 1367 	clr	c
      005D11 EB               [12] 1368 	mov	a,r3
      005D12 94 03            [12] 1369 	subb	a,#0x03
      005D14 EC               [12] 1370 	mov	a,r4
      005D15 94 00            [12] 1371 	subb	a,#0x00
      005D17 92 16            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      005D19 EB               [12] 1374 	mov	a,r3
      005D1A 4C               [12] 1375 	orl	a,r4
      005D1B B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      005D1E                       1377 01201$:
      005D1E 92 17            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      005D20 ED               [12] 1380 	mov	a,r5
      005D21 4E               [12] 1381 	orl	a,r6
      005D22 B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      005D25                       1383 01202$:
                                   1384 ;	assignBit
      005D25 92 1A            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      005D27 92 18            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      005D29 90 07 D0         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      005D2C E4               [12] 1389 	clr	a
      005D2D F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005D2E 90 07 73         [24] 1392 	mov	dptr,#_raw_state
      005D31 E0               [24] 1393 	movx	a,@dptr
      005D32 FA               [12] 1394 	mov	r2,a
      005D33 BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      005D36 90 07 73         [24] 1396 	mov	dptr,#_raw_state
      005D39 E4               [12] 1397 	clr	a
      005D3A F0               [24] 1398 	movx	@dptr,a
      005D3B                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      005D3B C0 07            [24] 1401 	push	ar7
      005D3D 90 07 C5         [24] 1402 	mov	dptr,#_output_kind
      005D40 E4               [12] 1403 	clr	a
      005D41 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      005D42 90 07 C4         [24] 1406 	mov	dptr,#_control_phase
      005D45 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      005D46 90 07 C7         [24] 1409 	mov	dptr,#_control_zlp
      005D49 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005D4A 90 10 01         [24] 1412 	mov	dptr,#0x1001
      005D4D E0               [24] 1413 	movx	a,@dptr
      005D4E 90 07 65         [24] 1414 	mov	dptr,#_D0SetupReqCode
      005D51 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005D52 90 10 06         [24] 1417 	mov	dptr,#0x1006
      005D55 E0               [24] 1418 	movx	a,@dptr
      005D56 FA               [12] 1419 	mov	r2,a
      005D57 A3               [24] 1420 	inc	dptr
      005D58 E0               [24] 1421 	movx	a,@dptr
      005D59 F9               [12] 1422 	mov	r1,a
      005D5A 78 00            [12] 1423 	mov	r0,#0x00
      005D5C 7F 00            [12] 1424 	mov	r7,#0x00
      005D5E 90 07 66         [24] 1425 	mov	dptr,#_D0SetupLen
      005D61 E8               [12] 1426 	mov	a,r0
      005D62 4A               [12] 1427 	orl	a,r2
      005D63 F0               [24] 1428 	movx	@dptr,a
      005D64 E9               [12] 1429 	mov	a,r1
      005D65 4F               [12] 1430 	orl	a,r7
      005D66 A3               [24] 1431 	inc	dptr
      005D67 F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      005D68 90 07 66         [24] 1434 	mov	dptr,#_D0SetupLen
      005D6B E0               [24] 1435 	movx	a,@dptr
      005D6C FA               [12] 1436 	mov	r2,a
      005D6D A3               [24] 1437 	inc	dptr
      005D6E E0               [24] 1438 	movx	a,@dptr
      005D6F 4A               [12] 1439 	orl	a,r2
      005D70 B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      005D73                       1441 01205$:
      005D73 92 19            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      005D75 90 22 00         [24] 1444 	mov	dptr,#0x2200
      005D78 74 C2            [12] 1445 	mov	a,#0xc2
      005D7A F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      005D7B 90 22 08         [24] 1448 	mov	dptr,#0x2208
      005D7E E4               [12] 1449 	clr	a
      005D7F F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      005D80 90 07 65         [24] 1452 	mov	dptr,#_D0SetupReqCode
      005D83 E0               [24] 1453 	movx	a,@dptr
      005D84 F5 16            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      005D86 C3               [12] 1455 	clr	c
      005D87 74 0B            [12] 1456 	mov	a,#0x0b
      005D89 95 16            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      005D8B D0 07            [24] 1458 	pop	ar7
      005D8D 50 03            [24] 1459 	jnc	01206$
      005D8F 02 5A CD         [24] 1460 	ljmp	_control_stall
      005D92                       1461 01206$:
                                   1462 ;	free result
      005D92 E5 16            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      005D94 F5 F0            [12] 1464 	mov	b,a
      005D96 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      005D98 83               [24] 1466 	movc	a,@a+pc
      005D99 F5 82            [12] 1467 	mov	dpl,a
      005D9B E5 F0            [12] 1468 	mov	a,b
      005D9D 24 10            [12] 1469 	add	a,#(01208$-3-.)
      005D9F 83               [24] 1470 	movc	a,@a+pc
      005DA0 F5 83            [12] 1471 	mov	dph,a
      005DA2 E4               [12] 1472 	clr	a
      005DA3 73               [24] 1473 	jmp	@a+dptr
      005DA4                       1474 01207$:
      005DA4 4C                    1475 	.db	00188$
      005DA5 F2                    1476 	.db	00205$
      005DA6 35                    1477 	.db	00282$
      005DA7 F2                    1478 	.db	00205$
      005DA8 79                    1479 	.db	00290$
      005DA9 76                    1480 	.db	00116$
      005DAA BC                    1481 	.db	00103$
      005DAB 79                    1482 	.db	00290$
      005DAC 7B                    1483 	.db	00150$
      005DAD 9F                    1484 	.db	00123$
      005DAE AB                    1485 	.db	00157$
      005DAF FE                    1486 	.db	00173$
      005DB0                       1487 01208$:
      005DB0 60                    1488 	.db	00188$>>8
      005DB1 60                    1489 	.db	00205$>>8
      005DB2 64                    1490 	.db	00282$>>8
      005DB3 60                    1491 	.db	00205$>>8
      005DB4 64                    1492 	.db	00290$>>8
      005DB5 5E                    1493 	.db	00116$>>8
      005DB6 5D                    1494 	.db	00103$>>8
      005DB7 64                    1495 	.db	00290$>>8
      005DB8 5F                    1496 	.db	00150$>>8
      005DB9 5E                    1497 	.db	00123$>>8
      005DBA 5F                    1498 	.db	00157$>>8
      005DBB 5F                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      005DBC                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      005DBC BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      005DBF 80 08            [24] 1504 	sjmp	00112$
      005DC1                       1505 01209$:
      005DC1 BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      005DC4 80 03            [24] 1507 	sjmp	01211$
      005DC6                       1508 01210$:
      005DC6 02 5A CD         [24] 1509 	ljmp	_control_stall
      005DC9                       1510 01211$:
      005DC9                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      005DC9 8E 01            [24] 1513 	mov	ar1,r6
      005DCB B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      005DCE 80 09            [24] 1515 	sjmp	00301$
      005DD0                       1516 01212$:
      005DD0 B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      005DD3 80 04            [24] 1518 	sjmp	00301$
      005DD5                       1519 01213$:
                                   1520 ;	assignBit
      005DD5 C2 1B            [12] 1521 	clr	_control_setup_sloc2_1_0
      005DD7 80 02            [24] 1522 	sjmp	00302$
      005DD9                       1523 00301$:
                                   1524 ;	assignBit
      005DD9 D2 1B            [12] 1525 	setb	_control_setup_sloc2_1_0
      005DDB                       1526 00302$:
      005DDB E4               [12] 1527 	clr	a
      005DDC BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      005DDF 04               [12] 1529 	inc	a
      005DE0                       1530 01214$:
      005DE0 FA               [12] 1531 	mov	r2,a
      005DE1 A2 1B            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      005DE3 E4               [12] 1533 	clr	a
      005DE4 33               [12] 1534 	rlc	a
      005DE5 B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      005DE8 80 03            [24] 1536 	sjmp	00105$
      005DEA                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      005DEA 02 5A CD         [24] 1539 	ljmp	_control_stall
      005DED                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      005DED 8E 02            [24] 1542 	mov	ar2,r6
      005DEF 90 07 CA         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      005DF2 ED               [12] 1544 	mov	a,r5
      005DF3 F0               [24] 1545 	movx	@dptr,a
      005DF4 90 07 CB         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      005DF7 EB               [12] 1547 	mov	a,r3
      005DF8 F0               [24] 1548 	movx	@dptr,a
      005DF9 EC               [12] 1549 	mov	a,r4
      005DFA A3               [24] 1550 	inc	dptr
      005DFB F0               [24] 1551 	movx	@dptr,a
      005DFC 8A 82            [24] 1552 	mov	dpl, r2
      005DFE 12 5B 6B         [24] 1553 	lcall	_descriptor_select
      005E01 85 82 17         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      005E04 85 83 18         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      005E07 E5 17            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      005E09 45 18            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      005E0B 70 03            [24] 1559 	jnz	00107$
      005E0D 02 5A CD         [24] 1560 	ljmp	_control_stall
      005E10                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      005E10 90 07 66         [24] 1563 	mov	dptr,#_D0SetupLen
      005E13 E0               [24] 1564 	movx	a,@dptr
      005E14 F8               [12] 1565 	mov	r0,a
      005E15 A3               [24] 1566 	inc	dptr
      005E16 E0               [24] 1567 	movx	a,@dptr
      005E17 FA               [12] 1568 	mov	r2,a
      005E18 C3               [12] 1569 	clr	c
      005E19 E5 17            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      005E1B 98               [12] 1571 	subb	a,r0
      005E1C E5 18            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E1E 9A               [12] 1573 	subb	a,r2
      005E1F 50 06            [24] 1574 	jnc	00303$
      005E21 E5 17            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      005E23 54 3F            [12] 1576 	anl	a,#0x3f
      005E25 60 04            [24] 1577 	jz	00304$
      005E27                       1578 00303$:
                                   1579 ;	assignBit
      005E27 C2 1B            [12] 1580 	clr	_control_setup_sloc2_1_0
      005E29 80 02            [24] 1581 	sjmp	00305$
      005E2B                       1582 00304$:
                                   1583 ;	assignBit
      005E2B D2 1B            [12] 1584 	setb	_control_setup_sloc2_1_0
      005E2D                       1585 00305$:
      005E2D 90 07 C7         [24] 1586 	mov	dptr,#_control_zlp
      005E30 A2 1B            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      005E32 E4               [12] 1588 	clr	a
      005E33 33               [12] 1589 	rlc	a
      005E34 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      005E35 90 07 66         [24] 1592 	mov	dptr,#_D0SetupLen
      005E38 E0               [24] 1593 	movx	a,@dptr
      005E39 F9               [12] 1594 	mov	r1,a
      005E3A A3               [24] 1595 	inc	dptr
      005E3B E0               [24] 1596 	movx	a,@dptr
      005E3C FA               [12] 1597 	mov	r2,a
      005E3D C3               [12] 1598 	clr	c
      005E3E E5 17            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      005E40 99               [12] 1600 	subb	a,r1
      005E41 E5 18            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E43 9A               [12] 1602 	subb	a,r2
      005E44 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      005E46 90 07 66         [24] 1605 	mov	dptr,#_D0SetupLen
      005E49 E5 17            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      005E4B F0               [24] 1607 	movx	@dptr,a
      005E4C E5 18            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E4E A3               [24] 1609 	inc	dptr
      005E4F F0               [24] 1610 	movx	@dptr,a
      005E50                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      005E50 90 07 66         [24] 1613 	mov	dptr,#_D0SetupLen
      005E53 E0               [24] 1614 	movx	a,@dptr
      005E54 F9               [12] 1615 	mov	r1,a
      005E55 A3               [24] 1616 	inc	dptr
      005E56 E0               [24] 1617 	movx	a,@dptr
      005E57 49               [12] 1618 	orl	a,r1
      005E58 60 04            [24] 1619 	jz	00306$
      005E5A 7A 01            [12] 1620 	mov	r2,#0x01
      005E5C 80 02            [24] 1621 	sjmp	00307$
      005E5E                       1622 00306$:
      005E5E 7A 02            [12] 1623 	mov	r2,#0x02
      005E60                       1624 00307$:
      005E60 90 07 C4         [24] 1625 	mov	dptr,#_control_phase
      005E63 EA               [12] 1626 	mov	a,r2
      005E64 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      005E65 90 07 66         [24] 1629 	mov	dptr,#_D0SetupLen
      005E68 E0               [24] 1630 	movx	a,@dptr
      005E69 F9               [12] 1631 	mov	r1,a
      005E6A A3               [24] 1632 	inc	dptr
      005E6B E0               [24] 1633 	movx	a,@dptr
      005E6C 49               [12] 1634 	orl	a,r1
      005E6D 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      005E6F 02 5A EF         [24] 1637 	ljmp	_control_next
      005E72                       1638 00111$:
      005E72 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      005E73 02 5A CD         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      005E76                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      005E76 EF               [12] 1645 	mov	a,r7
      005E77 70 23            [24] 1646 	jnz	00118$
      005E79 30 17 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      005E7C 30 19 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      005E7F 8D 01            [24] 1649 	mov	ar1,r5
      005E81 8E 02            [24] 1650 	mov	ar2,r6
      005E83 C3               [12] 1651 	clr	c
      005E84 74 7F            [12] 1652 	mov	a,#0x7f
      005E86 99               [12] 1653 	subb	a,r1
      005E87 E4               [12] 1654 	clr	a
      005E88 9A               [12] 1655 	subb	a,r2
      005E89 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      005E8B 90 07 66         [24] 1659 	mov	dptr,#_D0SetupLen
      005E8E ED               [12] 1660 	mov	a,r5
      005E8F F0               [24] 1661 	movx	@dptr,a
      005E90 EE               [12] 1662 	mov	a,r6
      005E91 A3               [24] 1663 	inc	dptr
      005E92 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      005E93 90 07 C4         [24] 1666 	mov	dptr,#_control_phase
      005E96 74 03            [12] 1667 	mov	a,#0x03
      005E98 F0               [24] 1668 	movx	@dptr,a
      005E99 02 64 7C         [24] 1669 	ljmp	00291$
      005E9C                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      005E9C 02 5A CD         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      005E9F                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      005E9F EF               [12] 1676 	mov	a,r7
      005EA0 70 3C            [24] 1677 	jnz	00145$
      005EA2 30 17 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      005EA5 30 19 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      005EA8 8D 01            [24] 1680 	mov	ar1,r5
      005EAA 8E 02            [24] 1681 	mov	ar2,r6
      005EAC C3               [12] 1682 	clr	c
      005EAD 74 01            [12] 1683 	mov	a,#0x01
      005EAF 99               [12] 1684 	subb	a,r1
      005EB0 E4               [12] 1685 	clr	a
      005EB1 9A               [12] 1686 	subb	a,r2
      005EB2 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      005EB4 C0 06            [24] 1690 	push	ar6
      005EB6 C0 05            [24] 1691 	push	ar5
      005EB8 12 5A 76         [24] 1692 	lcall	_endpoints_reset
      005EBB D0 05            [24] 1693 	pop	ar5
      005EBD D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      005EBF 90 07 6B         [24] 1696 	mov	dptr,#_D0UsbConfig
      005EC2 ED               [12] 1697 	mov	a,r5
      005EC3 F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      005EC4 A2 1A            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      005EC6 B3               [12] 1701 	cpl	c
      005EC7 92 1B            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      005EC9 90 07 6C         [24] 1703 	mov	dptr,#_USB_EnumStatus
      005ECC E4               [12] 1704 	clr	a
      005ECD 33               [12] 1705 	rlc	a
      005ECE F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      005ECF 90 07 95         [24] 1708 	mov	dptr,#_keyboard_reset
      005ED2 74 01            [12] 1709 	mov	a,#0x01
      005ED4 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      005ED5 90 07 C4         [24] 1712 	mov	dptr,#_control_phase
      005ED8 74 03            [12] 1713 	mov	a,#0x03
      005EDA F0               [24] 1714 	movx	@dptr,a
      005EDB 02 64 7C         [24] 1715 	ljmp	00291$
      005EDE                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      005EDE BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      005EE1 80 03            [24] 1719 	sjmp	01232$
      005EE3                       1720 01231$:
      005EE3 02 5A CD         [24] 1721 	ljmp	_control_stall
      005EE6                       1722 01232$:
      005EE6 90 07 6B         [24] 1723 	mov	dptr,#_D0UsbConfig
      005EE9 E0               [24] 1724 	movx	a,@dptr
      005EEA 70 03            [24] 1725 	jnz	01233$
      005EEC 02 5A CD         [24] 1726 	ljmp	_control_stall
      005EEF                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      005EEF BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      005EF2 BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      005EF5 8D 01            [24] 1731 	mov	ar1,r5
      005EF7 8E 02            [24] 1732 	mov	ar2,r6
      005EF9 B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      005EFC BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      005EFF 90 07 66         [24] 1735 	mov	dptr,#_D0SetupLen
      005F02 E0               [24] 1736 	movx	a,@dptr
      005F03 F9               [12] 1737 	mov	r1,a
      005F04 A3               [24] 1738 	inc	dptr
      005F05 E0               [24] 1739 	movx	a,@dptr
      005F06 FA               [12] 1740 	mov	r2,a
      005F07 B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      005F0A BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      005F0D 90 07 73         [24] 1743 	mov	dptr,#_raw_state
      005F10 E0               [24] 1744 	movx	a,@dptr
      005F11 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      005F13 90 07 73         [24] 1747 	mov	dptr,#_raw_state
      005F16 74 01            [12] 1748 	mov	a,#0x01
      005F18 F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      005F19 90 07 C5         [24] 1751 	mov	dptr,#_output_kind
      005F1C F0               [24] 1752 	movx	@dptr,a
      005F1D 80 52            [24] 1753 	sjmp	00136$
      005F1F                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      005F1F EB               [12] 1756 	mov	a,r3
      005F20 4C               [12] 1757 	orl	a,r4
      005F21 70 20            [24] 1758 	jnz	00130$
      005F23 8D 01            [24] 1759 	mov	ar1,r5
      005F25 8E 02            [24] 1760 	mov	ar2,r6
      005F27 B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      005F2A BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      005F2D 90 07 66         [24] 1763 	mov	dptr,#_D0SetupLen
      005F30 E0               [24] 1764 	movx	a,@dptr
      005F31 F9               [12] 1765 	mov	r1,a
      005F32 A3               [24] 1766 	inc	dptr
      005F33 E0               [24] 1767 	movx	a,@dptr
      005F34 FA               [12] 1768 	mov	r2,a
      005F35 B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      005F38 BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      005F3B 90 07 C5         [24] 1772 	mov	dptr,#_output_kind
      005F3E 74 02            [12] 1773 	mov	a,#0x02
      005F40 F0               [24] 1774 	movx	@dptr,a
      005F41 80 2E            [24] 1775 	sjmp	00136$
      005F43                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      005F43 BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      005F46 BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      005F49 8D 01            [24] 1780 	mov	ar1,r5
      005F4B 8E 02            [24] 1781 	mov	ar2,r6
      005F4D B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      005F50 BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      005F53 90 07 66         [24] 1784 	mov	dptr,#_D0SetupLen
      005F56 E0               [24] 1785 	movx	a,@dptr
      005F57 F9               [12] 1786 	mov	r1,a
      005F58 A3               [24] 1787 	inc	dptr
      005F59 E0               [24] 1788 	movx	a,@dptr
      005F5A FA               [12] 1789 	mov	r2,a
      005F5B B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      005F5E BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      005F61 90 07 C5         [24] 1793 	mov	dptr,#_output_kind
      005F64 74 03            [12] 1794 	mov	a,#0x03
      005F66 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      005F67 90 07 C6         [24] 1797 	mov	dptr,#_output_report_id
      005F6A 23               [12] 1798 	rl	a
      005F6B F0               [24] 1799 	movx	@dptr,a
      005F6C 80 03            [24] 1800 	sjmp	00136$
      005F6E                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      005F6E 02 5A CD         [24] 1803 	ljmp	_control_stall
      005F71                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      005F71 90 07 C4         [24] 1806 	mov	dptr,#_control_phase
      005F74 74 04            [12] 1807 	mov	a,#0x04
      005F76 F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      005F77 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      005F78 02 5A CD         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      005F7B                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      005F7B BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      005F7E 30 17 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      005F81 30 18 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      005F84 90 07 66         [24] 1819 	mov	dptr,#_D0SetupLen
      005F87 E0               [24] 1820 	movx	a,@dptr
      005F88 F9               [12] 1821 	mov	r1,a
      005F89 A3               [24] 1822 	inc	dptr
      005F8A E0               [24] 1823 	movx	a,@dptr
      005F8B FA               [12] 1824 	mov	r2,a
      005F8C B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      005F8F BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      005F92 90 07 6B         [24] 1828 	mov	dptr,#_D0UsbConfig
      005F95 E0               [24] 1829 	movx	a,@dptr
      005F96 90 10 00         [24] 1830 	mov	dptr,#0x1000
      005F99 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      005F9A 90 22 08         [24] 1833 	mov	dptr,#0x2208
      005F9D 74 01            [12] 1834 	mov	a,#0x01
      005F9F F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      005FA0 90 07 C4         [24] 1837 	mov	dptr,#_control_phase
      005FA3 04               [12] 1838 	inc	a
      005FA4 F0               [24] 1839 	movx	@dptr,a
      005FA5 02 64 7C         [24] 1840 	ljmp	00291$
      005FA8                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      005FA8 02 5A CD         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      005FAB                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      005FAB BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      005FAE 30 16 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      005FB1 30 18 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      005FB4 90 07 66         [24] 1850 	mov	dptr,#_D0SetupLen
      005FB7 E0               [24] 1851 	movx	a,@dptr
      005FB8 F9               [12] 1852 	mov	r1,a
      005FB9 A3               [24] 1853 	inc	dptr
      005FBA E0               [24] 1854 	movx	a,@dptr
      005FBB FA               [12] 1855 	mov	r2,a
      005FBC B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      005FBF BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      005FC2 90 07 6B         [24] 1858 	mov	dptr,#_D0UsbConfig
      005FC5 E0               [24] 1859 	movx	a,@dptr
      005FC6 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      005FC8 90 10 00         [24] 1862 	mov	dptr,#0x1000
      005FCB E4               [12] 1863 	clr	a
      005FCC F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      005FCD 90 22 08         [24] 1866 	mov	dptr,#0x2208
      005FD0 04               [12] 1867 	inc	a
      005FD1 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      005FD2 90 07 C4         [24] 1870 	mov	dptr,#_control_phase
      005FD5 04               [12] 1871 	inc	a
      005FD6 F0               [24] 1872 	movx	@dptr,a
      005FD7 02 64 7C         [24] 1873 	ljmp	00291$
      005FDA                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      005FDA 30 16 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      005FDD 90 07 6B         [24] 1877 	mov	dptr,#_D0UsbConfig
      005FE0 E0               [24] 1878 	movx	a,@dptr
      005FE1 60 18            [24] 1879 	jz	00161$
      005FE3 BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      005FE6 30 19 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      005FE9 EB               [12] 1883 	mov	a,r3
      005FEA 4C               [12] 1884 	orl	a,r4
      005FEB 70 05            [24] 1885 	jnz	00159$
      005FED 90 06 43         [24] 1886 	mov	dptr,#_keyboard_idle
      005FF0 EE               [12] 1887 	mov	a,r6
      005FF1 F0               [24] 1888 	movx	@dptr,a
      005FF2                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      005FF2 90 07 C4         [24] 1891 	mov	dptr,#_control_phase
      005FF5 74 03            [12] 1892 	mov	a,#0x03
      005FF7 F0               [24] 1893 	movx	@dptr,a
      005FF8 02 64 7C         [24] 1894 	ljmp	00291$
      005FFB                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      005FFB 02 5A CD         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      005FFE                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      005FFE BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      006001 30 16 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      006004 30 18 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      006007 30 19 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      00600A 90 07 6B         [24] 1905 	mov	dptr,#_D0UsbConfig
      00600D E0               [24] 1906 	movx	a,@dptr
      00600E 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      006010 90 07 C4         [24] 1909 	mov	dptr,#_control_phase
      006013 74 03            [12] 1910 	mov	a,#0x03
      006015 F0               [24] 1911 	movx	@dptr,a
      006016 02 64 7C         [24] 1912 	ljmp	00291$
      006019                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006019 EB               [12] 1915 	mov	a,r3
      00601A 4C               [12] 1916 	orl	a,r4
      00601B 70 2C            [24] 1917 	jnz	00175$
      00601D 90 07 6B         [24] 1918 	mov	dptr,#_D0UsbConfig
      006020 E0               [24] 1919 	movx	a,@dptr
      006021 60 26            [24] 1920 	jz	00175$
      006023 BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      006026 30 19 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      006029 8D 01            [24] 1923 	mov	ar1,r5
      00602B 8E 02            [24] 1924 	mov	ar2,r6
      00602D C3               [12] 1925 	clr	c
      00602E 74 01            [12] 1926 	mov	a,#0x01
      006030 99               [12] 1927 	subb	a,r1
      006031 E4               [12] 1928 	clr	a
      006032 9A               [12] 1929 	subb	a,r2
      006033 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      006035 90 0D B6         [24] 1933 	mov	dptr,#_keyboard_protocol
      006038 ED               [12] 1934 	mov	a,r5
      006039 F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      00603A 90 07 95         [24] 1937 	mov	dptr,#_keyboard_reset
      00603D 74 01            [12] 1938 	mov	a,#0x01
      00603F F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      006040 90 07 C4         [24] 1941 	mov	dptr,#_control_phase
      006043 74 03            [12] 1942 	mov	a,#0x03
      006045 F0               [24] 1943 	movx	@dptr,a
      006046 02 64 7C         [24] 1944 	ljmp	00291$
      006049                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      006049 02 5A CD         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      00604C                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      00604C 20 18 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      00604F 02 5A CD         [24] 1952 	ljmp	_control_stall
      006052                       1953 01283$:
      006052 90 07 66         [24] 1954 	mov	dptr,#_D0SetupLen
      006055 E0               [24] 1955 	movx	a,@dptr
      006056 F9               [12] 1956 	mov	r1,a
      006057 A3               [24] 1957 	inc	dptr
      006058 E0               [24] 1958 	movx	a,@dptr
      006059 FA               [12] 1959 	mov	r2,a
      00605A B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      00605D BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      006060 80 03            [24] 1962 	sjmp	01285$
      006062                       1963 01284$:
      006062 02 5A CD         [24] 1964 	ljmp	_control_stall
      006065                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006065 E4               [12] 1967 	clr	a
      006066 BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      006069 04               [12] 1969 	inc	a
      00606A                       1970 01286$:
      00606A FA               [12] 1971 	mov	r2,a
      00606B 60 03            [24] 1972 	jz	00196$
      00606D 20 17 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      006070                       1974 00196$:
      006070 BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      006073 30 16 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      006076 90 07 6B         [24] 1977 	mov	dptr,#_D0UsbConfig
      006079 E0               [24] 1978 	movx	a,@dptr
      00607A 70 29            [24] 1979 	jnz	00189$
      00607C                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      00607C BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      00607F 90 07 6B         [24] 1983 	mov	dptr,#_D0UsbConfig
      006082 E0               [24] 1984 	movx	a,@dptr
      006083 60 6A            [24] 1985 	jz	00190$
      006085 EB               [12] 1986 	mov	a,r3
      006086 4C               [12] 1987 	orl	a,r4
      006087 60 1C            [24] 1988 	jz	00189$
      006089 8B 00            [24] 1989 	mov	ar0,r3
      00608B 8C 01            [24] 1990 	mov	ar1,r4
      00608D B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      006090 B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      006093 80 10            [24] 1993 	sjmp	00189$
      006095                       1994 01298$:
      006095 C3               [12] 1995 	clr	c
      006096 E8               [12] 1996 	mov	a,r0
      006097 94 81            [12] 1997 	subb	a,#0x81
      006099 E9               [12] 1998 	mov	a,r1
      00609A 94 00            [12] 1999 	subb	a,#0x00
      00609C 40 51            [24] 2000 	jc	00190$
      00609E 74 83            [12] 2001 	mov	a,#0x83
      0060A0 98               [12] 2002 	subb	a,r0
      0060A1 E4               [12] 2003 	clr	a
      0060A2 99               [12] 2004 	subb	a,r1
      0060A3 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      0060A5                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      0060A5 8B 01            [24] 2009 	mov	ar1,r3
      0060A7 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0060AA EA               [12] 2012 	mov	a,r2
      0060AB 60 0B            [24] 2013 	jz	00308$
      0060AD 90 07 6D         [24] 2014 	mov	dptr,#_USB_SleepStatus
      0060B0 E0               [24] 2015 	movx	a,@dptr
      0060B1 54 01            [12] 2016 	anl	a,#0x01
      0060B3 25 E0            [12] 2017 	add	a,acc
      0060B5 FA               [12] 2018 	mov	r2,a
      0060B6 80 22            [24] 2019 	sjmp	00309$
      0060B8                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0060B8 BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      0060BB E9               [12] 2023 	mov	a,r1
      0060BC 60 18            [24] 2024 	jz	00310$
      0060BE 89 00            [24] 2025 	mov	ar0,r1
      0060C0 79 00            [12] 2026 	mov	r1,#0x00
      0060C2 74 22            [12] 2027 	mov	a,#0x22
      0060C4 29               [12] 2028 	add	a, r1
      0060C5 F9               [12] 2029 	mov	r1,a
      0060C6 88 82            [24] 2030 	mov	dpl,r0
      0060C8 89 83            [24] 2031 	mov	dph,r1
      0060CA E0               [24] 2032 	movx	a,@dptr
      0060CB F9               [12] 2033 	mov	r1,a
      0060CC 53 01 03         [24] 2034 	anl	ar1,#0x03
      0060CF B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      0060D2 79 01            [12] 2036 	mov	r1,#0x01
      0060D4 80 02            [24] 2037 	sjmp	00311$
      0060D6                       2038 00310$:
      0060D6 79 00            [12] 2039 	mov	r1,#0x00
      0060D8                       2040 00311$:
      0060D8 89 02            [24] 2041 	mov	ar2,r1
      0060DA                       2042 00309$:
      0060DA 90 10 00         [24] 2043 	mov	dptr,#0x1000
      0060DD EA               [12] 2044 	mov	a,r2
      0060DE F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      0060DF A3               [24] 2047 	inc	dptr
      0060E0 E4               [12] 2048 	clr	a
      0060E1 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      0060E2 90 22 08         [24] 2051 	mov	dptr,#0x2208
      0060E5 74 02            [12] 2052 	mov	a,#0x02
      0060E7 F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      0060E8 90 07 C4         [24] 2055 	mov	dptr,#_control_phase
      0060EB F0               [24] 2056 	movx	@dptr,a
      0060EC 02 64 7C         [24] 2057 	ljmp	00291$
      0060EF                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      0060EF 02 5A CD         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      0060F2                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      0060F2 20 19 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      0060F5 02 61 85         [24] 2065 	ljmp	00279$
      0060F8                       2066 01307$:
      0060F8 90 07 6B         [24] 2067 	mov	dptr,#_D0UsbConfig
      0060FB E0               [24] 2068 	movx	a,@dptr
      0060FC 70 03            [24] 2069 	jnz	01308$
      0060FE 02 61 85         [24] 2070 	ljmp	00279$
      006101                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      006101 EF               [12] 2073 	mov	a,r7
      006102 70 29            [24] 2074 	jnz	00218$
      006104 8D 01            [24] 2075 	mov	ar1,r5
      006106 8E 02            [24] 2076 	mov	ar2,r6
      006108 B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      00610B BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      00610E 30 17 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006111 90 07 65         [24] 2081 	mov	dptr,#_D0SetupReqCode
      006114 E0               [24] 2082 	movx	a,@dptr
      006115 FA               [12] 2083 	mov	r2,a
      006116 BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      006119 90 07 6D         [24] 2085 	mov	dptr,#_USB_SleepStatus
      00611C E0               [24] 2086 	movx	a,@dptr
      00611D 43 E0 01         [24] 2087 	orl	acc,#0x01
      006120 F0               [24] 2088 	movx	@dptr,a
      006121 80 59            [24] 2089 	sjmp	00219$
      006123                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      006123 90 07 6D         [24] 2092 	mov	dptr,#_USB_SleepStatus
      006126 E0               [24] 2093 	movx	a,@dptr
      006127 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      00612A F0               [24] 2095 	movx	@dptr,a
      00612B 80 4F            [24] 2096 	sjmp	00219$
      00612D                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      00612D BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      006130 30 18 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      006133 8B 01            [24] 2101 	mov	ar1,r3
      006135 8C 02            [24] 2102 	mov	ar2,r4
      006137 C3               [12] 2103 	clr	c
      006138 E9               [12] 2104 	mov	a,r1
      006139 94 81            [12] 2105 	subb	a,#0x81
      00613B EA               [12] 2106 	mov	a,r2
      00613C 94 00            [12] 2107 	subb	a,#0x00
      00613E 40 39            [24] 2108 	jc	00212$
      006140 74 83            [12] 2109 	mov	a,#0x83
      006142 99               [12] 2110 	subb	a,r1
      006143 E4               [12] 2111 	clr	a
      006144 9A               [12] 2112 	subb	a,r2
      006145 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      006147 8B 02            [24] 2116 	mov	ar2,r3
      006149 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      00614C 8A 00            [24] 2119 	mov	ar0,r2
      00614E 79 00            [12] 2120 	mov	r1,#0x00
      006150 74 22            [12] 2121 	mov	a,#0x22
      006152 29               [12] 2122 	add	a, r1
      006153 F9               [12] 2123 	mov	r1,a
      006154 88 17            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      006156 89 18            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006158 90 07 65         [24] 2126 	mov	dptr,#_D0SetupReqCode
      00615B E0               [24] 2127 	movx	a,@dptr
      00615C F9               [12] 2128 	mov	r1,a
      00615D B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      006160 79 03            [12] 2130 	mov	r1,#0x03
      006162 80 02            [24] 2131 	sjmp	00319$
      006164                       2132 00318$:
      006164 79 02            [12] 2133 	mov	r1,#0x02
      006166                       2134 00319$:
      006166 43 01 10         [24] 2135 	orl	ar1,#0x10
      006169 85 17 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      00616C 85 18 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00616F E9               [12] 2138 	mov	a,r1
      006170 F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006171 BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      006174 12 5A 59         [24] 2142 	lcall	_raw_complete
      006177 80 03            [24] 2143 	sjmp	00219$
      006179                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      006179 02 5A CD         [24] 2146 	ljmp	_control_stall
      00617C                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      00617C 90 07 C4         [24] 2149 	mov	dptr,#_control_phase
      00617F 74 03            [12] 2150 	mov	a,#0x03
      006181 F0               [24] 2151 	movx	@dptr,a
      006182 02 64 7C         [24] 2152 	ljmp	00291$
      006185                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006185 E4               [12] 2155 	clr	a
      006186 BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      006189 04               [12] 2157 	inc	a
      00618A                       2158 01324$:
      00618A FA               [12] 2159 	mov	r2,a
      00618B 70 03            [24] 2160 	jnz	01326$
      00618D 02 63 F7         [24] 2161 	ljmp	00273$
      006190                       2162 01326$:
      006190 90 07 65         [24] 2163 	mov	dptr,#_D0SetupReqCode
      006193 E0               [24] 2164 	movx	a,@dptr
      006194 F9               [12] 2165 	mov	r1,a
      006195 B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      006198 80 03            [24] 2167 	sjmp	01328$
      00619A                       2168 01327$:
      00619A 02 63 F7         [24] 2169 	ljmp	00273$
      00619D                       2170 01328$:
      00619D 90 07 6B         [24] 2171 	mov	dptr,#_D0UsbConfig
      0061A0 E0               [24] 2172 	movx	a,@dptr
      0061A1 70 03            [24] 2173 	jnz	01329$
      0061A3 02 63 F7         [24] 2174 	ljmp	00273$
      0061A6                       2175 01329$:
      0061A6 90 07 66         [24] 2176 	mov	dptr,#_D0SetupLen
      0061A9 E0               [24] 2177 	movx	a,@dptr
      0061AA F8               [12] 2178 	mov	r0,a
      0061AB A3               [24] 2179 	inc	dptr
      0061AC E0               [24] 2180 	movx	a,@dptr
      0061AD 48               [12] 2181 	orl	a,r0
      0061AE 70 03            [24] 2182 	jnz	01330$
      0061B0 02 63 F7         [24] 2183 	ljmp	00273$
      0061B3                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      0061B3 C0 03            [24] 2186 	push	ar3
      0061B5 C0 04            [24] 2187 	push	ar4
      0061B7 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0061B9 8E 00            [24] 2190 	mov	ar0,r6
      0061BB B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      0061BE E8               [12] 2192 	mov	a,r0
      0061BF 80 01            [24] 2193 	sjmp	01332$
      0061C1                       2194 01331$:
      0061C1 E4               [12] 2195 	clr	a
      0061C2                       2196 01332$:
      0061C2 F5 17            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      0061C4 D0 04            [24] 2198 	pop	ar4
      0061C6 D0 03            [24] 2199 	pop	ar3
      0061C8 E5 17            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      0061CA 60 17            [24] 2201 	jz	00251$
      0061CC EB               [12] 2202 	mov	a,r3
      0061CD 4C               [12] 2203 	orl	a,r4
      0061CE 70 13            [24] 2204 	jnz	00251$
      0061D0 E9               [12] 2205 	mov	a,r1
      0061D1 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      0061D3 90 07 CE         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      0061D6 74 08            [12] 2209 	mov	a,#0x08
      0061D8 F0               [24] 2210 	movx	@dptr,a
      0061D9 E4               [12] 2211 	clr	a
      0061DA A3               [24] 2212 	inc	dptr
      0061DB F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      0061DC 90 07 D0         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      0061DF F0               [24] 2216 	movx	@dptr,a
      0061E0 02 63 67         [24] 2217 	ljmp	00252$
      0061E3                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0061E3 E5 17            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      0061E5 60 27            [24] 2221 	jz	00245$
      0061E7 BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      0061EA BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      0061ED B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      0061F0                       2226 01339$:
      0061F0 50 1C            [24] 2227 	jnc	00245$
      0061F2 E9               [12] 2228 	mov	a,r1
      0061F3 90 B9 1F         [24] 2229 	mov	dptr,#_shared_lengths
      0061F6 93               [24] 2230 	movc	a,@a+dptr
      0061F7 F8               [12] 2231 	mov	r0,a
      0061F8 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      0061FA 90 07 CE         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      0061FD E8               [12] 2235 	mov	a,r0
      0061FE F0               [24] 2236 	movx	@dptr,a
      0061FF E4               [12] 2237 	clr	a
      006200 A3               [24] 2238 	inc	dptr
      006201 F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      006202 E9               [12] 2241 	mov	a,r1
      006203 90 B9 18         [24] 2242 	mov	dptr,#_shared_offsets
      006206 93               [24] 2243 	movc	a,@a+dptr
      006207 90 07 D0         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      00620A F0               [24] 2245 	movx	@dptr,a
      00620B 02 63 67         [24] 2246 	ljmp	00252$
      00620E                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      00620E E5 17            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      006210 60 7A            [24] 2250 	jz	00240$
      006212 BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      006215 BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      006218 E9               [12] 2253 	mov	a,r1
      006219 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      00621B 90 07 66         [24] 2256 	mov	dptr,#_D0SetupLen
      00621E E0               [24] 2257 	movx	a,@dptr
      00621F F8               [12] 2258 	mov	r0,a
      006220 A3               [24] 2259 	inc	dptr
      006221 E0               [24] 2260 	movx	a,@dptr
      006222 F9               [12] 2261 	mov	r1,a
      006223 C3               [12] 2262 	clr	c
      006224 E8               [12] 2263 	mov	a,r0
      006225 94 20            [12] 2264 	subb	a,#0x20
      006227 E9               [12] 2265 	mov	a,r1
      006228 94 00            [12] 2266 	subb	a,#0x00
      00622A 50 0A            [24] 2267 	jnc	00320$
      00622C 90 07 66         [24] 2268 	mov	dptr,#_D0SetupLen
      00622F E0               [24] 2269 	movx	a,@dptr
      006230 F8               [12] 2270 	mov	r0,a
      006231 A3               [24] 2271 	inc	dptr
      006232 E0               [24] 2272 	movx	a,@dptr
      006233 F9               [12] 2273 	mov	r1,a
      006234 80 04            [24] 2274 	sjmp	00321$
      006236                       2275 00320$:
      006236 78 20            [12] 2276 	mov	r0,#0x20
      006238 79 00            [12] 2277 	mov	r1,#0x00
      00623A                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      00623A 75 17 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      00623D                       2281 00293$:
      00623D C0 03            [24] 2282 	push	ar3
      00623F C0 04            [24] 2283 	push	ar4
      006241 AB 17            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      006243 7C 00            [12] 2285 	mov	r4,#0x00
      006245 C3               [12] 2286 	clr	c
      006246 EB               [12] 2287 	mov	a,r3
      006247 98               [12] 2288 	subb	a,r0
      006248 EC               [12] 2289 	mov	a,r4
      006249 99               [12] 2290 	subb	a,r1
      00624A D0 04            [24] 2291 	pop	ar4
      00624C D0 03            [24] 2292 	pop	ar3
      00624E 50 32            [24] 2293 	jnc	00222$
      006250 C0 00            [24] 2294 	push	ar0
      006252 C0 01            [24] 2295 	push	ar1
      006254 85 17 19         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006257 74 10            [12] 2297 	mov	a,#0x10
      006259 24 00            [12] 2298 	add	a, #0x00
      00625B F5 1A            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      00625D A8 17            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      00625F 79 00            [12] 2301 	mov	r1,#0x00
      006261 74 C0            [12] 2302 	mov	a,#0xc0
      006263 28               [12] 2303 	add	a, r0
      006264 F8               [12] 2304 	mov	r0,a
      006265 E4               [12] 2305 	clr	a
      006266 39               [12] 2306 	addc	a, r1
      006267 F9               [12] 2307 	mov	r1,a
      006268 88 82            [24] 2308 	mov	dpl,r0
      00626A 74 10            [12] 2309 	mov	a,#0x10
      00626C 29               [12] 2310 	add	a, r1
      00626D F5 83            [12] 2311 	mov	dph,a
      00626F E0               [24] 2312 	movx	a,@dptr
      006270 85 19 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      006273 85 1A 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006276 F0               [24] 2315 	movx	@dptr,a
      006277 E5 17            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      006279 04               [12] 2317 	inc	a
      00627A F5 17            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      00627C D0 01            [24] 2319 	pop	ar1
      00627E D0 00            [24] 2320 	pop	ar0
      006280 80 BB            [24] 2321 	sjmp	00293$
      006282                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      006282 90 07 CE         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      006285 E4               [12] 2325 	clr	a
      006286 F0               [24] 2326 	movx	@dptr,a
      006287 A3               [24] 2327 	inc	dptr
      006288 F0               [24] 2328 	movx	@dptr,a
      006289 02 63 67         [24] 2329 	ljmp	00252$
      00628C                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      00628C 8D 00            [24] 2332 	mov	ar0,r5
      00628E 8E 01            [24] 2333 	mov	ar1,r6
      006290 B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      006293 B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      006296 EB               [12] 2336 	mov	a,r3
      006297 4C               [12] 2337 	orl	a,r4
      006298 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      00629A 90 07 70         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      00629D E0               [24] 2341 	movx	a,@dptr
      00629E 90 10 00         [24] 2342 	mov	dptr,#0x1000
      0062A1 F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      0062A2 90 07 CE         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      0062A5 E4               [12] 2346 	clr	a
      0062A6 F0               [24] 2347 	movx	@dptr,a
      0062A7 A3               [24] 2348 	inc	dptr
      0062A8 F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      0062A9 90 07 66         [24] 2351 	mov	dptr,#_D0SetupLen
      0062AC 04               [12] 2352 	inc	a
      0062AD F0               [24] 2353 	movx	@dptr,a
      0062AE E4               [12] 2354 	clr	a
      0062AF A3               [24] 2355 	inc	dptr
      0062B0 F0               [24] 2356 	movx	@dptr,a
      0062B1 02 63 67         [24] 2357 	ljmp	00252$
      0062B4                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0062B4 B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      0062B7 B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      0062BA BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      0062BD BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0062C0 C0 03            [24] 2365 	push	ar3
      0062C2 C0 04            [24] 2366 	push	ar4
      0062C4 90 10 00         [24] 2367 	mov	dptr,#0x1000
      0062C7 74 06            [12] 2368 	mov	a,#0x06
      0062C9 F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0062CA 90 07 70         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      0062CD E0               [24] 2372 	movx	a,@dptr
      0062CE 90 10 01         [24] 2373 	mov	dptr,#0x1001
      0062D1 F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      0062D2 90 07 CE         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      0062D5 E4               [12] 2377 	clr	a
      0062D6 F0               [24] 2378 	movx	@dptr,a
      0062D7 A3               [24] 2379 	inc	dptr
      0062D8 F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      0062D9 90 07 66         [24] 2382 	mov	dptr,#_D0SetupLen
      0062DC E0               [24] 2383 	movx	a,@dptr
      0062DD FB               [12] 2384 	mov	r3,a
      0062DE A3               [24] 2385 	inc	dptr
      0062DF E0               [24] 2386 	movx	a,@dptr
      0062E0 FC               [12] 2387 	mov	r4,a
      0062E1 C3               [12] 2388 	clr	c
      0062E2 74 02            [12] 2389 	mov	a,#0x02
      0062E4 9B               [12] 2390 	subb	a,r3
      0062E5 E4               [12] 2391 	clr	a
      0062E6 9C               [12] 2392 	subb	a,r4
      0062E7 D0 04            [24] 2393 	pop	ar4
      0062E9 D0 03            [24] 2394 	pop	ar3
      0062EB 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      0062ED 90 07 66         [24] 2397 	mov	dptr,#_D0SetupLen
      0062F0 74 02            [12] 2398 	mov	a,#0x02
      0062F2 F0               [24] 2399 	movx	@dptr,a
      0062F3 E4               [12] 2400 	clr	a
      0062F4 A3               [24] 2401 	inc	dptr
      0062F5 F0               [24] 2402 	movx	@dptr,a
      0062F6 80 6F            [24] 2403 	sjmp	00252$
      0062F8                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0062F8 B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      0062FB B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      0062FE BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      006301 BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      006304 90 10 00         [24] 2411 	mov	dptr,#0x1000
      006307 74 41            [12] 2412 	mov	a,#0x41
      006309 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      00630A A3               [24] 2415 	inc	dptr
      00630B 74 4B            [12] 2416 	mov	a,#0x4b
      00630D F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      00630E A3               [24] 2419 	inc	dptr
      00630F 74 42            [12] 2420 	mov	a,#0x42
      006311 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      006312 A3               [24] 2423 	inc	dptr
      006313 74 54            [12] 2424 	mov	a,#0x54
      006315 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      006316 A3               [24] 2427 	inc	dptr
      006317 74 01            [12] 2428 	mov	a,#0x01
      006319 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      00631A 90 07 71         [24] 2431 	mov	dptr,#_ak820_boot_stage
      00631D E0               [24] 2432 	movx	a,@dptr
      00631E 90 10 05         [24] 2433 	mov	dptr,#0x1005
      006321 F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006322 90 07 72         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      006325 E0               [24] 2437 	movx	a,@dptr
      006326 90 10 06         [24] 2438 	mov	dptr,#0x1006
      006329 F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      00632A 90 07 6C         [24] 2441 	mov	dptr,#_USB_EnumStatus
      00632D E0               [24] 2442 	movx	a,@dptr
      00632E 60 02            [24] 2443 	jz	00322$
      006330 74 01            [12] 2444 	mov	a,#0x01
      006332                       2445 00322$:
      006332 F9               [12] 2446 	mov	r1,a
      006333 90 07 6D         [24] 2447 	mov	dptr,#_USB_SleepStatus
      006336 E0               [24] 2448 	movx	a,@dptr
      006337 54 02            [12] 2449 	anl	a,#0x02
      006339 F8               [12] 2450 	mov	r0,a
      00633A E9               [12] 2451 	mov	a,r1
      00633B 42 00            [12] 2452 	orl	ar0,a
      00633D 90 10 07         [24] 2453 	mov	dptr,#0x1007
      006340 E8               [12] 2454 	mov	a,r0
      006341 F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      006342 90 07 CE         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      006345 E4               [12] 2458 	clr	a
      006346 F0               [24] 2459 	movx	@dptr,a
      006347 A3               [24] 2460 	inc	dptr
      006348 F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      006349 90 07 66         [24] 2463 	mov	dptr,#_D0SetupLen
      00634C E0               [24] 2464 	movx	a,@dptr
      00634D F8               [12] 2465 	mov	r0,a
      00634E A3               [24] 2466 	inc	dptr
      00634F E0               [24] 2467 	movx	a,@dptr
      006350 F9               [12] 2468 	mov	r1,a
      006351 C3               [12] 2469 	clr	c
      006352 74 08            [12] 2470 	mov	a,#0x08
      006354 98               [12] 2471 	subb	a,r0
      006355 E4               [12] 2472 	clr	a
      006356 99               [12] 2473 	subb	a,r1
      006357 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      006359 90 07 66         [24] 2476 	mov	dptr,#_D0SetupLen
      00635C 74 08            [12] 2477 	mov	a,#0x08
      00635E F0               [24] 2478 	movx	@dptr,a
      00635F E4               [12] 2479 	clr	a
      006360 A3               [24] 2480 	inc	dptr
      006361 F0               [24] 2481 	movx	@dptr,a
      006362 80 03            [24] 2482 	sjmp	00252$
      006364                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      006364 02 5A CD         [24] 2485 	ljmp	_control_stall
      006367                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      006367 90 07 CE         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      00636A E0               [24] 2489 	movx	a,@dptr
      00636B F5 19            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      00636D A3               [24] 2491 	inc	dptr
      00636E E0               [24] 2492 	movx	a,@dptr
      00636F F5 1A            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      006371 E5 19            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      006373 45 1A            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006375 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      006377 90 07 66         [24] 2498 	mov	dptr,#_D0SetupLen
      00637A E0               [24] 2499 	movx	a,@dptr
      00637B F8               [12] 2500 	mov	r0,a
      00637C A3               [24] 2501 	inc	dptr
      00637D E0               [24] 2502 	movx	a,@dptr
      00637E F9               [12] 2503 	mov	r1,a
      00637F C3               [12] 2504 	clr	c
      006380 E5 19            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      006382 98               [12] 2506 	subb	a,r0
      006383 E5 1A            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006385 99               [12] 2508 	subb	a,r1
      006386 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      006388 90 07 66         [24] 2511 	mov	dptr,#_D0SetupLen
      00638B E5 19            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      00638D F0               [24] 2513 	movx	@dptr,a
      00638E E5 1A            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006390 A3               [24] 2515 	inc	dptr
      006391 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      006392                       2518 00559$:
      006392 75 19 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      006395                       2520 00296$:
      006395 90 07 66         [24] 2521 	mov	dptr,#_D0SetupLen
      006398 E0               [24] 2522 	movx	a,@dptr
      006399 F8               [12] 2523 	mov	r0,a
      00639A C3               [12] 2524 	clr	c
      00639B E5 19            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      00639D 98               [12] 2526 	subb	a,r0
      00639E 50 46            [24] 2527 	jnc	00263$
      0063A0 85 19 17         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0063A3 74 10            [12] 2529 	mov	a,#0x10
      0063A5 24 00            [12] 2530 	add	a, #0x00
      0063A7 F5 18            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      0063A9 90 07 D0         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      0063AC E0               [24] 2533 	movx	a,@dptr
      0063AD 25 19            [12] 2534 	add	a, _control_setup_sloc4_1_0
      0063AF 24 96            [12] 2535 	add	a, #_input_snapshot
      0063B1 F5 82            [12] 2536 	mov	dpl,a
      0063B3 E4               [12] 2537 	clr	a
      0063B4 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      0063B6 F5 83            [12] 2539 	mov	dph,a
      0063B8 E0               [24] 2540 	movx	a,@dptr
      0063B9 85 17 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      0063BC 85 18 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0063BF F0               [24] 2543 	movx	@dptr,a
      0063C0 E5 19            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      0063C2 04               [12] 2545 	inc	a
      0063C3 F5 19            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      0063C5 80 CE            [24] 2547 	sjmp	00296$
      0063C7                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0063C7 BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      0063CA BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      0063CD 90 07 66         [24] 2552 	mov	dptr,#_D0SetupLen
      0063D0 E0               [24] 2553 	movx	a,@dptr
      0063D1 F8               [12] 2554 	mov	r0,a
      0063D2 A3               [24] 2555 	inc	dptr
      0063D3 E0               [24] 2556 	movx	a,@dptr
      0063D4 F9               [12] 2557 	mov	r1,a
      0063D5 C3               [12] 2558 	clr	c
      0063D6 74 20            [12] 2559 	mov	a,#0x20
      0063D8 98               [12] 2560 	subb	a,r0
      0063D9 E4               [12] 2561 	clr	a
      0063DA 99               [12] 2562 	subb	a,r1
      0063DB 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      0063DD 90 07 66         [24] 2565 	mov	dptr,#_D0SetupLen
      0063E0 74 20            [12] 2566 	mov	a,#0x20
      0063E2 F0               [24] 2567 	movx	@dptr,a
      0063E3 E4               [12] 2568 	clr	a
      0063E4 A3               [24] 2569 	inc	dptr
      0063E5 F0               [24] 2570 	movx	@dptr,a
      0063E6                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      0063E6 90 07 66         [24] 2573 	mov	dptr,#_D0SetupLen
      0063E9 E0               [24] 2574 	movx	a,@dptr
      0063EA 90 22 08         [24] 2575 	mov	dptr,#0x2208
      0063ED F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      0063EE 90 07 C4         [24] 2578 	mov	dptr,#_control_phase
      0063F1 74 02            [12] 2579 	mov	a,#0x02
      0063F3 F0               [24] 2580 	movx	@dptr,a
      0063F4 02 64 7C         [24] 2581 	ljmp	00291$
      0063F7                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0063F7 EB               [12] 2584 	mov	a,r3
      0063F8 4C               [12] 2585 	orl	a,r4
      0063F9 70 37            [24] 2586 	jnz	00265$
      0063FB 90 07 6B         [24] 2587 	mov	dptr,#_D0UsbConfig
      0063FE E0               [24] 2588 	movx	a,@dptr
      0063FF 60 31            [24] 2589 	jz	00265$
      006401 EA               [12] 2590 	mov	a,r2
      006402 60 2E            [24] 2591 	jz	00265$
      006404 90 07 65         [24] 2592 	mov	dptr,#_D0SetupReqCode
      006407 E0               [24] 2593 	movx	a,@dptr
      006408 FA               [12] 2594 	mov	r2,a
      006409 BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      00640C 30 18 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      00640F 90 07 66         [24] 2597 	mov	dptr,#_D0SetupLen
      006412 E0               [24] 2598 	movx	a,@dptr
      006413 F9               [12] 2599 	mov	r1,a
      006414 A3               [24] 2600 	inc	dptr
      006415 E0               [24] 2601 	movx	a,@dptr
      006416 FA               [12] 2602 	mov	r2,a
      006417 B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      00641A BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      00641D 90 0D B6         [24] 2606 	mov	dptr,#_keyboard_protocol
      006420 E0               [24] 2607 	movx	a,@dptr
      006421 90 10 00         [24] 2608 	mov	dptr,#0x1000
      006424 F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      006425 90 22 08         [24] 2611 	mov	dptr,#0x2208
      006428 74 01            [12] 2612 	mov	a,#0x01
      00642A F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      00642B 90 07 C4         [24] 2615 	mov	dptr,#_control_phase
      00642E 04               [12] 2616 	inc	a
      00642F F0               [24] 2617 	movx	@dptr,a
      006430 80 4A            [24] 2618 	sjmp	00291$
      006432                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      006432 02 5A CD         [24] 2622 	ljmp	_control_stall
      006435                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006435 30 16 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      006438 90 07 6B         [24] 2626 	mov	dptr,#_D0UsbConfig
      00643B E0               [24] 2627 	movx	a,@dptr
      00643C 60 38            [24] 2628 	jz	00284$
      00643E BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      006441 8E 05            [24] 2630 	mov	ar5,r6
      006443 7E 00            [12] 2631 	mov	r6,#0x00
      006445 ED               [12] 2632 	mov	a,r5
      006446 4E               [12] 2633 	orl	a,r6
      006447 70 2D            [24] 2634 	jnz	00284$
      006449 90 07 66         [24] 2635 	mov	dptr,#_D0SetupLen
      00644C E0               [24] 2636 	movx	a,@dptr
      00644D FE               [12] 2637 	mov	r6,a
      00644E A3               [24] 2638 	inc	dptr
      00644F E0               [24] 2639 	movx	a,@dptr
      006450 FF               [12] 2640 	mov	r7,a
      006451 BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      006454 BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006457 EB               [12] 2644 	mov	a,r3
      006458 4C               [12] 2645 	orl	a,r4
      006459 70 07            [24] 2646 	jnz	00324$
      00645B 90 06 43         [24] 2647 	mov	dptr,#_keyboard_idle
      00645E E0               [24] 2648 	movx	a,@dptr
      00645F FF               [12] 2649 	mov	r7,a
      006460 80 02            [24] 2650 	sjmp	00325$
      006462                       2651 00324$:
      006462 7F 00            [12] 2652 	mov	r7,#0x00
      006464                       2653 00325$:
      006464 90 10 00         [24] 2654 	mov	dptr,#0x1000
      006467 EF               [12] 2655 	mov	a,r7
      006468 F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      006469 90 22 08         [24] 2658 	mov	dptr,#0x2208
      00646C 74 01            [12] 2659 	mov	a,#0x01
      00646E F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      00646F 90 07 C4         [24] 2662 	mov	dptr,#_control_phase
      006472 04               [12] 2663 	inc	a
      006473 F0               [24] 2664 	movx	@dptr,a
      006474 80 06            [24] 2665 	sjmp	00291$
      006476                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      006476 02 5A CD         [24] 2669 	ljmp	_control_stall
      006479                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      006479 02 5A CD         [24] 2672 	ljmp	_control_stall
      00647C                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      00647C 90 22 00         [24] 2675 	mov	dptr,#0x2200
      00647F 74 C0            [12] 2676 	mov	a,#0xc0
      006481 F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      006482 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      006483                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006483 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      006486 E0               [24] 2692 	movx	a,@dptr
      006487 20 E6 01         [24] 2693 	jb	acc.6,00102$
      00648A 22               [24] 2694 	ret
      00648B                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      00648B 90 07 C4         [24] 2697 	mov	dptr,#_control_phase
      00648E E0               [24] 2698 	movx	a,@dptr
      00648F FF               [12] 2699 	mov	r7,a
      006490 BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      006493 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      006496 E0               [24] 2702 	movx	a,@dptr
      006497 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      006499 90 07 C4         [24] 2705 	mov	dptr,#_control_phase
      00649C E4               [12] 2706 	clr	a
      00649D F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00649E 90 22 00         [24] 2709 	mov	dptr,#0x2200
      0064A1 74 02            [12] 2710 	mov	a,#0x02
      0064A3 F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      0064A4 22               [24] 2713 	ret
      0064A5                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      0064A5 BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      0064A8 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      0064AB E0               [24] 2718 	movx	a,@dptr
      0064AC FF               [12] 2719 	mov	r7,a
      0064AD 90 07 66         [24] 2720 	mov	dptr,#_D0SetupLen
      0064B0 E0               [24] 2721 	movx	a,@dptr
      0064B1 FD               [12] 2722 	mov	r5,a
      0064B2 A3               [24] 2723 	inc	dptr
      0064B3 E0               [24] 2724 	movx	a,@dptr
      0064B4 FE               [12] 2725 	mov	r6,a
      0064B5 7C 00            [12] 2726 	mov	r4,#0x00
      0064B7 EF               [12] 2727 	mov	a,r7
      0064B8 B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      0064BB EC               [12] 2729 	mov	a,r4
      0064BC B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      0064BF 80 03            [24] 2731 	sjmp	00107$
      0064C1                       2732 00209$:
      0064C1                       2733 00106$:
      0064C1 02 5A CD         [24] 2734 	ljmp	_control_stall
      0064C4                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0064C4 90 07 C5         [24] 2737 	mov	dptr,#_output_kind
      0064C7 E0               [24] 2738 	movx	a,@dptr
      0064C8 FF               [12] 2739 	mov	r7,a
      0064C9 BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      0064CC 90 07 73         [24] 2741 	mov	dptr,#_raw_state
      0064CF E0               [24] 2742 	movx	a,@dptr
      0064D0 FE               [12] 2743 	mov	r6,a
      0064D1 BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0064D4 7E 00            [12] 2746 	mov	r6,#0x00
      0064D6                       2747 00121$:
      0064D6 EE               [12] 2748 	mov	a,r6
      0064D7 24 74            [12] 2749 	add	a, #_raw_buffer
      0064D9 FC               [12] 2750 	mov	r4,a
      0064DA E4               [12] 2751 	clr	a
      0064DB 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      0064DD FD               [12] 2753 	mov	r5,a
      0064DE 8E 82            [24] 2754 	mov	dpl,r6
      0064E0 74 10            [12] 2755 	mov	a,#0x10
      0064E2 24 00            [12] 2756 	add	a, #0x00
      0064E4 F5 83            [12] 2757 	mov	dph,a
      0064E6 E0               [24] 2758 	movx	a,@dptr
      0064E7 8C 82            [24] 2759 	mov	dpl,r4
      0064E9 8D 83            [24] 2760 	mov	dph,r5
      0064EB F0               [24] 2761 	movx	@dptr,a
      0064EC 0E               [12] 2762 	inc	r6
      0064ED BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      0064F0                       2764 00214$:
      0064F0 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      0064F2 90 07 73         [24] 2767 	mov	dptr,#_raw_state
      0064F5 74 02            [12] 2768 	mov	a,#0x02
      0064F7 F0               [24] 2769 	movx	@dptr,a
      0064F8 80 2B            [24] 2770 	sjmp	00119$
      0064FA                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      0064FA BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      0064FD 90 10 00         [24] 2775 	mov	dptr,#0x1000
      006500 E0               [24] 2776 	movx	a,@dptr
      006501 90 07 70         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      006504 F0               [24] 2778 	movx	@dptr,a
      006505 80 1E            [24] 2779 	sjmp	00119$
      006507                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006507 BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      00650A 90 10 00         [24] 2783 	mov	dptr,#0x1000
      00650D E0               [24] 2784 	movx	a,@dptr
      00650E FF               [12] 2785 	mov	r7,a
      00650F 90 07 C6         [24] 2786 	mov	dptr,#_output_report_id
      006512 E0               [24] 2787 	movx	a,@dptr
      006513 FE               [12] 2788 	mov	r6,a
      006514 EF               [12] 2789 	mov	a,r7
      006515 B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      006518 90 10 01         [24] 2792 	mov	dptr,#0x1001
      00651B E0               [24] 2793 	movx	a,@dptr
      00651C 90 07 70         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      00651F F0               [24] 2795 	movx	@dptr,a
      006520 80 03            [24] 2796 	sjmp	00119$
      006522                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      006522 02 5A CD         [24] 2799 	ljmp	_control_stall
      006525                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      006525 90 07 C5         [24] 2802 	mov	dptr,#_output_kind
      006528 E4               [12] 2803 	clr	a
      006529 F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      00652A 90 07 66         [24] 2806 	mov	dptr,#_D0SetupLen
      00652D F0               [24] 2807 	movx	@dptr,a
      00652E A3               [24] 2808 	inc	dptr
      00652F F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      006530 90 07 C4         [24] 2811 	mov	dptr,#_control_phase
      006533 74 03            [12] 2812 	mov	a,#0x03
      006535 F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      006536 90 22 08         [24] 2815 	mov	dptr,#0x2208
      006539 E4               [12] 2816 	clr	a
      00653A F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      00653B F5 82            [12] 2819 	mov	dpl,a
      00653D 74 48            [12] 2820 	mov	a,#0x48
      00653F F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      006540 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      006541                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      006541 90 07 C4         [24] 2833 	mov	dptr,#_control_phase
      006544 E0               [24] 2834 	movx	a,@dptr
      006545 FF               [12] 2835 	mov	r7,a
      006546 BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      006549 90 07 66         [24] 2838 	mov	dptr,#_D0SetupLen
      00654C E0               [24] 2839 	movx	a,@dptr
      00654D FD               [12] 2840 	mov	r5,a
      00654E A3               [24] 2841 	inc	dptr
      00654F E0               [24] 2842 	movx	a,@dptr
      006550 4D               [12] 2843 	orl	a,r5
      006551 70 06            [24] 2844 	jnz	00101$
      006553 90 07 C7         [24] 2845 	mov	dptr,#_control_zlp
      006556 E0               [24] 2846 	movx	a,@dptr
      006557 60 0A            [24] 2847 	jz	00102$
      006559                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006559 90 22 00         [24] 2850 	mov	dptr,#0x2200
      00655C E0               [24] 2851 	movx	a,@dptr
      00655D 64 40            [12] 2852 	xrl	a,#0x40
      00655F F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      006560 02 5A EF         [24] 2856 	ljmp	_control_next
      006563                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      006563 90 07 C4         [24] 2859 	mov	dptr,#_control_phase
      006566 74 02            [12] 2860 	mov	a,#0x02
      006568 F0               [24] 2861 	movx	@dptr,a
      006569 80 18            [24] 2862 	sjmp	00110$
      00656B                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      00656B BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      00656E 90 07 65         [24] 2867 	mov	dptr,#_D0SetupReqCode
      006571 E0               [24] 2868 	movx	a,@dptr
      006572 FF               [12] 2869 	mov	r7,a
      006573 BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      006576 90 07 66         [24] 2871 	mov	dptr,#_D0SetupLen
      006579 E0               [24] 2872 	movx	a,@dptr
      00657A 90 22 07         [24] 2873 	mov	dptr,#0x2207
      00657D F0               [24] 2874 	movx	@dptr,a
      00657E                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      00657E 90 07 C4         [24] 2877 	mov	dptr,#_control_phase
      006581 E4               [12] 2878 	clr	a
      006582 F0               [24] 2879 	movx	@dptr,a
      006583                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006583 90 22 00         [24] 2882 	mov	dptr,#0x2200
      006586 74 82            [12] 2883 	mov	a,#0x82
      006588 F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      006589 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      00658A                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      00658A                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      00658A 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      00658D E0               [24] 2902 	movx	a,@dptr
      00658E 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      006591 12 5A 76         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      006594 90 22 07         [24] 2907 	mov	dptr,#0x2207
      006597 E4               [12] 2908 	clr	a
      006598 F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006599 90 07 6D         [24] 2911 	mov	dptr,#_USB_SleepStatus
      00659C F0               [24] 2912 	movx	@dptr,a
      00659D 90 07 6C         [24] 2913 	mov	dptr,#_USB_EnumStatus
      0065A0 F0               [24] 2914 	movx	@dptr,a
      0065A1 90 07 6B         [24] 2915 	mov	dptr,#_D0UsbConfig
      0065A4 F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      0065A5 90 07 70         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      0065A8 F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      0065A9 90 0D B6         [24] 2921 	mov	dptr,#_keyboard_protocol
      0065AC 04               [12] 2922 	inc	a
      0065AD F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      0065AE 90 06 43         [24] 2925 	mov	dptr,#_keyboard_idle
      0065B1 E4               [12] 2926 	clr	a
      0065B2 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      0065B3 90 07 95         [24] 2929 	mov	dptr,#_keyboard_reset
      0065B6 04               [12] 2930 	inc	a
      0065B7 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      0065B8 90 07 65         [24] 2933 	mov	dptr,#_D0SetupReqCode
      0065BB 74 FF            [12] 2934 	mov	a,#0xff
      0065BD F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      0065BE 90 07 66         [24] 2937 	mov	dptr,#_D0SetupLen
      0065C1 E4               [12] 2938 	clr	a
      0065C2 F0               [24] 2939 	movx	@dptr,a
      0065C3 A3               [24] 2940 	inc	dptr
      0065C4 F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      0065C5 90 07 C4         [24] 2943 	mov	dptr,#_control_phase
      0065C8 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0065C9 90 22 00         [24] 2946 	mov	dptr,#0x2200
      0065CC 74 02            [12] 2947 	mov	a,#0x02
      0065CE F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      0065CF 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      0065D2 E4               [12] 2951 	clr	a
      0065D3 F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      0065D4 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      0065D7 04               [12] 2955 	inc	a
      0065D8 F0               [24] 2956 	movx	@dptr,a
      0065D9 02 66 6F         [24] 2957 	ljmp	00130$
      0065DC                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      0065DC 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      0065DF E0               [24] 2961 	movx	a,@dptr
      0065E0 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      0065E3 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      0065E6 E0               [24] 2965 	movx	a,@dptr
      0065E7 FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      0065E8 74 07            [12] 2968 	mov	a,#0x07
      0065EA 5F               [12] 2969 	anl	a,r7
      0065EB FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      0065EC EF               [12] 2972 	mov	a,r7
      0065ED 54 18            [12] 2973 	anl	a,#0x18
      0065EF 70 08            [24] 2974 	jnz	00115$
      0065F1 EE               [12] 2975 	mov	a,r6
      0065F2 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      0065F4 12 64 83         [24] 2978 	lcall	_control_out
      0065F7 80 43            [24] 2979 	sjmp	00116$
      0065F9                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      0065F9 8F 05            [24] 2982 	mov	ar5,r7
      0065FB 74 18            [12] 2983 	mov	a,#0x18
      0065FD 5D               [12] 2984 	anl	a,r5
      0065FE FC               [12] 2985 	mov	r4,a
      0065FF BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      006602 EE               [12] 2988 	mov	a,r6
      006603 70 05            [24] 2989 	jnz	00106$
      006605 12 65 41         [24] 2990 	lcall	_control_in
      006608 80 32            [24] 2991 	sjmp	00116$
      00660A                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      00660A EE               [12] 2994 	mov	a,r6
      00660B 24 FC            [12] 2995 	add	a,#0xff - 0x03
      00660D 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      00660F 8E 04            [24] 2999 	mov	ar4,r6
      006611 7B 00            [12] 3000 	mov	r3,#0x00
      006613 74 22            [12] 3001 	mov	a,#0x22
      006615 2B               [12] 3002 	add	a, r3
      006616 FB               [12] 3003 	mov	r3,a
      006617 8C 82            [24] 3004 	mov	dpl,r4
      006619 8B 83            [24] 3005 	mov	dph,r3
      00661B E0               [24] 3006 	movx	a,@dptr
      00661C FA               [12] 3007 	mov	r2,a
      00661D 74 FC            [12] 3008 	mov	a,#0xfc
      00661F 5A               [12] 3009 	anl	a,r2
      006620 44 02            [12] 3010 	orl	a,#0x02
      006622 8C 82            [24] 3011 	mov	dpl,r4
      006624 8B 83            [24] 3012 	mov	dph,r3
      006626 F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006627 BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      00662A 12 5A 59         [24] 3016 	lcall	_raw_complete
      00662D 80 0D            [24] 3017 	sjmp	00116$
      00662F                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      00662F 53 05 18         [24] 3020 	anl	ar5,#0x18
      006632 BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      006635 EF               [12] 3022 	mov	a,r7
      006636 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      006639 12 5C E6         [24] 3025 	lcall	_control_setup
      00663C                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      00663C 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      00663F E4               [12] 3029 	clr	a
      006640 F0               [24] 3030 	movx	@dptr,a
      006641 80 2C            [24] 3031 	sjmp	00130$
      006643                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      006643 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      006646 E0               [24] 3035 	movx	a,@dptr
      006647 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      00664A 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      00664D E0               [24] 3039 	movx	a,@dptr
      00664E 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      006651 90 07 6D         [24] 3041 	mov	dptr,#_USB_SleepStatus
      006654 E0               [24] 3042 	movx	a,@dptr
      006655 43 E0 02         [24] 3043 	orl	acc,#0x02
      006658 F0               [24] 3044 	movx	@dptr,a
      006659 80 0E            [24] 3045 	sjmp	00120$
      00665B                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      00665B 90 07 6D         [24] 3048 	mov	dptr,#_USB_SleepStatus
      00665E E0               [24] 3049 	movx	a,@dptr
      00665F 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      006662 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      006663 90 07 95         [24] 3053 	mov	dptr,#_keyboard_reset
      006666 74 01            [12] 3054 	mov	a,#0x01
      006668 F0               [24] 3055 	movx	@dptr,a
      006669                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006669 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      00666C 74 04            [12] 3059 	mov	a,#0x04
      00666E F0               [24] 3060 	movx	@dptr,a
      00666F                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      00666F 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      006672 E0               [24] 3064 	movx	a,@dptr
      006673 54 25            [12] 3065 	anl	a,#0x25
      006675 60 03            [24] 3066 	jz	00242$
      006677 02 65 8A         [24] 3067 	ljmp	00129$
      00667A                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      00667A 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      00667B                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3080 ;	assignBit
      00667B C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      00667D 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      006680 E4               [12] 3084 	clr	a
      006681 F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      006682 90 07 73         [24] 3087 	mov	dptr,#_raw_state
      006685 F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      006686 12 5A 76         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006689 90 07 6D         [24] 3092 	mov	dptr,#_USB_SleepStatus
      00668C E4               [12] 3093 	clr	a
      00668D F0               [24] 3094 	movx	@dptr,a
      00668E 90 07 6C         [24] 3095 	mov	dptr,#_USB_EnumStatus
      006691 F0               [24] 3096 	movx	@dptr,a
      006692 90 07 6B         [24] 3097 	mov	dptr,#_D0UsbConfig
      006695 F0               [24] 3098 	movx	@dptr,a
      006696 90 22 07         [24] 3099 	mov	dptr,#0x2207
      006699 F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      00669A 90 07 6E         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      00669D F0               [24] 3103 	movx	@dptr,a
      00669E 90 07 6F         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      0066A1 F0               [24] 3105 	movx	@dptr,a
      0066A2 90 07 70         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      0066A5 F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      0066A6 90 0D B6         [24] 3109 	mov	dptr,#_keyboard_protocol
      0066A9 04               [12] 3110 	inc	a
      0066AA F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      0066AB 90 06 43         [24] 3113 	mov	dptr,#_keyboard_idle
      0066AE E4               [12] 3114 	clr	a
      0066AF F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      0066B0 90 07 95         [24] 3117 	mov	dptr,#_keyboard_reset
      0066B3 F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      0066B4 90 07 C4         [24] 3120 	mov	dptr,#_control_phase
      0066B7 F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      0066B8 90 07 65         [24] 3123 	mov	dptr,#_D0SetupReqCode
      0066BB 14               [12] 3124 	dec	a
      0066BC F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      0066BD 90 07 66         [24] 3127 	mov	dptr,#_D0SetupLen
      0066C0 E4               [12] 3128 	clr	a
      0066C1 F0               [24] 3129 	movx	@dptr,a
      0066C2 A3               [24] 3130 	inc	dptr
      0066C3 F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0066C4 90 22 00         [24] 3133 	mov	dptr,#0x2200
      0066C7 74 02            [12] 3134 	mov	a,#0x02
      0066C9 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      0066CA 90 22 37         [24] 3137 	mov	dptr,#0x2237
      0066CD 74 7F            [12] 3138 	mov	a,#0x7f
      0066CF F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      0066D0 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      0066D3 74 FF            [12] 3142 	mov	a,#0xff
      0066D5 F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      0066D6 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      0066D9 74 07            [12] 3146 	mov	a,#0x07
      0066DB F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      0066DC A3               [24] 3149 	inc	dptr
      0066DD 74 80            [12] 3150 	mov	a,#0x80
      0066DF F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3153 ;	assignBit
      0066E0 D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      0066E2 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      0066E3                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      0066E3 90 07 6D         [24] 3169 	mov	dptr,#_USB_SleepStatus
      0066E6 E0               [24] 3170 	movx	a,@dptr
      0066E7 FF               [12] 3171 	mov	r7,a
      0066E8 BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      0066EB 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      0066EE E0               [24] 3175 	movx	a,@dptr
      0066EF FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      0066F0 E0               [24] 3178 	movx	a,@dptr
      0066F1 FE               [12] 3179 	mov	r6,a
      0066F2 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      0066F5 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      0066F8 EE               [12] 3182 	mov	a,r6
      0066F9 F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      0066FA 7E 0A            [12] 3185 	mov	r6,#0x0a
      0066FC                       3186 00108$:
      0066FC EE               [12] 3187 	mov	a,r6
      0066FD 60 09            [24] 3188 	jz	00105$
      0066FF 90 00 01         [24] 3189 	mov	dptr,#0x0001
      006702 12 58 BD         [24] 3190 	lcall	_mDelaymS
      006705 1E               [12] 3191 	dec	r6
      006706 80 F4            [24] 3192 	sjmp	00108$
      006708                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      006708 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      00670B EF               [12] 3196 	mov	a,r7
      00670C F0               [24] 3197 	movx	@dptr,a
      00670D                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      00670D 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      00670E                       3220 _ak820_usb_send:
      00670E E5 82            [12] 3221 	mov	a,dpl
      006710 90 07 D4         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006713 F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      006714 90 07 D5         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006717 74 2E            [12] 3226 	mov	a,#0x2e
      006719 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      00671A 90 07 D4         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00671D E0               [24] 3230 	movx	a,@dptr
      00671E FF               [12] 3231 	mov	r7,a
      00671F BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      006722                       3233 00306$:
      006722 40 14            [24] 3234 	jc	00101$
      006724 EF               [12] 3235 	mov	a,r7
      006725 24 FC            [12] 3236 	add	a,#0xff - 0x03
      006727 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      006729 90 07 D3         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      00672C E0               [24] 3240 	movx	a,@dptr
      00672D FE               [12] 3241 	mov  r6,a
      00672E 24 BF            [12] 3242 	add	a,#0xff - 0x40
      006730 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      006732 90 07 6C         [24] 3245 	mov	dptr,#_USB_EnumStatus
      006735 E0               [24] 3246 	movx	a,@dptr
      006736 70 04            [24] 3247 	jnz	00102$
      006738                       3248 00101$:
      006738 75 82 00         [24] 3249 	mov	dpl, #0x00
      00673B 22               [24] 3250 	ret
      00673C                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      00673C BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      00673F BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      006742 80 04            [24] 3256 	sjmp	00107$
      006744                       3257 00313$:
      006744 75 82 00         [24] 3258 	mov	dpl, #0x00
      006747 22               [24] 3259 	ret
      006748                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      006748 90 07 D5         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      00674B E4               [12] 3263 	clr	a
      00674C F0               [24] 3264 	movx	@dptr,a
      00674D 80 3C            [24] 3265 	sjmp	00119$
      00674F                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      00674F BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      006752 90 07 D1         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      006755 E0               [24] 3271 	movx	a,@dptr
      006756 FD               [12] 3272 	mov	r5,a
      006757 A3               [24] 3273 	inc	dptr
      006758 E0               [24] 3274 	movx	a,@dptr
      006759 FF               [12] 3275 	mov	r7,a
      00675A 8D 82            [24] 3276 	mov	dpl,r5
      00675C 8F 83            [24] 3277 	mov	dph,r7
      00675E E0               [24] 3278 	movx	a,@dptr
      00675F FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006760 BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      006763                       3282 00316$:
      006763 50 0E            [24] 3283 	jnc	00108$
      006765 EF               [12] 3284 	mov	a,r7
      006766 90 B9 1F         [24] 3285 	mov	dptr,#_shared_lengths
      006769 93               [24] 3286 	movc	a,@a+dptr
      00676A FD               [12] 3287 	mov	r5,a
      00676B 60 06            [24] 3288 	jz	00108$
      00676D EE               [12] 3289 	mov	a,r6
      00676E B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      006771 80 04            [24] 3291 	sjmp	00109$
      006773                       3292 00319$:
      006773                       3293 00108$:
      006773 75 82 00         [24] 3294 	mov	dpl, #0x00
      006776 22               [24] 3295 	ret
      006777                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006777 EF               [12] 3298 	mov	a,r7
      006778 90 B9 18         [24] 3299 	mov	dptr,#_shared_offsets
      00677B 93               [24] 3300 	movc	a,@a+dptr
      00677C 90 07 D5         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      00677F F0               [24] 3302 	movx	@dptr,a
      006780 80 09            [24] 3303 	sjmp	00119$
      006782                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      006782 BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      006785 80 04            [24] 3307 	sjmp	00119$
      006787                       3308 00320$:
      006787 75 82 00         [24] 3309 	mov	dpl, #0x00
      00678A 22               [24] 3310 	ret
      00678B                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      00678B 90 07 6D         [24] 3313 	mov	dptr,#_USB_SleepStatus
      00678E E0               [24] 3314 	movx	a,@dptr
      00678F 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      006792 12 66 E3         [24] 3316 	lcall	_USB_WakeUp_PC
      006795 75 82 00         [24] 3317 	mov	dpl, #0x00
      006798 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006799                       3320 00184$:
      006799 7F FA            [12] 3321 	mov	r7,#0xfa
      00679B                       3322 00127$:
      00679B 90 07 D4         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00679E E0               [24] 3324 	movx	a,@dptr
      00679F FC               [12] 3325 	mov	r4,a
      0067A0 7D 00            [12] 3326 	mov	r5,#0x00
      0067A2 8C 02            [24] 3327 	mov	ar2,r4
      0067A4 74 22            [12] 3328 	mov	a,#0x22
      0067A6 2D               [12] 3329 	add	a, r5
      0067A7 FB               [12] 3330 	mov	r3,a
      0067A8 8A 82            [24] 3331 	mov	dpl,r2
      0067AA 8B 83            [24] 3332 	mov	dph,r3
      0067AC E0               [24] 3333 	movx	a,@dptr
      0067AD 54 03            [12] 3334 	anl	a,#0x03
      0067AF 70 14            [24] 3335 	jnz	00129$
      0067B1 8F 03            [24] 3336 	mov	ar3,r7
      0067B3 1F               [12] 3337 	dec	r7
      0067B4 EB               [12] 3338 	mov	a,r3
      0067B5 60 0E            [24] 3339 	jz	00129$
      0067B7 7B 28            [12] 3340 	mov	r3,#0x28
      0067B9                       3341 00141$:
      0067B9 EB               [12] 3342 	mov	a,r3
      0067BA 60 DF            [24] 3343 	jz	00127$
      0067BC 90 00 01         [24] 3344 	mov	dptr,#0x0001
      0067BF 12 58 79         [24] 3345 	lcall	_mDelayuS
      0067C2 1B               [12] 3346 	dec	r3
      0067C3 80 F4            [24] 3347 	sjmp	00141$
      0067C5                       3348 00129$:
                                   3349 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      0067C5 A2 AF            [12] 3350 	mov	c,_EA
      0067C7 E4               [12] 3351 	clr	a
      0067C8 33               [12] 3352 	rlc	a
      0067C9 FF               [12] 3353 	mov	r7,a
                                   3354 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3355 ;	assignBit
      0067CA C2 AF            [12] 3356 	clr	_EA
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      0067CC 90 07 6C         [24] 3358 	mov	dptr,#_USB_EnumStatus
      0067CF E0               [24] 3359 	movx	a,@dptr
      0067D0 60 25            [24] 3360 	jz	00130$
      0067D2 90 07 D4         [24] 3361 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0067D5 E0               [24] 3362 	movx	a,@dptr
      0067D6 FB               [12] 3363 	mov	r3,a
      0067D7 F9               [12] 3364 	mov	r1,a
      0067D8 7A 00            [12] 3365 	mov	r2,#0x00
      0067DA 74 22            [12] 3366 	mov	a,#0x22
      0067DC 2A               [12] 3367 	add	a, r2
      0067DD FA               [12] 3368 	mov	r2,a
      0067DE 89 82            [24] 3369 	mov	dpl,r1
      0067E0 8A 83            [24] 3370 	mov	dph,r2
      0067E2 E0               [24] 3371 	movx	a,@dptr
      0067E3 FA               [12] 3372 	mov	r2,a
      0067E4 53 02 03         [24] 3373 	anl	ar2,#0x03
      0067E7 BA 02 0D         [24] 3374 	cjne	r2,#0x02,00130$
                                   3375 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      0067EA BB 03 13         [24] 3376 	cjne	r3,#0x03,00192$
      0067ED 90 07 73         [24] 3377 	mov	dptr,#_raw_state
      0067F0 E0               [24] 3378 	movx	a,@dptr
      0067F1 FB               [12] 3379 	mov	r3,a
      0067F2 BB 03 02         [24] 3380 	cjne	r3,#0x03,00331$
      0067F5 80 09            [24] 3381 	sjmp	00192$
      0067F7                       3382 00331$:
      0067F7                       3383 00130$:
                                   3384 ;	assignBit
      0067F7 EF               [12] 3385 	mov	a,r7
      0067F8 24 FF            [12] 3386 	add	a,#0xff
      0067FA 92 AF            [24] 3387 	mov	_EA,c
      0067FC 75 82 00         [24] 3388 	mov	dpl, #0x00
      0067FF 22               [24] 3389 	ret
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006800                       3391 00192$:
      006800 7B 00            [12] 3392 	mov	r3,#0x00
      006802                       3393 00144$:
      006802 C3               [12] 3394 	clr	c
      006803 EB               [12] 3395 	mov	a,r3
      006804 9E               [12] 3396 	subb	a,r6
      006805 50 67            [24] 3397 	jnc	00137$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006807 C0 07            [24] 3399 	push	ar7
      006809 90 07 D4         [24] 3400 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00680C E0               [24] 3401 	movx	a,@dptr
      00680D F9               [12] 3402 	mov	r1,a
      00680E E4               [12] 3403 	clr	a
      00680F C3               [12] 3404 	clr	c
      006810 C9               [12] 3405 	xch	a,r1
      006811 13               [12] 3406 	rrc	a
      006812 C9               [12] 3407 	xch	a,r1
      006813 13               [12] 3408 	rrc	a
      006814 A2 E0            [12] 3409 	mov	c,acc.0
      006816 C9               [12] 3410 	xch	a,r1
      006817 13               [12] 3411 	rrc	a
      006818 C9               [12] 3412 	xch	a,r1
      006819 13               [12] 3413 	rrc	a
      00681A C9               [12] 3414 	xch	a,r1
      00681B FA               [12] 3415 	mov	r2,a
      00681C 8B 00            [24] 3416 	mov	ar0,r3
      00681E 7F 00            [12] 3417 	mov	r7,#0x00
      006820 E8               [12] 3418 	mov	a,r0
      006821 29               [12] 3419 	add	a, r1
      006822 F9               [12] 3420 	mov	r1,a
      006823 EF               [12] 3421 	mov	a,r7
      006824 3A               [12] 3422 	addc	a, r2
      006825 24 10            [12] 3423 	add	a,#0x10
      006827 FA               [12] 3424 	mov	r2,a
      006828 90 07 D1         [24] 3425 	mov	dptr,#_ak820_usb_send_PARM_2
      00682B E0               [24] 3426 	movx	a,@dptr
      00682C F8               [12] 3427 	mov	r0,a
      00682D A3               [24] 3428 	inc	dptr
      00682E E0               [24] 3429 	movx	a,@dptr
      00682F FF               [12] 3430 	mov	r7,a
      006830 EB               [12] 3431 	mov	a,r3
      006831 28               [12] 3432 	add	a, r0
      006832 F5 1B            [12] 3433 	mov	_ak820_usb_send_sloc0_1_0,a
      006834 E4               [12] 3434 	clr	a
      006835 3F               [12] 3435 	addc	a, r7
      006836 F5 1C            [12] 3436 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006838 85 1B 82         [24] 3437 	mov	dpl,_ak820_usb_send_sloc0_1_0
      00683B 85 1C 83         [24] 3438 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      00683E E0               [24] 3439 	movx	a,@dptr
      00683F 89 82            [24] 3440 	mov	dpl,r1
      006841 8A 83            [24] 3441 	mov	dph,r2
      006843 F0               [24] 3442 	movx	@dptr,a
                                   3443 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006844 90 07 D5         [24] 3444 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006847 E0               [24] 3445 	movx	a,@dptr
      006848 F5 1D            [12] 3446 	mov	_ak820_usb_send_sloc1_1_0,a
      00684A 74 2E            [12] 3447 	mov	a,#0x2e
      00684C B5 1D 04         [24] 3448 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      00684F D0 07            [24] 3449 	pop	ar7
      006851 80 18            [24] 3450 	sjmp	00145$
      006853                       3451 00333$:
      006853 D0 07            [24] 3452 	pop	ar7
      006855 EB               [12] 3453 	mov	a,r3
      006856 25 1D            [12] 3454 	add	a, _ak820_usb_send_sloc1_1_0
      006858 24 96            [12] 3455 	add	a, #_input_snapshot
      00685A F9               [12] 3456 	mov	r1,a
      00685B E4               [12] 3457 	clr	a
      00685C 34 07            [12] 3458 	addc	a,#(_input_snapshot >> 8)
      00685E FA               [12] 3459 	mov	r2,a
      00685F 85 1B 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006862 85 1C 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006865 E0               [24] 3462 	movx	a,@dptr
      006866 89 82            [24] 3463 	mov	dpl,r1
      006868 8A 83            [24] 3464 	mov	dph,r2
      00686A F0               [24] 3465 	movx	@dptr,a
      00686B                       3466 00145$:
                                   3467 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      00686B 0B               [12] 3468 	inc	r3
      00686C 80 94            [24] 3469 	sjmp	00144$
      00686E                       3470 00137$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      00686E 90 07 D4         [24] 3472 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006871 E0               [24] 3473 	movx	a,@dptr
      006872 FB               [12] 3474 	mov	r3,a
      006873 F9               [12] 3475 	mov	r1,a
      006874 7A 00            [12] 3476 	mov	r2,#0x00
      006876 74 08            [12] 3477 	mov	a,#0x08
      006878 29               [12] 3478 	add	a, r1
      006879 F9               [12] 3479 	mov	r1,a
      00687A 74 22            [12] 3480 	mov	a,#0x22
      00687C 3A               [12] 3481 	addc	a, r2
      00687D FA               [12] 3482 	mov	r2,a
      00687E 89 82            [24] 3483 	mov	dpl,r1
      006880 8A 83            [24] 3484 	mov	dph,r2
      006882 EE               [12] 3485 	mov	a,r6
      006883 F0               [24] 3486 	movx	@dptr,a
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006884 BB 03 06         [24] 3488 	cjne	r3,#0x03,00139$
      006887 90 07 73         [24] 3489 	mov	dptr,#_raw_state
      00688A 74 04            [12] 3490 	mov	a,#0x04
      00688C F0               [24] 3491 	movx	@dptr,a
      00688D                       3492 00139$:
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      00688D 74 22            [12] 3494 	mov	a,#0x22
      00688F 2D               [12] 3495 	add	a, r5
      006890 FD               [12] 3496 	mov	r5,a
      006891 8C 82            [24] 3497 	mov	dpl,r4
      006893 8D 83            [24] 3498 	mov	dph,r5
      006895 E0               [24] 3499 	movx	a,@dptr
      006896 FE               [12] 3500 	mov	r6,a
      006897 53 06 FC         [24] 3501 	anl	ar6,#0xfc
      00689A 8C 82            [24] 3502 	mov	dpl,r4
      00689C 8D 83            [24] 3503 	mov	dph,r5
      00689E EE               [12] 3504 	mov	a,r6
      00689F F0               [24] 3505 	movx	@dptr,a
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3507 ;	assignBit
      0068A0 EF               [12] 3508 	mov	a,r7
      0068A1 24 FF            [12] 3509 	add	a,#0xff
      0068A3 92 AF            [24] 3510 	mov	_EA,c
                                   3511 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      0068A5 75 82 01         [24] 3512 	mov	dpl, #0x01
                                   3513 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      0068A8 22               [24] 3514 	ret
                                   3515 ;------------------------------------------------------------
                                   3516 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3517 ;------------------------------------------------------------
                                   3518 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3519 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3520 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3521 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3522 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3523 ;------------------------------------------------------------
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3525 ;	-----------------------------------------
                                   3526 ;	 function ak820_usb_try_send
                                   3527 ;	-----------------------------------------
      0068A9                       3528 _ak820_usb_try_send:
      0068A9 E5 82            [12] 3529 	mov	a,dpl
      0068AB 90 07 D9         [24] 3530 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      0068AE F0               [24] 3531 	movx	@dptr,a
                                   3532 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3533 ;	assignBit
      0068AF A2 AF            [12] 3534 	mov	c,_EA
      0068B1 92 1C            [24] 3535 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      0068B3 90 07 DA         [24] 3537 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      0068B6 E4               [12] 3538 	clr	a
      0068B7 F0               [24] 3539 	movx	@dptr,a
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3541 ;	assignBit
      0068B8 C2 AF            [12] 3542 	clr	_EA
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      0068BA 90 07 D9         [24] 3544 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      0068BD E0               [24] 3545 	movx	a,@dptr
      0068BE FF               [12] 3546 	mov	r7,a
      0068BF BF 01 00         [24] 3547 	cjne	r7,#0x01,00152$
      0068C2                       3548 00152$:
      0068C2 40 4E            [24] 3549 	jc	00102$
      0068C4 EF               [12] 3550 	mov	a,r7
      0068C5 24 FD            [12] 3551 	add	a,#0xff - 0x02
      0068C7 40 49            [24] 3552 	jc	00102$
                                   3553 ;	free result
      0068C9 90 07 6C         [24] 3554 	mov	dptr,#_USB_EnumStatus
      0068CC E0               [24] 3555 	movx	a,@dptr
      0068CD 60 43            [24] 3556 	jz	00102$
                                   3557 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      0068CF 90 07 6D         [24] 3558 	mov	dptr,#_USB_SleepStatus
      0068D2 E0               [24] 3559 	movx	a,@dptr
      0068D3 20 E1 3C         [24] 3560 	jb	acc.1,00102$
      0068D6 90 07 95         [24] 3561 	mov	dptr,#_keyboard_reset
      0068D9 E0               [24] 3562 	movx	a,@dptr
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      0068DA 70 36            [24] 3564 	jnz	00102$
      0068DC 8F 06            [24] 3565 	mov	ar6,r7
      0068DE 24 22            [12] 3566 	add	a,#0x22
      0068E0 FD               [12] 3567 	mov	r5,a
      0068E1 8E 82            [24] 3568 	mov	dpl,r6
      0068E3 8D 83            [24] 3569 	mov	dph,r5
      0068E5 E0               [24] 3570 	movx	a,@dptr
      0068E6 FE               [12] 3571 	mov	r6,a
      0068E7 53 06 03         [24] 3572 	anl	ar6,#0x03
      0068EA BE 02 25         [24] 3573 	cjne	r6,#0x02,00102$
                                   3574 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      0068ED 90 07 D6         [24] 3575 	mov	dptr,#_ak820_usb_try_send_PARM_2
      0068F0 E0               [24] 3576 	movx	a,@dptr
      0068F1 FD               [12] 3577 	mov	r5,a
      0068F2 A3               [24] 3578 	inc	dptr
      0068F3 E0               [24] 3579 	movx	a,@dptr
      0068F4 FE               [12] 3580 	mov	r6,a
      0068F5 90 07 D8         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_3
      0068F8 E0               [24] 3582 	movx	a,@dptr
      0068F9 FC               [12] 3583 	mov	r4,a
      0068FA 90 07 D1         [24] 3584 	mov	dptr,#_ak820_usb_send_PARM_2
      0068FD ED               [12] 3585 	mov	a,r5
      0068FE F0               [24] 3586 	movx	@dptr,a
      0068FF EE               [12] 3587 	mov	a,r6
      006900 A3               [24] 3588 	inc	dptr
      006901 F0               [24] 3589 	movx	@dptr,a
      006902 90 07 D3         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_3
      006905 EC               [12] 3591 	mov	a,r4
      006906 F0               [24] 3592 	movx	@dptr,a
      006907 8F 82            [24] 3593 	mov	dpl, r7
      006909 12 67 0E         [24] 3594 	lcall	_ak820_usb_send
      00690C E5 82            [12] 3595 	mov	a, dpl
      00690E 90 07 DA         [24] 3596 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006911 F0               [24] 3597 	movx	@dptr,a
      006912                       3598 00102$:
                                   3599 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3600 ;	assignBit
      006912 A2 1C            [12] 3601 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006914 92 AF            [24] 3602 	mov	_EA,c
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      006916 90 07 DA         [24] 3604 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006919 E0               [24] 3605 	movx	a,@dptr
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      00691A F5 82            [12] 3607 	mov	dpl,a
      00691C 22               [24] 3608 	ret
                                   3609 ;------------------------------------------------------------
                                   3610 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3611 ;------------------------------------------------------------
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3613 ;	-----------------------------------------
                                   3614 ;	 function raw_request_is_nonpersistent
                                   3615 ;	-----------------------------------------
      00691D                       3616 _raw_request_is_nonpersistent:
                                   3617 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      00691D 90 07 74         [24] 3618 	mov	dptr,#_raw_buffer
      006920 E0               [24] 3619 	movx	a,@dptr
      006921 FF               [12] 3620 	mov	r7,a
      006922 BF 01 02         [24] 3621 	cjne	r7,#0x01,00302$
      006925 80 35            [24] 3622 	sjmp	00108$
      006927                       3623 00302$:
      006927 BF 02 02         [24] 3624 	cjne	r7,#0x02,00303$
      00692A 80 34            [24] 3625 	sjmp	00109$
      00692C                       3626 00303$:
      00692C BF 04 02         [24] 3627 	cjne	r7,#0x04,00304$
      00692F 80 2B            [24] 3628 	sjmp	00108$
      006931                       3629 00304$:
      006931 BF 08 02         [24] 3630 	cjne	r7,#0x08,00305$
      006934 80 47            [24] 3631 	sjmp	00116$
      006936                       3632 00305$:
      006936 BF 0B 02         [24] 3633 	cjne	r7,#0x0b,00306$
      006939 80 21            [24] 3634 	sjmp	00108$
      00693B                       3635 00306$:
      00693B BF 0C 02         [24] 3636 	cjne	r7,#0x0c,00307$
      00693E 80 1C            [24] 3637 	sjmp	00108$
      006940                       3638 00307$:
      006940 BF 0D 02         [24] 3639 	cjne	r7,#0x0d,00308$
      006943 80 17            [24] 3640 	sjmp	00108$
      006945                       3641 00308$:
      006945 BF 0E 02         [24] 3642 	cjne	r7,#0x0e,00309$
      006948 80 12            [24] 3643 	sjmp	00108$
      00694A                       3644 00309$:
      00694A BF 11 02         [24] 3645 	cjne	r7,#0x11,00310$
      00694D 80 0D            [24] 3646 	sjmp	00108$
      00694F                       3647 00310$:
      00694F BF 12 02         [24] 3648 	cjne	r7,#0x12,00311$
      006952 80 08            [24] 3649 	sjmp	00108$
      006954                       3650 00311$:
      006954 BF FE 02         [24] 3651 	cjne	r7,#0xfe,00312$
      006957 80 46            [24] 3652 	sjmp	00124$
      006959                       3653 00312$:
      006959 02 69 F4         [24] 3654 	ljmp	00144$
                                   3655 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      00695C                       3656 00108$:
                                   3657 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      00695C 75 82 01         [24] 3658 	mov	dpl, #0x01
      00695F 22               [24] 3659 	ret
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      006960                       3661 00109$:
                                   3662 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      006960 12 6C 26         [24] 3663 	lcall	_ak820_outline_0167
      006963 BF 01 02         [24] 3664 	cjne	r7,#0x01,00313$
      006966 80 0D            [24] 3665 	sjmp	00113$
      006968                       3666 00313$:
      006968 BF 02 02         [24] 3667 	cjne	r7,#0x02,00314$
      00696B 80 08            [24] 3668 	sjmp	00113$
      00696D                       3669 00314$:
      00696D BF 03 02         [24] 3670 	cjne	r7,#0x03,00315$
      006970 80 03            [24] 3671 	sjmp	00113$
      006972                       3672 00315$:
      006972 BF 04 04         [24] 3673 	cjne	r7,#0x04,00114$
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      006975                       3675 00113$:
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      006975 75 82 01         [24] 3677 	mov	dpl, #0x01
      006978 22               [24] 3678 	ret
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006979                       3680 00114$:
      006979 75 82 00         [24] 3681 	mov	dpl, #0x00
      00697C 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      00697D                       3684 00116$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      00697D 12 6C 26         [24] 3686 	lcall	_ak820_outline_0167
      006980 BF 40 02         [24] 3687 	cjne	r7,#0x40,00318$
      006983 80 12            [24] 3688 	sjmp	00121$
      006985                       3689 00318$:
      006985 BF 41 02         [24] 3690 	cjne	r7,#0x41,00319$
      006988 80 0D            [24] 3691 	sjmp	00121$
      00698A                       3692 00319$:
      00698A BF 42 02         [24] 3693 	cjne	r7,#0x42,00320$
      00698D 80 08            [24] 3694 	sjmp	00121$
      00698F                       3695 00320$:
      00698F BF 43 02         [24] 3696 	cjne	r7,#0x43,00321$
      006992 80 03            [24] 3697 	sjmp	00121$
      006994                       3698 00321$:
      006994 BF 44 04         [24] 3699 	cjne	r7,#0x44,00122$
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      006997                       3701 00121$:
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      006997 75 82 01         [24] 3703 	mov	dpl, #0x01
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      00699A 22               [24] 3705 	ret
      00699B                       3706 00122$:
      00699B 75 82 00         [24] 3707 	mov	dpl, #0x00
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      00699E 22               [24] 3709 	ret
      00699F                       3710 00124$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      00699F 12 6C 26         [24] 3712 	lcall	_ak820_outline_0167
      0069A2 24 F2            [12] 3713 	add	a,#0xff - 0x0d
      0069A4 40 4A            [24] 3714 	jc	00142$
                                   3715 ;	free result
      0069A6 EF               [12] 3716 	mov	a,r7
      0069A7 24 0A            [12] 3717 	add	a,#(00325$-3-.)
      0069A9 83               [24] 3718 	movc	a,@a+pc
      0069AA F5 82            [12] 3719 	mov	dpl,a
      0069AC EF               [12] 3720 	mov	a,r7
      0069AD 24 12            [12] 3721 	add	a,#(00326$-3-.)
      0069AF 83               [24] 3722 	movc	a,@a+pc
      0069B0 F5 83            [12] 3723 	mov	dph,a
      0069B2 E4               [12] 3724 	clr	a
      0069B3 73               [24] 3725 	jmp	@a+dptr
      0069B4                       3726 00325$:
      0069B4 D0                    3727 	.db	00134$
      0069B5 D0                    3728 	.db	00134$
      0069B6 D0                    3729 	.db	00134$
      0069B7 D0                    3730 	.db	00134$
      0069B8 F0                    3731 	.db	00142$
      0069B9 D0                    3732 	.db	00134$
      0069BA D0                    3733 	.db	00134$
      0069BB D0                    3734 	.db	00134$
      0069BC D0                    3735 	.db	00134$
      0069BD D0                    3736 	.db	00134$
      0069BE D0                    3737 	.db	00134$
      0069BF F0                    3738 	.db	00142$
      0069C0 F0                    3739 	.db	00142$
      0069C1 D4                    3740 	.db	00135$
      0069C2                       3741 00326$:
      0069C2 69                    3742 	.db	00134$>>8
      0069C3 69                    3743 	.db	00134$>>8
      0069C4 69                    3744 	.db	00134$>>8
      0069C5 69                    3745 	.db	00134$>>8
      0069C6 69                    3746 	.db	00142$>>8
      0069C7 69                    3747 	.db	00134$>>8
      0069C8 69                    3748 	.db	00134$>>8
      0069C9 69                    3749 	.db	00134$>>8
      0069CA 69                    3750 	.db	00134$>>8
      0069CB 69                    3751 	.db	00134$>>8
      0069CC 69                    3752 	.db	00134$>>8
      0069CD 69                    3753 	.db	00142$>>8
      0069CE 69                    3754 	.db	00142$>>8
      0069CF 69                    3755 	.db	00135$>>8
                                   3756 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      0069D0                       3757 00134$:
                                   3758 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      0069D0 75 82 01         [24] 3759 	mov	dpl, #0x01
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      0069D3 22               [24] 3761 	ret
      0069D4                       3762 00135$:
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      0069D4 90 07 76         [24] 3764 	mov	dptr,#(_raw_buffer + 0x0002)
      0069D7 E0               [24] 3765 	movx	a,@dptr
      0069D8 FF               [12] 3766 	mov	r7,a
      0069D9 60 0D            [24] 3767 	jz	00139$
      0069DB BF 01 02         [24] 3768 	cjne	r7,#0x01,00328$
      0069DE 80 08            [24] 3769 	sjmp	00139$
      0069E0                       3770 00328$:
      0069E0 BF 03 02         [24] 3771 	cjne	r7,#0x03,00329$
      0069E3 80 03            [24] 3772 	sjmp	00139$
      0069E5                       3773 00329$:
      0069E5 BF 05 04         [24] 3774 	cjne	r7,#0x05,00140$
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      0069E8                       3776 00139$:
                                   3777 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      0069E8 75 82 01         [24] 3778 	mov	dpl, #0x01
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      0069EB 22               [24] 3780 	ret
      0069EC                       3781 00140$:
      0069EC 75 82 00         [24] 3782 	mov	dpl, #0x00
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      0069EF 22               [24] 3784 	ret
      0069F0                       3785 00142$:
      0069F0 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      0069F3 22               [24] 3788 	ret
      0069F4                       3789 00144$:
      0069F4 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      0069F7 22               [24] 3793 	ret
                                   3794 ;------------------------------------------------------------
                                   3795 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3796 ;------------------------------------------------------------
                                   3797 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3798 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3799 ;------------------------------------------------------------
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3801 ;	-----------------------------------------
                                   3802 ;	 function ak820_usb_raw_send
                                   3803 ;	-----------------------------------------
      0069F8                       3804 _ak820_usb_raw_send:
      0069F8 12 43 13         [24] 3805 	lcall	_ak820_outline_0036
      0069FB 90 07 DC         [24] 3806 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      0069FE 12 38 1F         [24] 3807 	lcall	_ak820_outline_0016
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006A01 90 07 DB         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006A04 E0               [24] 3810 	movx	a,@dptr
      006A05 FF               [12] 3811 	mov	r7,a
      006A06 BF 20 2B         [24] 3812 	cjne	r7,#0x20,00106$
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006A09 C0 07            [24] 3814 	push	ar7
      006A0B 12 3E 29         [24] 3815 	lcall	_ak820_nvm_flush
      006A0E D0 07            [24] 3816 	pop	ar7
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006A10 90 07 94         [24] 3818 	mov	dptr,#_raw_reply_without_nvm
      006A13 E0               [24] 3819 	movx	a,@dptr
      006A14 70 07            [24] 3820 	jnz	00103$
      006A16 12 3E 1A         [24] 3821 	lcall	_ak820_nvm_ok
      006A19 E5 82            [12] 3822 	mov	a, dpl
      006A1B 60 17            [24] 3823 	jz	00106$
      006A1D                       3824 00103$:
      006A1D 90 07 DC         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006A20 12 38 64         [24] 3826 	lcall	_ak820_outline_0080
      006A23 90 07 D1         [24] 3827 	mov	dptr,#_ak820_usb_send_PARM_2
      006A26 12 43 7D         [24] 3828 	lcall	_ak820_outline_0165
      006A29 90 07 D3         [24] 3829 	mov	dptr,#_ak820_usb_send_PARM_3
      006A2C EF               [12] 3830 	mov	a,r7
      006A2D F0               [24] 3831 	movx	@dptr,a
      006A2E 75 82 03         [24] 3832 	mov	dpl, #0x03
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006A31 02 67 0E         [24] 3834 	ljmp	_ak820_usb_send
      006A34                       3835 00106$:
      006A34 22               [24] 3836 	ret
                                   3837 ;------------------------------------------------------------
                                   3838 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3839 ;------------------------------------------------------------
                                   3840 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3841 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3842 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3843 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3844 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3845 ;------------------------------------------------------------
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3847 ;	-----------------------------------------
                                   3848 ;	 function ak820_usb_raw_task
                                   3849 ;	-----------------------------------------
      006A35                       3850 _ak820_usb_raw_task:
                                   3851 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006A35 A2 AF            [12] 3852 	mov	c,_EA
      006A37 E4               [12] 3853 	clr	a
      006A38 33               [12] 3854 	rlc	a
      006A39 FF               [12] 3855 	mov	r7,a
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3857 ;	assignBit
      006A3A C2 AF            [12] 3858 	clr	_EA
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006A3C 90 07 6C         [24] 3860 	mov	dptr,#_USB_EnumStatus
      006A3F E0               [24] 3861 	movx	a,@dptr
      006A40 60 0A            [24] 3862 	jz	00101$
      006A42 90 07 73         [24] 3863 	mov	dptr,#_raw_state
      006A45 E0               [24] 3864 	movx	a,@dptr
      006A46 FE               [12] 3865 	mov	r6,a
      006A47 BE 02 02         [24] 3866 	cjne	r6,#0x02,00270$
      006A4A 80 06            [24] 3867 	sjmp	00102$
      006A4C                       3868 00270$:
      006A4C                       3869 00101$:
                                   3870 ;	assignBit
      006A4C EF               [12] 3871 	mov	a,r7
      006A4D 24 FF            [12] 3872 	add	a,#0xff
      006A4F 92 AF            [24] 3873 	mov	_EA,c
      006A51 22               [24] 3874 	ret
      006A52                       3875 00102$:
                                   3876 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006A52 90 07 73         [24] 3877 	mov	dptr,#_raw_state
      006A55 74 03            [12] 3878 	mov	a,#0x03
      006A57 F0               [24] 3879 	movx	@dptr,a
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3881 ;	assignBit
      006A58 EF               [12] 3882 	mov	a,r7
      006A59 24 FF            [12] 3883 	add	a,#0xff
      006A5B 92 AF            [24] 3884 	mov	_EA,c
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006A5D 90 07 74         [24] 3886 	mov	dptr,#_raw_buffer
      006A60 E0               [24] 3887 	movx	a,@dptr
      006A61 FF               [12] 3888 	mov	r7,a
      006A62 E4               [12] 3889 	clr	a
      006A63 BF FD 01         [24] 3890 	cjne	r7,#0xfd,00271$
      006A66 04               [12] 3891 	inc	a
      006A67                       3892 00271$:
      006A67 FF               [12] 3893 	mov	r7,a
      006A68 70 03            [24] 3894 	jnz	00273$
      006A6A 02 6B 0A         [24] 3895 	ljmp	00118$
      006A6D                       3896 00273$:
      006A6D 90 07 75         [24] 3897 	mov	dptr,#(_raw_buffer + 0x0001)
      006A70 E0               [24] 3898 	movx	a,@dptr
      006A71 60 03            [24] 3899 	jz	00274$
      006A73 02 6B 0A         [24] 3900 	ljmp	00118$
      006A76                       3901 00274$:
                                   3902 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006A76 90 07 76         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0002)
      006A79 E0               [24] 3904 	movx	a,@dptr
      006A7A FD               [12] 3905 	mov	r5,a
      006A7B 7E 00            [12] 3906 	mov	r6,#0x00
      006A7D 90 07 77         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0003)
      006A80 E0               [24] 3908 	movx	a,@dptr
      006A81 7B 00            [12] 3909 	mov	r3,#0x00
      006A83 42 06            [12] 3910 	orl	ar6,a
      006A85 EB               [12] 3911 	mov	a,r3
      006A86 42 05            [12] 3912 	orl	ar5,a
                                   3913 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006A88 90 07 78         [24] 3914 	mov	dptr,#(_raw_buffer + 0x0004)
      006A8B E0               [24] 3915 	movx	a,@dptr
      006A8C FC               [12] 3916 	mov	r4,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006A8D 7B 05            [12] 3918 	mov	r3,#0x05
      006A8F                       3919 00128$:
      006A8F EB               [12] 3920 	mov	a,r3
      006A90 12 6C 14         [24] 3921 	lcall	_ak820_outline_0106
      006A93 0B               [12] 3922 	inc	r3
      006A94 BB 20 00         [24] 3923 	cjne	r3,#0x20,00275$
      006A97                       3924 00275$:
      006A97 40 F6            [24] 3925 	jc	00128$
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006A99 EC               [12] 3927 	mov	a,r4
      006A9A 24 E4            [12] 3928 	add	a,#0xff - 0x1b
      006A9C 40 1C            [24] 3929 	jc	00106$
                                   3930 ;	free result
      006A9E EC               [12] 3931 	mov	a,r4
      006A9F 60 26            [24] 3932 	jz	00165$
      006AA1 8C 03            [24] 3933 	mov	ar3,r4
      006AA3 1B               [12] 3934 	dec	r3
      006AA4 7A 00            [12] 3935 	mov	r2,#0x00
      006AA6 74 FF            [12] 3936 	mov	a,#0xff
      006AA8 C3               [12] 3937 	clr	c
      006AA9 9B               [12] 3938 	subb	a,r3
      006AAA FB               [12] 3939 	mov	r3,a
      006AAB 74 FF            [12] 3940 	mov	a,#0xff
      006AAD 9A               [12] 3941 	subb	a,r2
      006AAE FA               [12] 3942 	mov	r2,a
      006AAF 8E 00            [24] 3943 	mov	ar0,r6
      006AB1 8D 01            [24] 3944 	mov	ar1,r5
      006AB3 C3               [12] 3945 	clr	c
      006AB4 EB               [12] 3946 	mov	a,r3
      006AB5 98               [12] 3947 	subb	a,r0
      006AB6 EA               [12] 3948 	mov	a,r2
      006AB7 99               [12] 3949 	subb	a,r1
      006AB8 50 0D            [24] 3950 	jnc	00165$
                                   3951 ;	free result
      006ABA                       3952 00106$:
                                   3953 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006ABA 90 07 75         [24] 3954 	mov	dptr,#(_raw_buffer + 0x0001)
      006ABD 74 FF            [12] 3955 	mov	a,#0xff
      006ABF F0               [24] 3956 	movx	@dptr,a
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      006AC0 90 07 78         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0004)
      006AC3 E4               [12] 3959 	clr	a
      006AC4 F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006AC5 80 3A            [24] 3962 	sjmp	00108$
      006AC7                       3963 00165$:
      006AC7 7B 00            [12] 3964 	mov	r3,#0x00
      006AC9                       3965 00131$:
      006AC9 C3               [12] 3966 	clr	c
      006ACA EB               [12] 3967 	mov	a,r3
      006ACB 9C               [12] 3968 	subb	a,r4
      006ACC 50 33            [24] 3969 	jnc	00108$
      006ACE C0 04            [24] 3970 	push	ar4
      006AD0 8B 02            [24] 3971 	mov	ar2,r3
      006AD2 74 05            [12] 3972 	mov	a,#0x05
      006AD4 2A               [12] 3973 	add	a, r2
      006AD5 F9               [12] 3974 	mov	r1,a
      006AD6 33               [12] 3975 	rlc	a
      006AD7 95 E0            [12] 3976 	subb	a,acc
      006AD9 FA               [12] 3977 	mov	r2,a
      006ADA E9               [12] 3978 	mov	a,r1
      006ADB 24 74            [12] 3979 	add	a, #_raw_buffer
      006ADD F9               [12] 3980 	mov	r1,a
      006ADE EA               [12] 3981 	mov	a,r2
      006ADF 34 07            [12] 3982 	addc	a, #(_raw_buffer >> 8)
      006AE1 FA               [12] 3983 	mov	r2,a
      006AE2 8B 1E            [24] 3984 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006AE4 75 1F 00         [24] 3985 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006AE7 8E 00            [24] 3986 	mov	ar0,r6
      006AE9 8D 04            [24] 3987 	mov	ar4,r5
      006AEB E5 1E            [12] 3988 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006AED 28               [12] 3989 	add	a, r0
      006AEE F8               [12] 3990 	mov	r0,a
      006AEF E5 1F            [12] 3991 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006AF1 3C               [12] 3992 	addc	a, r4
      006AF2 FC               [12] 3993 	mov	r4,a
      006AF3 88 82            [24] 3994 	mov	dpl,r0
      006AF5 8C 83            [24] 3995 	mov	dph,r4
      006AF7 E4               [12] 3996 	clr	a
      006AF8 93               [24] 3997 	movc	a,@a+dptr
      006AF9 12 6C 20         [24] 3998 	lcall	_ak820_outline_0141
      006AFC 0B               [12] 3999 	inc	r3
      006AFD D0 04            [24] 4000 	pop	ar4
      006AFF 80 C8            [24] 4001 	sjmp	00131$
      006B01                       4002 00108$:
                                   4003 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006B01 12 6C 00         [24] 4004 	lcall	_ak820_outline_0045
      006B04 12 67 0E         [24] 4005 	lcall	_ak820_usb_send
      006B07 02 6B B0         [24] 4006 	ljmp	00119$
      006B0A                       4007 00118$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006B0A EF               [12] 4009 	mov	a,r7
      006B0B 70 03            [24] 4010 	jnz	00281$
      006B0D 02 6B 8D         [24] 4011 	ljmp	00114$
      006B10                       4012 00281$:
      006B10 12 6C 26         [24] 4013 	lcall	_ak820_outline_0167
      006B13 BF 01 02         [24] 4014 	cjne	r7,#0x01,00282$
      006B16 80 03            [24] 4015 	sjmp	00283$
      006B18                       4016 00282$:
      006B18 02 6B 8D         [24] 4017 	ljmp	00114$
      006B1B                       4018 00283$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006B1B 7F 02            [12] 4020 	mov	r7,#0x02
      006B1D                       4021 00133$:
      006B1D EF               [12] 4022 	mov	a,r7
      006B1E 12 6C 14         [24] 4023 	lcall	_ak820_outline_0106
      006B21 0F               [12] 4024 	inc	r7
      006B22 BF 20 00         [24] 4025 	cjne	r7,#0x20,00284$
      006B25                       4026 00284$:
      006B25 40 F6            [24] 4027 	jc	00133$
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      006B27 90 07 76         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0002)
      006B2A 74 01            [12] 4030 	mov	a,#0x01
      006B2C F0               [24] 4031 	movx	@dptr,a
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      006B2D 90 07 77         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0003)
      006B30 74 A8            [12] 4034 	mov	a,#0xa8
      006B32 F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      006B33 90 07 78         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0004)
      006B36 12 3B 97         [24] 4038 	lcall	_ak820_nvm_diagnostic
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006B39 7F 00            [12] 4040 	mov	r7,#0x00
      006B3B                       4041 00135$:
      006B3B 8F 06            [24] 4042 	mov	ar6,r7
      006B3D 74 0B            [12] 4043 	mov	a,#0x0b
      006B3F 2E               [12] 4044 	add	a, r6
      006B40 24 74            [12] 4045 	add	a,#_raw_buffer
      006B42 FE               [12] 4046 	mov	r6,a
      006B43 E4               [12] 4047 	clr	a
      006B44 34 07            [12] 4048 	addc	a, #(_raw_buffer >> 8)
      006B46 FD               [12] 4049 	mov	r5,a
      006B47 EF               [12] 4050 	mov	a,r7
      006B48 24 64            [12] 4051 	add	a, #_ak820_flash_diagnostic
      006B4A F5 82            [12] 4052 	mov	dpl,a
      006B4C E4               [12] 4053 	clr	a
      006B4D 34 04            [12] 4054 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006B4F F5 83            [12] 4055 	mov	dph,a
      006B51 E0               [24] 4056 	movx	a,@dptr
      006B52 8E 82            [24] 4057 	mov	dpl,r6
      006B54 8D 83            [24] 4058 	mov	dph,r5
      006B56 F0               [24] 4059 	movx	@dptr,a
      006B57 0F               [12] 4060 	inc	r7
      006B58 BF 06 00         [24] 4061 	cjne	r7,#0x06,00286$
      006B5B                       4062 00286$:
      006B5B 40 DE            [24] 4063 	jc	00135$
                                   4064 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      006B5D 90 0E 24         [24] 4065 	mov	dptr,#_vial_unlocked
      006B60 E0               [24] 4066 	movx	a,@dptr
      006B61 90 07 85         [24] 4067 	mov	dptr,#(_raw_buffer + 0x0011)
      006B64 F0               [24] 4068 	movx	@dptr,a
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      006B65 90 0E 25         [24] 4070 	mov	dptr,#_vial_unlock_in_progress
      006B68 E0               [24] 4071 	movx	a,@dptr
      006B69 90 07 86         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0012)
      006B6C F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      006B6D 90 07 6C         [24] 4075 	mov	dptr,#_USB_EnumStatus
      006B70 E0               [24] 4076 	movx	a,@dptr
      006B71 90 07 87         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0013)
      006B74 F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      006B75 90 07 6D         [24] 4080 	mov	dptr,#_USB_SleepStatus
      006B78 E0               [24] 4081 	movx	a,@dptr
      006B79 90 07 88         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0014)
      006B7C F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      006B7D 90 07 73         [24] 4085 	mov	dptr,#_raw_state
      006B80 E0               [24] 4086 	movx	a,@dptr
      006B81 90 07 89         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0015)
      006B84 F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006B85 12 6C 00         [24] 4090 	lcall	_ak820_outline_0045
      006B88 12 67 0E         [24] 4091 	lcall	_ak820_usb_send
      006B8B 80 23            [24] 4092 	sjmp	00119$
      006B8D                       4093 00114$:
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006B8D 12 69 1D         [24] 4095 	lcall	_raw_request_is_nonpersistent
      006B90 E5 82            [12] 4096 	mov	a, dpl
      006B92 90 07 94         [24] 4097 	mov	dptr,#_raw_reply_without_nvm
      006B95 F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      006B96 12 3F 7C         [24] 4100 	lcall	_ak820_nvm_begin
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006B99 90 0C 56         [24] 4102 	mov	dptr,#_raw_hid_receive_PARM_2
      006B9C 74 20            [12] 4103 	mov	a,#0x20
      006B9E F0               [24] 4104 	movx	@dptr,a
      006B9F 90 07 74         [24] 4105 	mov	dptr,#_raw_buffer
      006BA2 75 F0 00         [24] 4106 	mov	b, #0x00
      006BA5 12 A6 49         [24] 4107 	lcall	_raw_hid_receive
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      006BA8 12 3F 91         [24] 4109 	lcall	_ak820_nvm_end
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      006BAB 90 07 94         [24] 4111 	mov	dptr,#_raw_reply_without_nvm
      006BAE E4               [12] 4112 	clr	a
      006BAF F0               [24] 4113 	movx	@dptr,a
      006BB0                       4114 00119$:
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4116 ;	assignBit
      006BB0 A2 AF            [12] 4117 	mov	c,_EA
      006BB2 92 1D            [24] 4118 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4120 ;	assignBit
      006BB4 C2 AF            [12] 4121 	clr	_EA
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006BB6 12 6C 2C         [24] 4123 	lcall	_ak820_outline_0169
      006BB9 BF 04 08         [24] 4124 	cjne	r7,#0x04,00126$
      006BBC 90 07 73         [24] 4125 	mov	dptr,#_raw_state
      006BBF 74 05            [12] 4126 	mov	a,#0x05
      006BC1 F0               [24] 4127 	movx	@dptr,a
      006BC2 80 1B            [24] 4128 	sjmp	00127$
      006BC4                       4129 00126$:
                                   4130 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006BC4 12 6C 2C         [24] 4131 	lcall	_ak820_outline_0169
      006BC7 BF 03 02         [24] 4132 	cjne	r7,#0x03,00290$
      006BCA 80 0E            [24] 4133 	sjmp	00121$
      006BCC                       4134 00290$:
      006BCC 12 6C 2C         [24] 4135 	lcall	_ak820_outline_0169
      006BCF BF 06 02         [24] 4136 	cjne	r7,#0x06,00291$
      006BD2 80 06            [24] 4137 	sjmp	00121$
      006BD4                       4138 00291$:
      006BD4 12 6C 2C         [24] 4139 	lcall	_ak820_outline_0169
      006BD7 BF 07 05         [24] 4140 	cjne	r7,#0x07,00127$
      006BDA                       4141 00121$:
      006BDA 90 07 73         [24] 4142 	mov	dptr,#_raw_state
      006BDD E4               [12] 4143 	clr	a
      006BDE F0               [24] 4144 	movx	@dptr,a
      006BDF                       4145 00127$:
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4147 ;	assignBit
      006BDF A2 1D            [12] 4148 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006BE1 92 AF            [24] 4149 	mov	_EA,c
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      006BE3 22               [24] 4151 	ret
                                   4152 ;------------------------------------------------------------
                                   4153 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4154 ;------------------------------------------------------------
                                   4155 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4156 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_take_keyboard_reset
                                   4161 ;	-----------------------------------------
      006BE4                       4162 _ak820_usb_take_keyboard_reset:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4164 ;	assignBit
      006BE4 A2 AF            [12] 4165 	mov	c,_EA
      006BE6 92 1E            [24] 4166 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4168 ;	assignBit
      006BE8 C2 AF            [12] 4169 	clr	_EA
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      006BEA 90 07 95         [24] 4171 	mov	dptr,#_keyboard_reset
      006BED E0               [24] 4172 	movx	a,@dptr
      006BEE FF               [12] 4173 	mov	r7,a
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      006BEF E4               [12] 4175 	clr	a
      006BF0 F0               [24] 4176 	movx	@dptr,a
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4178 ;	assignBit
      006BF1 A2 1E            [12] 4179 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006BF3 92 AF            [24] 4180 	mov	_EA,c
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      006BF5 EF               [12] 4182 	mov	a,r7
      006BF6 B4 01 00         [24] 4183 	cjne	a,#0x01,00103$
      006BF9                       4184 00103$:
      006BF9 B3               [12] 4185 	cpl	c
      006BFA 92 1E            [24] 4186 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006BFC 12 38 B1         [24] 4187 	lcall	_ak820_outline_0159
                                   4188 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      006BFF 22               [24] 4189 	ret
                                   4190 	.area CSEG    (CODE)
                                   4191 	.area CONST   (CODE)
                                   4192 	.area CONST   (CODE)
      00B918                       4193 _shared_offsets:
      00B918 00                    4194 	.db #0x00	; 0
      00B919 00                    4195 	.db #0x00	; 0
      00B91A 28                    4196 	.db #0x28	; 40
      00B91B 28                    4197 	.db #0x28	; 40
      00B91C 2B                    4198 	.db #0x2b	; 43
      00B91D 00                    4199 	.db #0x00	; 0
      00B91E 08                    4200 	.db #0x08	; 8
                                   4201 	.area CSEG    (CODE)
                                   4202 	.area CONST   (CODE)
      00B91F                       4203 _shared_lengths:
      00B91F 00                    4204 	.db #0x00	; 0
      00B920 00                    4205 	.db #0x00	; 0
      00B921 00                    4206 	.db #0x00	; 0
      00B922 03                    4207 	.db #0x03	; 3
      00B923 03                    4208 	.db #0x03	; 3
      00B924 00                    4209 	.db #0x00	; 0
      00B925 20                    4210 	.db #0x20	; 32
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00B926                       4213 _interface_descriptors:
      00B926 C1 BE                 4214 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00B928 C1 BF                 4215 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00B92A 74 BF                 4216 	.byte _RawReport, (_RawReport >> 8)
      00B92C DA BF                 4217 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00B92E 06 BF                 4218 	.byte _SharedReport, (_SharedReport >> 8)
      00B930 F3 BF                 4219 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4220 	.area CSEG    (CODE)
                                   4221 	.area XINIT   (CODE)
                                   4222 	.area CABS    (ABS,CODE)
                                   4223 
                                   4224 ; Experimental exact instruction outlining.
                                   4225 	.globl _ak820_outline_0016
                                   4226 	.globl _ak820_outline_0036
                                   4227 	.globl _ak820_outline_0045
                                   4228 	.globl _ak820_outline_0080
                                   4229 	.globl _ak820_outline_0106
                                   4230 	.globl _ak820_outline_0141
                                   4231 	.globl _ak820_outline_0159
                                   4232 	.globl _ak820_outline_0165
                                   4233 	.globl _ak820_outline_0167
                                   4234 	.globl _ak820_outline_0169
                                   4235 
                                   4236 	.area CSEG (CODE)
                                   4237 ; function ak820_outline_0045
      006C00                       4238 _ak820_outline_0045:
      006C00 90 07 D1         [24] 4239 	mov	dptr,#_ak820_usb_send_PARM_2
      006C03 74 74            [12] 4240 	mov	a,#_raw_buffer
      006C05 F0               [24] 4241 	movx	@dptr,a
      006C06 74 07            [12] 4242 	mov	a,#(_raw_buffer>>8)
      006C08 A3               [24] 4243 	inc	dptr
      006C09 F0               [24] 4244 	movx	@dptr,a
      006C0A 90 07 D3         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_3
      006C0D 74 20            [12] 4246 	mov	a,#0x20
      006C0F F0               [24] 4247 	movx	@dptr,a
      006C10 75 82 03         [24] 4248 	mov	dpl,#0x03
      006C13 22               [24] 4249 	ret
                                   4250 
                                   4251 	.area CSEG (CODE)
                                   4252 ; function ak820_outline_0106
      006C14                       4253 _ak820_outline_0106:
      006C14 24 74            [12] 4254 	add	a,#_raw_buffer
      006C16 F5 82            [12] 4255 	mov	dpl,a
      006C18 E4               [12] 4256 	clr	a
      006C19 34 07            [12] 4257 	addc	a,#(_raw_buffer>>8)
      006C1B F5 83            [12] 4258 	mov	dph,a
      006C1D E4               [12] 4259 	clr	a
      006C1E F0               [24] 4260 	movx	@dptr,a
      006C1F 22               [24] 4261 	ret
                                   4262 
                                   4263 	.area CSEG (CODE)
                                   4264 ; function ak820_outline_0141
      006C20                       4265 _ak820_outline_0141:
      006C20 89 82            [24] 4266 	mov	dpl,r1
      006C22 8A 83            [24] 4267 	mov	dph,r2
      006C24 F0               [24] 4268 	movx	@dptr,a
      006C25 22               [24] 4269 	ret
                                   4270 
                                   4271 	.area CSEG (CODE)
                                   4272 ; function ak820_outline_0167
      006C26                       4273 _ak820_outline_0167:
      006C26 90 07 75         [24] 4274 	mov	dptr,#(_raw_buffer+0x0001)
      006C29 E0               [24] 4275 	movx	a,@dptr
      006C2A FF               [12] 4276 	mov	r7,a
      006C2B 22               [24] 4277 	ret
                                   4278 
                                   4279 	.area CSEG (CODE)
                                   4280 ; function ak820_outline_0169
      006C2C                       4281 _ak820_outline_0169:
      006C2C 90 07 73         [24] 4282 	mov	dptr,#_raw_state
      006C2F E0               [24] 4283 	movx	a,@dptr
      006C30 FF               [12] 4284 	mov	r7,a
      006C31 22               [24] 4285 	ret
