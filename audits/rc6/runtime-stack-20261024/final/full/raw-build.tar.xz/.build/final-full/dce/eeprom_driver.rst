                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00067F                         85 _eeprom_read_word_addr_10000_91:
      00067F                         86 	.ds 3
      000682                         87 _eeprom_read_word_ret_10000_92:
      000682                         88 	.ds 2
      000684                         89 _eeprom_read_dword_addr_10000_93:
      000684                         90 	.ds 3
      000687                         91 _eeprom_read_dword_ret_10000_94:
      000687                         92 	.ds 4
      00068B                         93 _eeprom_write_byte_PARM_2:
      00068B                         94 	.ds 1
      00068C                         95 _eeprom_write_byte_addr_10000_95:
      00068C                         96 	.ds 3
      00068F                         97 _eeprom_write_word_PARM_2:
      00068F                         98 	.ds 2
      000691                         99 _eeprom_write_word_addr_10000_97:
      000691                        100 	.ds 3
      000694                        101 _eeprom_write_dword_PARM_2:
      000694                        102 	.ds 4
      000698                        103 _eeprom_write_dword_addr_10000_99:
      000698                        104 	.ds 3
      00069B                        105 _eeprom_update_byte_PARM_2:
      00069B                        106 	.ds 1
      00069C                        107 _eeprom_update_byte_addr_10000_107:
      00069C                        108 	.ds 3
      00069F                        109 _eeprom_update_word_PARM_2:
      00069F                        110 	.ds 2
      0006A1                        111 _eeprom_update_word_addr_10000_111:
      0006A1                        112 	.ds 3
      0006A4                        113 _eeprom_update_dword_PARM_2:
      0006A4                        114 	.ds 4
      0006A8                        115 _eeprom_update_dword_addr_10000_115:
      0006A8                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004D31                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004D31 12 43 13         [24]  170 	lcall	_ak820_outline_0036
      004D34 90 06 7F         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004D37 12 38 1F         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004D3A 90 06 82         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D3D 12 4F 3C         [24]  175 	lcall	_ak820_outline_0184
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004D40 90 06 7F         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004D43 12 4E E9         [24]  178 	lcall	_ak820_outline_0012
      004D46 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004D49 ED               [12]  180 	mov	a,r5
      004D4A 12 38 1F         [24]  181 	lcall	_ak820_outline_0016
      004D4D 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D50 12 4F 2E         [24]  183 	lcall	_ak820_outline_0112
      004D53 90 06 82         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D56 12 40 AF         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004D59 90 06 82         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D5C 12 4F 25         [24]  188 	lcall	_ak820_outline_0093
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004D5F 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004D60                        201 _eeprom_read_dword:
      004D60 12 43 13         [24]  202 	lcall	_ak820_outline_0036
      004D63 90 06 84         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D66 12 38 1F         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004D69 90 06 87         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D6C 12 4E FA         [24]  207 	lcall	_ak820_outline_0051
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004D6F 90 06 84         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D72 12 4E E9         [24]  210 	lcall	_ak820_outline_0012
      004D75 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004D78 ED               [12]  212 	mov	a,r5
      004D79 12 38 1F         [24]  213 	lcall	_ak820_outline_0016
      004D7C 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D7F 74 04            [12]  215 	mov	a,#0x04
      004D81 12 38 9C         [24]  216 	lcall	_ak820_outline_0136
      004D84 90 06 87         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D87 12 40 AF         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004D8A 90 06 87         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D8D 12 4F 03         [24]  221 	lcall	_ak820_outline_0055
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004D90 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004D91                        234 _eeprom_write_byte:
      004D91 12 43 13         [24]  235 	lcall	_ak820_outline_0036
      004D94 90 06 8C         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D97 12 38 1F         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004D9A 90 06 8C         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D9D 12 4E D2         [24]  240 	lcall	_ak820_outline_0004
      004DA0 74 01            [12]  241 	mov	a,#0x01
      004DA2 12 38 9C         [24]  242 	lcall	_ak820_outline_0136
      004DA5 90 06 8B         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004DA8 02 41 3B         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004DAB                        256 _eeprom_write_word:
      004DAB 12 43 13         [24]  257 	lcall	_ak820_outline_0036
      004DAE 90 06 91         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004DB1 12 38 1F         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004DB4 90 06 91         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004DB7 12 4E D2         [24]  262 	lcall	_ak820_outline_0004
      004DBA 12 4F 2E         [24]  263 	lcall	_ak820_outline_0112
      004DBD 90 06 8F         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004DC0 02 41 3B         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004DC3                        277 _eeprom_write_dword:
      004DC3 12 43 13         [24]  278 	lcall	_ak820_outline_0036
      004DC6 90 06 98         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004DC9 12 38 1F         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004DCC 90 06 98         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004DCF 12 4E D2         [24]  283 	lcall	_ak820_outline_0004
      004DD2 74 04            [12]  284 	mov	a,#0x04
      004DD4 12 38 9C         [24]  285 	lcall	_ak820_outline_0136
      004DD7 90 06 94         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004DDA 02 41 3B         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004DDD                        307 _eeprom_update_byte:
      004DDD C0 07            [24]  308 	push	ar7
      004DDF C0 06            [24]  309 	push	ar6
      004DE1 C0 05            [24]  310 	push	ar5
      004DE3 C0 04            [24]  311 	push	ar4
      004DE5 12 43 13         [24]  312 	lcall	_ak820_outline_0036
      004DE8 90 06 9C         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004DEB 12 38 1F         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004DEE 90 06 9C         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004DF1 12 4E C3         [24]  317 	lcall	_ak820_outline_0001
      004DF4 12 40 74         [24]  318 	lcall	_eeprom_read_byte
      004DF7 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004DF9 90 06 9B         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004DFC E0               [24]  322 	movx	a,@dptr
      004DFD FE               [12]  323 	mov	r6,a
      004DFE EF               [12]  324 	mov	a,r7
      004DFF B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004E02 80 35            [24]  326 	sjmp	00103$
      004E04                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004E04 90 06 9C         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E07 12 38 58         [24]  330 	lcall	_ak820_outline_0061
      004E0A A3               [24]  331 	inc	dptr
      004E0B E0               [24]  332 	movx	a,@dptr
      004E0C FF               [12]  333 	mov	r7,a
      004E0D 90 06 8B         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004E10 EE               [12]  335 	mov	a,r6
      004E11 12 38 76         [24]  336 	lcall	_ak820_outline_0103
      004E14 8F F0            [24]  337 	mov	b, r7
      004E16 C0 07            [24]  338 	push	ar7
      004E18 C0 06            [24]  339 	push	ar6
      004E1A C0 05            [24]  340 	push	ar5
      004E1C C0 04            [24]  341 	push	ar4
      004E1E C0 03            [24]  342 	push	ar3
      004E20 C0 02            [24]  343 	push	ar2
      004E22 C0 01            [24]  344 	push	ar1
      004E24 C0 00            [24]  345 	push	ar0
      004E26 12 4D 91         [24]  346 	lcall	_eeprom_write_byte
      004E29 D0 00            [24]  347 	pop	ar0
      004E2B D0 01            [24]  348 	pop	ar1
      004E2D D0 02            [24]  349 	pop	ar2
      004E2F D0 03            [24]  350 	pop	ar3
      004E31 D0 04            [24]  351 	pop	ar4
      004E33 D0 05            [24]  352 	pop	ar5
      004E35 D0 06            [24]  353 	pop	ar6
      004E37 D0 07            [24]  354 	pop	ar7
      004E39                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      004E39 D0 04            [24]  357 	pop	ar4
      004E3B D0 05            [24]  358 	pop	ar5
      004E3D D0 06            [24]  359 	pop	ar6
      004E3F D0 07            [24]  360 	pop	ar7
      004E41 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      004E42                        373 _eeprom_update_word:
      004E42 12 43 13         [24]  374 	lcall	_ak820_outline_0036
      004E45 90 06 A1         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E48 12 38 1F         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004E4B 90 06 A1         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E4E 12 4E C3         [24]  379 	lcall	_ak820_outline_0001
      004E51 12 4D 31         [24]  380 	lcall	_eeprom_read_word
      004E54 12 43 5C         [24]  381 	lcall	_ak820_outline_0135
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004E57 90 06 9F         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      004E5A 12 38 58         [24]  384 	lcall	_ak820_outline_0061
      004E5D EE               [12]  385 	mov	a,r6
      004E5E B5 04 05         [24]  386 	cjne	a,ar4,00112$
      004E61 EF               [12]  387 	mov	a,r7
      004E62 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      004E65 22               [24]  389 	ret
      004E66                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004E66 90 06 A1         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E69 E0               [24]  393 	movx	a,@dptr
      004E6A FB               [12]  394 	mov	r3,a
      004E6B A3               [24]  395 	inc	dptr
      004E6C 12 38 41         [24]  396 	lcall	_ak820_outline_0052
      004E6F 90 06 8F         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      004E72 12 38 5E         [24]  398 	lcall	_ak820_outline_0072
      004E75 8B 82            [24]  399 	mov	dpl, r3
      004E77 8E 83            [24]  400 	mov	dph, r6
      004E79 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      004E7B 02 4D AB         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      004E7E                        415 _eeprom_update_dword:
      004E7E 12 43 13         [24]  416 	lcall	_ak820_outline_0036
      004E81 90 06 A8         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E84 12 38 1F         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004E87 90 06 A8         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E8A 12 4E C3         [24]  421 	lcall	_ak820_outline_0001
      004E8D 12 4D 60         [24]  422 	lcall	_eeprom_read_dword
      004E90 12 4F 14         [24]  423 	lcall	_ak820_outline_0057
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004E93 90 06 A4         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      004E96 E0               [24]  426 	movx	a,@dptr
      004E97 F8               [12]  427 	mov	r0,a
      004E98 A3               [24]  428 	inc	dptr
      004E99 12 4F 1C         [24]  429 	lcall	_ak820_outline_0092
      004E9C EC               [12]  430 	mov	a,r4
      004E9D B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004EA0 ED               [12]  432 	mov	a,r5
      004EA1 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004EA4 EE               [12]  434 	mov	a,r6
      004EA5 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004EA8 EF               [12]  436 	mov	a,r7
      004EA9 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004EAC 22               [24]  438 	ret
      004EAD                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004EAD 90 06 A8         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004EB0 12 4E E9         [24]  442 	lcall	_ak820_outline_0012
      004EB3 90 06 94         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004EB6 E8               [12]  444 	mov	a,r0
      004EB7 F0               [24]  445 	movx	@dptr,a
      004EB8 E9               [12]  446 	mov	a,r1
      004EB9 A3               [24]  447 	inc	dptr
      004EBA 12 4F 35         [24]  448 	lcall	_ak820_outline_0158
      004EBD 12 4E F2         [24]  449 	lcall	_ak820_outline_0034
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      004EC0 02 4D C3         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0012
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0034
                                    463 	.globl _ak820_outline_0036
                                    464 	.globl _ak820_outline_0051
                                    465 	.globl _ak820_outline_0052
                                    466 	.globl _ak820_outline_0055
                                    467 	.globl _ak820_outline_0057
                                    468 	.globl _ak820_outline_0061
                                    469 	.globl _ak820_outline_0072
                                    470 	.globl _ak820_outline_0092
                                    471 	.globl _ak820_outline_0093
                                    472 	.globl _ak820_outline_0103
                                    473 	.globl _ak820_outline_0112
                                    474 	.globl _ak820_outline_0135
                                    475 	.globl _ak820_outline_0136
                                    476 	.globl _ak820_outline_0158
                                    477 	.globl _ak820_outline_0184
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      004EC3                        481 _ak820_outline_0001:
      004EC3 E0               [24]  482 	movx	a,@dptr
      004EC4 FD               [12]  483 	mov	r5,a
      004EC5 A3               [24]  484 	inc	dptr
      004EC6 E0               [24]  485 	movx	a,@dptr
      004EC7 FE               [12]  486 	mov	r6,a
      004EC8 A3               [24]  487 	inc	dptr
      004EC9 E0               [24]  488 	movx	a,@dptr
      004ECA FF               [12]  489 	mov	r7,a
      004ECB 8D 82            [24]  490 	mov	dpl,r5
      004ECD 8E 83            [24]  491 	mov	dph,r6
      004ECF 8F F0            [24]  492 	mov	b,r7
      004ED1 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      004ED2                        497 _ak820_outline_0004:
      004ED2 E0               [24]  498 	movx	a,@dptr
      004ED3 FD               [12]  499 	mov	r5,a
      004ED4 A3               [24]  500 	inc	dptr
      004ED5 E0               [24]  501 	movx	a,@dptr
      004ED6 FE               [12]  502 	mov	r6,a
      004ED7 A3               [24]  503 	inc	dptr
      004ED8 E0               [24]  504 	movx	a,@dptr
      004ED9 FF               [12]  505 	mov	r7,a
      004EDA 90 05 8E         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004EDD ED               [12]  507 	mov	a,r5
      004EDE F0               [24]  508 	movx	@dptr,a
      004EDF EE               [12]  509 	mov	a,r6
      004EE0 A3               [24]  510 	inc	dptr
      004EE1 F0               [24]  511 	movx	@dptr,a
      004EE2 EF               [12]  512 	mov	a,r7
      004EE3 A3               [24]  513 	inc	dptr
      004EE4 F0               [24]  514 	movx	@dptr,a
      004EE5 90 05 91         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004EE8 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0012
      004EE9                        520 _ak820_outline_0012:
      004EE9 E0               [24]  521 	movx	a,@dptr
      004EEA FD               [12]  522 	mov	r5,a
      004EEB A3               [24]  523 	inc	dptr
      004EEC E0               [24]  524 	movx	a,@dptr
      004EED FE               [12]  525 	mov	r6,a
      004EEE A3               [24]  526 	inc	dptr
      004EEF E0               [24]  527 	movx	a,@dptr
      004EF0 FF               [12]  528 	mov	r7,a
      004EF1 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0034
      004EF2                        533 _ak820_outline_0034:
      004EF2 F0               [24]  534 	movx	@dptr,a
      004EF3 8D 82            [24]  535 	mov	dpl,r5
      004EF5 8E 83            [24]  536 	mov	dph,r6
      004EF7 8F F0            [24]  537 	mov	b,r7
      004EF9 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0051
      004EFA                        542 _ak820_outline_0051:
      004EFA E4               [12]  543 	clr	a
      004EFB F0               [24]  544 	movx	@dptr,a
      004EFC A3               [24]  545 	inc	dptr
      004EFD F0               [24]  546 	movx	@dptr,a
      004EFE A3               [24]  547 	inc	dptr
      004EFF F0               [24]  548 	movx	@dptr,a
      004F00 A3               [24]  549 	inc	dptr
      004F01 F0               [24]  550 	movx	@dptr,a
      004F02 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0055
      004F03                        555 _ak820_outline_0055:
      004F03 E0               [24]  556 	movx	a,@dptr
      004F04 FC               [12]  557 	mov	r4,a
      004F05 A3               [24]  558 	inc	dptr
      004F06 E0               [24]  559 	movx	a,@dptr
      004F07 FD               [12]  560 	mov	r5,a
      004F08 A3               [24]  561 	inc	dptr
      004F09 E0               [24]  562 	movx	a,@dptr
      004F0A FE               [12]  563 	mov	r6,a
      004F0B A3               [24]  564 	inc	dptr
      004F0C E0               [24]  565 	movx	a,@dptr
      004F0D 8C 82            [24]  566 	mov	dpl,r4
      004F0F 8D 83            [24]  567 	mov	dph,r5
      004F11 8E F0            [24]  568 	mov	b,r6
      004F13 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0057
      004F14                        573 _ak820_outline_0057:
      004F14 AC 82            [24]  574 	mov	r4,dpl
      004F16 AD 83            [24]  575 	mov	r5,dph
      004F18 AE F0            [24]  576 	mov	r6,b
      004F1A FF               [12]  577 	mov	r7,a
      004F1B 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0092
      004F1C                        582 _ak820_outline_0092:
      004F1C E0               [24]  583 	movx	a,@dptr
      004F1D F9               [12]  584 	mov	r1,a
      004F1E A3               [24]  585 	inc	dptr
      004F1F E0               [24]  586 	movx	a,@dptr
      004F20 FA               [12]  587 	mov	r2,a
      004F21 A3               [24]  588 	inc	dptr
      004F22 E0               [24]  589 	movx	a,@dptr
      004F23 FB               [12]  590 	mov	r3,a
      004F24 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0093
      004F25                        595 _ak820_outline_0093:
      004F25 E0               [24]  596 	movx	a,@dptr
      004F26 FE               [12]  597 	mov	r6,a
      004F27 A3               [24]  598 	inc	dptr
      004F28 E0               [24]  599 	movx	a,@dptr
      004F29 8E 82            [24]  600 	mov	dpl,r6
      004F2B F5 83            [12]  601 	mov	dph,a
      004F2D 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0112
      004F2E                        606 _ak820_outline_0112:
      004F2E 74 02            [12]  607 	mov	a,#0x02
      004F30 F0               [24]  608 	movx	@dptr,a
      004F31 E4               [12]  609 	clr	a
      004F32 A3               [24]  610 	inc	dptr
      004F33 F0               [24]  611 	movx	@dptr,a
      004F34 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0158
      004F35                        616 _ak820_outline_0158:
      004F35 F0               [24]  617 	movx	@dptr,a
      004F36 EA               [12]  618 	mov	a,r2
      004F37 A3               [24]  619 	inc	dptr
      004F38 F0               [24]  620 	movx	@dptr,a
      004F39 EB               [12]  621 	mov	a,r3
      004F3A A3               [24]  622 	inc	dptr
      004F3B 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0184
      004F3C                        627 _ak820_outline_0184:
      004F3C E4               [12]  628 	clr	a
      004F3D F0               [24]  629 	movx	@dptr,a
      004F3E A3               [24]  630 	inc	dptr
      004F3F F0               [24]  631 	movx	@dptr,a
      004F40 22               [24]  632 	ret
